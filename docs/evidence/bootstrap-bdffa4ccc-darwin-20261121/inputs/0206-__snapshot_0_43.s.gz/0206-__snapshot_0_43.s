	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_ws_values_minimum_storage   ; -- Begin function nl_ws_values_minimum_storage
	.p2align	2
_nl_ws_values_minimum_storage:          ; @nl_ws_values_minimum_storage
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	mov	w8, #8856                       ; =0x2298
	str	x8, [x0]
LBB0_2:
	cmp	x0, #0
	cset	w0, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_create_bounded    ; -- Begin function nl_ws_values_create_bounded
	.p2align	2
_nl_ws_values_create_bounded:           ; @nl_ws_values_create_bounded
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB1_8
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB1_9
; %bb.2:
	ldr	x9, [x2]
	cbnz	x9, LBB1_9
; %bb.3:
	ldr	w9, [x8, #16]
	mov	w10, #60000                     ; =0xea60
	cmp	w9, w10
	b.hi	LBB1_9
; %bb.4:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x19, [x8, #8]
	cbz	x19, LBB1_10
; %bb.5:
	mov	x20, x8
	mov	x21, x1
	mov	x22, x2
	mov	x0, x19
	bl	_strlen
	sub	x8, x0, #1, lsl #12             ; =4096
	cmn	x8, #4095
	b.lo	LBB1_7
; %bb.6:
	ldrb	w8, [x19]
	cmp	w8, #47
	mov	x2, x22
	mov	x1, x21
	mov	x8, x20
	b.eq	LBB1_11
LBB1_7:
	mov	w0, #1                          ; =0x1
	b	LBB1_20
LBB1_8:
	mov	w0, #1                          ; =0x1
LBB1_9:
	ret
LBB1_10:
	mov	x0, #0                          ; =0x0
LBB1_11:
	lsr	x9, x1, #3
	cmp	x9, #1107
	b.hs	LBB1_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	b	LBB1_20
LBB1_13:
	mov	x22, x0
	mov	x25, x8
	mov	x20, x1
	mov	x21, x2
	add	x0, sp, #8
	bl	_nl_ws_transport_storage_bound
	mov	x8, x0
	mov	w0, #5                          ; =0x5
	cbz	w8, LBB1_20
; %bb.14:
	adrp	x23, _wv_identity@PAGE
	ldr	x24, [x23, _wv_identity@PAGEOFF]
	cmn	x24, #1
	b.eq	LBB1_20
; %bb.15:
	mov	w0, #1                          ; =0x1
	mov	w1, #8856                       ; =0x2298
	bl	_calloc
	cbz	x0, LBB1_19
; %bb.16:
	mov	x19, x0
	ldr	q0, [x25]
	stur	q0, [x0, #24]
	ldp	x1, x8, [x25, #8]
	str	x8, [x0, #40]
	ldr	x8, [sp, #8]
	stp	x20, x8, [x0, #8]
	cbz	x1, LBB1_18
; %bb.17:
	add	x20, x19, #48
	add	x2, x22, #1
	mov	x0, x20
	mov	w3, #8808                       ; =0x2268
	bl	___memcpy_chk
	str	x20, [x19, #32]
LBB1_18:
	mov	w0, #0                          ; =0x0
	add	x8, x24, #1
	str	x8, [x23, _wv_identity@PAGEOFF]
	str	x8, [x19]
	str	x19, [x21]
	b	LBB1_20
LBB1_19:
	mov	w0, #6                          ; =0x6
LBB1_20:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_create            ; -- Begin function nl_ws_values_create
	.p2align	2
_nl_ws_values_create:                   ; @nl_ws_values_create
	.cfi_startproc
; %bb.0:
	mov	x2, x1
	mov	x1, #-1                         ; =0xffffffffffffffff
	b	_nl_ws_values_create_bounded
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_connect           ; -- Begin function nl_ws_values_connect
	.p2align	2
_nl_ws_values_connect:                  ; @nl_ws_values_connect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	cbz	x0, LBB3_19
; %bb.1:
	mov	w8, #4144                       ; =0x1030
	ldrb	w8, [x0, x8]
	tbz	w8, #0, LBB3_3
; %bb.2:
	mov	w8, #7                          ; =0x7
	b	LBB3_20
LBB3_3:
	cbz	x4, LBB3_19
; %bb.4:
	ldr	x9, [x4]
	mov	w8, #1                          ; =0x1
	cbnz	x9, LBB3_20
; %bb.5:
	ldr	x9, [x4, #8]
	cbnz	x9, LBB3_20
; %bb.6:
	ldr	w9, [x4, #16]
	cbnz	w9, LBB3_20
; %bb.7:
	cbnz	x1, LBB3_9
; %bb.8:
	cbnz	x2, LBB3_20
LBB3_9:
	cbz	x1, LBB3_11
; %bb.10:
	sub	x8, x4, x1
	cmp	x8, x2
	cset	w8, hs
	subs	x9, x1, x4
	cmp	x9, #23
	cset	w9, hi
	cmp	x1, x4
	csel	w8, w9, w8, hi
	cmp	w8, #1
	b.ne	LBB3_19
LBB3_11:
	mov	x19, #0                         ; =0x0
	mov	w8, #4248                       ; =0x1098
	add	x20, x0, x8
	b	LBB3_13
LBB3_12:                                ;   in Loop: Header=BB3_13 Depth=1
	add	x19, x19, #1
	add	x20, x20, #72
	mov	w8, #5                          ; =0x5
	cmp	x19, #64
	b.eq	LBB3_20
LBB3_13:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #16]
	cbnz	w8, LBB3_12
; %bb.14:                               ;   in Loop: Header=BB3_13 Depth=1
	ldr	x8, [x20]
	cmn	x8, #1
	b.eq	LBB3_12
; %bb.15:                               ;   in Loop: Header=BB3_13 Depth=1
	ldr	x8, [x20, #8]
	cmn	x8, #1
	b.eq	LBB3_12
; %bb.16:
	stp	xzr, xzr, [sp, #40]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #64]
	str	wzr, [sp, #80]
	stur	xzr, [sp, #54]
	mov	w8, #60000                      ; =0xea60
	cmp	x3, x8
	b.hi	LBB3_22
; %bb.17:
	mov	w8, #4344                       ; =0x10f8
	add	x8, x0, x8
	mov	w9, #4488                       ; =0x1188
	add	x9, x0, x9
	mov	w10, #4632                      ; =0x1218
	add	x10, x0, x10
	mov	w11, #4776                      ; =0x12a8
	ldr	d0, [x0, #4272]
	ld1.d	{ v0 }[1], [x8]
	ldr	d1, [x0, #4416]
	ld1.d	{ v1 }[1], [x9]
	ldr	d2, [x0, #4560]
	ld1.d	{ v2 }[1], [x10]
	add	x8, x0, x11
	ldr	d3, [x0, #4704]
	ld1.d	{ v3 }[1], [x8]
	cmeq.2d	v0, v0, #0
	mov	w8, #1                          ; =0x1
	dup.2d	v4, x8
	bic.16b	v0, v4, v0
	cmeq.2d	v1, v1, #0
	bic.16b	v1, v4, v1
	cmeq.2d	v2, v2, #0
	bic.16b	v2, v4, v2
	cmeq.2d	v3, v3, #0
	bic.16b	v3, v4, v3
	mov	w8, #4920                       ; =0x1338
	add	x8, x0, x8
	mov	w9, #5064                       ; =0x13c8
	add	x9, x0, x9
	mov	w10, #5208                      ; =0x1458
	add	x10, x0, x10
	mov	w11, #5352                      ; =0x14e8
	add	x11, x0, x11
	ldr	d4, [x0, #4848]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #4992]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #5136]
	ld1.d	{ v6 }[1], [x10]
	ldr	d7, [x0, #5280]
	ld1.d	{ v7 }[1], [x11]
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v7, v7
	sub.2d	v4, v0, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	sub.2d	v0, v3, v7
	mov	w8, #5496                       ; =0x1578
	add	x8, x0, x8
	mov	w9, #5640                       ; =0x1608
	add	x9, x0, x9
	mov	w10, #5784                      ; =0x1698
	add	x10, x0, x10
	mov	w11, #5928                      ; =0x1728
	add	x11, x0, x11
	ldr	d3, [x0, #5424]
	ld1.d	{ v3 }[1], [x8]
	ldr	d5, [x0, #5568]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #5712]
	ld1.d	{ v6 }[1], [x10]
	ldr	d7, [x0, #5856]
	ld1.d	{ v7 }[1], [x11]
	cmtst.2d	v3, v3, v3
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v7, v7
	sub.2d	v3, v4, v3
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	mov	w8, #6072                       ; =0x17b8
	add	x8, x0, x8
	mov	w9, #6216                       ; =0x1848
	add	x9, x0, x9
	mov	w10, #6360                      ; =0x18d8
	add	x10, x0, x10
	mov	w11, #6504                      ; =0x1968
	add	x11, x0, x11
	ldr	d4, [x0, #6000]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #6144]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #6288]
	ld1.d	{ v6 }[1], [x10]
	ldr	d16, [x0, #6432]
	ld1.d	{ v16 }[1], [x11]
	sub.2d	v0, v0, v7
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v16, v16
	sub.2d	v3, v3, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	sub.2d	v0, v0, v7
	mov	w8, #6648                       ; =0x19f8
	add	x8, x0, x8
	mov	w9, #6792                       ; =0x1a88
	add	x9, x0, x9
	mov	w10, #6936                      ; =0x1b18
	add	x10, x0, x10
	mov	w11, #7080                      ; =0x1ba8
	add	x11, x0, x11
	ldr	d4, [x0, #6576]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #6720]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #6864]
	ld1.d	{ v6 }[1], [x10]
	ldr	d7, [x0, #7008]
	ld1.d	{ v7 }[1], [x11]
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v7, v7
	sub.2d	v3, v3, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	sub.2d	v0, v0, v7
	mov	w8, #7224                       ; =0x1c38
	add	x8, x0, x8
	mov	w9, #7368                       ; =0x1cc8
	add	x9, x0, x9
	mov	w10, #7512                      ; =0x1d58
	add	x10, x0, x10
	mov	w11, #7656                      ; =0x1de8
	add	x11, x0, x11
	ldr	d4, [x0, #7152]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #7296]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #7440]
	ld1.d	{ v6 }[1], [x10]
	ldr	d7, [x0, #7584]
	ld1.d	{ v7 }[1], [x11]
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v7, v7
	sub.2d	v3, v3, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	mov	w8, #7800                       ; =0x1e78
	add	x8, x0, x8
	mov	w9, #7944                       ; =0x1f08
	add	x9, x0, x9
	mov	w10, #8088                      ; =0x1f98
	add	x10, x0, x10
	mov	w11, #8232                      ; =0x2028
	add	x11, x0, x11
	ldr	d4, [x0, #7728]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #7872]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #8016]
	ld1.d	{ v6 }[1], [x10]
	ldr	d16, [x0, #8160]
	ld1.d	{ v16 }[1], [x11]
	sub.2d	v0, v0, v7
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v16, v16
	sub.2d	v3, v3, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	sub.2d	v0, v0, v7
	mov	w8, #8376                       ; =0x20b8
	add	x8, x0, x8
	mov	w9, #8520                       ; =0x2148
	add	x9, x0, x9
	mov	w10, #8664                      ; =0x21d8
	add	x10, x0, x10
	mov	w11, #8808                      ; =0x2268
	add	x11, x0, x11
	ldr	d4, [x0, #8304]
	ld1.d	{ v4 }[1], [x8]
	ldr	d5, [x0, #8448]
	ld1.d	{ v5 }[1], [x9]
	ldr	d6, [x0, #8592]
	ld1.d	{ v6 }[1], [x10]
	ldr	d7, [x0, #8736]
	ld1.d	{ v7 }[1], [x11]
	cmtst.2d	v4, v4, v4
	cmtst.2d	v5, v5, v5
	cmtst.2d	v6, v6, v6
	cmtst.2d	v7, v7, v7
	sub.2d	v3, v3, v4
	sub.2d	v1, v1, v5
	sub.2d	v2, v2, v6
	sub.2d	v0, v0, v7
	add.2d	v1, v1, v3
	add.2d	v0, v0, v2
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x8, d0
	mov	x9, #-8856                      ; =0xffffffffffffdd68
	ldp	x10, x11, [x0, #8]
	add	x9, x10, x9
	udiv	x9, x9, x11
	cmp	x8, x9
	b.hs	LBB3_22
; %bb.18:
	mov	x8, sp
	mov	x21, x0
	mov	x9, x2
	add	x2, x0, #24
	mov	x22, x4
	add	x4, sp, #40
	mov	x0, x1
	mov	x1, x9
                                        ; kill: def $w3 killed $w3 killed $x3
	bl	_nl_ws_transport_connect
	mov	x4, x22
	ldr	w10, [sp]
	ldur	q0, [sp, #4]
	str	q0, [sp, #64]
	ldr	w8, [sp, #20]
	str	w8, [sp, #80]
	ldrb	w8, [sp, #24]
	ldrb	w9, [sp, #25]
	ldur	x11, [sp, #26]
	str	x11, [sp, #48]
	ldr	x11, [sp, #32]
	stur	x11, [sp, #54]
	ldr	x11, [x20]
	add	x11, x11, #1
	str	x11, [x20]
	cmp	w10, #0
	mov	w12, #2                         ; =0x2
	cinc	w13, w12, ne
	ldr	x12, [sp, #40]
	b	LBB3_23
LBB3_19:
	mov	w8, #1                          ; =0x1
LBB3_20:
	ldur	x9, [x29, #-40]
Lloh3:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB3_33
; %bb.21:
	mov	x0, x8
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB3_22:
	mov	x21, x0
	mov	x12, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	ldr	x10, [x20]
	add	x11, x10, #1
	str	x11, [x20]
	mov	w13, #3                         ; =0x3
	mov	w10, #4                         ; =0x4
LBB3_23:
	str	w13, [x20, #16]
	str	x12, [x20, #24]
	str	w10, [x20, #32]
	ldr	q0, [sp, #64]
	stur	q0, [x20, #36]
	ldr	w12, [sp, #80]
	str	w12, [x20, #52]
	strb	w8, [x20, #56]
	strb	w9, [x20, #57]
	ldr	x12, [sp, #48]
	stur	x12, [x20, #58]
	ldur	x12, [sp, #54]
	str	x12, [x20, #64]
	tbnz	w8, #0, LBB3_25
; %bb.24:
	tbz	w9, #0, LBB3_32
LBB3_25:
	ldr	x12, [x21, #4160]
	cmn	x12, #1
	b.eq	LBB3_32
; %bb.26:
	cbz	x12, LBB3_29
; %bb.27:
	cmp	x12, #1
	b.ne	LBB3_31
; %bb.28:
	mov	w11, #4208                      ; =0x1070
	b	LBB3_30
LBB3_29:
	mov	w11, #4168                      ; =0x1048
LBB3_30:
	add	x11, x21, x11
	str	w10, [x11]
	ldr	q0, [sp, #64]
	stur	q0, [x11, #4]
	ldr	w10, [sp, #80]
	str	w10, [x11, #20]
	strb	w8, [x11, #24]
	strb	w9, [x11, #25]
	ldr	x8, [sp, #48]
	stur	x8, [x11, #26]
	ldur	x8, [sp, #54]
	str	x8, [x11, #32]
	ldr	x11, [x20]
LBB3_31:
	add	x8, x12, #1
	str	x8, [x21, #4160]
LBB3_32:
	mov	w8, #0                          ; =0x0
	ldr	x9, [x21]
	stp	x9, x11, [x4]
	stp	w19, wzr, [x4, #16]
	b	LBB3_20
LBB3_33:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_move               ; -- Begin function nl_ws_value_move
	.p2align	2
_nl_ws_value_move:                      ; @nl_ws_value_move
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB4_19
; %bb.1:
	cbz	x2, LBB4_19
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB4_19
; %bb.3:
	cbz	x8, LBB4_19
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB4_19
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB4_19
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB4_19
; %bb.7:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB4_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB4_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB4_16
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB4_16
; %bb.11:
	ldr	x10, [x1, #8]
	cbz	x10, LBB4_16
; %bb.12:
	mov	w11, #72                        ; =0x48
	umaddl	x11, w9, w11, x8
	ldr	w12, [x11, #4264]
	cbz	w12, LBB4_16
; %bb.13:
	mov	w12, #4248                      ; =0x1098
	add	x11, x11, x12
	ldr	x12, [x11]
	cmp	x12, x10
	b.ne	LBB4_16
; %bb.14:
	ldrb	w12, [x11, #20]
	tbz	w12, #0, LBB4_17
; %bb.15:
	mov	w0, #4                          ; =0x4
	ret
LBB4_16:
	mov	w0, #2                          ; =0x2
	ret
LBB4_17:
	cmn	x10, #1
	b.eq	LBB4_20
; %bb.18:
	mov	w0, #0                          ; =0x0
	add	x10, x10, #1
	str	x10, [x11]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldr	x10, [x11]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB4_19:
	ret
LBB4_20:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_connect_take_ok          ; -- Begin function nl_ws_connect_take_ok
	.p2align	2
_nl_ws_connect_take_ok:                 ; @nl_ws_connect_take_ok
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB5_21
; %bb.1:
	cbz	x2, LBB5_21
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB5_21
; %bb.3:
	cbz	x8, LBB5_21
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB5_21
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB5_21
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB5_21
; %bb.7:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB5_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB5_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB5_17
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB5_17
; %bb.11:
	ldr	x10, [x1, #8]
	cbz	x10, LBB5_17
; %bb.12:
	mov	w11, #72                        ; =0x48
	umaddl	x11, w9, w11, x8
	ldr	w12, [x11, #4264]
	cbz	w12, LBB5_17
; %bb.13:
	mov	w13, #4248                      ; =0x1098
	add	x11, x11, x13
	ldr	x13, [x11]
	cmp	x13, x10
	b.ne	LBB5_17
; %bb.14:
	cmp	w12, #2
	b.ne	LBB5_18
; %bb.15:
	ldrb	w12, [x11, #20]
	tbz	w12, #0, LBB5_19
; %bb.16:
	mov	w0, #4                          ; =0x4
	ret
LBB5_17:
	mov	w0, #2                          ; =0x2
	ret
LBB5_18:
	mov	w0, #3                          ; =0x3
	ret
LBB5_19:
	cmn	x10, #1
	b.eq	LBB5_22
; %bb.20:
	mov	w0, #0                          ; =0x0
	add	x10, x10, #1
	str	x10, [x11]
	mov	w10, #1                         ; =0x1
	str	w10, [x11, #16]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldr	x10, [x11]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB5_21:
	ret
LBB5_22:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_connect_view             ; -- Begin function nl_ws_connect_view
	.p2align	2
_nl_ws_connect_view:                    ; @nl_ws_connect_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh6:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x9, [x9]
	stur	x9, [x29, #-8]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB6_16
; %bb.1:
	cbz	x2, LBB6_16
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #24
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #48
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB6_16
; %bb.3:
	tbnz	w9, #0, LBB6_16
; %bb.4:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB6_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB6_16
LBB6_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB6_15
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB6_15
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB6_15
; %bb.9:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #4264]
	cbz	w9, LBB6_15
; %bb.10:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	x11, x10
	b.ne	LBB6_15
; %bb.11:
	and	w10, w9, #0xfffffffe
	cmp	w10, #2
	b.ne	LBB6_18
; %bb.12:
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #31]
	stp	q0, q0, [sp]
	cmp	w9, #2
	cset	w9, eq
	b.eq	LBB6_14
; %bb.13:
	ldp	q0, q1, [x8, #32]
	stur	q0, [sp, #7]
	stur	q1, [sp, #23]
	ldr	x8, [x8, #64]
	stur	x8, [sp, #39]
LBB6_14:
	mov	w0, #0                          ; =0x0
	strb	w9, [x2]
	ldp	q0, q1, [sp]
	stur	q0, [x2, #1]
	stur	q1, [x2, #17]
	ldur	q0, [sp, #31]
	str	q0, [x2, #32]
	b	LBB6_16
LBB6_15:
	mov	w0, #2                          ; =0x2
LBB6_16:
	ldur	x8, [x29, #-8]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_19
; %bb.17:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB6_18:
	mov	w0, #3                          ; =0x3
	b	LBB6_16
LBB6_19:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_connect_take_error       ; -- Begin function nl_ws_connect_take_error
	.p2align	2
_nl_ws_connect_take_error:              ; @nl_ws_connect_take_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB7_13
; %bb.1:
	cbz	x2, LBB7_13
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #24
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #40
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB7_13
; %bb.3:
	tbnz	w9, #0, LBB7_13
; %bb.4:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB7_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	add	sp, sp, #48
	ret
LBB7_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB7_14
; %bb.7:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB7_14
; %bb.8:
	ldr	x9, [x1, #8]
	cbz	x9, LBB7_14
; %bb.9:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB7_14
; %bb.10:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	x11, x9
	b.ne	LBB7_14
; %bb.11:
	cmp	w10, #3
	b.ne	LBB7_15
; %bb.12:
	mov	w0, #0                          ; =0x0
	ldp	q0, q1, [x8, #32]
	ldr	x10, [x8, #64]
	ldr	x11, [x8, #8]
	movi.2d	v2, #0000000000000000
	stp	q2, q2, [x8]
	stp	q2, q2, [x8, #32]
	str	xzr, [x8, #64]
	stp	x9, x11, [x8]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	str	x10, [x2, #32]
	stp	q0, q1, [x2]
LBB7_13:
	add	sp, sp, #48
	ret
LBB7_14:
	mov	w0, #2                          ; =0x2
	add	sp, sp, #48
	ret
LBB7_15:
	mov	w0, #3                          ; =0x3
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_borrow             ; -- Begin function nl_ws_value_borrow
	.p2align	2
_nl_ws_value_borrow:                    ; @nl_ws_value_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB8_22
; %bb.1:
	cbz	x2, LBB8_22
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #23
	cset	w9, hi
	subs	x10, x1, x2
	cmp	x10, #31
	cset	w10, hi
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB8_22
; %bb.3:
	ldr	x9, [x2]
	cbnz	x9, LBB8_22
; %bb.4:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB8_22
; %bb.5:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB8_22
; %bb.6:
	cbz	x8, LBB8_22
; %bb.7:
	ldr	x9, [x2, #24]
	cbnz	x9, LBB8_22
; %bb.8:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB8_10
; %bb.9:
	mov	w0, #7                          ; =0x7
	ret
LBB8_10:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB8_18
; %bb.11:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB8_18
; %bb.12:
	ldr	x9, [x1, #8]
	cbz	x9, LBB8_18
; %bb.13:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB8_18
; %bb.14:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	x11, x9
	b.ne	LBB8_18
; %bb.15:
	cmp	w10, #1
	b.ne	LBB8_19
; %bb.16:
	ldrb	w9, [x8, #20]
	tbz	w9, #0, LBB8_20
; %bb.17:
	mov	w0, #4                          ; =0x4
	ret
LBB8_18:
	mov	w0, #2                          ; =0x2
	ret
LBB8_19:
	mov	w0, #3                          ; =0x3
	ret
LBB8_20:
	ldr	x9, [x8, #8]
	cmn	x9, #1
	b.eq	LBB8_23
; %bb.21:
	mov	w0, #0                          ; =0x0
	add	x9, x9, #1
	str	x9, [x8, #8]
	mov	w10, #1                         ; =0x1
	strb	w10, [x8, #20]
	ldr	q0, [x1]
	ldr	x8, [x1, #16]
	str	q0, [x2]
	stp	x8, x9, [x2, #16]
LBB8_22:
	ret
LBB8_23:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_end_borrow         ; -- Begin function nl_ws_value_end_borrow
	.p2align	2
_nl_ws_value_end_borrow:                ; @nl_ws_value_end_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB9_13
; %bb.1:
	cbz	x1, LBB9_13
; %bb.2:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB9_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB9_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB9_14
; %bb.5:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB9_14
; %bb.6:
	ldr	x9, [x1, #8]
	cbz	x9, LBB9_14
; %bb.7:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB9_14
; %bb.8:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	w10, #1
	ccmp	x11, x9, #0, eq
	b.ne	LBB9_14
; %bb.9:
	ldrb	w9, [x8, #20]
	cmp	w9, #1
	b.ne	LBB9_14
; %bb.10:
	ldr	x9, [x1, #24]
	cbz	x9, LBB9_14
; %bb.11:
	ldr	x10, [x8, #8]
	cmp	x9, x10
	b.ne	LBB9_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	strb	wzr, [x8, #20]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x1]
LBB9_13:
	ret
LBB9_14:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wv_borrow
_wv_borrow:                             ; @wv_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB10_13
; %bb.1:
	cbz	x1, LBB10_13
; %bb.2:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB10_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB10_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB10_14
; %bb.5:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB10_14
; %bb.6:
	ldr	x9, [x1, #8]
	cbz	x9, LBB10_14
; %bb.7:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB10_14
; %bb.8:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	x11, x9
	ccmp	w10, #1, #0, eq
	b.ne	LBB10_14
; %bb.9:
	ldrb	w9, [x8, #20]
	cmp	w9, #1
	b.ne	LBB10_14
; %bb.10:
	ldr	x9, [x1, #24]
	cbz	x9, LBB10_14
; %bb.11:
	ldr	x10, [x8, #8]
	cmp	x9, x10
	b.ne	LBB10_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	str	x8, [x2]
LBB10_13:
	ret
LBB10_14:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_send               ; -- Begin function nl_ws_value_send
	.p2align	2
_nl_ws_value_send:                      ; @nl_ws_value_send
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB11_21
; %bb.1:
	cbz	x6, LBB11_21
; %bb.2:
	cbnz	x3, LBB11_4
; %bb.3:
	cbnz	x4, LBB11_21
LBB11_4:
	sub	x9, x6, x1
	cmp	x9, #31
	cset	w9, hi
	subs	x10, x1, x6
	cmp	x10, #39
	cset	w10, hi
	cmp	x1, x6
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB11_21
; %bb.5:
	cbz	x3, LBB11_8
; %bb.6:
	sub	x9, x6, x3
	cmp	x9, x4
	cset	w9, lo
	subs	x10, x3, x6
	cmp	x10, #40
	cset	w10, lo
	cmp	x3, x6
	csel	w9, w10, w9, hi
	cbz	x8, LBB11_21
; %bb.7:
	tbz	w9, #0, LBB11_9
	b	LBB11_21
LBB11_8:
	cbz	x8, LBB11_21
LBB11_9:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB11_11
; %bb.10:
	mov	w0, #7                          ; =0x7
	ret
LBB11_11:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB11_22
; %bb.12:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB11_22
; %bb.13:
	ldr	x9, [x1, #8]
	cbz	x9, LBB11_22
; %bb.14:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB11_22
; %bb.15:
	mov	w0, #2                          ; =0x2
	cmp	w10, #1
	b.ne	LBB11_21
; %bb.16:
	mov	w10, #4248                      ; =0x1098
	add	x8, x8, x10
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB11_21
; %bb.17:
	ldrb	w9, [x8, #20]
	cmp	w9, #1
	b.ne	LBB11_21
; %bb.18:
	ldr	x9, [x1, #24]
	cbz	x9, LBB11_21
; %bb.19:
	ldr	x10, [x8, #8]
	cmp	x9, x10
	b.ne	LBB11_21
; %bb.20:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w9, #60000                      ; =0xea60
	cmp	x5, x9
	mov	w9, #60001                      ; =0xea61
	csel	w9, w9, w5, hi
	ldr	x0, [x8, #24]
	add	x8, sp, #8
	mov	x1, x2
	mov	x2, x3
	mov	x3, x4
	mov	x4, x9
	mov	x19, x6
	bl	_nl_ws_transport_send
	mov	w0, #0                          ; =0x0
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldr	x8, [sp, #40]
	str	x8, [x19, #32]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB11_21:
	ret
LBB11_22:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_receive            ; -- Begin function nl_ws_value_receive
	.p2align	2
_nl_ws_value_receive:                   ; @nl_ws_value_receive
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB12_4
; %bb.1:
	cbz	x1, LBB12_4
; %bb.2:
	cbz	x4, LBB12_4
; %bb.3:
	ldr	x9, [x3, #8]
	cbz	x9, LBB12_5
LBB12_4:
	ret
LBB12_5:
	ldr	x9, [x3, #16]
	cbnz	x9, LBB12_4
; %bb.6:
	ldrb	w9, [x3]
	tbnz	w9, #0, LBB12_4
; %bb.7:
	sub	x9, x4, x1
	cmp	x9, #31
	cset	w9, hi
	subs	x10, x1, x4
	cmp	x10, #39
	cset	w10, hi
	cmp	x1, x4
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB12_4
; %bb.8:
	sub	x9, x3, x1
	cmp	x9, #31
	cset	w9, hi
	subs	x10, x1, x3
	cmp	x10, #23
	cset	w10, hi
	cmp	x1, x3
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB12_4
; %bb.9:
	sub	x9, x3, x4
	cmp	x9, #39
	cset	w9, hi
	subs	x10, x4, x3
	cmp	x10, #23
	cset	w10, hi
	cmp	x4, x3
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB12_4
; %bb.10:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x19, x3
	mov	x20, x4
	add	x2, sp, #40
	mov	x0, x8
	bl	_wv_borrow
	cbnz	w0, LBB12_12
; %bb.11:
	mov	w8, #60000                      ; =0xea60
	cmp	x21, x8
	mov	w8, #60001                      ; =0xea61
	csel	w1, w8, w21, hi
	ldr	x8, [sp, #40]
	ldr	x9, [x8, #24]
	mov	x8, sp
	mov	x21, x0
	mov	x0, x9
	mov	x2, x19
	bl	_nl_ws_transport_receive
	mov	x0, x21
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20]
	ldr	x8, [sp, #32]
	str	x8, [x20, #32]
LBB12_12:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_close              ; -- Begin function nl_ws_value_close
	.p2align	2
_nl_ws_value_close:                     ; @nl_ws_value_close
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	cbz	x1, LBB13_26
; %bb.1:
	cbz	x3, LBB13_26
; %bb.2:
	sub	x8, x3, x1
	cmp	x8, #24
	cset	w8, lo
	subs	x9, x1, x3
	cmp	x9, #40
	cset	w9, lo
	cmp	x1, x3
	csel	w9, w9, w8, hi
	mov	w8, #1                          ; =0x1
	cbz	x0, LBB13_26
; %bb.3:
	tbnz	w9, #0, LBB13_26
; %bb.4:
	mov	w8, #4144                       ; =0x1030
	ldrb	w8, [x0, x8]
	tbz	w8, #0, LBB13_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	ret
LBB13_6:
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB13_14
; %bb.7:
	ldr	w8, [x1, #16]
	cmp	w8, #63
	b.hi	LBB13_14
; %bb.8:
	ldr	x9, [x1, #8]
	cbz	x9, LBB13_14
; %bb.9:
	mov	w10, #72                        ; =0x48
	umaddl	x8, w8, w10, x0
	ldr	w10, [x8, #4264]
	cbz	w10, LBB13_14
; %bb.10:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	x11, x9
	b.ne	LBB13_14
; %bb.11:
	cmp	w10, #1
	b.ne	LBB13_15
; %bb.12:
	ldrb	w9, [x8, #20]
	tbz	w9, #0, LBB13_16
; %bb.13:
	mov	w0, #4                          ; =0x4
	ret
LBB13_14:
	mov	w0, #2                          ; =0x2
	ret
LBB13_15:
	mov	w0, #3                          ; =0x3
	ret
LBB13_16:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x9, [x8, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #32]
	str	xzr, [x8, #64]
	mov	w10, #60000                     ; =0xea60
	cmp	x2, x10
	mov	w10, #60001                     ; =0xea61
	csel	w1, w10, w2, hi
	str	q0, [x8, #16]
	add	x19, sp, #8
	add	x8, sp, #8
	mov	x20, x0
	mov	x0, x9
	mov	x21, x3
	bl	_nl_ws_transport_close
	mov	x8, x20
	mov	x9, x21
	ldrb	w10, [sp, #32]
	ldrb	w11, [sp, #33]
	tbnz	w10, #0, LBB13_18
; %bb.17:
	tbz	w11, #0, LBB13_25
LBB13_18:
	ldr	x12, [x8, #4160]
	cmn	x12, #1
	b.eq	LBB13_25
; %bb.19:
	cbz	x12, LBB13_22
; %bb.20:
	cmp	x12, #1
	b.ne	LBB13_24
; %bb.21:
	mov	w13, #4208                      ; =0x1070
	b	LBB13_23
LBB13_22:
	mov	w13, #4168                      ; =0x1048
LBB13_23:
	add	x13, x8, x13
	ldur	q0, [sp, #8]
	str	q0, [x13]
	ldr	x14, [sp, #24]
	str	x14, [x13, #16]
	strb	w10, [x13, #24]
	strb	w11, [x13, #25]
	ldur	x10, [x19, #26]
	stur	x10, [x13, #26]
	ldur	x10, [x19, #32]
	str	x10, [x13, #32]
LBB13_24:
	add	x10, x12, #1
	str	x10, [x8, #4160]
LBB13_25:
	mov	w8, #0                          ; =0x0
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x9]
	ldr	x10, [sp, #40]
	str	x10, [x9, #32]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
LBB13_26:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wv_close_slot
_wv_close_slot:                         ; @wv_close_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x19, x0
	mov	x20, x8
	ldr	x22, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x1, #32]
	str	xzr, [x1, #64]
	str	q0, [x1, #16]
	cbz	w3, LBB14_2
; %bb.1:
	add	x8, sp, #8
	mov	x0, x22
	bl	_nl_ws_transport_abort
LBB14_2:
	mov	w8, #60000                      ; =0xea60
	cmp	x21, x8
	mov	w8, #60001                      ; =0xea61
	csel	w1, w8, w21, hi
	mov	x8, x20
	mov	x0, x22
	bl	_nl_ws_transport_close
	ldrb	w8, [x20, #24]
	ldrb	w9, [x20, #25]
	tbnz	w8, #0, LBB14_4
; %bb.3:
	tbz	w9, #0, LBB14_11
LBB14_4:
	ldr	x10, [x19, #4160]
	cmn	x10, #1
	b.eq	LBB14_11
; %bb.5:
	cbz	x10, LBB14_8
; %bb.6:
	cmp	x10, #1
	b.ne	LBB14_10
; %bb.7:
	mov	w11, #4208                      ; =0x1070
	b	LBB14_9
LBB14_8:
	mov	w11, #4168                      ; =0x1048
LBB14_9:
	add	x11, x19, x11
	ldr	q0, [x20]
	str	q0, [x11]
	ldr	x12, [x20, #16]
	str	x12, [x11, #16]
	strb	w8, [x11, #24]
	strb	w9, [x11, #25]
	ldur	x8, [x20, #26]
	stur	x8, [x11, #26]
	ldur	x8, [x20, #32]
	str	x8, [x11, #32]
LBB14_10:
	add	x8, x10, #1
	str	x8, [x19, #4160]
LBB14_11:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_drop               ; -- Begin function nl_ws_value_drop
	.p2align	2
_nl_ws_value_drop:                      ; @nl_ws_value_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_8
; %bb.1:
	mov	w8, #4144                       ; =0x1030
	ldrb	w8, [x0, x8]
	tbz	w8, #0, LBB15_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB15_3:
	cbz	x1, LBB15_8
; %bb.4:
	ldp	x11, x10, [x1]
	ldr	w9, [x1, #16]
	cbnz	x11, LBB15_9
; %bb.5:
	cbnz	x10, LBB15_9
; %bb.6:
	cbnz	w9, LBB15_9
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB15_8:
	mov	w0, #1                          ; =0x1
	ret
LBB15_9:
	ldr	x12, [x0]
	mov	w8, #2                          ; =0x2
	cmp	x11, x12
	b.ne	LBB15_20
; %bb.10:
	cmp	w9, #63
	ccmp	x10, #0, #4, ls
	b.eq	LBB15_20
; %bb.11:
	mov	w8, #72                         ; =0x48
	umaddl	x9, w9, w8, x0
	ldr	w8, [x9, #4264]
	cbz	w8, LBB15_15
; %bb.12:
	mov	w11, #4248                      ; =0x1098
	add	x9, x9, x11
	ldr	x11, [x9]
	cmp	x11, x10
	b.ne	LBB15_15
; %bb.13:
	ldrb	w11, [x9, #20]
	tbz	w11, #0, LBB15_16
; %bb.14:
	mov	w0, #4                          ; =0x4
	ret
LBB15_15:
	mov	w0, #2                          ; =0x2
	ret
LBB15_16:
	cmp	w8, #3
	b.ne	LBB15_18
; %bb.17:
	ldr	x8, [x9, #8]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	str	xzr, [x9, #64]
	stp	x10, x8, [x9]
	b	LBB15_19
LBB15_18:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x8, sp, #8
	mov	x19, x1
	mov	x1, x9
	mov	x2, #0                          ; =0x0
	mov	w3, #1                          ; =0x1
	bl	_wv_close_slot
	mov	x1, x19
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
LBB15_19:
	mov	w8, #0                          ; =0x0
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
LBB15_20:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_validate           ; -- Begin function nl_ws_value_validate
	.p2align	2
_nl_ws_value_validate:                  ; @nl_ws_value_validate
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_10
; %bb.1:
	mov	w8, #4144                       ; =0x1030
	ldrb	w8, [x0, x8]
	tbz	w8, #0, LBB16_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB16_3:
	cbz	x1, LBB16_10
; %bb.4:
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB16_11
; %bb.5:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB16_11
; %bb.6:
	ldr	x8, [x1, #8]
	cbz	x8, LBB16_11
; %bb.7:
	mov	w10, #72                        ; =0x48
	umaddl	x10, w9, w10, x0
	ldr	w9, [x10, #4264]
	cbz	w9, LBB16_11
; %bb.8:
	mov	w11, #4248                      ; =0x1098
	ldr	x10, [x10, x11]
	cmp	x10, x8
	b.ne	LBB16_11
; %bb.9:
	sub	w8, w9, #4
	cmn	w8, #2
	cset	w8, lo
	cmp	w9, #1
	cset	w9, ne
	cmp	w2, #0
	csel	w8, w8, w9, ne
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w0, w9, wzr, ne
	ret
LBB16_10:
	mov	w0, #1                          ; =0x1
	ret
LBB16_11:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_value_borrow_validate    ; -- Begin function nl_ws_value_borrow_validate
	.p2align	2
_nl_ws_value_borrow_validate:           ; @nl_ws_value_borrow_validate
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB17_12
; %bb.1:
	cbz	x1, LBB17_12
; %bb.2:
	mov	w9, #4144                       ; =0x1030
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB17_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB17_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB17_13
; %bb.5:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB17_13
; %bb.6:
	ldr	x9, [x1, #8]
	cbz	x9, LBB17_13
; %bb.7:
	mov	w11, #72                        ; =0x48
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #4264]
	cbz	w10, LBB17_13
; %bb.8:
	mov	w11, #4248                      ; =0x1098
	add	x8, x8, x11
	ldr	x11, [x8]
	cmp	w10, #1
	ccmp	x11, x9, #0, eq
	b.ne	LBB17_13
; %bb.9:
	ldrb	w9, [x8, #20]
	cmp	w9, #1
	b.ne	LBB17_13
; %bb.10:
	ldr	x9, [x1, #24]
	mov	w0, #2                          ; =0x2
	cbz	x9, LBB17_12
; %bb.11:
	ldr	x8, [x8, #8]
	cmp	x9, x8
	csel	w0, wzr, w0, eq
LBB17_12:
	ret
LBB17_13:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_live_slots        ; -- Begin function nl_ws_values_live_slots
	.p2align	2
_nl_ws_values_live_slots:               ; @nl_ws_values_live_slots
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_3
; %bb.1:
	add	x17, x0, #1, lsl #12            ; =4096
	ldrb	w8, [x17, #48]
	tbz	w8, #0, LBB18_4
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB18_3:
	mov	w0, #1                          ; =0x1
	ret
LBB18_4:
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB18_10
; %bb.5:
	cbz	x2, LBB18_10
; %bb.6:
	sub	x8, x2, x1
	subs	x9, x1, x2
	csel	x8, x9, x8, hi
	cmp	x8, #8
	b.lo	LBB18_10
; %bb.7:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	mov	x12, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	add	x17, x17, #388
	mov	w0, #1                          ; =0x1
	mov	w3, #2                          ; =0x2
	mov	w4, #4                          ; =0x4
	mov	w5, #8                          ; =0x8
LBB18_8:                                ; =>This Inner Loop Header: Depth=1
	ldur	w6, [x17, #-220]
	ldur	w7, [x17, #-148]
	ldur	w19, [x17, #-76]
	ldur	w20, [x17, #-4]
	lsl	x21, x0, x12
	lsl	x22, x3, x12
	lsl	x23, x4, x12
	lsl	x24, x5, x12
	cmp	w6, #0
	csel	x6, xzr, x21, eq
	cmp	w7, #0
	csel	x7, xzr, x22, eq
	cmp	w19, #0
	csel	x19, xzr, x23, eq
	cmp	w20, #0
	csel	x20, xzr, x24, eq
	orr	x11, x6, x11
	orr	x14, x7, x14
	orr	x15, x19, x15
	orr	x16, x20, x16
	ldurb	w6, [x17, #-216]
	ldurb	w7, [x17, #-144]
	ldurb	w19, [x17, #-72]
	ldrb	w20, [x17]
	cmp	w6, #0
	csel	x6, x21, xzr, ne
	cmp	w7, #0
	csel	x7, x22, xzr, ne
	cmp	w19, #0
	csel	x19, x23, xzr, ne
	cmp	w20, #0
	csel	x20, x24, xzr, ne
	orr	x8, x6, x8
	orr	x9, x7, x9
	orr	x10, x19, x10
	orr	x13, x20, x13
	add	x12, x12, #4
	add	x17, x17, #288
	cmp	x12, #64
	b.ne	LBB18_8
; %bb.9:
	mov	w0, #0                          ; =0x0
	orr	x8, x9, x8
	orr	x9, x13, x10
	orr	x8, x9, x8
	orr	x9, x14, x11
	orr	x10, x16, x15
	orr	x9, x10, x9
	str	x9, [x1]
	str	x8, [x2]
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
LBB18_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_report            ; -- Begin function nl_ws_values_report
	.p2align	2
_nl_ws_values_report:                   ; @nl_ws_values_report
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB19_2
; %bb.1:
	mov	w9, #4152                       ; =0x1038
	add	x8, x8, x9
	ldp	q0, q1, [x8]
	stp	q0, q1, [x1]
	ldp	q0, q1, [x8, #32]
	ldp	q2, q3, [x8, #64]
	stp	q2, q3, [x1, #64]
	stp	q0, q1, [x1, #32]
LBB19_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_finish            ; -- Begin function nl_ws_values_finish
	.p2align	2
_nl_ws_values_finish:                   ; @nl_ws_values_finish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x8
	cbz	x0, LBB20_4
; %bb.1:
	mov	x20, x0
	add	x22, x0, #1, lsl #12            ; =4096
	ldrb	w8, [x22, #48]
	cmp	w8, #1
	b.ne	LBB20_3
; %bb.2:
	mov	w8, #4152                       ; =0x1038
	add	x8, x20, x8
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [x8]
	b	LBB20_19
LBB20_3:
	cmp	w1, #9
	b.lo	LBB20_5
LBB20_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	b	LBB20_20
LBB20_5:
	mov	w8, #4152                       ; =0x1038
	add	x23, x20, x8
	str	w1, [x20, #4152]
	add	x24, x22, #152
	mov	x25, sp
	mov	w26, #64                        ; =0x40
	movi.2d	v0, #0000000000000000
	b	LBB20_11
LBB20_6:                                ;   in Loop: Header=BB20_11 Depth=1
	mov	w11, #4168                      ; =0x1048
LBB20_7:                                ;   in Loop: Header=BB20_11 Depth=1
	add	x11, x20, x11
	ldr	q0, [sp]
	str	q0, [x11]
	ldr	x12, [sp, #16]
	str	x12, [x11, #16]
	strb	w8, [x11, #24]
	strb	w9, [x11, #25]
	ldur	x8, [x25, #26]
	stur	x8, [x11, #26]
	ldur	x8, [x25, #32]
	str	x8, [x11, #32]
LBB20_8:                                ;   in Loop: Header=BB20_11 Depth=1
	add	x8, x10, #1
	str	x8, [x20, #4160]
LBB20_9:                                ;   in Loop: Header=BB20_11 Depth=1
	movi.2d	v0, #0000000000000000
LBB20_10:                               ;   in Loop: Header=BB20_11 Depth=1
	stp	q0, q0, [x24, #16]
	str	q0, [x24, #48]
	str	xzr, [x24, #64]
	add	x24, x24, #72
	subs	x26, x26, #1
	b.eq	LBB20_18
LBB20_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24, #16]
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB20_10
; %bb.12:                               ;   in Loop: Header=BB20_11 Depth=1
	ldr	x21, [x24, #24]
	stp	q0, q0, [x24, #32]
	str	xzr, [x24, #64]
	str	q0, [x24, #16]
	add	x8, sp, #40
	mov	x0, x21
	bl	_nl_ws_transport_abort
	mov	x8, sp
	mov	x0, x21
	mov	w1, #0                          ; =0x0
	bl	_nl_ws_transport_close
	ldrb	w8, [sp, #24]
	ldrb	w9, [sp, #25]
	tbnz	w8, #0, LBB20_14
; %bb.13:                               ;   in Loop: Header=BB20_11 Depth=1
	tbz	w9, #0, LBB20_9
LBB20_14:                               ;   in Loop: Header=BB20_11 Depth=1
	ldr	x10, [x20, #4160]
	cmn	x10, #1
	b.eq	LBB20_9
; %bb.15:                               ;   in Loop: Header=BB20_11 Depth=1
	cbz	x10, LBB20_6
; %bb.16:                               ;   in Loop: Header=BB20_11 Depth=1
	cmp	x10, #1
	b.ne	LBB20_8
; %bb.17:                               ;   in Loop: Header=BB20_11 Depth=1
	mov	w11, #4208                      ; =0x1070
	b	LBB20_7
LBB20_18:
	mov	w8, #1                          ; =0x1
	strb	w8, [x22, #48]
	ldp	q0, q1, [x23, #32]
	stp	q0, q1, [x19, #32]
	ldp	q0, q1, [x23, #64]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [x23]
LBB20_19:
	stp	q0, q1, [x19]
LBB20_20:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_values_destroy           ; -- Begin function nl_ws_values_destroy
	.p2align	2
_nl_ws_values_destroy:                  ; @nl_ws_values_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nl_ws_values_finish
	cbz	x19, LBB21_3
; %bb.1:
	mov	w8, #4144                       ; =0x1030
	ldrb	w8, [x19, x8]
	cmp	w8, #1
	b.ne	LBB21_3
; %bb.2:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB21_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_wv_identity,8,3 ; @wv_identity
.subsections_via_symbols
