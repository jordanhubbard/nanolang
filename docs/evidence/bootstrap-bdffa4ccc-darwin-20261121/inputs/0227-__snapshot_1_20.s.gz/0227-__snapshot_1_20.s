	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_service_bindings_check ; -- Begin function nvm_service_bindings_check
	.globl	_nvm_service_bindings_check
	.p2align	2
_nvm_service_bindings_check:            ; @nvm_service_bindings_check
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	ldr	w8, [x0]
	cmn	w8, #1
	b.eq	LBB0_4
; %bb.2:
	ldr	w9, [x0, #4]
	cmn	w9, #1
	ccmp	w9, w8, #4, ne
	b.eq	LBB0_4
; %bb.3:
	ldr	w10, [x0, #8]
	cmn	w10, #1
	ccmp	w10, w8, #4, ne
	ccmp	w10, w9, #4, ne
	b.ne	LBB0_6
LBB0_4:
	mov	w0, #8                          ; =0x8
	ret
LBB0_5:
	mov	w0, #1                          ; =0x1
	ret
LBB0_6:
	mov	x12, x0
	ldr	w11, [x0, #12]
	mov	w0, #8                          ; =0x8
	cmn	w11, #1
	b.eq	LBB0_11
; %bb.7:
	cmp	w11, w8
	b.eq	LBB0_11
; %bb.8:
	cmp	w11, w9
	b.eq	LBB0_11
; %bb.9:
	cmp	w11, w10
	b.eq	LBB0_11
; %bb.10:
	ldr	w12, [x12, #16]
	cmp	w12, w11
	ccmp	w12, w10, #4, ne
	ccmp	w12, w9, #4, ne
	ccmp	w12, w8, #4, ne
	ccmn	w12, #1, #4, ne
	mov	w8, #8                          ; =0x8
	csel	w0, w8, wzr, eq
LBB0_11:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_bindings_decode ; -- Begin function nvm_service_bindings_decode
	.globl	_nvm_service_bindings_decode
	.p2align	2
_nvm_service_bindings_decode:           ; @nvm_service_bindings_decode
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB1_10
; %bb.1:
	cbz	x2, LBB1_10
; %bb.2:
	cmp	x1, #56
	b.ne	LBB1_9
; %bb.3:
	ldrh	w9, [x8]
	cmp	w9, #1
	b.ne	LBB1_11
; %bb.4:
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB1_12
; %bb.5:
	ldr	w9, [x8, #4]
	cmp	w9, #5
	b.ne	LBB1_13
; %bb.6:
	ldr	w9, [x8, #8]
	cbnz	w9, LBB1_8
; %bb.7:
	ldr	w9, [x8, #12]
	cbz	w9, LBB1_14
LBB1_8:
	mov	w0, #6                          ; =0x6
	ret
LBB1_9:
	mov	w0, #2                          ; =0x2
LBB1_10:
	ret
LBB1_11:
	mov	w0, #3                          ; =0x3
	ret
LBB1_12:
	mov	w0, #4                          ; =0x4
	ret
LBB1_13:
	mov	w0, #5                          ; =0x5
	ret
LBB1_14:
	ldr	w9, [x8, #16]
	cbz	w9, LBB1_16
; %bb.15:
	mov	w0, #7                          ; =0x7
	ret
LBB1_16:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldp	w9, w10, [x8, #20]
	str	w9, [sp, #12]
	cmp	w10, #1
	b.ne	LBB1_22
; %bb.17:
	ldp	w9, w10, [x8, #28]
	str	w9, [sp, #16]
	cmp	w10, #2
	b.ne	LBB1_22
; %bb.18:
	ldp	w9, w10, [x8, #36]
	str	w9, [sp, #20]
	cmp	w10, #3
	b.ne	LBB1_22
; %bb.19:
	str	x2, [sp]                        ; 8-byte Folded Spill
	ldp	w9, w10, [x8, #44]
	str	w9, [sp, #24]
	cmp	w10, #4
	b.ne	LBB1_22
; %bb.20:
	ldr	w8, [x8, #52]
	str	w8, [sp, #28]
	add	x0, sp, #12
	bl	_nvm_service_bindings_check
	cbnz	w0, LBB1_23
; %bb.21:
	ldur	q0, [sp, #12]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	w9, [sp, #28]
	str	w9, [x8, #16]
	b	LBB1_23
LBB1_22:
	mov	w0, #7                          ; =0x7
LBB1_23:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_service_bindings_encode
lCPI2_0:
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.byte	5                               ; 0x5
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_service_bindings_encode
	.globl	_nvm_service_bindings_encode
	.p2align	2
_nvm_service_bindings_encode:           ; @nvm_service_bindings_encode
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB2_5
; %bb.1:
	cbz	x3, LBB2_5
; %bb.2:
	ldr	w12, [x8]
	cmn	w12, #1
	b.eq	LBB2_4
; %bb.3:
	ldr	w11, [x8, #4]
	cmn	w11, #1
	ccmp	w11, w12, #4, ne
	b.ne	LBB2_6
LBB2_4:
	mov	w0, #8                          ; =0x8
LBB2_5:
	ret
LBB2_6:
	ldr	w9, [x8, #8]
	mov	w0, #8                          ; =0x8
	cmp	w9, w11
	b.eq	LBB2_5
; %bb.7:
	cmn	w9, #1
	b.eq	LBB2_5
; %bb.8:
	cmp	w9, w12
	b.eq	LBB2_5
; %bb.9:
	ldr	w10, [x8, #12]
	cmp	w10, w9
	b.eq	LBB2_5
; %bb.10:
	cmp	w10, w11
	b.eq	LBB2_5
; %bb.11:
	cmn	w10, #1
	b.eq	LBB2_5
; %bb.12:
	cmp	w10, w12
	b.eq	LBB2_5
; %bb.13:
	ldr	w13, [x8, #16]
	cmp	w13, w10
	b.eq	LBB2_5
; %bb.14:
	cmp	w13, w9
	b.eq	LBB2_5
; %bb.15:
	cmp	w13, w11
	b.eq	LBB2_5
; %bb.16:
	cmn	w13, #1
	b.eq	LBB2_5
; %bb.17:
	cmp	w13, w12
	b.eq	LBB2_5
; %bb.18:
	cbz	x1, LBB2_21
; %bb.19:
	cmp	x2, #56
	b.hs	LBB2_21
; %bb.20:
	mov	w0, #2                          ; =0x2
	ret
LBB2_21:
	cbz	x1, LBB2_23
; %bb.22:
	ldr	w8, [x8, #16]
	lsr	w13, w12, #8
Lloh0:
	adrp	x14, lCPI2_0@PAGE
Lloh1:
	ldr	d0, [x14, lCPI2_0@PAGEOFF]
	lsr	w14, w12, #16
	str	d0, [x1]
	lsr	w15, w12, #24
	str	xzr, [x1, #8]
	lsr	w16, w11, #8
	str	wzr, [x1, #16]
	lsr	w17, w11, #16
	strb	w12, [x1, #20]
	lsr	w12, w11, #24
	strb	w13, [x1, #21]
	lsr	w13, w9, #8
	strb	w14, [x1, #22]
	lsr	w14, w9, #16
	strb	w15, [x1, #23]
	lsr	w15, w9, #24
	movi.2s	v0, #1
	str	s0, [x1, #24]
	lsr	w0, w10, #8
	strb	w11, [x1, #28]
	lsr	w11, w10, #16
	strb	w16, [x1, #29]
	lsr	w16, w10, #24
	strb	w17, [x1, #30]
	lsr	w17, w8, #8
	strb	w12, [x1, #31]
	movi.2s	v0, #2
	lsr	w12, w8, #16
	str	s0, [x1, #32]
	lsr	w2, w8, #24
	strb	w9, [x1, #36]
	strb	w13, [x1, #37]
	strb	w14, [x1, #38]
	strb	w15, [x1, #39]
	movi.2s	v0, #3
	str	s0, [x1, #40]
	strb	w10, [x1, #44]
	strb	w0, [x1, #45]
	strb	w11, [x1, #46]
	strb	w16, [x1, #47]
	movi.2s	v0, #4
	str	s0, [x1, #48]
	strb	w8, [x1, #52]
	strb	w17, [x1, #53]
	strb	w12, [x1, #54]
	strb	w2, [x1, #55]
LBB2_23:
	mov	w0, #0                          ; =0x0
	mov	w8, #56                         ; =0x38
	str	x8, [x3]
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
