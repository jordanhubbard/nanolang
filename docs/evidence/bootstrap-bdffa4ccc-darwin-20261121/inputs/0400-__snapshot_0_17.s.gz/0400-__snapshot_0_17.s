	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_nominal_storage_bound ; -- Begin function nvm_socket_nominal_storage_bound
	.p2align	2
_nvm_socket_nominal_storage_bound:      ; @nvm_socket_nominal_storage_bound
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB0_3
	b	LBB0_1
LBB0_1:
	ldur	w8, [x29, #-8]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hi	LBB0_3
	b	LBB0_2
LBB0_2:
	ldur	w8, [x29, #-8]
	mov	x0, x8
	add	x1, sp, #8
	bl	_plan_extent
	tbnz	w0, #0, LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_5
LBB0_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_5
LBB0_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function plan_extent
_plan_extent:                           ; @plan_extent
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	mov	x9, #-3689348814741910324       ; =0xcccccccccccccccc
	movk	x9, #52425
	movk	x9, #3276, lsl #48
	subs	x8, x8, x9
	b.ls	LBB1_2
	b	LBB1_1
LBB1_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp, #16]
	mov	x9, #20                         ; =0x14
	mul	x8, x8, x9
	add	x8, x8, #60
	ldr	x9, [sp, #8]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_3:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_plan        ; -- Begin function nvm_socket_nominal_plan
	.p2align	2
_nvm_socket_nominal_plan:               ; @nvm_socket_nominal_plan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB2_3
	b	LBB2_2
LBB2_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #328]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #336]
	mov	x1, x8
	add	x2, sp, #48
	bl	_nvm_socket_nominal_decode
	cbnz	w0, LBB2_5
	b	LBB2_4
LBB2_4:
	ldur	x0, [x29, #-16]
	add	x1, sp, #48
	bl	_imports_valid
	tbnz	w0, #0, LBB2_6
	b	LBB2_5
LBB2_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_6:
	add	x2, sp, #44
	str	wzr, [sp, #44]
	ldur	x0, [x29, #-16]
	add	x1, sp, #48
	mov	x3, #0                          ; =0x0
	bl	_layouts_read
	str	w0, [sp, #40]
	ldr	w8, [sp, #40]
	cbz	w8, LBB2_8
	b	LBB2_7
LBB2_7:
	ldr	w8, [sp, #40]
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_8:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #44]
	add	x1, sp, #48
	bl	_ownership_valid
	tbnz	w0, #0, LBB2_10
	b	LBB2_9
LBB2_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_10:
	ldr	w8, [sp, #44]
	mov	x0, x8
	add	x1, sp, #32
	bl	_plan_extent
	tbnz	w0, #0, LBB2_12
	b	LBB2_11
LBB2_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_12:
	ldr	x0, [sp, #32]
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_14:
	ldr	x0, [sp, #24]
	add	x1, sp, #48
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #24]
	str	w8, [x9, #56]
	add	x2, sp, #20
	str	wzr, [sp, #20]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #24]
	add	x3, x8, #60
	bl	_layouts_read
	str	w0, [sp, #40]
	ldr	w8, [sp, #40]
	cbnz	w8, LBB2_16
	b	LBB2_15
LBB2_15:
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.eq	LBB2_17
	b	LBB2_16
LBB2_16:
	ldr	x0, [sp, #24]
	bl	_free
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_18
LBB2_17:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB2_18
LBB2_18:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function imports_valid
_imports_valid:                         ; @imports_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	subs	w8, w8, #5
	b.ne	LBB3_4
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #400]
	cbz	x8, LBB3_4
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB3_4
	b	LBB3_3
LBB3_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #424]
	cbz	w8, LBB3_5
	b	LBB3_4
LBB3_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_5:
	stur	wzr, [x29, #-28]
	b	LBB3_6
LBB3_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_24 Depth 2
	ldur	w8, [x29, #-28]
	subs	w8, w8, #5
	b.hs	LBB3_37
	b	LBB3_7
LBB3_7:                                 ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-24]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-32]
	ldur	w8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.lo	LBB3_9
	b	LBB3_8
LBB3_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_9:                                 ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-32]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	w8, [x29, #-28]
	mov	x0, x8
	bl	_nl_socket_catalog_method
	stur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB3_16
	b	LBB3_10
LBB3_10:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #56]
	cbz	x8, LBB3_16
	b	LBB3_11
LBB3_11:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #56]
	subs	x8, x8, #1
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB3_16
	b	LBB3_12
LBB3_12:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #3
	b.ne	LBB3_16
	b	LBB3_13
LBB3_13:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #10
	b.ne	LBB3_16
	b	LBB3_14
LBB3_14:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldr	w8, [x8]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	bl	_nl_socket_catalog_interface
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	mov	x2, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_text
	tbz	w0, #0, LBB3_16
	b	LBB3_15
LBB3_15:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w1, [x8, #4]
	ldur	x8, [x29, #-48]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB3_17
	b	LBB3_16
LBB3_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_17:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	cbz	x8, LBB3_19
	b	LBB3_18
LBB3_18:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_20
LBB3_19:                                ;   in Loop: Header=BB3_6 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_20
LBB3_20:                                ;   in Loop: Header=BB3_6 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #56]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #8]
	cbz	w8, LBB3_23
	b	LBB3_21
LBB3_21:                                ;   in Loop: Header=BB3_6 Depth=1
	ldr	x8, [sp, #56]
	cbnz	x8, LBB3_23
	b	LBB3_22
LBB3_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_23:                                ;   in Loop: Header=BB3_6 Depth=1
	strh	wzr, [sp, #54]
	b	LBB3_24
LBB3_24:                                ;   Parent Loop BB3_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #54]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB3_31
	b	LBB3_25
LBB3_25:                                ;   in Loop: Header=BB3_24 Depth=2
	ldur	x8, [x29, #-48]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldrh	w8, [sp, #54]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #24]
	cbnz	w8, LBB3_28
	b	LBB3_26
LBB3_26:                                ;   in Loop: Header=BB3_24 Depth=2
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-48]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldrh	w8, [sp, #54]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #16]
	add	x2, sp, #53
	add	x3, sp, #48
	bl	_member_type
	tbz	w0, #0, LBB3_28
	b	LBB3_27
LBB3_27:                                ;   in Loop: Header=BB3_24 Depth=2
	ldr	x8, [sp, #56]
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldrb	w9, [sp, #53]
	subs	w8, w8, w9
	b.eq	LBB3_29
	b	LBB3_28
LBB3_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_29:                                ;   in Loop: Header=BB3_24 Depth=2
	b	LBB3_30
LBB3_30:                                ;   in Loop: Header=BB3_24 Depth=2
	ldrh	w8, [sp, #54]
	add	w8, w8, #1
	strh	w8, [sp, #54]
	b	LBB3_24
LBB3_31:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-48]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #24]
	subs	w8, w8, #3
	b.ne	LBB3_34
	b	LBB3_32
LBB3_32:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #32]
	ldr	x1, [x8, #16]
	add	x2, sp, #47
	add	x3, sp, #40
	bl	_member_type
	tbz	w0, #0, LBB3_34
	b	LBB3_33
LBB3_33:                                ;   in Loop: Header=BB3_6 Depth=1
	ldrb	w8, [sp, #47]
	subs	w8, w8, #10
	b.eq	LBB3_35
	b	LBB3_34
LBB3_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_35:                                ;   in Loop: Header=BB3_6 Depth=1
	b	LBB3_36
LBB3_36:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB3_6
LBB3_37:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_38
LBB3_38:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_read
_layouts_read:                          ; @layouts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #32
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x8, #16]
	str	x1, [x8, #8]
	str	x2, [x8]
	stur	x3, [x29, #-40]
	ldr	x8, [x8, #16]
	ldr	x8, [x8, #312]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB4_3
	b	LBB4_2
LBB4_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	ldr	x1, [x9, #312]
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #64
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	wzr, [x29, #-72]
	stur	wzr, [x29, #-76]
	stur	wzr, [x29, #-80]
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	cbz	w0, LBB4_5
	b	LBB4_4
LBB4_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_5:
	ldur	w8, [x29, #-68]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB4_7
	b	LBB4_6
LBB4_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_7:
	ldur	w8, [x29, #-68]
	subs	w8, w8, #9
	b.lo	LBB4_9
	b	LBB4_8
LBB4_8:
	ldur	w8, [x29, #-68]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-56]
	ldur	x10, [x29, #-48]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_10
	b	LBB4_9
LBB4_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_10:
	stur	wzr, [x29, #-84]
	b	LBB4_11
LBB4_11:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-84]
	subs	w8, w8, #9
	b.hs	LBB4_16
	b	LBB4_12
LBB4_12:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	add	x8, x8, #20
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.lo	LBB4_14
	b	LBB4_13
LBB4_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_14:                                ;   in Loop: Header=BB4_11 Depth=1
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	w8, [x29, #-84]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	b	LBB4_11
LBB4_16:
	stur	wzr, [x29, #-88]
	b	LBB4_17
LBB4_17:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_45 Depth 2
	ldur	w8, [x29, #-88]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hs	LBB4_73
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_17 Depth=1
	sub	x0, x29, #64
	sub	x1, x29, #89
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_26
	b	LBB4_19
LBB4_19:                                ;   in Loop: Header=BB4_17 Depth=1
	sub	x0, x29, #64
	sub	x1, x29, #90
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_26
	b	LBB4_20
LBB4_20:                                ;   in Loop: Header=BB4_17 Depth=1
	sub	x0, x29, #64
	sub	x1, x29, #92
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_26
	b	LBB4_21
LBB4_21:                                ;   in Loop: Header=BB4_17 Depth=1
	sub	x0, x29, #64
	sub	x1, x29, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_26
	b	LBB4_22
LBB4_22:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurb	w8, [x29, #-90]
	cbnz	w8, LBB4_26
	b	LBB4_23
LBB4_23:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurb	w8, [x29, #-89]
	subs	w8, w8, #3
	b.gt	LBB4_26
	b	LBB4_24
LBB4_24:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-96]
	bl	_name_index
	tbz	w0, #0, LBB4_26
	b	LBB4_25
LBB4_25:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurh	w8, [x29, #-92]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-56]
	ldur	x10, [x29, #-48]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_27
	b	LBB4_26
LBB4_26:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_27:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-88]
	bl	_catalog_at
	stur	w0, [x29, #-100]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #104]
	ldurb	w8, [x29, #-89]
	cbnz	w8, LBB4_29
	b	LBB4_28
LBB4_28:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-72]
	add	w9, w8, #1
	stur	w9, [x29, #-72]
	str	w8, [sp, #104]
	b	LBB4_35
LBB4_29:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurb	w8, [x29, #-89]
	subs	w8, w8, #3
	b.ne	LBB4_31
	b	LBB4_30
LBB4_30:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-76]
	add	w8, w8, #1
	stur	w8, [x29, #-76]
	b	LBB4_34
LBB4_31:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurb	w8, [x29, #-89]
	subs	w8, w8, #2
	b.ne	LBB4_33
	b	LBB4_32
LBB4_32:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-80]
	add	w9, w8, #1
	stur	w9, [x29, #-80]
	str	w8, [sp, #104]
	b	LBB4_33
LBB4_33:                                ;   in Loop: Header=BB4_17 Depth=1
	b	LBB4_34
LBB4_34:                                ;   in Loop: Header=BB4_17 Depth=1
	b	LBB4_35
LBB4_35:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-100]
	adds	w8, w8, #1
	b.ne	LBB4_37
	b	LBB4_36
LBB4_36:                                ;   in Loop: Header=BB4_17 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB4_38
LBB4_37:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-100]
	mov	x0, x8
	bl	_nl_socket_catalog_type
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB4_38
LBB4_38:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #96]
	ldur	w8, [x29, #-100]
	adds	w8, w8, #1
	b.eq	LBB4_44
	b	LBB4_39
LBB4_39:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #96]
	cbz	x8, LBB4_43
	b	LBB4_40
LBB4_40:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurb	w8, [x29, #-89]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	w0, [x29, #-100]
	bl	_type_kind
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB4_43
	b	LBB4_41
LBB4_41:                                ;   in Loop: Header=BB4_17 Depth=1
	ldurh	w8, [x29, #-92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB4_43
	b	LBB4_42
LBB4_42:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-96]
	ldr	x8, [sp, #96]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB4_44
	b	LBB4_43
LBB4_43:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_44:                                ;   in Loop: Header=BB4_17 Depth=1
	str	wzr, [sp, #92]
	b	LBB4_45
LBB4_45:                                ;   Parent Loop BB4_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #92]
	ldurh	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB4_69
	b	LBB4_46
LBB4_46:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #91
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_59
	b	LBB4_47
LBB4_47:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #90
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_59
	b	LBB4_48
LBB4_48:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #89
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_59
	b	LBB4_49
LBB4_49:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #88
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_59
	b	LBB4_50
LBB4_50:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_59
	b	LBB4_51
LBB4_51:                                ;   in Loop: Header=BB4_45 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_59
	b	LBB4_52
LBB4_52:                                ;   in Loop: Header=BB4_45 Depth=2
	ldrb	w8, [sp, #91]
	subs	w8, w8, #16
	b.ge	LBB4_59
	b	LBB4_53
LBB4_53:                                ;   in Loop: Header=BB4_45 Depth=2
	ldrb	w8, [sp, #90]
	cbnz	w8, LBB4_59
	b	LBB4_54
LBB4_54:                                ;   in Loop: Header=BB4_45 Depth=2
	ldrb	w8, [sp, #89]
	cbnz	w8, LBB4_59
	b	LBB4_55
LBB4_55:                                ;   in Loop: Header=BB4_45 Depth=2
	ldrb	w8, [sp, #88]
	cbnz	w8, LBB4_59
	b	LBB4_56
LBB4_56:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w1, [sp, #80]
	bl	_name_index
	tbz	w0, #0, LBB4_59
	b	LBB4_57
LBB4_57:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	w8, [sp, #84]
	adds	w8, w8, #1
	b.eq	LBB4_60
	b	LBB4_58
LBB4_58:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-88]
	subs	w8, w8, w9
	b.lo	LBB4_60
	b	LBB4_59
LBB4_59:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_60:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	x8, [sp, #96]
	cbz	x8, LBB4_67
	b	LBB4_61
LBB4_61:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #24]
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	str	x9, [sp, #64]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #64]
	ldr	x1, [x8, #16]
	add	x2, sp, #79
	add	x3, sp, #72
	bl	_member_type
	tbz	w0, #0, LBB4_65
	b	LBB4_62
LBB4_62:                                ;   in Loop: Header=BB4_45 Depth=2
	ldrb	w8, [sp, #91]
	ldrb	w9, [sp, #79]
	subs	w8, w8, w9
	b.ne	LBB4_65
	b	LBB4_63
LBB4_63:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	w8, [sp, #84]
	ldr	w9, [sp, #72]
	subs	w8, w8, w9
	b.ne	LBB4_65
	b	LBB4_64
LBB4_64:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w1, [sp, #80]
	ldr	x8, [sp, #64]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB4_66
	b	LBB4_65
LBB4_65:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_66:                                ;   in Loop: Header=BB4_45 Depth=2
	b	LBB4_67
LBB4_67:                                ;   in Loop: Header=BB4_45 Depth=2
	b	LBB4_68
LBB4_68:                                ;   in Loop: Header=BB4_45 Depth=2
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB4_45
LBB4_69:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	x8, [x29, #-40]
	cbz	x8, LBB4_71
	b	LBB4_70
LBB4_70:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	x10, [x29, #-40]
	ldur	w8, [x29, #-88]
                                        ; kill: def $x8 killed $w8
	mov	x9, #20                         ; =0x14
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	w8, [x29, #-88]
	str	w8, [sp, #44]
	ldur	w8, [x29, #-100]
	str	w8, [sp, #48]
	ldr	w8, [sp, #104]
	str	w8, [sp, #52]
	ldurb	w8, [x29, #-89]
	strb	w8, [sp, #56]
	ldur	w0, [x29, #-100]
	bl	_type_flags
	strb	w0, [sp, #57]
	strh	wzr, [sp, #58]
	ldur	w0, [x29, #-100]
	bl	_category
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	str	w0, [sp, #60]
	ldur	q0, [sp, #44]
	str	q0, [x9]
	ldr	w8, [sp, #60]
	str	w8, [x9, #16]
	b	LBB4_71
LBB4_71:                                ;   in Loop: Header=BB4_17 Depth=1
	b	LBB4_72
LBB4_72:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	w8, [x29, #-88]
	add	w8, w8, #1
	stur	w8, [x29, #-88]
	b	LBB4_17
LBB4_73:
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-56]
	subs	x8, x8, x9
	b.ne	LBB4_77
	b	LBB4_74
LBB4_74:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-72]
	ldr	x9, [x9, #16]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.ne	LBB4_77
	b	LBB4_75
LBB4_75:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-76]
	ldr	x9, [x9, #16]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.ne	LBB4_77
	b	LBB4_76
LBB4_76:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-80]
	ldr	x9, [x9, #16]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.eq	LBB4_78
	b	LBB4_77
LBB4_77:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_79
LBB4_78:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-68]
	ldr	x9, [x9]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB4_79
LBB4_79:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_valid
_ownership_valid:                       ; @ownership_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB5_3
	b	LBB5_2
LBB5_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_3:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #56
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_9
	b	LBB5_4
LBB5_4:
	ldur	w8, [x29, #-60]
	subs	w8, w8, #1
	b.ne	LBB5_9
	b	LBB5_5
LBB5_5:
	sub	x0, x29, #56
	sub	x1, x29, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_9
	b	LBB5_6
LBB5_6:
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB5_9
	b	LBB5_7
LBB5_7:
	ldur	w8, [x29, #-64]
	mov	x1, x8
	sub	x0, x29, #56
	sub	x2, x29, #72
	bl	_nvm_v2_take
	cbnz	w0, LBB5_9
	b	LBB5_8
LBB5_8:
	sub	x0, x29, #56
	bl	_nvm_v2_align4
	cbz	w0, LBB5_10
	b	LBB5_9
LBB5_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_10:
	stur	wzr, [x29, #-76]
	b	LBB5_11
LBB5_11:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-76]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.hs	LBB5_16
	b	LBB5_12
LBB5_12:                                ;   in Loop: Header=BB5_11 Depth=1
	ldur	x8, [x29, #-72]
	ldur	w9, [x29, #-76]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-76]
	bl	_catalog_at
	bl	_type_flags
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.eq	LBB5_14
	b	LBB5_13
LBB5_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_14:                                ;   in Loop: Header=BB5_11 Depth=1
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_11 Depth=1
	ldur	w8, [x29, #-76]
	add	w8, w8, #1
	stur	w8, [x29, #-76]
	b	LBB5_11
LBB5_16:
	sub	x0, x29, #56
	sub	x1, x29, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_21
	b	LBB5_17
LBB5_17:
	ldur	w8, [x29, #-64]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB5_21
	b	LBB5_18
LBB5_18:
	ldur	w8, [x29, #-64]
	cbz	w8, LBB5_20
	b	LBB5_19
LBB5_19:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB5_21
	b	LBB5_20
LBB5_20:
	ldur	w8, [x29, #-64]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-40]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB5_22
	b	LBB5_21
LBB5_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_22:
	stur	wzr, [x29, #-80]
	b	LBB5_23
LBB5_23:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_44 Depth 2
	ldur	w8, [x29, #-80]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.hs	LBB5_54
	b	LBB5_24
LBB5_24:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #80]
	sub	x0, x29, #56
	sub	x1, x29, #82
	bl	_nvm_v2_u16
	cbnz	w0, LBB5_31
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_23 Depth=1
	sub	x0, x29, #56
	sub	x1, x29, #84
	bl	_nvm_v2_u16
	cbnz	w0, LBB5_31
	b	LBB5_26
LBB5_26:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-82]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB5_31
	b	LBB5_27
LBB5_27:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-84]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB5_31
	b	LBB5_28
LBB5_28:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-84]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	b.gt	LBB5_31
	b	LBB5_29
LBB5_29:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB5_31
	b	LBB5_30
LBB5_30:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-40]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB5_32
	b	LBB5_31
LBB5_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_32:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-24]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB5_34
	b	LBB5_33
LBB5_33:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #20]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB5_35
LBB5_34:                                ;   in Loop: Header=BB5_23 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB5_35
LBB5_35:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w3, [sp, #36]                   ; 4-byte Folded Reload
	sub	x0, x29, #56
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_descriptor_read
	tbnz	w0, #0, LBB5_37
	b	LBB5_36
LBB5_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_37:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB5_39
	b	LBB5_38
LBB5_38:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-80]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB5_40
LBB5_39:                                ;   in Loop: Header=BB5_23 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB5_40
LBB5_40:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #72]
	ldurh	w8, [x29, #-84]
	cbz	w8, LBB5_43
	b	LBB5_41
LBB5_41:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB5_43
	b	LBB5_42
LBB5_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_43:                                ;   in Loop: Header=BB5_23 Depth=1
	str	wzr, [sp, #68]
	b	LBB5_44
LBB5_44:                                ;   Parent Loop BB5_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	b.hs	LBB5_52
	b	LBB5_45
LBB5_45:                                ;   in Loop: Header=BB5_44 Depth=2
	ldur	x8, [x29, #-24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-84]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB5_47
	b	LBB5_46
LBB5_46:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB5_48
LBB5_47:                                ;   in Loop: Header=BB5_44 Depth=2
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB5_48
LBB5_48:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	w2, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w3, [sp, #4]                    ; 4-byte Folded Reload
	sub	x0, x29, #56
	bl	_descriptor_read
	tbnz	w0, #0, LBB5_50
	b	LBB5_49
LBB5_49:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_50:                                ;   in Loop: Header=BB5_44 Depth=2
	b	LBB5_51
LBB5_51:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB5_44
LBB5_52:                                ;   in Loop: Header=BB5_23 Depth=1
	b	LBB5_53
LBB5_53:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	w8, [x29, #-80]
	add	w8, w8, #1
	stur	w8, [x29, #-80]
	b	LBB5_23
LBB5_54:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-48]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_55:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_plan_free   ; -- Begin function nvm_socket_nominal_plan_free
	.p2align	2
_nvm_socket_nominal_plan_free:          ; @nvm_socket_nominal_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_layout_count ; -- Begin function nvm_socket_nominal_layout_count
	.p2align	2
_nvm_socket_nominal_layout_count:       ; @nvm_socket_nominal_layout_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #56]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB7_3
LBB7_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB7_3
LBB7_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_layout      ; -- Begin function nvm_socket_nominal_layout
	.p2align	2
_nvm_socket_nominal_layout:             ; @nvm_socket_nominal_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp]
	cbz	x8, LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #56]
	subs	w8, w8, w9
	b.lo	LBB8_4
	b	LBB8_3
LBB8_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB8_5
LBB8_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	add	x11, x8, #60
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #20                        ; =0x14
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	w8, [x8, #16]
	str	w8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB8_5
LBB8_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_type        ; -- Begin function nvm_socket_nominal_type
	.p2align	2
_nvm_socket_nominal_type:               ; @nvm_socket_nominal_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB9_3
	b	LBB9_1
LBB9_1:
	ldur	w8, [x29, #-12]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB9_3
	b	LBB9_2
LBB9_2:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	add	x8, x8, #20
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	ldr	x2, [sp, #8]
	bl	_nvm_socket_nominal_layout
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB9_3
LBB9_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_source      ; -- Begin function nvm_socket_nominal_source
	.p2align	2
_nvm_socket_nominal_source:             ; @nvm_socket_nominal_source
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	strb	w1, [sp, #31]
	str	w2, [sp, #24]
	str	x3, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB10_4
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB10_4
	b	LBB10_2
LBB10_2:
	ldrb	w8, [sp, #31]
	cbz	w8, LBB10_5
	b	LBB10_3
LBB10_3:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #2
	b.eq	LBB10_5
	b	LBB10_4
LBB10_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB10_13
LBB10_5:
	str	wzr, [sp, #12]
	b	LBB10_6
LBB10_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #56]
	subs	w8, w8, w9
	b.hs	LBB10_12
	b	LBB10_7
LBB10_7:                                ;   in Loop: Header=BB10_6 Depth=1
	ldr	x8, [sp, #32]
	add	x10, x8, #60
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #20                         ; =0x14
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #12]
	ldrb	w9, [sp, #31]
	subs	w8, w8, w9
	b.ne	LBB10_10
	b	LBB10_8
LBB10_8:                                ;   in Loop: Header=BB10_6 Depth=1
	ldr	x8, [sp, #32]
	add	x10, x8, #60
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #20                         ; =0x14
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.ne	LBB10_10
	b	LBB10_9
LBB10_9:
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #32]
	add	x11, x8, #60
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #20                        ; =0x14
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	w8, [x8, #16]
	str	w8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB10_13
LBB10_10:                               ;   in Loop: Header=BB10_6 Depth=1
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB10_6
LBB10_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB10_13
LBB10_13:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_nominal_import      ; -- Begin function nvm_socket_nominal_import
	.p2align	2
_nvm_socket_nominal_import:             ; @nvm_socket_nominal_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB11_3
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp]
	cbz	x8, LBB11_3
	b	LBB11_2
LBB11_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #5
	b.lo	LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB11_5
LBB11_4:
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB11_5
LBB11_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function text
_text:                                  ; @text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB12_4
	b	LBB12_1
LBB12_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	cbz	x8, LBB12_4
	b	LBB12_2
LBB12_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	cbz	x8, LBB12_4
	b	LBB12_3
LBB12_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB12_5
	b	LBB12_4
LBB12_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_8
LBB12_5:
	ldr	x0, [sp, #16]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	ldr	x10, [sp, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB12_7
	b	LBB12_6
LBB12_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB12_7
LBB12_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_8
LBB12_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function member_type
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x9, [sp, #24]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #32]
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_2:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB13_4
	b	LBB13_3
LBB13_3:
	ldr	x9, [sp, #32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_4:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB13_6
	b	LBB13_5
LBB13_5:
	ldr	x9, [sp, #32]
	mov	w8, #4                          ; =0x4
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_6:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB13_8
	b	LBB13_7
LBB13_7:
	ldr	x9, [sp, #32]
	mov	w8, #5                          ; =0x5
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_8:
	str	wzr, [sp, #20]
	b	LBB13_9
LBB13_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #9
	b.hs	LBB13_16
	b	LBB13_10
LBB13_10:                               ;   in Loop: Header=BB13_9 Depth=1
	ldr	w8, [sp, #20]
	mov	x0, x8
	bl	_nl_socket_catalog_type
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB13_12
	b	LBB13_11
LBB13_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_12:                               ;   in Loop: Header=BB13_9 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8]
	bl	_strcmp
	cbnz	w0, LBB13_14
	b	LBB13_13
LBB13_13:
	ldr	w0, [sp, #20]
	bl	_type_tag
	ldr	x8, [sp, #32]
	strb	w0, [x8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #20
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #24]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_14:                               ;   in Loop: Header=BB13_9 Depth=1
	b	LBB13_15
LBB13_15:                               ;   in Loop: Header=BB13_9 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB13_9
LBB13_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_17
LBB13_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_tag
_type_tag:                              ; @type_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-4]
	ldur	w0, [x29, #-4]
	bl	_type_kind
	mov	w9, #10                         ; =0xa
	mov	w8, #8                          ; =0x8
	subs	w10, w0, #0
	csel	w0, w8, w9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_kind
_type_kind:                             ; @type_kind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-4]
	ldur	w8, [x29, #-4]
	mov	x0, x8
	bl	_nl_socket_catalog_type
	ldr	w10, [x0, #16]
	mov	w8, #2                          ; =0x2
	mov	w9, #0                          ; =0x0
	subs	w10, w10, #2
	csel	w0, w8, w9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function name_index
_name_index:                            ; @name_index
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w9, [sp, #4]
	mov	w8, #1                          ; =0x1
	adds	w9, w9, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB16_2
	b	LBB16_1
LBB16_1:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB16_2
LBB16_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_at
_catalog_at:                            ; @catalog_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB17_1
LBB17_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	subs	w8, w8, #9
	b.hs	LBB17_6
	b	LBB17_2
LBB17_2:                                ;   in Loop: Header=BB17_1 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #20
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB17_4
	b	LBB17_3
LBB17_3:
	ldr	w8, [sp, #8]
	str	w8, [sp, #28]
	b	LBB17_7
LBB17_4:                                ;   in Loop: Header=BB17_1 Depth=1
	b	LBB17_5
LBB17_5:                                ;   in Loop: Header=BB17_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB17_1
LBB17_6:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB17_7
LBB17_7:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_flags
_type_flags:                            ; @type_flags
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	adds	w8, w8, #1
	b.ne	LBB18_2
	b	LBB18_1
LBB18_1:
	strb	wzr, [sp, #15]
	b	LBB18_5
LBB18_2:
	ldr	w8, [sp, #8]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB18_4
	b	LBB18_3
LBB18_3:
	ldr	w8, [sp, #8]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB18_4
LBB18_4:
	ldr	w11, [sp, #4]                   ; 4-byte Folded Reload
	mov	w9, #2                          ; =0x2
	mov	w10, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	orr	w8, w8, w9
	strb	w8, [sp, #15]
	b	LBB18_5
LBB18_5:
	ldrb	w0, [sp, #15]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function category
_category:                              ; @category
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	adds	w8, w8, #1
	b.ne	LBB19_2
	b	LBB19_1
LBB19_1:
	stur	wzr, [x29, #-4]
	b	LBB19_7
LBB19_2:
	ldr	w8, [sp, #8]
	cbnz	w8, LBB19_4
	b	LBB19_3
LBB19_3:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB19_7
LBB19_4:
	ldr	w8, [sp, #8]
	subs	w8, w8, #3
	b.ne	LBB19_6
	b	LBB19_5
LBB19_5:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB19_7
LBB19_6:
	ldr	w0, [sp, #8]
	bl	_type_kind
	mov	w8, #4                          ; =0x4
	mov	w9, #3                          ; =0x3
	subs	w10, w0, #0
	csel	w8, w8, w9, eq
	stur	w8, [x29, #-4]
	b	LBB19_7
LBB19_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor_read
_descriptor_read:                       ; @descriptor_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	str	w3, [sp, #32]
	ldur	x0, [x29, #-16]
	add	x1, sp, #31
	bl	_nvm_v2_u8
	cbnz	w0, LBB20_11
	b	LBB20_1
LBB20_1:
	ldur	x0, [x29, #-16]
	add	x1, sp, #30
	bl	_nvm_v2_u8
	cbnz	w0, LBB20_11
	b	LBB20_2
LBB20_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB20_11
	b	LBB20_3
LBB20_3:
	ldur	x0, [x29, #-16]
	add	x1, sp, #24
	bl	_nvm_v2_u32
	cbnz	w0, LBB20_11
	b	LBB20_4
LBB20_4:
	ldrh	w8, [sp, #28]
	cbnz	w8, LBB20_11
	b	LBB20_5
LBB20_5:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #16
	b.ge	LBB20_11
	b	LBB20_6
LBB20_6:
	ldrb	w8, [sp, #30]
	subs	w8, w8, #2
	b.gt	LBB20_11
	b	LBB20_7
LBB20_7:
	ldurb	w8, [x29, #-25]
	tbnz	w8, #0, LBB20_9
	b	LBB20_8
LBB20_8:
	ldrb	w8, [sp, #30]
	cbnz	w8, LBB20_11
	b	LBB20_9
LBB20_9:
	ldr	w8, [sp, #32]
	tbnz	w8, #31, LBB20_12
	b	LBB20_10
LBB20_10:
	ldrb	w8, [sp, #31]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	b.eq	LBB20_12
	b	LBB20_11
LBB20_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_23
LBB20_12:
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB20_14
	b	LBB20_13
LBB20_13:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB20_15
LBB20_14:
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #24]
	bl	_catalog_at
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB20_15
LBB20_15:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #20]
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB20_19
	b	LBB20_16
LBB20_16:
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.eq	LBB20_18
	b	LBB20_17
LBB20_17:
	ldrb	w8, [sp, #31]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldr	w0, [sp, #20]
	bl	_type_tag
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.eq	LBB20_19
	b	LBB20_18
LBB20_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_23
LBB20_19:
	ldrb	w8, [sp, #30]
	cbz	w8, LBB20_22
	b	LBB20_20
LBB20_20:
	ldr	w8, [sp, #20]
	cbz	w8, LBB20_22
	b	LBB20_21
LBB20_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_23
LBB20_22:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_23
LBB20_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

.subsections_via_symbols
