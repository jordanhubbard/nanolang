	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_execute_indirect_bytes
lCPI0_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_execute_indirect_bytes
	.p2align	2
_nvm_services_execute_indirect_bytes:   ; @nvm_services_execute_indirect_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #7568                       ; =0x1d90
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3472
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x4
	mov	x21, x3
	mov	x23, x2
	mov	x24, x1
	mov	x22, x0
	mov	x19, x8
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w1, #1                          ; =0x1
	mov	w2, #3                          ; =0x3
	bl	_nvm_services_host_enter
	mov	x25, x0
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w25, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w25, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w25, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w20, #4                         ; =0x4
	b	LBB0_10
LBB0_5:
	cbz	w25, LBB0_16
; %bb.6:
	mov	x20, x25
	cmp	w25, #1
	b.eq	LBB0_10
LBB0_7:
	mov	w20, #2                         ; =0x2
	b	LBB0_10
LBB0_8:
	mov	x0, x19
	mov	w1, #6728                       ; =0x1a48
	bl	_bzero
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	mov	w20, #11                        ; =0xb
	b	LBB0_13
LBB0_9:
	mov	w20, #5                         ; =0x5
LBB0_10:
	mov	x0, x19
	mov	w1, #6728                       ; =0x1a48
	bl	_bzero
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	cbz	x21, LBB0_13
; %bb.11:
	cmp	w25, #5
	b.eq	LBB0_13
; %bb.12:
	ldr	x8, [x21, #8]
LBB0_13:
	str	x8, [x19, #6704]
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
	str	w20, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
LBB0_14:
	ldur	x8, [x29, #-104]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_391
; %bb.15:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3472
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_16:
	cbz	x21, LBB0_22
; %bb.17:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB0_24
; %bb.18:
	ldr	x25, [x21, #8]
	cbz	x20, LBB0_23
; %bb.19:
	mov	w8, #16961                      ; =0x4241
	movk	w8, #15, lsl #16
	cmp	x25, x8
	b.hs	LBB0_23
; %bb.20:
	add	x28, sp, #496
	ldr	q0, [x21]
	str	q0, [sp, #144]
	str	xzr, [sp, #128]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	str	q0, [sp, #16]
	str	xzr, [sp, #264]
	add	x3, sp, #144
	add	x4, sp, #264
	mov	x0, x24
	mov	x1, x23
	mov	w2, #0                          ; =0x0
	bl	_nvm_services_runtime_indirect_create
	cbz	w0, LBB0_27
; %bb.21:
	mov	x21, x0
	add	x0, sp, #496
	mov	w1, #6728                       ; =0x1a48
	bl	_bzero
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #152]
	str	x9, [sp, #7200]
	str	w8, [sp, #496]
	str	w21, [sp, #504]
	b	LBB0_143
LBB0_22:
	mov	x25, #0                         ; =0x0
LBB0_23:
	stp	xzr, xzr, [sp, #496]
	b	LBB0_25
LBB0_24:
	stp	xzr, xzr, [sp, #496]
	ldr	x25, [x21, #8]
LBB0_25:
Lloh8:
	adrp	x8, lCPI0_0@PAGE
Lloh9:
	ldr	d0, [x8, lCPI0_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
	str	x25, [x19, #6704]
	ldr	q0, [sp, #496]
	mov	w8, #6712                       ; =0x1a38
	str	q0, [x19, x8]
LBB0_26:
	bl	_nvm_services_host_leave
	b	LBB0_14
LBB0_27:
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_indirect_plan
	mov	x21, x0
	add	x1, sp, #368
	bl	_nvm_services_indirect_hosted_startup
	cbz	w0, LBB0_142
; %bb.28:
	ldrb	w8, [sp, #456]
	tbnz	w8, #0, LBB0_142
; %bb.29:
	add	x26, sp, #1, lsl #12            ; =4096
	add	x26, x26, #3128
	ldr	w8, [sp, #380]
	cbz	w8, LBB0_137
; %bb.30:
	mov	w23, #0                         ; =0x0
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	add	x2, sp, #160
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_142
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrb	w8, [sp, #240]
	cbnz	w8, LBB0_142
; %bb.33:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrh	w8, [sp, #168]
	cbz	w8, LBB0_136
; %bb.34:                               ;   in Loop: Header=BB0_31 Depth=1
	mov	w27, #0                         ; =0x0
LBB0_35:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_43 Depth 3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	and	w2, w27, #0xffff
	add	x3, sp, #496
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_instruction
	cbz	w0, LBB0_142
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w0, [sp, #504]
	bl	_fcd_supported
	ldrb	w8, [sp, #572]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_142
; %bb.37:                               ;   in Loop: Header=BB0_35 Depth=2
	and	w2, w27, #0xffff
	add	x3, sp, #492
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_142
; %bb.38:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w8, [sp, #492]
	cmp	w8, #16
	b.hi	LBB0_142
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=2
	tst	w27, #0xffff
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_142
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_135
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=2
	mov	w25, #0                         ; =0x0
LBB0_43:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_92 Depth 4
                                        ;         Child Loop BB0_123 Depth 4
	and	w2, w27, #0xffff
	and	w3, w25, #0xff
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3208
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_variant
	cbz	w0, LBB0_142
; %bb.44:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #100]
	tbz	w8, #0, LBB0_142
; %bb.45:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w24, [sp, #504]
	mov	x0, x24
	bl	_fcd_supported
	cbz	w0, LBB0_142
; %bb.46:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w24, #147
	b.gt	LBB0_50
; %bb.47:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #60
	b.gt	LBB0_73
; %bb.48:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w24, #59
	cmp	w9, #2
	b.lo	LBB0_52
; %bb.49:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #15
	b.eq	LBB0_52
	b	LBB0_53
LBB0_50:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #150
	b.le	LBB0_76
; %bb.51:                               ;   in Loop: Header=BB0_43 Depth=3
	sub	w9, w24, #151
	cmp	w9, #2
	b.hs	LBB0_80
LBB0_52:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #5                          ; =0x5
LBB0_53:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #7336]
	cmp	w9, w8
	b.ne	LBB0_142
; %bb.54:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #102]
	cmp	w24, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.55:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #101]
	cmp	w24, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.56:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	sub	w9, w24, #59
	cmp	w9, #2
	b.lo	LBB0_59
; %bb.57:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #152
	b.eq	LBB0_59
; %bb.58:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #15
	mov	w8, #151                        ; =0x97
	ccmp	w24, w8, #4, ne
	cset	w8, eq
LBB0_59:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #145
	ldrb	w9, [x26, #103]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_142
; %bb.60:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w8, LBB0_72
; %bb.61:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7352]
	ldr	w9, [sp, #496]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.62:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #-1                         ; =0xffffffff
	cmp	w24, #60
	b.eq	LBB0_65
; %bb.63:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #152
	b.eq	LBB0_65
; %bb.64:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #512]
LBB0_65:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #7356]
	cmp	w9, w8
	b.ne	LBB0_142
; %bb.66:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #145
	cset	w8, ne
	ldr	w9, [sp, #7348]
	cmp	w9, w8
	b.ne	LBB0_142
; %bb.67:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #145
	b.ne	LBB0_79
; %bb.68:                               ;   in Loop: Header=BB0_43 Depth=3
	str	w25, [sp, #4]                   ; 4-byte Folded Spill
	ldr	w24, [sp, #1088]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3128
	str	x21, [sp, #8]                   ; 8-byte Folded Spill
	mov	x0, x21
	mov	x1, x24
	bl	_nvm_services_indirect_hosted_import
	cbz	w0, LBB0_142
; %bb.69:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7224]
	ldr	w9, [sp, #7356]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.70:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w24, w8
	lsr	x21, x8, #34
	add	w25, w21, w21, lsl #3
	add	w1, w25, #8
	add	x2, sp, #272
	ldr	x26, [sp, #8]                   ; 8-byte Folded Reload
	mov	x0, x26
	bl	_nvm_services_indirect_hosted_type
	str	w25, [sp]                       ; 4-byte Folded Spill
	cbz	w0, LBB0_82
; %bb.71:                               ;   in Loop: Header=BB0_43 Depth=3
	add	w8, w21, w21, lsl #2
	sub	w0, w24, w8
	bl	_nl_socket_catalog_method
	b	LBB0_87
LBB0_72:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #128                        ; =0x80
	b	LBB0_95
LBB0_73:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #61
	b.eq	LBB0_84
; %bb.74:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #145
	b.ne	LBB0_53
; %bb.75:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_53
LBB0_76:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #148
	b.eq	LBB0_85
; %bb.77:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #149
	b.ne	LBB0_53
; %bb.78:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_53
LBB0_79:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
	b	LBB0_94
LBB0_80:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w24, #161
	b.ne	LBB0_53
; %bb.81:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_53
LBB0_82:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	x0, x26
	mov	x1, x24
	bl	_services_dispatch_websocket
	mov	x8, x0
	add	w9, w21, w21, lsl #2
	sub	w0, w24, w9
	cbz	w8, LBB0_86
; %bb.83:                               ;   in Loop: Header=BB0_43 Depth=3
	bl	_nl_websocket_catalog_method
	b	LBB0_87
LBB0_84:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #4                          ; =0x4
	b	LBB0_53
LBB0_85:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_53
LBB0_86:                                ;   in Loop: Header=BB0_43 Depth=3
	bl	_nl_file_catalog_method
LBB0_87:                                ;   in Loop: Header=BB0_43 Depth=3
	cbz	x0, LBB0_142
; %bb.88:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7364]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.89:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7368]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.90:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	x25, x21
	ldr	w8, [x0, #44]
	cmp	w8, #1
	mov	w8, #399                        ; =0x18f
	mov	w9, #415                        ; =0x19f
	csel	w26, w9, w8, eq
	ldr	x9, [x0, #56]
	cmp	x9, #2
	b.lo	LBB0_93
; %bb.91:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [x0, #48]
	add	x8, x8, #40
	sub	x9, x9, #1
LBB0_92:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w10, [x8], #48
	orr	w11, w26, #0x20
	cmp	w10, #1
	csel	w11, w11, w26, eq
	orr	w12, w11, #0x400
	cmp	w10, #5
	csel	w26, w12, w11, eq
	subs	x9, x9, #1
	b.ne	LBB0_92
LBB0_93:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	add	w1, w8, #8
	add	x2, sp, #272
	ldr	x21, [sp, #8]                   ; 8-byte Folded Reload
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_type
	mov	w8, #0                          ; =0x0
	add	w9, w25, w25, lsl #2
	cmp	w24, w9
	cset	w9, eq
	orr	w10, w26, #0x200
	tst	w9, w0
	csel	w9, w10, w26, ne
	add	x26, sp, #1, lsl #12            ; =4096
	add	x26, x26, #3128
	ldr	w25, [sp, #4]                   ; 4-byte Folded Reload
LBB0_94:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #7360]
	cmp	w10, w9
	b.ne	LBB0_142
LBB0_95:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #7340]
	cmp	w10, w8
	b.ne	LBB0_142
; %bb.96:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #7344]
	bic	w8, w9, w8
	cmp	w10, w8
	b.ne	LBB0_142
; %bb.97:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #7328]
	ldrh	w9, [sp, #7306]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.98:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #7330]
	ldrh	w9, [sp, #7316]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.99:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #180]
	ldrb	w9, [sp, #572]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_142
; %bb.100:                              ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #0, LBB0_102
; %bb.101:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w9, [x26, #181]
	cmp	w9, #255
	b.eq	LBB0_107
	b	LBB0_142
LBB0_102:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w9, LBB0_142
; %bb.103:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #568]
	ldrh	w8, [sp, #168]
	cmp	w2, w8
	b.hs	LBB0_142
; %bb.104:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #272
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_142
; %bb.105:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #181]
	ldrb	w9, [sp, #272]
	cmp	w8, w9
	b.hs	LBB0_142
; %bb.106:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #180]
LBB0_107:                               ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #1, LBB0_109
; %bb.108:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #182]
	cmp	w8, #255
	b.eq	LBB0_113
	b	LBB0_142
LBB0_109:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #572]
	cmp	w8, #2
	b.lo	LBB0_142
; %bb.110:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #570]
	ldrh	w8, [sp, #168]
	cmp	w2, w8
	b.hs	LBB0_142
; %bb.111:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #272
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_variant_count
	cbz	w0, LBB0_142
; %bb.112:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [x26, #182]
	ldrb	w9, [sp, #272]
	cmp	w8, w9
	b.hs	LBB0_142
LBB0_113:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #504]
	cmp	w8, #152
	b.eq	LBB0_115
; %bb.114:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #60
	b.ne	LBB0_129
LBB0_115:                               ;   in Loop: Header=BB0_43 Depth=3
	and	w2, w27, #0xffff
	and	w3, w25, #0xff
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3128
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_call
	cbz	w0, LBB0_142
; %bb.116:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x8, [sp, #7232]
	cbz	x8, LBB0_142
; %bb.117:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	x9, [sp, #7240]
	cmp	x8, x9
	b.ne	LBB0_142
; %bb.118:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7224]
	cmp	w8, w23
	b.ne	LBB0_142
; %bb.119:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7228]
	ldr	w9, [sp, #496]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.120:                              ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #7256]
	cmn	w8, #1
	b.ne	LBB0_142
; %bb.121:                              ;   in Loop: Header=BB0_43 Depth=3
	mov	x24, #0                         ; =0x0
	b	LBB0_123
LBB0_122:                               ;   in Loop: Header=BB0_123 Depth=4
	add	x24, x24, #1
	cmp	x24, #64
	b.eq	LBB0_128
LBB0_123:                               ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ;       Parent Loop BB0_43 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x8, [sp, #7232]
	lsr	x8, x8, x24
	tbz	w8, #0, LBB0_122
; %bb.124:                              ;   in Loop: Header=BB0_123 Depth=4
	add	x2, sp, #272
	mov	x0, x21
	mov	x1, x24
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_142
; %bb.125:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrb	w8, [sp, #352]
	cbnz	w8, LBB0_142
; %bb.126:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrh	w8, [sp, #284]
	ldrh	w9, [sp, #7272]
	cmp	w8, w9
	b.ne	LBB0_142
; %bb.127:                              ;   in Loop: Header=BB0_123 Depth=4
	ldrb	w8, [sp, #288]
	ldrb	w9, [x26, #54]
	cmp	w8, w9
	b.eq	LBB0_122
	b	LBB0_142
LBB0_128:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #504]
LBB0_129:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #15
	b.eq	LBB0_132
; %bb.130:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #151
	b.eq	LBB0_132
; %bb.131:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #59
	b.ne	LBB0_134
LBB0_132:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #512]
	add	x2, sp, #272
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_function
	cbz	w0, LBB0_142
; %bb.133:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #352]
	cbnz	w8, LBB0_142
LBB0_134:                               ;   in Loop: Header=BB0_43 Depth=3
	add	w25, w25, #1
	ldrb	w8, [sp, #492]
	cmp	w8, w25, uxtb
	b.hi	LBB0_43
LBB0_135:                               ;   in Loop: Header=BB0_35 Depth=2
	add	w27, w27, #1
	ldrh	w8, [sp, #168]
	cmp	w8, w27, uxth
	b.hi	LBB0_35
LBB0_136:                               ;   in Loop: Header=BB0_31 Depth=1
	add	w23, w23, #1
	ldr	w8, [sp, #380]
	cmp	w23, w8
	b.lo	LBB0_31
LBB0_137:
	ldr	x24, [sp, #264]
	mov	x0, x24
	bl	_nvm_services_runtime_indirect_plan
	mov	x25, x0
	mov	x0, x22
	mov	x1, x25
	bl	_nvm_services_host_authorize
	mov	x23, x0
	cmp	w0, #1
	b.le	LBB0_162
; %bb.138:
	cmp	w23, #2
	b.eq	LBB0_177
; %bb.139:
	cmp	w23, #3
	b.eq	LBB0_185
; %bb.140:
	cmp	w23, #5
	b.ne	LBB0_164
LBB0_141:
	mov	w23, #11                        ; =0xb
	b	LBB0_186
LBB0_142:
	add	x8, sp, #496
	add	x0, sp, #264
	mov	x1, #0                          ; =0x0
	bl	_nvm_services_runtime_indirect_destroy
	add	x0, sp, #496
	mov	w1, #6728                       ; =0x1a48
	bl	_bzero
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #152]
	str	x9, [sp, #7200]
	mov	w9, #2                          ; =0x2
	str	w8, [sp, #496]
	str	w9, [sp, #504]
LBB0_143:
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x28, #20]
LBB0_144:
	add	x1, sp, #496
	mov	x0, x19
	mov	w2, #6728                       ; =0x1a48
	bl	_memcpy
	ldr	w21, [x19, #8]
	cbnz	w21, LBB0_161
; %bb.145:
	ldrb	w8, [x19, #12]
	tbz	w8, #0, LBB0_160
; %bb.146:
	ldr	w8, [x19, #16]
	mov	w21, #10                        ; =0xa
	cbnz	w8, LBB0_161
; %bb.147:
	ldr	w8, [x19, #32]
	cbnz	w8, LBB0_161
; %bb.148:
	ldr	x8, [x19, #40]
	cbnz	x8, LBB0_161
; %bb.149:
	ldrb	w8, [sp, #16]
	mov	w21, #6                         ; =0x6
	tbz	w8, #0, LBB0_161
; %bb.150:
	ldrb	w8, [sp, #17]
	tbnz	w8, #0, LBB0_161
; %bb.151:
	ldrb	w8, [sp, #18]
	tbnz	w8, #0, LBB0_161
; %bb.152:
	ldrb	w8, [sp, #21]
	cbnz	w8, LBB0_161
; %bb.153:
	ldr	w8, [sp, #32]
	cbnz	w8, LBB0_161
; %bb.154:
	ldr	w8, [sp, #24]
	cmn	w8, #1
	b.ne	LBB0_161
; %bb.155:
	ldr	w8, [sp, #28]
	cmn	w8, #1
	b.ne	LBB0_161
; %bb.156:
	ldrb	w8, [sp, #40]
	cmp	w8, #1
	b.ne	LBB0_161
; %bb.157:
	ldrb	w8, [sp, #20]
	cmp	w8, #4
	b.eq	LBB0_172
; %bb.158:
	cmp	w8, #1
	b.ne	LBB0_161
; %bb.159:
	ldr	x9, [sp, #48]
	b	LBB0_173
LBB0_160:
	mov	w21, #5                         ; =0x5
LBB0_161:
	ldurh	w8, [x19, #13]
	strh	w8, [sp, #368]
	ldurb	w8, [x19, #15]
	strb	w8, [sp, #370]
	ldur	x8, [x19, #20]
	str	x8, [sp, #7304]
	ldur	w8, [x19, #28]
	str	w8, [sp, #7312]
	add	x0, sp, #496
	add	x1, x19, #48
	mov	w2, #6656                       ; =0x1a00
	bl	_memcpy
	str	w21, [x19, #8]
	ldrh	w8, [sp, #368]
	sturh	w8, [x19, #13]
	ldrb	w8, [sp, #370]
	sturb	w8, [x19, #15]
	ldr	x8, [sp, #7304]
	stur	x8, [x19, #20]
	ldr	w8, [sp, #7312]
	stur	w8, [x19, #28]
	add	x0, x19, #48
	add	x1, sp, #496
	mov	w2, #6656                       ; =0x1a00
	bl	_memcpy
	b	LBB0_26
LBB0_162:
	cbz	w23, LBB0_165
; %bb.163:
	cmp	w23, #1
	b.eq	LBB0_186
LBB0_164:
	mov	w23, #2                         ; =0x2
	b	LBB0_186
LBB0_165:
	mov	x26, #0                         ; =0x0
	mov	w27, #7                         ; =0x7
	b	LBB0_167
LBB0_166:                               ;   in Loop: Header=BB0_167 Depth=1
	add	x26, x26, #1
	add	w27, w27, #9
	cmp	x26, #64
	b.eq	LBB0_178
LBB0_167:                               ; =>This Inner Loop Header: Depth=1
	sub	w1, w27, #7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x25
	bl	_nvm_services_indirect_hosted_type
	tbz	w0, #0, LBB0_178
; %bb.168:                              ;   in Loop: Header=BB0_167 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x25
	mov	x1, x27
	bl	_nvm_services_indirect_hosted_type
	tbnz	w0, #0, LBB0_166
; %bb.169:                              ;   in Loop: Header=BB0_167 Depth=1
	add	x2, sp, #496
	mov	x0, x22
	mov	x1, x26
	bl	_nvm_services_host_websocket_policy
	cbnz	w0, LBB0_174
; %bb.170:                              ;   in Loop: Header=BB0_167 Depth=1
	add	x2, sp, #496
	mov	x0, x24
	mov	x1, x26
	bl	_nvm_services_runtime_websocket_policy
	cbz	w0, LBB0_166
; %bb.171:
	mov	x23, x0
	b	LBB0_186
LBB0_172:
	ldr	x9, [sp, #48]
	cmp	x9, #1
	b.hi	LBB0_161
LBB0_173:
	mov	w21, #0                         ; =0x0
	strb	w8, [x20]
	stur	wzr, [x20, #1]
	str	wzr, [x20, #4]
	str	x9, [x20, #8]
	b	LBB0_161
LBB0_174:
	mov	x23, x0
	cmp	w0, #2
	b.gt	LBB0_183
; %bb.175:
	cmp	w23, #1
	b.eq	LBB0_186
; %bb.176:
	cmp	w23, #2
	b.ne	LBB0_164
LBB0_177:
	mov	w23, #4                         ; =0x4
	b	LBB0_186
LBB0_178:
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_begin
	cbnz	w0, LBB0_180
; %bb.179:
	mov	x27, x21
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_frame_start
	cbz	w0, LBB0_187
LBB0_180:
	mov	x1, x0
LBB0_181:
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_fail
LBB0_182:
	add	x8, sp, #496
	add	x0, sp, #264
	add	x1, sp, #16
	bl	_nvm_services_runtime_indirect_destroy
	b	LBB0_144
LBB0_183:
	cmp	w23, #5
	b.eq	LBB0_141
; %bb.184:
	cmp	w23, #3
	b.ne	LBB0_164
LBB0_185:
	mov	w23, #5                         ; =0x5
LBB0_186:
	add	x8, sp, #496
	add	x0, sp, #264
	mov	x1, #0                          ; =0x0
	bl	_nvm_services_runtime_indirect_destroy
	add	x0, sp, #496
	mov	w1, #6728                       ; =0x1a48
	bl	_bzero
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #152]
	str	x9, [sp, #7200]
	str	w8, [sp, #496]
	str	w23, [sp, #504]
	b	LBB0_143
LBB0_187:
	mov	w25, #-1                        ; =0xffffffff
	b	LBB0_190
LBB0_188:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_frame_start
	mov	x1, x0
LBB0_189:                               ;   in Loop: Header=BB0_190 Depth=1
	cbnz	w1, LBB0_181
LBB0_190:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_352 Depth 2
                                        ;     Child Loop BB0_266 Depth 2
	ldr	x0, [sp, #264]
	add	x1, sp, #272
	bl	_nvm_services_runtime_indirect_frame_view
	cbz	w0, LBB0_390
; %bb.191:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #325]
	tbnz	w8, #0, LBB0_390
; %bb.192:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #276]
	cbnz	w8, LBB0_390
; %bb.193:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x21, x27
	ldr	w1, [sp, #280]
	ldrh	w2, [sp, #284]
	add	x3, sp, #496
	mov	x0, x27
	bl	_nvm_services_indirect_hosted_instruction
	cbz	w0, LBB0_390
; %bb.194:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #280]
	ldrh	w2, [sp, #284]
	ldrb	w3, [sp, #324]
	add	x4, sp, #160
	mov	x0, x21
	bl	_nvm_services_indirect_hosted_variant
	cbz	w0, LBB0_390
; %bb.195:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #180]
	tbz	w8, #0, LBB0_390
; %bb.196:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w8, [sp, #162]
	ldr	w9, [sp, #312]
	cmp	w9, w8
	b.ne	LBB0_390
; %bb.197:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x0, [sp, #264]
	bl	_nvm_services_runtime_indirect_enter
	cbnz	w0, LBB0_180
; %bb.198:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	w24, #0                         ; =0x0
	ldr	x22, [sp, #264]
	ldr	w28, [sp, #312]
	ldrb	w23, [sp, #504]
	str	w25, [sp, #492]
	str	w25, [sp, #488]
	mov	w8, #2                          ; =0x2
	cmp	w23, #255
	b.eq	LBB0_227
; %bb.199:                              ;   in Loop: Header=BB0_190 Depth=1
Lloh10:
	adrp	x11, lJTI0_0@PAGE
Lloh11:
	add	x11, x11, lJTI0_0@PAGEOFF
	adr	x9, LBB0_200
	ldrh	w10, [x11, x23, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB0_200:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_call
	b	LBB0_343
LBB0_201:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	w28, LBB0_341
; %bb.202:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	tbz	w0, #0, LBB0_341
; %bb.203:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #252
	b.eq	LBB0_205
; %bb.204:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #106
	b.ne	LBB0_301
LBB0_205:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	ldrh	w2, [sp, #512]
	mov	x0, x22
	mov	x3, x1
	bl	_nvm_services_runtime_project
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_206:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	w28, LBB0_341
; %bb.207:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.208:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #368
	mov	x0, x22
	bl	_nvm_services_runtime_view
	tbz	w0, #0, LBB0_341
; %bb.209:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #368]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.210:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #369]
	tbnz	w8, #0, LBB0_336
; %bb.211:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #370]
	tbnz	w8, #0, LBB0_336
; %bb.212:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #373]
	cbnz	w8, LBB0_336
; %bb.213:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #384]
	cbnz	w8, LBB0_336
; %bb.214:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #372]
	cmp	w8, #4
	b.ne	LBB0_336
; %bb.215:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #376]
	cmn	w8, #1
	b.ne	LBB0_336
; %bb.216:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #380]
	cmn	w8, #1
	b.ne	LBB0_336
; %bb.217:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #392]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.218:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x8, [sp, #400]
	cmp	x8, #2
	b.hs	LBB0_336
; %bb.219:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	mov	x0, x22
	bl	_nvm_services_runtime_drop
	cbnz	w0, LBB0_180
; %bb.220:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x8, [sp, #400]
	cmp	w23, #161
	b.ne	LBB0_324
; %bb.221:                              ;   in Loop: Header=BB0_190 Depth=1
	cbnz	x8, LBB0_316
; %bb.222:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	mov	w1, #9                          ; =0x9
	b	LBB0_342
LBB0_223:                               ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.224:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #3
	mov	w8, #4                          ; =0x4
	csel	w8, w8, wzr, eq
	cmp	w23, #1
	csinc	w2, w8, wzr, ne
	b.ne	LBB0_299
; %bb.225:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x3, [sp, #512]
	b	LBB0_309
LBB0_226:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w24, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
LBB0_227:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	w28, w8
	b.lo	LBB0_341
; %bb.228:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w26, w28, w8
	and	w1, w26, #0xffff
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3128
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	tbz	w0, #0, LBB0_341
; %bb.229:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #7224]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x22
	bl	_nvm_services_runtime_view
	tbz	w0, #0, LBB0_341
; %bb.230:                              ;   in Loop: Header=BB0_190 Depth=1
	tbz	w24, #0, LBB0_318
LBB0_231:                               ;   in Loop: Header=BB0_190 Depth=1
	and	w8, w23, #0xfe
	cmp	w23, #50
	mov	w9, #48                         ; =0x30
	ccmp	w8, w9, #4, ne
	cset	w9, eq
	sub	w10, w23, #48
	cmp	w10, #3
	cset	w11, lo
	cmp	w8, #40
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #3128
	ldrb	w10, [x13, #84]
	and	w8, w10, #0xff
	ccmp	w8, #4, #0, eq
	csinc	w9, w9, wzr, ne
	csinc	w8, w11, wzr, ne
	cmp	w9, #0
	mov	w9, #4                          ; =0x4
	csinc	w9, w9, wzr, ne
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #3128
	ldrb	w11, [x13, #80]
	cmp	w11, #1
	b.ne	LBB0_336
; %bb.232:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w11, [x12, #81]
	tbnz	w11, #0, LBB0_336
; %bb.233:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w11, [x12, #82]
	tbnz	w11, #0, LBB0_336
; %bb.234:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w11, [x12, #85]
	cbnz	w11, LBB0_336
; %bb.235:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w11, [sp, #7320]
	cbnz	w11, LBB0_336
; %bb.236:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w9, w10, uxtb
	b.ne	LBB0_336
; %bb.237:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w10, [sp, #7312]
	cmn	w10, #1
	b.ne	LBB0_336
; %bb.238:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w10, [sp, #7316]
	cmn	w10, #1
	b.ne	LBB0_336
; %bb.239:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #104]
	cmp	w10, #1
	b.ne	LBB0_336
; %bb.240:                              ;   in Loop: Header=BB0_190 Depth=1
	cbz	w8, LBB0_242
; %bb.241:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x10, [sp, #7336]
	cmp	x10, #2
	b.hs	LBB0_336
LBB0_242:                               ;   in Loop: Header=BB0_190 Depth=1
	tbz	w24, #0, LBB0_325
LBB0_243:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	x10, [sp, #7456]
	cmp	w24, #0
	csel	x9, xzr, x10, ne
	sub	w11, w23, #32
	cmp	w11, #181
	b.hi	LBB0_341
; %bb.244:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x8, [sp, #7336]
Lloh12:
	adrp	x14, lJTI0_1@PAGE
Lloh13:
	add	x14, x14, lJTI0_1@PAGEOFF
	adr	x12, LBB0_245
	ldrh	w13, [x14, x11, lsl #1]
	add	x12, x12, x13, lsl #2
	br	x12
LBB0_245:                               ;   in Loop: Header=BB0_190 Depth=1
	add	x26, x9, x8
	b	LBB0_384
LBB0_246:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	w28, LBB0_341
; %bb.247:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.248:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #368
	mov	x0, x22
	bl	_nvm_services_runtime_view
	tbz	w0, #0, LBB0_341
; %bb.249:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #8
	b.ne	LBB0_275
; %bb.250:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #369]
	tbnz	w8, #0, LBB0_336
; %bb.251:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #370]
	tbz	w8, #0, LBB0_275
	b	LBB0_336
LBB0_252:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w1, [sp, #512]
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_local
	cbz	w0, LBB0_341
; %bb.253:                              ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	cbz	w0, LBB0_341
; %bb.254:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #368
	mov	x0, x22
	bl	_nvm_services_runtime_view
	tbz	w0, #0, LBB0_341
; %bb.255:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #368]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.256:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #370]
	tbnz	w8, #0, LBB0_336
; %bb.257:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #369]
	cmp	w23, #11
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_336
; %bb.258:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	ldr	w2, [sp, #488]
	mov	x0, x22
	cmp	w23, #16
	b.ne	LBB0_348
; %bb.259:                              ;   in Loop: Header=BB0_190 Depth=1
	bl	_nvm_services_runtime_copy
	b	LBB0_349
LBB0_260:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_store
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_261:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_borrow
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_262:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w8, [sp, #528]
	ldrh	w9, [sp, #520]
	cmp	w23, #251
	csel	w21, w8, w9, eq
	ldrh	w9, [sp, #536]
	csel	w8, w9, w8, eq
	and	w9, w8, #0xffff
	cmp	w9, #11
	b.hi	LBB0_341
; %bb.263:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w28, w9
	b.lo	LBB0_341
; %bb.264:                              ;   in Loop: Header=BB0_190 Depth=1
	tst	w8, #0xffff
	b.eq	LBB0_311
; %bb.265:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x26, #0                         ; =0x0
	and	x23, x8, #0xffff
	sub	w28, w28, w8
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #3208
LBB0_266:                               ;   Parent Loop BB0_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w8, w28, w26
	and	w1, w8, #0xffff
	mov	x0, x22
	mov	x2, x24
	bl	_nvm_services_runtime_frame_operand
	tbz	w0, #0, LBB0_341
; %bb.267:                              ;   in Loop: Header=BB0_266 Depth=2
	add	x26, x26, #1
	add	x24, x24, #4
	cmp	x23, x26
	b.ne	LBB0_266
; %bb.268:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w5, [sp, #7304]
	str	w5, [sp, #488]
	b	LBB0_313
LBB0_269:                               ;   in Loop: Header=BB0_190 Depth=1
	str	w25, [sp, #7304]
	cmp	w23, #68
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
	cmp	w28, w8
	b.lo	LBB0_341
; %bb.270:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, w8
	and	w1, w8, #0xffff
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.271:                              ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #68
	b.ne	LBB0_314
; %bb.272:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.273:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w3, [sp, #7304]
	b	LBB0_315
LBB0_274:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w1, [sp, #512]
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_local
	tbz	w0, #0, LBB0_341
LBB0_275:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	mov	x0, x22
	bl	_nvm_services_runtime_drop
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_276:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_end_reference
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_277:                               ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.278:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #488]
	mov	x0, x22
	bl	_nvm_services_runtime_indirect_funcref
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_279:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	w28, LBB0_341
; %bb.280:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.281:                              ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.282:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	ldr	w2, [sp, #488]
	mov	x0, x22
	bl	_nvm_services_runtime_copy
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_283:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w23, [sp, #1088]
	str	w25, [sp, #364]
	mov	x0, x22
	bl	_nvm_services_runtime_indirect_plan
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3128
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_import
	cbz	w0, LBB0_341
; %bb.284:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #7224]
	ldr	w9, [sp, #512]
	cmp	w8, w9
	b.ne	LBB0_341
; %bb.285:                              ;   in Loop: Header=BB0_190 Depth=1
	add	x1, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_scratch
	cbz	w0, LBB0_341
; %bb.286:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_indirect_plan
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w23, w8
	lsr	x24, x8, #34
	add	w8, w24, w24, lsl #3
	add	w1, w8, #8
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB0_322
; %bb.287:                              ;   in Loop: Header=BB0_190 Depth=1
	add	w8, w24, w24, lsl #2
	sub	w0, w23, w8
	bl	_nl_socket_catalog_method
	b	LBB0_338
LBB0_288:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_return
	b	LBB0_343
LBB0_289:                               ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.290:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #488]
	mov	x0, x22
	bl	_nvm_services_runtime_string_literal
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_291:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_region_begin
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_292:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_region_end
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_293:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w1, [sp, #512]
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_local
	cbz	w0, LBB0_341
; %bb.294:                              ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.295:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	ldrb	w8, [sp, #520]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w2, w8, ne
	ldr	w3, [sp, #488]
	mov	x0, x22
	bl	_nvm_services_runtime_take
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_296:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w1, [sp, #512]
	add	x2, sp, #492
	mov	x0, x22
	bl	_nvm_services_runtime_frame_local
	tbz	w0, #0, LBB0_341
; %bb.297:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x22
	bl	_nvm_services_runtime_result_arm
	mov	x1, x0
	cbnz	w0, LBB0_344
; %bb.298:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #7304]
	cmp	w8, #3
	cset	w24, eq
	b	LBB0_317
LBB0_299:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	w23, #3
	b.ne	LBB0_308
; %bb.300:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w3, [sp, #512]
	b	LBB0_309
LBB0_301:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #368
	mov	x0, x22
	bl	_nvm_services_runtime_view
	cbz	w0, LBB0_320
; %bb.302:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #369]
	mov	w1, #6                          ; =0x6
	tbnz	w8, #0, LBB0_321
; %bb.303:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #370]
	tbnz	w8, #0, LBB0_321
; %bb.304:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #384]
	cmp	w8, #3
	b.ne	LBB0_321
; %bb.305:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #3208
	mov	x0, x22
	bl	_nvm_services_runtime_result_arm
	cbnz	w0, LBB0_343
; %bb.306:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	mov	x0, x22
	bl	_nvm_services_runtime_drop
	cbnz	w0, LBB0_343
; %bb.307:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #492]
	ldr	w8, [sp, #7304]
	cmp	w8, #3
	cset	w3, eq
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	b	LBB0_310
LBB0_308:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x3, #0                          ; =0x0
LBB0_309:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #488]
	mov	x0, x22
LBB0_310:                               ;   in Loop: Header=BB0_190 Depth=1
	bl	_nvm_services_runtime_scalar
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_311:                               ;   in Loop: Header=BB0_190 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #488
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	cbz	w0, LBB0_341
; %bb.312:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x23, #0                         ; =0x0
	ldr	w5, [sp, #488]
LBB0_313:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #1088]
	and	w2, w21, #0xffff
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3208
	mov	x0, x22
	mov	x4, x23
	bl	_nvm_services_runtime_construct
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_314:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w3, #-1                         ; =0xffffffff
LBB0_315:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w2, [sp, #492]
	mov	x0, x22
	mov	x1, x23
	mov	x4, x2
	bl	_nvm_services_runtime_string_operation
	cbnz	w0, LBB0_180
LBB0_316:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w24, #0                         ; =0x0
LBB0_317:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	mov	x1, x24
	bl	_nvm_services_runtime_frame_next
	b	LBB0_343
LBB0_318:                               ;   in Loop: Header=BB0_190 Depth=1
	add	w8, w26, #1
	and	w1, w8, #0xffff
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3128
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_services_runtime_frame_operand
	cbz	w0, LBB0_341
; %bb.319:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #7228]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3208
	add	x2, x8, #120
	mov	x0, x22
	bl	_nvm_services_runtime_view
	tbnz	w0, #0, LBB0_231
	b	LBB0_341
LBB0_320:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w1, #5                          ; =0x5
LBB0_321:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	b	LBB0_342
LBB0_322:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_indirect_plan
	mov	x1, x23
	bl	_services_dispatch_websocket
	mov	x8, x0
	add	w9, w24, w24, lsl #2
	sub	w0, w23, w9
	cbz	w8, LBB0_337
; %bb.323:                              ;   in Loop: Header=BB0_190 Depth=1
	bl	_nl_websocket_catalog_method
	b	LBB0_338
LBB0_324:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, #0
	cset	w8, ne
	cmp	w23, #57
	cset	w9, ne
	eor	w24, w9, w8
	b	LBB0_317
LBB0_325:                               ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #200]
	cmp	w10, #1
	b.ne	LBB0_336
; %bb.326:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #201]
	tbnz	w10, #0, LBB0_336
; %bb.327:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #202]
	tbnz	w10, #0, LBB0_336
; %bb.328:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #205]
	cbnz	w10, LBB0_336
; %bb.329:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w10, [sp, #7440]
	cbnz	w10, LBB0_336
; %bb.330:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w10, [x12, #204]
	cmp	w10, w9
	b.ne	LBB0_336
; %bb.331:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w9, [sp, #7432]
	cmn	w9, #1
	b.ne	LBB0_336
; %bb.332:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w9, [sp, #7436]
	cmn	w9, #1
	b.ne	LBB0_336
; %bb.333:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w9, [x12, #224]
	cmp	w9, #1
	b.ne	LBB0_336
; %bb.334:                              ;   in Loop: Header=BB0_190 Depth=1
	cbz	w8, LBB0_243
; %bb.335:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x8, [sp, #7456]
	cmp	x8, #1
	b.ls	LBB0_243
LBB0_336:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	mov	w1, #6                          ; =0x6
	b	LBB0_342
LBB0_337:                               ;   in Loop: Header=BB0_190 Depth=1
	bl	_nl_file_catalog_method
LBB0_338:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	x0, LBB0_341
; %bb.339:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x8, [x0, #56]
	cbz	x8, LBB0_341
; %bb.340:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w9, [x0, #44]
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cmp	w9, #1
	cset	w10, eq
	csetm	x9, eq
	mvn	x10, x10
	add	x21, x10, x8
	cmp	x21, #2
	ccmp	x28, x21, #0, ls
	b.hs	LBB0_350
LBB0_341:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	mov	w1, #5                          ; =0x5
LBB0_342:                               ;   in Loop: Header=BB0_190 Depth=1
	bl	_nvm_services_runtime_fail
LBB0_343:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x1, x0
LBB0_344:                               ;   in Loop: Header=BB0_190 Depth=1
	cbnz	w1, LBB0_181
; %bb.345:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrb	w8, [sp, #504]
	cmp	w8, #61
	b.ne	LBB0_189
; %bb.346:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w8, [sp, #292]
	cmp	w8, #1
	b.ne	LBB0_189
; %bb.347:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	x0, [sp, #264]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #3208
	bl	_nvm_services_runtime_current_root
	tbnz	w0, #0, LBB0_188
	b	LBB0_182
LBB0_348:                               ;   in Loop: Header=BB0_190 Depth=1
	bl	_nvm_services_runtime_move
LBB0_349:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x1, x0
	cbz	w0, LBB0_316
	b	LBB0_181
LBB0_350:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	x21, LBB0_354
; %bb.351:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	x8, x28, x8
	sub	x8, x8, x9
	add	x26, x8, #1
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #3208
	mov	x23, x21
LBB0_352:                               ;   Parent Loop BB0_190 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w1, w26, #0xffff
	mov	x0, x22
	mov	x2, x24
	bl	_nvm_services_runtime_frame_operand
	tbz	w0, #0, LBB0_341
; %bb.353:                              ;   in Loop: Header=BB0_352 Depth=2
	add	x24, x24, #4
	add	x26, x26, #1
	subs	x23, x23, #1
	b.ne	LBB0_352
LBB0_354:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB0_357
; %bb.355:                              ;   in Loop: Header=BB0_190 Depth=1
	ldrh	w1, [sp, #520]
	add	x2, sp, #364
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reference
	cbz	w0, LBB0_341
; %bb.356:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w2, [sp, #364]
	b	LBB0_358
LBB0_357:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w2, #-1                         ; =0xffffffff
LBB0_358:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #512]
	ldr	w5, [sp, #488]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3208
	mov	x0, x22
	mov	x4, x21
	bl	_nvm_services_runtime_service_args
	mov	x1, x0
	cbnz	w0, LBB0_344
; %bb.359:                              ;   in Loop: Header=BB0_190 Depth=1
	sub	w8, w28, w21
	and	w1, w8, #0xffff
	add	x2, sp, #360
	mov	x0, x22
	bl	_nvm_services_runtime_frame_reserve
	tbz	w0, #0, LBB0_341
; %bb.360:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #488]
	ldr	w2, [sp, #360]
	mov	x0, x22
	bl	_nvm_services_runtime_move
	cbz	w0, LBB0_316
	b	LBB0_180
LBB0_361:                               ;   in Loop: Header=BB0_190 Depth=1
	sub	x26, x8, x9
	b	LBB0_384
LBB0_362:                               ;   in Loop: Header=BB0_190 Depth=1
	mul	x26, x9, x8
	b	LBB0_384
LBB0_363:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	x9, LBB0_370
; %bb.364:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x26, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x26
	b.ne	LBB0_366
; %bb.365:                              ;   in Loop: Header=BB0_190 Depth=1
	cmn	x9, #1
	b.eq	LBB0_384
LBB0_366:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w23, #1                         ; =0x1
	sdiv	x26, x8, x10
	b	LBB0_385
LBB0_367:                               ;   in Loop: Header=BB0_190 Depth=1
	cbz	x9, LBB0_370
; %bb.368:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x11, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x11
	b.ne	LBB0_383
; %bb.369:                              ;   in Loop: Header=BB0_190 Depth=1
	cmn	x9, #1
	b.ne	LBB0_383
LBB0_370:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	x26, #0                         ; =0x0
	b	LBB0_384
LBB0_371:                               ;   in Loop: Header=BB0_190 Depth=1
	neg	x26, x8
	b	LBB0_384
LBB0_372:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	b	LBB0_382
LBB0_373:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	b	LBB0_380
LBB0_374:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	cset	w26, lt
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_375:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	cset	w26, le
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_376:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	cset	w26, gt
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_377:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, x9
	cset	w26, ge
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_378:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, #0
	ccmp	x9, #0, #4, ne
	b	LBB0_380
LBB0_379:                               ;   in Loop: Header=BB0_190 Depth=1
	orr	x8, x8, x9
	cmp	x8, #0
LBB0_380:                               ;   in Loop: Header=BB0_190 Depth=1
	cset	w26, ne
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_381:                               ;   in Loop: Header=BB0_190 Depth=1
	cmp	x8, #0
LBB0_382:                               ;   in Loop: Header=BB0_190 Depth=1
	cset	w26, eq
	mov	w23, #4                         ; =0x4
	b	LBB0_385
LBB0_383:                               ;   in Loop: Header=BB0_190 Depth=1
	sdiv	x9, x8, x10
	msub	x26, x9, x10, x8
LBB0_384:                               ;   in Loop: Header=BB0_190 Depth=1
	mov	w23, #1                         ; =0x1
LBB0_385:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #7224]
	mov	x0, x22
	bl	_nvm_services_runtime_drop
	cbnz	w0, LBB0_343
; %bb.386:                              ;   in Loop: Header=BB0_190 Depth=1
	tbnz	w24, #0, LBB0_388
; %bb.387:                              ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #7228]
	mov	x0, x22
	bl	_nvm_services_runtime_drop
	cbnz	w0, LBB0_343
LBB0_388:                               ;   in Loop: Header=BB0_190 Depth=1
	ldr	w1, [sp, #7224]
	mov	x0, x22
	mov	x2, x23
	mov	x3, x26
	bl	_nvm_services_runtime_scalar
	mov	x1, x0
	cbnz	w0, LBB0_344
; %bb.389:                              ;   in Loop: Header=BB0_190 Depth=1
	mov	x0, x22
	bl	_nvm_services_runtime_frame_next
	b	LBB0_343
LBB0_390:
	ldr	x0, [sp, #264]
	mov	w1, #5                          ; =0x5
	bl	_nvm_services_runtime_fail
	cbnz	w0, LBB0_180
	b	LBB0_182
LBB0_391:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_317-LBB0_200)>>2
	.short	(LBB0_223-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_223-LBB0_200)>>2
	.short	(LBB0_289-LBB0_200)>>2
	.short	(LBB0_223-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_279-LBB0_200)>>2
	.short	(LBB0_246-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_252-LBB0_200)>>2
	.short	(LBB0_260-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_200-LBB0_200)>>2
	.short	(LBB0_252-LBB0_200)>>2
	.short	(LBB0_260-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_291-LBB0_200)>>2
	.short	(LBB0_292-LBB0_200)>>2
	.short	(LBB0_261-LBB0_200)>>2
	.short	(LBB0_261-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_226-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_226-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_317-LBB0_200)>>2
	.short	(LBB0_206-LBB0_200)>>2
	.short	(LBB0_206-LBB0_200)>>2
	.short	(LBB0_200-LBB0_200)>>2
	.short	(LBB0_200-LBB0_200)>>2
	.short	(LBB0_288-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_269-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_269-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_262-LBB0_200)>>2
	.short	(LBB0_201-LBB0_200)>>2
	.short	(LBB0_201-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_283-LBB0_200)>>2
	.short	(LBB0_296-LBB0_200)>>2
	.short	(LBB0_293-LBB0_200)>>2
	.short	(LBB0_274-LBB0_200)>>2
	.short	(LBB0_246-LBB0_200)>>2
	.short	(LBB0_276-LBB0_200)>>2
	.short	(LBB0_200-LBB0_200)>>2
	.short	(LBB0_200-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_206-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_226-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_277-LBB0_200)>>2
	.short	(LBB0_262-LBB0_200)>>2
	.short	(LBB0_201-LBB0_200)>>2
	.short	(LBB0_227-LBB0_200)>>2
	.short	(LBB0_201-LBB0_200)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_245-LBB0_245)>>2
	.short	(LBB0_361-LBB0_245)>>2
	.short	(LBB0_362-LBB0_245)>>2
	.short	(LBB0_363-LBB0_245)>>2
	.short	(LBB0_367-LBB0_245)>>2
	.short	(LBB0_371-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_372-LBB0_245)>>2
	.short	(LBB0_373-LBB0_245)>>2
	.short	(LBB0_374-LBB0_245)>>2
	.short	(LBB0_375-LBB0_245)>>2
	.short	(LBB0_376-LBB0_245)>>2
	.short	(LBB0_377-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_378-LBB0_245)>>2
	.short	(LBB0_379-LBB0_245)>>2
	.short	(LBB0_381-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_245-LBB0_245)>>2
	.short	(LBB0_361-LBB0_245)>>2
	.short	(LBB0_362-LBB0_245)>>2
	.short	(LBB0_363-LBB0_245)>>2
	.short	(LBB0_367-LBB0_245)>>2
	.short	(LBB0_371-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_341-LBB0_245)>>2
	.short	(LBB0_372-LBB0_245)>>2
	.short	(LBB0_373-LBB0_245)>>2
	.short	(LBB0_374-LBB0_245)>>2
	.short	(LBB0_375-LBB0_245)>>2
	.short	(LBB0_376-LBB0_245)>>2
	.short	(LBB0_377-LBB0_245)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB1_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh14:
	adrp	x9, lJTI1_0@PAGE
Lloh15:
	add	x9, x9, lJTI1_0@PAGEOFF
	adr	x10, LBB1_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB1_2:
	ret
LBB1_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
	.section	__TEXT,__const
lJTI1_0:
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function services_dispatch_websocket
_services_dispatch_websocket:           ; @services_dispatch_websocket
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w1, w8
	lsr	x8, x8, #34
	add	w20, w8, w8, lsl #3
	add	w1, w20, #6
	add	x2, sp, #12
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB2_2
; %bb.1:
	add	w1, w20, #7
	add	x2, sp, #12
	mov	x0, x19
	bl	_nvm_services_indirect_hosted_type
	eor	w0, w0, #0x1
LBB2_2:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
