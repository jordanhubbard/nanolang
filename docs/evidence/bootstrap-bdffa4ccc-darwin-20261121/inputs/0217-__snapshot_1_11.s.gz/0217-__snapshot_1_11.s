	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_functions_decode ; -- Begin function nvm_v2_functions_decode
	.globl	_nvm_v2_functions_decode
	.p2align	2
_nvm_v2_functions_decode:               ; @nvm_v2_functions_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_19
; %bb.1:
	ldr	w0, [sp, #4]
	cbz	w0, LBB0_19
; %bb.2:
	ldr	x8, [sp, #24]
	sub	x8, x20, x8
	cmp	x0, x8, lsr #5
	b.hi	LBB0_16
; %bb.3:
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB0_16
; %bb.4:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
LBB0_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x21, x20, x22
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_17
; %bb.6:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #8
	add	x1, x21, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_17
; %bb.7:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x21, x20, x22
	add	x0, sp, #8
	add	x1, x21, #8
	bl	_nvm_v2_u64
	cbnz	w0, LBB0_17
; %bb.8:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #8
	add	x1, x21, #16
	bl	_nvm_v2_u64
	cbnz	w0, LBB0_17
; %bb.9:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x21, x20, x22
	add	x0, sp, #8
	add	x1, x21, #24
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_17
; %bb.10:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #8
	add	x1, x21, #26
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_17
; %bb.11:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x8, x20, x22
	add	x0, sp, #8
	add	x1, x8, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_17
; %bb.12:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #8
	add	x1, sp, #2
	bl	_nvm_v2_u16
	cbnz	w0, LBB0_17
; %bb.13:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrh	w8, [sp, #2]
	cbnz	w8, LBB0_20
; %bb.14:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x23, #1
	ldr	w8, [sp, #4]
	add	x22, x22, #32
	cmp	x23, x8
	b.lo	LBB0_5
; %bb.15:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB0_19
LBB0_16:
	mov	w0, #1                          ; =0x1
	b	LBB0_19
LBB0_17:
	mov	x19, x0
LBB0_18:
	mov	x0, x20
	bl	_free
	mov	x0, x19
LBB0_19:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB0_20:
	mov	w19, #7                         ; =0x7
	b	LBB0_18
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_functions_free  ; -- Begin function nvm_v2_functions_free
	.globl	_nvm_v2_functions_free
	.p2align	2
_nvm_v2_functions_free:                 ; @nvm_v2_functions_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB1_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_functions_encoded_size ; -- Begin function nvm_v2_functions_encoded_size
	.globl	_nvm_v2_functions_encoded_size
	.p2align	2
_nvm_v2_functions_encoded_size:         ; @nvm_v2_functions_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #5
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_functions_encode ; -- Begin function nvm_v2_functions_encode
	.globl	_nvm_v2_functions_encode
	.p2align	2
_nvm_v2_functions_encode:               ; @nvm_v2_functions_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x1, x9, x8, lsl #5
	cmp	x2, x1
	b.hs	LBB3_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB3_6
LBB3_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB3_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	w9, #16                         ; =0x10
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	add	x10, x10, x9
	add	x11, x19, x9
	ldur	w12, [x10, #-16]
	stur	w12, [x11, #-12]
	ldur	w12, [x10, #-12]
	stur	w12, [x11, #-8]
	ldur	x12, [x10, #-8]
	stur	x12, [x11, #-4]
	ldr	x12, [x10]
	stur	x12, [x11, #4]
	ldrh	w12, [x10, #8]
	strh	w12, [x11, #12]
	ldrh	w12, [x10, #10]
	strh	w12, [x11, #14]
	ldrh	w10, [x10, #12]
	strh	w10, [x11, #16]
	add	x8, x8, #1
	ldr	w10, [x20, #8]
	add	x9, x9, #32
	cmp	x8, x10
	b.lo	LBB3_4
LBB3_5:
	mov	w0, #0                          ; =0x0
LBB3_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_globals_decode  ; -- Begin function nvm_v2_globals_decode
	.globl	_nvm_v2_globals_decode
	.p2align	2
_nvm_v2_globals_decode:                 ; @nvm_v2_globals_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_18
; %bb.1:
	ldr	w0, [sp, #4]
	cbz	w0, LBB4_18
; %bb.2:
	ldr	x8, [sp, #24]
	sub	x8, x20, x8
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43691
	umulh	x8, x8, x9
	cmp	x0, x8, lsr #3
	b.hi	LBB4_15
; %bb.3:
	mov	w1, #12                         ; =0xc
	bl	_calloc
	cbz	x0, LBB4_15
; %bb.4:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	add	x21, x0, #8
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	sub	x1, x21, #8
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_17
; %bb.6:                                ;   in Loop: Header=BB4_5 Depth=1
	add	x0, sp, #8
	add	x1, sp, #3
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_17
; %bb.7:                                ;   in Loop: Header=BB4_5 Depth=1
	add	x0, sp, #8
	add	x1, sp, #2
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_17
; %bb.8:                                ;   in Loop: Header=BB4_5 Depth=1
	add	x0, sp, #8
	mov	x1, sp
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_17
; %bb.9:                                ;   in Loop: Header=BB4_5 Depth=1
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_17
; %bb.10:                               ;   in Loop: Header=BB4_5 Depth=1
	ldrb	w8, [sp, #3]
	cmp	w8, #15
	b.hi	LBB4_16
; %bb.11:                               ;   in Loop: Header=BB4_5 Depth=1
	ldrb	w9, [sp, #2]
	mov	w0, #7                          ; =0x7
	cmp	w9, #1
	b.hi	LBB4_17
; %bb.12:                               ;   in Loop: Header=BB4_5 Depth=1
	ldrh	w10, [sp]
	cbnz	w10, LBB4_17
; %bb.13:                               ;   in Loop: Header=BB4_5 Depth=1
	sturb	w8, [x21, #-4]
	sturb	w9, [x21, #-3]
	add	x22, x22, #1
	ldr	w8, [sp, #4]
	add	x21, x21, #12
	cmp	x22, x8
	b.lo	LBB4_5
; %bb.14:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB4_18
LBB4_15:
	mov	w0, #1                          ; =0x1
	b	LBB4_18
LBB4_16:
	mov	w0, #8                          ; =0x8
LBB4_17:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
LBB4_18:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_globals_free    ; -- Begin function nvm_v2_globals_free
	.globl	_nvm_v2_globals_free
	.p2align	2
_nvm_v2_globals_free:                   ; @nvm_v2_globals_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB5_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_globals_encoded_size ; -- Begin function nvm_v2_globals_encoded_size
	.globl	_nvm_v2_globals_encoded_size
	.p2align	2
_nvm_v2_globals_encoded_size:           ; @nvm_v2_globals_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #12                         ; =0xc
	umull	x8, w8, w9
	add	x0, x8, #4
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_globals_encode  ; -- Begin function nvm_v2_globals_encode
	.globl	_nvm_v2_globals_encode
	.p2align	2
_nvm_v2_globals_encode:                 ; @nvm_v2_globals_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #12                         ; =0xc
	umull	x8, w8, w9
	add	x1, x8, #4
	cmp	x2, x1
	b.hs	LBB7_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB7_6
LBB7_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB7_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB7_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	add	x10, x10, x8
	add	x11, x19, x8
	ldr	w12, [x10]
	str	w12, [x11, #4]
	ldrb	w12, [x10, #4]
	strb	w12, [x11, #8]
	ldrb	w12, [x10, #5]
	strb	w12, [x11, #9]
	ldr	w10, [x10, #8]
	str	w10, [x11, #12]
	add	x9, x9, #1
	ldr	w10, [x20, #8]
	add	x8, x8, #12
	cmp	x9, x10
	b.lo	LBB7_4
LBB7_5:
	mov	w0, #0                          ; =0x0
LBB7_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
