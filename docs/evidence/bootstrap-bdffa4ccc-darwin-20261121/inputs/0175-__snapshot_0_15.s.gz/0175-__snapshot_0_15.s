	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_service_run_shadows         ; -- Begin function nl_service_run_shadows
	.p2align	2
_nl_service_run_shadows:                ; @nl_service_run_shadows
	.cfi_startproc
; %bb.0:
	mov	x6, x3
	mov	x3, x2
	mov	w2, #1                          ; =0x1
	mov	w4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	b	_run_shadows
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_run_catalog_shadows ; -- Begin function nl_service_run_catalog_shadows
	.p2align	2
_nl_service_run_catalog_shadows:        ; @nl_service_run_catalog_shadows
	.cfi_startproc
; %bb.0:
	sub	w8, w2, #3
	cmn	w8, #2
	b.hs	LBB1_2
; %bb.1:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB1_2:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x6, x4
	cmp	w2, #1
	csel	w8, wzr, w3, ne
	cmp	w2, #2
	csel	w4, wzr, w3, ne
	mov	x3, x8
	mov	x5, #0                          ; =0x0
	bl	_run_shadows
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function run_shadows
_run_shadows:                           ; @run_shadows
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #656
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	sub	w8, w2, #5
	cmn	w8, #4
	b.hs	LBB2_4
LBB2_1:
	mov	x1, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w26, #1                         ; =0x1
LBB2_2:
	ldur	x9, [x29, #-96]
Lloh3:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB2_112
; %bb.3:
	orr	x0, x8, x26
	add	sp, sp, #656
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB2_4:
	mov	x21, x1
	mov	x27, x0
	mov	x1, #0                          ; =0x0
	cmp	x0, #0
	ccmp	x21, #0, #4, eq
	cset	w8, ne
	mov	w26, #1                         ; =0x1
	cmp	x21, #1, lsl #12                ; =4096
	b.hi	LBB2_30
; %bb.5:
	tbnz	w8, #0, LBB2_30
; %bb.6:
	mov	x25, x6
	mov	x8, x1
	cbz	x6, LBB2_2
; %bb.7:
	ldrb	w8, [x25]
	cbz	w8, LBB2_1
; %bb.8:
	mov	x20, x5
	mov	x22, x3
	mov	x23, x2
	str	w4, [sp, #44]                   ; 4-byte Folded Spill
	cbz	x21, LBB2_19
; %bb.9:
	add	x28, x27, #16
	mov	w26, #1                         ; =0x1
	mov	x19, x21
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x28, #-16]
	cbz	x8, LBB2_31
; %bb.11:                               ;   in Loop: Header=BB2_10 Depth=1
	ldur	x8, [x28, #-8]
	cbz	x8, LBB2_31
; %bb.12:                               ;   in Loop: Header=BB2_10 Depth=1
	ldr	x0, [x28]
	cbz	x0, LBB2_60
; %bb.13:                               ;   in Loop: Header=BB2_10 Depth=1
	ldr	x24, [x28, #8]
	cbz	x24, LBB2_60
; %bb.14:                               ;   in Loop: Header=BB2_10 Depth=1
	ldrb	w8, [x0]
	cbz	w8, LBB2_60
; %bb.15:                               ;   in Loop: Header=BB2_10 Depth=1
	ldrb	w8, [x24]
	cbz	w8, LBB2_60
; %bb.16:                               ;   in Loop: Header=BB2_10 Depth=1
	mov	w1, #4097                       ; =0x1001
	bl	_strnlen
	cmp	x0, #1, lsl #12                 ; =4096
	b.hi	LBB2_60
; %bb.17:                               ;   in Loop: Header=BB2_10 Depth=1
	mov	x0, x24
	mov	w1, #4097                       ; =0x1001
	bl	_strnlen
	cmp	x0, #1, lsl #12                 ; =4096
	b.hi	LBB2_60
; %bb.18:                               ;   in Loop: Header=BB2_10 Depth=1
	add	x28, x28, #32
	subs	x19, x19, #1
	b.ne	LBB2_10
LBB2_19:
	cmp	w23, #1
	b.eq	LBB2_34
; %bb.20:
	cmp	w23, #4
	ldr	w28, [sp, #44]                  ; 4-byte Folded Reload
	b.eq	LBB2_32
; %bb.21:
	cmp	w23, #3
	b.ne	LBB2_35
; %bb.22:
	cbz	x21, LBB2_38
; %bb.23:
	add	x24, x27, #8
	mov	w26, #2                         ; =0x2
	mov	x19, x21
LBB2_24:                                ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB2_26
; %bb.25:                               ;   in Loop: Header=BB2_24 Depth=1
	ldrb	w8, [x20, #4]
	b	LBB2_27
LBB2_26:                                ;   in Loop: Header=BB2_24 Depth=1
	mov	w8, #0                          ; =0x0
LBB2_27:                                ;   in Loop: Header=BB2_24 Depth=1
	ldp	x0, x1, [x24, #-8]
	and	w4, w8, #0x1
	add	x5, sp, #96
	mov	x2, x22
	mov	x3, x28
	bl	_nl_service_policy_read
	ldr	w8, [sp, #96]
	cmp	w0, #0
	ccmp	w8, #3, #0, ne
	b.ne	LBB2_1
; %bb.28:                               ;   in Loop: Header=BB2_24 Depth=1
	ldrb	w8, [sp, #624]
	tbz	w8, #0, LBB2_60
; %bb.29:                               ;   in Loop: Header=BB2_24 Depth=1
	add	x24, x24, #32
	subs	x19, x19, #1
	b.ne	LBB2_24
	b	LBB2_38
LBB2_30:
	mov	x8, x1
	b	LBB2_2
LBB2_31:
	mov	x1, #0                          ; =0x0
	b	LBB2_2
LBB2_32:
	cbz	x21, LBB2_38
; %bb.33:
	cbz	x20, LBB2_37
	b	LBB2_38
LBB2_34:
	tbz	w22, #0, LBB2_36
	b	LBB2_38
LBB2_35:
	tbnz	w28, #0, LBB2_38
LBB2_36:
	cbz	x21, LBB2_38
LBB2_37:
	mov	x1, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w26, #2                         ; =0x2
	b	LBB2_2
LBB2_38:
Lloh6:
	adrp	x0, l_.str.7@PAGE
Lloh7:
	add	x0, x0, l_.str.7@PAGEOFF
	bl	_getenv
	mov	w8, #10                         ; =0xa
	cbz	x0, LBB2_42
; %bb.39:
	mov	x9, #0                          ; =0x0
	mov	w26, #0                         ; =0x0
LBB2_40:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x0]
	sub	w10, w10, #48
	cmp	w10, #9
	b.hi	LBB2_43
; %bb.41:                               ;   in Loop: Header=BB2_40 Depth=1
	mul	w11, w26, w8
	add	x0, x0, #1
	add	w26, w11, w10, uxtb
	sub	x9, x9, #1
	cmp	w26, #300
	b.ls	LBB2_40
	b	LBB2_44
LBB2_42:
	mov	w26, #10                        ; =0xa
	b	LBB2_46
LBB2_43:
	cbz	x9, LBB2_59
LBB2_44:
	ldrb	w8, [x0]
	cbnz	w8, LBB2_59
; %bb.45:
	sub	w8, w26, #301
	cmn	w8, #301
	b.ls	LBB2_59
LBB2_46:
	mov	w8, #384                        ; =0x180
	str	x8, [sp]
	mov	x0, x25
	mov	w1, #2817                       ; =0xb01
	movk	w1, #256, lsl #16
	bl	_open
	tbnz	w0, #31, LBB2_63
; %bb.47:
Lloh8:
	adrp	x1, l_.str@PAGE
Lloh9:
	add	x1, x1, l_.str@PAGEOFF
	str	w0, [sp, #40]                   ; 4-byte Folded Spill
	bl	_fdopen$DARWIN_EXTSN
	cbz	x0, LBB2_61
; %bb.48:
	mov	x19, x0
	cbz	x21, LBB2_52
; %bb.49:
	mov	x25, #0                         ; =0x0
Lloh10:
	adrp	x28, l_.str.1@PAGE
Lloh11:
	add	x28, x28, l_.str.1@PAGEOFF
	mov	x24, x27
LBB2_50:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x28
	mov	x2, x25
	mov	x3, x24
	bl	_record
	tbz	w0, #0, LBB2_58
; %bb.51:                               ;   in Loop: Header=BB2_50 Depth=1
	add	x25, x25, #1
	add	x24, x24, #32
	cmp	x21, x25
	b.ne	LBB2_50
LBB2_52:
	sub	x0, x29, #104
	bl	_pipe
	cbnz	w0, LBB2_58
; %bb.53:
	ldur	w0, [x29, #-104]
	mov	w8, #4                          ; =0x4
	str	x8, [sp]
	mov	w1, #4                          ; =0x4
	bl	_fcntl
	tbnz	w0, #31, LBB2_57
; %bb.54:
	ldur	w0, [x29, #-104]
	mov	w8, #1                          ; =0x1
	str	x8, [sp]
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbnz	w0, #31, LBB2_57
; %bb.55:
	ldur	w0, [x29, #-100]
	mov	w8, #1                          ; =0x1
	str	x8, [sp]
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbnz	w0, #31, LBB2_57
; %bb.56:
	add	x1, sp, #96
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB2_64
LBB2_57:
	ldur	w0, [x29, #-104]
	bl	_close
	ldur	w0, [x29, #-100]
	bl	_close
LBB2_58:
	mov	x0, x19
	bl	_fclose
	b	LBB2_63
LBB2_59:
Lloh12:
	adrp	x8, ___stderrp@GOTPAGE
Lloh13:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh14:
	ldr	x3, [x8]
Lloh15:
	adrp	x0, l_.str.8@PAGE
Lloh16:
	add	x0, x0, l_.str.8@PAGEOFF
	mov	w26, #1                         ; =0x1
	mov	w1, #70                         ; =0x46
	mov	w2, #1                          ; =0x1
	bl	_fwrite
LBB2_60:
	mov	x1, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	b	LBB2_2
LBB2_61:
	ldr	w0, [sp, #40]                   ; 4-byte Folded Reload
LBB2_62:
	bl	_close
LBB2_63:
	mov	x1, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w26, #5                         ; =0x5
	b	LBB2_2
LBB2_64:
	mov	x0, #0                          ; =0x0
	bl	_fflush
	bl	_fork
	mov	x25, x0
	bl	___error
	cbz	w25, LBB2_113
; %bb.65:
	ldr	w22, [x0]
	ldur	w0, [x29, #-100]
	bl	_close
	mov	x0, x19
	bl	_fclose
	tbnz	w25, #31, LBB2_73
; %bb.66:
	mov	x20, x0
	mov	x0, x25
	mov	x1, x25
	bl	_setpgid
	str	wzr, [sp, #76]
	strb	wzr, [sp, #75]
Lloh17:
	adrp	x8, l___const.run_shadows.pause@PAGE
Lloh18:
	add	x8, x8, l___const.run_shadows.pause@PAGEOFF
Lloh19:
	ldr	q0, [x8]
	str	q0, [sp, #80]
	add	x1, sp, #76
	mov	x0, x25
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	cmp	w0, w25
	b.eq	LBB2_72
; %bb.67:
	mov	x19, x0
LBB2_68:                                ; =>This Inner Loop Header: Depth=1
	tbz	w19, #31, LBB2_70
; %bb.69:                               ;   in Loop: Header=BB2_68 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB2_75
LBB2_70:                                ;   in Loop: Header=BB2_68 Depth=1
	ldp	x0, x1, [sp, #96]
	add	x3, sp, #75
	mov	x2, x26
	bl	_elapsed
	cbnz	w0, LBB2_74
; %bb.71:                               ;   in Loop: Header=BB2_68 Depth=1
	add	x0, sp, #80
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	add	x1, sp, #76
	mov	x0, x25
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	mov	x19, x0
	cmp	w0, w25
	b.ne	LBB2_68
LBB2_72:
	mov	w23, #0                         ; =0x0
	mov	x19, x25
	b	LBB2_76
LBB2_73:
Lloh20:
	adrp	x8, ___stderrp@GOTPAGE
Lloh21:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh22:
	ldr	x19, [x8]
	mov	x0, x22
	bl	_strerror
	str	x0, [sp]
Lloh23:
	adrp	x1, l_.str.4@PAGE
Lloh24:
	add	x1, x1, l_.str.4@PAGEOFF
	mov	x0, x19
	bl	_fprintf
	ldur	w0, [x29, #-104]
	b	LBB2_62
LBB2_74:
	bic	w19, w19, w19, asr #31
	mov	w23, #1                         ; =0x1
	b	LBB2_76
LBB2_75:
	mov	w23, #0                         ; =0x0
LBB2_76:
	neg	w0, w25
	mov	w1, #9                          ; =0x9
	bl	_kill
	cbz	w0, LBB2_78
; %bb.77:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #3
	cset	w24, ne
	b	LBB2_79
LBB2_78:
	mov	w24, #0                         ; =0x0
LBB2_79:
	cmp	w19, w25
	b.eq	LBB2_93
; %bb.80:
	tbnz	w19, #31, LBB2_93
; %bb.81:
	mov	x0, x25
	mov	w1, #9                          ; =0x9
	bl	_kill
	cbz	w0, LBB2_83
; %bb.82:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #3
	cset	w8, ne
	orr	w24, w8, w24
LBB2_83:
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB2_85
; %bb.84:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #75]
	b	LBB2_93
LBB2_85:
	add	x1, sp, #76
	mov	x0, x25
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	cmp	w0, w25
	b.eq	LBB2_91
; %bb.86:
	mov	x19, x0
LBB2_87:                                ; =>This Inner Loop Header: Depth=1
	tbz	w19, #31, LBB2_89
; %bb.88:                               ;   in Loop: Header=BB2_87 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB2_93
LBB2_89:                                ;   in Loop: Header=BB2_87 Depth=1
	ldp	x0, x1, [sp, #48]
	add	x3, sp, #75
	mov	w2, #1                          ; =0x1
	bl	_elapsed
	tbnz	w0, #0, LBB2_92
; %bb.90:                               ;   in Loop: Header=BB2_87 Depth=1
	add	x0, sp, #80
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	add	x1, sp, #76
	mov	x0, x25
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	mov	x19, x0
	cmp	w0, w25
	b.ne	LBB2_87
LBB2_91:
	mov	x19, x25
	b	LBB2_93
LBB2_92:
	bic	w19, w19, w19, asr #31
LBB2_93:
Lloh25:
	adrp	x8, l___const.run_shadows.received@PAGE
Lloh26:
	add	x8, x8, l___const.run_shadows.received@PAGEOFF
Lloh27:
	ldr	q0, [x8]
	str	q0, [sp, #48]
LBB2_94:                                ; =>This Inner Loop Header: Depth=1
	ldur	w0, [x29, #-104]
	add	x1, sp, #48
	mov	w2, #16                         ; =0x10
	bl	_read
	mov	x22, x0
	tbz	x0, #63, LBB2_96
; %bb.95:                               ;   in Loop: Header=BB2_94 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB2_94
LBB2_96:
	cmp	w20, #0
	cset	w26, ne
	ldur	w0, [x29, #-104]
	bl	_close
	orr	w9, w26, w24
	ldrb	w8, [sp, #75]
	tbnz	w9, #0, LBB2_101
; %bb.97:
	tbnz	w8, #0, LBB2_101
; %bb.98:
	cmp	w19, w25
	b.ne	LBB2_101
; %bb.99:
	tbz	w23, #0, LBB2_102
; %bb.100:
	mov	x1, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w26, #4                         ; =0x4
	b	LBB2_2
LBB2_101:
	cmp	w20, #0
	cset	w9, ne
Lloh28:
	adrp	x10, ___stderrp@GOTPAGE
Lloh29:
	ldr	x10, [x10, ___stderrp@GOTPAGEOFF]
Lloh30:
	ldr	x0, [x10]
	sxtw	x10, w19
	mov	w11, w25
	stp	x10, x11, [sp, #24]
	str	x8, [sp, #16]
	and	x8, x24, #0x1
	stp	x9, x8, [sp]
Lloh31:
	adrp	x1, l_.str.5@PAGE
Lloh32:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_fprintf
	b	LBB2_63
LBB2_102:
	ldr	w9, [sp, #76]
	ands	w8, w9, #0x7f
	b.eq	LBB2_104
; %bb.103:
	cmp	w8, #127
	csel	w8, wzr, w8, eq
	mov	w9, #-1                         ; =0xffffffff
	b	LBB2_111
LBB2_104:
	cmp	x22, #16
	b.ne	LBB2_110
; %bb.105:
	and	w8, w9, #0xff00
	cbnz	w8, LBB2_110
; %bb.106:
	ldr	x1, [sp, #56]
	cmp	x1, x21
	b.hi	LBB2_63
; %bb.107:
	cmp	x1, x21
	b.eq	LBB2_109
; %bb.108:
	ldr	w8, [sp, #48]
	cbz	w8, LBB2_63
LBB2_109:
	ldr	x9, [sp, #48]
	and	x8, x9, #0xffffffff00000000
	mov	w26, w9
	b	LBB2_2
LBB2_110:
	mov	w8, #0                          ; =0x0
	ubfx	w9, w9, #8, #8
LBB2_111:
Lloh33:
	adrp	x10, ___stderrp@GOTPAGE
Lloh34:
	ldr	x10, [x10, ___stderrp@GOTPAGEOFF]
Lloh35:
	ldr	x0, [x10]
	stp	x8, x22, [sp, #8]
	str	x9, [sp]
Lloh36:
	adrp	x1, l_.str.6@PAGE
Lloh37:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_fprintf
	b	LBB2_63
LBB2_112:
	bl	___stack_chk_fail
LBB2_113:
	ldur	w0, [x29, #-104]
	bl	_close
	mov	w0, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	bl	_setpgid
	cbnz	w0, LBB2_117
; %bb.114:
	ldr	w0, [sp, #40]                   ; 4-byte Folded Reload
	mov	w1, #1                          ; =0x1
	bl	_dup2
	tbnz	w0, #31, LBB2_116
; %bb.115:
	ldr	w0, [sp, #40]                   ; 4-byte Folded Reload
	mov	w1, #2                          ; =0x2
	bl	_dup2
	tbz	w0, #31, LBB2_119
LBB2_116:
	bl	___error
	ldr	w0, [x0]
	bl	_strerror
	str	x0, [sp]
Lloh38:
	adrp	x1, l_.str.3@PAGE
Lloh39:
	add	x1, x1, l_.str.3@PAGEOFF
	b	LBB2_118
LBB2_117:
	bl	___error
	ldr	w0, [x0]
	bl	_strerror
	str	x0, [sp]
Lloh40:
	adrp	x1, l_.str.2@PAGE
Lloh41:
	add	x1, x1, l_.str.2@PAGEOFF
LBB2_118:
	ldr	w0, [sp, #40]                   ; 4-byte Folded Reload
	bl	_dprintf
	mov	w0, #1                          ; =0x1
	bl	__exit
LBB2_119:
	mov	x0, x27
	mov	x1, x21
	mov	x2, x23
	mov	x3, x22
	ldr	w4, [sp, #44]                   ; 4-byte Folded Reload
	mov	x5, x20
	mov	x6, x19
	bl	_execute
	stp	x0, x1, [sp, #80]
	mov	x0, x19
	bl	_fclose
	cbz	w0, LBB2_121
; %bb.120:
	mov	w8, #5                          ; =0x5
	str	w8, [sp, #80]
LBB2_121:                               ; =>This Inner Loop Header: Depth=1
	ldur	w0, [x29, #-100]
	add	x1, sp, #80
	mov	w2, #16                         ; =0x10
	bl	_write
	mov	x19, x0
	tbz	x0, #63, LBB2_123
; %bb.122:                              ;   in Loop: Header=BB2_121 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB2_121
LBB2_123:
	ldur	w0, [x29, #-100]
	bl	_close
	cmp	x19, #16
	cset	w0, ne
	bl	__exit
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpAddLdr	Lloh17, Lloh18, Lloh19
	.loh AdrpAdd	Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh20, Lloh21, Lloh22
	.loh AdrpAddLdr	Lloh25, Lloh26, Lloh27
	.loh AdrpAdd	Lloh31, Lloh32
	.loh AdrpLdrGotLdr	Lloh28, Lloh29, Lloh30
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpLdrGotLdr	Lloh33, Lloh34, Lloh35
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_run_mixed_shadows   ; -- Begin function nl_service_run_mixed_shadows
	.p2align	2
_nl_service_run_mixed_shadows:          ; @nl_service_run_mixed_shadows
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x4, x3
	mov	x3, x2
	mov	w2, #3                          ; =0x3
	mov	x5, #0                          ; =0x0
	b	_run_shadows
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_run_websocket_shadows ; -- Begin function nl_service_run_websocket_shadows
	.p2align	2
_nl_service_run_websocket_shadows:      ; @nl_service_run_websocket_shadows
	.cfi_startproc
; %bb.0:
	mov	x6, x3
	mov	x5, x2
	mov	w2, #4                          ; =0x4
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	b	_run_shadows
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_run_mixed_config_shadows ; -- Begin function nl_service_run_mixed_config_shadows
	.p2align	2
_nl_service_run_mixed_config_shadows:   ; @nl_service_run_mixed_config_shadows
	.cfi_startproc
; %bb.0:
	mov	x6, x5
	mov	x5, x4
	mov	x4, x3
	mov	x3, x2
	mov	w2, #3                          ; =0x3
	b	_run_shadows
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record
_record:                                ; @record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x19, x0
	stp	x1, x2, [sp]
Lloh42:
	adrp	x1, l_.str.9@PAGE
Lloh43:
	add	x1, x1, l_.str.9@PAGEOFF
	bl	_fprintf
	tbnz	w0, #31, LBB6_12
; %bb.1:
	ldp	x9, x21, [x20, #16]
	ldrb	w8, [x9]
	cbz	w8, LBB6_5
; %bb.2:
	add	x22, x9, #1
Lloh44:
	adrp	x20, l_.str.10@PAGE
Lloh45:
	add	x20, x20, l_.str.10@PAGEOFF
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fprintf
	tbnz	w0, #31, LBB6_12
; %bb.4:                                ;   in Loop: Header=BB6_3 Depth=1
	ldrb	w8, [x22], #1
	cbnz	w8, LBB6_3
LBB6_5:
	mov	w0, #32                         ; =0x20
	mov	x1, x19
	bl	_fputc
	cmn	w0, #1
	b.eq	LBB6_12
; %bb.6:
	ldrb	w8, [x21], #1
	cbz	w8, LBB6_10
; %bb.7:
Lloh46:
	adrp	x20, l_.str.10@PAGE
Lloh47:
	add	x20, x20, l_.str.10@PAGEOFF
LBB6_8:                                 ; =>This Inner Loop Header: Depth=1
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fprintf
	tbnz	w0, #31, LBB6_12
; %bb.9:                                ;   in Loop: Header=BB6_8 Depth=1
	ldrb	w8, [x21], #1
	cbnz	w8, LBB6_8
LBB6_10:
	mov	w0, #10                         ; =0xa
	mov	x1, x19
	bl	_fputc
	cmn	w0, #1
	b.eq	LBB6_12
; %bb.11:
	mov	x0, x19
	bl	_fflush
	cbz	w0, LBB6_14
LBB6_12:
	mov	w0, #0                          ; =0x0
LBB6_13:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB6_14:
	mov	x0, x19
	bl	_fileno
	bl	_fsync
	cmp	w0, #0
	cset	w0, eq
	b	LBB6_13
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function execute
_execute:                               ; @execute
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #7376                       ; =0x1cd0
Lloh48:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh49:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3280
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	w4, [sp, #12]                   ; 4-byte Folded Spill
Lloh50:
	adrp	x8, l___const.execute.tcp_options@PAGE
Lloh51:
	add	x8, x8, l___const.execute.tcp_options@PAGEOFF
Lloh52:
	ldr	q0, [x8]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	stur	q0, [x29, #-112]
	cbz	x1, LBB7_45
; %bb.1:
	mov	x21, x6
	mov	x23, x5
	mov	x25, x3
	mov	x26, x2
	mov	x22, x1
	mov	x27, x0
	mov	x19, #0                         ; =0x0
Lloh53:
	adrp	x28, l_.str.11@PAGE
Lloh54:
	add	x28, x28, l_.str.11@PAGEOFF
Lloh55:
	adrp	x20, l_.str.12@PAGE
Lloh56:
	add	x20, x20, l_.str.12@PAGEOFF
LBB7_2:                                 ; =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x28
	mov	x2, x19
	mov	x3, x27
	bl	_record
	cbz	w0, LBB7_44
; %bb.3:                                ;   in Loop: Header=BB7_2 Depth=1
	cmp	w26, #2
	b.eq	LBB7_13
; %bb.4:                                ;   in Loop: Header=BB7_2 Depth=1
	cmp	w26, #3
	b.eq	LBB7_11
; %bb.5:                                ;   in Loop: Header=BB7_2 Depth=1
	cmp	w26, #4
	b.ne	LBB7_21
; %bb.6:                                ;   in Loop: Header=BB7_2 Depth=1
	str	xzr, [sp, #6760]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2664
	mov	x0, x23
	bl	_nvm_websocket_host_grant_create
	cbnz	w0, LBB7_44
; %bb.7:                                ;   in Loop: Header=BB7_2 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	str	q0, [sp, #6784]
	stp	xzr, xzr, [x29, #-128]
	ldr	x0, [sp, #6760]
	ldp	x1, x2, [x27]
	add	x8, sp, #32
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2688
	sub	x4, x29, #128
	bl	_nvm_websocket_execute_indirect_bytes
	ldr	x0, [sp, #6760]
	bl	_nvm_websocket_host_grant_revoke
	mov	x24, x0
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2664
	bl	_nvm_websocket_host_grant_destroy
	ldr	w8, [sp, #40]
	cbnz	w8, LBB7_44
; %bb.8:                                ;   in Loop: Header=BB7_2 Depth=1
	ldrb	w8, [sp, #44]
	tbz	w8, #0, LBB7_44
; %bb.9:                                ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB7_44
; %bb.10:                               ;   in Loop: Header=BB7_2 Depth=1
	cbz	w24, LBB7_18
	b	LBB7_44
LBB7_11:                                ;   in Loop: Header=BB7_2 Depth=1
	cbz	x23, LBB7_29
; %bb.12:                               ;   in Loop: Header=BB7_2 Depth=1
	ldrb	w8, [x23, #4]
	b	LBB7_30
LBB7_13:                                ;   in Loop: Header=BB7_2 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	str	q0, [sp, #6784]
	str	xzr, [sp, #6760]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2664
	bl	_nvm_socket_host_grant_create_tcp_connections
	cbnz	w0, LBB7_44
; %bb.14:                               ;   in Loop: Header=BB7_2 Depth=1
	stp	xzr, xzr, [x29, #-128]
	ldr	x0, [sp, #6760]
	ldp	x1, x2, [x27]
	add	x8, sp, #32
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2688
	sub	x4, x29, #128
	bl	_nvm_socket_execute_indirect_bytes
	ldr	x0, [sp, #6760]
	bl	_nvm_socket_host_grant_revoke
	mov	x24, x0
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2664
	bl	_nvm_socket_host_grant_destroy
	ldr	w8, [sp, #40]
	cbnz	w8, LBB7_44
; %bb.15:                               ;   in Loop: Header=BB7_2 Depth=1
	ldrb	w8, [sp, #44]
	tbz	w8, #0, LBB7_44
; %bb.16:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB7_44
; %bb.17:                               ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w24, LBB7_44
LBB7_18:                                ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w0, LBB7_44
; %bb.19:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #6760]
	cbnz	x8, LBB7_44
; %bb.20:                               ;   in Loop: Header=BB7_2 Depth=1
	ldur	x8, [x29, #-120]
	cbz	x8, LBB7_41
	b	LBB7_44
LBB7_21:                                ;   in Loop: Header=BB7_2 Depth=1
	stur	xzr, [x29, #-128]
	sub	x0, x29, #128
	bl	_nvm_file_host_grant_create_temporary_files
	cbnz	w0, LBB7_44
; %bb.22:                               ;   in Loop: Header=BB7_2 Depth=1
	str	xzr, [sp, #6792]
	str	xzr, [sp, #6784]
	ldur	x0, [x29, #-128]
	ldp	x1, x2, [x27]
	add	x8, sp, #32
	sub	x3, x29, #112
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2688
	bl	_nvm_file_execute_indirect_bytes
	ldur	x0, [x29, #-128]
	bl	_nvm_file_host_grant_revoke
	mov	x24, x0
	sub	x0, x29, #128
	bl	_nvm_file_host_grant_destroy
	ldr	w8, [sp, #40]
	cbnz	w8, LBB7_44
; %bb.23:                               ;   in Loop: Header=BB7_2 Depth=1
	ldrb	w8, [sp, #44]
	tbz	w8, #0, LBB7_44
; %bb.24:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB7_44
; %bb.25:                               ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w24, LBB7_44
; %bb.26:                               ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w0, LBB7_44
; %bb.27:                               ;   in Loop: Header=BB7_2 Depth=1
	ldur	x8, [x29, #-128]
	cbnz	x8, LBB7_44
; %bb.28:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #6792]
	cbz	x8, LBB7_41
	b	LBB7_44
LBB7_29:                                ;   in Loop: Header=BB7_2 Depth=1
	mov	w8, #0                          ; =0x0
LBB7_30:                                ;   in Loop: Header=BB7_2 Depth=1
	ldp	x0, x1, [x27]
	and	w4, w8, #0x1
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #2688
	mov	x2, x25
	ldr	w3, [sp, #12]                   ; 4-byte Folded Reload
	bl	_nl_service_policy_read
	cbz	w0, LBB7_44
; %bb.31:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	w8, [sp, #6784]
	cmp	w8, #3
	b.ne	LBB7_44
; %bb.32:                               ;   in Loop: Header=BB7_2 Depth=1
	add	x8, sp, #3217
	ldrb	w8, [x8, #4095]
	tbz	w8, #0, LBB7_44
; %bb.33:                               ;   in Loop: Header=BB7_2 Depth=1
	str	xzr, [sp, #6776]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2688
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2680
	mov	x1, x23
	bl	_nl_service_policy_grant
	cbnz	w0, LBB7_44
; %bb.34:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	stur	q0, [x29, #-128]
	str	xzr, [sp, #6768]
	str	xzr, [sp, #6760]
	ldr	x0, [sp, #6776]
	ldp	x1, x2, [x27]
	add	x8, sp, #32
	sub	x3, x29, #128
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2664
	bl	_nvm_services_execute_indirect_bytes
	ldr	x0, [sp, #6776]
	bl	_nvm_services_host_grant_revoke
	mov	x24, x0
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2680
	bl	_nvm_services_host_grant_destroy
	ldr	w8, [sp, #40]
	cbnz	w8, LBB7_44
; %bb.35:                               ;   in Loop: Header=BB7_2 Depth=1
	ldrb	w8, [sp, #44]
	tbz	w8, #0, LBB7_44
; %bb.36:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB7_44
; %bb.37:                               ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w24, LBB7_44
; %bb.38:                               ;   in Loop: Header=BB7_2 Depth=1
	cbnz	w0, LBB7_44
; %bb.39:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #6776]
	cbnz	x8, LBB7_44
; %bb.40:                               ;   in Loop: Header=BB7_2 Depth=1
	ldr	x8, [sp, #6768]
	cbnz	x8, LBB7_44
LBB7_41:                                ;   in Loop: Header=BB7_2 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	mov	x3, x27
	bl	_record
	cbz	w0, LBB7_44
; %bb.42:                               ;   in Loop: Header=BB7_2 Depth=1
	add	x19, x19, #1
	add	x27, x27, #32
	cmp	x22, x19
	b.ne	LBB7_2
; %bb.43:
	mov	x0, #0                          ; =0x0
	mov	x19, x22
	b	LBB7_46
LBB7_44:
	mov	w0, #3                          ; =0x3
	b	LBB7_46
LBB7_45:
	mov	x19, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
LBB7_46:
	mov	x1, x19
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3280
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAddLdr	Lloh50, Lloh51, Lloh52
	.loh AdrpAdd	Lloh55, Lloh56
	.loh AdrpAdd	Lloh53, Lloh54
	.loh AdrpLdrGot	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function elapsed
_elapsed:                               ; @elapsed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x3
	mov	x20, x2
	mov	x19, x1
	mov	x22, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB8_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	strb	w0, [x21]
	b	LBB8_5
LBB8_2:
	ldr	x8, [sp]
	mov	w9, w20
	sub	x8, x8, x22
	cmp	x8, x9
	b.le	LBB8_4
; %bb.3:
	mov	w0, #1                          ; =0x1
	b	LBB8_5
LBB8_4:
	ldr	x8, [sp, #8]
	ccmp	x8, x19, #8, eq
	cset	w0, ge
LBB8_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"w"

l_.str.1:                               ; @.str.1
	.asciz	"SELECT"

l_.str.2:                               ; @.str.2
	.asciz	"I cannot establish my shadow process group: %s.\n"

l_.str.3:                               ; @.str.3
	.asciz	"I cannot redirect my shadow log: %s.\n"

l_.str.4:                               ; @.str.4
	.asciz	"I cannot start my shadow child: %s.\n"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.run_shadows.pause
l___const.run_shadows.pause:
	.quad	0                               ; 0x0
	.quad	10000000                        ; 0x989680

	.p2align	3, 0x0                          ; @__const.run_shadows.received
l___const.run_shadows.received:
	.long	5                               ; 0x5
	.space	4
	.quad	0                               ; 0x0

	.section	__TEXT,__cstring,cstring_literals
l_.str.5:                               ; @.str.5
	.asciz	"I cannot finish shadow supervision (log %u, cleanup %u, clock %u, waited %ld, child %ld).\n"

l_.str.6:                               ; @.str.6
	.asciz	"I lost my shadow child report (exit %d, signal %d, bytes %ld).\n"

l_.str.7:                               ; @.str.7
	.asciz	"NANO_SHADOW_TIMEOUT_SECONDS"

l_.str.8:                               ; @.str.8
	.asciz	"I require NANO_SHADOW_TIMEOUT_SECONDS to be an integer from 1 to 300.\n"

l_.str.9:                               ; @.str.9
	.asciz	"%s %zu "

l_.str.10:                              ; @.str.10
	.asciz	"%02x"

l_.str.11:                              ; @.str.11
	.asciz	"START"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.execute.tcp_options
l___const.execute.tcp_options:
	.long	1                               ; 0x1
	.space	4
	.quad	1000000                         ; 0xf4240

	.section	__TEXT,__cstring,cstring_literals
l_.str.12:                              ; @.str.12
	.asciz	"DONE"

.subsections_via_symbols
