import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker='resource-keys-focused'
# This bounded gate proves preparation only; it cannot produce a passing worker result.
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("180",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
files=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p and not p.startswith('docs/evidence/')]
assert len(files)>3000 and all((root/p).is_file() for p in files)
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)

os.environ['NANO_SHADOW_TIMING']='1'
os.environ['NANO_CFLAGS']='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
os.environ['NANO_VERBOSE_BUILD']='1'
prior_root=Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-source')
closure_path=Path('/tmp/resource-keys-focused-build-closure.json')
overlay=Path('/tmp/resource-keys-focused-eval.c')
closure=json.loads(closure_path.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip().startswith('54e39da36')
assert sha(root/'src/eval.c')==closure['original_eval_sha256']
assert sha(overlay)==closure['overlay_sha256']
for p,h in closure['eval_dependencies'].items():assert sha(root/p)==h
for p,identity in closure['object_maps'].items():assert sha(p)==identity['sha256']
prior=json.loads(Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-reports/sanitize-artifacts.json').read_text())
for name in ['nanoc_c','nano_as_capture.so']:
 assert sha(root/'bin'/name)==prior[str(prior_root/'bin'/name)]['sha256']
paths.update(compiler=str(root/'bin/nanoc_c'),assembler_capture=str(root/'bin/nano_as_capture.so'),build_closure=str(closure_path),selection_overlay=str(overlay))
paths.update({'retained_object:'+p:p for p in closure['object_maps']})
expected=[]
text=(root/'src_nano/typecheck.nano').read_text()
original_text=subprocess.check_output(['git','show','53cc4f4e0:src_nano/typecheck.nano'],text=True)
names=('resource_classify','resource_concrete_payload_fact','resource_type_is_declared','resource_instantiated_classify')
for name in names:
 before=re.findall(r'^shadow '+name+r' \{\n(.*?)^\}',original_text,re.M|re.S)
 after=re.findall(r'^shadow '+name+r' \{\n(.*?)^\}',text,re.M|re.S)
 assert before and after[:len(before)]==before
 expected += [name]*len(after)
assert len(expected)==5
write('attribution.json',{'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'focused five original/additive resource bodies only; full original dependency checking and module initialization retained; other shadow runtime side effects excluded; no full preparation acceptance','expected_names':expected,'original_provider_source':'53cc4f4e039f2a8765b6200c2d8fc3abfb2302c0','overlay_sha256':sha(overlay),'original_eval_sha256':closure['original_eval_sha256'],'shadow_bound':60,'outer_bound':180,'environment':{k:os.environ.get(k) for k in ('ASAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','NANO_SHADOW_TIMING','NANO_CFLAGS','NANO_VERBOSE_BUILD')}})
shutil.copy2(overlay,report/'diagnostic-eval.c');shutil.copy2(closure_path,report/'build-closure.json')
obj=report/'diagnostic-eval.o';exe=root/'bin/nanoc_resource_focused'
cc=closure['cc']+closure['cflags']+closure['sanitize_flags']
compile_command=cc+['-MMD','-MP','-c',str(overlay),'-o',str(obj)]
objects=[str(obj) if p=='obj/eval.o' else str(prior_root/p) for p in closure['objects']]
link_command=cc+closure['sanitize_flags']+['-o',str(exe)]+objects+closure['ldflags']+closure['sanitize_flags']+closure['sanitize_flags']
write('build-commands.json',{'compile':compile_command,'link':link_command,'replaced_object':'obj/eval.o'})
try:
 run('focused-eval-compile',compile_command)
 run('focused-compiler-link',link_command)
 paths['focused_compiler']=str(exe)
 run('focused-symbols',[paths['nm'],'-u',str(exe)])
 symbols=(report/'focused-symbols.log').read_text();assert '__asan_' in symbols and '__ubsan_' in symbols
 run('focused-resource',[str(exe),'src_nano/typecheck_driver.nano','--verbose','-o',str(report/'sample')])
 log=(report/'focused-resource.log').read_text(errors='replace')
 selected=re.findall(r'^NANO_RESOURCE_SELECTION source=(\d+) item=(\d+) name=(\w+)$',log,re.M)
 assert sorted(v[2] for v in selected)==sorted(expected)
 assert len({v[0] for v in selected})==1
 records=[json.loads(line.split('NANO_SHADOW_TIMING ',1)[1]) for line in log.splitlines() if line.startswith('NANO_SHADOW_TIMING ')]
 starts=[v for v in records if v['phase']=='shadow_start'];ends=[v for v in records if v['phase']=='shadow_end']
 assert len(starts)==len(ends)==5 and all(v['status']==0 for v in ends)
 assert {(int(a),int(b)) for a,b,_ in selected}=={(v['source'],v['item']) for v in ends}
 assert re.findall(r'Loaded (\d+) module',log)==['19']
 assert len([v for v in records if v['phase']=='module_init_start'])==20
 write('focused-selection-validation.json',{'pass':True,'selection':selected,'records':records,'full_preparation_pass':False})
finally:
 write('retained-products.json',inventory([report,root/'bin']))
