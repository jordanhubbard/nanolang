#include "src/nanoisa/nvm2c_socket_indirect_private.h"
#include "tests/nanoisa/socket_dispatch_host.h"
int main(int argc,char **argv){
 if(argc!=3)return 2;
 NvmSocketIndirectOptions options={1,strtoull(argv[1],NULL,10)};
 dispatch_close_fault=atoi(argv[2])!=0;
 NvmSocketRuntimeView out={.fields=99,.values={12345}};
 NvmSocketIndirectExecutionReport r=nvm_socket_native_indirect_execute(&options,&out);
 dispatch_report(r,out);return 0;}
