#include "src/nanoisa/nvm2c_services_indirect_private.h"
#include <stdio.h>
#include <stdlib.h>
static unsigned services_tmpfiles;
FILE *services_test_tmpfile(void){services_tmpfiles++;return tmpfile();}
int main(int argc,char **argv){
 if(argc!=3)return 2;unsigned expected=(unsigned)strtoul(argv[2],NULL,10);
 NvmServicesIndirectOptions options={1,strtoull(argv[1],NULL,10)};NvmServicesRuntimeView out={.values={999}};
 NvmServicesIndirectExecutionReport r=nvm_services_native_indirect_execute(&options,&out);
 if(r.runtime.status!=expected || r.runtime.cleanup.cleanup_failures || r.runtime.cleanup.count!=3 ||
    out.values[0]!=(expected?999:42)){fprintf(stderr,"status=%u core=%u site=%u:%u value=%lld\n",r.runtime.status,r.runtime.core_status,r.runtime.function,r.runtime.instruction,(long long)out.values[0]);return 1;}
 if(services_tmpfiles)return 3;
 puts("PASS mixed generated native");return 0;}
