from pathlib import Path
import hashlib,json,shlex,subprocess,time
old=Path('/home/jkh/Src/nanolang-callable-ownership');base=Path.cwd();out=base/'.test_output/cycle-inline-candidate';assert out.is_dir();opts={l.partition('=')[0]:l.partition('=')[2] for l in (base/'.test_output/cycle-test-inputs.log').read_text().splitlines() if l.startswith('CYCLE_TEST_')};cc=shlex.split(opts['CYCLE_TEST_CC']);flags=shlex.split(opts['CYCLE_TEST_CFLAGS']);objects=shlex.split(opts['CYCLE_TEST_OBJECTS']);assert objects.count('obj/nanovm/heap_cycles.o')==1;record=dict(steps=[],source_sha256=hashlib.sha256((out/'heap_cycles.c').read_bytes()).hexdigest());(out/'heap_cycles.c').write_bytes((out/'heap_cycles.c').read_bytes());(out/'test_vm.c').write_bytes((base/'tests/nanovm/test_vm.c').read_bytes())
def run(argv,label):
 argv=list(map(str,argv));entry=dict(label=label,argv=argv);record['steps'].append(entry);t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(argv,cwd=old,stdout=a,stderr=b,timeout=600)
 entry.update(returncode=r.returncode,elapsed_seconds=time.monotonic()-t);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,entry
for name in ('heap.h','value.h','vm.h'):assert (base/'src/nanovm'/name).read_bytes()==(old/'src/nanovm'/name).read_bytes()
run([*cc,*flags,'-c',out/'heap_cycles.c','-I',base/'src/nanovm','-o',out/'heap_cycles.o'],'compile-collector')
objects=[str(out/'heap_cycles.o') if p=='obj/nanovm/heap_cycles.o' else p for p in objects]
run([*cc,*flags,'-o',out/'test_vm',base/'tests/nanovm/test_vm.c',*objects,*shlex.split(opts['CYCLE_TEST_LDFLAGS'])],'link-tests')
run([out/'test_vm'],'complete-original-and-new-vm-tests');print('I passed all original VM assertions and both packed-leaf regressions with the private inlined collector candidate.')
