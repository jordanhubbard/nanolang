from pathlib import Path
import hashlib,json,os,shlex,subprocess,time
old=Path('/home/jkh/Src/nanolang-callable-ownership');base=Path.cwd();out=base/'.test_output/cycle-leaf-graph-sanitizers';out.mkdir(exist_ok=False);opts={l.partition('=')[0]:l.partition('=')[2] for l in (base/'.test_output/cycle-test-inputs.log').read_text().splitlines() if l.startswith('CYCLE_TEST_')};cc=shlex.split(opts['CYCLE_TEST_CC']);flags=[*shlex.split(opts['CYCLE_TEST_CFLAGS']),'-O1','-UNDEBUG','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer','-ffp-contract=off','-fno-fast-math'];names=['heap','heap_cycles','value','vm'];objects=shlex.split(opts['CYCLE_TEST_OBJECTS']);unchanged=[p for p in objects if p not in [f'obj/nanovm/{n}.o' for n in names]];record=dict(steps=[],limits=['I instrument the actual VM, heap, values and test driver with the private leaf-graph collector candidate. Unchanged source/runtime providers retain their actual prebuilt objects, as in the original targeted sanitizer gate.'])
def run(argv,label):
 argv=list(map(str,argv));r=dict(label=label,argv=argv);record['steps'].append(r);t=time.monotonic();env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1')
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:s=subprocess.run(argv,cwd=old,env=env,stdout=a,stderr=b,timeout=600)
 r.update(returncode=s.returncode,elapsed_seconds=time.monotonic()-t);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert s.returncode==0,r
for n in names:run([*cc,*flags,'-c',(base/'.test_output/cycle-leaf-graph-candidate/heap_cycles.c' if n=='heap_cycles' else base/f'src/nanovm/{n}.c'),'-I',base/'src/nanovm','-o',out/(n+'.o')],'compile-'+n)
run([*cc,*flags,'-o',out/'test_vm',base/'tests/nanovm/test_vm.c',*[out/(n+'.o') for n in names],*unchanged,*shlex.split(opts['CYCLE_TEST_LDFLAGS'])],'link-full-vm-tests')
run([out/'test_vm'],'full-vm-tests')
run([*cc,*flags,'-o',out/'test_heap_failures',base/'tests/nanovm/test_heap_allocation_failure.c',*[out/(n+'.o') for n in names if n!='heap'],*unchanged,*shlex.split(opts['CYCLE_TEST_LDFLAGS'])],'link-original-allocation-failures')
run([out/'test_heap_failures'],'original-allocation-failures');print('I passed the original/new VM assertions and original allocation-failure controls with VM/heap/collector/value ASan/UBSan and leak checking.')
