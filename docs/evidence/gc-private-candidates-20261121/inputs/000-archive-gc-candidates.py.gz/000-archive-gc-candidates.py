from pathlib import Path
import gzip,hashlib,json
base=Path('.test_output');dest=Path('docs/evidence/gc-private-candidates-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__)}
for name in ['cycle-packed-leaf-generation','cycle-inline-candidate','cycle-inline-sanitizers','stage2-vm-cpu-inline-profile','cycle-leaf-graph-candidate','cycle-leaf-graph-sanitizers']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['run-cycle-generation.py','run-cycle-generation.log','run-cycle-inline-regression.py','run-cycle-inline-regression.log','run-cycle-inline-sanitizers.py','run-cycle-inline-sanitizers.log','run-cycle-inline-generation.py','profile-vm-cpu-inline.py','analyze-vm-cpu-inline.py','analyze-vm-cpu-inline.log','run-cycle-leaf-graph-regression.py','run-cycle-leaf-graph-regression.log','run-cycle-leaf-graph-sanitizers.py','run-cycle-leaf-graph-sanitizers.log','run-cycle-leaf-graph-generation.py']:
 paths.add(base/name)
assert not (base/'cycle-packed-leaf-generation/derived-stage2.nvm').exists()
for name in ['cycle-inline-sanitizers','cycle-leaf-graph-sanitizers']:
 assert '299243 passed, 0 failed' in (base/name/'full-vm-tests.stdout').read_text()
 assert all(x['returncode']==0 for x in json.loads((base/name/'manifest.json').read_text())['steps'])
sha=lambda b:hashlib.sha256(b).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,limits=['I retain the completed packed-only deadline failure, completed private unit/sanitizer/CPU observations and exact candidate source. Full inline/leaf-graph generation remains separate and is not included while running. Candidate checkout pins identify base checkout provenance; actual private collector source hashes identify the changed code.']),indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
