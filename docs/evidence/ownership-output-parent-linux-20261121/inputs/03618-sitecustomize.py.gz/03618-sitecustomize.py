from pathlib import Path
import tempfile
_parent=Path('/home/jkh/.worktrees/nanolang/ownership-output-parent-20261121-control/temporary-products')
class Retained(tempfile.TemporaryDirectory):
 def __init__(self,*args,**kwargs):
  kwargs["dir"]=_parent
  super().__init__(*args,**kwargs)
 def cleanup(self): self._finalizer.detach()
tempfile.TemporaryDirectory=Retained
