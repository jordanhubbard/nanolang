from pathlib import Path
import os,sys,subprocess,json,time,hashlib,signal,shutil,traceback
source=Path.cwd();root=Path('/home/jkh/.worktrees/nanolang/ownership-output-parent-20261121');out=root.with_name(root.name+'-control');assert not root.exists();out.mkdir(exist_ok=False);shutil.copy2(__file__,out/'observer.py');pin='91bfdc3280e5cfaa10d785912cb0d3ad868ad135';sha=lambda raw:hashlib.sha256(raw).hexdigest();record=dict(pin=pin,root=str(root),status='running',steps=[],limits=['I repair only the standalone test generated-parent setup. I run its actual Make target from a fresh detached source clone with .test_output absent, preserving the existing full ownership corpus, producers, private deferrals and limits. My external Python observer retains TemporaryDirectory products outside the clone and does not prepare .test_output. All production inputs match the paired ad2f8fbeb component; only the ownership test file differs. I claim no new production-source bootstrap or installed-isolation result.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc');b=None

def step(name,args,cwd,environment=env,timeout=3600):
 item=dict(name=name,argv=list(map(str,args)),cwd=str(cwd));record['steps'].append(item);save();start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as c:
  p=subprocess.Popen(args,cwd=cwd,env=environment,stdout=a,stderr=c,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['seconds']=time.monotonic()-start;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError((name,item['returncode']))
try:
 step('clone',['git','clone','--shared','--no-checkout',source,root],source,timeout=600)
 step('origin',['git','remote','set-url','origin','git@github.com:jordanhubbard/nanolang.git'],root,timeout=60)
 step('sparse-init',['git','sparse-checkout','init','--no-cone'],root,timeout=60)
 (root/'.git/info/sparse-checkout').write_text('/*\n!/docs/evidence/\n')
 step('checkout',['git','checkout','--detach',pin],root,timeout=600)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==pin
 names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],cwd=root,text=True).splitlines();expected={name:sha((root/name).read_bytes()) for name in names if (root/name).is_file()};record['source_hashes']=expected
 paired=json.loads((source/'docs/evidence/conversion-projection-linux-20261121/manifest.json').read_text())['source_hashes'];assert expected.keys()==paired.keys();delta=[name for name in expected if expected[name]!=paired[name]];assert delta==['tests/test_nanolang_translator_ownership_module.py'];record['delta_from_paired_ad2_source']=delta;save()
 frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
 b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider']=dict(native=str(frozen/'bin/nanoc_stage1'),native_sha256=sha((frozen/'bin/nanoc_stage1').read_bytes()),receipt_sha256=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes()))
 observers=out/'python-observer';observers.mkdir();retained=out/'temporary-products';retained.mkdir()
 (observers/'sitecustomize.py').write_text('from pathlib import Path\nimport tempfile\n_parent=Path('+repr(str(retained))+')\nclass Retained(tempfile.TemporaryDirectory):\n def __init__(self,*args,**kwargs):\n  kwargs["dir"]=_parent\n  super().__init__(*args,**kwargs)\n def cleanup(self): self._finalizer.detach()\ntempfile.TemporaryDirectory=Retained\n')
 gate=dict(env,PYTHONPATH=str(root)+os.pathsep+str(observers),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(frozen/'bin/nanoc_stage1'));gate.pop('NANOLANG_TRANSLATOR_SOURCE_MODULE',None)
 assert not (root/'.test_output').exists();record['output_parent_absent_before_make']=True;save()
 step('cold-make',['make','-j2','CC=/usr/bin/cc','test-nanolang-translator-ownership-module'],root,gate,timeout=3600)
 assert (root/'.test_output').is_dir();record['output_parent_created_by_gate']=True
 assert len(list((root/'.test_output').glob('ownership-module-products-*')))==1
 assert 'I compared 2563 full ownership module decisions' in (out/'cold-make.stdout').read_text()
 assert 'across 5 routes; 8 private-profile inputs remain pending' in (out/'cold-make.stdout').read_text()
 assert {name:sha((root/name).read_bytes()) for name in expected}==expected
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['source_and_provider_guards_unchanged']=True
 record['final_git_status']=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True);assert record['final_git_status']=='';record['status']='passed'
except BaseException as error:
 record['status']='failed';record['error']=repr(error);(out/'exception').write_text(traceback.format_exc())
finally:
 if b is not None:
  try:b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
  except BaseException as error:record.update(status='failed',guard_error=repr(error))
 save()
print(json.dumps({'status':record['status'],'manifest':str(out/'manifest.json')}),flush=True);sys.exit(0 if record['status']=='passed' else 1)
