from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,stat
source=Path.cwd();root=Path('/home/jkh/.worktrees/nanolang/ownership-output-parent-20261121');control=root.with_name(root.name+'-control');out=source/'docs/evidence/ownership-output-parent-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);sha=lambda raw:hashlib.sha256(raw).hexdigest();state=json.loads((control/'manifest.json').read_text());assert state['status']=='passed' and state['output_parent_absent_before_make'] and state['output_parent_created_by_gate'] and state['source_and_provider_guards_unchanged']
assert all(step['returncode']==0 for step in state['steps']);expected=state['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in expected.items())
old=subprocess.check_output(['git','show','ad2f8fbeb29636983463c559d7d1bbce5d6dbaab:tests/test_nanolang_translator_ownership_module.py']);(control/'baseline-test.py').write_bytes(old)
paths={Path(__file__).resolve()};paths.update(path for path in control.rglob('*') if path.is_file() and 'module-cache' not in path.relative_to(control).parts);paths.update(path for path in (root/'.test_output').rglob('*') if path.is_file());paths.update(root/name for name in expected)
for name in ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so','obj/nvm2c_module_reference','obj/nvm2c_declaration_reference']:
 p=root/name
 if p.is_file():paths.add(p)
work=source/'.test_output/conversion-projection-20261121'
for name in ['darwin-cold-ownership-make.stdout','darwin-cold-ownership-make.stderr','darwin-owned-make-dry-run.log','run-cold-output-parent.py']:paths.add(work/name)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
record=dict(implementation=state['pin'],issue=1175,source_hashes=expected,cold_make=state,baseline=dict(pin='ad2f8fbeb29636983463c559d7d1bbce5d6dbaab',test_sha256=sha(old),actual_make_exit=2,method_seconds=0.030,error='FileNotFoundError: absent .test_output/ownership-module-products-*'),limits=['I add only generated-parent preparation in the standalone ownership test. The actual Make target begins with .test_output absent, creates it itself, and passes the unchanged2563-case/five-route corpus including eight explicit private deferrals. My external Python retention observer keeps temporary products outside the clone and does not create the generated parent. Its PYTHONPATH and script are retained; build caches are omitted. Source, guards and qualified native bdffa4ccc provider remain unchanged. Only the test file differs from the paired ad2 conversion source snapshot; no production/compiler/runtime source changes. I do not claim a new final-source raw bootstrap, paired cold-root Make gate or release acceptance.'])
files=[];seen={}
for i,path in enumerate(sorted(paths)):
 raw=path.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{path.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(path),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(path.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and len(raw)==e['bytes'] and sha(raw)==e['sha256']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/name).read_bytes())==value for name,value in expected.items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
print(json.dumps(dict(files=len(files),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/name).stat().st_size for name in seen.values()),unique_artifacts=len(seen),source_files=len(expected))))
