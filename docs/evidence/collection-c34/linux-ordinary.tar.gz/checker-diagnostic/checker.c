#define main original_eval_main
#include "/home/jkh/nanolang-qualification/collection-c34-ordinary-source/tests/test_eval.c"
#undef main
void *nano_test_collection_calloc(size_t n,size_t w){return calloc(n,w);}
int main(void){
    const char *source =
        "struct DynamicChild { label:string }\n"
        "fn identity(x:string)->string{return x}\n"
        "fn keep(x:string)->bool{return (!= x \"\")}\n"
        "fn mapped(xs:array<string>)->array<string>{return (map xs identity)}\n"
        "fn filtered(xs:array<string>)->array<string>{return (filter xs keep)}\n"
        "fn pair(xs:array<string>,ys:array<string>)->array<string>{return (+ xs ys)}\n"
        "fn right(xs:array<string>,s:string)->array<string>{return (+ xs s)}\n"
        "fn left(s:string,xs:array<string>)->array<string>{return (+ s xs)}\n"
        "let mut task_input:array<string> = []\n"
        "fn task_slice()->array<string>{return (array_slice task_input 0 1)}\n"
        "fn main()->int{return 0}\n";
int count=0;Token *tokens=tokenize(source,&count);if(!tokens)return 2;ASTNode *program=parse_program(tokens,count);if(!program)return 3;Environment *env=create_environment();typecheck_set_current_file("<dynamic-child-fixture>");bool ok=type_check(program,env);fprintf(stderr,"checker-only result=%d\n",ok);free_environment(env);free_ast(program);free_tokens(tokens,count);clear_module_cache();return ok?0:1;}
