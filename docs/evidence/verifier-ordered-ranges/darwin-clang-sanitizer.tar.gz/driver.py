import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();config=sys.argv[3];report.mkdir(exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/Users/jkh/nanolang-qualification/verifier-service-supervisor.py');tree=ast.parse(base.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','write','inventory','run')];assert len(nodes)==4
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));
for node in nodes:
 if node.name=='run':
  for item in node.body:
   if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets):item.value=ast.Constant(value=1200)
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(module,str(base),'exec'));(report/'effective-supervisor.py').write_text(ast.unparse(module));shutil.copyfile(__file__,report/'driver.py')
files=(root/'.qualification-tracked').read_text().splitlines()
def source():return {p:sha(root/p) for p in files}
os.environ['PATH']='/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
paths={n:shutil.which(n) for n in ('make','cc','gcc','ar','ld','nm','ps','python3')};paths.update(driver=__file__,supervisor=str(base),driver_python=sys.executable)
compiler='/usr/bin/clang' if config=='apple-ordinary' else '/opt/homebrew/opt/llvm/bin/clang'
sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
paths['selected_compiler']=compiler
paths['xcrun']='/usr/bin/xcrun'
paths['sdk_settings']=str(Path(sdk)/'SDKSettings.json')
def tools():return {n:{'path':str(Path(p).resolve()),'sha256':sha(p)} for n,p in paths.items()}
phases=set();results=[];darwin=True
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['UBSAN_OPTIONS']='halt_on_error=1';os.environ['LSAN_OPTIONS']=''
flags='-Wall -Wextra -Werror -std=c99 -g -Isrc -D_GNU_SOURCE';link='-lm -lcrypto -L/opt/homebrew/opt/openssl@3/lib -isysroot '+shlex.quote(sdk)
flags+=' -I/opt/homebrew/opt/openssl@3/include -isysroot '+shlex.quote(sdk)
os.environ['SDKROOT']=sdk
if config=='clang-sanitizer':flags+=' -fsanitize=address,undefined -fno-omit-frame-pointer';link+=' -fsanitize=address,undefined'
write('attribution.json',{'source':'44d4eaf4f','config':config,'phase_bound':1200,'instrumentation':config,'LSan':False})

for target in ('test-verifier','test-forth-session','test-forth-core','test-forth-double','test-forth-float'):
 run(target,['make','-j2',target,'CC='+compiler,'CFLAGS='+flags,'LDFLAGS='+link])
write('final.json',{'status':'PASS','results':results})
