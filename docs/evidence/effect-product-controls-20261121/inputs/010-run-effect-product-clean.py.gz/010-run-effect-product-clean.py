from pathlib import Path
import os,subprocess,time,json
root=Path.cwd();out=root/'.test_output/effect-product-clean';out.mkdir(exist_ok=False);env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_BUILD_CACHE=str(root/'.test_output/effect-product-cache'),NANOLANG_EFFECT_COMPILERS=str(root/'bin/nano_virt'),NANOLANG_IMPORTED_EFFECT_COMPILERS=str(root/'bin/nano_virt'),NANOLANG_EFFECT_TARGETS='vm,native');record=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),steps=[],limits=['I build actual original source C/VM/translator providers with the effect-metadata cleanup. I exercise original publication/refusal, imported nominal identity and VM/native effect controls. I do not call these full sanitizer, self-hosted or Darwin acceptance.'])
def run(argv,label,timeout=1800):
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(argv,env=env,stdout=a,stderr=b,timeout=timeout)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
run(['make','-j4','CC=/usr/bin/cc','OBJ_DIR=.test_output/obj-effect-product-clean','bin/nanoc_c','nano_virt','nano_vm','nanoisa_dump','nvm2c','nvm2c-runtime','bin/nano_as_capture.so'],'build-original-product-providers')
run(['/usr/bin/python3','-m','unittest','-v','tests.test_imported_effect_identity','tests.test_selfhost_effects','tests.test_effect_execution','tests.test_native_effect_execution','tests.test_native_effects'],'original-effect-product-clean')
print('I passed original C/VM production and imported effect controls with VM/native execution.')
