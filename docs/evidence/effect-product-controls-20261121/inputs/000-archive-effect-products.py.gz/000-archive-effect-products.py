from pathlib import Path
import json,gzip,hashlib
root=Path.cwd();base=root/'.test_output';dest=root/'docs/evidence/effect-product-controls-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__)}
for directory in ['effect-product-controls','effect-product-clean']:
 paths.update(x for x in (base/directory).rglob('*') if x.is_file())
for pattern in ['run-effect-product*.py','run-effect-product*.log']:
 paths.update(base.glob(pattern))
for name in ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so','src/env.c','src/nanolang.h','tests/test_imported_effect_identity.py','tests/test_selfhost_effects.py','tests/test_effect_execution.py','tests/test_native_effect_execution.py','tests/test_native_effects.py']:
 paths.add(root/name)
sha=lambda x:hashlib.sha256(x).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p.relative_to(root)),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries),indent=2)+'\n')
for entry in entries:
 raw=(dest/entry['artifact']).read_bytes();assert sha(raw)==entry['compressed_sha256'] and sha(gzip.decompress(raw))==entry['sha256']
print(len(entries),sum(e['bytes'] for e in entries),sum(p.stat().st_size for p in seen.values()))
