from pathlib import Path
import os,json,hashlib,subprocess,time,sys
root=Path.cwd();out=root/'.test_output/host-closure-compiler-v2';out.mkdir(exist_ok=False);old=root/'.test_output/installed-tool-discovery';previous=json.loads((old/'build-manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert previous['source_sha256']==sha(root/'src_nano/nanoc_v06.nano');assert previous['products'][str(old/'compiler.nvm')]==sha(old/'compiler.nvm')
record=dict(compiler_source_sha256=previous['source_sha256'],raw_input=str(old/'compiler.nvm'),raw_sha256=sha(old/'compiler.nvm'),translator_sha256=sha(root/'bin/nvm2c'),steps=[],limits=['I translate the unchanged earlier development raw compiler with my new host loader. This uses actual retained host artifacts and does not regenerate raw stages or claim a new bootstrap/final-head qualification.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc')
for label,args in [('verify',[root/'bin/nano_vm','--verify-only',old/'compiler.nvm']),('translate',[root/'bin/nvm2c',old/'compiler.nvm','-o',out/'compiler.c']),('native',['/usr/bin/cc','-std=c11','-O1',out/'compiler.c',Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/bin/nano_aot_runtime.o'),'-lm','-rdynamic','-ldl','-o',out/'nanoc'])]:
 step=dict(label=label,argv=list(map(str,args)));record['steps'].append(step);save();t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(step['argv'],env=env,cwd=root,stdout=a,stderr=b,start_new_session=True);step['pid']=p.pid;save()
  try:step['returncode']=p.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   import signal;os.killpg(p.pid,signal.SIGKILL);step['returncode']=p.wait();step['timeout']=True
 step['elapsed_seconds']=time.monotonic()-t;save();assert step['returncode']==0,label
record['native_sha256']=sha(out/'nanoc');record['status']='passed';save()
