from pathlib import Path
import json,os,subprocess,time,sys,tempfile,hashlib,signal
root=Path.cwd();sys.path.insert(0,str(root));from scripts.install_host_artifacts import declared_artifacts
build=root/'.test_output/host-closure-compiler-v2';state=json.loads((build/'manifest.json').read_text());assert state['status']=='passed';compiler=build/'nanoc';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(compiler)==state['native_sha256'];out=root/'.test_output/host-closure-installed';out.mkdir(exist_ok=False)
frozen=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
record=dict(compiler_sha256=sha(compiler),translator_sha256=sha(root/'bin/nvm2c'),host_inputs={path:digest for digest,paths in declared_artifacts(compiler.read_bytes()).items() for path in paths},steps=[],limits=['I qualify this development compiler and its exact deployment libraries with actual Make installation and root isolation. I preserve original shadows and the separate frozen bootstrap guards. I do not claim a new bootstrap or final release qualification.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_SHADOW_TIMEOUT_SECONDS='10',NANO_BUILD_CACHE=str(out/'module-cache'))
def run(label,argv,cwd=root,child_env=env,expect=0,timeout=1800):
 entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd));record['steps'].append(entry);save();start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as z:
  p=subprocess.Popen(entry['argv'],cwd=cwd,env=child_env,stdout=a,stderr=z,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);entry.update(returncode=p.wait(),timeout=True)
 entry['elapsed_seconds']=time.monotonic()-start;save();assert not entry.get('timeout') and (entry['returncode']==0 if expect==0 else entry['returncode']!=0),entry
try:
 external=Path(tempfile.mkdtemp(prefix='nano-host-closure-prefix-'));oldprefix=external/'first-prefix';prefix=external/'relocated-prefix';client=external/'client';client.mkdir();record.update(external=str(external),prefix=str(prefix));save()
 run('actual-make-install',['make','CC=/usr/bin/cc','--old-file='+str(compiler),'COMPILER='+str(compiler),'PREFIX='+str(oldprefix),'install'])
 oldprefix.rename(prefix);assert sha(prefix/'bin/nanoc')==sha(compiler)
 source=client/'input.nano';source.write_text('fn answer()->int{return 42}\nshadow answer{assert (== (answer) 42)}\nfn main()->int{assert (== (answer) 42) (println "host-closure-prefix-ok") return 0}\n')
 provider=client/'provider';provider.mkdir();(provider/'module.json').write_text(json.dumps(dict(name='provider',c_sources=['api.c'])));(provider/'api.nano').write_text('extern fn path_basename(s: string) -> string\n');(provider/'api.c').write_text('const char *path_basename(const char *s) { (void)s; return "external-provider-ok"; }\n')
 foreign=client/'foreign.nano';foreign.write_text('import "provider/api.nano"\nfn main()->int { unsafe { (println (path_basename "input")) } return 0 }\nshadow main { assert true }\n')
 hidden=[p for p in [Path('/home/jkh/.worktrees/nanolang'),Path('/home/jkh/Src/nanolang'),Path('/home/jkh/Src/nanolang-callable-ownership')] if p.is_dir()];record['hidden_roots']=list(map(str,hidden));base=['/bin/bwrap','--bind','/','/','--proc','/proc','--dev','/dev']
 for path in hidden:assert not prefix.is_relative_to(path);base+=['--tmpfs',str(path)]
 base+=['--chdir',str(client),'--'];clean=dict(env,PATH=str(prefix/'bin')+':/usr/bin:/bin',NANO_CC='/bin/false',NANO_BUILD_CACHE=str(external/'external-cache'),TMPDIR=str(client))
 for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM']:clean.pop(key,None)
 record['isolated_environment']={k:clean.get(k) for k in ['PATH','CC','NANO_CC','NANO_BUILD_CACHE','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER']};save()
 run('namespace-setup',base+['/usr/bin/true'],cwd=client,child_env=clean,timeout=30)
 for label,input_,name,expected,driver in [('builtin',source,'builtin','host-closure-prefix-ok',prefix/'bin/nanoc'),('foreign',foreign,'foreign','external-provider-ok','nanoc')]:
  # Raw compilation of builtins cannot invoke a C compiler; foreign C inputs require the selected compiler.
  selected=clean if label=='builtin' else dict(clean,NANO_CC='/usr/bin/cc')
  run(label+'-compile-module',base+[driver,input_,'--emit-nvm','-o',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=180)
  run(label+'-verify-module',base+[prefix/'bin/nano_vm','--verify-only',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=30)
  run(label+'-execute-module',base+[prefix/'bin/nano_vm',client/(name+'.nvm')],cwd=client,child_env=selected,timeout=30)
  run(label+'-compile-native',base+[driver,input_,'--target','native','-o',client/(name+'.native')],cwd=client,child_env=dict(clean,NANO_CC='/usr/bin/cc'),timeout=180)
  run(label+'-execute-native',base+[client/(name+'.native')],cwd=client,child_env=selected,timeout=30)
  for kind in ['module','native']:assert (out/(label+'-execute-'+kind+'.stdout')).read_text()==expected+'\n'
 key=next(digest for path,digest in record['host_inputs'].items() if 'libfile_source_inputs.' in path);library=prefix/'lib/nanolang/hosts'/key;original=library.read_bytes();protected=client/'protected.nvm';protected.write_bytes(b'preserve-existing-output')
 try:
  library.write_bytes(original+b'changed')
  run('corrupt-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',protected],cwd=client,child_env=clean,expect=1,timeout=180)
  assert protected.read_bytes()==b'preserve-existing-output'
 finally:library.write_bytes(original)
 absent=library.with_name('same-basename.so');library.rename(absent)
 try:
  run('missing-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',protected],cwd=client,child_env=clean,expect=1,timeout=180);assert protected.read_bytes()==b'preserve-existing-output'
 finally:absent.rename(library)
 run('restored-installed-library',base+[prefix/'bin/nanoc',source,'--emit-nvm','-o',client/'restored.nvm'],cwd=client,child_env=clean,timeout=180)
 record['status']='passed'
finally:
 record['host_inputs_unchanged']=all(sha(path)==digest for path,digest in record['host_inputs'].items());b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['original_bootstrap_guards_unchanged']=True;save()
