# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_public.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_abi.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 2







typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[8u];
} NvmFileNominalBindings;
NvmServiceResult nvm_file_nominal_check(const NvmFileNominalBindings *);

NvmServiceResult nvm_file_nominal_decode(const uint8_t *,size_t,NvmFileNominalBindings *);


NvmServiceResult nvm_file_nominal_encode(const NvmFileNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_FILE_NOMINAL_DESCRIBED, NVM_FILE_NOMINAL_INVALID,
    NVM_FILE_NOMINAL_LIMIT, NVM_FILE_NOMINAL_MEMORY
} NvmFileNominalStatus;
typedef enum {
    NVM_FILE_CATEGORY_UNKNOWN, NVM_FILE_CATEGORY_FILE,
    NVM_FILE_CATEGORY_OPEN_RESULT, NVM_FILE_CATEGORY_SCALAR_RESULT,
    NVM_FILE_CATEGORY_RECORD
} NvmFileCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmFileCategory category;
} NvmFileNominalLayout;
typedef struct NvmFileNominalPlan NvmFileNominalPlan;




NvmFileNominalStatus nvm_file_nominal_plan(const NvmModule *,NvmFileNominalPlan **);
void nvm_file_nominal_plan_free(NvmFileNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_file_nominal_layout_count(const NvmFileNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_layout(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_type(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_source(const NvmFileNominalPlan *,uint8_t,uint32_t,NvmFileNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_import(const NvmFileNominalPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 2
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
typedef enum {
    NVM_FILE_FLOW_OK, NVM_FILE_FLOW_INVALID, NVM_FILE_FLOW_UNRESOLVED,
    NVM_FILE_FLOW_LIMIT, NVM_FILE_FLOW_MEMORY
} NvmFileFlowStatus;
typedef struct NvmFileFlowDeclarations NvmFileFlowDeclarations;
typedef struct NvmFileFlowState NvmFileFlowState;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_index, catalog_ordinal;
    NvmFileCategory category;
} NvmFileFlowDeclaration;
typedef struct {
    uint16_t parameters, locals;
    uint8_t result_count;
    NvmFileFlowDeclaration result;
} NvmFileFlowFunction;
typedef enum {
    NVM_FILE_FLOW_ARM_NONE, NVM_FILE_FLOW_ARM_UNKNOWN,
    NVM_FILE_FLOW_ARM_OK, NVM_FILE_FLOW_ARM_ERROR
} NvmFileFlowArm;
typedef struct {
    NvmFileFlowDeclaration type;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        initialized;
    uint64_t owner;
    NvmFileFlowArm arm;
} NvmFileFlowValue;
typedef struct {
    
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        live, formal;
    uint16_t local;
    uint64_t owner, identity, region;
    
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        shared;
} NvmFileFlowReference;
typedef struct {
    uint16_t stack, regions, owners, references;
    uint64_t cleanup_obligations;
    uint16_t obligations;
    
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        reachable;
} NvmFileFlowCounts;



typedef enum { NVM_FILE_FLOW_SERVICE, NVM_FILE_FLOW_CALL } NvmFileFlowObligationKind;
typedef enum { NVM_FILE_FLOW_INPUT_NONE, NVM_FILE_FLOW_INPUT_PRESERVED,
               NVM_FILE_FLOW_INPUT_CONSUMED } NvmFileFlowInputState;
enum {
    NVM_FILE_FLOW_CHECK_BINDING=1u, NVM_FILE_FLOW_CHECK_INVOCATION=2u,
    NVM_FILE_FLOW_CHECK_LIVENESS=4u, NVM_FILE_FLOW_CHECK_RIGHTS=8u,
    NVM_FILE_FLOW_CHECK_BORROW=16u, NVM_FILE_FLOW_CHECK_BYTE=32u,
    NVM_FILE_FLOW_CHECK_CALLEE=64u, NVM_FILE_FLOW_CHECK_CLEANUP=128u,
    NVM_FILE_FLOW_CHECK_RESULT=256u
};
typedef struct {
    NvmFileFlowObligationKind kind;
    uint32_t site, target, checks, required_rights, acquired_rights;
    uint16_t parameters, owned_inputs, borrowed_inputs;
    uint8_t result_count;
    NvmFileFlowDeclaration result;
    NvmFileFlowInputState outcomes[2];
} NvmFileFlowObligation;




NvmFileFlowStatus nvm_file_flow_declarations(const NvmModule *, NvmFileFlowDeclarations **out);
void nvm_file_flow_declarations_free(NvmFileFlowDeclarations *);

# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_function(const NvmFileFlowDeclarations *, uint32_t, NvmFileFlowFunction *);

# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_declaration(const NvmFileFlowDeclarations *, uint32_t, uint16_t,
                             NvmFileFlowDeclaration *);


NvmFileFlowStatus nvm_file_flow_state(NvmFileFlowDeclarations *, uint32_t, NvmFileFlowState **out);
void nvm_file_flow_state_free(NvmFileFlowState *);

# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_local(const NvmFileFlowState *, uint16_t, NvmFileFlowValue *);

# 91 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_stack(const NvmFileFlowState *, uint16_t, NvmFileFlowValue *);

# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_reference(const NvmFileFlowState *, uint16_t, NvmFileFlowReference *);

# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_counts(const NvmFileFlowState *, NvmFileFlowCounts *);

# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_obligation(const NvmFileFlowState *, uint16_t, NvmFileFlowObligation *);
NvmFileFlowStatus nvm_file_flow_clone(const NvmFileFlowState *, NvmFileFlowState **out);

NvmFileFlowStatus nvm_file_flow_refine(const NvmFileFlowState *, uint16_t local,
                                     NvmFileFlowState **ok, NvmFileFlowState **error);
NvmFileFlowStatus nvm_file_flow_join(NvmFileFlowState *, const NvmFileFlowState *, 
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
                                                                                  _Bool 
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
                                                                                       *changed);



NvmFileFlowStatus nvm_file_flow_push_scalar(NvmFileFlowState *, uint8_t);
NvmFileFlowStatus nvm_file_flow_load(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_store(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_dup(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_pop(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_clear_copy(NvmFileFlowState *, uint16_t);


NvmFileFlowStatus nvm_file_flow_construct(NvmFileFlowState *, uint32_t catalog, uint16_t variant);
NvmFileFlowStatus nvm_file_flow_field(NvmFileFlowState *, uint16_t field);
NvmFileFlowStatus nvm_file_flow_take_result(NvmFileFlowState *, uint16_t local, NvmFileFlowArm);


NvmFileFlowStatus nvm_file_flow_service(NvmFileFlowState *, uint32_t site, uint32_t import,
                                      uint16_t reference);




NvmFileFlowStatus nvm_file_flow_call(NvmFileFlowState *, uint32_t site, uint32_t function,
                                   const uint16_t *references, uint16_t count);
NvmFileFlowStatus nvm_file_flow_move(NvmFileFlowState *, uint16_t from, uint16_t to);
NvmFileFlowStatus nvm_file_flow_take(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_put(NvmFileFlowState *, uint16_t);

NvmFileFlowStatus nvm_file_flow_drop_local(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_drop_stack(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_region_begin(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_region_end(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_borrow(NvmFileFlowState *, uint16_t local, uint16_t reference);
NvmFileFlowStatus nvm_file_flow_borrow_shared(NvmFileFlowState *,uint16_t local,uint16_t reference);
NvmFileFlowStatus nvm_file_flow_end_borrow(NvmFileFlowState *, uint16_t reference);



NvmFileFlowStatus nvm_file_flow_can_exit(const NvmFileFlowState *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
typedef struct NvmFileCodePlan NvmFileCodePlan;
typedef struct {
    uint32_t byte_offset;
    DecodedInstruction decoded;
    uint16_t successors[2];
    uint8_t successor_count;
    uint16_t call_references[256u];
    uint32_t catalog_ordinal;
} NvmFileCodeInstruction;
typedef struct {
    uint32_t code_offset, code_length;
    uint16_t instruction_count;
    NvmFileFlowFunction declaration;
} NvmFileCodeFunction;
NvmFileFlowStatus nvm_file_code_prepare(const NvmModule *, NvmFileCodePlan **out);
void nvm_file_code_free(NvmFileCodePlan *);
uint32_t nvm_file_code_function_count(const NvmFileCodePlan *);


# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_function(const NvmFileCodePlan *, uint32_t, NvmFileCodeFunction *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_local(const NvmFileCodePlan *, uint32_t, uint16_t,
                         NvmFileFlowDeclaration *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_instruction(const NvmFileCodePlan *, uint32_t, uint16_t,
                               NvmFileCodeInstruction *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_instruction_order(const NvmFileCodePlan *, uint32_t, uint16_t,
                                     uint16_t *);


# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_function_order(const NvmFileCodePlan *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 2




typedef struct NvmFileBodyReport NvmFileBodyReport;
typedef enum {
    NVM_FILE_BODY_CLEANUP_NORMAL, NVM_FILE_BODY_CLEANUP_DROP_LOCAL,
    NVM_FILE_BODY_CLEANUP_DROP_STACK, NVM_FILE_BODY_CLEANUP_ASSERT,
    NVM_FILE_BODY_CLEANUP_RETURN, NVM_FILE_BODY_CLEANUP_CALL,
    NVM_FILE_BODY_CLEANUP_SERVICE
} NvmFileBodyCleanup;
typedef struct {
    
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
        reachable, exit_checked, refinement, has_obligation;
    uint16_t input_stack, output_stack, cleanup_local;
    NvmFileBodyCleanup cleanup;
    uint32_t discharged_checks, pending_checks;
    NvmFileFlowObligation obligation;
} NvmFileBodyInstruction;
NvmFileFlowStatus nvm_file_body_analyze(const NvmModule *, NvmFileBodyReport **out);
void nvm_file_body_free(NvmFileBodyReport *);
uint32_t nvm_file_body_function_count(const NvmFileBodyReport *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_function(const NvmFileBodyReport *, uint32_t, NvmFileCodeFunction *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_local(const NvmFileBodyReport *, uint32_t, uint16_t, NvmFileFlowDeclaration *);

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_instruction(const NvmFileBodyReport *, uint32_t, uint16_t,
                              NvmFileCodeInstruction *, NvmFileBodyInstruction *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
typedef struct NvmFileCyclicReport NvmFileCyclicReport;
typedef struct {
    uint32_t revision, functions, instructions, variants, transfers, edges;
    size_t storage_peak;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
        runtime_admitted;
} NvmFileCyclicSummary;
typedef struct {
    uint16_t locals, stack, regions, owners, references;
} NvmFileCyclicStateInfo;
typedef struct {
    NvmFileCyclicStateInfo input, output;
    NvmFileBodyInstruction body;
    uint8_t edge_mask, edge_variants[2];


} NvmFileCyclicVariant;
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
NvmFileFlowStatus nvm_file_cyclic_analyze(const NvmModule *, NvmFileCyclicReport **);
void nvm_file_cyclic_free(NvmFileCyclicReport *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_summary(const NvmFileCyclicReport *, NvmFileCyclicSummary *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_function(const NvmFileCyclicReport *, uint32_t, NvmFileCodeFunction *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_local(const NvmFileCyclicReport *, uint32_t, uint16_t, NvmFileFlowDeclaration *);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_instruction(const NvmFileCyclicReport *, uint32_t, uint16_t, NvmFileCodeInstruction *);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_component(const NvmFileCyclicReport *, uint32_t, uint16_t, uint16_t *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_variant_count(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t *);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_variant(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, NvmFileCyclicVariant *);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_local(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowValue *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_stack(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowValue *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_reference(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowReference *);

# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_region(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, uint64_t *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_type(const NvmFileCyclicReport *, uint32_t, NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_import(const NvmFileCyclicReport *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 1





typedef struct NvmFileHostedPlan NvmFileHostedPlan;
typedef struct {
    uint32_t entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t allocation_bound;
} NvmFileHostedStartup;
typedef struct {
    NvmFileCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
} NvmFileHostedFunction;






NvmFileFlowStatus nvm_file_hosted_prepare(const uint8_t *,size_t,NvmFileHostedPlan **);
void nvm_file_hosted_free(NvmFileHostedPlan *);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_startup(const NvmFileHostedPlan *,NvmFileHostedStartup *);

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_function(const NvmFileHostedPlan *,uint32_t,NvmFileHostedFunction *);

# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_local(const NvmFileHostedPlan *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_instruction(const NvmFileHostedPlan *,uint32_t,uint16_t,
                                NvmFileCodeInstruction *,NvmFileBodyInstruction *);


# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_type(const NvmFileHostedPlan *,uint32_t,NvmFileNominalLayout *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_import(const NvmFileHostedPlan *,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 2







typedef struct NvmFileCyclicHostedPlan NvmFileCyclicHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
        runtime_admitted;
} NvmFileCyclicHostedStartup;
typedef struct {
    NvmFileCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmFileCyclicHostedFunction;




NvmFileFlowStatus nvm_file_cyclic_hosted_prepare(const uint8_t *,size_t,NvmFileCyclicHostedPlan **);
void nvm_file_cyclic_hosted_free(NvmFileCyclicHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_query_summary(const NvmFileCyclicHostedPlan *,NvmFileCyclicSummary *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_startup(const NvmFileCyclicHostedPlan *,NvmFileCyclicHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_function(const NvmFileCyclicHostedPlan *,uint32_t,NvmFileCyclicHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_function_order(const NvmFileCyclicHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_local(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_instruction(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,NvmFileCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_component(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_variant_count(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_variant(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,NvmFileCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_local(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_stack(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_reference(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_region(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_type(const NvmFileCyclicHostedPlan *,uint32_t,NvmFileNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_import(const NvmFileCyclicHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_bytes(const NvmFileCyclicHostedPlan *,size_t,void *,size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_cap.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_cap.h" 2
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_cap.h"
typedef enum {
    NL_CAP_AUDIT_CREATE = 0,
    NL_CAP_AUDIT_DELEGATE,
    NL_CAP_AUDIT_USE,
    NL_CAP_AUDIT_REVOKE,
    NL_CAP_AUDIT_FAIL,
    NL_CAP_AUDIT_TRANSFER,
    NL_CAP_AUDIT_RESTART
} NlCapAuditKind;

typedef struct {
    uint64_t secret;
    uint32_t slot;
    uint32_t generation;
} NlCap;

typedef struct NlCapTable NlCapTable;

NlCapTable *nl_cap_table_create(void);
void nl_cap_table_destroy(NlCapTable *t);

int nl_cap_mint(NlCapTable *t, const char *type_id, const char *service_id,
                uint32_t rights, int transferable, const char *scope, NlCap *out);
int nl_cap_check(NlCapTable *t, const NlCap *c, uint32_t need);
int nl_cap_attenuate(NlCapTable *t, const NlCap *parent, uint32_t rights, NlCap *out);
int nl_cap_transfer(NlCapTable *t, const NlCap *src, NlCap *out);
int nl_cap_revoke(NlCapTable *t, const NlCap *c);
int nl_cap_restart(NlCapTable *t);
int nl_cap_invalidate_service(NlCapTable *t, const char *service_id);

int nl_cap_from_integer(NlCapTable *t, uint64_t n, NlCap *out);
int nl_cap_from_pointer(NlCapTable *t, void *p, NlCap *out);

int nl_cap_resource_own(NlCapTable *t, const char *nsi_type_id,
                        const char *service_id, uint32_t rights, NlCap *out);
int nl_cap_resource_consume(NlCapTable *t, const NlCap *c);

int nl_cap_forth_bind(NlCapTable *t, const NlCap *c, uint64_t *cell);
int nl_cap_forth_lookup(NlCapTable *t, uint64_t cell, NlCap *out);

uint32_t nl_cap_rights(NlCapTable *t, const NlCap *c);
uint32_t nl_cap_generation(NlCapTable *t, const NlCap *c);
const char *nl_cap_type_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_service_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_scope(NlCapTable *t, const NlCap *c);
int nl_cap_revoked(NlCapTable *t, const NlCap *c);
int nl_cap_transferable(NlCapTable *t, const NlCap *c);

int nl_cap_audit_count(const NlCapTable *t);
int nl_cap_audit_kind(const NlCapTable *t, int i);
const char *nl_cap_audit_id(const NlCapTable *t, int i);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 2




typedef struct NlFileService NlFileService;


# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h"
    nl_file_service_storage_bound(size_t *out);

typedef struct {
    uint64_t context_id;
    NlCap cap;
} NlFileToken;

typedef enum {
    NL_FILE_OK = 0,
    NL_FILE_ARGUMENT,
    NL_FILE_DISPOSED,
    NL_FILE_TOKEN,
    NL_FILE_RIGHTS,
    NL_FILE_CAPACITY,
    NL_FILE_LIMIT,
    NL_FILE_MEMORY,
    NL_FILE_IO,
    NL_FILE_DIRECTION
} NlFileStatus;

typedef struct {
    NlFileStatus status;
    int host_errno;
    int cleanup_errno;
    size_t bytes;
    
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h"
        eof;
    
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h"
        consumed;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file.h"
        cleanup_failed;
} NlFileResult;


NlFileResult nl_file_service_create(NlFileService **out);
NlFileResult nl_file_acquire_temp(NlFileService *, uint32_t rights, NlFileToken *out);



NlFileResult nl_file_read(NlFileService *, const NlFileToken *, void *, size_t);
NlFileResult nl_file_write(NlFileService *, const NlFileToken *, const void *, size_t);
NlFileResult nl_file_rewind(NlFileService *, const NlFileToken *);


NlFileResult nl_file_transfer(NlFileService *, const NlFileToken *, NlFileToken *out);

NlFileResult nl_file_consume_close(NlFileService *, const NlFileToken *);



NlFileResult nl_file_service_dispose(NlFileService *);
NlFileResult nl_file_service_destroy(NlFileService *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 2





typedef struct NlFileValues NlFileValues;


# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
_Bool 
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
    nl_file_values_storage_bound(size_t *out);



typedef enum {
    NL_FILE_VALUE_OK, NL_FILE_VALUE_ARGUMENT, NL_FILE_VALUE_STALE,
    NL_FILE_VALUE_TYPE, NL_FILE_VALUE_BORROWED, NL_FILE_VALUE_LIMIT,
    NL_FILE_VALUE_MEMORY, NL_FILE_VALUE_DISPOSED, NL_FILE_VALUE_STATE,
    NL_FILE_VALUE_STATUS_COUNT
} NlFileValueStatus;


typedef struct { uint64_t invocation, generation; uint32_t slot; } NlFileValue;
typedef struct { NlFileValue value; uint64_t epoch; } NlFileValueBorrow;
typedef struct { 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
                _Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
                     ok; NlFileResult error; } NlFileOpenView;
typedef enum {
    NL_FILE_VALUE_WRITE, NL_FILE_VALUE_POSITION, NL_FILE_VALUE_READ,
    NL_FILE_VALUE_CLOSE
} NlFileScalarKind;
typedef struct {
    NlFileScalarKind kind;
    
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
        ok;
    NlFileResult detail;
    int64_t value;
    
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
   _Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
        eof;
} NlFileScalarResult;
typedef struct {
    NlFileValueStatus execution;
    uint64_t cleanup_failures;
    NlFileResult first_cleanup, next_cleanup;
} NlFileValuesFinish;


NlFileValueStatus nl_file_values_create(NlFileValues **out);


NlFileValueStatus nl_file_values_temp(NlFileValues *, NlFileValue *out);


NlFileValueStatus nl_file_value_move(NlFileValues *, NlFileValue *source, NlFileValue *out);
NlFileValueStatus nl_file_open_view(NlFileValues *, const NlFileValue *, NlFileOpenView *out);
NlFileValueStatus nl_file_open_take_ok(NlFileValues *, NlFileValue *, NlFileValue *out);

NlFileValueStatus nl_file_open_take_error(NlFileValues *, NlFileValue *, NlFileResult *out);
NlFileValueStatus nl_file_value_borrow(NlFileValues *, const NlFileValue *, NlFileValueBorrow *out);
NlFileValueStatus nl_file_value_end_borrow(NlFileValues *, NlFileValueBorrow *);


NlFileValueStatus nl_file_value_write_byte(NlFileValues *, const NlFileValueBorrow *, int64_t, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_rewind(NlFileValues *, const NlFileValueBorrow *, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_read_byte(NlFileValues *, const NlFileValueBorrow *, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_close(NlFileValues *, NlFileValue *, NlFileScalarResult *out);


NlFileValueStatus nl_file_value_drop(NlFileValues *, NlFileValue *);






# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
    nl_file_values_report(const NlFileValues *, NlFileValuesFinish *out);
NlFileValuesFinish nl_file_values_finish(NlFileValues *, NlFileValueStatus first_execution_error);
NlFileValuesFinish nl_file_values_destroy(NlFileValues *, NlFileValueStatus first_execution_error);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
typedef enum { NVM_FILE_RUNTIME_VM, NVM_FILE_RUNTIME_NATIVE } NvmFileRuntimeMode;
typedef enum {
    NVM_FILE_RUNTIME_OK, NVM_FILE_RUNTIME_INVALID, NVM_FILE_RUNTIME_UNRESOLVED,
    NVM_FILE_RUNTIME_LIMIT, NVM_FILE_RUNTIME_MEMORY, NVM_FILE_RUNTIME_STATE,
    NVM_FILE_RUNTIME_TYPE, NVM_FILE_RUNTIME_STALE, NVM_FILE_RUNTIME_BORROWED,
    NVM_FILE_RUNTIME_ASSERT, NVM_FILE_RUNTIME_CLEANUP, NVM_FILE_RUNTIME_BUSY
} NvmFileRuntimeStatus;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
        initialized, owning, formal;
    NvmFileFlowDeclaration type;
    NvmFileFlowArm arm;
    uint8_t fields;
    int64_t values[7u];
} NvmFileRuntimeView;
typedef struct {
    NvmFileRuntimeStatus status;
    
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
   _Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
        acquired;
    NlFileValueStatus core_status;
    uint32_t function, instruction;
    NlFileValuesFinish cleanup;
} NvmFileRuntimeReport;
typedef struct {
    size_t allocation_bound;
    uint32_t values, references, regions;
    uint16_t frames;
} NvmFileRuntimeStorage;
typedef struct NvmFileRuntime NvmFileRuntime;


NvmFileRuntimeStatus nvm_file_runtime_create(const uint8_t *,size_t,NvmFileRuntimeMode,NvmFileRuntime **out);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
    nvm_file_runtime_storage(const NvmFileRuntime *,NvmFileRuntimeStorage *);
const NvmFileHostedPlan *nvm_file_runtime_plan(const NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_begin(NvmFileRuntime *);


NvmFileRuntimeStatus nvm_file_runtime_site(NvmFileRuntime *,uint32_t function,uint16_t instruction);
NvmFileRuntimeStatus nvm_file_runtime_fail(NvmFileRuntime *,NvmFileRuntimeStatus);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
    nvm_file_runtime_current_root(const NvmFileRuntime *,uint32_t *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
    nvm_file_runtime_view(const NvmFileRuntime *,uint32_t,NvmFileRuntimeView *);

NvmFileRuntimeStatus nvm_file_runtime_scalar(NvmFileRuntime *,uint32_t,uint8_t,int64_t);




NvmFileRuntimeStatus nvm_file_runtime_string(NvmFileRuntime *,uint32_t,const void *,size_t);
NvmFileRuntimeStatus nvm_file_runtime_string_literal(NvmFileRuntime *,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_string_operation(NvmFileRuntime *,uint8_t,uint32_t,uint32_t,uint32_t);

# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime.h"
    nvm_file_runtime_string_read(const NvmFileRuntime *,uint32_t,void *,size_t,size_t *);
NvmFileRuntimeStatus nvm_file_runtime_copy(NvmFileRuntime *,uint32_t,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_move(NvmFileRuntime *,uint32_t,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_drop(NvmFileRuntime *,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_construct(NvmFileRuntime *,uint32_t ordinal,uint16_t variant,const uint32_t *,size_t,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_project(NvmFileRuntime *,uint32_t,uint16_t,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_result_arm(NvmFileRuntime *,uint32_t,NvmFileFlowArm *);
NvmFileRuntimeStatus nvm_file_runtime_take(NvmFileRuntime *,uint32_t,NvmFileFlowArm,uint32_t);
NvmFileRuntimeStatus nvm_file_runtime_region_begin(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_region_end(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_borrow(NvmFileRuntime *,uint32_t owner,uint32_t reference);
NvmFileRuntimeStatus nvm_file_runtime_borrow_shared(NvmFileRuntime *,uint32_t owner,uint32_t reference);
NvmFileRuntimeStatus nvm_file_runtime_bind_formal(NvmFileRuntime *,uint32_t source_reference,uint32_t formal_root,uint32_t formal_reference);
NvmFileRuntimeStatus nvm_file_runtime_end_reference(NvmFileRuntime *,uint32_t);



NvmFileRuntimeStatus nvm_file_runtime_service(NvmFileRuntime *,uint32_t import,uint32_t reference,uint32_t input,uint32_t output);


NvmFileRuntimeStatus nvm_file_runtime_complete_root(NvmFileRuntime *,uint32_t result);



NvmFileRuntimeReport nvm_file_runtime_finish(NvmFileRuntime *,NvmFileRuntimeView *);
NvmFileRuntimeReport nvm_file_runtime_destroy(NvmFileRuntime **,NvmFileRuntimeView *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 2






typedef struct {
    NvmFileRuntimeMode mode;
    uint32_t function, instruction, byte_offset;
    uint16_t depth, locals, staging_slots, operand_peak;
    uint32_t locals_base, staging_base, stack_base, stack_count;
    uint32_t reference_base, region_floor;
} NvmFileRuntimeFrameView;

NvmFileRuntimeStatus nvm_file_runtime_frame_start(NvmFileRuntime *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_view(const NvmFileRuntime *,NvmFileRuntimeFrameView *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_local(const NvmFileRuntime *,uint16_t,uint32_t *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_operand(const NvmFileRuntime *,uint16_t,uint32_t *);


# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_reserve(const NvmFileRuntime *,uint16_t,uint32_t *);


# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_scratch(const NvmFileRuntime *,uint32_t *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_runtime_frames.h"
    nvm_file_runtime_frame_reference(const NvmFileRuntime *,uint16_t,uint32_t *);


NvmFileRuntimeStatus nvm_file_runtime_frame_store(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_frame_next(NvmFileRuntime *,uint8_t successor);
NvmFileRuntimeStatus nvm_file_runtime_frame_call(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_frame_return(NvmFileRuntime *);


NvmFileRuntimeStatus nvm_file_runtime_frame_region_begin(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_frame_region_end(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_frame_borrow(NvmFileRuntime *);
NvmFileRuntimeStatus nvm_file_runtime_frame_end_reference(NvmFileRuntime *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_report.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_report.h"
typedef struct { uint32_t revision; uint64_t instruction_limit; } NvmFileCyclicOptions;
typedef struct {
    uint32_t revision;
    NvmFileRuntimeReport runtime;
    uint64_t instruction_limit, instructions_started;
    
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_report.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_report.h"
        fuel_exhausted;
} NvmFileCyclicExecutionReport;
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 2


typedef struct {
    uint32_t revision;
    NvmFileRuntimeFrameView frame;
    uint8_t variant;
    
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h"
        instruction_open;
} NvmFileCyclicFrameView;
NvmFileRuntimeStatus nvm_file_runtime_cyclic_create(const uint8_t *,size_t,
    NvmFileRuntimeMode,const NvmFileCyclicOptions *,NvmFileRuntime **);

const NvmFileCyclicHostedPlan *nvm_file_runtime_cyclic_plan(const NvmFileRuntime *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h"
    nvm_file_runtime_cyclic_frame_view(const NvmFileRuntime *,NvmFileCyclicFrameView *);

NvmFileRuntimeStatus nvm_file_runtime_cyclic_enter(NvmFileRuntime *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h"
    nvm_file_runtime_cyclic_report(const NvmFileRuntime *,NvmFileCyclicExecutionReport *);
NvmFileCyclicExecutionReport nvm_file_runtime_cyclic_finish(NvmFileRuntime *,NvmFileRuntimeView *);
NvmFileCyclicExecutionReport nvm_file_runtime_cyclic_destroy(NvmFileRuntime **,NvmFileRuntimeView *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h"
    nvm_file_runtime_cyclic_abi(uint32_t,size_t,size_t,size_t,size_t);


# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_runtime.h"
    nvm_file_runtime_cyclic_native_abi(uint32_t,size_t,size_t,size_t,size_t,size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_abi.h" 2
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_public.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant.h"
typedef struct NvmFileHostGrant NvmFileHostGrant;
typedef enum {
    NVM_FILE_HOST_OK = 0,
    NVM_FILE_HOST_INVALID = 1,
    NVM_FILE_HOST_MEMORY = 2,
    NVM_FILE_HOST_STATE = 3,
    NVM_FILE_HOST_UNRESOLVED = 4,
    NVM_FILE_HOST_BUSY = 5
} NvmFileHostStatus;







NvmFileHostStatus nvm_file_host_grant_create_temporary_files(NvmFileHostGrant **out);

NvmFileHostStatus nvm_file_host_grant_revoke(NvmFileHostGrant *grant);


NvmFileHostStatus nvm_file_host_grant_destroy(NvmFileHostGrant **inout);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_public.h" 2




typedef struct { uint8_t tag; int64_t value; } NvmFileScalar;



NvmFileRuntimeReport nvm_file_execute_bytes(NvmFileHostGrant *,
    const uint8_t *, size_t, NvmFileScalar *out);




NvmFileRuntimeStatus nvm2c_emit_file_bytes(const uint8_t *, size_t,
    const char *entry_identifier, char **out, char *diagnostic, size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public.h" 2







NvmFileCyclicExecutionReport nvm_file_execute_cyclic_bytes(NvmFileHostGrant *,
    const uint8_t *, size_t, const NvmFileCyclicOptions *, NvmFileScalar *);


NvmFileRuntimeStatus nvm2c_emit_file_cyclic_bytes(const uint8_t *, size_t,
    const char *entry_identifier, char **out, char *diagnostic, size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_internal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_public_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant_internal.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant_internal.h"
NvmFileHostStatus nvm_file_host_enter_query(void);
NvmFileHostStatus nvm_file_host_enter(const NvmFileHostGrant *grant,
                                    unsigned abi, unsigned catalog);
void nvm_file_host_leave(void);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_public_internal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_public_internal.h" 2


static inline NvmFileRuntimeStatus nvm_file_public_grant_status(NvmFileHostStatus s) {
    switch (s) {
    case NVM_FILE_HOST_OK: return NVM_FILE_RUNTIME_OK;
    case NVM_FILE_HOST_INVALID: return NVM_FILE_RUNTIME_INVALID;
    case NVM_FILE_HOST_MEMORY: return NVM_FILE_RUNTIME_MEMORY;
    case NVM_FILE_HOST_STATE: return NVM_FILE_RUNTIME_STATE;
    case NVM_FILE_HOST_BUSY: return NVM_FILE_RUNTIME_BUSY;
    default: return NVM_FILE_RUNTIME_UNRESOLVED;
    }
}
static inline NvmFileRuntimeReport nvm_file_public_refused(NvmFileRuntimeStatus s) {
    NvmFileRuntimeReport r = {0};
    r.status = s;
    r.function = r.instruction = 0xFFFFFFFFu;
    return r;
}


static inline NvmFileRuntimeReport nvm_file_public_publish(NvmFileRuntimeReport r,
    const NvmFileRuntimeView *view, NvmFileScalar *out) {
    if (r.status != NVM_FILE_RUNTIME_OK) return r;
    if (!r.acquired) { r.status = NVM_FILE_RUNTIME_STATE; return r; }
    if (r.core_status != NL_FILE_VALUE_OK || r.cleanup.execution != NL_FILE_VALUE_OK ||
        r.cleanup.cleanup_failures) { r.status = NVM_FILE_RUNTIME_CLEANUP; return r; }
    if (!out || !view->initialized || view->owning || view->formal ||
        view->type.mode || view->type.category != NVM_FILE_CATEGORY_UNKNOWN ||
        view->type.global_index != 0xFFFFFFFFu ||
        view->type.catalog_ordinal != 0xFFFFFFFFu || view->fields != 1 ||
        (view->type.tag != TAG_INT && view->type.tag != TAG_BOOL) ||
        (view->type.tag == TAG_BOOL && view->values[0] != 0 && view->values[0] != 1)) {
        r.status = NVM_FILE_RUNTIME_TYPE;
        return r;
    }
    NvmFileScalar scalar = {view->type.tag, view->values[0]};
    *out = scalar;
    return r;
}
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_internal.h" 2

static inline NvmFileCyclicExecutionReport nvm_file_cyclic_public_refused(
    NvmFileRuntimeStatus status, const NvmFileCyclicOptions *options) {
    NvmFileCyclicExecutionReport report = {0};
    report.revision = 1u;
    report.instruction_limit = options ? options->instruction_limit : 0;
    report.runtime = nvm_file_public_refused(status);
    return report;
}
static inline 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_internal.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_internal.h"
                  nvm_file_cyclic_public_options(const NvmFileCyclicOptions *options) {
    return options && options->revision == 1u &&
        options->instruction_limit <= 1000000UL;
}
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_public.h" 2





# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_public.h" 3 4
_Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_public.h"
    nvm_file_runtime_cyclic_public_abi(uint32_t, size_t, size_t, size_t);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 1

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 2



typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 2


const char *nl_file_catalog_interface(void);
const NlFilePlanMethod *nl_file_catalog_method(size_t);
const NlFilePlanType *nl_file_catalog_type(size_t);
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2
# 1 "/usr/include/inttypes.h" 1 3 4
# 34 "/usr/include/inttypes.h" 3 4

# 34 "/usr/include/inttypes.h" 3 4
typedef unsigned int __gwchar_t;
# 327 "/usr/include/inttypes.h" 3 4





typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
# 351 "/usr/include/inttypes.h" 3 4
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));





extern intmax_t strtoimax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoimax") __attribute__ ((__nothrow__ , __leaf__))

                                         ;
extern uintmax_t strtoumax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoumax") __attribute__ ((__nothrow__ , __leaf__))

                                          ;
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoimax") __attribute__ ((__nothrow__ , __leaf__))


                       ;
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoumax") __attribute__ ((__nothrow__ , __leaf__))


                        ;
# 415 "/usr/include/inttypes.h" 3 4

# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 103 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __gnuc_va_list va_list;
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;






typedef __off64_t off64_t;






typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) __attribute__ ((__warn_unused_result__));
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__));

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4




extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                          __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                         __attribute__ ((__warn_unused_result__));
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
    __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) __attribute__ ((__warn_unused_result__));






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern int __sprintf_chk (char *__restrict __s, int __flag, size_t __slen,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));
extern int __vsprintf_chk (char *__restrict __s, int __flag, size_t __slen,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));



extern int __snprintf_chk (char *__restrict __s, size_t __n, int __flag,
      size_t __slen, const char *__restrict __format,
      ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int __vsnprintf_chk (char *__restrict __s, size_t __n, int __flag,
       size_t __slen, const char *__restrict __format,
       __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));





extern int __fprintf_chk (FILE *__restrict __stream, int __flag,
     const char *__restrict __format, ...)
    __attribute__ ((__nonnull__ (1)));
extern int __printf_chk (int __flag, const char *__restrict __format, ...);
extern int __vfprintf_chk (FILE *__restrict __stream, int __flag,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nonnull__ (1)));
extern int __vprintf_chk (int __flag, const char *__restrict __format,
     __gnuc_va_list __ap);


extern int __dprintf_chk (int __fd, int __flag, const char *__restrict __fmt,
     ...) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __vdprintf_chk (int __fd, int __flag,
      const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 3, 0)));




extern int __asprintf_chk (char **__restrict __ptr, int __flag,
      const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4))) __attribute__ ((__warn_unused_result__));
extern int __vasprintf_chk (char **__restrict __ptr, int __flag,
       const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0))) __attribute__ ((__warn_unused_result__));
extern int __obstack_printf_chk (struct obstack *__restrict __obstack,
     int __flag, const char *__restrict __format,
     ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __obstack_vprintf_chk (struct obstack *__restrict __obstack,
      int __flag,
      const char *__restrict __format,
      __gnuc_va_list __args)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 96 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern char *__fgets_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets called with bigger size than length " "of destination buffer")))
                                 ;

extern char *__fgets_chk (char *__restrict __s, size_t __size, int __n,
     FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));

extern size_t __fread_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread")


            __attribute__ ((__warn_unused_result__));
extern size_t __fread_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread called with bigger size * nmemb than length " "of destination buffer")))
                                 ;

extern size_t __fread_chk (void *__restrict __ptr, size_t __ptrlen,
      size_t __size, size_t __n,
      FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));


extern char *__fgets_unlocked_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets_unlocked")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_unlocked_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_unlocked_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets_unlocked called with bigger size than length " "of destination buffer")))
                                 ;


extern char *__fgets_unlocked_chk (char *__restrict __s, size_t __size,
       int __n, FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));




extern size_t __fread_unlocked_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread_unlocked")


                     __attribute__ ((__warn_unused_result__));
extern size_t __fread_unlocked_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_unlocked_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread_unlocked called with bigger size * nmemb than " "length of destination buffer")))
                                        ;

extern size_t __fread_unlocked_chk (void *__restrict __ptr, size_t __ptrlen,
        size_t __size, size_t __n,
        FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));
# 965 "/usr/include/stdio.h" 2 3 4
# 976 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 1 3 4
# 46 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return getc (stdin);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





extern __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


extern __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




extern __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return putc (__c, stdout);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


extern __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) __ssize_t
getline (char **__lineptr, size_t *__n, FILE *__stream)
{
  return __getdelim (__lineptr, __n, '\n', __stream);
}





extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0010) != 0);
}


extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0020) != 0);
}
# 977 "/usr/include/stdio.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) sprintf (char *__restrict __s, const char *__restrict __fmt, ...)
{
  return __builtin___sprintf_chk (__s, 3 - 1,
      __builtin_dynamic_object_size (__s, 1), __fmt,
      __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsprintf (char *__restrict __s, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsprintf_chk (__s, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) snprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, ...)

{
  return __builtin___snprintf_chk (__s, __n, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt,
       __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsnprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsnprintf_chk (__s, __n, 3 - 1,
        __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
fprintf (FILE *__restrict __stream, const char *__restrict __fmt, ...)
{
  return __fprintf_chk (__stream, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
printf (const char *__restrict __fmt, ...)
{
  return __printf_chk (3 - 1, __fmt, __builtin_va_arg_pack ());
}







extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __ap)
{

  return __vfprintf_chk (stdout, 3 - 1, __fmt, __ap);



}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
vfprintf (FILE *__restrict __stream,
   const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vfprintf_chk (__stream, 3 - 1, __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
dprintf (int __fd, const char *__restrict __fmt, ...)
{
  return __dprintf_chk (__fd, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vdprintf (int __fd, const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vdprintf_chk (__fd, 3 - 1, __fmt, __ap);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)
{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) __asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)

{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_printf (struct obstack *__restrict __obstack, const char *__restrict __fmt, ...)

{
  return __obstack_printf_chk (__obstack, 3 - 1, __fmt,
          __builtin_va_arg_pack ());
}
# 165 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vasprintf (char **__restrict __ptr, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __vasprintf_chk (__ptr, 3 - 1, __fmt, __ap);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_vprintf (struct obstack *__restrict __obstack, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __obstack_vprintf_chk (__obstack, 3 - 1, __fmt,
    __ap);
}
# 194 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_chk_warn (__s, sz, __n, __stream);
  return __fgets_chk (__s, sz, __n, __stream);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread (void *__restrict __ptr, size_t __size, size_t __n,
       FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    return __fread_alias (__ptr, __size, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_chk (__ptr, sz, __size, __n, __stream);
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets_unlocked (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_unlocked_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_unlocked_chk_warn (__s, sz, __n, __stream);
  return __fgets_unlocked_chk (__s, sz, __n, __stream);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread_unlocked (void *__restrict __ptr, size_t __size, size_t __n,
  FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    {

      if (__builtin_constant_p (__size)
   && __builtin_constant_p (__n)
   && (__size | __n) < (((size_t) 1) << (8 * sizeof (size_t) / 2))
   && __size * __n <= 8)
 {
   size_t __cnt = __size * __n;
   char *__cptr = (char *) __ptr;
   if (__cnt == 0)
     return 0;

   for (; __cnt > 0; --__cnt)
     {
       int __c = getc_unlocked (__stream);
       if (__c == (-1))
  break;
       *__cptr++ = __c;
     }
   return (__cptr - (char *) __ptr) / __size;
 }

      return __fread_unlocked_alias (__ptr, __size, __n, __stream);
    }
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_unlocked_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_unlocked_chk (__ptr, sz, __size, __n, __stream);

}
# 981 "/usr/include/stdio.h" 2 3 4



# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 97 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 114 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2


# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
typedef enum { FNE_PRIVATE, FNE_PUBLIC } FileCyclicNativeSurface;


typedef struct { char *text; size_t used,capacity; NvmFileRuntimeStatus status; } Fne;
static void fn_text(Fne *b,const char *format,...) {
    if(b->status!=NVM_FILE_RUNTIME_OK)return;
    va_list ap,copy;
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                   __builtin_va_start(
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                   ap
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                   ,
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                   format
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                   )
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                      ;
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                       __builtin_va_copy(
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                       copy
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                       ,
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                       ap
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                       )
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                       ;
    int n=vsnprintf(
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                   ((void *)0)
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                       ,0,format,copy);
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                       __builtin_va_end(
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                       copy
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                       )
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                   ;
    if(n<0){b->status=NVM_FILE_RUNTIME_INVALID;
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                              __builtin_va_end(
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                              ap
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                              )
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                        ;return;}
    size_t size=(size_t)n;
    if(size>=(128u*1024u*1024u) || b->used>(128u*1024u*1024u)-size-1u) {
        b->status=NVM_FILE_RUNTIME_LIMIT;
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                        __builtin_va_end(
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                        ap
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                        )
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                  ;return;
    }
    size_t need=b->used+size+1;
    if(need>b->capacity) {
        size_t capacity=b->capacity?b->capacity:4096;
        while(capacity<need) {
            if(capacity>(128u*1024u*1024u)/2u){capacity=(128u*1024u*1024u);break;}
            capacity*=2;
        }
        char *text=realloc(b->text,capacity);
        if(!text){b->status=NVM_FILE_RUNTIME_MEMORY;
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                   __builtin_va_end(
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                   ap
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                   )
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                             ;return;}
        b->text=text;b->capacity=capacity;
    }
    int written=vsnprintf(b->text+b->used,b->capacity-b->used,format,ap);
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                        __builtin_va_end(
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                        ap
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                        )
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                                  ;
    if(written!=n){b->status=NVM_FILE_RUNTIME_INVALID;return;}
    b->used+=size;
}
static void fn_expect(Fne *b,const char *field,uint64_t value) {
    fn_text(b,"if((uint64_t)(%s)!=UINT64_C(%" 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                             "l" "u" 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                    "))return false;\n",field,value);
}

static void fn_declaration(Fne *b,const char *prefix,NvmFileFlowDeclaration d) {
    char field[96];

    do { (void)snprintf(field,sizeof field,"%s%s",prefix,"tag");fn_expect(b,field,d.tag); } while(0);do { (void)snprintf(field,sizeof field,"%s%s",prefix,"mode");fn_expect(b,field,d.mode); } while(0);do { (void)snprintf(field,sizeof field,"%s%s",prefix,"global_index");fn_expect(b,field,d.global_index); } while(0);do { (void)snprintf(field,sizeof field,"%s%s",prefix,"catalog_ordinal");fn_expect(b,field,d.catalog_ordinal); } while(0);do { (void)snprintf(field,sizeof field,"%s%s",prefix,"category");fn_expect(b,field,d.category); } while(0);

}
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 1




static 
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
      _Bool 
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
           fcd_supported(uint8_t op) {
    switch(op) {
    case OP_NOP: case OP_PUSH_I64: case OP_PUSH_BOOL: case OP_PUSH_VOID:
    case OP_DUP: case OP_POP: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL:
    case OP_REGION_BEGIN: case OP_REGION_END: case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:
    case OP_FILE_SERVICE: case OP_FILE_RESULT_BRANCH: case OP_FILE_RESULT_TAKE:
    case OP_FILE_DROP_LOCAL: case OP_FILE_DROP_STACK: case OP_FILE_END_BORROW:
    case OP_CALL: case OP_CALL_REF:case OP_FILE_CALL_REFS: case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE:
    case OP_RET: case OP_ASSERT:
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
    case OP_I64_REM_S: case OP_I64_NEG:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
    case OP_I64_GT_S: case OP_I64_GE_S: case OP_AND: case OP_OR: case OP_NOT:
    case OP_AGG_PACK: case OP_UNION_CONSTRUCT: case OP_AGG_GET: case OP_UNION_FIELD:
    case OP_AGG_TAG: case OP_UNION_TAG:return 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                             1
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                 ;
    default:return 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                  0
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                       ;
    }
}
static 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
      _Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
           fcd_fact(const NvmFileCyclicHostedPlan *p,const NvmFileCodeInstruction *in,
                     const NvmFileBodyInstruction *fact) {
    uint8_t op=in->decoded.opcode;
    if(!fcd_supported(op))return 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                0
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                     ;
    if(!fact->reachable)return 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                              1
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                  ;
    NvmFileBodyCleanup cleanup=NVM_FILE_BODY_CLEANUP_NORMAL;
    switch(op) {
    case OP_FILE_DROP_LOCAL:cleanup=NVM_FILE_BODY_CLEANUP_DROP_LOCAL;break;
    case OP_FILE_DROP_STACK:cleanup=NVM_FILE_BODY_CLEANUP_DROP_STACK;break;
    case OP_ASSERT:cleanup=NVM_FILE_BODY_CLEANUP_ASSERT;break;
    case OP_RET:cleanup=NVM_FILE_BODY_CLEANUP_RETURN;break;
    case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:cleanup=NVM_FILE_BODY_CLEANUP_CALL;break;
    case OP_FILE_SERVICE:cleanup=NVM_FILE_BODY_CLEANUP_SERVICE;break;
    default:break;
    }
    if(fact->cleanup!=cleanup || fact->refinement!=(op==OP_FILE_RESULT_BRANCH) ||
       fact->exit_checked!=(op==OP_RET))return 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                              0
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                   ;
    uint32_t checks=NVM_FILE_FLOW_CHECK_CLEANUP,discharged=0;
    
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
   _Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
        service=op==OP_FILE_SERVICE,call=op==OP_CALL || (op==OP_CALL_REF || op==OP_FILE_CALL_REFS);
    if(fact->has_obligation!=(service || call))return 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                     0
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                          ;
    if(service || call) {
        const NvmFileFlowObligation *o=&fact->obligation;
        if(o->site!=in->byte_offset || o->target!=in->decoded.operands[0].u32 ||
           o->kind!=(service?NVM_FILE_FLOW_SERVICE:NVM_FILE_FLOW_CALL))return 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                             0
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                  ;
        checks|=NVM_FILE_FLOW_CHECK_RESULT;
        if(service) {
            uint32_t original,ordinal=in->catalog_ordinal;
            if(!nvm_file_cyclic_hosted_import(p,ordinal,&original) || original!=o->target)return 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                                                0
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                                     ;
            const NlFilePlanMethod *method=nl_file_catalog_method(ordinal);
            if(!method || o->required_rights!=method->required_rights ||
               o->acquired_rights!=method->acquired_rights)return 
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                 0
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                      ;
            checks|=NVM_FILE_FLOW_CHECK_BINDING|NVM_FILE_FLOW_CHECK_INVOCATION|
                    NVM_FILE_FLOW_CHECK_LIVENESS|NVM_FILE_FLOW_CHECK_RIGHTS;
            if(ordinal>=1 && ordinal<=3)checks|=NVM_FILE_FLOW_CHECK_BORROW;
            if(ordinal==1)checks|=NVM_FILE_FLOW_CHECK_BYTE;
        } else { checks|=NVM_FILE_FLOW_CHECK_CALLEE;discharged=NVM_FILE_FLOW_CHECK_CALLEE; }
        if(o->checks!=checks)return 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                   0
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                        ;
    }
    return fact->discharged_checks==discharged && fact->pending_checks==(checks&~discharged);
}
static 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
      _Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
           fcd_coverage(const NvmFileCyclicHostedPlan *p) {
    NvmFileCyclicHostedStartup start;
    if(!nvm_file_cyclic_hosted_startup(p,&start) || start.runtime_admitted)return 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                                 0
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                      ;
    for(uint32_t f=0;f<start.functions;f++) {
        NvmFileCyclicHostedFunction fn;
        if(!nvm_file_cyclic_hosted_function(p,f,&fn) || fn.entry_variant!=0)return 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                                  0
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                       ;
        for(uint16_t i=0;i<fn.code.instruction_count;i++) {
            NvmFileCodeInstruction in;uint8_t count;
            if(!nvm_file_cyclic_hosted_instruction(p,f,i,&in) || !fcd_supported(in.decoded.opcode) || in.successor_count>2 ||
               !nvm_file_cyclic_hosted_variant_count(p,f,i,&count) ||
               count>16u || (!i && !count))return 
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                          0
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                               ;
            for(uint8_t v=0;v<count;v++) {
                NvmFileCyclicVariant fact;
                if(!nvm_file_cyclic_hosted_variant(p,f,i,v,&fact) || !fact.body.reachable ||
                   !fcd_fact(p,&in,&fact.body) || fact.body.input_stack!=fact.input.stack ||
                   fact.body.output_stack!=fact.output.stack ||
                   (fact.edge_mask & ~((1u<<in.successor_count)-1u)))return 
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                           0
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                ;
                for(uint8_t e=0;e<2;e++) {
                    if(!(fact.edge_mask&(1u<<e))) {
                        if(fact.edge_variants[e]!=
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                 (255)
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                           )return 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                                   0
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                                        ;
                    } else {
                        uint8_t destination_count;
                        if(e>=in.successor_count || in.successors[e]>=fn.code.instruction_count ||
                           !nvm_file_cyclic_hosted_variant_count(p,f,in.successors[e],&destination_count) ||
                           fact.edge_variants[e]>=destination_count)return 
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                                          0
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                                               ;
                    }
                }
                if(in.decoded.opcode==OP_CALL || (in.decoded.opcode==OP_CALL_REF || in.decoded.opcode==OP_FILE_CALL_REFS)) {
                    NvmFileCyclicHostedFunction callee;
                    if(!nvm_file_cyclic_hosted_function(p,in.decoded.operands[0].u32,&callee) ||
                       callee.entry_variant!=0)return 
# 96 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
                                                     0
# 96 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
                                                          ;
                }
            }
        }
    }
    return 
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc" 3 4
          1
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_dispatch.inc"
              ;
}
static inline NvmFileCyclicExecutionReport fcd_refused(NvmFileRuntimeStatus status,
                                               const NvmFileCyclicOptions *options) {
    NvmFileCyclicExecutionReport report={0};
    report.revision=1u;
    report.instruction_limit=options?options->instruction_limit:0;
    report.runtime.status=status;
    report.runtime.function=report.runtime.instruction=0xFFFFFFFFu;
    return report;
}
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 2

static void fn_value(Fne *b,NvmFileFlowValue value) {
    fn_declaration(b,"value.type.",value.type);
    fn_expect((b),"value." "initialized",(uint64_t)((value).initialized));fn_expect((b),"value." "owner",(uint64_t)((value).owner));
    fn_expect((b),"value." "arm",(uint64_t)((value).arm));
}
static void fn_variant(Fne *b,const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v) {
    NvmFileCyclicVariant variant;
    if(!nvm_file_cyclic_hosted_variant(p,f,i,v,&variant)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
    fn_text(b,"if(!nvm_file_cyclic_hosted_variant(p,%u,%u,%u,&variant))return false;\n",f,i,v);

    fn_expect((b),"variant." "input.locals",(uint64_t)((variant).input.locals));fn_expect((b),"variant." "input.stack",(uint64_t)((variant).input.stack));fn_expect((b),"variant." "input.regions",(uint64_t)((variant).input.regions));fn_expect((b),"variant." "input.owners",(uint64_t)((variant).input.owners));fn_expect((b),"variant." "input.references",(uint64_t)((variant).input.references));
    fn_expect((b),"variant." "output.locals",(uint64_t)((variant).output.locals));fn_expect((b),"variant." "output.stack",(uint64_t)((variant).output.stack));fn_expect((b),"variant." "output.regions",(uint64_t)((variant).output.regions));fn_expect((b),"variant." "output.owners",(uint64_t)((variant).output.owners));fn_expect((b),"variant." "output.references",(uint64_t)((variant).output.references));
    fn_expect((b),"variant." "edge_mask",(uint64_t)((variant).edge_mask));fn_expect((b),"variant." "edge_variants[0]",(uint64_t)((variant).edge_variants[0]));fn_expect((b),"variant." "edge_variants[1]",(uint64_t)((variant).edge_variants[1]));
    fn_expect((b),"variant." "body.reachable",(uint64_t)((variant).body.reachable));fn_expect((b),"variant." "body.exit_checked",(uint64_t)((variant).body.exit_checked));fn_expect((b),"variant." "body.refinement",(uint64_t)((variant).body.refinement));fn_expect((b),"variant." "body.has_obligation",(uint64_t)((variant).body.has_obligation));
    fn_expect((b),"variant." "body.input_stack",(uint64_t)((variant).body.input_stack));fn_expect((b),"variant." "body.output_stack",(uint64_t)((variant).body.output_stack));fn_expect((b),"variant." "body.cleanup_local",(uint64_t)((variant).body.cleanup_local));fn_expect((b),"variant." "body.cleanup",(uint64_t)((variant).body.cleanup));
    fn_expect((b),"variant." "body.discharged_checks",(uint64_t)((variant).body.discharged_checks));fn_expect((b),"variant." "body.pending_checks",(uint64_t)((variant).body.pending_checks));
    if(variant.body.has_obligation) {
        fn_expect((b),"variant." "body.obligation.kind",(uint64_t)((variant).body.obligation.kind));fn_expect((b),"variant." "body.obligation.site",(uint64_t)((variant).body.obligation.site));fn_expect((b),"variant." "body.obligation.target",(uint64_t)((variant).body.obligation.target));fn_expect((b),"variant." "body.obligation.checks",(uint64_t)((variant).body.obligation.checks));
        fn_expect((b),"variant." "body.obligation.required_rights",(uint64_t)((variant).body.obligation.required_rights));fn_expect((b),"variant." "body.obligation.acquired_rights",(uint64_t)((variant).body.obligation.acquired_rights));
        fn_expect((b),"variant." "body.obligation.parameters",(uint64_t)((variant).body.obligation.parameters));fn_expect((b),"variant." "body.obligation.owned_inputs",(uint64_t)((variant).body.obligation.owned_inputs));fn_expect((b),"variant." "body.obligation.borrowed_inputs",(uint64_t)((variant).body.obligation.borrowed_inputs));
        fn_expect((b),"variant." "body.obligation.result_count",(uint64_t)((variant).body.obligation.result_count));fn_expect((b),"variant." "body.obligation.outcomes[0]",(uint64_t)((variant).body.obligation.outcomes[0]));fn_expect((b),"variant." "body.obligation.outcomes[1]",(uint64_t)((variant).body.obligation.outcomes[1]));
        fn_declaration(b,"variant.body.obligation.result.",variant.body.obligation.result);
    }

    for(uint16_t n=0;n<variant.input.locals;n++) {
        NvmFileFlowValue value;
        if(!nvm_file_cyclic_hosted_input_local(p,f,i,v,n,&value)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_input_local(p,%u,%u,%u,%u,&value))return false;\n",f,i,v,n);
        fn_value(b,value);
    }
    for(uint16_t n=0;n<variant.input.stack;n++) {
        NvmFileFlowValue value;
        if(!nvm_file_cyclic_hosted_input_stack(p,f,i,v,n,&value)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_input_stack(p,%u,%u,%u,%u,&value))return false;\n",f,i,v,n);
        fn_value(b,value);
    }


    fn_text(b,"for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){\n"
        "if(!nvm_file_cyclic_hosted_input_reference(p,%u,%u,%u,n,&reference))return false;\nswitch(n){\n",f,i,v);
    for(uint16_t n=0;n<256u;n++) {
        NvmFileFlowReference reference;
        if(!nvm_file_cyclic_hosted_input_reference(p,f,i,v,n,&reference)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        if(!reference.live) {
            if(reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared) {
                b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;
            }
            continue;
        }
        fn_text(b,"case %u:\n",n);

        fn_expect((b),"reference." "live",(uint64_t)((reference).live));fn_expect((b),"reference." "formal",(uint64_t)((reference).formal));fn_expect((b),"reference." "local",(uint64_t)((reference).local));fn_expect((b),"reference." "owner",(uint64_t)((reference).owner));fn_expect((b),"reference." "identity",(uint64_t)((reference).identity));fn_expect((b),"reference." "region",(uint64_t)((reference).region));fn_expect((b),"reference." "shared",(uint64_t)((reference).shared));

        fn_text(b,"break;\n");
    }
    fn_text(b,"default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}\n");
    for(uint16_t n=0;n<variant.input.regions;n++) {
        uint64_t region;
        if(!nvm_file_cyclic_hosted_input_region(p,f,i,v,n,&region)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_input_region(p,%u,%u,%u,%u,&region) || region!=UINT64_C(%" 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                                                        "l" "u" 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                                                               "))return false;\n",f,i,v,n,region);
    }
}
static void fn_instruction_agreement(Fne *b,const NvmFileCyclicHostedPlan *p,uint32_t index,uint16_t j) {
    fn_text(b,"static bool nf_agrees_%u_%u(const NvmFileCyclicHostedPlan *p){\n"
        "NvmFileCodeInstruction in;NvmFileCyclicVariant variant;\n"
        "NvmFileFlowValue value;NvmFileFlowReference reference;\n"
        "uint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;\n"
        "(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;\n",index,j);
    NvmFileCodeInstruction in;uint8_t count;uint16_t component;
    if(!nvm_file_cyclic_hosted_instruction(p,index,j,&in) ||
       !nvm_file_cyclic_hosted_variant_count(p,index,j,&count) ||
       !nvm_file_cyclic_hosted_component(p,index,j,&component)) {b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
    fn_text(b,"if(!nvm_file_cyclic_hosted_instruction(p,%u,%u,&in) || !nvm_file_cyclic_hosted_variant_count(p,%u,%u,&count) || count!=%u || !nvm_file_cyclic_hosted_component(p,%u,%u,&component) || component!=%u)return false;\n",index,j,index,j,count,index,j,component);

    fn_expect((b),"in." "byte_offset",(uint64_t)((in).byte_offset));fn_expect((b),"in." "decoded.opcode",(uint64_t)((in).decoded.opcode));fn_expect((b),"in." "decoded.operand_count",(uint64_t)((in).decoded.operand_count));fn_expect((b),"in." "decoded.byte_length",(uint64_t)((in).decoded.byte_length));
    fn_expect((b),"in." "successor_count",(uint64_t)((in).successor_count));fn_expect((b),"in." "catalog_ordinal",(uint64_t)((in).catalog_ordinal));

    for(uint8_t k=0;k<in.successor_count;k++)fn_text(b,"if(in.successors[%u]!=%u)return false;\n",k,in.successors[k]);
    for(uint8_t k=0;k<in.decoded.operand_count;k++) {
        const char *member=
# 128 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                          ((void *)0)
# 128 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                              ;uint64_t value=0;
        switch(in.decoded.operand_types[k]) {
        case OPERAND_U8:member="u8";value=in.decoded.operands[k].u8;break;
        case OPERAND_U16:member="u16";value=in.decoded.operands[k].u16;break;
        case OPERAND_U32:member="u32";value=in.decoded.operands[k].u32;break;
        case OPERAND_I32:member="i32";value=(uint64_t)(int64_t)in.decoded.operands[k].i32;break;
        case OPERAND_I64:member="i64";value=(uint64_t)in.decoded.operands[k].i64;break;
        default:b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;
        }
        fn_text(b,"if(in.decoded.operand_types[%u]!=%u || (uint64_t)in.decoded.operands[%u].%s!=UINT64_C(%" 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                                                           "l" "u" 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                                                                  "))return false;\n",k,in.decoded.operand_types[k],k,member,value);
    }
    if(in.decoded.opcode==OP_CALL || in.decoded.opcode==OP_CALL_REF || in.decoded.opcode==OP_FILE_CALL_REFS) {
        NvmFileCyclicHostedFunction callee;
        if(!nvm_file_cyclic_hosted_function(p,in.decoded.operands[0].u32,&callee)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        for(uint16_t k=0;k<callee.code.declaration.parameters;k++)
            fn_text(b,"if(in.call_references[%u]!=%u)return false;\n",k,in.call_references[k]);
    }
    for(uint8_t v=0;v<count;v++)fn_variant(b,p,index,j,v);
    if(in.decoded.opcode==OP_FILE_SERVICE) {
        uint32_t original;
        if(!nvm_file_cyclic_hosted_import(p,in.catalog_ordinal,&original)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_import(p,%u,&ordinal) || ordinal!=%u)return false;\n",in.catalog_ordinal,original);
    }
    fn_text(b,"return true;}\n");
}
static void fn_agreement(Fne *b,const NvmFileCyclicHostedPlan *p,NvmFileCyclicHostedStartup start) {
    for(uint32_t f=0;f<start.functions;f++) {
        NvmFileCyclicHostedFunction function;
        if(!nvm_file_cyclic_hosted_function(p,f,&function)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        for(uint16_t i=0;i<function.code.instruction_count;i++)fn_instruction_agreement(b,p,f,i);
    }
    fn_text(b,"static bool nf_agrees(const NvmFileCyclicHostedPlan *p){\n"
        "NvmFileCyclicHostedStartup s;NvmFileCyclicHostedFunction f;NvmFileFlowDeclaration l;\n"
        "NvmFileNominalLayout t;uint32_t ordinal;uint8_t byte;\n"
        "(void)l;\n"
        "if(!nvm_file_cyclic_hosted_startup(p,&s))return false;\n");

    fn_expect((b),"s." "revision",(uint64_t)((start).revision));fn_expect((b),"s." "entry",(uint64_t)((start).entry));fn_expect((b),"s." "initializer",(uint64_t)((start).initializer));fn_expect((b),"s." "functions",(uint64_t)((start).functions));fn_expect((b),"s." "features",(uint64_t)((start).features));
    fn_expect((b),"s." "vm_value_slots",(uint64_t)((start).vm_value_slots));fn_expect((b),"s." "native_value_slots",(uint64_t)((start).native_value_slots));fn_expect((b),"s." "frames",(uint64_t)((start).frames));fn_expect((b),"s." "reference_slots",(uint64_t)((start).reference_slots));fn_expect((b),"s." "region_slots",(uint64_t)((start).region_slots));
    fn_expect((b),"s." "input_bytes",(uint64_t)((start).input_bytes));fn_expect((b),"s." "allocation_bound",(uint64_t)((start).allocation_bound));fn_expect((b),"s." "query_storage_peak",(uint64_t)((start).query_storage_peak));fn_expect((b),"s." "retained_bound",(uint64_t)((start).retained_bound));fn_expect((b),"s." "runtime_admitted",(uint64_t)((start).runtime_admitted));

    fn_text(b,"if(s.input_bytes!=sizeof nf_module)return false;\n"
        "for(size_t n=0;n<sizeof nf_module;n++)if(!nvm_file_cyclic_hosted_bytes(p,n,&byte,1) || byte!=nf_module[n])return false;\n");
    for(uint32_t i=0;i<8u;i++) {
        NvmFileNominalLayout t;
        if(!nvm_file_cyclic_hosted_type(p,i,&t)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_type(p,%u,&t))return false;\n",i);

        fn_expect((b),"t." "global_index",(uint64_t)((t).global_index));fn_expect((b),"t." "catalog_ordinal",(uint64_t)((t).catalog_ordinal));fn_expect((b),"t." "source_ordinal",(uint64_t)((t).source_ordinal));fn_expect((b),"t." "layout_kind",(uint64_t)((t).layout_kind));fn_expect((b),"t." "ownership_flags",(uint64_t)((t).ownership_flags));fn_expect((b),"t." "category",(uint64_t)((t).category));

    }
    for(uint32_t method=0;method<5u;method++) {
        uint32_t original;
        if(!nvm_file_cyclic_hosted_import(p,method,&original)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"if(!nvm_file_cyclic_hosted_import(p,%u,&ordinal) || ordinal!=%u)return false;\n",method,original);
    }
    for(uint32_t index=0;index<start.functions;index++) {
        NvmFileCyclicHostedFunction f;uint32_t order;
        if(!nvm_file_cyclic_hosted_function(p,index,&f) || !nvm_file_cyclic_hosted_function_order(p,index,&order)) {
            b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;
        }
        fn_text(b,"if(!nvm_file_cyclic_hosted_function_order(p,%u,&ordinal) || ordinal!=%u || !nvm_file_cyclic_hosted_function(p,%u,&f))return false;\n",index,order,index);

        fn_expect((b),"f." "code.code_offset",(uint64_t)((f).code.code_offset));fn_expect((b),"f." "code.code_length",(uint64_t)((f).code.code_length));fn_expect((b),"f." "code.instruction_count",(uint64_t)((f).code.instruction_count));
        fn_expect((b),"f." "code.declaration.parameters",(uint64_t)((f).code.declaration.parameters));fn_expect((b),"f." "code.declaration.locals",(uint64_t)((f).code.declaration.locals));fn_expect((b),"f." "code.declaration.result_count",(uint64_t)((f).code.declaration.result_count));
        fn_declaration(b,"f.code.declaration.result.",f.code.declaration.result);
        fn_expect((b),"f." "declared_stack",(uint64_t)((f).declared_stack));fn_expect((b),"f." "operand_peak",(uint64_t)((f).operand_peak));fn_expect((b),"f." "locals",(uint64_t)((f).locals));fn_expect((b),"f." "staging_slots",(uint64_t)((f).staging_slots));fn_expect((b),"f." "frames",(uint64_t)((f).frames));
        fn_expect((b),"f." "frame_owner_peak",(uint64_t)((f).frame_owner_peak));fn_expect((b),"f." "frame_reference_peak",(uint64_t)((f).frame_reference_peak));fn_expect((b),"f." "frame_region_peak",(uint64_t)((f).frame_region_peak));
        fn_expect((b),"f." "reference_slots",(uint64_t)((f).reference_slots));fn_expect((b),"f." "region_slots",(uint64_t)((f).region_slots));fn_expect((b),"f." "vm_value_slots",(uint64_t)((f).vm_value_slots));fn_expect((b),"f." "native_value_slots",(uint64_t)((f).native_value_slots));fn_expect((b),"f." "entry_variant",(uint64_t)((f).entry_variant));

        for(uint16_t j=0;j<f.locals;j++) {
            NvmFileFlowDeclaration l;
            if(!nvm_file_cyclic_hosted_local(p,index,j,&l)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
            fn_text(b,"if(!nvm_file_cyclic_hosted_local(p,%u,%u,&l))return false;\n",index,j);
            fn_declaration(b,"l.",l);
        }
        for(uint16_t j=0;j<f.code.instruction_count;j++)
            fn_text(b,"if(!nf_agrees_%u_%u(p))return false;\n",index,j);
    }
    fn_text(b,"return true;}\n");
}

static void fn_preamble(Fne *b,FileCyclicNativeSurface surface) {
    if(surface==FNE_PUBLIC) {
        fn_text(b,"%s","#include <nanolang/file/nanoisa/file_cyclic_native_public.h>\n#include <limits.h>\n#include <string.h>\n");
        fn_text(b,"%s","#if NVM_FILE_CYCLIC_PUBLIC_ABI != 1u || NVM_FILE_CYCLIC_NATIVE_ABI != 1u\n#error I require cyclic public and native ABI revision 1\n#endif\n");
    } else {
    fn_text(b,"%s","#include \"src/nanoisa/nvm2c_file_cyclic_private.h\"\n#include \"src/nanoisa/nvm_v2_sections.h\"\n#include <limits.h>\n#include <string.h>\n");
    fn_text(b,"%s","#ifndef NVM_FILE_CYCLIC_NATIVE_PRIVATE\n#error I require private cyclic File providers\n#endif\n#if NVM_FILE_CYCLIC_NATIVE_ABI != 1u\n#error I require cyclic native ABI revision 1\n#endif\n");
    }
    fn_text(b,"%s","#define NF_TRY(expr) do { NvmFileRuntimeStatus nf_status_=(expr); if(nf_status_!=NVM_FILE_RUNTIME_OK)return nf_status_; } while(0)\n");
    fn_text(b,"%s","static NvmFileRuntimeStatus nf_bad(NvmFileRuntime *c){return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_STATE);}\n");
    fn_text(b,"%s","static int64_t nf_bits(uint64_t x){int64_t y;memcpy(&y,&x,sizeof y);return y;}\n");
    fn_text(b,"%s","static bool nf_scalar(const NvmFileRuntimeView *v,uint8_t tag){\n");
    fn_text(b,"%s"," return v->initialized && !v->owning && !v->formal && !v->type.mode &&\n");
    fn_text(b,"%s"," v->type.category==NVM_FILE_CATEGORY_UNKNOWN && v->type.tag==tag &&\n");
    fn_text(b,"%s"," v->type.global_index==NVM_V2_NO_INDEX && v->type.catalog_ordinal==NVM_V2_NO_INDEX &&\n");
    fn_text(b,"%s"," v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);\n");
    fn_text(b,"%s","}\n");
    fn_text(b,"%s","static NvmFileCyclicExecutionReport nf_refused(NvmFileRuntimeStatus status,const NvmFileCyclicOptions *options){\n"
        "NvmFileCyclicExecutionReport r={0};r.revision=1u;r.instruction_limit=options?options->instruction_limit:0;\n"
        "r.runtime.status=status;r.runtime.function=r.runtime.instruction=NVM_V2_NO_INDEX;return r;}\n");
}
static void fn_numeric(Fne *b,uint8_t op) {
    
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
   _Bool 
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
        unary=op==OP_NEG || op==OP_I64_NEG || op==OP_NOT;
    
# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
   _Bool 
# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
        logic=op==OP_AND || op==OP_OR || op==OP_NOT;
    uint16_t count=unary?1:2;
    const char *expression=
# 235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                          ((void *)0)
# 235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                              ;uint8_t result=TAG_INT;
    switch(op) {
    case OP_ADD:case OP_I64_ADD:expression="nf_bits((uint64_t)a+(uint64_t)z)";break;
    case OP_SUB:case OP_I64_SUB:expression="nf_bits((uint64_t)a-(uint64_t)z)";break;
    case OP_MUL:case OP_I64_MUL:expression="nf_bits((uint64_t)a*(uint64_t)z)";break;
    case OP_DIV:case OP_I64_DIV_S:expression="!z?0:a==INT64_MIN&&z==-1?INT64_MIN:a/z";break;
    case OP_MOD:case OP_I64_REM_S:expression="!z||(a==INT64_MIN&&z==-1)?0:a%z";break;
    case OP_NEG:case OP_I64_NEG:expression="nf_bits(UINT64_C(0)-(uint64_t)a)";break;
    case OP_EQ:case OP_I64_EQ:expression="a==z";result=TAG_BOOL;break;
    case OP_NE:case OP_I64_NE:expression="a!=z";result=TAG_BOOL;break;
    case OP_LT:case OP_I64_LT_S:expression="a<z";result=TAG_BOOL;break;
    case OP_LE:case OP_I64_LE_S:expression="a<=z";result=TAG_BOOL;break;
    case OP_GT:case OP_I64_GT_S:expression="a>z";result=TAG_BOOL;break;
    case OP_GE:case OP_I64_GE_S:expression="a>=z";result=TAG_BOOL;break;
    case OP_AND:expression="a&&z";result=TAG_BOOL;break;
    case OP_OR:expression="a||z";result=TAG_BOOL;break;
    case OP_NOT:expression="!a";result=TAG_BOOL;break;
    default:b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;
    }
    fn_text(b,"if(f.stack_count<%u)return nf_bad(c);\n",count);
    for(uint16_t k=0;k<count;k++)fn_text(b,
        "if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&roots[%u]) || !nvm_file_runtime_view(c,roots[%u],&values[%u]))return nf_bad(c);\n",count-k,k,k,k);
    fn_text(b,"tag=%u;\n",logic?TAG_BOOL:TAG_INT);
    if(op==OP_EQ || op==OP_NE)fn_text(b,"if(values[0].type.tag==TAG_BOOL)tag=TAG_BOOL;\n");
    for(uint16_t k=0;k<count;k++)fn_text(b,"if(!nf_scalar(&values[%u],tag))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n",k);
    fn_text(b,"a=values[0].values[0];z=%s;r=(%s);\n",unary?"0":"values[1].values[0]",expression);
    for(uint16_t k=0;k<count;k++)fn_text(b,"NF_TRY(nvm_file_runtime_drop(c,roots[%u]));\n",k);
    fn_text(b,"NF_TRY(nvm_file_runtime_scalar(c,roots[0],%u,r));\n",result);
}
static void fn_instruction(Fne *b,uint32_t function,const NvmFileCodeInstruction *in) {
    const DecodedInstruction *d=&in->decoded;
    uint8_t op=d->opcode;
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                        _Bool 
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                             branch=
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                    0
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                         ;
    switch(op) {
    case OP_NOP:case OP_JMP:break;
    case OP_PUSH_I64:case OP_PUSH_BOOL:case OP_PUSH_VOID:
        fn_text(b,"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"
            "NF_TRY(nvm_file_runtime_scalar(c,dst,%u,nf_bits(UINT64_C(%" 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                        "l" "u" 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                               "))));\n",
            op==OP_PUSH_I64?TAG_INT:op==OP_PUSH_BOOL?TAG_BOOL:TAG_VOID,
            op==OP_PUSH_I64?(uint64_t)d->operands[0].i64:op==OP_PUSH_BOOL?(uint64_t)d->operands[0].u8:0UL);break;
    case OP_DUP:
        fn_text(b,"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"
            "NF_TRY(nvm_file_runtime_copy(c,src,dst));\n");break;
    case OP_POP:case OP_FILE_DROP_STACK:
        fn_text(b,"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n");
        if(op==OP_POP)fn_text(b,"if(value.owning || value.formal)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n");
        fn_text(b,"NF_TRY(nvm_file_runtime_drop(c,src));\n");break;
    case OP_LOAD_LOCAL:case OP_OWN_MOVE_LOCAL:
        fn_text(b,"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n"
            "if(!value.initialized || value.formal || value.owning!=%u)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"
            "NF_TRY(nvm_file_runtime_%s(c,src,dst));\n",d->operands[0].u16,op==OP_OWN_MOVE_LOCAL,op==OP_OWN_MOVE_LOCAL?"move":"copy");break;
    case OP_STORE_LOCAL:case OP_OWN_STORE_LOCAL:fn_text(b,"NF_TRY(nvm_file_runtime_frame_store(c));\n");break;
    case OP_REGION_BEGIN:fn_text(b,"NF_TRY(nvm_file_runtime_frame_region_begin(c));\n");break;
    case OP_REGION_END:fn_text(b,"NF_TRY(nvm_file_runtime_frame_region_end(c));\n");break;
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:fn_text(b,"NF_TRY(nvm_file_runtime_frame_borrow(c));\n");break;
    case OP_FILE_END_BORROW:fn_text(b,"NF_TRY(nvm_file_runtime_frame_end_reference(c));\n");break;
    case OP_FILE_DROP_LOCAL:
        fn_text(b,"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_drop(c,src));\n",d->operands[0].u16);break;
    case OP_FILE_RESULT_BRANCH:
        fn_text(b,"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nedge=arm==NVM_FILE_FLOW_ARM_ERROR;\n",d->operands[0].u16);branch=
# 293 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                                                                                                                                                    1
# 293 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                                                                                                                                                        ;break;
    case OP_FILE_RESULT_TAKE:
        fn_text(b,"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"
            "NF_TRY(nvm_file_runtime_take(c,src,%u,dst));\n",d->operands[0].u16,d->operands[1].u8?NVM_FILE_FLOW_ARM_ERROR:NVM_FILE_FLOW_ARM_OK);break;
    case OP_FILE_SERVICE: {
        uint32_t ordinal=in->catalog_ordinal;
# 298 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                            _Bool 
# 298 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                 consumes=ordinal==1 || ordinal==4;
        fn_text(b,"src=reference=NVM_FILE_RUNTIME_NO_SLOT;\nif(!nvm_file_runtime_frame_scratch(c,&dst))return nf_bad(c);\n");
        if(consumes)fn_text(b,"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return nf_bad(c);\n");
        if(ordinal>=1 && ordinal<=3)fn_text(b,"if(!nvm_file_runtime_frame_reference(c,%u,&reference))return nf_bad(c);\n",d->operands[1].u16);
        fn_text(b,"NF_TRY(nvm_file_runtime_service(c,%u,reference,src,dst));\n"
            "if(!nvm_file_runtime_frame_reserve(c,(uint16_t)(f.stack_count-%u),&output))return nf_bad(c);\n"
            "NF_TRY(nvm_file_runtime_move(c,dst,output));\n",d->operands[0].u32,consumes?1u:0u);break;
    }
    case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_ASSERT:
        fn_text(b,"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n"
            "if(!nf_scalar(&value,TAG_BOOL))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"
            "NF_TRY(nvm_file_runtime_drop(c,src));\n");
        if(op==OP_ASSERT)fn_text(b,"if(!value.values[0])return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_ASSERT);\n");
        else {fn_text(b,"edge=(value.values[0]!=0)==%u;\n",op==OP_JMP_TRUE);branch=
# 311 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                                                                  1
# 311 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                                                                      ;}
        break;
    case OP_AGG_PACK:case OP_UNION_CONSTRUCT: {
        uint16_t variant=d->operands[op==OP_AGG_PACK?2:1].u16,count=d->operands[op==OP_AGG_PACK?3:2].u16;
        if(count>7u){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        if(count)fn_text(b,"if(f.stack_count<%u)return nf_bad(c);\n",count);
        for(uint16_t k=0;k<count;k++)fn_text(b,"if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&inputs[%u]))return nf_bad(c);\n",count-k,k);
        if(count)fn_text(b,"dst=inputs[0];\n");else fn_text(b,"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n");
        fn_text(b,"NF_TRY(nvm_file_runtime_construct(c,%u,%u,inputs,%u,dst));\n",in->catalog_ordinal,variant,count);break;
    }
    case OP_AGG_GET:case OP_UNION_FIELD:case OP_AGG_TAG:case OP_UNION_TAG:
        fn_text(b,"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return nf_bad(c);\n");
        if(op==OP_AGG_GET || op==OP_UNION_FIELD)fn_text(b,"NF_TRY(nvm_file_runtime_project(c,src,%u,src));\n",d->operands[0].u16);
        else fn_text(b,"if(!nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n"
            "if(value.owning || value.formal || value.type.category!=NVM_FILE_CATEGORY_SCALAR_RESULT)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"
            "NF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nNF_TRY(nvm_file_runtime_drop(c,src));\n"
            "NF_TRY(nvm_file_runtime_scalar(c,src,TAG_INT,arm==NVM_FILE_FLOW_ARM_ERROR));\n");
        break;
    case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:
        if(in->successor_count!=1){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"NF_TRY(nvm_file_runtime_frame_call(c));\nNF_TRY(nf_function_%u(c));\ngoto nf_label_%u;\n",d->operands[0].u32,in->successors[0]);return;
    case OP_RET:fn_text(b,"return nvm_file_runtime_frame_return(c);\n");return;
    default:fn_numeric(b,op);break;
    }
    (void)function;
    if(branch) {
        if(in->successor_count!=2){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"NF_TRY(nvm_file_runtime_frame_next(c,edge));\nif(edge)goto nf_label_%u;\ngoto nf_label_%u;\n",in->successors[1],in->successors[0]);
    } else {
        if(in->successor_count!=1){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"NF_TRY(nvm_file_runtime_frame_next(c,0));\ngoto nf_label_%u;\n",in->successors[0]);
    }
}
static void fn_function(Fne *b,const NvmFileCyclicHostedPlan *p,uint32_t index) {
    NvmFileCyclicHostedFunction function;
    if(!nvm_file_cyclic_hosted_function(p,index,&function)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
    fn_text(b,"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *c){\n"
        "NvmFileCyclicFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;\n"
        "NvmFileRuntimeView value,values[2];NvmFileFlowArm arm;\n"
        "uint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];\n"
        "uint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;\n"
        "(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;\n"
        "(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;\n",index);
    for(uint16_t i=0;i<function.code.instruction_count;i++)fn_text(b,"if(0)goto nf_label_%u;\n",i);
    fn_text(b,"goto nf_label_0;\n");
    for(uint16_t i=0;i<function.code.instruction_count;i++) {
        NvmFileCodeInstruction in;uint8_t count;
        if(!nvm_file_cyclic_hosted_instruction(p,index,i,&in) ||
           !nvm_file_cyclic_hosted_variant_count(p,index,i,&count)){b->status=NVM_FILE_RUNTIME_UNRESOLVED;return;}
        fn_text(b,"nf_label_%u:\n",i);
        if(!count){fn_text(b,"return nf_bad(c);\n");continue;}
        fn_text(b,"if(!nvm_file_runtime_cyclic_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=%u || current.frame.instruction!=%u || !nvm_file_cyclic_hosted_variant(nvm_file_runtime_cyclic_plan(c),%u,%u,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);\n"
            "f=current.frame;(void)f;NF_TRY(nvm_file_runtime_cyclic_enter(c));\n",index,i,index,i);
        fn_instruction(b,index,&in);
    }
    fn_text(b,"}\n");
}
static NvmFileRuntimeStatus file_cyclic_native_emit_serialized(const uint8_t *bytes,size_t size,
    FileCyclicNativeSurface surface,const char *identifier,char **out,char *err,size_t err_size) {
    if(surface!=FNE_PRIVATE && surface!=FNE_PUBLIC)return NVM_FILE_RUNTIME_INVALID;
    if(surface==FNE_PUBLIC && !identifier)return NVM_FILE_RUNTIME_INVALID;
    if(!out || !bytes || !size || (err_size && !err))return NVM_FILE_RUNTIME_INVALID;
    NvmFileCyclicHostedPlan *plan=
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc" 3 4
                                 ((void *)0)
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_native_emit.inc"
                                     ;
    NvmFileFlowStatus prepared=nvm_file_cyclic_hosted_prepare(bytes,size,&plan);
    NvmFileRuntimeStatus result=NVM_FILE_RUNTIME_OK;
    if(prepared!=NVM_FILE_FLOW_OK) {
        result=prepared==NVM_FILE_FLOW_MEMORY?NVM_FILE_RUNTIME_MEMORY:prepared==NVM_FILE_FLOW_LIMIT?NVM_FILE_RUNTIME_LIMIT:
            prepared==NVM_FILE_FLOW_UNRESOLVED?NVM_FILE_RUNTIME_UNRESOLVED:NVM_FILE_RUNTIME_INVALID;
        if(err_size)(void)snprintf(err,err_size,"I refuse %scyclic File preparation (%u)",surface==FNE_PRIVATE?"private ":"",(unsigned)result);
        return result;
    }
    NvmFileCyclicHostedStartup startup;
    if(!nvm_file_cyclic_hosted_startup(plan,&startup) || !fcd_coverage(plan)) {
        nvm_file_cyclic_hosted_free(plan);
        if(err_size)(void)snprintf(err,err_size,"I lack complete %scyclic File instruction coverage",surface==FNE_PRIVATE?"private ":"");
        return NVM_FILE_RUNTIME_UNRESOLVED;
    }
    Fne b={0};fn_preamble(&b,surface);
    fn_text(&b,"static const uint8_t nf_module[]={\n");
    for(size_t i=0;i<size;i++)fn_text(&b,"%u,%s",bytes[i],i%24==23?"\n":"");
    fn_text(&b,"\n};\n");fn_agreement(&b,plan,startup);
    for(uint32_t f=0;f<startup.functions;f++)fn_text(&b,"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *);\n",f);
    for(uint32_t f=0;f<startup.functions;f++)fn_function(&b,plan,f);
    fn_text(&b,"%s",surface==FNE_PUBLIC?
        "static NvmFileCyclicExecutionReport nf_execute(const NvmFileCyclicOptions *options,NvmFileRuntimeView *out){\n":
        "NvmFileCyclicExecutionReport nvm_file_native_cyclic_execute(const NvmFileCyclicOptions *options,NvmFileRuntimeView *out){\n");
    fn_text(&b,
        "if(!out || !options || options->revision!=NVM_FILE_CYCLIC_RUNTIME_REVISION || options->instruction_limit>NVM_FILE_CYCLIC_FUEL_MAX)return nf_refused(NVM_FILE_RUNTIME_INVALID,options);\n"
        "if(!nvm_file_runtime_cyclic_native_abi(1u,sizeof(NvmFileCyclicOptions),sizeof(NvmFileCyclicExecutionReport),sizeof(NvmFileCyclicFrameView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)))return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);\n"
        "NvmFileRuntime *c=NULL;uint32_t root;\n"
        "NvmFileRuntimeStatus status=nvm_file_runtime_cyclic_create(nf_module,sizeof nf_module,NVM_FILE_RUNTIME_NATIVE,options,&c);\n"
        "if(status!=NVM_FILE_RUNTIME_OK)return nf_refused(status,options);\n"
        "if(!nf_agrees(nvm_file_runtime_cyclic_plan(c))){(void)nvm_file_runtime_cyclic_destroy(&c,NULL);return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);}\n"
        "status=nvm_file_runtime_begin(c);\n(void)nf_bits;(void)nf_scalar;\n");
    for(uint32_t f=0;f<startup.functions;f++)fn_text(&b,"(void)nf_function_%u;\n",f);
    if(startup.initializer!=0xFFFFFFFFu)fn_text(&b,
        "if(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\n"
        "if(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c);\n",startup.initializer);
    fn_text(&b,"if(status==NVM_FILE_RUNTIME_OK && (!nvm_file_runtime_current_root(c,&root) || root!=%u))status=nf_bad(c);\n"
        "if(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\n"
        "if(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c);\n"
        "if(status==NVM_FILE_RUNTIME_OK && nvm_file_runtime_current_root(c,&root))status=nf_bad(c);\n"
        "if(status!=NVM_FILE_RUNTIME_OK)(void)nvm_file_runtime_fail(c,status);\n"
        "return nvm_file_runtime_cyclic_destroy(&c,out);\n}\n#undef NF_TRY\n",startup.entry,startup.entry);
    if(surface==FNE_PUBLIC)fn_text(&b,
        "NvmFileCyclicExecutionReport nvm_file_cyclic_program_%s(NvmFileHostGrant *grant,const NvmFileCyclicOptions *options,NvmFileScalar *out){\n"
        "NvmFileHostStatus entered=nvm_file_host_enter(grant,NVM_FILE_HOST_ABI,NVM_FILE_HOST_CATALOG);\n"
        "if(entered!=NVM_FILE_HOST_OK)return nvm_file_cyclic_public_refused(nvm_file_public_grant_status(entered),entered==NVM_FILE_HOST_BUSY?NULL:options);\n"
        "NvmFileCyclicExecutionReport report;\n"
        "if(!nvm_file_cyclic_public_options(options) || !out)report=nvm_file_cyclic_public_refused(NVM_FILE_RUNTIME_INVALID,options);\n"
        "else {NvmFileCyclicOptions copied=*options;NvmFileRuntimeView view={0};\n"
        "if(!nvm_file_runtime_cyclic_public_abi(1u,sizeof copied,sizeof report,sizeof *out))report=nvm_file_cyclic_public_refused(NVM_FILE_RUNTIME_UNRESOLVED,&copied);\n"
        "else {report=nf_execute(&copied,&view);report.runtime=nvm_file_public_publish(report.runtime,&view,out);}}\n"
        "nvm_file_host_leave();return report;}\n",identifier);
    nvm_file_cyclic_hosted_free(plan);
    result=b.status;
    if(result!=NVM_FILE_RUNTIME_OK) {
        free(b.text);
        if(err_size)(void)snprintf(err,err_size,"I refuse %scyclic File emission (%u)",surface==FNE_PRIVATE?"private ":"",(unsigned)result);
        return result;
    }
    *out=b.text;if(err_size)err[0]='\0';return NVM_FILE_RUNTIME_OK;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 2

static 
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 3 4
      _Bool 
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
           file_public_identifier(const char *name) {
    if (!name) return 
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 3 4
                     0
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
                          ;
    for (size_t i = 0; i < 64; ++i) {
        unsigned char ch = (unsigned char)name[i];
        if (!ch) return i != 0;
        
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 3 4
       _Bool 
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
            letter = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
        if (!letter && (!i || !((ch >= '0' && ch <= '9') || ch == '_')))
            return 
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 3 4
                  0
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
                       ;
    }
    return 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c" 3 4
          0
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_public_native.c"
               ;
}

NvmFileRuntimeStatus nvm2c_emit_file_cyclic_bytes(const uint8_t *bytes, size_t size,
    const char *entry_identifier, char **out, char *diagnostic, size_t diagnostic_size) {
    NvmFileHostStatus entered = nvm_file_host_enter_query();
    if (entered != NVM_FILE_HOST_OK) return nvm_file_public_grant_status(entered);
    NvmFileRuntimeStatus status;
    if (!out || !bytes || !size || (diagnostic_size && !diagnostic) ||
        !file_public_identifier(entry_identifier)) {
        status = NVM_FILE_RUNTIME_INVALID;
        if (diagnostic && diagnostic_size)
            (void)snprintf(diagnostic, diagnostic_size, "I require exact File bytes and a valid entry identifier");
    } else status = file_cyclic_native_emit_serialized(bytes, size, FNE_PUBLIC, entry_identifier,
                                               out, diagnostic, diagnostic_size);
    nvm_file_host_leave();
    return status;
}
