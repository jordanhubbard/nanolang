/*
 * NanoVM Heap - GC-managed heap objects
 *
 * Reference counting GC. Every heap object has a VmHeapHeader prepended.
 * When ref_count reaches 0, the object is freed (with recursive release
 * of any contained references).
 */

#ifndef NANOVM_HEAP_H
#define NANOVM_HEAP_H

#include "value.h"
#include "../runtime/nl_string.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* ========================================================================
 * Heap Header (prepended to every heap object)
 * ======================================================================== */

/* Tri-colour marks for the cycle collector (Bacon-Rajan, PLDI 2001). Only
 * meaningful during a collection, except PURPLE, which persists between them
 * to mark an object sitting in the suspect buffer. */
#define VM_GC_BLACK  0u   /* in use, or already traced this pass */
#define VM_GC_GRAY   1u   /* trial deletion applied to its children */
#define VM_GC_WHITE  2u   /* provisionally garbage */
#define VM_GC_PURPLE 3u   /* suspected cycle root; on the suspect buffer */

/* How many suspects accumulate before a collection runs. Large enough that a
 * program churning short-lived aggregates does not pay for a pass per object,
 * small enough that a leak stays bounded. */
#define VM_GC_CYCLE_THRESHOLD 4096u

typedef struct VmHeapHeader {
    uint32_t ref_count;
    uint8_t  obj_type;  /* NanoValueTag */
    uint8_t  colour;    /* VM_GC_* */
    uint8_t  buffered;  /* nonzero while on the heap's suspect buffer */
} VmHeapHeader;

/* ========================================================================
 * Heap Object Types
 * ======================================================================== */

/* String: immutable, reference counted */
struct VmString {
    VmHeapHeader header;
    uint32_t length;
    uint32_t hash;       /* Cached hash for interning */
    struct VmString *intern_next; /* Chaining link within the intern bucket */
    char data[];         /* Flexible array member */
};

/* I own a length-aware payload independently of immutable, interned STRINGs. */
struct VmBString {
    VmHeapHeader header;
    nl_string_t *value;
};

/* Array: dynamic, growable.
 *
 * Homogeneous arrays of the non-reference primitive element types
 * (TAG_INT, TAG_FLOAT, TAG_BOOL, TAG_U8) are stored *unboxed*: a compact
 * typed buffer holding just the payloads (8/8/1/1 bytes per element) rather
 * than a NanoValue[] (16 bytes each, plus a per-element type tag). This
 * halves-or-better the memory footprint and removes per-element reference
 * counting for these element types. All other arrays (references, void,
 * mixed) keep the boxed NanoValue[] representation. The `unboxed` flag
 * selects between the two; callers must go through the vm_array_* accessors,
 * never touch `packed`/`elements` directly for reads or writes. */
struct VmArray {
    VmHeapHeader header;
    uint8_t  elem_type;  /* Expected element type tag */
    uint8_t  unboxed;    /* 1 => `packed` holds raw payloads, `elements` unused */
    uint32_t length;
    uint32_t capacity;
    NanoValue *elements; /* Boxed storage (unboxed == 0) */
    void     *packed;    /* Unboxed storage (unboxed == 1): int64_t/double/uint8_t buffer */
};

/* True when `elem_type` is one of the non-reference primitive types that
 * qualify for unboxed storage. */
bool vm_array_type_unboxable(uint8_t elem_type);

/* Size in bytes of one unboxed element for `elem_type`, or 0 for boxed types. */
size_t vm_array_elem_size(uint8_t elem_type);

/* Struct: named fields */
struct VmStruct {
    VmHeapHeader header;
    uint32_t    def_idx;     /* Struct definition index */
    uint32_t    field_count;
    VmString   **field_names; /* Optional: field name strings */
    NanoValue   *fields;
};

/* Union: tagged union with variant fields */
struct VmUnion {
    VmHeapHeader header;
    uint32_t def_idx;
    uint16_t variant;
    uint16_t field_count;
    NanoValue *fields;
};

/* Tuple: fixed-size heterogeneous */
struct VmTuple {
    VmHeapHeader header;
    uint32_t count;
    NanoValue elements[];  /* Flexible array member */
};

/* Closure: function + captured environment */
struct VmClosure {
    VmHeapHeader header;
    uint32_t fn_idx;
    uint32_t callable_module; /* Same VM-local identity as a direct callable. */
    uint16_t capture_count;
    NanoValue captures[];  /* Flexible array member */
};

/* HashMap entry */
typedef struct VmHMEntry {
    uint8_t state;  /* 0=empty, 1=filled, 2=tombstone */
    NanoValue key;
    NanoValue value;
} VmHMEntry;

/* HashMap: key-value map */
struct VmHashMap {
    VmHeapHeader header;
    uint8_t key_type;
    uint8_t val_type;
    uint32_t count;
    uint32_t tombstone_count;
    uint32_t bucket_count;
    VmHMEntry *entries;
};

/* ========================================================================
 * Heap State
 * ======================================================================== */

typedef struct {
    size_t allocated;
    size_t freed;
    size_t num_objects;
    uint64_t allocation_calls;
    uint64_t retain_calls;
    uint64_t release_calls;
} VmHeapStats;

typedef struct VmHeap {
    VmHeapStats stats;
    /* String interning table: chained hash buckets keyed by content hash.
     * Lookup, insertion, and removal are all O(1) amortized, replacing the
     * previous linear scan over every interned string. */
    VmString **intern_buckets;
    uint32_t   intern_bucket_count;
    uint32_t   intern_count;

    /* Suspect cycle roots: objects whose reference count dropped without
     * reaching zero. Reference counting alone cannot reclaim a cycle -- every
     * member keeps the next one alive -- and cycles are constructible from
     * ordinary NanoLang, so something has to look. See vm_gc_collect_cycles. */
    void     **cycle_buf;
    uint32_t   cycle_count;
    uint32_t   cycle_capacity;
    uint64_t   cycles_collected;   /* objects reclaimed by cycle collection */
    bool       gc_running;         /* guards re-entry: collection releases */
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
    /* Set only by the private instance after exact nominal DAG validation.
     * Ordinary heaps remain zero/disabled. No private caller exports VmHeap. */
    bool private_record_dag;
    struct { NanoValue value; uint32_t child; } private_release[259];
#endif
} VmHeap;

/* ========================================================================
 * Heap API
 * ======================================================================== */

/* Reclaim objects that are only kept alive by references among themselves.
 *
 * Reference counting frees an object the moment its count reaches zero, which
 * never happens for a cycle: each member's count includes the reference from
 * the next. This walks the objects whose counts dropped without reaching zero
 * and reclaims those that turn out to be unreachable, using trial deletion --
 * subtract each member's internal references and see whether anything is left.
 *
 * Returns the number of objects reclaimed. Safe to call at any point; it only
 * frees what is already unreachable. */
uint64_t vm_gc_collect_cycles(VmHeap *heap);

/* Record an object whose reference count dropped without reaching zero. Only
 * such objects can be cycle roots: one whose count never dropped is still held
 * by whoever held it before. Called from vm_release. */
void vm_gc_note_suspect(VmHeap *heap, NanoValue v);

/* Release the suspect buffer itself. */
void vm_gc_maybe_collect(VmHeap *heap);
void vm_gc_cycle_buffer_free(VmHeap *heap);

/* Initialize/destroy heap */
void vm_heap_init(VmHeap *heap);
void vm_heap_destroy(VmHeap *heap);

/* Reference counting */
void vm_retain(VmHeap *heap, NanoValue v);
void vm_release(VmHeap *heap, NanoValue v);

/* I consume the payload on success or allocation failure. */
VmBString *vm_bstring_adopt(VmHeap *heap, nl_string_t *owned);
void vm_bstring_clear(VmHeap *heap, VmBString *value);

/* String allocation */
VmString *vm_string_new(VmHeap *heap, const char *data, uint32_t length);
VmString *vm_string_concat(VmHeap *heap, VmString *a, VmString *b);
VmString *vm_string_substr(VmHeap *heap, VmString *s, uint32_t start, uint32_t len);

/* String operations */
const char *vmstring_cstr(VmString *s);
uint32_t vmstring_len(VmString *s);
bool vmstring_equal(VmString *a, VmString *b);
int vmstring_compare(VmString *a, VmString *b);
bool vmstring_contains(VmString *haystack, VmString *needle);
/* Length-aware substring search that honors stored lengths and embedded
 * zero bytes. Returns the byte offset of the first match, or -1 when the
 * needle is not present. An empty needle matches at offset 0. */
int64_t vmstring_find(VmString *haystack, VmString *needle);
VmString *vmstring_char_at(VmHeap *heap, VmString *s, uint32_t index);

/* Array allocation */
VmArray *vm_array_new(VmHeap *heap, uint8_t elem_type, uint32_t initial_capacity);
/* I retain v only on success; failure leaves the array and v unchanged. */
bool vm_array_push(VmHeap *heap, VmArray *a, NanoValue v);
NanoValue vm_array_pop(VmArray *a);
NanoValue vm_array_get(VmArray *a, uint32_t index);
void vm_array_set(VmArray *a, uint32_t index, NanoValue v);
/* I exchange scalar/string storage without changing either array identity.
 * Both arrays must have the same scalar/string element type. */
void vm_array_swap_scalar_storage(VmArray *a, VmArray *b);
VmArray *vm_array_slice(VmHeap *heap, VmArray *a, uint32_t start, uint32_t end);
/* Remove the element at `index`, shifting the tail left.
 *
 * Takes the heap because it must release the reference the array held to the
 * element it drops -- exactly as vm_array_set releases the value it
 * overwrites. Without that, removing an element from an array of strings,
 * arrays or structs leaked it permanently: the refcount was never decremented
 * and nothing else held a claim to decrement it. */
void vm_array_remove(VmHeap *heap, VmArray *a, uint32_t index);

/* Struct allocation */
VmStruct *vm_struct_new(VmHeap *heap, uint32_t def_idx, uint32_t field_count);

/* Union allocation */
VmUnion *vm_union_new(VmHeap *heap, uint32_t def_idx, uint16_t variant, uint16_t field_count);

/* Tuple allocation */
VmTuple *vm_tuple_new(VmHeap *heap, uint32_t count);

/* Closure allocation */
VmClosure *vm_closure_new(VmHeap *heap, uint32_t fn_idx, uint16_t capture_count);

/* HashMap allocation */
VmHashMap *vm_hashmap_new(VmHeap *heap, uint8_t key_type, uint8_t val_type);
NanoValue vm_hashmap_get(VmHashMap *m, NanoValue key);
/* I borrow inputs; false preserves prior contents and retains neither input. */
bool vm_hashmap_set(VmHeap *heap, VmHashMap *m, NanoValue key, NanoValue value);
bool vm_hashmap_has(VmHashMap *m, NanoValue key);
void vm_hashmap_delete(VmHeap *heap, VmHashMap *m, NanoValue key);
VmArray *vm_hashmap_keys(VmHeap *heap, VmHashMap *m);
VmArray *vm_hashmap_values(VmHeap *heap, VmHashMap *m);

/* String conversion helpers (for STR_FROM_INT, STR_FROM_FLOAT, CAST_STRING) */
/* I publish a replacement size only when counted spans and uint32 growth fit. */
bool vm_string_replacement_length(uint32_t source_length, uint32_t needle_length,
                                  uint32_t replacement_length, uint64_t count,
                                  uint32_t *out);
VmString *vm_string_from_int(VmHeap *heap, int64_t v);
VmString *vm_string_from_float(VmHeap *heap, double v);
VmString *vm_string_from_bool(VmHeap *heap, bool v);

#endif /* NANOVM_HEAP_H */
