nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_inputs/../../src/nanoisa/file_source_snapshot.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_inputs/../../src/nanoisa/file_source_snapshot.h \
 src/nsi_file_binding.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h src/nsi_binding.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_inputs/../../src/nanoisa/service_source_catalog.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 src/nsi_socket_binding.h src/nsi_websocket_binding.h src/utf8.h \
 /usr/include/errno.h /usr/include/aarch64-linux-gnu/bits/errno.h \
 /usr/include/linux/errno.h /usr/include/aarch64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/aarch64-linux-gnu/bits/types/error_t.h /usr/include/fcntl.h \
 /usr/include/aarch64-linux-gnu/bits/fcntl.h \
 /usr/include/aarch64-linux-gnu/bits/fcntl-linux.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_iovec.h \
 /usr/include/linux/falloc.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/stat.h \
 /usr/include/aarch64-linux-gnu/bits/struct_stat.h /usr/include/stdlib.h \
 /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/aarch64-linux-gnu/sys/types.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/endian.h /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/alloca.h /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/string.h /usr/include/strings.h \
 /usr/include/aarch64-linux-gnu/sys/stat.h \
 /usr/include/aarch64-linux-gnu/bits/statx.h /usr/include/linux/stat.h \
 /usr/include/linux/types.h /usr/include/aarch64-linux-gnu/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/aarch64-linux-gnu/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h \
 /usr/include/aarch64-linux-gnu/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/aarch64-linux-gnu/bits/statx-generic.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx_timestamp.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx.h \
 /usr/include/unistd.h /usr/include/aarch64-linux-gnu/bits/posix_opt.h \
 /usr/include/aarch64-linux-gnu/bits/environments.h \
 /usr/include/aarch64-linux-gnu/bits/confname.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_posix.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_core.h \
 /usr/include/aarch64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h
