nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/passive.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/passive.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/generated_schema.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/passive_calls.inc
