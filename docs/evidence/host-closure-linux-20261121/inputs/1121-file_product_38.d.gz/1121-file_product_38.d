nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/websocket_host_grant.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/websocket_host_grant_internal.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/websocket_host_grant.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant_internal.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_host_grant.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/aarch64-linux-gnu/sys/types.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/endian.h /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/select2.h \
 /usr/include/aarch64-linux-gnu/bits/select-decl.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/alloca.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib.h /usr/include/string.h \
 /usr/include/strings.h \
 /usr/include/aarch64-linux-gnu/bits/strings_fortified.h \
 /usr/include/aarch64-linux-gnu/bits/string_fortified.h
