#include "../nanoisa/record_array_admission.h"
#include "../nanoisa/record_map_admission.h"
#include "vm_ffi_private.h"
#include "../nanoisa/service_bindings_module.h"
#include "../nanoisa/service_classification_private.h"
#include "../nanoisa/affine_state.h"
#include "../nanoisa/mixed_samples_internal.h"
#include "../nanoisa/owned_array_authority.h"
#include "../nanoisa/owned_array_admission.h"
#include "owned_array_runtime_private.h"
/*
 * NanoVM - Bytecode execution engine
 *
 * Simple switch dispatch over all NanoISA opcodes.
 */

#include "vm.h"
#include "record_array_runtime_private.h"
#include "record_map_runtime_private.h"
#include "../binary64_bits.h"
#include "../binary64_arithmetic.h"
#include "vm_ffi.h"
#include "cop_protocol.h"
#include "../nanoisa/verifier.h"
#include "../nanoisa/binary64_parse.h"
#include "../nanoisa/ownership_contracts.h"
#include "../nanoisa/nvm_v2_sections.h"
#include "../utf8.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#ifdef NANO_VM_TRACE_COMPILED
#define NANO_VM_TRACE_BUILD 1
#else
#define NANO_VM_TRACE_BUILD 0
#endif

/* ========================================================================
 * Error Handling
 * ======================================================================== */

static VmResult vm_error(VmState *vm, VmResult err, const char *fmt, ...) {
    vm->last_error = err;
    va_list args;
    va_start(args, fmt);
    vsnprintf(vm->error_msg, sizeof(vm->error_msg), fmt, args);
    va_end(args);
    return err;
}

const char *vm_error_string(VmResult result) {
    switch (result) {
        case VM_OK:                   return "OK";
        case VM_ERR_STACK_OVERFLOW:   return "Stack overflow";
        case VM_ERR_STACK_UNDERFLOW:  return "Stack underflow";
        case VM_ERR_CALL_DEPTH:       return "Call stack overflow";
        case VM_ERR_INVALID_OPCODE:   return "Invalid opcode";
        case VM_ERR_TYPE_ERROR:       return "Type error";
        case VM_ERR_OUT_OF_BOUNDS:    return "Index out of bounds";
        case VM_ERR_DIV_ZERO:         return "Division by zero";
        case VM_ERR_ASSERT_FAILED:    return "Assertion failed";
        case VM_ERR_UNDEFINED_GLOBAL: return "Undefined global";
        case VM_ERR_UNDEFINED_FUNCTION: return "Undefined function";
        case VM_ERR_NOT_IMPLEMENTED:  return "Not implemented";
        case VM_ERR_MEMORY:           return "Out of memory";
        case VM_ERR_DECODE:           return "Instruction decode error";
    }
    return "Unknown error";
}

/* Vector arithmetic borrows operands and returns one owned array. Validate
 * every participating pair before allocating; preserve the existing shorter-
 * array rule and scalar operand order. Mixed result tags use boxed storage. */
static uint8_t arithmetic_pair_tag(NanoOpcode op, NanoValue a, NanoValue b) {
    if (a.tag == TAG_INT && b.tag == TAG_INT) return TAG_INT;
    if ((a.tag == TAG_INT || a.tag == TAG_FLOAT) &&
        (b.tag == TAG_INT || b.tag == TAG_FLOAT)) return TAG_FLOAT;
    if (op == OP_ADD && a.tag == TAG_STRING && b.tag == TAG_STRING &&
        a.as.string && b.as.string) return TAG_STRING;
    return TAG_VOID;
}

static VmResult vm_array_arithmetic(VmState *vm, NanoOpcode op,
                                    NanoValue a, NanoValue b, NanoValue *out) {
    VmArray *left = a.tag == TAG_ARRAY ? a.as.array : NULL;
    VmArray *right = b.tag == TAG_ARRAY ? b.as.array : NULL;
    if ((a.tag == TAG_ARRAY && !left) || (b.tag == TAG_ARRAY && !right))
        return VM_ERR_TYPE_ERROR;
    if ((!left && a.tag != TAG_INT && a.tag != TAG_FLOAT &&
         !(op == OP_ADD && a.tag == TAG_STRING && a.as.string)) ||
        (!right && b.tag != TAG_INT && b.tag != TAG_FLOAT &&
         !(op == OP_ADD && b.tag == TAG_STRING && b.as.string)) ||
        (!left && !right))
        return VM_ERR_TYPE_ERROR;
    uint32_t len = left ? left->length : right->length;
    if (left && right && right->length < len) len = right->length;
    uint8_t result_tag = TAG_VOID;
    bool mixed = false;
    for (uint32_t i = 0; i < len; i++) {
        NanoValue ea = left ? vm_array_get(left, i) : a;
        NanoValue eb = right ? vm_array_get(right, i) : b;
        uint8_t tag = arithmetic_pair_tag(op, ea, eb);
        if (tag == TAG_VOID) return VM_ERR_TYPE_ERROR;
        if (i == 0) result_tag = tag;
        else if (tag != result_tag) mixed = true;
    }
    /* Empty typed numeric/string arrays still carry a useful result type. */
    if (!len) {
        NanoValue ea = left ? val_void() : a;
        NanoValue eb = right ? val_void() : b;
        if (left) ea.tag = left->elem_type;
        if (right) eb.tag = right->elem_type;
        if (ea.tag == TAG_STRING && eb.tag == TAG_STRING && op == OP_ADD)
            result_tag = TAG_STRING;
        else
            result_tag = arithmetic_pair_tag(op, ea, eb);
    }
    VmArray *result = vm_array_new(&vm->heap, mixed ? TAG_VOID : result_tag, len);
    if (!result) return VM_ERR_MEMORY;
    for (uint32_t i = 0; i < len; i++) {
        NanoValue ea = left ? vm_array_get(left, i) : a;
        NanoValue eb = right ? vm_array_get(right, i) : b;
        NanoValue value;
        uint8_t tag = arithmetic_pair_tag(op, ea, eb);
        if (tag == TAG_STRING) {
            VmString *s = vm_string_concat(&vm->heap, ea.as.string, eb.as.string);
            if (!s) {
                vm_release(&vm->heap, val_array(result));
                return VM_ERR_MEMORY;
            }
            value = val_string(s);
        } else if (tag == TAG_INT) {
            uint64_t x = (uint64_t)ea.as.i64, y = (uint64_t)eb.as.i64;
            switch (op) {
                case OP_ADD: value = val_int((int64_t)(x + y)); break;
                case OP_SUB: value = val_int((int64_t)(x - y)); break;
                case OP_MUL: value = val_int((int64_t)(x * y)); break;
                default:
                    value = val_int(eb.as.i64 == 0 ? 0 :
                        (ea.as.i64 == INT64_MIN && eb.as.i64 == -1) ?
                        INT64_MIN : ea.as.i64 / eb.as.i64);
                    break;
            }
        } else {
            double x = ea.tag == TAG_FLOAT ? ea.as.f64 : (double)ea.as.i64;
            double y = eb.tag == TAG_FLOAT ? eb.as.f64 : (double)eb.as.i64;
            switch (op) {
                case OP_ADD: value = val_float(nano_rt_f64_add(x, y)); break;
                case OP_SUB: value = val_float(nano_rt_f64_sub(x, y)); break;
                case OP_MUL: value = val_float(nano_rt_f64_mul(x, y)); break;
                default: value = val_float(nano_rt_f64_div(x, y)); break;
            }
        }
        bool appended = vm_array_push(&vm->heap, result, value);
        vm_release(&vm->heap, value); /* The array retains heap values. */
        if (!appended) {
            vm_release(&vm->heap, val_array(result));
            return VM_ERR_MEMORY;
        }
    }
    *out = val_array(result);
    return VM_OK;
}

/* ========================================================================
 * Init / Destroy
 * ======================================================================== */

/* Return one past the highest global slot referenced by any LOAD_GLOBAL or
 * STORE_GLOBAL instruction in a decoded module, i.e. the number of global
 * slots the module declares. Returns 0 when the module uses no globals. */
static uint32_t vm_decoded_module_global_slots(const VmDecodedModule *decoded) {
    uint32_t slots = 0;
    if (!decoded) return 0;
    for (uint32_t f = 0; f < decoded->function_count; f++) {
        const VmDecodedFunction *fn = &decoded->functions[f];
        for (uint32_t i = 0; i < fn->instruction_count; i++) {
            const DecodedInstruction *ins = &fn->instructions[i].instruction;
            if (ins->opcode == OP_LOAD_GLOBAL || ins->opcode == OP_STORE_GLOBAL) {
                uint32_t idx = ins->operands[0].u32;
                if (idx < VM_MAX_GLOBALS && idx + 1 > slots) slots = idx + 1;
            }
        }
    }
    return slots;
}

bool vm_ensure_globals(VmState *vm, uint32_t count) {
    if (!vm) return false;
    if (count > VM_MAX_GLOBALS) return false;
    if (count <= vm->global_capacity) return true;
    NanoValue *grown = realloc(vm->globals, (size_t)count * sizeof(NanoValue));
    if (!grown) return false;
    memset(grown + vm->global_capacity, 0,
           (size_t)(count - vm->global_capacity) * sizeof(NanoValue));
    vm->globals = grown;
    vm->global_capacity = count;
    return true;
}

/* Establish the safety proof for the whole program the VM is about to run.
 * The unchecked private stack handlers on the hot path are sound only when
 * every reachable module has passed nvm_verify_linked(); this recomputes that fact
 * over the root module and every linked module and records it on the VM.
 * Any module that fails verification (or is absent) clears the proof, so the
 * VM falls back to the checked handlers. */
/* Checked stack handlers do not implement declared reference semantics.
 * I refuse these contracts even when a caller bypasses the CLI verifier. */
/* I distinguish valid advisory declarations from instructions that actually
 * require my private owned-transfer execution path. Every public entry uses
 * this classification before it asks whether instantiated constants are ready. */
static bool vm_module_ownership_required(const NvmModule *module, bool *required,
                                          const NvmServiceClassification *facts) {
    if (required) *required=false;
    if (!module || !required || nvm_service_pending_classified(module,facts)) return false;
    if(nvm_record_map_selected(nvm_record_map_route(module)))return false;
    if(nvm_owned_array_route_classified(module,facts)!=NVM_OWNER_ARRAY_NOT_SELECTED){*required=true;return true;}
    if(nvm_mixed_samples_candidate_classified(module,facts)){*required=true;return true;}
    if(nvm_record_array_candidate(module)) {
        NvmRecordArrayExecutionPlan *plan=NULL;
        NvmArrayEligibilityResult result=nvm_record_array_admit(module,&plan);
        nvm_record_array_execution_free(plan);
        return result.status==NVM_ARRAY_ELIGIBLE;
    }
    if (!module->ownership_data && !module->ownership_size) return true;
    bool needs=false;
    if (nvm_ownership_contracts_validate(module,&needs)!=NVM_V2_OK) return false;
    *required=needs || nvm_uses_owned_transfers(module);
    return true;
}

static bool vm_module_ownership_supported(const NvmModule *module, bool standalone,
                                           const NvmServiceClassification *facts) {
    if (nvm_service_pending_classified(module,facts)) return false;
    if(nvm_record_map_selected(nvm_record_map_route(module)))return false;
    if(nvm_owned_array_route_classified(module,facts)!=NVM_OWNER_ARRAY_NOT_SELECTED) {
        if(!standalone)return false;
        NvmOwnedArrayPlan *plan=NULL;
        NvmOwnerAuthorityResult result=nvm_owned_array_admit(module,&plan);
        nvm_owned_array_plan_free(plan);
        return result.status==NVM_OWNER_AUTH_PREPARED;
    }
    if(nvm_mixed_samples_candidate_classified(module,facts)) {
        if(!standalone)return false;
        NvmMixedSamplesPlan *plan=NULL;
        NvmMixedShapeResult result=nvm_mixed_samples_admit(module,&plan);
        nvm_mixed_samples_plan_free(plan);
        return result.status==NVM_MIXED_SHAPE_PROVED;
    }
    if(nvm_record_array_candidate(module)) {
        if(!standalone)return false;
        NvmRecordArrayExecutionPlan *plan=NULL;
        NvmArrayEligibilityResult result=nvm_record_array_admit(module,&plan);
        nvm_record_array_execution_free(plan);
        return result.status==NVM_ARRAY_ELIGIBLE;
    }
    bool required=false;
    return vm_module_ownership_required(module,&required,facts) &&
        (!required || (standalone && nvm_verify_owned_module(module).ok));
}

static bool vm_ownership_supported_scoped(const VmState *vm,
                                           const NvmServiceClassification *facts) {
    if (!vm) return false;
    bool standalone=vm->linked_module_count==0 && vm->module==vm->root_module;
    if (!vm_module_ownership_supported(vm->module,standalone,facts)) return false;
    NvmServiceClassification root_facts;
    const NvmServiceClassification *root=facts;
    if (facts && facts->module!=vm->root_module) {
        root_facts=nvm_service_classify(vm->root_module);
        root=&root_facts;
    }
    if (!vm_module_ownership_supported(vm->root_module,standalone,root)) return false;
    for (uint32_t i=0;i<vm->linked_module_count;i++) {
        NvmServiceClassification linked_facts;
        const NvmServiceClassification *linked=NULL;
        if (facts) {
            linked_facts=nvm_service_classify(vm->linked_modules[i]);
            linked=&linked_facts;
        }
        if (!vm_module_ownership_supported(vm->linked_modules[i],false,linked)) return false;
    }
    return true;
}
static bool vm_ownership_supported(const VmState *vm) {
    return vm_ownership_supported_scoped(vm,NULL);
}

/* I keep this proof only on one synchronous public invocation's C stack.
 * The admitted standalone module is immutable while that invocation executes. */
typedef struct {
    const NvmModule *module;
    bool mixed, owner_arrays, ordinary_arrays;
    uint32_t ordinary_root;
    uint32_t *ordinary_active_root; /* Borrowed only during the synchronous root call. */
    uint32_t global_count;
    const NvmModule *global_module;
    VmResult refusal;
    const char *reason;
    uint32_t function_count, record_count;
    NvmMixedSignature signatures[8];
    NvmMixedRecordIdentity records[NVM_RECORD_PLAN_MAX_LAYOUTS];
    bool ordinary_records[NVM_RECORD_PLAN_MAX_LAYOUTS];
} VmOwnedInvocationProof;

static bool vm_owned_proof_matches(const VmState *vm, const VmOwnedInvocationProof *proof) {
    return proof && proof->module && vm && vm->module==proof->module &&
        vm->root_module==proof->module && !vm->linked_module_count &&
        !vm->callbacks && !vm->opcode_trace;
}

/* I retain ordinary admission only between synchronous ASSERT resumes. The
 * File-opcode presence below is a narrower code fact: one public invocation
 * may reuse it after host traps while code identity and the VM mutation revision
 * remain unchanged. Supported active append/rebuild APIs invalidate that fact.
 * Mutable service and ownership metadata are still read on every admission. */
typedef struct {
    const VmState *vm;
    const NvmModule *module;
    bool valid;
    const NvmModule *service_module;
    bool service_file_known;
    bool service_file_pending;
    uint64_t service_revision;
    const uint8_t *service_code;
    const NvmFunctionEntry *service_functions;
    uint32_t service_code_size, service_function_count;
} VmOrdinaryAdmission;

static bool vm_ordinary_admission_eligible(const VmState *vm) {
    return vm && vm->module && vm->module==vm->root_module &&
        !vm->linked_module_count && !vm->callbacks && !vm->opcode_trace;
}

static bool vm_ordinary_admission_matches(const VmState *vm,
                                          const VmOrdinaryAdmission *ordinary) {
    return ordinary && ordinary->valid && ordinary->vm==vm &&
        vm_ordinary_admission_eligible(vm) && ordinary->module==vm->module;
}

static NvmServiceClassification vm_invocation_service_classify(
        const VmState *vm, const NvmModule *module, VmOrdinaryAdmission *ordinary) {
    if (!vm || !module || !ordinary) return nvm_service_classify(module);
    if (!ordinary->service_file_known || ordinary->service_module != module ||
        vm->module_revision == UINT64_MAX ||
        ordinary->service_revision != vm->module_revision ||
        ordinary->service_code != module->code ||
        ordinary->service_functions != module->functions ||
        ordinary->service_code_size != module->code_size ||
        ordinary->service_function_count != module->function_count) {
        NvmServiceClassification first = nvm_service_classify(module);
        bool bindings = nvm_service_bindings_present(module);
        ordinary->service_module = module;
        ordinary->service_file_known = true;
        ordinary->service_revision = vm->module_revision;
        ordinary->service_code = module->code;
        ordinary->service_functions = module->functions;
        ordinary->service_code_size = module->code_size;
        ordinary->service_function_count = module->function_count;
        /* A negative complete query proves both terms absent. A positive
         * binding query needs one explicit code query so later metadata
         * removal cannot hide a File instruction. */
        ordinary->service_file_pending = first.pending &&
            (!bindings || nvm_file_instructions_present(module));
    }
    return (NvmServiceClassification){
        module,
        nvm_service_bindings_present(module) || ordinary->service_file_pending
    };
}

static bool vm_owned_constants_ready(const VmState *vm) {
    if (!vm || !vm->module) return false;
    const VmModuleConstants *constants = NULL;
    if (vm->module==vm->root_module) constants=&vm->module_constants;
    else for (uint32_t i=0;i<vm->linked_module_count;i++)
        if (vm->linked_modules[i]==vm->module) {
            constants=&vm->linked_module_constants[i];break;
        }
    if (!constants || constants->count!=vm->module->string_count)
        return false;
    for (uint32_t i=0;i<constants->count;i++)
        if (!constants->strings || !constants->strings[i]) return false;
    return true;
}

static bool vm_owned_runtime_ready_scoped(const VmState *vm, bool *required,
                                          const NvmServiceClassification *facts) {
    if (required) *required=false;
    if (!vm || !required ||
        !vm_module_ownership_required(vm->module,required,facts)) return false;
    return !*required || vm_owned_constants_ready(vm);
}

static bool vm_owned_runtime_ready(const VmState *vm, bool *required) {
    return vm_owned_runtime_ready_scoped(vm,required,NULL);
}

/* I prepare fresh immutable facts for one C-stack invocation. Direct core
 * continuations reverify rather than persisting a module trust flag. */
static bool vm_mixed_invocation_prepare(VmState *vm,VmOwnedInvocationProof *out,bool resuming) {
    if(!out)return false;
    *out=(VmOwnedInvocationProof){0};
    if(!vm || !vm->module || vm->module!=vm->root_module ||
       vm->linked_module_count || vm->callbacks || vm->opcode_trace ||
       (!resuming && vm->references.active) || !vm_owned_constants_ready(vm))return false;
    NvmMixedSamplesPlan *plan=NULL;
    NvmMixedShapeResult checked=nvm_mixed_samples_admit(vm->module,&plan);
    if(checked.status!=NVM_MIXED_SHAPE_PROVED) {
        out->refusal=checked.status==NVM_MIXED_SHAPE_MEMORY?VM_ERR_MEMORY:VM_ERR_TYPE_ERROR;
        out->reason=checked.message;return false;
    }
    VmOwnedInvocationProof prepared={0};
    prepared.module=vm->module;prepared.mixed=true;prepared.function_count=vm->module->function_count;
    for(uint32_t f=0;f<prepared.function_count;f++)
        if(!nvm_mixed_samples_signature(plan,f,&prepared.signatures[f]))goto fail;
    if(prepared.signatures[0].result.tag!=TAG_INT && prepared.signatures[0].result.tag!=TAG_BOOL &&
       prepared.signatures[0].result.tag!=TAG_U8)goto fail;
    const NvmMixedSamplesProof *facts=nvm_mixed_samples_obligations(plan);
    prepared.record_count=facts->shape->view->record_count;
    for(uint32_t i=0;i<prepared.record_count;i++)
        prepared.ordinary_records[i]=nvm_mixed_samples_record(plan,i,&prepared.records[i]);
    nvm_mixed_samples_plan_free(plan);*out=prepared;return true;
fail:nvm_mixed_samples_plan_free(plan);return false;
}

static bool vm_owner_array_invocation_prepare(VmState *vm,VmOwnedInvocationProof *out) {
    if(!out)return false;
    *out=(VmOwnedInvocationProof){0};
    if(!vm || !vm->module || vm->module!=vm->root_module || vm->stack_size ||
       vm->frame_count || vm->activation_floor || vm->references.active ||
       vm->callee_references.active || vm->linked_module_count || vm->callbacks ||
       vm->opcode_trace || !vm_owned_constants_ready(vm))return false;
    for(unsigned f=0;f<NVM_OWNED_MAX_FUNCTIONS-2;f++)if(vm->value_references[f].active)return false;
    NvmOwnedArrayPlan *plan=NULL;NvmOwnerAuthorityResult checked=nvm_owned_array_admit(vm->module,&plan);
    if(checked.status!=NVM_OWNER_AUTH_PREPARED) {
        out->refusal=checked.status==NVM_OWNER_AUTH_MEMORY?VM_ERR_MEMORY:VM_ERR_TYPE_ERROR;
        out->reason=checked.message;return false;
    }
    VmOwnedInvocationProof prepared={0};prepared.module=vm->module;prepared.owner_arrays=true;
    prepared.function_count=vm->module->function_count;
    for(uint32_t f=0;f<prepared.function_count;f++) {
        NvmOwnerSignature from;if(!nvm_owned_array_plan_signature(plan,f,&from))goto fail;
        NvmMixedSignature *to=&prepared.signatures[f];
        to->parameter_count=from.parameter_count;to->local_count=from.local_count;
        to->max_stack=from.max_stack;to->result_fields=from.result_fields;
        to->result=(NvmMixedDeclaration){from.result.tag,from.result.mode,from.result.global_layout,
            from.result.owner?NVM_MIXED_VALUE_OWNER:NVM_MIXED_VALUE_SCALAR};
        for(uint16_t n=0;n<from.parameter_count;n++) {
            NvmOwnerDeclaration d=from.parameters[n];
            to->parameters[n]=(NvmMixedDeclaration){d.tag,d.mode,d.global_layout,
                d.owner?NVM_MIXED_VALUE_OWNER:NVM_MIXED_VALUE_SCALAR};
        }
    }
    nvm_owned_array_plan_free(plan);*out=prepared;return true;
fail:nvm_owned_array_plan_free(plan);return false;
}

static bool vm_ownership_admit(VmState *vm, VmOwnedInvocationProof *proof) {
    proof->module=NULL;proof->mixed=false;proof->owner_arrays=false;proof->ordinary_arrays=false;proof->ordinary_active_root=NULL;proof->global_count=0;proof->global_module=NULL;proof->refusal=VM_OK;proof->reason=NULL;
    if(vm && nvm_owned_array_route(vm->module)!=NVM_OWNER_ARRAY_NOT_SELECTED)return vm_owner_array_invocation_prepare(vm,proof);
    if(vm && nvm_mixed_samples_candidate(vm->module))return vm_mixed_invocation_prepare(vm,proof,false);
    bool required=false;
    if (!vm_owned_runtime_ready(vm,&required)) return false;
    if (vm && vm->module && vm->module==vm->root_module &&
        !vm->linked_module_count && !vm->callbacks && !vm->opcode_trace &&
        !vm->references.active && required) {
        if (!nvm_verify_owned_module(vm->module).ok) return false;
        if (nvm_ownership_globals(vm->module,NULL,0,&proof->global_count)!=NVM_V2_OK) return false;
        proof->module=vm->module;
        return true;
    }
    return vm_ownership_supported(vm);
}

static const char VM_OWNERSHIP_REQUIRED[] =
    "I require reference lifetime and ownership instruction verification before execution";

static void vm_recompute_verified(VmState *vm) {
    if (!vm) return;
    bool proven = vm->root_module != NULL
        && nvm_verify_linked(vm->root_module, vm->linked_modules,
                             vm->linked_module_count).ok;
    for (uint32_t i = 0; proven && i < vm->linked_module_count; i++) {
        if (!vm->linked_modules[i]
                || !nvm_verify_linked(vm->linked_modules[i], vm->linked_modules,
                                      vm->linked_module_count).ok)
            proven = false;
    }
    vm->verified = proven;
}
static void vm_module_constants_free(VmState *vm, VmModuleConstants *constants) {
    if (!constants) return;
    for (uint32_t i = 0; i < constants->count; i++) {
        if (constants->strings[i])
            vm_release(&vm->heap, val_string(constants->strings[i]));
    }
    free(constants->strings);
    constants->strings = NULL;
    constants->count = 0;
}

static bool vm_module_constants_build(VmState *vm, const NvmModule *module,
                                      VmModuleConstants *constants) {
    memset(constants, 0, sizeof(*constants));
    if (module->string_count == 0) return true;

    constants->strings = calloc(module->string_count, sizeof(VmString *));
    if (!constants->strings) return false;
    constants->count = module->string_count;
    for (uint32_t i = 0; i < module->string_count; i++) {
        constants->strings[i] = vm_string_new(&vm->heap, module->strings[i],
                                               module->string_lengths[i]);
        if (!constants->strings[i]) {
            vm_module_constants_free(vm, constants);
            return false;
        }
    }
    return true;
}

void vm_init(VmState *vm, const NvmModule *module) {
    memset(vm, 0, sizeof(*vm));
    vm->owner_thread = pthread_self();
    vm->module = module;
    vm->root_module = module;
    vm->stack_capacity = VM_STACK_INITIAL;
    vm->stack = calloc(vm->stack_capacity, sizeof(NanoValue));
    vm->output = NULL; /* default stdout */
    vm->cop_in_fd = -1;
    vm->cop_out_fd = -1;
    vm->cop_pid = -1;
    vm->cop_mailbox = NULL;
    vm->cop_mailbox_size = 0;
    vm->cop_sig_send_fd = -1;
    vm->cop_sig_recv_fd = -1;
    /* Read per-call timeout from env (default 5 s); -1 = unlimited */
    const char *tenv = getenv("COP_TIMEOUT_MS");
    vm->cop_timeout_ms = tenv ? atoi(tenv) : 5000;
    const char *trace_env = getenv("NANO_VM_TRACE");
    vm->opcode_trace = NANO_VM_TRACE_BUILD
        || (trace_env && trace_env[0] != '\0' && strcmp(trace_env, "0") != 0);
    vm_heap_init(&vm->heap);
    if (!vm_module_constants_build(vm, module, &vm->module_constants)) {
        vm_error(vm, VM_ERR_MEMORY, "Module constant instantiation failed");
        return;
    }
    char decode_error[VM_DECODE_ERROR_SIZE];
    if (vm_decode_module(module, &vm->decoded_module, decode_error)) {
        vm->decoded_module_valid = true;
        /* Size the globals array from the declarations the module actually
         * uses instead of embedding VM_MAX_GLOBALS values in every VM. */
        uint32_t root_globals = vm_decoded_module_global_slots(&vm->decoded_module);
        if (root_globals > 0 && !vm_ensure_globals(vm, root_globals)) {
            vm_error(vm, VM_ERR_MEMORY,
                     "Failed to allocate %u globals", root_globals);
        }
        char dispatch_error[VM_DISPATCH_ERROR_SIZE];
        if (vm_dispatch_build_module(&vm->decoded_module, vm->dispatch_profile,
                                     &vm->dispatch_module, dispatch_error)) {
            vm->dispatch_module_valid = true;
        } else {
            vm_error(vm, VM_ERR_DECODE, "%s", dispatch_error);
        }
    } else {
        vm_error(vm, VM_ERR_DECODE, "%s", decode_error);
    }
    /* Record whether the root module is verified so the hot path can pick
     * the unchecked private handlers where the proof permits it. */
    vm_recompute_verified(vm);
}

static void vm_clear_reference_activations(VmState *vm);

void vm_destroy(VmState *vm) {
    vm_clear_reference_activations(vm);
    if (vm->callbacks && vm_callback_shutdown(vm) != NANO_CALLBACK_OK) {
        /* I cannot free roots beneath a running callback or on another thread. */
        return;
    }
    vm->callbacks_closed = true;
    /* Direct/core invocation can leave frames after a trap. I detach their
     * owned callables before destroying heap roots; borrowed effect closures
     * do not acquire or release a second reference here. */
    while (vm->frame_count) {
        VmCallFrame *frame = &vm->frames[--vm->frame_count];
        NanoValue callable = frame->owned_callable;
        frame->owned_callable = val_void();
        frame->closure = NULL;
        vm_release(&vm->heap, callable);
    }
    vm->handler_count = 0;
    /* Release all globals */
    for (uint32_t i = 0; i < vm->global_count; i++) {
        vm_release(&vm->heap, vm->globals[i]);
    }
    /* Release all stack values */
    for (uint32_t i = 0; i < vm->stack_size; i++) {
        vm_release(&vm->heap, vm->stack[i]);
    }
    free(vm->stack);
    free(vm->globals);
    vm->globals = NULL;
    vm->global_capacity = 0;
    vm->global_count = 0;
    vm_decoded_module_free(&vm->decoded_module);
    vm_dispatch_module_free(&vm->dispatch_module);
    for (uint32_t i = 0; i < vm->linked_module_count; i++) {
        vm_decoded_module_free(&vm->decoded_linked_modules[i]);
        vm_dispatch_module_free(&vm->dispatch_linked_modules[i]);
        vm_module_constants_free(vm, &vm->linked_module_constants[i]);
    }
    vm_module_constants_free(vm, &vm->module_constants);
    free(vm->decoded_linked_modules);
    free(vm->decoded_linked_modules_valid);
    free(vm->dispatch_linked_modules);
    free(vm->dispatch_linked_modules_valid);
    free(vm->linked_module_constants);
    free(vm->linked_modules);
    free(vm->memory);
    vm_heap_destroy(&vm->heap);
    vm->stack = NULL;
    vm->decoded_linked_modules = NULL;
    vm->decoded_linked_modules_valid = NULL;
    vm->dispatch_linked_modules = NULL;
    vm->dispatch_linked_modules_valid = NULL;
    vm->linked_module_constants = NULL;
    vm->linked_modules = NULL;
    vm->memory = NULL;
    vm->decoded_module_valid = false;
    vm->dispatch_module_valid = false;
    vm->linked_module_count = 0;
    vm->linked_module_capacity = 0;
}

bool vm_memory_resize(VmState *vm, uint64_t size) {
    if (!vm || size > SIZE_MAX) return false;
    if (size == 0) {
        free(vm->memory);
        vm->memory = NULL;
        vm->memory_size = 0;
        return true;
    }
    uint8_t *memory = realloc(vm->memory, (size_t)size);
    if (!memory) return false;
    if (size > vm->memory_size)
        memset(memory + vm->memory_size, 0, (size_t)(size - vm->memory_size));
    vm->memory = memory;
    vm->memory_size = size;
    return true;
}

static uint32_t vm_link_module_at_next_index(VmState *vm, const NvmModule *mod) {
    if (!vm || !mod || vm->frame_count != 0) return (uint32_t)-1;
    VmDecodedModule decoded;
    char decode_error[VM_DECODE_ERROR_SIZE];
    if (!vm_decode_module(mod, &decoded, decode_error)) {
        vm_error(vm, VM_ERR_DECODE, "%s", decode_error);
        return (uint32_t)-1;
    }
    VmDispatchModule dispatch;
    char dispatch_error[VM_DISPATCH_ERROR_SIZE];
    if (!vm_dispatch_build_module(&decoded, vm->dispatch_profile, &dispatch, dispatch_error)) {
        vm_decoded_module_free(&decoded);
        vm_error(vm, VM_ERR_DECODE, "%s", dispatch_error);
        return (uint32_t)-1;
    }
    /* Grow the globals array to cover the linked module's declarations; the
     * global namespace is shared across the root and all linked modules. */
    uint32_t linked_globals = vm_decoded_module_global_slots(&decoded);
    if (linked_globals > 0 && !vm_ensure_globals(vm, linked_globals)) {
        vm_decoded_module_free(&decoded);
        vm_dispatch_module_free(&dispatch);
        vm_error(vm, VM_ERR_MEMORY,
                 "Failed to allocate %u globals", linked_globals);
        return (uint32_t)-1;
    }

    VmModuleConstants constants;
    if (!vm_module_constants_build(vm, mod, &constants)) {
        vm_decoded_module_free(&decoded);
        vm_dispatch_module_free(&dispatch);
        vm_error(vm, VM_ERR_MEMORY, "Module constant instantiation failed");
        return (uint32_t)-1;
    }
    if (vm->linked_module_count >= vm->linked_module_capacity) {
        uint32_t new_cap = vm->linked_module_capacity ? vm->linked_module_capacity * 2 : 8;
        const NvmModule **new_arr = realloc(vm->linked_modules,
                                             new_cap * sizeof(const NvmModule *));
        if (!new_arr) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->linked_modules = new_arr;
        VmDecodedModule *new_decoded = realloc(vm->decoded_linked_modules,
                                               new_cap * sizeof(VmDecodedModule));
        if (!new_decoded) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->decoded_linked_modules = new_decoded;
        bool *new_valid = realloc(vm->decoded_linked_modules_valid,
                                  new_cap * sizeof(bool));
        if (!new_valid) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->decoded_linked_modules_valid = new_valid;
        VmDispatchModule *new_dispatch = realloc(vm->dispatch_linked_modules,
                                                 new_cap * sizeof(VmDispatchModule));
        if (!new_dispatch) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->dispatch_linked_modules = new_dispatch;
        bool *new_dispatch_valid = realloc(vm->dispatch_linked_modules_valid,
                                           new_cap * sizeof(bool));
        if (!new_dispatch_valid) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->dispatch_linked_modules_valid = new_dispatch_valid;
        VmModuleConstants *new_constants = realloc(vm->linked_module_constants,
                                                    new_cap * sizeof(VmModuleConstants));
        if (!new_constants) {
            vm_decoded_module_free(&decoded);
            vm_dispatch_module_free(&dispatch);
            vm_module_constants_free(vm, &constants);
            return (uint32_t)-1;
        }
        vm->linked_module_constants = new_constants;
        vm->linked_module_capacity = new_cap;
    }
    uint32_t idx = vm->linked_module_count++;
    vm->linked_modules[idx] = mod;
    vm->decoded_linked_modules[idx] = decoded;
    vm->decoded_linked_modules_valid[idx] = true;
    /* Linking changed: callable handles must be re-resolved. */
    vm->module_calls_resolved = false;
    vm->dispatch_linked_modules[idx] = dispatch;
    vm->dispatch_linked_modules_valid[idx] = true;
    /* A newly linked module joins the program; re-establish the proof so an
     * unverified link cannot leave the unchecked handlers enabled. */
    vm_recompute_verified(vm);
    vm->linked_module_constants[idx] = constants;
    return idx;
}

uint32_t vm_link_module(VmState *vm, const NvmModule *mod) {
    if (vm && vm->root_module && vm->root_module->module_ref_count != 0) {
        vm_error(vm, VM_ERR_DECODE,
                 "Named module dependencies require vm_link_named_module");
        return (uint32_t)-1;
    }
    return vm_link_module_at_next_index(vm, mod);
}

uint32_t vm_link_named_module(VmState *vm, const char *name,
                              const NvmModule *mod) {
    if (!vm || !vm->root_module || !name) return (uint32_t)-1;
    uint32_t idx = vm->linked_module_count;
    if (idx >= vm->root_module->module_ref_count) {
        vm_error(vm, VM_ERR_OUT_OF_BOUNDS,
                 "No module dependency declared at index %u", idx);
        return (uint32_t)-1;
    }
    const char *expected = nvm_get_string(
        vm->root_module, vm->root_module->module_refs[idx].module_name_idx);
    if (!expected || strcmp(expected, name) != 0) {
        vm_error(vm, VM_ERR_DECODE,
                 "Module dependency %u is '%s', not '%s'", idx,
                 expected ? expected : "<invalid>", name);
        return (uint32_t)-1;
    }
    return vm_link_module_at_next_index(vm, mod);
}

static uint32_t vm_callable_module_id(const VmState *vm, const NvmModule *module) {
    if (module == vm->root_module) return 1;
    for (uint32_t i = 0; i < vm->linked_module_count; i++)
        if (vm->linked_modules[i] == module && i <= UINT32_MAX - 2) return i + 2;
    return 0;
}

bool vm_callable_target(const VmState *vm, NanoValue callable,
                        const NvmModule **module, uint32_t *function_index) {
    if (!vm || !module || !function_index) return false;
    uint32_t owner, index;
    if (callable.tag == TAG_FUNCTION) {
        owner = callable.callable_module;
        index = callable.as.fn_idx;
    } else if (callable.tag == TAG_CLOSURE && callable.as.closure) {
        owner = callable.as.closure->callable_module;
        index = callable.as.closure->fn_idx;
    } else return false;
    const NvmModule *target = owner == 1 ? vm->root_module :
        owner >= 2 && owner - 2 < vm->linked_module_count ? vm->linked_modules[owner - 2] : NULL;
    if (!target || index >= target->function_count) return false;
    *module = target;
    *function_index = index;
    return true;
}

static VmDecodedModule *decoded_module_for(VmState *vm, const NvmModule *module,
                                            bool **valid) {
    if (module == vm->root_module) {
        if (valid) *valid = &vm->decoded_module_valid;
        return &vm->decoded_module;
    }
    for (uint32_t i = 0; i < vm->linked_module_count; i++) {
        if (vm->linked_modules[i] == module) {
            if (valid) *valid = &vm->decoded_linked_modules_valid[i];
            return &vm->decoded_linked_modules[i];
        }
    }
    return NULL;
}

static VmDispatchModule *dispatch_module_for(VmState *vm, const NvmModule *module,
                                             bool **valid) {
    if (module == vm->root_module) {
        if (valid) *valid = &vm->dispatch_module_valid;
        return &vm->dispatch_module;
    }
    for (uint32_t i = 0; i < vm->linked_module_count; i++) {
        if (vm->linked_modules[i] == module) {
            if (valid) *valid = &vm->dispatch_linked_modules_valid[i];
            return &vm->dispatch_linked_modules[i];
        }
    }
    return NULL;
}

static VmModuleConstants *module_constants_for(VmState *vm,
                                                const NvmModule *module) {
    if (module == vm->root_module) return &vm->module_constants;
    for (uint32_t i = 0; i < vm->linked_module_count; i++) {
        if (vm->linked_modules[i] == module)
            return &vm->linked_module_constants[i];
    }
    return NULL;
}

static void vm_note_module_change(VmState *vm) {
    if (vm->module_revision != UINT64_MAX) ++vm->module_revision;
}

void vm_invalidate_module(VmState *vm, const NvmModule *module) {
    if (!vm || !module) return;
    bool *valid = NULL;
    VmDecodedModule *decoded = decoded_module_for(vm, module, &valid);
    if (!decoded) return;
    vm_note_module_change(vm);
    vm_decoded_module_free(decoded);
    *valid = false;
    /* Freed decoded instructions invalidate resolved handles. */
    vm->module_calls_resolved = false;
    bool *dispatch_valid = NULL;
    VmDispatchModule *dispatch = dispatch_module_for(vm, module, &dispatch_valid);
    if (dispatch) {
        vm_dispatch_module_free(dispatch);
        *dispatch_valid = false;
    }
    /* An invalidated module is no longer proven; drop to the checked path. */
    vm->verified = false;
}

bool vm_rebuild_module(VmState *vm, const NvmModule *module) {
    if (!vm || !module) return false;
    bool *valid = NULL;
    VmDecodedModule *slot = decoded_module_for(vm, module, &valid);
    if (!slot) return false;
    vm_note_module_change(vm);
    VmDecodedModule replacement;
    char decode_error[VM_DECODE_ERROR_SIZE];
    if (!vm_decode_module(module, &replacement, decode_error)) {
        vm_error(vm, VM_ERR_DECODE, "%s", decode_error);
        return false;
    }
    VmModuleConstants constants_replacement;
    if (!vm_module_constants_build(vm, module, &constants_replacement)) {
        vm_decoded_module_free(&replacement);
        vm_error(vm, VM_ERR_MEMORY, "Module constant instantiation failed");
        return false;
    }
    vm_decoded_module_free(slot);
    *slot = replacement;
    *valid = true;
    /* Rebuilt decoded instructions must be re-resolved before dispatch. */
    vm->module_calls_resolved = false;

    bool *dispatch_valid = NULL;
    VmDispatchModule *dispatch_slot = dispatch_module_for(vm, module, &dispatch_valid);
    if (dispatch_slot) {
        VmDispatchModule dispatch_replacement;
        char dispatch_error[VM_DISPATCH_ERROR_SIZE];
        if (!vm_dispatch_build_module(slot, vm->dispatch_profile, &dispatch_replacement, dispatch_error)) {
            vm_module_constants_free(vm, &constants_replacement);

            vm_error(vm, VM_ERR_DECODE, "%s", dispatch_error);
            return false;
        }
        vm_dispatch_module_free(dispatch_slot);
        *dispatch_slot = dispatch_replacement;
        *dispatch_valid = true;
    }
    VmModuleConstants *constants_slot = module_constants_for(vm, module);
    if (constants_slot) {
        vm_module_constants_free(vm, constants_slot);
        *constants_slot = constants_replacement;
    } else {
        vm_module_constants_free(vm, &constants_replacement);
    }
    vm->last_error = VM_OK;
    vm->error_msg[0] = '\0';
    /* The rebuilt module must be re-verified before the unchecked handlers
     * may be used again. */
    vm_recompute_verified(vm);
    return true;
}

void vm_invalidate_decoded_module(VmState *vm, const NvmModule *module) {
    vm_invalidate_module(vm, module);
}

VmResult vm_rebuild_decoded_module(VmState *vm, const NvmModule *module) {
    return vm_rebuild_module(vm, module) ? VM_OK : vm->last_error;
}

static void vm_resolve_function_calls(VmState *vm, VmDecodedFunction *function,
                                      VmDispatchFunction *dispatch);

static bool vm_module_constants_append(VmState *vm, const NvmModule *module,
                                       VmModuleConstants *constants) {
    uint32_t i;
    VmString **grown;

    if (!vm || !module || !constants) return false;
    if (module->string_count <= constants->count) return true;
    grown = realloc(constants->strings,
                    (size_t)module->string_count * sizeof(*grown));
    if (!grown) return false;
    constants->strings = grown;
    for (i = constants->count; i < module->string_count; i++) {
        constants->strings[i] = vm_string_new(&vm->heap, module->strings[i],
                                              module->string_lengths[i]);
        if (!constants->strings[i]) {
            constants->count = i;
            return false;
        }
    }
    constants->count = module->string_count;
    return true;
}

bool vm_sync_new_functions(VmState *vm, const NvmModule *module) {
    bool *valid = NULL;
    bool *dispatch_valid = NULL;
    VmDecodedModule *decoded;
    VmDispatchModule *dispatch;
    VmModuleConstants *constants;
    VmDecodedFunction *decoded_fns;
    VmDispatchFunction *dispatch_fns;
    char decode_error[VM_DECODE_ERROR_SIZE];
    char dispatch_error[VM_DISPATCH_ERROR_SIZE];
    uint32_t old;
    uint32_t n;
    uint32_t i;

    if (!vm || !module) return false;
    decoded = decoded_module_for(vm, module, &valid);
    if (!decoded || !valid || !*valid) {
        if (vm->frame_count != 0) {
            vm_error(vm, VM_ERR_DECODE,
                     "Cannot rebuild a module while a function is executing");
            return false;
        }
        return vm_rebuild_module(vm, module);
    }
    if (decoded->function_count >= module->function_count) return true;
    vm_note_module_change(vm);

    old = decoded->function_count;
    n = module->function_count;
    dispatch = dispatch_module_for(vm, module, &dispatch_valid);
    if (dispatch && dispatch_valid && *dispatch_valid
            && dispatch->function_count != old) {
        vm_error(vm, VM_ERR_DECODE,
                 "Decoded and dispatch function counts drifted");
        return false;
    }

    decoded_fns = realloc(decoded->functions, (size_t)n * sizeof(*decoded_fns));
    if (!decoded_fns) {
        vm_error(vm, VM_ERR_MEMORY, "Failed to grow decoded functions");
        return false;
    }
    memset(decoded_fns + old, 0, (size_t)(n - old) * sizeof(*decoded_fns));
    decoded->functions = decoded_fns;

    for (i = old; i < n; i++) {
        if (!vm_decode_function(module, i, &decoded->functions[i], decode_error)) {
            uint32_t j;
            for (j = old; j < i; j++)
                vm_decoded_function_free(&decoded->functions[j]);
            vm_error(vm, VM_ERR_DECODE, "%s", decode_error);
            return false;
        }
    }

    if (dispatch && dispatch_valid && *dispatch_valid) {
        dispatch_fns = realloc(dispatch->functions,
                               (size_t)n * sizeof(*dispatch_fns));
        if (!dispatch_fns) {
            for (i = old; i < n; i++)
                vm_decoded_function_free(&decoded->functions[i]);
            vm_error(vm, VM_ERR_MEMORY, "Failed to grow dispatch functions");
            return false;
        }
        memset(dispatch_fns + old, 0, (size_t)(n - old) * sizeof(*dispatch_fns));
        dispatch->functions = dispatch_fns;
        for (i = old; i < n; i++) {
            if (!vm_dispatch_build_function(&decoded->functions[i],
                                            vm->dispatch_profile,
                                            &dispatch->functions[i],
                                            dispatch_error)) {
                uint32_t j;
                for (j = old; j < i; j++)
                    vm_dispatch_function_free(&dispatch->functions[j]);
                for (j = old; j < n; j++)
                    vm_decoded_function_free(&decoded->functions[j]);
                vm_error(vm, VM_ERR_DECODE, "%s", dispatch_error);
                return false;
            }
        }
        dispatch->function_count = n;
    }

    decoded->function_count = n;
    constants = module_constants_for(vm, module);
    if (constants && !vm_module_constants_append(vm, module, constants)) {
        vm_error(vm, VM_ERR_MEMORY, "Module constant append failed");
        return false;
    }

    if (vm->module_calls_resolved) {
        for (i = old; i < n; i++) {
            vm_resolve_function_calls(vm, &decoded->functions[i],
                (dispatch && dispatch_valid && *dispatch_valid)
                    ? &dispatch->functions[i] : NULL);
        }
    }
    vm_recompute_verified(vm);
    vm->last_error = VM_OK;
    vm->error_msg[0] = '\0';
    return true;
}

void vm_request_halt(VmState *vm) {
    if (vm) vm->halt_requested = true;
}

/* Bind one function's cross-module calls to callable handles.
 * Every OP_CALL_MODULE (module index, function index) operand pair is
 * resolved once against the linked-module table, so dispatch follows a
 * direct module/function pointer instead of re-indexing the tables and
 * repeating bounds checks on every call. An out-of-range pair leaves the
 * handle unresolved; dispatch then traps, preserving the prior behavior. */
static void vm_resolve_function_calls(VmState *vm, VmDecodedFunction *function,
                                      VmDispatchFunction *dispatch) {
    for (uint32_t i = 0; i < function->instruction_count; i++) {
        VmDecodedInstruction *decoded = &function->instructions[i];
        if (decoded->instruction.opcode != OP_CALL_MODULE) continue;

        VmCallHandle *handle = &decoded->call_handle;
        handle->module = NULL;
        handle->function = NULL;
        handle->function_index = 0;
        handle->resolved = false;

        uint32_t mod_idx = decoded->instruction.operands[0].u32;
        uint32_t fn_idx  = decoded->instruction.operands[1].u32;
        if (mod_idx >= vm->linked_module_count) continue;

        const NvmModule *target = vm->linked_modules[mod_idx];
        if (!target || fn_idx >= target->function_count) continue;

        handle->module = target;
        handle->function = &target->functions[fn_idx];
        handle->function_index = fn_idx;
        handle->resolved = true;

        if (dispatch && i < dispatch->instruction_count)
            dispatch->instructions[i].call_handle = *handle;
    }
}

bool vm_resolve_module_calls(VmState *vm) {
    if (!vm) return false;
    if (vm->module_calls_resolved) return true;

    if (vm->decoded_module_valid) {
        for (uint32_t f = 0; f < vm->decoded_module.function_count; f++)
            vm_resolve_function_calls(vm, &vm->decoded_module.functions[f],
                vm->dispatch_module_valid ? &vm->dispatch_module.functions[f] : NULL);
    }
    for (uint32_t m = 0; m < vm->linked_module_count; m++) {
        if (!vm->decoded_linked_modules_valid[m]) continue;
        VmDecodedModule *dm = &vm->decoded_linked_modules[m];
        for (uint32_t f = 0; f < dm->function_count; f++)
            vm_resolve_function_calls(vm, &dm->functions[f],
                vm->dispatch_linked_modules_valid[m]
                    ? &vm->dispatch_linked_modules[m].functions[f] : NULL);
    }

    vm->module_calls_resolved = true;
    return true;
}

/* ========================================================================
 * Stack Operations
 * ======================================================================== */

static VmResult stack_reserve(VmState *vm, uint64_t required) {
    if (required > UINT32_MAX || required > SIZE_MAX / sizeof(NanoValue))
        return vm_error(vm, VM_ERR_MEMORY, "I cannot represent the requested stack size.");
    if (required > vm->stack_capacity || (!vm->stack && required)) {
        uint64_t new_cap = vm->stack_capacity ? vm->stack_capacity : VM_STACK_INITIAL;
        while (new_cap < required) new_cap *= 2;
        if (new_cap > UINT32_MAX || new_cap > SIZE_MAX / sizeof(NanoValue))
            new_cap = required;
        NanoValue *new_stack = realloc(vm->stack, (size_t)new_cap * sizeof(NanoValue));
        if (!new_stack) return vm_error(vm, VM_ERR_MEMORY, "I could not grow the stack.");
        vm->stack = new_stack;
        vm->stack_capacity = (uint32_t)new_cap;
    }
    return VM_OK;
}

static inline VmResult stack_push(VmState *vm, NanoValue v) {
    VmResult result = stack_reserve(vm, (uint64_t)vm->stack_size + 1);
    if (result != VM_OK) return result;
    vm->stack[vm->stack_size++] = v;
    return VM_OK;
}

static VmResult stack_reserve_frame(VmState *vm, uint32_t base,
                                    const NvmFunctionEntry *callee) {
    if (callee->local_count < callee->arity)
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need enough callee parameter locals.");
    return stack_reserve(vm, (uint64_t)base + callee->local_count);
}

/* Unchecked private handlers.
 *
 * These skip the operand-stack bounds guards. They are sound only for a
 * verified program: nvm_verify()'s verify_stack_heights() infers the stack
 * height at every reachable instruction and rejects any function that could
 * underflow, so a pop/peek the verifier accepted can never touch below the
 * base. vm->verified records that proof; the checked wrappers below route to
 * these handlers only when it holds and fall back to the guarded path
 * otherwise (e.g. an embedder that ran the VM without verifying). */
static inline NanoValue stack_pop_unchecked(VmState *vm) {
    return vm->stack[--vm->stack_size];
}

static inline NanoValue stack_peek_unchecked(VmState *vm, uint32_t offset) {
    return vm->stack[vm->stack_size - 1 - offset];
}

static inline NanoValue stack_pop(VmState *vm) {
    if (vm->verified) return stack_pop_unchecked(vm);
    if (vm->stack_size == 0) return val_void();
    return vm->stack[--vm->stack_size];
}

static inline NanoValue stack_peek(VmState *vm, uint32_t offset) {
    if (vm->verified) return stack_peek_unchecked(vm, offset);
    if (offset >= vm->stack_size) return val_void();
    return vm->stack[vm->stack_size - 1 - offset];
}

/* Locals and the caller's stack are not operands of the current frame. */
/* Handler locals alias their lexical frame; arm parameters and temporaries
 * live in the activation itself so recursive performs cannot overwrite them. */
static uint32_t effect_local_index(VmState *vm, VmCallFrame *frame, uint16_t index) {
    while (frame->effect_owner && index < frame->effect_local_start)
        frame = &vm->frames[frame->effect_owner - 1];
    return frame->stack_base + index;
}

static void effect_prune(VmState *vm, uint32_t frame_count) {
    while (vm->handler_count && vm->handlers[vm->handler_count - 1].owner >= frame_count)
        vm->handler_count--;
}

static inline bool stack_has_operands(const VmState *vm, uint32_t count) {
    if (vm->verified) return true;
    uint32_t base = 0;
    if (vm->frame_count) {
        const VmCallFrame *frame = &vm->frames[vm->frame_count - 1];
        base = frame->stack_base + frame->local_count;
    }
    return vm->stack_size >= base && vm->stack_size - base >= count;
}

static inline void profile_instruction(VmState *vm, uint8_t opcode) {
    VmProfile *p = &vm->profile;
    if (!p->enabled) return;

    p->retired++;
    p->opcode_counts[opcode]++;
    if (p->has_previous) {
        uint16_t pair = (uint16_t)(((uint16_t)p->previous << 8) | opcode);
        p->pair_counts[pair]++;
        if (p->has_previous_pair) {
            uint32_t key = ((uint32_t)p->previous_pair << 8) | opcode;
            uint32_t slot = (key * 2654435761U) % VM_PROFILE_TRIPLES;
            for (uint32_t probe = 0; probe < VM_PROFILE_TRIPLES; probe++) {
                VmProfileTriple *entry = &p->triples[slot];
                if (!entry->used || entry->key == key) {
                    entry->used = true;
                    entry->key = key;
                    entry->count++;
                    break;
                }
                slot = (slot + 1) % VM_PROFILE_TRIPLES;
            }
        }
        p->previous_pair = pair;
        p->has_previous_pair = true;
    }
    p->previous = opcode;
    p->has_previous = true;
    if (vm->stack_size > p->max_stack_depth)
        p->max_stack_depth = vm->stack_size;
    if (vm->frame_count > p->max_frame_depth)
        p->max_frame_depth = vm->frame_count;
}

void vm_profile_enable(VmState *vm, bool enabled) {
    if (!vm) return;
    memset(&vm->profile, 0, sizeof(vm->profile));
    vm->profile.enabled = enabled;
}

void vm_set_dispatch_profile(VmState *vm, VmDispatchProfile profile) {
    if (!vm) return;
    vm->dispatch_profile = profile;
}

bool vm_profile_write_json(const VmState *vm, FILE *out) {
    if (!vm || !out) return false;
    const VmProfile *p = &vm->profile;
    fprintf(out, "{\n  \"schema\": \"nanoisa.profile.v1\",\n");
    fprintf(out, "  \"retired\": %llu,\n", (unsigned long long)p->retired);
    fprintf(out, "  \"max_stack_depth\": %u,\n", p->max_stack_depth);
    fprintf(out, "  \"max_frame_depth\": %u,\n", p->max_frame_depth);
    fprintf(out, "  \"branches\": %llu,\n", (unsigned long long)p->branches);
    fprintf(out, "  \"branches_taken\": %llu,\n",
            (unsigned long long)p->branches_taken);
    fprintf(out, "  \"calls\": {\"direct\": %llu, \"indirect\": %llu, "
                 "\"extern\": %llu, \"module\": %llu},\n",
            (unsigned long long)p->direct_calls,
            (unsigned long long)p->indirect_calls,
            (unsigned long long)p->extern_calls,
            (unsigned long long)p->module_calls);
    fprintf(out, "  \"traps\": %llu,\n", (unsigned long long)p->traps);
    fprintf(out, "  \"heap\": {\"allocation_calls\": %llu, "
                 "\"allocated_bytes\": %llu, \"freed_bytes\": %llu, "
                 "\"live_objects\": %llu, \"retain_calls\": %llu, "
                 "\"release_calls\": %llu},\n",
            (unsigned long long)vm->heap.stats.allocation_calls,
            (unsigned long long)vm->heap.stats.allocated,
            (unsigned long long)vm->heap.stats.freed,
            (unsigned long long)vm->heap.stats.num_objects,
            (unsigned long long)vm->heap.stats.retain_calls,
            (unsigned long long)vm->heap.stats.release_calls);
    fprintf(out, "  \"ffi\": {\"request_bytes\": %llu, "
                 "\"response_bytes\": %llu, \"elapsed_ns\": %llu, "
                 "\"failures\": %llu},\n",
            (unsigned long long)p->ffi_request_bytes,
            (unsigned long long)p->ffi_response_bytes,
            (unsigned long long)p->ffi_elapsed_ns,
            (unsigned long long)p->ffi_failures);

    fprintf(out, "  \"opcodes\": {");
    bool first = true;
    for (uint32_t i = 0; i < 256; i++) {
        if (p->opcode_counts[i] == 0) continue;
        fprintf(out, "%s\n    \"0x%02x\": %llu", first ? "" : ",", i,
                (unsigned long long)p->opcode_counts[i]);
        first = false;
    }
    fprintf(out, "%s\n  },\n", first ? "" : "");

    fprintf(out, "  \"pairs\": {");
    first = true;
    for (uint32_t i = 0; i < 256U * 256U; i++) {
        if (p->pair_counts[i] == 0) continue;
        fprintf(out, "%s\n    \"%02x-%02x\": %llu", first ? "" : ",",
                i >> 8, i & 0xff,
                (unsigned long long)p->pair_counts[i]);
        first = false;
    }
    fprintf(out, "%s\n  },\n", first ? "" : "");

    fprintf(out, "  \"triples\": {");
    first = true;
    for (uint32_t i = 0; i < VM_PROFILE_TRIPLES; i++) {
        const VmProfileTriple *entry = &p->triples[i];
        if (!entry->used) continue;
        fprintf(out, "%s\n    \"%02x-%02x-%02x\": %llu",
                first ? "" : ",", (entry->key >> 16) & 0xff,
                (entry->key >> 8) & 0xff, entry->key & 0xff,
                (unsigned long long)entry->count);
        first = false;
    }
    fprintf(out, "%s\n  }\n}\n", first ? "" : "");
    return !ferror(out);
}

/* ========================================================================
 * Helper: output stream
 * ======================================================================== */

static inline FILE *vm_out(VmState *vm) {
    return vm->output ? vm->output : stdout;
}

static void vm_trace_value(const char *label, NanoValue value) {
    const char *tag = isa_tag_name(value.tag);
    if (value.tag == TAG_STRING && value.as.string) {
        fprintf(stderr, " %s={tag=%s ptr=%p len=%u text=\"%s\"}",
                label, tag ? tag : "?", (void *)value.as.string,
                value.as.string->length, vmstring_cstr(value.as.string));
    } else {
        fprintf(stderr, " %s={tag=%s raw=%lld ptr=%p}", label,
                tag ? tag : "?", (long long)value.as.i64, value.as.obj);
    }
}

static void vm_trace_instruction(const VmState *vm, uint32_t offset,
                                 const DecodedInstruction *instr,
                                 uint32_t stack_before) {
    const NvmFunctionEntry *fn = &vm->module->functions[vm->current_fn];
    const char *name = nvm_get_string(vm->module, fn->name_idx);
    const InstructionInfo *info = isa_get_info(instr->opcode);
    fprintf(stderr, "[nanovm] fn=%u(%s) off=%u op=%s stack=%u",
            vm->current_fn, name ? name : "?", offset,
            info && info->name ? info->name : "UNKNOWN", stack_before);
    for (uint32_t i = 0; i < stack_before && i < 4; i++) {
        vm_trace_value("top", vm->stack[stack_before - 1 - i]);
    }
    fputc('\n', stderr);
}

static void vm_trace_ffi_result(const VmState *vm, uint32_t import_idx,
                                NanoValue result) {
    if (import_idx >= vm->module->import_count) return;
    const NvmImportEntry *imp = &vm->module->imports[import_idx];
    const char *name = nvm_get_string(vm->module, imp->function_name_idx);
    fprintf(stderr, "[nanovm] ffi import=%u name=%s return=%s",
            import_idx, name ? name : "?", isa_tag_name(result.tag));
    vm_trace_value("result", result);
    fputc('\n', stderr);
}

static bool result_tag_matches(uint8_t declared, uint8_t actual) {
    /* TAG_VOID with results is reserved for untyped in-memory embedders. */
    if (declared == TAG_VOID) return true;
    if (declared == TAG_FUNCTION)
        return actual == TAG_FUNCTION || actual == TAG_CLOSURE;
    return declared == actual;
}

/* ========================================================================
 * Execution Engine
 * ======================================================================== */

/* Length-aware substring search within raw byte buffers. Honors the
 * provided lengths and therefore matches correctly across embedded zero
 * bytes. Returns a pointer to the first match, or NULL when absent. */
static const char *vm_mem_find(const char *hay, size_t hlen,
                               const char *needle, size_t nlen) {
    if (nlen == 0) return hay;
    if (nlen > hlen) return NULL;
    for (size_t i = 0; i <= hlen - nlen; i++) {
        if (memcmp(hay + i, needle, nlen) == 0) return hay + i;
    }
    return NULL;
}
NanoValue vm_get_result(VmState *vm) {
    if (vm->stack_size == 0) return val_void();
    return vm->stack[vm->stack_size - 1];
}

/* ========================================================================
 * Trap helpers
 * ======================================================================== */

static inline VmTrap trap_none(void) {
    return (VmTrap){ .type = TRAP_NONE };
}

static inline VmTrap trap_halt(void) {
    return (VmTrap){ .type = TRAP_HALT };
}

static VmReferenceActivation *vm_reference_activation(VmState *vm,uint32_t frame) {
    if (!frame) return &vm->references;
    if (frame==1) return &vm->callee_references;
    if(frame<NVM_OWNED_MAX_FUNCTIONS)return &vm->value_references[frame-2];
    return frame<VM_MAX_FRAMES?vm->effect_references[frame-NVM_OWNED_MAX_FUNCTIONS]:NULL;
}
static VmReferenceActivation *vm_prepare_reference_activation(VmState *vm,uint32_t frame) {
    if(frame>=VM_MAX_FRAMES)return NULL;
    if(frame>=NVM_OWNED_MAX_FUNCTIONS && !vm->effect_references[frame-NVM_OWNED_MAX_FUNCTIONS])
        vm->effect_references[frame-NVM_OWNED_MAX_FUNCTIONS]=calloc(1,sizeof(VmReferenceActivation));
    return vm_reference_activation(vm,frame);
}
static void vm_end_reference_activation(VmState *vm,uint32_t frame) {
    if(frame>=VM_MAX_FRAMES)return;
    if(frame>=NVM_OWNED_MAX_FUNCTIONS) {
        free(vm->effect_references[frame-NVM_OWNED_MAX_FUNCTIONS]);
        vm->effect_references[frame-NVM_OWNED_MAX_FUNCTIONS]=NULL;
    } else {
        VmReferenceActivation *context=vm_reference_activation(vm,frame);
        memset(context,0,sizeof(*context));
    }
}
static void vm_clear_reference_activations(VmState *vm) {
    memset(&vm->references,0,sizeof(vm->references));
    memset(&vm->callee_references,0,sizeof(vm->callee_references));
    memset(vm->value_references,0,sizeof(vm->value_references));
    for(uint32_t frame=NVM_OWNED_MAX_FUNCTIONS;frame<VM_MAX_FRAMES;frame++)
        vm_end_reference_activation(vm,frame);
}

static inline VmTrap trap_error(VmState *vm, VmResult err, const char *fmt, ...) {
    vm_clear_reference_activations(vm);
    vm->last_error = err;
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(vm->error_msg, sizeof(vm->error_msg), fmt, ap);
    va_end(ap);
    VmTrap t = { .type = TRAP_ERROR };
    t.data.error.code = err;
    return t;
}

/* ========================================================================
 * Dispatch strategy
 *
 * Two ways to get from an opcode to its handler, written from one copy of the
 * handlers. The portable form is a switch. Where the compiler supports labels
 * as values -- GCC and Clang -- each handler instead jumps straight to the
 * next one, so the processor sees a separate indirect branch per opcode rather
 * than a single shared branch it has little hope of predicting.
 *
 * One copy is the point. A dispatch rewrite that duplicates 161 handlers grows
 * a bug that only one of the copies has, and the bug is silent because both
 * copies still compile and most programs exercise neither difference.
 * VM_CASE and VM_NEXT are the entire difference here.
 *
 * The failure mode to fear is a missing VM_NEXT: control would fall out of one
 * handler into the next, producing wrong answers rather than a crash. In the
 * threaded build there is no loop around the handlers, so a `break` left
 * behind by the conversion is a compile error rather than a silent exit from
 * the interpreter -- which is what makes the conversion checkable rather than
 * merely careful.
 * ======================================================================== */

#if defined(__GNUC__) && !defined(NANO_NO_COMPUTED_GOTO)
#  define NANO_COMPUTED_GOTO 1
#endif

#ifdef NANO_COMPUTED_GOTO
#  define VM_DISPATCH_BEGIN(op)  goto *vm_labels[(uint8_t)(op)];
#  define VM_CASE(name)          L_##name:
#  define VM_DEFAULT             L_vm_default:
#  define VM_NEXT()              goto vm_dispatch_top
#  define VM_DISPATCH_END()
#else
#  define VM_DISPATCH_BEGIN(op)  switch (op) {
#  define VM_CASE(name)          case name:
#  define VM_DEFAULT             default:
#  define VM_NEXT()              break
#  define VM_DISPATCH_END()      }
#endif

/* ========================================================================
 * Core Execution Engine (the "processor")
 *
 * Runs pure NanoISA instructions.  Returns a VmTrap when it hits an
 * external operation (I/O, FFI, halt) or completes / errors.
 * ======================================================================== */

/* I reserve every staged argument retain before dropping any frame root.
 * Duplicate heap arguments consume cumulative headroom, not one retain each
 * against the same unchanged counter. This helper never mutates an owner. */
static VmResult vm_tail_arguments_preflight(VmState *vm,const NvmFunctionEntry *callee,uint32_t target) {
    if(!stack_has_operands(vm,callee->arity))return VM_ERR_STACK_UNDERFLOW;
    for(uint16_t i=0;i<callee->arity;i++) {
        NanoValue value=stack_peek(vm,callee->arity-1-i);
        if(vm->module->function_param_types && vm->module->function_param_types[target]) {
            uint8_t tag=vm->module->function_param_types[target][i];
            if(tag!=TAG_VOID && value.tag!=tag)return VM_ERR_TYPE_ERROR;
        }
        if(val_is_heap_obj(value)) {
            if(!value.as.obj)return VM_ERR_TYPE_ERROR;
            uint32_t copies=0;
            for(uint16_t j=0;j<callee->arity;j++) {
                NanoValue other=stack_peek(vm,j);
                if(val_is_heap_obj(other) && other.as.obj==value.as.obj)copies++;
            }
            if(((VmHeapHeader *)value.as.obj)->ref_count>UINT32_MAX-copies)return VM_ERR_MEMORY;
        }
    }
    return VM_OK;
}
/* I protect array-owner retains on the actual selected ordinary route as well
 * as the independent private runner. Nested slice children may share owners;
 * I count duplicates only near saturation, keeping normal slices linear. */
static VmResult vm_record_array_retain_preflight(VmState *vm,VmCallFrame *frame,
                                                const VmDispatchInstruction *decoded) {
    const DecodedInstruction *in=&decoded->instruction;NanoValue retained=val_void();
    switch(in->opcode) {
    case OP_PUSH_STR:
        if(in->operands[0].u32>=vm->module_constants.count)return VM_ERR_OUT_OF_BOUNDS;
        retained=val_string(vm->module_constants.strings[in->operands[0].u32]);break;
    case OP_LOAD_LOCAL: {
        uint32_t index=effect_local_index(vm,frame,in->operands[0].u16);
        if(index>=vm->stack_size)return VM_ERR_TYPE_ERROR;
        retained=vm->stack[index];
        if(decoded->super_op==VM_SUPER_LOAD_LOCAL_FIELD) {
            if(retained.tag!=TAG_STRUCT || !retained.as.sval || decoded->super_operand>=retained.as.sval->field_count)return VM_ERR_TYPE_ERROR;
            retained=retained.as.sval->fields[decoded->super_operand];
        }
        break;
    }
    case OP_LOAD_GLOBAL:
        if(in->operands[0].u32>=vm->global_capacity)return VM_ERR_OUT_OF_BOUNDS;
        retained=vm->globals[in->operands[0].u32];break;
    case OP_DUP:case OP_ARR_PUSH:retained=stack_peek(vm,0);break;
    case OP_AGG_GET: {
        NanoValue owner=stack_peek(vm,0);uint16_t field=in->operands[0].u16;
        if(owner.tag!=TAG_STRUCT || !owner.as.sval || field>=owner.as.sval->field_count)return VM_ERR_TYPE_ERROR;
        retained=owner.as.sval->fields[field];break;
    }
    case OP_ARR_GET: {
        NanoValue owner=stack_peek(vm,1),index=stack_peek(vm,0);
        if(owner.tag!=TAG_ARRAY || !owner.as.array || index.tag!=TAG_INT)return VM_ERR_TYPE_ERROR;
        if(index.as.i64>=0 && (uint64_t)index.as.i64<owner.as.array->length)
            retained=vm_array_get(owner.as.array,(uint32_t)index.as.i64);
        break;
    }
    case OP_ARR_SLICE: {
        NanoValue owner=stack_peek(vm,2),first=stack_peek(vm,1),last=stack_peek(vm,0);
        if(owner.tag!=TAG_ARRAY || !owner.as.array)return VM_ERR_TYPE_ERROR;
        VmArray *a=owner.as.array;if(a->elem_type!=TAG_ARRAY && a->elem_type!=TAG_STRING)break;
        uint32_t start=first.tag==TAG_INT?(uint32_t)first.as.i64:0;
        uint32_t end=last.tag==TAG_INT?(uint32_t)last.as.i64:a->length;
        if(start>a->length)start=a->length;
        if(end>a->length)end=a->length;
        if(end<=start)break;
        for(uint32_t i=start;i<end;i++) {
            NanoValue child=a->elements[i];
            if(child.tag!=a->elem_type || !child.as.obj)return VM_ERR_TYPE_ERROR;
            uint32_t references=((VmHeapHeader *)child.as.obj)->ref_count;
            if(references>UINT32_MAX-(end-start)) {
                uint32_t copies=0;
                for(uint32_t j=start;j<end;j++)if(a->elements[j].as.obj==child.as.obj)copies++;
                if(references>UINT32_MAX-copies)return VM_ERR_MEMORY;
            }
        }
        break;
    }
    default:break;
    }
    if(retained.tag==TAG_ARRAY || retained.tag==TAG_STRING) {
        if(!retained.as.obj)return VM_ERR_TYPE_ERROR;
        if(((VmHeapHeader *)retained.as.obj)->ref_count==UINT32_MAX)return VM_ERR_MEMORY;
    }
    return VM_OK;
}
/* I check the actual next retain before the unchanged shared handler commits
 * it. A fused field load retains the field, not its containing shell. */
static VmResult vm_owned_array_preflight(VmState *vm,VmCallFrame *frame,
                                         const VmDispatchInstruction *decoded) {
    const DecodedInstruction *in=&decoded->instruction;
    NanoValue retained=val_void();
    switch(in->opcode) {
    case OP_PUSH_STR: {
        uint32_t index=in->operands[0].u32;
        if(index>=vm->module_constants.count || !vm->module_constants.strings[index])return VM_ERR_TYPE_ERROR;
        retained=val_string(vm->module_constants.strings[index]);break;
    }
    case OP_LOAD_LOCAL: {
        uint32_t index=effect_local_index(vm,frame,in->operands[0].u16);
        if(index>=vm->stack_size)return VM_ERR_TYPE_ERROR;
        retained=vm->stack[index];
        if(decoded->super_op==VM_SUPER_LOAD_LOCAL_FIELD) {
            frame->instruction_ip += in->byte_length;
            if(retained.tag!=TAG_STRUCT || !retained.as.sval || decoded->super_operand>=retained.as.sval->field_count)return VM_ERR_TYPE_ERROR;
            retained=retained.as.sval->fields[decoded->super_operand];
        }
        break;
    }
    case OP_DUP:retained=stack_peek(vm,0);break;
    case OP_AGG_GET: {
        NanoValue owner=stack_peek(vm,0);uint16_t field=in->operands[0].u16;
        if(owner.tag!=TAG_STRUCT || !owner.as.sval || field>=owner.as.sval->field_count)return VM_ERR_TYPE_ERROR;
        retained=owner.as.sval->fields[field];break;
    }
    case OP_F64_EQ:case OP_F64_NE:case OP_F64_LT:case OP_F64_LE:case OP_F64_GT:case OP_F64_GE:
        if(stack_peek(vm,0).tag!=TAG_FLOAT || stack_peek(vm,1).tag!=TAG_FLOAT)return VM_ERR_TYPE_ERROR;
        break;
    case OP_PRINT:case OP_PRINTLN:
        if(stack_peek(vm,0).tag!=TAG_INT)return VM_ERR_TYPE_ERROR;
        break;
    default:break;
    }
    if(val_is_heap_obj(retained)) {
        if(!retained.as.obj)return VM_ERR_TYPE_ERROR;
        if(((VmHeapHeader *)retained.as.obj)->ref_count==UINT32_MAX)return VM_ERR_MEMORY;
    }
    return VM_OK;
}

#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
#include "record_array_vm_prepare.inc"
#endif
#include "record_map_common.inc"
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
#include "union_field_vm_prepare.inc"
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_PREPARATION
#include "record_map_vm_prepare.inc"
#endif

typedef struct VmRecordMapBorrowedInvocation VmRecordMapBorrowedInvocation;
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
#include "record_map_vm_context.inc"
#endif
#include "record_map_borrowed_types.inc"
#include "record_map_borrowed_context.inc"
typedef struct VmUnionFieldInvocation VmUnionFieldInvocation;
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
#include "union_field_vm_context.inc"
#endif
static VmTrap vm_core_execute_union(VmState *vm, const VmOwnedInvocationProof *proof,
                                      VmOrdinaryAdmission *ordinary,VmRecordArrayPrivate *record_array,
                                      VmRecordMapInvocation *record_map,VmRecordMapBorrowedInvocation *borrowed_map,uint8_t map_value_tag,
                                      VmUnionFieldInvocation *union_field) {
    bool union_execution=false;
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
    if(union_field) {
        if(proof || ordinary || record_array || record_map || borrowed_map || map_value_tag!=TAG_VOID ||
           !vm_uf_context(union_field,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require this exact private union invocation.");
        union_execution=true;
    }
#else
    if(union_field)return trap_error(vm,VM_ERR_TYPE_ERROR,"I have no private union runtime.");
#endif
    VmOwnedInvocationProof resumed;
    bool admitted=false, required=false;
    bool reuse=vm_ordinary_admission_matches(vm,ordinary);
    bool record_execution=false,map_execution=false,borrowed_map_execution=false;
    if((record_map || borrowed_map) && map_value_tag!=TAG_INT && map_value_tag!=TAG_STRING)
        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require an independent exact map pair.");
    if(borrowed_map) {
        if(record_map || record_array || ordinary || proof || !vm_rmb_context(borrowed_map,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require this exact borrowed map invocation.");
        borrowed_map_execution=true;
    }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
    if(record_map) {
        if(record_array || ordinary || proof || !vm_rmx_context(record_map,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require this exact closed private map invocation.");
        map_execution=true;
    }
#else
    if(record_map)return trap_error(vm,VM_ERR_TYPE_ERROR,"I have no private map runtime.");
#endif
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
    if(record_array) {
        if(!vm_ra_context(record_array,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require this exact private ordinary instance.");
        record_execution=true;
    }
#else
    (void)record_array;
#endif
    if (ordinary) ordinary->valid=false;
    if (!reuse && !record_execution && !map_execution && !borrowed_map_execution && !union_execution) {
        /* These service facts expire at the end of this classification block.
         * No host callback or bytecode dispatch occurs while they are live. */
        NvmServiceClassification service;
        const NvmServiceClassification *facts=NULL;
        if (vm && vm->module) {
            service=vm_invocation_service_classify(vm,vm->module,ordinary);
            facts=&service;
        }
        if(vm && nvm_owned_array_route_classified(vm->module,facts)!=NVM_OWNER_ARRAY_NOT_SELECTED && !vm_owned_proof_matches(vm,proof))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a synchronous owner ARRAY root invocation before execution.");
        if(vm && nvm_mixed_samples_candidate_classified(vm->module,facts) && !vm_owned_proof_matches(vm,proof)) {
            if(!vm_mixed_invocation_prepare(vm,&resumed,true))
                return trap_error(vm,resumed.refusal?resumed.refusal:VM_ERR_TYPE_ERROR,"%s",
                                  resumed.reason?resumed.reason:VM_OWNERSHIP_REQUIRED);
            proof=&resumed;
        }
        admitted=vm_owned_proof_matches(vm,proof);
        if (admitted && proof->owner_arrays) {
            required=true;
            if(!vm_owned_constants_ready(vm))return trap_error(vm,VM_ERR_TYPE_ERROR,"I require complete owner ARRAY constants.");
        } else if (!vm_owned_runtime_ready_scoped(vm,&required,facts))
            return trap_error(vm, VM_ERR_TYPE_ERROR, "%s", VM_OWNERSHIP_REQUIRED);
        if (required && !(admitted && (proof->mixed || proof->owner_arrays))) {
            uint32_t globals=0;
            if (nvm_ownership_globals(vm->module,NULL,0,&globals)!=NVM_V2_OK)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I require complete typed-global declarations.");
            if (globals && (!proof || proof->global_module!=vm->module || proof->global_count!=globals))
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a scoped typed-global entry invocation.");
        }
        if (!admitted && !vm_ownership_supported_scoped(vm,facts))
            return trap_error(vm, VM_ERR_TYPE_ERROR, "%s", VM_OWNERSHIP_REQUIRED);
    }
    if(admitted && proof->ordinary_arrays) {
        if(!vm->frame_count || vm->frame_count>VM_MAX_FRAMES ||
           !proof->ordinary_active_root || vm->frames[0].fn_idx!=*proof->ordinary_active_root)
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require the admitted record-array root activation.");
        for(uint32_t i=0;i<vm->frame_count;i++)if(vm->frames[i].module!=proof->module)
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require standalone record-array frames.");
    }
    const bool owned_execution = (admitted && !proof->ordinary_arrays) || required;
    const bool mixed_execution = admitted && (proof->mixed || proof->owner_arrays);
    if (owned_execution) {
        if (!vm->frame_count || vm->frame_count>VM_MAX_FRAMES ||
            vm->frames[0].fn_idx!=0)
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a bounded standalone owned activation");
        for (uint32_t i=0;i<vm->frame_count;i++) {
            VmReferenceActivation *context=vm_reference_activation(vm,i);
            if (vm->frames[i].module!=vm->module ||
                ((i || vm->references.active) && (!context || !context->active)))
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I require each active owned frame context");
        }
        if (!vm->references.active) {
            if (vm->frame_count!=1 || vm->current_fn!=0 || vm->ip!=vm->module->functions[0].code_offset)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need reference activation entry before resuming");
            memset(&vm->references,0,sizeof(vm->references));
            vm->references.active=true;
            if (vm->reference_generation==UINT64_MAX)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I exhausted reference activation identities");
            vm->references.generation=++vm->reference_generation;
        }
    }
    /* Only ordinary classification is reused. The owned frame/reference
     * checks above and all dispatch/stack checks below remain on every entry.
     * Ordinary CALL/RET/effect transitions do not change module declarations. */
    if (ordinary && !record_execution && !map_execution && !borrowed_map_execution && !union_execution && !admitted && !required && vm_ordinary_admission_eligible(vm)) {
        ordinary->vm=vm;
        ordinary->module=vm->module;
        ordinary->valid=true;
    }
    /* Derive code_end from current function */
    const NvmFunctionEntry *cur_fn = &vm->module->functions[vm->current_fn];
    uint32_t code_end = cur_fn->code_offset + cur_fn->code_length;

    VmCallFrame *frame = &vm->frames[vm->frame_count - 1];

    /* The VM executes the optimized dispatch IR (representation 3), a
     * projection of the verified instruction IR (representation 2).  The
     * linear path advances the cursor by a precomputed instruction index;
     * the byte-offset map is consulted only to re-enter the stream after a
     * jump, a call, or a return. */
    VmDispatchCursor cursor = {0};
    uint32_t cursor_offset = UINT32_MAX;
    uint32_t callback_budget = 1024;

#ifdef NANO_COMPUTED_GOTO
    /* One entry per opcode, defaulting to the same handler the switch's
     * `default` uses. Filled once: the values are compile-time constants, so
     * two VMs racing to fill it write identical pointers.
     *
     * An opcode with a handler but no entry here would dispatch to the
     * default and be reported as unknown -- a working instruction that stops
     * working, and only in this build.
     * test_computed_goto_table_matches_the_handlers compares this list against
     * the VM_CASE labels in the source, which is the only place that drift is
     * visible: the table is a function-local static no test can read. */
    static void *vm_labels[256];
    if (vm_labels[OP_NOP] == NULL) {
        for (int label_index = 0; label_index < 256; label_index++)
            vm_labels[label_index] = &&L_vm_default;
        vm_labels[OP_BORROW_PATH_SHARED] = &&L_OP_BORROW_PATH_SHARED;
        vm_labels[OP_BORROW_PATH_EXCLUSIVE] = &&L_OP_BORROW_PATH_EXCLUSIVE;
        vm_labels[OP_CALL_REF] = &&L_OP_CALL_REF;
        vm_labels[OP_REBORROW_SHARED] = &&L_OP_REBORROW_SHARED;
        vm_labels[OP_REBORROW_EXCLUSIVE] = &&L_OP_REBORROW_EXCLUSIVE;
        vm_labels[OP_REGION_BEGIN] = &&L_OP_REGION_BEGIN;
        vm_labels[OP_REGION_END] = &&L_OP_REGION_END;
        vm_labels[OP_BORROW_LOCAL_SHARED] = &&L_OP_BORROW_LOCAL_SHARED;
        vm_labels[OP_BORROW_LOCAL_EXCLUSIVE] = &&L_OP_BORROW_LOCAL_EXCLUSIVE;
        vm_labels[OP_REF_GET] = &&L_OP_REF_GET;
        vm_labels[OP_REF_SET] = &&L_OP_REF_SET;
        vm_labels[OP_NOP] = &&L_OP_NOP;
        vm_labels[OP_OWN_MOVE_LOCAL] = &&L_OP_OWN_MOVE_LOCAL;
        vm_labels[OP_OWN_STORE_LOCAL] = &&L_OP_OWN_STORE_LOCAL;
        vm_labels[OP_OWN_PACK] = &&L_OP_OWN_PACK;
        vm_labels[OP_OWN_UNPACK_LOCAL] = &&L_OP_OWN_UNPACK_LOCAL;
        vm_labels[OP_PUSH_I64] = &&L_OP_PUSH_I64;
        vm_labels[OP_PUSH_F64] = &&L_OP_PUSH_F64;
        vm_labels[OP_PUSH_BOOL] = &&L_OP_PUSH_BOOL;
        vm_labels[OP_PUSH_STR] = &&L_OP_PUSH_STR;
        vm_labels[OP_PUSH_VOID] = &&L_OP_PUSH_VOID;
        vm_labels[OP_PUSH_U8] = &&L_OP_PUSH_U8;
        vm_labels[OP_FUNCREF] = &&L_OP_FUNCREF;
        vm_labels[OP_DUP] = &&L_OP_DUP;
        vm_labels[OP_POP] = &&L_OP_POP;
        vm_labels[OP_SWAP] = &&L_OP_SWAP;
        vm_labels[OP_ROT3] = &&L_OP_ROT3;
        vm_labels[OP_PICK] = &&L_OP_PICK;
        vm_labels[OP_ROLL] = &&L_OP_ROLL;
        vm_labels[OP_LOAD_LOCAL] = &&L_OP_LOAD_LOCAL;
        vm_labels[OP_STORE_LOCAL] = &&L_OP_STORE_LOCAL;
        vm_labels[OP_LOAD_GLOBAL] = &&L_OP_LOAD_GLOBAL;
        vm_labels[OP_STORE_GLOBAL] = &&L_OP_STORE_GLOBAL;
        vm_labels[OP_LOAD_UPVALUE] = &&L_OP_LOAD_UPVALUE;
        vm_labels[OP_STORE_UPVALUE] = &&L_OP_STORE_UPVALUE;
        vm_labels[OP_ARRAY_ADD] = &&L_OP_ARRAY_ADD;
        vm_labels[OP_ADD] = &&L_OP_ADD;
        vm_labels[OP_ARRAY_SUB] = &&L_OP_ARRAY_SUB;
        vm_labels[OP_SUB] = &&L_OP_SUB;
        vm_labels[OP_ARRAY_MUL] = &&L_OP_ARRAY_MUL;
        vm_labels[OP_MUL] = &&L_OP_MUL;
        vm_labels[OP_ARRAY_DIV] = &&L_OP_ARRAY_DIV;
        vm_labels[OP_DIV] = &&L_OP_DIV;
        vm_labels[OP_MOD] = &&L_OP_MOD;
        vm_labels[OP_NEG] = &&L_OP_NEG;
        vm_labels[OP_I64_ADD] = &&L_OP_I64_ADD;
        vm_labels[OP_I64_SUB] = &&L_OP_I64_SUB;
        vm_labels[OP_I64_MUL] = &&L_OP_I64_MUL;
        vm_labels[OP_I64_DIV_S] = &&L_OP_I64_DIV_S;
        vm_labels[OP_I64_REM_S] = &&L_OP_I64_REM_S;
        vm_labels[OP_I64_NEG] = &&L_OP_I64_NEG;
        vm_labels[OP_F64_ADD] = &&L_OP_F64_ADD;
        vm_labels[OP_F64_SUB] = &&L_OP_F64_SUB;
        vm_labels[OP_F64_MUL] = &&L_OP_F64_MUL;
        vm_labels[OP_F64_DIV] = &&L_OP_F64_DIV;
        vm_labels[OP_F64_NEG] = &&L_OP_F64_NEG;
        vm_labels[OP_EQ] = &&L_OP_EQ;
        vm_labels[OP_NE] = &&L_OP_NE;
        vm_labels[OP_LT] = &&L_OP_LT;
        vm_labels[OP_LE] = &&L_OP_LE;
        vm_labels[OP_GT] = &&L_OP_GT;
        vm_labels[OP_GE] = &&L_OP_GE;
        vm_labels[OP_I64_EQ] = &&L_OP_I64_EQ;
        vm_labels[OP_I64_NE] = &&L_OP_I64_NE;
        vm_labels[OP_I64_LT_S] = &&L_OP_I64_LT_S;
        vm_labels[OP_I64_LE_S] = &&L_OP_I64_LE_S;
        vm_labels[OP_I64_GT_S] = &&L_OP_I64_GT_S;
        vm_labels[OP_I64_GE_S] = &&L_OP_I64_GE_S;
        vm_labels[OP_F64_EQ] = &&L_OP_F64_EQ;
        vm_labels[OP_F64_NE] = &&L_OP_F64_NE;
        vm_labels[OP_F64_LT] = &&L_OP_F64_LT;
        vm_labels[OP_F64_LE] = &&L_OP_F64_LE;
        vm_labels[OP_F64_GT] = &&L_OP_F64_GT;
        vm_labels[OP_F64_GE] = &&L_OP_F64_GE;
        vm_labels[OP_AND] = &&L_OP_AND;
        vm_labels[OP_OR] = &&L_OP_OR;
        vm_labels[OP_NOT] = &&L_OP_NOT;
        vm_labels[OP_BOOL_AND] = &&L_OP_BOOL_AND;
        vm_labels[OP_BOOL_OR] = &&L_OP_BOOL_OR;
        vm_labels[OP_BOOL_NOT] = &&L_OP_BOOL_NOT;
        vm_labels[OP_I64_DIV_U] = &&L_OP_I64_DIV_U;
        vm_labels[OP_I64_REM_U] = &&L_OP_I64_REM_U;
        vm_labels[OP_I64_LT_U] = &&L_OP_I64_LT_U;
        vm_labels[OP_I64_LE_U] = &&L_OP_I64_LE_U;
        vm_labels[OP_I64_GT_U] = &&L_OP_I64_GT_U;
        vm_labels[OP_I64_GE_U] = &&L_OP_I64_GE_U;
        vm_labels[OP_I64_AND] = &&L_OP_I64_AND;
        vm_labels[OP_I64_OR] = &&L_OP_I64_OR;
        vm_labels[OP_I64_XOR] = &&L_OP_I64_XOR;
        vm_labels[OP_I64_SHL] = &&L_OP_I64_SHL;
        vm_labels[OP_I64_SHR_S] = &&L_OP_I64_SHR_S;
        vm_labels[OP_I64_SHR_U] = &&L_OP_I64_SHR_U;
        vm_labels[OP_I64_INVERT] = &&L_OP_I64_INVERT;
        vm_labels[OP_I64_ADD_CARRY] = &&L_OP_I64_ADD_CARRY;
        vm_labels[OP_I64_SUB_BORROW] = &&L_OP_I64_SUB_BORROW;
        vm_labels[OP_I64_MUL_WIDE_S] = &&L_OP_I64_MUL_WIDE_S;
        vm_labels[OP_I64_MUL_WIDE_U] = &&L_OP_I64_MUL_WIDE_U;
        vm_labels[OP_JMP] = &&L_OP_JMP;
        vm_labels[OP_JMP_TRUE] = &&L_OP_JMP_TRUE;
        vm_labels[OP_JMP_FALSE] = &&L_OP_JMP_FALSE;
        vm_labels[OP_CALL] = &&L_OP_CALL;
        vm_labels[OP_TAIL_CALL] = &&L_OP_TAIL_CALL;
        vm_labels[OP_CALL_INDIRECT] = &&L_OP_CALL_INDIRECT;
        vm_labels[OP_HANDLER_PUSH] = &&L_OP_HANDLER_PUSH;
        vm_labels[OP_HANDLER_POP] = &&L_OP_HANDLER_POP;
        vm_labels[OP_PERFORM] = &&L_OP_PERFORM;
        vm_labels[OP_EFFECT_RESUME] = &&L_OP_EFFECT_RESUME;
        vm_labels[OP_RET] = &&L_OP_RET;
        vm_labels[OP_CALL_EXTERN] = &&L_OP_CALL_EXTERN;
        vm_labels[OP_CALL_MODULE] = &&L_OP_CALL_MODULE;
        vm_labels[OP_STR_LEN] = &&L_OP_STR_LEN;
        vm_labels[OP_STR_CONCAT] = &&L_OP_STR_CONCAT;
        vm_labels[OP_STR_SUBSTR] = &&L_OP_STR_SUBSTR;
        vm_labels[OP_STR_CONTAINS] = &&L_OP_STR_CONTAINS;
        vm_labels[OP_STR_EQ] = &&L_OP_STR_EQ;
        vm_labels[OP_STR_CHAR_AT] = &&L_OP_STR_CHAR_AT;
        vm_labels[OP_STR_FROM_INT] = &&L_OP_STR_FROM_INT;
        vm_labels[OP_STR_FROM_FLOAT] = &&L_OP_STR_FROM_FLOAT;
        vm_labels[OP_STR_TRIM] = &&L_OP_STR_TRIM;
        vm_labels[OP_STR_TO_LOWER] = &&L_OP_STR_TO_LOWER;
        vm_labels[OP_STR_TO_UPPER] = &&L_OP_STR_TO_UPPER;
        vm_labels[OP_STR_STARTS_WITH] = &&L_OP_STR_STARTS_WITH;
        vm_labels[OP_STR_ENDS_WITH] = &&L_OP_STR_ENDS_WITH;
        vm_labels[OP_STR_SPLIT] = &&L_OP_STR_SPLIT;
        vm_labels[OP_STR_REPLACE] = &&L_OP_STR_REPLACE;
        vm_labels[OP_ARR_NEW] = &&L_OP_ARR_NEW;
        vm_labels[OP_ARR_PUSH] = &&L_OP_ARR_PUSH;
        vm_labels[OP_ARR_POP] = &&L_OP_ARR_POP;
        vm_labels[OP_ARR_GET] = &&L_OP_ARR_GET;
        vm_labels[OP_ARR_SET] = &&L_OP_ARR_SET;
        vm_labels[OP_ARR_LEN] = &&L_OP_ARR_LEN;
        vm_labels[OP_ARR_SLICE] = &&L_OP_ARR_SLICE;
        vm_labels[OP_ARR_REMOVE] = &&L_OP_ARR_REMOVE;
        vm_labels[OP_ARR_LITERAL] = &&L_OP_ARR_LITERAL;
        vm_labels[OP_STRUCT_NEW] = &&L_OP_STRUCT_NEW;
        vm_labels[OP_STRUCT_GET] = &&L_OP_STRUCT_GET;
        vm_labels[OP_STRUCT_SET] = &&L_OP_STRUCT_SET;
        vm_labels[OP_STRUCT_LITERAL] = &&L_OP_STRUCT_LITERAL;
        vm_labels[OP_UNION_CONSTRUCT] = &&L_OP_UNION_CONSTRUCT;
        vm_labels[OP_UNION_TAG] = &&L_OP_UNION_TAG;
        vm_labels[OP_UNION_FIELD] = &&L_OP_UNION_FIELD;
        vm_labels[OP_MATCH_TAG] = &&L_OP_MATCH_TAG;
        vm_labels[OP_ENUM_VAL] = &&L_OP_ENUM_VAL;
        vm_labels[OP_TUPLE_NEW] = &&L_OP_TUPLE_NEW;
        vm_labels[OP_TUPLE_GET] = &&L_OP_TUPLE_GET;
        vm_labels[OP_AGG_PACK] = &&L_OP_AGG_PACK;
        vm_labels[OP_AGG_GET] = &&L_OP_AGG_GET;
        vm_labels[OP_AGG_SET] = &&L_OP_AGG_SET;
        vm_labels[OP_AGG_TAG] = &&L_OP_AGG_TAG;
        vm_labels[OP_HM_NEW] = &&L_OP_HM_NEW;
        vm_labels[OP_HM_GET] = &&L_OP_HM_GET;
        vm_labels[OP_HM_SET] = &&L_OP_HM_SET;
        vm_labels[OP_HM_HAS] = &&L_OP_HM_HAS;
        vm_labels[OP_HM_DELETE] = &&L_OP_HM_DELETE;
        vm_labels[OP_HM_KEYS] = &&L_OP_HM_KEYS;
        vm_labels[OP_HM_VALUES] = &&L_OP_HM_VALUES;
        vm_labels[OP_HM_LEN] = &&L_OP_HM_LEN;
        vm_labels[OP_GC_RETAIN] = &&L_OP_GC_RETAIN;
        vm_labels[OP_GC_RELEASE] = &&L_OP_GC_RELEASE;
        vm_labels[OP_CAST_INT] = &&L_OP_CAST_INT;
        vm_labels[OP_CAST_U8] = &&L_OP_CAST_U8;
        vm_labels[OP_CAST_FLOAT] = &&L_OP_CAST_FLOAT;
        vm_labels[OP_F64_FROM_BITS] = &&L_OP_F64_FROM_BITS;
        vm_labels[OP_F64_TO_BITS] = &&L_OP_F64_TO_BITS;
        vm_labels[OP_CAST_BOOL] = &&L_OP_CAST_BOOL;
        vm_labels[OP_CAST_STRING] = &&L_OP_CAST_STRING;
        vm_labels[OP_TYPE_CHECK] = &&L_OP_TYPE_CHECK;
        vm_labels[OP_CLOSURE_NEW] = &&L_OP_CLOSURE_NEW;
        vm_labels[OP_PRINT] = &&L_OP_PRINT;
        vm_labels[OP_PRINTLN] = &&L_OP_PRINTLN;
        vm_labels[OP_ASSERT] = &&L_OP_ASSERT;
        vm_labels[OP_DEBUG_LINE] = &&L_OP_DEBUG_LINE;
        vm_labels[OP_HALT] = &&L_OP_HALT;
        vm_labels[OP_OPAQUE_NULL] = &&L_OP_OPAQUE_NULL;
        vm_labels[OP_OPAQUE_VALID] = &&L_OP_OPAQUE_VALID;
        vm_labels[OP_MEM_LOAD8] = &&L_OP_MEM_LOAD8;
        vm_labels[OP_MEM_LOAD16] = &&L_OP_MEM_LOAD16;
        vm_labels[OP_MEM_LOAD32] = &&L_OP_MEM_LOAD32;
        vm_labels[OP_MEM_LOAD64] = &&L_OP_MEM_LOAD64;
        vm_labels[OP_MEM_STORE8] = &&L_OP_MEM_STORE8;
        vm_labels[OP_MEM_STORE16] = &&L_OP_MEM_STORE16;
        vm_labels[OP_MEM_STORE32] = &&L_OP_MEM_STORE32;
        vm_labels[OP_MEM_STORE64] = &&L_OP_MEM_STORE64;
    }
#endif

    /* Main dispatch loop.
     *
     * The threaded form has no loop around the handlers on purpose: without
     * one, a `break` that should have become VM_NEXT() will not compile, so
     * the conversion checks itself rather than relying on review. */
#ifdef NANO_COMPUTED_GOTO
vm_dispatch_top:
    if (vm->ip >= code_end) goto vm_dispatch_done;
    {
#else
    while (vm->ip < code_end) {
#endif
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
        if(union_execution && !vm_uf_context(union_field,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require bounded union frames before dispatch lookup.");
#endif
        if(borrowed_map_execution && !vm_rmb_context(borrowed_map,vm))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require bounded borrowed frames before dispatch lookup.");
        if (vm->callbacks && --callback_budget == 0) {
            VmTrap yielded = {.type = TRAP_YIELD};
            return yielded;
        }
        frame->instruction_ip = vm->ip;
        VmReferenceActivation *reference_context=vm_reference_activation(vm,vm->frame_count-1);
        bool *dispatch_valid = NULL;
        VmDispatchModule *dispatch_module = dispatch_module_for(
            vm, vm->module, &dispatch_valid);
        if (!dispatch_module || !dispatch_valid || !*dispatch_valid
                || vm->current_fn >= dispatch_module->function_count) {
            return trap_error(vm, VM_ERR_DECODE,
                              "Dispatch module is stale at offset %u", vm->ip);
        }
        const VmDispatchFunction *dispatch_function =
            &dispatch_module->functions[vm->current_fn];
        uint32_t function_offset = vm->ip - cur_fn->code_offset;
        const VmDispatchInstruction *decoded;
        if (vm->ip == cursor_offset && cursor.function == dispatch_function) {
            decoded = vm_dispatch_advance(&cursor);
        } else {
            decoded = vm_dispatch_seek(&cursor, dispatch_function, function_offset)
                ? vm_dispatch_current(&cursor) : NULL;
        }
        if (!decoded || decoded->byte_offset != function_offset) {
            return trap_error(vm, VM_ERR_DECODE,
                              "No dispatch instruction at offset %u", vm->ip);
        }
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
        if(record_execution) {
            VmResult checked=vm_ra_preflight(record_array,decoded);
            if(checked!=VM_OK)return trap_error(vm,checked,"I require the complete private opcode root contract.");
        }
#endif
        if(borrowed_map_execution) {
            VmResult checked=vm_rmb_preflight(borrowed_map,decoded,map_value_tag);
            if(checked!=VM_OK)return trap_error(vm,checked,"I require the complete borrowed map opcode contract.");
        }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
        if(map_execution) {
            VmResult checked=vm_rmx_preflight(record_map,decoded,map_value_tag);
            if(checked!=VM_OK)return trap_error(vm,checked,"I require the complete private map opcode root contract.");
        }
#endif
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
        if(union_execution) {
            VmResult checked=vm_uf_preflight(union_field,decoded);
            if(checked!=VM_OK)return trap_error(vm,checked,"I require the complete private union opcode contract.");
        }
#endif
        /* I borrow this checked instruction only until this dispatch returns or advances. */
        const DecodedInstruction *instr = &decoded->instruction;
        uint32_t instr_start = vm->ip;
        uint32_t stack_before = vm->stack_size;
        vm->ip = cur_fn->code_offset + decoded->next_byte_offset;
        cursor_offset = vm->ip;
        profile_instruction(vm, instr->opcode);
        if (vm->opcode_trace)
            vm_trace_instruction(vm, instr_start, instr, stack_before);

        /* Check the whole input requirement before a handler mutates
         * anything. A guarded pop alone cannot reject an operation atomically,
         * and the caller's values and frame locals are not operands. */
        {
            const InstructionInfo *info = isa_get_info(instr->opcode);
            int32_t required = info ? info->pop_count : -1;
            int32_t produced = info ? info->push_count : -1;
            switch (instr->opcode) {
            case OP_PERFORM:
                required = instr->operands[1].u16;
                produced = 1;
                break;
            case OP_ARR_LITERAL:
            case OP_STRUCT_LITERAL:
            case OP_CLOSURE_NEW:
                required = instr->operands[1].u16;
                produced = 1;
                break;
            case OP_UNION_CONSTRUCT:
                required = instr->operands[2].u16;
                produced = 1;
                break;
            case OP_TUPLE_NEW:
                required = instr->operands[0].u16;
                produced = 1;
                break;
            case OP_AGG_PACK:
                required = instr->operands[3].u16;
                produced = 1;
                break;
            case OP_PICK:
            case OP_ROLL:
                required = (int32_t)instr->operands[0].u16 + 1;
                produced = required + (instr->opcode == OP_PICK ? 1 : 0);
                break;
            default:
                break;
            }
            if (required >= 0
                    && !stack_has_operands(vm, (uint32_t)required))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need %d operands for %s.",
                                  required, info->name);
            if (required >= 0 && produced > required
                    && stack_reserve(vm, (uint64_t)vm->stack_size
                                          + (uint32_t)(produced - required)) != VM_OK)
                return trap_error(vm, VM_ERR_MEMORY,
                                  "I could not reserve instruction output space.");
        }

        if((admitted && proof->ordinary_arrays) || record_execution) {
            VmResult checked=vm_record_array_retain_preflight(vm,frame,decoded);
            if(checked!=VM_OK)return trap_error(vm,checked,"I could not preserve my ordinary array-owner retain headroom: opcode %u status %u.",decoded->instruction.opcode,checked);
        }

        if(admitted && proof->owner_arrays) {
            VmResult checked=vm_owned_array_preflight(vm,frame,decoded);
            if(checked!=VM_OK)return trap_error(vm,checked,"I could not satisfy an owner ARRAY operand or retain obligation.");
        }

        /* Private superinstructions run before the portable opcode switch.
         * They are an internal fusion of already-verified steps, so they
         * reproduce the exact stack, heap, and ownership effects of the
         * instructions they replace while advancing `ip` past the whole run
         * in one dispatch step.  A dispatch instruction is never both a
         * superinstruction and a portable opcode: super_op == VM_SUPER_NONE
         * falls through to the normal switch below. */
        if (decoded->super_op != VM_SUPER_NONE) {
            switch (decoded->super_op) {
            case VM_SUPER_LOAD_LOCAL_FIELD: {
                /* Fused OP_LOAD_LOCAL idx ; OP_AGG_GET field. */
                uint16_t idx = instr->operands[0].u16;
                uint16_t field = decoded->super_operand;
                uint32_t abs_idx = effect_local_index(vm, frame, idx);
                if (abs_idx >= vm->stack_size) {
                    return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                      "Local %u out of range", idx);
                }
                /* I have completed the local-load phase. The field access
                 * retains its own portable source location under fusion. */
                frame->instruction_ip = instr_start + instr->byte_length;
                NanoValue aggregate = vm->stack[abs_idx];
                NanoValue value = val_void();
                if (aggregate.tag == TAG_STRUCT && aggregate.as.sval
                        && field < aggregate.as.sval->field_count) {
                    value = aggregate.as.sval->fields[field];
                } else if (aggregate.tag == TAG_UNION && aggregate.as.uval
                           && field < aggregate.as.uval->field_count) {
                    value = aggregate.as.uval->fields[field];
                } else if (aggregate.tag == TAG_TUPLE && aggregate.as.tuple
                           && field < aggregate.as.tuple->count) {
                    value = aggregate.as.tuple->elements[field];
                } else {
                    return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                      "AGG_GET field %u is unavailable", field);
                }
                vm_retain(&vm->heap, value);
                stack_push(vm, value);
                break;
            }
            case VM_SUPER_NONE:
            case VM_SUPER__COUNT:
            default:
                return trap_error(vm, VM_ERR_DECODE,
                                  "Unknown superinstruction %u",
                                  (unsigned)decoded->super_op);
            }
            VM_NEXT();
        }

        VM_DISPATCH_BEGIN(instr->opcode)

        /* ============================================================
         * Stack & Constants
         * ============================================================ */

        VM_CASE(OP_OWN_MOVE_LOCAL)
        VM_CASE(OP_OWN_STORE_LOCAL)
        VM_CASE(OP_OWN_PACK)
        VM_CASE(OP_OWN_UNPACK_LOCAL) {
            if (!owned_execution)
                return trap_error(vm, VM_ERR_NOT_IMPLEMENTED,
                                  "I require owned-transfer execution semantics before execution");
            uint8_t op=instr->opcode;
            if (op==OP_OWN_PACK) {
                NvmV2Layouts layouts={0};
                if (nvm_v2_layouts_decode(vm->module->layout_data, vm->module->layout_size, &layouts)!=NVM_V2_OK)
                    return trap_error(vm,VM_ERR_MEMORY,"I cannot load owned record fields");
                uint32_t layout=instr->operands[0].u32;
                uint16_t count=layouts.items[layout].field_count;
                nvm_v2_layouts_free(&layouts);
                if (!stack_has_operands(vm,count))
                    return trap_error(vm,VM_ERR_STACK_UNDERFLOW,"I require every owned field");
                if (stack_reserve(vm,(uint64_t)vm->stack_size+1)!=VM_OK)
                    return trap_error(vm,VM_ERR_MEMORY,"I cannot reserve an owned record result");
                VmStruct *record=vm_struct_new(&vm->heap,layout,count);
                if (!record) return trap_error(vm,VM_ERR_MEMORY,"I cannot allocate an owned record");
                for (uint16_t i=count;i>0;i--) record->fields[i-1]=stack_pop(vm);
                stack_push(vm,val_struct(record));
            } else {
                uint32_t index=effect_local_index(vm,frame,instr->operands[0].u16);
                if (index>=vm->stack_size)
                    return trap_error(vm,VM_ERR_OUT_OF_BOUNDS,"I require an owned local slot");
                if (op==OP_OWN_STORE_LOCAL) {
                    NanoValue previous=vm->stack[index];
                    vm->stack[index]=stack_pop(vm);
                    vm_release(&vm->heap,previous);
                } else {
                    NanoValue value=vm->stack[index];
                    if ((value.tag!=TAG_STRUCT || !value.as.sval) &&
                        (value.tag!=TAG_UNION || !value.as.uval))
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a live owned aggregate");
                    if (op==OP_OWN_MOVE_LOCAL) {
                        /* I preserve the owner even if this handler is later
                         * separated from the common instruction preflight. */
                        if (stack_reserve(vm,(uint64_t)vm->stack_size+1)!=VM_OK)
                            return trap_error(vm,VM_ERR_MEMORY,"I cannot reserve a moved owner");
                        vm->stack[index]=val_void();
                        stack_push(vm,value);
                    } else {
                        uint32_t count=value.tag==TAG_STRUCT?value.as.sval->field_count:value.as.uval->field_count;
                        NanoValue *fields=value.tag==TAG_STRUCT?value.as.sval->fields:value.as.uval->fields;
                        bool buffered=value.tag==TAG_STRUCT?value.as.sval->header.buffered:value.as.uval->header.buffered;
                        if (stack_reserve(vm,(uint64_t)vm->stack_size+count)!=VM_OK)
                            return trap_error(vm,VM_ERR_MEMORY,"I cannot reserve every unpacked field");
                        vm->stack[index]=val_void();
                        for (uint32_t i=0;i<count;i++) {
                            stack_push(vm,fields[i]);
                            fields[i]=val_void();
                        }
                        vm_release(&vm->heap,value);
                        if (buffered) vm_gc_collect_cycles(&vm->heap);
                    }
                }
            }
            VM_NEXT();
        }

        VM_CASE(OP_CALL_REF) {
            uint32_t target=instr->operands[0].u32;
            uint16_t reference=instr->operands[1].u16;
            if (!owned_execution || vm->frame_count!=1 || vm->current_fn!=0 || target!=1 ||
                vm->module->function_count!=2 || vm->callee_references.active ||
                vm->reference_generation==UINT64_MAX)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a checked entry-to-helper reference call");
            const NvmFunctionEntry *callee=&vm->module->functions[1];
            if(!callee->arity || callee->arity>NVM_AFFINE_MAX_PARAMETERS ||
               reference>frame->local_count || callee->arity>frame->local_count-reference)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a complete bounded reference argument range");
            NvmAffineState *contract=nvm_affine_state_create(vm->module,1,callee->local_count);
            if (!contract) return trap_error(vm,VM_ERR_MEMORY,"I could not allocate the borrowed parameter facts");
            VmReferenceSlot arguments[NVM_AFFINE_MAX_PARAMETERS];
            bool valid=true;
            for(uint16_t p=0;p<callee->arity;p++) {
                NvmAffineType type;NvmReferenceMode mode;
                if(!nvm_affine_parameter_at(contract,p,&type,&mode) ||
                   !reference_context->slots[(uint32_t)reference+p].live) {valid=false;break;}
                arguments[p]=reference_context->slots[(uint32_t)reference+p];
                if(mode==NVM_REFERENCE_EXCLUSIVE && !arguments[p].exclusive) {valid=false;break;}
                arguments[p].region=0;arguments[p].parent=UINT16_MAX;
                arguments[p].exclusive=mode==NVM_REFERENCE_EXCLUSIVE;
            }
            nvm_affine_state_free(contract);
            if(!valid) return trap_error(vm,VM_ERR_TYPE_ERROR,"I require checked borrowed parameter contracts");
            uint32_t base=vm->stack_size;
            VmResult reserved=stack_reserve_frame(vm,base,callee);
            if (reserved!=VM_OK) return trap_error(vm,reserved,"I could not reserve the borrowed helper frame");
            memset(&vm->callee_references,0,sizeof(vm->callee_references));
            vm->callee_references.active=true;
            vm->callee_references.generation=++vm->reference_generation;
            for(uint16_t p=0;p<callee->arity;p++) vm->callee_references.slots[p]=arguments[p];
            for(uint16_t i=0;i<callee->local_count;i++) stack_push(vm,val_void());
            VmCallFrame *next=&vm->frames[vm->frame_count++];
            memset(next,0,sizeof(*next));next->fn_idx=1;next->return_ip=vm->ip;
            next->instruction_ip=callee->code_offset;
            next->stack_base=base;next->local_count=callee->local_count;
            next->owned_callable=val_void();next->module=vm->module;
            frame=next;vm->current_fn=1;vm->ip=callee->code_offset;cur_fn=callee;
            code_end=callee->code_offset+callee->code_length;
            VM_NEXT();
        }

        VM_CASE(OP_REGION_BEGIN)
            if (!owned_execution || reference_context->region==UINT32_MAX)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I cannot begin this reference region");
            ++reference_context->region;
            VM_NEXT();
        VM_CASE(OP_REGION_END)
            if (!owned_execution || !reference_context->region)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need a live reference region to end");
            for (unsigned i=0;i<256;i++)
                if (reference_context->slots[i].region==reference_context->region)
                    reference_context->slots[i]=(VmReferenceSlot){0};
            --reference_context->region;
            VM_NEXT();
        VM_CASE(OP_BORROW_PATH_SHARED)
        VM_CASE(OP_BORROW_PATH_EXCLUSIVE)
        VM_CASE(OP_BORROW_LOCAL_SHARED)
        VM_CASE(OP_BORROW_LOCAL_EXCLUSIVE) {
            uint16_t ref=instr->operands[0].u16,root=instr->operands[1].u16;
            if (!owned_execution || ref>=frame->local_count || root>=frame->local_count ||
                !reference_context->region || reference_context->slots[ref].live)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need an available reference slot and owner");
            reference_context->slots[ref]=(VmReferenceSlot){root,reference_context->region,
                instr->opcode==OP_BORROW_LOCAL_EXCLUSIVE || instr->opcode==OP_BORROW_PATH_EXCLUSIVE,
                (instr->opcode==OP_BORROW_PATH_SHARED || instr->opcode==OP_BORROW_PATH_EXCLUSIVE)?
                    instr->operands[2].u32:NVM_V2_NO_INDEX,UINT16_MAX,true,
                (uint16_t)(vm->frame_count-1),reference_context->generation};
            VM_NEXT();
        }
        VM_CASE(OP_REBORROW_SHARED)
        VM_CASE(OP_REBORROW_EXCLUSIVE) {
            uint16_t ref=instr->operands[0].u16,parent=instr->operands[1].u16;
            bool exclusive=instr->opcode==OP_REBORROW_EXCLUSIVE;
            if (!owned_execution || ref>=frame->local_count || parent>=frame->local_count ||
                reference_context->slots[ref].live || !reference_context->slots[parent].live ||
                reference_context->slots[parent].region>=reference_context->region ||
                (exclusive && !reference_context->slots[parent].exclusive))
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need parent authority in an enclosing region");
            reference_context->slots[ref]=reference_context->slots[parent];
            reference_context->slots[ref].parent=parent;
            reference_context->slots[ref].region=reference_context->region;
            reference_context->slots[ref].exclusive=exclusive;
            VM_NEXT();
        }
        VM_CASE(OP_REF_GET)
        VM_CASE(OP_REF_SET) {
            uint16_t ref=instr->operands[0].u16,field=instr->operands[1].u16;
            if (!owned_execution || ref>=frame->local_count || !reference_context->slots[ref].live)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need a live reference slot");
            VmReferenceSlot slot=reference_context->slots[ref];
            VmReferenceActivation *origin=vm_reference_activation(vm,slot.origin_frame);
            if (slot.origin_frame>=vm->frame_count || !origin || !origin->active ||
                origin->generation!=slot.origin_generation ||
                slot.root>=vm->frames[slot.origin_frame].local_count)
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need the live originating reference frame");
            NanoValue owner=vm->stack[vm->frames[slot.origin_frame].stack_base+slot.root];
            if (slot.path!=NVM_V2_NO_INDEX) {
                uint16_t fields[NVM_OWNERSHIP_MAX_PATH_DEPTH],count;
                if (nvm_ownership_path(vm->module,slot.path,fields,NVM_OWNERSHIP_MAX_PATH_DEPTH,&count)!=NVM_V2_OK)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I need a retained reference path");
                for (uint16_t i=0;i<count;i++) {
                    if (owner.tag!=TAG_STRUCT || fields[i]>=owner.as.sval->field_count)
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I need an owner matching its reference path");
                    owner=owner.as.sval->fields[fields[i]];
                }
            }
            if (owner.tag!=TAG_STRUCT || field>=owner.as.sval->field_count ||
                (instr->opcode==OP_REF_SET && !slot.exclusive))
                return trap_error(vm,VM_ERR_TYPE_ERROR,"I need a permitted scalar reference field");
            if (instr->opcode==OP_REF_GET) stack_push(vm,owner.as.sval->fields[field]);
            else {
                NanoValue value=stack_peek(vm,0);
                if (value.tag!=owner.as.sval->fields[field].tag)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I need the exact reference field type");
                owner.as.sval->fields[field]=stack_pop(vm);
            }
            VM_NEXT();
        }

        VM_CASE(OP_NOP) {
            /* I report a selected shadow only when execution reaches its marker.
             * Advisory metadata never grants execution or ownership authority. */
            if (getenv("NANO_SHADOW_TRACE")) {
                char key[64];
                snprintf(key, sizeof key, "nanolang.shadow.offset.%u", instr_start);
                for (uint32_t i = 0; i < vm->module->metadata_count; ++i) {
                    const NvmMetadataEntry *entry = &vm->module->metadata[i];
                    const char *name = nvm_get_string(vm->module, entry->key_idx);
                    if (name && strcmp(name, key) == 0) {
                        const char *target = nvm_get_string(vm->module, entry->value_idx);
                        if (target) fprintf(stderr, "I am testing shadow %s\n", target);
                    }
                }
            }
            VM_NEXT();
        }

        VM_CASE(OP_PUSH_I64)
            stack_push(vm, val_int(instr->operands[0].i64));
            VM_NEXT();

        VM_CASE(OP_PUSH_F64)
            stack_push(vm, val_float(instr->operands[0].f64));
            VM_NEXT();

        VM_CASE(OP_PUSH_BOOL)
            stack_push(vm, val_bool(instr->operands[0].u8 != 0));
            VM_NEXT();

        VM_CASE(OP_PUSH_STR) {
            uint32_t idx = instr->operands[0].u32;
            VmModuleConstants *constants = module_constants_for(vm, vm->module);
            if (!constants || idx >= constants->count || !constants->strings[idx])
                return trap_error(vm, VM_ERR_DECODE,
                                  "String constant %u is not instantiated", idx);
            NanoValue value = val_string(constants->strings[idx]);
            vm_retain(&vm->heap, value);
            stack_push(vm, value);
            VM_NEXT();
        }

        VM_CASE(OP_PUSH_VOID)
            stack_push(vm, val_void());
            VM_NEXT();

        VM_CASE(OP_PUSH_U8)
            stack_push(vm, val_u8(instr->operands[0].u8));
            VM_NEXT();

        VM_CASE(OP_FUNCREF)
            stack_push(vm, val_function_owned(instr->operands[0].u32,
                                              vm_callable_module_id(vm, vm->module)));
            VM_NEXT();

        VM_CASE(OP_DUP) {
            if (!stack_has_operands(vm, 1))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need one operand for DUP.");
            NanoValue top = stack_peek(vm, 0);
            vm_retain(&vm->heap, top);
            stack_push(vm, top);
            VM_NEXT();
        }

        VM_CASE(OP_POP) {
            if (!stack_has_operands(vm, 1))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need one operand for POP.");
            NanoValue v = stack_pop(vm);
            vm_release(&vm->heap, v);
            VM_NEXT();
        }

        VM_CASE(OP_SWAP) {
            if (!stack_has_operands(vm, 2))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need two operands for SWAP.");
            NanoValue a = vm->stack[vm->stack_size - 1];
            NanoValue b = vm->stack[vm->stack_size - 2];
            vm->stack[vm->stack_size - 1] = b;
            vm->stack[vm->stack_size - 2] = a;
            VM_NEXT();
        }

        VM_CASE(OP_ROT3) {
            if (!stack_has_operands(vm, 3))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need three operands for ROT3.");
            uint32_t top = vm->stack_size - 1;
            NanoValue a = vm->stack[top];
            vm->stack[top] = vm->stack[top - 1];
            vm->stack[top - 1] = vm->stack[top - 2];
            vm->stack[top - 2] = a;
            VM_NEXT();
        }

        VM_CASE(OP_PICK) {
            uint16_t depth = instr->operands[0].u16;
            if (!stack_has_operands(vm, (uint32_t)depth + 1))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I have no operand at PICK depth %u.", depth);
            NanoValue value = vm->stack[vm->stack_size - 1 - depth];
            vm_retain(&vm->heap, value);
            stack_push(vm, value);
            VM_NEXT();
        }

        VM_CASE(OP_ROLL) {
            uint16_t depth = instr->operands[0].u16;
            if (!stack_has_operands(vm, (uint32_t)depth + 1))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I have no operand at ROLL depth %u.", depth);
            uint32_t index = vm->stack_size - 1 - depth;
            NanoValue value = vm->stack[index];
            memmove(&vm->stack[index], &vm->stack[index + 1],
                    depth * sizeof(NanoValue));
            vm->stack[vm->stack_size - 1] = value;
            VM_NEXT();
        }

        /* ============================================================
         * Variable Access
         * ============================================================ */

        VM_CASE(OP_LOAD_LOCAL) {
            uint16_t idx = instr->operands[0].u16;
            uint32_t abs_idx = effect_local_index(vm, frame, idx);
            if (abs_idx >= vm->stack_size) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "Local %u out of range", idx);
            }
            NanoValue v = vm->stack[abs_idx];
            vm_retain(&vm->heap, v);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_STORE_LOCAL) {
            uint16_t idx = instr->operands[0].u16;
            uint32_t abs_idx = effect_local_index(vm, frame, idx);
            if (abs_idx >= vm->stack_size) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "Local %u out of range", idx);
            }
            NanoValue v = stack_pop(vm);
            NanoValue previous = vm->stack[abs_idx];
            vm->stack[abs_idx] = v;
            vm_release(&vm->heap, previous);
            VM_NEXT();
        }

        VM_CASE(OP_LOAD_GLOBAL) {
            uint32_t idx = instr->operands[0].u32;
            if (idx >= vm->global_capacity) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "Global %u out of range", idx);
            }
            NanoValue v = vm->globals[idx];
            vm_retain(&vm->heap, v);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_STORE_GLOBAL) {
            uint32_t idx = instr->operands[0].u32;
            if (idx >= VM_MAX_GLOBALS) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "Global %u out of range", idx);
            }
            /* Grow the dynamically-sized globals array on demand (bounded by
             * VM_MAX_GLOBALS) so stores never exceed the allocation. */
            if (idx >= vm->global_capacity && !vm_ensure_globals(vm, idx + 1)) {
                return trap_error(vm, VM_ERR_MEMORY, "Failed to allocate global %u", idx);
            }
            NanoValue v = stack_pop(vm);
            NanoValue previous = vm->globals[idx];
            bool buffered=owned_execution && val_is_heap_obj(previous) && previous.as.obj &&
                ((VmHeapHeader *)previous.as.obj)->buffered;
            vm->globals[idx] = v;
            vm_release(&vm->heap, previous);
            if (buffered) vm_gc_collect_cycles(&vm->heap);
            if (idx >= vm->global_count) vm->global_count = idx + 1;
            VM_NEXT();
        }

        VM_CASE(OP_LOAD_UPVALUE) {
            uint16_t idx = instr->operands[1].u16;
            /* depth (operands[0]) is always 0: codegen flattens upvalue chains so
             * every captured variable lives in the immediate closure's capture array. */
            if (frame->closure && idx < frame->closure->capture_count) {
                NanoValue v = frame->closure->captures[idx];
                vm_retain(&vm->heap, v);
                stack_push(vm, v);
            } else {
                stack_push(vm, val_void());
            }
            VM_NEXT();
        }

        VM_CASE(OP_STORE_UPVALUE) {
            uint16_t idx = instr->operands[1].u16;
            /* depth (operands[0]) always 0 — see OP_LOAD_UPVALUE note above */
            NanoValue v = stack_pop(vm);
            if (frame->closure && idx < frame->closure->capture_count) {
                NanoValue previous = frame->closure->captures[idx];
                frame->closure->captures[idx] = v;
                vm_release(&vm->heap, previous);
            } else {
                vm_release(&vm->heap, v);
            }
            VM_NEXT();
        }

        /* ============================================================
         * Arithmetic
         * ============================================================ */

        VM_CASE(OP_ARRAY_ADD)
            if (stack_peek(vm, 0).tag != TAG_ARRAY
                    && stack_peek(vm, 1).tag != TAG_ARRAY)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "ARRAY_ADD requires at least one array");
            goto dynamic_add;
        VM_CASE(OP_ADD) {
dynamic_add:
            ;
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            /* Coerce enum to int for arithmetic */
            if (a.tag == TAG_ENUM) { a = val_int((int64_t)a.as.enum_val); }
            if (b.tag == TAG_ENUM) { b = val_int((int64_t)b.as.enum_val); }
            if (a.tag == TAG_INT && b.tag == TAG_INT) {
                /* Compute the wrapped bits without signed C overflow. */
                stack_push(vm, val_int((int64_t)((uint64_t)a.as.i64 + (uint64_t)b.as.i64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_add(a.as.f64, b.as.f64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_INT) {
                stack_push(vm, val_float(nano_rt_f64_add(a.as.f64, (double)b.as.i64)));
            } else if (a.tag == TAG_INT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_add((double)a.as.i64, b.as.f64)));
            } else if (a.tag == TAG_STRING && b.tag == TAG_STRING) {
                VmString *s = vm_string_concat(&vm->heap, a.as.string, b.as.string);
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                if (!s)
                    return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the concatenated string.");
                stack_push(vm, val_string(s));
            } else if (a.tag == TAG_ARRAY || b.tag == TAG_ARRAY) {
                NanoValue result = val_void();
                VmResult status = vm_array_arithmetic(vm, OP_ADD, a, b, &result);
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                if (status != VM_OK)
                    return trap_error(vm, status, status == VM_ERR_MEMORY ?
                        "I could not allocate the array result." :
                        "I require compatible numeric elements, or strings for array addition.");
                stack_push(vm, result);
            } else {
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ADD: incompatible types %s + %s",
                                isa_tag_name(a.tag), isa_tag_name(b.tag));
            }
            VM_NEXT();
        }

        VM_CASE(OP_ARRAY_SUB)
            if (stack_peek(vm, 0).tag != TAG_ARRAY
                    && stack_peek(vm, 1).tag != TAG_ARRAY)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "ARRAY_SUB requires at least one array");
            goto dynamic_sub;
        VM_CASE(OP_SUB) {
dynamic_sub:
            ;
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_ENUM) { a = val_int((int64_t)a.as.enum_val); }
            if (b.tag == TAG_ENUM) { b = val_int((int64_t)b.as.enum_val); }
            if (a.tag == TAG_INT && b.tag == TAG_INT) {
                stack_push(vm, val_int((int64_t)((uint64_t)a.as.i64 - (uint64_t)b.as.i64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_sub(a.as.f64, b.as.f64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_INT) {
                stack_push(vm, val_float(nano_rt_f64_sub(a.as.f64, (double)b.as.i64)));
            } else if (a.tag == TAG_INT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_sub((double)a.as.i64, b.as.f64)));
            } else if (a.tag == TAG_ARRAY || b.tag == TAG_ARRAY) {
                NanoValue result = val_void();
                VmResult status = vm_array_arithmetic(vm, OP_SUB, a, b, &result);
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                if (status != VM_OK)
                    return trap_error(vm, status, status == VM_ERR_MEMORY ?
                        "I could not allocate the array result." :
                        "I require compatible numeric elements, or strings for array addition.");
                stack_push(vm, result);
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "SUB: type error");
            }
            VM_NEXT();
        }

        VM_CASE(OP_ARRAY_MUL)
            if (stack_peek(vm, 0).tag != TAG_ARRAY
                    && stack_peek(vm, 1).tag != TAG_ARRAY)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "ARRAY_MUL requires at least one array");
            goto dynamic_mul;
        VM_CASE(OP_MUL) {
dynamic_mul:
            ;
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_ENUM) { a = val_int((int64_t)a.as.enum_val); }
            if (b.tag == TAG_ENUM) { b = val_int((int64_t)b.as.enum_val); }
            if (a.tag == TAG_INT && b.tag == TAG_INT) {
                stack_push(vm, val_int((int64_t)((uint64_t)a.as.i64 * (uint64_t)b.as.i64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_mul(a.as.f64, b.as.f64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_INT) {
                stack_push(vm, val_float(nano_rt_f64_mul(a.as.f64, (double)b.as.i64)));
            } else if (a.tag == TAG_INT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_mul((double)a.as.i64, b.as.f64)));
            } else if (a.tag == TAG_ARRAY || b.tag == TAG_ARRAY) {
                NanoValue result = val_void();
                VmResult status = vm_array_arithmetic(vm, OP_MUL, a, b, &result);
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                if (status != VM_OK)
                    return trap_error(vm, status, status == VM_ERR_MEMORY ?
                        "I could not allocate the array result." :
                        "I require compatible numeric elements, or strings for array addition.");
                stack_push(vm, result);
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "MUL: type error");
            }
            VM_NEXT();
        }

        VM_CASE(OP_ARRAY_DIV)
            if (stack_peek(vm, 0).tag != TAG_ARRAY
                    && stack_peek(vm, 1).tag != TAG_ARRAY)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "ARRAY_DIV requires at least one array");
            goto dynamic_div;
        VM_CASE(OP_DIV) {
dynamic_div:
            ;
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_ENUM) { a = val_int((int64_t)a.as.enum_val); }
            if (b.tag == TAG_ENUM) { b = val_int((int64_t)b.as.enum_val); }
            if (a.tag == TAG_INT && b.tag == TAG_INT) {
                /* Total division: by zero = 0 (matches Coq semantics); the
                 * INT64_MIN / -1 case is signed-overflow UB that raises SIGFPE
                 * on x86-64, so wrap to INT64_MIN instead of dividing. */
                int64_t q;
                if (b.as.i64 == 0) q = 0;
                else if (a.as.i64 == INT64_MIN && b.as.i64 == -1) q = INT64_MIN;
                else q = a.as.i64 / b.as.i64;
                stack_push(vm, val_int(q));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_div(a.as.f64, b.as.f64)));
            } else if (a.tag == TAG_FLOAT && b.tag == TAG_INT) {
                stack_push(vm, val_float(nano_rt_f64_div(a.as.f64, (double)b.as.i64)));
            } else if (a.tag == TAG_INT && b.tag == TAG_FLOAT) {
                stack_push(vm, val_float(nano_rt_f64_div((double)a.as.i64, b.as.f64)));
            } else if (a.tag == TAG_ARRAY || b.tag == TAG_ARRAY) {
                NanoValue result = val_void();
                VmResult status = vm_array_arithmetic(vm, OP_DIV, a, b, &result);
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                if (status != VM_OK)
                    return trap_error(vm, status, status == VM_ERR_MEMORY ?
                        "I could not allocate the array result." :
                        "I require compatible numeric elements, or strings for array addition.");
                stack_push(vm, result);
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "DIV: type error");
            }
            VM_NEXT();
        }

        VM_CASE(OP_MOD) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_INT && b.tag == TAG_INT) {
                /* Total modulo: by zero = 0; INT64_MIN % -1 is mathematically 0
                 * but signed-overflow UB (SIGFPE) if computed directly. */
                int64_t r;
                if (b.as.i64 == 0) r = 0;
                else if (a.as.i64 == INT64_MIN && b.as.i64 == -1) r = 0;
                else r = a.as.i64 % b.as.i64;
                stack_push(vm, val_int(r));
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "MOD: type error");
            }
            VM_NEXT();
        }

        VM_CASE(OP_NEG) {
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_INT) {
                /* -INT64_MIN overflows (UB); wrap to INT64_MIN. */
                stack_push(vm, val_int(a.as.i64 == INT64_MIN ? INT64_MIN : -a.as.i64));
            } else if (a.tag == TAG_FLOAT) {
                stack_push(vm, val_float(-a.as.f64));
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "NEG: type error");
            }
            VM_NEXT();
        }

        VM_CASE(OP_I64_ADD)
        VM_CASE(OP_I64_SUB)
        VM_CASE(OP_I64_MUL)
        VM_CASE(OP_I64_DIV_S)
        VM_CASE(OP_I64_REM_S) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_ENUM) a = val_int((int64_t)a.as.enum_val);
            if (b.tag == TAG_ENUM) b = val_int((int64_t)b.as.enum_val);
            if (a.tag != TAG_INT || b.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two integers",
                                  isa_get_info(instr->opcode)->name);
            int64_t result = 0;
            /* Unsigned intermediates implement modulo-2^64 arithmetic. */
            if (instr->opcode == OP_I64_ADD) result = (int64_t)((uint64_t)a.as.i64 + (uint64_t)b.as.i64);
            else if (instr->opcode == OP_I64_SUB) result = (int64_t)((uint64_t)a.as.i64 - (uint64_t)b.as.i64);
            else if (instr->opcode == OP_I64_MUL) result = (int64_t)((uint64_t)a.as.i64 * (uint64_t)b.as.i64);
            else if (instr->opcode == OP_I64_DIV_S) {
                if (b.as.i64 == 0) result = 0;
                else if (a.as.i64 == INT64_MIN && b.as.i64 == -1) result = INT64_MIN;
                else result = a.as.i64 / b.as.i64;
            } else {
                if (b.as.i64 == 0 || (a.as.i64 == INT64_MIN && b.as.i64 == -1))
                    result = 0;
                else result = a.as.i64 % b.as.i64;
            }
            stack_push(vm, val_int(result));
            VM_NEXT();
        }

        VM_CASE(OP_I64_NEG) {
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I64_NEG requires an integer");
            stack_push(vm, val_int(a.as.i64 == INT64_MIN ? INT64_MIN : -a.as.i64));
            VM_NEXT();
        }

        VM_CASE(OP_F64_ADD)
        VM_CASE(OP_F64_SUB)
        VM_CASE(OP_F64_MUL)
        VM_CASE(OP_F64_DIV) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_FLOAT || b.tag != TAG_FLOAT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two floats",
                                  isa_get_info(instr->opcode)->name);
            double result = 0.0;
            if (instr->opcode == OP_F64_ADD) result = nano_rt_f64_add(a.as.f64, b.as.f64);
            else if (instr->opcode == OP_F64_SUB) result = nano_rt_f64_sub(a.as.f64, b.as.f64);
            else if (instr->opcode == OP_F64_MUL) result = nano_rt_f64_mul(a.as.f64, b.as.f64);
            else result = nano_rt_f64_div(a.as.f64, b.as.f64);
            stack_push(vm, val_float(result));
            VM_NEXT();
        }

        VM_CASE(OP_F64_FROM_BITS)
        VM_CASE(OP_F64_TO_BITS) {
            NanoValue value = stack_pop(vm);
            uint8_t expected = instr->opcode == OP_F64_FROM_BITS ? TAG_INT : TAG_FLOAT;
            if (value.tag != expected) {
                vm_release(&vm->heap, value);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I require the exact input tag for binary64 bit transport.");
            }
            if (expected == TAG_INT) stack_push(vm, val_float(nl_float_from_bits(value.as.i64)));
            else stack_push(vm, val_int(nl_float_to_bits(value.as.f64)));
            VM_NEXT();
        }

        VM_CASE(OP_F64_NEG) {
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_FLOAT)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "F64_NEG requires a float");
            stack_push(vm, val_float(-a.as.f64));
            VM_NEXT();
        }

        /* ============================================================
         * Comparison
         * ============================================================ */

        VM_CASE(OP_EQ) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_equal(a, b)));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_NE) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(!val_equal(a, b)));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_LT) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_compare(a, b) < 0));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_LE) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_compare(a, b) <= 0));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_GT) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_compare(a, b) > 0));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_GE) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_compare(a, b) >= 0));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_I64_EQ)
        VM_CASE(OP_I64_NE)
        VM_CASE(OP_I64_LT_S)
        VM_CASE(OP_I64_LE_S)
        VM_CASE(OP_I64_GT_S)
        VM_CASE(OP_I64_GE_S) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag == TAG_ENUM) a = val_int((int64_t)a.as.enum_val);
            if (b.tag == TAG_ENUM) b = val_int((int64_t)b.as.enum_val);
            if (a.tag != TAG_INT || b.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two integers",
                                  isa_get_info(instr->opcode)->name);
            bool result = false;
            if (instr->opcode == OP_I64_EQ) result = a.as.i64 == b.as.i64;
            else if (instr->opcode == OP_I64_NE) result = a.as.i64 != b.as.i64;
            else if (instr->opcode == OP_I64_LT_S) result = a.as.i64 < b.as.i64;
            else if (instr->opcode == OP_I64_LE_S) result = a.as.i64 <= b.as.i64;
            else if (instr->opcode == OP_I64_GT_S) result = a.as.i64 > b.as.i64;
            else result = a.as.i64 >= b.as.i64;
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        VM_CASE(OP_F64_EQ)
        VM_CASE(OP_F64_NE)
        VM_CASE(OP_F64_LT)
        VM_CASE(OP_F64_LE)
        VM_CASE(OP_F64_GT)
        VM_CASE(OP_F64_GE) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_FLOAT || b.tag != TAG_FLOAT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two floats",
                                  isa_get_info(instr->opcode)->name);
            bool result = false;
            if (instr->opcode == OP_F64_EQ) result = a.as.f64 == b.as.f64;
            else if (instr->opcode == OP_F64_NE) result = a.as.f64 != b.as.f64;
            else if (instr->opcode == OP_F64_LT) result = a.as.f64 < b.as.f64;
            else if (instr->opcode == OP_F64_LE) result = a.as.f64 <= b.as.f64;
            else if (instr->opcode == OP_F64_GT) result = a.as.f64 > b.as.f64;
            else result = a.as.f64 >= b.as.f64;
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        /* ============================================================
         * Logic
         * ============================================================ */

        VM_CASE(OP_AND) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_truthy(a) && val_truthy(b)));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_OR) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(val_truthy(a) || val_truthy(b)));
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            VM_NEXT();
        }

        VM_CASE(OP_NOT) {
            NanoValue a = stack_pop(vm);
            stack_push(vm, val_bool(!val_truthy(a)));
            vm_release(&vm->heap, a);
            VM_NEXT();
        }

        VM_CASE(OP_BOOL_AND)
        VM_CASE(OP_BOOL_OR) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_BOOL || b.tag != TAG_BOOL)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two booleans",
                                  isa_get_info(instr->opcode)->name);
            stack_push(vm, val_bool(instr->opcode == OP_BOOL_AND
                                    ? a.as.boolean && b.as.boolean
                                    : a.as.boolean || b.as.boolean));
            VM_NEXT();
        }

        VM_CASE(OP_BOOL_NOT) {
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_BOOL)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "BOOL_NOT requires a boolean");
            stack_push(vm, val_bool(!a.as.boolean));
            VM_NEXT();
        }

        VM_CASE(OP_I64_DIV_U)
        VM_CASE(OP_I64_REM_U)
        VM_CASE(OP_I64_LT_U)
        VM_CASE(OP_I64_LE_U)
        VM_CASE(OP_I64_GT_U)
        VM_CASE(OP_I64_GE_U)
        VM_CASE(OP_I64_AND)
        VM_CASE(OP_I64_OR)
        VM_CASE(OP_I64_XOR)
        VM_CASE(OP_I64_SHL)
        VM_CASE(OP_I64_SHR_S)
        VM_CASE(OP_I64_SHR_U) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_INT || b.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two integers",
                                  isa_get_info(instr->opcode)->name);
            uint64_t ua = (uint64_t)a.as.i64;
            uint64_t ub = (uint64_t)b.as.i64;
            uint32_t shift = (uint32_t)(ub & 63U);
            switch (instr->opcode) {
                case OP_I64_DIV_U: stack_push(vm, val_int(ub ? (int64_t)(ua / ub) : 0)); break;
                case OP_I64_REM_U: stack_push(vm, val_int(ub ? (int64_t)(ua % ub) : 0)); break;
                case OP_I64_LT_U: stack_push(vm, val_bool(ua < ub)); break;
                case OP_I64_LE_U: stack_push(vm, val_bool(ua <= ub)); break;
                case OP_I64_GT_U: stack_push(vm, val_bool(ua > ub)); break;
                case OP_I64_GE_U: stack_push(vm, val_bool(ua >= ub)); break;
                case OP_I64_AND: stack_push(vm, val_int((int64_t)(ua & ub))); break;
                case OP_I64_OR: stack_push(vm, val_int((int64_t)(ua | ub))); break;
                case OP_I64_XOR: stack_push(vm, val_int((int64_t)(ua ^ ub))); break;
                case OP_I64_SHL: stack_push(vm, val_int((int64_t)(ua << shift))); break;
                case OP_I64_SHR_S: stack_push(vm, val_int(a.as.i64 >> shift)); break;
                case OP_I64_SHR_U: stack_push(vm, val_int((int64_t)(ua >> shift))); break;
                default: break;
            }
            VM_NEXT();
        }

        VM_CASE(OP_I64_INVERT) {
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I64_INVERT requires an integer");
            stack_push(vm, val_int((int64_t)~(uint64_t)a.as.i64));
            VM_NEXT();
        }

        VM_CASE(OP_I64_ADD_CARRY)
        VM_CASE(OP_I64_SUB_BORROW) {
            NanoValue carry = stack_pop(vm);
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_INT || b.tag != TAG_INT || carry.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires three integers",
                                  isa_get_info(instr->opcode)->name);
            uint64_t ua = (uint64_t)a.as.i64;
            uint64_t ub = (uint64_t)b.as.i64;
            uint64_t uc = (uint64_t)carry.as.i64 & 1U;
            uint64_t low;
            uint64_t high;
            if (instr->opcode == OP_I64_ADD_CARRY) {
                low = ua + ub;
                high = low < ua;
                uint64_t with_carry = low + uc;
                high |= with_carry < low;
                low = with_carry;
            } else {
                low = ua - ub;
                high = ua < ub;
                uint64_t with_borrow = low - uc;
                high |= low < uc;
                low = with_borrow;
            }
            stack_push(vm, val_int((int64_t)low));
            stack_push(vm, val_int((int64_t)high));
            VM_NEXT();
        }

        VM_CASE(OP_I64_MUL_WIDE_S)
        VM_CASE(OP_I64_MUL_WIDE_U) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_INT || b.tag != TAG_INT)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires two integers",
                                  isa_get_info(instr->opcode)->name);
            uint64_t low;
            uint64_t high;
#if defined(__SIZEOF_INT128__)
            if (instr->opcode == OP_I64_MUL_WIDE_S) {
                __int128 product = (__int128)a.as.i64 * (__int128)b.as.i64;
                low = (uint64_t)product;
                high = (uint64_t)((unsigned __int128)product >> 64);
            } else {
                unsigned __int128 product =
                    (unsigned __int128)(uint64_t)a.as.i64
                    * (unsigned __int128)(uint64_t)b.as.i64;
                low = (uint64_t)product;
                high = (uint64_t)(product >> 64);
            }
#else
#error "NanoISA wide multiplication requires compiler 128-bit integer support"
#endif
            stack_push(vm, val_int((int64_t)low));
            stack_push(vm, val_int((int64_t)high));
            VM_NEXT();
        }

        /* ============================================================
         * Control Flow
         * ============================================================ */

        VM_CASE(OP_JMP) {
            if (vm->profile.enabled) {
                vm->profile.branches++;
                vm->profile.branches_taken++;
            }
            vm->ip = decoded->branch_target_offset;
            VM_NEXT();
        }

        VM_CASE(OP_JMP_TRUE) {
            NanoValue cond = stack_pop(vm);
            bool taken = val_truthy(cond);
            if (vm->profile.enabled) {
                vm->profile.branches++;
                if (taken) vm->profile.branches_taken++;
            }
            if (taken) {
                vm->ip = decoded->branch_target_offset;
            }
            vm_release(&vm->heap, cond);
            VM_NEXT();
        }

        VM_CASE(OP_JMP_FALSE) {
            NanoValue cond = stack_pop(vm);
            bool taken = !val_truthy(cond);
            if (vm->profile.enabled) {
                vm->profile.branches++;
                if (taken) vm->profile.branches_taken++;
            }
            if (taken) {
                vm->ip = decoded->branch_target_offset;
            }
            vm_release(&vm->heap, cond);
            VM_NEXT();
        }

        VM_CASE(OP_CALL) {
            if (vm->profile.enabled) vm->profile.direct_calls++;
            uint32_t callee_idx = decoded->call_target;
            if (callee_idx >= vm->module->function_count) {
                return trap_error(vm, VM_ERR_UNDEFINED_FUNCTION, "Function %u not found", callee_idx);
            }

            const NvmFunctionEntry *callee = &vm->module->functions[callee_idx];

            if (vm->frame_count >= VM_MAX_FRAMES) {
                return trap_error(vm, VM_ERR_CALL_DEPTH, "Call depth exceeded");
            }
            if (!stack_has_operands(vm, callee->arity)) {
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "Function %u needs %u arguments",
                                  callee_idx, callee->arity);
            }

            VmReferenceActivation *next_reference_context=NULL;
            if (owned_execution) {
                next_reference_context=vm_prepare_reference_activation(vm,vm->frame_count);
                if(!next_reference_context)
                    return trap_error(vm,VM_ERR_MEMORY,"I cannot allocate an owned reference context");
                if (!callee_idx || next_reference_context->active ||
                    vm->reference_generation==UINT64_MAX)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a checked bounded owned value activation");
                NvmAffineType parameters[NVM_AFFINE_MAX_PARAMETERS];uint16_t count=0;
                bool valid=false;
                if(mixed_execution) {
                    if(callee_idx>=proof->function_count)
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a checked mixed callee");
                    const NvmMixedSignature *signature=&proof->signatures[callee_idx];
                    count=signature->parameter_count;
                    for(uint16_t p=0;p<count;p++)parameters[p]=(NvmAffineType){signature->parameters[p].tag,signature->parameters[p].global_layout};
                    valid=true;
                } else {
                    NvmAffineState *contract=nvm_affine_state_create(vm->module,callee_idx,callee->local_count);
                    if (!contract) return trap_error(vm,VM_ERR_MEMORY,"I could not allocate consuming parameter facts");
                    valid=nvm_affine_value_parameters(contract,parameters,NVM_AFFINE_MAX_PARAMETERS,&count);
                    nvm_affine_state_free(contract);
                }
                if (!valid || count!=callee->arity)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a complete consuming parameter contract");
                for (uint16_t p=0;p<count;p++) {
                    NanoValue argument=stack_peek(vm,count-1-p);
                    if (argument.tag!=parameters[p].tag ||
                        (argument.tag==TAG_STRUCT && (!argument.as.sval ||
                         argument.as.sval->def_idx!=parameters[p].layout)))
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require exact positional consuming argument types");
                    if (argument.tag==TAG_UNION) {
                        NvmUnionVariantFact fact;
                        if (!argument.as.uval || nvm_ownership_union_variant(vm->module,
                            argument.as.uval->def_idx,argument.as.uval->variant,&fact)!=NVM_V2_OK ||
                            fact.layout!=parameters[p].layout || fact.field_count!=argument.as.uval->field_count)
                            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require exact consuming union argument identity");
                    }
                }
            }

            /* Arguments are already on the stack, pop them into the new frame */
            uint32_t new_base = vm->stack_size - callee->arity;
            VmResult reserved = stack_reserve_frame(vm, new_base, callee);
            if (reserved != VM_OK)
                return trap_error(vm, reserved, "I could not reserve the call frame.");

            if (owned_execution) {
                /* I publish the new activation only after the frame preflight. */
                memset(next_reference_context,0,sizeof(*next_reference_context));
                next_reference_context->active=true;
                next_reference_context->generation=++vm->reference_generation;
            }

            /* Allocate space for remaining locals */
            for (uint16_t i = callee->arity; i < callee->local_count; i++) {
                stack_push(vm, val_void());
            }

            VmCallFrame *new_frame = &vm->frames[vm->frame_count++];
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
            if(record_execution && vm->frame_count>record_array->maximum_frames)
                record_array->maximum_frames=vm->frame_count;
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution && vm->frame_count>record_map->owner->maximum_frames)
                record_map->owner->maximum_frames=vm->frame_count;
#endif
            new_frame->fn_idx = callee_idx;
            new_frame->return_ip = vm->ip;
            new_frame->instruction_ip = callee->code_offset;
            new_frame->effect_owner = 0;
            new_frame->stack_base = new_base;
            new_frame->local_count = callee->local_count;
            /* I retain the active environment for a direct recursive call. */
            bool recursive_closure = callee_idx == frame->fn_idx && callee->upvalue_count;
            new_frame->closure = recursive_closure ? frame->closure : NULL;
            new_frame->owned_callable = recursive_closure ? frame->owned_callable : val_void();
            if (recursive_closure) vm_retain(&vm->heap, new_frame->owned_callable);
            new_frame->module = vm->module;
            new_frame->current_line = 0;
            new_frame->current_col  = 0;

            /* Save current execution context */
            frame = new_frame;
            vm->current_fn = callee_idx;
            vm->ip = callee->code_offset;
            cur_fn = callee;
            code_end = callee->code_offset + callee->code_length;
            VM_NEXT();
        }

        VM_CASE(OP_TAIL_CALL) {
            if (frame->effect_owner)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I cannot tail-call from an effect activation.");
            effect_prune(vm, vm->frame_count - 1);
            if (vm->profile.enabled) vm->profile.direct_calls++;
            uint32_t callee_idx = decoded->call_target;
            if (callee_idx >= vm->module->function_count)
                return trap_error(vm, VM_ERR_UNDEFINED_FUNCTION,
                                  "Tail-call function %u not found", callee_idx);
            const NvmFunctionEntry *callee = &vm->module->functions[callee_idx];
            if (callee->result_count != cur_fn->result_count
                    || callee->result_tag != cur_fn->result_tag)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "Tail-call result signature mismatch");
            if (!stack_has_operands(vm, callee->arity))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "Tail-call function %u needs %u arguments",
                                  callee_idx, callee->arity);

            if(admitted && proof->ordinary_arrays) {
                if(frame->stack_base>vm->stack_size || frame->local_count>vm->stack_size-frame->stack_base ||
                   vm->stack_size-frame->stack_base-frame->local_count!=callee->arity)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I require exactly the admitted tail arguments.");
                VmResult checked=vm_tail_arguments_preflight(vm,callee,callee_idx);
                if(checked!=VM_OK)return trap_error(vm,checked,"I could not stage every admitted tail argument.");
            }
            VmResult reserved = stack_reserve_frame(vm, frame->stack_base, callee);
            if (reserved != VM_OK)
                return trap_error(vm, reserved, "I could not reserve the tail-call frame.");
            NanoValue inline_args[16];
            NanoValue *args = callee->arity <= 16 ? inline_args
                : malloc((size_t)callee->arity * sizeof(*args));
            if (!args)
                return trap_error(vm, VM_ERR_MEMORY,
                                  "Tail-call argument allocation failed");
            uint32_t args_start = vm->stack_size - callee->arity;
            for (uint16_t i = 0; i < callee->arity; i++) {
                args[i] = vm->stack[args_start + i];
                vm_retain(&vm->heap, args[i]);
            }

            while (vm->stack_size > frame->stack_base) {
                NanoValue value = stack_pop(vm);
                vm_release(&vm->heap, value);
            }
            for (uint16_t i = 0; i < callee->arity; i++)
                stack_push(vm, args[i]);
            if (args != inline_args) free(args);
            for (uint16_t i = callee->arity; i < callee->local_count; i++)
                stack_push(vm, val_void());

            /* I preserve the environment when this frame recurs into itself. */
            bool recursive_closure = callee_idx == frame->fn_idx && callee->upvalue_count;
            if (!recursive_closure) {
                vm_release(&vm->heap, frame->owned_callable);
                frame->closure = NULL;
                frame->owned_callable = val_void();
            }
            frame->fn_idx = callee_idx;
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution && vm->frame_count==1)record_map->active_root=callee_idx;
#endif
            if(borrowed_map_execution && vm->frame_count==1)borrowed_map->active_root=callee_idx;
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
            if(union_execution && vm->frame_count==1)union_field->active_root=callee_idx;
#endif
            if(admitted && proof->ordinary_arrays && vm->frame_count==1)
                *proof->ordinary_active_root=callee_idx;
            frame->instruction_ip = callee->code_offset;
            frame->local_count = callee->local_count;
            frame->current_line = 0;
            frame->current_col = 0;
            vm->current_fn = callee_idx;
            vm->ip = callee->code_offset;
            cur_fn = callee;
            code_end = callee->code_offset + callee->code_length;
            VM_NEXT();
        }

        VM_CASE(OP_CALL_INDIRECT) {
            if (vm->profile.enabled) vm->profile.indirect_calls++;
            if (!stack_has_operands(vm, (uint32_t)instr->operands[0].u16 + 1))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need the callable and all indirect-call arguments.");
            NanoValue fn_val = stack_peek(vm, 0);
            if (fn_val.tag == TAG_FUNCTION || fn_val.tag == TAG_CLOSURE) {
                VmClosure *closure = NULL;
                uint32_t callee_idx;
                const NvmModule *callee_module;
                if (!vm_callable_target(vm, fn_val, &callee_module, &callee_idx))
                    return trap_error(vm, VM_ERR_UNDEFINED_FUNCTION, "I cannot resolve this callable's module and function.");
                if (fn_val.tag == TAG_CLOSURE) closure = fn_val.as.closure;

                const NvmFunctionEntry *callee = &callee_module->functions[callee_idx];

                /* The instruction declares the shape the verifier proved this
                 * function's stack discipline against. The callee is only
                 * known now, so this is where the two are compared: a
                 * mismatch means the proof does not describe what is about to
                 * run. */
                if (instr->operands[0].u16 != callee->arity
                        || instr->operands[1].u16 != callee->result_count) {
                    return trap_error(vm, VM_ERR_TYPE_ERROR,
                                      "Indirect call declares %u->%u but function %u is %u->%u",
                                      instr->operands[0].u16, instr->operands[1].u16,
                                      callee_idx, callee->arity, callee->result_count);
                }

                if (vm->frame_count >= VM_MAX_FRAMES) {
                    return trap_error(vm, VM_ERR_CALL_DEPTH, "Call depth exceeded");
                }
                if (!stack_has_operands(vm, (uint32_t)callee->arity + 1)) {
                    return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                      "Function %u needs %u arguments",
                                      callee_idx, callee->arity);
                }

                /* Transfer ownership only after every call validation passes. */
                uint32_t new_base = vm->stack_size - 1 - callee->arity;
                VmResult reserved = stack_reserve_frame(vm, new_base, callee);
                if (reserved != VM_OK)
                    return trap_error(vm, reserved, "I could not reserve the indirect-call frame.");
                fn_val = stack_pop(vm);
                for (uint16_t i = callee->arity; i < callee->local_count; i++) {
                    stack_push(vm, val_void());
                }

                VmCallFrame *new_frame = &vm->frames[vm->frame_count++];
                new_frame->fn_idx = callee_idx;
                new_frame->return_ip = vm->ip;
                new_frame->instruction_ip = callee->code_offset;
                new_frame->effect_owner = 0;
            new_frame->stack_base = new_base;
                new_frame->local_count = callee->local_count;
                new_frame->closure = closure;
                new_frame->module = callee_module;
                /* stack_pop transferred the callable's reference to fn_val;
                 * the frame takes it from here and releases it on teardown. */
                new_frame->owned_callable = fn_val;
            new_frame->current_line = 0;
            new_frame->current_col  = 0;

                frame = new_frame;
                vm->module = callee_module;
                vm->current_fn = callee_idx;
                vm->ip = callee->code_offset;
                cur_fn = callee;
                code_end = callee->code_offset + callee->code_length;
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR, "CALL_INDIRECT: not a function");
            }
            VM_NEXT();
        }

        VM_CASE(OP_HANDLER_PUSH) {
            if (instr->operands[0].u32 >= vm->module->string_count ||
                (uint32_t)instr->operands[2].u16 + instr->operands[3].u16 > frame->local_count)
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "I require valid handler names and local slots.");
            if (vm->handler_count == VM_MAX_FRAMES)
                return trap_error(vm, VM_ERR_CALL_DEPTH, "I exceeded my effect handler limit.");
            VmEffectHandler *handler = &vm->handlers[vm->handler_count++];
            *handler = (VmEffectHandler){vm->module, instr->operands[0].u32,
                decoded->branch_target_offset, vm->frame_count - 1,
                instr->operands[2].u16, instr->operands[3].u16};
            VM_NEXT();
        }
        VM_CASE(OP_HANDLER_POP) {
            uint16_t count = instr->operands[0].u16;
            if (count > vm->handler_count)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I cannot pop absent effect handlers.");
            for (uint16_t i = 0; i < count; i++) {
                if (vm->handlers[vm->handler_count - 1].owner != vm->frame_count - 1)
                    return trap_error(vm, VM_ERR_TYPE_ERROR, "I cannot pop another frame's handler.");
                vm->handler_count--;
            }
            VM_NEXT();
        }
        VM_CASE(OP_PERFORM) {
            if (instr->operands[0].u32 >= vm->module->string_count)
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "I require a valid effect name.");
            const char *operation = vm->module->strings[instr->operands[0].u32];
            VmEffectHandler *handler = NULL;
            for (uint32_t i = vm->handler_count; i > 0; i--) {
                VmEffectHandler *candidate = &vm->handlers[i - 1];
                if (candidate->owner >= vm->activation_floor &&
                    !strcmp(operation, candidate->module->strings[candidate->operation])) {
                    handler = candidate; break;
                }
            }
            if (!handler)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I found no handler for %s.", operation);
            uint16_t argc = instr->operands[1].u16;
            if (argc != handler->parameter_count)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I require matching effect argument counts.");
            if (vm->frame_count == VM_MAX_FRAMES)
                return trap_error(vm, VM_ERR_CALL_DEPTH, "I exceeded my effect activation limit.");
            VmReferenceActivation *activation_context=NULL;
            if(owned_execution) {
                activation_context=vm_prepare_reference_activation(vm,vm->frame_count);
                if(!activation_context)
                    return trap_error(vm,VM_ERR_MEMORY,"I cannot allocate an effect reference context");
                if(activation_context->active || vm->reference_generation==UINT64_MAX)
                    return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a fresh owned effect activation");
            }
            VmCallFrame *owner = &vm->frames[handler->owner];
            const NvmFunctionEntry *function = &handler->module->functions[owner->fn_idx];
            uint32_t base = vm->stack_size - argc;
            if (stack_reserve_frame(vm, base, function) != VM_OK)
                return trap_error(vm, VM_ERR_MEMORY, "I cannot reserve an effect activation.");
            if(activation_context) {
                memset(activation_context,0,sizeof(*activation_context));
                activation_context->active=true;
                activation_context->generation=++vm->reference_generation;
            }
            /* Move ordered arguments above the caller's operand stack into
             * their lexical slots; all other activation slots begin void. */
            memmove(&vm->stack[base + handler->parameter_start], &vm->stack[base],
                    argc * sizeof(NanoValue));
            for (uint16_t i = 0; i < function->local_count; i++)
                if (i < handler->parameter_start || i >= handler->parameter_start + argc)
                    vm->stack[base + i] = val_void();
            vm->stack_size = base + function->local_count;
            VmCallFrame *activation = &vm->frames[vm->frame_count++];
            *activation = *owner;
            activation->stack_base = base;
            activation->effect_owner = handler->owner + 1;
            activation->effect_local_start = handler->parameter_start;
            activation->owned_callable = val_void();
            activation->return_ip = vm->ip;
            activation->instruction_ip = handler->target;
            frame = activation;
            vm->module = handler->module;
            vm->current_fn = owner->fn_idx;
            vm->ip = handler->target;
            cur_fn = function;
            code_end = function->code_offset + function->code_length;
            VM_NEXT();
        }
        VM_CASE(OP_EFFECT_RESUME) {
            if (!frame->effect_owner || vm->stack_size != frame->stack_base + frame->local_count + 1)
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I can resume only an active effect with one result.");
            NanoValue value = stack_pop(vm);
            while (vm->stack_size > frame->stack_base) vm_release(&vm->heap, stack_pop(vm));
            uint32_t return_ip = frame->return_ip;
            if(owned_execution)vm_end_reference_activation(vm,vm->frame_count-1);
            vm->frame_count--;
            effect_prune(vm, vm->frame_count);
            frame = &vm->frames[vm->frame_count - 1];
            vm->module = frame->module;
            vm->current_fn = frame->fn_idx;
            vm->ip = return_ip;
            cur_fn = &vm->module->functions[frame->fn_idx];
            code_end = cur_fn->code_offset + cur_fn->code_length;
            stack_push(vm, value);
            VM_NEXT();
        }
        VM_CASE(OP_RET) {
            if (frame->effect_owner) {
                uint32_t owner = frame->effect_owner - 1;
                while (vm->frames[owner].effect_owner)
                    owner = vm->frames[owner].effect_owner - 1;
                uint8_t count = vm->module->functions[frame->fn_idx].result_count;
                if (vm->stack_size != frame->stack_base + frame->local_count + count)
                    return trap_error(vm, VM_ERR_TYPE_ERROR, "I require the lexical return result shape.");
                NanoValue results[UINT8_MAX];
                for (uint8_t i = count; i > 0; i--) results[i - 1] = stack_pop(vm);
                uint32_t keep = vm->frames[owner].stack_base + vm->frames[owner].local_count;
                while (vm->stack_size > keep) vm_release(&vm->heap, stack_pop(vm));
                while (vm->frame_count > owner + 1) {
                    if(owned_execution)vm_end_reference_activation(vm,vm->frame_count-1);
                    vm_release(&vm->heap, vm->frames[--vm->frame_count].owned_callable);
                    vm->frames[vm->frame_count].owned_callable = val_void();
                }
                effect_prune(vm, vm->frame_count);
                frame = &vm->frames[owner];
                vm->module = frame->module;
                vm->current_fn = frame->fn_idx;
                for (uint8_t i = 0; i < count; i++) stack_push(vm, results[i]);
            }
vm_return_values: ;
            /* Implicit completion shares ordinary cleanup, not lexical effect unwind. */
            const NvmFunctionEntry *returning =
                &vm->module->functions[frame->fn_idx];
            uint32_t actual_results = vm->stack_size
                - frame->stack_base - frame->local_count;
            if (actual_results != returning->result_count) {
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "Function %u returned %u values, expected %u",
                                  frame->fn_idx, actual_results,
                                  returning->result_count);
            }
            NanoValue results[UINT8_MAX];
            for (uint8_t i = 0; i < returning->result_count; i++) {
                results[i] = vm->stack[vm->stack_size - returning->result_count + i];
                /* I admit only zero as the integer spelling of opaque null. */
                if (returning->result_tag == TAG_OPAQUE &&
                    results[i].tag == TAG_INT && results[i].as.i64 == 0) {
                    results[i] = (NanoValue){0};
                    results[i].tag = TAG_OPAQUE;
                }
                if (!result_tag_matches(returning->result_tag, results[i].tag)) {
                    return trap_error(vm, VM_ERR_TYPE_ERROR,
                                      "Function %u returned %s, expected %s",
                                      frame->fn_idx, isa_tag_name(results[i].tag),
                                      isa_tag_name(returning->result_tag));
                }
            }
            if (owned_execution) {
                if (returning->result_tag==TAG_STRUCT) {
                    /* I validate while the pending owner is still a stack root.
                     * Scalar/void count and tag checks need no extra facts. */
                    NvmAffineType type;uint16_t fields=0;
                    bool valid=false;
                    if(mixed_execution) {
                        if(frame->fn_idx>=proof->function_count)
                            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a checked mixed result");
                        const NvmMixedSignature *signature=&proof->signatures[frame->fn_idx];
                        type=(NvmAffineType){signature->result.tag,signature->result.global_layout};
                        fields=signature->result_fields;
                        valid=signature->result.category==NVM_MIXED_VALUE_OWNER;
                    } else {
                        NvmAffineState *contract=nvm_affine_state_create(vm->module,frame->fn_idx,returning->local_count);
                        if (!contract) return trap_error(vm,VM_ERR_MEMORY,"I cannot load owned return facts");
                        valid=nvm_affine_value_result(contract,&type,&fields);
                        nvm_affine_state_free(contract);
                    }
                    if (!valid || type.tag!=TAG_STRUCT || !results[0].as.sval ||
                        results[0].as.sval->def_idx!=type.layout || results[0].as.sval->field_count!=fields)
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require an exact declared owned result");
                }
                if (returning->result_tag==TAG_UNION) {
                    NvmAffineState *contract=nvm_affine_state_create(vm->module,frame->fn_idx,returning->local_count);
                    NvmAffineType type;uint16_t fields=0;NvmUnionVariantFact fact;
                    bool valid=nvm_affine_value_result(contract,&type,&fields);
                    nvm_affine_state_free(contract);
                    VmUnion *value=results[0].as.uval;
                    if (!valid || type.tag!=TAG_UNION || !value ||
                        nvm_ownership_union_variant(vm->module,value->def_idx,value->variant,&fact)!=NVM_V2_OK ||
                        fact.layout!=type.layout || fact.field_count!=value->field_count)
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require an exact declared union result");
                }
                /* The returned operand already fits this stack. I establish
                 * publication capacity before removing any callee roots. */
                VmResult reserved=stack_reserve(vm,(uint64_t)frame->stack_base+returning->result_count);
                if (reserved!=VM_OK) return trap_error(vm,reserved,"I cannot reserve an owned return result");
                vm_end_reference_activation(vm,vm->frame_count-1);
            }
            vm->stack_size -= returning->result_count;

            /* Clean up locals */
            while (vm->stack_size > frame->stack_base) {
                NanoValue v = stack_pop(vm);
                vm_release(&vm->heap, v);
            }
            /* Save the returning function's return_ip (points to instruction
             * after the CALL in the caller) before we pop the frame */
            uint32_t ret_ip = frame->return_ip;

            vm_release(&vm->heap, frame->owned_callable);
            frame->owned_callable = val_void();
            vm->frame_count--;
            effect_prune(vm, vm->frame_count);

            if (vm->frame_count == vm->activation_floor) {
                for (uint8_t i = 0; i < returning->result_count; i++)
                    stack_push(vm, results[i]);
                return trap_none();
            }

            /* Restore caller's frame context, but use callee's return_ip */
            frame = &vm->frames[vm->frame_count - 1];
            vm->current_fn = frame->fn_idx;
            vm->ip = ret_ip;
            vm->module = frame->module;  /* Restore caller's module */
            const NvmFunctionEntry *caller_fn = &vm->module->functions[frame->fn_idx];
            cur_fn = caller_fn;
            code_end = caller_fn->code_offset + caller_fn->code_length;

            for (uint8_t i = 0; i < returning->result_count; i++)
                stack_push(vm, results[i]);
            VM_NEXT();
        }

        VM_CASE(OP_CALL_EXTERN) {
            if (vm->profile.enabled) {
                vm->profile.extern_calls++;
                vm->profile.traps++;
            }
            uint32_t import_idx = instr->operands[0].u32;

            /* Determine arg count from import table */
            if (import_idx >= vm->module->import_count) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                "Import index %u out of range", import_idx);
            }
            int ext_argc = vm->module->imports[import_idx].param_count;

            /* Foreign calls share a single argument limit across imports,
             * traps, direct FFI, and co-process dispatch. The verifier
             * rejects imports past NANO_MAX_FFI_ARGS, but guard here too so
             * an unverified module traps cleanly instead of overrunning the
             * fixed trap argument buffer. */
            if (ext_argc > NANO_MAX_FFI_ARGS) {
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                "Import %u declares %d args, exceeding the "
                                "foreign-call argument limit of %d",
                                import_idx, ext_argc, NANO_MAX_FFI_ARGS);
            }

            /* Pop arguments from stack (they were pushed left-to-right,
             * so pop in reverse to get them in order) */
            if (!stack_has_operands(vm, (uint32_t)ext_argc))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "I need %d operands for the foreign call.", ext_argc);
            uint32_t result_slots = vm->module->imports[import_idx].return_type
                == TAG_VOID ? 0 : 1;
            if (stack_reserve(vm, (uint64_t)vm->stack_size - (uint32_t)ext_argc
                                   + result_slots) != VM_OK)
                return trap_error(vm, VM_ERR_MEMORY,
                                  "I could not reserve the foreign-call result slot.");
            VmTrap t = { .type = TRAP_EXTERN_CALL };
            t.data.extern_call.import_idx = import_idx;
            t.data.extern_call.argc = ext_argc;
            for (int i = t.data.extern_call.argc - 1; i >= 0; i--) {
                t.data.extern_call.args[i] = stack_pop(vm);
            }
            return t;
        }

        VM_CASE(OP_CALL_MODULE) {
            if (vm->profile.enabled) vm->profile.module_calls++;

            /* Follow the callable handle bound during linking rather than
             * re-index the module/function tables on every call. An
             * unresolved handle means the operand pair was out of range at
             * link time; report the same errors the pair would have. */
            const VmCallHandle *handle = &decoded->call_handle;
            if (!handle->resolved) {
                uint32_t mod_idx = instr->operands[0].u32;
                uint32_t fn_idx_bad = instr->operands[1].u32;
                if (mod_idx >= vm->linked_module_count) {
                    return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                        "Module index %u out of range (have %u)", mod_idx,
                        vm->linked_module_count);
                }
                return trap_error(vm, VM_ERR_UNDEFINED_FUNCTION,
                    "Function %u not found in module %u", fn_idx_bad, mod_idx);
            }
            const NvmModule *target = handle->module;
            uint32_t fn_idx_m = handle->function_index;
            const NvmFunctionEntry *callee = handle->function;

            if (instr->operands[2].u16 != callee->arity
                    || instr->operands[3].u16 != callee->result_count)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "I declared a linked call %u->%u, but its target is %u->%u.",
                                  instr->operands[2].u16, instr->operands[3].u16,
                                  callee->arity, callee->result_count);

            if (vm->frame_count >= VM_MAX_FRAMES) {
                return trap_error(vm, VM_ERR_CALL_DEPTH, "Call depth exceeded");
            }
            if (!stack_has_operands(vm, callee->arity)) {
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "Function %u needs %u arguments",
                                  fn_idx_m, callee->arity);
            }

            uint32_t new_base = vm->stack_size - callee->arity;
            VmResult reserved = stack_reserve_frame(vm, new_base, callee);
            if (reserved != VM_OK)
                return trap_error(vm, reserved, "I could not reserve the linked-call frame.");
            for (uint16_t i = callee->arity; i < callee->local_count; i++) {
                stack_push(vm, val_void());
            }

            /* Create frame for the callee in the target module.
             * frame->module stores the module the callee runs in, so that
             * OP_RET can correctly restore vm->module to the caller's module. */
            VmCallFrame *new_frame = &vm->frames[vm->frame_count++];
            new_frame->fn_idx = fn_idx_m;
            new_frame->return_ip = vm->ip;
            new_frame->instruction_ip = callee->code_offset;
            new_frame->effect_owner = 0;
            new_frame->stack_base = new_base;
            new_frame->local_count = callee->local_count;
            new_frame->closure = NULL;
            new_frame->owned_callable = val_void();
            new_frame->module = target;  /* This frame runs in the target module */
            new_frame->current_line = 0;
            new_frame->current_col  = 0;

            /* Switch to target module */
            vm->module = target;
            frame = new_frame;
            vm->current_fn = fn_idx_m;
            vm->ip = callee->code_offset;
            cur_fn = callee;
            code_end = callee->code_offset + callee->code_length;
            VM_NEXT();
        }

        /* ============================================================
         * String Ops
         * ============================================================ */

        VM_CASE(OP_STR_LEN) {
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING) {
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_LEN: not a string");
            }
            int64_t len = vmstring_len(s.as.string);
            vm_release(&vm->heap, s);
            stack_push(vm, val_int(len));
            VM_NEXT();
        }

        VM_CASE(OP_STR_CONCAT) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_STRING || b.tag != TAG_STRING) {
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_CONCAT: not strings");
            }
            VmString *result = vm_string_concat(&vm->heap, a.as.string, b.as.string);
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            if (!result)
                return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the concatenated string.");
            stack_push(vm, val_string(result));
            VM_NEXT();
        }

        VM_CASE(OP_STR_SUBSTR) {
            NanoValue len_v = stack_pop(vm);
            NanoValue start_v = stack_pop(vm);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING) {
                vm_release(&vm->heap, s);
                vm_release(&vm->heap, start_v);
                vm_release(&vm->heap, len_v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_SUBSTR: not a string");
            }
            uint32_t start = (uint32_t)(start_v.tag == TAG_INT ? start_v.as.i64 : 0);
            uint32_t len = (uint32_t)(len_v.tag == TAG_INT ? len_v.as.i64 : 0);
            VmString *result = vm_string_substr(&vm->heap, s.as.string, start, len);
            vm_release(&vm->heap, s);
            vm_release(&vm->heap, start_v);
            vm_release(&vm->heap, len_v);
            if (!result)
                return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the substring.");
            stack_push(vm, val_string(result));
            VM_NEXT();
        }

        VM_CASE(OP_STR_CONTAINS) {
            NanoValue needle = stack_pop(vm);
            NanoValue haystack = stack_pop(vm);
            if (haystack.tag != TAG_STRING || needle.tag != TAG_STRING) {
                vm_release(&vm->heap, haystack);
                vm_release(&vm->heap, needle);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_CONTAINS: not strings");
            }
            bool result = vmstring_contains(haystack.as.string, needle.as.string);
            vm_release(&vm->heap, haystack);
            vm_release(&vm->heap, needle);
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        VM_CASE(OP_STR_EQ) {
            NanoValue b = stack_pop(vm);
            NanoValue a = stack_pop(vm);
            if (a.tag != TAG_STRING || b.tag != TAG_STRING) {
                vm_release(&vm->heap, a);
                vm_release(&vm->heap, b);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_EQ: not strings");
            }
            bool result = vmstring_equal(a.as.string, b.as.string);
            vm_release(&vm->heap, a);
            vm_release(&vm->heap, b);
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        VM_CASE(OP_STR_CHAR_AT) {
            NanoValue idx_v = stack_pop(vm);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING) {
                vm_release(&vm->heap, idx_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_CHAR_AT: not a string");
            }
            int64_t idx = (idx_v.tag == TAG_INT ? idx_v.as.i64 : 0);
            const char *str = vmstring_cstr(s.as.string);
            int64_t len = (int64_t)vmstring_len(s.as.string);
            int64_t ch = (idx >= 0 && idx < len) ? (unsigned char)str[idx] : -1;
            vm_release(&vm->heap, idx_v);
            vm_release(&vm->heap, s);
            stack_push(vm, val_int(ch));
            VM_NEXT();
        }

        VM_CASE(OP_STR_FROM_INT) {
            NanoValue v = stack_pop(vm);
            VmString *s = vm_string_from_int(&vm->heap, v.tag == TAG_INT ? v.as.i64 : 0);
            vm_release(&vm->heap, v);
            if (!s)
                return trap_error(vm, VM_ERR_MEMORY, "I could not format the primitive numeric string.");
            stack_push(vm, val_string(s));
            VM_NEXT();
        }

        VM_CASE(OP_STR_FROM_FLOAT) {
            NanoValue v = stack_pop(vm);
            VmString *s = vm_string_from_float(&vm->heap, v.tag == TAG_FLOAT ? v.as.f64 : 0.0);
            vm_release(&vm->heap, v);
            if (!s)
                return trap_error(vm, VM_ERR_MEMORY, "I could not format the primitive numeric string.");
            stack_push(vm, val_string(s));
            VM_NEXT();
        }

        VM_CASE(OP_STR_TRIM) {
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING) {
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_TRIM: not a string");
            }
            const char *str = vmstring_cstr(s.as.string);
            int64_t len = (int64_t)vmstring_len(s.as.string);
            int64_t start = 0;
            while (start < len && (str[start] == ' ' || str[start] == '\t' ||
                                   str[start] == '\n' || str[start] == '\r')) {
                start++;
            }
            int64_t end = len;
            while (end > start && (str[end - 1] == ' ' || str[end - 1] == '\t' ||
                                   str[end - 1] == '\n' || str[end - 1] == '\r')) {
                end--;
            }
            VmString *out = vm_string_new(&vm->heap, str + start, (uint32_t)(end - start));
            vm_release(&vm->heap, s);
            if (!out)
                return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the trimmed string.");
            stack_push(vm, val_string(out));
            VM_NEXT();
        }

        VM_CASE(OP_STR_TO_LOWER)
        VM_CASE(OP_STR_TO_UPPER) {
            bool to_lower = (instr->opcode == OP_STR_TO_LOWER);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING) {
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  to_lower ? "STR_TO_LOWER: not a string"
                                           : "STR_TO_UPPER: not a string");
            }
            const char *str = vmstring_cstr(s.as.string);
            int64_t len = (int64_t)vmstring_len(s.as.string);
            /* Strings are interned/immutable, so transform into a scratch
             * buffer and only then construct the result string. */
            if ((uint64_t)len >= SIZE_MAX) {
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_MEMORY, "I cannot represent the case-conversion scratch size.");
            }
            char stackbuf[256];
            char *buf = (len < (int64_t)sizeof(stackbuf)) ? stackbuf
                                                          : malloc((size_t)len + 1);
            if (!buf) {
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_MEMORY, "STR_TO_LOWER/UPPER: alloc failed");
            }
            for (int64_t i = 0; i < len; i++) {
                unsigned char c = (unsigned char)str[i];
                if (to_lower) {
                    buf[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : (char)c;
                } else {
                    buf[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
                }
            }
            buf[len] = '\0';
            VmString *out = vm_string_new(&vm->heap, buf, (uint32_t)len);
            if (buf != stackbuf) free(buf);
            vm_release(&vm->heap, s);
            if (!out)
                return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the case-converted string.");
            stack_push(vm, val_string(out));
            VM_NEXT();
        }

        VM_CASE(OP_STR_STARTS_WITH)
        VM_CASE(OP_STR_ENDS_WITH) {
            bool starts = (instr->opcode == OP_STR_STARTS_WITH);
            NanoValue affix_v = stack_pop(vm);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING || affix_v.tag != TAG_STRING) {
                vm_release(&vm->heap, affix_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  starts ? "STR_STARTS_WITH: not a string"
                                         : "STR_ENDS_WITH: not a string");
            }
            const char *str = vmstring_cstr(s.as.string);
            const char *affix = vmstring_cstr(affix_v.as.string);
            size_t slen = vmstring_len(s.as.string);
            size_t alen = vmstring_len(affix_v.as.string);
            bool result;
            if (alen > slen) {
                result = false;
            } else if (alen == 0) {
                result = true;
            } else if (starts) {
                result = memcmp(str, affix, alen) == 0;
            } else {
                result = memcmp(str + slen - alen, affix, alen) == 0;
            }
            vm_release(&vm->heap, affix_v);
            vm_release(&vm->heap, s);
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        VM_CASE(OP_STR_SPLIT) {
            NanoValue delim_v = stack_pop(vm);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING || delim_v.tag != TAG_STRING) {
                vm_release(&vm->heap, delim_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_SPLIT: not a string");
            }
            const char *str = vmstring_cstr(s.as.string);
            const char *delim = vmstring_cstr(delim_v.as.string);
            size_t slen = vmstring_len(s.as.string);
            size_t dlen = vmstring_len(delim_v.as.string);
            VmArray *arr = vm_array_new(&vm->heap, TAG_STRING, 8);
            if (!arr) goto split_allocation_failed;
            if (dlen == 0) {
                /* Empty delimiter: split into individual characters. */
                for (size_t i = 0; i < slen; i++) {
                    VmString *ch = vm_string_new(&vm->heap, str + i, 1);
                    if (!ch || !vm_array_push(&vm->heap, arr, val_string(ch))) {
                        vm_release(&vm->heap, val_string(ch));
                        goto split_allocation_failed;
                    }
                    vm_release(&vm->heap, val_string(ch));
                }
            } else {
                const char *start = str;
                const char *end = str + slen;
                const char *found;
                while ((found = vm_mem_find(start, (size_t)(end - start),
                                            delim, dlen)) != NULL) {
                    VmString *seg = vm_string_new(&vm->heap, start,
                                                  (uint32_t)(found - start));
                    if (!seg || !vm_array_push(&vm->heap, arr, val_string(seg))) {
                        vm_release(&vm->heap, val_string(seg));
                        goto split_allocation_failed;
                    }
                    vm_release(&vm->heap, val_string(seg));
                    start = found + dlen;
                }
                VmString *rest = vm_string_new(&vm->heap, start,
                                               (uint32_t)(end - start));
                if (!rest || !vm_array_push(&vm->heap, arr, val_string(rest))) {
                    vm_release(&vm->heap, val_string(rest));
                    goto split_allocation_failed;
                }
                vm_release(&vm->heap, val_string(rest));
            }
            vm_release(&vm->heap, delim_v);
            vm_release(&vm->heap, s);
            stack_push(vm, val_array(arr));
            VM_NEXT();
        split_allocation_failed:
            vm_release(&vm->heap, val_array(arr));
            vm_release(&vm->heap, delim_v);
            vm_release(&vm->heap, s);
            return trap_error(vm, VM_ERR_MEMORY, "I could not build the split result.");
        }

        VM_CASE(OP_STR_REPLACE) {
            /* Args were pushed s, old, new -> pop in reverse. */
            NanoValue new_v = stack_pop(vm);
            NanoValue old_v = stack_pop(vm);
            NanoValue s = stack_pop(vm);
            if (s.tag != TAG_STRING || old_v.tag != TAG_STRING || new_v.tag != TAG_STRING) {
                vm_release(&vm->heap, new_v);
                vm_release(&vm->heap, old_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STR_REPLACE: not a string");
            }
            const char *str = vmstring_cstr(s.as.string);
            const char *old_str = vmstring_cstr(old_v.as.string);
            const char *new_str = vmstring_cstr(new_v.as.string);
            size_t slen = vmstring_len(s.as.string);
            size_t olen = vmstring_len(old_v.as.string);
            if (olen == 0) {
                /* Empty needle: return the input unchanged (matches runtime). */
                VmString *copy = vm_string_new(&vm->heap, str, (uint32_t)slen);
                vm_release(&vm->heap, new_v);
                vm_release(&vm->heap, old_v);
                vm_release(&vm->heap, s);
                if (!copy)
                    return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the replacement string.");
                stack_push(vm, val_string(copy));
                VM_NEXT();
            }
            size_t nlen = vmstring_len(new_v.as.string);
            const char *str_end = str + slen;
            /* Count occurrences to size the output buffer. */
            size_t count = 0;
            const char *p = str;
            const char *found;
            while ((found = vm_mem_find(p, (size_t)(str_end - p), old_str, olen)) != NULL) {
                count++; p = found + olen;
            }
            uint32_t checked_length;
            if (!vm_string_replacement_length((uint32_t)slen, (uint32_t)olen,
                                               (uint32_t)nlen, count, &checked_length) ||
                (uint64_t)checked_length + 1 > SIZE_MAX) {
                vm_release(&vm->heap, new_v);
                vm_release(&vm->heap, old_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_MEMORY, "I cannot represent the replacement result size.");
            }
            size_t out_len = checked_length;
            char stackbuf[512];
            char *buf = (out_len < sizeof(stackbuf)) ? stackbuf : malloc(out_len + 1);
            if (!buf) {
                vm_release(&vm->heap, new_v);
                vm_release(&vm->heap, old_v);
                vm_release(&vm->heap, s);
                return trap_error(vm, VM_ERR_MEMORY, "STR_REPLACE: alloc failed");
            }
            char *dst = buf;
            const char *src = str;
            while ((found = vm_mem_find(src, (size_t)(str_end - src), old_str, olen)) != NULL) {
                size_t seg = (size_t)(found - src);
                memcpy(dst, src, seg); dst += seg;
                memcpy(dst, new_str, nlen); dst += nlen;
                src = found + olen;
            }
            size_t rest = (size_t)(str_end - src);
            memcpy(dst, src, rest); dst += rest;
            VmString *out = vm_string_new(&vm->heap, buf, (uint32_t)(dst - buf));
            if (buf != stackbuf) free(buf);
            vm_release(&vm->heap, new_v);
            vm_release(&vm->heap, old_v);
            vm_release(&vm->heap, s);
            if (!out)
                return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the replacement string.");
            stack_push(vm, val_string(out));
            VM_NEXT();
        }

        /* ============================================================
         * Array Ops
         * ============================================================ */

        VM_CASE(OP_ARR_NEW) {
            uint8_t elem_type = instr->operands[0].u8;
            VmArray *a = vm_array_new(&vm->heap, elem_type, 8);
            if (!a) return trap_error(vm, VM_ERR_MEMORY, "I could not create the array.");
            stack_push(vm, val_array(a));
            VM_NEXT();
        }

        VM_CASE(OP_ARR_PUSH) {
            NanoValue v = stack_pop(vm);
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_PUSH: not an array");
            }
            if (!vm_array_push(&vm->heap, arr.as.array, v)) {
                vm_release(&vm->heap, v);
                vm_release(&vm->heap, arr);
                return trap_error(vm, VM_ERR_MEMORY, "I could not append the array element.");
            }
            vm_release(&vm->heap, v); /* push retains */
            stack_push(vm, arr);
            VM_NEXT();
        }

        VM_CASE(OP_ARR_POP) {
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_POP: not an array");
            }
            NanoValue v = vm_array_pop(arr.as.array);
            /* One result: the popped element. The array used to be pushed back
             * as a second result, which every caller then had to discard --
             * codegen emitted an OP_POP after every array_pop. The array is a
             * heap reference the caller already holds; threading it back
             * through the stack bought nothing and made this the only
             * instruction in the ISA with two results. */
            vm_release(&vm->heap, arr);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_ARR_GET) {
            NanoValue idx_v = stack_pop(vm);
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY || idx_v.tag != TAG_INT) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, idx_v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I require an array and an integer ARR_GET index.");
            }
            /* Raw reads preserve a missing value as void. Check before narrowing. */
            NanoValue v = val_void();
            if (idx_v.as.i64 >= 0 && (uint64_t)idx_v.as.i64 < arr.as.array->length)
                v = vm_array_get(arr.as.array, (uint32_t)idx_v.as.i64);
            vm_retain(&vm->heap, v);
            vm_release(&vm->heap, arr);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_ARR_SET) {
            NanoValue v = stack_pop(vm);
            NanoValue idx_v = stack_pop(vm);
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, idx_v);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_SET: not an array");
            }
            if (idx_v.tag != TAG_INT) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, idx_v);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "I require an integer ARR_SET index.");
            }
            if (idx_v.as.i64 < 0 || (uint64_t)idx_v.as.i64 >= arr.as.array->length) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "I require an ARR_SET index within the array.");
            }
            uint32_t idx = (uint32_t)idx_v.as.i64;
            NanoValue previous = vm_array_get(arr.as.array, idx);
            /* I publish the new edge before release can collect cycles. */
            vm_array_set(arr.as.array, idx, v);
            vm_release(&vm->heap, previous);
            stack_push(vm, arr);
            VM_NEXT();
        }

        VM_CASE(OP_ARR_LEN) {
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_LEN: not an array");
            }
            int64_t len = arr.as.array->length;
            vm_release(&vm->heap, arr);
            stack_push(vm, val_int(len));
            VM_NEXT();
        }

        VM_CASE(OP_ARR_SLICE) {
            NanoValue end_v = stack_pop(vm);
            NanoValue start_v = stack_pop(vm);
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                vm_release(&vm->heap, start_v);
                vm_release(&vm->heap, end_v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_SLICE: not an array");
            }
            uint32_t start = (uint32_t)(start_v.tag == TAG_INT ? start_v.as.i64 : 0);
            uint32_t end = (uint32_t)(end_v.tag == TAG_INT ? end_v.as.i64 : arr.as.array->length);
            VmArray *result = vm_array_slice(&vm->heap, arr.as.array, start, end);
            vm_release(&vm->heap, arr);
            vm_release(&vm->heap, start_v);
            vm_release(&vm->heap, end_v);
            if (!result) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the array slice.");
            stack_push(vm, val_array(result));
            VM_NEXT();
        }

        VM_CASE(OP_ARR_REMOVE) {
            NanoValue idx_v = stack_pop(vm);
            NanoValue arr = stack_pop(vm);
            if (arr.tag != TAG_ARRAY) {
                vm_release(&vm->heap, arr);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "ARR_REMOVE: not an array");
            }
            uint32_t idx = (uint32_t)(idx_v.tag == TAG_INT ? idx_v.as.i64 : 0);
            vm_array_remove(&vm->heap, arr.as.array, idx);
            stack_push(vm, arr);
            VM_NEXT();
        }

        VM_CASE(OP_ARR_LITERAL) {
            uint8_t elem_type = instr->operands[0].u8;
            uint16_t count = instr->operands[1].u16;
            VmArray *a = vm_array_new(&vm->heap, elem_type, count > 0 ? count : 8);
            if (!a) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the array.");
            /* Pop count values in reverse (they were pushed in order). The
             * popped values transfer their ownership into the array, so for
             * boxed storage we store without an extra retain; for unboxed
             * storage vm_array_set packs the payload. */
            a->length = count;
            for (uint16_t i = 0; i < count; i++) {
                vm_array_set(a, (uint32_t)(count - 1 - i), stack_pop(vm));
            }
            stack_push(vm, val_array(a));
            VM_NEXT();
        }

        /* ============================================================
         * Struct Ops
         * ============================================================ */

        VM_CASE(OP_STRUCT_NEW) {
            uint32_t def_idx = instr->operands[0].u32;
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
            if(record_execution)def_idx=record_array->record_layouts[def_idx];
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution)def_idx=vm_rmx_record_layout(record_map,def_idx);
#endif
            VmStruct *s = vm_struct_new(&vm->heap, def_idx, 0);
            if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the struct.");
            stack_push(vm, val_struct(s));
            VM_NEXT();
        }

        VM_CASE(OP_STRUCT_GET) {
            uint16_t field_idx = instr->operands[0].u16;
            NanoValue sv = stack_pop(vm);
            if (sv.tag != TAG_STRUCT || !sv.as.sval) {
                vm_release(&vm->heap, sv);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STRUCT_GET: not a struct");
            }
            if (field_idx >= sv.as.sval->field_count) {
                vm_release(&vm->heap, sv);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "STRUCT_GET: field %u out of range", field_idx);
            }
            NanoValue v = sv.as.sval->fields[field_idx];
            vm_retain(&vm->heap, v);
            vm_release(&vm->heap, sv);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_STRUCT_SET) {
            uint16_t field_idx = instr->operands[0].u16;
            NanoValue v = stack_pop(vm);
            NanoValue sv = stack_pop(vm);
            if (sv.tag != TAG_STRUCT || !sv.as.sval) {
                vm_release(&vm->heap, sv);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "STRUCT_SET: not a struct");
            }
            if (field_idx >= sv.as.sval->field_count) {
                vm_release(&vm->heap, sv);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "STRUCT_SET: field %u out of range", field_idx);
            }
            NanoValue previous = sv.as.sval->fields[field_idx];
            sv.as.sval->fields[field_idx] = v;
            vm_release(&vm->heap, previous);
            stack_push(vm, sv);
            VM_NEXT();
        }

        VM_CASE(OP_STRUCT_LITERAL) {
            uint32_t def_idx = instr->operands[0].u32;
            uint16_t field_count = instr->operands[1].u16;
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
            if(record_execution)def_idx=record_array->record_layouts[def_idx];
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution)def_idx=vm_rmx_record_layout(record_map,def_idx);
#endif
            VmStruct *s = vm_struct_new(&vm->heap, def_idx, field_count);
            if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the struct.");
            /* Pop fields in reverse order */
            for (uint16_t i = 0; i < field_count; i++) {
                s->fields[field_count - 1 - i] = stack_pop(vm);
            }
            stack_push(vm, val_struct(s));
            VM_NEXT();
        }

        /* ============================================================
         * Union/Enum Ops
         * ============================================================ */

        VM_CASE(OP_UNION_CONSTRUCT) {
            uint32_t def_idx = instr->operands[0].u32;
            uint16_t variant = instr->operands[1].u16;
            uint16_t fcount = instr->operands[2].u16;
            VmUnion *u = vm_union_new(&vm->heap, def_idx, variant, fcount);
            if (!u) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the union.");
            for (uint16_t i = 0; i < fcount; i++) {
                u->fields[fcount - 1 - i] = stack_pop(vm);
            }
            stack_push(vm, val_union(u));
            VM_NEXT();
        }

        VM_CASE(OP_UNION_TAG) {
            NanoValue uv = stack_pop(vm);
            if (uv.tag != TAG_UNION || !uv.as.uval) {
                vm_release(&vm->heap, uv);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "UNION_TAG: not a union");
            }
            int64_t tag = uv.as.uval->variant;
            vm_release(&vm->heap, uv);
            stack_push(vm, val_int(tag));
            VM_NEXT();
        }

        VM_CASE(OP_UNION_FIELD) {
            uint16_t field_idx = instr->operands[0].u16;
            NanoValue uv = stack_pop(vm);
            if (uv.tag != TAG_UNION || !uv.as.uval) {
                vm_release(&vm->heap, uv);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "UNION_FIELD: not a union");
            }
            if (field_idx >= uv.as.uval->field_count) {
                vm_release(&vm->heap, uv);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "UNION_FIELD: field %u out of range", field_idx);
            }
            NanoValue v = uv.as.uval->fields[field_idx];
            vm_retain(&vm->heap, v);
            vm_release(&vm->heap, uv);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_MATCH_TAG) {
            uint16_t variant = instr->operands[0].u16;
            NanoValue top = stack_peek(vm, 0);
            if (top.tag == TAG_UNION && top.as.uval && top.as.uval->variant == variant) {
                /* Match - jump to arm */
                vm->ip = decoded->branch_target_offset;
            }
            /* No match - fall through to next MATCH_TAG */
            VM_NEXT();
        }

        VM_CASE(OP_ENUM_VAL) {
            uint32_t def_idx = instr->operands[0].u32;
            uint16_t variant = instr->operands[1].u16;
            (void)def_idx;
            stack_push(vm, val_enum((int32_t)variant));
            VM_NEXT();
        }

        /* ============================================================
         * Tuple Ops
         * ============================================================ */

        VM_CASE(OP_TUPLE_NEW) {
            uint16_t count = instr->operands[0].u16;
            VmTuple *t = vm_tuple_new(&vm->heap, count);
            if (!t) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the tuple.");
            for (uint16_t i = 0; i < count; i++) {
                t->elements[count - 1 - i] = stack_pop(vm);
            }
            stack_push(vm, val_tuple(t));
            VM_NEXT();
        }

        VM_CASE(OP_TUPLE_GET) {
            uint16_t index = instr->operands[0].u16;
            NanoValue tv = stack_pop(vm);
            if (tv.tag != TAG_TUPLE || !tv.as.tuple) {
                vm_release(&vm->heap, tv);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "TUPLE_GET: not a tuple");
            }
            if (index >= tv.as.tuple->count) {
                vm_release(&vm->heap, tv);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS, "TUPLE_GET: index %u out of range", index);
            }
            NanoValue v = tv.as.tuple->elements[index];
            vm_retain(&vm->heap, v);
            vm_release(&vm->heap, tv);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_AGG_PACK) {
            uint8_t kind = instr->operands[0].u8;
            uint32_t layout = instr->operands[1].u32;
            uint16_t variant = instr->operands[2].u16;
            uint16_t count = instr->operands[3].u16;
            if (!stack_has_operands(vm, count))
                return trap_error(vm, VM_ERR_STACK_UNDERFLOW,
                                  "AGG_PACK needs %u values", count);
            if (kind == AGG_RECORD) {
                if(mixed_execution) {
                    if(layout>=proof->record_count || !proof->ordinary_records[layout] ||
                       proof->records[layout].field_count!=count)
                        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require an exact ordinary mixed record identity");
                    layout=proof->records[layout].global_layout;
                }
#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
                if(record_execution)layout=record_array->record_layouts[layout];
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
                if(map_execution)layout=vm_rmx_record_layout(record_map,layout);
#endif
                VmStruct *record = vm_struct_new(&vm->heap, layout, count);
                if (!record) return trap_error(vm, VM_ERR_MEMORY,
                                               "AGG_PACK record allocation failed");
                for (uint16_t i = 0; i < count; i++)
                    record->fields[count - 1 - i] = stack_pop(vm);
                stack_push(vm, val_struct(record));
            } else if (kind == AGG_VARIANT) {
                VmUnion *value = vm_union_new(&vm->heap, layout, variant, count);
                if (!value) return trap_error(vm, VM_ERR_MEMORY,
                                              "AGG_PACK variant allocation failed");
                for (uint16_t i = 0; i < count; i++)
                    value->fields[count - 1 - i] = stack_pop(vm);
                stack_push(vm, val_union(value));
            } else if (kind == AGG_TUPLE) {
                VmTuple *tuple = vm_tuple_new(&vm->heap, count);
                if (!tuple) return trap_error(vm, VM_ERR_MEMORY,
                                              "AGG_PACK tuple allocation failed");
                for (uint16_t i = 0; i < count; i++)
                    tuple->elements[count - 1 - i] = stack_pop(vm);
                stack_push(vm, val_tuple(tuple));
            } else {
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "AGG_PACK unknown kind %u", kind);
            }
            VM_NEXT();
        }

        VM_CASE(OP_AGG_GET) {
            uint16_t index = instr->operands[0].u16;
            NanoValue aggregate = stack_pop(vm);
            NanoValue value = val_void();
            if (aggregate.tag == TAG_STRUCT && aggregate.as.sval
                    && index < aggregate.as.sval->field_count) {
                value = aggregate.as.sval->fields[index];
            } else if (aggregate.tag == TAG_UNION && aggregate.as.uval
                       && index < aggregate.as.uval->field_count) {
                value = aggregate.as.uval->fields[index];
            } else if (aggregate.tag == TAG_TUPLE && aggregate.as.tuple
                       && index < aggregate.as.tuple->count) {
                value = aggregate.as.tuple->elements[index];
            } else {
                vm_release(&vm->heap, aggregate);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                  "AGG_GET field %u is unavailable", index);
            }
            vm_retain(&vm->heap, value);
            vm_release(&vm->heap, aggregate);
            stack_push(vm, value);
            VM_NEXT();
        }

        VM_CASE(OP_AGG_SET) {
            uint16_t index = instr->operands[0].u16;
            NanoValue value = stack_pop(vm);
            NanoValue aggregate = stack_pop(vm);
            NanoValue *field = NULL;
            if (aggregate.tag == TAG_STRUCT && aggregate.as.sval
                    && index < aggregate.as.sval->field_count) {
                field = &aggregate.as.sval->fields[index];
            } else if (aggregate.tag == TAG_UNION && aggregate.as.uval
                       && index < aggregate.as.uval->field_count) {
                field = &aggregate.as.uval->fields[index];
            } else if (aggregate.tag == TAG_TUPLE && aggregate.as.tuple
                       && index < aggregate.as.tuple->count) {
                field = &aggregate.as.tuple->elements[index];
            }
            if (!field) {
                vm_release(&vm->heap, aggregate);
                vm_release(&vm->heap, value);
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                  "AGG_SET field %u is unavailable", index);
            }
            NanoValue previous = *field;
            *field = value;
            vm_release(&vm->heap, previous);
            stack_push(vm, aggregate);
            VM_NEXT();
        }

        VM_CASE(OP_AGG_TAG) {
            NanoValue aggregate = stack_pop(vm);
            if (aggregate.tag != TAG_UNION || !aggregate.as.uval) {
                vm_release(&vm->heap, aggregate);
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "AGG_TAG requires a variant");
            }
            int64_t tag = aggregate.as.uval->variant;
            vm_release(&vm->heap, aggregate);
            stack_push(vm, val_int(tag));
            VM_NEXT();
        }

        /* ============================================================
         * Hashmap Ops
         * ============================================================ */

        VM_CASE(OP_HM_NEW) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_NEW,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_NEW,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            uint8_t key_type = instr->operands[0].u8;
            uint8_t val_type = instr->operands[1].u8;
            VmHashMap *m = vm_hashmap_new(&vm->heap, key_type, val_type);
            if (!m) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate a hashmap.");
            stack_push(vm, val_hashmap(m));
            VM_NEXT();
        }

        VM_CASE(OP_HM_GET) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_GET,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_GET,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            NanoValue key = stack_pop(vm);
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_GET: not a hashmap");
            }
            NanoValue v = vm_hashmap_get(map.as.hashmap, key);
            vm_retain(&vm->heap, v);
            vm_release(&vm->heap, map);
            vm_release(&vm->heap, key);
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_HM_SET) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_SET,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_SET,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            NanoValue v = stack_pop(vm);
            NanoValue key = stack_pop(vm);
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_SET: not a hashmap");
            }
            if (key.tag != map.as.hashmap->key_type || v.tag != map.as.hashmap->val_type) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "I require HM_SET key/value tags to match the map declaration.");
            }
            if (!vm_hashmap_set(&vm->heap, map.as.hashmap, key, v)) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_MEMORY, "I could not grow this hashmap.");
            }
            vm_release(&vm->heap, key);
            vm_release(&vm->heap, v);
            stack_push(vm, map);
            VM_NEXT();
        }

        VM_CASE(OP_HM_HAS) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_HAS,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_HAS,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            NanoValue key = stack_pop(vm);
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_HAS: not a hashmap");
            }
            bool has = vm_hashmap_has(map.as.hashmap, key);
            vm_release(&vm->heap, map);
            vm_release(&vm->heap, key);
            stack_push(vm, val_bool(has));
            VM_NEXT();
        }

        VM_CASE(OP_HM_DELETE) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_DELETE,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_DELETE,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            NanoValue key = stack_pop(vm);
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                vm_release(&vm->heap, key);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_DELETE: not a hashmap");
            }
            vm_hashmap_delete(&vm->heap, map.as.hashmap, key);
            vm_release(&vm->heap, key);
            stack_push(vm, map);
            VM_NEXT();
        }

        VM_CASE(OP_HM_KEYS) {
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_KEYS: not a hashmap");
            }
            VmArray *keys = vm_hashmap_keys(&vm->heap, map.as.hashmap);
            vm_release(&vm->heap, map);
            if (!keys) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate hashmap keys.");
            stack_push(vm, val_array(keys));
            VM_NEXT();
        }

        VM_CASE(OP_HM_VALUES) {
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_VALUES: not a hashmap");
            }
            VmArray *vals = vm_hashmap_values(&vm->heap, map.as.hashmap);
            vm_release(&vm->heap, map);
            if (!vals) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate hashmap values.");
            stack_push(vm, val_array(vals));
            VM_NEXT();
        }

        VM_CASE(OP_HM_LEN) {
            if(borrowed_map_execution) {
                VmResult checked=vm_rmb_map_instruction(borrowed_map,OP_HM_LEN,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked ordinary map operation.");
                VM_NEXT();
            }
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
            if(map_execution) {
                VmResult checked=vm_rmx_map_instruction(record_map,OP_HM_LEN,map_value_tag);
                if(checked!=VM_OK)return trap_error(vm,checked,"I stopped at a checked private map operation.");
                VM_NEXT();
            }
#endif
            NanoValue map = stack_pop(vm);
            if (map.tag != TAG_HASHMAP) {
                vm_release(&vm->heap, map);
                return trap_error(vm, VM_ERR_TYPE_ERROR, "HM_LEN: not a hashmap");
            }
            int64_t len = map.as.hashmap->count;
            vm_release(&vm->heap, map);
            stack_push(vm, val_int(len));
            VM_NEXT();
        }

        /* ============================================================
         * GC/Memory
         * ============================================================ */

        VM_CASE(OP_GC_RETAIN) {
            NanoValue v = stack_peek(vm, 0);
            vm_retain(&vm->heap, v);
            VM_NEXT();
        }

        VM_CASE(OP_GC_RELEASE) {
            NanoValue v = stack_pop(vm);
            vm_release(&vm->heap, v);
            VM_NEXT();
        }

        /* ============================================================
         * Type Casts
         * ============================================================ */

        VM_CASE(OP_CAST_INT) {
            NanoValue v = stack_pop(vm);
            switch (v.tag) {
                case TAG_INT:   stack_push(vm, v); break;
                case TAG_FLOAT:
                    /* I check the exact binary64 interval before truncating. */
                    if (!(v.as.f64 >= -0x1p63 && v.as.f64 < 0x1p63))
                        return trap_error(vm, VM_ERR_TYPE_ERROR,
                            "I cannot convert this float to int: I require a finite value in [-2^63, 2^63).");
                    stack_push(vm, val_int((int64_t)v.as.f64));
                    break;
                case TAG_BOOL:  stack_push(vm, val_int(v.as.boolean ? 1 : 0)); break;
                case TAG_U8:    stack_push(vm, val_int(v.as.u8)); break;
                case TAG_ENUM:  stack_push(vm, val_int(v.as.i64)); break;
                case TAG_STRING: {
                    const char *str = vmstring_cstr(v.as.string);
                    int64_t result = str ? strtoll(str, NULL, 10) : 0;
                    vm_release(&vm->heap, v);
                    stack_push(vm, val_int(result));
                    break;
                }
                default:
                    vm_release(&vm->heap, v);
                    stack_push(vm, val_int(0));
                    break;
            }
            VM_NEXT();
        }

        VM_CASE(OP_CAST_U8) {
            NanoValue v = stack_pop(vm);
            if (v.tag == TAG_INT) {
                /* I use defined unsigned narrowing, including negative INTs. */
                stack_push(vm, val_u8((uint8_t)v.as.i64));
            } else if (v.tag == TAG_U8) {
                stack_push(vm, v);
            } else {
                vm_release(&vm->heap, v);
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                    "I require int or u8 for byte conversion.");
            }
            VM_NEXT();
        }

        VM_CASE(OP_CAST_FLOAT) {
            NanoValue v = stack_pop(vm);
            switch (v.tag) {
                case TAG_FLOAT: stack_push(vm, v); break;
                case TAG_INT:   stack_push(vm, val_float((double)v.as.i64)); break;
                case TAG_U8:    stack_push(vm, val_float((double)v.as.u8)); break;
                case TAG_BOOL:  stack_push(vm, val_float(v.as.boolean ? 1.0 : 0.0)); break;
                case TAG_STRING: {
                    const char *str = vmstring_cstr(v.as.string);
                    uint64_t bits = 0;
                    int parsed = nbp_parse((const unsigned char *)str,
                                          str ? vmstring_len(v.as.string) : 0, &bits);
                    vm_release(&vm->heap, v);
                    if (!parsed) return trap_error(vm, VM_ERR_TYPE_ERROR,
                        "I could not finish the checked binary64 conversion.");
                    double result;
                    memcpy(&result, &bits, sizeof result);
                    stack_push(vm, val_float(result));
                    break;
                }
                default:
                    vm_release(&vm->heap, v);
                    stack_push(vm, val_float(0.0));
                    break;
            }
            VM_NEXT();
        }

        VM_CASE(OP_CAST_BOOL) {
            NanoValue v = stack_pop(vm);
            bool result = val_truthy(v);
            vm_release(&vm->heap, v);
            stack_push(vm, val_bool(result));
            VM_NEXT();
        }

        VM_CASE(OP_CAST_STRING) {
            NanoValue v = stack_pop(vm);
            VmString *s;
            switch (v.tag) {
                case TAG_STRING: stack_push(vm, v); break; /* already a string */
                case TAG_U8:
                    s = vm_string_from_int(&vm->heap, (int64_t)v.as.u8);
                    if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the byte string.");
                    stack_push(vm, val_string(s));
                    break;
                case TAG_INT:
                    s = vm_string_from_int(&vm->heap, v.as.i64);
                    if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the converted string.");
                    stack_push(vm, val_string(s));
                    break;
                case TAG_FLOAT:
                    s = vm_string_from_float(&vm->heap, v.as.f64);
                    if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the converted string.");
                    stack_push(vm, val_string(s));
                    break;
                case TAG_BOOL:
                    s = vm_string_from_bool(&vm->heap, v.as.boolean);
                    if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the converted string.");
                    stack_push(vm, val_string(s));
                    break;
                default:
                    vm_release(&vm->heap, v);
                    s = vm_string_new(&vm->heap, "", 0);
                    if (!s) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the converted string.");
                    stack_push(vm, val_string(s));
                    break;
            }
            VM_NEXT();
        }

        VM_CASE(OP_TYPE_CHECK) {
            uint8_t expected = instr->operands[0].u8;
            NanoValue v = stack_pop(vm);
            stack_push(vm, val_bool(v.tag == expected));
            vm_release(&vm->heap, v);
            VM_NEXT();
        }

        /* ============================================================
         * Closures
         * ============================================================ */

        VM_CASE(OP_CLOSURE_NEW) {
            uint32_t fn_idx_c = instr->operands[0].u32;
            uint16_t capture_count = instr->operands[1].u16;
            VmClosure *c = vm_closure_new(&vm->heap, fn_idx_c, capture_count);
            if (!c) return trap_error(vm, VM_ERR_MEMORY, "I could not allocate the closure.");
            c->callable_module = vm_callable_module_id(vm, vm->module);
            /* Pop captures from stack (pushed in order, stored in order) */
            for (uint32_t i = capture_count; i > 0; i--) {
                c->captures[i - 1] = stack_pop(vm);
            }
            stack_push(vm, val_closure(c));
            VM_NEXT();
        }

        /* ============================================================
         * I/O & Debug
         * ============================================================ */

        VM_CASE(OP_PRINT) {
            if (vm->profile.enabled) vm->profile.traps++;
            VmTrap t = { .type = TRAP_PRINT };
            t.data.print.value = stack_pop(vm);
            t.data.print.newline = false;
            return t;
        }

        VM_CASE(OP_PRINTLN) {
            if (vm->profile.enabled) vm->profile.traps++;
            VmTrap t = { .type = TRAP_PRINT };
            t.data.print.value = stack_pop(vm);
            t.data.print.newline = true;
            return t;
        }

        VM_CASE(OP_ASSERT) {
            if (vm->profile.enabled) vm->profile.traps++;
            VmTrap t = { .type = TRAP_ASSERT };
            t.data.assert_check.condition = stack_pop(vm);
            return t;
        }

        VM_CASE(OP_DEBUG_LINE)
            /* Track source line in the current frame for stack traces.
             * Column is resolved via debug_entries; reset to 0 here. */
            frame->current_line = instr->operands[0].u32;
            frame->current_col  = 0;
            /* Resolve column from debug_entries if available */
            {
                const NvmModule *dbg_mod = vm->module;
                if (dbg_mod && dbg_mod->debug_count > 0) {
                    uint32_t best_off = 0;
                    bool col_found = false;
                    for (uint32_t d = 0; d < dbg_mod->debug_count; d++) {
                        uint32_t off = dbg_mod->debug_entries[d].bytecode_offset;
                        if (off <= instr_start && (!col_found || off >= best_off)) {
                            best_off = off;
                            if (dbg_mod->debug_entries[d].source_line == frame->current_line)
                                frame->current_col = dbg_mod->debug_entries[d].source_col;
                            col_found = true;
                        }
                    }
                }
            }
            VM_NEXT();

        VM_CASE(OP_HALT)
            vm_clear_reference_activations(vm);
            if (vm->profile.enabled) vm->profile.traps++;
            return trap_halt();

        /* ============================================================
         * Opaque Proxy
         * ============================================================ */

        VM_CASE(OP_OPAQUE_NULL) {
            NanoValue v = {0};
            v.tag = TAG_OPAQUE;
            v.as.proxy_id = 0;
            stack_push(vm, v);
            VM_NEXT();
        }

        VM_CASE(OP_OPAQUE_VALID) {
            NanoValue v = stack_pop(vm);
            stack_push(vm, val_bool(v.tag == TAG_OPAQUE && v.as.proxy_id != 0));
            VM_NEXT();
        }

        VM_CASE(OP_MEM_LOAD8)
        VM_CASE(OP_MEM_LOAD16)
        VM_CASE(OP_MEM_LOAD32)
        VM_CASE(OP_MEM_LOAD64) {
            NanoValue address = stack_pop(vm);
            if (address.tag != TAG_INT || address.as.i64 < 0)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires a non-negative integer address",
                                  isa_get_info(instr->opcode)->name);
            uint64_t width = instr->opcode == OP_MEM_LOAD8 ? 1
                : instr->opcode == OP_MEM_LOAD16 ? 2
                : instr->opcode == OP_MEM_LOAD32 ? 4 : 8;
            uint64_t start = (uint64_t)address.as.i64;
            if (start > vm->memory_size || width > vm->memory_size - start)
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                  "Memory load at %llu exceeds %llu bytes",
                                  (unsigned long long)start,
                                  (unsigned long long)vm->memory_size);
            uint64_t value = 0;
            for (uint64_t i = 0; i < width; i++)
                value |= (uint64_t)vm->memory[start + i] << (i * 8);
            stack_push(vm, val_int((int64_t)value));
            VM_NEXT();
        }

        VM_CASE(OP_MEM_STORE8)
        VM_CASE(OP_MEM_STORE16)
        VM_CASE(OP_MEM_STORE32)
        VM_CASE(OP_MEM_STORE64) {
            /* Caller-provided linear memory need not be disjoint from inputs. */
            if (ordinary) ordinary->valid=false;
            NanoValue value = stack_pop(vm);
            NanoValue address = stack_pop(vm);
            if (address.tag != TAG_INT || value.tag != TAG_INT || address.as.i64 < 0)
                return trap_error(vm, VM_ERR_TYPE_ERROR,
                                  "%s requires integer address and value",
                                  isa_get_info(instr->opcode)->name);
            uint64_t width = instr->opcode == OP_MEM_STORE8 ? 1
                : instr->opcode == OP_MEM_STORE16 ? 2
                : instr->opcode == OP_MEM_STORE32 ? 4 : 8;
            uint64_t start = (uint64_t)address.as.i64;
            if (start > vm->memory_size || width > vm->memory_size - start)
                return trap_error(vm, VM_ERR_OUT_OF_BOUNDS,
                                  "Memory store at %llu exceeds %llu bytes",
                                  (unsigned long long)start,
                                  (unsigned long long)vm->memory_size);
            uint64_t bits = (uint64_t)value.as.i64;
            for (uint64_t i = 0; i < width; i++)
                vm->memory[start + i] = (uint8_t)(bits >> (i * 8));
            VM_NEXT();
        }

        VM_DEFAULT
            return trap_error(vm, VM_ERR_INVALID_OPCODE, "Unknown opcode 0x%02x", instr->opcode);

        VM_DISPATCH_END() /* switch */
#ifdef NANO_COMPUTED_GOTO
    }
    goto vm_dispatch_top;
vm_dispatch_done: ;
#else
    } /* while */
#endif

#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
    if(union_execution) {
        if(!vm_uf_context(union_field,vm) ||
           vm->stack_size-frame->stack_base-frame->local_count!=cur_fn->result_count ||
           (cur_fn->result_count && (stack_peek(vm,0).tag!=cur_fn->result_tag ||
             !vm_uf_shell(union_field->owner,stack_peek(vm,0)))))
            return trap_error(vm,VM_ERR_TYPE_ERROR,"I require an exact union completion result.");
    }
#endif
    /* The verifier requires exactly the declared results at this boundary.
     * Resume a nested caller through the same activation/module path as RET. */
    if (vm->frame_count > vm->activation_floor) goto vm_return_values;

    return trap_none();
}

static VmTrap vm_core_execute_pair(VmState *vm,const VmOwnedInvocationProof *proof,
    VmOrdinaryAdmission *ordinary,VmRecordArrayPrivate *record_array,
    VmRecordMapInvocation *record_map,VmRecordMapBorrowedInvocation *borrowed_map,uint8_t map_value_tag) {
    return vm_core_execute_union(vm,proof,ordinary,record_array,record_map,borrowed_map,map_value_tag,NULL);
}
#ifdef NANO_UNION_FIELD_PRIVATE_PREPARATION
#include "union_field_vm_run.inc"
#endif

static VmTrap vm_core_execute_views(VmState *vm,const VmOwnedInvocationProof *proof,
    VmOrdinaryAdmission *ordinary,VmRecordArrayPrivate *record_array,
    VmRecordMapInvocation *record_map,VmRecordMapBorrowedInvocation *borrowed_map) {
    return vm_core_execute_pair(vm,proof,ordinary,record_array,record_map,borrowed_map,TAG_VOID);
}

static VmTrap vm_core_execute_context(VmState *vm,const VmOwnedInvocationProof *proof,
                                      VmOrdinaryAdmission *ordinary,VmRecordArrayPrivate *record_array,
                                      VmRecordMapInvocation *record_map) {
    return vm_core_execute_views(vm,proof,ordinary,record_array,record_map,NULL);
}

static VmTrap vm_core_execute_scoped(VmState *vm,const VmOwnedInvocationProof *proof,
                                     VmOrdinaryAdmission *ordinary,VmRecordArrayPrivate *record_array) {
    return vm_core_execute_context(vm,proof,ordinary,record_array,NULL);
}

#ifdef NANO_RECORD_ARRAY_PRIVATE_RUNTIME
#include "record_array_vm_run.inc"
#endif
#ifdef NANO_RECORD_MAP_PRIVATE_RUNTIME
#include "record_map_vm_run.inc"
#include "record_map_vm_observe.inc"
#endif
#include "record_map_import.inc"
#include "record_map_public_prepare.inc"
#include "record_map_borrowed_run.inc"

VmTrap vm_core_execute(VmState *vm) {
    if(vm && nvm_record_map_selected(nvm_record_map_route(vm->module)))
        return trap_error(vm,VM_ERR_TYPE_ERROR,"I require a complete synchronous map invocation.");
    if(vm && (nvm_owned_array_route(vm->module)!=NVM_OWNER_ARRAY_NOT_SELECTED || nvm_record_array_candidate(vm->module))) {
        VmTrap refused={.type=TRAP_ERROR};
        refused.data.error.code=vm_error(vm,VM_ERR_TYPE_ERROR,
            "I require a synchronous owner ARRAY root invocation before execution.");
        return refused;
    }
    bool mixed=vm && nvm_mixed_samples_candidate(vm->module);
    uint32_t base=mixed && vm->frame_count?vm->frames[0].stack_base:0;
    VmTrap trap=vm_core_execute_scoped(vm,NULL,NULL,NULL);
    if(mixed && (trap.type==TRAP_ERROR ||
       (trap.type==TRAP_ASSERT && !val_truthy(trap.data.assert_check.condition)))) {
        while(vm->stack_size>base)vm_release(&vm->heap,stack_pop(vm));
        for(uint32_t f=0;f<vm->frame_count;f++) {
            vm_release(&vm->heap,vm->frames[f].owned_callable);
            vm->frames[f].owned_callable=val_void();
        }
        vm->frame_count=0;vm_clear_reference_activations(vm);effect_prune(vm,0);
    }
    return trap;
}

/* ========================================================================
 * Debug: Source-Mapped Stack Trace
 * ======================================================================== */

void vm_stack_trace(const VmState *vm, FILE *out) {
    if (!out) out = stderr;
    fprintf(out, "Stack trace (most recent call first):\n");
    if (vm->frame_count == 0) {
        fprintf(out, "  (no frames)\n");
        return;
    }
    for (int i = (int)vm->frame_count - 1; i >= 0; i--) {
        const VmCallFrame *frame = &vm->frames[i];
        const NvmModule *mod = frame->module ? frame->module : vm->module;

        /* Resolve function name */
        const char *fn_name = "??";
        if (mod && frame->fn_idx < mod->function_count) {
            const char *s = nvm_get_string(mod, mod->functions[frame->fn_idx].name_idx);
            if (s && s[0]) fn_name = s;
        }

        /* Resolve source file: prefer module's source_file_idx, fall back to string 0 */
        const char *src_file = "<unknown>";
        if (mod) {
            if (mod->source_file_idx > 0) {
                const char *sf = nvm_get_string(mod, mod->source_file_idx);
                if (sf && sf[0]) src_file = sf;
            } else {
                /* Legacy: use string 0 as module/file name */
                const char *s0 = nvm_get_string(mod, 0);
                if (s0 && s0[0]) src_file = s0;
            }
        }

        /* Source line and col: prefer per-frame tracking, fall back to debug entries */
        uint32_t line = frame->current_line;
        uint32_t col  = frame->current_col;
        if (line == 0 && mod && mod->debug_count > 0) {
            /* I retain the executing instruction for each frame. The next IP
             * names a continuation, and return_ip belongs to the caller. */
            uint32_t search_ip = frame->instruction_ip;
            const NvmFunctionEntry *function = frame->fn_idx < mod->function_count
                ? &mod->functions[frame->fn_idx] : NULL;
            uint32_t best_line = 0;
            uint32_t best_col  = 0;
            uint32_t best_offset = 0;
            bool found = false;
            for (uint32_t d = 0; d < mod->debug_count; d++) {
                uint32_t off = mod->debug_entries[d].bytecode_offset;
                if (function && off >= function->code_offset &&
                    off - function->code_offset < function->code_length && off <= search_ip) {
                    if (!found || off >= best_offset) {
                        best_offset = off;
                        best_line   = mod->debug_entries[d].source_line;
                        best_col    = mod->debug_entries[d].source_col;
                        found = true;
                    }
                }
            }
            if (found) { line = best_line; col = best_col; }
        }

        int frame_num = (int)vm->frame_count - 1 - i;
        fn_name = nl_utf8_cstr_or_marker(fn_name);
        src_file = nl_utf8_cstr_or_marker(src_file);
        if (line > 0 && col > 0) {
            fprintf(out, "  #%-2d  %s  %s:%u:%u\n",
                    frame_num, fn_name, src_file, line, col);
        } else if (line > 0) {
            fprintf(out, "  #%-2d  %s  %s:%u\n",
                    frame_num, fn_name, src_file, line);
        } else {
            fprintf(out, "  #%-2d  %s  %s:?\n",
                    frame_num, fn_name, src_file);
        }
    }
}

/* ========================================================================
 * Runtime Harness (the "co-processor")
 *
 * Calls vm_core_execute() in a loop, handling each trap that the
 * NanoISA core returns.  In the software VM both layers run in the
 * same process.  On an FPGA the harness would run on the host CPU
 * and communicate with the core over PCIe/AXI.
 * ======================================================================== */

static bool vm_stack_address(const VmState *vm, const void *pointer) {
    uintptr_t address = (uintptr_t)pointer, base = (uintptr_t)vm->stack;
    return pointer && vm->stack && address >= base
        && address - base <= (uint64_t)vm->stack_capacity * sizeof(NanoValue);
}

static VmResult vm_call_function_impl(VmState *vm, uint32_t fn_idx, NanoValue *args,
                                      uint16_t arg_count, NanoValue callable,
                                      VmOwnedInvocationProof *proof) {
    if (arg_count && vm_stack_address(vm, args))
        return vm_error(vm, VM_ERR_TYPE_ERROR,
                        "I borrow stack arguments through vm_invoke, not vm_call_function.");
    /* Bind cross-module callable handles before executing. Guarded so
     * this only runs once per link configuration. */
    if (!vm->module_calls_resolved) vm_resolve_module_calls(vm);
    if (fn_idx >= vm->module->function_count) {
        return vm_error(vm, VM_ERR_UNDEFINED_FUNCTION, "Function %u out of range", fn_idx);
    }

    const NvmFunctionEntry *fn = &vm->module->functions[fn_idx];
    if (arg_count != fn->arity) {
        return vm_error(vm, VM_ERR_TYPE_ERROR,
                        "Function %u expects %u arguments, got %u",
                        fn_idx, fn->arity, arg_count);
    }

    /* Push a call frame */
    if (vm->frame_count >= VM_MAX_FRAMES) {
        return vm_error(vm, VM_ERR_CALL_DEPTH, "Call depth exceeded");
    }

    uint32_t stack_base = vm->stack_size;

    if (fn->local_count < arg_count || (arg_count && !args))
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need valid arguments and enough parameter locals.");
    VmResult reserve_result = stack_reserve(vm, (uint64_t)stack_base + fn->local_count);
    if (reserve_result != VM_OK) return reserve_result;

    vm->halt_requested = false;

    /* Push args as first locals */
    for (uint16_t i = 0; i < arg_count; i++) {
        VmResult r = stack_push(vm, args[i]);
        if (r != VM_OK) return r;
    }

    /* Push remaining locals as void */
    for (uint16_t i = arg_count; i < fn->local_count; i++) {
        VmResult r = stack_push(vm, val_void());
        if (r != VM_OK) return r;
    }

    VmCallFrame *frame = &vm->frames[vm->frame_count++];
    frame->fn_idx = fn_idx;
    frame->return_ip = vm->ip;
    frame->instruction_ip = fn->code_offset;
    frame->effect_owner = 0;
    frame->stack_base = stack_base;
    frame->local_count = fn->local_count;
    frame->closure = callable.tag == TAG_CLOSURE ? callable.as.closure : NULL;
    vm_retain(&vm->heap, callable);
    frame->owned_callable = callable;
    frame->module = vm->module;
    frame->current_line = 0;
    frame->current_col  = 0;

    vm->current_fn = fn_idx;
    vm->ip = fn->code_offset;

    /* Each public or nested invocation starts without ordinary authority. */
    VmOrdinaryAdmission ordinary={0};
    /* Run the core in a loop, handling traps */
    bool pump_at_boundary = false;
    for (;;) {
        /* I do not recursively drain queued requests before a newly entered
         * callback executes its first instruction. Nested native waits pump
         * explicitly; pure execution gets its own bounded safe points. */
        if (pump_at_boundary && vm->callbacks) {
            ordinary.valid=false;
            proof->module=NULL;
            vm_callback_pump(vm, false);
        }
        pump_at_boundary = true;
        if (vm->callback_error != VM_OK)
            return vm_error(vm, vm->callback_error, "%s", vm->callback_error_msg);
        if (!vm_owned_proof_matches(vm,proof)) proof->module=NULL;
        VmTrap trap = vm_core_execute_scoped(vm,proof,&ordinary,NULL);
        /* Invalidate before any host effect, yield, completion or error.
         * Only a successful assertion and its closed heap release may resume. */
        if (trap.type!=TRAP_ASSERT) ordinary.valid=false;

        switch (trap.type) {
        case TRAP_YIELD:
            proof->module=NULL;
            break;
        case TRAP_NONE:
            return VM_OK;

        case TRAP_HALT:
            return VM_OK;

        case TRAP_PRINT:
            if(!proof->owner_arrays)proof->module=NULL;
            val_print(trap.data.print.value, vm_out(vm));
            if (trap.data.print.newline) fprintf(vm_out(vm), "\n");
            vm_release(&vm->heap, trap.data.print.value);
            break;

        case TRAP_ASSERT:
            if (!val_truthy(trap.data.assert_check.condition)) {
                ordinary.valid=false;
                vm_release(&vm->heap, trap.data.assert_check.condition);
                VmResult result = vm_error(vm, VM_ERR_ASSERT_FAILED, "Assertion failed");
                if (vm->debug_mode || (vm->module->header.flags & NVM_FLAG_DEBUG_INFO)) {
                    FILE *trace_out = vm->output ? vm->output : stderr;
                    fprintf(trace_out, "\nRuntime error: %s\n", vm_error_string(result));
                    vm_stack_trace(vm, trace_out);
                }
                return result;
            }
            vm_release(&vm->heap, trap.data.assert_check.condition);
            break;

        case TRAP_EXTERN_CALL: {
            proof->module=NULL;
            NanoValue ext_result;
            char ext_err[256];
            bool ffi_ok;
            struct timespec ffi_start = {0}, ffi_stop = {0};
            if (vm->profile.enabled) {
                clock_gettime(CLOCK_MONOTONIC, &ffi_start);
                uint8_t scratch[COP_MAILBOX_SLOT_SIZE];
                for (int i = 0; i < trap.data.extern_call.argc; i++) {
                    vm->profile.ffi_request_bytes += cop_serialize_value(
                        &trap.data.extern_call.args[i], scratch, sizeof(scratch));
                }
            }
            /* I refresh mutable service bindings now and reuse only this
             * invocation's immutable File-opcode fact. No host code runs
             * between classification and the FFI boundary check. */
            NvmServiceClassification ffi_service =
                vm_invocation_service_classify(vm, vm->module, &ordinary);
            ffi_ok = vm_ffi_call_vm_classified(vm, vm->module, trap.data.extern_call.import_idx,
                                    trap.data.extern_call.args, trap.data.extern_call.argc,
                                    &ext_result, ext_err, sizeof(ext_err), &ffi_service);
            if (vm->profile.enabled) {
                clock_gettime(CLOCK_MONOTONIC, &ffi_stop);
                int64_t seconds = ffi_stop.tv_sec - ffi_start.tv_sec;
                int64_t nanoseconds = ffi_stop.tv_nsec - ffi_start.tv_nsec;
                vm->profile.ffi_elapsed_ns +=
                    (uint64_t)(seconds * 1000000000LL + nanoseconds);
                if (!ffi_ok) {
                    vm->profile.ffi_failures++;
                } else {
                    uint8_t scratch[COP_MAILBOX_SLOT_SIZE];
                    vm->profile.ffi_response_bytes += cop_serialize_value(
                        &ext_result, scratch, sizeof(scratch));
                }
            }
            /* OP_CALL_EXTERN popped the arguments into the trap, which
             * transferred the stack's references to it. The dispatch borrows
             * them for the duration of the call and retains anything it keeps,
             * so the trap is where they are released -- on every path,
             * including the failing one, or an FFI call with a string or array
             * argument leaks it. */
            for (int i = 0; i < trap.data.extern_call.argc; i++) {
                vm_release(&vm->heap, trap.data.extern_call.args[i]);
                trap.data.extern_call.args[i] = val_void();
            }

            if (!ffi_ok) {
                if (vm->callback_error != VM_OK)
                    return vm_error(vm, vm->callback_error, "%s", vm->callback_error_msg);
                return vm_error(vm, VM_ERR_NOT_IMPLEMENTED,
                                "FFI call failed: %s", ext_err);
            }
            /* Void imports have no stack result. Non-void imports return one
             * value for the suspended instruction to consume. */
            if (vm->opcode_trace)
                vm_trace_ffi_result(vm, trap.data.extern_call.import_idx, ext_result);
            if (vm->module->imports[trap.data.extern_call.import_idx].return_type
                    != TAG_VOID) {
                VmResult pushed = stack_push(vm, ext_result);
                if (pushed != VM_OK) {
                    vm_release(&vm->heap, ext_result);
                    return pushed;
                }
            } else {
                /* A void import contributes nothing to the stack, so anything
                 * the dispatch allocated for the result has no other owner. */
                vm_release(&vm->heap, ext_result);
            }
            if (vm->halt_requested) {
                vm->halt_requested = false;
                return VM_OK;
            }
            break;
        }

        case TRAP_ERROR:
            /* Emit source-mapped stack trace before unwinding.
             * Always emit when debug_mode is on; also emit when the
             * binary was compiled with debug info. */
            if (vm->debug_mode || (vm->module->header.flags & NVM_FLAG_DEBUG_INFO)) {
                FILE *trace_out = vm->output ? vm->output : stderr;
                fprintf(trace_out, "\nRuntime error: %s\n",
                        nl_utf8_cstr_or_marker(vm_error_string(trap.data.error.code)));
                if (vm->error_msg[0]) {
                    fprintf(trace_out, "  %s\n", nl_utf8_cstr_or_marker(vm->error_msg));
                }
                vm_stack_trace(vm, trace_out);
            }
            return trap.data.error.code;
        }
    }
}

static void vm_owned_globals_clear(VmState *vm) {
    for (uint32_t i=0;i<vm->global_count;i++) {
        vm_release(&vm->heap,vm->globals[i]);vm->globals[i]=val_void();
    }
    vm->global_count=0;
    vm_gc_collect_cycles(&vm->heap);
}

static VmResult vm_call_function_scoped(VmState *vm, uint32_t fn_idx, NanoValue *args,
                                         uint16_t arg_count, VmOwnedInvocationProof *proof) {
    if(nvm_record_map_selected(nvm_record_map_route(vm->module)))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete synchronous map invocation.");
    if(nvm_record_array_candidate(vm->module) &&
       (!vm_owned_proof_matches(vm,proof) || !proof->ordinary_arrays || fn_idx!=proof->ordinary_root))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete record-array root invocation.");
    if ((nvm_uses_owned_transfers(vm->module) || nvm_owned_array_route(vm->module)!=NVM_OWNER_ARRAY_NOT_SELECTED || nvm_mixed_samples_candidate(vm->module)) && fn_idx!=0)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I refuse host entry into a borrowed helper");
    if (!vm_owned_proof_matches(vm,proof) && !vm_ownership_admit(vm,proof))
        return vm_error(vm,proof->refusal?proof->refusal:VM_ERR_TYPE_ERROR,"%s",
                        proof->reason?proof->reason:VM_OWNERSHIP_REQUIRED);
    if (vm->references.active)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I cannot nest a call in my standalone reference activation");
    if (proof->global_count) {
        if (fn_idx || vm->frame_count)
            return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a root typed-global entry invocation");
        if (!vm_ensure_globals(vm,proof->global_count))
            return vm_error(vm,VM_ERR_MEMORY,"I cannot allocate typed-global invocation storage");
        vm_owned_globals_clear(vm);proof->global_module=vm->module;
    }
    uint32_t base = vm->stack_size, frames = vm->frame_count;
    bool owned = nvm_uses_owned_transfers(vm->module) || proof->mixed || proof->owner_arrays || proof->ordinary_arrays || proof->global_count;
    uint32_t floor = vm->activation_floor;
    vm->activation_floor = vm->frame_count;
    uint32_t active_root=fn_idx;uint32_t *previous_root=proof->ordinary_active_root;
    if(proof->ordinary_arrays)proof->ordinary_active_root=&active_root;
    VmResult result = vm_call_function_impl(vm, fn_idx, args, arg_count, val_void(),proof);
    proof->ordinary_active_root=previous_root;
    vm->activation_floor = floor;
    if (result!=VM_OK) {
        vm_clear_reference_activations(vm);
        if (owned) {
            /* I unwind actual owners after an owned entry/helper failure.
             * Direct execution has no outer vm_invoke cleanup wrapper. */
            while (vm->stack_size > base) vm_release(&vm->heap,stack_pop(vm));
            for (uint32_t i = frames; i < vm->frame_count; ++i) {
                vm_release(&vm->heap,vm->frames[i].owned_callable);
                vm->frames[i].owned_callable = val_void();
            }
            vm->frame_count = frames;
            effect_prune(vm,frames);
        }
    }
    if (proof->global_count) {vm_owned_globals_clear(vm);proof->global_module=NULL;}
    return result;
}

#ifdef NANO_OWNED_ARRAY_PRIVATE_RUNTIME
VmResult vm_execute_owned_array_private(VmState *vm,NanoValue *out) {
    if(!vm || !out || vm_stack_address(vm,out) || !vm->module || vm->module!=vm->root_module ||
       vm->stack_size || vm->frame_count || vm->activation_floor || vm->references.active ||
       vm->linked_module_count || vm->callbacks || vm->opcode_trace || !vm_owned_constants_ready(vm))
        return VM_ERR_TYPE_ERROR;
    NvmOwnedArrayPlan *plan=NULL;
    NvmOwnerAuthorityResult checked=nvm_prepare_owned_array_authority(vm->module,&plan);
    if(checked.status!=NVM_OWNER_AUTH_PREPARED)
        return vm_error(vm,checked.status==NVM_OWNER_AUTH_MEMORY?VM_ERR_MEMORY:VM_ERR_TYPE_ERROR,"%s",checked.message);
    VmOwnedInvocationProof proof={0};proof.module=vm->module;proof.owner_arrays=true;
    proof.function_count=vm->module->function_count;
    VmResult result=VM_ERR_TYPE_ERROR;
    for(uint32_t f=0;f<proof.function_count;f++) {
        NvmOwnerSignature from;if(!nvm_owned_array_plan_signature(plan,f,&from))goto done;
        NvmMixedSignature *to=&proof.signatures[f];
        to->parameter_count=from.parameter_count;to->local_count=from.local_count;
        to->max_stack=from.max_stack;to->result_fields=from.result_fields;
        to->result=(NvmMixedDeclaration){from.result.tag,from.result.mode,from.result.global_layout,
            from.result.owner?NVM_MIXED_VALUE_OWNER:NVM_MIXED_VALUE_SCALAR};
        for(uint16_t n=0;n<from.parameter_count;n++) {
            NvmOwnerDeclaration d=from.parameters[n];
            to->parameters[n]=(NvmMixedDeclaration){d.tag,d.mode,d.global_layout,
                d.owner?NVM_MIXED_VALUE_OWNER:NVM_MIXED_VALUE_SCALAR};
        }
    }
    if(proof.signatures[0].parameter_count ||
       (proof.signatures[0].result.tag!=TAG_INT && proof.signatures[0].result.tag!=TAG_BOOL && proof.signatures[0].result.tag!=TAG_U8))goto done;
    result=vm_call_function_scoped(vm,0,NULL,0,&proof);
    if(result==VM_OK) {
        if(vm->stack_size!=1 || vm->frame_count || vm->stack[0].tag!=proof.signatures[0].result.tag)
            result=VM_ERR_TYPE_ERROR;
        else *out=stack_pop(vm);
    }
    /* The scoped call drains failed frames; I also drain an unexpected result
     * shape before returning, without publishing any caller output. */
    while(vm->stack_size)vm_release(&vm->heap,stack_pop(vm));
    vm_clear_reference_activations(vm);
done:
    nvm_owned_array_plan_free(plan);return result;
}
#endif

VmResult vm_call_function(VmState *vm, uint32_t fn_idx, NanoValue *args, uint16_t arg_count) {
    VmOwnedInvocationProof proof={0};
    return vm_call_function_scoped(vm,fn_idx,args,arg_count,&proof);
}

VmResult vm_invoke_callable(VmState *vm, NanoValue callable, const NanoValue *args,
                            uint16_t arg_count, NanoValue *out_result) {
    const NvmModule *target;
    uint32_t function_index;
    if (!vm) return VM_ERR_UNDEFINED_FUNCTION;
    if(nvm_record_map_selected(nvm_record_map_route(vm->module)))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete synchronous map invocation.");
    if(nvm_record_array_candidate(vm->module))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete record-array root invocation.");
    VmOwnedInvocationProof proof={0};
    if (!vm_ownership_admit(vm,&proof))
        return vm_error(vm,proof.refusal?proof.refusal:VM_ERR_TYPE_ERROR,"%s",
                        proof.reason?proof.reason:VM_OWNERSHIP_REQUIRED);
    if(proof.owner_arrays && callable.tag!=TAG_FUNCTION)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a direct root function for owner ARRAY invocation.");
    if (vm->references.active)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I cannot nest a callable in my standalone reference activation");
    if (!vm_callable_target(vm, callable, &target, &function_index))
        return vm_error(vm, VM_ERR_UNDEFINED_FUNCTION, "I need a callable with a live module identity.");
    if(nvm_record_map_selected(nvm_record_map_route(target)))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I refuse record-map callable entry.");
    if(nvm_record_array_candidate(target))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I refuse record-array callable entry.");
    if (proof.global_count) {
        if (callable.tag!=TAG_FUNCTION || target!=vm->root_module || function_index)
            return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a direct root typed-global callable");
        return vm_invoke(vm,0,args,arg_count,out_result);
    }
    if (vm_stack_address(vm, out_result))
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need result storage outside my movable stack.");
    if ((nvm_uses_owned_transfers(target) || nvm_owned_array_route(target)!=NVM_OWNER_ARRAY_NOT_SELECTED || nvm_mixed_samples_candidate(target)) && function_index!=0)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I refuse callable entry into a borrowed helper");
    const NvmFunctionEntry *fn = &target->functions[function_index];
    if (fn->arity != arg_count || fn->local_count < arg_count ||
        fn->result_count > 1 || (arg_count && !args) ||
        (callable.tag == TAG_CLOSURE ? callable.as.closure->capture_count != fn->upvalue_count :
                                      fn->upvalue_count != 0))
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need a matching callable, capture environment, and argument shape.");
    if (vm->frame_count >= VM_MAX_FRAMES)
        return vm_error(vm, VM_ERR_CALL_DEPTH, "I cannot enter another callable activation.");
    if (arg_count && vm_stack_address(vm, args)) {
        uintptr_t offset = (uintptr_t)args - (uintptr_t)vm->stack;
        if (offset % sizeof(NanoValue) || offset / sizeof(NanoValue) > vm->stack_size ||
            arg_count > vm->stack_size - offset / sizeof(NanoValue))
            return vm_error(vm, VM_ERR_TYPE_ERROR, "I need a complete live stack argument slice.");
    }
    NanoValue inline_args[16];
    NanoValue *stable_args = arg_count <= 16 ? inline_args : malloc((size_t)arg_count * sizeof(*args));
    if (!stable_args) return vm_error(vm, VM_ERR_MEMORY, "I could not snapshot callable arguments.");
    if (arg_count) memcpy(stable_args, args, (size_t)arg_count * sizeof(*args));
    uint32_t base = vm->stack_size, frames = vm->frame_count, floor = vm->activation_floor;
    uint32_t ip = vm->ip, current_fn = vm->current_fn;
    const NvmModule *module = vm->module;
    bool halted = vm->halt_requested;
    VmResult previous_error = vm->last_error;
    char previous_message[sizeof(vm->error_msg)];
    memcpy(previous_message, vm->error_msg, sizeof(previous_message));
    VmResult status = stack_reserve(vm, (uint64_t)base + fn->local_count);
    if (status != VM_OK) {
        if (stable_args != inline_args) free(stable_args);
        return status;
    }
    if (out_result) *out_result = val_void();
    if (target!=proof.module) proof.module=NULL;
    vm->module = target;
    vm->activation_floor = frames;
    for (uint16_t i = 0; i < arg_count; i++) vm_retain(&vm->heap, stable_args[i]);
    status = vm_call_function_impl(vm, function_index, stable_args, arg_count, callable,&proof);
    if (status!=VM_OK && target->ownership_size) {
        vm_clear_reference_activations(vm);
    }
    if (stable_args != inline_args) free(stable_args);
    NanoValue returned = val_void();
    if (status == VM_OK) {
        if (vm->frame_count != frames || vm->stack_size != base + fn->result_count)
            status = vm_error(vm, VM_ERR_TYPE_ERROR, "I require the callable activation to return normally.");
        else if (fn->result_count) returned = stack_pop(vm);
    }
    while (vm->stack_size > base) vm_release(&vm->heap, stack_pop(vm));
    for (uint32_t i = frames; i < vm->frame_count; i++) {
        vm_release(&vm->heap, vm->frames[i].owned_callable);
        vm->frames[i].owned_callable = val_void();
    }
    vm->frame_count = frames;
    effect_prune(vm, frames);
    vm->activation_floor = floor;
    vm->ip = ip;
    vm->current_fn = current_fn;
    vm->module = module;
    vm->halt_requested = halted;
    if (status == VM_OK) {
        vm->last_error = previous_error;
        memcpy(vm->error_msg, previous_message, sizeof(previous_message));
        if (out_result) *out_result = returned;
        else vm_release(&vm->heap, returned);
    }
    return status;
}

VmResult vm_invoke(VmState *vm, uint32_t fn_idx, const NanoValue *args,
                   uint16_t arg_count, NanoValue *out_result) {
    if (!vm || !vm->module) return VM_ERR_UNDEFINED_FUNCTION;
    if(nvm_record_map_selected(nvm_record_map_route(vm->module)))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete synchronous map invocation.");
    if(nvm_record_array_candidate(vm->module))
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I require a complete record-array root invocation.");
    if ((nvm_uses_owned_transfers(vm->module) || nvm_owned_array_route(vm->module)!=NVM_OWNER_ARRAY_NOT_SELECTED || nvm_mixed_samples_candidate(vm->module)) && fn_idx!=0)
        return vm_error(vm,VM_ERR_TYPE_ERROR,"I refuse invocation entry into a borrowed helper");
    VmOwnedInvocationProof proof={0};
    if (!vm_ownership_admit(vm,&proof))
        return vm_error(vm,proof.refusal?proof.refusal:VM_ERR_TYPE_ERROR,"%s",
                        proof.reason?proof.reason:VM_OWNERSHIP_REQUIRED);
    if (vm_stack_address(vm, out_result))
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need result storage outside my movable stack.");
    if (vm->frame_count != 0) {
        return vm_error(vm, VM_ERR_CALL_DEPTH,
                        "Cannot invoke a function while the VM is executing");
    }
    if (fn_idx >= vm->module->function_count) {
        return vm_error(vm, VM_ERR_UNDEFINED_FUNCTION,
                        "Function %u out of range", fn_idx);
    }

    const NvmFunctionEntry *fn = &vm->module->functions[fn_idx];
    if (arg_count != fn->arity) {
        return vm_error(vm, VM_ERR_TYPE_ERROR,
                        "Function %u expects %u arguments, got %u",
                        fn_idx, fn->arity, arg_count);
    }
    if (arg_count > 0 && !args) {
        return vm_error(vm, VM_ERR_TYPE_ERROR,
                        "Function %u arguments are NULL", fn_idx);
    }

    uint32_t stack_base = vm->stack_size;
    uint32_t saved_ip = vm->ip;
    uint32_t saved_fn = vm->current_fn;
    const NvmModule *saved_module = vm->module;

    if (fn->local_count < arg_count)
        return vm_error(vm, VM_ERR_TYPE_ERROR, "I need enough parameter locals.");
    if (arg_count && vm_stack_address(vm, args)) {
        uintptr_t offset = (uintptr_t)args - (uintptr_t)vm->stack;
        if (offset % sizeof(NanoValue) || offset / sizeof(NanoValue) > vm->stack_size
                || arg_count > vm->stack_size - offset / sizeof(NanoValue))
            return vm_error(vm, VM_ERR_TYPE_ERROR, "I need a complete live stack argument slice.");
    }
    NanoValue inline_args[16];
    NanoValue *stable_args = arg_count <= 16 ? inline_args
        : malloc((size_t)arg_count * sizeof(NanoValue));
    if (!stable_args)
        return vm_error(vm, VM_ERR_MEMORY, "I could not snapshot invocation arguments.");
    if (arg_count) memcpy(stable_args, args, (size_t)arg_count * sizeof(NanoValue));
    if (out_result) *out_result = val_void();
    VmResult reserve_result = stack_reserve(vm, (uint64_t)stack_base + fn->local_count);
    if (reserve_result != VM_OK) {
        if (stable_args != inline_args) free(stable_args);
        return reserve_result;
    }

    /* vm_call_function consumes argument ownership through its frame cleanup. */
    for (uint16_t i = 0; i < arg_count; i++) vm_retain(&vm->heap, stable_args[i]);

    VmResult result = vm_call_function_scoped(vm, fn_idx, stable_args, arg_count,&proof);
    if (stable_args != inline_args) free(stable_args);
    NanoValue returned = val_void();
    if (result == VM_OK && vm->stack_size > stack_base) {
        returned = stack_pop(vm);
    }

    while (vm->stack_size > stack_base) {
        vm_release(&vm->heap, stack_pop(vm));
    }
    /* Any frame still standing owns its callable; a trap unwinds without
     * reaching OP_RET, so this is the only place those get released. */
    for (uint32_t i = 0; i < vm->frame_count; i++) {
        vm_release(&vm->heap, vm->frames[i].owned_callable);
        vm->frames[i].owned_callable = val_void();
    }
    vm->frame_count = 0;
    vm->handler_count = 0;
    vm->ip = saved_ip;
    vm->current_fn = saved_fn;
    vm->module = saved_module;

    if (result == VM_OK) {
        vm->last_error = VM_OK;
        vm->error_msg[0] = '\0';
        if (out_result) {
            *out_result = returned;
        } else {
            vm_release(&vm->heap, returned);
        }
    }
    return result;
}

static VmResult vm_execute_record_arrays(VmState *vm) {
    if(!vm || !vm->module || vm->module!=vm->root_module || vm->stack_size ||
       vm->frame_count || vm->activation_floor || vm->references.active ||
       vm->linked_module_count || vm->callbacks || vm->opcode_trace || !vm_owned_constants_ready(vm))
        return VM_ERR_TYPE_ERROR;
    NvmRecordArrayExecutionPlan *plan=NULL;
    NvmArrayEligibilityResult admission=nvm_record_array_admit(vm->module,&plan);
    if(admission.status!=NVM_ARRAY_ELIGIBLE)
        return vm_error(vm,admission.status==NVM_ARRAY_MEMORY?VM_ERR_MEMORY:VM_ERR_TYPE_ERROR,"%s",admission.message);
    NvmRecordArrayExecutionCounts counts;
    bool complete=nvm_record_array_execution_counts(plan,&counts);
    nvm_record_array_execution_free(plan);
    if(!complete)return VM_ERR_TYPE_ERROR;
    VmOwnedInvocationProof proof={0};proof.module=vm->module;proof.ordinary_arrays=true;
    VmResult result=VM_OK;
    if(counts.initializer!=UINT32_MAX) {
        proof.ordinary_root=counts.initializer;
        result=vm_call_function_scoped(vm,counts.initializer,NULL,0,&proof);
        /* The initializer's scalar return is not the program result. */
        while(vm->stack_size)vm_release(&vm->heap,stack_pop(vm));
    }
    if(result==VM_OK) {
        proof.ordinary_root=counts.entry;
        result=vm_call_function_scoped(vm,counts.entry,NULL,0,&proof);
    }
    if(result!=VM_OK)while(vm->stack_size)vm_release(&vm->heap,stack_pop(vm));
    return result;
}

VmResult vm_execute(VmState *vm) {
    if(vm && nvm_record_map_selected(nvm_record_map_route(vm->module)))
        return vm_execute_record_maps(vm->module,vm);
    if(vm && nvm_record_array_candidate(vm->module))return vm_execute_record_arrays(vm);
    if (!(vm->module->header.flags & NVM_FLAG_HAS_MAIN)) {
        return vm_error(vm, VM_ERR_UNDEFINED_FUNCTION, "No entry point defined");
    }

    uint32_t entry = vm->module->header.entry_point;
    if (entry >= vm->module->function_count) {
        return vm_error(vm, VM_ERR_UNDEFINED_FUNCTION, "Entry point %u out of range", entry);
    }

    /* Call __init__ to initialize globals before the entry point */
    for (uint32_t i = 0; i < vm->module->function_count; i++) {
        const char *fn_name = nvm_get_string(vm->module,
                                              vm->module->functions[i].name_idx);
        if (fn_name && strcmp(fn_name, "__init__") == 0) {
            VmResult ir = vm_call_function(vm, i, NULL, 0);
            if (ir != VM_OK) return ir;
            break;
        }
    }

    return vm_call_function(vm, entry, NULL, 0);
}
