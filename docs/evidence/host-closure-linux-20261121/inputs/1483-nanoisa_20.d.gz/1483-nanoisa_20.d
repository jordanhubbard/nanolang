nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_file_plan.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_file_plan.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_service_catalog.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_file_catalog.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_service_catalog_internal.h \
 /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nsi_cap.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h
