nano_module_dependencies: \
 /tmp/nano-host-closure-prefix-hl5iss8z/client/provider/api.c \
 /usr/include/stdc-predef.h
