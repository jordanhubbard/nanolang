	.arch armv8-a
	.file	"api.c"
	.text
	.section	.rodata
	.align	3
.LC0:
	.string	"external-provider-ok"
	.text
	.align	2
	.global	path_basename
	.type	path_basename, %function
path_basename:
.LFB0:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	adrp	x0, .LC0
	add	x0, x0, :lo12:.LC0
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	path_basename, .-path_basename
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
