/*
 * Dynamic Array Implementation
 */

#define _POSIX_C_SOURCE 200809L  /* For strdup() */

#include "dyn_array.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

/* Dynamic array configuration */
#define INITIAL_CAPACITY 8
#define GROWTH_FACTOR 2
#define DARRAY_ALIGN 32  /* 32-byte alignment for AVX2 auto-vectorization */

/* Aligned allocation helper: always returns memory aligned to DARRAY_ALIGN.
 * Size is rounded up to the next multiple of DARRAY_ALIGN. */
static void *darray_aligned_alloc(size_t size) {
    if (size == 0) size = DARRAY_ALIGN;
    if (size > SIZE_MAX - (DARRAY_ALIGN - 1)) return NULL;
    /* Round up to alignment multiple */
    size = (size + DARRAY_ALIGN - 1) & ~(size_t)(DARRAY_ALIGN - 1);
    void *ptr = NULL;
    if (posix_memalign(&ptr, DARRAY_ALIGN, size) != 0) return NULL;
    return ptr;
}

static bool darray_storage_size(int64_t count, size_t element_size, size_t *bytes) {
    if (count < 0 || (element_size && (uint64_t)count > SIZE_MAX / element_size)) return false;
    *bytes = (size_t)count * element_size;
    return true;
}

static void darray_allocation_failure(void) __attribute__((noreturn));
static void darray_allocation_failure(void) {
    fprintf(stderr, "I cannot grow this native array safely.\n");
    abort();
}

/* Get element size for type */
static size_t get_element_size(ElementType type) {
    switch (type) {
        case ELEM_INT:    return sizeof(int64_t);
        case ELEM_U8:     return sizeof(uint8_t);
        case ELEM_FLOAT:  return sizeof(double);
        case ELEM_STRING: return sizeof(char*);
        case ELEM_BOOL:   return sizeof(bool);
        case ELEM_POINTER: return sizeof(int64_t);  /* Pointers stored as int64_t */
        default:          return sizeof(void*);
    }
}

/* Create new dynamic array */
DynArray* dyn_array_new(ElementType elem_type) {
    DynArray* arr = (DynArray*)gc_alloc(sizeof(DynArray), GC_TYPE_ARRAY);
    if (arr == NULL) {
        return NULL;
    }
    
    arr->length = 0;
    arr->capacity = INITIAL_CAPACITY;
    arr->elem_type = elem_type;
    arr->elem_size = get_element_size(elem_type);
    arr->data = NULL;
    
    /* For structs, we don't know the size yet - delay allocation */
    if (elem_type == ELEM_STRUCT) {
        arr->elem_size = 0;  /* Will be set on first push */
        arr->data = NULL;     /* Allocate on first push */
    } else {
        size_t bytes;
        if (darray_storage_size(arr->capacity, arr->elem_size, &bytes))
            arr->data = darray_aligned_alloc(bytes);
        if (arr->data == NULL) {
            gc_release(arr);
            return NULL;
        }
    }

    return arr;
}

/* Create new dynamic array with custom initial capacity */
DynArray* dyn_array_new_with_capacity(ElementType elem_type, int64_t initial_capacity) {
    DynArray* arr = (DynArray*)gc_alloc(sizeof(DynArray), GC_TYPE_ARRAY);
    if (arr == NULL) {
        return NULL;
    }
    
    /* Use at least INITIAL_CAPACITY */
    if (initial_capacity < INITIAL_CAPACITY) {
        initial_capacity = INITIAL_CAPACITY;
    }
    
    arr->length = 0;
    arr->capacity = initial_capacity;
    arr->elem_type = elem_type;
    arr->elem_size = get_element_size(elem_type);
    arr->data = NULL;
    
    /* For structs, we don't know the size yet - delay allocation */
    if (elem_type == ELEM_STRUCT) {
        arr->elem_size = 0;  /* Will be set on first push */
        arr->data = NULL;     /* Allocate on first push */
    } else {
        size_t bytes;
        if (darray_storage_size(arr->capacity, arr->elem_size, &bytes))
            arr->data = darray_aligned_alloc(bytes);
        if (arr->data == NULL) {
            gc_release(arr);
            return NULL;
        }
    }
    
    return arr;
}

/* Grow array capacity (maintains 32-byte alignment for SIMD) */
static void dyn_array_grow(DynArray* arr) {
    if (arr->capacity <= 0 || arr->capacity > INT64_MAX / GROWTH_FACTOR)
        darray_allocation_failure();
    int64_t new_capacity = arr->capacity * GROWTH_FACTOR;
    size_t bytes;
    if (!darray_storage_size(new_capacity, arr->elem_size, &bytes)) darray_allocation_failure();
    void* new_data = darray_aligned_alloc(bytes);

    if (new_data == NULL) {
        darray_allocation_failure();
    }

    if (arr->length) memcpy(new_data, arr->data, (size_t)arr->length * arr->elem_size);
    free(arr->data);
    arr->data = new_data;
    arr->capacity = new_capacity;
}

/* Push int */
DynArray* dyn_array_push_int(DynArray* arr, int64_t value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_INT && "DynArray: Type mismatch");
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    ((int64_t*)arr->data)[arr->length] = value;
    arr->length++;
    
    return arr;
}

/* Push u8 */
DynArray* dyn_array_push_u8(DynArray* arr, uint8_t value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_U8 && "DynArray: Type mismatch");

    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }

    ((uint8_t*)arr->data)[arr->length] = value;
    arr->length++;

    return arr;
}

/* Push float */
DynArray* dyn_array_push_float(DynArray* arr, double value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_FLOAT && "DynArray: Type mismatch");
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    ((double*)arr->data)[arr->length] = value;
    arr->length++;
    
    return arr;
}

/* Push bool */
DynArray* dyn_array_push_bool(DynArray* arr, bool value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_BOOL && "DynArray: Type mismatch");
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    ((bool*)arr->data)[arr->length] = value;
    arr->length++;
    
    return arr;
}

/* Push string */
DynArray* dyn_array_push_string(DynArray* arr, const char* value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRING && "DynArray: Type mismatch");
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    /* Store string pointer (caller responsible for string lifetime) */
    ((const char**)arr->data)[arr->length] = value;
    arr->length++;
    
    return arr;
}

/* Push string (makes a copy with strdup) */
DynArray* dyn_array_push_string_copy(DynArray* arr, const char* value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRING && "DynArray: Type mismatch");
    
    if (value == NULL) {
        return arr;  /* Silently ignore NULL strings */
    }
    
    /* Duplicate the string */
    char* copy = strdup(value);
    if (copy == NULL) {
        darray_allocation_failure();
    }
    
    /* Use regular push with the copy */
    return dyn_array_push_string(arr, copy);
}

DynArray* dyn_array_push_array(DynArray* arr, DynArray* value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_ARRAY && "DynArray: Type mismatch");
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    /* Store DynArray pointer - nested array */
    ((DynArray**)arr->data)[arr->length] = value;
    arr->length++;
    
    return arr;
}

/* Pop int */
int64_t dyn_array_pop_int(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_INT && "DynArray: Type mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return 0;
    }
    
    arr->length--;
    if (success) *success = true;
    return ((int64_t*)arr->data)[arr->length];
}

/* Pop u8 */
uint8_t dyn_array_pop_u8(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_U8 && "DynArray: Type mismatch");

    if (arr->length == 0) {
        if (success) *success = false;
        return 0;
    }

    arr->length--;
    if (success) *success = true;
    return ((uint8_t*)arr->data)[arr->length];
}

/* Pop float */
double dyn_array_pop_float(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_FLOAT && "DynArray: Type mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return 0.0;
    }
    
    arr->length--;
    if (success) *success = true;
    return ((double*)arr->data)[arr->length];
}

/* Pop bool */
bool dyn_array_pop_bool(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_BOOL && "DynArray: Type mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return false;
    }
    
    arr->length--;
    if (success) *success = true;
    return ((bool*)arr->data)[arr->length];
}

/* Pop string */
const char* dyn_array_pop_string(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRING && "DynArray: Type mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return NULL;
    }
    
    arr->length--;
    if (success) *success = true;
    return ((const char**)arr->data)[arr->length];
}

DynArray* dyn_array_pop_array(DynArray* arr, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_ARRAY && "DynArray: Type mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return NULL;
    }
    
    arr->length--;
    if (success) *success = true;
    return ((DynArray**)arr->data)[arr->length];
}

/* Get int */
int64_t dyn_array_get_int(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_INT && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    return ((int64_t*)arr->data)[index];
}

/* Get u8 */
uint8_t dyn_array_get_u8(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_U8 && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");

    return ((uint8_t*)arr->data)[index];
}

/* Get float */
double dyn_array_get_float(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_FLOAT && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    return ((double*)arr->data)[index];
}

/* Get bool */
bool dyn_array_get_bool(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_BOOL && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    return ((bool*)arr->data)[index];
}

/* Get string */
char* dyn_array_get_string(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRING && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");

    return (char*)((const char**)arr->data)[index];
}

DynArray* dyn_array_get_array(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_ARRAY && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    return ((DynArray**)arr->data)[index];
}

/* Set int */
void dyn_array_set_int(DynArray* arr, int64_t index, int64_t value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_INT && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    ((int64_t*)arr->data)[index] = value;
}

/* Set u8 */
void dyn_array_set_u8(DynArray* arr, int64_t index, uint8_t value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_U8 && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");

    ((uint8_t*)arr->data)[index] = value;
}

/* Set float */
void dyn_array_set_float(DynArray* arr, int64_t index, double value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_FLOAT && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    ((double*)arr->data)[index] = value;
}

/* Set bool */
void dyn_array_set_bool(DynArray* arr, int64_t index, bool value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_BOOL && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    ((bool*)arr->data)[index] = value;
}

/* Set string */
void dyn_array_set_string(DynArray* arr, int64_t index, const char* value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRING && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    ((const char**)arr->data)[index] = value;
}

void dyn_array_set_array(DynArray* arr, int64_t index, DynArray* value) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_ARRAY && "DynArray: Type mismatch");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    ((DynArray**)arr->data)[index] = value;
}

/* Remove element at index */
DynArray* dyn_array_remove_at(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(index >= 0 && index < arr->length && "DynArray: Index out of bounds");
    
    /* Shift elements down */
    if (index < arr->length - 1) {
        char* data_ptr = (char*)arr->data;
        memmove(
            data_ptr + (index * arr->elem_size),
            data_ptr + ((index + 1) * arr->elem_size),
            (arr->length - index - 1) * arr->elem_size
        );
    }
    
    arr->length--;
    return arr;
}

/* Clear all elements */
void dyn_array_clear(DynArray* arr) {
    assert(arr != NULL && "DynArray: NULL array");
    arr->length = 0;
}

/* Get length */
int64_t dyn_array_length(DynArray* arr) {
    assert(arr != NULL && "DynArray: NULL array");
    return arr->length;
}

/* Get capacity */
int64_t dyn_array_capacity(DynArray* arr) {
    assert(arr != NULL && "DynArray: NULL array");
    return arr->capacity;
}

/* Get element type */
ElementType dyn_array_get_elem_type(DynArray* arr) {
    assert(arr != NULL && "DynArray: NULL array");
    return arr->elem_type;
}

/* Reserve capacity */
void dyn_array_reserve(DynArray* arr, int64_t new_capacity) {
    assert(arr != NULL && "DynArray: NULL array");
    
    if (new_capacity <= arr->capacity) {
        return;
    }
    
    size_t bytes;
    if (!darray_storage_size(new_capacity, arr->elem_size, &bytes)) darray_allocation_failure();
    if (!arr->elem_size) {
        arr->capacity = new_capacity;
        return;
    }
    void* new_data = darray_aligned_alloc(bytes);
    if (new_data == NULL) {
        darray_allocation_failure();
    }

    if (arr->length) memcpy(new_data, arr->data, (size_t)arr->length * arr->elem_size);
    free(arr->data);
    arr->data = new_data;
    arr->capacity = new_capacity;
}

/* Clone array */
DynArray* dyn_array_clone(DynArray* arr) {
    assert(arr != NULL && "DynArray: NULL array");
    
    DynArray* new_arr = dyn_array_new_with_capacity(arr->elem_type, arr->length);
    if (new_arr == NULL) {
        return NULL;
    }
    
    /* I preserve flat struct width; its constructor deliberately delays storage. */
    if (arr->elem_type == ELEM_STRUCT && arr->elem_size) {
        size_t bytes;
        new_arr->elem_size = arr->elem_size;
        if (darray_storage_size(new_arr->capacity, new_arr->elem_size, &bytes))
            new_arr->data = darray_aligned_alloc(bytes);
        if (!new_arr->data) { gc_release(new_arr); return NULL; }
    }
    if (arr->length) memcpy(new_arr->data, arr->data, (size_t)arr->length * arr->elem_size);
    new_arr->length = arr->length;
    
    return new_arr;
}

static int compare_int(const void *left, const void *right) {
    int64_t a = *(const int64_t *)left, b = *(const int64_t *)right;
    return (a > b) - (a < b);
}
static int compare_u8(const void *left, const void *right) {
    uint8_t a = *(const uint8_t *)left, b = *(const uint8_t *)right;
    return (a > b) - (a < b);
}
static int compare_float(const void *left, const void *right) {
    double a = *(const double *)left, b = *(const double *)right;
    if (isnan(a) || isnan(b)) return isnan(a) ? (isnan(b) ? 0 : 1) : -1;
    return (a > b) - (a < b);
}
static int compare_bool(const void *left, const void *right) {
    bool a = *(const bool *)left, b = *(const bool *)right;
    return (a > b) - (a < b);
}
static int compare_string(const void *left, const void *right) {
    return strcmp(*(char *const *)left, *(char *const *)right);
}

DynArray *dyn_array_sorted(DynArray *arr) {
    if (!arr) return NULL;
    int (*compare)(const void *, const void *);
    switch (arr->elem_type) {
        case ELEM_INT: compare = compare_int; break;
        case ELEM_U8: compare = compare_u8; break;
        case ELEM_FLOAT: compare = compare_float; break;
        case ELEM_BOOL: compare = compare_bool; break;
        case ELEM_STRING: compare = compare_string; break;
        default: return NULL;
    }
    size_t width = get_element_size(arr->elem_type), bytes;
    if (arr->elem_size != width || arr->length < 0 || arr->capacity < arr->length ||
        !darray_storage_size(arr->capacity, width, &bytes) ||
        (arr->length && !arr->data)) return NULL;
    if (arr->elem_type == ELEM_STRING) {
        for (int64_t i = 0; i < arr->length; i++)
            if (!((char **)arr->data)[i]) return NULL;
    }
    DynArray *result = dyn_array_clone(arr);
    if (!result) return NULL;
    if (result->length > 1)
        qsort(result->data, (size_t)result->length, width, compare);
    return result;
}

/* Push struct - makes a copy of the struct */
DynArray* dyn_array_push_struct(DynArray* arr, const void* struct_ptr, size_t struct_size) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(struct_ptr != NULL && "DynArray: NULL struct pointer");
    /* My current native array ABI stores width in one byte. */
    if (struct_size == 0 || struct_size > UINT8_MAX) darray_allocation_failure();
    /* I snapshot a borrowed element before growth can invalidate its address. */
    unsigned char snapshot[UINT8_MAX];
    memcpy(snapshot, struct_ptr, struct_size);
    /* Auto-promote empty arrays to ELEM_STRUCT on first struct push.
     * This handles empty array literals [] whose element type couldn't
     * be inferred at compile time (e.g. bare [] passed as function args). */
    if (arr->length == 0 && arr->elem_type != ELEM_STRUCT) {
        arr->elem_type = ELEM_STRUCT;
        if (arr->data) { free(arr->data); arr->data = NULL; }
        arr->elem_size = 0;
    }
    assert(arr->elem_type == ELEM_STRUCT && "DynArray: Type mismatch");

    /* Set struct size and allocate on first push */
    if (arr->elem_size == 0) {
        size_t bytes;
        if (!struct_size || !darray_storage_size(arr->capacity, struct_size, &bytes))
            darray_allocation_failure();
        arr->data = darray_aligned_alloc(bytes);
        if (arr->data == NULL) {
            darray_allocation_failure();
        }
        arr->elem_size = struct_size;
    }
    
    if (arr->elem_size != struct_size) darray_allocation_failure();
    
    if (arr->length >= arr->capacity) {
        dyn_array_grow(arr);
    }
    
    /* Copy struct into array */
    void* dest = (uint8_t*)arr->data + (arr->length * arr->elem_size);
    memcpy(dest, snapshot, struct_size);
    arr->length++;
    
    return arr;
}

/* Get struct - returns pointer to struct in array (not a copy) */
void* dyn_array_get_struct(DynArray* arr, int64_t index) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(arr->elem_type == ELEM_STRUCT && "DynArray: Type mismatch");
    
    if (index < 0 || index >= arr->length) {
        fprintf(stderr, "DynArray: Index out of bounds: %lld (length: %lld)\n", 
                (long long)index, (long long)arr->length);
        return NULL;
    }
    
    /* Return pointer to struct in array */
    return (uint8_t*)arr->data + (index * arr->elem_size);
}

/* Set struct - copies the struct into the array */
void dyn_array_set_struct(DynArray* arr, int64_t index, const void* struct_ptr, size_t struct_size) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(struct_ptr != NULL && "DynArray: NULL struct pointer");
    assert(arr->elem_type == ELEM_STRUCT && "DynArray: Type mismatch");
    assert(arr->elem_size == struct_size && "DynArray: Struct size mismatch");
    
    if (index < 0 || index >= arr->length) {
        fprintf(stderr, "DynArray: Index out of bounds: %lld (length: %lld)\n", 
                (long long)index, (long long)arr->length);
        return;
    }
    
    /* Copy struct into array */
    void* dest = (uint8_t*)arr->data + (index * arr->elem_size);
    memcpy(dest, struct_ptr, struct_size);
}

/* Pop struct - copies the last struct into out_struct and removes it */
void dyn_array_pop_struct(DynArray* arr, void* out_struct, size_t struct_size, bool* success) {
    assert(arr != NULL && "DynArray: NULL array");
    assert(out_struct != NULL && "DynArray: NULL output pointer");
    assert(arr->elem_type == ELEM_STRUCT && "DynArray: Type mismatch");
    assert(arr->elem_size == struct_size && "DynArray: Struct size mismatch");
    
    if (arr->length == 0) {
        if (success) *success = false;
        return;
    }
    
    /* Copy last struct to output */
    void* src = (uint8_t*)arr->data + ((arr->length - 1) * arr->elem_size);
    memcpy(out_struct, src, struct_size);
    arr->length--;
    
    if (success) *success = true;
}
