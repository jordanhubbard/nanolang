# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow_config.h" 1

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 2







typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[8u];
} NvmFileNominalBindings;
NvmServiceResult nvm_file_nominal_check(const NvmFileNominalBindings *);

NvmServiceResult nvm_file_nominal_decode(const uint8_t *,size_t,NvmFileNominalBindings *);


NvmServiceResult nvm_file_nominal_encode(const NvmFileNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_FILE_NOMINAL_DESCRIBED, NVM_FILE_NOMINAL_INVALID,
    NVM_FILE_NOMINAL_LIMIT, NVM_FILE_NOMINAL_MEMORY
} NvmFileNominalStatus;
typedef enum {
    NVM_FILE_CATEGORY_UNKNOWN, NVM_FILE_CATEGORY_FILE,
    NVM_FILE_CATEGORY_OPEN_RESULT, NVM_FILE_CATEGORY_SCALAR_RESULT,
    NVM_FILE_CATEGORY_RECORD
} NvmFileCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmFileCategory category;
} NvmFileNominalLayout;
typedef struct NvmFileNominalPlan NvmFileNominalPlan;




NvmFileNominalStatus nvm_file_nominal_plan(const NvmModule *,NvmFileNominalPlan **);
void nvm_file_nominal_plan_free(NvmFileNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_file_nominal_layout_count(const NvmFileNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_layout(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_type(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_source(const NvmFileNominalPlan *,uint8_t,uint32_t,NvmFileNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_import(const NvmFileNominalPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 2
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
typedef enum {
    NVM_FILE_FLOW_OK, NVM_FILE_FLOW_INVALID, NVM_FILE_FLOW_UNRESOLVED,
    NVM_FILE_FLOW_LIMIT, NVM_FILE_FLOW_MEMORY
} NvmFileFlowStatus;
typedef struct NvmFileFlowDeclarations NvmFileFlowDeclarations;
typedef struct NvmFileFlowState NvmFileFlowState;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_index, catalog_ordinal;
    NvmFileCategory category;
} NvmFileFlowDeclaration;
typedef struct {
    uint16_t parameters, locals;
    uint8_t result_count;
    NvmFileFlowDeclaration result;
} NvmFileFlowFunction;
typedef enum {
    NVM_FILE_FLOW_ARM_NONE, NVM_FILE_FLOW_ARM_UNKNOWN,
    NVM_FILE_FLOW_ARM_OK, NVM_FILE_FLOW_ARM_ERROR
} NvmFileFlowArm;
typedef struct {
    NvmFileFlowDeclaration type;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        initialized;
    uint64_t owner;
    NvmFileFlowArm arm;
} NvmFileFlowValue;
typedef struct {
    
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        live, formal;
    uint16_t local;
    uint64_t owner, identity, region;
    
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        shared;
} NvmFileFlowReference;
typedef struct {
    uint16_t stack, regions, owners, references;
    uint64_t cleanup_obligations;
    uint16_t obligations;
    
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
   _Bool 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
        reachable;
} NvmFileFlowCounts;



typedef enum { NVM_FILE_FLOW_SERVICE, NVM_FILE_FLOW_CALL } NvmFileFlowObligationKind;
typedef enum { NVM_FILE_FLOW_INPUT_NONE, NVM_FILE_FLOW_INPUT_PRESERVED,
               NVM_FILE_FLOW_INPUT_CONSUMED } NvmFileFlowInputState;
enum {
    NVM_FILE_FLOW_CHECK_BINDING=1u, NVM_FILE_FLOW_CHECK_INVOCATION=2u,
    NVM_FILE_FLOW_CHECK_LIVENESS=4u, NVM_FILE_FLOW_CHECK_RIGHTS=8u,
    NVM_FILE_FLOW_CHECK_BORROW=16u, NVM_FILE_FLOW_CHECK_BYTE=32u,
    NVM_FILE_FLOW_CHECK_CALLEE=64u, NVM_FILE_FLOW_CHECK_CLEANUP=128u,
    NVM_FILE_FLOW_CHECK_RESULT=256u
};
typedef struct {
    NvmFileFlowObligationKind kind;
    uint32_t site, target, checks, required_rights, acquired_rights;
    uint16_t parameters, owned_inputs, borrowed_inputs;
    uint8_t result_count;
    NvmFileFlowDeclaration result;
    NvmFileFlowInputState outcomes[2];
} NvmFileFlowObligation;




NvmFileFlowStatus nvm_file_flow_declarations(const NvmModule *, NvmFileFlowDeclarations **out);
void nvm_file_flow_declarations_free(NvmFileFlowDeclarations *);

# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_function(const NvmFileFlowDeclarations *, uint32_t, NvmFileFlowFunction *);

# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_declaration(const NvmFileFlowDeclarations *, uint32_t, uint16_t,
                             NvmFileFlowDeclaration *);


NvmFileFlowStatus nvm_file_flow_state(NvmFileFlowDeclarations *, uint32_t, NvmFileFlowState **out);
void nvm_file_flow_state_free(NvmFileFlowState *);

# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_local(const NvmFileFlowState *, uint16_t, NvmFileFlowValue *);

# 91 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_stack(const NvmFileFlowState *, uint16_t, NvmFileFlowValue *);

# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_reference(const NvmFileFlowState *, uint16_t, NvmFileFlowReference *);

# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_counts(const NvmFileFlowState *, NvmFileFlowCounts *);

# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
_Bool 
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
    nvm_file_flow_obligation(const NvmFileFlowState *, uint16_t, NvmFileFlowObligation *);
NvmFileFlowStatus nvm_file_flow_clone(const NvmFileFlowState *, NvmFileFlowState **out);

NvmFileFlowStatus nvm_file_flow_refine(const NvmFileFlowState *, uint16_t local,
                                     NvmFileFlowState **ok, NvmFileFlowState **error);
NvmFileFlowStatus nvm_file_flow_join(NvmFileFlowState *, const NvmFileFlowState *, 
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h" 3 4
                                                                                  _Bool 
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.h"
                                                                                       *changed);



NvmFileFlowStatus nvm_file_flow_push_scalar(NvmFileFlowState *, uint8_t);
NvmFileFlowStatus nvm_file_flow_load(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_store(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_dup(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_pop(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_clear_copy(NvmFileFlowState *, uint16_t);


NvmFileFlowStatus nvm_file_flow_construct(NvmFileFlowState *, uint32_t catalog, uint16_t variant);
NvmFileFlowStatus nvm_file_flow_field(NvmFileFlowState *, uint16_t field);
NvmFileFlowStatus nvm_file_flow_take_result(NvmFileFlowState *, uint16_t local, NvmFileFlowArm);


NvmFileFlowStatus nvm_file_flow_service(NvmFileFlowState *, uint32_t site, uint32_t import,
                                      uint16_t reference);




NvmFileFlowStatus nvm_file_flow_call(NvmFileFlowState *, uint32_t site, uint32_t function,
                                   const uint16_t *references, uint16_t count);
NvmFileFlowStatus nvm_file_flow_move(NvmFileFlowState *, uint16_t from, uint16_t to);
NvmFileFlowStatus nvm_file_flow_take(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_put(NvmFileFlowState *, uint16_t);

NvmFileFlowStatus nvm_file_flow_drop_local(NvmFileFlowState *, uint16_t);
NvmFileFlowStatus nvm_file_flow_drop_stack(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_region_begin(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_region_end(NvmFileFlowState *);
NvmFileFlowStatus nvm_file_flow_borrow(NvmFileFlowState *, uint16_t local, uint16_t reference);
NvmFileFlowStatus nvm_file_flow_borrow_shared(NvmFileFlowState *,uint16_t local,uint16_t reference);
NvmFileFlowStatus nvm_file_flow_end_borrow(NvmFileFlowState *, uint16_t reference);



NvmFileFlowStatus nvm_file_flow_can_exit(const NvmFileFlowState *);
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow_config.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal_config.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 2



typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 2


const char *nl_file_catalog_interface(void);
const NlFilePlanMethod *nl_file_catalog_method(size_t);
const NlFilePlanType *nl_file_catalog_type(size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal_config.h" 2
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow_config.h" 2
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 1

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow_catalog.inc" 1
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 2


# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
struct NvmFileFlowDeclarations {
    uint32_t references, count;
    uint64_t next_identity;
    NvmFileNominalPlan *nominal;
    NvmFileFlowFunction functions[64u];
    uint32_t offsets[64u];
    NvmFileFlowDeclaration locals[];
};
struct NvmFileFlowState {
    NvmFileFlowDeclarations *declarations;
    uint32_t function;
    uint16_t stack_count, region_count, obligation_count;
    uint64_t family, cleanup_obligations;
    
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        reachable;
    NvmFileFlowObligation obligations[256u];
    NvmFileFlowValue locals[256u];
    NvmFileFlowValue stack[256u];
    NvmFileFlowReference references[256u];
    uint64_t regions[256u];
};
static 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           scalar(uint8_t tag) { return tag==TAG_INT || tag==TAG_BOOL || tag==TAG_VOID || tag==TAG_STRING; }
static 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           owned(NvmFileFlowDeclaration d) {
    return !d.mode && (d.category==NVM_FILE_CATEGORY_FILE || d.category==NVM_FILE_CATEGORY_OPEN_RESULT);
}
static 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           same(NvmFileFlowDeclaration a,NvmFileFlowDeclaration b) {
    return a.tag==b.tag && a.mode==b.mode && a.global_index==b.global_index &&
           a.catalog_ordinal==b.catalog_ordinal && a.category==b.category;
}
static NvmFileFlowDeclaration scalar_type(uint8_t tag) {
    return (NvmFileFlowDeclaration){tag,0,0xFFFFFFFFu,0xFFFFFFFFu,NVM_FILE_CATEGORY_UNKNOWN};
}
static NvmFileFlowStatus read_declaration(NvmV2Cursor *c,const NvmFileNominalPlan *p,
                                         NvmFileFlowDeclaration *out,
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                    _Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                         callables) {
    uint8_t tag,mode;uint16_t pad;uint32_t index;
    if(nvm_v2_u8(c,&tag)!=NVM_V2_OK || nvm_v2_u8(c,&mode)!=NVM_V2_OK ||
       nvm_v2_u16(c,&pad)!=NVM_V2_OK || nvm_v2_u32(c,&index)!=NVM_V2_OK || pad)
        return NVM_FILE_FLOW_INVALID;
    NvmFileFlowDeclaration d=scalar_type(tag);d.mode=mode;d.global_index=index;
    if(index==0xFFFFFFFFu) {
        if(mode || (!scalar(tag) && !(callables && tag==TAG_FUNCTION)))return NVM_FILE_FLOW_UNRESOLVED;
    } else {
        NvmFileNominalLayout layout;
        if(!nvm_file_nominal_layout(p,index,&layout))return NVM_FILE_FLOW_INVALID;
        if(layout.category==NVM_FILE_CATEGORY_UNKNOWN)return NVM_FILE_FLOW_UNRESOLVED;
        d.catalog_ordinal=layout.catalog_ordinal;d.category=layout.category;
        if((mode && ((mode!=1 && mode!=2) || d.category!=NVM_FILE_CATEGORY_FILE)) ||
           tag!=(layout.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION))
            return NVM_FILE_FLOW_INVALID;
    }
    *out=d;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus nominal_status(NvmFileNominalStatus s) {
    switch(s) {
    case NVM_FILE_NOMINAL_DESCRIBED:return NVM_FILE_FLOW_OK;
    case NVM_FILE_NOMINAL_LIMIT:return NVM_FILE_FLOW_LIMIT;
    case NVM_FILE_NOMINAL_MEMORY:return NVM_FILE_FLOW_MEMORY;
    default:return NVM_FILE_FLOW_INVALID;
    }
}
static NvmFileFlowStatus file_flow_declarations_mode(const NvmModule *m,NvmFileFlowDeclarations **out,
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                                     _Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                                          callables) {
    if(!m || !out || !m->function_count || !m->functions)return NVM_FILE_FLOW_INVALID;
    if(m->function_count>64u)return NVM_FILE_FLOW_LIMIT;
    if(m->callback_contract_count || m->module_ref_count)return NVM_FILE_FLOW_UNRESOLVED;
    size_t count=0;
    for(uint32_t i=0;i<m->function_count;i++) {
        const NvmFunctionEntry *f=&m->functions[i];
        if(f->arity>f->local_count || f->result_count>1)return NVM_FILE_FLOW_INVALID;
        if(f->upvalue_count)return NVM_FILE_FLOW_UNRESOLVED;
        if(f->local_count>256u)return NVM_FILE_FLOW_LIMIT;
        if(count>
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                (18446744073709551615UL)
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                        -f->local_count)return NVM_FILE_FLOW_LIMIT;
        count+=f->local_count;
    }
    if(count>(
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
             (18446744073709551615UL)
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                     -sizeof(NvmFileFlowDeclarations))/sizeof(NvmFileFlowDeclaration))
        return NVM_FILE_FLOW_LIMIT;
    size_t bytes=sizeof(NvmFileFlowDeclarations)+count*sizeof(NvmFileFlowDeclaration);


    size_t nominal_bound;
    if(!nvm_file_nominal_storage_bound(65536u,&nominal_bound) ||
       bytes>(16u * 1024u * 1024u) || nominal_bound>(16u * 1024u * 1024u)-bytes)return NVM_FILE_FLOW_LIMIT;
    NvmFileNominalPlan *nominal=
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                        ((void *)0)
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                            ;
    NvmFileFlowStatus status=nominal_status(nvm_file_nominal_plan(m,&nominal));
    if(status!=NVM_FILE_FLOW_OK)return status;
    NvmFileFlowDeclarations *d=calloc(1,bytes);
    if(!d){nvm_file_nominal_plan_free(nominal);return NVM_FILE_FLOW_MEMORY;}
    d->references=1;d->count=m->function_count;d->nominal=nominal;d->next_identity=1;
    NvmV2Cursor c;nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    uint32_t version,layouts,functions;const uint8_t *flags;
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK || version!=1u ||
       nvm_v2_u32(&c,&layouts)!=NVM_V2_OK || layouts!=nvm_file_nominal_layout_count(nominal) ||
       nvm_v2_take(&c,layouts,&flags)!=NVM_V2_OK || nvm_v2_align4(&c)!=NVM_V2_OK ||
       nvm_v2_u32(&c,&functions)!=NVM_V2_OK || functions!=d->count) {
        status=NVM_FILE_FLOW_INVALID;goto fail;
    }
    size_t offset=0;
    for(uint32_t i=0;i<d->count;i++) {
        NvmFileFlowFunction *f=&d->functions[i];const NvmFunctionEntry *actual=&m->functions[i];
        if(nvm_v2_u16(&c,&f->locals)!=NVM_V2_OK || nvm_v2_u16(&c,&f->parameters)!=NVM_V2_OK ||
           f->locals!=actual->local_count || f->parameters!=actual->arity) {
            status=NVM_FILE_FLOW_INVALID;goto fail;
        }
        d->offsets[i]=(uint32_t)offset;f->result_count=actual->result_count;
        status=read_declaration(&c,nominal,&f->result,callables);if(status!=NVM_FILE_FLOW_OK)goto fail;
        if(f->result.mode || f->result.tag!=(f->result_count?actual->result_tag:TAG_VOID)) {
            status=NVM_FILE_FLOW_INVALID;goto fail;
        }
        for(uint16_t j=0;j<f->locals;j++) {
            status=read_declaration(&c,nominal,&d->locals[offset+j],callables);if(status!=NVM_FILE_FLOW_OK)goto fail;
            if(j>=f->parameters && d->locals[offset+j].mode) {status=NVM_FILE_FLOW_INVALID;goto fail;}
        }
        offset+=f->locals;
    }
    if(offset!=count || c.pos!=c.size){status=NVM_FILE_FLOW_INVALID;goto fail;}
    *out=d;return NVM_FILE_FLOW_OK;
fail:
    nvm_file_flow_declarations_free(d);return status;
}
NvmFileFlowStatus nvm_file_flow_declarations(const NvmModule *m,NvmFileFlowDeclarations **out) {
    return file_flow_declarations_mode(m,out,
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                            0
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                 );
}
void nvm_file_flow_declarations_free(NvmFileFlowDeclarations *d) {
    if(d && --d->references==0){nvm_file_nominal_plan_free(d->nominal);free(d);}
}

# 132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_function(const NvmFileFlowDeclarations *d,uint32_t f,NvmFileFlowFunction *out) {
    if(!d || !out || f>=d->count)return 
# 133 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                       0
# 133 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                            ;
    *out=d->functions[f];return 
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                               1
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                   ;
}

# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_declaration(const NvmFileFlowDeclarations *d,uint32_t f,uint16_t local,
                              NvmFileFlowDeclaration *out) {
    if(!d || !out || f>=d->count || local>=d->functions[f].locals)return 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                        0
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                             ;
    *out=d->locals[d->offsets[f]+local];return 
# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                              1
# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                  ;
}
static NvmFileFlowValue initial_value(NvmFileFlowDeclaration type,
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                 _Bool 
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                      initialized,uint64_t owner) {
    NvmFileFlowArm arm=type.category==NVM_FILE_CATEGORY_OPEN_RESULT ||
                       type.category==NVM_FILE_CATEGORY_SCALAR_RESULT ? NVM_FILE_FLOW_ARM_UNKNOWN:NVM_FILE_FLOW_ARM_NONE;
    return (NvmFileFlowValue){type,initialized,owner,arm};
}
NvmFileFlowStatus nvm_file_flow_state(NvmFileFlowDeclarations *d,uint32_t function,NvmFileFlowState **out) {
    if(!d || !out || function>=d->count)return NVM_FILE_FLOW_INVALID;
    if(d->references==
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                     (4294967295U) 
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                || sizeof(NvmFileFlowState)>(16u * 1024u * 1024u))return NVM_FILE_FLOW_LIMIT;
    uint32_t owners=0,identities=1;
    for(uint16_t i=0;i<d->functions[function].parameters;i++) {
        NvmFileFlowDeclaration type=d->locals[d->offsets[function]+i];
        owners+=owned(type);identities+=owned(type) || type.mode;
    }
    if(owners>256u || identities>
# 154 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                              (18446744073709551615UL)
# 154 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                        -d->next_identity)return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowState *s=calloc(1,sizeof *s);if(!s)return NVM_FILE_FLOW_MEMORY;
    s->declarations=d;s->function=function;s->family=d->next_identity++;s->reachable=
# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                    1
# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                        ;
    const NvmFileFlowFunction *f=&d->functions[function];
    for(uint16_t i=0;i<f->locals;i++) {
        NvmFileFlowDeclaration type=d->locals[d->offsets[function]+i];
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                     _Bool 
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                          parameter=i<f->parameters;
        s->locals[i]=initial_value(type,parameter,parameter && owned(type)?d->next_identity++:0);
        if(parameter && type.mode) {
            uint64_t identity=d->next_identity++;
            s->references[i]=(NvmFileFlowReference){
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                   1
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                       ,
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                        1
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                            ,i,identity,identity,0,type.mode==1};
        }
    }
    d->references++;*out=s;return NVM_FILE_FLOW_OK;
}
void nvm_file_flow_state_free(NvmFileFlowState *s) {
    if(s){nvm_file_flow_declarations_free(s->declarations);free(s);}
}
static 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           local_valid(const NvmFileFlowState *s,uint16_t local) {
    return s && local<s->declarations->functions[s->function].locals;
}

# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_local(const NvmFileFlowState *s,uint16_t local,NvmFileFlowValue *out) {
    if(!out || !local_valid(s,local))return 
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                           0
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                ;
    *out=s->locals[local];return 
# 176 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                1
# 176 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                    ;
}

# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_stack(const NvmFileFlowState *s,uint16_t index,NvmFileFlowValue *out) {
    if(!s || !out || index>=s->stack_count)return 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                 0
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                      ;
    *out=s->stack[index];return 
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                               1
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                   ;
}

# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_reference(const NvmFileFlowState *s,uint16_t reference,NvmFileFlowReference *out) {
    if(!s || !out || reference>=256u)return 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                             0
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                  ;
    *out=s->references[reference];return 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                        1
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                            ;
}

# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_counts(const NvmFileFlowState *s,NvmFileFlowCounts *out) {
    if(!s || !out)return 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                        0
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                             ;
    NvmFileFlowCounts c={s->stack_count,s->region_count,0,0,s->cleanup_obligations,s->obligation_count,s->reachable};
    for(uint16_t i=0;i<s->declarations->functions[s->function].locals;i++)c.owners+=s->locals[i].owner!=0;
    for(uint16_t i=0;i<s->stack_count;i++)c.owners+=s->stack[i].owner!=0;
    for(uint16_t i=0;i<256u;i++)c.references+=s->references[i].live;
    *out=c;return 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                 1
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                     ;
}
static 
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           held(const NvmFileFlowState *s,uint64_t owner) {
    for(uint16_t i=0;i<256u;i++)
        if(s->references[i].live && s->references[i].owner==owner)return 
# 196 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                        1
# 196 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                            ;
    return 
# 197 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
          0
# 197 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
               ;
}
static 
# 199 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 199 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           live_owner(const NvmFileFlowState *s,uint16_t local) {
    return local_valid(s,local) && s->locals[local].initialized && s->locals[local].owner &&
           owned(s->locals[local].type) && !held(s,s->locals[local].owner);
}
static void clear_local(NvmFileFlowState *s,uint16_t local) {
    s->locals[local]=initial_value(s->locals[local].type,
# 204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                        0
# 204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                             ,0);
}
static void pop(NvmFileFlowState *s) { s->stack[--s->stack_count]=(NvmFileFlowValue){0}; }
NvmFileFlowStatus nvm_file_flow_push_scalar(NvmFileFlowState *s,uint8_t tag) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s)return NVM_FILE_FLOW_INVALID;
    if(!scalar(tag))return NVM_FILE_FLOW_UNRESOLVED;
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    s->stack[s->stack_count++]=initial_value(scalar_type(tag),
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                             1
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                 ,0);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_load(NvmFileFlowState *s,uint16_t local) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!local_valid(s,local) || !s->locals[local].initialized || s->locals[local].type.mode ||
       owned(s->locals[local].type))return NVM_FILE_FLOW_INVALID;
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    s->stack[s->stack_count++]=s->locals[local];return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_store(NvmFileFlowState *s,uint16_t local) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!local_valid(s,local) || !s->stack_count)return NVM_FILE_FLOW_INVALID;
    NvmFileFlowValue value=s->stack[s->stack_count-1];


    if(value.initialized && !value.owner && value.type.tag==TAG_VOID &&
       !value.type.mode && value.type.global_index==0xFFFFFFFFu &&
       s->locals[local].type.tag!=TAG_VOID) {
        NvmFileFlowStatus status=nvm_file_flow_clear_copy(s,local);
        if(status==NVM_FILE_FLOW_OK)pop(s);
        return status;
    }
    if(!value.initialized || value.owner || s->locals[local].type.mode || owned(s->locals[local].type) ||
       !same(value.type,s->locals[local].type))return NVM_FILE_FLOW_INVALID;
    s->locals[local]=value;pop(s);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_dup(NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s || !s->stack_count || s->stack[s->stack_count-1].owner)return NVM_FILE_FLOW_INVALID;
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    s->stack[s->stack_count]=s->stack[s->stack_count-1];s->stack_count++;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_pop(NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s || !s->stack_count || s->stack[s->stack_count-1].owner)return NVM_FILE_FLOW_INVALID;
    pop(s);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_move(NvmFileFlowState *s,uint16_t from,uint16_t to) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!live_owner(s,from) || !local_valid(s,to) || s->locals[to].initialized ||
       !same(s->locals[from].type,s->locals[to].type))return NVM_FILE_FLOW_INVALID;
    s->locals[to]=s->locals[from];
    if(s->locals[to].type.category==NVM_FILE_CATEGORY_OPEN_RESULT)s->locals[to].arm=NVM_FILE_FLOW_ARM_UNKNOWN;
    clear_local(s,from);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_take(NvmFileFlowState *s,uint16_t local) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!live_owner(s,local))return NVM_FILE_FLOW_INVALID;
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    s->stack[s->stack_count]=s->locals[local];
    if(s->stack[s->stack_count].type.category==NVM_FILE_CATEGORY_OPEN_RESULT)s->stack[s->stack_count].arm=NVM_FILE_FLOW_ARM_UNKNOWN;
    s->stack_count++;clear_local(s,local);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_put(NvmFileFlowState *s,uint16_t local) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!local_valid(s,local) || s->locals[local].initialized || !s->stack_count)return NVM_FILE_FLOW_INVALID;
    NvmFileFlowValue value=s->stack[s->stack_count-1];
    if(!value.owner || !owned(value.type) || !same(value.type,s->locals[local].type))return NVM_FILE_FLOW_INVALID;
    if(value.type.category==NVM_FILE_CATEGORY_OPEN_RESULT)value.arm=NVM_FILE_FLOW_ARM_UNKNOWN;
    s->locals[local]=value;pop(s);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_drop_local(NvmFileFlowState *s,uint16_t local) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!live_owner(s,local))return NVM_FILE_FLOW_INVALID;
    if(s->cleanup_obligations==
# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                              (18446744073709551615UL)
# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                        )return NVM_FILE_FLOW_LIMIT;
    s->cleanup_obligations++;clear_local(s,local);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_drop_stack(NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s || !s->stack_count || !s->stack[s->stack_count-1].owner)return NVM_FILE_FLOW_INVALID;
    if(s->cleanup_obligations==
# 282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                              (18446744073709551615UL)
# 282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                        )return NVM_FILE_FLOW_LIMIT;
    s->cleanup_obligations++;pop(s);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_region_begin(NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s)return NVM_FILE_FLOW_INVALID;
    if(s->region_count==256u || s->declarations->next_identity==
# 288 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                 (18446744073709551615UL)
# 288 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                           )return NVM_FILE_FLOW_LIMIT;
    s->regions[s->region_count++]=s->declarations->next_identity++;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_region_end(NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s || !s->region_count)return NVM_FILE_FLOW_INVALID;
    uint64_t region=s->regions[s->region_count-1];
    for(uint16_t i=0;i<256u;i++)
        if(s->references[i].live && !s->references[i].formal && s->references[i].region==region)
            s->references[i]=(NvmFileFlowReference){0};
    s->regions[--s->region_count]=0;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_flow_borrow_mode(NvmFileFlowState *s,uint16_t local,uint16_t reference,
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                                    _Bool 
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                                         shared) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!local_valid(s,local) || !s->locals[local].initialized || !s->locals[local].owner ||
       s->locals[local].type.mode || s->locals[local].type.category!=NVM_FILE_CATEGORY_FILE ||
       reference>=256u || s->references[reference].live || !s->region_count)
        return NVM_FILE_FLOW_INVALID;
    for(uint16_t i=0;i<256u;i++)
        if(s->references[i].live && s->references[i].owner==s->locals[local].owner &&
           (!shared || !s->references[i].shared))return NVM_FILE_FLOW_INVALID;
    if(s->declarations->next_identity==
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                      (18446744073709551615UL)
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                )return NVM_FILE_FLOW_LIMIT;
    s->references[reference]=(NvmFileFlowReference){
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                   1
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                       ,
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                        0
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                             ,local,s->locals[local].owner,
        s->declarations->next_identity++,s->regions[s->region_count-1],shared};return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_borrow(NvmFileFlowState *s,uint16_t local,uint16_t reference) {
    return file_flow_borrow_mode(s,local,reference,
# 314 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                  0
# 314 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                       );
}
NvmFileFlowStatus nvm_file_flow_borrow_shared(NvmFileFlowState *s,uint16_t local,uint16_t reference) {
    return file_flow_borrow_mode(s,local,reference,
# 317 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                  1
# 317 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                      );
}
NvmFileFlowStatus nvm_file_flow_end_borrow(NvmFileFlowState *s,uint16_t reference) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s || reference>=256u || !s->references[reference].live ||
       s->references[reference].formal)return NVM_FILE_FLOW_INVALID;
    s->references[reference]=(NvmFileFlowReference){0};return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_can_exit(const NvmFileFlowState *s) {
    if(s && !s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(!s)return NVM_FILE_FLOW_INVALID;
    const NvmFileFlowFunction *f=&s->declarations->functions[s->function];
    if(s->region_count || s->stack_count!=f->result_count)return NVM_FILE_FLOW_INVALID;
    if(f->result_count) {
        NvmFileFlowValue value=s->stack[0];
        if(!value.initialized || !same(value.type,f->result) ||
           (owned(value.type)!=(value.owner!=0)))return NVM_FILE_FLOW_INVALID;
    }
    for(uint16_t i=0;i<f->locals;i++)if(s->locals[i].owner)return NVM_FILE_FLOW_INVALID;
    for(uint16_t i=0;i<256u;i++)
        if(s->references[i].live && !s->references[i].formal)return NVM_FILE_FLOW_INVALID;
    return NVM_FILE_FLOW_OK;
}

static 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           result_type(NvmFileFlowDeclaration type) {
    return type.category==NVM_FILE_CATEGORY_OPEN_RESULT || type.category==NVM_FILE_CATEGORY_SCALAR_RESULT;
}
static 
# 344 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 344 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           catalog_type(const NvmFileFlowState *s,uint32_t ordinal,NvmFileFlowDeclaration *out) {
    NvmFileNominalLayout l;
    if(!nvm_file_nominal_type(s->declarations->nominal,ordinal,&l))return 
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                    0
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                         ;
    *out=(NvmFileFlowDeclaration){l.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION,
        0,l.global_index,l.catalog_ordinal,l.category};return 
# 348 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                             1
# 348 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                 ;
}
static 
# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           member_type(const NvmFileFlowState *s,uint32_t context,const char *id,NvmFileFlowDeclaration *out) {
    if(!id){*out=scalar_type(TAG_VOID);return 
# 351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                             1
# 351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                 ;}
    if(!strcmp(id,"nsi:core/int")){*out=scalar_type(TAG_INT);return 
# 352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                   1
# 352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                       ;}
    if(!strcmp(id,"nsi:core/bool")){*out=scalar_type(TAG_BOOL);return 
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                     1
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                         ;}
    if(!strcmp(id,"nsi:core/string")){*out=scalar_type(TAG_STRING);return 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                         1
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                             ;}
    for(uint32_t i=((void)(context),0u);i<((void)(context),0u)+((void)(context),8u);i++) {
        const NlServicePlanType *t=nl_file_catalog_type(i);
        if(t && !strcmp(t->id,id))return catalog_type(s,i,out);
    }
    return 
# 359 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
          0
# 359 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
               ;
}
static 
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           value_same(NvmFileFlowValue a,NvmFileFlowValue b) {
    return same(a.type,b.type) && a.initialized==b.initialized && a.owner==b.owner;
}
static 
# 364 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 364 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           reference_same(NvmFileFlowReference a,NvmFileFlowReference b) {
    return a.live==b.live && (!a.live || (a.formal==b.formal && a.local==b.local &&
        a.owner==b.owner && a.identity==b.identity && a.region==b.region && a.shared==b.shared));
}
static 
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           obligation_same(NvmFileFlowObligation a,NvmFileFlowObligation b) {
    return a.kind==b.kind && a.site==b.site && a.target==b.target && a.checks==b.checks &&
        a.required_rights==b.required_rights && a.acquired_rights==b.acquired_rights &&
        a.parameters==b.parameters && a.owned_inputs==b.owned_inputs && a.borrowed_inputs==b.borrowed_inputs &&
        a.result_count==b.result_count && same(a.result,b.result) &&
        a.outcomes[0]==b.outcomes[0] && a.outcomes[1]==b.outcomes[1];
}
static NvmFileFlowStatus obligation_slot(const NvmFileFlowState *s,NvmFileFlowObligation item,uint16_t *slot) {
    if(item.site==
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                 (4294967295U)
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                           )return NVM_FILE_FLOW_INVALID;
    for(uint16_t i=0;i<s->obligation_count;i++)if(s->obligations[i].site==item.site) {
        if(!obligation_same(s->obligations[i],item))return NVM_FILE_FLOW_UNRESOLVED;
        *slot=i;return NVM_FILE_FLOW_OK;
    }
    if(s->obligation_count==256u)return NVM_FILE_FLOW_LIMIT;
    *slot=s->obligation_count;return NVM_FILE_FLOW_OK;
}
static void commit_obligation(NvmFileFlowState *s,NvmFileFlowObligation item,uint16_t slot) {
    if(slot==s->obligation_count)s->obligations[s->obligation_count++]=item;
}

# 387 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
_Bool 
# 387 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
    nvm_file_flow_obligation(const NvmFileFlowState *s,uint16_t index,NvmFileFlowObligation *out) {
    if(!s || !out || index>=s->obligation_count)return 
# 388 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                      0
# 388 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                           ;
    *out=s->obligations[index];return 
# 389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                     1
# 389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                         ;
}
NvmFileFlowStatus nvm_file_flow_clone(const NvmFileFlowState *s,NvmFileFlowState **out) {
    if(!s || !out)return NVM_FILE_FLOW_INVALID;
    if(s->declarations->references==
# 393 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                   (4294967295U)
# 393 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                             )return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowState *copy=malloc(sizeof *copy);if(!copy)return NVM_FILE_FLOW_MEMORY;
    *copy=*s;s->declarations->references++;*out=copy;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_refine(const NvmFileFlowState *s,uint16_t local,
                                      NvmFileFlowState **ok,NvmFileFlowState **error) {
    if(!s || !ok || !error || ok==error || !local_valid(s,local))return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    NvmFileFlowValue value=s->locals[local];
    if(!value.initialized || !result_type(value.type) || value.type.mode)return NVM_FILE_FLOW_INVALID;
    if(s->declarations->references>
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                  (4294967295U)
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                            -2)return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowState *a=
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                       ((void *)0)
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                           ,*b=
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                               ((void *)0)
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                   ;
    NvmFileFlowStatus status=nvm_file_flow_clone(s,&a);if(status!=NVM_FILE_FLOW_OK)return status;
    status=nvm_file_flow_clone(s,&b);
    if(status!=NVM_FILE_FLOW_OK){nvm_file_flow_state_free(a);return status;}
    a->reachable=value.arm!=NVM_FILE_FLOW_ARM_ERROR;b->reachable=value.arm!=NVM_FILE_FLOW_ARM_OK;
    a->locals[local].arm=NVM_FILE_FLOW_ARM_OK;b->locals[local].arm=NVM_FILE_FLOW_ARM_ERROR;
    *ok=a;*error=b;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_join(NvmFileFlowState *s,const NvmFileFlowState *incoming,
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                    _Bool 
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                         *changed) {
    if(!s || !incoming || !changed)return NVM_FILE_FLOW_INVALID;
    if(s->declarations!=incoming->declarations || s->function!=incoming->function || s->family!=incoming->family)
        return NVM_FILE_FLOW_UNRESOLVED;
    if(!incoming->reachable){*changed=
# 416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                     0
# 416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                          ;return NVM_FILE_FLOW_OK;}
    if(!s->reachable){*s=*incoming;*changed=
# 417 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                           1
# 417 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                               ;return NVM_FILE_FLOW_OK;}
    if(s->stack_count!=incoming->stack_count || s->region_count!=incoming->region_count ||
       s->cleanup_obligations!=incoming->cleanup_obligations)return NVM_FILE_FLOW_UNRESOLVED;
    
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        differs=
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                0
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                     ;
    uint16_t locals=s->declarations->functions[s->function].locals;
    for(uint16_t i=0;i<locals;i++) {
        if(!value_same(s->locals[i],incoming->locals[i]))return NVM_FILE_FLOW_UNRESOLVED;
        if(s->locals[i].initialized && s->locals[i].arm!=incoming->locals[i].arm) {
            if(!result_type(s->locals[i].type))return NVM_FILE_FLOW_UNRESOLVED;
            differs|=s->locals[i].arm!=NVM_FILE_FLOW_ARM_UNKNOWN;
        }
    }
    for(uint16_t i=0;i<s->stack_count;i++) {
        if(!value_same(s->stack[i],incoming->stack[i]))return NVM_FILE_FLOW_UNRESOLVED;
        if(s->stack[i].arm!=incoming->stack[i].arm) {
            if(!result_type(s->stack[i].type))return NVM_FILE_FLOW_UNRESOLVED;
            differs|=s->stack[i].arm!=NVM_FILE_FLOW_ARM_UNKNOWN;
        }
    }
    for(uint16_t i=0;i<s->region_count;i++)if(s->regions[i]!=incoming->regions[i])return NVM_FILE_FLOW_UNRESOLVED;
    for(uint16_t i=0;i<256u;i++)
        if(!reference_same(s->references[i],incoming->references[i]))return NVM_FILE_FLOW_UNRESOLVED;
    uint16_t add=0;
    for(uint16_t i=0;i<incoming->obligation_count;i++) {
        
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
       _Bool 
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
            found=
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                  0
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                       ;
        for(uint16_t j=0;j<s->obligation_count;j++)if(s->obligations[j].site==incoming->obligations[i].site) {
            if(!obligation_same(s->obligations[j],incoming->obligations[i]))return NVM_FILE_FLOW_UNRESOLVED;
            found=
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                 1
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                     ;break;
        }
        add+=!found;
    }
    if((uint32_t)s->obligation_count+add>256u)return NVM_FILE_FLOW_LIMIT;

    for(uint16_t i=0;i<locals;i++)if(s->locals[i].initialized && s->locals[i].arm!=incoming->locals[i].arm)
        s->locals[i].arm=NVM_FILE_FLOW_ARM_UNKNOWN;
    for(uint16_t i=0;i<s->stack_count;i++)if(s->stack[i].arm!=incoming->stack[i].arm)
        s->stack[i].arm=NVM_FILE_FLOW_ARM_UNKNOWN;
    for(uint16_t i=0;i<incoming->obligation_count;i++) {
        
# 455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
       _Bool 
# 455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
            found=
# 455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                  0
# 455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                       ;
        for(uint16_t j=0;j<s->obligation_count;j++)if(s->obligations[j].site==incoming->obligations[i].site){found=
# 456 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                                                  1
# 456 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                                                      ;break;}
        if(!found)s->obligations[s->obligation_count++]=incoming->obligations[i];
    }
    *changed=differs || add!=0;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_clear_copy(NvmFileFlowState *s,uint16_t local) {
    if(!local_valid(s,local))return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    if(s->locals[local].type.mode || owned(s->locals[local].type))return NVM_FILE_FLOW_INVALID;
    clear_local(s,local);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_construct(NvmFileFlowState *s,uint32_t ordinal,uint16_t variant) {
    if(!s)return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    NvmFileFlowDeclaration result;
    if(!catalog_type(s,ordinal,&result))return NVM_FILE_FLOW_INVALID;
    if(owned(result))return NVM_FILE_FLOW_INVALID;
    const NlServicePlanType *type=nl_file_catalog_type(ordinal);
    
# 474 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 474 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        record=result.category==NVM_FILE_CATEGORY_RECORD;
    if(!type || (record?variant!=0:variant>=type->member_count))return NVM_FILE_FLOW_INVALID;
    size_t count=record?type->member_count:1;
    if(count>s->stack_count)return NVM_FILE_FLOW_INVALID;
    if((size_t)s->stack_count-count+1>256u)return NVM_FILE_FLOW_LIMIT;
    uint16_t start=(uint16_t)(s->stack_count-count);
    for(size_t i=0;i<count;i++) {
        NvmFileFlowDeclaration expected;const NlServicePlanMember *member=&type->members[record?i:variant];
        if(!member_type(s,ordinal,member->type_id,&expected) || owned(expected))return NVM_FILE_FLOW_INVALID;
        NvmFileFlowValue value=s->stack[start+i];
        if(!value.initialized || value.owner || !same(expected,value.type))return NVM_FILE_FLOW_INVALID;
    }
    while(s->stack_count>start)pop(s);
    NvmFileFlowValue value=initial_value(result,
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                               1
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                   ,0);
    if(!record)value.arm=variant?NVM_FILE_FLOW_ARM_ERROR:NVM_FILE_FLOW_ARM_OK;
    s->stack[s->stack_count++]=value;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_field(NvmFileFlowState *s,uint16_t field) {
    if(!s || !s->stack_count)return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    NvmFileFlowValue value=s->stack[s->stack_count-1];
    if(value.owner || value.type.category!=NVM_FILE_CATEGORY_RECORD)return NVM_FILE_FLOW_INVALID;
    const NlServicePlanType *type=nl_file_catalog_type(value.type.catalog_ordinal);NvmFileFlowDeclaration result;
    if(!type || field>=type->member_count || !member_type(s,value.type.catalog_ordinal,type->members[field].type_id,&result) ||
       !scalar(result.tag) || result.global_index!=0xFFFFFFFFu)return NVM_FILE_FLOW_INVALID;
    s->stack[s->stack_count-1]=initial_value(result,
# 499 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                   1
# 499 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                       ,0);return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_take_result(NvmFileFlowState *s,uint16_t local,NvmFileFlowArm arm) {
    if(!local_valid(s,local))return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    NvmFileFlowValue value=s->locals[local];
    if(!value.initialized || !result_type(value.type) || value.arm!=arm ||
       (arm!=NVM_FILE_FLOW_ARM_OK && arm!=NVM_FILE_FLOW_ARM_ERROR))return NVM_FILE_FLOW_INVALID;
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    const NlServicePlanType *type=nl_file_catalog_type(value.type.catalog_ordinal);NvmFileFlowDeclaration payload;
    if(!type || type->member_count!=2 || !member_type(s,value.type.catalog_ordinal,type->members[arm==NVM_FILE_FLOW_ARM_ERROR].type_id,&payload))
        return NVM_FILE_FLOW_INVALID;
    if(owned(payload) && (!value.owner || value.type.category!=NVM_FILE_CATEGORY_OPEN_RESULT))return NVM_FILE_FLOW_INVALID;
    s->stack[s->stack_count++]=initial_value(payload,
# 512 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                    1
# 512 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                        ,owned(payload)?value.owner:0);
    clear_local(s,local);return NVM_FILE_FLOW_OK;
}
static 
# 515 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
      _Bool 
# 515 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
           live_reference(const NvmFileFlowState *s,uint16_t index,NvmFileFlowDeclaration *out) {
    if(index>=256u)return 
# 516 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                           0
# 516 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                ;
    NvmFileFlowReference r=s->references[index];
    if(!r.live || !local_valid(s,r.local))return 
# 518 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                0
# 518 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                     ;
    NvmFileFlowValue value=s->locals[r.local];
    if(!value.initialized || value.type.category!=NVM_FILE_CATEGORY_FILE)return 
# 520 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                               0
# 520 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                    ;
    if(r.formal) {
        if(index!=r.local || value.type.mode!=(r.shared?1:2) || value.owner)return 
# 522 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                                  0
# 522 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                       ;
    } else {
        if(value.type.mode || value.owner!=r.owner)return 
# 524 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                         0
# 524 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                              ;
        
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
       _Bool 
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
            found=
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                  0
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                       ;
        for(uint16_t i=0;i<s->region_count;i++)found|=s->regions[i]==r.region;
        if(!found)return 
# 527 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                        0
# 527 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                             ;
    }
    value.type.mode=r.shared?1:2;*out=value.type;return 
# 529 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                       1
# 529 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                           ;
}
static NvmFileFlowInputState input_state(NlServiceOwnerState state) {
    return state==NL_SERVICE_OWNER_PRESERVED?NVM_FILE_FLOW_INPUT_PRESERVED:
           state==NL_SERVICE_OWNER_CONSUMED?NVM_FILE_FLOW_INPUT_CONSUMED:NVM_FILE_FLOW_INPUT_NONE;
}
NvmFileFlowStatus nvm_file_flow_service(NvmFileFlowState *s,uint32_t site,uint32_t import,uint16_t reference) {
    if(!s)return NVM_FILE_FLOW_INVALID;
    if(!s->reachable)return NVM_FILE_FLOW_UNRESOLVED;
    uint32_t ordinal=5u;
    for(uint32_t i=0;i<5u;i++) {
        uint32_t index;
        if(nvm_file_nominal_import(s->declarations->nominal,i,&index) && index==import){ordinal=i;break;}
    }
    const NlServicePlanMethod *method=nl_file_catalog_method(ordinal);
    if(!method || !method->param_count)return NVM_FILE_FLOW_INVALID;
    NvmFileFlowDeclaration result,file;
    if(!member_type(s,((void)(ordinal),0u),method->params[method->param_count-1].type_id,&result) || !catalog_type(s,((void)(ordinal),0u),&file))
        return NVM_FILE_FLOW_INVALID;
    uint16_t consumed=0;
    NvmFileFlowObligation obligation={0};obligation.kind=NVM_FILE_FLOW_SERVICE;obligation.site=site;
    obligation.target=import;obligation.parameters=(uint16_t)(method->param_count-1);
    obligation.result_count=1;obligation.result=result;
    obligation.required_rights=method->required_rights;obligation.acquired_rights=method->acquired_rights;
    obligation.checks=NVM_FILE_FLOW_CHECK_BINDING|NVM_FILE_FLOW_CHECK_INVOCATION|NVM_FILE_FLOW_CHECK_LIVENESS|
        NVM_FILE_FLOW_CHECK_RIGHTS|NVM_FILE_FLOW_CHECK_RESULT|NVM_FILE_FLOW_CHECK_CLEANUP;
    obligation.outcomes[0]=input_state(method->outcomes[0].input_state);
    obligation.outcomes[1]=input_state(method->outcomes[1].input_state);
    size_t inputs=method->param_count-1;
    
# 558 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 558 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        exclusive=method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE;
    
# 559 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 559 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        consuming=method->input_mode==NL_SERVICE_INPUT_CONSUME;
    if((exclusive || consuming) && !inputs)return NVM_FILE_FLOW_INVALID;
    if(exclusive) {
        NvmFileFlowDeclaration ref_type;
        if(!live_reference(s,reference,&ref_type))return NVM_FILE_FLOW_INVALID;
        file.mode=2;if(!same(file,ref_type))return NVM_FILE_FLOW_INVALID;
        obligation.borrowed_inputs=1;obligation.checks|=NVM_FILE_FLOW_CHECK_BORROW;
    } else if(reference!=
# 566 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                        (65535)
# 566 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                )return NVM_FILE_FLOW_INVALID;



    size_t first=exclusive?1:0,values=inputs-first;
    if(values>s->stack_count)return NVM_FILE_FLOW_INVALID;
    for(size_t i=first;i<inputs;i++) {
        NvmFileFlowDeclaration expected;
        NvmFileFlowValue value=s->stack[s->stack_count-values+i-first];
        if(!member_type(s,((void)(ordinal),0u),method->params[i].type_id,&expected) ||
           !value.initialized || !same(expected,value.type))return NVM_FILE_FLOW_INVALID;
        if(consuming && !i) {
            if(!value.owner || !same(expected,file) || held(s,value.owner))return NVM_FILE_FLOW_INVALID;
            obligation.owned_inputs=1;
        } else if(owned(expected) || value.owner)return NVM_FILE_FLOW_INVALID;
        if(method->params[i].domain==NL_SERVICE_DOMAIN_BYTE_INT)obligation.checks|=NVM_FILE_FLOW_CHECK_BYTE;
        if(method->params[i].domain==NL_SERVICE_DOMAIN_TIMEOUT_MS)obligation.checks|=0u;
        if(((expected.catalog_ordinal)==
# 583 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
          (4294967295U)
# 583 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
          ) && expected.category==NVM_FILE_CATEGORY_RECORD)
            obligation.checks|=0u;
    }
    consumed=(uint16_t)values;
    if((uint32_t)s->stack_count-consumed+1>256u)return NVM_FILE_FLOW_LIMIT;
    if(owned(result)) {
        NvmFileFlowCounts counts;nvm_file_flow_counts(s,&counts);
        if(counts.owners==256u || s->declarations->next_identity==
# 590 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                               (18446744073709551615UL)
# 590 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                                         )return NVM_FILE_FLOW_LIMIT;
    }
    uint16_t slot;NvmFileFlowStatus status=obligation_slot(s,obligation,&slot);if(status!=NVM_FILE_FLOW_OK)return status;
    uint64_t owner=owned(result)?s->declarations->next_identity++:0;
    while(consumed){pop(s);consumed--;}
    s->stack[s->stack_count++]=initial_value(result,
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                   1
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                       ,owner);commit_obligation(s,obligation,slot);
    return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_flow_call(NvmFileFlowState *s,uint32_t site,uint32_t function,
                                    const uint16_t *references,uint16_t count) {
    if(!s || function>=s->declarations->count)return NVM_FILE_FLOW_INVALID;
    if(!s->reachable || function==s->function)return NVM_FILE_FLOW_UNRESOLVED;
    const NvmFileFlowFunction *f=&s->declarations->functions[function];
    if(count!=f->parameters || (count && !references))return NVM_FILE_FLOW_INVALID;
    uint16_t values=0,owners=0,borrows=0;
    const NvmFileFlowDeclaration *params=s->declarations->locals+s->declarations->offsets[function];
    for(uint16_t i=0;i<count;i++){values+=!params[i].mode;owners+=owned(params[i]);borrows+=params[i].mode!=0;}
    if(values>s->stack_count)return NVM_FILE_FLOW_INVALID;
    uint16_t start=(uint16_t)(s->stack_count-values),value_index=start;
    for(uint16_t i=0;i<count;i++) {
        if(params[i].mode) {
            NvmFileFlowDeclaration actual;
            if(!live_reference(s,references[i],&actual) || !same(params[i],actual))return NVM_FILE_FLOW_INVALID;
            for(uint16_t j=0;j<i;j++)if(params[j].mode &&
                s->references[references[j]].owner==s->references[references[i]].owner &&
                (params[j].mode!=1 || params[i].mode!=1))return NVM_FILE_FLOW_INVALID;
        } else {
            if(references[i]!=
# 617 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                             (65535)
# 617 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                     )return NVM_FILE_FLOW_INVALID;
            NvmFileFlowValue actual=s->stack[value_index++];
            if(!actual.initialized || !same(actual.type,params[i]) || owned(params[i])!=(actual.owner!=0) ||
               (actual.owner && held(s,actual.owner)))return NVM_FILE_FLOW_INVALID;
        }
    }
    if((uint32_t)start+f->result_count>256u)return NVM_FILE_FLOW_LIMIT;
    
# 624 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
   _Bool 
# 624 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
        owner_result=f->result_count && owned(f->result);
    NvmFileFlowCounts counts;nvm_file_flow_counts(s,&counts);
    if(counts.owners<owners)return NVM_FILE_FLOW_INVALID;
    if((uint32_t)counts.owners-owners+owner_result>256u ||
       (owner_result && s->declarations->next_identity==
# 628 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                       (18446744073709551615UL)
# 628 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                 ))return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowObligation obligation={0};obligation.kind=NVM_FILE_FLOW_CALL;obligation.site=site;
    obligation.target=function;obligation.parameters=count;obligation.owned_inputs=owners;obligation.borrowed_inputs=borrows;
    obligation.result_count=f->result_count;obligation.result=f->result;
    obligation.checks=NVM_FILE_FLOW_CHECK_CALLEE|NVM_FILE_FLOW_CHECK_RESULT|NVM_FILE_FLOW_CHECK_CLEANUP;
    uint16_t slot;NvmFileFlowStatus status=obligation_slot(s,obligation,&slot);if(status!=NVM_FILE_FLOW_OK)return status;
    uint64_t owner=owner_result?s->declarations->next_identity++:0;
    while(s->stack_count>start)pop(s);
    if(f->result_count)s->stack[s->stack_count++]=initial_value(f->result,
# 636 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc" 3 4
                                                                         1
# 636 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_flow.inc"
                                                                             ,owner);
    commit_obligation(s,obligation,slot);return NVM_FILE_FLOW_OK;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 1
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
typedef struct NvmFileCodePlan NvmFileCodePlan;
typedef struct {
    uint32_t byte_offset;
    DecodedInstruction decoded;
    uint16_t successors[2];
    uint8_t successor_count;
    uint16_t call_references[256u];
    uint32_t catalog_ordinal;
} NvmFileCodeInstruction;
typedef struct {
    uint32_t code_offset, code_length;
    uint16_t instruction_count;
    NvmFileFlowFunction declaration;
} NvmFileCodeFunction;
NvmFileFlowStatus nvm_file_code_prepare(const NvmModule *, NvmFileCodePlan **out);
void nvm_file_code_free(NvmFileCodePlan *);
uint32_t nvm_file_code_function_count(const NvmFileCodePlan *);


# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_function(const NvmFileCodePlan *, uint32_t, NvmFileCodeFunction *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_local(const NvmFileCodePlan *, uint32_t, uint16_t,
                         NvmFileFlowDeclaration *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_instruction(const NvmFileCodePlan *, uint32_t, uint16_t,
                               NvmFileCodeInstruction *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_instruction_order(const NvmFileCodePlan *, uint32_t, uint16_t,
                                     uint16_t *);


# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.h"
    nvm_file_code_function_order(const NvmFileCodePlan *, uint32_t, uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 1


struct NvmFileCodePlan {
    NvmFileFlowDeclarations *declarations;
    uint8_t *code;
    NvmFileCodeInstruction *instructions;
    uint32_t count, code_size, instruction_count;
    size_t storage_bound;
    NvmFileCodeFunction functions[64u];
    uint32_t starts[64u], function_order[64u];
    uint16_t instruction_order[4096u];
    uint64_t calls[64u];
};



static 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
      _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
           file_code_supported_mode(uint8_t op,
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                               _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                    indirect) {
    if(indirect && (op==OP_FUNCREF || isa_is_file_indirect_call(op)))return 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                           1
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                               ;
    if((indirect || 0) && (op==OP_PUSH_STR || op==OP_STR_EQ || op==OP_STR_LEN))return 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                                1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                                    ;
    switch(op) {
    case OP_NOP: case OP_PUSH_I64: case OP_PUSH_BOOL: case OP_PUSH_VOID:
    case OP_DUP: case OP_POP: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL:
    case OP_REGION_BEGIN: case OP_REGION_END: case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:
    case OP_FILE_SERVICE: case OP_FILE_RESULT_BRANCH: case OP_FILE_RESULT_TAKE:
    case OP_FILE_DROP_LOCAL: case OP_FILE_DROP_STACK: case OP_FILE_END_BORROW:
    case OP_CALL: case OP_CALL_REF: case OP_FILE_CALL_REFS: case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE:
    case OP_RET: case OP_ASSERT:
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
    case OP_I64_REM_S: case OP_I64_NEG:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
    case OP_I64_GT_S: case OP_I64_GE_S: case OP_AND: case OP_OR: case OP_NOT:
    case OP_AGG_PACK: case OP_UNION_CONSTRUCT: case OP_AGG_GET: case OP_UNION_FIELD:
    case OP_AGG_TAG: case OP_UNION_TAG:return 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                             1
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                 ;
    default:return 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                  0
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                       ;
    }
}
static 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
      _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
           file_code_supported(uint8_t op) { return file_code_supported_mode(op,
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                0
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                     ); }
static 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
      _Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
           file_code_budget(size_t *bytes,size_t count,size_t width) {
    if(count && width>
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                     (18446744073709551615UL)
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                             /count)return 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                           0
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                ;
    size_t add=count*width;
    if(*bytes>(16u * 1024u * 1024u) || add>(16u * 1024u * 1024u)-*bytes)return 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                      0
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                           ;
    *bytes+=add;return 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                      1
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                          ;
}
static NvmFileFlowStatus file_code_preflight(const NvmModule *m,uint32_t *instructions,
                                             size_t *budget) {
    if(!m || !m->functions || !m->function_count || !m->code || !m->code_size)
        return NVM_FILE_FLOW_INVALID;
    if(m->function_count>64u || m->code_size>65536u)
        return NVM_FILE_FLOW_LIMIT;
    if(m->header.entry_point>=m->function_count)return NVM_FILE_FLOW_INVALID;
    uint32_t total=0,covered=0;size_t locals=0;
    for(uint32_t f=0;f<m->function_count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];
        if(!fn->code_length || fn->code_offset>m->code_size ||
           fn->code_length>m->code_size-fn->code_offset || fn->arity>fn->local_count ||
           fn->name_idx>=m->string_count || fn->result_tag>=TAG_COUNT ||
           (fn->result_count==0)!=(fn->result_tag==TAG_VOID))
            return NVM_FILE_FLOW_INVALID;
        if(fn->local_count>256u)return NVM_FILE_FLOW_LIMIT;
        locals+=fn->local_count;
        for(uint32_t prior=0;prior<f;prior++) {
            const NvmFunctionEntry *p=&m->functions[prior];
            if(fn->code_offset<p->code_offset+p->code_length &&
               p->code_offset<fn->code_offset+fn->code_length)return NVM_FILE_FLOW_INVALID;
        }
        covered+=fn->code_length;uint32_t pc=0,count=0;
        while(pc<fn->code_length) {
            DecodedInstruction decoded={0};
            uint32_t width=isa_decode(m->code+fn->code_offset+pc,fn->code_length-pc,&decoded);
            if(!width)return NVM_FILE_FLOW_INVALID;
            if(++count>256u || ++total>4096u)
                return NVM_FILE_FLOW_LIMIT;
            pc+=width;
        }
    }
    if(covered!=m->code_size)return NVM_FILE_FLOW_UNRESOLVED;
    size_t bytes=0,nominal_bound=0;
    if(!nvm_file_nominal_storage_bound(65536u,&nominal_bound) ||
       !file_code_budget(&bytes,1,sizeof(NvmFileFlowDeclarations)) ||
       !file_code_budget(&bytes,locals,sizeof(NvmFileFlowDeclaration)) ||
       !file_code_budget(&bytes,1,nominal_bound) ||
       !file_code_budget(&bytes,1,sizeof(NvmFileCodePlan)) ||
       !file_code_budget(&bytes,m->code_size,1) ||
       !file_code_budget(&bytes,total,sizeof(NvmFileCodeInstruction)) ||

       !file_code_budget(&bytes,256u,sizeof(uint16_t)+sizeof(
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                         _Bool
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                             )) ||
       !file_code_budget(&bytes,1,sizeof(DecodedInstruction)))return NVM_FILE_FLOW_LIMIT;
    *instructions=total;*budget=bytes;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_code_operands(NvmFileCodePlan *p,uint32_t function,
                                            NvmFileCodeInstruction *in,
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                      _Bool 
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                           indirect,const NvmModule *module) {
    const DecodedInstruction *d=&in->decoded;
    const NvmFileFlowFunction *fn=&p->functions[function].declaration;
    if(!(indirect?file_code_supported_mode(d->opcode,
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                    1
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                        ):file_code_supported(d->opcode)))return NVM_FILE_FLOW_UNRESOLVED;
    switch(d->opcode) {
    case OP_PUSH_STR:
        if(d->operands[0].u32>=module->string_count || !nvm_get_string(module,d->operands[0].u32))return NVM_FILE_FLOW_INVALID;
        return nvm_get_string_len(module,d->operands[0].u32)>1024u*1024u?NVM_FILE_FLOW_LIMIT:NVM_FILE_FLOW_OK;
    case OP_FUNCREF:
        return d->operands[0].u32<p->count?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    case OP_FILE_CALL_INDIRECT_REFS: {
        uint16_t parameters=d->operands[0].u16;uint32_t index=d->operands[2].u32;
        if(parameters>256u || d->operands[1].u16>1)return NVM_FILE_FLOW_INVALID;
        const char *map=nvm_get_string(module,index);
        if(!map || nvm_get_string_len(module,index)!=2u*parameters)return NVM_FILE_FLOW_INVALID;
        
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
       _Bool 
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
            borrowed=
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                     0
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                          ;
        for(uint16_t i=0;i<parameters;i++) {
            uint16_t ref=(uint16_t)(uint8_t)map[2u*i]|((uint16_t)(uint8_t)map[2u*i+1u]<<8);
            if(ref!=
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                   (65535) 
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                            && ref>=256u)return NVM_FILE_FLOW_INVALID;
            borrowed|=ref!=
# 113 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                          (65535)
# 113 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                  ;in->call_references[i]=ref;
        }
        if(!borrowed)return NVM_FILE_FLOW_INVALID;
        break;
    }
    case OP_CALL_INDIRECT:
        if(d->operands[0].u16>256u || d->operands[1].u16>1)
            return NVM_FILE_FLOW_INVALID;
        break;
    case OP_PUSH_BOOL:return d->operands[0].u8<=1?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    case OP_LOAD_LOCAL: case OP_STORE_LOCAL: case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL:
    case OP_FILE_DROP_LOCAL: case OP_FILE_RESULT_BRANCH: case OP_FILE_RESULT_TAKE:
        if(d->operands[0].u16>=fn->locals)return NVM_FILE_FLOW_INVALID;
        if(d->opcode==OP_FILE_RESULT_TAKE && d->operands[1].u8>1)return NVM_FILE_FLOW_INVALID;
        break;
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:
        if(d->operands[0].u16>=256u || d->operands[1].u16>=fn->locals)
            return NVM_FILE_FLOW_INVALID;
        break;
    case OP_FILE_END_BORROW:
        if(d->operands[0].u16>=256u)return NVM_FILE_FLOW_INVALID;
        break;
    case OP_CALL: case OP_CALL_REF: case OP_FILE_CALL_REFS: {
        uint32_t target=d->operands[0].u32;
        if(target>=p->count)return NVM_FILE_FLOW_INVALID;
        NvmFileFlowFunction callee;
        if(!nvm_file_flow_function(p->declarations,target,&callee))return NVM_FILE_FLOW_INVALID;
        const char *map=
# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                       ((void *)0)
# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                           ;
        if(d->opcode==OP_FILE_CALL_REFS) {
            map=nvm_get_string(module,d->operands[1].u32);
            if(!map || nvm_get_string_len(module,d->operands[1].u32)!=2u*callee.parameters)
                return NVM_FILE_FLOW_INVALID;
        }
        uint32_t borrowed=0;
        for(uint16_t i=0;i<callee.parameters;i++) {
            NvmFileFlowDeclaration type;
            if(!nvm_file_flow_declaration(p->declarations,target,i,&type))return NVM_FILE_FLOW_INVALID;
            borrowed+=type.mode!=0;
            uint16_t reference=
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                              (65535)
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                      ;
            if(map)reference=(uint16_t)(uint8_t)map[2u*i]|((uint16_t)(uint8_t)map[2u*i+1u]<<8);
            else if(type.mode && d->opcode==OP_CALL_REF)reference=d->operands[1].u16;
            if(type.mode ? reference>=256u : reference!=
# 154 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                         (65535)
# 154 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                                 )
                return NVM_FILE_FLOW_INVALID;
            in->call_references[i]=reference;
        }
        if(d->opcode==OP_CALL_REF) {
            if(d->operands[1].u16>=256u)return NVM_FILE_FLOW_INVALID;
            if(borrowed!=1)return NVM_FILE_FLOW_UNRESOLVED;
        } else if(d->opcode==OP_FILE_CALL_REFS) {
            if(!borrowed)return NVM_FILE_FLOW_INVALID;
        } else if(borrowed)return NVM_FILE_FLOW_INVALID;
        p->calls[function]|=1UL<<target;
        break;
    }
    case OP_FILE_SERVICE: {
        uint32_t ordinal=5u;
        for(uint32_t i=0;i<5u;i++) {
            uint32_t import;
            if(nvm_file_nominal_import(p->declarations->nominal,i,&import) && import==d->operands[0].u32) {
                ordinal=i;break;
            }
        }
        const NlServicePlanMethod *method=nl_file_catalog_method(ordinal);
        if(!method)return NVM_FILE_FLOW_INVALID;
        uint16_t reference=d->operands[1].u16;
        if(method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE) {
            if(reference>=256u)return NVM_FILE_FLOW_INVALID;
        } else if(reference!=
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                            (65535)
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                    )return NVM_FILE_FLOW_INVALID;
        in->catalog_ordinal=ordinal;break;
    }
    case OP_AGG_PACK: case OP_UNION_CONSTRUCT: {
        uint8_t kind=NVM_V2_LAYOUT_UNION;uint32_t source=d->operands[0].u32;
        uint16_t variant=d->operands[1].u16,count=d->operands[2].u16;
        if(d->opcode==OP_AGG_PACK) {
            uint8_t aggregate=d->operands[0].u8;
            if(aggregate>AGG_TUPLE)return NVM_FILE_FLOW_INVALID;
            if(aggregate==AGG_TUPLE)return NVM_FILE_FLOW_UNRESOLVED;
            kind=aggregate==AGG_RECORD?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION;
            source=d->operands[1].u32;variant=d->operands[2].u16;count=d->operands[3].u16;
        }
        NvmFileNominalLayout layout;
        if(!nvm_file_nominal_source(p->declarations->nominal,kind,source,&layout))return NVM_FILE_FLOW_INVALID;
        if(layout.category!=NVM_FILE_CATEGORY_RECORD && layout.category!=NVM_FILE_CATEGORY_SCALAR_RESULT)
            return NVM_FILE_FLOW_UNRESOLVED;
        const NlServicePlanType *type=nl_file_catalog_type(layout.catalog_ordinal);
        
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
       _Bool 
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
            record=layout.category==NVM_FILE_CATEGORY_RECORD;
        if(!type || (record?variant!=0:variant>=type->member_count) ||
           count!=(record?type->member_count:1))return NVM_FILE_FLOW_INVALID;
        in->catalog_ordinal=layout.catalog_ordinal;break;
    }
    default:break;
    }
    return NVM_FILE_FLOW_OK;
}
static 
# 207 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
      _Bool 
# 207 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
           file_code_index(const NvmFileCodePlan *p,uint32_t f,int64_t pc,uint16_t *out) {
    const NvmFileCodeFunction *fn=&p->functions[f];
    if(pc<0 || pc>=fn->code_length)return 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                         0
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                              ;
    for(uint16_t i=0;i<fn->instruction_count;i++)
        if(p->instructions[p->starts[f]+i].byte_offset==(uint32_t)pc){*out=i;return 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                   1
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                       ;}
    return 
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
          0
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
               ;
}
static NvmFileFlowStatus file_code_cfg(NvmFileCodePlan *p,uint32_t f,
# 214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                    _Bool 
# 214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                         acyclic) {
    NvmFileCodeFunction *fn=&p->functions[f];
    uint16_t indegree[256u]={0};
    
# 217 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
   _Bool 
# 217 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
        selected[256u]={0};
    for(uint16_t i=0;i<fn->instruction_count;i++) {
        NvmFileCodeInstruction *in=&p->instructions[p->starts[f]+i];
        uint8_t op=in->decoded.opcode;
        if(op!=OP_RET && op!=OP_JMP) {
            int64_t next=(int64_t)in->byte_offset+in->decoded.byte_length;
            if(!file_code_index(p,f,next,&in->successors[in->successor_count]))return NVM_FILE_FLOW_INVALID;
            in->successor_count++;
        }
        if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE || op==OP_FILE_RESULT_BRANCH) {
            int32_t displacement=in->decoded.operands[op==OP_FILE_RESULT_BRANCH?1:0].i32;
            int64_t target=(int64_t)in->byte_offset+displacement;
            if(!file_code_index(p,f,target,&in->successors[in->successor_count]))return NVM_FILE_FLOW_INVALID;
            in->successor_count++;
        }
        for(uint8_t e=0;e<in->successor_count;e++)indegree[in->successors[e]]++;
    }
    if(!acyclic)return NVM_FILE_FLOW_OK;
    for(uint16_t rank=0;rank<fn->instruction_count;rank++) {
        uint16_t found=fn->instruction_count;
        for(uint16_t i=0;i<fn->instruction_count;i++)if(!selected[i] && !indegree[i]){found=i;break;}
        if(found==fn->instruction_count)return NVM_FILE_FLOW_UNRESOLVED;
        selected[found]=
# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                       1
# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                           ;p->instruction_order[p->starts[f]+rank]=found;
        const NvmFileCodeInstruction *in=&p->instructions[p->starts[f]+found];
        for(uint8_t e=0;e<in->successor_count;e++)indegree[in->successors[e]]--;
    }
    return NVM_FILE_FLOW_OK;
}
void nvm_file_code_free(NvmFileCodePlan *p) {
    if(p){nvm_file_flow_declarations_free(p->declarations);free(p->instructions);free(p->code);free(p);}
}
static NvmFileFlowStatus file_code_prepare_profile(const NvmModule *m,NvmFileCodePlan **out,
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                           _Bool 
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                                acyclic,
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                                        _Bool 
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                                             indirect) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    uint32_t total;size_t budget;
    NvmFileFlowStatus status=file_code_preflight(m,&total,&budget);
    if(status!=NVM_FILE_FLOW_OK)return status;
    NvmFileFlowDeclarations *declarations=
# 253 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                         ((void *)0)
# 253 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                             ;
    status=file_flow_declarations_mode(m,&declarations,indirect);if(status!=NVM_FILE_FLOW_OK)return status;
    const NvmFileFlowFunction *entry=&declarations->functions[m->header.entry_point];
    if(entry->result.tag==TAG_STRING || !scalar(entry->result.tag) || entry->result.global_index!=0xFFFFFFFFu) {
        nvm_file_flow_declarations_free(declarations);return NVM_FILE_FLOW_UNRESOLVED;
    }
    for(uint16_t i=0;i<entry->parameters;i++) {
        NvmFileFlowDeclaration type=declarations->locals[declarations->offsets[m->header.entry_point]+i];
        if(type.mode || !scalar(type.tag) || type.global_index!=0xFFFFFFFFu) {
            nvm_file_flow_declarations_free(declarations);return NVM_FILE_FLOW_UNRESOLVED;
        }
    }
    NvmFileCodePlan *p=calloc(1,sizeof *p);
    if(!p){nvm_file_flow_declarations_free(declarations);return NVM_FILE_FLOW_MEMORY;}
    p->declarations=declarations;p->count=m->function_count;p->code_size=m->code_size;
    p->instruction_count=total;p->storage_bound=budget;
    p->code=malloc(m->code_size);p->instructions=calloc(total,sizeof *p->instructions);
    if(!p->code || !p->instructions){status=NVM_FILE_FLOW_MEMORY;goto fail;}
    memcpy(p->code,m->code,m->code_size);
    uint32_t cursor=0;
    for(uint32_t f=0;f<p->count;f++) {
        NvmFileCodeFunction *fn=&p->functions[f];
        fn->code_offset=m->functions[f].code_offset;fn->code_length=m->functions[f].code_length;
        fn->declaration=declarations->functions[f];p->starts[f]=cursor;
        uint32_t pc=0;
        while(pc<fn->code_length) {
            NvmFileCodeInstruction *in=&p->instructions[cursor++];in->byte_offset=pc;
            in->catalog_ordinal=0xFFFFFFFFu;
            in->successors[0]=in->successors[1]=
# 281 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                               (65535)
# 281 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                       ;
            uint32_t width=isa_decode(p->code+fn->code_offset+pc,fn->code_length-pc,&in->decoded);
            if(!width){status=NVM_FILE_FLOW_INVALID;goto fail;}
            status=file_code_operands(p,f,in,indirect,m);if(status!=NVM_FILE_FLOW_OK)goto fail;
            pc+=width;fn->instruction_count++;
        }
        status=file_code_cfg(p,f,acyclic);if(status!=NVM_FILE_FLOW_OK)goto fail;
    }
    uint64_t done=0;
    for(uint32_t rank=0;rank<p->count;rank++) {
        uint32_t found=p->count;
        for(uint32_t f=0;f<p->count;f++)if(!(done&(1UL<<f)) && !(p->calls[f]&~done)){found=f;break;}
        if(found==p->count){status=NVM_FILE_FLOW_UNRESOLVED;goto fail;}
        p->function_order[rank]=found;done|=1UL<<found;
    }
    *out=p;return NVM_FILE_FLOW_OK;
fail:
    nvm_file_code_free(p);return status;
}
static NvmFileFlowStatus file_code_prepare_mode(const NvmModule *m,NvmFileCodePlan **out,
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                        _Bool 
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                             acyclic) {
    return file_code_prepare_profile(m,out,acyclic,
# 301 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                  0
# 301 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                       );
}


NvmFileFlowStatus nvm_file_code_prepare(const NvmModule *m,NvmFileCodePlan **out) {
    return file_code_prepare_mode(m,out,
# 306 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                       1
# 306 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                           );
}
uint32_t nvm_file_code_function_count(const NvmFileCodePlan *p){return p?p->count:0;}

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
    nvm_file_code_function(const NvmFileCodePlan *p,uint32_t f,NvmFileCodeFunction *out) {
    if(!p || !out || f>=p->count)return 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                       0
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                            ;
    *out=p->functions[f];return 
# 311 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                               1
# 311 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                   ;
}

# 313 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
_Bool 
# 313 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
    nvm_file_code_local(const NvmFileCodePlan *p,uint32_t f,uint16_t local,NvmFileFlowDeclaration *out) {
    return p && nvm_file_flow_declaration(p->declarations,f,local,out);
}

# 316 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
_Bool 
# 316 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
    nvm_file_code_instruction(const NvmFileCodePlan *p,uint32_t f,uint16_t i,NvmFileCodeInstruction *out) {
    if(!p || !out || f>=p->count || i>=p->functions[f].instruction_count)return 
# 317 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                               0
# 317 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                    ;
    *out=p->instructions[p->starts[f]+i];return 
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                               1
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                   ;
}

# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
_Bool 
# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
    nvm_file_code_instruction_order(const NvmFileCodePlan *p,uint32_t f,uint16_t rank,uint16_t *out) {
    if(!p || !out || f>=p->count || rank>=p->functions[f].instruction_count)return 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                                                  0
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                                                       ;
    *out=p->instruction_order[p->starts[f]+rank];return 
# 322 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                                       1
# 322 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                                           ;
}

# 324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
_Bool 
# 324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
    nvm_file_code_function_order(const NvmFileCodePlan *p,uint32_t rank,uint32_t *out) {
    if(!p || !out || rank>=p->count)return 
# 325 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                          0
# 325 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                               ;
    *out=p->function_order[rank];return 
# 326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc" 3 4
                                       1
# 326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_code.inc"
                                           ;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_code.inc" 2
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 1







typedef struct NvmFileBodyReport NvmFileBodyReport;
typedef enum {
    NVM_FILE_BODY_CLEANUP_NORMAL, NVM_FILE_BODY_CLEANUP_DROP_LOCAL,
    NVM_FILE_BODY_CLEANUP_DROP_STACK, NVM_FILE_BODY_CLEANUP_ASSERT,
    NVM_FILE_BODY_CLEANUP_RETURN, NVM_FILE_BODY_CLEANUP_CALL,
    NVM_FILE_BODY_CLEANUP_SERVICE
} NvmFileBodyCleanup;
typedef struct {
    
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
        reachable, exit_checked, refinement, has_obligation;
    uint16_t input_stack, output_stack, cleanup_local;
    NvmFileBodyCleanup cleanup;
    uint32_t discharged_checks, pending_checks;
    NvmFileFlowObligation obligation;
} NvmFileBodyInstruction;
NvmFileFlowStatus nvm_file_body_analyze(const NvmModule *, NvmFileBodyReport **out);
void nvm_file_body_free(NvmFileBodyReport *);
uint32_t nvm_file_body_function_count(const NvmFileBodyReport *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_function(const NvmFileBodyReport *, uint32_t, NvmFileCodeFunction *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_local(const NvmFileBodyReport *, uint32_t, uint16_t, NvmFileFlowDeclaration *);

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.h"
    nvm_file_body_instruction(const NvmFileBodyReport *, uint32_t, uint16_t,
                              NvmFileCodeInstruction *, NvmFileBodyInstruction *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 1


struct NvmFileBodyReport {
    NvmFileCodePlan *plan;
    NvmFileBodyInstruction *facts;
    
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
   _Bool 
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
        checked[64u];
};
typedef struct {
    size_t bytes;
    NvmFileFlowState *incoming[256u];
    NvmFileFlowState *working, *edges[2];
} FileBodyWorkspace;
static void file_body_release(FileBodyWorkspace *w,NvmFileFlowState **s) {
    if(*s){nvm_file_flow_state_free(*s);*s=
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                     ((void *)0)
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                         ;w->bytes-=sizeof(NvmFileFlowState);}
}
static 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
      _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
           file_body_room(const FileBodyWorkspace *w,size_t count) {
    size_t bytes=w->bytes;return file_code_budget(&bytes,count,sizeof(NvmFileFlowState));
}
static NvmFileFlowStatus file_body_clone(FileBodyWorkspace *w,const NvmFileFlowState *s,
                                         NvmFileFlowState **out) {
    if(!file_body_room(w,1))return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowStatus status=nvm_file_flow_clone(s,out);
    if(status==NVM_FILE_FLOW_OK)w->bytes+=sizeof(NvmFileFlowState);
    return status;
}
static NvmFileFlowStatus file_body_scalar(NvmFileFlowState *s,uint8_t input,uint8_t output,
                                          uint16_t count,
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                        _Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                             equality) {
    if(s->stack_count<count)return NVM_FILE_FLOW_INVALID;
    for(uint16_t i=0;i<count;i++) {
        NvmFileFlowValue v=s->stack[s->stack_count-count+i];
        if(!v.initialized || v.owner || !same(v.type,scalar_type(v.type.tag)))return NVM_FILE_FLOW_INVALID;
        if(equality) {
            if(v.type.tag!=TAG_INT && v.type.tag!=TAG_BOOL)return NVM_FILE_FLOW_UNRESOLVED;
            if(i && v.type.tag!=s->stack[s->stack_count-count].type.tag)return NVM_FILE_FLOW_UNRESOLVED;
        } else if(v.type.tag!=input)return NVM_FILE_FLOW_INVALID;
    }
    for(uint16_t i=0;i<count;i++)pop(s);
    if(output!=TAG_COUNT)s->stack[s->stack_count++]=initial_value(scalar_type(output),
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                                     1
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                         ,0);
    return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_body_projection(NvmFileFlowState *s,uint16_t field,
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                                _Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                     tag,
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                                         _Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                              record) {
    if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
    NvmFileFlowValue v=s->stack[s->stack_count-1];
    if(!v.initialized || v.owner || v.type.mode)return NVM_FILE_FLOW_INVALID;
    if(record && !tag && v.type.category==NVM_FILE_CATEGORY_RECORD)return nvm_file_flow_field(s,field);
    if(v.type.category!=NVM_FILE_CATEGORY_SCALAR_RESULT)return NVM_FILE_FLOW_UNRESOLVED;
    NvmFileFlowDeclaration result=scalar_type(TAG_INT);
    if(!tag) {
        if(field)return NVM_FILE_FLOW_INVALID;
        if(v.arm!=NVM_FILE_FLOW_ARM_OK && v.arm!=NVM_FILE_FLOW_ARM_ERROR)return NVM_FILE_FLOW_UNRESOLVED;
        const NlServicePlanType *type=nl_file_catalog_type(v.type.catalog_ordinal);
        if(!type || type->member_count!=2 ||
           !member_type(s,v.type.catalog_ordinal,type->members[v.arm==NVM_FILE_FLOW_ARM_ERROR].type_id,&result) || owned(result))
            return NVM_FILE_FLOW_INVALID;
    }
    s->stack[s->stack_count-1]=initial_value(result,
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                   1
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                       ,0);return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_body_transfer(NvmFileBodyReport *r,NvmFileFlowState *s,
                                            const NvmFileCodeInstruction *in,NvmFileBodyInstruction *fact) {
    const DecodedInstruction *d=&in->decoded;uint16_t local=d->operands[0].u16;
    NvmFileFlowStatus status;
    switch(d->opcode) {
    case OP_NOP: case OP_JMP: case OP_FILE_RESULT_BRANCH:return NVM_FILE_FLOW_OK;
    case OP_PUSH_STR:return nvm_file_flow_push_scalar(s,TAG_STRING);
    case OP_STR_EQ:return file_body_scalar(s,TAG_STRING,TAG_BOOL,2,
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                  0
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                       );
    case OP_STR_LEN:return file_body_scalar(s,TAG_STRING,TAG_INT,1,
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                  0
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                       );
    case OP_PUSH_I64:return nvm_file_flow_push_scalar(s,TAG_INT);
    case OP_PUSH_BOOL:return nvm_file_flow_push_scalar(s,TAG_BOOL);
    case OP_PUSH_VOID:return nvm_file_flow_push_scalar(s,TAG_VOID);
    case OP_DUP:return nvm_file_flow_dup(s);
    case OP_POP:return nvm_file_flow_pop(s);
    case OP_LOAD_LOCAL:return nvm_file_flow_load(s,local);
    case OP_STORE_LOCAL:return nvm_file_flow_store(s,local);
    case OP_OWN_MOVE_LOCAL:return nvm_file_flow_take(s,local);
    case OP_OWN_STORE_LOCAL:return nvm_file_flow_put(s,local);
    case OP_REGION_BEGIN:return nvm_file_flow_region_begin(s);
    case OP_REGION_END:return nvm_file_flow_region_end(s);
    case OP_BORROW_LOCAL_SHARED:return nvm_file_flow_borrow_shared(s,d->operands[1].u16,local);
    case OP_BORROW_LOCAL_EXCLUSIVE:return nvm_file_flow_borrow(s,d->operands[1].u16,local);
    case OP_FILE_END_BORROW:return nvm_file_flow_end_borrow(s,local);
    case OP_FILE_RESULT_TAKE:return nvm_file_flow_take_result(s,local,
        d->operands[1].u8?NVM_FILE_FLOW_ARM_ERROR:NVM_FILE_FLOW_ARM_OK);
    case OP_FILE_DROP_LOCAL:
        fact->cleanup=NVM_FILE_BODY_CLEANUP_DROP_LOCAL;fact->cleanup_local=local;
        return nvm_file_flow_drop_local(s,local);
    case OP_FILE_DROP_STACK:
        fact->cleanup=NVM_FILE_BODY_CLEANUP_DROP_STACK;return nvm_file_flow_drop_stack(s);
    case OP_RET:
        status=nvm_file_flow_can_exit(s);fact->exit_checked=status==NVM_FILE_FLOW_OK;
        fact->cleanup=NVM_FILE_BODY_CLEANUP_RETURN;return status;
    case OP_ASSERT:
        fact->cleanup=NVM_FILE_BODY_CLEANUP_ASSERT;
        return file_body_scalar(s,TAG_BOOL,TAG_COUNT,1,
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                      0
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                           );
    case OP_JMP_TRUE: case OP_JMP_FALSE:return file_body_scalar(s,TAG_BOOL,TAG_COUNT,1,
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                                      0
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                           );
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S: case OP_I64_REM_S:
        return file_body_scalar(s,TAG_INT,TAG_INT,2,
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                   0
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                        );
    case OP_NEG: case OP_I64_NEG:return file_body_scalar(s,TAG_INT,TAG_INT,1,
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                            0
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                 );
    case OP_EQ: case OP_NE:return file_body_scalar(s,TAG_INT,TAG_BOOL,2,
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                       1
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                           );
    case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
    case OP_I64_GT_S: case OP_I64_GE_S:return file_body_scalar(s,TAG_INT,TAG_BOOL,2,
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                                   0
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                        );
    case OP_AND: case OP_OR:return file_body_scalar(s,TAG_BOOL,TAG_BOOL,2,
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                         0
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                              );
    case OP_NOT:return file_body_scalar(s,TAG_BOOL,TAG_BOOL,1,
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                             0
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                  );
    case OP_AGG_PACK: case OP_UNION_CONSTRUCT:return nvm_file_flow_construct(s,in->catalog_ordinal,
        d->operands[d->opcode==OP_AGG_PACK?2:1].u16);
    case OP_AGG_GET: case OP_UNION_FIELD:
        return file_body_projection(s,local,
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                           0
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                ,d->opcode==OP_AGG_GET);
    case OP_AGG_TAG: case OP_UNION_TAG:return file_body_projection(s,0,
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                      1
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                          ,
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                           0
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                );
    case OP_FILE_SERVICE:
        fact->cleanup=NVM_FILE_BODY_CLEANUP_SERVICE;
        status=nvm_file_flow_service(s,in->byte_offset,d->operands[0].u32,d->operands[1].u16);break;
    case OP_CALL: case OP_CALL_REF:case OP_FILE_CALL_REFS: {
        uint32_t target=d->operands[0].u32;
        if(target>=r->plan->count || !r->checked[target])return NVM_FILE_FLOW_UNRESOLVED;
        const NvmFileFlowFunction *callee=&r->plan->functions[target].declaration;
        uint16_t references[256u];
        for(uint16_t i=0;i<callee->parameters;i++) {
            NvmFileFlowDeclaration type=s->declarations->locals[s->declarations->offsets[target]+i];
            references[i]=type.mode?in->call_references[i]:
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                          (65535)
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                                  ;
        }
        fact->cleanup=NVM_FILE_BODY_CLEANUP_CALL;
        status=nvm_file_flow_call(s,in->byte_offset,target,references,callee->parameters);
        if(status==NVM_FILE_FLOW_OK)fact->discharged_checks=NVM_FILE_FLOW_CHECK_CALLEE;
        break;
    }
    default:return NVM_FILE_FLOW_UNRESOLVED;
    }
    if(status!=NVM_FILE_FLOW_OK)return status;
    for(uint16_t i=0;i<s->obligation_count;i++)if(s->obligations[i].site==in->byte_offset) {
        fact->has_obligation=
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                            1
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                ;fact->obligation=s->obligations[i];
        fact->pending_checks|=fact->obligation.checks & ~fact->discharged_checks;
        return NVM_FILE_FLOW_OK;
    }
    return NVM_FILE_FLOW_INVALID;
}
static NvmFileFlowStatus file_body_function(NvmFileBodyReport *r,uint32_t f,FileBodyWorkspace *w) {
    NvmFileCodePlan *p=r->plan;
    if(!file_body_room(w,1))return NVM_FILE_FLOW_LIMIT;
    NvmFileFlowStatus status=nvm_file_flow_state(p->declarations,f,&w->incoming[0]);
    if(status!=NVM_FILE_FLOW_OK)return status;
    w->bytes+=sizeof(NvmFileFlowState);
    
# 143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
   _Bool 
# 143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
        returned=
# 143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                 0
# 143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                      ;
    for(uint16_t rank=0;rank<p->functions[f].instruction_count;rank++) {
        uint16_t index=p->instruction_order[p->starts[f]+rank];
        w->working=w->incoming[index];w->incoming[index]=
# 146 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                        ((void *)0)
# 146 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                            ;
        if(!w->working)continue;
        NvmFileCodeInstruction *in=&p->instructions[p->starts[f]+index];
        NvmFileBodyInstruction *fact=&r->facts[p->starts[f]+index];
        fact->reachable=
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                       1
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                           ;fact->input_stack=w->working->stack_count;
        fact->cleanup_local=
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                           (65535)
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                   ;
        fact->pending_checks=NVM_FILE_FLOW_CHECK_CLEANUP;
        status=file_body_transfer(r,w->working,in,fact);
        if(status!=NVM_FILE_FLOW_OK)return status;
        fact->output_stack=w->working->stack_count;returned|=fact->exit_checked;
        if(in->decoded.opcode==OP_FILE_RESULT_BRANCH) {
            if(!file_body_room(w,2))return NVM_FILE_FLOW_LIMIT;
            status=nvm_file_flow_refine(w->working,in->decoded.operands[0].u16,&w->edges[0],&w->edges[1]);
            if(status!=NVM_FILE_FLOW_OK)return status;
            w->bytes+=2*sizeof(NvmFileFlowState);fact->refinement=
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                 1
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                     ;
        } else if(in->successor_count) {
            status=file_body_clone(w,w->working,&w->edges[0]);
            if(status!=NVM_FILE_FLOW_OK)return status;
            if(in->successor_count==2) {
                status=file_body_clone(w,w->working,&w->edges[1]);
                if(status!=NVM_FILE_FLOW_OK)return status;
            }
        }
        file_body_release(w,&w->working);
        for(uint8_t edge=0;edge<in->successor_count;edge++) {
            if(!w->edges[edge]->reachable){file_body_release(w,&w->edges[edge]);continue;}
            NvmFileFlowState **destination=&w->incoming[in->successors[edge]];
            if(!*destination){*destination=w->edges[edge];w->edges[edge]=
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                                        ((void *)0)
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                                            ;}
            else {
                
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
               _Bool 
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                    changed=
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                            0
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                 ;status=nvm_file_flow_join(*destination,w->edges[edge],&changed);
                if(status!=NVM_FILE_FLOW_OK)return status;
                file_body_release(w,&w->edges[edge]);
            }
        }
    }
    if(!returned)return NVM_FILE_FLOW_INVALID;
    r->checked[f]=
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                 1
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                     ;return NVM_FILE_FLOW_OK;
}
void nvm_file_body_free(NvmFileBodyReport *r) {
    if(r){nvm_file_code_free(r->plan);free(r->facts);free(r);}
}
NvmFileFlowStatus nvm_file_body_analyze(const NvmModule *module,NvmFileBodyReport **out) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    NvmFileCodePlan *p=
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                      ((void *)0)
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                          ;NvmFileFlowStatus status=nvm_file_code_prepare(module,&p);
    if(status!=NVM_FILE_FLOW_OK)return status;
    size_t bytes=p->storage_bound;
    if(!file_code_budget(&bytes,1,sizeof(NvmFileBodyReport)) ||
       !file_code_budget(&bytes,p->instruction_count,sizeof(NvmFileBodyInstruction)) ||
       !file_code_budget(&bytes,1,sizeof(FileBodyWorkspace)) ||
       !file_code_budget(&bytes,256u,sizeof(uint16_t))) {
        nvm_file_code_free(p);return NVM_FILE_FLOW_LIMIT;
    }
    NvmFileBodyReport *r=calloc(1,sizeof *r);
    if(!r){nvm_file_code_free(p);return NVM_FILE_FLOW_MEMORY;}
    r->plan=p;r->facts=calloc(p->instruction_count,sizeof *r->facts);
    if(!r->facts){nvm_file_body_free(r);return NVM_FILE_FLOW_MEMORY;}
    FileBodyWorkspace w={0};w.bytes=bytes;
    for(uint32_t rank=0;rank<p->count;rank++) {
        status=file_body_function(r,p->function_order[rank],&w);
        if(status!=NVM_FILE_FLOW_OK)break;
    }
    file_body_release(&w,&w.working);
    for(uint16_t i=0;i<256u;i++)file_body_release(&w,&w.incoming[i]);
    for(uint8_t i=0;i<2;i++)file_body_release(&w,&w.edges[i]);
    if(status!=NVM_FILE_FLOW_OK){nvm_file_body_free(r);return status;}
    *out=r;return NVM_FILE_FLOW_OK;
}
uint32_t nvm_file_body_function_count(const NvmFileBodyReport *r) {
    return r?nvm_file_code_function_count(r->plan):0;
}

# 216 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
_Bool 
# 216 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
    nvm_file_body_function(const NvmFileBodyReport *r,uint32_t f,NvmFileCodeFunction *out) {
    return r && nvm_file_code_function(r->plan,f,out);
}

# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
_Bool 
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
    nvm_file_body_local(const NvmFileBodyReport *r,uint32_t f,uint16_t local,NvmFileFlowDeclaration *out) {
    return r && nvm_file_code_local(r->plan,f,local,out);
}

# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
_Bool 
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
    nvm_file_body_instruction(const NvmFileBodyReport *r,uint32_t f,uint16_t i,
                              NvmFileCodeInstruction *instruction,NvmFileBodyInstruction *fact) {
    if(!r || !instruction || !fact || f>=r->plan->count ||
       i>=r->plan->functions[f].instruction_count)return 
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                                        0
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                             ;
    *instruction=r->plan->instructions[r->plan->starts[f]+i];
    *fact=r->facts[r->plan->starts[f]+i];return 
# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc" 3 4
                                               1
# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_body.inc"
                                                   ;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_body.inc" 2
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 1





typedef struct NvmFileHostedPlan NvmFileHostedPlan;
typedef struct {
    uint32_t entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t allocation_bound;
} NvmFileHostedStartup;
typedef struct {
    NvmFileCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
} NvmFileHostedFunction;






NvmFileFlowStatus nvm_file_hosted_prepare(const uint8_t *,size_t,NvmFileHostedPlan **);
void nvm_file_hosted_free(NvmFileHostedPlan *);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_startup(const NvmFileHostedPlan *,NvmFileHostedStartup *);

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_function(const NvmFileHostedPlan *,uint32_t,NvmFileHostedFunction *);

# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_local(const NvmFileHostedPlan *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_instruction(const NvmFileHostedPlan *,uint32_t,uint16_t,
                                NvmFileCodeInstruction *,NvmFileBodyInstruction *);


# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_type(const NvmFileHostedPlan *,uint32_t,NvmFileNominalLayout *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.h"
    nvm_file_hosted_import(const NvmFileHostedPlan *,uint32_t,uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 1




struct NvmFileHostedPlan {
    NvmFileBodyReport *body;
    NvmFileHostedStartup startup;
    NvmFileHostedFunction functions[64u];
};
typedef struct {
    uint32_t counts[NVM_V2_SECTION_SERVICE_BINDINGS+1];
    size_t section_bytes[NVM_V2_SECTION_SERVICE_BINDINGS+1];
    size_t decoded, fields, strings;
    uint16_t maximum_params;
} FileHostedCounts;
static 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
      _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
           file_hosted_add(size_t *total,size_t count,size_t width) {
    if(count && width>
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                     (18446744073709551615UL)
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                             /count)return 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                           0
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                                ;
    size_t add=count*width;
    if(*total>(64u*1024u*1024u) || add>(64u*1024u*1024u)-*total)return 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                                                                          0
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                                                                               ;
    *total+=add;return 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                      1
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                          ;
}
static 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
      _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
           file_hosted_take(NvmV2Cursor *c,size_t count) {
    const uint8_t *ignored;return nvm_v2_take(c,count,&ignored)==NVM_V2_OK;
}
static 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
      _Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
           file_hosted_array(size_t *total,size_t count,size_t initial,size_t width) {
    size_t capacity=initial;
    while(capacity<count){if(capacity>
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                     (18446744073709551615UL)
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                             /2)return 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                                       0
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                                            ;capacity*=2;}

    return file_hosted_add(total,capacity,width) && file_hosted_add(total,capacity,width);
}
static NvmFileFlowStatus file_hosted_section(const uint8_t *data,NvmV2SectionEntry e,FileHostedCounts *a) {
    a->section_bytes[e.type]=(size_t)e.size;
    if(e.type==NVM_V2_SECTION_CODE)
        return e.size && e.size<=65536u?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_LIMIT;
    if(e.type==NVM_V2_SECTION_OWNERSHIP)return e.size?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    if(e.type==NVM_V2_SECTION_SERVICE_BINDINGS) {
        NvmFileNominalBindings bindings;
        return nvm_file_nominal_decode(data+e.offset,(size_t)e.size,&bindings)==NVM_SERVICE_OK?
            NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    }
    if(e.type==NVM_V2_SECTION_PASSIVE)return NVM_FILE_FLOW_UNRESOLVED;
    NvmV2Cursor c;nvm_v2_cursor_init(&c,data+e.offset,(size_t)e.size);uint32_t count;
    if(nvm_v2_u32(&c,&count)!=NVM_V2_OK)return NVM_FILE_FLOW_INVALID;
    a->counts[e.type]=count;
    size_t wire=0,width=0;
    switch(e.type) {
    case NVM_V2_SECTION_GLOBALS:case NVM_V2_SECTION_LINKS:case NVM_V2_SECTION_CALLBACKS:
        if(count)return NVM_FILE_FLOW_UNRESOLVED;
        break;
    case NVM_V2_SECTION_FUNCTIONS:
        if(!count || count>64u)return NVM_FILE_FLOW_LIMIT;
        wire=32;width=sizeof(NvmV2Function);break;
    case NVM_V2_SECTION_IMPORTS:
        if(!((count)==5u))return NVM_FILE_FLOW_INVALID;
        wire=16;width=sizeof(NvmV2Import);break;
    case NVM_V2_SECTION_METADATA:wire=8;width=sizeof(NvmV2MetadataEntry);break;
    case NVM_V2_SECTION_DEBUG:wire=16;width=sizeof(NvmV2DebugEntry);break;
    case NVM_V2_SECTION_CONSTANTS:
        if(count>(c.size-c.pos)/8)return NVM_FILE_FLOW_INVALID;
        width=sizeof(NvmV2Constant);
        for(uint32_t i=0;i<count;i++) {
            uint8_t tag,pad;uint16_t pad2;uint32_t length;
            if(nvm_v2_u8(&c,&tag)!=NVM_V2_OK || nvm_v2_u8(&c,&pad)!=NVM_V2_OK ||
               nvm_v2_u16(&c,&pad2)!=NVM_V2_OK || nvm_v2_u32(&c,&length)!=NVM_V2_OK ||
               pad || pad2 || tag!=TAG_STRING || !file_hosted_take(&c,length) ||
               nvm_v2_align4(&c)!=NVM_V2_OK)return NVM_FILE_FLOW_INVALID;
            if(!file_hosted_add(&a->strings,(size_t)length+1,1))return NVM_FILE_FLOW_LIMIT;
        }
        break;
    case NVM_V2_SECTION_SIGNATURES:
        if(count>(c.size-c.pos)/4)return NVM_FILE_FLOW_INVALID;
        width=sizeof(NvmV2Signature);
        for(uint32_t i=0;i<count;i++) {
            uint16_t params,results;
            if(nvm_v2_u16(&c,&params)!=NVM_V2_OK || nvm_v2_u16(&c,&results)!=NVM_V2_OK ||
               !file_hosted_take(&c,params) || nvm_v2_align4(&c)!=NVM_V2_OK ||
               !file_hosted_take(&c,results) || nvm_v2_align4(&c)!=NVM_V2_OK)return NVM_FILE_FLOW_INVALID;
            if(params>a->maximum_params)a->maximum_params=params;
        }
        break;
    case NVM_V2_SECTION_LAYOUTS:
        if(count<8u || count>65536u)return NVM_FILE_FLOW_LIMIT;
        if(count>(c.size-c.pos)/8)return NVM_FILE_FLOW_INVALID;
        width=sizeof(NvmV2Layout);
        for(uint32_t i=0;i<count;i++) {
            uint8_t kind,pad;uint16_t fields;uint32_t ignored;
            if(nvm_v2_u8(&c,&kind)!=NVM_V2_OK || nvm_v2_u8(&c,&pad)!=NVM_V2_OK ||
               nvm_v2_u16(&c,&fields)!=NVM_V2_OK || nvm_v2_u32(&c,&ignored)!=NVM_V2_OK ||
               pad || kind>NVM_V2_LAYOUT_ENUM || fields>(c.size-c.pos)/12)return NVM_FILE_FLOW_INVALID;
            if(!file_hosted_add(&a->fields,fields,sizeof(NvmV2LayoutField)))return NVM_FILE_FLOW_LIMIT;
            for(uint32_t j=0;j<fields;j++) {
                uint32_t nested;
                if(!file_hosted_take(&c,4) || nvm_v2_u32(&c,&nested)!=NVM_V2_OK ||
                   !file_hosted_take(&c,4) || (nested!=0xFFFFFFFFu && nested>=i))return NVM_FILE_FLOW_INVALID;
            }
        }
        break;
    default:return NVM_FILE_FLOW_INVALID;
    }
    if(wire && (count>(c.size-c.pos)/wire || !file_hosted_take(&c,(size_t)count*wire)))return NVM_FILE_FLOW_INVALID;
    if(!nvm_v2_cursor_exhausted(&c))return NVM_FILE_FLOW_INVALID;
    if(!file_hosted_add(&a->decoded,count,width))return NVM_FILE_FLOW_LIMIT;
    return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_hosted_preflight(const uint8_t *data,size_t size,NvmV2Header *header,size_t *bound) {
    if(!data)return NVM_FILE_FLOW_INVALID;
    if(size>(16u*1024u*1024u))return NVM_FILE_FLOW_LIMIT;
    if(nvm_v2_validate(data,size)!=NVM_V2_OK || nvm_v2_read_header(data,size,header)!=NVM_V2_OK ||
       header->total_size!=size || header->isa_version!=2)return NVM_FILE_FLOW_INVALID;
    uint32_t required=(1u << 1)|(1u << 7)|
                      (1u << 8)|(1u << 9);
    if((header->feature_bits & required)!=required)return NVM_FILE_FLOW_INVALID;
    if(header->feature_bits & ~(required|(1u << 3)))return NVM_FILE_FLOW_UNRESOLVED;
    FileHostedCounts a={0};
    for(uint32_t i=0;i<header->section_count;i++) {
        NvmV2SectionEntry e;
        if(nvm_v2_read_section(data,size,header,i,&e)!=NVM_V2_OK)return NVM_FILE_FLOW_INVALID;
        NvmFileFlowStatus status=file_hosted_section(data,e,&a);if(status!=NVM_FILE_FLOW_OK)return status;
    }
    uint32_t constants=a.counts[NVM_V2_SECTION_CONSTANTS],functions=a.counts[NVM_V2_SECTION_FUNCTIONS];
    uint32_t layouts=a.counts[NVM_V2_SECTION_LAYOUTS];
    size_t layout=a.section_bytes[NVM_V2_SECTION_LAYOUTS],nominal=0,total=0;
    if(!functions || header->entry_point>=functions || !a.section_bytes[NVM_V2_SECTION_SERVICE_BINDINGS] ||
       !a.section_bytes[NVM_V2_SECTION_OWNERSHIP] || !a.section_bytes[NVM_V2_SECTION_CODE])return NVM_FILE_FLOW_INVALID;
    if(!nvm_file_nominal_storage_bound(layouts,&nominal))return NVM_FILE_FLOW_LIMIT;





    if(!file_hosted_add(&total,size,1) || !file_hosted_add(&total,a.decoded,1) ||
       !file_hosted_add(&total,a.fields,2) || !file_hosted_add(&total,layouts,sizeof(NvmV2Layout)) ||
       !file_hosted_add(&total,1,(16u * 1024u * 1024u)) || !file_hosted_add(&total,1,sizeof(NvmFileHostedPlan)) ||
       !file_hosted_add(&total,2,sizeof(NvmModule)) || !file_hosted_add(&total,1,sizeof(NvmV2Module)) ||
       !file_hosted_add(&total,1,sizeof(FileHostedCounts)) ||
       !file_hosted_array(&total,constants,64,sizeof(char *)+sizeof(uint32_t)) ||
       !file_hosted_array(&total,functions,32,sizeof(NvmFunctionEntry)+sizeof(uint8_t *)) ||
       !file_hosted_array(&total,a.section_bytes[NVM_V2_SECTION_CODE],4096,1) ||
       !file_hosted_array(&total,a.counts[NVM_V2_SECTION_DEBUG],256,sizeof(NvmDebugEntry)) ||
       !file_hosted_array(&total,a.counts[NVM_V2_SECTION_METADATA],8,sizeof(NvmMetadataEntry)) ||
       !file_hosted_array(&total,a.counts[NVM_V2_SECTION_IMPORTS],32,sizeof(NvmImportEntry)+sizeof(uint8_t *)) ||
       !file_hosted_add(&total,16,sizeof(NvmModuleRefEntry)) ||
       !file_hosted_add(&total,a.strings,1) ||
       !file_hosted_add(&total,(size_t)functions+a.counts[NVM_V2_SECTION_IMPORTS],a.maximum_params) ||
       !file_hosted_add(&total,layout,2) ||
       !file_hosted_add(&total,a.section_bytes[NVM_V2_SECTION_OWNERSHIP],1) ||
       !file_hosted_add(&total,120u,1) ||
       !file_hosted_add(&total,constants,sizeof(char *)+sizeof(uint32_t)) ||
       !file_hosted_add(&total,functions,sizeof(NvmFunctionEntry)+sizeof(uint8_t *)) ||
       !file_hosted_add(&total,nominal,1))return NVM_FILE_FLOW_LIMIT;
    *bound=total;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_hosted_codec_status(NvmV2Result r) {



    (void)r;return NVM_FILE_FLOW_UNRESOLVED;
}
static NvmFileFlowStatus file_hosted_start(NvmFileHostedPlan *p,const NvmV2Module *wire,const NvmModule *m) {
    NvmFileCodePlan *code=p->body->plan;
    p->startup.entry=wire->entry_point;p->startup.initializer=0xFFFFFFFFu;p->startup.functions=code->count;
    if(!(m->header.flags & (1 << 0)) || m->header.entry_point!=wire->entry_point)return NVM_FILE_FLOW_INVALID;
    const NvmFileFlowFunction *entry=&code->functions[p->startup.entry].declaration;
    if(entry->parameters || entry->result_count!=1 || entry->result.mode ||
       entry->result.global_index!=0xFFFFFFFFu ||
       (entry->result.tag!=TAG_INT && entry->result.tag!=TAG_BOOL))return NVM_FILE_FLOW_UNRESOLVED;
    for(uint32_t f=0;f<code->count;f++) {
        uint32_t index=m->functions[f].name_idx;
        if(index>=m->string_count || !m->strings[index] || memchr(m->strings[index],0,m->string_lengths[index]))return NVM_FILE_FLOW_INVALID;
        if(p->startup.initializer==0xFFFFFFFFu && !strcmp(m->strings[index],"__init__")) {
            const NvmFileFlowFunction *init=&code->functions[f].declaration;
            if(init->parameters || init->result_count || init->result.tag!=TAG_VOID ||
               init->result.mode || init->result.global_index!=0xFFFFFFFFu)return NVM_FILE_FLOW_UNRESOLVED;
            p->startup.initializer=f;
        }
    }
    return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_hosted_bounds(NvmFileHostedPlan *p,const NvmV2Module *wire) {
    NvmFileCodePlan *code=p->body->plan;
    for(uint32_t rank=0;rank<code->count;rank++) {
        uint32_t f=code->function_order[rank];NvmFileHostedFunction *fact=&p->functions[f];
        fact->code=code->functions[f];
        fact->declared_stack=wire->functions.items[f].max_stack;
        fact->locals=code->functions[f].declaration.locals;fact->staging_slots=1;fact->frames=1;
        for(uint16_t i=0;i<code->functions[f].instruction_count;i++) {
            const NvmFileBodyInstruction *body=&p->body->facts[code->starts[f]+i];
            if(!body->reachable)continue;
            if(body->input_stack>fact->operand_peak)fact->operand_peak=body->input_stack;
            if(body->output_stack>fact->operand_peak)fact->operand_peak=body->output_stack;
            if(body->has_obligation && body->obligation.kind==NVM_FILE_FLOW_CALL &&
               (uint32_t)body->obligation.parameters+1>fact->staging_slots)
                fact->staging_slots=(uint16_t)(body->obligation.parameters+1);
        }
        if(fact->declared_stack && fact->declared_stack<fact->operand_peak)return NVM_FILE_FLOW_INVALID;
        uint64_t frame=(uint64_t)fact->locals+fact->operand_peak+fact->staging_slots;
        fact->vm_value_slots=fact->native_value_slots=frame;
        for(uint16_t i=0;i<code->functions[f].instruction_count;i++) {
            const NvmFileBodyInstruction *body=&p->body->facts[code->starts[f]+i];
            if(!body->reachable || !body->has_obligation || body->obligation.kind!=NVM_FILE_FLOW_CALL)continue;
            const NvmFileFlowObligation *call=&body->obligation;
            if(call->target>=code->count || call->borrowed_inputs>call->parameters)return NVM_FILE_FLOW_INVALID;
            uint16_t supplied=(uint16_t)(call->parameters-call->borrowed_inputs);
            if(supplied>body->input_stack)return NVM_FILE_FLOW_INVALID;
            const NvmFileHostedFunction *callee=&p->functions[call->target];



            uint64_t vm=(uint64_t)fact->locals+body->input_stack-supplied+fact->staging_slots+callee->vm_value_slots;
            uint64_t native=frame+callee->native_value_slots;
            if(vm>fact->vm_value_slots)fact->vm_value_slots=vm;
            if(native>fact->native_value_slots)fact->native_value_slots=native;
            if((uint32_t)callee->frames+1>fact->frames)fact->frames=(uint16_t)(callee->frames+1);
        }


        fact->reference_slots=(uint32_t)fact->frames*256u;
        fact->region_slots=(uint32_t)fact->frames*256u;
        if(fact->frames>64u || fact->vm_value_slots>64UL*769 ||
           fact->native_value_slots>64UL*769)return NVM_FILE_FLOW_LIMIT;
    }
    uint32_t roots[2]={p->startup.entry,p->startup.initializer};
    for(unsigned i=0;i<2;i++)if(roots[i]!=0xFFFFFFFFu) {
        const NvmFileHostedFunction *f=&p->functions[roots[i]];
        if(f->vm_value_slots>p->startup.vm_value_slots)p->startup.vm_value_slots=f->vm_value_slots;
        if(f->native_value_slots>p->startup.native_value_slots)p->startup.native_value_slots=f->native_value_slots;
        if(f->frames>p->startup.frames)p->startup.frames=f->frames;
        if(f->reference_slots>p->startup.reference_slots)p->startup.reference_slots=f->reference_slots;
        if(f->region_slots>p->startup.region_slots)p->startup.region_slots=f->region_slots;
    }
    return NVM_FILE_FLOW_OK;
}
void nvm_file_hosted_free(NvmFileHostedPlan *p){if(p){nvm_file_body_free(p->body);free(p);}}
NvmFileFlowStatus nvm_file_hosted_prepare(const uint8_t *data,size_t size,NvmFileHostedPlan **out) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    NvmV2Header header;size_t bound;
    NvmFileFlowStatus status=file_hosted_preflight(data,size,&header,&bound);
    if(status!=NVM_FILE_FLOW_OK)return status;
    uint8_t *copy=malloc(size);if(!copy)return NVM_FILE_FLOW_MEMORY;memcpy(copy,data,size);
    NvmV2Module wire={0};NvmModule *module=
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                          ((void *)0)
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                              ;NvmFileHostedPlan *plan=
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                                                              ((void *)0)
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                                                                  ;
    NvmV2Result decoded=nvm_v2_module_deserialize(copy,size,&wire);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}
    decoded=nvm_v2_to_nvm_module(&wire,&module);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}


    if(!module || module->code_size!=wire.code_size || !module->code ||
       memcmp(module->code,wire.code,wire.code_size)) {
        status=NVM_FILE_FLOW_UNRESOLVED;goto done;
    }
    plan=calloc(1,sizeof *plan);if(!plan){status=NVM_FILE_FLOW_MEMORY;goto done;}
    plan->startup.features=header.feature_bits;plan->startup.allocation_bound=bound;
    status=nvm_file_body_analyze(module,&plan->body);if(status!=NVM_FILE_FLOW_OK)goto done;
    status=file_hosted_start(plan,&wire,module);if(status!=NVM_FILE_FLOW_OK)goto done;
    status=file_hosted_bounds(plan,&wire);if(status!=NVM_FILE_FLOW_OK)goto done;
    *out=plan;plan=
# 256 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                  ((void *)0)
# 256 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                      ;
done:
    nvm_file_hosted_free(plan);nvm_module_free(module);nvm_v2_module_free(&wire);free(copy);return status;
}

# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_startup(const NvmFileHostedPlan *p,NvmFileHostedStartup *out) {
    if(!p || !out)return 
# 261 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                        0
# 261 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                             ;
    *out=p->startup;return 
# 262 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                          1
# 262 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                              ;
}

# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_function(const NvmFileHostedPlan *p,uint32_t f,NvmFileHostedFunction *out) {
    if(!p || !out || f>=p->startup.functions)return 
# 265 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                                                   0
# 265 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                                        ;
    *out=p->functions[f];return 
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
                               1
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
                                   ;
}

# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_local(const NvmFileHostedPlan *p,uint32_t f,uint16_t i,NvmFileFlowDeclaration *out) {
    return p && nvm_file_body_local(p->body,f,i,out);
}

# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_instruction(const NvmFileHostedPlan *p,uint32_t f,uint16_t i,
                                NvmFileCodeInstruction *instruction,NvmFileBodyInstruction *fact) {
    return p && nvm_file_body_instruction(p->body,f,i,instruction,fact);
}


# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_type(const NvmFileHostedPlan *p,uint32_t ordinal,NvmFileNominalLayout *out) {
    return p && nvm_file_nominal_type(p->body->plan->declarations->nominal,ordinal,out);
}

# 279 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc" 3 4
_Bool 
# 279 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_hosted.inc"
    nvm_file_hosted_import(const NvmFileHostedPlan *p,uint32_t index,uint32_t *out) {
    return p && nvm_file_nominal_import(p->body->plan->declarations->nominal,index,out);
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_hosted.inc" 2
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
typedef struct NvmFileCyclicReport NvmFileCyclicReport;
typedef struct {
    uint32_t revision, functions, instructions, variants, transfers, edges;
    size_t storage_peak;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
        runtime_admitted;
} NvmFileCyclicSummary;
typedef struct {
    uint16_t locals, stack, regions, owners, references;
} NvmFileCyclicStateInfo;
typedef struct {
    NvmFileCyclicStateInfo input, output;
    NvmFileBodyInstruction body;
    uint8_t edge_mask, edge_variants[2];


} NvmFileCyclicVariant;
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
NvmFileFlowStatus nvm_file_cyclic_analyze(const NvmModule *, NvmFileCyclicReport **);
void nvm_file_cyclic_free(NvmFileCyclicReport *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_summary(const NvmFileCyclicReport *, NvmFileCyclicSummary *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_function(const NvmFileCyclicReport *, uint32_t, NvmFileCodeFunction *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_local(const NvmFileCyclicReport *, uint32_t, uint16_t, NvmFileFlowDeclaration *);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_instruction(const NvmFileCyclicReport *, uint32_t, uint16_t, NvmFileCodeInstruction *);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_component(const NvmFileCyclicReport *, uint32_t, uint16_t, uint16_t *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_variant_count(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t *);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_variant(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, NvmFileCyclicVariant *);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_local(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowValue *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_stack(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowValue *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_reference(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmFileFlowReference *);

# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_input_region(const NvmFileCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, uint64_t *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_type(const NvmFileCyclicReport *, uint32_t, NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.h"
    nvm_file_cyclic_import(const NvmFileCyclicReport *, uint32_t, uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 1

typedef struct {
    NvmFileCyclicStateInfo info;
    NvmFileFlowValue locals[256u], stack[256u];
    NvmFileFlowReference references[256u];
    uint64_t regions[256u];
} FileCyclicState;
typedef struct {
    NvmFileCyclicStateInfo info;
    NvmFileFlowValue *locals, *stack;
    NvmFileFlowReference *references;
    uint64_t *regions;
    uint16_t reference_extent;
} FileCyclicStoredState;
typedef struct {
    FileCyclicStoredState state;
    NvmFileCyclicVariant fact;
    
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
   _Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
        processed;
} FileCyclicNode;
typedef struct {
    uint8_t count;
    uint16_t component;
    FileCyclicNode *nodes[16u];
} FileCyclicSite;
struct NvmFileCyclicReport {
    NvmFileCodePlan *plan;
    FileCyclicSite *sites;
    NvmFileCyclicSummary summary;
};
typedef struct { uint16_t instruction; uint8_t variant; } FileCyclicWork;
typedef struct {
    NvmFileBodyReport body;
    NvmFileFlowState transfer;
    FileCyclicState canonical;
    FileCyclicWork queue[4096u];
    uint32_t head, tail;
    uint64_t owners[256u];
    uint64_t reach[256u][4];
    uint16_t todo[256u];
} FileCyclicWorkspace;



typedef struct {
    size_t extra_bytes;
    const uint64_t *graph;
    void *context;
    NvmFileFlowStatus (*transfer)(void *,NvmFileBodyReport *,NvmFileFlowState *,
                                  const NvmFileCodeInstruction *,NvmFileBodyInstruction *);
} FileCyclicExtension;

static 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
      _Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
           file_cyclic_room(NvmFileCyclicReport *r,size_t count,size_t width) {
    size_t bytes=r->summary.storage_peak;
    if(!file_code_budget(&bytes,count,width) || bytes>(16u * 1024u * 1024u))return 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                        0
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                             ;
    r->summary.storage_peak=bytes;return 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                        1
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                            ;
}
static 
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
      _Bool 
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
           file_cyclic_value_equal(NvmFileFlowValue a,NvmFileFlowValue b) {
    return value_same(a,b) && a.arm==b.arm;
}
static 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
      _Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
           file_cyclic_equal(const FileCyclicState *a,const FileCyclicState *b) {
    if(a->info.locals!=b->info.locals || a->info.stack!=b->info.stack ||
       a->info.regions!=b->info.regions || a->info.owners!=b->info.owners ||
       a->info.references!=b->info.references)return 
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                    0
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                         ;
    for(uint16_t i=0;i<a->info.locals;i++)if(!file_cyclic_value_equal(a->locals[i],b->locals[i]))return 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                       0
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                            ;
    for(uint16_t i=0;i<a->info.stack;i++)if(!file_cyclic_value_equal(a->stack[i],b->stack[i]))return 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                    0
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                         ;
    for(uint16_t i=0;i<a->info.regions;i++)if(a->regions[i]!=b->regions[i])return 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                 0
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                      ;
    for(uint16_t i=0;i<256u;i++)if(!reference_same(a->references[i],b->references[i]))return 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                                      0
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                           ;
    return 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
          1
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
              ;
}
static 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
      _Bool 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
           file_cyclic_stored_equal(const FileCyclicStoredState *a,const FileCyclicState *b) {
    if(a->info.locals!=b->info.locals || a->info.stack!=b->info.stack ||
       a->info.regions!=b->info.regions || a->info.owners!=b->info.owners ||
       a->info.references!=b->info.references)return 
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                    0
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                         ;
    for(uint16_t i=0;i<a->info.locals;i++)if(!file_cyclic_value_equal(a->locals[i],b->locals[i]))return 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                       0
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                            ;
    for(uint16_t i=0;i<a->info.stack;i++)if(!file_cyclic_value_equal(a->stack[i],b->stack[i]))return 
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                    0
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                         ;
    for(uint16_t i=0;i<a->info.regions;i++)if(a->regions[i]!=b->regions[i])return 
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                 0
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                      ;
    for(uint16_t i=0;i<256u;i++)if(!reference_same(i<a->reference_extent?a->references[i]:(NvmFileFlowReference){0},b->references[i]))return 
# 77 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                                                                                             0
# 77 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                                                                                  ;
    return 
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
          1
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
              ;
}
static NvmFileFlowStatus file_cyclic_value(FileCyclicWorkspace *w,NvmFileFlowValue v,
                                          NvmFileFlowValue *out,
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                      _Bool 
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                           local) {
    if(v.type.mode && (!local || (v.type.mode!=1 && v.type.mode!=2) || v.type.category!=NVM_FILE_CATEGORY_FILE))
        return NVM_FILE_FLOW_INVALID;
    if(!v.initialized) {
        if(v.owner || v.type.mode)return NVM_FILE_FLOW_INVALID;
        v=initial_value(v.type,
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                              0
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                   ,0);
    } else {
        if(!local && v.type.mode)return NVM_FILE_FLOW_INVALID;
        if(owned(v.type)!=(v.owner!=0))return NVM_FILE_FLOW_INVALID;
        if(result_type(v.type)) {
            if(v.arm!=NVM_FILE_FLOW_ARM_UNKNOWN && v.arm!=NVM_FILE_FLOW_ARM_OK &&
               v.arm!=NVM_FILE_FLOW_ARM_ERROR)return NVM_FILE_FLOW_INVALID;
        } else if(v.arm!=NVM_FILE_FLOW_ARM_NONE)return NVM_FILE_FLOW_INVALID;
    }
    if(v.owner) {
        uint16_t count=w->canonical.info.owners;
        if(count==256u)return NVM_FILE_FLOW_LIMIT;
        for(uint16_t i=0;i<count;i++)if(w->owners[i]==v.owner)return NVM_FILE_FLOW_INVALID;
        w->owners[count]=v.owner;v.owner=(uint64_t)count+1;
        w->canonical.info.owners++;
    }
    *out=v;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_cyclic_canonicalize(FileCyclicWorkspace *w) {
    NvmFileFlowState *s=&w->transfer;FileCyclicState *c=&w->canonical;
    if(!s->reachable || s->stack_count>256u || s->region_count>256u)
        return NVM_FILE_FLOW_INVALID;
    memset(c,0,sizeof *c);memset(w->owners,0,sizeof w->owners);
    c->info.locals=s->declarations->functions[s->function].locals;
    c->info.stack=s->stack_count;c->info.regions=s->region_count;
    for(uint16_t i=0;i<c->info.locals;i++) {
        if(!same(s->locals[i].type,s->declarations->locals[s->declarations->offsets[s->function]+i]))
            return NVM_FILE_FLOW_INVALID;
        NvmFileFlowStatus status=file_cyclic_value(w,s->locals[i],&c->locals[i],
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                      1
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                          );
        if(status!=NVM_FILE_FLOW_OK)return status;
    }
    for(uint16_t i=0;i<c->info.stack;i++) {
        if(!s->stack[i].initialized)return NVM_FILE_FLOW_INVALID;
        NvmFileFlowStatus status=file_cyclic_value(w,s->stack[i],&c->stack[i],
# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                    0
# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                         );
        if(status!=NVM_FILE_FLOW_OK)return status;
    }
    for(uint16_t i=0;i<s->region_count;i++) {
        if(!s->regions[i])return NVM_FILE_FLOW_INVALID;
        for(uint16_t j=0;j<i;j++)if(s->regions[i]==s->regions[j])return NVM_FILE_FLOW_INVALID;
        c->regions[i]=513UL +i;
    }
    for(uint16_t i=0;i<256u;i++) {
        NvmFileFlowReference ref=s->references[i];
        if(!ref.live)continue;
        NvmFileFlowDeclaration actual;
        if(!ref.owner || !ref.identity || !live_reference(s,i,&actual))return NVM_FILE_FLOW_INVALID;
        for(uint16_t j=0;j<i;j++)if(s->references[j].live &&
            ((s->references[j].owner==ref.owner && (!ref.shared || !s->references[j].shared)) || s->references[j].identity==ref.identity))
            return NVM_FILE_FLOW_INVALID;
        if(ref.formal) {
            if(i>=s->declarations->functions[s->function].parameters || ref.local!=i || ref.region ||
               ref.owner!=257UL +i || ref.identity!=ref.owner)return NVM_FILE_FLOW_INVALID;
        } else {
            uint16_t owner=0,region=s->region_count;
            for(uint16_t j=0;j<c->info.owners;j++)if(w->owners[j]==ref.owner)owner=(uint16_t)(j+1);
            for(uint16_t j=0;j<s->region_count;j++)if(s->regions[j]==ref.region)region=j;
            if(!owner || region==s->region_count)return NVM_FILE_FLOW_INVALID;
            ref.owner=owner;ref.identity=769UL +i;ref.region=513UL +region;
        }
        c->references[i]=ref;c->info.references++;
    }
    for(uint16_t i=0;i<c->info.locals;i++)if(c->locals[i].type.mode &&
        (!c->references[i].live || !c->references[i].formal))return NVM_FILE_FLOW_INVALID;
    return NVM_FILE_FLOW_OK;
}


static void file_cyclic_scratch(FileCyclicWorkspace *w,NvmFileFlowDeclarations *scratch,
                                uint32_t function,const FileCyclicState *input) {
    memset(&w->transfer,0,sizeof w->transfer);
    NvmFileFlowState *s=&w->transfer;s->declarations=scratch;s->function=function;
    s->family=1;s->reachable=
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                            1
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                ;scratch->next_identity=1025;
    s->stack_count=input->info.stack;s->region_count=input->info.regions;
    memcpy(s->locals,input->locals,sizeof s->locals);memcpy(s->stack,input->stack,sizeof s->stack);
    memcpy(s->references,input->references,sizeof s->references);memcpy(s->regions,input->regions,sizeof s->regions);
}
static NvmFileFlowStatus file_cyclic_intern(NvmFileCyclicReport *r,FileCyclicWorkspace *w,
    uint32_t function,uint16_t instruction,uint8_t *ordinal) {
    FileCyclicSite *site=&r->sites[r->plan->starts[function]+instruction];
    for(uint8_t i=0;i<site->count;i++)if(file_cyclic_stored_equal(&site->nodes[i]->state,&w->canonical)) {
        *ordinal=i;return NVM_FILE_FLOW_OK;
    }



    uint16_t extent=0;
    for(uint16_t i=0;i<256u;i++)if(w->canonical.references[i].live)extent=i+1;
    size_t bytes=sizeof(FileCyclicNode)+
        ((size_t)w->canonical.info.locals+w->canonical.info.stack)*sizeof(NvmFileFlowValue)+
        (size_t)extent*sizeof(NvmFileFlowReference)+
        (size_t)w->canonical.info.regions*sizeof(uint64_t);
    if(site->count==16u || w->tail==4096u ||
       r->summary.variants==65536u || !file_cyclic_room(r,1,bytes))
        return NVM_FILE_FLOW_LIMIT;
    FileCyclicNode *node=calloc(1,bytes);if(!node)return NVM_FILE_FLOW_MEMORY;
    node->state.info=w->canonical.info;node->state.reference_extent=extent;
    node->state.locals=(NvmFileFlowValue *)(node+1);
    node->state.stack=node->state.locals+w->canonical.info.locals;
    node->state.references=(NvmFileFlowReference *)(node->state.stack+w->canonical.info.stack);
    node->state.regions=(uint64_t *)(node->state.references+extent);
    memcpy(node->state.locals,w->canonical.locals,(size_t)w->canonical.info.locals*sizeof(NvmFileFlowValue));
    memcpy(node->state.stack,w->canonical.stack,(size_t)w->canonical.info.stack*sizeof(NvmFileFlowValue));
    memcpy(node->state.references,w->canonical.references,(size_t)extent*sizeof(NvmFileFlowReference));
    memcpy(node->state.regions,w->canonical.regions,(size_t)w->canonical.info.regions*sizeof(uint64_t));
    node->fact.input=w->canonical.info;
    node->fact.edge_variants[0]=node->fact.edge_variants[1]=
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                           (255)
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                           ;
    uint8_t v=site->count;site->nodes[v]=node;site->count++;r->summary.variants++;
    w->queue[w->tail++]=(FileCyclicWork){instruction,v};*ordinal=v;
    return NVM_FILE_FLOW_OK;
}


static void file_cyclic_components(NvmFileCyclicReport *r,FileCyclicWorkspace *w,uint32_t f) {
    uint16_t count=r->plan->functions[f].instruction_count;
    memset(w->reach,0,sizeof w->reach);
    for(uint16_t origin=0;origin<count;origin++) {
        uint16_t used=0;w->todo[used++]=origin;
        w->reach[origin][origin/64]|=1UL<<(origin%64);
        while(used) {
            uint16_t i=w->todo[--used];
            const NvmFileCodeInstruction *in=&r->plan->instructions[r->plan->starts[f]+i];
            for(uint8_t e=0;e<in->successor_count;e++) {
                uint16_t next=in->successors[e];uint64_t bit=1UL<<(next%64);
                if(!(w->reach[origin][next/64]&bit)) {
                    w->reach[origin][next/64]|=bit;w->todo[used++]=next;
                }
            }
        }
    }
    for(uint16_t i=0;i<count;i++) {
        uint16_t representative=i;
        for(uint16_t j=0;j<i;j++)if((w->reach[i][j/64]&(1UL<<(j%64))) &&
            (w->reach[j][i/64]&(1UL<<(i%64)))){representative=j;break;}
        r->sites[r->plan->starts[f]+i].component=representative;
    }
}
static NvmFileFlowStatus file_cyclic_function_analyze(NvmFileCyclicReport *r,FileCyclicWorkspace *w,
                                                    NvmFileFlowDeclarations *scratch,uint32_t f,const FileCyclicExtension *extension) {
    w->head=w->tail=0;file_cyclic_components(r,w,f);
    memset(&w->canonical,0,sizeof w->canonical);
    const NvmFileFlowFunction *fn=&r->plan->functions[f].declaration;
    w->canonical.info.locals=fn->locals;
    uint64_t next=1;
    for(uint16_t i=0;i<fn->locals;i++) {
        NvmFileFlowDeclaration d=scratch->locals[scratch->offsets[f]+i];
# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                              _Bool 
# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                   initialized=i<fn->parameters;
        w->canonical.locals[i]=initial_value(d,initialized,initialized && owned(d)?next++:0);
        if(initialized && d.mode)w->canonical.references[i]=(NvmFileFlowReference){
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                         1
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                             ,
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                              1
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                  ,i,
            257UL +i,257UL +i,0,d.mode==1};
    }
    file_cyclic_scratch(w,scratch,f,&w->canonical);
    NvmFileFlowStatus status=file_cyclic_canonicalize(w);if(status!=NVM_FILE_FLOW_OK)return status;
    uint8_t ordinal;status=file_cyclic_intern(r,w,f,0,&ordinal);if(status!=NVM_FILE_FLOW_OK)return status;
    
# 238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
   _Bool 
# 238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
        returned=
# 238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                 0
# 238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                      ;
    while(w->head<w->tail) {
        FileCyclicWork item=w->queue[w->head++];
        FileCyclicSite *site=&r->sites[r->plan->starts[f]+item.instruction];
        FileCyclicNode *node=site->nodes[item.variant];
        if(node->processed || r->summary.transfers==65536u)return NVM_FILE_FLOW_LIMIT;
        r->summary.transfers++;
        memset(&w->canonical,0,sizeof w->canonical);
        w->canonical.info=node->state.info;
        memcpy(w->canonical.locals,node->state.locals,(size_t)node->state.info.locals*sizeof(NvmFileFlowValue));
        memcpy(w->canonical.stack,node->state.stack,(size_t)node->state.info.stack*sizeof(NvmFileFlowValue));
        memcpy(w->canonical.references,node->state.references,(size_t)node->state.reference_extent*sizeof(NvmFileFlowReference));
        memcpy(w->canonical.regions,node->state.regions,(size_t)node->state.info.regions*sizeof(uint64_t));
        file_cyclic_scratch(w,scratch,f,&w->canonical);
        const NvmFileCodeInstruction *in=&r->plan->instructions[r->plan->starts[f]+item.instruction];
        NvmFileBodyInstruction *fact=&node->fact.body;
        fact->reachable=
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                       1
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                           ;fact->input_stack=w->transfer.stack_count;
        fact->cleanup_local=
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                           (65535)
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                           ;fact->pending_checks=NVM_FILE_FLOW_CHECK_CLEANUP;
        status=extension?extension->transfer(extension->context,&w->body,&w->transfer,in,fact):
                         file_body_transfer(&w->body,&w->transfer,in,fact);
        if(status!=NVM_FILE_FLOW_OK)return status;
        fact->output_stack=w->transfer.stack_count;returned|=fact->exit_checked;
        status=file_cyclic_canonicalize(w);if(status!=NVM_FILE_FLOW_OK)return status;
        node->fact.output=w->canonical.info;
        NvmFileFlowArm prior=NVM_FILE_FLOW_ARM_NONE;
        uint16_t refine=0;
        if(in->decoded.opcode==OP_FILE_RESULT_BRANCH) {
            refine=in->decoded.operands[0].u16;
            NvmFileFlowValue value=w->transfer.locals[refine];
            if(!value.initialized || !result_type(value.type) || value.type.mode)return NVM_FILE_FLOW_INVALID;
            prior=value.arm;fact->refinement=
# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                            1
# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                ;
        }
        for(uint8_t edge=0;edge<in->successor_count;edge++) {
            if(fact->refinement) {
                NvmFileFlowArm arm=edge?NVM_FILE_FLOW_ARM_ERROR:NVM_FILE_FLOW_ARM_OK;
                if(prior!=NVM_FILE_FLOW_ARM_UNKNOWN && prior!=arm)continue;
                w->transfer.locals[refine].arm=arm;
            }
            if(r->summary.edges==131072u)return NVM_FILE_FLOW_LIMIT;
            r->summary.edges++;
            status=file_cyclic_canonicalize(w);if(status!=NVM_FILE_FLOW_OK)return status;
            status=file_cyclic_intern(r,w,f,in->successors[edge],&ordinal);
            if(status!=NVM_FILE_FLOW_OK)return status;
            node->fact.edge_variants[edge]=ordinal;node->fact.edge_mask|=(uint8_t)(1u<<edge);
        }
        node->processed=
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                       1
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                           ;
    }
    if(!returned)return NVM_FILE_FLOW_INVALID;
    w->body.checked[f]=
# 286 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                      1
# 286 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                          ;return NVM_FILE_FLOW_OK;
}
void nvm_file_cyclic_free(NvmFileCyclicReport *r) {
    if(!r)return;
    if(r->sites)for(uint32_t i=0;i<r->plan->instruction_count;i++)
        for(uint8_t j=0;j<r->sites[i].count;j++)free(r->sites[i].nodes[j]);
    free(r->sites);nvm_file_code_free(r->plan);free(r);
}
static 
# 294 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
      _Bool 
# 294 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
           file_cyclic_complete(const NvmFileCyclicReport *r) {
    uint32_t count=0;
    for(uint32_t f=0;f<r->plan->count;f++)for(uint16_t i=0;i<r->plan->functions[f].instruction_count;i++) {
        const NvmFileCodeInstruction *in=&r->plan->instructions[r->plan->starts[f]+i];
        const FileCyclicSite *site=&r->sites[r->plan->starts[f]+i];
        if(site->count>16u || site->component>=r->plan->functions[f].instruction_count)
            return 
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                  0
# 300 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                       ;
        for(uint8_t v=0;v<site->count;v++) {
            const FileCyclicNode *n=site->nodes[v];
            if(!n || !n->processed || n->fact.body.input_stack!=n->fact.input.stack ||
               n->fact.body.output_stack!=n->fact.output.stack ||
               (n->fact.edge_mask>>in->successor_count))return 
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                              0
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                   ;
            for(uint8_t e=0;e<2;e++) {
                if(n->fact.edge_mask&(1u<<e)) {
                    if(e>=in->successor_count || in->successors[e]>=r->plan->functions[f].instruction_count ||
                       n->fact.edge_variants[e]>=r->sites[r->plan->starts[f]+in->successors[e]].count)return 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                            0
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                 ;
                } else if(n->fact.edge_variants[e]!=
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                   (255)
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                   )return 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                           0
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                ;
            }
            count++;
        }
    }
    return count==r->summary.variants && count==r->summary.transfers;
}
static NvmFileFlowStatus file_cyclic_budget(const NvmModule *m,size_t extra,
                                             uint32_t *instructions,size_t *bytes,
                                             size_t *declaration_bytes) {
    NvmFileFlowStatus status=file_code_preflight(m,instructions,bytes);
    if(status!=NVM_FILE_FLOW_OK)return status;
    size_t locals=0;
    for(uint32_t i=0;i<m->function_count;i++)locals+=m->functions[i].local_count;
    *declaration_bytes=sizeof(NvmFileFlowDeclarations)+locals*sizeof(NvmFileFlowDeclaration);
    if(!file_code_budget(bytes,1,sizeof(NvmFileCyclicReport)) ||
       !file_code_budget(bytes,*instructions,sizeof(FileCyclicSite)) ||
       !file_code_budget(bytes,1,sizeof(FileCyclicWorkspace)) ||
       !file_code_budget(bytes,1,*declaration_bytes) ||
       !file_code_budget(bytes,1,extra) || *bytes>(16u * 1024u * 1024u))return NVM_FILE_FLOW_LIMIT;
    return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus file_cyclic_analyze_extended(const NvmModule *m,NvmFileCyclicReport **out,
                                                      const FileCyclicExtension *extension) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    uint32_t instructions;size_t bytes,declaration_bytes;
    NvmFileFlowStatus status=file_cyclic_budget(m,extension?extension->extra_bytes:0,
                                               &instructions,&bytes,&declaration_bytes);
    if(status!=NVM_FILE_FLOW_OK)return status;
    NvmFileCodePlan *p=
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                             ((void *)0)
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                 ;status=file_code_prepare_profile(m,&p,
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                        0
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                             ,extension!=
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                         ((void *)0)
# 339 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                             );
    if(status!=NVM_FILE_FLOW_OK)return status;
    if(extension) {
        uint64_t done=0;
        for(uint32_t rank=0;rank<p->count;rank++) {
            uint32_t f;
            for(f=0;f<p->count;f++)
                if(!(done&(1UL<<f)) && !(extension->graph[f]&~done))break;
            if(f==p->count){nvm_file_code_free(p);return NVM_FILE_FLOW_UNRESOLVED;}
            p->function_order[rank]=f;done|=1UL<<f;
        }
    }
    NvmFileCyclicReport *r=calloc(1,sizeof *r);
    if(!r){nvm_file_code_free(p);return NVM_FILE_FLOW_MEMORY;}
    r->plan=p;r->summary=(NvmFileCyclicSummary){1u,p->count,instructions,0,0,0,bytes,
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                                       0
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                            };
    r->sites=calloc(instructions,sizeof *r->sites);
    FileCyclicWorkspace *w=calloc(1,sizeof *w);
    NvmFileFlowDeclarations *scratch=malloc(declaration_bytes);
    if(!r->sites || !w || !scratch){status=NVM_FILE_FLOW_MEMORY;goto done;}
    memcpy(scratch,p->declarations,declaration_bytes);scratch->references=1;
    w->body.plan=p;
    for(uint32_t rank=0;rank<p->count;rank++) {
        status=file_cyclic_function_analyze(r,w,scratch,p->function_order[rank],extension);
        if(status!=NVM_FILE_FLOW_OK)break;
    }
    if(status==NVM_FILE_FLOW_OK && !file_cyclic_complete(r))status=NVM_FILE_FLOW_INVALID;
done:

    free(scratch);free(w);
    if(status!=NVM_FILE_FLOW_OK){nvm_file_cyclic_free(r);return status;}
    *out=r;return NVM_FILE_FLOW_OK;
}
NvmFileFlowStatus nvm_file_cyclic_analyze(const NvmModule *m,NvmFileCyclicReport **out) {
    return file_cyclic_analyze_extended(m,out,
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                             ((void *)0)
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                 );
}
static const FileCyclicSite *file_cyclic_site(const NvmFileCyclicReport *r,uint32_t f,uint16_t i) {
    if(!r || f>=r->plan->count || i>=r->plan->functions[f].instruction_count)return 
# 375 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                   ((void *)0)
# 375 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                       ;
    return &r->sites[r->plan->starts[f]+i];
}
static const FileCyclicNode *file_cyclic_node(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v) {
    const FileCyclicSite *site=file_cyclic_site(r,f,i);
    return site && v<site->count?site->nodes[v]:
# 380 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                               ((void *)0)
# 380 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                   ;
}

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_summary(const NvmFileCyclicReport *r,NvmFileCyclicSummary *out) {
    if(!r || !out)return 
# 383 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                        0
# 383 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                             ;
    *out=r->summary;return 
# 384 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                          1
# 384 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                              ;
}

# 386 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 386 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_function(const NvmFileCyclicReport *r,uint32_t f,NvmFileCodeFunction *out) {
    return r && nvm_file_code_function(r->plan,f,out);
}

# 389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_local(const NvmFileCyclicReport *r,uint32_t f,uint16_t l,NvmFileFlowDeclaration *out) {
    return r && nvm_file_code_local(r->plan,f,l,out);
}

# 392 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 392 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_instruction(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,NvmFileCodeInstruction *out) {
    return r && nvm_file_code_instruction(r->plan,f,i,out);
}

# 395 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 395 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_component(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint16_t *out) {
    const FileCyclicSite *site=file_cyclic_site(r,f,i);if(!site || !out)return 
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                              0
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                   ;
    *out=site->component;return 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                               1
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                   ;
}

# 399 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 399 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_variant_count(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t *out) {
    const FileCyclicSite *site=file_cyclic_site(r,f,i);if(!site || !out)return 
# 400 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                              0
# 400 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                   ;
    *out=site->count;return 
# 401 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                           1
# 401 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                               ;
}

# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_variant(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v,NvmFileCyclicVariant *out) {
    const FileCyclicNode *node=file_cyclic_node(r,f,i,v);if(!node || !out)return 
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                0
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                     ;
    *out=node->fact;return 
# 405 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                          1
# 405 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                              ;
}

# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_input_local(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowValue *out) {
    const FileCyclicNode *node=file_cyclic_node(r,f,i,v);if(!node || !out || l>=node->state.info.locals)return 
# 408 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                              0
# 408 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                   ;
    *out=node->state.locals[l];return 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                     1
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                         ;
}

# 411 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 411 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_input_stack(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v,uint16_t s,NvmFileFlowValue *out) {
    const FileCyclicNode *node=file_cyclic_node(r,f,i,v);if(!node || !out || s>=node->state.info.stack)return 
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                             0
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                  ;
    *out=node->state.stack[s];return 
# 413 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                    1
# 413 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                        ;
}

# 415 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 415 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_input_reference(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v,uint16_t ref,NvmFileFlowReference *out) {
    const FileCyclicNode *node=file_cyclic_node(r,f,i,v);if(!node || !out || ref>=256u)return 
# 416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                                       0
# 416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                            ;
    *out=ref<node->state.reference_extent?node->state.references[ref]:(NvmFileFlowReference){0};return 
# 417 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                             1
# 417 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                 ;
}

# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_input_region(const NvmFileCyclicReport *r,uint32_t f,uint16_t i,uint8_t v,uint16_t region,uint64_t *out) {
    const FileCyclicNode *node=file_cyclic_node(r,f,i,v);if(!node || !out || region>=node->state.info.regions)return 
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                                                                                                    0
# 420 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                                                                                                         ;
    *out=node->state.regions[region];return 
# 421 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
                                           1
# 421 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
                                               ;
}

# 423 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 423 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_type(const NvmFileCyclicReport *r,uint32_t ordinal,NvmFileNominalLayout *out) {
    return r && nvm_file_nominal_type(r->plan->declarations->nominal,ordinal,out);
}

# 426 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc" 3 4
_Bool 
# 426 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic.inc"
    nvm_file_cyclic_import(const NvmFileCyclicReport *r,uint32_t ordinal,uint32_t *out) {
    return r && nvm_file_nominal_import(r->plan->declarations->nominal,ordinal,out);
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic.inc" 2
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
typedef struct NvmFileCyclicHostedPlan NvmFileCyclicHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
        runtime_admitted;
} NvmFileCyclicHostedStartup;
typedef struct {
    NvmFileCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmFileCyclicHostedFunction;




NvmFileFlowStatus nvm_file_cyclic_hosted_prepare(const uint8_t *,size_t,NvmFileCyclicHostedPlan **);
void nvm_file_cyclic_hosted_free(NvmFileCyclicHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_query_summary(const NvmFileCyclicHostedPlan *,NvmFileCyclicSummary *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_startup(const NvmFileCyclicHostedPlan *,NvmFileCyclicHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_function(const NvmFileCyclicHostedPlan *,uint32_t,NvmFileCyclicHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_function_order(const NvmFileCyclicHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_local(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_instruction(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,NvmFileCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_component(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_variant_count(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_variant(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,NvmFileCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_local(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_stack(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_reference(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_input_region(const NvmFileCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_type(const NvmFileCyclicHostedPlan *,uint32_t,NvmFileNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_import(const NvmFileCyclicHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.h"
    nvm_file_cyclic_hosted_bytes(const NvmFileCyclicHostedPlan *,size_t,void *,size_t);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 1


struct NvmFileCyclicHostedPlan {
    NvmFileCyclicReport *query;
    uint8_t *bytes;
    NvmFileCyclicHostedStartup startup;
    NvmFileCyclicHostedFunction functions[64u];
};
static 
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
      _Bool 
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
           file_ch_member(const NvmFileCyclicReport *r,uint32_t context,const char *id,NvmFileFlowDeclaration *out) {
    if(!id){*out=scalar_type(TAG_VOID);return 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                             1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                 ;}
    if(!strcmp(id,"nsi:core/int")){*out=scalar_type(TAG_INT);return 
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                   1
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                       ;}
    if(!strcmp(id,"nsi:core/bool")){*out=scalar_type(TAG_BOOL);return 
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                     1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                         ;}
    if(!strcmp(id,"nsi:core/string")){*out=scalar_type(TAG_STRING);return 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                         1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                             ;}
    for(uint32_t i=((void)(context),0u);i<((void)(context),0u)+((void)(context),8u);i++) {
        const NlServicePlanType *type=nl_file_catalog_type(i);NvmFileNominalLayout layout;
        if(type && !strcmp(type->id,id) && nvm_file_cyclic_type(r,i,&layout)) {
            *out=(NvmFileFlowDeclaration){layout.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION,
                0,layout.global_index,layout.catalog_ordinal,layout.category};return 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                    1
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                        ;
        }
    }
    return 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
          0
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
               ;
}


static 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
      _Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
           file_ch_fact(const NvmFileCyclicReport *r,const NvmFileCodeInstruction *in,
                         const NvmFileCyclicVariant *variant) {
    const NvmFileBodyInstruction *fact=&variant->body;uint8_t op=in->decoded.opcode;
    NvmFileBodyCleanup cleanup=NVM_FILE_BODY_CLEANUP_NORMAL;
    uint16_t cleanup_local=
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                          (65535)
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                          ;
    switch(op) {
    case OP_FILE_DROP_LOCAL:cleanup=NVM_FILE_BODY_CLEANUP_DROP_LOCAL;cleanup_local=in->decoded.operands[0].u16;break;
    case OP_FILE_DROP_STACK:cleanup=NVM_FILE_BODY_CLEANUP_DROP_STACK;break;
    case OP_ASSERT:cleanup=NVM_FILE_BODY_CLEANUP_ASSERT;break;
    case OP_RET:cleanup=NVM_FILE_BODY_CLEANUP_RETURN;break;
    case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:cleanup=NVM_FILE_BODY_CLEANUP_CALL;break;
    case OP_FILE_SERVICE:cleanup=NVM_FILE_BODY_CLEANUP_SERVICE;break;
    default:break;
    }
    
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
   _Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
        call=op==OP_CALL || (op==OP_CALL_REF || op==OP_FILE_CALL_REFS),service=op==OP_FILE_SERVICE;
    if(!fact->reachable || fact->cleanup!=cleanup || fact->cleanup_local!=cleanup_local ||
       fact->refinement!=(op==OP_FILE_RESULT_BRANCH) || fact->exit_checked!=(op==OP_RET) ||
       fact->input_stack!=variant->input.stack || fact->output_stack!=variant->output.stack ||
       fact->has_obligation!=(call || service))return 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                     0
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                          ;
    NvmFileFlowObligation expected={0};uint32_t discharged=0,checks=NVM_FILE_FLOW_CHECK_CLEANUP;
    if(call) {
        uint32_t target=in->decoded.operands[0].u32;
        if(target>=r->plan->count)return 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                        0
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                             ;
        const NvmFileFlowFunction *fn=&r->plan->functions[target].declaration;
        expected.kind=NVM_FILE_FLOW_CALL;expected.site=in->byte_offset;expected.target=target;
        expected.parameters=fn->parameters;expected.result_count=fn->result_count;expected.result=fn->result;
        for(uint16_t i=0;i<fn->parameters;i++) {
            NvmFileFlowDeclaration d;
            if(!nvm_file_cyclic_local(r,target,i,&d))return 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                              0
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                   ;
            expected.owned_inputs+=owned(d);expected.borrowed_inputs+=d.mode!=0;
        }
        expected.checks=checks|NVM_FILE_FLOW_CHECK_CALLEE|NVM_FILE_FLOW_CHECK_RESULT;
        discharged=NVM_FILE_FLOW_CHECK_CALLEE;checks=expected.checks;
    } else if(service) {
        const NlServicePlanMethod *method=nl_file_catalog_method(in->catalog_ordinal);uint32_t import;
        if(!method || !method->param_count ||
           !nvm_file_cyclic_import(r,in->catalog_ordinal,&import) || import!=in->decoded.operands[0].u32 ||
           !file_ch_member(r,((void)(in->catalog_ordinal),0u),method->params[method->param_count-1].type_id,&expected.result))return 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                                                                          0
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                                                                               ;
        expected.kind=NVM_FILE_FLOW_SERVICE;expected.site=in->byte_offset;expected.target=import;
        expected.parameters=(uint16_t)(method->param_count-1);expected.result_count=1;
        expected.required_rights=method->required_rights;expected.acquired_rights=method->acquired_rights;
        expected.outcomes[0]=input_state(method->outcomes[0].input_state);
        expected.outcomes[1]=input_state(method->outcomes[1].input_state);
        checks|=NVM_FILE_FLOW_CHECK_BINDING|NVM_FILE_FLOW_CHECK_INVOCATION|
                NVM_FILE_FLOW_CHECK_LIVENESS|NVM_FILE_FLOW_CHECK_RIGHTS|NVM_FILE_FLOW_CHECK_RESULT;
        if(method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE) {
            expected.borrowed_inputs=1;checks|=NVM_FILE_FLOW_CHECK_BORROW;
        } else if(method->input_mode==NL_SERVICE_INPUT_CONSUME)expected.owned_inputs=1;
        for(size_t i=0;i+1<method->param_count;i++) {
            if(method->params[i].domain==NL_SERVICE_DOMAIN_BYTE_INT)checks|=NVM_FILE_FLOW_CHECK_BYTE;
            if(method->params[i].domain==NL_SERVICE_DOMAIN_TIMEOUT_MS)checks|=0u;
            NvmFileFlowDeclaration argument;
            if(!file_ch_member(r,((void)(in->catalog_ordinal),0u),method->params[i].type_id,&argument))return 
# 77 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                                                   0
# 77 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                                                        ;
            if(((argument.catalog_ordinal)==
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
              (4294967295U)
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
              ) && argument.category==NVM_FILE_CATEGORY_RECORD)
                checks|=0u;
        }
        expected.checks=checks;
    }
    return fact->discharged_checks==discharged && fact->pending_checks==(checks&~discharged) &&
        obligation_same(fact->obligation,expected);
}
static NvmFileFlowStatus file_ch_start(NvmFileCyclicHostedPlan *p,const NvmV2Module *wire,const NvmModule *m) {
    NvmFileCodePlan *code=p->query->plan;
    if(code->count!=wire->functions.count || code->count!=m->function_count ||
       !(m->header.flags & (1 << 0)) || m->header.entry_point!=wire->entry_point ||
       wire->entry_point>=code->count)return NVM_FILE_FLOW_INVALID;
    p->startup.entry=wire->entry_point;p->startup.initializer=0xFFFFFFFFu;p->startup.functions=code->count;
    const NvmFileFlowFunction *entry=&code->functions[p->startup.entry].declaration;
    if(entry->parameters || entry->result_count!=1 || entry->result.mode ||
       entry->result.global_index!=0xFFFFFFFFu ||
       (entry->result.tag!=TAG_INT && entry->result.tag!=TAG_BOOL))return NVM_FILE_FLOW_UNRESOLVED;
    for(uint32_t f=0;f<code->count;f++) {
        uint32_t index=m->functions[f].name_idx;
        if(index>=m->string_count || !m->strings[index] || memchr(m->strings[index],0,m->string_lengths[index]))
            return NVM_FILE_FLOW_INVALID;
        if(p->startup.initializer==0xFFFFFFFFu && !strcmp(m->strings[index],"__init__")) {
            const NvmFileFlowFunction *init=&code->functions[f].declaration;
            if(init->parameters || init->result_count || init->result.tag!=TAG_VOID ||
               init->result.mode || init->result.global_index!=0xFFFFFFFFu)return NVM_FILE_FLOW_UNRESOLVED;
            p->startup.initializer=f;
        }
    }
    return NVM_FILE_FLOW_OK;
}
static 
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
      _Bool 
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
           file_ch_peak(NvmFileCyclicHostedFunction *fn,NvmFileCyclicStateInfo info) {
    if(info.locals!=fn->locals || info.stack>256u || info.owners>256u ||
       info.references>256u || info.regions>256u)return 
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                                           0
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                                                ;
    if(info.stack>fn->operand_peak)fn->operand_peak=info.stack;
    if(info.owners>fn->frame_owner_peak)fn->frame_owner_peak=info.owners;
    if(info.references>fn->frame_reference_peak)fn->frame_reference_peak=info.references;
    if(info.regions>fn->frame_region_peak)fn->frame_region_peak=info.regions;
    return 
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
          1
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
              ;
}
static NvmFileFlowStatus file_ch_bounds(NvmFileCyclicHostedPlan *p,const NvmV2Module *wire) {
    NvmFileCodePlan *code=p->query->plan;
# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                               _Bool 
# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                    checked[64u]={0};
    if(!file_cyclic_complete(p->query))return NVM_FILE_FLOW_INVALID;
    for(uint32_t rank=0;rank<code->count;rank++) {
        uint32_t f=code->function_order[rank];
        if(f>=code->count || checked[f])return NVM_FILE_FLOW_INVALID;
        NvmFileCyclicHostedFunction *fn=&p->functions[f];fn->code=code->functions[f];
        fn->declared_stack=wire->functions.items[f].max_stack;fn->locals=fn->code.declaration.locals;
        fn->staging_slots=1;fn->frames=1;fn->entry_variant=0;
        const FileCyclicSite *entry=file_cyclic_site(p->query,f,0);
        if(!entry || !entry->count || entry->nodes[0]->state.info.stack)return NVM_FILE_FLOW_INVALID;
        for(uint16_t i=0;i<fn->code.instruction_count;i++) {
            const NvmFileCodeInstruction *in=&code->instructions[code->starts[f]+i];
            const FileCyclicSite *site=file_cyclic_site(p->query,f,i);

            if(!site || !file_code_supported(in->decoded.opcode))return NVM_FILE_FLOW_UNRESOLVED;
            for(uint8_t v=0;v<site->count;v++) {
                const NvmFileCyclicVariant *fact=&site->nodes[v]->fact;
                if(!file_ch_fact(p->query,in,fact) || !file_ch_peak(fn,fact->input) ||
                   !file_ch_peak(fn,fact->output))return NVM_FILE_FLOW_INVALID;
                if(fact->body.has_obligation && fact->body.obligation.kind==NVM_FILE_FLOW_CALL) {
                    uint32_t staging=(uint32_t)fact->body.obligation.parameters+1;
                    if(staging>256u +1u)return NVM_FILE_FLOW_INVALID;
                    if(staging>fn->staging_slots)fn->staging_slots=(uint16_t)staging;
                }
            }
        }
        if(fn->declared_stack && fn->declared_stack<fn->operand_peak)return NVM_FILE_FLOW_INVALID;
        uint64_t frame=(uint64_t)fn->locals+fn->operand_peak+fn->staging_slots;
        fn->vm_value_slots=fn->native_value_slots=frame;
        for(uint16_t i=0;i<fn->code.instruction_count;i++) {
            const FileCyclicSite *site=file_cyclic_site(p->query,f,i);
            for(uint8_t v=0;v<site->count;v++) {
                const NvmFileBodyInstruction *body=&site->nodes[v]->fact.body;
                if(!body->has_obligation || body->obligation.kind!=NVM_FILE_FLOW_CALL)continue;
                const NvmFileFlowObligation *call=&body->obligation;
                if(call->target>=code->count || !checked[call->target] || call->borrowed_inputs>call->parameters)
                    return NVM_FILE_FLOW_INVALID;
                uint16_t supplied=(uint16_t)(call->parameters-call->borrowed_inputs);
                if(supplied>body->input_stack)return NVM_FILE_FLOW_INVALID;
                const NvmFileCyclicHostedFunction *callee=&p->functions[call->target];


                uint64_t vm=(uint64_t)fn->locals+body->input_stack-supplied+fn->staging_slots+callee->vm_value_slots;
                uint64_t native=frame+callee->native_value_slots;
                if(vm>fn->vm_value_slots)fn->vm_value_slots=vm;
                if(native>fn->native_value_slots)fn->native_value_slots=native;
                if((uint32_t)callee->frames+1>fn->frames)fn->frames=(uint16_t)(callee->frames+1);
            }
        }
        fn->reference_slots=(uint32_t)fn->frames*256u;
        fn->region_slots=(uint32_t)fn->frames*256u;
        if(fn->frames>64u || fn->vm_value_slots>64UL*769 ||
           fn->native_value_slots>64UL*769)return NVM_FILE_FLOW_LIMIT;
        checked[f]=
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                  1
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                      ;
    }
    uint32_t roots[2]={p->startup.entry,p->startup.initializer};
    for(unsigned i=0;i<2;i++)if(roots[i]!=0xFFFFFFFFu) {
        const NvmFileCyclicHostedFunction *fn=&p->functions[roots[i]];
        if(fn->vm_value_slots>p->startup.vm_value_slots)p->startup.vm_value_slots=fn->vm_value_slots;
        if(fn->native_value_slots>p->startup.native_value_slots)p->startup.native_value_slots=fn->native_value_slots;
        if(fn->frames>p->startup.frames)p->startup.frames=fn->frames;
        if(fn->reference_slots>p->startup.reference_slots)p->startup.reference_slots=fn->reference_slots;
        if(fn->region_slots>p->startup.region_slots)p->startup.region_slots=fn->region_slots;
    }
    return NVM_FILE_FLOW_OK;
}
void nvm_file_cyclic_hosted_free(NvmFileCyclicHostedPlan *p) {
    if(p){nvm_file_cyclic_free(p->query);free(p->bytes);free(p);}
}
NvmFileFlowStatus nvm_file_cyclic_hosted_prepare(const uint8_t *data,size_t size,NvmFileCyclicHostedPlan **out) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    NvmV2Header header;size_t bound;
    NvmFileFlowStatus status=file_hosted_preflight(data,size,&header,&bound);
    if(status!=NVM_FILE_FLOW_OK)return status;



    if(bound<(16u * 1024u * 1024u))return NVM_FILE_FLOW_INVALID;
    bound-=(16u * 1024u * 1024u);
    if(!file_hosted_add(&bound,1,(16u * 1024u * 1024u)) ||
       !file_hosted_add(&bound,1,sizeof(NvmFileCyclicHostedPlan)))return NVM_FILE_FLOW_LIMIT;
    uint8_t *copy=malloc(size);if(!copy)return NVM_FILE_FLOW_MEMORY;
    memcpy(copy,data,size);
    NvmV2Module wire={0};NvmModule *module=
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                          ((void *)0)
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                              ;NvmFileCyclicHostedPlan *plan=
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                    ((void *)0)
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                        ;
    NvmV2Result decoded=nvm_v2_module_deserialize(copy,size,&wire);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}
    decoded=nvm_v2_to_nvm_module(&wire,&module);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}
    if(!module || module->code_size!=wire.code_size || !module->code ||
       memcmp(module->code,wire.code,wire.code_size)) {
        status=NVM_FILE_FLOW_UNRESOLVED;goto done;
    }
    plan=calloc(1,sizeof *plan);if(!plan){status=NVM_FILE_FLOW_MEMORY;goto done;}
    plan->startup.revision=1u;
    plan->startup.features=header.feature_bits;plan->startup.input_bytes=size;plan->startup.allocation_bound=bound;
    status=nvm_file_cyclic_analyze(module,&plan->query);if(status!=NVM_FILE_FLOW_OK)goto done;
    if(plan->query->summary.revision!=1u || plan->query->summary.runtime_admitted ||
       plan->query->summary.storage_peak>(16u * 1024u * 1024u)){status=NVM_FILE_FLOW_INVALID;goto done;}
    plan->startup.query_storage_peak=plan->query->summary.storage_peak;
    size_t retained=sizeof *plan;
    if(!file_hosted_add(&retained,size,1) || !file_hosted_add(&retained,1,plan->startup.query_storage_peak) ||
       retained>bound){status=NVM_FILE_FLOW_LIMIT;goto done;}
    plan->startup.retained_bound=retained;
    status=file_ch_start(plan,&wire,module);if(status!=NVM_FILE_FLOW_OK)goto done;
    status=file_ch_bounds(plan,&wire);if(status!=NVM_FILE_FLOW_OK)goto done;
    plan->bytes=copy;copy=
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                         ((void *)0)
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                             ;*out=plan;plan=
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                             ((void *)0)
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                 ;
done:
    nvm_file_cyclic_hosted_free(plan);nvm_module_free(module);nvm_v2_module_free(&wire);free(copy);return status;
}

# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_query_summary(const NvmFileCyclicHostedPlan *p,NvmFileCyclicSummary *out) {
    return p && nvm_file_cyclic_summary(p->query,out);
}

# 231 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 231 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_startup(const NvmFileCyclicHostedPlan *p,NvmFileCyclicHostedStartup *out) {
    if(!p || !out)return 
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                        0
# 232 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                             ;
    *out=p->startup;return 
# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                          1
# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                              ;
}

# 235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_function(const NvmFileCyclicHostedPlan *p,uint32_t f,NvmFileCyclicHostedFunction *out) {
    if(!p || !out || f>=p->startup.functions)return 
# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                   0
# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                        ;
    *out=p->functions[f];return 
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                               1
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                   ;
}

# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_function_order(const NvmFileCyclicHostedPlan *p,uint32_t rank,uint32_t *out) {
    return p && nvm_file_code_function_order(p->query->plan,rank,out);
}

# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_local(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t l,NvmFileFlowDeclaration *out) {
    return p && nvm_file_cyclic_local(p->query,f,l,out);
}

# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_instruction(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,NvmFileCodeInstruction *out) {
    return p && nvm_file_cyclic_instruction(p->query,f,i,out);
}

# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_component(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint16_t *out) {
    return p && nvm_file_cyclic_component(p->query,f,i,out);
}

# 251 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 251 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_variant_count(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t *out) {
    return p && nvm_file_cyclic_variant_count(p->query,f,i,out);
}

# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_variant(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,NvmFileCyclicVariant *out) {
    return p && nvm_file_cyclic_variant(p->query,f,i,v,out);
}

# 257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_input_local(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowValue *out) {
    return p && nvm_file_cyclic_input_local(p->query,f,i,v,l,out);
}

# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_input_stack(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t s,NvmFileFlowValue *out) {
    return p && nvm_file_cyclic_input_stack(p->query,f,i,v,s,out);
}

# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_input_reference(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t ref,NvmFileFlowReference *out) {
    return p && nvm_file_cyclic_input_reference(p->query,f,i,v,ref,out);
}

# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_input_region(const NvmFileCyclicHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t region,uint64_t *out) {
    return p && nvm_file_cyclic_input_region(p->query,f,i,v,region,out);
}

# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_type(const NvmFileCyclicHostedPlan *p,uint32_t ordinal,NvmFileNominalLayout *out) {
    return p && nvm_file_cyclic_type(p->query,ordinal,out);
}

# 272 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 272 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_import(const NvmFileCyclicHostedPlan *p,uint32_t ordinal,uint32_t *out) {
    return p && nvm_file_cyclic_import(p->query,ordinal,out);
}

# 275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
_Bool 
# 275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
    nvm_file_cyclic_hosted_bytes(const NvmFileCyclicHostedPlan *p,size_t offset,void *out,size_t count) {
    if(!p || (count && !out) || offset>p->startup.input_bytes || count>p->startup.input_bytes-offset)return 
# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
                                                                                                           0
# 276 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
                                                                                                                ;
    if(count)memcpy(out,p->bytes+offset,count);
    return 
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc" 3 4
          1
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_cyclic_hosted.inc"
              ;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_cyclic_hosted.inc" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h" 1





typedef struct NvmFileIndirectTargets NvmFileIndirectTargets;
typedef enum { NVM_FILE_INDIRECT_DESCRIBED, NVM_FILE_INDIRECT_INVALID,
 NVM_FILE_INDIRECT_UNRESOLVED, NVM_FILE_INDIRECT_LIMIT,
 NVM_FILE_INDIRECT_MEMORY } NvmFileIndirectStatus;
typedef struct {
 NvmFileIndirectStatus status;
 uint32_t function,pc;
 const char *message;
} NvmFileIndirectResult;
typedef struct {
 uint32_t functions,instructions,calls,visits;
 size_t storage_bound;
} NvmFileIndirectSummary;
typedef struct {
 uint32_t function,pc;
 uint16_t instruction,parameters;
 uint64_t candidates;
 uint8_t result_count;
 NvmFileFlowDeclaration result;
} NvmFileIndirectCall;





NvmFileIndirectResult nvm_file_indirect_targets(const NvmModule *,NvmFileIndirectTargets **);
void nvm_file_indirect_targets_free(NvmFileIndirectTargets *);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h"
    nvm_file_indirect_targets_summary(const NvmFileIndirectTargets *,NvmFileIndirectSummary *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h"
    nvm_file_indirect_targets_call(const NvmFileIndirectTargets *,uint32_t,NvmFileIndirectCall *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.h"
    nvm_file_indirect_targets_parameter(const NvmFileIndirectTargets *,uint32_t,uint16_t,NvmFileFlowDeclaration *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 1


typedef struct {
    NvmFileFlowDeclaration type;
    uint64_t targets;
    uint8_t initialized;
    uint8_t arms;
} FileIndirectValue;
typedef struct {
    
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
        reached;
    uint16_t stack_count;
    FileIndirectValue locals[256u],stack[256u];
} FileIndirectState;
typedef struct {
    FileIndirectState incoming[256u],working,edge;
    
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
        pending[256u];
} FileIndirectWorkspace;
struct NvmFileIndirectTargets {
    NvmFileCodePlan *plan;
    NvmFileIndirectSummary summary;
    NvmFileIndirectCall *calls;
    uint64_t graph[64u];

    uint64_t parameters[64u][256u];
    uint64_t results[64u];
};
static FileIndirectValue fi_value(NvmFileFlowDeclaration t,uint8_t initialized) {
    FileIndirectValue v={0};v.type=t;v.initialized=initialized;
    if(t.category==NVM_FILE_CATEGORY_OPEN_RESULT || t.category==NVM_FILE_CATEGORY_SCALAR_RESULT)v.arms=3;
    return v;
}
static 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
      _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
           fi_catalog(const NvmFileCodePlan *p,uint32_t ordinal,NvmFileFlowDeclaration *out) {
    NvmFileNominalLayout l;
    if(!nvm_file_nominal_type(p->declarations->nominal,ordinal,&l))return 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                            0
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                 ;
    *out=(NvmFileFlowDeclaration){l.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION,
        0,l.global_index,l.catalog_ordinal,l.category};return 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                             1
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                 ;
}
static 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
      _Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
           fi_member(const NvmFileCodePlan *p,uint32_t context,const char *id,NvmFileFlowDeclaration *out) {
    if(!id){*out=scalar_type(TAG_VOID);return 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                             1
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                 ;}
    if(!strcmp(id,"nsi:core/int")){*out=scalar_type(TAG_INT);return 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                   1
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                       ;}
    if(!strcmp(id,"nsi:core/bool")){*out=scalar_type(TAG_BOOL);return 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                     1
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                         ;}
    if(!strcmp(id,"nsi:core/string")){*out=scalar_type(TAG_STRING);return 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                         1
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                             ;}
    for(uint32_t i=((void)(context),0u);i<((void)(context),0u)+((void)(context),8u);i++) {
        const NlServicePlanType *t=nl_file_catalog_type(i);
        if(t && !strcmp(t->id,id))return fi_catalog(p,i,out);
    }
    return 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
          0
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
               ;
}
static NvmFileFlowStatus fi_push(FileIndirectState *s,FileIndirectValue v) {
    if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
    s->stack[s->stack_count++]=v;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus fi_take(FileIndirectState *s,NvmFileFlowDeclaration expected) {
    if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
    FileIndirectValue *v=&s->stack[s->stack_count-1];
    if(v->initialized!=2 || !same(v->type,expected))return NVM_FILE_FLOW_INVALID;
    *v=(FileIndirectValue){0};s->stack_count--;return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus fi_join(FileIndirectState *to,const FileIndirectState *from,
                                  uint16_t locals,
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                 _Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                      *changed) {
    *changed=
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
            0
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                 ;
    if(!from->reached)return NVM_FILE_FLOW_OK;
    if(!to->reached){*to=*from;*changed=
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                       1
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                           ;return NVM_FILE_FLOW_OK;}
    if(to->stack_count!=from->stack_count)return NVM_FILE_FLOW_INVALID;
    for(uint16_t group=0;group<2;group++) {
        uint16_t n=group?to->stack_count:locals;
        for(uint16_t i=0;i<n;i++) {
            FileIndirectValue *a=group?&to->stack[i]:&to->locals[i];
            const FileIndirectValue *b=group?&from->stack[i]:&from->locals[i];
            if(!same(a->type,b->type))return NVM_FILE_FLOW_UNRESOLVED;
            uint64_t targets=a->targets|b->targets;
            uint8_t init=(uint8_t)(a->initialized|b->initialized),arms=(uint8_t)(a->arms|b->arms);
            *changed|=targets!=a->targets || init!=a->initialized || arms!=a->arms;
            a->targets=targets;a->initialized=init;a->arms=arms;
        }
    }
    return NVM_FILE_FLOW_OK;
}
static 
# 79 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
      _Bool 
# 79 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
           fi_signature(const NvmFileCodePlan *p,uint32_t a,uint32_t b) {
    const NvmFileFlowFunction *x=&p->functions[a].declaration,*y=&p->functions[b].declaration;
    if(x->parameters!=y->parameters || x->result_count!=y->result_count || !same(x->result,y->result))return 
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                                            0
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                                                 ;
    for(uint16_t i=0;i<x->parameters;i++)
        if(!same(p->declarations->locals[p->declarations->offsets[a]+i],
                 p->declarations->locals[p->declarations->offsets[b]+i]))return 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                               0
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                    ;
    return 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
          1
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
              ;
}
static NvmFileFlowStatus fi_candidates(const NvmFileCodePlan *p,const FileIndirectState *s,
                                         const NvmFileCodeInstruction *in,uint64_t *bits,uint32_t *first) {
    const DecodedInstruction *d=&in->decoded;
    if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
    const FileIndirectValue *v=&s->stack[s->stack_count-1];
    if(v->initialized!=2 || !same(v->type,scalar_type(TAG_FUNCTION)) || !v->targets)
        return NVM_FILE_FLOW_UNRESOLVED;
    if(p->count<64 && (v->targets>>p->count))return NVM_FILE_FLOW_INVALID;
    uint32_t selected=p->count;
    for(uint32_t f=0;f<p->count;f++)if(v->targets&(1UL<<f)) {
        const NvmFileFlowFunction *fn=&p->functions[f].declaration;
        if(fn->parameters!=d->operands[0].u16 || fn->result_count!=d->operands[1].u16)
            return NVM_FILE_FLOW_INVALID;
        for(uint16_t i=0;i<fn->parameters;i++) {
            NvmFileFlowDeclaration type=p->declarations->locals[p->declarations->offsets[f]+i];
            if(d->opcode==OP_FILE_CALL_INDIRECT_REFS) {
                if(type.mode ? in->call_references[i]>=256u :
                   in->call_references[i]!=
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                          (65535)
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                          )return NVM_FILE_FLOW_INVALID;
            } else if(type.mode)return NVM_FILE_FLOW_UNRESOLVED;
        }
        if(selected==p->count)selected=f;
        else if(!fi_signature(p,selected,f))return NVM_FILE_FLOW_UNRESOLVED;
    }
    *bits=v->targets;*first=selected;return NVM_FILE_FLOW_OK;
}
static void fi_grow(uint64_t *to,uint64_t bits,
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                              _Bool 
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                   *changed) {
    *changed|=(*to|bits)!=*to;*to|=bits;
}
static NvmFileFlowStatus fi_call(NvmFileIndirectTargets *r,FileIndirectState *s,
                                  uint64_t candidates,uint32_t first,
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                    _Bool 
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                         *changed) {
    const NvmFileCodePlan *p=r->plan;
    const NvmFileFlowFunction *fn=&p->functions[first].declaration;
    for(uint16_t i=fn->parameters;i>0;i--) {
        NvmFileFlowDeclaration type=p->declarations->locals[p->declarations->offsets[first]+i-1];
        if(type.mode)continue;
        if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
        FileIndirectValue value=s->stack[s->stack_count-1];
        NvmFileFlowStatus status=fi_take(s,type);if(status!=NVM_FILE_FLOW_OK)return status;
        if(type.tag==TAG_FUNCTION)for(uint32_t f=0;f<p->count;f++)
            if(candidates&(1UL<<f))fi_grow(&r->parameters[f][i-1],value.targets,changed);
    }
    if(!fn->result_count)return NVM_FILE_FLOW_OK;
    FileIndirectValue result=fi_value(fn->result,2);
    if(fn->result.tag==TAG_FUNCTION)for(uint32_t f=0;f<p->count;f++)
        if(candidates&(1UL<<f))result.targets|=r->results[f];
    return fi_push(s,result);
}
static NvmFileFlowStatus fi_scalar(FileIndirectState *s,uint8_t input,uint8_t output,uint16_t count,
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                                          _Bool 
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                                               equality) {
    if(s->stack_count<count)return NVM_FILE_FLOW_INVALID;
    if(equality) {
        input=s->stack[s->stack_count-1].type.tag;
        if(input!=TAG_INT && input!=TAG_BOOL)return NVM_FILE_FLOW_UNRESOLVED;
    }
    for(uint16_t i=0;i<count;i++) {
        NvmFileFlowStatus status=fi_take(s,scalar_type(input));if(status!=NVM_FILE_FLOW_OK)return status;
    }
    return output==TAG_COUNT?NVM_FILE_FLOW_OK:fi_push(s,fi_value(scalar_type(output),2));
}
static NvmFileFlowStatus fi_transfer(NvmFileIndirectTargets *r,uint32_t f,FileIndirectState *s,
                                      const NvmFileCodeInstruction *in,
# 146 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                             _Bool 
# 146 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                  *changed) {
    const NvmFileCodePlan *p=r->plan;
    const DecodedInstruction *d=&in->decoded;uint16_t local=d->operands[0].u16;
    FileIndirectValue value;NvmFileFlowDeclaration type;NvmFileFlowStatus status;
    switch(d->opcode) {
    case OP_NOP:case OP_JMP:case OP_REGION_BEGIN:case OP_REGION_END:case OP_FILE_END_BORROW:
        return NVM_FILE_FLOW_OK;
    case OP_FILE_RESULT_BRANCH:
        value=s->locals[local];
        return value.initialized==2 && value.arms?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:
        value=s->locals[d->operands[1].u16];
        return value.initialized==2 && value.type.category==NVM_FILE_CATEGORY_FILE?NVM_FILE_FLOW_OK:NVM_FILE_FLOW_INVALID;
    case OP_PUSH_STR:return fi_push(s,fi_value(scalar_type(TAG_STRING),2));
    case OP_STR_EQ:return fi_scalar(s,TAG_STRING,TAG_BOOL,2,
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                           0
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                );
    case OP_STR_LEN:return fi_scalar(s,TAG_STRING,TAG_INT,1,
# 161 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                           0
# 161 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                );
    case OP_PUSH_I64:return fi_push(s,fi_value(scalar_type(TAG_INT),2));
    case OP_PUSH_BOOL:return fi_push(s,fi_value(scalar_type(TAG_BOOL),2));
    case OP_PUSH_VOID:return fi_push(s,fi_value(scalar_type(TAG_VOID),2));
    case OP_FUNCREF:
        value=fi_value(scalar_type(TAG_FUNCTION),2);value.targets=1UL<<d->operands[0].u32;
        return fi_push(s,value);
    case OP_LOAD_LOCAL:case OP_OWN_MOVE_LOCAL:
        value=s->locals[local];
        if(value.initialized!=2 || value.type.mode || owned(value.type)!=(d->opcode==OP_OWN_MOVE_LOCAL))
            return NVM_FILE_FLOW_INVALID;
        status=fi_push(s,value);
        if(status==NVM_FILE_FLOW_OK && d->opcode==OP_OWN_MOVE_LOCAL)s->locals[local]=fi_value(value.type,1);
        return status;
    case OP_STORE_LOCAL:case OP_OWN_STORE_LOCAL:
        if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
        value=s->stack[s->stack_count-1];



        if(d->opcode==OP_STORE_LOCAL && value.initialized==2 &&
           same(value.type,scalar_type(TAG_VOID)) && s->locals[local].type.tag!=TAG_VOID) {
            type=s->locals[local].type;
            if(type.mode || owned(type))return NVM_FILE_FLOW_INVALID;
            s->locals[local]=fi_value(type,1);
            return fi_take(s,scalar_type(TAG_VOID));
        }
        if(value.initialized!=2 || value.type.mode || !same(value.type,s->locals[local].type) ||
           owned(value.type)!=(d->opcode==OP_OWN_STORE_LOCAL) ||
           (d->opcode==OP_OWN_STORE_LOCAL && s->locals[local].initialized!=1))return NVM_FILE_FLOW_INVALID;
        s->locals[local]=value;return fi_take(s,value.type);
    case OP_DUP:
        if(!s->stack_count || owned(s->stack[s->stack_count-1].type))return NVM_FILE_FLOW_INVALID;
        return fi_push(s,s->stack[s->stack_count-1]);
    case OP_POP:case OP_FILE_DROP_STACK:
        if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
        value=s->stack[s->stack_count-1];
        if(owned(value.type)!=(d->opcode==OP_FILE_DROP_STACK))return NVM_FILE_FLOW_INVALID;
        return fi_take(s,value.type);
    case OP_FILE_DROP_LOCAL:
        value=s->locals[local];
        if(value.initialized!=2 || !owned(value.type))return NVM_FILE_FLOW_INVALID;
        s->locals[local]=fi_value(value.type,1);return NVM_FILE_FLOW_OK;
    case OP_FILE_RESULT_TAKE: {
        value=s->locals[local];uint8_t arm=(uint8_t)(1u<<d->operands[1].u8);
        if(value.initialized!=2 || value.arms!=arm)return NVM_FILE_FLOW_UNRESOLVED;
        const NlServicePlanType *t=nl_file_catalog_type(value.type.catalog_ordinal);
        if(!t || t->member_count!=2 || !fi_member(p,value.type.catalog_ordinal,t->members[d->operands[1].u8].type_id,&type))return NVM_FILE_FLOW_INVALID;
        status=fi_push(s,fi_value(type,2));
        if(status==NVM_FILE_FLOW_OK)s->locals[local]=fi_value(value.type,1);
        return status;
    }
    case OP_RET: {
        const NvmFileFlowFunction *fn=&p->functions[f].declaration;
        if(s->stack_count!=fn->result_count)return NVM_FILE_FLOW_INVALID;
        if(fn->result_count && fn->result.tag==TAG_FUNCTION)
            fi_grow(&r->results[f],s->stack[0].targets,changed);
        return fn->result_count?fi_take(s,fn->result):NVM_FILE_FLOW_OK;
    }
    case OP_ASSERT:case OP_JMP_TRUE:case OP_JMP_FALSE:return fi_scalar(s,TAG_BOOL,TAG_COUNT,1,
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                             0
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                                  );
    case OP_ADD:case OP_SUB:case OP_MUL:case OP_DIV:case OP_MOD:
    case OP_I64_ADD:case OP_I64_SUB:case OP_I64_MUL:case OP_I64_DIV_S:case OP_I64_REM_S:
        return fi_scalar(s,TAG_INT,TAG_INT,2,
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                            0
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                 );
    case OP_NEG:case OP_I64_NEG:return fi_scalar(s,TAG_INT,TAG_INT,1,
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                    0
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                         );
    case OP_EQ:case OP_NE:return fi_scalar(s,TAG_INT,TAG_BOOL,2,
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                               1
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                   );
    case OP_LT:case OP_LE:case OP_GT:case OP_GE:
    case OP_I64_EQ:case OP_I64_NE:case OP_I64_LT_S:case OP_I64_LE_S:case OP_I64_GT_S:case OP_I64_GE_S:
        return fi_scalar(s,TAG_INT,TAG_BOOL,2,
# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                             0
# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                  );
    case OP_AND:case OP_OR:return fi_scalar(s,TAG_BOOL,TAG_BOOL,2,
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                 0
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                      );
    case OP_NOT:return fi_scalar(s,TAG_BOOL,TAG_BOOL,1,
# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                      0
# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                           );
    case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:
        return fi_call(r,s,1UL<<d->operands[0].u32,d->operands[0].u32,changed);
    case OP_FILE_CALL_INDIRECT_REFS:case OP_CALL_INDIRECT: {
        uint64_t bits;uint32_t first;
        status=fi_candidates(p,s,in,&bits,&first);if(status!=NVM_FILE_FLOW_OK)return status;
        status=fi_take(s,scalar_type(TAG_FUNCTION));if(status!=NVM_FILE_FLOW_OK)return status;
        fi_grow(&r->graph[f],bits,changed);
        return fi_call(r,s,bits,first,changed);
    }
    case OP_FILE_SERVICE: {
        const NlServicePlanMethod *method=nl_file_catalog_method(in->catalog_ordinal);
        if(!method || !method->param_count)return NVM_FILE_FLOW_INVALID;
        size_t first=method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE?1u:0u;
        for(size_t i=method->param_count-1;i>first;i--) {
            if(!fi_member(p,((void)(in->catalog_ordinal),0u),method->params[i-1].type_id,&type))return NVM_FILE_FLOW_INVALID;
            status=fi_take(s,type);if(status!=NVM_FILE_FLOW_OK)return status;
        }
        if(!fi_member(p,((void)(in->catalog_ordinal),0u),method->params[method->param_count-1].type_id,&type))return NVM_FILE_FLOW_INVALID;
        return fi_push(s,fi_value(type,2));
    }
    case OP_AGG_PACK:case OP_UNION_CONSTRUCT: {
        const NlServicePlanType *t=nl_file_catalog_type(in->catalog_ordinal);
        if(!t || !fi_catalog(p,in->catalog_ordinal,&type))return NVM_FILE_FLOW_INVALID;
        
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
       _Bool 
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
            record=type.category==NVM_FILE_CATEGORY_RECORD;
        uint16_t variant=d->operands[d->opcode==OP_AGG_PACK?2:1].u16;
        size_t count=record?t->member_count:1;
        for(size_t i=count;i>0;i--) {
            NvmFileFlowDeclaration member;
            if(!fi_member(p,in->catalog_ordinal,t->members[record?i-1:variant].type_id,&member))return NVM_FILE_FLOW_INVALID;
            status=fi_take(s,member);if(status!=NVM_FILE_FLOW_OK)return status;
        }
        value=fi_value(type,2);if(!record)value.arms=(uint8_t)(1u<<variant);
        return fi_push(s,value);
    }
    case OP_AGG_GET:case OP_UNION_FIELD:case OP_AGG_TAG:case OP_UNION_TAG: {
        if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
        value=s->stack[s->stack_count-1];
        if(value.initialized!=2 || owned(value.type) || value.type.mode)return NVM_FILE_FLOW_INVALID;
        const NlServicePlanType *t=nl_file_catalog_type(value.type.catalog_ordinal);
        if(!t)return NVM_FILE_FLOW_INVALID;
        
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
       _Bool 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
            tag=d->opcode==OP_AGG_TAG || d->opcode==OP_UNION_TAG;
        if(value.type.category==NVM_FILE_CATEGORY_RECORD && d->opcode==OP_AGG_GET) {
            if(local>=t->member_count || !fi_member(p,value.type.catalog_ordinal,t->members[local].type_id,&type))return NVM_FILE_FLOW_INVALID;
        } else if(value.type.category==NVM_FILE_CATEGORY_SCALAR_RESULT) {
            if(tag)type=scalar_type(TAG_INT);
            else {
                if(local || (value.arms!=1 && value.arms!=2))return NVM_FILE_FLOW_UNRESOLVED;
                if(!fi_member(p,value.type.catalog_ordinal,t->members[value.arms==2].type_id,&type))return NVM_FILE_FLOW_INVALID;
            }
        } else return NVM_FILE_FLOW_UNRESOLVED;
        s->stack[s->stack_count-1]=fi_value(type,2);return NVM_FILE_FLOW_OK;
    }
    default:return NVM_FILE_FLOW_UNRESOLVED;
    }
}
static NvmFileFlowStatus fi_function(NvmFileIndirectTargets *r,uint32_t f,
                                      FileIndirectWorkspace *w,uint32_t *failed_pc,
# 287 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                  _Bool 
# 287 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                       publish,
# 287 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                               _Bool 
# 287 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                                    *changed) {
    NvmFileCodePlan *p=r->plan;const NvmFileCodeFunction *fn=&p->functions[f];
    memset(w,0,sizeof *w);w->incoming[0].reached=
# 289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                1
# 289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                    ;w->pending[0]=
# 289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                   1
# 289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                       ;
    for(uint16_t l=0;l<fn->declaration.locals;l++) {
        FileIndirectValue value=fi_value(p->declarations->locals[p->declarations->offsets[f]+l],
                                            l<fn->declaration.parameters?2:1);
        if(l<fn->declaration.parameters && value.type.tag==TAG_FUNCTION)value.targets=r->parameters[f][l];
        w->incoming[0].locals[l]=value;
    }
    for(;;) {
        uint16_t i=0;while(i<fn->instruction_count && !w->pending[i])i++;
        if(i==fn->instruction_count)break;
        const NvmFileCodeInstruction *in=&p->instructions[p->starts[f]+i];
        *failed_pc=in->byte_offset;
        if(r->summary.visits==262144u)return NVM_FILE_FLOW_LIMIT;
        r->summary.visits++;w->pending[i]=
# 302 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                         0
# 302 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                              ;w->working=w->incoming[i];


        if(!publish && isa_is_file_indirect_call(in->decoded.opcode) && w->working.stack_count) {
            const FileIndirectValue *v=&w->working.stack[w->working.stack_count-1];
            if(v->initialized==2 && same(v->type,scalar_type(TAG_FUNCTION)) && !v->targets)continue;
        }
        NvmFileFlowStatus status=fi_transfer(r,f,&w->working,in,changed);
        if(status!=NVM_FILE_FLOW_OK)return status;
        for(uint8_t e=0;e<in->successor_count;e++) {
            w->edge=w->working;
            if(in->decoded.opcode==OP_FILE_RESULT_BRANCH) {
                FileIndirectValue *v=&w->edge.locals[in->decoded.operands[0].u16];
                v->arms&=(uint8_t)(1u<<e);
                if(!v->arms)continue;
            }
            
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
           _Bool 
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                edge_changed=
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                             0
# 318 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                  ;uint16_t target=in->successors[e];
            status=fi_join(&w->incoming[target],&w->edge,fn->declaration.locals,&edge_changed);
            if(status!=NVM_FILE_FLOW_OK)return status;
            w->pending[target]|=edge_changed;
        }
    }
    if(!publish)return NVM_FILE_FLOW_OK;

    for(uint16_t i=0;i<fn->instruction_count;i++) {
        const NvmFileCodeInstruction *in=&p->instructions[p->starts[f]+i];
        if(!isa_is_file_indirect_call(in->decoded.opcode))continue;
        *failed_pc=in->byte_offset;
        if(!w->incoming[i].reached)return NVM_FILE_FLOW_UNRESOLVED;
        uint64_t bits;uint32_t first;
        NvmFileFlowStatus status=fi_candidates(p,&w->incoming[i],in,&bits,&first);
        if(status!=NVM_FILE_FLOW_OK)return status;
        const NvmFileFlowFunction *callee=&p->functions[first].declaration;
        r->calls[r->summary.calls++]=(NvmFileIndirectCall){f,in->byte_offset,i,callee->parameters,
            bits,callee->result_count,callee->result};
        r->graph[f]|=bits;
    }
    return NVM_FILE_FLOW_OK;
}
static NvmFileIndirectResult fi_result(NvmFileFlowStatus s,uint32_t f,uint32_t pc) {
    NvmFileIndirectStatus status=NVM_FILE_INDIRECT_INVALID;const char *message="I found invalid callable target facts.";
    switch(s) {
    case NVM_FILE_FLOW_OK:status=NVM_FILE_INDIRECT_DESCRIBED;message="I describe exact targets without File execution authority.";break;
    case NVM_FILE_FLOW_UNRESOLVED:status=NVM_FILE_INDIRECT_UNRESOLVED;message="I cannot resolve this complete callable target contract.";break;
    case NVM_FILE_FLOW_LIMIT:status=NVM_FILE_INDIRECT_LIMIT;message="I reached my bounded target-query limit.";break;
    case NVM_FILE_FLOW_MEMORY:status=NVM_FILE_INDIRECT_MEMORY;message="I could not allocate the target-query staging.";break;
    default:break;
    }
    return (NvmFileIndirectResult){status,f,pc,message};
}
NvmFileIndirectResult nvm_file_indirect_targets(const NvmModule *m,NvmFileIndirectTargets **out) {
    uint32_t f=0xFFFFFFFFu,pc=0xFFFFFFFFu,total=0;size_t bytes=0;
    if(!out)return fi_result(NVM_FILE_FLOW_INVALID,f,pc);
    NvmFileFlowStatus status=file_code_preflight(m,&total,&bytes);
    if(status!=NVM_FILE_FLOW_OK)return fi_result(status,f,pc);
    if(!file_code_budget(&bytes,1,sizeof(NvmFileIndirectTargets)) ||
       !file_code_budget(&bytes,total,sizeof(NvmFileIndirectCall)) ||
       !file_code_budget(&bytes,1,sizeof(FileIndirectWorkspace)) || bytes>(16u * 1024u * 1024u))
        return fi_result(NVM_FILE_FLOW_LIMIT,f,pc);
    NvmFileCodePlan *plan=
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                ((void *)0)
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                    ;
    status=file_code_prepare_profile(m,&plan,
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                            0
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                 ,
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                  1
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                      );
    if(status!=NVM_FILE_FLOW_OK)return fi_result(status,f,pc);
    NvmFileIndirectTargets *r=calloc(1,sizeof *r);
    if(!r){nvm_file_code_free(plan);return fi_result(NVM_FILE_FLOW_MEMORY,f,pc);}
    r->plan=plan;r->summary=(NvmFileIndirectSummary){plan->count,total,0,0,bytes};
    r->calls=calloc(total,sizeof *r->calls);
    FileIndirectWorkspace *w=calloc(1,sizeof *w);
    if(!r->calls || !w){status=NVM_FILE_FLOW_MEMORY;goto fail;}
    memcpy(r->graph,plan->calls,sizeof r->graph);
    
# 371 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
   _Bool 
# 371 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
        changed;
    do {
        changed=
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
               0
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                    ;
        for(f=0;f<plan->count;f++) {
            pc=0xFFFFFFFFu;status=fi_function(r,f,w,&pc,
# 375 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                           0
# 375 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                ,&changed);
            if(status!=NVM_FILE_FLOW_OK)goto fail;
        }
    } while(changed);
    for(f=0;f<plan->count;f++) {
        pc=0xFFFFFFFFu;status=fi_function(r,f,w,&pc,
# 380 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                       1
# 380 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                           ,&changed);
        if(status!=NVM_FILE_FLOW_OK)goto fail;
    }
    if(changed){status=NVM_FILE_FLOW_INVALID;goto fail;}

    for(uint32_t via=0;via<plan->count;via++)
        for(uint32_t source=0;source<plan->count;source++)
            if(r->graph[source]&(1UL<<via))r->graph[source]|=r->graph[via];
    for(f=0;f<plan->count;f++)if(r->graph[f]&(1UL<<f)) {
        pc=0xFFFFFFFFu;status=NVM_FILE_FLOW_UNRESOLVED;goto fail;
    }
    free(w);*out=r;return fi_result(NVM_FILE_FLOW_OK,0xFFFFFFFFu,0xFFFFFFFFu);
fail:
    free(w);nvm_file_indirect_targets_free(r);return fi_result(status,f,pc);
}
void nvm_file_indirect_targets_free(NvmFileIndirectTargets *r) {
    if(r){nvm_file_code_free(r->plan);free(r->calls);free(r);}
}

# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
    nvm_file_indirect_targets_summary(const NvmFileIndirectTargets *r,NvmFileIndirectSummary *out) {
    if(!r || !out)return 
# 399 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                        0
# 399 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                             ;
    *out=r->summary;return 
# 400 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                          1
# 400 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                              ;
}

# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
_Bool 
# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
    nvm_file_indirect_targets_call(const NvmFileIndirectTargets *r,uint32_t index,NvmFileIndirectCall *out) {
    if(!r || !out || index>=r->summary.calls)return 
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                   0
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                        ;
    *out=r->calls[index];return 
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                               1
# 404 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                   ;
}

# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
    nvm_file_indirect_targets_parameter(const NvmFileIndirectTargets *r,uint32_t index,uint16_t parameter,NvmFileFlowDeclaration *out) {
    if(!r || !out || index>=r->summary.calls || parameter>=r->calls[index].parameters)return 
# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc" 3 4
                                                                                            0
# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_targets.inc"
                                                                                                 ;
    uint32_t f=0;while(f<r->plan->count && !(r->calls[index].candidates&(1UL<<f)))f++;
    return nvm_file_code_local(r->plan,f,parameter,out);
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_targets.inc" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 1






typedef struct NvmFileIndirectFlow NvmFileIndirectFlow;
typedef struct {
 NvmFileIndirectSummary targets;
 NvmFileCyclicSummary ownership;
 uint32_t candidate_applications;
 size_t storage_bound;
 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
     runtime_admitted;
} NvmFileIndirectFlowSummary;
typedef struct {
 uint32_t function,pc;
 uint64_t candidates,checked_candidates;
 NvmFileFlowObligation common;
} NvmFileIndirectFlowCall;





NvmFileFlowStatus nvm_file_indirect_flow_analyze(const NvmModule *,NvmFileIndirectFlow **);
void nvm_file_indirect_flow_free(NvmFileIndirectFlow *);

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_summary(const NvmFileIndirectFlow *,NvmFileIndirectFlowSummary *);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_function(const NvmFileIndirectFlow *,uint32_t,NvmFileCodeFunction *);

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_local(const NvmFileIndirectFlow *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_instruction(const NvmFileIndirectFlow *,uint32_t,uint16_t,NvmFileCodeInstruction *);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_variant_count(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t *);

# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_variant(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmFileCyclicVariant *);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_input_local(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_input_stack(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_input_reference(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowReference *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_input_region(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_call(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmFileIndirectFlowCall *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_component(const NvmFileIndirectFlow *,uint32_t,uint16_t,uint16_t *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_type(const NvmFileIndirectFlow *,uint32_t,NvmFileNominalLayout *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.h"
    nvm_file_indirect_flow_import(const NvmFileIndirectFlow *,uint32_t,uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 1
struct NvmFileIndirectFlow {
 NvmFileIndirectTargets *targets;
 NvmFileCyclicReport *ownership;
 NvmFileIndirectFlowSummary summary;
};
typedef struct {
 const NvmFileIndirectTargets *targets;
 uint64_t bits[4096u];
 uint32_t applications;
 NvmFileFlowState saved,first;
 FileCyclicState canonical_first;
 FileCyclicWorkspace candidate;
} FileIndirectFlowScratch;
static 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
      _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
           fif_state_metadata_equal(const NvmFileFlowState *a,const NvmFileFlowState *b) {
 if(a->family!=b->family || a->reachable!=b->reachable ||
    a->cleanup_obligations!=b->cleanup_obligations || a->obligation_count!=b->obligation_count)return 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                                                     0
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                                                          ;
 for(uint16_t i=0;i<a->obligation_count;i++)if(!obligation_same(a->obligations[i],b->obligations[i]))return 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                                                           0
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                                                                ;
 return 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
       1
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
           ;
}
static NvmFileFlowStatus fif_transfer(void *context,NvmFileBodyReport *body,NvmFileFlowState *s,
                                      const NvmFileCodeInstruction *in,NvmFileBodyInstruction *fact) {
 FileIndirectFlowScratch *w=context;
 if(in->decoded.opcode==OP_FUNCREF) {
  if(in->decoded.operands[0].u32>=body->plan->count)return NVM_FILE_FLOW_INVALID;
  if(s->stack_count==256u)return NVM_FILE_FLOW_LIMIT;
  s->stack[s->stack_count++]=initial_value(scalar_type(TAG_FUNCTION),
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                    1
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                        ,0);
  return NVM_FILE_FLOW_OK;
 }
 if(!isa_is_file_indirect_call(in->decoded.opcode))return file_body_transfer(body,s,in,fact);
 if(!s->stack_count)return NVM_FILE_FLOW_INVALID;
 NvmFileFlowValue callable=s->stack[s->stack_count-1];
 if(!callable.initialized || !same(callable.type,scalar_type(TAG_FUNCTION)) ||
    callable.owner || callable.arm!=NVM_FILE_FLOW_ARM_NONE)return NVM_FILE_FLOW_INVALID;


 size_t index=(size_t)(in-body->plan->instructions);
 if(index>=body->plan->instruction_count || !w->bits[index])return NVM_FILE_FLOW_UNRESOLVED;
 const NvmFileCodePlan *original=w->targets->plan;
 uint32_t caller=s->function;
 if(caller>=original->count || caller>=body->plan->count ||
    original->instruction_count!=body->plan->instruction_count ||
    original->starts[caller]!=body->plan->starts[caller] ||
    index<original->starts[caller] ||
    index-original->starts[caller]>=original->functions[caller].instruction_count ||
    original->functions[caller].instruction_count!=body->plan->functions[caller].instruction_count ||
    original->instructions[index].byte_offset!=in->byte_offset ||
    original->instructions[index].decoded.opcode!=in->decoded.opcode)return NVM_FILE_FLOW_INVALID;
 uint64_t candidates=w->bits[index];
 pop(s);w->saved=*s;
 uint64_t identity=s->declarations->next_identity,first_identity=identity;
 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
     first=
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
           1
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
               ;NvmFileFlowObligation common={0};
 for(uint32_t f=0;f<body->plan->count;f++)if(candidates&(1UL<<f)) {
  if(!body->checked[f])return NVM_FILE_FLOW_UNRESOLVED;
  if(w->applications==262144u)return NVM_FILE_FLOW_LIMIT;
  w->applications++;
  w->candidate.transfer=w->saved;s->declarations->next_identity=identity;
  const NvmFileFlowFunction *fn=&body->plan->functions[f].declaration;
  uint16_t references[256u];
  for(uint16_t i=0;i<fn->parameters;i++) {
   
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
  _Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
       borrowed=s->declarations->locals[s->declarations->offsets[f]+i].mode!=0;
   if(borrowed && in->decoded.opcode!=OP_FILE_CALL_INDIRECT_REFS)return NVM_FILE_FLOW_UNRESOLVED;
   references[i]=borrowed?in->call_references[i]:
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                (65535)
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                                ;
  }
  NvmFileFlowStatus status=nvm_file_flow_call(&w->candidate.transfer,in->byte_offset,f,references,fn->parameters);
  if(status!=NVM_FILE_FLOW_OK)return status;
  NvmFileFlowObligation *call=
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                    ((void *)0)
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                        ;
  for(uint16_t i=0;i<w->candidate.transfer.obligation_count;i++)
   if(w->candidate.transfer.obligations[i].site==in->byte_offset)call=&w->candidate.transfer.obligations[i];
  if(!call || call->kind!=NVM_FILE_FLOW_CALL || call->target!=f)return NVM_FILE_FLOW_INVALID;
  call->target=0xFFFFFFFFu;
  status=file_cyclic_canonicalize(&w->candidate);if(status!=NVM_FILE_FLOW_OK)return status;
  if(first) {
   w->first=w->candidate.transfer;w->canonical_first=w->candidate.canonical;
   common=*call;first_identity=s->declarations->next_identity;first=
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                   0
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                        ;
  } else if(!file_cyclic_equal(&w->canonical_first,&w->candidate.canonical) ||
            !fif_state_metadata_equal(&w->first,&w->candidate.transfer) ||
            !obligation_same(common,*call))return NVM_FILE_FLOW_UNRESOLVED;
 }
 if(first)return NVM_FILE_FLOW_UNRESOLVED;
 *s=w->first;s->declarations->next_identity=first_identity;
 fact->cleanup=NVM_FILE_BODY_CLEANUP_CALL;fact->has_obligation=
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                    1
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                        ;fact->obligation=common;
 fact->discharged_checks=NVM_FILE_FLOW_CHECK_CALLEE;
 fact->pending_checks|=common.checks&~fact->discharged_checks;
 return NVM_FILE_FLOW_OK;
}
static NvmFileFlowStatus fif_target_status(NvmFileIndirectStatus status) {
 switch(status) {
 case NVM_FILE_INDIRECT_DESCRIBED:return NVM_FILE_FLOW_OK;
 case NVM_FILE_INDIRECT_INVALID:return NVM_FILE_FLOW_INVALID;
 case NVM_FILE_INDIRECT_UNRESOLVED:return NVM_FILE_FLOW_UNRESOLVED;
 case NVM_FILE_INDIRECT_LIMIT:return NVM_FILE_FLOW_LIMIT;
 case NVM_FILE_INDIRECT_MEMORY:return NVM_FILE_FLOW_MEMORY;
 }
 return NVM_FILE_FLOW_INVALID;
}
NvmFileFlowStatus nvm_file_indirect_flow_analyze(const NvmModule *m,NvmFileIndirectFlow **out) {
 if(!out)return NVM_FILE_FLOW_INVALID;
 NvmFileIndirectTargets *targets=
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                       ((void *)0)
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                           ;
 NvmFileFlowStatus status=fif_target_status(nvm_file_indirect_targets(m,&targets).status);
 if(status!=NVM_FILE_FLOW_OK)return status;
 size_t extra=sizeof(NvmFileIndirectFlow)+sizeof(FileIndirectFlowScratch),bytes,declaration_bytes;
 uint32_t instructions;
 status=file_cyclic_budget(m,extra,&instructions,&bytes,&declaration_bytes);
 if(status!=NVM_FILE_FLOW_OK){nvm_file_indirect_targets_free(targets);return status;}
 if(targets->summary.storage_bound>(32u * 1024u * 1024u)-bytes) {
  nvm_file_indirect_targets_free(targets);return NVM_FILE_FLOW_LIMIT;
 }
 NvmFileIndirectFlow *r=calloc(1,sizeof *r);
 FileIndirectFlowScratch *w=calloc(1,sizeof *w);
 if(!r || !w){free(r);free(w);nvm_file_indirect_targets_free(targets);return NVM_FILE_FLOW_MEMORY;}
 r->targets=targets;w->targets=targets;
 for(uint32_t i=0;i<targets->summary.calls;i++) {
  NvmFileIndirectCall call=targets->calls[i];
  uint32_t index=targets->plan->starts[call.function]+call.instruction;
  if(index>=instructions || targets->plan->instructions[index].byte_offset!=call.pc || w->bits[index]) {
   status=NVM_FILE_FLOW_INVALID;goto fail;
  }
  w->bits[index]=call.candidates;
 }
 FileCyclicExtension extension={extra,targets->graph,w,fif_transfer};
 status=file_cyclic_analyze_extended(m,&r->ownership,&extension);
 if(status!=NVM_FILE_FLOW_OK)goto fail;
 r->summary.targets=targets->summary;r->summary.ownership=r->ownership->summary;
 r->summary.candidate_applications=w->applications;
 r->summary.storage_bound=targets->summary.storage_bound+r->ownership->summary.storage_peak;
 if(r->summary.storage_bound>(32u * 1024u * 1024u)){status=NVM_FILE_FLOW_LIMIT;goto fail;}
 free(w);*out=r;return NVM_FILE_FLOW_OK;
fail:
 free(w);nvm_file_indirect_flow_free(r);return status;
}
void nvm_file_indirect_flow_free(NvmFileIndirectFlow *r) {
 if(r){nvm_file_cyclic_free(r->ownership);nvm_file_indirect_targets_free(r->targets);free(r);}
}

# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_summary(const NvmFileIndirectFlow *r,NvmFileIndirectFlowSummary *out) {
 if(!r || !out)return 
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                     0
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                          ;
 *out=r->summary;return 
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                       1
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                           ;
}

# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_function(const NvmFileIndirectFlow *r,uint32_t f,NvmFileCodeFunction *out) {
 return r && nvm_file_cyclic_function(r->ownership,f,out);
}

# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_local(const NvmFileIndirectFlow *r,uint32_t f,uint16_t l,NvmFileFlowDeclaration *out) {
 return r && nvm_file_cyclic_local(r->ownership,f,l,out);
}

# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_instruction(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,NvmFileCodeInstruction *out) {
 return r && nvm_file_cyclic_instruction(r->ownership,f,i,out);
}

# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_variant_count(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t *out) {
 return r && nvm_file_cyclic_variant_count(r->ownership,f,i,out);
}

# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_variant(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,NvmFileCyclicVariant *out) {
 return r && nvm_file_cyclic_variant(r->ownership,f,i,v,out);
}

# 153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_input_local(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowValue *out) {
 return r && nvm_file_cyclic_input_local(r->ownership,f,i,v,l,out);
}

# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_input_stack(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowValue *out) {
 return r && nvm_file_cyclic_input_stack(r->ownership,f,i,v,l,out);
}

# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_input_reference(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowReference *out) {
 return r && nvm_file_cyclic_input_reference(r->ownership,f,i,v,l,out);
}

# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_input_region(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,uint16_t l,uint64_t *out) {
 return r && nvm_file_cyclic_input_region(r->ownership,f,i,v,l,out);
}

# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_call(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint8_t v,NvmFileIndirectFlowCall *out) {
 if(!r || !out)return 
# 166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                     0
# 166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                          ;
 NvmFileCodeInstruction in;NvmFileCyclicVariant variant;
 if(!nvm_file_cyclic_instruction(r->ownership,f,i,&in) || !isa_is_file_indirect_call(in.decoded.opcode) ||
    !nvm_file_cyclic_variant(r->ownership,f,i,v,&variant) || !variant.body.has_obligation)return 
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                                                   0
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                                                        ;
 for(uint32_t n=0;n<r->targets->summary.calls;n++) {
  const NvmFileIndirectCall *call=&r->targets->calls[n];
  if(call->function==f && call->instruction==i && call->pc==in.byte_offset) {
   *out=(NvmFileIndirectFlowCall){f,in.byte_offset,call->candidates,call->candidates,variant.body.obligation};return 
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
                                                                                                                           1
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
                                                                                                                               ;
  }
 }
 return 
# 176 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
       0
# 176 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
            ;
}

# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_component(const NvmFileIndirectFlow *r,uint32_t f,uint16_t i,uint16_t *out) {
 return r && nvm_file_cyclic_component(r->ownership,f,i,out);
}

# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_type(const NvmFileIndirectFlow *r,uint32_t i,NvmFileNominalLayout *out) {
 return r && nvm_file_cyclic_type(r->ownership,i,out);
}

# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc" 3 4
_Bool 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_flow.inc"
    nvm_file_indirect_flow_import(const NvmFileIndirectFlow *r,uint32_t i,uint32_t *out) {
 return r && nvm_file_cyclic_import(r->ownership,i,out);
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_flow.inc" 2
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
typedef struct NvmFileIndirectHostedPlan NvmFileIndirectHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
        runtime_admitted;
} NvmFileIndirectHostedStartup;
typedef struct {
    NvmFileCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmFileIndirectHostedFunction;




NvmFileFlowStatus nvm_file_indirect_hosted_prepare(const uint8_t *,size_t,NvmFileIndirectHostedPlan **);
void nvm_file_indirect_hosted_free(NvmFileIndirectHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_query_summary(const NvmFileIndirectHostedPlan *,NvmFileIndirectFlowSummary *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_startup(const NvmFileIndirectHostedPlan *,NvmFileIndirectHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_function(const NvmFileIndirectHostedPlan *,uint32_t,NvmFileIndirectHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_function_order(const NvmFileIndirectHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_local(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,NvmFileFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_instruction(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,NvmFileCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_component(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_variant_count(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_variant(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmFileCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_input_local(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_input_stack(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_input_reference(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmFileFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_input_region(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_type(const NvmFileIndirectHostedPlan *,uint32_t,NvmFileNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_import(const NvmFileIndirectHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_bytes(const NvmFileIndirectHostedPlan *,size_t,void *,size_t);

# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_call(const NvmFileIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmFileIndirectFlowCall *);


# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h" 3 4
_Bool 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.h"
    nvm_file_indirect_hosted_string(const NvmFileIndirectHostedPlan *,uint32_t,const uint8_t **,size_t *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 1

struct NvmFileIndirectHostedPlan {
    NvmFileIndirectFlow *query;
    uint64_t targets[4096u];
    uint8_t *bytes;
    NvmFileIndirectHostedStartup startup;
    NvmFileIndirectHostedFunction functions[64u];
};
static 
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
      _Bool 
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
           file_ih_fact(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,
                        const NvmFileCodeInstruction *in,const NvmFileCyclicVariant *v) {
    const NvmFileCyclicReport *r=p->query->ownership;
    if(!isa_is_file_indirect_call(in->decoded.opcode))return file_ch_fact(r,in,v);
    const NvmFileBodyInstruction *b=&v->body;
    uint64_t bits=p->targets[r->plan->starts[f]+i];
    if(!bits || !b->reachable || b->cleanup!=NVM_FILE_BODY_CLEANUP_CALL ||
       b->cleanup_local!=
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                        (65535) 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                         || b->refinement || b->exit_checked ||
       !b->has_obligation || b->input_stack!=v->input.stack || b->output_stack!=v->output.stack ||
       !b->input_stack || b->discharged_checks!=NVM_FILE_FLOW_CHECK_CALLEE ||
       b->pending_checks!=(NVM_FILE_FLOW_CHECK_RESULT|NVM_FILE_FLOW_CHECK_CLEANUP))return 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                     0
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                          ;
    for(uint32_t target=0;target<r->plan->count;target++)if(bits&(1UL<<target)) {
        const NvmFileFlowFunction *fn=&r->plan->functions[target].declaration;
        NvmFileFlowObligation expected={0};expected.kind=NVM_FILE_FLOW_CALL;
        expected.site=in->byte_offset;expected.target=0xFFFFFFFFu;
        expected.parameters=fn->parameters;expected.result_count=fn->result_count;expected.result=fn->result;
        expected.checks=NVM_FILE_FLOW_CHECK_CALLEE|NVM_FILE_FLOW_CHECK_RESULT|NVM_FILE_FLOW_CHECK_CLEANUP;
        for(uint16_t local=0;local<fn->parameters;local++) {
            NvmFileFlowDeclaration d;
            if(!nvm_file_indirect_flow_local(p->query,target,local,&d))return 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                0
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                     ;
            if(d.mode && in->decoded.opcode!=OP_FILE_CALL_INDIRECT_REFS)return 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                              0
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                   ;
            if(d.mode ? in->call_references[local]>=256u :
               (in->decoded.opcode==OP_FILE_CALL_INDIRECT_REFS && in->call_references[local]!=
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                             (65535)
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                                             ))return 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                                                      0
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                                                           ;
            expected.borrowed_inputs+=d.mode!=0;
            expected.owned_inputs+=owned(d);
        }
        if(!obligation_same(b->obligation,expected))return 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                          0
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                               ;
    }
    return 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          1
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
              ;
}
static 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
      _Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
           file_ih_target_map(NvmFileIndirectHostedPlan *p) {
    const NvmFileIndirectTargets *t=p->query->targets;
    const NvmFileCodePlan *code=p->query->ownership->plan;
    if(t->summary.functions!=code->count || t->summary.instructions!=code->instruction_count)return 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                   0
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                        ;
    for(uint32_t n=0;n<t->summary.calls;n++) {
        NvmFileIndirectCall call=t->calls[n];
        if(call.function>=code->count || call.instruction>=code->functions[call.function].instruction_count ||
           !call.candidates || (code->count<64 && (call.candidates>>code->count)))return 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                        0
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                             ;
        uint32_t index=code->starts[call.function]+call.instruction;
        if(index>=4096u || p->targets[index] ||
           !isa_is_file_indirect_call(code->instructions[index].decoded.opcode) ||
           code->instructions[index].byte_offset!=call.pc)return 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                0
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                     ;
        p->targets[index]=call.candidates;
    }
    for(uint32_t i=0;i<code->instruction_count;i++)
        if((isa_is_file_indirect_call(code->instructions[i].decoded.opcode))!=!!p->targets[i])return 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                    0
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                         ;
    return 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          1
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
              ;
}
static NvmFileFlowStatus file_ih_start(NvmFileIndirectHostedPlan *p,const NvmV2Module *wire,const NvmModule *m) {
    NvmFileCodePlan *code=p->query->ownership->plan;
    if(code->count!=wire->functions.count || code->count!=m->function_count ||
       !(m->header.flags & (1 << 0)) || m->header.entry_point!=wire->entry_point ||
       wire->entry_point>=code->count)return NVM_FILE_FLOW_INVALID;
    p->startup.entry=wire->entry_point;p->startup.initializer=0xFFFFFFFFu;p->startup.functions=code->count;
    const NvmFileFlowFunction *entry=&code->functions[p->startup.entry].declaration;
    if(entry->parameters || entry->result_count!=1 || entry->result.mode ||
       entry->result.global_index!=0xFFFFFFFFu ||
       (entry->result.tag!=TAG_INT && entry->result.tag!=TAG_BOOL))return NVM_FILE_FLOW_UNRESOLVED;
    for(uint32_t f=0;f<code->count;f++) {
        uint32_t index=m->functions[f].name_idx;
        if(index>=m->string_count || !m->strings[index] || memchr(m->strings[index],0,m->string_lengths[index]))
            return NVM_FILE_FLOW_INVALID;
        if(p->startup.initializer==0xFFFFFFFFu && !strcmp(m->strings[index],"__init__")) {
            const NvmFileFlowFunction *init=&code->functions[f].declaration;
            if(init->parameters || init->result_count || init->result.tag!=TAG_VOID ||
               init->result.mode || init->result.global_index!=0xFFFFFFFFu)return NVM_FILE_FLOW_UNRESOLVED;
            p->startup.initializer=f;
        }
    }
    return NVM_FILE_FLOW_OK;
}
static 
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
      _Bool 
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
           file_ih_peak(NvmFileIndirectHostedFunction *fn,NvmFileCyclicStateInfo info) {
    if(info.locals!=fn->locals || info.stack>256u || info.owners>256u ||
       info.references>256u || info.regions>256u)return 
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                           0
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                                ;
    if(info.stack>fn->operand_peak)fn->operand_peak=info.stack;
    if(info.owners>fn->frame_owner_peak)fn->frame_owner_peak=info.owners;
    if(info.references>fn->frame_reference_peak)fn->frame_reference_peak=info.references;
    if(info.regions>fn->frame_region_peak)fn->frame_region_peak=info.regions;
    return 
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          1
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
              ;
}
static NvmFileFlowStatus file_ih_bounds(NvmFileIndirectHostedPlan *p,const NvmV2Module *wire) {
    NvmFileCodePlan *code=p->query->ownership->plan;
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                          _Bool 
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                               checked[64u]={0};
    if(!file_cyclic_complete(p->query->ownership))return NVM_FILE_FLOW_INVALID;
    for(uint32_t rank=0;rank<code->count;rank++) {
        uint32_t f=code->function_order[rank];
        if(f>=code->count || checked[f])return NVM_FILE_FLOW_INVALID;
        NvmFileIndirectHostedFunction *fn=&p->functions[f];fn->code=code->functions[f];
        fn->declared_stack=wire->functions.items[f].max_stack;fn->locals=fn->code.declaration.locals;
        fn->staging_slots=1;fn->frames=1;fn->entry_variant=0;
        const FileCyclicSite *entry=file_cyclic_site(p->query->ownership,f,0);
        if(!entry || !entry->count || entry->nodes[0]->state.info.stack)return NVM_FILE_FLOW_INVALID;
        for(uint16_t i=0;i<fn->code.instruction_count;i++) {
            const NvmFileCodeInstruction *in=&code->instructions[code->starts[f]+i];
            const FileCyclicSite *site=file_cyclic_site(p->query->ownership,f,i);

            if(!site || !file_code_supported_mode(in->decoded.opcode,
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                    1
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                        ))return NVM_FILE_FLOW_UNRESOLVED;
            for(uint8_t v=0;v<site->count;v++) {
                const NvmFileCyclicVariant *fact=&site->nodes[v]->fact;
                if(!file_ih_fact(p,f,i,in,fact) || !file_ih_peak(fn,fact->input) ||
                   !file_ih_peak(fn,fact->output))return NVM_FILE_FLOW_INVALID;
                if(fact->body.has_obligation && fact->body.obligation.kind==NVM_FILE_FLOW_CALL) {
                    uint32_t staging=(uint32_t)fact->body.obligation.parameters+1u+(isa_is_file_indirect_call(in->decoded.opcode));
                    if(staging>256u +2u)return NVM_FILE_FLOW_INVALID;
                    if(staging>fn->staging_slots)fn->staging_slots=(uint16_t)staging;
                }
            }
        }
        if(fn->declared_stack && fn->declared_stack<fn->operand_peak)return NVM_FILE_FLOW_INVALID;
        uint64_t frame=(uint64_t)fn->locals+fn->operand_peak+fn->staging_slots;
        fn->vm_value_slots=fn->native_value_slots=frame;
        for(uint16_t i=0;i<fn->code.instruction_count;i++) {
            const FileCyclicSite *site=file_cyclic_site(p->query->ownership,f,i);
            for(uint8_t v=0;v<site->count;v++) {
                const NvmFileBodyInstruction *body=&site->nodes[v]->fact.body;
                if(!body->has_obligation || body->obligation.kind!=NVM_FILE_FLOW_CALL)continue;
                const NvmFileFlowObligation *call=&body->obligation;
                
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
               _Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                    indirect=isa_is_file_indirect_call(code->instructions[code->starts[f]+i].decoded.opcode);
                uint64_t candidates=indirect?p->targets[code->starts[f]+i]:
                    (call->target<code->count?1UL<<call->target:0);
                if(!candidates || call->borrowed_inputs>call->parameters ||
                   (indirect && call->target!=0xFFFFFFFFu))return NVM_FILE_FLOW_INVALID;
                uint32_t consumed=(uint32_t)call->parameters-call->borrowed_inputs+(unsigned)indirect;
                if(consumed>body->input_stack)return NVM_FILE_FLOW_INVALID;
                for(uint32_t target=0;target<code->count;target++)if(candidates&(1UL<<target)) {
                    if(!checked[target])return NVM_FILE_FLOW_INVALID;
                    const NvmFileIndirectHostedFunction *callee=&p->functions[target];
                    uint64_t vm=(uint64_t)fn->locals+body->input_stack-consumed+fn->staging_slots+callee->vm_value_slots;
                    uint64_t native=frame+callee->native_value_slots;
                    if(vm>fn->vm_value_slots)fn->vm_value_slots=vm;
                    if(native>fn->native_value_slots)fn->native_value_slots=native;
                    if((uint32_t)callee->frames+1>fn->frames)fn->frames=(uint16_t)(callee->frames+1);
                }
            }
        }
        fn->reference_slots=(uint32_t)fn->frames*256u;
        fn->region_slots=(uint32_t)fn->frames*256u;
        if(fn->frames>64u || fn->vm_value_slots>64UL*770 ||
           fn->native_value_slots>64UL*770)return NVM_FILE_FLOW_LIMIT;
        checked[f]=
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                  1
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                      ;
    }
    uint32_t roots[2]={p->startup.entry,p->startup.initializer};
    for(unsigned i=0;i<2;i++)if(roots[i]!=0xFFFFFFFFu) {
        const NvmFileIndirectHostedFunction *fn=&p->functions[roots[i]];
        if(fn->vm_value_slots>p->startup.vm_value_slots)p->startup.vm_value_slots=fn->vm_value_slots;
        if(fn->native_value_slots>p->startup.native_value_slots)p->startup.native_value_slots=fn->native_value_slots;
        if(fn->frames>p->startup.frames)p->startup.frames=fn->frames;
        if(fn->reference_slots>p->startup.reference_slots)p->startup.reference_slots=fn->reference_slots;
        if(fn->region_slots>p->startup.region_slots)p->startup.region_slots=fn->region_slots;
    }
    return NVM_FILE_FLOW_OK;
}
void nvm_file_indirect_hosted_free(NvmFileIndirectHostedPlan *p) {
    if(p){nvm_file_indirect_flow_free(p->query);free(p->bytes);free(p);}
}
NvmFileFlowStatus nvm_file_indirect_hosted_prepare(const uint8_t *data,size_t size,NvmFileIndirectHostedPlan **out) {
    if(!out)return NVM_FILE_FLOW_INVALID;
    NvmV2Header header;size_t bound;
    NvmFileFlowStatus status=file_hosted_preflight(data,size,&header,&bound);
    if(status!=NVM_FILE_FLOW_OK)return status;



    if(bound<(16u * 1024u * 1024u))return NVM_FILE_FLOW_INVALID;
    bound-=(16u * 1024u * 1024u);
    if(!file_hosted_add(&bound,1,(32u * 1024u * 1024u)) ||
       !file_hosted_add(&bound,1,sizeof(NvmFileIndirectHostedPlan)))return NVM_FILE_FLOW_LIMIT;
    uint8_t *copy=malloc(size);if(!copy)return NVM_FILE_FLOW_MEMORY;
    memcpy(copy,data,size);
    NvmV2Module wire={0};NvmModule *module=
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                          ((void *)0)
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                              ;NvmFileIndirectHostedPlan *plan=
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                      ((void *)0)
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                          ;
    NvmV2Result decoded=nvm_v2_module_deserialize(copy,size,&wire);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}
    decoded=nvm_v2_to_nvm_module(&wire,&module);
    if(decoded!=NVM_V2_OK){status=file_hosted_codec_status(decoded);goto done;}
    if(!module || module->code_size!=wire.code_size || !module->code ||
       memcmp(module->code,wire.code,wire.code_size)) {
        status=NVM_FILE_FLOW_UNRESOLVED;goto done;
    }
    plan=calloc(1,sizeof *plan);if(!plan){status=NVM_FILE_FLOW_MEMORY;goto done;}
    plan->startup.revision=1u;
    plan->startup.features=header.feature_bits;plan->startup.input_bytes=size;plan->startup.allocation_bound=bound;
    status=nvm_file_indirect_flow_analyze(module,&plan->query);if(status!=NVM_FILE_FLOW_OK)goto done;
    if(plan->query->summary.ownership.revision!=1u || plan->query->summary.runtime_admitted || plan->query->summary.ownership.runtime_admitted ||
       plan->query->summary.storage_bound>(32u * 1024u * 1024u)){status=NVM_FILE_FLOW_INVALID;goto done;}
    plan->startup.query_storage_peak=plan->query->summary.storage_bound;
    size_t retained=sizeof *plan;
    if(!file_hosted_add(&retained,size,1) || !file_hosted_add(&retained,1,plan->startup.query_storage_peak) ||
       retained>bound){status=NVM_FILE_FLOW_LIMIT;goto done;}
    plan->startup.retained_bound=retained;
    if(!file_ih_target_map(plan)){status=NVM_FILE_FLOW_INVALID;goto done;}
    status=file_ih_start(plan,&wire,module);if(status!=NVM_FILE_FLOW_OK)goto done;
    status=file_ih_bounds(plan,&wire);if(status!=NVM_FILE_FLOW_OK)goto done;
    plan->bytes=copy;copy=
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                         ((void *)0)
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                             ;*out=plan;plan=
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                             ((void *)0)
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                 ;
done:
    nvm_file_indirect_hosted_free(plan);nvm_module_free(module);nvm_v2_module_free(&wire);free(copy);return status;
}

# 204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_query_summary(const NvmFileIndirectHostedPlan *p,NvmFileIndirectFlowSummary *out) {
    return p && nvm_file_indirect_flow_summary(p->query,out);
}

# 207 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 207 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_startup(const NvmFileIndirectHostedPlan *p,NvmFileIndirectHostedStartup *out) {
    if(!p || !out)return 
# 208 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                        0
# 208 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                             ;
    *out=p->startup;return 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                          1
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                              ;
}

# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_function(const NvmFileIndirectHostedPlan *p,uint32_t f,NvmFileIndirectHostedFunction *out) {
    if(!p || !out || f>=p->startup.functions)return 
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                   0
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                        ;
    *out=p->functions[f];return 
# 213 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                               1
# 213 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                   ;
}

# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_function_order(const NvmFileIndirectHostedPlan *p,uint32_t rank,uint32_t *out) {
    return p && nvm_file_code_function_order(p->query->ownership->plan,rank,out);
}

# 218 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 218 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_local(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t l,NvmFileFlowDeclaration *out) {
    return p && nvm_file_indirect_flow_local(p->query,f,l,out);
}

# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_instruction(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,NvmFileCodeInstruction *out) {
    return p && nvm_file_indirect_flow_instruction(p->query,f,i,out);
}

# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_component(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint16_t *out) {
    return p && nvm_file_indirect_flow_component(p->query,f,i,out);
}

# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_variant_count(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t *out) {
    return p && nvm_file_indirect_flow_variant_count(p->query,f,i,out);
}

# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_variant(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,NvmFileCyclicVariant *out) {
    return p && nvm_file_indirect_flow_variant(p->query,f,i,v,out);
}

# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_input_local(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t l,NvmFileFlowValue *out) {
    return p && nvm_file_indirect_flow_input_local(p->query,f,i,v,l,out);
}

# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_input_stack(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t s,NvmFileFlowValue *out) {
    return p && nvm_file_indirect_flow_input_stack(p->query,f,i,v,s,out);
}

# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_input_reference(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t ref,NvmFileFlowReference *out) {
    return p && nvm_file_indirect_flow_input_reference(p->query,f,i,v,ref,out);
}

# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_input_region(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,uint16_t region,uint64_t *out) {
    return p && nvm_file_indirect_flow_input_region(p->query,f,i,v,region,out);
}

# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_type(const NvmFileIndirectHostedPlan *p,uint32_t ordinal,NvmFileNominalLayout *out) {
    return p && nvm_file_indirect_flow_type(p->query,ordinal,out);
}

# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 248 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_import(const NvmFileIndirectHostedPlan *p,uint32_t ordinal,uint32_t *out) {
    return p && nvm_file_indirect_flow_import(p->query,ordinal,out);
}

# 251 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 251 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_bytes(const NvmFileIndirectHostedPlan *p,size_t offset,void *out,size_t count) {
    if(!p || (count && !out) || offset>p->startup.input_bytes || count>p->startup.input_bytes-offset)return 
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                           0
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                                ;
    if(count)memcpy(out,p->bytes+offset,count);
    return 
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          1
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
              ;
}

# 256 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 256 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_call(const NvmFileIndirectHostedPlan *p,uint32_t f,uint16_t i,uint8_t v,NvmFileIndirectFlowCall *out) {
    if(!p || !out || f>=p->startup.functions || i>=p->functions[f].code.instruction_count)return 
# 257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                                0
# 257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                     ;
    NvmFileCyclicVariant variant;
    uint32_t index=p->query->ownership->plan->starts[f]+i;
    if(!p->targets[index] || !nvm_file_indirect_flow_variant(p->query,f,i,v,&variant))return 
# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                               0
# 260 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                    ;
    *out=(NvmFileIndirectFlowCall){f,p->query->ownership->plan->instructions[index].byte_offset,
        p->targets[index],p->targets[index],variant.body.obligation};
    return 
# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          1
# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
              ;
}




# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
_Bool 
# 268 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
    nvm_file_indirect_hosted_string(const NvmFileIndirectHostedPlan *p,
    uint32_t index,const uint8_t **out,size_t *length) {
    if(!p || !out || !length)return 
# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                   0
# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                        ;
    NvmV2Header h;
    if(nvm_v2_read_header(p->bytes,p->startup.input_bytes,&h)!=NVM_V2_OK)return 
# 272 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                               0
# 272 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                    ;
    for(uint32_t section=0;section<h.section_count;section++) {
        NvmV2SectionEntry e;
        if(nvm_v2_read_section(p->bytes,p->startup.input_bytes,&h,section,&e)!=NVM_V2_OK)return 
# 275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                               0
# 275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                                    ;
        if(e.type!=NVM_V2_SECTION_CONSTANTS)continue;
        NvmV2Cursor c;nvm_v2_cursor_init(&c,p->bytes+e.offset,(size_t)e.size);
        uint32_t count;if(nvm_v2_u32(&c,&count)!=NVM_V2_OK || index>=count)return 
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                                                 0
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                                                      ;
        for(uint32_t i=0;i<=index;i++) {
            uint8_t tag,pad;uint16_t pad2;uint32_t size;const uint8_t *bytes;
            if(nvm_v2_u8(&c,&tag)!=NVM_V2_OK || nvm_v2_u8(&c,&pad)!=NVM_V2_OK ||
               nvm_v2_u16(&c,&pad2)!=NVM_V2_OK || nvm_v2_u32(&c,&size)!=NVM_V2_OK ||
               tag!=TAG_STRING || pad || pad2 || nvm_v2_take(&c,size,&bytes)!=NVM_V2_OK ||
               nvm_v2_align4(&c)!=NVM_V2_OK)return 
# 284 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                  0
# 284 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                       ;
            if(i==index){*out=bytes;*length=size;return 
# 285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
                                                       1
# 285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
                                                           ;}
        }
    }
    return 
# 288 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc" 3 4
          0
# 288 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_indirect_hosted.inc"
               ;
}
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_indirect_hosted.inc" 2
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/file_flow.c" 2
