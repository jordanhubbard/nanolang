nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_bytecode.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_bytecode.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_state.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/ownership_contracts.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/reference_places.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_global_flow.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/isa.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/generated_schema.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h \
 /usr/include/stdio.h /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_array_flow.inc \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/affine_effect_globals.inc \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/value.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/heap.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../runtime/nl_string.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_dispatch.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/ownership_contracts.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h \
 /home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../runtime/nano_callback.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/sched.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/aarch64-linux-gnu/bits/cpu-set.h /usr/include/time.h \
 /usr/include/aarch64-linux-gnu/bits/time.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/aarch64-linux-gnu/bits/setjmp.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h
