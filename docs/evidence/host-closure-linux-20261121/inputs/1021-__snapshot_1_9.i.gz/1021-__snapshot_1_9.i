# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 30 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"

# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2







typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 1
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 2




typedef struct {
    
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
        ok;
    char error_msg[256];
} NvmVerifyResult;
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify(const NvmModule *mod);







typedef enum {
    NVM_PROFILE_GENERAL = 0,
    NVM_PROFILE_CLOSED_SCALAR = 1,
    NVM_PROFILE_CLOSED_LITERAL_STRINGS = 2,
    NVM_PROFILE_CLOSED_MANAGED_STRINGS = 3,


    NVM_PROFILE_PORTABLE_FILE_READ = 5,
    NVM_PROFILE_PORTABLE_READ_TEXT = 4
} NvmVerifyProfile;
NvmVerifyResult nvm_verify_profile(const NvmModule *mod, NvmVerifyProfile profile);



NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod);



# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
    nvm_uses_owned_transfers(const NvmModule *mod);



NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx);


NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx);
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_function_types(const NvmModule *mod, uint32_t fn_idx,
                                          const VmDecodedFunction *decoded,
                                          uint16_t max_depth,
                                          char *error, size_t error_size);

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack);





NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count);
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count);
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h" 1






# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h"
    nvm_passive_valid(const NvmModule *module);
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 1







# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h"
    nvm_layouts_have_facts(const NvmV2Layouts *layouts);



# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h"
    nvm_retained_layouts_valid(const NvmModule *module);


NvmV2Result nvm_retain_layouts(NvmModule *module, const NvmV2Layouts *layouts);
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[8u];
} NvmFileNominalBindings;
NvmServiceResult nvm_file_nominal_check(const NvmFileNominalBindings *);

NvmServiceResult nvm_file_nominal_decode(const uint8_t *,size_t,NvmFileNominalBindings *);


NvmServiceResult nvm_file_nominal_encode(const NvmFileNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_FILE_NOMINAL_DESCRIBED, NVM_FILE_NOMINAL_INVALID,
    NVM_FILE_NOMINAL_LIMIT, NVM_FILE_NOMINAL_MEMORY
} NvmFileNominalStatus;
typedef enum {
    NVM_FILE_CATEGORY_UNKNOWN, NVM_FILE_CATEGORY_FILE,
    NVM_FILE_CATEGORY_OPEN_RESULT, NVM_FILE_CATEGORY_SCALAR_RESULT,
    NVM_FILE_CATEGORY_RECORD
} NvmFileCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmFileCategory category;
} NvmFileNominalLayout;
typedef struct NvmFileNominalPlan NvmFileNominalPlan;




NvmFileNominalStatus nvm_file_nominal_plan(const NvmModule *,NvmFileNominalPlan **);
void nvm_file_nominal_plan_free(NvmFileNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_file_nominal_layout_count(const NvmFileNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_layout(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_type(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_source(const NvmFileNominalPlan *,uint8_t,uint32_t,NvmFileNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_import(const NvmFileNominalPlan *,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[9u];
} NvmSocketNominalBindings;
NvmServiceResult nvm_socket_nominal_check(const NvmSocketNominalBindings *);

NvmServiceResult nvm_socket_nominal_decode(const uint8_t *,size_t,NvmSocketNominalBindings *);


NvmServiceResult nvm_socket_nominal_encode(const NvmSocketNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_SOCKET_NOMINAL_DESCRIBED, NVM_SOCKET_NOMINAL_INVALID,
    NVM_SOCKET_NOMINAL_LIMIT, NVM_SOCKET_NOMINAL_MEMORY
} NvmSocketNominalStatus;
typedef enum {
    NVM_SOCKET_CATEGORY_UNKNOWN, NVM_SOCKET_CATEGORY_CONN,
    NVM_SOCKET_CATEGORY_CONNECT_RESULT, NVM_SOCKET_CATEGORY_SCALAR_RESULT,
    NVM_SOCKET_CATEGORY_RECORD
} NvmSocketCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmSocketCategory category;
} NvmSocketNominalLayout;
typedef struct NvmSocketNominalPlan NvmSocketNominalPlan;




NvmSocketNominalStatus nvm_socket_nominal_plan(const NvmModule *,NvmSocketNominalPlan **);
void nvm_socket_nominal_plan_free(NvmSocketNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_socket_nominal_layout_count(const NvmSocketNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_layout(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_type(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_source(const NvmSocketNominalPlan *,uint8_t,uint32_t,NvmSocketNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_import(const NvmSocketNominalPlan *,uint32_t,uint32_t *);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
typedef struct {
    uint32_t catalog;
    uint32_t imports[5], layouts[9];
} NvmServiceInstance;
typedef struct {
    uint32_t count;
    NvmServiceInstance instances[64u];
} NvmMultiNominalBindings;






uint32_t nvm_multi_nominal_catalog_types(uint32_t catalog);
uint32_t nvm_multi_nominal_catalog_methods(uint32_t catalog);
NvmServiceResult nvm_multi_nominal_check(const NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_decode(const uint8_t *,size_t,NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_encode(const NvmMultiNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum { NVM_MULTI_NOMINAL_DESCRIBED, NVM_MULTI_NOMINAL_INVALID,
    NVM_MULTI_NOMINAL_LIMIT, NVM_MULTI_NOMINAL_MEMORY } NvmMultiNominalStatus;
typedef struct {
    uint32_t global_index, instance, catalog, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
} NvmMultiNominalLayout;
typedef struct NvmMultiNominalPlan NvmMultiNominalPlan;


NvmMultiNominalStatus nvm_multi_nominal_plan(const NvmModule *,NvmMultiNominalPlan **);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_storage_bound(uint32_t,size_t *);
uint32_t nvm_multi_nominal_layout_count(const NvmMultiNominalPlan *);
void nvm_multi_nominal_plan_free(NvmMultiNominalPlan *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_layout(const NvmMultiNominalPlan *,uint32_t,NvmMultiNominalLayout *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_type(const NvmMultiNominalPlan *,uint32_t,uint32_t,NvmMultiNominalLayout *);

# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_import(const NvmMultiNominalPlan *,uint32_t,uint32_t,uint32_t *);
uint32_t nvm_multi_nominal_instance_count(const NvmMultiNominalPlan *);
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 2




typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_socket_plan_free(NlSocketPlan *);
size_t nl_socket_plan_storage_size(void);
const char *nl_socket_plan_interface(const NlSocketPlan *);
size_t nl_socket_plan_method_count(const NlSocketPlan *);
size_t nl_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_socket_catalog_interface(void);
const NlServicePlanMethod *nl_socket_catalog_method(size_t);
const NlServicePlanType *nl_socket_catalog_type(size_t);
# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1






typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2




# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_bindings_present(const NvmModule *);

# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_service_bindings_present(const NvmV2Module *);



# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_file_instructions_present(const NvmModule *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_file_instructions_present(const NvmV2Module *);


# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_execution_pending(const NvmModule *);


NvmV2Result nvm_service_bindings_validate(const NvmModule *);
NvmV2Result nvm_v2_service_bindings_validate(const NvmV2Module *);



NvmV2Result nvm_service_bindings_attach(NvmModule *, const NlFilePlan *,
                                       const NvmServiceBindings *);


NvmV2Result nvm_file_nominal_attach(NvmModule *,const NlFilePlan *,
                                   const NvmFileNominalBindings *);

NvmV2Result nvm_socket_nominal_attach(NvmModule *,const NlSocketPlan *,const NvmSocketNominalBindings *);
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_codec_internal.h" 1






typedef struct {
    NvmV2Result (*module)(const NvmModule *);
    NvmV2Result (*wire)(const NvmV2Module *);
    uint32_t service_bytes;
} NvmPrivateServiceCodec;
static inline NvmV2Result nvm_private_service_module(const NvmModule *m,const NvmPrivateServiceCodec *c) {
    return c?(c->module && c->wire && c->service_bytes?c->module(m):NVM_V2_ERR_SECTION_TYPE):nvm_service_bindings_validate(m);
}
static inline NvmV2Result nvm_private_service_wire(const NvmV2Module *m,const NvmPrivateServiceCodec *c) {
    return c?(c->module && c->wire && c->service_bytes?c->wire(m):NVM_V2_ERR_SECTION_TYPE):nvm_v2_service_bindings_validate(m);
}
NvmV2Result nvm_private_nominal_wire(const NvmV2Module *,uint32_t minimum_imports,uint32_t minimum_layouts,
    NvmV2Result (*validate)(const NvmModule *));
NvmV2Result nvm_private_from_module(const NvmModule *,NvmV2Module *,const NvmPrivateServiceCodec *);
NvmV2Result nvm_private_to_module(const NvmV2Module *,NvmModule **,const NvmPrivateServiceCodec *);
NvmV2Result nvm_private_serialize(const NvmV2Module *,uint8_t *,size_t,size_t *,const NvmPrivateServiceCodec *);
NvmV2Result nvm_private_deserialize(const uint8_t *,size_t,NvmV2Module *,const NvmPrivateServiceCodec *);
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_layout_view.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_plan.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_plan.h"
typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_layout_view.h" 2


typedef enum {
    NVM_MIXED_UNKNOWN, NVM_MIXED_RESOURCE,
    NVM_MIXED_ORDINARY_STRUCTURAL, NVM_MIXED_PENDING_ARRAY_PROOF
} NvmMixedLayoutClass;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count, managed_count;
    uint32_t source_to_global[256u];
    uint32_t global_to_source[256u];
    uint32_t managed_to_global[256u];
    uint32_t global_to_managed[256u];
    NvmMixedLayoutClass classes[256u];
    uint8_t *ownership;
    uint32_t ownership_size;
} NvmMixedLayoutView;

NvmRecordPlanResult nvm_describe_mixed_layouts(const NvmModule *, NvmMixedLayoutView **);
void nvm_mixed_layout_view_free(NvmMixedLayoutView *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 2




typedef enum {
    NVM_MIXED_SHAPE_PROVED, NVM_MIXED_SHAPE_UNRESOLVED,
    NVM_MIXED_SHAPE_INVALID, NVM_MIXED_SHAPE_LIMIT, NVM_MIXED_SHAPE_MEMORY
} NvmMixedShapeStatus;
typedef struct {
    NvmMixedShapeStatus status;
    uint32_t function, pc;
    const char *message;
} NvmMixedShapeResult;
typedef struct {
    uint16_t tags;
    uint64_t origins;
} NvmMixedFieldFact;
typedef struct {
    uint32_t function, pc, global_layout, source_record, field_start;
    uint16_t field_count;
    uint8_t tag;
} NvmMixedFloatOrigin;
typedef struct {
    uint32_t function, pc;
    uint16_t read_tags;
    uint16_t required_tags, actual_tags;
} NvmMixedScalarObligation;
typedef struct {
    NvmMixedLayoutView *view;
    uint32_t origin_count, field_count, obligation_count, checked_writes;
    
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 3 4
   _Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h"
        requires_affine_verification;
    NvmMixedFloatOrigin origins[64u];
    NvmMixedFieldFact *fields;
    NvmMixedScalarObligation obligations[4096u];
} NvmMixedFloatProof;


NvmMixedShapeResult nvm_analyze_mixed_float_origins(const NvmModule *, NvmMixedFloatProof **);
void nvm_mixed_float_proof_free(NvmMixedFloatProof *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 2

typedef enum { NVM_MIXED_CHECK_FLOAT, NVM_MIXED_COMPARE_VALUE } NvmMixedScalarPolicy;
typedef struct {
    uint32_t function, pc;
    uint16_t operand, actual_tags, required_tags;
    NvmMixedScalarPolicy policy;
} NvmMixedScalarCheck;
typedef struct {
    NvmMixedFloatProof *shape;
    uint32_t checked_functions, checked_instructions, visits, check_count;
    uint16_t max_stack[8];
    uint32_t managed_count;
    uint32_t global_to_managed[256u];
    uint32_t managed_to_global[256u];
    NvmMixedScalarCheck checks[(2u * 4096u)];
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h"
        affine_checked;
    
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h"
        runtime_admitted;
} NvmMixedSamplesProof;




NvmMixedShapeResult nvm_analyze_mixed_samples(const NvmModule *, NvmMixedSamplesProof **);
void nvm_mixed_samples_proof_free(NvmMixedSamplesProof *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 2




typedef struct NvmMixedSamplesPlan NvmMixedSamplesPlan;
typedef enum {
    NVM_MIXED_VALUE_UNAVAILABLE, NVM_MIXED_VALUE_SCALAR,
    NVM_MIXED_VALUE_OWNER, NVM_MIXED_VALUE_ORDINARY
} NvmMixedValueCategory;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_layout;
    NvmMixedValueCategory category;
} NvmMixedDeclaration;
typedef struct {
    uint16_t parameter_count, local_count, max_stack;
    NvmMixedDeclaration parameters[8], result;
    uint16_t result_fields;
} NvmMixedSignature;
typedef struct {
    uint32_t source_record, global_layout, managed_record, field_count;
} NvmMixedRecordIdentity;
typedef struct {
    const uint8_t *layouts, *ownership;
    uint32_t layout_size, ownership_size;
} NvmMixedTransport;





# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_candidate(const NvmModule *);



NvmMixedShapeResult nvm_mixed_samples_admit(const NvmModule *, NvmMixedSamplesPlan **out);
NvmMixedShapeResult nvm_mixed_samples_prepare(const NvmModule *, NvmMixedSamplesPlan **out);
void nvm_mixed_samples_plan_free(NvmMixedSamplesPlan *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_signature(const NvmMixedSamplesPlan *, uint32_t function,
                                 NvmMixedSignature *out);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_local(const NvmMixedSamplesPlan *, uint32_t function,
                             uint16_t local, NvmMixedDeclaration *out);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_record(const NvmMixedSamplesPlan *, uint32_t source_record,
                              NvmMixedRecordIdentity *out);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_transport(const NvmMixedSamplesPlan *, NvmMixedTransport *out);

const NvmMixedSamplesProof *nvm_mixed_samples_obligations(const NvmMixedSamplesPlan *);
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
typedef struct NvmOwnedArrayLayouts NvmOwnedArrayLayouts;
typedef struct {
    uint32_t layouts, source_records, managed_records, leaf_paths;
} NvmOwnedArrayLayoutCounts;
typedef struct {
    uint32_t global_layout, source_record, managed_record, field_count;
    uint32_t path_start, path_count;
    uint8_t flags, owner_depth;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
        has_array, has_string, whole_root_borrow_unsuitable;
} NvmOwnedArrayLayoutFact;
typedef struct {
    uint32_t root_layout, terminal_layout;
    uint16_t length;
    uint8_t tag;
    uint16_t fields[32u];
} NvmOwnedArrayLeafPath;
typedef struct {
    const uint8_t *layouts, *ownership;
    uint32_t layout_size, ownership_size;
} NvmOwnedArrayTransport;



NvmRecordPlanResult nvm_describe_owned_array_layouts(const NvmModule *, NvmOwnedArrayLayouts **out);
void nvm_owned_array_layouts_free(NvmOwnedArrayLayouts *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_counts(const NvmOwnedArrayLayouts *, NvmOwnedArrayLayoutCounts *out);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_fact(const NvmOwnedArrayLayouts *, uint32_t global, NvmOwnedArrayLayoutFact *out);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_source_layout(const NvmOwnedArrayLayouts *, uint32_t source, uint32_t *out_global);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_managed_layout(const NvmOwnedArrayLayouts *, uint32_t managed, uint32_t *out_global);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_leaf_path(const NvmOwnedArrayLayouts *, uint32_t path, NvmOwnedArrayLeafPath *out);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_field(const NvmOwnedArrayLayouts *, uint32_t global, uint16_t field, NvmV2LayoutField *out);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_transport(const NvmOwnedArrayLayouts *, NvmOwnedArrayTransport *out);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 2



typedef struct NvmOwnedArrayOrigins NvmOwnedArrayOrigins;
typedef enum { NVM_OWNER_ORIGIN_PROVED, NVM_OWNER_ORIGIN_UNRESOLVED,
    NVM_OWNER_ORIGIN_INVALID, NVM_OWNER_ORIGIN_LIMIT, NVM_OWNER_ORIGIN_MEMORY
} NvmOwnerOriginStatus;
typedef struct { NvmOwnerOriginStatus status; uint32_t function, pc; const char *message; } NvmOwnerOriginResult;
typedef struct { uint64_t words[5u]; } NvmOwnerOriginSet;
typedef struct { uint32_t function, pc; uint8_t opcode; } NvmOwnerOriginSite;
typedef struct { uint16_t ordinal; NvmOwnedArrayLeafPath path; NvmOwnerOriginSet origins; } NvmOwnerOriginPath;
typedef struct {
    uint32_t formal_count, result_count;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
        reachable, conditional;
    NvmOwnerOriginSet required;
} NvmOwnerOriginSummary;
typedef struct { uint32_t functions, sites, obligations; } NvmOwnerOriginCounts;
typedef struct {
    uint32_t function, pc;
    uint16_t actual_tags, required_tags, read_tags;

    uint16_t operand_actual[2], operand_required[2];
    uint8_t opcode, operand_count, runtime_checks;
} NvmOwnerOriginObligation;


NvmOwnerOriginResult nvm_analyze_owned_array_origins(const NvmModule *, NvmOwnedArrayOrigins **);
void nvm_owned_array_origins_free(NvmOwnedArrayOrigins *);

# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_counts(const NvmOwnedArrayOrigins *, NvmOwnerOriginCounts *);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_site(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSite *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_summary(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSummary *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_input(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_result(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_obligation(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 2

typedef struct NvmOwnedArrayPlan NvmOwnedArrayPlan;
typedef enum { NVM_OWNER_AUTH_PREPARED, NVM_OWNER_AUTH_UNRESOLVED,
    NVM_OWNER_AUTH_INVALID, NVM_OWNER_AUTH_LIMIT, NVM_OWNER_AUTH_MEMORY
} NvmOwnerAuthorityStatus;
typedef struct { NvmOwnerAuthorityStatus status; uint32_t function, pc; const char *message; } NvmOwnerAuthorityResult;
typedef struct { uint8_t tag, mode; uint32_t global_layout; 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
                                                           _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
                                                                owner; } NvmOwnerDeclaration;
typedef struct {
    uint16_t local_count, parameter_count, max_stack, result_fields;
    NvmOwnerDeclaration result, parameters[8];
} NvmOwnerSignature;
typedef struct { uint32_t functions, instructions, persisted_cells, visits, work; } NvmOwnerAuthorityCounts;


NvmOwnerAuthorityResult nvm_prepare_owned_array_authority(const NvmModule *, NvmOwnedArrayPlan **);
void nvm_owned_array_plan_free(NvmOwnedArrayPlan *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_counts(const NvmOwnedArrayPlan *, NvmOwnerAuthorityCounts *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_signature(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerSignature *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_local(const NvmOwnedArrayPlan *, uint32_t, uint16_t, NvmOwnerDeclaration *);

# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_layout(const NvmOwnedArrayPlan *, uint32_t, NvmOwnedArrayLayoutFact *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_source(const NvmOwnedArrayPlan *, uint32_t, uint32_t *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_transport(const NvmOwnedArrayPlan *, NvmOwnedArrayTransport *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_obligation(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admission.h" 2


typedef enum { NVM_OWNER_ARRAY_NOT_SELECTED, NVM_OWNER_ARRAY_SELECTED,
    NVM_OWNER_ARRAY_INVALID } NvmOwnedArrayRoute;
NvmOwnedArrayRoute nvm_owned_array_route(const NvmModule *);



NvmOwnerAuthorityResult nvm_owned_array_admit(const NvmModule *, NvmOwnedArrayPlan **out);
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_array_shapes.h" 1






typedef enum {
    NVM_ARRAY_ELIGIBLE, NVM_ARRAY_UNRESOLVED, NVM_ARRAY_INVALID,
    NVM_ARRAY_LIMIT, NVM_ARRAY_MEMORY
} NvmArrayEligibilityStatus;
typedef struct {
    uint32_t function, pc;
    uint16_t child_tags;
    uint8_t declared_tag, packed;
} NvmArrayOrigin;
typedef struct {
    uint32_t origin_count, checked_writes;

    uint32_t runtime_tag_checks;
    NvmArrayOrigin origins[64];
} NvmArrayEligibilityReport;

typedef struct {
    NvmArrayEligibilityReport arrays;
    uint64_t child_origins[64];
    uint8_t child_unknown[64];
} NvmArrayGraphEligibilityReport;
typedef struct {
    NvmArrayEligibilityStatus status;
    uint32_t function, pc;
    char message[192];
} NvmArrayEligibilityResult;

NvmArrayEligibilityResult nvm_analyze_managed_arrays(
    const NvmModule *module, NvmArrayEligibilityReport **out);
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report);

NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(
    const NvmModule *module, NvmArrayGraphEligibilityReport **out);
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report);



NvmArrayEligibilityResult nvm_select_managed_array_mode(
    const NvmModule *module, int *graph_required);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 2



typedef struct {
    uint64_t origins;
    uint16_t tags;
    uint8_t unknown;
} NvmRecordValueOrigins;
typedef enum { NVM_HEAP_ORIGIN_ARRAY, NVM_HEAP_ORIGIN_RECORD } NvmHeapOriginKind;
typedef struct {
    uint32_t function, pc;
    uint32_t record_ordinal, layout_index, field_start;
    uint16_t field_count;
    uint8_t kind, declared_tag, packed;
    NvmRecordValueOrigins children;
} NvmRecordHeapOrigin;
typedef struct {
    uint32_t origin_count, field_value_count, checked_field_writes;
    uint32_t checked_array_writes, runtime_tag_checks;
    NvmRecordHeapOrigin origins[64];
    NvmRecordValueOrigins *fields;
} NvmRecordEligibilityReport;



NvmArrayEligibilityResult nvm_analyze_managed_records(
    const NvmModule *module, NvmRecordEligibilityReport **out);
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report);


typedef enum { NVM_MANAGED_LEAF, NVM_MANAGED_ARRAY_GRAPH, NVM_MANAGED_RECORD } NvmManagedHeapMode;
typedef struct {
    NvmManagedHeapMode mode;
    NvmRecordPlan *records;
    NvmRecordEligibilityReport *fields;
} NvmManagedHeapPlan;
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *, int mutable_arrays,
                                                 NvmManagedHeapPlan **out);
void nvm_managed_heap_plan_free(NvmManagedHeapPlan *);
NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *, NvmManagedHeapPlan **);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 1






typedef struct NvmOrdinaryArrayAuthority NvmOrdinaryArrayAuthority;
typedef enum { NVM_OAA_DESCRIBED, NVM_OAA_UNKNOWN, NVM_OAA_INVALID,
               NVM_OAA_LIMIT, NVM_OAA_MEMORY } NvmOrdinaryArrayStatus;
typedef struct { NvmOrdinaryArrayStatus status; uint32_t layout, field;
                 const char *message; } NvmOrdinaryArrayResult;
typedef struct { uint32_t layouts, types, bindings; } NvmOrdinaryArrayCounts;
typedef struct { uint8_t tag; uint32_t referent; } NvmOrdinaryArrayType;
typedef struct { uint32_t layout; uint16_t field; uint32_t element_type; } NvmOrdinaryArrayBinding;
NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(const NvmModule *, NvmOrdinaryArrayAuthority **);
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *, NvmOrdinaryArrayCounts *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayType *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayBinding *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 2





typedef struct NvmOwnershipDeclarationPlan NvmOwnershipDeclarationPlan;
typedef enum {
    NVM_DECL_PREPARED, NVM_DECL_UNKNOWN, NVM_DECL_INVALID,
    NVM_DECL_LIMIT, NVM_DECL_MEMORY
} NvmDeclarationStatus;
typedef struct { NvmDeclarationStatus status; const char *message; } NvmDeclarationResult;
typedef struct { uint32_t layouts, types, bindings, unions, variants; } NvmDeclarationCounts;
typedef struct { uint8_t kind, flags; uint16_t fields; uint32_t name; } NvmDeclarationLayout;
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *,NvmOwnershipDeclarationPlan **);
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *,NvmDeclarationCounts *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *,uint32_t,NvmDeclarationLayout *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayType *);

# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 2


typedef struct NvmRecordArrayOrigins NvmRecordArrayOrigins;
typedef struct {
    uint32_t origins, fields, checked_field_writes, checked_array_writes, runtime_tag_checks;
    uint64_t work_reserved, peak_bytes_reserved;
} NvmRecordArrayOriginCounts;
NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *,NvmRecordArrayOrigins **);
void nvm_record_array_origins_free(NvmRecordArrayOrigins *);

# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *,NvmRecordArrayOriginCounts *);

# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origin(const NvmRecordArrayOrigins *,uint32_t,NvmRecordHeapOrigin *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *,uint32_t,NvmRecordValueOrigins *);
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
static inline uint16_t nvm_record_array_requirement(uint8_t depth,uint8_t leaf) {
    if(leaf<TAG_INT || leaf>TAG_STRING)return 0;
    if(depth==1)return (uint16_t)(1u<<leaf);
    if(depth==2) {
        switch(leaf) {
        case TAG_INT:return ((uint16_t)(1u << TAG_ARRAY));
        case TAG_U8:return ((uint16_t)(1u << 9));
        case TAG_FLOAT:return ((uint16_t)(1u << 10));
        case TAG_BOOL:return ((uint16_t)(1u << 11));
        case TAG_STRING:return ((uint16_t)(1u << 8));
        }
    }
    if(depth==3)return leaf==TAG_STRING?((uint16_t)(1u << 6)):(uint16_t)(1u<<(11u+leaf));
    return 0;
}
static inline uint8_t nvm_record_array_requirement_depth(uint16_t requirement) {
    for(uint8_t depth=1;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(requirement==nvm_record_array_requirement(depth,leaf))return depth;
    return 0;
}

static inline uint8_t nvm_record_array_requirement_leaf(uint16_t requirement) {
    switch(requirement) {
    case ((uint16_t)(1u << 12)):case ((uint16_t)(1u << TAG_ARRAY)):return TAG_INT;
    case ((uint16_t)(1u << 13)):case ((uint16_t)(1u << 9)):return TAG_U8;
    case ((uint16_t)(1u << 14)):case ((uint16_t)(1u << 10)):return TAG_FLOAT;
    case ((uint16_t)(1u << 15)):case ((uint16_t)(1u << 11)):return TAG_BOOL;
    case ((uint16_t)(1u << 6)):case ((uint16_t)(1u << 8)):return TAG_STRING;
    default:return TAG_VOID;
    }
}

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *,uint32_t,uint16_t *);

# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *,NvmDeclarationCounts *);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *,uint32_t,NvmDeclarationLayout *);

# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmV2LayoutField *);

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayType *);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayBinding *);

# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 2





typedef struct NvmRecordArrayExecutionPlan NvmRecordArrayExecutionPlan;
typedef enum {
    NVM_RA_ROOT_SCALAR, NVM_RA_ROOT_CONSTANT, NVM_RA_ROOT_LOAD,
    NVM_RA_ROOT_STORE, NVM_RA_ROOT_DUP, NVM_RA_ROOT_SWAP, NVM_RA_ROOT_DROP,
    NVM_RA_ROOT_BRANCH, NVM_RA_ROOT_CALL, NVM_RA_ROOT_RETURN,
    NVM_RA_ROOT_STRING, NVM_RA_ROOT_CONSTRUCT, NVM_RA_ROOT_GET,
    NVM_RA_ROOT_SET, NVM_RA_ROOT_ARRAY_PUSH, NVM_RA_ROOT_ARRAY_POP,
    NVM_RA_ROOT_ARRAY_COPY, NVM_RA_ROOT_TAIL
} NvmRecordArrayRootRecipe;
enum {

    NVM_RA_CHECK_TAGS=1u, NVM_RA_CHECK_BOUNDS=2u, NVM_RA_CHECK_NOMINAL=4u,
    NVM_RA_SAFEPOINT_BEFORE=8u, NVM_RA_STAGE_OPERANDS=16u,
    NVM_RA_RETAIN_BEFORE_RELEASE=32u, NVM_RA_FIRST_ERROR_CLEANUP=64u
};
typedef struct {
    uint32_t functions, instructions, globals, initializer, entry, frame_limit;
    uint32_t strings, sections, metadata, debug, records;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordArrayExecutionCounts;
typedef struct {
    NvmFunctionEntry signature;
    uint32_t instruction_start, instruction_count;
    uint16_t maximum_stack;
    uint8_t parameter_tags_present;
} NvmRecordArrayExecutionFunction;



typedef struct {
    uint32_t function, pc, next_pc, successors[2], callee;
    uint16_t pops, pushes, obligations;
    uint8_t opcode, recipe, successor_count, operand_count;
    uint8_t operand_types[4];
    uint64_t operand_bits[4];
} NvmRecordArrayExecutionInstruction;
typedef struct {
    uint32_t ordinal, layout;
    uint16_t fields;
} NvmRecordArrayExecutionDescriptor;
typedef enum {
    NVM_RA_SNAPSHOT_CODE, NVM_RA_SNAPSHOT_LAYOUTS, NVM_RA_SNAPSHOT_OWNERSHIP,
    NVM_RA_SNAPSHOT_STRING
} NvmRecordArraySnapshotKind;
NvmArrayEligibilityResult nvm_prepare_record_array_execution(
    const NvmModule *, NvmRecordArrayExecutionPlan **);
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *);

# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionInstruction *);

# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionDescriptor *);

# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *,NvmHeader *);

# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *,uint32_t,NvmSectionEntry *);

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *,uint32_t,NvmMetadataEntry *);

# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDebugEntry *);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayOriginCounts *);

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordHeapOrigin *);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t *);

# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *,NvmDeclarationCounts *);

# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayType *);

# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 2



# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h"
    nvm_record_array_candidate(const NvmModule *);


NvmArrayEligibilityResult nvm_record_array_admit(const NvmModule *,NvmRecordArrayExecutionPlan **);
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
typedef struct NvmRecordMapFrozenContext NvmRecordMapFrozenContext;
typedef struct {
    uint32_t origins,map_origins,fields,checked_map_operations;
    uint64_t peak_bytes_reserved,work_reserved;
} NvmRecordMapCounts;
NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *,NvmRecordMapFrozenContext **);
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *,NvmRecordMapCounts *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *,uint32_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordHeapOrigin *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordValueOrigins *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 2


typedef struct NvmRecordMapExecutionPlan NvmRecordMapExecutionPlan;
typedef enum { NVM_RM_NONE, NVM_RM_NEW, NVM_RM_SET, NVM_RM_GET,
               NVM_RM_HAS, NVM_RM_LEN, NVM_RM_DELETE } NvmRecordMapOperation;
typedef struct {
    NvmRecordArrayExecutionCounts carrier;
    NvmRecordMapCounts maps;
} NvmRecordMapExecutionCounts;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    uint16_t key_tags,value_tags,result_tags;
    uint8_t map_operation;
} NvmRecordMapExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *,NvmRecordMapExecutionPlan **);




# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *,uint8_t *);
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *,NvmRecordMapExecutionCounts *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *,uint32_t,NvmRecordMapExecutionInstruction *);

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *,uint32_t,uint8_t *,uint8_t *);

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out);

# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out);

# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 2





typedef enum { NVM_RECORD_MAP_ABSENT, NVM_RECORD_MAP_PRESENT,
    NVM_RECORD_MAP_INVALID, NVM_RECORD_MAP_LIMIT, NVM_RECORD_MAP_DEFER } NvmRecordMapRoute;
NvmRecordMapRoute nvm_record_map_route(const NvmModule *);


# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h"
    nvm_record_map_wire_selected(const NvmV2Module *);
static inline 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h"
                  nvm_record_map_selected(NvmRecordMapRoute r) {
    return r==NVM_RECORD_MAP_PRESENT || r==NVM_RECORD_MAP_INVALID || r==NVM_RECORD_MAP_LIMIT;
}


NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *,NvmRecordMapExecutionPlan **);
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h" 1
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h"
NvmV2Result nvm_ownership_layouts_private_decode(const uint8_t *,size_t,NvmV2Layouts *);


NvmV2Result nvm_ownership_mixed_layouts_private_decode(const uint8_t *,size_t,NvmV2Layouts *);




NvmV2Result nvm_ownership_mixed_layouts_private_decode_detailed(const uint8_t *,size_t,
                                                             NvmV2Layouts *,
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h" 3 4
                                                                           _Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h"
                                                                                *allocation_failed);

NvmV2Result nvm_ownership_map_layouts_private_decode_detailed(const uint8_t *,size_t,
                                                             NvmV2Layouts *,
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h" 3 4
                                                                           _Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_layouts_private.h"
                                                                                *allocation_failed);
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 2




static NvmV2Result conversion_ownership(const NvmModule *module,
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                               _Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                    *needs,uint16_t *checked_depths,NvmOwnerSignature *owner_signatures,const NvmPrivateServiceCodec *codec) {
    if(nvm_record_map_selected(nvm_record_map_route(module))) {
        NvmRecordMapExecutionPlan *plan=
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                       ((void *)0)
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                           ;
        NvmArrayEligibilityResult r=nvm_record_map_admit(module,&plan);
        if(r.status!=NVM_ARRAY_ELIGIBLE)return r.status==NVM_ARRAY_MEMORY?NVM_V2_ERR_TRUNCATED:NVM_V2_ERR_INDEX_RANGE;
        if(checked_depths)for(uint32_t f=0;f<module->function_count;f++) {
            NvmRecordArrayExecutionFunction info;
            if(!nvm_record_map_execution_function(plan,f,&info)) {
                nvm_record_map_execution_free(plan);return NVM_V2_ERR_INDEX_RANGE;
            }
            checked_depths[f]=info.maximum_stack;
        }
        nvm_record_map_execution_free(plan);*needs=
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                  0
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                       ;return NVM_V2_OK;
    }
    if(nvm_service_bindings_present(module)) {
        NvmV2Result service=nvm_private_service_module(module,codec);
        if(service!=NVM_V2_OK)return service;
        if(codec){*needs=
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                        1
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                            ;return NVM_V2_OK;}
        NvmFileNominalBindings nominal;
        NvmSocketNominalBindings tcp;
        NvmMultiNominalBindings multi;
        if(nvm_file_nominal_decode(module->service_data,module->service_size,&nominal)==NVM_SERVICE_OK ||
           nvm_socket_nominal_decode(module->service_data,module->service_size,&tcp)==NVM_SERVICE_OK ||
           nvm_multi_nominal_decode(module->service_data,module->service_size,&multi)==NVM_SERVICE_OK) {
            *needs=
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                  1
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                      ;return NVM_V2_OK;
        }
        return nvm_ownership_contracts_validate(module,needs);
    }
    if(nvm_owned_array_route(module)!=NVM_OWNER_ARRAY_NOT_SELECTED) {
        NvmOwnedArrayPlan *plan=
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                               ((void *)0)
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                   ;NvmOwnerAuthorityResult r=nvm_owned_array_admit(module,&plan);
        if(r.status!=NVM_OWNER_AUTH_PREPARED)
            return r.status==NVM_OWNER_AUTH_MEMORY?NVM_V2_ERR_TRUNCATED:NVM_V2_ERR_INDEX_RANGE;
        uint16_t depths[8]={0};
        for(uint32_t f=0;f<module->function_count;f++) {
            NvmOwnerSignature signature;
            if(!nvm_owned_array_plan_signature(plan,f,&signature)){nvm_owned_array_plan_free(plan);return NVM_V2_ERR_INDEX_RANGE;}
            depths[f]=signature.max_stack;
            if(owner_signatures)owner_signatures[f]=signature;
        }
        nvm_owned_array_plan_free(plan);
        if(checked_depths)memcpy(checked_depths,depths,sizeof depths);
        *needs=
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
              1
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                  ;return NVM_V2_OK;
    }
    if(nvm_record_array_candidate(module) && !nvm_mixed_samples_candidate(module)) {
        NvmRecordArrayExecutionPlan *plan=
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                         ((void *)0)
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                             ;
        NvmArrayEligibilityResult admission=nvm_record_array_admit(module,&plan);
        if(admission.status!=NVM_ARRAY_ELIGIBLE)
            return admission.status==NVM_ARRAY_MEMORY?NVM_V2_ERR_TRUNCATED:NVM_V2_ERR_INDEX_RANGE;
        if(checked_depths)for(uint32_t f=0;f<module->function_count;f++) {
            NvmRecordArrayExecutionFunction info;
            if(!nvm_record_array_execution_function(plan,f,&info)) {
                nvm_record_array_execution_free(plan);return NVM_V2_ERR_INDEX_RANGE;
            }
            checked_depths[f]=info.maximum_stack;
        }
        nvm_record_array_execution_free(plan);
        *needs=
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
              0
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                   ;return NVM_V2_OK;
    }
    if(!nvm_mixed_samples_candidate(module))return nvm_ownership_contracts_validate(module,needs);
    NvmMixedSamplesPlan *plan=
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                             ((void *)0)
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                 ;
    NvmMixedShapeResult result=nvm_mixed_samples_admit(module,&plan);
    if(result.status!=NVM_MIXED_SHAPE_PROVED)
        return result.status==NVM_MIXED_SHAPE_MEMORY?NVM_V2_ERR_TRUNCATED:NVM_V2_ERR_INDEX_RANGE;
    uint16_t depths[8]={0};
    if(checked_depths)for(uint32_t f=0;f<module->function_count;f++) {
        NvmMixedSignature signature;
        if(!nvm_mixed_samples_signature(plan,f,&signature)){nvm_mixed_samples_plan_free(plan);return NVM_V2_ERR_INDEX_RANGE;}
        depths[f]=signature.max_stack;
    }
    nvm_mixed_samples_plan_free(plan);
    if(checked_depths)memcpy(checked_depths,depths,sizeof depths);
    *needs=
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
          1
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
              ;return NVM_V2_OK;
}





static const char SOURCE_FILE_KEY[] = "nano.source_file";






static uint32_t intern_signature(NvmV2Signatures *sigs, const NvmV2Signature *sig,
                                 size_t *pool_used, size_t pool_mark) {
    for (uint32_t i = 0; i < sigs->count; i++) {
        if (nvm_v2_signature_equal(&sigs->items[i], sig)) {
            *pool_used = pool_mark;
            return i;
        }
    }
    sigs->items[sigs->count] = *sig;
    return sigs->count++;
}

static NvmV2Result nvm_from_module_core(const NvmModule *mod, NvmV2Module *out,const NvmPrivateServiceCodec *codec) {
    if (!mod || !out) return NVM_V2_ERR_INDEX_RANGE;
    memset(out, 0, sizeof *out);
    out->isa_version = 2;
    NvmV2Result service = nvm_private_service_module(mod,codec);
    if (service != NVM_V2_OK) return service;
    out->service_data = mod->service_data;
    out->service_size = mod->service_size;
    
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        record_map=
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                   0
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                        ;
    record_map=nvm_record_map_selected(nvm_record_map_route(mod));
    if (!nvm_metadata_valid(mod) || !nvm_callback_contracts_valid(mod) || !nvm_passive_valid(mod) ||
        (!record_map && !nvm_record_array_candidate(mod) && !nvm_retained_layouts_valid(mod))) return NVM_V2_ERR_INDEX_RANGE;
    
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        needs_ownership = 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                          0
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                               ;
    
# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 156 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        owner_array=nvm_owned_array_route(mod)!=NVM_OWNER_ARRAY_NOT_SELECTED;
    
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        checked_profile=record_map || owner_array || nvm_mixed_samples_candidate(mod) || nvm_record_array_candidate(mod);
    uint16_t checked_depths[256u]={0};NvmOwnerSignature owner_signatures[8]={0};
    NvmV2Result ownership = conversion_ownership(mod, &needs_ownership, checked_profile?checked_depths:
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                      ((void *)0)
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                          ,owner_array?owner_signatures:
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                                                        ((void *)0)
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                                                            ,codec);
    if (ownership != NVM_V2_OK) return ownership;
    out->ownership_data = mod->ownership_data;
    out->ownership_size = mod->ownership_size;
    out->passive_data = mod->passive_data;
    out->passive_size = mod->passive_size;

    const uint32_t n_fn = mod->function_count;
    const uint32_t n_im = mod->import_count;
    const uint32_t n_cb = mod->callback_contract_count;
    const uint32_t n_lk = mod->module_ref_count;
    const uint32_t n_db = mod->debug_count;
    const 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
         _Bool 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
              has_source = mod->source_file_idx != 0 &&
                            mod->source_file_idx < mod->string_count;

    
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        explicit_source = 
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                          0
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                               ;
    uint32_t key_idx = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < mod->metadata_count; ++i)
        if (nvm_metadata_source_key(mod, mod->metadata[i].key_idx)) explicit_source = 
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                     1
# 177 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                         ;
    const 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
         _Bool 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
              synthesize_source = has_source && !explicit_source;
    if (synthesize_source)
        for (uint32_t i = 0; i < mod->string_count; ++i)
            if (nvm_metadata_source_key(mod, i)) { key_idx = i; break; }
    
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        append_key = synthesize_source && key_idx == 0xFFFFFFFFu;
    if (append_key && mod->string_count == 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                          (4294967295U)
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                    ) return NVM_V2_ERR_INDEX_RANGE;
    uint32_t n_ck = mod->string_count + (append_key ? 1u : 0u);
    NvmV2Constant *ck = n_ck ? calloc(n_ck, sizeof *ck) : 
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                         ((void *)0)
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                             ;
    if (n_ck && !ck) return NVM_V2_ERR_TRUNCATED;
    for (uint32_t i = 0; i < mod->string_count; i++) {
        ck[i].tag = TAG_STRING;
        ck[i].length = mod->string_lengths ? mod->string_lengths[i] : 0;
        ck[i].payload = (const uint8_t *)mod->strings[i];
    }
    if (append_key) {
        key_idx = mod->string_count;
        ck[key_idx].tag = TAG_STRING;
        ck[key_idx].length = (uint32_t)(sizeof SOURCE_FILE_KEY - 1);
        ck[key_idx].payload = (const uint8_t *)SOURCE_FILE_KEY;
    }
    out->constants.items = ck;
    out->constants.count = n_ck;




    size_t pool_cap = 0;
    for (uint32_t i = 0; i < n_fn; i++)
        pool_cap += (size_t)mod->functions[i].arity + mod->functions[i].result_count;
    for (uint32_t i = 0; i < n_im; i++)
        pool_cap += (size_t)mod->imports[i].param_count + 1u;
    for (uint32_t i = 0; i < n_cb; i++)
        pool_cap += (size_t)mod->callback_contracts[i].param_count + 1u;

    uint8_t *pool = pool_cap ? calloc(pool_cap, 1) : 
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                    ((void *)0)
# 212 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                        ;
    if (pool_cap && !pool) goto oom;
    out->owned_tags = pool;
    size_t pool_used = 0;

    if ((uint64_t)n_fn + n_im + n_cb > 
# 217 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                      (4294967295U)
# 217 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                ) goto oom;
    uint32_t sig_cap = n_fn + n_im + n_cb;
    NvmV2Signature *sigs = sig_cap ? calloc(sig_cap, sizeof *sigs) : 
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                    ((void *)0)
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                        ;
    if (sig_cap && !sigs) goto oom;
    out->signatures.items = sigs;
    out->signatures.count = 0;

    NvmV2Function *fns = n_fn ? calloc(n_fn, sizeof *fns) : 
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                           ((void *)0)
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                               ;
    if (n_fn && !fns) goto oom;
    out->functions.items = fns;
    out->functions.count = n_fn;

    for (uint32_t i = 0; i < n_fn; i++) {
        const NvmFunctionEntry *f = &mod->functions[i];
        size_t mark = pool_used;




        const uint8_t *ptags = f->arity ? pool + pool_used : 
# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                            ((void *)0)
# 236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                ;
        if(owner_array) {
            for(uint16_t n=0;n<f->arity;n++)pool[pool_used+n]=owner_signatures[i].parameters[n].tag;
        } else if (f->arity && mod->function_param_types && mod->function_param_types[i])
            memcpy(pool + pool_used, mod->function_param_types[i], f->arity);
        else if (f->arity)
            memset(pool + pool_used, TAG_VOID, f->arity);
        pool_used += f->arity;

        const uint8_t *rtags = 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                              ((void *)0)
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                  ;
        if (f->result_count) {
            rtags = pool + pool_used;
            memset(pool + pool_used, f->result_tag, f->result_count);
            pool_used += f->result_count;
        }

        NvmV2Signature sig = { f->arity, f->result_count, ptags, rtags };
        fns[i].signature_idx = intern_signature(&out->signatures, &sig,
                                                &pool_used, mark);
        fns[i].name_idx = f->name_idx;
        fns[i].code_offset = f->code_offset;
        fns[i].code_length = f->code_length;
        fns[i].local_count = f->local_count;
        fns[i].upvalue_count = f->upvalue_count;







        uint16_t depth = 0;
        if(checked_profile)fns[i].max_stack=checked_depths[i];
        else if (!nvm_service_bindings_present(mod) && nvm_verify_function_max_stack(mod, i, &depth).ok)
            fns[i].max_stack = depth;
    }

    NvmV2Import *ims = n_im ? calloc(n_im, sizeof *ims) : 
# 273 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                         ((void *)0)
# 273 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                             ;
    if (n_im && !ims) goto oom;
    out->imports.items = ims;
    out->imports.count = n_im;

    for (uint32_t i = 0; i < n_im; i++) {
        const NvmImportEntry *im = &mod->imports[i];
        size_t mark = pool_used;

        const uint8_t *ptags = 
# 282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                              ((void *)0)
# 282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                  ;
        if (im->param_count) {
            ptags = pool + pool_used;
            if (mod->import_param_types && mod->import_param_types[i])
                memcpy(pool + pool_used, mod->import_param_types[i], im->param_count);
            else
                memset(pool + pool_used, TAG_VOID, im->param_count);
            pool_used += im->param_count;
        }


        uint16_t rcount = (im->return_type == TAG_VOID) ? 0 : 1;
        const uint8_t *rtags = 
# 294 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                              ((void *)0)
# 294 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                  ;
        if (rcount) {
            rtags = pool + pool_used;
            pool[pool_used++] = im->return_type;
        }

        NvmV2Signature sig = { im->param_count, rcount, ptags, rtags };
        ims[i].signature_idx = intern_signature(&out->signatures, &sig,
                                                  &pool_used, mark);
        ims[i].module_name_idx = im->module_name_idx;
        ims[i].symbol_name_idx = im->function_name_idx;
        ims[i].kind = mod->imports[i].kind;
    }

    out->callbacks.items = n_cb ? calloc(n_cb, sizeof(*out->callbacks.items)) : 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                               ((void *)0)
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                   ;
    if (n_cb && !out->callbacks.items) goto oom;
    out->callbacks.count = n_cb;
    for (uint32_t i = 0; i < n_cb; i++) {
        const NvmCallbackContract *c = &mod->callback_contracts[i];
        NvmV2Callback *wire = &out->callbacks.items[i];
        wire->import_idx = c->import_idx;
        wire->adapter_name_idx = c->adapter_name_idx;
        wire->parameter_idx = c->parameter_idx;
        wire->abi_version = c->abi_version;
        wire->execution = c->execution;
        wire->signature_idx = 0xFFFFFFFFu;
        if (c->parameter_idx != 
# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                               (65535)
# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                        ) {
            size_t mark = pool_used;
            const uint8_t *params = c->param_count ? pool + pool_used : 
# 322 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                       ((void *)0)
# 322 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                           ;
            if (c->param_count) memcpy(pool + pool_used, c->param_tags, c->param_count);
            pool_used += c->param_count;
            uint16_t result_count = c->return_tag != TAG_VOID;
            const uint8_t *results = result_count ? pool + pool_used : 
# 326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                      ((void *)0)
# 326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                          ;
            if (result_count) pool[pool_used++] = c->return_tag;
            NvmV2Signature signature = {c->param_count, result_count, params, results};
            wire->signature_idx = intern_signature(&out->signatures, &signature, &pool_used, mark);
        }
    }



    NvmV2Link *lks = n_lk ? calloc(n_lk, sizeof *lks) : 
# 335 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                       ((void *)0)
# 335 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                           ;
    if (n_lk && !lks) goto oom;
    for (uint32_t i = 0; i < n_lk; i++) {
        lks[i].module_name_idx = mod->module_refs[i].module_name_idx;
        lks[i].symbol_name_idx = 0xFFFFFFFFu;
        lks[i].signature_idx = 0xFFFFFFFFu;
        lks[i].flags = 0;
    }
    out->links.items = lks;
    out->links.count = n_lk;

    NvmV2DebugEntry *dbs = n_db ? calloc(n_db, sizeof *dbs) : 
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                             ((void *)0)
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                 ;
    if (n_db && !dbs) goto oom;
    for (uint32_t i = 0; i < n_db; i++) {
        dbs[i].bytecode_offset = mod->debug_entries[i].bytecode_offset;
        dbs[i].source_line = mod->debug_entries[i].source_line;
        dbs[i].source_col = mod->debug_entries[i].source_col;
    }
    out->debug.items = dbs;
    out->debug.count = n_db;
    out->has_debug = n_db > 0 || (mod->header.flags & (1 << 2)) != 0;

    if (synthesize_source && mod->metadata_count == 
# 357 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                   (4294967295U)
# 357 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                             ) goto oom;
    uint32_t metadata_count = mod->metadata_count + (synthesize_source ? 1u : 0u);
    if (metadata_count) {
        NvmV2MetadataEntry *md = calloc(metadata_count, sizeof *md);
        if (!md) goto oom;
        for (uint32_t i = 0; i < mod->metadata_count; ++i)
            md[i] = (NvmV2MetadataEntry){mod->metadata[i].key_idx, mod->metadata[i].value_idx};
        if (synthesize_source)
            md[mod->metadata_count] = (NvmV2MetadataEntry){key_idx, mod->source_file_idx};
        out->metadata.items = md;
        out->metadata.count = metadata_count;
    }






    uint32_t n_lay = mod->struct_count + mod->enum_count + mod->union_count;
    if (mod->layout_size) {
        NvmV2Result retained = record_map ?
            nvm_ownership_map_layouts_private_decode_detailed(mod->layout_data,mod->layout_size,&out->layouts,
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                             ((void *)0)
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                                 ) :
            nvm_record_array_candidate(mod) ?
            nvm_ownership_layouts_private_decode(mod->layout_data,mod->layout_size,&out->layouts) :
            nvm_v2_layouts_decode(mod->layout_data,mod->layout_size,&out->layouts);
        if (retained != NVM_V2_OK) { nvm_v2_module_free(out); return retained; }
        out->extra_features |= (1u << 7);
    } else if (n_lay) {
        NvmV2Layout *lay = calloc(n_lay, sizeof *lay);
        if (!lay) goto oom;
        uint32_t k = 0;
        for (uint32_t i = 0; i < mod->struct_count; i++, k++) {
            lay[k].kind = NVM_V2_LAYOUT_STRUCT; lay[k].name_idx = 0xFFFFFFFFu;
        }
        for (uint32_t i = 0; i < mod->enum_count; i++, k++) {
            lay[k].kind = NVM_V2_LAYOUT_ENUM; lay[k].name_idx = 0xFFFFFFFFu;
        }
        for (uint32_t i = 0; i < mod->union_count; i++, k++) {
            lay[k].kind = NVM_V2_LAYOUT_UNION; lay[k].name_idx = 0xFFFFFFFFu;
        }
        out->layouts.items = lay;
        out->layouts.count = n_lay;
    }




    if (mod->header.flags & (1 << 1))
        out->extra_features |= (1u << 1);

    out->code = mod->code;
    out->code_size = mod->code_size;




    out->entry_point = ((mod->header.flags & (1 << 0)) &&
                        mod->header.entry_point < n_fn)
                         ? mod->header.entry_point
                         : 0xFFFFFFFFu;

    return NVM_V2_OK;

oom:
    nvm_v2_module_free(out);
    return NVM_V2_ERR_TRUNCATED;
}



static NvmV2Result nvm_to_module_core(const NvmV2Module *m, NvmModule **out,const NvmPrivateServiceCodec *codec) {
    if (!m || !out) return NVM_V2_ERR_INDEX_RANGE;
    *out = 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
          ((void *)0)
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
              ;
    NvmV2Result service = nvm_private_service_wire(m,codec);
    if (service != NVM_V2_OK) return service;

    NvmModule *mod = nvm_module_new();
    if (!mod) return NVM_V2_ERR_TRUNCATED;




    for (uint32_t i = 0; i < m->constants.count; i++) {
        const NvmV2Constant *c = &m->constants.items[i];
        if (c->tag != TAG_STRING) {
            nvm_module_free(mod);
            return NVM_V2_ERR_SECTION_TYPE;
        }
        uint32_t idx = nvm_add_string(mod, (const char *)c->payload, c->length);
        if (idx != i) {
            nvm_module_free(mod);
            return NVM_V2_ERR_INDEX_RANGE;
        }
    }

    for (uint32_t i = 0; i < m->metadata.count; i++) {
        const NvmV2MetadataEntry *e = &m->metadata.items[i];
        if (!nvm_add_metadata(mod, e->key_idx, e->value_idx)) {
            nvm_module_free(mod);
            return NVM_V2_ERR_INDEX_RANGE;
        }
    }

    if (m->code_size) {
        if (!m->code || m->code_size > 
# 461 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                      (4294967295U)
# 461 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                ) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }
        uint32_t size = (uint32_t)m->code_size;


        if (size > mod->code_capacity) {
            uint8_t *code = realloc(mod->code, size);
            if (!code) { nvm_module_free(mod); return NVM_V2_ERR_TRUNCATED; }
            mod->code = code;
            mod->code_capacity = size;
        }
        memcpy(mod->code, m->code, size);
        mod->code_size = size;
    }

    for (uint32_t i = 0; i < m->functions.count; i++) {
        const NvmV2Function *f = &m->functions.items[i];
        const NvmV2Signature *s = &m->signatures.items[f->signature_idx];



        if (f->code_offset > 
# 481 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                            (4294967295U) 
# 481 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                       || f->code_length > 
# 481 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                           (4294967295U) 
# 481 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                      ||
            s->result_count > 
# 482 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                             (255)
# 482 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                      ) {
            nvm_module_free(mod);
            return NVM_V2_ERR_INDEX_RANGE;
        }
        NvmFunctionEntry e;
        memset(&e, 0, sizeof e);
        e.name_idx = f->name_idx;
        e.arity = s->param_count;
        e.code_offset = (uint32_t)f->code_offset;
        e.code_length = (uint32_t)f->code_length;
        e.local_count = f->local_count;
        e.upvalue_count = f->upvalue_count;
        e.result_count = (uint8_t)s->result_count;
        e.result_tag = s->result_count ? s->result_tags[0] : TAG_VOID;
        uint32_t index = nvm_add_function(mod, &e);
        if (index == 
# 497 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                    (4294967295U) 
# 497 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                               ||
            !nvm_set_function_param_types(mod, index, s->param_tags, s->param_count)) {
            nvm_module_free(mod);
            return NVM_V2_ERR_TRUNCATED;
        }
    }

    for (uint32_t i = 0; i < m->imports.count; i++) {
        const NvmV2Import *im = &m->imports.items[i];
        const NvmV2Signature *s = &m->signatures.items[im->signature_idx];
        uint8_t ret = s->result_count ? s->result_tags[0] : TAG_VOID;
        uint32_t index = nvm_add_import(mod, im->module_name_idx, im->symbol_name_idx,
                                       s->param_count, ret, s->param_tags);
        if (index == 
# 510 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                    (4294967295U)
# 510 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                              ) {
            nvm_module_free(mod);
            return NVM_V2_ERR_TRUNCATED;
        }
        mod->imports[index].kind = im->kind;
    }

    for (uint32_t i = 0; i < m->callbacks.count; i++) {
        const NvmV2Callback *wire = &m->callbacks.items[i];
        NvmCallbackContract c = {0};
        c.import_idx = wire->import_idx;
        c.adapter_name_idx = wire->adapter_name_idx;
        c.parameter_idx = wire->parameter_idx;
        c.abi_version = wire->abi_version;
        c.execution = wire->execution;
        if (c.parameter_idx != 
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                              (65535)
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                       ) {
            if (wire->signature_idx >= m->signatures.count) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }
            const NvmV2Signature *s = &m->signatures.items[wire->signature_idx];
            if (s->param_count > 16 || s->result_count > 1) {
                nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE;
            }
            c.param_count = s->param_count;
            c.return_tag = s->result_count ? s->result_tags[0] : TAG_VOID;
            if (s->param_count) memcpy(c.param_tags, s->param_tags, s->param_count);
        } else if (wire->signature_idx != 0xFFFFFFFFu) {
            nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE;
        }
        if (!nvm_add_callback_contract(mod, &c)) {
            nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE;
        }
    }
    if (!nvm_callback_contracts_valid(mod)) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }

    for (uint32_t i = 0; i < m->links.count; i++)
        nvm_add_module_ref(mod, m->links.items[i].module_name_idx);

    for (uint32_t i = 0; i < m->debug.count; i++) {
        const NvmV2DebugEntry *d = &m->debug.items[i];
        if (d->bytecode_offset > 
# 548 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                (4294967295U)
# 548 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                          ) {
            nvm_module_free(mod);
            return NVM_V2_ERR_INDEX_RANGE;
        }
        if (!nvm_add_debug_entry(mod, (uint32_t)d->bytecode_offset,
                                 d->source_line, d->source_col)) {
            nvm_module_free(mod);
            return NVM_V2_ERR_INDEX_RANGE;
        }
    }

    if (m->layouts.count && !m->layouts.items) {
        nvm_module_free(mod);
        return NVM_V2_ERR_INDEX_RANGE;
    }
    for (uint32_t i = 0; i < m->layouts.count; i++) {
        switch (m->layouts.items[i].kind) {
        case NVM_V2_LAYOUT_STRUCT: mod->struct_count++; break;
        case NVM_V2_LAYOUT_ENUM: mod->enum_count++; break;
        case NVM_V2_LAYOUT_UNION: mod->union_count++; break;
        default: break;
        }
    }

    if ((m->extra_features & (1u << 7)) ||
        nvm_layouts_have_facts(&m->layouts)) {


        size_t bytes=4;
        for(uint32_t i=0;i<m->layouts.count;i++) {
            const NvmV2Layout *layout=&m->layouts.items[i];
            size_t row=8+(size_t)layout->field_count*12;
            if((layout->field_count && !layout->fields) || row>
# 580 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                              (4294967295U)
# 580 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                        -bytes) {
                nvm_module_free(mod);return NVM_V2_ERR_INDEX_RANGE;
            }
            bytes+=row;
        }
        uint8_t *encoded=malloc(bytes);
        if(!encoded){nvm_module_free(mod);return NVM_V2_ERR_TRUNCATED;}
        NvmV2Result retained=nvm_v2_layouts_encode(&m->layouts,encoded,bytes);
        NvmModule staged=*mod;staged.layout_data=encoded;staged.layout_size=(uint32_t)bytes;
        staged.ownership_data=(uint8_t *)m->ownership_data;staged.ownership_size=m->ownership_size;
        staged.service_data=(uint8_t *)m->service_data;staged.service_size=m->service_size;
        
# 591 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
       _Bool 
# 591 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
            staged_map=
# 591 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                       0
# 591 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                            ;
        staged_map=nvm_record_map_selected(nvm_record_map_route(&staged));
        if(retained==NVM_V2_OK && (staged_map || nvm_record_array_candidate(&staged))) {
            mod->layout_data=encoded;mod->layout_size=(uint32_t)bytes;encoded=
# 594 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                             ((void *)0)
# 594 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                 ;
        } else if(retained==NVM_V2_OK)retained=nvm_retain_layouts(mod,&m->layouts);
        free(encoded);
        if (retained != NVM_V2_OK) { nvm_module_free(mod); return retained; }
    }




    mod->header.flags = 0;
    if (m->entry_point != 0xFFFFFFFFu) {
        mod->header.flags |= (1 << 0);
        mod->header.entry_point = m->entry_point;
    } else {
        mod->header.entry_point = 0;
    }
    if (m->imports.count || (m->extra_features & (1u << 1)))
        mod->header.flags |= (1 << 1);
    if (m->has_debug) mod->header.flags |= (1 << 2);

    if (m->service_size) {
        mod->service_data = malloc(m->service_size);
        if (!mod->service_data) { nvm_module_free(mod); return NVM_V2_ERR_TRUNCATED; }
        memcpy(mod->service_data, m->service_data, m->service_size);
        mod->service_size = m->service_size;
    }
    if (m->passive_size) {
        if (!m->passive_data) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }
        mod->passive_data = malloc(m->passive_size);
        if (!mod->passive_data) { nvm_module_free(mod); return NVM_V2_ERR_TRUNCATED; }
        memcpy(mod->passive_data, m->passive_data, m->passive_size);
        mod->passive_size = m->passive_size;
    }
    if (m->ownership_size) {
        if (!m->ownership_data) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }
        mod->ownership_data = malloc(m->ownership_size);
        if (!mod->ownership_data) { nvm_module_free(mod); return NVM_V2_ERR_TRUNCATED; }
        memcpy(mod->ownership_data, m->ownership_data, m->ownership_size);
        mod->ownership_size = m->ownership_size;
    }
    
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        needs_ownership = 
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                          0
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                               ;
    
# 635 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 635 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        owner_array=nvm_owned_array_route(mod)!=NVM_OWNER_ARRAY_NOT_SELECTED;
    
# 636 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 636 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        record_array=nvm_record_array_candidate(mod) && !nvm_mixed_samples_candidate(mod);
    
# 637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
   _Bool 
# 637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
        record_map=
# 637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                   0
# 637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                        ;
    record_map=nvm_record_map_selected(nvm_record_map_route(mod));
    uint16_t owner_depths[256u]={0};
    NvmV2Result ownership = conversion_ownership(mod, &needs_ownership,(record_map || owner_array || record_array)?owner_depths:
# 640 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                                               ((void *)0)
# 640 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                                                   ,
# 640 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                                                    ((void *)0)
# 640 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                                                        ,codec);
    if (ownership != NVM_V2_OK) { nvm_module_free(mod); return ownership; }
    if(record_map || owner_array || record_array)for(uint32_t f=0;f<mod->function_count;f++) {
        uint16_t declared=m->functions.items[f].max_stack;
        if(declared && declared<owner_depths[f]){nvm_module_free(mod);return NVM_V2_ERR_INDEX_RANGE;}
    }
    if (!nvm_passive_valid(mod)) { nvm_module_free(mod); return NVM_V2_ERR_INDEX_RANGE; }
    *out = mod;
    return NVM_V2_OK;
}



NvmV2Result nvm_private_from_module(const NvmModule *m,NvmV2Module *out,const NvmPrivateServiceCodec *codec) {
    if(nvm_record_map_selected(nvm_record_map_route(m))) {
        if(!out)return NVM_V2_ERR_INDEX_RANGE;
        NvmV2Module staged={0};NvmV2Result r=nvm_from_module_core(m,&staged,codec);
        if(r==NVM_V2_OK)*out=staged;
        else nvm_v2_module_free(&staged);
        return r;
    }
    return nvm_from_module_core(m,out,codec);
}

NvmV2Result nvm_private_to_module(const NvmV2Module *m,NvmModule **out,const NvmPrivateServiceCodec *codec) {
    if(nvm_record_map_wire_selected(m)) {
        if(!out)return NVM_V2_ERR_INDEX_RANGE;
        NvmModule *staged=
# 667 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                         ((void *)0)
# 667 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                             ;NvmV2Result r=nvm_to_module_core(m,&staged,codec);
        if(r==NVM_V2_OK)*out=staged;
        else nvm_module_free(staged);
        return r;
    }
    return nvm_to_module_core(m,out,codec);
}

NvmV2Result nvm_v2_from_nvm_module(const NvmModule *m,NvmV2Module *out) {return nvm_private_from_module(m,out,
# 675 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                             ((void *)0)
# 675 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                                 );}
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m,NvmModule **out) {return nvm_private_to_module(m,out,
# 676 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c" 3 4
                                                                                                          ((void *)0)
# 676 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_convert.c"
                                                                                                              );}
