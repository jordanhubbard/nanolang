# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 2





typedef struct {
    
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
        ok;
    uint32_t byte_offset;
    uint32_t reachable;
    uint32_t visits;
    char message[192];
} NvmAffineAnalysis;

typedef struct {
    
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
   _Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
        reachable;
    uint8_t top_tag;
    uint16_t stack_depth;
    uint16_t unpack_count;
    uint32_t byte_offset;
} NvmAffineInstructionFact;




NvmAffineAnalysis nvm_affine_analyze_instructions(const NvmModule *module,
    uint32_t function, NvmAffineInstructionFact *facts, uint32_t capacity);




# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
    nvm_affine_value_call_graph(const NvmModule *module);
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
NvmAffineAnalysis nvm_affine_analyze_function(const NvmModule *module,
                                              uint32_t function);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 2




typedef enum {
    NVM_REFERENCE_SHARED = 1,
    NVM_REFERENCE_EXCLUSIVE = 2
} NvmReferenceMode;

typedef struct {
    uint64_t invocation;
    uint16_t local;
    uint32_t root_layout;
    const uint16_t *fields;
    uint16_t field_count;
    uint32_t referent_layout;
    NvmReferenceMode mode;
} NvmReferencePlace;






# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_place_valid(const NvmV2Layouts *layouts,
                               uint32_t authoritative_root_layout,
                               const NvmReferencePlace *place);





# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_places_overlap(const NvmReferencePlace *a,
                                  const NvmReferencePlace *b);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_holds_conflict(const NvmReferencePlace *a,
                                 const NvmReferencePlace *b);



# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_owner_access_conflicts(const NvmReferencePlace *hold,
                                          const NvmReferencePlace *access,
                                          
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
                                         _Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
                                              write_or_move);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 2







typedef struct NvmAffineState NvmAffineState;
NvmAffineState *nvm_affine_state_create(const NvmModule *module,
                                       uint32_t function, uint32_t references);
NvmAffineState *nvm_affine_state_clone(const NvmAffineState *state);




NvmAffineState *nvm_affine_handler_enter(const NvmAffineState *state,
                                         uint32_t key_idx,uint16_t first);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_suspend(const NvmAffineState *state);
void nvm_affine_state_free(NvmAffineState *state);


# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_complete_unions(const NvmAffineState *state);


# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_array_types(const NvmAffineState *state);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_equal(const NvmAffineState *a, const NvmAffineState *b);



# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_meet_initialization(NvmAffineState *destination,
                                          const NvmAffineState *incoming,
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                        _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                             *changed);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_define(NvmAffineState *state, uint16_t local);


# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_define(NvmAffineState *state, uint16_t local);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_move(NvmAffineState *state, uint16_t source, uint16_t destination);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_pack(NvmAffineState *state, uint16_t destination,
                      const uint16_t *fields, uint16_t count);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_unpack(NvmAffineState *state, uint16_t source,
                        const uint16_t *fields, uint16_t count);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owner_access(const NvmAffineState *state, uint16_t root,
                              const uint16_t *path, uint16_t count, 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                   _Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                        write);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_begin(NvmAffineState *state);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_end(NvmAffineState *state);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_borrow(NvmAffineState *state, uint32_t reference,
                        uint16_t root, const uint16_t *path, uint16_t count,
                        NvmReferenceMode mode);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reborrow(NvmAffineState *state, uint32_t reference,
                          uint32_t parent, NvmReferenceMode mode);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_access(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write);

# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_field(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write, uint8_t *tag);




# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit(const NvmAffineState *state, uint16_t result);



# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_info(const NvmAffineState *state, uint16_t local,
                            uint8_t *tag, uint8_t *mode);

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_scalar(const NvmAffineState *state, uint8_t tag);
typedef struct { uint8_t tag; uint32_t layout; } NvmAffineType;

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_types_equal(const NvmAffineState *,NvmAffineType,NvmAffineType);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_define(NvmAffineState *,uint16_t local,uint32_t element);



# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_element(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_type(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_tag_type(const NvmAffineState *,uint8_t,NvmAffineType *);

# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_resume(const NvmAffineState *state,NvmAffineType result);






# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_type_is_owned(const NvmAffineState *state,NvmAffineType type);

# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_is_copyable(const NvmAffineState *state,uint32_t layout);

# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_define(NvmAffineState *state,uint16_t local,uint32_t layout);

# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_local_fields(const NvmAffineState *state,uint16_t local,
    NvmAffineType *fields,uint16_t capacity,uint16_t *count);

# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_take_local(NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_put_local(NvmAffineState *state, uint16_t local, NvmAffineType type);

# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_type(const NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_fields(const NvmAffineState *state, uint32_t layout,
                               NvmAffineType *fields, uint16_t capacity, uint16_t *count);



# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_define(NvmAffineState *state,uint16_t local,
                              uint32_t layout,uint16_t variant);




# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_pack(NvmAffineState *state,uint16_t destination,uint16_t variant,
                            const uint16_t *fields,uint16_t count);

# 100 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 100 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_unpack(NvmAffineState *state,uint16_t source,uint16_t variant,
                              const uint16_t *fields,uint16_t count);

# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_refine(NvmAffineState *state,uint16_t local,uint16_t variant);

# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_variant(const NvmAffineState *state,uint16_t local,
                               uint16_t *variant);

# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_fields(const NvmAffineState *state,uint32_t layout,
                              uint16_t variant,NvmAffineType *fields,
                              uint16_t capacity,uint16_t *count);

# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_type(const NvmAffineState *state, NvmAffineType type);






# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_bind_caller(NvmAffineState *callee,const NvmAffineState *caller,
                             uint32_t reference);

# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_at(const NvmAffineState *state,uint16_t parameter,
                               NvmAffineType *type,NvmReferenceMode *mode);
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"

# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_result(const NvmAffineState *state,NvmAffineType *type,
                              uint16_t *field_count);



# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_parameters(const NvmAffineState *state,
                                  NvmAffineType *types,uint16_t capacity,uint16_t *count);



# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_consuming_parameters(const NvmAffineState *state,
                                      NvmAffineType *types,uint16_t capacity,uint16_t *count);


# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_parameter_type(const NvmAffineState *state,NvmAffineType *type);

# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_type(const NvmAffineState *state,NvmAffineType *type,
                                 NvmReferenceMode *mode);
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_global_flow.h" 1







typedef struct {
    uint8_t allowed;
    uint8_t normal;
    uint8_t lexical_return;
} NvmAffineGlobalFlow;

static inline uint8_t nvm_affine_global_require(uint8_t relation, uint8_t permitted) {
    uint8_t allowed = 3;
    for (unsigned input = 0; input < 2; input++)
        if (((relation >> (input * 2)) & 3u) & ~permitted)
            allowed &= (uint8_t)~(1u << input);
    return allowed;
}

static inline uint8_t nvm_affine_global_compose(uint8_t before, uint8_t after) {
    uint8_t result = 0;
    for (unsigned input = 0; input < 2; input++)
        for (unsigned middle = 0; middle < 2; middle++)
            if (before & (1u << (input * 2 + middle)))
                result |= (uint8_t)(((after >> (middle * 2)) & 3u) << (input * 2));
    return result;
}

static inline NvmAffineGlobalFlow nvm_affine_global_flow(uint8_t allowed,
        uint8_t normal, uint8_t lexical_return) {
    allowed &= 3u;
    uint8_t rows = (uint8_t)(((allowed & 1u) ? 3u : 0u) |
                            ((allowed & 2u) ? 12u : 0u));
    return (NvmAffineGlobalFlow){allowed, normal & rows, lexical_return & rows};
}



static inline NvmAffineGlobalFlow nvm_affine_global_then(
        NvmAffineGlobalFlow first, NvmAffineGlobalFlow second) {
    uint8_t allowed = first.allowed &
        nvm_affine_global_require(first.normal, second.allowed);
    return nvm_affine_global_flow(allowed,
        nvm_affine_global_compose(first.normal, second.normal),
        first.lexical_return |
        nvm_affine_global_compose(first.normal, second.lexical_return));
}


static inline NvmAffineGlobalFlow nvm_affine_global_join(
        NvmAffineGlobalFlow left, NvmAffineGlobalFlow right) {
    return nvm_affine_global_flow(left.allowed & right.allowed,
        left.normal | right.normal, left.lexical_return | right.lexical_return);
}
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;






typedef __off64_t off64_t;






typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) __attribute__ ((__warn_unused_result__));
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__));

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4




extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                          __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                         __attribute__ ((__warn_unused_result__));
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
    __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) __attribute__ ((__warn_unused_result__));






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern int __sprintf_chk (char *__restrict __s, int __flag, size_t __slen,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));
extern int __vsprintf_chk (char *__restrict __s, int __flag, size_t __slen,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));



extern int __snprintf_chk (char *__restrict __s, size_t __n, int __flag,
      size_t __slen, const char *__restrict __format,
      ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int __vsnprintf_chk (char *__restrict __s, size_t __n, int __flag,
       size_t __slen, const char *__restrict __format,
       __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));





extern int __fprintf_chk (FILE *__restrict __stream, int __flag,
     const char *__restrict __format, ...)
    __attribute__ ((__nonnull__ (1)));
extern int __printf_chk (int __flag, const char *__restrict __format, ...);
extern int __vfprintf_chk (FILE *__restrict __stream, int __flag,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nonnull__ (1)));
extern int __vprintf_chk (int __flag, const char *__restrict __format,
     __gnuc_va_list __ap);


extern int __dprintf_chk (int __fd, int __flag, const char *__restrict __fmt,
     ...) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __vdprintf_chk (int __fd, int __flag,
      const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 3, 0)));




extern int __asprintf_chk (char **__restrict __ptr, int __flag,
      const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4))) __attribute__ ((__warn_unused_result__));
extern int __vasprintf_chk (char **__restrict __ptr, int __flag,
       const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0))) __attribute__ ((__warn_unused_result__));
extern int __obstack_printf_chk (struct obstack *__restrict __obstack,
     int __flag, const char *__restrict __format,
     ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __obstack_vprintf_chk (struct obstack *__restrict __obstack,
      int __flag,
      const char *__restrict __format,
      __gnuc_va_list __args)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 96 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern char *__fgets_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets called with bigger size than length " "of destination buffer")))
                                 ;

extern char *__fgets_chk (char *__restrict __s, size_t __size, int __n,
     FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));

extern size_t __fread_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread")


            __attribute__ ((__warn_unused_result__));
extern size_t __fread_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread called with bigger size * nmemb than length " "of destination buffer")))
                                 ;

extern size_t __fread_chk (void *__restrict __ptr, size_t __ptrlen,
      size_t __size, size_t __n,
      FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));


extern char *__fgets_unlocked_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets_unlocked")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_unlocked_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_unlocked_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets_unlocked called with bigger size than length " "of destination buffer")))
                                 ;


extern char *__fgets_unlocked_chk (char *__restrict __s, size_t __size,
       int __n, FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));




extern size_t __fread_unlocked_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread_unlocked")


                     __attribute__ ((__warn_unused_result__));
extern size_t __fread_unlocked_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_unlocked_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread_unlocked called with bigger size * nmemb than " "length of destination buffer")))
                                        ;

extern size_t __fread_unlocked_chk (void *__restrict __ptr, size_t __ptrlen,
        size_t __size, size_t __n,
        FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));
# 965 "/usr/include/stdio.h" 2 3 4
# 976 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 1 3 4
# 46 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return getc (stdin);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





extern __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


extern __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




extern __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return putc (__c, stdout);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


extern __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) __ssize_t
getline (char **__lineptr, size_t *__n, FILE *__stream)
{
  return __getdelim (__lineptr, __n, '\n', __stream);
}





extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0010) != 0);
}


extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0020) != 0);
}
# 977 "/usr/include/stdio.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) sprintf (char *__restrict __s, const char *__restrict __fmt, ...)
{
  return __builtin___sprintf_chk (__s, 3 - 1,
      __builtin_dynamic_object_size (__s, 1), __fmt,
      __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsprintf (char *__restrict __s, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsprintf_chk (__s, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) snprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, ...)

{
  return __builtin___snprintf_chk (__s, __n, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt,
       __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsnprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsnprintf_chk (__s, __n, 3 - 1,
        __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
fprintf (FILE *__restrict __stream, const char *__restrict __fmt, ...)
{
  return __fprintf_chk (__stream, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
printf (const char *__restrict __fmt, ...)
{
  return __printf_chk (3 - 1, __fmt, __builtin_va_arg_pack ());
}







extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __ap)
{

  return __vfprintf_chk (stdout, 3 - 1, __fmt, __ap);



}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
vfprintf (FILE *__restrict __stream,
   const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vfprintf_chk (__stream, 3 - 1, __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
dprintf (int __fd, const char *__restrict __fmt, ...)
{
  return __dprintf_chk (__fd, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vdprintf (int __fd, const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vdprintf_chk (__fd, 3 - 1, __fmt, __ap);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)
{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) __asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)

{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_printf (struct obstack *__restrict __obstack, const char *__restrict __fmt, ...)

{
  return __obstack_printf_chk (__obstack, 3 - 1, __fmt,
          __builtin_va_arg_pack ());
}
# 165 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vasprintf (char **__restrict __ptr, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __vasprintf_chk (__ptr, 3 - 1, __fmt, __ap);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_vprintf (struct obstack *__restrict __obstack, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __obstack_vprintf_chk (__obstack, 3 - 1, __fmt,
    __ap);
}
# 194 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_chk_warn (__s, sz, __n, __stream);
  return __fgets_chk (__s, sz, __n, __stream);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread (void *__restrict __ptr, size_t __size, size_t __n,
       FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    return __fread_alias (__ptr, __size, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_chk (__ptr, sz, __size, __n, __stream);
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets_unlocked (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_unlocked_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_unlocked_chk_warn (__s, sz, __n, __stream);
  return __fgets_unlocked_chk (__s, sz, __n, __stream);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread_unlocked (void *__restrict __ptr, size_t __size, size_t __n,
  FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    {

      if (__builtin_constant_p (__size)
   && __builtin_constant_p (__n)
   && (__size | __n) < (((size_t) 1) << (8 * sizeof (size_t) / 2))
   && __size * __n <= 8)
 {
   size_t __cnt = __size * __n;
   char *__cptr = (char *) __ptr;
   if (__cnt == 0)
     return 0;

   for (; __cnt > 0; --__cnt)
     {
       int __c = getc_unlocked (__stream);
       if (__c == (-1))
  break;
       *__cptr++ = __c;
     }
   return (__cptr - (char *) __ptr) / __size;
 }

      return __fread_unlocked_alias (__ptr, __size, __n, __stream);
    }
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_unlocked_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_unlocked_chk (__ptr, sz, __size, __n, __stream);

}
# 981 "/usr/include/stdio.h" 2 3 4



# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 97 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 114 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2


# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
typedef struct {
    uint8_t tag;
    
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        observation;
    uint16_t root;
    
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        owned;
    uint32_t layout;
    uint16_t variant;
    uint64_t excluded[(256u +63u)/64u];
} Value;

typedef struct { uint32_t key, site; } Handler;
typedef struct {
    NvmAffineState *locals;
    Value *stack;
    uint16_t count;
    
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        visited;
    uint16_t global_count;


    uint8_t globals[256u];
    uint16_t handler_count, handler_floor;
    uint32_t activation;
    Handler handlers[64u];
} Frame;
static 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           observes_owner(const Frame *frame,uint16_t root) {
    for (uint16_t i=0;i<frame->count;i++)
        if (frame->stack[i].observation && frame->stack[i].root==root) return 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                             1
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                 ;
    return 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          0
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
               ;
}
static void frame_free(Frame *frame) {
    if (!frame) return;
    nvm_affine_state_free(frame->locals);free(frame->stack);free(frame);
}
static Frame *frame_clone(const Frame *from) {
    Frame *out=calloc(1,sizeof(*out));
    if (!out) return 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                    ((void *)0)
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                        ;
    out->locals=nvm_affine_state_clone(from->locals);
    if (!out->locals) {frame_free(out);return 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                             ((void *)0)
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                 ;}
    out->count=from->count;
    out->global_count=from->global_count;
    memcpy(out->globals,from->globals,from->global_count);
    out->handler_count=from->handler_count;out->handler_floor=from->handler_floor;
    out->activation=from->activation;
    memcpy(out->handlers,from->handlers,from->handler_count*sizeof(*from->handlers));
    if (out->count) {
        out->stack=malloc(out->count*sizeof(*out->stack));
        if (!out->stack) {frame_free(out);return 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    ;}
        memcpy(out->stack,from->stack,out->count*sizeof(*out->stack));
    }
    return out;
}
static 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           stack_meet(Frame *destination,const Frame *incoming,
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                               _Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                    *changed) {
    if (!changed) return 
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                        0
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                             ;
    *changed=
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
            0
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                 ;
    if (destination->count!=incoming->count) return 
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                   0
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                        ;
    for (uint16_t i=0;i<destination->count;i++) {
        Value x=destination->stack[i],y=incoming->stack[i];
        if (x.tag!=y.tag || x.observation!=y.observation || x.owned!=y.owned ||
            ((x.owned || x.tag==TAG_STRUCT || x.tag==TAG_ARRAY) &&
             !nvm_affine_types_equal(destination->locals,(NvmAffineType){x.tag,x.layout},(NvmAffineType){y.tag,y.layout})) ||
            (x.observation && x.root!=y.root)) return 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                     0
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                          ;
        if (x.tag==TAG_UNION) {
            if (x.layout!=y.layout) return 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                          0
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                               ;
            if (x.variant!=y.variant || x.variant==
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                  (65535)
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                            ) {
                for (unsigned w=0;w<(256u +63u)/64u;w++) {
                    uint64_t a=x.variant==
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                         (65535)
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                   ?x.excluded[w]:
                        ~(x.variant/64u==w?1UL<<(x.variant%64u):0UL);
                    uint64_t b=y.variant==
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                         (65535)
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                   ?y.excluded[w]:
                        ~(y.variant/64u==w?1UL<<(y.variant%64u):0UL);
                    uint64_t joined=a&b;
                    if (destination->stack[i].excluded[w]!=joined) {
                        destination->stack[i].excluded[w]=joined;*changed=
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                         1
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                             ;
                    }
                }
                if (x.variant!=
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                              (65535)
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                        ) {
                    destination->stack[i].variant=
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                 (65535)
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                           ;*changed=
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                     1
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                         ;
                }
            }
            if (x.root!=y.root && x.root!=
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                         (65535)
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   ) {
                destination->stack[i].root=
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                          (65535)
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    ;*changed=
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                              1
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                  ;
            }
        }
    }
    return 
# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          1
# 92 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
              ;
}
static 
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           scalar(uint8_t tag) {
    return tag==TAG_INT || tag==TAG_U8 || tag==TAG_BOOL || tag==TAG_FLOAT;
}
static 
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 97 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           union_fact_for_layout(const NvmModule *module,uint32_t layout,
                                  uint16_t variant,NvmUnionVariantFact *out) {
    if (!module || !out) return 
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                               0
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                    ;
    for (uint32_t ordinal=0;ordinal<module->union_count;ordinal++) {
        NvmUnionVariantFact fact;
        if (nvm_ownership_union_variant(module,ordinal,variant,&fact)!=NVM_V2_OK)
            continue;
        if (fact.layout==layout) {*out=fact;return 
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                  1
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                      ;}
    }
    return 
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          0
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
               ;
}
static 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           push(Frame *f,Value value) {
    if (f->count==256u) return 
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                              0
# 109 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   ;
    Value *next=realloc(f->stack,(f->count+1)*sizeof(*next));
    if (!next) return 
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                     0
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                          ;
    f->stack=next;f->stack[f->count++]=value;return 
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                   1
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                       ;
}
static 
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           pop_scalar(Frame *f,uint8_t tag) {
    if (!f->count || (f->stack[f->count-1].observation || f->stack[f->count-1].owned) ||
        f->stack[f->count-1].tag!=tag) return 
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                             0
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                  ;
    f->count--;return 
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                     1
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                         ;
}
typedef struct {
    
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        value_graph, globals_valid, effect_globals;
    uint32_t global_count;
    NvmOwnershipGlobal globals[256u];


    uint8_t global_allowed[8u][256u];
    uint8_t global_returns[8u][256u];
    uint32_t fact_function, fact_capacity;
    NvmAffineInstructionFact *facts;
    uint8_t status[8u];
    NvmAffineAnalysis results[8u];
    uint16_t escape_count[8u];
    uint32_t escapes[8u][256u];
} AnalysisCalls;


# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
_Bool 
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
    nvm_affine_value_call_graph(const NvmModule *m) {
    if (!m || !m->functions || !m->function_count ||
        m->function_count>8u || m->header.entry_point!=0) return 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                     0
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                          ;
    
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        edges[8u][8u]={{
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                  0
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                       }};
    for (uint32_t f=0;f<m->function_count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];
        if ((!f && (fn->arity || fn->result_count!=1 ||
            (fn->result_tag!=TAG_INT && fn->result_tag!=TAG_BOOL && fn->result_tag!=TAG_U8))) || fn->upvalue_count ||
            fn->local_count>256u ||
            fn->code_length>4096u*32) return 
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                        0
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                             ;
        NvmAffineState *state=nvm_affine_state_create(m,f,fn->local_count);
        NvmAffineType parameters[8u],result;uint16_t count=0,fields=0;
        
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            valid=nvm_affine_value_parameters(state,parameters,8u,&count) && count==fn->arity &&
            nvm_affine_value_result(state,&result,&fields);
        nvm_affine_state_free(state);
        if (!valid) return 
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                          0
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                               ;
        VmDecodedFunction decoded={0};char error[256];
        if (!vm_decode_function(m,f,&decoded,error)) return 
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                           0
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                ;
        if (!decoded.instruction_count || decoded.instruction_count>4096u) valid=
# 153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                                      0
# 153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                                           ;
        for (uint32_t i=0;i<decoded.instruction_count && valid;i++) {
            const DecodedInstruction *in=&decoded.instructions[i].instruction;
            if (in->opcode==OP_CALL) {
                uint32_t target=in->operands[0].u32;
                if (!target || target>=m->function_count) valid=
# 158 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                               0
# 158 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                    ;
                else edges[f][target]=
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                     1
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                         ;
            } else if (in->opcode==OP_CALL_REF || in->opcode==OP_TAIL_CALL ||
                       in->opcode==OP_CALL_INDIRECT || in->opcode==OP_CALL_MODULE ||
                       in->opcode==OP_CALL_EXTERN) valid=
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                        0
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                             ;
        }
        vm_decoded_function_free(&decoded);
        if (!valid) return 
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                          0
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                               ;
    }
    for (uint32_t k=0;k<m->function_count;k++)
        for (uint32_t i=0;i<m->function_count;i++)
            for (uint32_t j=0;j<m->function_count;j++)
                edges[i][j]=edges[i][j] || (edges[i][k] && edges[k][j]);
    for (uint32_t i=0;i<m->function_count;i++) if (edges[i][i]) return 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                      0
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                           ;
    return 
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          1
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
              ;
}
static void analysis_calls_init(AnalysisCalls *calls,const NvmModule *module) {
    calls->globals_valid=nvm_ownership_globals(module,calls->globals,
        256u,&calls->global_count)==NVM_V2_OK;
    calls->value_graph=calls->globals_valid && nvm_affine_value_call_graph(module);
    if(calls->value_graph && calls->global_count) {
        for(uint32_t f=0;f<module->function_count;f++) {
            VmDecodedFunction decoded={0};char error[256];
            if(!vm_decode_function(module,f,&decoded,error)){calls->globals_valid=
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                 0
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                      ;return;}
            for(uint32_t i=0;i<decoded.instruction_count;i++) {
                uint8_t op=decoded.instructions[i].instruction.opcode;
                if(op==OP_HANDLER_PUSH || op==OP_HANDLER_POP || op==OP_PERFORM || op==OP_EFFECT_RESUME)
                    calls->effect_globals=
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                         1
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                             ;
            }
            vm_decoded_function_free(&decoded);
        }
    }
}


static void global_require(Frame *frame,AnalysisCalls *calls,uint32_t function,
                           uint32_t slot,uint8_t permitted) {
    if(calls->effect_globals)return;
    calls->global_allowed[function][slot]&=
        nvm_affine_global_require(frame->globals[slot],permitted);
}

static NvmAffineAnalysis analyze(const NvmModule *m,uint32_t function,
                                   const NvmAffineState *caller,uint32_t reference,AnalysisCalls *calls);
static 
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           supported(uint8_t op,
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                _Bool 
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                     value_graph) {
    switch(op) {
    case OP_HALT: case OP_CALL: case OP_CALL_REF: case OP_MATCH_TAG:
    case OP_HANDLER_PUSH: case OP_HANDLER_POP: case OP_PERFORM: case OP_EFFECT_RESUME:
    case OP_BORROW_PATH_SHARED: case OP_BORROW_PATH_EXCLUSIVE:
    case OP_REBORROW_SHARED: case OP_REBORROW_EXCLUSIVE:
    case OP_REGION_BEGIN: case OP_REGION_END:
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE: case OP_REF_GET: case OP_REF_SET:
    case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL: case OP_OWN_PACK: case OP_OWN_UNPACK_LOCAL:
    case OP_ARR_NEW: case OP_ARR_LITERAL: case OP_ARR_PUSH: case OP_ARR_POP:
    case OP_ARR_GET: case OP_ARR_SET: case OP_ARR_LEN: case OP_ARR_SLICE: case OP_ARR_REMOVE:
    case OP_NOP: case OP_PUSH_VOID: case OP_PUSH_I64: case OP_PUSH_U8: case OP_PUSH_F64: case OP_PUSH_BOOL:
    case OP_DUP: case OP_POP: case OP_SWAP: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_AGG_PACK: case OP_AGG_GET: case OP_AGG_TAG: case OP_STRUCT_GET:
    case OP_ADD: case OP_SUB: case OP_MUL:
    case OP_DIV: case OP_MOD: case OP_NEG: case OP_EQ: case OP_NE: case OP_LT:
    case OP_LE: case OP_GT: case OP_GE: case OP_AND: case OP_OR: case OP_NOT:
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV: case OP_F64_NEG:
    case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE: case OP_RET: case OP_ASSERT:
        return 
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              1
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    case OP_PUSH_STR: case OP_PRINT: case OP_PRINTLN:
    case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL:
        return value_graph;
    default:return 
# 226 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                  0
# 226 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                       ;
    }
}
static 
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           effect_value_matches(const NvmAffineState *state,Value value,
                                   NvmOwnershipEffectValue declared) {
    NvmAffineType type={declared.tag,declared.layout};
    return !value.observation && value.tag==type.tag &&
        value.owned==nvm_affine_type_is_owned(state,type) &&
        ((type.tag!=TAG_STRUCT && type.tag!=TAG_UNION && type.tag!=TAG_ARRAY) ||
         nvm_affine_types_equal(state,(NvmAffineType){value.tag,value.layout},type));
}
static 
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           effect_key_equal(const NvmModule *module,uint32_t a,uint32_t b) {
    const char *left=nvm_get_string(module,a),*right=nvm_get_string(module,b);
    return left && right && nvm_get_string_len(module,a)==nvm_get_string_len(module,b) &&
        !strcmp(left,right);
}
static 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           effect_escape(AnalysisCalls *calls,const NvmModule *module,
                            uint32_t function,const Frame *frame,uint32_t key) {
    for (uint16_t i=0;i<frame->handler_count;i++)
        if (effect_key_equal(module,key,frame->handlers[i].key)) return 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                       1
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                           ;
    if (function>=8u) return 
# 246 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                 0
# 246 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                      ;
    uint16_t *count=&calls->escape_count[function];
    for (uint16_t i=0;i<*count;i++)
        if (effect_key_equal(module,key,calls->escapes[function][i])) return 
# 249 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                            1
# 249 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                ;
    if (*count==256u) return 
# 250 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                 0
# 250 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                      ;
    calls->escapes[function][(*count)++]=key;
    return 
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          1
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
              ;
}

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
           array_index(Value v) { return v.tag==TAG_INT && !v.owned && !v.observation; }
static 
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
      _Bool 
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
           array_push_type(Frame *f,NvmAffineType type) {
    return push(f,(Value){.tag=type.tag,.layout=type.layout,.root=
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                                                 (65535)
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                                                           ,
        .owned=nvm_affine_type_is_owned(f->locals,type),.variant=
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                                                (65535)
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                                                                          });
}
static const char *array_step(Frame *f,const DecodedInstruction *in,
        const NvmModule *module,uint32_t function,uint32_t pc) {
    uint8_t op=in->opcode;NvmAffineType type,element;
    if (!nvm_affine_has_array_types(f->locals)) return "I require retained element types for array flow";
    if (op==OP_ARR_NEW || op==OP_ARR_LITERAL) {
        uint16_t count=op==OP_ARR_LITERAL?in->operands[1].u16:0;
        uint8_t tag=in->operands[0].u8;
        if (count>f->count) return "I require all declared array literal elements";
        if (!count) {
            uint32_t declared;
            if (nvm_ownership_array_constructor(module,function,pc,&declared)!=NVM_V2_OK)
                return "I require checked empty-array constructor declarations";
            if (declared!=0xFFFFFFFFu) {
                type=(NvmAffineType){TAG_ARRAY,declared};
                if (!nvm_affine_array_element(f->locals,type,&element) || element.tag!=tag)
                    return "I require the exact declared empty-array element tag";
            } else if (!nvm_affine_array_tag_type(f->locals,tag,&type))
                return "I require an unambiguous retained element type for empty array construction";
        } else {
            Value first=f->stack[f->count-count];element=(NvmAffineType){first.tag,first.layout};
            if (element.tag!=tag || !nvm_affine_array_type(f->locals,element,&type))
                return "I require an exact retained array literal element type";
            for (uint16_t i=0;i<count;i++)
                if (!effect_value_matches(f->locals,f->stack[f->count-count+i],
                        (NvmOwnershipEffectValue){element.tag,element.layout}))
                    return "I require exact array literal element ownership in source order";
        }
        f->count-=count;
        return array_push_type(f,type)?
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                      ((void *)0)
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                          :"I cannot retain an array construction result";
    }
    uint16_t count=(op==OP_ARR_SET || op==OP_ARR_SLICE)?3:
        (op==OP_ARR_PUSH || op==OP_ARR_GET || op==OP_ARR_REMOVE)?2:1;
    if (f->count<count) return "I require every array operation operand";
    Value array=f->stack[f->count-count];type=(NvmAffineType){array.tag,array.layout};
    if (!nvm_affine_array_element(f->locals,type,&element)) return "I require an exact array operand";
    if (op==OP_ARR_LEN) {
        if (array.owned || (array.observation &&
            !nvm_affine_owner_access(f->locals,array.root,
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                                         ((void *)0)
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                                             ,0,
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                                                0
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                                                     )))
            return "I require a live owner observation for resource-array length";
        f->count--;return array_push_type(f,(NvmAffineType){TAG_INT,0xFFFFFFFFu})?
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                                                                     ((void *)0)
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                                                                         :
            "I cannot retain array length";
    }
    if (array.observation) return "I cannot mutate or extract through an array owner observation";
    if (op!=OP_ARR_PUSH && array.owned)
        return "I require explicit resource-element extraction and disposal contracts";
    if ((op==OP_ARR_GET || op==OP_ARR_REMOVE || op==OP_ARR_SET || op==OP_ARR_SLICE) &&
        !array_index(f->stack[f->count-count+1])) return "I require an integer array index";
    if (op==OP_ARR_SLICE && !array_index(f->stack[f->count-1])) return "I require an integer slice end";
    if (op==OP_ARR_PUSH || op==OP_ARR_SET) {
        if (!effect_value_matches(f->locals,f->stack[f->count-1],
                (NvmOwnershipEffectValue){element.tag,element.layout}))
            return "I require the exact array element type and ownership";
    }
    f->count-=count;
    if (op==OP_ARR_GET || op==OP_ARR_POP) type=element;
    return array_push_type(f,type)?
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc" 3 4
                                  ((void *)0)
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_array_flow.inc"
                                      :"I cannot retain an array operation result";
}
# 256 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2

static const char *step(Frame *f,const DecodedInstruction *in,uint16_t locals,const NvmModule *module,uint32_t function,uint32_t pc,AnalysisCalls *calls) {
    uint8_t op=in->opcode,tag=TAG_VOID,mode;
    uint16_t local;
    switch(op) {
    case OP_ARR_NEW: case OP_ARR_LITERAL: case OP_ARR_PUSH: case OP_ARR_POP:
    case OP_ARR_GET: case OP_ARR_SET: case OP_ARR_LEN: case OP_ARR_SLICE: case OP_ARR_REMOVE:
        return array_step(f,in,module,function,pc);
    case OP_NOP: case OP_JMP: case OP_HALT: return 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                  ((void *)0)
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                      ;
    case OP_CALL: {
        uint32_t target=in->operands[0].u32;
        if (!calls->value_graph || !target || target>=module->function_count)
            return "I require a checked acyclic owned value call";
        NvmAffineState *callee=nvm_affine_state_create(module,target,module->functions[target].local_count);
        NvmAffineType parameters[8u],result;uint16_t count=0,fields=0;
        
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            valid=nvm_affine_value_parameters(callee,parameters,8u,&count) &&
            nvm_affine_value_result(callee,&result,&fields);
        nvm_affine_state_free(callee);
        if (!valid || count!=module->functions[target].arity || f->count<count)
            return "I require a complete consuming argument list";
        for (uint16_t p=0;p<count;p++) {
            Value argument=f->stack[f->count-count+p];
            NvmAffineType parameter=parameters[p];
            if (argument.observation || argument.tag!=parameter.tag ||
                argument.owned!=nvm_affine_type_is_owned(f->locals,parameter) ||
                ((argument.owned || argument.tag==TAG_UNION || argument.tag==TAG_STRUCT || argument.tag==TAG_ARRAY) &&
                 !nvm_affine_types_equal(f->locals,(NvmAffineType){argument.tag,argument.layout},parameter)))
                return "I require exact positional consuming argument types";
        }
        NvmAffineAnalysis call=analyze(module,target,
# 285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                    ((void *)0)
# 285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                        ,0,calls);
        if (!call.ok) return "I require complete consuming-helper owner resolution";
        if (calls->escape_count[target]) {
            if (!nvm_affine_can_suspend(f->locals))
                return "I cannot suspend live local owners across an escaping effect call";
            for (uint16_t i=0;i<f->count-count;i++)
                if (f->stack[i].owned || f->stack[i].observation)
                    return "I cannot suspend staged owners across an escaping effect call";
            for (uint16_t i=0;i<calls->escape_count[target];i++)
                if (!effect_escape(calls,module,function,f,calls->escapes[target][i]))
                    return "I cannot retain escaping operation identities";
        }
        for (uint32_t g=0;!calls->effect_globals && g<calls->global_count;g++) {
            global_require(f,calls,function,g,calls->global_allowed[target][g]);
            f->globals[g]=nvm_affine_global_compose(f->globals[g],calls->global_returns[target][g]);
        }
        f->count-=count;
        if (result.tag==TAG_VOID) return 
# 302 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                        ((void *)0)
# 302 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                            ;
        return push(f,(Value){.tag=result.tag,.root=
# 303 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                   (65535)
# 303 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                             ,
                              .owned=nvm_affine_type_is_owned(f->locals,result),.layout=result.layout,
                              .variant=
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                      (65535)
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                })
            ? 
# 306 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
             ((void *)0)
# 306 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                 :"I cannot retain a checked value-call result";
    }
    case OP_CALL_REF: {
        if (function!=0 || module->function_count!=2 || in->operands[0].u32!=1)
            return "I require entry-to-helper reference calls without recursion";
        NvmAffineAnalysis call=analyze(module,1,f->locals,in->operands[1].u16,calls);
        if (!call.ok) return "I require checked caller authority and a non-escaping helper";
        tag=module->functions[1].result_tag;
        if (module->functions[1].result_count!=1 ||
            (tag!=TAG_INT && tag!=TAG_BOOL && tag!=TAG_U8))
            return "I require a single scalar reference-call result";
        break;
    }
    case OP_HANDLER_PUSH: return 
# 319 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                ((void *)0)
# 319 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                    ;
    case OP_HANDLER_POP: {
        uint16_t count=in->operands[0].u16;
        if (count>f->handler_count-f->handler_floor)
            return "I cannot pop absent or inherited handlers";
        f->handler_count-=count;return 
# 324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                      ((void *)0)
# 324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                          ;
    }
    case OP_PERFORM: {
        NvmOwnershipEffect effect;
        if (nvm_ownership_effect(module,in->operands[0].u32,&effect)!=NVM_V2_OK ||
            effect.parameter_count!=in->operands[1].u16 || f->count<effect.parameter_count)
            return "I require the exact retained performed signature";
        uint16_t first=f->count-effect.parameter_count;
        for (uint16_t p=0;p<effect.parameter_count;p++)
            if (!effect_value_matches(f->locals,f->stack[first+p],effect.parameters[p]))
                return "I require exact positional effect argument ownership";
        for (uint16_t p=0;p<first;p++)
            if (f->stack[p].owned || f->stack[p].observation)
                return "I cannot abandon a staged owner across an effect";
        if (!nvm_affine_can_suspend(f->locals))
            return "I cannot abandon a local owner or borrow across an effect";
        if (!effect_escape(calls,module,function,f,effect.key_idx))
            return "I cannot retain escaping operation identities";
        f->count=first;
        NvmAffineType type={effect.result.tag,effect.result.layout};
        return push(f,(Value){.tag=type.tag,.layout=type.layout,.root=
# 344 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                     (65535)
# 344 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                               ,
                              .owned=nvm_affine_type_is_owned(f->locals,type),
                              .variant=
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                      (65535)
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                })?
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                   ((void *)0)
# 346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                       :
            "I cannot retain a resumed effect value";
    }
    case OP_PUSH_VOID:tag=TAG_VOID;break;
    case OP_PUSH_I64:tag=TAG_INT;break;
    case OP_PUSH_U8:tag=TAG_U8;break;
    case OP_PUSH_F64:tag=TAG_FLOAT;break;
    case OP_PUSH_BOOL:
        if (in->operands[0].u8>1) return "I require a Boolean literal";
        tag=TAG_BOOL;break;
    case OP_PUSH_STR: {
        if (!calls->value_graph)
            return "I require string literals inside an owned value-call graph";
        uint32_t index=in->operands[0].u32;
        if (index>=module->string_count || !module->strings || !module->string_lengths ||
            !module->strings[index] ||
            memchr(module->strings[index],'\0',module->string_lengths[index]))
            return "I require an instantiated string literal without embedded NUL";
        tag=TAG_STRING;break;
    }
    case OP_REGION_BEGIN:
        return nvm_affine_region_begin(f->locals)?
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                 ((void *)0)
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                     :"I cannot begin another reference region";
    case OP_REGION_END:
        return nvm_affine_region_end(f->locals)?
# 369 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                               ((void *)0)
# 369 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   :"I need a live reference region to end";
    case OP_REBORROW_SHARED: case OP_REBORROW_EXCLUSIVE:
        return nvm_affine_reborrow(f->locals,in->operands[0].u16,in->operands[1].u16,
            op==OP_REBORROW_SHARED?NVM_REFERENCE_SHARED:NVM_REFERENCE_EXCLUSIVE)?
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                ((void *)0)
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                    :
            "I require permitted parent authority and a fresh reborrow in a deeper region";
    case OP_BORROW_PATH_SHARED: case OP_BORROW_PATH_EXCLUSIVE:
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE: {
        
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            exclusive=op==OP_BORROW_LOCAL_EXCLUSIVE || op==OP_BORROW_PATH_EXCLUSIVE;
        uint16_t fields[32u],count=0;
        if ((op==OP_BORROW_PATH_SHARED || op==OP_BORROW_PATH_EXCLUSIVE) &&
            nvm_ownership_path(module,in->operands[2].u32,fields,32u,&count)!=NVM_V2_OK)
            return "I require a retained bounded ownership path";

        if (exclusive && observes_owner(f,in->operands[1].u16))
            return "I cannot borrow exclusively while an owner observation is on my stack";
        return nvm_affine_borrow(f->locals,in->operands[0].u16,in->operands[1].u16,
            fields,count,exclusive?NVM_REFERENCE_EXCLUSIVE:NVM_REFERENCE_SHARED)?
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                ((void *)0)
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                    :
            "I require an available scalar-leaf resource owner and reference slot in a live region";
    }
    case OP_REF_GET: case OP_REF_SET:
        if (!nvm_affine_reference_field(f->locals,in->operands[0].u16,
                in->operands[1].u16,op==OP_REF_SET,&tag))
            return "I require a live permitted scalar reference field";
        if (op==OP_REF_SET)
            return pop_scalar(f,tag)?
# 393 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                    ((void *)0)
# 393 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                        :"I require the exact scalar reference field type";
        break;
    case OP_OWN_MOVE_LOCAL: {
        NvmAffineType type;uint16_t variant=
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                           (65535)
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                     ;
        if (observes_owner(f,in->operands[0].u16))
            return "I cannot move while an owner observation is on my stack";
        (void)nvm_affine_union_variant(f->locals,in->operands[0].u16,&variant);
        if (!nvm_affine_take_local(f->locals,in->operands[0].u16,&type))
            return "I require a live unheld owner for an explicit move";
        return push(f,(Value){.tag=type.tag,.root=
# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                 (65535)
# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                           ,.owned=
# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                   1
# 402 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                       ,
                              .layout=type.layout,.variant=variant})?
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                    ((void *)0)
# 403 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                        :
            "I cannot extend my owned analysis stack";
    }
    case OP_OWN_STORE_LOCAL: {
        if (!f->count || !f->stack[f->count-1].owned)
            return "I require an owned token for an explicit store";
        Value value=f->stack[f->count-1];
        if (!nvm_affine_put_local(f->locals,in->operands[0].u16,(NvmAffineType){value.tag,value.layout}))
            return "I require an exact available owner destination";
        if (value.tag==TAG_UNION && value.variant!=
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                  (65535) 
# 412 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                             &&
            !nvm_affine_union_refine(f->locals,in->operands[0].u16,value.variant))
            return "I require the stored union's exact selected arm";
        f->count--;return 
# 415 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                         ((void *)0)
# 415 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                             ;
    }
    case OP_OWN_PACK: {
        NvmAffineType fields[256u];uint16_t count;
        uint32_t layout=in->operands[0].u32;
        if (!nvm_affine_type_is_owned(f->locals,(NvmAffineType){TAG_STRUCT,layout}) ||
            !nvm_affine_record_fields(f->locals,layout,fields,256u,&count) ||
            count>f->count) return "I require every declared field for owned construction";
        for (uint16_t i=0;i<count;i++) {
            Value value=f->stack[f->count-count+i];NvmAffineType field=fields[i];
            if (value.observation || value.tag!=field.tag ||
                (value.owned!=nvm_affine_type_is_owned(f->locals,field)) ||
                ((field.tag==TAG_STRUCT || field.tag==TAG_UNION) && value.layout!=field.layout))
                return "I require exact scalar or owned fields in declaration order";
        }
        f->count-=count;
        return push(f,(Value){.tag=TAG_STRUCT,.root=
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                   (65535)
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                             ,.owned=
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                     1
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                         ,
                              .layout=layout,.variant=
# 432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                     (65535)
# 432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                               })?
# 432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                  ((void *)0)
# 432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                      :
            "I cannot extend my owned analysis stack";
    }
    case OP_OWN_UNPACK_LOCAL: {
        NvmAffineType type,fields[256u];uint16_t count;
        uint16_t source=in->operands[0].u16;
        if (observes_owner(f,source))
            return "I cannot unpack while an owner observation is on my stack";
        if (!nvm_affine_local_type(f->locals,source,&type) ||
            !nvm_affine_owned_local_fields(f->locals,source,fields,256u,&count) ||
            f->count+count>256u || !nvm_affine_take_local(f->locals,source,&type))
            return "I require an intact owner and space for all unpacked fields";
        for (uint16_t i=0;i<count;i++) if (!push(f,(Value){.tag=fields[i].tag,
                                                    .root=
# 445 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                         (65535)
# 445 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                   ,
                                                    .owned=nvm_affine_type_is_owned(f->locals,fields[i]),
                                                    .layout=fields[i].layout,
                                                    .variant=
# 448 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                            (65535)
# 448 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                      }))
            return "I cannot extend my unpacked analysis stack";
        return 
# 450 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              ((void *)0)
# 450 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    }
    case OP_AGG_PACK: {
        if (in->operands[0].u8==AGG_RECORD) {
            uint32_t layout=in->operands[1].u32;
            NvmAffineType fields[256u];uint16_t count=0;
            if (!calls->value_graph || in->operands[2].u16 ||
                !nvm_affine_record_is_copyable(f->locals,layout) ||
                !nvm_affine_record_fields(f->locals,layout,fields,256u,&count) ||
                count!=in->operands[3].u16 || count>f->count)
                return "I require an exact complete copyable record constructor";
            for (uint16_t i=0;i<count;i++) {
                Value value=f->stack[f->count-count+i];
                if (value.observation || value.owned || value.tag!=fields[i].tag || value.layout!=fields[i].layout)
                    return "I require exact copyable record fields without owned authority";
            }
            f->count-=count;
            return push(f,(Value){.tag=TAG_STRUCT,.root=
# 467 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                       (65535)
# 467 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                 ,.layout=layout,
                .variant=
# 468 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                        (65535)
# 468 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                  })?
# 468 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                     ((void *)0)
# 468 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                         :"I cannot retain a copyable record";
        }
        if (in->operands[0].u8!=AGG_VARIANT)
            return "I require explicit owned construction for records";
        NvmUnionVariantFact fact;
        uint16_t variant=in->operands[2].u16,count=in->operands[3].u16;
        if (nvm_ownership_union_variant(module,in->operands[1].u32,variant,&fact)!=NVM_V2_OK ||
            count!=fact.field_count || count>f->count)
            return "I require an exact retained scalar-union constructor shape";
        NvmAffineType fields[256u];uint16_t available=0;
        if (!nvm_affine_union_fields(f->locals,fact.layout,variant,fields,
                                     256u,&available) || available!=count)
            return "I require exact scalar-union payload facts";
        for (uint16_t i=0;i<count;i++) {
            Value value=f->stack[f->count-count+i];
            if (value.observation || value.tag!=fields[i].tag ||
                value.owned!=nvm_affine_type_is_owned(f->locals,fields[i]) ||
                ((value.tag==TAG_STRUCT || value.tag==TAG_UNION) && value.layout!=fields[i].layout))
                return "I require exact scalar-union fields in declaration order";
        }
        f->count-=count;
        return push(f,(Value){.tag=TAG_UNION,.root=
# 489 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                  (65535)
# 489 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                            ,.layout=fact.layout,
                              .owned=nvm_affine_type_is_owned(f->locals,(NvmAffineType){TAG_UNION,fact.layout}),
                              .variant=variant})?
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                ((void *)0)
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    :
            "I cannot retain a checked scalar-union value";
    }
    case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL: {
        uint32_t index=in->operands[0].u32;
        if (!calls->value_graph || index>=calls->global_count)
            return "I require an exact declared global slot";
        NvmOwnershipGlobal declaration=calls->globals[index];
        NvmAffineType type={declaration.tag,declaration.layout};
        if (nvm_affine_type_is_owned(f->locals,type))
            return "I require explicit global owner transfers and lifetime before resource storage";
        if (op==OP_LOAD_GLOBAL) {
            global_require(f,calls,function,index,2u);
            return push(f,(Value){.tag=type.tag,.root=
# 504 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                     (65535)
# 504 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                               ,.layout=type.layout,
                                  .variant=
# 505 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                          (65535)
# 505 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                    })?
# 505 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                       ((void *)0)
# 505 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                           :
                "I cannot retain a checked global load";
        }
        if (!f->count) return "I require a value for a global store";
        Value value=f->stack[f->count-1];
        if (value.observation || value.owned || value.tag!=type.tag || value.layout!=type.layout)
            return "I require the exact global type without an owner or observation escape";
        if (!declaration.mutable) global_require(f,calls,function,index,1u);
        f->globals[index]=nvm_affine_global_compose(f->globals[index],10u);
        f->count--;return 
# 514 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                         ((void *)0)
# 514 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                             ;
    }
    case OP_LOAD_LOCAL: {
        local=in->operands[0].u16;
        if (!nvm_affine_local_info(f->locals,local,&tag,&mode))
            return "I require a live checked local";
        uint32_t layout=0xFFFFFFFFu;uint16_t variant=
# 520 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                        (65535)
# 520 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                  ;
        
# 521 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 521 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            observation=tag==TAG_STRUCT;
        if (tag==TAG_STRUCT && !mode) {
            NvmAffineType type;
            if (!nvm_affine_local_type(f->locals,local,&type)) return "I require an exact record local";
            layout=type.layout;
            if (nvm_affine_record_is_copyable(f->locals,layout)) observation=
# 526 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                            0
# 526 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                 ;
        }
        if (tag==TAG_ARRAY) {
            NvmAffineType type;
            if (!nvm_affine_local_type(f->locals,local,&type)) return "I require an exact array local";
            layout=type.layout;observation=nvm_affine_type_is_owned(f->locals,type);
        }
        if (tag==TAG_UNION) {
            NvmAffineType type;
            if (!nvm_affine_local_type(f->locals,local,&type))
                return "I require an exact scalar-union local";
            if (nvm_affine_type_is_owned(f->locals,type))
                return "I require an explicit move of a resource union";
            layout=type.layout;
            (void)nvm_affine_union_variant(f->locals,local,&variant);
        }
        if (!push(f,(Value){.tag=tag,.observation=observation,.root=local,
                            .layout=layout,.variant=variant}))
            return "I cannot extend my analysis stack";
        return 
# 545 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              ((void *)0)
# 545 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    }
    case OP_STORE_LOCAL: {
        local=in->operands[0].u16;
        if (local>=locals || !f->count || (f->stack[f->count-1].observation || f->stack[f->count-1].owned))
            return "I refuse an observation escape or missing scalar store";
        Value value=f->stack[f->count-1];


        
# 554 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 554 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            defined=scalar(value.tag) ? nvm_affine_scalar_define(f->locals,local) :
            calls->value_graph && value.tag==TAG_STRING ? nvm_affine_string_define(f->locals,local) :
            calls->value_graph && value.tag==TAG_UNION ?
                nvm_affine_union_define(f->locals,local,value.layout,value.variant) :
            calls->value_graph && value.tag==TAG_STRUCT ?
                nvm_affine_record_define(f->locals,local,value.layout) :
            calls->value_graph && value.tag==TAG_ARRAY ?
                nvm_affine_array_define(f->locals,local,value.layout) : 
# 561 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                       0
# 561 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                            ;
        if (!defined ||
            !nvm_affine_local_info(f->locals,local,&tag,&mode) || tag!=value.tag)
            return "I require the exact scalar local type";
        f->count--;return 
# 565 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                         ((void *)0)
# 565 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                             ;
    }
    case OP_MATCH_TAG: {
        if (!f->count || f->stack[f->count-1].tag!=TAG_UNION ||
            f->stack[f->count-1].observation)
            return "I require an exact scalar-union match source";
        NvmUnionVariantFact fact;
        if (!union_fact_for_layout(module,f->stack[f->count-1].layout,
                                   in->operands[0].u16,&fact))
            return "I require a match variant within the concrete union";

        return 
# 576 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              ((void *)0)
# 576 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    }
    case OP_AGG_TAG:
        if (!f->count || f->stack[f->count-1].tag!=TAG_UNION ||
            f->stack[f->count-1].observation || f->stack[f->count-1].owned)
            return "I require an exact scalar-union tag source";
        f->count--;tag=TAG_INT;break;
    case OP_AGG_GET:
        if (f->count && f->stack[f->count-1].tag==TAG_STRUCT &&
            !f->stack[f->count-1].observation && !f->stack[f->count-1].owned) {
            Value value=f->stack[f->count-1];
            NvmAffineType fields[256u];uint16_t count=0;
            if (!nvm_affine_record_is_copyable(f->locals,value.layout) ||
                !nvm_affine_record_fields(f->locals,value.layout,fields,256u,&count) ||
                in->operands[0].u16>=count) return "I require an exact ordinary record projection";
            NvmAffineType field=fields[in->operands[0].u16];
            if (nvm_affine_type_is_owned(f->locals,field)) return "I refuse an owned ordinary projection";
            f->count--;
            return push(f,(Value){.tag=field.tag,.root=
# 594 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                      (65535)
# 594 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                ,.layout=field.layout,
                .variant=
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                        (65535)
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                  })?
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                     ((void *)0)
# 595 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                         :"I cannot retain an ordinary projection";
        }
        if (f->count && f->stack[f->count-1].tag==TAG_UNION &&
            !f->stack[f->count-1].observation && !f->stack[f->count-1].owned) {
            Value value=f->stack[f->count-1];
            if (value.variant==
# 600 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                              (65535)
# 600 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                        )
                return "I require a proven scalar-union variant before projection";
            NvmAffineType fields[256u];uint16_t count=0;
            if (!nvm_affine_union_fields(f->locals,value.layout,value.variant,fields,
                                         256u,&count) ||
                in->operands[0].u16>=count)
                return "I require an exact scalar-union payload field";
            NvmAffineType field=fields[in->operands[0].u16];
            if (!scalar(field.tag) && field.tag!=TAG_STRING)
                return "I require destructive unpack for aggregate payloads";
            tag=field.tag;f->count--;break;
        }


    case OP_STRUCT_GET:
        if (!f->count || !f->stack[f->count-1].observation || f->stack[f->count-1].owned ||
            !(nvm_affine_scalar_field(f->locals,f->stack[f->count-1].root,
                                     in->operands[0].u16,&tag) ||
              (calls->value_graph && nvm_affine_string_field(f->locals,f->stack[f->count-1].root,
                                     in->operands[0].u16,&tag))))
            return "I require a checked scalar field observation";
        f->count--;break;
    case OP_DUP:
        if (!f->count || (f->stack[f->count-1].observation || f->stack[f->count-1].owned))
            return "I refuse to duplicate reference authority";
        if (!calls->value_graph && f->stack[f->count-1].tag==TAG_STRING)
            return "I refuse unsupported string duplication";
        if (!push(f,f->stack[f->count-1])) return "I cannot extend my analysis stack";
        return 
# 628 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              ((void *)0)
# 628 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    case OP_POP:
        if (!f->count || (f->stack[f->count-1].observation || f->stack[f->count-1].owned))
            return "I require a scalar discard; an observation is not an owned consume";
        if (!calls->value_graph && f->stack[f->count-1].tag==TAG_STRING)
            return "I require PRINT or PRINTLN to consume a string";
        f->count--;return 
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                         ((void *)0)
# 634 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                             ;
    case OP_SWAP:
        if (f->count<2 || (f->stack[f->count-1].observation || f->stack[f->count-1].owned) || (f->stack[f->count-2].observation || f->stack[f->count-2].owned))
            return "I require scalar stack permutation";
        if (!calls->value_graph && (f->stack[f->count-1].tag==TAG_STRING || f->stack[f->count-2].tag==TAG_STRING))
            return "I refuse unsupported string permutation";
        {Value value=f->stack[f->count-1];f->stack[f->count-1]=f->stack[f->count-2];f->stack[f->count-2]=value;}
        return 
# 641 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              ((void *)0)
# 641 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                  ;
    case OP_PRINT: case OP_PRINTLN:
        if (!calls->value_graph)
            return "I require string output inside an owned value-call graph";
        return pop_scalar(f,TAG_STRING)?
# 645 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                       ((void *)0)
# 645 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                           :
            "I require one exact immutable string print operand";
    case OP_ASSERT:
        return pop_scalar(f,TAG_BOOL)?
# 648 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                     ((void *)0)
# 648 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                         :"I require an exact Boolean assertion condition";
    case OP_JMP_TRUE: case OP_JMP_FALSE:
        return pop_scalar(f,TAG_BOOL)?
# 650 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                     ((void *)0)
# 650 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                         :"I require an exact Boolean branch condition";
    case OP_NOT: case OP_AND: case OP_OR:
        if (!pop_scalar(f,TAG_BOOL) || (op!=OP_NOT && !pop_scalar(f,TAG_BOOL)))
            return "I require Boolean operands";
        tag=TAG_BOOL;break;
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
        if (!pop_scalar(f,TAG_INT) || (op!=OP_NEG && !pop_scalar(f,TAG_INT)))
            return "I require integer arithmetic operands";
        tag=TAG_INT;break;
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV: case OP_F64_NEG:
        if (!pop_scalar(f,TAG_FLOAT) || (op!=OP_F64_NEG && !pop_scalar(f,TAG_FLOAT)))
            return "I require float arithmetic operands";
        tag=TAG_FLOAT;break;
    case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
        if (!pop_scalar(f,TAG_FLOAT) || !pop_scalar(f,TAG_FLOAT))
            return "I require float comparison operands";
        tag=TAG_BOOL;break;
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
        if (calls->value_graph && (op==OP_EQ || op==OP_NE) && f->count &&
            f->stack[f->count-1].tag==TAG_STRING) {
            if (!pop_scalar(f,TAG_STRING) || !pop_scalar(f,TAG_STRING))
                return "I require exact STRING equality operands";
            tag=TAG_BOOL;break;
        }
        if (!f->count || (f->stack[f->count-1].observation || f->stack[f->count-1].owned) || !scalar(f->stack[f->count-1].tag))
            return "I require scalar comparison operands";
        tag=f->stack[f->count-1].tag;
        if (!pop_scalar(f,tag) || !pop_scalar(f,tag)) return "I require matching comparison tags";
        tag=TAG_BOOL;break;
    default:return "I require a connected affine instruction contract";
    }
    return push(f,(Value){.tag=tag,.root=
# 681 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                        (65535)
# 681 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                  ,.layout=0xFFFFFFFFu,
                          .variant=
# 682 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                  (65535)
# 682 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                            })?
# 682 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                               ((void *)0)
# 682 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                   :
        "I cannot extend my analysis stack";
}
typedef struct {
    uint32_t *items;
    
# 687 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 687 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        *queued;
    uint32_t capacity,head,tail,pending;
} Worklist;
static 
# 690 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 690 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           enqueue(Worklist *work,uint32_t index) {
    if (work->queued[index]) return 
# 691 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                   1
# 691 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                       ;
    if (work->pending==work->capacity) return 
# 692 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                             0
# 692 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                  ;
    work->items[work->tail]=index;
    work->tail=(work->tail+1)%work->capacity;work->pending++;
    work->queued[index]=
# 695 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                       1
# 695 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                           ;return 
# 695 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                   1
# 695 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                       ;
}
static 
# 697 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 697 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           propagate(Frame **frames,uint32_t target,const Frame *state,Worklist *work,
                       const char **error) {
    
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
   _Bool 
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
        changed=
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                1
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                    ;
    if (frames[target]) {
        if (frames[target]->handler_count!=state->handler_count ||
            frames[target]->handler_floor!=state->handler_floor ||
            frames[target]->activation!=state->activation ||
            memcmp(frames[target]->handlers,state->handlers,state->handler_count*sizeof(*state->handlers))) {
            *error="I require identical handler context at every control-flow join";return 
# 705 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                          0
# 705 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                               ;
        }
        
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            stack_changed=
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                          0
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                               ,locals_changed=
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                               0
# 707 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    ;
        if (!stack_meet(frames[target],state,&stack_changed) ||
            !nvm_affine_state_meet_initialization(frames[target]->locals,state->locals,&locals_changed)) {
            *error="I require exact ownership and stack provenance at every join";return 
# 710 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                        0
# 710 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                             ;
        }
        changed=stack_changed || locals_changed;
        if (frames[target]->global_count!=state->global_count) {
            *error="I require one global declaration domain at every join";return 
# 714 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                 0
# 714 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                      ;
        }
        for (uint16_t g=0;g<state->global_count;g++) {
            uint8_t joined=frames[target]->globals[g]|state->globals[g];
            if (joined!=frames[target]->globals[g]) {frames[target]->globals[g]=joined;changed=
# 718 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                              1
# 718 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                                  ;}
        }
    } else {
        frames[target]=frame_clone(state);
        if (!frames[target]) {*error="I cannot allocate an analysis branch";return 
# 722 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                  0
# 722 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                       ;}
    }
    if (changed && !enqueue(work,target)) {
        *error="I exceeded my bounded affine worklist";return 
# 725 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                             0
# 725 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                  ;
    }
    return 
# 727 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          1
# 727 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
              ;
}
static 
# 729 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
      _Bool 
# 729 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
           match_refine(Frame *frame,uint16_t variant) {
    if (!frame || !frame->count) return 
# 730 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                       0
# 730 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                            ;
    Value *value=&frame->stack[frame->count-1];
    if (value->tag!=TAG_UNION || value->observation ||
        (value->variant!=
# 733 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                        (65535) 
# 733 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   && value->variant!=variant))
        return 
# 734 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
              0
# 734 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                   ;
    value->variant=variant;memset(value->excluded,0,sizeof(value->excluded));



    return 
# 739 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
          1
# 739 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
              ;
}



static NvmAffineAnalysis analyze(const NvmModule *m,uint32_t function,
                                   const NvmAffineState *caller,uint32_t reference,AnalysisCalls *calls) {
    NvmAffineAnalysis result={0};
    const char *error="I require checked ownership declarations";
    VmDecodedFunction decoded={0};Frame **frames=
# 748 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                ((void *)0)
# 748 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    ;Worklist work={0};
    Frame *current=
# 749 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                  ((void *)0)
# 749 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                      ;
    if (!m || !m->functions || function>=m->function_count || !calls->globals_valid) goto done;
    if (calls->global_count && !calls->value_graph) {
        error="I require a bounded acyclic value graph for global flow";goto done;
    }
    if (calls->value_graph && !caller) {
        if (calls->status[function]==2) return calls->results[function];
        if (calls->status[function]==1) {error="I refuse recursive owned value analysis";goto done;}
        calls->status[function]=1;
        memset(calls->global_allowed[function],3,calls->global_count);
    }
    const NvmFunctionEntry *entry=&m->functions[function];
    if (entry->local_count>256u ||
        entry->code_length>4096u*32) {
        error="I exceeded my bounded affine analysis size";goto done;
    }
    NvmAffineState *initial=nvm_affine_state_create(m,function,entry->local_count);
    if (!initial) goto done;
    if (caller && !nvm_affine_bind_caller(initial,caller,reference)) {
        nvm_affine_state_free(initial);error="I require exact caller-origin parameter authority";goto done;
    }
    char detail[256];
    if (!vm_decode_function(m,function,&decoded,detail)) {
        nvm_affine_state_free(initial);error="I require decodable function control flow";goto done;
    }
    uint32_t count=decoded.instruction_count;
    if (!count || count>4096u) {
        nvm_affine_state_free(initial);error="I exceeded my bounded affine instruction count";goto done;
    }
    for (uint32_t i=0;i<count;i++) if (!supported(decoded.instructions[i].instruction.opcode,
                                                  calls->value_graph)) {
        result.byte_offset=decoded.instructions[i].byte_offset;
        uint8_t op=decoded.instructions[i].instruction.opcode;
        nvm_affine_state_free(initial);
        error=op==OP_PUSH_STR
            ? "I require string literals inside an owned value-call graph"
            : (op==OP_PRINT || op==OP_PRINTLN)
                ? "I require string output inside an owned value-call graph"
                : "I require a connected affine instruction contract";
        goto done;
    }
    for (uint32_t i=0;i<count;i++) {
        const DecodedInstruction *in=&decoded.instructions[i].instruction;
        if (in->opcode==OP_HANDLER_PUSH || in->opcode==OP_PERFORM) {
            NvmOwnershipEffect effect;
            uint16_t arity=in->operands[in->opcode==OP_HANDLER_PUSH?3:1].u16;
            if (nvm_ownership_effect(m,in->operands[0].u32,&effect)!=NVM_V2_OK ||
                arity!=effect.parameter_count) {
                nvm_affine_state_free(initial);error="I require a retained exact effect signature at every operation";goto done;
            }
            if (in->opcode==OP_HANDLER_PUSH) {
                uint16_t first=in->operands[2].u16;
                if ((uint32_t)first+arity>entry->local_count) {
                    nvm_affine_state_free(initial);error="I require bounded handler parameter slots";goto done;
                }
                for (uint16_t p=0;p<arity;p++) {
                    NvmAffineType type;
                    if (!nvm_affine_local_type(initial,first+p,&type) ||
                        !nvm_affine_types_equal(initial,type,(NvmAffineType){effect.parameters[p].tag,effect.parameters[p].layout})) {
                        nvm_affine_state_free(initial);error="I require exact declared handler parameter types";goto done;
                    }
                }
            }
        }
        if ((in->opcode==OP_LOAD_GLOBAL || in->opcode==OP_STORE_GLOBAL) &&
            in->operands[0].u32>=calls->global_count) {
            result.byte_offset=decoded.instructions[i].byte_offset;
            nvm_affine_state_free(initial);error="I require an exact declared global slot";goto done;
        }
    }
    if (calls->facts && !caller && function==calls->fact_function && count!=calls->fact_capacity) {
        nvm_affine_state_free(initial);error="I require exact instruction fact capacity";goto done;
    }
    frames=calloc(count,sizeof(*frames));work.capacity=count;
    work.items=malloc(count*sizeof(*work.items));work.queued=calloc(count,sizeof(*work.queued));
    if (!frames || !work.items || !work.queued) {nvm_affine_state_free(initial);error="I cannot allocate analysis state";goto done;}
    frames[0]=calloc(1,sizeof(*frames[0]));
    if (!frames[0]) {nvm_affine_state_free(initial);error="I cannot allocate entry state";goto done;}
    frames[0]->locals=initial;
    frames[0]->global_count=(uint16_t)calls->global_count;
    memset(frames[0]->globals,9,calls->global_count);


    uint32_t visit_limit=count*(2u*(uint32_t)entry->local_count+4u*calls->global_count+1u+
        256u*(256u +1u));



    if (!enqueue(&work,0)) {error="I cannot queue my entry state";goto done;}
    while (work.pending) {
        if (result.visits>=visit_limit) {error="I exceeded my bounded affine visit count";goto done;}
        result.visits++;
        uint32_t index=work.items[work.head];
        work.head=(work.head+1)%work.capacity;work.pending--;work.queued[index]=
# 842 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                               0
# 842 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                    ;
        const VmDecodedInstruction *instruction=&decoded.instructions[index];
        result.byte_offset=instruction->byte_offset;
        if (!frames[index]->visited) {frames[index]->visited=
# 845 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                            1
# 845 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                ;result.reachable++;}
        current=frame_clone(frames[index]);
        if (!current) {error="I cannot allocate an instruction state";goto done;}
        uint8_t op=instruction->instruction.opcode;
        
# 849 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
       _Bool 
# 849 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
            fallthrough=
# 849 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                        1
# 849 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                            ;
        if (op==OP_RET) {
            uint8_t tag=TAG_VOID;
            if (current->count==1 && !current->stack[0].observation) tag=current->stack[0].tag;
            else if (current->count) {error="I refuse an observation escape or extra return operands";goto done;}
            
# 854 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
           _Bool 
# 854 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                exact_value=current->count==1 &&
                (current->stack[0].owned || current->stack[0].tag==TAG_UNION || current->stack[0].tag==TAG_STRUCT || current->stack[0].tag==TAG_ARRAY);
            
# 856 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
           _Bool 
# 856 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                exit_ok=exact_value
                ? nvm_affine_can_exit_type(current->locals,(NvmAffineType){tag,current->stack[0].layout})
                : nvm_affine_can_exit_scalar(current->locals,tag);
            if (!exit_ok) {
                error="I require an exact declared result and no live owned obligations";goto done;
            }
            for (uint32_t g=0;g<calls->global_count;g++)
                calls->global_returns[function][g]|=current->globals[g];
        } else if (op==OP_EFFECT_RESUME) {
            if (!current->activation || current->count!=1 || current->stack[0].observation ||
                !nvm_affine_can_resume(current->locals,
                    (NvmAffineType){current->stack[0].tag,
                        current->stack[0].tag==TAG_STRUCT || current->stack[0].tag==TAG_UNION || current->stack[0].tag==TAG_ARRAY
                            ?current->stack[0].layout:0xFFFFFFFFu}) ||
                current->stack[0].owned!=nvm_affine_type_is_owned(current->locals,
                    (NvmAffineType){current->stack[0].tag,current->stack[0].layout})) {
                error="I require the active operation result and resolved arm ownership at resumption";goto done;
            }
        } else if (op==OP_HALT) {
            if (current->count || current->activation || !nvm_affine_can_suspend(current->locals)) {
                error="I require an empty stack and resolved owners at my terminal invariant";goto done;
            }
        } else {
            error=step(current,&instruction->instruction,entry->local_count,m,function,instruction->byte_offset,calls);
            if (error) goto done;
            if (op==OP_HANDLER_PUSH) {
                if (current->handler_count==64u) {
                    error="I exceeded my bounded affine handler depth";goto done;
                }
                uint32_t key=instruction->instruction.operands[0].u32;
                uint16_t first=instruction->instruction.operands[2].u16;
                current->handlers[current->handler_count++]=(Handler){key,index};
                Frame *arm=frame_clone(current);
                if (!arm) {error="I cannot allocate handler control-flow state";goto done;}
                NvmAffineState *locals=nvm_affine_handler_enter(current->locals,key,first);
                if (!locals) {frame_free(arm);error="I require a fresh exact handler activation";goto done;}
                nvm_affine_state_free(arm->locals);arm->locals=locals;
                free(arm->stack);arm->stack=
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                           ((void *)0)
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                               ;arm->count=0;
                arm->activation=index+1;arm->handler_floor=arm->handler_count;
                uint32_t relative=instruction->resolved_target-entry->code_offset;
                const VmDecodedInstruction *target=vm_decoded_function_at(&decoded,relative);
                if (!target || !propagate(frames,(uint32_t)(target-decoded.instructions),arm,&work,&error)) {
                    frame_free(arm);if (!error) error="I require a valid handler entry edge";goto done;
                }
                frame_free(arm);
            }
            if (op==OP_MATCH_TAG) {
                uint32_t relative=instruction->resolved_target-entry->code_offset;
                const VmDecodedInstruction *target=vm_decoded_function_at(&decoded,relative);
                uint16_t wanted=instruction->instruction.operands[0].u16;
                uint16_t known=current->stack[current->count-1].variant;
                if (!target) {error="I require an instruction at my match target";goto done;}
                Value *tested=&current->stack[current->count-1];
                
# 909 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
               _Bool 
# 909 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                    excluded=(tested->excluded[wanted/64u]&(1UL<<(wanted%64u)))!=0;
                if ((known==
# 910 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                           (65535) 
# 910 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                      && !excluded) || known==wanted) {
                    Frame *matched=frame_clone(current);
                    if (!matched || !match_refine(matched,wanted) ||
                        !propagate(frames,(uint32_t)(target-decoded.instructions),matched,&work,&error)) {
                        frame_free(matched);
                        if (!error) error="I require a checked scalar-union match edge";
                        goto done;
                    }
                    frame_free(matched);
                }


                if (known==wanted) fallthrough=
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                              0
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   ;
                else if (known==
# 923 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                               (65535)
# 923 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                         ) {
                    tested->excluded[wanted/64u]|=1UL<<(wanted%64u);
                    uint16_t remaining=0,last=0;
                    for (uint16_t v=0;v<256u;v++) {
                        NvmUnionVariantFact fact;
                        if (!union_fact_for_layout(m,tested->layout,v,&fact)) break;
                        if (!(tested->excluded[v/64u]&(1UL<<(v%64u)))) {remaining++;last=v;}
                    }
                    if (!remaining) fallthrough=
# 931 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                               0
# 931 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                    ;
                    else if (remaining==1) {tested->variant=last;memset(tested->excluded,0,sizeof(tested->excluded));}
                }
            }
            if (op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
                uint32_t relative=instruction->resolved_target-entry->code_offset;
                const VmDecodedInstruction *target=vm_decoded_function_at(&decoded,relative);
                if (!target) {error="I require an instruction at my branch target";goto done;}
                if (!propagate(frames,(uint32_t)(target-decoded.instructions),current,&work,&error)) goto done;
            }
            if (op!=OP_JMP && fallthrough) {
                if (index+1==count) {error="I require an explicit return rather than fallthrough";goto done;}
                if (!propagate(frames,index+1,current,&work,&error)) goto done;
            }
        }
        frame_free(current);current=
# 946 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                   ((void *)0)
# 946 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                       ;
    }
    for (uint32_t g=0;g<calls->global_count;g++) {
        uint8_t allowed=calls->global_allowed[function][g];
        if (!allowed || (!function && !(allowed&1u))) {
            error="I require global initialization before reads and no repeated immutable store";goto done;
        }
    }
    if (calls->facts && !caller && function==calls->fact_function) {
        NvmAffineInstructionFact *facts=calloc(count,sizeof(*facts));
        if (!facts) {error="I cannot allocate converged instruction facts";goto done;}
        for (uint32_t i=0;i<count;i++) {
            facts[i].byte_offset=decoded.instructions[i].byte_offset;
            if (!frames[i] || !frames[i]->visited) continue;
            facts[i].reachable=
# 960 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                              1
# 960 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                  ;facts[i].stack_depth=frames[i]->count;
            facts[i].top_tag=frames[i]->count?frames[i]->stack[frames[i]->count-1].tag:TAG_VOID;
            if (decoded.instructions[i].instruction.opcode==OP_OWN_UNPACK_LOCAL) {
                NvmAffineType type,fields[256u];uint16_t fields_count=0;
                uint16_t local=decoded.instructions[i].instruction.operands[0].u16;
                if (!nvm_affine_local_type(frames[i]->locals,local,&type) ||
                    !nvm_affine_owned_local_fields(frames[i]->locals,local,fields,
                                                  256u,&fields_count)) {
                    free(facts);error="I require exact destructive-unpack facts";goto done;
                }
                facts[i].unpack_count=fields_count;
            }
        }
        memcpy(calls->facts,facts,count*sizeof(*facts));free(facts);
    }
    result.ok=
# 975 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
             1
# 975 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                 ;result.byte_offset=0;error=
# 975 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                             ((void *)0)
# 975 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                 ;
done:
    frame_free(current);
    if (frames) for (uint32_t i=0;i<decoded.instruction_count;i++) frame_free(frames[i]);
    free(frames);free(work.items);free(work.queued);vm_decoded_function_free(&decoded);
    if (error) snprintf(result.message,sizeof(result.message),"%s",error);
    if (calls->value_graph && !caller && function<8u) {
        calls->results[function]=result;calls->status[function]=2;
    }
    return result;
}

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 2
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
typedef struct VmString VmString;
typedef struct VmBString VmBString;
typedef struct VmArray VmArray;
typedef struct VmStruct VmStruct;
typedef struct VmUnion VmUnion;
typedef struct VmTuple VmTuple;
typedef struct VmHashMap VmHashMap;
typedef struct VmClosure VmClosure;





typedef struct {
    uint8_t tag;


    uint32_t callable_module;
    union {
        int64_t i64;
        double f64;
        uint8_t u8;
        
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
       _Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                boolean;
        int32_t enum_val;
        uint32_t fn_idx;
        uint32_t proxy_id;


        VmString *string;
        VmArray *array;
        VmStruct *sval;
        VmUnion *uval;
        VmTuple *tuple;
        VmHashMap *hashmap;
        VmClosure *closure;
        void *obj;
    } as;
} NanoValue;





static inline NanoValue val_void(void) {
    NanoValue v = {0};
    v.tag = TAG_VOID;
    return v;
}

static inline NanoValue val_int(int64_t n) {
    NanoValue v = {0};
    v.tag = TAG_INT;
    v.as.i64 = n;
    return v;
}

static inline NanoValue val_float(double d) {
    NanoValue v = {0};
    v.tag = TAG_FLOAT;
    v.as.f64 = d;
    return v;
}

static inline NanoValue val_bool(
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
                                _Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                                     b) {
    NanoValue v = {0};
    v.tag = TAG_BOOL;
    v.as.boolean = b;
    return v;
}

static inline NanoValue val_u8(uint8_t b) {
    NanoValue v = {0};
    v.tag = TAG_U8;
    v.as.u8 = b;
    return v;
}

static inline NanoValue val_string(VmString *s) {
    NanoValue v = {0};
    v.tag = TAG_STRING;
    v.as.string = s;
    return v;
}

static inline NanoValue val_bstring(VmBString *s) {
    NanoValue v = {0};
    v.tag = TAG_BSTRING;
    v.as.obj = s;
    return v;
}

static inline NanoValue val_array(VmArray *a) {
    NanoValue v = {0};
    v.tag = TAG_ARRAY;
    v.as.array = a;
    return v;
}

static inline NanoValue val_struct(VmStruct *s) {
    NanoValue v = {0};
    v.tag = TAG_STRUCT;
    v.as.sval = s;
    return v;
}

static inline NanoValue val_enum(int32_t variant) {
    NanoValue v = {0};
    v.tag = TAG_ENUM;
    v.as.enum_val = variant;
    return v;
}

static inline NanoValue val_union(VmUnion *u) {
    NanoValue v = {0};
    v.tag = TAG_UNION;
    v.as.uval = u;
    return v;
}

static inline NanoValue val_function(uint32_t fn_idx) {
    NanoValue v = {0};
    v.tag = TAG_FUNCTION;
    v.callable_module = 1;
    v.as.fn_idx = fn_idx;
    return v;
}

static inline NanoValue val_function_owned(uint32_t fn_idx, uint32_t module_id) {
    NanoValue v = val_function(fn_idx);
    v.callable_module = module_id;
    return v;
}

static inline NanoValue val_tuple(VmTuple *t) {
    NanoValue v = {0};
    v.tag = TAG_TUPLE;
    v.as.tuple = t;
    return v;
}

static inline NanoValue val_hashmap(VmHashMap *h) {
    NanoValue v = {0};
    v.tag = TAG_HASHMAP;
    v.as.hashmap = h;
    return v;
}

static inline NanoValue val_closure(VmClosure *c) {
    NanoValue v = {0};
    v.tag = TAG_CLOSURE;
    v.as.closure = c;
    return v;
}





static inline 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_int(NanoValue v) { return v.tag == TAG_INT; }
static inline 
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_float(NanoValue v) { return v.tag == TAG_FLOAT; }
static inline 
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_bool(NanoValue v) { return v.tag == TAG_BOOL; }
static inline 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_string(NanoValue v) { return v.tag == TAG_STRING; }
static inline 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_array(NanoValue v) { return v.tag == TAG_ARRAY; }
static inline 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_struct(NanoValue v) { return v.tag == TAG_STRUCT; }
static inline 
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_union(NanoValue v) { return v.tag == TAG_UNION; }
static inline 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_tuple(NanoValue v) { return v.tag == TAG_TUPLE; }
static inline 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_hashmap(NanoValue v) { return v.tag == TAG_HASHMAP; }
static inline 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_function(NanoValue v) {
    return v.tag == TAG_FUNCTION || v.tag == TAG_CLOSURE;
}
static inline 
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_void(NanoValue v) { return v.tag == TAG_VOID; }
static inline 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_heap_obj(NanoValue v) {
    return v.tag == TAG_STRING || v.tag == TAG_BSTRING || v.tag == TAG_ARRAY || v.tag == TAG_STRUCT ||
           v.tag == TAG_UNION || v.tag == TAG_TUPLE || v.tag == TAG_HASHMAP ||
           v.tag == TAG_CLOSURE;
}






void val_print(NanoValue v, FILE *out);


void val_println(NanoValue v);



# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
_Bool 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
    val_equal(NanoValue a, NanoValue b);


int val_compare(NanoValue a, NanoValue b);



# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
_Bool 
# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
    val_truthy(NanoValue v);


char *val_to_cstring(NanoValue v);
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 2
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
        is_utf8;
    
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
        null_terminated;
} nl_string_t;


static inline void nl_string_free_owned_storage(nl_string_t *str) {
    if (!str) return;
    free(str->data);
    free(str);
}
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
nl_string_t* nl_string_new(const char *cstr);





nl_string_t* nl_string_new_binary(const void *data, size_t length);





nl_string_t* nl_string_from_utf8(const char *utf8_data, size_t length);




nl_string_t* nl_string_with_capacity(size_t capacity);




void nl_string_free(nl_string_t *str);
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
size_t nl_string_length(const nl_string_t *str);




char nl_string_byte_at(const nl_string_t *str, size_t index);





# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_byte_at_safe(const nl_string_t *str, size_t index, char *out);





nl_string_t* nl_string_concat(const nl_string_t *a, const nl_string_t *b);





nl_string_t* nl_string_substring(const nl_string_t *str, size_t start, size_t length);





# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_equals(const nl_string_t *a, const nl_string_t *b);





# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_equals_cstr(const nl_string_t *str, const char *cstr);
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"

# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_validate_utf8(nl_string_t *str);






int64_t nl_string_utf8_length(const nl_string_t *str);





int32_t nl_string_utf8_char_at(const nl_string_t *str, size_t char_index);




nl_string_t* nl_string_utf8_substring(const nl_string_t *str, size_t char_start, size_t char_length);
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
const char* nl_string_to_cstr(nl_string_t *str);




const void* nl_string_to_binary(const nl_string_t *str, size_t *out_length);





void nl_string_ensure_null_terminated(nl_string_t *str);
# 170 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
void nl_string_reserve(nl_string_t *str, size_t new_capacity);




void nl_string_shrink_to_fit(nl_string_t *str);




nl_string_t* nl_string_clone(const nl_string_t *str);
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
int64_t nl_cstr_length(const char *s);


char *nl_cstr_concat(const char *a, const char *b);


char *nl_cstr_substring(const char *s, int64_t start, int64_t len);



# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
           nl_cstr_contains(const char *haystack, const char *needle);


int64_t nl_cstr_index_of(const char *haystack, const char *needle);
int64_t nl_cstr_last_index_of(const char *haystack, const char *needle);


int64_t nl_cstr_char_at(const char *s, int64_t index);


char *nl_cstr_from_char(int64_t code);
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 2
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
typedef struct VmHeapHeader {
    uint32_t ref_count;
    uint8_t obj_type;
    uint8_t colour;
    uint8_t buffered;
} VmHeapHeader;






struct VmString {
    VmHeapHeader header;
    uint32_t length;
    uint32_t hash;
    struct VmString *intern_next;
    char data[];
};


struct VmBString {
    VmHeapHeader header;
    nl_string_t *value;
};
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
struct VmArray {
    VmHeapHeader header;
    uint8_t elem_type;
    uint8_t unboxed;
    uint32_t length;
    uint32_t capacity;
    NanoValue *elements;
    void *packed;
};




# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_array_type_unboxable(uint8_t elem_type);


size_t vm_array_elem_size(uint8_t elem_type);


struct VmStruct {
    VmHeapHeader header;
    uint32_t def_idx;
    uint32_t field_count;
    VmString **field_names;
    NanoValue *fields;
};


struct VmUnion {
    VmHeapHeader header;
    uint32_t def_idx;
    uint16_t variant;
    uint16_t field_count;
    NanoValue *fields;
};


struct VmTuple {
    VmHeapHeader header;
    uint32_t count;
    NanoValue elements[];
};


struct VmClosure {
    VmHeapHeader header;
    uint32_t fn_idx;
    uint32_t callable_module;
    uint16_t capture_count;
    NanoValue captures[];
};


typedef struct VmHMEntry {
    uint8_t state;
    NanoValue key;
    NanoValue value;
} VmHMEntry;


struct VmHashMap {
    VmHeapHeader header;
    uint8_t key_type;
    uint8_t val_type;
    uint32_t count;
    uint32_t tombstone_count;
    uint32_t bucket_count;
    VmHMEntry *entries;
};





typedef struct {
    size_t allocated;
    size_t freed;
    size_t num_objects;
    uint64_t allocation_calls;
    uint64_t retain_calls;
    uint64_t release_calls;
} VmHeapStats;

typedef struct VmHeap {
    VmHeapStats stats;



    VmString **intern_buckets;
    uint32_t intern_bucket_count;
    uint32_t intern_count;





    void **cycle_buf;
    uint32_t cycle_count;
    uint32_t cycle_capacity;
    uint64_t cycles_collected;
    
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
   _Bool 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
              gc_running;






} VmHeap;
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
uint64_t vm_gc_collect_cycles(VmHeap *heap);




void vm_gc_note_suspect(VmHeap *heap, NanoValue v);


void vm_gc_maybe_collect(VmHeap *heap);
void vm_gc_cycle_buffer_free(VmHeap *heap);


void vm_heap_init(VmHeap *heap);
void vm_heap_destroy(VmHeap *heap);


void vm_retain(VmHeap *heap, NanoValue v);
void vm_release(VmHeap *heap, NanoValue v);


VmBString *vm_bstring_adopt(VmHeap *heap, nl_string_t *owned);
void vm_bstring_clear(VmHeap *heap, VmBString *value);


VmString *vm_string_new(VmHeap *heap, const char *data, uint32_t length);
VmString *vm_string_concat(VmHeap *heap, VmString *a, VmString *b);
VmString *vm_string_substr(VmHeap *heap, VmString *s, uint32_t start, uint32_t len);


const char *vmstring_cstr(VmString *s);
uint32_t vmstring_len(VmString *s);

# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vmstring_equal(VmString *a, VmString *b);
int vmstring_compare(VmString *a, VmString *b);

# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vmstring_contains(VmString *haystack, VmString *needle);



int64_t vmstring_find(VmString *haystack, VmString *needle);
VmString *vmstring_char_at(VmHeap *heap, VmString *s, uint32_t index);


VmArray *vm_array_new(VmHeap *heap, uint8_t elem_type, uint32_t initial_capacity);


# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_array_push(VmHeap *heap, VmArray *a, NanoValue v);
NanoValue vm_array_pop(VmArray *a);
NanoValue vm_array_get(VmArray *a, uint32_t index);
void vm_array_set(VmArray *a, uint32_t index, NanoValue v);


void vm_array_swap_scalar_storage(VmArray *a, VmArray *b);
VmArray *vm_array_slice(VmHeap *heap, VmArray *a, uint32_t start, uint32_t end);







void vm_array_remove(VmHeap *heap, VmArray *a, uint32_t index);


VmStruct *vm_struct_new(VmHeap *heap, uint32_t def_idx, uint32_t field_count);


VmUnion *vm_union_new(VmHeap *heap, uint32_t def_idx, uint16_t variant, uint16_t field_count);


VmTuple *vm_tuple_new(VmHeap *heap, uint32_t count);


VmClosure *vm_closure_new(VmHeap *heap, uint32_t fn_idx, uint16_t capture_count);


VmHashMap *vm_hashmap_new(VmHeap *heap, uint8_t key_type, uint8_t val_type);
NanoValue vm_hashmap_get(VmHashMap *m, NanoValue key);


# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_hashmap_set(VmHeap *heap, VmHashMap *m, NanoValue key, NanoValue value);

# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_hashmap_has(VmHashMap *m, NanoValue key);
void vm_hashmap_delete(VmHeap *heap, VmHashMap *m, NanoValue key);
VmArray *vm_hashmap_keys(VmHeap *heap, VmHashMap *m);
VmArray *vm_hashmap_values(VmHeap *heap, VmHashMap *m);




# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_string_replacement_length(uint32_t source_length, uint32_t needle_length,
                                  uint32_t replacement_length, uint64_t count,
                                  uint32_t *out);
VmString *vm_string_from_int(VmHeap *heap, int64_t v);
VmString *vm_string_from_float(VmHeap *heap, double v);
VmString *vm_string_from_bool(VmHeap *heap, 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
                                           _Bool 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
                                                v);
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 1
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
typedef enum {
    VM_SUPER_NONE = 0,

    VM_SUPER_LOAD_LOCAL_FIELD,
    VM_SUPER__COUNT
} VmSuperOp;
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
typedef struct {
    
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
   _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
        fuse_load_local_field;
} VmDispatchProfile;


VmDispatchProfile vm_dispatch_profile_none(void);



VmDispatchProfile vm_dispatch_profile_all(void);



typedef struct {
    DecodedInstruction instruction;
    VmCallHandle call_handle;
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t next_index;
    uint32_t branch_target;
    uint32_t branch_target_offset;
    uint32_t call_target;




    uint16_t super_op;
    uint16_t super_operand;
} VmDispatchInstruction;

typedef struct {
    VmDispatchInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;

    uint32_t *offset_to_index;
} VmDispatchFunction;

typedef struct {
    VmDispatchFunction *functions;
    uint32_t function_count;
} VmDispatchModule;






typedef struct {
    const VmDispatchFunction *function;
    uint32_t index;
} VmDispatchCursor;





# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_build_function(const VmDecodedFunction *decoded,
                                VmDispatchProfile profile,
                                VmDispatchFunction *out,
                                char error[256]);




# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_build_module(const VmDecodedModule *decoded,
                              VmDispatchProfile profile,
                              VmDispatchModule *out,
                              char error[256]);

void vm_dispatch_function_free(VmDispatchFunction *function);
void vm_dispatch_module_free(VmDispatchModule *module);




# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_seek(VmDispatchCursor *cursor,
                      const VmDispatchFunction *function,
                      uint32_t byte_offset);


const VmDispatchInstruction *vm_dispatch_current(const VmDispatchCursor *cursor);


const VmDispatchInstruction *vm_dispatch_advance(VmDispatchCursor *cursor);
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/ownership_contracts.h" 1
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nano_callback.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nano_callback.h"
typedef enum {
    NANO_CALLBACK_VOID = 0,
    NANO_CALLBACK_INT = 1,
    NANO_CALLBACK_FLOAT = 2,
    NANO_CALLBACK_BOOL = 3,
    NANO_CALLBACK_BYTE = 4,
    NANO_CALLBACK_POINTER = 5
} NanoCallbackTag;

typedef struct {
    uint32_t tag;
    union { int64_t integer; double number; uint8_t byte; void *pointer; } as;
} NanoCallbackValue;

typedef struct {
    uint32_t argument_count;
    uint32_t result_tag;
    uint32_t argument_tags[16u];
} NanoCallbackSignature;

typedef enum {
    NANO_CALLBACK_OK = 0,
    NANO_CALLBACK_CANCELLED,
    NANO_CALLBACK_TYPE_ERROR,
    NANO_CALLBACK_EXECUTION_ERROR,
    NANO_CALLBACK_WRONG_THREAD,
    NANO_CALLBACK_BUSY
} NanoCallbackStatus;

typedef struct NanoCallbackV1 NanoCallbackV1;
struct NanoCallbackV1 {
    uint32_t abi_version;
    NanoCallbackSignature signature;
    void (*retain)(NanoCallbackV1 *callback);
    void (*release)(NanoCallbackV1 *callback);
    NanoCallbackStatus (*invoke)(NanoCallbackV1 *callback,
        const NanoCallbackValue *arguments, uint32_t count,
        NanoCallbackValue *result);
};
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 2


typedef struct NanoCallbackRuntime NanoCallbackRuntime;
typedef NanoCallbackStatus (*NanoCallbackExecute)(void *payload,
    const NanoCallbackValue *arguments, uint32_t count,
    NanoCallbackValue *result);
typedef void (*NanoCallbackDrop)(void *payload);




NanoCallbackRuntime *nano_callback_runtime_create(void);
NanoCallbackV1 *nano_callback_create(NanoCallbackRuntime *runtime,
    const NanoCallbackSignature *signature, NanoCallbackExecute execute,
    NanoCallbackDrop drop, void *payload);




int nano_callback_pump(NanoCallbackRuntime *runtime, 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 3 4
                                                    _Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h"
                                                         wait);


void nano_callback_wake(NanoCallbackRuntime *runtime);
void nano_callback_collect(NanoCallbackRuntime *runtime);
NanoCallbackStatus nano_callback_close(NanoCallbackRuntime *runtime);
NanoCallbackStatus nano_callback_runtime_destroy(NanoCallbackRuntime *runtime);
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/usr/include/pthread.h" 1 3 4
# 22 "/usr/include/pthread.h" 3 4
# 1 "/usr/include/sched.h" 1 3 4
# 29 "/usr/include/sched.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 30 "/usr/include/sched.h" 2 3 4
# 43 "/usr/include/sched.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/sched.h" 1 3 4
# 80 "/usr/include/aarch64-linux-gnu/bits/sched.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 3 4

# 23 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 3 4
struct sched_param
{
  int sched_priority;
};
# 81 "/usr/include/aarch64-linux-gnu/bits/sched.h" 2 3 4





extern int clone (int (*__fn) (void *__arg), void *__child_stack,
    int __flags, void *__arg, ...) __attribute__ ((__nothrow__ , __leaf__));


extern int unshare (int __flags) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getcpu (void) __attribute__ ((__nothrow__ , __leaf__));


extern int getcpu (unsigned int *, unsigned int *) __attribute__ ((__nothrow__ , __leaf__));


extern int setns (int __fd, int __nstype) __attribute__ ((__nothrow__ , __leaf__));



# 44 "/usr/include/sched.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 3 4
typedef unsigned long int __cpu_mask;






typedef struct
{
  __cpu_mask __bits[1024 / (8 * sizeof (__cpu_mask))];
} cpu_set_t;
# 115 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 3 4


extern int __sched_cpucount (size_t __setsize, const cpu_set_t *__setp)
     __attribute__ ((__nothrow__ , __leaf__));
extern cpu_set_t *__sched_cpualloc (size_t __count) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern void __sched_cpufree (cpu_set_t *__set) __attribute__ ((__nothrow__ , __leaf__));


# 45 "/usr/include/sched.h" 2 3 4









extern int sched_setparam (__pid_t __pid, const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getparam (__pid_t __pid, struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_setscheduler (__pid_t __pid, int __policy,
          const struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getscheduler (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_yield (void) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_get_priority_max (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_get_priority_min (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));



extern int sched_rr_get_interval (__pid_t __pid, struct timespec *__t) __attribute__ ((__nothrow__ , __leaf__));
# 130 "/usr/include/sched.h" 3 4
extern int sched_setaffinity (__pid_t __pid, size_t __cpusetsize,
         const cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getaffinity (__pid_t __pid, size_t __cpusetsize,
         cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));



# 23 "/usr/include/pthread.h" 2 3 4
# 1 "/usr/include/time.h" 1 3 4
# 29 "/usr/include/time.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 30 "/usr/include/time.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/time.h" 1 3 4
# 73 "/usr/include/aarch64-linux-gnu/bits/time.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timex.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/timex.h" 3 4
struct timex
{
# 58 "/usr/include/aarch64-linux-gnu/bits/timex.h" 3 4
  unsigned int modes;
  __syscall_slong_t offset;
  __syscall_slong_t freq;
  __syscall_slong_t maxerror;
  __syscall_slong_t esterror;
  int status;
  __syscall_slong_t constant;
  __syscall_slong_t precision;
  __syscall_slong_t tolerance;
  struct timeval time;
  __syscall_slong_t tick;
  __syscall_slong_t ppsfreq;
  __syscall_slong_t jitter;
  int shift;
  __syscall_slong_t stabil;
  __syscall_slong_t jitcnt;
  __syscall_slong_t calcnt;
  __syscall_slong_t errcnt;
  __syscall_slong_t stbcnt;

  int tai;


  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32;

};
# 74 "/usr/include/aarch64-linux-gnu/bits/time.h" 2 3 4




extern int clock_adjtime (__clockid_t __clock_id, struct timex *__utx) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 90 "/usr/include/aarch64-linux-gnu/bits/time.h" 3 4

# 34 "/usr/include/time.h" 2 3 4





# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_tm.h" 1 3 4






struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;


  long int tm_gmtoff;
  const char *tm_zone;




};
# 40 "/usr/include/time.h" 2 3 4
# 48 "/usr/include/time.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_itimerspec.h" 1 3 4







struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };
# 49 "/usr/include/time.h" 2 3 4
struct sigevent;
# 68 "/usr/include/time.h" 3 4




extern clock_t clock (void) __attribute__ ((__nothrow__ , __leaf__));



extern time_t time (time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));


extern double difftime (time_t __time1, time_t __time0)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
# 100 "/usr/include/time.h" 3 4
extern size_t strftime (char *__restrict __s, size_t __maxsize,
   const char *__restrict __format,
   const struct tm *__restrict __tp)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3, 4)));




extern char *strptime (const char *__restrict __s,
         const char *__restrict __fmt, struct tm *__tp)
     __attribute__ ((__nothrow__ , __leaf__));






extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     const char *__restrict __format,
     const struct tm *__restrict __tp,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));



extern char *strptime_l (const char *__restrict __s,
    const char *__restrict __fmt, struct tm *__tp,
    locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));






extern struct tm *gmtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));



extern struct tm *localtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
# 155 "/usr/include/time.h" 3 4
extern struct tm *gmtime_r (const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));



extern struct tm *localtime_r (const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));
# 180 "/usr/include/time.h" 3 4
extern char *asctime (const struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));



extern char *ctime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
# 198 "/usr/include/time.h" 3 4
extern char *asctime_r (const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



extern char *ctime_r (const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));
# 218 "/usr/include/time.h" 3 4
extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;




extern char *tzname[2];



extern void tzset (void) __attribute__ ((__nothrow__ , __leaf__));



extern int daylight;
extern long int timezone;
# 247 "/usr/include/time.h" 3 4
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
# 264 "/usr/include/time.h" 3 4
extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));







extern int dysize (int __year) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 282 "/usr/include/time.h" 3 4
extern int nanosleep (const struct timespec *__requested_time,
        struct timespec *__remaining);


extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__ , __leaf__));


extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int clock_settime (clockid_t __clock_id, const struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 324 "/usr/include/time.h" 3 4
extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       const struct timespec *__req,
       struct timespec *__rem);
# 339 "/usr/include/time.h" 3 4
extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__ , __leaf__));




extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__ , __leaf__));


extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));



extern int timer_settime (timer_t __timerid, int __flags,
     const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__ , __leaf__));


extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__ , __leaf__));
# 377 "/usr/include/time.h" 3 4
extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));






extern int timespec_get (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 400 "/usr/include/time.h" 3 4
extern int timespec_getres (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
# 426 "/usr/include/time.h" 3 4
extern int getdate_err;
# 435 "/usr/include/time.h" 3 4
extern struct tm *getdate (const char *__string);
# 449 "/usr/include/time.h" 3 4
extern int getdate_r (const char *__restrict __string,
        struct tm *__restrict __resbufp);



# 24 "/usr/include/pthread.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/setjmp.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/bits/setjmp.h" 3 4
__extension__ typedef unsigned long long __jmp_buf [22];
# 28 "/usr/include/pthread.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 29 "/usr/include/pthread.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 3 4
struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };
# 32 "/usr/include/pthread.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4

extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 34 "/usr/include/pthread.h" 2 3 4



enum
{
  PTHREAD_CREATE_JOINABLE,

  PTHREAD_CREATE_DETACHED

};



enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP

  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL



  , PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_TIMED_NP

};




enum
{
  PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_ROBUST,
  PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST
};





enum
{
  PTHREAD_PRIO_NONE,
  PTHREAD_PRIO_INHERIT,
  PTHREAD_PRIO_PROTECT
};
# 104 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP
};
# 124 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_INHERIT_SCHED,

  PTHREAD_EXPLICIT_SCHED

};



enum
{
  PTHREAD_SCOPE_SYSTEM,

  PTHREAD_SCOPE_PROCESS

};



enum
{
  PTHREAD_PROCESS_PRIVATE,

  PTHREAD_PROCESS_SHARED

};
# 159 "/usr/include/pthread.h" 3 4
struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);
  void *__arg;
  int __canceltype;
  struct _pthread_cleanup_buffer *__prev;
};


enum
{
  PTHREAD_CANCEL_ENABLE,

  PTHREAD_CANCEL_DISABLE

};
enum
{
  PTHREAD_CANCEL_DEFERRED,

  PTHREAD_CANCEL_ASYNCHRONOUS

};
# 197 "/usr/include/pthread.h" 3 4





extern int pthread_create (pthread_t *__restrict __newthread,
      const pthread_attr_t *__restrict __attr,
      void *(*__start_routine) (void *),
      void *__restrict __arg) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));





extern void pthread_exit (void *__retval) __attribute__ ((__noreturn__));







extern int pthread_join (pthread_t __th, void **__thread_return);




extern int pthread_tryjoin_np (pthread_t __th, void **__thread_return) __attribute__ ((__nothrow__ , __leaf__));
# 233 "/usr/include/pthread.h" 3 4
extern int pthread_timedjoin_np (pthread_t __th, void **__thread_return,
     const struct timespec *__abstime);
# 243 "/usr/include/pthread.h" 3 4
extern int pthread_clockjoin_np (pthread_t __th, void **__thread_return,
                                 clockid_t __clockid,
     const struct timespec *__abstime);
# 269 "/usr/include/pthread.h" 3 4
extern int pthread_detach (pthread_t __th) __attribute__ ((__nothrow__ , __leaf__));



extern pthread_t pthread_self (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int pthread_equal (pthread_t __thread1, pthread_t __thread2)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));







extern int pthread_attr_init (pthread_attr_t *__attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_destroy (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getdetachstate (const pthread_attr_t *__attr,
     int *__detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setdetachstate (pthread_attr_t *__attr,
     int __detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getguardsize (const pthread_attr_t *__attr,
          size_t *__guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setguardsize (pthread_attr_t *__attr,
          size_t __guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getschedparam (const pthread_attr_t *__restrict __attr,
           struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedparam (pthread_attr_t *__restrict __attr,
           const struct sched_param *__restrict
           __param) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_getschedpolicy (const pthread_attr_t *__restrict
     __attr, int *__restrict __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedpolicy (pthread_attr_t *__attr, int __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getinheritsched (const pthread_attr_t *__restrict
      __attr, int *__restrict __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setinheritsched (pthread_attr_t *__attr,
      int __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getscope (const pthread_attr_t *__restrict __attr,
      int *__restrict __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setscope (pthread_attr_t *__attr, int __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getstackaddr (const pthread_attr_t *__restrict
          __attr, void **__restrict __stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__deprecated__));





extern int pthread_attr_setstackaddr (pthread_attr_t *__attr,
          void *__stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__));


extern int pthread_attr_getstacksize (const pthread_attr_t *__restrict
          __attr, size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_attr_setstacksize (pthread_attr_t *__attr,
          size_t __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getstack (const pthread_attr_t *__restrict __attr,
      void **__restrict __stackaddr,
      size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3)));




extern int pthread_attr_setstack (pthread_attr_t *__attr, void *__stackaddr,
      size_t __stacksize) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int pthread_attr_setaffinity_np (pthread_attr_t *__attr,
     size_t __cpusetsize,
     const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern int pthread_attr_getaffinity_np (const pthread_attr_t *__attr,
     size_t __cpusetsize,
     cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));


extern int pthread_getattr_default_np (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_setsigmask_np (pthread_attr_t *__attr,
           const __sigset_t *sigmask);




extern int pthread_attr_getsigmask_np (const pthread_attr_t *__attr,
           __sigset_t *sigmask);







extern int pthread_setattr_default_np (const pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_getattr_np (pthread_t __th, pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));







extern int pthread_setschedparam (pthread_t __target_thread, int __policy,
      const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));


extern int pthread_getschedparam (pthread_t __target_thread,
      int *__restrict __policy,
      struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));


extern int pthread_setschedprio (pthread_t __target_thread, int __prio)
     __attribute__ ((__nothrow__ , __leaf__));




extern int pthread_getname_np (pthread_t __target_thread, char *__buf,
          size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int pthread_setname_np (pthread_t __target_thread, const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





extern int pthread_getconcurrency (void) __attribute__ ((__nothrow__ , __leaf__));


extern int pthread_setconcurrency (int __level) __attribute__ ((__nothrow__ , __leaf__));



extern int pthread_yield (void) __attribute__ ((__nothrow__ , __leaf__));

extern int pthread_yield (void) __asm__ ("" "sched_yield") __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("pthread_yield is deprecated, use sched_yield instead")))
                                                      ;







extern int pthread_setaffinity_np (pthread_t __th, size_t __cpusetsize,
       const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));


extern int pthread_getaffinity_np (pthread_t __th, size_t __cpusetsize,
       cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 509 "/usr/include/pthread.h" 3 4
extern int pthread_once (pthread_once_t *__once_control,
    void (*__init_routine) (void)) __attribute__ ((__nonnull__ (1, 2)));
# 521 "/usr/include/pthread.h" 3 4
extern int pthread_setcancelstate (int __state, int *__oldstate);



extern int pthread_setcanceltype (int __type, int *__oldtype);


extern int pthread_cancel (pthread_t __th);




extern void pthread_testcancel (void);




struct __cancel_jmp_buf_tag
{
  __jmp_buf __cancel_jmp_buf;
  int __mask_was_saved;
};

typedef struct
{
  struct __cancel_jmp_buf_tag __cancel_jmp_buf[1];
  void *__pad[4];
} __pthread_unwind_buf_t __attribute__ ((__aligned__));
# 557 "/usr/include/pthread.h" 3 4
struct __pthread_cleanup_frame
{
  void (*__cancel_routine) (void *);
  void *__cancel_arg;
  int __do_it;
  int __cancel_type;
};
# 697 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel (__pthread_unwind_buf_t *__buf)
     ;
# 709 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel (__pthread_unwind_buf_t *__buf)
  ;
# 732 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel_defer (__pthread_unwind_buf_t *__buf)
     ;
# 745 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel_restore (__pthread_unwind_buf_t *__buf)
  ;



extern void __pthread_unwind_next (__pthread_unwind_buf_t *__buf)
     __attribute__ ((__noreturn__))

     __attribute__ ((__weak__))

     ;
# 766 "/usr/include/pthread.h" 3 4
extern int __sigsetjmp_cancel (struct __cancel_jmp_buf_tag __env[1], int __savemask) __asm__ ("" "__sigsetjmp") __attribute__ ((__nothrow__))


                     __attribute__ ((__returns_twice__));
# 781 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_init (pthread_mutex_t *__mutex,
          const pthread_mutexattr_t *__mutexattr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_trylock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_lock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_mutex_timedlock (pthread_mutex_t *__restrict __mutex,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 817 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_clocklock (pthread_mutex_t *__restrict __mutex,
        clockid_t __clockid,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 835 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_unlock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutex_getprioceiling (const pthread_mutex_t *
      __restrict __mutex,
      int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutex_setprioceiling (pthread_mutex_t *__restrict __mutex,
      int __prioceiling,
      int *__restrict __old_ceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));




extern int pthread_mutex_consistent (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_consistent_np (pthread_mutex_t *) __asm__ ("" "pthread_mutex_consistent") __attribute__ ((__nothrow__ , __leaf__))
                                __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutex_consistent_np is deprecated, use pthread_mutex_consistent")))
                                                                         ;
# 874 "/usr/include/pthread.h" 3 4
extern int pthread_mutexattr_init (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getpshared (const pthread_mutexattr_t *
      __restrict __attr,
      int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
      int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_gettype (const pthread_mutexattr_t *__restrict
          __attr, int *__restrict __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getprotocol (const pthread_mutexattr_t *
       __restrict __attr,
       int *__restrict __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutexattr_setprotocol (pthread_mutexattr_t *__attr,
       int __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getprioceiling (const pthread_mutexattr_t *
          __restrict __attr,
          int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setprioceiling (pthread_mutexattr_t *__attr,
          int __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getrobust (const pthread_mutexattr_t *__attr,
     int *__robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_getrobust_np (pthread_mutexattr_t *, int *) __asm__ ("" "pthread_mutexattr_getrobust") __attribute__ ((__nothrow__ , __leaf__))

                                   __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_getrobust_np is deprecated, use pthread_mutexattr_getrobust")))
                                                                               ;






extern int pthread_mutexattr_setrobust (pthread_mutexattr_t *__attr,
     int __robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_setrobust_np (pthread_mutexattr_t *, int) __asm__ ("" "pthread_mutexattr_setrobust") __attribute__ ((__nothrow__ , __leaf__))

                                   __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_setrobust_np is deprecated, use pthread_mutexattr_setrobust")))
                                                                               ;
# 967 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_init (pthread_rwlock_t *__restrict __rwlock,
    const pthread_rwlockattr_t *__restrict
    __attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_destroy (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_rdlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_tryrdlock (pthread_rwlock_t *__rwlock)
  __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedrdlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1004 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockrdlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1023 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_wrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_trywrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedwrlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1051 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockwrlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1071 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_unlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int pthread_rwlockattr_init (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_destroy (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getpshared (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setpshared (pthread_rwlockattr_t *__attr,
       int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getkind_np (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pref)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setkind_np (pthread_rwlockattr_t *__attr,
       int __pref) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int pthread_cond_init (pthread_cond_t *__restrict __cond,
         const pthread_condattr_t *__restrict __cond_attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_destroy (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_signal (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_broadcast (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_cond_wait (pthread_cond_t *__restrict __cond,
         pthread_mutex_t *__restrict __mutex)
     __attribute__ ((__nonnull__ (1, 2)));
# 1145 "/usr/include/pthread.h" 3 4
extern int pthread_cond_timedwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 3)));
# 1171 "/usr/include/pthread.h" 3 4
extern int pthread_cond_clockwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       __clockid_t __clock_id,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 4)));
# 1194 "/usr/include/pthread.h" 3 4
extern int pthread_condattr_init (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_destroy (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_getpshared (const pthread_condattr_t *
     __restrict __attr,
     int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setpshared (pthread_condattr_t *__attr,
     int __pshared) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_condattr_getclock (const pthread_condattr_t *
          __restrict __attr,
          __clockid_t *__restrict __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setclock (pthread_condattr_t *__attr,
          __clockid_t __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1230 "/usr/include/pthread.h" 3 4
extern int pthread_spin_init (pthread_spinlock_t *__lock, int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_destroy (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_lock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_trylock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_unlock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_barrier_init (pthread_barrier_t *__restrict __barrier,
     const pthread_barrierattr_t *__restrict
     __attr, unsigned int __count)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_destroy (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_wait (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_barrierattr_init (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_destroy (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_getpshared (const pthread_barrierattr_t *
        __restrict __attr,
        int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_barrierattr_setpshared (pthread_barrierattr_t *__attr,
        int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1297 "/usr/include/pthread.h" 3 4
extern int pthread_key_create (pthread_key_t *__key,
          void (*__destr_function) (void *))
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_key_delete (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));


extern void *pthread_getspecific (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));


extern int pthread_setspecific (pthread_key_t __key,
    const void *__pointer)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__access__ (__none__, 2)));




extern int pthread_getcpuclockid (pthread_t __thread_id,
      __clockid_t *__clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 1332 "/usr/include/pthread.h" 3 4
extern int pthread_atfork (void (*__prepare) (void),
      void (*__parent) (void),
      void (*__child) (void)) __attribute__ ((__nothrow__ , __leaf__));




extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) pthread_equal (pthread_t __thread1, pthread_t __thread2)
{
  return __thread1 == __thread2;
}



# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
typedef struct {
    uint32_t key;
    uint64_t count;
    
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        used;
} VmProfileTriple;

typedef struct {
    
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        enabled;
    
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        has_previous;
    
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        has_previous_pair;
    uint8_t previous;
    uint16_t previous_pair;
    uint64_t retired;
    uint64_t opcode_counts[256];
    uint64_t pair_counts[256 * 256];
    VmProfileTriple triples[4096];
    uint64_t branches;
    uint64_t branches_taken;
    uint64_t direct_calls;
    uint64_t indirect_calls;
    uint64_t extern_calls;
    uint64_t module_calls;
    uint64_t traps;
    uint64_t ffi_request_bytes;
    uint64_t ffi_response_bytes;
    uint64_t ffi_elapsed_ns;
    uint64_t ffi_failures;
    uint32_t max_stack_depth;
    uint32_t max_frame_depth;
} VmProfile;

typedef struct {
    VmString **strings;
    uint32_t count;
} VmModuleConstants;





typedef struct {
    uint32_t effect_owner;
    uint16_t effect_local_start;
    uint32_t fn_idx;
    uint32_t return_ip;
    uint32_t instruction_ip;
    uint32_t stack_base;
    uint16_t local_count;
    VmClosure *closure;






    NanoValue owned_callable;
    const NvmModule *module;
    uint32_t current_line;
    uint32_t current_col;
} VmCallFrame;





typedef enum {
    VM_OK = 0,
    VM_ERR_STACK_OVERFLOW,
    VM_ERR_STACK_UNDERFLOW,
    VM_ERR_CALL_DEPTH,
    VM_ERR_INVALID_OPCODE,
    VM_ERR_TYPE_ERROR,
    VM_ERR_OUT_OF_BOUNDS,
    VM_ERR_DIV_ZERO,
    VM_ERR_ASSERT_FAILED,
    VM_ERR_UNDEFINED_GLOBAL,
    VM_ERR_UNDEFINED_FUNCTION,
    VM_ERR_NOT_IMPLEMENTED,
    VM_ERR_MEMORY,
    VM_ERR_DECODE
} VmResult;





typedef struct {
    const NvmModule *module;
    uint32_t operation, target, owner;
    uint16_t parameter_start, parameter_count;
} VmEffectHandler;



typedef struct {
    uint16_t root;
    uint32_t region;
    
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        exclusive;
    uint32_t path;
    uint16_t parent;
    
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        live;
    uint16_t origin_frame;
    uint64_t origin_generation;
} VmReferenceSlot;
typedef struct {
    VmReferenceSlot slots[256];
    uint32_t region;
    
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        active;
    uint64_t generation;
} VmReferenceActivation;

typedef struct VmState {

    const NvmModule *module;
    const NvmModule *root_module;
    VmDecodedModule decoded_module;
    
# 145 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 145 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        decoded_module_valid;


    
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        module_calls_resolved;

    uint64_t module_revision;
    VmDispatchModule dispatch_module;
    
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        dispatch_module_valid;







    
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        verified; VmModuleConstants module_constants;


    NanoValue *stack;
    uint32_t stack_size;
    uint32_t stack_capacity;


    VmCallFrame frames[1024];
    uint32_t frame_count;
    VmReferenceActivation references, callee_references;


    VmReferenceActivation value_references[8u -2];

    VmReferenceActivation *effect_references[1024 -8u];
    uint64_t reference_generation;
    VmEffectHandler handlers[1024];
    uint32_t handler_count;
    uint32_t activation_floor;
    pthread_t owner_thread;
    NanoCallbackRuntime *callbacks;
    
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        callbacks_closed;
    VmResult callback_error;
    char callback_error_msg[256];


    uint32_t ip;
    uint32_t current_fn;






    NanoValue *globals;
    uint32_t global_capacity;
    uint32_t global_count;


    uint8_t *memory;
    uint64_t memory_size;


    VmHeap heap;


    const NvmModule **linked_modules;
    VmDecodedModule *decoded_linked_modules;
    
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        *decoded_linked_modules_valid;
    VmDispatchModule *dispatch_linked_modules;
    
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        *dispatch_linked_modules_valid;
    VmModuleConstants *linked_module_constants;
    uint32_t linked_module_count;
    uint32_t linked_module_capacity;


    FILE *output;


    
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        isolate_ffi;

    
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        halt_requested;


    int cop_in_fd;
    int cop_out_fd;
    int cop_pid;


    struct CopMailbox *cop_mailbox;
    size_t cop_mailbox_size;
    int cop_sig_send_fd;
    int cop_sig_recv_fd;
    int cop_timeout_ms;


    VmResult last_error;
    char error_msg[256];



    
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        debug_mode;


    
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        opcode_trace;


    VmProfile profile;




    VmDispatchProfile dispatch_profile;
} VmState;
# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
typedef enum {
    TRAP_NONE = 0,
    TRAP_EXTERN_CALL,
    TRAP_PRINT,
    TRAP_ASSERT,
    TRAP_HALT,
    TRAP_ERROR,
    TRAP_YIELD
} VmTrapType;

typedef struct {
    VmTrapType type;
    union {
        struct { uint32_t import_idx; NanoValue args[16]; int argc; } extern_call;
        struct { NanoValue value; 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                 _Bool 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                      newline; } print;
        struct { NanoValue condition; } assert_check;
        struct { VmResult code; } error;
    } data;
} VmTrap;






void vm_init(VmState *vm, const NvmModule *module);


void vm_destroy(VmState *vm);




VmResult vm_execute(VmState *vm);




VmResult vm_call_function(VmState *vm, uint32_t fn_idx, NanoValue *args, uint16_t arg_count);







VmResult vm_invoke(VmState *vm, uint32_t fn_idx, const NanoValue *args,
                   uint16_t arg_count, NanoValue *out_result);





VmResult vm_invoke_callable(VmState *vm, NanoValue callable, const NanoValue *args,
                            uint16_t arg_count, NanoValue *out_result);



NanoCallbackV1 *vm_callback_create(VmState *vm, NanoValue callable,
                                  const NvmCallbackContract *contract);
int vm_callback_pump(VmState *vm, 
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                 _Bool 
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                      wait);
NanoCallbackStatus vm_callback_shutdown(VmState *vm);




VmTrap vm_core_execute(VmState *vm);


NanoValue vm_get_result(VmState *vm);


void vm_profile_enable(VmState *vm, 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                   _Bool 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                        enabled);





void vm_set_dispatch_profile(VmState *vm, VmDispatchProfile profile);



# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_profile_write_json(const VmState *vm, FILE *out);


const char *vm_error_string(VmResult result);



uint32_t vm_link_module(VmState *vm, const NvmModule *mod);




# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_callable_target(const VmState *vm, NanoValue callable,
                        const NvmModule **module, uint32_t *function_index);



uint32_t vm_link_named_module(VmState *vm, const char *name,
                              const NvmModule *mod);





# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_ensure_globals(VmState *vm, uint32_t count);






# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_resolve_module_calls(VmState *vm);


void vm_invalidate_module(VmState *vm, const NvmModule *module);
void vm_invalidate_decoded_module(VmState *vm, const NvmModule *module);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_rebuild_module(VmState *vm, const NvmModule *module);
VmResult vm_rebuild_decoded_module(VmState *vm, const NvmModule *module);




# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_sync_new_functions(VmState *vm, const NvmModule *module);


void vm_request_halt(VmState *vm);



# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_memory_resize(VmState *vm, uint64_t size);
# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
void vm_stack_trace(const VmState *vm, FILE *out);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 2







typedef struct {
    uint32_t parent, function, continuation, handlers, lexical, depth, next;
    
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
        effect;
} EGFrame;
typedef struct {
    uint32_t parent, owner, key, target, depth, next;
} EGHandler;
typedef struct {
    uint32_t frame, pc, handlers, next, queued_next;
    
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
        queued;
    uint8_t globals[256u];
} EGPoint;
typedef struct {
    const NvmModule *module;
    const NvmOwnershipGlobal *globals;
    uint32_t global_count;
    VmDecodedFunction decoded[8u];
    EGFrame *frames; EGHandler *handlers; EGPoint *points;
    uint32_t frame_count, handler_count, point_count;
    uint32_t frame_capacity, handler_capacity, point_capacity;
    uint32_t *frame_buckets, *handler_buckets, *point_buckets;
    uint32_t head, tail;
    const char *error;
} EGProof;

static uint32_t eg_hash(uint32_t a, uint32_t b, uint32_t c, uint32_t d, uint32_t e) {
    uint32_t h=2166136261u;
    h=(h^a)*16777619u; h=(h^b)*16777619u; h=(h^c)*16777619u;
    h=(h^d)*16777619u; h=(h^e)*16777619u;
    return h&(65536u -1u);
}
static void *eg_grow(void *data, uint32_t *capacity, uint32_t count, size_t width) {
    if(count<*capacity)return data;
    uint32_t limit=262144u;




    if(count>=limit)return 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                          ((void *)0)
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                              ;
    uint32_t next=*capacity?*capacity*2u:32u;
    if(next>limit)next=limit;
    void *grown=realloc(data,(size_t)next*width);
    if(!grown)return 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                    ((void *)0)
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                        ;
    *capacity=next;return grown;
}
static uint32_t eg_frame(EGProof *p, uint32_t parent, uint32_t function,
                          uint32_t continuation, uint32_t handlers, uint32_t lexical) {
    uint32_t bucket=eg_hash(parent,function,continuation,handlers,lexical);
    for(uint32_t n=p->frame_buckets[bucket];n;n=p->frames[n-1].next) {
        const EGFrame *f=&p->frames[n-1];
        if(f->parent==parent && f->function==function && f->continuation==continuation &&
           f->handlers==handlers && f->effect==(lexical!=
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                        (4294967295U)
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                               ) && f->lexical==(lexical==
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                          (4294967295U)
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                                 ?n-1:lexical))return n-1;
    }
    void *grown=eg_grow(p->frames,&p->frame_capacity,p->frame_count,sizeof(*p->frames));
    if(!grown) {
        p->error="I cannot retain bounded effect/global activation states";return 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                 (4294967295U)
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                        ;
    }
    p->frames=grown;
    uint32_t index=p->frame_count++;
    p->frames[index]=(EGFrame){parent,function,continuation,handlers,
        lexical==
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                (4294967295U)
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                       ?index:lexical,parent==
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                              (4294967295U)
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                     ?1:p->frames[parent].depth+1,
        p->frame_buckets[bucket],lexical!=
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                         (4294967295U)
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                };
    p->frame_buckets[bucket]=index+1;return index;
}
static uint32_t eg_handler(EGProof *p, uint32_t parent, uint32_t owner,
                            uint32_t key, uint32_t target) {
    uint32_t bucket=eg_hash(parent,owner,key,target,0);
    for(uint32_t n=p->handler_buckets[bucket];n;n=p->handlers[n-1].next) {
        const EGHandler *h=&p->handlers[n-1];
        if(h->parent==parent && h->owner==owner && h->key==key && h->target==target)return n-1;
    }
    void *grown=eg_grow(p->handlers,&p->handler_capacity,p->handler_count,sizeof(*p->handlers));
    if(!grown) {
        p->error="I cannot retain bounded effect/global handler states";return 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                              (4294967295U)
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                     ;
    }
    p->handlers=grown;
    uint32_t index=p->handler_count++;
    p->handlers[index]=(EGHandler){parent,owner,key,target,
        parent==
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
               (4294967295U)
# 90 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                      ?1:p->handlers[parent].depth+1,p->handler_buckets[bucket]};
    p->handler_buckets[bucket]=index+1;return index;
}
static 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
      _Bool 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
           eg_queue(EGProof *p, uint32_t frame, uint32_t pc, uint32_t handlers,
                       const uint8_t *globals) {
    if(frame>=p->frame_count || pc>=p->decoded[p->frames[frame].function].instruction_count) {
        p->error="I require an exact effect/global continuation";return 
# 96 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                       0
# 96 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                            ;
    }
    uint32_t bucket=eg_hash(frame,pc,handlers,0,0),index=
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                        (4294967295U)
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                               ;
    for(uint32_t n=p->point_buckets[bucket];n;n=p->points[n-1].next)
        if(p->points[n-1].frame==frame && p->points[n-1].pc==pc &&
           p->points[n-1].handlers==handlers){index=n-1;break;}
    
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
   _Bool 
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
        changed=
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                0
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                     ;
    if(index==
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
             (4294967295U)
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                    ) {
        void *grown=eg_grow(p->points,&p->point_capacity,p->point_count,sizeof(*p->points));
        if(!grown) {
            p->error="I exceeded my effect/global control-state storage budget";return 
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                      0
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                           ;
        }
        p->points=grown;
        index=p->point_count++;
        p->points[index]=(EGPoint){.frame=frame,.pc=pc,.handlers=handlers,
            .next=p->point_buckets[bucket],.queued_next=
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                       (4294967295U)
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                              };
        p->point_buckets[bucket]=index+1;changed=
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                1
# 112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                    ;
    }
    EGPoint *point=&p->points[index];
    for(uint32_t g=0;g<p->global_count;g++) {
        uint8_t joined=point->globals[g]|globals[g];
        if(joined!=point->globals[g]){point->globals[g]=joined;changed=
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                      1
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                          ;}
    }
    if(changed && !point->queued) {
        point->queued=
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                     1
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                         ;point->queued_next=
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                             (4294967295U)
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                    ;
        if(p->tail==
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                   (4294967295U)
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                          )p->head=index;
        else p->points[p->tail].queued_next=index;
        p->tail=index;
    }
    return 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
          1
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
              ;
}
static 
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
      _Bool 
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
           eg_return(EGProof *p, uint32_t frame, const uint8_t *globals) {
    EGFrame f=p->frames[frame];
    return f.parent==
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                    (4294967295U) 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                            || eg_queue(p,f.parent,f.continuation,f.handlers,globals);
}
static uint32_t eg_target(EGProof *p, uint32_t function, uint32_t offset) {
    uint32_t base=p->module->functions[function].code_offset;
    const VmDecodedInstruction *in=offset>=base?
        vm_decoded_function_at(&p->decoded[function],offset-base):
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                 ((void *)0)
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                     ;
    if(!in){p->error="I require an exact effect/global branch target";return 
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                            (4294967295U)
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                   ;}
    return (uint32_t)(in-p->decoded[function].instructions);
}
static 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
      _Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
           eg_step(EGProof *p, EGPoint state) {
    EGFrame frame=p->frames[state.frame];
    const VmDecodedInstruction *decoded=&p->decoded[frame.function].instructions[state.pc];
    const DecodedInstruction *in=&decoded->instruction;
    uint32_t next=state.pc+1;
    switch(in->opcode) {
    case OP_HALT:return 
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                       1
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                           ;
    case OP_RET:return eg_return(p,frame.lexical,state.globals);
    case OP_EFFECT_RESUME:
        if(!frame.effect){p->error="I require an active effect/global resumption";return 
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                        0
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                             ;}
        return eg_return(p,state.frame,state.globals);
    case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL: {
        uint32_t g=in->operands[0].u32;
        if(g>=p->global_count){p->error="I require a declared effect/global slot";return 
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                        0
# 151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                             ;}
        uint8_t permitted=in->opcode==OP_LOAD_GLOBAL?2u:(p->globals[g].mutable?3u:1u);
        if(!(nvm_affine_global_require(state.globals[g],permitted)&1u)) {
            p->error="I require global initialization before reads and no repeated immutable store across effects";
            return 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                  0
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                       ;
        }
        if(in->opcode==OP_STORE_GLOBAL)state.globals[g]=nvm_affine_global_compose(state.globals[g],10u);
        break;
    }
    case OP_CALL: {
        uint32_t target=in->operands[0].u32;
        if(!target || target>=p->module->function_count){p->error="I require a declared effect/global callee";return 
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                                                    0
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                                                         ;}

        if(frame.depth==1024)return 
# 164 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                            1
# 164 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                ;
        uint32_t child=eg_frame(p,state.frame,target,next,state.handlers,
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                        (4294967295U)
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                               );
        return child!=
# 166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                     (4294967295U) 
# 166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                             && eg_queue(p,child,0,state.handlers,state.globals);
    }
    case OP_HANDLER_PUSH: {
        if(state.handlers!=
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                          (4294967295U) 
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                  && p->handlers[state.handlers].depth==1024)return 
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                             1
# 169 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                                 ;
        uint32_t target=eg_target(p,frame.function,decoded->resolved_target);
        if(target==
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                  (4294967295U)
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                         )return 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                 0
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                      ;
        state.handlers=eg_handler(p,state.handlers,state.frame,in->operands[0].u32,target);
        if(state.handlers==
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                          (4294967295U)
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                 )return 
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                         0
# 173 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                              ;
        break;
    }
    case OP_HANDLER_POP:
        for(uint16_t i=0;i<in->operands[0].u16;i++) {
            if(state.handlers==
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                              (4294967295U) 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                      || p->handlers[state.handlers].owner!=state.frame) {
                p->error="I cannot pop an absent or inherited effect/global handler";return 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                           0
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                                ;
            }
            state.handlers=p->handlers[state.handlers].parent;
        }
        break;
    case OP_PERFORM: {
        uint32_t selected=state.handlers;
        while(selected!=
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                       (4294967295U) 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                               && !effect_key_equal(p->module,in->operands[0].u32,p->handlers[selected].key))
            selected=p->handlers[selected].parent;
        if(selected==
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                    (4294967295U) 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                            || frame.depth==1024)return 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                 1
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                     ;
        EGHandler handler=p->handlers[selected];EGFrame owner=p->frames[handler.owner];
        uint32_t child=eg_frame(p,state.frame,owner.function,next,state.handlers,owner.lexical);
        return child!=
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                     (4294967295U) 
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                             && eg_queue(p,child,handler.target,state.handlers,state.globals);
    }
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE: case OP_MATCH_TAG: {
        uint32_t target=eg_target(p,frame.function,decoded->resolved_target);
        if(target==
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                  (4294967295U) 
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                          || !eg_queue(p,state.frame,target,state.handlers,state.globals))return 
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                                                                 0
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                                                      ;
        if(in->opcode==OP_JMP)return 
# 196 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                    1
# 196 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                        ;
        break;
    }
    default:break;
    }
    return eg_queue(p,state.frame,next,state.handlers,state.globals);
}
static NvmAffineAnalysis effect_global_proof(const NvmModule *m, const AnalysisCalls *calls) {
    NvmAffineAnalysis result={0};EGProof p={.module=m,.globals=calls->globals,
        .global_count=calls->global_count,.head=
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                               (4294967295U)
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                      ,.tail=
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                             (4294967295U)
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                    };
    p.frame_buckets=calloc(65536u,sizeof(uint32_t));
    p.handler_buckets=calloc(65536u,sizeof(uint32_t));
    p.point_buckets=calloc(65536u,sizeof(uint32_t));
    if(!p.frame_buckets || !p.handler_buckets || !p.point_buckets) {
        p.error="I cannot allocate effect/global control indexes";goto done;
    }
    for(uint32_t f=0;f<m->function_count;f++) {
        char error[256];
        if(!vm_decode_function(m,f,&p.decoded[f],error)) {
            p.error="I require decodable effect/global control flow";goto done;
        }
    }
    uint8_t initial[256u];memset(initial,1,p.global_count);
    uint32_t root=eg_frame(&p,
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                             (4294967295U)
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                    ,0,
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                       (4294967295U)
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                              ,
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                               (4294967295U)
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                      ,
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                       (4294967295U)
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                              );
    if(root==
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
            (4294967295U) 
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                    || !eg_queue(&p,root,0,
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                           (4294967295U)
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                  ,initial))goto done;
    while(p.head!=
# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                 (4294967295U)
# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                        ) {
        uint32_t index=p.head;EGPoint state=p.points[index];
        p.head=state.queued_next;if(p.head==
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                           (4294967295U)
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                  )p.tail=
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                                                          (4294967295U)
# 223 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                                                 ;
        p.points[index].queued=
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
                              0
# 224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                                   ;
        result.byte_offset=p.decoded[p.frames[state.frame].function].instructions[state.pc].byte_offset;
        result.visits++;
        if(!eg_step(&p,state))goto done;
    }
    result.ok=
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc" 3 4
             1
# 229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_effect_globals.inc"
                 ;result.reachable=p.point_count;result.byte_offset=0;
 done:
    if(p.error)snprintf(result.message,sizeof(result.message),"%s",p.error);
    for(uint32_t f=0;f<m->function_count;f++)vm_decoded_function_free(&p.decoded[f]);
    free(p.frames);free(p.handlers);free(p.points);
    free(p.frame_buckets);free(p.handler_buckets);free(p.point_buckets);
    return result;
}
# 988 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 2

NvmAffineAnalysis nvm_affine_analyze_function(const NvmModule *m,uint32_t function) {
    AnalysisCalls calls={0};analysis_calls_init(&calls,m);
    NvmAffineAnalysis result=analyze(m,function,
# 991 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                               ((void *)0)
# 991 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   ,0,&calls);
    if(result.ok && calls.effect_globals) {
        NvmAffineAnalysis globals=effect_global_proof(m,&calls);
        if(!globals.ok)return globals;
    }
    return result;
}

NvmAffineAnalysis nvm_affine_analyze_instructions(const NvmModule *m,
    uint32_t function,NvmAffineInstructionFact *facts,uint32_t capacity) {
    if (!facts || !capacity || capacity>4096u) {
        NvmAffineAnalysis result={0};
        snprintf(result.message,sizeof(result.message),"I require a bounded instruction fact buffer");
        return result;
    }
    AnalysisCalls calls={0};analysis_calls_init(&calls,m);
    NvmAffineInstructionFact *staged=calls.effect_globals?malloc(capacity*sizeof(*staged)):
# 1007 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                                                                          ((void *)0)
# 1007 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                                                              ;
    if(calls.effect_globals && !staged) {
        NvmAffineAnalysis result={0};
        snprintf(result.message,sizeof(result.message),"I cannot stage effect/global instruction facts");return result;
    }
    calls.fact_function=function;calls.fact_capacity=capacity;calls.facts=staged?staged:facts;
    NvmAffineAnalysis result=analyze(m,function,
# 1013 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c" 3 4
                                               ((void *)0)
# 1013 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.c"
                                                   ,0,&calls);
    if(result.ok && calls.effect_globals) {
        NvmAffineAnalysis globals=effect_global_proof(m,&calls);
        if(!globals.ok)result=globals;
    }
    if(result.ok && staged)memcpy(facts,staged,capacity*sizeof(*facts));
    free(staged);return result;
}
