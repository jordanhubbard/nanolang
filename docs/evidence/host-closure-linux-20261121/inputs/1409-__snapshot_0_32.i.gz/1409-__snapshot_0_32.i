# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.h" 1
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.h" 2


typedef enum {
    ASM_OK = 0,
    ASM_ERR_SYNTAX,
    ASM_ERR_UNKNOWN_OPCODE,
    ASM_ERR_BAD_OPERAND,
    ASM_ERR_UNDEFINED_LABEL,
    ASM_ERR_DUPLICATE_LABEL,
    ASM_ERR_NO_FUNCTION,
    ASM_ERR_VERIFY,
    ASM_ERR_MEMORY,
    ASM_ERR_IO,
    ASM_ERR_UNDEFINED_SYMBOL,
    ASM_ERR_DUPLICATE_SYMBOL
} AsmError;


typedef struct {
    AsmError error;
    uint32_t line;
    char message[256];
} AsmResult;






NvmModule *asm_assemble(const char *source, AsmResult *result);






NvmModule *asm_assemble_unverified(const char *source, AsmResult *result);



NvmModule *asm_assemble_file(const char *path, AsmResult *result);
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/local_bindings.h" 1




typedef struct {
    uint32_t function, begin, end;
    uint16_t slot;
    const uint8_t *name;
    uint32_t name_size;
} NvmLocalBinding;
typedef enum { NVM_LOCAL_NAMES_ABSENT, NVM_LOCAL_NAMES_VALID, NVM_LOCAL_NAMES_INVALID } NvmLocalNamesStatus;
NvmLocalNamesStatus nvm_local_names_validate(const NvmModule *module);
NvmLocalNamesStatus nvm_local_name_at(const NvmModule *module, uint32_t function,
                                     uint16_t slot, uint32_t pc, NvmLocalBinding *out);

# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/local_bindings.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/local_bindings.h"
    nvm_add_local_binding(NvmModule *module, const NvmLocalBinding *binding);


NvmLocalNamesStatus nvm_upvalue_names_validate(const NvmModule *module);
NvmLocalNamesStatus nvm_upvalue_name_at(const NvmModule *module, uint32_t function,
                                       uint16_t slot, uint32_t pc, NvmLocalBinding *out);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/local_bindings.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/local_bindings.h"
    nvm_add_upvalue_binding(NvmModule *module, const NvmLocalBinding *binding);
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h" 1
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h" 2




typedef struct {
    
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
        ok;
    char error_msg[256];
} NvmVerifyResult;
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify(const NvmModule *mod);







typedef enum {
    NVM_PROFILE_GENERAL = 0,
    NVM_PROFILE_CLOSED_SCALAR = 1,
    NVM_PROFILE_CLOSED_LITERAL_STRINGS = 2,
    NVM_PROFILE_CLOSED_MANAGED_STRINGS = 3,


    NVM_PROFILE_PORTABLE_FILE_READ = 5,
    NVM_PROFILE_PORTABLE_READ_TEXT = 4
} NvmVerifyProfile;
NvmVerifyResult nvm_verify_profile(const NvmModule *mod, NvmVerifyProfile profile);



NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod);



# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
    nvm_uses_owned_transfers(const NvmModule *mod);



NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx);


NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx);
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_function_types(const NvmModule *mod, uint32_t fn_idx,
                                          const VmDecodedFunction *decoded,
                                          uint16_t max_depth,
                                          char *error, size_t error_size);

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack);





NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count);
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count);
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4
# 53 "/usr/include/stdio.h" 3 4
typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;
# 78 "/usr/include/stdio.h" 3 4
typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 184 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 211 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 236 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 299 "/usr/include/stdio.h" 3 4
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 314 "/usr/include/stdio.h" 3 4
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 357 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 410 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4
# 463 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 540 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 635 "/usr/include/stdio.h" 3 4
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
# 654 "/usr/include/stdio.h" 3 4
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 779 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 860 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 878 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
# 941 "/usr/include/stdio.h" 3 4
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/ctype.h" 1 3 4
# 28 "/usr/include/ctype.h" 3 4

# 39 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 40 "/usr/include/ctype.h" 2 3 4






enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};
# 79 "/usr/include/ctype.h" 3 4
extern const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 108 "/usr/include/ctype.h" 3 4
extern int isalnum (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha (int) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit (int) __attribute__ ((__nothrow__ , __leaf__));
extern int islower (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint (int) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit (int) __attribute__ ((__nothrow__ , __leaf__));



extern int tolower (int __c) __attribute__ ((__nothrow__ , __leaf__));


extern int toupper (int __c) __attribute__ ((__nothrow__ , __leaf__));




extern int isblank (int) __attribute__ ((__nothrow__ , __leaf__));
# 251 "/usr/include/ctype.h" 3 4
extern int isalnum_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int islower_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));

extern int isblank_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));



extern int __tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


extern int __toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 327 "/usr/include/ctype.h" 3 4

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/errno.h" 1 3 4
# 28 "/usr/include/errno.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/errno.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/errno.h" 3 4
# 1 "/usr/include/linux/errno.h" 1 3 4
# 1 "/usr/include/aarch64-linux-gnu/asm/errno.h" 1 3 4
# 1 "/usr/include/asm-generic/errno.h" 1 3 4




# 1 "/usr/include/asm-generic/errno-base.h" 1 3 4
# 6 "/usr/include/asm-generic/errno.h" 2 3 4
# 2 "/usr/include/aarch64-linux-gnu/asm/errno.h" 2 3 4
# 2 "/usr/include/linux/errno.h" 2 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/errno.h" 2 3 4
# 29 "/usr/include/errno.h" 2 3 4








extern int *__errno_location (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 52 "/usr/include/errno.h" 3 4

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 1 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 205 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 2 3 4
# 82 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4
# 206 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 2 3 4
# 35 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2
# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 28 "/usr/include/math.h" 2 3 4












# 1 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 3 4
typedef __Float32x4_t __f32x4_t;
typedef __Float64x2_t __f64x2_t;
# 106 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 3 4
typedef __SVFloat32_t __sv_f32_t;
typedef __SVFloat64_t __sv_f64_t;
typedef __SVBool_t __sv_bool_t;
# 118 "/usr/include/aarch64-linux-gnu/bits/math-vector.h" 3 4
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4vv_atan2f (__f32x4_t, __f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_acosf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_asinf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_atanf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_cosf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_expf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_exp10f (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_exp2f (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_expm1f (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_logf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_log10f (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_log1pf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_log2f (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_sinf (__f32x4_t);
__attribute__ ((__aarch64_vector_pcs__)) __f32x4_t _ZGVnN4v_tanf (__f32x4_t);

__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2vv_atan2 (__f64x2_t, __f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_acos (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_asin (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_atan (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_cos (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_exp (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_exp10 (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_exp2 (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_expm1 (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_log (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_log10 (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_log1p (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_log2 (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_sin (__f64x2_t);
__attribute__ ((__aarch64_vector_pcs__)) __f64x2_t _ZGVnN2v_tan (__f64x2_t);






__sv_f32_t _ZGVsMxvv_atan2f (__sv_f32_t, __sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_acosf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_asinf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_atanf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_cosf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_expf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_exp10f (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_exp2f (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_expm1f (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_logf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_log10f (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_log1pf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_log2f (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_sinf (__sv_f32_t, __sv_bool_t);
__sv_f32_t _ZGVsMxv_tanf (__sv_f32_t, __sv_bool_t);

__sv_f64_t _ZGVsMxvv_atan2 (__sv_f64_t, __sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_acos (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_asin (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_atan (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_cos (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_exp (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_exp10 (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_exp2 (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_expm1 (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_log (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_log10 (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_log1p (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_log2 (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_sin (__sv_f64_t, __sv_bool_t);
__sv_f64_t _ZGVsMxv_tan (__sv_f64_t, __sv_bool_t);
# 41 "/usr/include/math.h" 2 3 4
# 152 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 153 "/usr/include/math.h" 2 3 4
# 163 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 204 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/fp-logb.h" 1 3 4
# 205 "/usr/include/math.h" 2 3 4
# 247 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/fp-fast.h" 1 3 4
# 248 "/usr/include/math.h" 2 3 4
# 312 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinf (double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __isnan (double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __iseqsig (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignaling (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 313 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acos (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __acos (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double asin (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __asin (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double atan (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atan (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern double cos (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cos (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double sin (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sin (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double tan (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __tan (double __x) __attribute__ ((__nothrow__ , __leaf__));




 extern double cosh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cosh (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double sinh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sinh (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double tanh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __tanh (double __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acosh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __acosh (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double asinh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __asinh (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double atanh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atanh (double __x) __attribute__ ((__nothrow__ , __leaf__));





 extern double exp (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __exp (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern double log (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log (double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern double log10 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log10 (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern double expm1 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __expm1 (double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern double log1p (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log1p (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double logb (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __logb (double __x) __attribute__ ((__nothrow__ , __leaf__));




 extern double exp2 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __exp2 (double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern double log2 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log2 (double __x) __attribute__ ((__nothrow__ , __leaf__));






 extern double pow (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));


extern double sqrt (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sqrt (double __x) __attribute__ ((__nothrow__ , __leaf__));



 extern double hypot (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));




 extern double cbrt (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cbrt (double __x) __attribute__ ((__nothrow__ , __leaf__));






extern double ceil (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __ceil (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fabs (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __floor (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));
# 198 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern double copysign (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __copysign (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern double nan (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)); extern double __nan (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__));
# 231 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern double erf (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __erf (double) __attribute__ ((__nothrow__ , __leaf__));
 extern double erfc (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __erfc (double) __attribute__ ((__nothrow__ , __leaf__));
extern double lgamma (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __lgamma (double) __attribute__ ((__nothrow__ , __leaf__));




extern double tgamma (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __tgamma (double) __attribute__ ((__nothrow__ , __leaf__));
# 259 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern double rint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __rint (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 275 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogb (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogb (double __x) __attribute__ ((__nothrow__ , __leaf__));
# 293 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern double nearbyint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __nearbyint (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern double round (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __round (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __trunc (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrint (double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrint (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lround (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lround (double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llround (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llround (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));



extern double fmax (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fmax (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fmin (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ , __leaf__)); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ , __leaf__));
# 314 "/usr/include/math.h" 2 3 4
# 329 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinff (float __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __isnanf (float __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __iseqsigf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignalingf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 330 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acosf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __acosf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float asinf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __asinf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float atanf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atanf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__ , __leaf__));


 extern float cosf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __cosf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float sinf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sinf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float tanf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __tanf (float __x) __attribute__ ((__nothrow__ , __leaf__));




 extern float coshf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __coshf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float sinhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sinhf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float tanhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __tanhf (float __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acoshf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __acoshf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float asinhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __asinhf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float atanhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atanhf (float __x) __attribute__ ((__nothrow__ , __leaf__));





 extern float expf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __expf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern float logf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __logf (float __x) __attribute__ ((__nothrow__ , __leaf__));


 extern float log10f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log10f (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern float expm1f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __expm1f (float __x) __attribute__ ((__nothrow__ , __leaf__));


 extern float log1pf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log1pf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float logbf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __logbf (float __x) __attribute__ ((__nothrow__ , __leaf__));




 extern float exp2f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __exp2f (float __x) __attribute__ ((__nothrow__ , __leaf__));


 extern float log2f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log2f (float __x) __attribute__ ((__nothrow__ , __leaf__));






 extern float powf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));


extern float sqrtf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sqrtf (float __x) __attribute__ ((__nothrow__ , __leaf__));



 extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));




 extern float cbrtf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __cbrtf (float __x) __attribute__ ((__nothrow__ , __leaf__));






extern float ceilf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __ceilf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fabsf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __floorf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));
# 198 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __copysignf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern float nanf (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)); extern float __nanf (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__));
# 231 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern float erff (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __erff (float) __attribute__ ((__nothrow__ , __leaf__));
 extern float erfcf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __erfcf (float) __attribute__ ((__nothrow__ , __leaf__));
extern float lgammaf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __lgammaf (float) __attribute__ ((__nothrow__ , __leaf__));




extern float tgammaf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __tgammaf (float) __attribute__ ((__nothrow__ , __leaf__));
# 259 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern float rintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __rintf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 275 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogbf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogbf (float __x) __attribute__ ((__nothrow__ , __leaf__));
# 293 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern float roundf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __roundf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __truncf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrintf (float __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lroundf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lroundf (float __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llroundf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));



extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fmaxf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fminf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ , __leaf__)); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ , __leaf__));
# 331 "/usr/include/math.h" 2 3 4
# 398 "/usr/include/math.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinfl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __isnanl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__const__));


extern int __iseqsigl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignalingl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 399 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acosl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __acosl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double asinl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __asinl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double atanl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atanl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern long double cosl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __cosl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double sinl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sinl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double tanl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tanl (long double __x) __attribute__ ((__nothrow__ , __leaf__));




 extern long double coshl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __coshl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double sinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double tanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acoshl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double asinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double atanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));





 extern long double expl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __expl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern long double logl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __logl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern long double log10l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log10l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double expm1l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern long double log1pl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double logbl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __logbl (long double __x) __attribute__ ((__nothrow__ , __leaf__));




 extern long double exp2l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern long double log2l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log2l (long double __x) __attribute__ ((__nothrow__ , __leaf__));






 extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



 extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));




 extern long double cbrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__));






extern long double ceill (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __ceill (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fabsl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __floorl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 198 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern long double nanl (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nanl (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__));
# 231 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double erfl (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __erfl (long double) __attribute__ ((__nothrow__ , __leaf__));
 extern long double erfcl (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __erfcl (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double lgammal (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __lgammal (long double) __attribute__ ((__nothrow__ , __leaf__));




extern long double tgammal (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tgammal (long double) __attribute__ ((__nothrow__ , __leaf__));
# 259 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern long double rintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __rintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 275 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
# 293 "/usr/include/aarch64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long double roundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __roundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __truncl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));



extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fminl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ , __leaf__));
# 400 "/usr/include/math.h" 2 3 4
# 934 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 1472 "/usr/include/math.h" 3 4

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 2







# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
typedef enum {
    SYMBOL_FUNCTION,
    SYMBOL_IMPORT,
    SYMBOL_FIELD,
    SYMBOL_TYPE,
    SYMBOL_CONSTANT
} SymbolKind;

typedef struct {
    char name[128];
    uint32_t value;
    SymbolKind kind;
} Symbol;

typedef struct {
    char name[128];
    uint32_t offset;
    uint32_t function;
    
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        defined;
} Label;






typedef struct {
    char label[128];
    uint32_t code_offset;
    uint32_t instr_start;
    uint32_t function;
} Patch;





typedef struct { uint32_t offset, length; } FlowMarker;

typedef struct LocalMarker {
    uint16_t slot;
    uint32_t begin,end,length;
    char *name;
    
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        closed, upvalue;
    struct LocalMarker *next;
} LocalMarker;

typedef struct {
    NvmModule *mod;
    LocalMarker *local_markers, *local_tail;

    Label *labels;
    uint32_t label_count, label_capacity;

    Symbol *symbols;
    uint32_t symbol_count, symbol_capacity;

    Patch *patches;
    uint32_t patch_count, patch_capacity;


    
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        in_function;
    uint32_t current_function;
    uint32_t function_code_start;


    uint8_t *fn_code;
    uint32_t fn_code_size;
    uint32_t fn_code_capacity;
    
# 95 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 95 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        fn_memory_failed;


    
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        passive_structured, par_active, par_node_active;
    uint32_t passive_capacity, par_block_offset, par_node_offset;
    uint32_t passive_blocks, par_nodes;
    FlowMarker *flow_nodes;
    uint32_t flow_count;


    uint32_t line;
} AsmState;

static void asm_state_init(AsmState *state) {
    memset(state, 0, sizeof(*state));
    state->fn_code_capacity = 4096;
    state->fn_code = malloc(state->fn_code_capacity);
}

static void asm_state_cleanup(AsmState *state) {
    while (state->local_markers) {
        LocalMarker *next=state->local_markers->next;
        free(state->local_markers->name);free(state->local_markers);state->local_markers=next;
    }

    free(state->fn_code);
    free(state->labels);
    free(state->symbols);
    free(state->patches);
    free(state->flow_nodes);
}

static void fn_emit(AsmState *state, const uint8_t *data, uint32_t size) {
    if (state->fn_memory_failed) return;
    if (size > 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              (4294967295U) 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                         - state->fn_code_size) {
        state->fn_memory_failed = 
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                 1
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     ;
        return;
    }
    uint32_t required = state->fn_code_size + size;
    if (required > state->fn_code_capacity) {
        uint32_t capacity = state->fn_code_capacity;
        while (capacity < required) {
            if (capacity > 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          (4294967295U) 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     / 2) { capacity = required; break; }
            capacity *= 2;
        }
        uint8_t *grown = realloc(state->fn_code, capacity);
        if (!grown) { state->fn_memory_failed = 
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                               1
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   ; return; }
        state->fn_code = grown;
        state->fn_code_capacity = capacity;
    }
    memcpy(state->fn_code + state->fn_code_size, data, size);
    state->fn_code_size += size;
}





static void skip_whitespace(const char **p) {
    while (**p == ' ' || **p == '\t') (*p)++;
}

static 
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           require_line_end(const char *p, AsmResult *result) {
    skip_whitespace(&p);
    if (*p == '\0') return 
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          1
# 159 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                              ;

    result->error = ASM_ERR_SYNTAX;
    snprintf(result->message, sizeof(result->message),
             "Unexpected trailing input: %s", p);
    return 
# 164 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          0
# 164 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
               ;
}

static 
# 167 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 167 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_identifier(const char **p, char *out, size_t out_size) {
    skip_whitespace(p);
    size_t i = 0;
    while ((**p >= 'A' && **p <= 'Z') || (**p >= 'a' && **p <= 'z') ||
           (**p >= '0' && **p <= '9') || **p == '_' || **p == '$' || **p == '.') {
        if (i + 1 >= out_size) return 
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                     0
# 172 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          ;
        out[i++] = *(*p)++;
    }
    out[i] = '\0';
    return i > 0;
}

static 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           at_line_end(const char *p) {
    skip_whitespace(&p);
    return *p == '\0';
}

static 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_int64(const char **p, int64_t *val) {
    skip_whitespace(p);
    char *end;
    
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   (*__errno_location ()) 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
         = 0;
    long long v = strtoll(*p, &end, 0);
    if (end == *p || 
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                    (*__errno_location ()) 
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                          != 0) return 
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                       0
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                            ;
    *val = (int64_t)v;
    *p = end;
    return 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 195 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_uint32(const char **p, uint32_t *val) {
    int64_t v;
    if (!parse_int64(p, &v)) return 
# 197 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   0
# 197 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ;
    if (v < 0 || v > 
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                    (4294967295U)
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                              ) return 
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                       0
# 198 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                            ;
    *val = (uint32_t)v;
    return 
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 200 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_uint16(const char **p, uint16_t *val) {
    int64_t v;
    if (!parse_int64(p, &v)) return 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   0
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ;
    if (v < 0 || v > 
# 206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                    (65535)
# 206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                              ) return 
# 206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                       0
# 206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                            ;
    *val = (uint16_t)v;
    return 
# 208 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 208 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_uint8(const char **p, uint8_t *val) {
    int64_t v;
    if (!parse_int64(p, &v)) return 
# 213 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   0
# 213 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ;
    if (v < 0 || v > 255) return 
# 214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                0
# 214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     ;
    *val = (uint8_t)v;
    return 
# 216 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 216 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 219 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_result_tag(const char **p, uint8_t *tag) {
    char name[32];
    if (!parse_identifier(p, name, sizeof(name))) return 
# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                        0
# 221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                             ;
    for (uint8_t candidate = 0; candidate < TAG_COUNT; candidate++) {
        if (strcmp(name, isa_tag_name(candidate)) == 0) {
            *tag = candidate;
            return 
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }
    }
    return 
# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          0
# 228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
               ;
}

static 
# 231 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 231 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_double(const char **p, double *val) {
    skip_whitespace(p);
    if (strncmp(*p, "bits:", 5) == 0) {
        const char *digits = *p + 5;
        uint64_t bits = 0;
        for (unsigned i = 0; i < 16; i++) {
            unsigned char c = (unsigned char)digits[i];
            unsigned digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
            else return 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                       0
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                            ;
            bits = (bits << 4) | digit;
        }
        if (digits[16] && !
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          ((*__ctype_b_loc ())[(int) ((
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                          (unsigned char)digits[16]
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          ))] & (unsigned short int) _ISspace)
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                            ) return 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                     0
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                          ;
        _Static_assert(sizeof(bits) == sizeof(*val), "I require binary64 operand storage.");
        memcpy(val, &bits, sizeof(bits));
        *p = digits + 16;
        return 
# 249 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 249 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    char *end;
    
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   (*__errno_location ()) 
# 252 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
         = 0;
    double v = strtod(*p, &end);
    if (end == *p || (
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                     (*__errno_location ()) 
# 254 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           != 0 &&
        !(
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
         (*__errno_location ()) 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
               == 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  34 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                         && 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            __builtin_fpclassify (0, 1, 4, 3, 2, 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                            v
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            ) 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          == 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                             3
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                         ))) return 
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                    0
# 255 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                         ;
    *val = v;
    *p = end;
    return 
# 258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 261 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 261 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_int32(const char **p, int32_t *val) {
    int64_t v;
    if (!parse_int64(p, &v)) return 
# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   0
# 263 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ;
    if (v < 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           (-2147483647-1) 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                     || v > 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            (2147483647)
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     ) return 
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                              0
# 264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   ;
    *val = (int32_t)v;
    return 
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 266 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_symbol_kind(const char **p, SymbolKind *kind) {
    char name[32];
    if (!parse_identifier(p, name, sizeof(name))) return 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                        0
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                             ;
    if (strcmp(name, "function") == 0) *kind = SYMBOL_FUNCTION;
    else if (strcmp(name, "import") == 0) *kind = SYMBOL_IMPORT;
    else if (strcmp(name, "field") == 0) *kind = SYMBOL_FIELD;
    else if (strcmp(name, "type") == 0) *kind = SYMBOL_TYPE;
    else if (strcmp(name, "constant") == 0) *kind = SYMBOL_CONSTANT;
    else return 
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
               0
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                    ;
    return 
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static const char *symbol_kind_name(SymbolKind kind) {
    static const char *names[] = { "function", "import", "field", "type", "constant" };
    return names[kind];
}

static int find_symbol(const AsmState *state, SymbolKind kind, const char *name) {
    for (uint32_t i = 0; i < state->symbol_count; i++) {
        if (state->symbols[i].kind == kind && strcmp(state->symbols[i].name, name) == 0)
            return (int)i;
    }
    return -1;
}


static void *reserve_table(void *table, uint32_t *capacity, uint32_t count,
                           size_t element_size, AsmResult *result) {
    if (count < *capacity) return table;
    if (count >= 0x7fffffff
# 298 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ) {
        result->error = ASM_ERR_BAD_OPERAND;
        snprintf(result->message, sizeof(result->message), "I reached my assembler table index limit");
        return 
# 301 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 301 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    uint32_t next = *capacity ? (*capacity > 0x7fffffff 
# 303 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                    / 2 ? 0x7fffffff 
# 303 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                  : *capacity * 2) : 64;
    if (next > 
# 304 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              (18446744073709551615UL) 
# 304 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       / element_size) {
        result->error = ASM_ERR_BAD_OPERAND;
        snprintf(result->message, sizeof(result->message), "I cannot represent this assembler table size");
        return 
# 307 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 307 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    void *grown = realloc(table, (size_t)next * element_size);
    if (!grown) {
        result->error = ASM_ERR_MEMORY;
        snprintf(result->message, sizeof(result->message), "I cannot grow this assembler table");
        return 
# 313 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 313 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    *capacity = next;
    return grown;
}

static 
# 319 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 319 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           add_symbol(AsmState *state, SymbolKind kind, const char *name, uint32_t value, AsmResult *result) {
    if (find_symbol(state, kind, name) >= 0) { result->error = ASM_ERR_DUPLICATE_SYMBOL; return 
# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                                               0
# 320 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                                                    ; }
    Symbol *grown = reserve_table(state->symbols, &state->symbol_capacity,
                                 state->symbol_count, sizeof(Symbol), result);
    if (!grown) return 
# 323 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 323 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
    state->symbols = grown;
    Symbol *symbol = &state->symbols[state->symbol_count++];
    snprintf(symbol->name, sizeof(symbol->name), "%s", name);
    symbol->kind = kind;
    symbol->value = value;
    return 
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           operand_symbol_kind(uint8_t opcode, int operand_index, SymbolKind *kind) {
    if (operand_index == 0) {
        switch (opcode) {
            case OP_CALL: case OP_TAIL_CALL: case OP_FUNCREF: case OP_CLOSURE_NEW:
                *kind = SYMBOL_FUNCTION; return 
# 336 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                               1
# 336 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   ;
            case OP_CALL_EXTERN:
                *kind = SYMBOL_IMPORT; return 
# 338 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                             1
# 338 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                 ;
            case OP_PUSH_STR: case OP_HANDLER_PUSH: case OP_PERFORM:
                *kind = SYMBOL_CONSTANT; return 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                               1
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   ;
            case OP_STRUCT_NEW: case OP_STRUCT_LITERAL: case OP_UNION_CONSTRUCT: case OP_ENUM_VAL:
                *kind = SYMBOL_TYPE; return 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                           1
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                               ;
            case OP_STRUCT_GET: case OP_STRUCT_SET: case OP_UNION_FIELD:
            case OP_AGG_GET: case OP_AGG_SET:
                *kind = SYMBOL_FIELD; return 
# 345 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            1
# 345 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                ;
            default: break;
        }
    }
    if (opcode == OP_AGG_PACK && operand_index == 1) {
        *kind = SYMBOL_TYPE;
        return 
# 351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    return 
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          0
# 353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
               ;
}

static int hex_digit_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}





static void strip_trailing_comment(char *line) {
    
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        quoted = 
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                 0
# 368 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
    for (char *p = line; *p; p++) {
        if (quoted && *p == '\\' && p[1]) { p++; continue; }
        if (*p == '"') { quoted = !quoted; continue; }
        if (!quoted && (*p == ';' || *p == '#')) { *p = '\0'; return; }
    }
}

static 
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           parse_quoted_string(const char **p, char *out, size_t out_size, uint32_t *out_len) {
    skip_whitespace(p);
    if (**p != '"') return 
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
    (*p)++;

    uint32_t i = 0;
    while (**p != '"' && **p != '\0') {
        if (i + 1 >= out_size) return 
# 383 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                     0
# 383 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          ;
        if (**p == '\\') {
            (*p)++;




            if (**p == '\0') return 
# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   0
# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ;
            switch (**p) {
                case 'n': out[i++] = '\n'; break;
                case 'r': out[i++] = '\r'; break;
                case 't': out[i++] = '\t'; break;
                case '\\': out[i++] = '\\'; break;
                case '"': out[i++] = '"'; break;
                case '0': out[i++] = '\0'; break;
                case 'x': {
                    int hi = hex_digit_value((*p)[1]);
                    int lo = hi < 0 ? -1 : hex_digit_value((*p)[2]);
                    if (lo < 0) return 
# 401 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                      0
# 401 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                           ;
                    out[i++] = (char)((hi << 4) | lo);
                    (*p) += 2;
                    break;
                }
                default: out[i++] = **p; break;
            }
        } else {
            out[i++] = **p;
        }
        (*p)++;
    }
    if (**p != '"') return 
# 413 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 413 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
    (*p)++;

    out[i] = '\0';
    *out_len = i;
    return 
# 418 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 418 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}





static int find_label(AsmState *state, const char *name, uint32_t function) {
    for (uint32_t i = 0; i < state->label_count; i++) {
        if (state->labels[i].function == function &&
            strcmp(state->labels[i].name, name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

static 
# 435 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 435 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           add_label(AsmState *state, const char *name, uint32_t offset, AsmResult *result) {
    int existing = find_label(state, name, state->current_function);
    if (existing >= 0 && state->labels[existing].defined) { result->error = ASM_ERR_DUPLICATE_LABEL; return 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                                                           0
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                                                                ; }

    if (existing >= 0) {
        state->labels[existing].offset = offset;
        state->labels[existing].defined = 
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                         1
# 441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                             ;
        return 
# 442 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 442 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }

    Label *grown = reserve_table(state->labels, &state->label_capacity,
                                state->label_count, sizeof(Label), result);
    if (!grown) return 
# 447 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 447 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
    state->labels = grown;
    Label *l = &state->labels[state->label_count++];
    snprintf(l->name, sizeof(l->name), "%s", name);
    l->offset = offset;
    l->function = state->current_function;
    l->defined = 
# 453 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                1
# 453 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                    ;
    return 
# 454 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 454 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 457 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 457 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           add_patch(AsmState *state, const char *label, uint32_t code_offset, uint32_t instr_start, AsmResult *result) {
    Patch *grown = reserve_table(state->patches, &state->patch_capacity,
                                state->patch_count, sizeof(Patch), result);
    if (!grown) return 
# 460 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 460 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
    state->patches = grown;
    Patch *p = &state->patches[state->patch_count++];
    snprintf(p->label, sizeof(p->label), "%s", label);
    p->code_offset = code_offset;
    p->instr_start = instr_start;
    p->function = state->current_function;
    return 
# 467 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 467 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}






static uint32_t encode_operand(uint8_t *buf, OperandType type, uint8_t opcode,
                               int operand_index,
                               const char **line_ptr, AsmState *state,
                               uint32_t instr_start, AsmResult *result) {
    SymbolKind symbol_kind;
    if ((type == OPERAND_U16 || type == OPERAND_U32) &&
        operand_symbol_kind(opcode, operand_index, &symbol_kind)) {
        const char *saved = *line_ptr;
        char name[128];
        skip_whitespace(line_ptr);
        if (((**line_ptr >= 'A' && **line_ptr <= 'Z') ||
             (**line_ptr >= 'a' && **line_ptr <= 'z') || **line_ptr == '_' || **line_ptr == '$') &&
            parse_identifier(line_ptr, name, sizeof(name))) {
            int found = find_symbol(state, symbol_kind, name);
            if (found < 0) {
                result->error = ASM_ERR_UNDEFINED_SYMBOL;
                snprintf(result->message, sizeof(result->message),
                         "Undefined %s symbol: %s", symbol_kind_name(symbol_kind), name);
                return 0;
            }
            uint32_t value = state->symbols[found].value;
            if (type == OPERAND_U16 && value > 
# 496 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                              (65535)
# 496 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                        ) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "%s symbol out of u16 range: %s", symbol_kind_name(symbol_kind), name);
                return 0;
            }
            buf[0] = (uint8_t)(value & 0xff);
            buf[1] = (uint8_t)((value >> 8) & 0xff);
            if (type == OPERAND_U32) {
                buf[2] = (uint8_t)((value >> 16) & 0xff);
                buf[3] = (uint8_t)((value >> 24) & 0xff);
                return 4;
            }
            return 2;
        }
        *line_ptr = saved;
    }
    switch (type) {
        case OPERAND_U8: {
            uint8_t v;
            if (!parse_uint8(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected u8 operand");
                return 0;
            }
            buf[0] = v;
            return 1;
        }
        case OPERAND_U16: {
            uint16_t v;
            if (!parse_uint16(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected u16 operand");
                return 0;
            }
            buf[0] = (uint8_t)(v & 0xFF);
            buf[1] = (uint8_t)((v >> 8) & 0xFF);
            return 2;
        }
        case OPERAND_U32: {
            uint32_t v;
            if (!parse_uint32(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected u32 operand");
                return 0;
            }
            buf[0] = (uint8_t)(v & 0xFF);
            buf[1] = (uint8_t)((v >> 8) & 0xFF);
            buf[2] = (uint8_t)((v >> 16) & 0xFF);
            buf[3] = (uint8_t)((v >> 24) & 0xFF);
            return 4;
        }
        case OPERAND_I32: {

            skip_whitespace(line_ptr);
            if ((**line_ptr >= 'A' && **line_ptr <= 'Z') ||
                (**line_ptr >= 'a' && **line_ptr <= 'z') ||
                (**line_ptr == '_' || **line_ptr == '$')) {

                char label[128];
                if (!parse_identifier(line_ptr, label, sizeof(label))) {
                    result->error = ASM_ERR_BAD_OPERAND;
                    snprintf(result->message, sizeof(result->message),
                             "Expected label or i32 operand");
                    return 0;
                }

                if (!add_patch(state, label, 0, instr_start, result)) return 0;

                memset(buf, 0, 4);
                return 4;
            }
            int32_t v;
            if (!parse_int32(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected i32 operand");
                return 0;
            }
            uint32_t uv = (uint32_t)v;
            buf[0] = (uint8_t)(uv & 0xFF);
            buf[1] = (uint8_t)((uv >> 8) & 0xFF);
            buf[2] = (uint8_t)((uv >> 16) & 0xFF);
            buf[3] = (uint8_t)((uv >> 24) & 0xFF);
            return 4;
        }
        case OPERAND_I64: {
            int64_t v;
            if (!parse_int64(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected i64 operand");
                return 0;
            }
            uint64_t uv = (uint64_t)v;
            for (int i = 0; i < 8; i++) {
                buf[i] = (uint8_t)(uv & 0xFF);
                uv >>= 8;
            }
            return 8;
        }
        case OPERAND_F64: {
            double v;
            if (!parse_double(line_ptr, &v)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "Expected f64 operand");
                return 0;
            }
            uint64_t bits;
            memcpy(&bits, &v, sizeof(bits));
            for (int i = 0; i < 8; i++) {
                buf[i] = (uint8_t)(bits & 0xFF);
                bits >>= 8;
            }
            return 8;
        }
        case OPERAND_NONE:
            return 0;
    }
    return 0;
}

static 
# 622 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 622 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           assemble_instruction(AsmState *state, const char *mnemonic,
                                 const char **rest, AsmResult *result) {
    int opcode = isa_opcode_by_name(mnemonic);
    if (opcode < 0) {
        result->error = ASM_ERR_UNKNOWN_OPCODE;
        snprintf(result->message, sizeof(result->message),
                 "Unknown opcode: %s", mnemonic);
        return 
# 629 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 629 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }

    const InstructionInfo *info = isa_get_info((uint8_t)opcode);
    if (!info) {
        result->error = ASM_ERR_UNKNOWN_OPCODE;
        return 
# 635 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 635 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }

    uint32_t instr_start = state->fn_code_size;


    uint8_t op = (uint8_t)opcode;
    fn_emit(state, &op, 1);


    for (int i = 0; i < info->operand_count; i++) {
        uint8_t operand_buf[8];

        uint32_t patch_offset = state->fn_code_size;
        uint32_t patches_before = state->patch_count;
        uint32_t nbytes = encode_operand(operand_buf, info->operands[i], (uint8_t)opcode, i,
                                           rest, state, instr_start, result);
        if (result->error != ASM_OK) return 
# 652 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                           0
# 652 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                ;


        if (info->operands[i] == OPERAND_I32 && state->patch_count > patches_before) {
            Patch *last = &state->patches[state->patch_count - 1];
            if (last->code_offset != patch_offset) {
                last->code_offset = patch_offset;
            }
        }

        fn_emit(state, operand_buf, nbytes);
    }

    return require_line_end(*rest, result);
}





static 
# 672 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 672 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           par_error(AsmResult *result, const char *message) {
    result->error = ASM_ERR_SYNTAX;
    snprintf(result->message, sizeof(result->message), "%s", message);
    return 
# 675 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          0
# 675 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
               ;
}

static void passive_patch(AsmState *state, uint32_t offset, uint32_t word) {
    for (unsigned i = 0; i < 4; ++i)
        state->mod->passive_data[offset + i] = (uint8_t)(word >> (8 * i));
}

static 
# 683 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 683 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           passive_word(AsmState *state, uint32_t word, AsmResult *result) {
    uint32_t size = state->mod->passive_size;
    if (size > 
# 685 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              (4294967295U) 
# 685 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                         - 4) {
        result->error = ASM_ERR_MEMORY;
        snprintf(result->message, sizeof(result->message), "I cannot grow the passive record.");
        return 
# 688 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 688 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }
    uint32_t needed = size + 4;
    if (needed > state->passive_capacity) {
        uint32_t capacity = state->passive_capacity ? state->passive_capacity : 128;
        while (capacity < needed)
            capacity = capacity > 
# 694 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                 (4294967295U) 
# 694 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                            / 2 ? 
# 694 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                  (4294967295U) 
# 694 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                             : capacity * 2;
        uint8_t *data = realloc(state->mod->passive_data, capacity);
        if (!data) {
            result->error = ASM_ERR_MEMORY;
            snprintf(result->message, sizeof(result->message), "I cannot allocate the passive record.");
            return 
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 699 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }
        state->mod->passive_data = data;
        state->passive_capacity = capacity;
    }
    passive_patch(state, size, word);
    state->mod->passive_size = needed;
    return 
# 706 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 706 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 709 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 709 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           par_directive(AsmState *state, const char *directive,
                          const char *p, AsmResult *result) {
    if (state->flow_nodes)
        return par_error(result, "I cannot mix par markers into a flow block.");
    if (!state->in_function)
        return par_error(result, "I require passive producer markers inside a function.");
    if (state->mod->code_size > 
# 715 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                               (4294967295U) 
# 715 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          - state->fn_code_size)
        return par_error(result, "I cannot represent the passive instruction offset.");
    uint32_t offset = state->mod->code_size + state->fn_code_size;
    if (strcmp(directive, "par_begin") == 0) {
        if (!require_line_end(p, result)) return 
# 719 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                0
# 719 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                     ;
        if (state->par_active)
            return par_error(result, "I cannot nest passive producer blocks.");
        if (!state->passive_structured) {
            if (state->mod->passive_size)
                return par_error(result, "I cannot mix raw passive chunks and producer markers.");
            if (!passive_word(state, 2, result) || !passive_word(state, 0, result)) return 
# 725 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                                          0
# 725 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                                               ;
            state->passive_structured = 
# 726 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                       1
# 726 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                           ;
        }
        state->par_block_offset = state->mod->passive_size;
        uint32_t fields[] = {1, state->current_function, offset, 0, 0};
        for (unsigned i = 0; i < 5; ++i)
            if (!passive_word(state, fields[i], result)) return 
# 731 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                               0
# 731 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                    ;
        state->par_active = 
# 732 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                           1
# 732 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
        state->par_node_active = 
# 733 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                0
# 733 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     ;
        state->par_nodes = 0;
        return 
# 735 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 735 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    if (!state->par_active)
        return par_error(result, "I require .par_begin before a passive node or end marker.");
    if (strcmp(directive, "par_end") == 0) {
        if (!require_line_end(p, result)) return 
# 740 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                0
# 740 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                     ;
        if (!state->par_node_active)
            return par_error(result, "I require at least one node in a passive producer block.");
        passive_patch(state, state->par_node_offset + 4, offset);
        passive_patch(state, state->par_block_offset + 12, offset);
        passive_patch(state, state->par_block_offset + 16, state->par_nodes);
        passive_patch(state, 4, ++state->passive_blocks);
        state->par_active = state->par_node_active = 
# 747 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                    0
# 747 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                         ;
        return 
# 748 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 748 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    uint32_t local;
    if (!parse_uint32(&p, &local) || local > 
# 751 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            (65535)
# 751 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                      )
        return par_error(result, "I require a local index after .par_node.");
    if (state->par_node_active) passive_patch(state, state->par_node_offset + 4, offset);
    state->par_node_offset = state->mod->passive_size;
    uint32_t fields[] = {offset, 0, local, 0, 0, 0, 0};
    for (unsigned i = 0; i < 7; ++i)
        if (!passive_word(state, fields[i], result)) return 
# 757 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                           0
# 757 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                ;
    uint32_t count = 0;
    for (;;) {
        skip_whitespace(&p);
        if (!*p) break;
        uint32_t input;
        if (!parse_uint32(&p, &input) || input > 
# 763 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                (65535)
# 763 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                          )
            return par_error(result, "I require parameter indices after the passive result local.");
        if (!passive_word(state, input, result)) return 
# 765 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                       0
# 765 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                            ;
        ++count;
    }
    passive_patch(state, state->par_node_offset + 16, count);
    ++state->par_nodes;
    state->par_node_active = 
# 770 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            1
# 770 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                ;
    return 
# 771 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 771 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static 
# 774 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 774 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           flow_directive(AsmState *state, const char *directive,
                           const char *p, AsmResult *result) {
    if (!state->in_function)
        return par_error(result, "I require flow producer markers inside a function.");
    if (state->mod->code_size > 
# 778 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                               (4294967295U) 
# 778 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          - state->fn_code_size)
        return par_error(result, "I cannot represent the flow instruction offset.");
    uint32_t offset = state->mod->code_size + state->fn_code_size;
    if (strcmp(directive, "flow_begin") == 0) {
        uint32_t count;
        if (!parse_uint32(&p, &count) || !count ||
            count > state->mod->functions[state->current_function].local_count)
            return par_error(result, "I require a positive flow node count within the function locals.");
        if (!require_line_end(p, result)) return 
# 786 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                0
# 786 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                     ;
        if (!par_directive(state, "par_begin", "", result)) return 
# 787 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                  0
# 787 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                       ;
        state->flow_nodes = calloc(count, sizeof(FlowMarker));
        if (!state->flow_nodes) {
            result->error = ASM_ERR_MEMORY;
            snprintf(result->message, sizeof(result->message), "I cannot allocate the flow marker index.");
            return 
# 792 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 792 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }
        state->flow_count = count;
        passive_patch(state, state->par_block_offset, 2);
        return 
# 796 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 796 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    if (!state->flow_nodes)
        return par_error(result, "I require .flow_begin before a flow node or end marker.");
    if (strcmp(directive, "flow_end") == 0) {
        if (!require_line_end(p, result)) return 
# 801 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                0
# 801 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                     ;
        if (state->par_nodes != state->flow_count)
            return par_error(result, "I require every source node exactly once before .flow_end.");
        passive_patch(state, state->par_node_offset + 4, offset);
        uint32_t start = state->par_block_offset + 20;
        uint32_t size = state->mod->passive_size - start;
        uint8_t *ordered = malloc(size);
        if (!ordered) {
            result->error = ASM_ERR_MEMORY;
            snprintf(result->message, sizeof(result->message), "I cannot order the flow records.");
            return 
# 811 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 811 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }
        uint32_t cursor = 0;
        for (uint32_t i = 0; i < state->flow_count; ++i) {
            FlowMarker node = state->flow_nodes[i];
            memcpy(ordered + cursor, state->mod->passive_data + node.offset, node.length);
            cursor += node.length;
        }
        memcpy(state->mod->passive_data + start, ordered, size);
        free(ordered);
        free(state->flow_nodes);
        state->flow_nodes = 
# 822 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                           ((void *)0)
# 822 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
        passive_patch(state, state->par_block_offset + 12, offset);
        passive_patch(state, state->par_block_offset + 16, state->flow_count);
        passive_patch(state, 4, ++state->passive_blocks);
        state->par_active = state->par_node_active = 
# 826 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                    0
# 826 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                         ;
        state->flow_count = 0;
        return 
# 828 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              1
# 828 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    uint32_t id, local, dependencies;
    if (!parse_uint32(&p, &id) || id >= state->flow_count ||
        !parse_uint32(&p, &local) || local > 
# 832 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            (65535) 
# 832 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                       ||
        !parse_uint32(&p, &dependencies) || dependencies > state->flow_count)
        return par_error(result, "I require a source ID, result local and dependency count after .flow_node.");
    if (state->flow_nodes[id].length)
        return par_error(result, "I require distinct flow source IDs.");
    if (state->par_node_active) passive_patch(state, state->par_node_offset + 4, offset);
    uint32_t start = state->mod->passive_size;
    uint32_t fields[] = {offset, 0, local, dependencies, 0, 0, 0};
    for (unsigned i = 0; i < 7; ++i)
        if (!passive_word(state, fields[i], result)) return 
# 841 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                           0
# 841 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                ;
    uint32_t previous = 0;
    for (uint32_t i = 0; i < dependencies; ++i) {
        uint32_t dependency;
        if (!parse_uint32(&p, &dependency) || dependency >= state->flow_count ||
            (i && dependency <= previous))
            return par_error(result, "I require sorted distinct source IDs for flow dependencies.");
        if (!passive_word(state, dependency, result)) return 
# 848 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                            0
# 848 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                 ;
        previous = dependency;
    }
    uint32_t reads;
    if (!parse_uint32(&p, &reads) || reads > state->mod->functions[state->current_function].arity)
        return par_error(result, "I require a parameter-read count after flow dependencies.");
    passive_patch(state, start + 16, reads);
    previous = 0;
    for (uint32_t i = 0; i < reads; ++i) {
        uint32_t input;
        if (!parse_uint32(&p, &input) || input >= state->mod->functions[state->current_function].arity ||
            (i && input <= previous))
            return par_error(result, "I require sorted distinct parameter indices for flow reads.");
        if (!passive_word(state, input, result)) return 
# 861 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                       0
# 861 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                            ;
        previous = input;
    }
    if (!require_line_end(p, result)) return 
# 864 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            0
# 864 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                 ;
    state->flow_nodes[id].offset = start;
    state->flow_nodes[id].length = state->mod->passive_size - start;
    state->par_node_offset = start;
    state->par_node_active = 
# 868 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            1
# 868 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                ;
    ++state->par_nodes;
    return 
# 870 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 870 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}




static 
# 876 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 876 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           assemble_import(AsmState *state, const char *p, AsmResult *result) {
    size_t length = strlen(p);
    if (length >= 
# 878 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                 (4294967295U)
# 878 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ) {
        result->error = ASM_ERR_BAD_OPERAND;
        snprintf(result->message, sizeof(result->message),
                 "I require import names within the u32 string length limit");
        return 
# 882 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 882 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }
    size_t capacity = length + 1;
    char *names = malloc(capacity);
    if (!names) {
        result->error = ASM_ERR_MEMORY;
        snprintf(result->message, sizeof(result->message), "I cannot allocate import names");
        return 
# 889 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 889 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }
    uint32_t mlen = 0, slen = 0;
    uint8_t return_tag;
    
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
   _Bool 
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
        parsed = parse_quoted_string(&p, names, capacity, &mlen);
    char *symbol = parsed ? names + mlen + 1 : names;
    if (!parsed || !parse_quoted_string(&p, symbol, capacity - (size_t)(symbol - names), &slen) ||
        !parse_result_tag(&p, &return_tag)) {
        result->error = ASM_ERR_SYNTAX;
        snprintf(result->message, sizeof(result->message),
                 "I expect .import \"module\" \"symbol\" return-tag [param-tags...]");
        free(names);
        return 
# 901 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 901 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }
    uint8_t params[16];
    uint16_t param_count = 0;
    for (;;) {
        skip_whitespace(&p);
        if (at_line_end(p)) break;
        if (param_count >= 16 || !parse_result_tag(&p, &params[param_count])) {
            result->error = ASM_ERR_SYNTAX;
            snprintf(result->message, sizeof(result->message),
                     "I require at most %d valid parameter tags after .import", 16);
            free(names);
            return 
# 913 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 913 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }
        param_count++;
    }
    uint32_t midx = nvm_add_string(state->mod, names, mlen);
    uint32_t sidx = midx == 
# 918 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                           (4294967295U) 
# 918 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                      ? 
# 918 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                        (4294967295U) 
# 918 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   : nvm_add_string(state->mod, symbol, slen);
    free(names);
    if (midx == 
# 920 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
               (4294967295U) 
# 920 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                          || sidx == 
# 920 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                     (4294967295U) 
# 920 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                ||
        nvm_add_import(state->mod, midx, sidx, param_count, return_tag,
                       param_count ? params : 
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                             ((void *)0)
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                 ) == 
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                      (4294967295U)
# 922 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                ) {
        result->error = ASM_ERR_MEMORY;
        snprintf(result->message, sizeof(result->message), "I cannot retain this import declaration");
        return 
# 925 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 925 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }
    return require_line_end(p, result);
}

static 
# 930 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 930 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           process_line(AsmState *state, const char *line, AsmResult *result) {
    const char *p = line;
    skip_whitespace(&p);


    if (*p == '\0' || *p == ';' || *p == '#') return 
# 935 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                    1
# 935 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                        ;


    if (*p == '.') {
        p++;
        char directive[64];
        if (!parse_identifier(&p, directive, sizeof(directive))) {
            result->error = ASM_ERR_SYNTAX;
            snprintf(result->message, sizeof(result->message),
                     "Invalid directive");
            return 
# 945 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 945 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }


        if (strcmp(directive, "shadow") == 0) {
            if (!state->in_function || state->mod->code_size > 
# 950 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                              (4294967295U) 
# 950 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                         - state->fn_code_size)
                return par_error(result, "I require a shadow marker inside a bounded function.");
            size_t available = strlen(p) + 1;
            uint32_t length = 0;
            char *name = malloc(available);
            if (!name) return par_error(result, "I cannot allocate a shadow name.");
            
# 956 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 956 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid = parse_quoted_string(&p, name, available, &length) && length && require_line_end(p, result);
            for (uint32_t i = 0; valid && i < length; ++i)
                if ((unsigned char)name[i] < 32 || (unsigned char)name[i] == 127) valid = 
# 958 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                                         0
# 958 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                                              ;
            if (!valid) {
                free(name);
                return par_error(result, "I require one nonempty shadow name without control bytes.");
            }
            char key[64];
            snprintf(key, sizeof key, "nanolang.shadow.offset.%u", state->mod->code_size + state->fn_code_size);
            uint32_t key_index = nvm_add_string(state->mod, key, (uint32_t)strlen(key));
            uint32_t value_index = nvm_add_string(state->mod, name, length);
            free(name);
            if (key_index == 
# 968 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            (4294967295U) 
# 968 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                       || value_index == 
# 968 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                         (4294967295U) 
# 968 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                    ||
                !nvm_add_metadata(state->mod, key_index, value_index))
                return par_error(result, "I cannot retain a shadow execution marker.");
            uint8_t opcode = OP_NOP;
            fn_emit(state, &opcode, 1);
            return 
# 973 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 973 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "generic_binding") == 0) {
            if (!state->in_function)
                return par_error(result, "I require generic_binding inside a function.");
            char *fields[4] = {0};
            
# 980 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 980 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid = 
# 980 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                        1
# 980 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                            ;
            for (unsigned i = 0; i < 4 && valid; ++i) {
                size_t capacity = strlen(p) + 1;
                uint32_t length = 0;
                fields[i] = malloc(capacity);
                valid = fields[i] && parse_quoted_string(&p, fields[i], capacity, &length) &&
                    strlen(fields[i]) == length;
            }
            valid = valid && require_line_end(p, result) &&
                nvm_add_generic_binding(state->mod, state->current_function,
                    fields[0], fields[1], fields[2], fields[3]);
            for (unsigned i = 0; i < 4; ++i) free(fields[i]);
            if (!valid) return par_error(result, "I require four quoted, unambiguous generic binding fields.");
            return 
# 993 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 993 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "function_purity") == 0) {
            uint16_t declared;
            if (!state->in_function || !parse_uint16(&p, &declared) ||
                declared > 1 || !require_line_end(p, result))
                return par_error(result, "I require function_purity 0 or 1 inside a function.");
            if (!nvm_add_function_purity(state->mod, state->current_function, declared != 0))
                return par_error(result, "I cannot retain an ambiguous function purity declaration.");
            return 
# 1003 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1003 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "match_coverage") == 0) {
            uint32_t line, column, coverage, coordinates;
            if (!state->in_function || !parse_uint32(&p, &line) || !parse_uint32(&p, &column) ||
                !parse_uint32(&p, &coverage) || !parse_uint32(&p, &coordinates))
                return par_error(result, "I require match line, column, coverage and coordinate provenance inside a function.");
            size_t capacity = strlen(p) + 1;
            char *path = malloc(capacity);
            uint32_t length = 0;
            
# 1014 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1014 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid = path && parse_quoted_string(&p, path, capacity, &length) &&
                strlen(path) == length && require_line_end(p, result) &&
                nvm_add_match_coverage(state->mod, state->current_function, line, column,
                                      coverage, coordinates, path);
            free(path);
            if (!valid) return par_error(result, "I require an unambiguous match coverage record with a quoted source path.");
            return 
# 1020 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1020 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "function_effects") == 0) {
            uint16_t effects;
            if (!state->in_function || !parse_uint16(&p, &effects) ||
                effects > 63 || !require_line_end(p, result))
                return par_error(result, "I require function_effects a mask from 0 through 63 inside a function.");
            if (!nvm_add_function_effects(state->mod, state->current_function, effects))
                return par_error(result, "I cannot retain an ambiguous function effect summary.");
            return 
# 1030 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1030 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "borrow_place") == 0) {
            NvmBorrowPlace fact={0};uint32_t mode,coordinates;
            if(state->in_function || !parse_uint32(&p,&fact.function) ||
               !parse_uint32(&p,&fact.call_line) || !parse_uint32(&p,&fact.call_column) ||
               !parse_uint32(&p,&fact.argument_line) || !parse_uint32(&p,&fact.argument_column) ||
               !parse_uint32(&p,&fact.ordinal) || !parse_uint32(&p,&mode) || !parse_uint32(&p,&coordinates))
                return par_error(result,"I require an indexed checked borrow source event outside a function.");
            size_t capacity=strlen(p)+1;
            char *path=malloc(capacity),*root=malloc(capacity),*projection=malloc(capacity);
            fact.mode=mode;fact.coordinates=coordinates;fact.source_path=path;fact.root=root;fact.projection=projection;
            
# 1043 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1043 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid=path && root && projection &&
                parse_quoted_string(&p,path,capacity,&fact.source_path_length) &&
                parse_quoted_string(&p,root,capacity,&fact.root_length) &&
                parse_quoted_string(&p,projection,capacity,&fact.projection_length) &&
                require_line_end(p,result) && nvm_add_borrow_place(state->mod,&fact);
            free(path);free(root);free(projection);
            if(!valid)return par_error(result,"I require an unambiguous checked borrow source event with valid counted strings.");
            return 
# 1050 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1050 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "field_read") == 0) {
            NvmFieldRead fact={0};uint32_t category,coordinates;
            if(state->in_function || !parse_uint32(&p,&fact.function) ||
               !parse_uint32(&p,&fact.line) || !parse_uint32(&p,&fact.column) || !parse_uint32(&p,&category) || !parse_uint32(&p,&coordinates))
                return par_error(result,"I require an indexed checked field-read source event outside a function.");
            size_t capacity=strlen(p)+1;
            char *path=malloc(capacity),*root=malloc(capacity),*projection=malloc(capacity);
            fact.category=category;fact.coordinates=coordinates;fact.source_path=path;fact.root=root;fact.projection=projection;
            
# 1061 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1061 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid=path && root && projection &&
                parse_quoted_string(&p,path,capacity,&fact.source_path_length) &&
                parse_quoted_string(&p,root,capacity,&fact.root_length) &&
                parse_quoted_string(&p,projection,capacity,&fact.projection_length) &&
                require_line_end(p,result) && nvm_add_field_read(state->mod,&fact);
            free(path);free(root);free(projection);
            if(!valid)return par_error(result,"I require an unambiguous checked field-read source event with valid counted strings.");
            return 
# 1068 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1068 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }
        if (strcmp(directive, "field_write") == 0) {
            NvmFieldWrite fact={0};uint32_t mode,coordinates;
            if(state->in_function || !parse_uint32(&p,&fact.function) ||
               !parse_uint32(&p,&fact.line) || !parse_uint32(&p,&fact.column) || !parse_uint32(&p,&mode) || !parse_uint32(&p,&coordinates))
                return par_error(result,"I require an indexed checked field-write source event outside a function.");
            size_t capacity=strlen(p)+1;
            char *path=malloc(capacity),*root=malloc(capacity),*projection=malloc(capacity);
            fact.mode=mode;fact.coordinates=coordinates;fact.source_path=path;fact.root=root;fact.projection=projection;
            
# 1078 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1078 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid=path && root && projection &&
                parse_quoted_string(&p,path,capacity,&fact.source_path_length) &&
                parse_quoted_string(&p,root,capacity,&fact.root_length) &&
                parse_quoted_string(&p,projection,capacity,&fact.projection_length) &&
                require_line_end(p,result) && nvm_add_field_write(state->mod,&fact);
            free(path);free(root);free(projection);
            if(!valid)return par_error(result,"I require an unambiguous checked field-write source event with valid counted strings.");
            return 
# 1085 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1085 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "affine_use") == 0) {
            uint32_t function, line, column, use, coordinates;
            if (state->in_function || !parse_uint32(&p, &function) || !parse_uint32(&p, &line) ||
                !parse_uint32(&p, &column) || !parse_uint32(&p, &use) || !parse_uint32(&p, &coordinates))
                return par_error(result, "I require an indexed affine source use outside a function body.");
            size_t capacity = strlen(p) + 1;
            char *path = malloc(capacity), *binding = malloc(capacity);
            uint32_t path_length = 0, binding_length = 0;
            
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                valid = path && binding && parse_quoted_string(&p, path, capacity, &path_length) &&
                strlen(path) == path_length && parse_quoted_string(&p, binding, capacity, &binding_length) &&
                strlen(binding) == binding_length && require_line_end(p, result) &&
                nvm_add_affine_use(state->mod, function, line, column, use, coordinates, path, binding);
            free(path); free(binding);
            if (!valid) return par_error(result, "I require an unambiguous affine use with quoted source path and binding.");
            return 
# 1102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "affine_completion") == 0) {
            uint32_t function;
            uint16_t affine;
            if (state->in_function || !parse_uint32(&p, &function) ||
                !parse_uint16(&p, &affine) || affine > 1 || !require_line_end(p, result) ||
                !nvm_add_function_affine(state->mod, function, affine))
                return par_error(result, "I require an unambiguous affine completion for an existing function outside its body.");
            return 
# 1112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1112 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "function_affine") == 0) {
            uint16_t affine;
            if (!state->in_function || !parse_uint16(&p, &affine) ||
                affine > 1 || !require_line_end(p, result))
                return par_error(result, "I require function_affine 0 or 1 inside a function.");
            if (!nvm_add_function_affine(state->mod, state->current_function, affine))
                return par_error(result, "I cannot retain an ambiguous function affine completion fact.");
            return 
# 1122 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1122 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive,"local_begin")==0 || strcmp(directive,"local_end")==0 || strcmp(directive,"upvalue_name")==0) {
            
# 1126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                upvalue=strcmp(directive,"upvalue_name")==0;
            uint16_t slot;
            if(!state->in_function || !parse_uint16(&p,&slot) ||
               slot>=(upvalue?state->mod->functions[state->current_function].upvalue_count:
                              state->mod->functions[state->current_function].local_count))
                return par_error(result,"I require a declared local slot inside a function.");
            LocalMarker *active=
# 1132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                               ((void *)0)
# 1132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                   ;
            for(LocalMarker *m=state->local_markers;m;m=m->next)
                if(m->upvalue==upvalue && m->slot==slot && !m->closed)active=m;
            if(strcmp(directive,"local_end")==0) {
                if(!active || !require_line_end(p,result))
                    return par_error(result,"I require an open local-name marker before its end.");
                active->end=state->fn_code_size;active->closed=
# 1138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                              1
# 1138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                  ;return 
# 1138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                          1
# 1138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                              ;
            }
            if(active)return par_error(result,"I require disjoint local-name markers for one slot.");
            size_t available=strlen(p)+1;uint32_t length=0;
            char *name=malloc(available);
            if(!name)return par_error(result,"I cannot allocate a local-name marker.");
            if(!parse_quoted_string(&p,name,available,&length) || !length || !require_line_end(p,result)) {
                free(name);return par_error(result,"I require one nonempty quoted local name.");
            }
            LocalMarker *m=calloc(1,sizeof *m);
            if(!m){free(name);return par_error(result,"I cannot allocate a local-name marker.");}
            m->upvalue=upvalue;m->slot=slot;m->begin=upvalue?0:state->fn_code_size;m->name=name;m->length=length;
            if(state->local_tail)state->local_tail->next=m;else state->local_markers=m;
            state->local_tail=m;return 
# 1151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                      1
# 1151 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          ;
        }

        if (strcmp(directive, "debug") == 0) {
            uint32_t offset, line, column;
            if (state->in_function || !parse_uint32(&p, &offset) ||
                !parse_uint32(&p, &line) || !parse_uint32(&p, &column) ||
                !require_line_end(p, result)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "I require three unsigned 32-bit DEBUG operands outside functions");
                return 
# 1162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (!nvm_add_debug_entry(state->mod, offset, line, column)) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof(result->message),
                         "I cannot retain this DEBUG entry");
                return 
# 1168 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1168 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            state->mod->header.flags |= (1 << 2);
            return 
# 1171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "metadata") == 0) {
            uint32_t key, value;
            if (state->in_function || !parse_uint32(&p, &key) ||
                !parse_uint32(&p, &value) || key >= state->mod->string_count ||
                value >= state->mod->string_count || !require_line_end(p, result)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof result->message,
                         "I require two declared string indices outside functions for metadata");
                return 
# 1182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (!nvm_add_metadata(state->mod, key, value)) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof result->message,
                         "I cannot retain this advisory metadata entry");
                return 
# 1188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            return 
# 1190 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1190 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }


        if (strcmp(directive, "par_begin") == 0 || strcmp(directive, "par_node") == 0 ||
            strcmp(directive, "par_end") == 0)
            return par_directive(state, directive, p, result);
        if (strcmp(directive, "flow_begin") == 0 || strcmp(directive, "flow_node") == 0 ||
            strcmp(directive, "flow_end") == 0)
            return flow_directive(state, directive, p, result);

        if (strcmp(directive, "passive") == 0 || strcmp(directive, "layouts") == 0 ||
            strcmp(directive, "ownership") == 0) {
            
# 1203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                layouts = strcmp(directive, "layouts") == 0;
            
# 1204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1204 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                ownership = strcmp(directive, "ownership") == 0;
            uint8_t **payload = ownership ? &state->mod->ownership_data :
                layouts ? &state->mod->layout_data : &state->mod->passive_data;
            uint32_t *payload_size = ownership ? &state->mod->ownership_size :
                layouts ? &state->mod->layout_size : &state->mod->passive_size;
            if (!layouts && !ownership && state->passive_structured)
                return par_error(result, "I cannot mix raw passive chunks and producer markers.");
            char hex[4096];
            uint32_t length;
            if (state->in_function || !parse_quoted_string(&p, hex, sizeof(hex), &length) ||
                !length || length % 2 || !require_line_end(p, result)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "I expect a nonempty quoted hexadecimal metadata chunk outside functions");
                return 
# 1218 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1218 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            for (uint32_t i = 0; i < length; ++i) {
                if (!
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                    ((*__ctype_b_loc ())[(int) ((
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                    (unsigned char)hex[i]
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                    ))] & (unsigned short int) _ISxdigit)
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                   ) {
                    result->error = ASM_ERR_SYNTAX;
                    snprintf(result->message, sizeof(result->message), "I require hexadecimal metadata bytes");
                    return 
# 1224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1224 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }
            }
            uint32_t bytes = length / 2;
            if (bytes > 
# 1228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                       (4294967295U) 
# 1228 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                  - *payload_size) {
                result->error = ASM_ERR_MEMORY;
                return 
# 1230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1230 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            uint8_t *data = realloc(*payload, *payload_size + bytes);
            if (!data) { result->error = ASM_ERR_MEMORY; return 
# 1233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                               0
# 1233 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                    ; }
            for (uint32_t i = 0; i < bytes; ++i) {
                unsigned char a = (unsigned char)tolower((unsigned char)hex[i * 2]);
                unsigned char b = (unsigned char)tolower((unsigned char)hex[i * 2 + 1]);
                unsigned high = a <= '9' ? a - '0' : a - 'a' + 10;
                unsigned low = b <= '9' ? b - '0' : b - 'a' + 10;
                data[*payload_size + i] = (uint8_t)(high * 16 + low);
            }
            *payload = data;
            *payload_size += bytes;
            return 
# 1243 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1243 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "string") == 0) {
            char name[128];
            uint32_t len;
            const char *before_name = p;
            
# 1250 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1250 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                named = parse_identifier(&p, name, sizeof(name));
            if (!named) p = before_name;
            size_t source_length = strlen(p);
            if (source_length >= 
# 1253 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                (4294967295U)
# 1253 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                          ) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message),
                         "I require a string literal within the u32 length limit");
                return 
# 1257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1257 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            char *buf = malloc(source_length + 1);
            if (!buf) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof(result->message),
                         "I cannot allocate this string literal");
                return 
# 1264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1264 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (!parse_quoted_string(&p, buf, source_length + 1, &len)) {
                free(buf);
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected quoted string after .string");
                return 
# 1271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            uint32_t index = nvm_add_string(state->mod, buf, len);
            free(buf);
            if (index == 
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                        (4294967295U)
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                  ) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof(result->message),
                         "I cannot retain this string literal");
                return 
# 1279 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1279 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (named && !add_symbol(state, SYMBOL_CONSTANT, name, index, result)) {
                if (result->error != ASM_ERR_DUPLICATE_SYMBOL) return 
# 1282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                     0
# 1282 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                          ;
                snprintf(result->message, sizeof(result->message),
                         "Duplicate constant symbol: %.200s", name);
                return 
# 1285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1285 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            return require_line_end(p, result);
        }

        if (strcmp(directive, "import") == 0)
            return assemble_import(state, p, result);

        if (strcmp(directive, "callback") == 0) {
            NvmCallbackContract c = {0};
            uint32_t parameter, abi, length;
            char adapter[4096], execution[32];
            if (!parse_uint32(&p, &c.import_idx) || !parse_uint32(&p, &parameter) ||
                parameter > 
# 1298 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                           (65535) 
# 1298 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                      ||
                !parse_quoted_string(&p, adapter, sizeof(adapter), &length) ||
                !parse_uint32(&p, &abi) || abi != 1u ||
                !parse_identifier(&p, execution, sizeof(execution)) ||
                (strcmp(execution, "owner") && strcmp(execution, "worker")) ||
                !parse_result_tag(&p, &c.return_tag)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "I expect .callback import parameter \"adapter\" 1 owner|worker result [parameters]");
                return 
# 1307 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1307 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            c.parameter_idx = (uint16_t)parameter;
            c.abi_version = (uint8_t)abi;
            c.execution = strcmp(execution, "worker") == 0 ? NVM_FOREIGN_WORKER_THREAD : NVM_FOREIGN_OWNER_THREAD;
            while (!at_line_end(p)) {
                if (c.param_count >= 16 || !parse_result_tag(&p, &c.param_tags[c.param_count])) {
                    result->error = ASM_ERR_SYNTAX;
                    snprintf(result->message, sizeof(result->message), "I need at most 16 callback parameter tags");
                    return 
# 1316 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1316 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }
                c.param_count++;
            }
            c.adapter_name_idx = nvm_add_string(state->mod, adapter, length);
            if (c.adapter_name_idx == 
# 1321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                     (4294967295U) 
# 1321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                || !nvm_add_callback_contract(state->mod, &c)) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message), "I could not add this callback contract");
                return 
# 1324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1324 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            return 
# 1326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1326 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "parameters") == 0) {
            uint32_t index = 
# 1330 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                            (4294967295U)
# 1330 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                      ;
            const char *start = p;
            if (!parse_uint32(&p, &index)) {
                char name[128];
                p = start;
                if (parse_identifier(&p, name, sizeof(name))) {
                    int found = find_symbol(state, SYMBOL_FUNCTION, name);
                    if (found >= 0) index = state->symbols[found].value;
                }
            }
            if (index >= state->mod->function_count) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message), "I need an existing function name or index for .parameters");
                return 
# 1343 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1343 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            uint16_t arity = state->mod->functions[index].arity;
            uint8_t *tags = arity ? malloc(arity) : 
# 1346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                   ((void *)0)
# 1346 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                       ;
            
# 1347 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
           _Bool 
# 1347 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                ok = !arity || tags;
            for (uint16_t i = 0; ok && i < arity; i++) ok = parse_result_tag(&p, &tags[i]);
            ok = ok && at_line_end(p) && nvm_set_function_param_types(state->mod, index, tags, arity);
            free(tags);
            if (!ok) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message), "I need exact-arity tags for .parameters");
            }
            return ok;
        }

        if (strcmp(directive, "import_kind") == 0) {
            uint32_t index;
            char kind[32];
            if (!parse_uint32(&p, &index) || index >= state->mod->import_count ||
                !parse_identifier(&p, kind, sizeof(kind)) || !at_line_end(p) ||
                (strcmp(kind, "ffi") && strcmp(kind, "coprocess") && strcmp(kind, "artifact"))) {
                result->error = ASM_ERR_BAD_OPERAND;
                snprintf(result->message, sizeof(result->message), "I expect .import_kind index ffi|coprocess|artifact");
                return 
# 1366 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1366 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            state->mod->imports[index].kind = !strcmp(kind, "artifact") ? NVM_IMPORT_ARTIFACT :
                !strcmp(kind, "coprocess") ? NVM_IMPORT_COPROCESS : NVM_IMPORT_FFI;
            return 
# 1370 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1370 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }



        if (strcmp(directive, "module_ref") == 0) {
            char name[256];
            uint32_t len = 0;
            if (!parse_quoted_string(&p, name, sizeof(name), &len)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected: .module_ref \"name\"");
                return 
# 1382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            nvm_add_module_ref(state->mod, nvm_add_string(state->mod, name, len));
            return require_line_end(p, result);
        }




        if (strcmp(directive, "types") == 0) {
            uint32_t structs, enums, unions;
            if (!parse_uint32(&p, &structs) || !parse_uint32(&p, &enums) ||
                !parse_uint32(&p, &unions)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected: .types <structs> <enums> <unions>");
                return 
# 1398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            state->mod->struct_count = structs;
            state->mod->enum_count = enums;
            state->mod->union_count = unions;
            return require_line_end(p, result);
        }

        if (strcmp(directive, "symbol") == 0) {
            SymbolKind kind;
            char name[128];
            uint32_t value;
            if (!parse_symbol_kind(&p, &kind) ||
                !parse_identifier(&p, name, sizeof(name)) ||
                !parse_uint32(&p, &value) || !at_line_end(p)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected: .symbol function|import|field|type|constant name index");
                return 
# 1416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1416 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (!add_symbol(state, kind, name, value, result)) {
                if (result->error != ASM_ERR_DUPLICATE_SYMBOL) return 
# 1419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                     0
# 1419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                          ;
                snprintf(result->message, sizeof(result->message),
                         "Duplicate %s symbol: %.200s", symbol_kind_name(kind), name);
                return 
# 1422 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1422 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            return 
# 1424 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  1
# 1424 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        if (strcmp(directive, "function") == 0) {
            if (state->in_function) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Nested .function not allowed");
                return 
# 1432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1432 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }


            char name[256];
            if (!parse_identifier(&p, name, sizeof(name))) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected function name after .function");
                return 
# 1441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1441 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }

            uint32_t arity_val, locals_val, upvalues_val;
            uint8_t result_tag, result_count;
            if (!parse_uint32(&p, &arity_val) ||
                !parse_uint32(&p, &locals_val) ||
                !parse_uint32(&p, &upvalues_val) ||
                !parse_result_tag(&p, &result_tag) ||
                !parse_uint8(&p, &result_count) ||
                ((result_count == 0) != (result_tag == TAG_VOID))) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected: .function name arity locals upvalues result-tag result-count");
                return 
# 1455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1455 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }

            NvmFunctionEntry fn = {0};
            fn.name_idx = nvm_add_string(state->mod, name, (uint32_t)strlen(name));
            if (fn.name_idx == 
# 1460 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                              (4294967295U)
# 1460 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        ) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof(result->message),
                         "I cannot allocate the function name.");
                return 
# 1464 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1464 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            fn.arity = (uint16_t)arity_val;
            fn.local_count = (uint16_t)locals_val;
            fn.upvalue_count = (uint16_t)upvalues_val;
            fn.result_tag = result_tag;
            fn.result_count = result_count;

            state->current_function = nvm_add_function(state->mod, &fn);
            if (state->current_function == 
# 1473 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                          (4294967295U)
# 1473 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                    ) {
                result->error = ASM_ERR_MEMORY;
                snprintf(result->message, sizeof(result->message),
                         "I cannot allocate the function entry.");
                return 
# 1477 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1477 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            int symbol = find_symbol(state, SYMBOL_FUNCTION, name);
            if (symbol < 0 || state->symbols[symbol].value != state->current_function) {
                result->error = ASM_ERR_DUPLICATE_SYMBOL;
                snprintf(result->message, sizeof(result->message),
                         "Duplicate function symbol: %.200s", name);
                return 
# 1484 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1484 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            state->in_function = 
# 1486 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                1
# 1486 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                    ;
            state->fn_code_size = 0;
            return require_line_end(p, result);
        }

        if (strcmp(directive, "end") == 0) {
            if (state->par_active)
                return par_error(result, "I require the passive block's end marker before ending the function.");
            if (!state->in_function) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         ".end without matching .function");
                return 
# 1498 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1498 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }


            for (uint32_t i = 0; i < state->patch_count; i++) {
                Patch *patch = &state->patches[i];
                if (patch->function != state->current_function) continue;

                int lbl = find_label(state, patch->label, state->current_function);
                if (lbl < 0 || !state->labels[lbl].defined) {
                    result->error = ASM_ERR_UNDEFINED_LABEL;
                    snprintf(result->message, sizeof(result->message),
                             "Undefined label: %s", patch->label);
                    return 
# 1511 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1511 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }


                int32_t rel = (int32_t)state->labels[lbl].offset - (int32_t)patch->instr_start;
                uint32_t urel = (uint32_t)rel;
                state->fn_code[patch->code_offset + 0] = (uint8_t)(urel & 0xFF);
                state->fn_code[patch->code_offset + 1] = (uint8_t)((urel >> 8) & 0xFF);
                state->fn_code[patch->code_offset + 2] = (uint8_t)((urel >> 16) & 0xFF);
                state->fn_code[patch->code_offset + 3] = (uint8_t)((urel >> 24) & 0xFF);
            }


            uint32_t code_off = nvm_append_code(state->mod, state->fn_code, state->fn_code_size);
            state->mod->functions[state->current_function].code_offset = code_off;
            state->mod->functions[state->current_function].code_length = state->fn_code_size;

            while(state->local_markers) {
                LocalMarker *m=state->local_markers;
                NvmLocalBinding binding={.function=state->current_function,.slot=m->slot,
                    .begin=m->begin,.end=m->closed?m->end:state->fn_code_size,
                    .name=(const uint8_t *)m->name,.name_size=m->length};
                if(!(m->upvalue?nvm_add_upvalue_binding(state->mod,&binding):nvm_add_local_binding(state->mod,&binding)))
                    return par_error(result,"I cannot retain this lexical local name.");
                state->local_markers=m->next;free(m->name);free(m);
            }
            state->local_tail=
# 1537 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                             ((void *)0)
# 1537 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                 ;
            state->in_function = 
# 1538 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                0
# 1538 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                     ;


            uint32_t new_count = 0;
            for (uint32_t i = 0; i < state->patch_count; i++) {
                if (state->patches[i].function != state->current_function) {
                    state->patches[new_count++] = state->patches[i];
                }
            }
            state->patch_count = new_count;

            return require_line_end(p, result);
        }

        if (strcmp(directive, "entry") == 0) {
            uint32_t v;
            const char *before_symbol = p;
            char name[128];
            skip_whitespace(&p);
            if (((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z') || *p == '_' || *p == '$') &&
                parse_identifier(&p, name, sizeof(name))) {
                int found = find_symbol(state, SYMBOL_FUNCTION, name);
                if (found < 0) {
                    result->error = ASM_ERR_UNDEFINED_SYMBOL;
                    snprintf(result->message, sizeof(result->message),
                             "Undefined function symbol: %s", name);
                    return 
# 1564 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1564 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }
                v = state->symbols[found].value;
            } else {
                p = before_symbol;
                if (!parse_uint32(&p, &v)) {
                    result->error = ASM_ERR_SYNTAX;
                    snprintf(result->message, sizeof(result->message),
                             "Expected function name or index after .entry");
                    return 
# 1573 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1573 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }
            }
            if (!at_line_end(p)) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Unexpected text after .entry operand");
                return 
# 1580 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1580 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            state->mod->header.entry_point = v;
            state->mod->header.flags |= (1 << 0);
            return require_line_end(p, result);
        }

        if (strcmp(directive, "flag") == 0) {
            char flag_name[64];
            if (!parse_identifier(&p, flag_name, sizeof(flag_name))) {
                result->error = ASM_ERR_SYNTAX;
                snprintf(result->message, sizeof(result->message),
                         "Expected flag name after .flag");
                return 
# 1593 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1593 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
            if (strcmp(flag_name, "has_main") == 0) {
                state->mod->header.flags |= (1 << 0);
            } else if (strcmp(flag_name, "needs_extern") == 0) {
                state->mod->header.flags |= (1 << 1);
            } else if (strcmp(flag_name, "debug_info") == 0) {
                state->mod->header.flags |= (1 << 2);
            }
            return require_line_end(p, result);
        }

        result->error = ASM_ERR_SYNTAX;
        snprintf(result->message, sizeof(result->message),
                 "Unknown directive: .%s", directive);
        return 
# 1608 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 1608 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }


    {
        const char *saved = p;
        char ident[128];
        if (parse_identifier(&p, ident, sizeof(ident))) {
            skip_whitespace(&p);
            if (*p == ':') {
                p++;
                if (!state->in_function) {
                    result->error = ASM_ERR_NO_FUNCTION;
                    snprintf(result->message, sizeof(result->message),
                             "Label outside .function/.end block");
                    return 
# 1623 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1623 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }
                if (!add_label(state, ident, state->fn_code_size, result)) {
                    if (result->error != ASM_ERR_DUPLICATE_LABEL) return 
# 1626 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                                                        0
# 1626 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                                             ;
                    snprintf(result->message, sizeof(result->message),
                             "Duplicate label: %s", ident);
                    return 
# 1629 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                          0
# 1629 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                               ;
                }

                skip_whitespace(&p);
                if (*p != '\0' && *p != ';' && *p != '#') {
                    char mnemonic[64];
                    if (!parse_identifier(&p, mnemonic, sizeof(mnemonic))) {
                        result->error = ASM_ERR_SYNTAX;
                        return 
# 1637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                              0
# 1637 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                   ;
                    }
                    return assemble_instruction(state, mnemonic, &p, result);
                }
                return 
# 1641 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      1
# 1641 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                          ;
            }

            p = saved;
        } else {
            p = saved;
        }
    }


    if (!state->in_function) {
        result->error = ASM_ERR_NO_FUNCTION;
        snprintf(result->message, sizeof(result->message),
                 "Instruction outside .function/.end block");
        return 
# 1655 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 1655 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }

    char mnemonic[64];
    if (!parse_identifier(&p, mnemonic, sizeof(mnemonic))) {
        result->error = ASM_ERR_SYNTAX;
        snprintf(result->message, sizeof(result->message),
                 "Expected instruction mnemonic");
        return 
# 1663 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              0
# 1663 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                   ;
    }

    return assemble_instruction(state, mnemonic, &p, result);
}





static 
# 1673 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
      _Bool 
# 1673 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
           collect_function_symbols(AsmState *state, const char *source, AsmResult *result) {
    const char *p = source;
    uint32_t line = 0;
    uint32_t function_index = 0;
    while (*p) {
        line++;
        const char *line_start = p;
        while (*p && *p != '\n') p++;
        size_t line_len = (size_t)(p - line_start);
        char *line_buf = malloc(line_len + 1);
        if (!line_buf) {
            result->error = ASM_ERR_MEMORY;
            result->line = line;
            snprintf(result->message, sizeof(result->message), "Out of memory");
            return 
# 1687 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  0
# 1687 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       ;
        }
        memcpy(line_buf, line_start, line_len);
        line_buf[line_len] = '\0';

        const char *cursor = line_buf;
        skip_whitespace(&cursor);
        if (strncmp(cursor, ".function", 9) == 0 &&
            (cursor[9] == ' ' || cursor[9] == '\t')) {
            cursor += 9;
            char name[128];
            if (parse_identifier(&cursor, name, sizeof(name)) &&
                !add_symbol(state, SYMBOL_FUNCTION, name, function_index++, result)) {
                result->line = line;
                if (result->error == ASM_ERR_DUPLICATE_SYMBOL)
                    snprintf(result->message, sizeof(result->message),
                             "Duplicate function symbol: %.200s", name);
                free(line_buf);
                return 
# 1705 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                      0
# 1705 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                           ;
            }
        }
        free(line_buf);
        if (*p == '\n') p++;
    }
    return 
# 1711 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
          1
# 1711 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
              ;
}

static NvmModule *asm_assemble_impl(const char *source, AsmResult *result,
                                    
# 1715 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                   _Bool 
# 1715 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                        verify) {
    memset(result, 0, sizeof(*result));

    AsmState state;
    asm_state_init(&state);
    state.mod = nvm_module_new();
    if (!state.mod || !state.fn_code) {
        result->error = ASM_ERR_MEMORY;
        snprintf(result->message, sizeof(result->message), "Out of memory");
        nvm_module_free(state.mod);
        asm_state_cleanup(&state);
        return 
# 1726 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1726 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }
    if (!collect_function_symbols(&state, source, result)) {
        nvm_module_free(state.mod);
        asm_state_cleanup(&state);
        return 
# 1731 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1731 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }


    const char *p = source;
    state.line = 0;

    while (*p) {
        state.line++;


        const char *line_start = p;
        while (*p && *p != '\n') p++;

        size_t line_len = (size_t)(p - line_start);
        char *line_buf = malloc(line_len + 1);
        if (!line_buf) {
            result->error = ASM_ERR_MEMORY;
            result->line = state.line;
            nvm_module_free(state.mod);
            asm_state_cleanup(&state);
            return 
# 1752 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  ((void *)0)
# 1752 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }
        memcpy(line_buf, line_start, line_len);
        line_buf[line_len] = '\0';


        strip_trailing_comment(line_buf);


        size_t len = strlen(line_buf);
        while (len > 0 && (line_buf[len - 1] == ' ' || line_buf[len - 1] == '\t' ||
                           line_buf[len - 1] == '\r')) {
            line_buf[--len] = '\0';
        }

        
# 1767 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
       _Bool 
# 1767 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
            line_ok = process_line(&state, line_buf, result);
        if (state.fn_memory_failed) {
            result->error = ASM_ERR_MEMORY;
            snprintf(result->message, sizeof(result->message),
                     "I cannot grow my function code buffer.");
            line_ok = 
# 1772 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                     0
# 1772 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                          ;
        }
        if (!line_ok) {
            result->line = state.line;
            free(line_buf);
            nvm_module_free(state.mod);
            asm_state_cleanup(&state);
            return 
# 1779 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  ((void *)0)
# 1779 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }

        free(line_buf);
        if (*p == '\n') p++;
    }

    if (state.in_function) {
        result->error = ASM_ERR_SYNTAX;
        result->line = state.line;
        snprintf(result->message, sizeof(result->message),
                 "Unterminated .function (missing .end)");
        nvm_module_free(state.mod);
        asm_state_cleanup(&state);
        return 
# 1793 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1793 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }

    NvmModule *mod = state.mod;
    asm_state_cleanup(&state);

    if (verify) {
        NvmVerifyResult verdict = nvm_verify(mod);
        if (!verdict.ok) {
            result->error = ASM_ERR_VERIFY;
            snprintf(result->message, sizeof(result->message),
                     "Assembled module failed verification: %.210s", verdict.error_msg);
            nvm_module_free(mod);
            return 
# 1806 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                  ((void *)0)
# 1806 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                      ;
        }
    }
    return mod;
}

NvmModule *asm_assemble(const char *source, AsmResult *result) {
    return asm_assemble_impl(source, result, 
# 1813 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            1
# 1813 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                );
}

NvmModule *asm_assemble_unverified(const char *source, AsmResult *result) {
    return asm_assemble_impl(source, result, 
# 1817 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
                                            0
# 1817 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                                                 );
}

NvmModule *asm_assemble_file(const char *path, AsmResult *result) {
    FILE *f = fopen(path, "r");
    if (!f) {
        result->error = ASM_ERR_IO;
        snprintf(result->message, sizeof(result->message),
                 "Cannot open file: %s", path);
        return 
# 1826 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1826 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }

    fseek(f, 0, 
# 1829 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
               2
# 1829 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       );
    long fsize = ftell(f);
    fseek(f, 0, 
# 1831 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
               0
# 1831 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                       );

    if (fsize < 0 || fsize > 10 * 1024 * 1024) {
        result->error = ASM_ERR_IO;
        snprintf(result->message, sizeof(result->message),
                 "File too large or unreadable: %s", path);
        fclose(f);
        return 
# 1838 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1838 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }

    char *source = malloc((size_t)fsize + 1);
    if (!source) {
        result->error = ASM_ERR_MEMORY;
        fclose(f);
        return 
# 1845 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c" 3 4
              ((void *)0)
# 1845 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/nanoisa/../../src/nanoisa/assembler.c"
                  ;
    }

    size_t nread = fread(source, 1, (size_t)fsize, f);
    fclose(f);
    source[nread] = '\0';

    NvmModule *mod = asm_assemble(source, result);
    free(source);
    return mod;
}
