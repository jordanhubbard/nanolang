# 0 "/tmp/nano-host-closure-prefix-hl5iss8z/client/provider/api.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/tmp/nano-host-closure-prefix-hl5iss8z/client/provider/api.c"
const char *path_basename(const char *s) { (void)s; return "external-provider-ok"; }
