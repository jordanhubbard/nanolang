const char *path_basename(const char *s) { (void)s; return "external-provider-ok"; }
