import copy
import importlib.util
import re
import unittest
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "gen_nanoisa_schema", ROOT / "scripts/gen_nanoisa_schema.py"
)
generator = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(generator)

# Opcodes the verifier checks with a dedicated `case`, beyond what decoding
# alone establishes. Every other opcode in the schema is decode-backed and
# falls to the `default:` arm; the test below asserts that partition is exact,
# so adding a verifier rule without listing it here is a deliberate failure.
SPECIALIZED_VERIFIER_OPCODES = {
    "OP_BORROW_PATH_SHARED", "OP_BORROW_PATH_EXCLUSIVE", "OP_REBORROW_SHARED", "OP_REBORROW_EXCLUSIVE",
    "OP_REGION_BEGIN", "OP_REGION_END",
    "OP_BORROW_LOCAL_SHARED", "OP_BORROW_LOCAL_EXCLUSIVE", "OP_REF_GET", "OP_REF_SET",
    "OP_OWN_MOVE_LOCAL", "OP_OWN_STORE_LOCAL", "OP_OWN_PACK", "OP_OWN_UNPACK_LOCAL",
    "OP_HANDLER_PUSH", "OP_PERFORM",
    "OP_AGG_PACK",
    "OP_ARR_LITERAL",
    "OP_ARR_NEW",
    "OP_CALL",
    "OP_CALL_EXTERN",
    "OP_CALL_MODULE",
    "OP_CLOSURE_NEW",
    "OP_ENUM_VAL",
    "OP_FUNCREF",
    "OP_HM_NEW",
    "OP_JMP",
    "OP_JMP_FALSE",
    "OP_JMP_TRUE",
    "OP_LOAD_GLOBAL",
    "OP_LOAD_LOCAL",
    "OP_LOAD_UPVALUE",
    "OP_MATCH_TAG",
    "OP_PUSH_STR",
    "OP_STORE_GLOBAL",
    "OP_STORE_LOCAL",
    "OP_STORE_UPVALUE",
    "OP_STRUCT_LITERAL",
    "OP_STRUCT_NEW",
    "OP_TAIL_CALL",
    "OP_TYPE_CHECK",
    "OP_UNION_CONSTRUCT",
}


class NanoisaSchemaTests(unittest.TestCase):
    def setUp(self):
        self.schema = yaml.safe_load((ROOT / "spec/nanoisa.yaml").read_text())

    def families(self):
        return [
            instruction
            for family in self.schema["instruction_families"].values()
            for instruction in family
        ]

    def legacy_opcodes(self):
        return {
            f"OP_{entry['name']}": generator._as_int(entry["code"])
            for entry in self.schema["legacy_opcodes"]
        }

    @staticmethod
    def switch_body(source, marker):
        start = source.index(marker)
        brace = source.index("{", start)
        depth = 0
        for index in range(brace, len(source)):
            if source[index] == "{":
                depth += 1
            elif source[index] == "}":
                depth -= 1
                if depth == 0:
                    return source[brace + 1:index]
        raise AssertionError(f"unterminated switch after {marker}")

    @staticmethod
    def dispatch_body(source):
        """The opcode handlers, however they are dispatched to.

        VM_DISPATCH_BEGIN expands to a switch or to a computed goto depending
        on the compiler, so the region is delimited by the macros rather than
        by a brace-matched switch statement.
        """
        start = source.index("VM_DISPATCH_BEGIN(instr->opcode)")
        end = source.index("VM_DISPATCH_END()", start)
        return source[start:end]

    def test_codes_and_names_are_unique(self):
        entries = self.schema["legacy_opcodes"]
        self.assertEqual(len({entry["code"] for entry in entries}), len(entries))
        self.assertEqual(len({entry["name"] for entry in entries}), len(entries))

    def test_generated_header_is_current(self):
        expected = generator.generate(self.schema)
        actual = (ROOT / "src/nanoisa/generated_schema.h").read_text()
        self.assertEqual(actual, expected)

    def test_every_schema_opcode_matches_enum_and_vm_dispatch(self):
        expected = self.legacy_opcodes()
        isa_header = (ROOT / "src/nanoisa/isa.h").read_text()
        enum_body = isa_header[
            isa_header.index("typedef enum {"):isa_header.index("} NanoOpcode;")
        ]
        enum_entries = {
            name: int(value, 0)
            for name, value in re.findall(
                r"\b(OP_[A-Z0-9_]+)\s*=\s*(0x[0-9A-Fa-f]+|[0-9]+)",
                enum_body,
            )
            if name != "OP_EXTENSION_PREFIX"
        }
        self.assertEqual(enum_entries, expected)

        # The dispatch handlers are written once and reached either through a
        # switch or through a computed-goto table, so the opcode labels are
        # VM_CASE(...) rather than `case ...:`. This test is the guarantee that
        # every executable ISA opcode has a handler, so I read whichever
        # form the source uses rather than assume the switch.
        vm_source = (ROOT / "src/nanovm/vm.c").read_text()
        dispatch = self.dispatch_body(vm_source)
        vm_opcodes = set(re.findall(r"\bVM_CASE\((OP_[A-Z0-9_]+)\)", dispatch))
        vm_opcodes |= set(re.findall(r"\bcase\s+(OP_[A-Z0-9_]+)\s*:", dispatch))
        # I recognize these exact bytes for transport and private analysis,
        # while public execution refuses them before reaching dispatch.
        non_executing = {
            "OP_FILE_SERVICE": 0x91, "OP_FILE_RESULT_BRANCH": 0x92,
            "OP_FILE_RESULT_TAKE": 0x93, "OP_FILE_DROP_LOCAL": 0x94,
            "OP_FILE_DROP_STACK": 0x95, "OP_FILE_END_BORROW": 0x96,
            "OP_FILE_CALL_REFS": 0x97, "OP_FILE_CALL_INDIRECT_REFS": 0x98,
        }
        self.assertEqual({name: expected[name] for name in non_executing},
                         non_executing)
        self.assertTrue(vm_opcodes.isdisjoint(non_executing))
        self.assertEqual(vm_opcodes, set(expected) - set(non_executing))

    def test_computed_goto_table_matches_the_handlers(self):
        """Every handler must be reachable through the computed-goto table.

        The handlers are labelled with VM_CASE and the table is a separate list
        of assignments, so the two can drift. An opcode with a handler but no
        table entry would dispatch to the default and be reported as unknown --
        not silent corruption, but a working instruction that stops working,
        and only in the threaded build. Comparing the two lists in the source
        is the only place that drift is visible, since the table is a
        function-local static the tests cannot read at run time.
        """
        vm_source = (ROOT / "src/nanovm/vm.c").read_text()
        handlers = set(re.findall(r"\bVM_CASE\((OP_[A-Z0-9_]+)\)", vm_source))
        table = set(re.findall(
            r"vm_labels\[(OP_[A-Z0-9_]+)\]\s*=\s*&&L_(?:OP_[A-Z0-9_]+);", vm_source))
        self.assertEqual(handlers, table)

        # And each entry must point at its own label rather than another's.
        for name, label in re.findall(
                r"vm_labels\[(OP_[A-Z0-9_]+)\]\s*=\s*&&L_(OP_[A-Z0-9_]+);", vm_source):
            self.assertEqual(name, label)

    def test_every_schema_opcode_has_a_verifier_route(self):
        expected = set(self.legacy_opcodes())
        verifier = (ROOT / "src/nanoisa/verifier.c").read_text()
        rules = self.switch_body(verifier, "switch (instr.opcode)")
        explicit = set(re.findall(r"\bcase\s+(OP_[A-Z0-9_]+)\s*:", rules))
        self.assertEqual(explicit, SPECIALIZED_VERIFIER_OPCODES)
        decode_backed = expected - SPECIALIZED_VERIFIER_OPCODES
        self.assertEqual(explicit | decode_backed, expected)
        # The default arm is not a silent accept-all. Opcodes that reach it are
        # documented as safe-once-decoded, but it still rejects anything outside
        # the primary opcode plane, so an unknown byte cannot be waved through
        # as "some family we do not check".
        self.assertIn("NANOISA_PRIMARY_OPCODE_LIMIT", rules)
        self.assertRegex(rules, r"default:")

    def test_v2_families_declare_stack_and_ownership(self):
        for instruction in self.families():
            self.assertIn("pops", instruction)
            self.assertIn("pushes", instruction)
            self.assertIn("ownership", instruction)

    def test_every_instruction_has_a_comprehensible_meaning(self):
        for instruction in self.families():
            meaning = instruction.get("meaning")
            self.assertIsInstance(meaning, str, instruction["name"])
            self.assertTrue(meaning.strip(), instruction["name"])

    def test_meanings_are_unique(self):
        meanings = [instruction["meaning"] for instruction in self.families()]
        self.assertEqual(len(set(meanings)), len(meanings))

    def test_operands_reference_declared_kinds(self):
        declared = {kind["name"] for kind in self.schema["operand_kinds"]}
        for instruction in self.families():
            for operand in instruction.get("operands", []):
                self.assertIn(operand, declared, instruction["name"])

    def test_get_set_pairs_are_symmetric(self):
        by_name = {inst["name"]: inst for inst in self.families()}
        for base in ("local", "global", "upvalue"):
            getter = by_name[f"{base}.get"]
            setter = by_name[f"{base}.set"]
            self.assertEqual(getter["operands"], setter["operands"], base)

    def test_memory_operands_are_uniform(self):
        mem = [inst for inst in self.families() if inst["name"].startswith("mem.")]
        self.assertTrue(mem)
        for instruction in mem:
            self.assertEqual(instruction["operands"], ["offset", "align"])

    def test_validate_rejects_missing_meaning(self):
        broken = copy.deepcopy(self.schema)
        broken["instruction_families"]["stack"][0].pop("meaning")
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_validate_rejects_duplicate_meaning(self):
        broken = copy.deepcopy(self.schema)
        stack = broken["instruction_families"]["stack"]
        stack[1]["meaning"] = stack[0]["meaning"]
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_validate_rejects_undeclared_operand(self):
        broken = copy.deepcopy(self.schema)
        broken["instruction_families"]["constants"][0]["operands"] = ["sleb"]
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_c_string_escapes_dangerous_characters(self):
        self.assertEqual(generator.c_string('a"b'), '"a\\"b"')
        self.assertEqual(generator.c_string("a\\b"), '"a\\\\b"')
        self.assertEqual(generator.c_string("a\nb"), '"a\\nb"')
        self.assertEqual(generator.c_string("café"), '"caf\\xc3\\xa9"')

    def test_fixed_legacy_stack_effects_are_paired(self):
        for instruction in self.schema["legacy_opcodes"]:
            self.assertEqual("pops" in instruction, "pushes" in instruction)
        add = next(op for op in self.schema["legacy_opcodes"] if op["name"] == "ADD")
        self.assertEqual((add["pops"], add["pushes"]), (2, 1))

    def _all_family_instructions(self):
        by_name = {}
        for family in self.schema["instruction_families"].values():
            for instruction in family:
                by_name[instruction["name"]] = instruction
        return by_name

    def test_compact_operand_kinds_alias_canonical_encodings(self):
        kinds = list(self.schema["operand_kinds"])
        canonical_encodings = {
            kind["encoding"] for kind in kinds if "canonical" not in kind
        }
        compact_kinds = [k for k in kinds if "canonical" in k]
        self.assertTrue(compact_kinds, "expected compact operand kinds")
        for kind in compact_kinds:
            # Each compact operand decodes to a canonical variable-length
            # encoding already used by a non-compact operand kind.
            self.assertIn(kind["canonical"], canonical_encodings)
            self.assertIn("range", kind)
            low, high = kind["range"]
            self.assertLessEqual(low, high)

    def test_compact_forms_alias_canonical_instructions(self):
        instructions = self._all_family_instructions()
        compact_family = self.schema["instruction_families"].get("compact", [])
        self.assertTrue(compact_family, "expected a compact instruction family")
        for compact in compact_family:
            self.assertIn(
                "canonical",
                compact,
                f"{compact['name']} must name its canonical instruction",
            )
            canonical = instructions.get(compact["canonical"])
            self.assertIsNotNone(
                canonical,
                f"{compact['name']} aliases unknown {compact['canonical']}",
            )
            # A compact form is an encoding-only variant: identical stack effect
            # and ownership keep assembly regular.
            self.assertEqual(compact["pops"], canonical["pops"])
            self.assertEqual(compact["pushes"], canonical["pushes"])
            self.assertEqual(compact["ownership"], canonical["ownership"])
            self.assertNotIn(
                "canonical",
                canonical,
                "a compact form must alias a canonical (non-compact) instruction",
            )

    def test_compact_forms_use_compact_operands(self):
        compact_kinds = {
            kind["name"]
            for kind in self.schema["operand_kinds"]
            if "canonical" in kind
        }
        for compact in self.schema["instruction_families"].get("compact", []):
            self.assertTrue(
                any(op in compact_kinds for op in compact.get("operands", [])),
                f"{compact['name']} must carry a compact operand",
            )

    def test_extension_prefix_is_not_a_primary_opcode(self):
        encoding = self.schema["encoding"]
        prefix = generator._as_int(encoding["extension_prefix"])
        limit = generator._as_int(encoding["primary_opcode_limit"])
        # The prefix is the exclusive upper bound of the primary plane: no
        # legacy opcode may use it, and it must equal the plane limit.
        self.assertEqual(prefix, limit)
        codes = {generator._as_int(entry["code"]) for entry in self.schema["legacy_opcodes"]}
        self.assertNotIn(prefix, codes)
        self.assertTrue(all(code < limit for code in codes))

    def test_extended_plane_is_defined_and_disjoint(self):
        self.assertIn("extended_opcodes", self.schema)
        extended = self.schema["extended_opcodes"] or []
        ext_codes = [generator._as_int(entry["code"]) for entry in extended]
        # Extended codes are a separate one-byte plane; they may reuse values
        # from the primary plane because the prefix disambiguates them.
        self.assertEqual(len(ext_codes), len(set(ext_codes)))
        for code in ext_codes:
            self.assertTrue(0 <= code <= 0xFF)

    def test_generated_header_exposes_encoding_constants(self):
        rendered = generator.generate(self.schema)
        self.assertIn("#define NANOISA_PRIMARY_OPCODE_LIMIT", rendered)
        self.assertIn("#define NANOISA_EXTENSION_PREFIX", rendered)
        self.assertIn("#define NANOISA_EXTENDED_OPCODE_COUNT", rendered)
        self.assertIn("nanoisa_extended_opcodes", rendered)

    def test_v2_families_exclude_string_and_collection_algorithms(self):
        """Trimming, case, splitting, replacement, formatting, parsing, and
        collection algorithms live in runtime libraries, not the portable ISA."""
        forbidden = (
            "trim", "lower", "upper", "split", "join", "replace",
            "starts_with", "ends_with", "index_of", "format", "parse",
            "to_int", "to_float",
        )
        for family_name, family in self.schema["instruction_families"].items():
            for instruction in family:
                name = instruction["name"].lower()
                for token in forbidden:
                    self.assertNotIn(
                        token,
                        name,
                        msg=(
                            f"v2 family '{family_name}' instruction "
                            f"'{instruction['name']}' looks like a runtime-library "
                            f"algorithm ('{token}') that must stay out of the ISA"
                        ),
                    )

    def test_runtime_library_algorithms_are_documented(self):
        algorithms = self.schema["runtime_library_algorithms"]
        self.assertTrue(algorithms)
        expected_categories = {
            "trimming",
            "case-conversion",
            "splitting",
            "replacement",
            "formatting",
            "parsing",
            "collection",
        }
        seen_categories = set()
        for entry in algorithms:
            self.assertIn("name", entry)
            self.assertIn("category", entry)
            self.assertIn("primitives", entry)
            self.assertTrue(entry["primitives"])
            seen_categories.add(entry["category"])
        self.assertLessEqual(expected_categories, seen_categories)

    def test_every_public_instruction_records_a_justification(self):
        """Roadmap 4.0 Phase 12: every public instruction records why it belongs
        in the ISA rather than a runtime library."""
        allowed = {
            "representation",
            "core-semantics",
            "execution-substrate",
            "control-flow",
            "host-boundary",
            "encoding",
        }
        self.assertEqual(allowed, generator.JUSTIFICATIONS)
        for instruction in self.families():
            justification = instruction.get("justification")
            self.assertIn(
                justification,
                allowed,
                msg=(
                    f"{instruction['name']} must record one justification for "
                    f"belonging in the ISA (got {justification!r})"
                ),
            )

    def test_encoding_justifications_alias_a_canonical_instruction(self):
        for instruction in self.families():
            if instruction.get("justification") == "encoding":
                self.assertIn(
                    "canonical",
                    instruction,
                    msg=(
                        f"{instruction['name']} is justified only as an encoding "
                        "and must name the canonical instruction it aliases"
                    ),
                )

    def test_compact_forms_are_encoding_justified(self):
        for compact in self.schema["instruction_families"].get("compact", []):
            self.assertEqual(
                compact.get("justification"),
                "encoding",
                msg=f"{compact['name']} is a compact alias and is encoding-only",
            )

    def test_only_encoding_forms_claim_the_encoding_justification(self):
        for instruction in self.families():
            if instruction.get("justification") == "encoding":
                self.assertIn("canonical", instruction, instruction["name"])
            else:
                self.assertNotIn("canonical", instruction, instruction["name"])

    def test_generated_header_records_justifications(self):
        rendered = generator.generate(self.schema)
        self.assertIn("core-semantics", rendered)
        self.assertIn("representation", rendered)
        self.assertIn("host-boundary", rendered)

    def test_validate_rejects_missing_justification(self):
        broken = copy.deepcopy(self.schema)
        broken["instruction_families"]["stack"][0].pop("justification")
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_validate_rejects_unknown_justification(self):
        broken = copy.deepcopy(self.schema)
        broken["instruction_families"]["stack"][0]["justification"] = "library-algorithm"
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_validate_rejects_encoding_without_canonical(self):
        broken = copy.deepcopy(self.schema)
        target = broken["instruction_families"]["stack"][0]
        target["justification"] = "encoding"
        target.pop("canonical", None)
        with self.assertRaises(ValueError):
            generator.validate(broken)

    def test_runtime_library_algorithms_are_not_v2_instructions(self):
        family_names = {
            instruction["name"]
            for family in self.schema["instruction_families"].values()
            for instruction in family
        }
        for entry in self.schema["runtime_library_algorithms"]:
            self.assertNotIn(entry["name"], family_names)


if __name__ == "__main__":
    unittest.main()
