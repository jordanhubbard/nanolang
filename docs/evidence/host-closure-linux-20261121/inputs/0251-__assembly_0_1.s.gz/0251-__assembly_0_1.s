	.arch armv8-a
	.file	"nsi_file_plan.c"
	.text
	.align	2
	.type	nl_service_catalog_text_equal, %function
nl_service_catalog_text_equal:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 0
	beq	.L2
	ldr	x0, [sp, 16]
	cmp	x0, 0
	bne	.L3
.L2:
	ldr	x1, [sp, 24]
	ldr	x0, [sp, 16]
	cmp	x1, x0
	cset	w0, eq
	and	w0, w0, 255
	b	.L4
.L3:
	ldr	x1, [sp, 16]
	ldr	x0, [sp, 24]
	bl	strcmp
	cmp	w0, 0
	cset	w0, eq
	and	w0, w0, 255
.L4:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	nl_service_catalog_text_equal, .-nl_service_catalog_text_equal
	.align	2
	.type	nl_service_catalog_document_equal, %function
nl_service_catalog_document_equal:
.LFB1:
	.cfi_startproc
	stp	x29, x30, [sp, -144]!
	.cfi_def_cfa_offset 144
	.cfi_offset 29, -144
	.cfi_offset 30, -136
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	w0, [x0]
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 64]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 48]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 80]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 64]
	cmp	x0, 1
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 80]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 48]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 40]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 72]
	cmp	x0, 0
	bne	.L8
.L7:
	mov	w0, 0
	b	.L9
.L8:
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L10
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 24]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L10
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 32]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L11
.L10:
	mov	w0, 0
	b	.L9
.L11:
	str	xzr, [sp, 40]
	b	.L12
.L15:
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 72]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x2, [x0]
	ldr	x0, [sp, 16]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L13
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 72]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L14
.L13:
	mov	w0, 0
	b	.L9
.L14:
	ldr	x0, [sp, 40]
	add	x0, x0, 1
	str	x0, [sp, 40]
.L12:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 48]
	ldr	x1, [sp, 40]
	cmp	x1, x0
	bcc	.L15
	str	xzr, [sp, 48]
	b	.L16
.L23:
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 24]
	ldr	x1, [sp, 48]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 112]
	ldr	x0, [sp, 16]
	ldr	x2, [x0, 56]
	ldr	x1, [sp, 48]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	add	x0, x2, x0
	str	x0, [sp, 120]
	ldr	x0, [sp, 112]
	ldr	x2, [x0]
	ldr	x0, [sp, 120]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	w0, [x0, 32]
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 56]
	cmp	x1, x0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x0, [x0, 16]
	cmp	x0, 0
	bne	.L18
.L17:
	mov	w0, 0
	b	.L9
.L18:
	str	xzr, [sp, 56]
	b	.L19
.L22:
	ldr	x0, [sp, 112]
	ldr	x2, [x0, 16]
	ldr	x1, [sp, 56]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 128]
	ldr	x0, [sp, 120]
	ldr	x2, [x0, 48]
	ldr	x1, [sp, 56]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 136]
	ldr	x0, [sp, 128]
	ldr	x2, [x0]
	ldr	x0, [sp, 136]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 136]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 136]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 24]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 24]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 28]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 28]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 32]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 32]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 36]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 36]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w0, [x0, 40]
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w0, [x0, 44]
	cmp	w0, 0
	beq	.L21
.L20:
	mov	w0, 0
	b	.L9
.L21:
	ldr	x0, [sp, 56]
	add	x0, x0, 1
	str	x0, [sp, 56]
.L19:
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 56]
	ldr	x1, [sp, 56]
	cmp	x1, x0
	bcc	.L22
	ldr	x0, [sp, 48]
	add	x0, x0, 1
	str	x0, [sp, 48]
.L16:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 64]
	ldr	x1, [sp, 48]
	cmp	x1, x0
	bcc	.L23
	str	xzr, [sp, 64]
	b	.L24
.L32:
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 64]
	lsl	x0, x0, 6
	add	x0, x1, x0
	str	x0, [sp, 80]
	ldr	x0, [sp, 16]
	ldr	x2, [x0, 72]
	ldr	x1, [sp, 64]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 88]
	ldr	x0, [sp, 80]
	ldr	x2, [x0]
	ldr	x0, [sp, 88]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	w1, [x0, 16]
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 16]
	cmp	w1, w0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x1, x0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 40]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 48]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 56]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x0, 0
	beq	.L26
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L25
.L26:
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x0, 0
	bne	.L27
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L27
.L25:
	mov	w0, 0
	b	.L9
.L27:
	str	xzr, [sp, 72]
	b	.L28
.L31:
	ldr	x0, [sp, 80]
	ldr	x2, [x0, 24]
	ldr	x1, [sp, 72]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 96]
	ldr	x0, [sp, 88]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 72]
	lsl	x0, x0, 5
	add	x0, x1, x0
	str	x0, [sp, 104]
	ldr	x0, [sp, 96]
	ldr	x2, [x0]
	ldr	x0, [sp, 104]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L29
	ldr	x0, [sp, 96]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L29
	ldr	x0, [sp, 96]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L30
.L29:
	mov	w0, 0
	b	.L9
.L30:
	ldr	x0, [sp, 72]
	add	x0, x0, 1
	str	x0, [sp, 72]
.L28:
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	ldr	x1, [sp, 72]
	cmp	x1, x0
	bcc	.L31
	ldr	x0, [sp, 64]
	add	x0, x0, 1
	str	x0, [sp, 64]
.L24:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 80]
	ldr	x1, [sp, 64]
	cmp	x1, x0
	bcc	.L32
	mov	w0, 1
.L9:
	ldp	x29, x30, [sp], 144
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE1:
	.size	nl_service_catalog_document_equal, .-nl_service_catalog_document_equal
	.section	.rodata
	.align	3
.LC0:
	.string	"nsi:nanolang/filesystem#FileError.status"
	.align	3
.LC1:
	.string	"status"
	.align	3
.LC2:
	.string	"nsi:core/int"
	.align	3
.LC3:
	.string	"nsi:nanolang/filesystem#FileError.host_errno"
	.align	3
.LC4:
	.string	"host_errno"
	.align	3
.LC5:
	.string	"nsi:nanolang/filesystem#FileError.cleanup_errno"
	.align	3
.LC6:
	.string	"cleanup_errno"
	.align	3
.LC7:
	.string	"nsi:nanolang/filesystem#FileError.bytes"
	.align	3
.LC8:
	.string	"bytes"
	.align	3
.LC9:
	.string	"nsi:nanolang/filesystem#FileError.eof"
	.align	3
.LC10:
	.string	"eof"
	.align	3
.LC11:
	.string	"nsi:core/bool"
	.align	3
.LC12:
	.string	"nsi:nanolang/filesystem#FileError.consumed"
	.align	3
.LC13:
	.string	"consumed"
	.align	3
.LC14:
	.string	"nsi:nanolang/filesystem#FileError.cleanup_failed"
	.align	3
.LC15:
	.string	"cleanup_failed"
	.section	.data.rel.ro.local,"aw"
	.align	3
	.type	error_fields, %object
	.size	error_fields, 224
error_fields:
	.xword	.LC0
	.xword	.LC1
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC3
	.xword	.LC4
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC5
	.xword	.LC6
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC7
	.xword	.LC8
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC9
	.xword	.LC10
	.xword	.LC11
	.word	0
	.zero	4
	.xword	.LC12
	.xword	.LC13
	.xword	.LC11
	.word	0
	.zero	4
	.xword	.LC14
	.xword	.LC15
	.xword	.LC11
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC16:
	.string	"nsi:nanolang/filesystem#ReadByte.value"
	.align	3
.LC17:
	.string	"value"
	.align	3
.LC18:
	.string	"nsi:nanolang/filesystem#ReadByte.eof"
	.section	.data.rel.ro.local
	.align	3
	.type	byte_fields, %object
	.size	byte_fields, 64
byte_fields:
	.xword	.LC16
	.xword	.LC17
	.xword	.LC2
	.word	1
	.zero	4
	.xword	.LC18
	.xword	.LC10
	.xword	.LC11
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC19:
	.string	"nsi:nanolang/filesystem#OpenResult.Ok"
	.align	3
.LC20:
	.string	"Ok"
	.align	3
.LC21:
	.string	"nsi:nanolang/filesystem#File"
	.align	3
.LC22:
	.string	"nsi:nanolang/filesystem#OpenResult.Error"
	.align	3
.LC23:
	.string	"Error"
	.align	3
.LC24:
	.string	"nsi:nanolang/filesystem#FileError"
	.section	.data.rel.ro.local
	.align	3
	.type	OpenResult_cases, %object
	.size	OpenResult_cases, 64
OpenResult_cases:
	.xword	.LC19
	.xword	.LC20
	.xword	.LC21
	.word	0
	.zero	4
	.xword	.LC22
	.xword	.LC23
	.xword	.LC24
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC25:
	.string	"nsi:nanolang/filesystem#WriteResult.Ok"
	.align	3
.LC26:
	.string	"nsi:nanolang/filesystem#WriteResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	WriteResult_cases, %object
	.size	WriteResult_cases, 64
WriteResult_cases:
	.xword	.LC25
	.xword	.LC20
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC26
	.xword	.LC23
	.xword	.LC24
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC27:
	.string	"nsi:nanolang/filesystem#PositionResult.Ok"
	.align	3
.LC28:
	.string	"nsi:nanolang/filesystem#PositionResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	PositionResult_cases, %object
	.size	PositionResult_cases, 64
PositionResult_cases:
	.xword	.LC27
	.xword	.LC20
	.xword	0
	.word	0
	.zero	4
	.xword	.LC28
	.xword	.LC23
	.xword	.LC24
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC29:
	.string	"nsi:nanolang/filesystem#ReadResult.Ok"
	.align	3
.LC30:
	.string	"nsi:nanolang/filesystem#ReadByte"
	.align	3
.LC31:
	.string	"nsi:nanolang/filesystem#ReadResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	ReadResult_cases, %object
	.size	ReadResult_cases, 64
ReadResult_cases:
	.xword	.LC29
	.xword	.LC20
	.xword	.LC30
	.word	0
	.zero	4
	.xword	.LC31
	.xword	.LC23
	.xword	.LC24
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC32:
	.string	"nsi:nanolang/filesystem#CloseResult.Ok"
	.align	3
.LC33:
	.string	"nsi:nanolang/filesystem#CloseResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	CloseResult_cases, %object
	.size	CloseResult_cases, 64
CloseResult_cases:
	.xword	.LC32
	.xword	.LC20
	.xword	0
	.word	0
	.zero	4
	.xword	.LC33
	.xword	.LC23
	.xword	.LC24
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC34:
	.string	"File"
	.align	3
.LC35:
	.string	"FileError"
	.align	3
.LC36:
	.string	"ReadByte"
	.align	3
.LC37:
	.string	"nsi:nanolang/filesystem#OpenResult"
	.align	3
.LC38:
	.string	"OpenResult"
	.align	3
.LC39:
	.string	"nsi:nanolang/filesystem#WriteResult"
	.align	3
.LC40:
	.string	"WriteResult"
	.align	3
.LC41:
	.string	"nsi:nanolang/filesystem#PositionResult"
	.align	3
.LC42:
	.string	"PositionResult"
	.align	3
.LC43:
	.string	"nsi:nanolang/filesystem#ReadResult"
	.align	3
.LC44:
	.string	"ReadResult"
	.align	3
.LC45:
	.string	"nsi:nanolang/filesystem#CloseResult"
	.align	3
.LC46:
	.string	"CloseResult"
	.section	.data.rel.ro.local
	.align	3
	.type	types, %object
	.size	types, 320
types:
	.xword	.LC21
	.xword	.LC34
	.word	6
	.zero	4
	.xword	0
	.xword	0
	.xword	.LC24
	.xword	.LC35
	.word	1
	.zero	4
	.xword	error_fields
	.xword	7
	.xword	.LC30
	.xword	.LC36
	.word	1
	.zero	4
	.xword	byte_fields
	.xword	2
	.xword	.LC37
	.xword	.LC38
	.word	2
	.zero	4
	.xword	OpenResult_cases
	.xword	2
	.xword	.LC39
	.xword	.LC40
	.word	2
	.zero	4
	.xword	WriteResult_cases
	.xword	2
	.xword	.LC41
	.xword	.LC42
	.word	2
	.zero	4
	.xword	PositionResult_cases
	.xword	2
	.xword	.LC43
	.xword	.LC44
	.word	2
	.zero	4
	.xword	ReadResult_cases
	.xword	2
	.xword	.LC45
	.xword	.LC46
	.word	2
	.zero	4
	.xword	CloseResult_cases
	.xword	2
	.section	.rodata
	.align	3
.LC47:
	.string	"nsi:nanolang/filesystem#temp.result"
	.align	3
.LC48:
	.string	"result"
	.section	.data.rel.ro.local
	.align	3
	.type	temp_params, %object
	.size	temp_params, 48
temp_params:
	.xword	.LC47
	.xword	.LC48
	.xword	.LC37
	.word	3
	.word	1
	.word	3
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC49:
	.string	"nsi:nanolang/filesystem#write_byte.file"
	.align	3
.LC50:
	.string	"file"
	.align	3
.LC51:
	.string	"nsi:nanolang/filesystem#write_byte.value"
	.align	3
.LC52:
	.string	"nsi:nanolang/filesystem#write_byte.result"
	.section	.data.rel.ro.local
	.align	3
	.type	write_params, %object
	.size	write_params, 144
write_params:
	.xword	.LC49
	.xword	.LC50
	.xword	.LC21
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC51
	.xword	.LC17
	.xword	.LC2
	.word	0
	.word	2
	.word	0
	.word	0
	.word	1
	.zero	4
	.xword	.LC52
	.xword	.LC48
	.xword	.LC39
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC53:
	.string	"nsi:nanolang/filesystem#rewind.file"
	.align	3
.LC54:
	.string	"nsi:nanolang/filesystem#rewind.result"
	.section	.data.rel.ro.local
	.align	3
	.type	rewind_params, %object
	.size	rewind_params, 96
rewind_params:
	.xword	.LC53
	.xword	.LC50
	.xword	.LC21
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC54
	.xword	.LC48
	.xword	.LC41
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC55:
	.string	"nsi:nanolang/filesystem#read_byte.file"
	.align	3
.LC56:
	.string	"nsi:nanolang/filesystem#read_byte.result"
	.section	.data.rel.ro.local
	.align	3
	.type	read_params, %object
	.size	read_params, 96
read_params:
	.xword	.LC55
	.xword	.LC50
	.xword	.LC21
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC56
	.xword	.LC48
	.xword	.LC43
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC57:
	.string	"nsi:nanolang/filesystem#close.file"
	.align	3
.LC58:
	.string	"nsi:nanolang/filesystem#close.result"
	.section	.data.rel.ro.local
	.align	3
	.type	close_params, %object
	.size	close_params, 96
close_params:
	.xword	.LC57
	.xword	.LC50
	.xword	.LC21
	.word	0
	.word	1
	.word	2
	.word	0
	.word	0
	.zero	4
	.xword	.LC58
	.xword	.LC48
	.xword	.LC45
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC59:
	.string	"nsi:nanolang/filesystem#temp"
	.align	3
.LC60:
	.string	"temp"
	.align	3
.LC61:
	.string	"nsi_nanolang_filesystem_temp"
	.align	3
.LC62:
	.string	"nsi.local-file.v1.temp"
	.align	3
.LC63:
	.string	"nsi:nanolang/filesystem#write_byte"
	.align	3
.LC64:
	.string	"write_byte"
	.align	3
.LC65:
	.string	"nsi_nanolang_filesystem_write_byte"
	.align	3
.LC66:
	.string	"nsi.local-file.v1.write_byte"
	.align	3
.LC67:
	.string	"nsi:nanolang/filesystem#rewind"
	.align	3
.LC68:
	.string	"rewind"
	.align	3
.LC69:
	.string	"nsi_nanolang_filesystem_rewind"
	.align	3
.LC70:
	.string	"nsi.local-file.v1.rewind"
	.align	3
.LC71:
	.string	"nsi:nanolang/filesystem#read_byte"
	.align	3
.LC72:
	.string	"read_byte"
	.align	3
.LC73:
	.string	"nsi_nanolang_filesystem_read_byte"
	.align	3
.LC74:
	.string	"nsi.local-file.v1.read_byte"
	.align	3
.LC75:
	.string	"nsi:nanolang/filesystem#close"
	.align	3
.LC76:
	.string	"close"
	.align	3
.LC77:
	.string	"nsi_nanolang_filesystem_close"
	.align	3
.LC78:
	.string	"nsi.local-file.v1.close"
	.section	.data.rel.ro.local
	.align	3
	.type	methods, %object
	.size	methods, 480
methods:
	.xword	.LC59
	.xword	.LC60
	.xword	.LC61
	.xword	.LC62
	.word	1
	.word	0
	.word	19
	.word	0
	.xword	temp_params
	.xword	1
	.word	0
	.zero	4
	.xword	.LC21
	.word	0
	.zero	4
	.xword	0
	.xword	.LC63
	.xword	.LC64
	.xword	.LC65
	.xword	.LC66
	.word	1
	.word	2
	.word	0
	.word	1
	.xword	write_params
	.xword	3
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC67
	.xword	.LC68
	.xword	.LC69
	.xword	.LC70
	.word	1
	.word	1
	.word	0
	.word	1
	.xword	rewind_params
	.xword	2
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC71
	.xword	.LC72
	.xword	.LC73
	.xword	.LC74
	.word	1
	.word	1
	.word	0
	.word	1
	.xword	read_params
	.xword	2
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC75
	.xword	.LC76
	.xword	.LC77
	.xword	.LC78
	.word	1
	.word	0
	.word	0
	.word	2
	.xword	close_params
	.xword	2
	.word	2
	.zero	4
	.xword	0
	.word	2
	.zero	4
	.xword	0
	.section	.rodata
	.align	3
.LC79:
	.string	"cap:nanolang/filesystem.temp"
	.section	.data.rel.ro.local
	.align	3
	.type	capabilities, %object
	.size	capabilities, 16
capabilities:
	.xword	.LC79
	.xword	.LC60
	.section	.rodata
	.align	3
.LC80:
	.string	"nsi:nanolang/filesystem"
	.align	3
.LC81:
	.string	"filesystem"
	.align	3
.LC82:
	.string	"nsi:nanolang/filesystem#io"
	.align	3
.LC83:
	.string	"io"
	.align	3
.LC84:
	.string	"1"
	.section	.data.rel.ro.local
	.align	3
	.type	catalog, %object
	.size	catalog, 88
catalog:
	.xword	.LC80
	.xword	.LC81
	.xword	.LC82
	.xword	.LC83
	.xword	.LC84
	.xword	capabilities
	.xword	1
	.xword	methods
	.xword	5
	.xword	types
	.xword	8
	.text
	.align	2
	.type	document_equal, %function
document_equal:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	adrp	x0, catalog
	add	x1, x0, :lo12:catalog
	ldr	x0, [sp, 24]
	bl	nl_service_catalog_document_equal
	and	w0, w0, 255
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	document_equal, .-document_equal
	.align	2
	.global	nl_source_catalog_private_file_plan_build
	.type	nl_source_catalog_private_file_plan_build, %function
nl_source_catalog_private_file_plan_build:
.LFB3:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 16]
	cmp	x0, 0
	beq	.L36
	ldr	x0, [sp, 24]
	bl	document_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L37
.L36:
	mov	w0, 1
	b	.L38
.L37:
	mov	x0, 16
	bl	malloc
	str	x0, [sp, 40]
	ldr	x0, [sp, 40]
	cmp	x0, 0
	bne	.L39
	mov	w0, 2
	b	.L38
.L39:
	ldr	x0, [sp, 40]
	adrp	x1, methods
	add	x1, x1, :lo12:methods
	str	x1, [x0]
	ldr	x0, [sp, 40]
	adrp	x1, types
	add	x1, x1, :lo12:types
	str	x1, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x1, [sp, 40]
	str	x1, [x0]
	mov	w0, 0
.L38:
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE3:
	.size	nl_source_catalog_private_file_plan_build, .-nl_source_catalog_private_file_plan_build
	.align	2
	.global	nl_source_catalog_private_file_plan_free
	.type	nl_source_catalog_private_file_plan_free, %function
nl_source_catalog_private_file_plan_free:
.LFB4:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	ldr	x0, [sp, 24]
	bl	free
	nop
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE4:
	.size	nl_source_catalog_private_file_plan_free, .-nl_source_catalog_private_file_plan_free
	.align	2
	.global	nl_source_catalog_private_file_plan_storage_size
	.type	nl_source_catalog_private_file_plan_storage_size, %function
nl_source_catalog_private_file_plan_storage_size:
.LFB5:
	.cfi_startproc
	mov	x0, 16
	ret
	.cfi_endproc
.LFE5:
	.size	nl_source_catalog_private_file_plan_storage_size, .-nl_source_catalog_private_file_plan_storage_size
	.align	2
	.global	nl_source_catalog_private_file_plan_interface
	.type	nl_source_catalog_private_file_plan_interface, %function
nl_source_catalog_private_file_plan_interface:
.LFB6:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L44
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	b	.L46
.L44:
	mov	x0, 0
.L46:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE6:
	.size	nl_source_catalog_private_file_plan_interface, .-nl_source_catalog_private_file_plan_interface
	.align	2
	.global	nl_source_catalog_private_file_plan_method_count
	.type	nl_source_catalog_private_file_plan_method_count, %function
nl_source_catalog_private_file_plan_method_count:
.LFB7:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L48
	mov	x0, 5
	b	.L50
.L48:
	mov	x0, 0
.L50:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE7:
	.size	nl_source_catalog_private_file_plan_method_count, .-nl_source_catalog_private_file_plan_method_count
	.align	2
	.global	nl_source_catalog_private_file_plan_type_count
	.type	nl_source_catalog_private_file_plan_type_count, %function
nl_source_catalog_private_file_plan_type_count:
.LFB8:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L52
	mov	x0, 8
	b	.L54
.L52:
	mov	x0, 0
.L54:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE8:
	.size	nl_source_catalog_private_file_plan_type_count, .-nl_source_catalog_private_file_plan_type_count
	.align	2
	.global	nl_source_catalog_private_file_plan_method
	.type	nl_source_catalog_private_file_plan_method, %function
nl_source_catalog_private_file_plan_method:
.LFB9:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	str	x1, [sp]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L56
	ldr	x0, [sp]
	cmp	x0, 4
	bhi	.L56
	ldr	x0, [sp, 8]
	ldr	x2, [x0]
	ldr	x1, [sp]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	add	x0, x2, x0
	b	.L58
.L56:
	mov	x0, 0
.L58:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE9:
	.size	nl_source_catalog_private_file_plan_method, .-nl_source_catalog_private_file_plan_method
	.align	2
	.global	nl_source_catalog_private_file_plan_type
	.type	nl_source_catalog_private_file_plan_type, %function
nl_source_catalog_private_file_plan_type:
.LFB10:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	str	x1, [sp]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L60
	ldr	x0, [sp]
	cmp	x0, 7
	bhi	.L60
	ldr	x0, [sp, 8]
	ldr	x2, [x0, 8]
	ldr	x1, [sp]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	b	.L62
.L60:
	mov	x0, 0
.L62:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE10:
	.size	nl_source_catalog_private_file_plan_type, .-nl_source_catalog_private_file_plan_type
	.align	2
	.global	nl_source_catalog_private_file_catalog_interface
	.type	nl_source_catalog_private_file_catalog_interface, %function
nl_source_catalog_private_file_catalog_interface:
.LFB11:
	.cfi_startproc
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	ret
	.cfi_endproc
.LFE11:
	.size	nl_source_catalog_private_file_catalog_interface, .-nl_source_catalog_private_file_catalog_interface
	.align	2
	.global	nl_source_catalog_private_file_catalog_method
	.type	nl_source_catalog_private_file_catalog_method, %function
nl_source_catalog_private_file_catalog_method:
.LFB12:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 4
	bhi	.L66
	ldr	x1, [sp, 8]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	adrp	x1, methods
	add	x1, x1, :lo12:methods
	add	x0, x0, x1
	b	.L68
.L66:
	mov	x0, 0
.L68:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE12:
	.size	nl_source_catalog_private_file_catalog_method, .-nl_source_catalog_private_file_catalog_method
	.align	2
	.global	nl_source_catalog_private_file_catalog_type
	.type	nl_source_catalog_private_file_catalog_type, %function
nl_source_catalog_private_file_catalog_type:
.LFB13:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 7
	bhi	.L70
	ldr	x1, [sp, 8]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	adrp	x1, types
	add	x1, x1, :lo12:types
	add	x0, x0, x1
	b	.L72
.L70:
	mov	x0, 0
.L72:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE13:
	.size	nl_source_catalog_private_file_catalog_type, .-nl_source_catalog_private_file_catalog_type
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
