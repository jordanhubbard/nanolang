from pathlib import Path
import json,gzip,hashlib,subprocess,re,sys
root=Path.cwd();out=root/'docs/evidence/host-closure-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest();paths={Path(__file__).resolve()}
for folder in ['host-closure-compiler','host-closure-compiler-v2','host-closure-installed']:
 paths.update(p for p in (root/'.test_output'/folder).rglob('*') if p.is_file())
for name in ['build-host-closure-compiler.py','build-host-closure-compiler-v2.py','probe-host-closure-installed.py','build-host-artifact-loader.log','build-host-artifact-loader-v2.log','host-artifact-deployment-tests.log','host-artifact-deployment-tests-v2.log','host-artifact-deployment-tests-v3.log','host-closure-original-adapters.log','host-closure-original-adapters-v2.log','host-closure-original-unit-plan.log','host-closure-original-unit-argv.json','host-closure-original-unit-build.log','host-closure-original-unit.log','host-closure-original-unit','host-closure-artifact-helper-plan.log','host-closure-artifact-helper-argv.json','host-closure-artifact-helper-build.log','host-closure-startup-probe.json','probe-host-closure-installed.log','host-closure-make-deployment.log','host-closure-make-deployment-v2.log']:
 p=root/'.test_output'/name
 if p.is_file():paths.add(p)
state=json.loads((root/'.test_output/host-closure-installed/manifest.json').read_text());assert state['status']=='passed' and state['host_inputs_unchanged'] and state['original_bootstrap_guards_unchanged'];external=Path(state['external']);paths.update(p for p in external.rglob('*') if p.is_file())
for path,digest in state['host_inputs'].items():
 p=Path(path);assert sha(p.read_bytes())==digest;paths.update(q for q in p.parent.rglob('*') if q.is_file())
for directory in (root/'.test_output').glob('host-artifact-deployment-*'):
 if directory.is_dir():paths.update(p for p in directory.rglob('*') if p.is_file())
for name in ['src','src_nano','modules','include','scripts','tests']:
 names=subprocess.check_output(['git','ls-files',name],cwd=root,text=True).splitlines()
 for file in names:
  p=root/file
  if p.is_file():paths.add(p)
for name in ['Makefile.gnu','README.md','docs/NATIVE_HOST_DEPLOYMENT.md','scripts/embed_host_artifact_loader.py','scripts/install_host_artifacts.py','src/nanoisa/host_artifact_digest.h','src/nanoisa/host_artifact_loader.h','src/nanoisa/host_artifact_source.h','tests/test_host_artifact_deployment.py','tests/nanoisa/test_nanoisa_src_nano','.test_output/installed-tool-discovery/compiler.nvm']:
 paths.add(root/name)
paths.add(Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/bin/nano_aot_runtime.o'))
patch=subprocess.check_output(['git','diff','--binary'],cwd=root);(out/'source-diff.patch').write_bytes(patch)
seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw)
 if h not in seen:
  artifact=f'inputs/{i:04d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 artifact=seen[h];packed=(out/artifact).read_bytes();entries.append(dict(path=str(p),artifact=artifact,sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),files=entries,installed=state,limits=['I retain all available current declared inputs, generated/native deployment products and original test drivers. Original temporary adapter/unit products removed by their tests are not retained. My first bytes/text harness mismatch, missing-helper cohort and mistyped Make prerequisite remain failed observations; final corrected cohorts retain unchanged original assertions. This is development closure evidence, not a new bootstrap or final release qualification.'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for entry in entries:
 packed=(out/entry['artifact']).read_bytes();assert sha(packed)==entry['compressed_sha256'] and sha(gzip.decompress(packed))==entry['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),compressed_bytes=sum((out/x).stat().st_size for x in seen.values()))))
