# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h"

# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h"
typedef enum { NL_FILE_SOURCE_OK,NL_FILE_SOURCE_INVALID,NL_FILE_SOURCE_LIMIT,
 NL_FILE_SOURCE_MEMORY,NL_FILE_SOURCE_UNRESOLVED } NlFileSourceStatus;
typedef struct { const char *data;size_t size; } NlFileSourceText;
typedef struct { uint32_t id,kind,ordinal;NlFileSourceText name; } NlFileSourceBinding;
typedef struct {
 NlFileSourceText module,interface_id,catalog_view;
 uint32_t catalog_version,line,column;
 const NlFileSourceBinding *bindings;size_t binding_count;
} NlFileSourceRequest;
typedef struct { NlFileSourceText module,name;uint32_t id,target; } NlFileSourceAlias;
typedef struct { NlFileSourceText module,name;uint32_t id; } NlFileSourceOrdinary;
typedef struct NlFileSourcePlan NlFileSourcePlan;
typedef struct {
 NlFileSourceText module,name;uint32_t id,target,request,kind,ordinal,category;
 uint32_t input_mode,result_ordinal,global_layout,import_index,line,column,catalog;
} NlFileSourceRow;




NlFileSourceStatus nl_file_source_plan_build(const NlFileSourceRequest *,size_t,
 const NlFileSourceAlias *,size_t,const NlFileSourceOrdinary *,size_t,NlFileSourcePlan **out);


NlFileSourceStatus nl_service_source_plan_build(const NlFileSourceRequest *,size_t,
 const NlFileSourceAlias *,size_t,const NlFileSourceOrdinary *,size_t,NlFileSourcePlan **out);
void nl_file_source_plan_free(NlFileSourcePlan *);
size_t nl_file_source_plan_count(const NlFileSourcePlan *);
size_t nl_file_source_plan_bytes(const NlFileSourcePlan *);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h"
    nl_file_source_plan_row(const NlFileSourcePlan *,size_t,NlFileSourceRow *out);



const char *nl_file_source_catalog_string(int64_t,int64_t,int64_t,int64_t);
int64_t nl_file_source_catalog_number(int64_t,int64_t,int64_t,int64_t);




# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h"
    nl_file_source_catalog_view(char *out,size_t capacity,size_t *needed);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/service_source_catalog.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/service_source_catalog.h" 2


enum { NL_SOURCE_CATALOG_NONE = 0, NL_SOURCE_CATALOG_FILE = 1,
       NL_SOURCE_CATALOG_SOCKET = 2, NL_SOURCE_CATALOG_WEBSOCKET = 3 };
int64_t nl_service_source_catalog_id(const char *interface_id);

int64_t nl_service_source_catalog_count(int64_t catalog, int64_t kind);

const char *nl_service_source_catalog_string(int64_t catalog, int64_t kind,
                                            int64_t ordinal, int64_t field, int64_t member);
int64_t nl_service_source_catalog_number(int64_t catalog, int64_t kind,
                                        int64_t ordinal, int64_t field, int64_t member);



# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/service_source_catalog.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/service_source_catalog.h"
    nl_service_source_catalog_view(int64_t catalog, char *out, size_t capacity, size_t *needed);
# 3 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_socket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_socket_plan.h" 2




typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_source_catalog_private_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_source_catalog_private_socket_plan_free(NlSocketPlan *);
size_t nl_source_catalog_private_socket_plan_storage_size(void);
const char *nl_source_catalog_private_socket_plan_interface(const NlSocketPlan *);
size_t nl_source_catalog_private_socket_plan_method_count(const NlSocketPlan *);
size_t nl_source_catalog_private_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_source_catalog_private_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_source_catalog_private_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_source_catalog_private_socket_catalog_interface(void);
const NlServicePlanMethod *nl_source_catalog_private_socket_catalog_method(size_t);
const NlServicePlanType *nl_source_catalog_private_socket_catalog_type(size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_websocket_plan.h" 1






typedef struct NlWebSocketPlan NlWebSocketPlan;
typedef enum { NL_WEBSOCKET_PLAN_OK, NL_WEBSOCKET_PLAN_INVALID, NL_WEBSOCKET_PLAN_MEMORY } NlWebSocketPlanStatus;



NlWebSocketPlanStatus nl_source_catalog_private_websocket_plan_build(const NlNsi *,NlWebSocketPlan **out);
void nl_source_catalog_private_websocket_plan_free(NlWebSocketPlan *);
size_t nl_source_catalog_private_websocket_plan_storage_size(void);
const char *nl_source_catalog_private_websocket_plan_interface(const NlWebSocketPlan *);
size_t nl_source_catalog_private_websocket_plan_method_count(const NlWebSocketPlan *);
size_t nl_source_catalog_private_websocket_plan_type_count(const NlWebSocketPlan *);
size_t nl_source_catalog_private_websocket_plan_capability_count(const NlWebSocketPlan *);
const NlServicePlanMethod *nl_source_catalog_private_websocket_plan_method(const NlWebSocketPlan *,size_t);
const NlServicePlanType *nl_source_catalog_private_websocket_plan_type(const NlWebSocketPlan *,size_t);
const NlServicePlanCapability *nl_source_catalog_private_websocket_plan_capability(const NlWebSocketPlan *,size_t);
const char *nl_source_catalog_private_websocket_catalog_interface(void);
const NlServicePlanMethod *nl_source_catalog_private_websocket_catalog_method(size_t);
const NlServicePlanType *nl_source_catalog_private_websocket_catalog_type(size_t);
const NlServicePlanCapability *nl_source_catalog_private_websocket_catalog_capability(size_t);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_file_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_file_plan.h" 1






typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_source_catalog_private_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_source_catalog_private_file_plan_free(NlFilePlan *);

size_t nl_source_catalog_private_file_plan_storage_size(void);
const char *nl_source_catalog_private_file_plan_interface(const NlFilePlan *);
size_t nl_source_catalog_private_file_plan_method_count(const NlFilePlan *);
size_t nl_source_catalog_private_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_source_catalog_private_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_source_catalog_private_file_plan_type(const NlFilePlan *, size_t);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/../nsi_file_catalog.h" 2


const char *nl_source_catalog_private_file_catalog_interface(void);
const NlFilePlanMethod *nl_source_catalog_private_file_catalog_method(size_t);
const NlFilePlanType *nl_source_catalog_private_file_catalog_type(size_t);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4
# 53 "/usr/include/stdio.h" 3 4
typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;
# 78 "/usr/include/stdio.h" 3 4
typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 184 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 211 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 236 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 299 "/usr/include/stdio.h" 3 4
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 314 "/usr/include/stdio.h" 3 4
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 357 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 410 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));
# 463 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 540 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 635 "/usr/include/stdio.h" 3 4
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
# 654 "/usr/include/stdio.h" 3 4
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 779 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 860 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 878 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
# 941 "/usr/include/stdio.h" 3 4
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2
# 1 "/usr/include/inttypes.h" 1 3 4
# 34 "/usr/include/inttypes.h" 3 4
typedef unsigned int __gwchar_t;
# 327 "/usr/include/inttypes.h" 3 4





typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
# 351 "/usr/include/inttypes.h" 3 4
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
# 415 "/usr/include/inttypes.h" 3 4

# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 2

# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
int64_t nl_service_source_catalog_id(const char *id) {
 if(!id)return NL_SOURCE_CATALOG_NONE;
 if(!strcmp(id,nl_source_catalog_private_file_catalog_interface()))return NL_SOURCE_CATALOG_FILE;
 if(!strcmp(id,nl_source_catalog_private_socket_catalog_interface()))return NL_SOURCE_CATALOG_SOCKET;
 if(!strcmp(id,nl_source_catalog_private_websocket_catalog_interface()))return NL_SOURCE_CATALOG_WEBSOCKET;
 return NL_SOURCE_CATALOG_NONE;
}
int64_t nl_service_source_catalog_count(int64_t catalog,int64_t kind) {
 if(catalog==NL_SOURCE_CATALOG_FILE)return kind==1?8:kind==2?5:-1;
 if(catalog==NL_SOURCE_CATALOG_SOCKET)return kind==1?(int64_t)9u:kind==2?(int64_t)5u:-1;
 if(catalog==NL_SOURCE_CATALOG_WEBSOCKET)return kind==1?(int64_t)7u:kind==2?(int64_t)4u:-1;
 return -1;
}
static const char *source_interface(int64_t catalog) {
 return catalog==NL_SOURCE_CATALOG_FILE?nl_source_catalog_private_file_catalog_interface():
        catalog==NL_SOURCE_CATALOG_SOCKET?nl_source_catalog_private_socket_catalog_interface():
        catalog==NL_SOURCE_CATALOG_WEBSOCKET?nl_source_catalog_private_websocket_catalog_interface():"";
}
static const NlServicePlanType *source_type(int64_t catalog,size_t ordinal) {
 return catalog==NL_SOURCE_CATALOG_FILE?nl_source_catalog_private_file_catalog_type(ordinal):catalog==NL_SOURCE_CATALOG_SOCKET?nl_source_catalog_private_socket_catalog_type(ordinal):nl_source_catalog_private_websocket_catalog_type(ordinal);
}
static const NlServicePlanMethod *source_method(int64_t catalog,size_t ordinal) {
 return catalog==NL_SOURCE_CATALOG_FILE?nl_source_catalog_private_file_catalog_method(ordinal):catalog==NL_SOURCE_CATALOG_SOCKET?nl_source_catalog_private_socket_catalog_method(ordinal):nl_source_catalog_private_websocket_catalog_method(ordinal);
}





const char *nl_service_source_catalog_string(int64_t catalog,int64_t k,int64_t i,int64_t f,int64_t j) {
 const char *s=
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
              ((void *)0)
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                  ;
 if(k==0 && i==0 && f==0 && j==0)s=source_interface(catalog);
 if(k==1 && i>=0 && i<nl_service_source_catalog_count(catalog,1) && j>=0) {
  const NlServicePlanType *t=source_type(catalog,(size_t)i);
  if(f==0 && j==0)s=t->id;else if(f==1 && j==0)s=t->name;
  else if((uint64_t)j<t->member_count) {
   const NlServicePlanMember *m=&t->members[j];
   if(f==2)s=m->id;else if(f==3)s=m->name;else if(f==4)s=m->type_id;
  }
 }
 if(k==2 && i>=0 && i<nl_service_source_catalog_count(catalog,2) && j>=0) {
  const NlServicePlanMethod *m=source_method(catalog,(size_t)i);
  if(f==0 && j==0)s=m->id;else if(f==1 && j==0)s=m->name;else if(f==2 && j==0)s=m->generated_name;else if(f==3 && j==0)s=m->binding_id;
  else if(f==7 && j<2)s=m->outcomes[j].owned_payload_type;
  else if((uint64_t)j<m->param_count) {
   const NlServicePlanParam *p=&m->params[j];
   if(f==4)s=p->id;else if(f==5)s=p->name;else if(f==6)s=p->type_id;
  }
 }
 return s?s:"";
}
int64_t nl_service_source_catalog_number(int64_t catalog,int64_t k,int64_t i,int64_t f,int64_t j) {
 if(k==1 && i>=0 && i<nl_service_source_catalog_count(catalog,1) && j>=0) {
  const NlServicePlanType *t=source_type(catalog,(size_t)i);
  if(f==0 && j==0)return t->kind;
  if(f==1 && j==0)return (int64_t)t->member_count;
  if(f==2 && (uint64_t)j<t->member_count)return t->members[j].domain;
 }
 if(k==2 && i>=0 && i<nl_service_source_catalog_count(catalog,2) && j>=0) {
  const NlServicePlanMethod *m=source_method(catalog,(size_t)i);
  if(f==0 && j==0)return m->abi_version;
  if(f==1 && j==0)return m->required_rights;
  if(f==2 && j==0)return m->acquired_rights;
  if(f==3 && j==0)return m->input_mode;
  if(f==4 && j==0)return (int64_t)m->param_count;
  if(f==10 && j<2)return m->outcomes[j].input_state;
  if((uint64_t)j<m->param_count) {
   const NlServicePlanParam *p=&m->params[j];
   if(f==5)return p->direction;
   if(f==6)return p->ownership;
   if(f==7)return p->lifetime;
   if(f==8)return p->mutability;
   if(f==9)return p->domain;
  }
 }
 return -1;
}
typedef struct { char bytes[32768];size_t used;
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                              _Bool 
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                                   ok; } CatalogText;
static void catalog_text(CatalogText *b,const char *s) {
 size_t n=strlen(s);if(!b->ok || n>=sizeof b->bytes-b->used){b->ok=
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                                                  0
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                                                       ;return;}
 memcpy(b->bytes+b->used,s,n);b->used+=n;b->bytes[b->used]=0;
}
static void catalog_number(CatalogText *b,int64_t n) {
 char text[32];int rc=snprintf(text,sizeof text,"#%" 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                                    "l" "d" 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                                           ";",n);
 if(rc<0 || (size_t)rc>=sizeof text){b->ok=
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                          0
# 94 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                               ;return;}catalog_text(b,text);
}
static void catalog_string(CatalogText *b,const char *s) {
 char text[32];int rc=snprintf(text,sizeof text,"%zu:",strlen(s));
 if(rc<0 || (size_t)rc>=sizeof text){b->ok=
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                          0
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                               ;return;}
 catalog_text(b,text);catalog_text(b,s);catalog_text(b,";");
}

# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
_Bool 
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
    nl_service_source_catalog_view(int64_t catalog,char *out,size_t cap,size_t *needed) {
 if(!needed || (!out && cap) || nl_service_source_catalog_count(catalog,1)<0)return 
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                                                                   0
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                                                                        ;
 CatalogText b={{0},0,
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                     1
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                         };catalog_text(&b,catalog==NL_SOURCE_CATALOG_FILE?"file-source-catalog1;":catalog==NL_SOURCE_CATALOG_SOCKET?"socket-source-catalog1;":"websocket-source-catalog1;");
 catalog_string(&b,source_interface(catalog));catalog_number(&b,nl_service_source_catalog_count(catalog,1));catalog_number(&b,nl_service_source_catalog_count(catalog,2));
 for(int64_t i=0;i<nl_service_source_catalog_count(catalog,1);i++) {
  for(int64_t f=0;f<2;f++)catalog_string(&b,nl_service_source_catalog_string(catalog,1,i,f,0));
  for(int64_t f=0;f<2;f++)catalog_number(&b,nl_service_source_catalog_number(catalog,1,i,f,0));
  int64_t count=nl_service_source_catalog_number(catalog,1,i,1,0);
  for(int64_t j=0;j<count;j++) {
   for(int64_t f=2;f<5;f++)catalog_string(&b,nl_service_source_catalog_string(catalog,1,i,f,j));
   catalog_number(&b,nl_service_source_catalog_number(catalog,1,i,2,j));
  }
 }
 for(int64_t i=0;i<nl_service_source_catalog_count(catalog,2);i++) {
  for(int64_t f=0;f<4;f++)catalog_string(&b,nl_service_source_catalog_string(catalog,2,i,f,0));
  for(int64_t f=0;f<5;f++)catalog_number(&b,nl_service_source_catalog_number(catalog,2,i,f,0));
  int64_t count=nl_service_source_catalog_number(catalog,2,i,4,0);
  for(int64_t j=0;j<count;j++) {
   for(int64_t f=4;f<7;f++)catalog_string(&b,nl_service_source_catalog_string(catalog,2,i,f,j));
   for(int64_t f=5;f<10;f++)catalog_number(&b,nl_service_source_catalog_number(catalog,2,i,f,j));
  }
  for(int64_t j=0;j<2;j++) {
   catalog_number(&b,nl_service_source_catalog_number(catalog,2,i,10,j));
   catalog_string(&b,nl_service_source_catalog_string(catalog,2,i,7,j));
  }
 }
 if(!b.ok || (out && cap<=b.used))return 
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                                        0
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                                             ;
 if(out)memcpy(out,b.bytes,b.used+1);
 *needed=b.used+1;return 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
                        1
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
                            ;
}


const char *nl_file_source_catalog_string(int64_t k,int64_t i,int64_t f,int64_t j) {
 return nl_service_source_catalog_string(NL_SOURCE_CATALOG_FILE,k,i,f,j);
}
int64_t nl_file_source_catalog_number(int64_t k,int64_t i,int64_t f,int64_t j) {
 return nl_service_source_catalog_number(NL_SOURCE_CATALOG_FILE,k,i,f,j);
}

# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c" 3 4
_Bool 
# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c"
    nl_file_source_catalog_view(char *out,size_t cap,size_t *needed) {
 return nl_service_source_catalog_view(NL_SOURCE_CATALOG_FILE,out,cap,needed);
}
