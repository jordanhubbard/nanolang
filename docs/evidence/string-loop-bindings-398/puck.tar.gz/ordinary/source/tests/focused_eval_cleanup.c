#define main retained_full_eval_main
#include "test_eval.c"
#undef main
int main(void) {
 TEST(eval_for_loop);
 TEST(eval_nested_for_loops);
 TEST(eval_for_over_dynarray);
 TEST(eval_for_over_float_array);
 TEST(eval_string_loop_bindings);
 puts("I completed the string loop ownership controls.");
 return 0;
}
