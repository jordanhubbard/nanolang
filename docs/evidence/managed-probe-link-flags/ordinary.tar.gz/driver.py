import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();config=sys.argv[3];report.mkdir(exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','write','inventory','run')];assert len(nodes)==4
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));
for node in nodes:
 if node.name=='run':
  for item in node.body:
   if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets):item.value=ast.Constant(value=1200)
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(module,str(base),'exec'));(report/'effective-supervisor.py').write_text(ast.unparse(module));shutil.copyfile(__file__,report/'driver.py')
files=(root/'.qualification-tracked').read_text().splitlines()
def source():return {p:sha(root/p) for p in files}
paths={n:shutil.which(n) for n in ('make','cc','gcc','clang','opt','llvm-as','llvm-dis','lli','llc','llvm-nm','wasm-ld','wasmtime','node','ar','ld','nm','ps','python3')};paths.update(driver=__file__,supervisor=str(base),driver_python=sys.executable)
for n in ('cc1','collect2','libasan.so','libubsan.so'):
 p=subprocess.check_output(['gcc',('-print-prog-name=' if n in ('cc1','collect2') else '-print-file-name=')+n],text=True).strip()
 if Path(p).is_file():paths[n]=p
def tools():return {n:{'path':str(Path(p).resolve()),'sha256':sha(p)} for n,p in paths.items()}
phases=set();results=[];darwin=False
hook=Path('/home/jkh/nanolang-qualification/managed-probe-63b-hooks')
paths['retention_hook']=str(hook/'sitecustomize.py')
os.environ['NMS_NATIVE_CLANG_FLAGS']='--gcc-install-dir=/usr/lib/gcc/aarch64-linux-gnu/13'
os.environ['QUAL_CHILD_REPORT']=str(report/'children')
os.environ['PYTHONPATH']=str(hook)+':'+str(root)
write('selected-environment.json',{k:os.environ[k] for k in ('NMS_NATIVE_CLANG_FLAGS','QUAL_CHILD_REPORT','PYTHONPATH')})
os.environ['ASAN_OPTIONS']='detect_leaks=1';os.environ['UBSAN_OPTIONS']='halt_on_error=1';os.environ['LSAN_OPTIONS']=''
flags='-Wall -Wextra -Werror -std=c99 -g -Isrc -D_GNU_SOURCE';link='-lm -lcrypto'
if config=='sanitizer':flags+=' -fsanitize=address,undefined -fno-omit-frame-pointer';link+=' -fsanitize=address,undefined'
write('attribution.json',{'source':'63b4111f9','config':config,'phase_bound':1200,'instrumentation':config,'LSan':True})

try:
 for target in ('test-managed-array-eligibility','test-managed-record-eligibility','test-llvm-managed-records'):
  run(target,['make','-j2',target,'CC=gcc','CFLAGS='+flags,'LDFLAGS='+link])
finally:
 retained=set()
 for p in (report/'children').glob('*-command.json'):
  argv=json.loads(p.read_text()).get('argv',[])
  if isinstance(argv,list):
   for arg in argv:
    q=Path(arg)
    if q.is_absolute() and str(q).startswith('/tmp/nano-') and q.parent.is_dir():retained.add(str(q.parent))
 write('retained-child-artifacts.json',inventory(sorted(retained)))
write('final.json',{'status':'PASS','results':results})
