from pathlib import Path
import gzip,hashlib,json
root=Path.cwd();base=root/'.test_output';dest=root/'docs/evidence/record-stack-linux-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__)}
for name in ['record-stack-b41s55_f','record-stack-we8mt8sq','record-stack-sanitizers','record-stack-map-fixture-refusal']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for pattern in ['record-stack-*.log','run-record-stack-sanitizers.py','run-record-stack-sanitizers.log','build-record-stack-sanitizer.py','build-record-stack-sanitizer.log']:
 paths.update(base.glob(pattern))
for name in ['src_nano/nvm2c/record_stack.nano','tests/nvm2c_record_stack_driver.nano','tests/nvm2c_record_stack_reference.c','tests/test_nanolang_translator_record_stack.py','src/nanoisa/verifier.c','Makefile.gnu','src/nanoisa/managed_record_array_execution.inc','src/nanoisa/managed_record_map_execution.inc','src/nanoisa/managed_array_shapes.c','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','.test_output/obj-enum-functional/nvm2c_record_stack_reference']:
 paths.add(root/name)
paths.add(Path('/home/jkh/Src/nanolang-callable-ownership/bin/nanoc_stage1'))
sha=lambda x:hashlib.sha256(x).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries),indent=2)+'\n')
for entry in entries:
 raw=(dest/entry['artifact']).read_bytes();assert sha(raw)==entry['compressed_sha256'] and sha(gzip.decompress(raw))==entry['sha256']
print(len(entries),sum(e['bytes'] for e in entries),sum(p.stat().st_size for p in seen.values()))
