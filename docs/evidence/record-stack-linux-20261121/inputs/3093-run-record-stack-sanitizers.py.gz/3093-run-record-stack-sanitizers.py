from pathlib import Path
import os,json,subprocess,time
root=Path.cwd();products=root/'.test_output/record-stack-we8mt8sq';out=root/'.test_output/record-stack-sanitizers';expected=(products/'actual-c.reports').read_text().splitlines();env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',LSAN_OPTIONS='');record=dict(products=str(products),environment={k:env[k] for k in ['ASAN_OPTIONS','LSAN_OPTIONS']},steps=[]);reports=[]
for offset in range(0,len(expected),32):
 label=f'cases-{offset}';argv=[out/'actual-shared-height-helper',*[products/f'case-{i}.bin' for i in range(offset,min(offset+32,len(expected)))]];t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(list(map(str,argv)),env=env,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=list(map(str,argv)),returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label;reports.extend((out/(label+'.stdout')).read_text().splitlines())
assert reports==expected;record['reports']=len(reports);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print('I matched all corrected actual C copier/height reports with targeted ASan/UBSan and leak detection.')
