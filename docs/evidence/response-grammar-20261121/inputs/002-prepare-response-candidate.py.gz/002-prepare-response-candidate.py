from pathlib import Path
s=Path('src/module_builder.c').read_text()
def change(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
change('static char *module_capture_response_fragment(const char *fragment);','static char *module_capture_response_fragment(const char *fragment, const ModuleBuildMetadata *meta);\nstatic unsigned module_response_grammar(const ModuleBuildMetadata *meta);')
change('expanded[group][i] = module_capture_response_fragment(source[i]);','expanded[group][i] = module_capture_response_fragment(source[i], meta);')
change('static int module_response_word(const char **cursor, char *word, size_t capacity) {','static int module_response_word(const char **cursor, char *word, size_t capacity,\n                                const ModuleBuildMetadata *meta, unsigned *grammar) {')
old='''        if (c == '\\\\') {
            if (!*p) { errno = EINVAL; return -1; }
            c = *p++;
        } else if (quote) {'''
new='''        if (c == '\\\\') {
            if (!*p) { errno = EINVAL; return -1; }
            if (quote && !*grammar) {
                *grammar = module_response_grammar(meta);
                if (!*grammar) { errno = EINVAL; return -1; }
            }
            /* My measured quoted-literal grammar preserves every backslash
             * inside single quotes. Double quotes escape only quote/slash. */
            if (!(*grammar == 2 && (quote == '\\'' ||
                    (quote == '"' && *p != '\\\\' && *p != '"')))) c = *p++;
        } else if (quote) {'''
change(old,new)
change('/* GNU response words are not shell words: dollar signs and operators are\n * literal, and a backslash quotes the next byte even inside single quotes. */','/* I keep response words separate from shell words. Quoted backslashes use\n * the actual selected driver grammar; an unmeasured grammar stays pending. */')
change('unsigned depth, size_t *bytes) {','unsigned depth, size_t *bytes,\n                                       const ModuleBuildMetadata *meta, unsigned *grammar) {')
change('module_response_word(&cursor, argument, sizeof(argument))','module_response_word(&cursor, argument, sizeof(argument), meta, grammar)')
change('module_expand_response_word(argument, output, capacity, depth + 1, bytes);','module_expand_response_word(argument, output, capacity, depth + 1, bytes, meta, grammar);')
change('static char *module_capture_response_fragment(const char *fragment) {','static char *module_capture_response_fragment(const char *fragment, const ModuleBuildMetadata *meta) {')
change('    size_t bytes = 0;\n    while ((status = module_flag_word(&cursor, word, sizeof(word))) > 0) {','    size_t bytes = 0;\n    unsigned grammar = 0;\n    while ((status = module_flag_word(&cursor, word, sizeof(word))) > 0) {')
change('module_expand_response_word(word, output, 65536, 0, &bytes)','module_expand_response_word(word, output, 65536, 0, &bytes, meta, &grammar)')
change('module_capture_response_fragment(flags[i])','module_capture_response_fragment(flags[i], meta)')
# I prepare an isolated candidate; no active source/provider is replaced.
query=r'''
/* I observe four literal macro arguments through the actual selected driver.
 * This is a bounded preprocessing request, never a version-major inference or
 * execution of compiler output. Unknown output leaves the original response
 * pending. I perform it only when quoted backslashes require disambiguation. */
static unsigned module_response_grammar(const ModuleBuildMetadata *meta) {
    char *driver = module_compiler_path(module_selected_compiler(meta));
    if (!driver) return 0;
    int64_t deadline;
    if (!module_capture_deadline(&deadline)) { free(driver); return 0; }
    const char *temporary = getenv("TMPDIR");
    if (!temporary || !*temporary) temporary = "/tmp";
    char directory[2048] = {0}, response[2048] = {0}, source[2048] = {0}, argument[2050] = {0};
    bool made = module_build_append(directory, sizeof(directory), "%s/nano-response-check-XXXXXX", temporary)
        && mkdtemp(directory);
    bool ok = made && module_build_append(response, sizeof(response), "%s/flags.rsp", directory)
        && module_build_append(source, sizeof(source), "%s/input.c", directory)
        && module_build_append(argument, sizeof(argument), "@%s", response);
    if (ok) {
        FILE *file = fopen(response, "wx");
        ok = file != NULL;
        if (file) {
            ok = fputs("'-DNANO_RSP_A=a\\b' '-DNANO_RSP_B=a\\\\b' "
                       "\"-DNANO_RSP_C=a\\qb\" \"-DNANO_RSP_D=a\\\\b\"\n", file) >= 0;
            if (fclose(file)) ok = false;
        }
    }
    if (ok) {
        FILE *file = fopen(source, "wx");
        ok = file != NULL;
        if (file) {
            ok = fputs("NANO_RSP_A\nNANO_RSP_B\nNANO_RSP_C\nNANO_RSP_D\n", file) >= 0;
            if (fclose(file)) ok = false;
        }
    }
    char output[256] = {0};
    char *args[] = {driver, "-E", "-P", "-x", "c", argument, source, NULL};
    if (ok) ok = module_link_query_output(args, output, sizeof(output), deadline);
    unsigned grammar = 0;
    if (ok) {
        size_t first = strspn(output, " \t\r\n"), size = strlen(output);
        while (size > first && strchr(" \t\r\n", output[size - 1])) size--;
        output[size] = 0;
        if (!strcmp(output + first, "ab\na\\b\naqb\na\\b")) grammar = 1;
        else if (!strcmp(output + first, "a\\b\na\\\\b\na\\qb\na\\b")) grammar = 2;
    }
    if (response[0]) unlink(response);
    if (source[0]) unlink(source);
    if (made) rmdir(directory);
    free(driver);
    return grammar;
}
'''
needle='static ModuleLinkResponseGrammar module_link_response_grammar_command(const char *command) {'
change(needle,query+'\n'+needle)
Path('.test_output/module_builder_response.c').write_text(s)
p=Path('tests/test_module_generation_probe.c').read_text().replace('#include "../src/module_builder.c"','#include "module_builder_response.c"').replace('char *captured = module_capture_response_fragment(argv[2]);','ModuleBuildMetadata response_meta = {0};\n        char *captured = module_capture_response_fragment(argv[2], &response_meta);')
Path('.test_output/response_generation_probe.c').write_text(p)
