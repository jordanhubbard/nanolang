	.arch armv8-a
	.file	"answer.c"
	.text
	.align	2
	.global	nano_build_answer
	.type	nano_build_answer, %function
nano_build_answer:
.LFB0:
	.cfi_startproc
	mov	x0, 42
	ret
	.cfi_endproc
.LFE0:
	.size	nano_build_answer, .-nano_build_answer
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
