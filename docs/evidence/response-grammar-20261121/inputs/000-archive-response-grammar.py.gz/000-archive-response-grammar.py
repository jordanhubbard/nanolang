from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('.test_output'); dest=Path('docs/evidence/response-grammar-20261121'); (dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__),Path('src/module_builder.c'),Path('tests/test_module_generation_probe.c'),Path('tests/test_response_driver_grammar.py'),Path('scripts/ci_qualify_as246.py'),Path('obj/test_module_generation_probe')}
for name in ['response-grammar-hosted-44942021445','response-grammar-old-local','response-private-44943541684','response-matrix-44943965916','response-qualified-44944360513','source-default-clang23']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['response-qualified-tool-identities.json','response-grammar-paired-controls.json','response-driver-grammar-matrix.json','response-qualified-full-source-linux.log','response-qualified-probe-build.log','response-candidate-build.log','response-candidate-build-from-sources.log','response-candidate-local-controls.json','response-candidate-selected-controls.log','prepare-response-candidate.py','module_builder_response.c','response_generation_probe.c']:
 p=base/name
 if p.exists():paths.add(p)
result=json.loads((base/'response-qualified-44944360513/source-capture-tools-linux/as246-candidate/result.json').read_text()); tests=json.loads((base/'response-qualified-44944360513/source-capture-tools-linux/as246-candidate/tests.json').read_text())
assert result['response_grammar_observation_passed'] and result['checkout_sources_restored'] and not result['private_candidate_qualification_passed']
assert tests['ran']==tests['discovered']==9 and tests['failures']==tests['errors']==0 and not tests['skipped']
assert 'Ran 129 tests in 1285.535s\n\nOK (skipped=24)' in (base/'response-qualified-full-source-linux.log').read_text()
matrix=json.loads((base/'response-driver-grammar-matrix.json').read_text());assert len(matrix)==600
assert all(x['native_returncode']==x['replay_returncode'] and x['native_stdout']==x['replay_stdout'] for x in matrix)
sha=lambda b:hashlib.sha256(b).hexdigest(); entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz');seen[h]=out;packed=gzip.compress(raw,mtime=0);out.write_bytes(packed)
 entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
manifest=dict(semantic_source_pin=result['source_pin'],retention_pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),hosted_run=44944360513,files=entries,limits=['I retain original test cleanup; successful temporary native object bytes are not part of this receipt. Darwin and general tool admission remain separate.'])
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
