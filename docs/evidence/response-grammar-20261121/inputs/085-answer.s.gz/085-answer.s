	.file	"answer.c"
	.text
	.globl	nano_build_answer               // -- Begin function nano_build_answer
	.p2align	2
	.type	nano_build_answer,@function
nano_build_answer:                      // @nano_build_answer
	.cfi_startproc
// %bb.0:
	mov	x0, #42                         // =0x2a
	ret
.Lfunc_end0:
	.size	nano_build_answer, .Lfunc_end0-nano_build_answer
	.cfi_endproc
                                        // -- End function
	.ident	"clang version 23.0.0git (https://github.com/llvm/llvm-project.git 11af80c3ec82dc1800c9fa80190c75cd3d69249f)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
