from pathlib import Path
import gzip,hashlib,json
root=Path('docs/evidence/nanolang-service-nominal-20261121');inputs=root/'inputs';inputs.mkdir(parents=True,exist_ok=True)
files=[Path('Makefile.gnu'),Path('scripts/generate_nvm2c_service_catalog.py'),Path('docs/NANOLANG_NANOISA_C_TRANSLATOR.md')]
files += [Path(p) for p in ['src_nano/nvm2c/service_catalog.nano','src_nano/nvm2c/service_nominal.nano','tests/nvm2c_service_catalog_reference.c','tests/nvm2c_service_nominal_driver.nano','tests/nvm2c_service_nominal_reference.c','tests/test_nanolang_translator_service_nominal.py','tests/nanolang_translator_routes.py','tests/native_process.py','tests/test_nanolang_translator_ownership.py','tests/test_nanolang_translator_services.py','tests/test_service_drivers.py','tests/test_socket_service_source.py','tests/test_websocket_service_drivers.py','tests/test_mixed_websocket_source.py']]
files += [p for p in Path('src/nanoisa').glob('service*nominal*') if p.is_file()]
files += [Path('src/nanoisa/nvm_v2_cursor.c'),Path('src/nanoisa/file_source_catalog.c')]
files += [p for p in Path('src').glob('nsi*') if p.suffix in ('.c','.h')]
files += list(Path('tests/fixtures').glob('nsi_*_plan.json'))
files += [p for p in Path('.test_output').glob('service-nominal-*') if p.is_file() and p.suffix in ('.log','.py','.json','.gz','.nano','.c','.txt')]
records=[]
for path in sorted(set(files)):
 data=path.read_bytes();name=str(path).replace('/','_')
 if path.suffix=='.gz':name=name[:-3];data=gzip.decompress(data)
 name += '.gz';blob=gzip.compress(data,mtime=0);(inputs/name).write_bytes(blob)
 records.append(dict(path=str(path),artifact='inputs/'+name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),compressed_sha256=hashlib.sha256(blob).hexdigest(),compressed_bytes=len(blob)))
(root/'manifest.json').write_text(json.dumps(dict(code_commit='1ffd6ed55',files=records),indent=2)+'\n')
print('I retain',len(records),'hash-bound inputs;',sum(r['compressed_bytes'] for r in records),'compressed bytes.')
