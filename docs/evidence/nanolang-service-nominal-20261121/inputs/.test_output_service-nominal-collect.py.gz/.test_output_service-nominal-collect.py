from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tempfile
from tests.nanolang_translator_routes import checked
from tests.test_nanolang_translator_service_nominal import corpus

def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,data):Path(path).write_bytes(gzip.compress((json.dumps(data,separators=(',',':'))+'\n').encode(),mtime=0))
def observe(*args):
 p=subprocess.run(args,capture_output=True,text=True);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

if sys.argv[1]=='--corpus':
 cases=corpus();reports={}
 with tempfile.TemporaryDirectory(prefix='service-nominal-corpus-') as directory:
  groups={}
  for i,(profile,_,data,_) in enumerate(cases):
   path=Path(directory)/str(i);path.write_bytes(data);groups.setdefault(profile,[]).append((i,path))
  for profile,items in groups.items():
   for offset in range(0,len(items),32):
    batch=items[offset:offset+32];values=checked(['obj/nvm2c_service_nominal_reference',str(profile),*[p for _,p in batch]],timeout=600).splitlines();assert len(values)==len(batch)
    reports.update({i:value for (i,_),value in zip(batch,values)})
 records=[]
 for i,(profile,name,data,expected) in enumerate(cases):
  report=reports[i]
  if expected is not None:assert int(report.split('|')[0])==expected,(profile,name,expected,report[:100])
  records.append(dict(profile=profile,name=name,bytes_hex=data.hex(),sha256=digest(data),explicit_status=expected,actual_c_report=report))
 save('.test_output/service-nominal-corpus.json.gz',records)
 print('I retained',len(records),'nominal inputs and complete C reports;',sum(r['explicit_status'] is not None for r in records),'explicit statuses.')
elif sys.argv[1]=='--products':
 host='darwin' if sys.platform=='darwin' else 'linux'
 log=Path('.test_output/service-nominal-'+host+('-resumed-final.log' if host=='linux' else '-final.log')).read_text()
 roots=[line.split('I retain actual service source products at ',1)[1] for line in log.splitlines() if 'I retain actual service source products at ' in line]
 assert len(roots)==2,roots
 root=Path(roots[-1]);records=json.loads((root/'records.json').read_text());assert len(records)==8
 files={str(p.relative_to(root)):dict(sha256=digest(p.read_bytes()),bytes_hex=p.read_bytes().hex()) for p in sorted(root.rglob('*')) if p.is_file()}
 for record in records:
  assert files[record['module']]['sha256']==record['module_sha256']
  assert files[record['carrier']]['sha256']==record['carrier_sha256']
  for name,sha in record['sources'].items():assert files[name]['sha256']==sha
 save('.test_output/service-nominal-'+host+'-products.json.gz',dict(records=records,files=files,metadata_only=True))
 print('I retained',len(records),'actual producer modules/carriers,',len(files),'files, and exact source/catalog bytes; selected shadows run during production, but metadata success grants no execution authority.')
else:
 host='darwin' if sys.platform=='darwin' else 'linux'
 sources=['Makefile.gnu','src/eval.c','src/typechecker.c','src/nanovm/vm_builtins.c','src/nanovm/vm_ffi_arrays.c','src/nanovm/vm_ffi.c','src/module_builder.c','src/runtime/assembler_capture.c','tests/nanovm/test_vm_builtins.c','tests/test_eval.c','tests/test_typechecker.c']
 sources += [str(p) for p in Path('src').glob('nsi*') if p.suffix in ('.c','.h')]
 sources += [str(p) for p in Path('src_nano/nvm2c').glob('*.nano')]+[str(p) for p in Path('src/nanoisa').iterdir() if p.suffix in ('.c','.h','.inc')]
 sources += ['scripts/generate_nvm2c_service_catalog.py','tests/nvm2c_service_catalog_reference.c','tests/nvm2c_service_nominal_driver.nano','tests/nvm2c_service_nominal_reference.c','tests/test_nanolang_translator_service_nominal.py','src/nsi_file_plan.c','src/nsi_socket_plan.c','src/nsi_websocket_plan.c',*[str(p) for p in Path('tests/fixtures').glob('nsi_*_plan.json')]]
 sources += ['tests/'+s for s in ['nvm2c_service_driver.nano','nvm2c_service_reference.c','test_nanolang_translator_services.py','test_native_byte_array_results.py','nanolang_translator_routes.py','native_process.py','test_native_byte_arrays.py','test_native_nested_arrays.py','test_native_record_array_scalar_tags.py','test_native_generic_scalar_array.py','test_byte_array_literals.py','test_byte_conversion_contracts.py','test_byte_alias_contracts.py','test_u8_argument_contracts.py','test_numeric_builtin_selection.py','test_module_builder_self_capture.py','test_assembler_capture_records.py','test_bytes_conversion.nano','test_u8_basic.nano','nanoisa/fixtures/generic_scalar_array.nano']]
 sources += ['tests/'+s for s in ['nanoisa/test_service_bindings.c','nanoisa/test_file_nominal.c','nanoisa/test_socket_nominal.c','nanoisa/test_websocket_nominal.c','nanoisa/test_multi_nominal.c','nanoisa/test_nvm2c.c','nanoisa/test_nvm2c_shape.c','nanoisa/test_nvm2c_callables.c','test_service_bindings.py','test_service_bindings_module.py','test_socket_nominal.py','test_multi_nominal.py','test_type_infer.c']]
 tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_service_reference','obj/nvm2c_service_reference_asan','obj/nvm2c_service_catalog_reference','obj/nvm2c_service_nominal_reference','obj/nvm2c_service_nominal_reference_asan','.test_output/ownership-source-final']
 if host=='linux':tools+=['bin/nano_as_capture.so','obj/test_module_generation_probe']
 hashes={s:digest(Path(s).read_bytes()) for s in tools}
 previous=json.loads(gzip.decompress(Path('docs/evidence/nanolang-ownership-20261120/inputs/ownership-'+host+'-manifest.json.gz').read_bytes()))
 assert previous['post_run_tool_sha256']['.test_output/ownership-source-final']==hashes['.test_output/ownership-source-final']
 result=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,environment={k:os.environ.get(k) for k in ('CC','NANO_NUMERIC_PROVIDERS','NANO_AS_CAPTURE_HELPER','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS')},source_sha256={s:digest(Path(s).read_bytes()) for s in sorted(set(sources))},post_run_tool_sha256=hashes,reused_compiler_matches_previous_receipt=True,limits=['I reuse the real C-seed-built development NanoLang compiler image from7cd173b30; it matches the previous paired ownership receipt.','I explicitly configure the real Linux GNU-as capture helper for the development image outside bin; no capture/shadow guards are disabled.','All four nominal metadata providers/planners, unified views, cursor and three immutable catalogs are ASan/UBSan instrumented in the nominal differential oracle. Generated C driver fixtures are instrumented and link an ordinary AOT runtime; metadata extraction/transport and original allocation controls retain their stated separate scope.','The full C evaluator/checker/VM/provider regression has its stated ordinary or focused sanitizer scope; this is no complete evaluator leak qualification or Darwin LSan claim.','I model immutable normal narrow value carriers, not arbitrary C pointer/overlap graphs; original C raw units retain null/overlap/short-buffer/failure-atomic controls.','The installed Stage1/Stage2 generic-source gate remains open; the original fixture is independently executed with actual available C/NanoLang development producers.','Nominal service metadata grants no flow, execution or host authority; legacy/full-module service integration, pure NanoLang C emission and release acceptance remain open.'])
 if host=='darwin':result.update(sdk=observe('xcrun','--sdk','macosx','--show-sdk-version'),sdk_path=observe('xcrun','--sdk','macosx','--show-sdk-path'),os=observe('sw_vers'))
 Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
