/* I expose actual nominal plans/getters through normal immutable carriers. */
#include "../src/nanoisa/service_file_nominal.h"
#include "../src/nanoisa/service_socket_nominal.h"
#include "../src/nanoisa/service_websocket_nominal.h"
#include "../src/nanoisa/services_nominal.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {bool found;uint32_t global,instance,catalog,ordinal,source,kind,flags,category;} Row;
static Row missing(void){return (Row){false,UINT32_MAX,UINT32_MAX,0,UINT32_MAX,UINT32_MAX,0,0,0};}
#define SINGLE_ROW(v,c) ((Row){true,(v).global_index,(v).catalog_ordinal==UINT32_MAX?UINT32_MAX:0,(v).catalog_ordinal==UINT32_MAX?0:c,(v).catalog_ordinal,(v).source_ordinal,(v).layout_kind,(v).ownership_flags,(uint32_t)(v).category})
#define SINGLE_CASE(n,T,call) case n:{T v,prior;memset(&v,0xa5,sizeof v);memcpy(&prior,&v,sizeof v);if(!(call)){assert(!memcmp(&v,&prior,sizeof v));return missing();}return SINGLE_ROW(v,n-1);}
static Row get_layout(unsigned profile,const void *plan,uint32_t index){
 switch(profile){
 SINGLE_CASE(2,NvmFileNominalLayout,nvm_file_nominal_layout(plan,index,&v))
 SINGLE_CASE(3,NvmSocketNominalLayout,nvm_socket_nominal_layout(plan,index,&v))
 SINGLE_CASE(4,NvmWebSocketNominalLayout,nvm_websocket_nominal_layout(plan,index,&v))
 default:{NvmMultiNominalLayout v,prior;memset(&v,0xa5,sizeof v);memcpy(&prior,&v,sizeof v);
 if(!nvm_multi_nominal_layout(plan,index,&v)){assert(!memcmp(&v,&prior,sizeof v));return missing();}
 NvmServicesNominalLayout unified;assert(nvm_services_nominal_layout(plan,index,&unified));
 return (Row){true,v.global_index,v.instance,v.catalog,v.catalog_ordinal,v.source_ordinal,v.layout_kind,v.ownership_flags,(uint32_t)unified.category};}
 }
}
static Row get_type(unsigned profile,const void *plan,uint32_t instance,uint32_t ordinal){
 if(profile!=5 && instance)return missing();
 switch(profile){
 SINGLE_CASE(2,NvmFileNominalLayout,nvm_file_nominal_type(plan,ordinal,&v))
 SINGLE_CASE(3,NvmSocketNominalLayout,nvm_socket_nominal_type(plan,ordinal,&v))
 SINGLE_CASE(4,NvmWebSocketNominalLayout,nvm_websocket_nominal_type(plan,ordinal,&v))
 default:{NvmMultiNominalLayout v,prior;memset(&v,0xa5,sizeof v);memcpy(&prior,&v,sizeof v);
 if(!nvm_multi_nominal_type(plan,instance,ordinal,&v)){assert(!memcmp(&v,&prior,sizeof v));return missing();}
 return get_layout(profile,plan,v.global_index);}
 }
}
static Row get_source(unsigned profile,const void *plan,uint8_t kind,uint32_t ordinal){
 switch(profile){
 SINGLE_CASE(2,NvmFileNominalLayout,nvm_file_nominal_source(plan,kind,ordinal,&v))
 SINGLE_CASE(3,NvmSocketNominalLayout,nvm_socket_nominal_source(plan,kind,ordinal,&v))
 SINGLE_CASE(4,NvmWebSocketNominalLayout,nvm_websocket_nominal_source(plan,kind,ordinal,&v))
 default:{NvmServicesNominalLayout v,prior;memset(&v,0xa5,sizeof v);memcpy(&prior,&v,sizeof v);
 if(!nvm_services_nominal_source(plan,kind,ordinal,&v)){assert(!memcmp(&v,&prior,sizeof v));return missing();}
 return get_layout(profile,plan,v.global_index);}
 }
}
static int64_t get_import(unsigned profile,const void *plan,uint32_t instance,uint32_t ordinal){
 if(profile!=5 && instance)return -1;
 uint32_t value=123456;bool ok=false;
 switch(profile){case 2:ok=nvm_file_nominal_import(plan,ordinal,&value);break;
 case 3:ok=nvm_socket_nominal_import(plan,ordinal,&value);break;
 case 4:ok=nvm_websocket_nominal_import(plan,ordinal,&value);break;
 default:ok=nvm_multi_nominal_import(plan,instance,ordinal,&value);break;}
 if(!ok){assert(value==123456);return -1;}return value;
}
#define BUILD_CASE(n,T,fn) case n:{T *p=(T *)&sentinel;status=fn(m,&p);if(status)assert(p==(T *)&sentinel);else *out=p;break;}
static unsigned build(unsigned profile,const NvmModule *m,void **out){
 unsigned status=1;static int sentinel;
 switch(profile){BUILD_CASE(2,NvmFileNominalPlan,nvm_file_nominal_plan)
 BUILD_CASE(3,NvmSocketNominalPlan,nvm_socket_nominal_plan)
 BUILD_CASE(4,NvmWebSocketNominalPlan,nvm_websocket_nominal_plan)
 BUILD_CASE(5,NvmMultiNominalPlan,nvm_multi_nominal_plan)}return status;
}
static uint32_t layout_count(unsigned profile,const void *p){switch(profile){case 2:return nvm_file_nominal_layout_count(p);case 3:return nvm_socket_nominal_layout_count(p);case 4:return nvm_websocket_nominal_layout_count(p);default:return nvm_multi_nominal_layout_count(p);}}
static void release(unsigned profile,void *p){switch(profile){case 2:nvm_file_nominal_plan_free(p);break;case 3:nvm_socket_nominal_plan_free(p);break;case 4:nvm_websocket_nominal_plan_free(p);break;default:nvm_multi_nominal_plan_free(p);}}
static void row_print(Row r){printf("%u,%u,%u,%u,%u,%u,%u,%u,%u,",(unsigned)r.found,r.global,r.instance,r.catalog,r.ordinal,r.source,r.kind,r.flags,r.category);}
static void report(unsigned profile,const NvmModule *m){
 void *plan=NULL;unsigned status=build(profile,m,&plan);if(status){assert(!plan);printf("%u\n",status);return;}
 uint32_t count=layout_count(profile,plan),instances=profile==5?nvm_multi_nominal_instance_count(plan):1;
 printf("0|%u,%u,",count,instances);
 for(uint32_t i=0;i<=count;i++)row_print(get_layout(profile,plan,i));
 for(uint32_t i=0;i<=instances;i++){
  Row first=get_type(profile,plan,i,0);unsigned types=first.found?nvm_multi_nominal_catalog_types(first.catalog):0;
  unsigned methods=first.found?nvm_multi_nominal_catalog_methods(first.catalog):0;
  for(unsigned j=0;j<=types;j++)row_print(get_type(profile,plan,i,j));
  for(unsigned j=0;j<=methods;j++)printf("%lld,",(long long)get_import(profile,plan,i,j));
 }
 for(uint8_t kind=0;kind<4;kind++){
  uint32_t end=kind==0?m->struct_count:kind==2?m->union_count:0;
  for(uint32_t i=0;i<=end;i++)row_print(get_source(profile,plan,kind,i));
 }
 putchar('\n');release(profile,plan);
}
