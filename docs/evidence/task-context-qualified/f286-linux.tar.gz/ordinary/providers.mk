include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	@printf '%s\n' '$(COMMON_OBJECTS) $(RUNTIME_OBJECTS)' > /home/jkh/nanolang-qualification/task-context-f286-linux/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/task-context-f286-linux/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/task-context-f286-linux/ordinary/ldflags.txt
