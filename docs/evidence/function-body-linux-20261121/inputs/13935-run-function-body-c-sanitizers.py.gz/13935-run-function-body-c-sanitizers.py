from pathlib import Path
import os,shlex,subprocess,json,time,re
root=Path.cwd();out=root/'.test_output/function-body-c-sanitizers';out.mkdir(exist_ok=False)
lines=(root/'.test_output/function-body-qualified-stage1/stdout').read_text().replace('\\\n',' ').splitlines()
commands=[shlex.split(line) for line in lines if line.startswith('/usr/bin/cc ') and 'tests/nvm2c_function_body_reference.c ' in line]
assert commands
args=[a for a in commands[-1] if a not in ['obj/nanovm/vm_decode.o','obj/nanoisa/isa.o','obj/nanoisa/verifier_types.o']]
args[args.index('-o')+1]=str(out/'reference')
args+=['src/nanovm/vm_decode.c','src/nanoisa/isa.c','src/nanoisa/verifier_types.c','-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
record=dict(build_argv=args,limits=['I instrument actual unchanged verifier.c (included), verifier_types.c, vm_decode.c and isa.c together with my carrier. Other linked providers retain ordinary instrumentation. Affine results stay deferred; this is not full-provider/profile sanitizer qualification.'],steps=[],sanitizer_environment={k:os.environ.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']})
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
save();r=subprocess.run(args,cwd=root,capture_output=True,timeout=600);(out/'build.stdout').write_bytes(r.stdout);(out/'build.stderr').write_bytes(r.stderr);record['build_returncode']=r.returncode;save();assert r.returncode==0
work=Path(re.findall(r'I retain ordinary function-body products at (\S+)',(root/'.test_output/function-body-qualified-stage1/stdout').read_text())[0]);record['work']=str(work);manifest=json.loads((work/'manifest.json').read_text());expected=(work/'actual-c.reports').read_text().splitlines();reports=[];env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin')
with (out/'stderr').open('wb') as errors:
 for i in range(0,len(expected),64):
  argv=[str(out/'reference'),*[str(work/f'case-{j}.bin') for j in range(i,min(len(expected),i+64))]];start=time.monotonic();r=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=600);record['steps'].append(dict(first_case=i,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));save();reports+=r.stdout.decode().splitlines();errors.write(r.stderr);errors.flush();(out/'reports').write_text('\n'.join(reports)+'\n');assert r.returncode==0,(i,r.stderr[-2000:]);assert reports==expected[:len(reports)]
record.update(reports=len(reports),status='passed');save();print(json.dumps(dict(reports=len(reports),cases=len(manifest['cases']),status='passed')))
