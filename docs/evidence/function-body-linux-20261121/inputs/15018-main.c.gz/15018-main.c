/*
 * nano_virt main.c - CLI for compiling .nano to .nvm bytecode or a packaged
 * interpreter executable
 *
 * Usage: nano_virt input.nano [-o output] [--run] [--emit-nvm] [--emit-nvm-v2] [--daemon-wrapper] [-v]
 *
 * Pipeline: .nano → lexer → parser → typechecker → codegen → .nvm
 * With -o:        writes .nvm bytecode (if .nvm extension or --emit-nvm)
 *                 or a packaged-interpreter executable (otherwise, via
 *                 wrapper_gen, which embeds nano_vm). Checked File graphs use
 *                 their qualified native emitter instead of wrapper_gen.
 * With --run:     executes the .nvm via the embedded VM
 */

#include "nanolang.h"
#include "checked_borrow_facts.h"
#include "nanovirt/checked_borrow_codegen.h"
#include "service_driver.h"
#include "module_builder.h"
#include "nanovirt/codegen.h"
#include "nanovirt/wrapper_gen.h"
#include "nanoisa/nvm_format.h"
#include "nanoisa/verifier.h"
#include "../../modules/nanoisa/nanoisa.h"
#include "nanovm/vm.h"
#include "nanovm/vm_ffi.h"
#include "nanovm/value.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#include <time.h>

/* Forward declarations for interpreter FFI (already linked) */
extern bool ffi_init(bool verbose);
extern bool ffi_load_module(const char *module_name, const char *module_path,
                            Environment *env, bool verbose);

/* Globals expected by runtime/cli.c */
int g_argc = 0;
char **g_argv = NULL;

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    if (len < 0 || len > 10 * 1024 * 1024) { fclose(f); return NULL; }
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)len + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t n = fread(buf, 1, (size_t)len, f);
    buf[n] = '\0';
    fclose(f);
    return buf;
}

static void usage(const char *prog) {
    fprintf(stderr, "Usage: %s <input.nano> [-o output] [--run] [--emit-nvm] [--emit-nvm-v2] [--strip-debug] [--daemon-wrapper] [-v]\n", prog);
    fprintf(stderr, "\n");
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "  -o <path>          Packaged interpreter for ordinary graphs: wrapper_gen embeds\n");
    fprintf(stderr, "                     nano_vm to run the module. It is not native AOT.\n");
    fprintf(stderr, "                     Use --emit-nvm or a .nvm path for bytecode;\n");
    fprintf(stderr, "                     ordinary native AOT uses bin/nvm2c\n");
    fprintf(stderr, "  --run              Execute after compilation (in-process VM)\n");
    fprintf(stderr, "  --emit-nvm         Write raw .nvm bytecode instead of the packaged interpreter\n");
    fprintf(stderr, "  --emit-nvm-v2      Retired alias for --emit-nvm (v2 is the default since 4.0)\n");
    fprintf(stderr, "  --strip-debug      Strip source-map debug info from emitted module\n");
    fprintf(stderr, "  --test-imports     I run dependency shadows before root shadows (default)\n");
    fprintf(stderr, "  --root-shadows-only I run only root-file shadows\n");
    fprintf(stderr, "  --allow-tcp-connections I grant TCP shadows and --run outbound connections\n");
    fprintf(stderr, "  --allow-websocket-connections I grant WebSocket connections\n");
    fprintf(stderr, "  --allow-websocket-lookup I separately grant DNS with --websocket-resolver-helper PATH\n");
    fprintf(stderr, "  --allow-temporary-files I grant File shadows and --run temporary-file access\n");
    fprintf(stderr, "                     I publish File graphs as native executables unless --emit-nvm\n");
    fprintf(stderr, "  --daemon-wrapper   Generate thin daemon-mode binary (needs nano_vmd at runtime)\n");
    fprintf(stderr, "  -v                 Verbose output\n");
}

/* Check if path ends with .nvm extension */
static bool has_nvm_extension(const char *path) {
    size_t len = strlen(path);
    return (len >= 4 && strcmp(path + len - 4, ".nvm") == 0);
}

#include "shadow_runner.h"

int main(int argc, char **argv) {
    g_argc = argc;
    g_argv = argv;
    const char *input = NULL;
    const char *output = NULL;
    bool run = false;
    bool emit_nvm = false;
    bool strip_debug = false;
    bool daemon_wrapper = false;
    bool verbose = false;
    bool test_imports = true;
    bool allow_temporary_files = false, allow_tcp_connections = false;
    bool allow_websocket_connections=false,allow_websocket_lookup=false;
    const char *websocket_resolver_helper=NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
            output = argv[++i];
        } else if (strcmp(argv[i], "--allow-websocket-connections") == 0) {
            if(allow_websocket_connections)return 1;
            allow_websocket_connections=true;
        } else if (strcmp(argv[i], "--allow-websocket-lookup") == 0) {
            if(allow_websocket_lookup)return 1;
            allow_websocket_lookup=true;
        } else if (strcmp(argv[i], "--websocket-resolver-helper") == 0) {
            if(websocket_resolver_helper || i+1>=argc)return 1;
            websocket_resolver_helper=argv[++i];
        } else if (strcmp(argv[i], "--allow-tcp-connections") == 0) {
            allow_tcp_connections = true;
        } else if (strcmp(argv[i], "--allow-temporary-files") == 0) {
            allow_temporary_files = true;
        } else if (strcmp(argv[i], "--test-imports") == 0) {
            test_imports = true;
        } else if (strcmp(argv[i], "--root-shadows-only") == 0) {
            test_imports = false;
        } else if (strcmp(argv[i], "--run") == 0) {
            run = true;
        } else if (strcmp(argv[i], "--emit-nvm") == 0) {
            emit_nvm = true;
        } else if (strcmp(argv[i], "--emit-nvm-v2") == 0) {
            /* Retired: v2 is what --emit-nvm writes since 4.0. Still accepted
             * so build scripts written against the transitional flag keep
             * working rather than failing on an unknown option. */
            emit_nvm = true;
        } else if (strcmp(argv[i], "--strip-debug") == 0) {
            strip_debug = true;
        } else if (strcmp(argv[i], "--daemon-wrapper") == 0) {
            daemon_wrapper = true;
        } else if (strcmp(argv[i], "-v") == 0) {
            verbose = true;
        } else if (argv[i][0] != '-') {
            input = argv[i];
        } else {
            usage(argv[0]);
            return 1;
        }
    }

    if (!input) { usage(argv[0]); return 1; }

    /* Read source */
    char *source = read_file(input);
    if (!source) {
        fprintf(stderr, "error: cannot read '%s'\n", input);
        return 1;
    }

    /* Lexer */
    int token_count = 0;
    Token *tokens = tokenize(source, &token_count);
    if (!tokens) {
        fprintf(stderr, "error: lexer failed\n");
        free(source);
        return 1;
    }

    /* Parser */
    ASTNode *program = parse_program(tokens, token_count);
    if (!program) {
        fprintf(stderr, "error: parser failed\n");
        free_tokens(tokens, token_count);
        free(source);
        return 1;
    }

    /* Environment + Module Resolution */
    clear_module_cache();
    Environment *env = create_environment();
    if(!env || !checked_borrow_begin(env)) {
        if(env)free_environment(env);
        free_ast(program);free_tokens(tokens,token_count);free(source);
        fprintf(stderr,"I cannot allocate checked source capture\n");return 1;
    }

    ModuleList *modules = create_module_list();
    if (!process_imports_for_service(program, env, modules, input)) {
        fprintf(stderr, "error: module loading failed\n");
        free_ast(program);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free_tokens(tokens, token_count);
        free(source);
        return 1;
    }

    if(env->service_namespace) {
        int result=1;
        char *root=nl_service_product_root(argv[0]);
        const char *cc=getenv("NANO_CC");if(!cc || !*cc)cc=getenv("CC");
        NvmWebSocketHostPolicy websocket={1,allow_websocket_connections,allow_websocket_lookup,60000,websocket_resolver_helper};
        NlServiceProductOptions options={output,root,cc,getenv("NANO_CFLAGS"),getenv("NANO_LDFLAGS"),
            emit_nvm || (output && has_nvm_extension(output)),allow_temporary_files,run,allow_tcp_connections,&websocket};
        if(daemon_wrapper || strip_debug)fputs("I do not support these output options for File source.\n",stderr);
        else if(root)result=nl_service_compile(program,env,test_imports,&options);
        free(root);free_environment(env);free_ast(program);free_module_list(modules);
        clear_module_cache();free_tokens(tokens,token_count);free(source);return result;
    }

    /* Type Checking */
    typecheck_set_current_file(input);
    env_set_current_file(env, input);
    bool has_main = false, has_shadows = false;
    for (int i = 0; i < program->as.program.count; i++) {
        ASTNode *item = program->as.program.items[i];
        if (item->type == AST_SHADOW) has_shadows = true;
        if (item->type == AST_FUNCTION && strcmp(item->as.function.name, "main") == 0) has_main = true;
    }
    bool typed = has_shadows && !has_main ? type_check_module(program, env) : type_check(program, env);
    if (typed) typed = type_check_shadow_scope(program, env, modules, input, test_imports);
    if (!typed) {
        fprintf(stderr, "error: type check failed\n");
        free_ast(program);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free_tokens(tokens, token_count);
        free(source);
        return 1;
    }

    checked_borrow_finish_capture(env);
    FfiBinding *bindings = calloc(modules->count ? (size_t)modules->count : 1, sizeof(*bindings));
    if (!bindings || !build_ffi_modules(modules, bindings) ||
        !check_shadows(program, env, modules, input, bindings, test_imports)) {
        free_ffi_bindings(bindings, modules->count);
        free_ast(program);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free_tokens(tokens, token_count);
        free(source);
        return 1;
    }

    /* I publish no facts before semantic and runtime shadows complete. */
    CodegenResult cg={0};
    if(checked_borrow_seal(env))cg=codegen_compile_checked(program,env,modules,input);
    else snprintf(cg.error_msg,sizeof cg.error_msg,"I cannot seal checked source capture");
    checked_borrow_end(env);
    if (cg.ok && !bind_ffi_imports(cg.module, modules, bindings, input, env)) {
        fprintf(stderr, "I could not bind production foreign imports\n");
        nvm_module_free(cg.module);
        cg.ok = false;
    }
    free_ffi_bindings(bindings, modules->count);
    if (!cg.ok) {
        fprintf(stderr, "error: codegen failed at line %d: %s\n",
                cg.error_line, cg.error_msg);
        free_ast(program);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free_tokens(tokens, token_count);
        free(source);
        return 1;
    }

    if (strip_debug) {
        nvm_strip_debug_info(cg.module);
    }

    /* Write output if requested */
    if (output) {
        uint32_t size = 0;
        NanoisaErr save_error;
        uint8_t *blob = nanoisa_save_bytes(cg.module, &size, &save_error);
        if (!blob) {
            fprintf(stderr, "error: serialization failed: %s\n",
                    save_error.message);
            nvm_module_free(cg.module);
            free_ast(program);
            free_environment(env);
            free_module_list(modules);
            clear_module_cache();
            free_tokens(tokens, token_count);
            free(source);
            return 1;
        }

        bool want_nvm = emit_nvm || has_nvm_extension(output);

        if (daemon_wrapper) {
            /* Generate thin daemon-mode binary */
            if (verbose) {
                printf("Generating daemon-mode wrapper: %s\n", output);
            }
            if (!wrapper_generate_daemon(blob, size, output, verbose)) {
                free(blob);
                nvm_module_free(cg.module);
                free_ast(program);
                free_environment(env);
                free_module_list(modules);
                clear_module_cache();
                free_tokens(tokens, token_count);
                free(source);
                return 1;
            }
            if (verbose) {
                printf("Daemon-mode wrapper generated: %s\n", output);
            }
        } else if (want_nvm) {
            /* Write raw .nvm bytecode */
            FILE *f = fopen(output, "wb");
            if (!f) {
                fprintf(stderr, "error: cannot write '%s'\n", output);
                free(blob);
                nvm_module_free(cg.module);
                free_ast(program);
                free_environment(env);
                free_module_list(modules);
                clear_module_cache();
                free_tokens(tokens, token_count);
                free(source);
                return 1;
            }
            fwrite(blob, 1, size, f);
            fclose(f);
            if (verbose) {
                printf("Wrote %u bytes of NVM bytecode to %s\n", size, output);
            }
        } else {
            /* Generate a packaged interpreter, never native AOT. */
            if (verbose) {
                printf("Generating packaged interpreter (wrapper_gen): %s\n", output);
            }
            if (!wrapper_generate(cg.module, blob, size, output, input,
                                  program, verbose)) {
                free(blob);
                nvm_module_free(cg.module);
                free_ast(program);
                free_environment(env);
                free_module_list(modules);
                clear_module_cache();
                free_tokens(tokens, token_count);
                free(source);
                return 1;
            }
            if (verbose) {
                printf("Packaged interpreter generated: %s\n", output);
            }
        }
        free(blob);
    }

    /* Preload modules for FFI if the module has imports */
    if (cg.module->import_count > 0) {
        vm_ffi_init();
        vm_ffi_set_env(env);

        /* Load modules referenced in import table */
        for (uint32_t i = 0; i < cg.module->import_count; i++) {
            vm_ffi_load_import(cg.module, i);
        }

        /* Also scan for AST_IMPORT nodes to load modules by path.
         * This handles the case where extern fns have empty module names
         * but the .nano file has module/import statements. */
        for (int i = 0; i < program->as.program.count; i++) {
            ASTNode *item = program->as.program.items[i];
            if (item->type == AST_IMPORT) {
                const char *mod_path = item->as.import_stmt.module_path;
                if (mod_path) {
                    vm_ffi_load_module(mod_path);
                }
            }
        }

        /* Try loading well-known standard modules for bare extern fns.
         * Map function name prefixes to module paths. */
        static const struct { const char *prefix; const char *module; } known_modules[] = {
            {"path_",    "std/fs"},
            {"fs_",      "std/fs"},
            {"file_",    "std/fs"},
            {"dir_",     "std/fs"},
            {"regex_",   "std/regex"},
            {"process_", "std/process"},
            {"json_",    "std/json"},
            {"bstr_",    "std/bstring"},
            {NULL, NULL}
        };

        for (uint32_t i = 0; i < cg.module->import_count; i++) {
            const char *fn_name = nvm_get_string(cg.module,
                                                  cg.module->imports[i].function_name_idx);
            const char *mod_name = nvm_get_string(cg.module,
                                                   cg.module->imports[i].module_name_idx);
            if (fn_name && (!mod_name || mod_name[0] == '\0')) {
                for (int k = 0; known_modules[k].prefix; k++) {
                    if (strncmp(fn_name, known_modules[k].prefix,
                               strlen(known_modules[k].prefix)) == 0) {
                        vm_ffi_load_module(known_modules[k].module);
                        break;
                    }
                }
            }
        }
    }

    int exit_code = 0;

    /* Execute if requested */
    if (run) {
        /* Verify bytecode safety (catches codegen bugs) */
        NvmVerifyResult vr = nvm_verify(cg.module);
        if (!vr.ok) {
            fprintf(stderr, "internal error: bytecode verification failed: %s\n", vr.error_msg);
            nvm_module_free(cg.module);
            return 1;
        }

        VmState vm;
        vm_init(&vm, cg.module);

        /* vm_execute calls __init__ automatically before main */
        VmResult r = vm_execute(&vm);
        if (r != VM_OK) {
            fprintf(stderr, "runtime error: %s\n", vm.error_msg[0] ? vm.error_msg : vm_error_string(r));
            exit_code = 1;
        } else {
            NanoValue result = vm_get_result(&vm);
            if (result.tag == TAG_INT) {
                exit_code = (int)result.as.i64;
            }
        }
        vm_destroy(&vm);
    }

    vm_ffi_shutdown();
    nvm_module_free(cg.module);
    free_ast(program);
    free_environment(env);
    free_module_list(modules);
    clear_module_cache();
    free_tokens(tokens, token_count);
    free(source);
    return exit_code;
}
