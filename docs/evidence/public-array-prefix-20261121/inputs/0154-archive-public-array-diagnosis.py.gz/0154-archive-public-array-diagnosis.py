from pathlib import Path
import gzip,hashlib,json,re
root=Path.cwd();frozen=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');dest=root/'docs/evidence/public-array-prefix-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__).resolve()}
for name in ['public-array-prefix-diagnosis','public-array-prefix-controls','public-array-prefix-controls-v2','public-array-prefix-progress','public-array-prefix-cpu','public-array-prefix-stack','public-array-merge-pointer','public-array-merge-pointer-v2','merge-public-gates','merge-public-gates-clang18','public-array-mutation-cpu','asan-frame-cleanup-control','merge-union-proof']:
 directory=root/'.test_output'/name
 if directory.is_dir():paths.update(p for p in directory.rglob('*') if p.is_file())
for pattern in ['*public-array*.py','*public-array*.log','run-merge-public-gates.py','run-merge-public-gates.log']:
 paths.update((root/'.test_output').glob(pattern))
for name in ['post-bootstrap-acceptance','independent-cli-product']:
 paths.update(p for p in (frozen/'.test_output'/name).rglob('*') if p.is_file())
for name in ['run-post-bootstrap-acceptance.py','run-independent-cli-product.py']:
 p=frozen/'.test_output'/name
 if p.is_file():paths.add(p)
for directory in [Path('/tmp/nano-record-array-public-6w9ows3j')]:paths.update(p for p in directory.rglob('*') if p.is_file())
log='\n'.join(p.read_text() for p in [root/'.test_output/merge-public-gates/original.stdout',root/'.test_output/merge-public-gates-clang18/original.stdout'] if p.exists())
for directory in re.findall(r'I retain (?:public-route evidence at|actual public map evidence at) (/[^\n]+)',log):paths.update(p for p in Path(directory).rglob('*') if p.is_file())
# I retain actual link providers and their immutable original inputs when recorded.
m=json.loads((root/'.test_output/public-array-prefix-controls-v2/manifest.json').read_text())
for name,expected in m['remaining_providers'].items():
 p=Path(name);p=p if p.is_absolute() else frozen/p;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;paths.add(p)
for name in ['src/nanoisa/managed_array_shapes.c','src/nanoisa/record_array_origins.inc','src/nanoisa/union_field_analysis.inc','tests/nanoisa/test_record_array_public.c','tests/nanoisa/record_array_alloc.c','tests/nanoisa/record_array_alloc.h','tests/test_record_array_public.py','tests/test_record_map_public.py']:
 paths.add(root/name);paths.add(frozen/name)
for name in ['/usr/lib/aarch64-linux-gnu/libasan.so.8.0.0','/usr/lib/aarch64-linux-gnu/libc.so.6','/usr/lib/aarch64-linux-gnu/ld-linux-aarch64.so.1']:
 paths.add(Path(name))
sha=lambda raw:hashlib.sha256(raw).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);packed=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:packed.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=packed
 data=packed.read_bytes();entries.append(dict(path=str(p),artifact=str(packed.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(data),compressed_bytes=len(data)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries),indent=2)+'\n')
for e in entries:
 data=(dest/e['artifact']).read_bytes();assert sha(data)==e['compressed_sha256'] and sha(gzip.decompress(data))==e['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum(p.stat().st_size for p in seen.values()))))
