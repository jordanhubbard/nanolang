from pathlib import Path
import subprocess,json,os,time,signal,hashlib
base=Path.cwd();root=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');out=base/'.test_output/public-array-merge-pointer';out.mkdir(exist_ok=False)
s=(root/'src/nanoisa/managed_array_shapes.c').read_text();start=s.index('static int merge(Value');end=s.index('static int stop(',start)
s=s[:start]+s[start:end].replace('Value from','const Value *from').replace('from.','from->')+s[end:]
start=s.index('static int global_merge');end=s.index('static Value *global_values',start)
s=s[:start]+s[start:end].replace('Value from','const Value *from').replace('from.','from->')+s[end:]
changes=[('values[slot]','&values[slot]'),('state[i]','&state[i]'),('global_values(f,state)[slot]','&global_values(f,state)[slot]'),('a->children[i]','&a->children[i]'),('value','&value'),('a->fields[a->field_start[i]+field]','&a->fields[a->field_start[i]+field]'),('stack[depth-1]','&stack[depth-1]'),('stack[base]','&stack[base]'),('stack[base+1]','&stack[base+1]'),('stack[base+2]','&stack[base+2]'),('result','&result')]
import re
for old,new in changes:s=re.sub(r'(\b(?:global_)?merge\([^\n]*?,)'+re.escape(old)+r'\)',lambda m:m[1]+new+')',s)
# Every call passes a stable lvalue; helper-to-helper forwarding already passes a pointer.
source=out/'managed_array_shapes.c';source.write_text(s)
m=json.loads((base/'.test_output/public-array-prefix-controls-v2/corrected-count-build.json').read_text());argv=list(next(x for x in m['steps'] if x['label']=='scheduled')['argv']);src_index=argv.index(str(base/'.test_output/public-array-prefix-controls-v2/initial-count.c'));flags=argv[:src_index];provider=out/'observed-managed_array_shapes.o';build=[*flags,'-DRA_ALLOC_WRAP','-include','tests/nanoisa/record_array_alloc.h','-I'+str(root/'src/nanoisa'),'-c',str(source),'-o',str(provider)];env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',LSAN_OPTIONS='');record={'limits':['I privately replace only aggregate-by-value merge arguments with const pointers to the same stable lvalues. I preserve all fields, joins, original fault loops, ASan/UBSan flags and120-second guest deadline. This is a measured candidate, not yet product acceptance.'],'steps':[]}
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,timeout):
 t=time.monotonic();r={'label':label,'argv':args};record['steps'].append(r);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);r['pid']=p.pid
  try:r['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:r['timeout']=True;os.killpg(p.pid,signal.SIGKILL);r['returncode']=p.wait()
 r['elapsed_seconds']=time.monotonic()-t;save();return r['returncode']==0
assert run('build',build,600)
argv[src_index]='tests/nanoisa/test_record_array_public.c';argv[argv.index('/tmp/nano-record-array-public-6w9ows3j/observed-managed_array_shapes.o')]=str(provider);argv[-1]=str(out/'campaign');assert run('link',argv,600)
record['candidate_source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();record['candidate_image_sha256']=hashlib.sha256((out/'campaign').read_bytes()).hexdigest();save()
run('flow1',[str(out/'campaign'),str(out),'flow','1'],120)
print(json.dumps(record))
