from pathlib import Path
import os,subprocess,json,time,sys,signal
root=Path.cwd();out=root/'.test_output/independent-cli-product';out.mkdir(exist_ok=False);sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(root,1800,30);b.load();artifacts=list(b.manifest['artifacts']);b.check_artifacts(artifacts);env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_BUILD_CACHE=str(out/'module-cache'),LSAN_OPTIONS='');env.pop('NANO_CC',None);env.pop('NANOLANG_ROOT',None);env.pop('NANO_NVM2C',None);args=['/usr/bin/python3','-m','unittest','-v','tests.test_selfhost_cli','tests.test_selfhost_nanoisa_product'];m=dict(argv=args,revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),original_receipt_sha256=digest(root/'bin/nanoc_bootstrap.json'),limits=['I run these independent original scalar CLI/product controls after the public ARRAY fault campaign fails its deadline. That profile gate and #1166 remain open; this command does not claim complete profile or fresh-PREFIX acceptance. I preserve the qualified tool/source/host/artifact guards and use a separate cache.']);start=time.monotonic()
try:
 with (out/'original.stdout').open('wb') as a,(out/'original.stderr').open('wb') as c:
  p=subprocess.Popen(args,env=env,stdout=a,stderr=c,start_new_session=True);m['pid']=p.pid;(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
  try:m['returncode']=p.wait(timeout=1800)
  except subprocess.TimeoutExpired:m['timeout']=True;os.killpg(p.pid,signal.SIGKILL);m['returncode']=p.wait()
finally:
 m['elapsed_seconds']=time.monotonic()-start
 try:b.check_inputs();b.check_artifacts(artifacts);m['original_guards_unchanged']=True
 except Exception as error:m['original_guard_failure']=repr(error)
 (out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
assert m.get('returncode')==0 and m.get('original_guards_unchanged');print('I passed the independent original CLI/product gate; the public ARRAY deadline remains a separate failed gate.')
