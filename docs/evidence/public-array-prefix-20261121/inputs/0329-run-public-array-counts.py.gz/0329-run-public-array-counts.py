from pathlib import Path
import json,subprocess,os,time,signal,hashlib
base=Path.cwd();out=base/'.test_output/public-array-prefix-controls-v2';root=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',LSAN_OPTIONS='');record=dict(steps=[],limits=['I execute only the original first successful allocation-count step, not the fault-injection campaign. Both controls keep the original checks and actual observed providers; the preceding image substitutes the actual changed heap/collector/FFI providers. My30-second measurement bound is not original campaign qualification.'])
for label in ['scheduled','preceding']:
 exe=out/(label+'-initial-count');start=time.monotonic();entry=dict(label=label,argv=[str(exe)],sha256=hashlib.sha256(exe.read_bytes()).hexdigest());record['steps'].append(entry)
 with (out/(label+'-count.stdout')).open('wb') as a,(out/(label+'-count.stderr')).open('wb') as b:
  p=subprocess.Popen([exe],cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);entry['pid']=p.pid
  try:entry['returncode']=p.wait(timeout=30)
  except subprocess.TimeoutExpired:
   entry['measurement_timeout']=True;os.killpg(p.pid,signal.SIGKILL);entry['returncode']=p.wait()
 entry['elapsed_seconds']=time.monotonic()-start;(out/'counts.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['steps'])
