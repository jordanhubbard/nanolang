#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sanitizer/asan_interface.h>
typedef struct {uint64_t origins;uint16_t tags;uint8_t unknown,relation_tag;uint16_t relation;} Value;
static unsigned char *flag;
static unsigned during;
__attribute__((no_sanitize_address,noinline)) static void observe(const void *address) {
    void *begin=0,*end=0;
    void *frame=__asan_addr_is_in_fake_stack(__asan_get_current_fake_stack(),(void *)address,&begin,&end);
    if(!frame || !end)return;
    memcpy(&flag,(unsigned char *)end-sizeof(flag),sizeof(flag));
    during=*flag;
}
__attribute__((noinline)) static int merge(Value *to,Value from) {
    observe(&from);
    Value old=*to;
    to->tags|=from.tags;to->origins|=from.origins;to->unknown|=from.unknown;
    return old.tags!=to->tags || old.origins!=to->origins || old.unknown!=to->unknown;
}
int main(void) {
    Value to={0},from={.origins=4,.tags=2,.unknown=1};
    int changed=merge(&to,from);
    if(!flag || during!=1 || !changed || to.origins!=4 || to.tags!=2 || to.unknown!=1)return 97;
    printf("during=%u after=%u\n",during,*flag);
    return *flag?108:0;
}
