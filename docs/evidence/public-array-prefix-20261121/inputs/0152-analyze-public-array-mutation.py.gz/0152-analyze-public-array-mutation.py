from pathlib import Path
import collections,json,os,struct,subprocess
p=Path('.test_output/public-array-mutation-cpu');m=json.loads((p/'manifest.json').read_text());step=m['steps'][-1];assert step['intentional_window_stop'];rows=list(struct.iter_unpack('<QQQQ',(p/'campaign.bin').read_bytes()));assert len(rows)>100 and all(r[2]==step['pid'] and r[3]==step['pid'] for r in rows);window={'start_ns':rows[0][0],'end_ns':rows[-1][0]}
maps=[]
for line in (p/'campaign.loaded.maps').read_text().splitlines():
 fields=line.split(maxsplit=5)
 if len(fields)<6 or 'x' not in fields[1]:continue
 a,b=(int(v,16) for v in fields[0].split('-'));maps.append(dict(start=a,end=b,offset=int(fields[2],16),file=fields[5]))
def elf_offset(mapping,pc):
 f=Path(mapping['file']);data=f.read_bytes();assert data[:6]==b'\x7fELF\x02\x01';phoff=struct.unpack_from('<Q',data,32)[0];phsize,phnum=struct.unpack_from('<HH',data,54);page=os.sysconf('SC_PAGE_SIZE')
 for i in range(phnum):
  kind,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*phsize)
  if kind==1 and flags&1 and off//page*page<=mapping['offset']<(off+fs+page-1)//page*page:
   bias=mapping['start']-(va-off+mapping['offset']);return pc-bias
 raise ValueError(mapping)
locations=collections.Counter();unmapped=collections.Counter()
for ns,pc,pid,tid in rows:
 mapping=next((r for r in maps if r['start']<=pc<r['end']),None)
 if not mapping or not mapping['file'].startswith('/') or not Path(mapping['file']).is_file():unmapped[str(mapping)]+=1;continue
 locations[(mapping['file'],elf_offset(mapping,pc))]+=1
byfile=collections.defaultdict(list)
for file,offset in locations:byfile[file].append(offset)
resolved={};symbol_logs=[]
for file,offsets in byfile.items():
 args=['addr2line','-f','-C','-e',file,*map(hex,offsets)];r=subprocess.run(args,capture_output=True,text=True,timeout=60);assert r.returncode==0;lines=r.stdout.splitlines();assert len(lines)==2*len(offsets),(file,len(lines),len(offsets));symbol_logs.append(dict(file=file,command=args,stdout=r.stdout,stderr=r.stderr))
 for i,offset in enumerate(offsets):resolved[(file,offset)]=(lines[2*i],lines[2*i+1])
functions=collections.Counter();source_lines=collections.Counter();binaries=collections.Counter()
for key,count in locations.items():
 name,source=resolved[key];functions[(key[0],name)]+=count;source_lines[(key[0],name,source)]+=count;binaries[key[0]]+=count
report=dict(samples=len(rows),window=window,returncode=step['returncode'],intentional_completed_window_stop=True,unmapped=dict(unmapped),binaries=[dict(file=f,count=c) for f,c in binaries.most_common()],functions=[dict(file=f,name=n,count=c,percent=100*c/len(rows)) for (f,n),c in functions.most_common(30)],source_lines=[dict(file=f,name=n,source=s,count=c) for (f,n,s),c in source_lines.most_common(40)],limits=['I sample main-thread CPU program counters with a private10ms thread-clock timer in the original ASan allocation-campaign process. This is diagnostic instrumentation, not a correctness proof or original full-campaign acceptance. I do not infer NanoLang caller time from native PCs alone.'])
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');(p/'symbols.json').write_text(json.dumps(symbol_logs,indent=2)+'\n');print(json.dumps(dict(samples=report['samples'],functions=report['functions'][:14],lines=report['source_lines'][:12],unmapped=report['unmapped']),indent=2))
