from pathlib import Path
import subprocess,json,os,time,signal,hashlib
base=Path.cwd();out=base/'.test_output/public-array-prefix-controls-v2';root=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');artifacts=Path('/tmp/nano-record-array-public-6w9ows3j');env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',LSAN_OPTIONS='');record=dict(steps=[],deadline_seconds=120,limits=['I compare the actual original scheduled guest and the private preceding-collector guest, preserving original120-second command bounds, all original prefix/recovery assertions and identical remaining providers. These flow1 controls are not the complete profile gate.']);jobs=[]
for label,exe in [('scheduled',artifacts/'public-api-allocation-prefixes'),('preceding',out/'preceding-campaign')]:
 args=list(map(str,[exe,artifacts,'flow','1']));a=(out/(label+'-campaign.stdout')).open('wb');b=(out/(label+'-campaign.stderr')).open('wb');start=time.monotonic();p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);entry=dict(label=label,argv=args,pid=p.pid,sha256=hashlib.sha256(exe.read_bytes()).hexdigest());record['steps'].append(entry);jobs.append((p,start,entry,a,b))
(out/'campaign-comparison.json').write_text(json.dumps(record,indent=2)+'\n')
for p,start,entry,a,b in jobs:
 try:entry['returncode']=p.wait(timeout=max(0.001,120-(time.monotonic()-start)))
 except subprocess.TimeoutExpired:entry['timeout']=True;os.killpg(p.pid,signal.SIGKILL);entry['returncode']=p.wait()
 finally:a.close();b.close();entry['observed_elapsed_seconds']=time.monotonic()-start;(out/'campaign-comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['steps'])
