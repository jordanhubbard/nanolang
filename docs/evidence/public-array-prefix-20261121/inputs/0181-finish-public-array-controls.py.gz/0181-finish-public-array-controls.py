from pathlib import Path
import json,re,subprocess,os,time,hashlib,shutil
base=Path.cwd();root=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');out=base/'.test_output/public-array-prefix-controls-v2';m=json.loads((out/'manifest.json').read_text());refusal=out/'counter-rename-refusal';refusal.mkdir(exist_ok=False)
for name in ['initial-count.c','link-scheduled-count.stderr','link-scheduled-count.stdout']:
 shutil.copy2(out/name,refusal/name)
s=(out/'initial-count.c').read_text();body=s[s.index('#include <time.h>'):];original=root/'tests/nanoisa/test_record_array_public.c';text=original.read_text();needle='int main(int argc,char **argv) {';assert text.count(needle)==1;text=text.replace(needle,'int original_fault_campaign_main(int argc,char **argv) {');text=re.sub(r'#include "([^"]+)"',lambda match:'#include '+json.dumps(str((original.parent/match.group(1)).resolve())),text);(out/'original-fixture.c').write_text(text);(out/'initial-count.c').write_text('#include "original-fixture.c"\n'+body)
assert (out/'preceding/vm_ffi.c').read_bytes()==(root/'src/nanovm/vm_ffi.c').read_bytes()
record=dict(steps=[],limits=['My first count wrapper collides with the original fixture own main wrapper. I retain its exact refusal and use a private copy with only original main renamed and includes bound to the same original files. Every original assertion stays in that copy; the measuring entry executes only the original first successful step.'])
for label in ['scheduled','preceding']:
 entry=next(x for x in m['steps'] if x['label']==('link-scheduled-count' if label=='scheduled' else 'link-preceding-campaign'));argv=list(entry['argv'])
 if label=='preceding':argv[argv.index('tests/nanoisa/test_record_array_public.c')]=str(out/'initial-count.c')
 argv[argv.index('-o')+1]=str(out/(label+'-initial-count'));t=time.monotonic()
 with (out/('corrected-link-'+label+'.stdout')).open('wb') as a,(out/('corrected-link-'+label+'.stderr')).open('wb') as b:r=subprocess.run(argv,cwd=root,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'corrected-count-build.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
record['sources']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'preceding').iterdir() if p.is_file()};(out/'corrected-count-build.json').write_text(json.dumps(record,indent=2)+'\n');print('I linked both initial-count controls with all original assertions retained.')
