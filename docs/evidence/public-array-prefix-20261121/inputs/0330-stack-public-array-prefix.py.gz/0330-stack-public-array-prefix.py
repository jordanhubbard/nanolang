from pathlib import Path
import subprocess,os,signal,json,time
out=Path('.test_output/public-array-prefix-stack');out.mkdir(exist_ok=False);image='/tmp/nano-record-array-public-6w9ows3j/public-api-allocation-prefixes';args=['/usr/bin/gdb','--batch','-ex','set pagination off','-ex','set confirm off','-ex','run','-ex','thread apply all bt','-ex','quit','--args',image,str(out.resolve()),'flow','1'];t=time.monotonic()
with (out/'stack.log').open('wb') as f:
 p=subprocess.Popen(args,stdout=f,stderr=f,env=dict(os.environ,PATH='/usr/bin:/bin'),start_new_session=True)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:
  os.kill(p.pid,signal.SIGINT)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
(out/'manifest.json').write_text(json.dumps(dict(argv=args,returncode=p.returncode,elapsed_seconds=time.monotonic()-t,limits=['I interrupt one private ptraced diagnostic after ten seconds. Its stack is not guest deadline qualification or sanitizer completion.']),indent=2)+'\n')
