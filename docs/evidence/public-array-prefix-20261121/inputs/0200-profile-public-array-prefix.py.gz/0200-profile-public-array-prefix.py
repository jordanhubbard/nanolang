from pathlib import Path
import os,subprocess,json,time,signal,hashlib,shutil
base=Path.cwd();out=base/'.test_output/public-array-prefix-cpu';out.mkdir(exist_ok=False)
root=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121')
helper=out/'sampler.so';shutil.copy2(base/'.test_output/cpu-timer-sampler.c',out/'sampler.c')
subprocess.run(['/usr/bin/cc','-Wall','-Wextra','-Werror','-std=c11','-O2','-g','-shared','-fPIC',str(out/'sampler.c'),'-o',str(helper),'-lrt'],check=True)
asan=subprocess.check_output(['/usr/bin/cc','-print-file-name=libasan.so'],text=True).strip()
manifest={'limits':['I sample the actual original allocation campaign with private CPU-timer instrumentation and first preload the selected ASan runtime. I preserve the original campaign image, assertions, loops and fault coverage. My 30-second profile is not 120-second acceptance.'],'steps':[]}
for label,image,args,limit in [('control',base/'.test_output/public-array-prefix-controls-v2/initial-count-scheduled',[],10),('campaign',Path('/tmp/nano-record-array-public-6w9ows3j/public-api-allocation-prefixes'),[str(out),'flow','1'],30)]:
 if not image.exists() and label=='control':
  m=json.loads((base/'.test_output/public-array-prefix-controls-v2/corrected-count-build.json').read_text());image=Path(next(x for x in m['steps'] if x['label']=='scheduled')['argv'][-1])
 env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',LD_PRELOAD=asan+':'+str(helper),NANO_CPU_PROFILE_TARGET=str(image),NANO_CPU_PROFILE_OUTPUT=str(out/(label+'.bin')),NANO_CPU_PROFILE_STATUS=str(out/(label+'.status.json')),LSAN_OPTIONS='')
 args=[str(image)]+args;t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True)
  try:(out/(label+'.maps')).write_text(Path('/proc')/str(p.pid)/'maps' and (Path('/proc')/str(p.pid)/'maps').read_text())
  except FileNotFoundError:pass
  r={'label':label,'argv':args,'pid':p.pid,'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest()}
  try:r['returncode']=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:r['intentional_window_stop']=True;os.killpg(p.pid,signal.SIGKILL);r['returncode']=p.wait()
  r['elapsed_seconds']=time.monotonic()-t;manifest['steps'].append(r);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  if label=='control':assert r['returncode']==0,r
print(json.dumps(manifest))
