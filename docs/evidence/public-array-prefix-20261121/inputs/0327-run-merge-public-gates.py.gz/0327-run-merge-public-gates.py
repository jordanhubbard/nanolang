from pathlib import Path
import os,subprocess,time,signal,json,hashlib
root=Path.cwd();out=root/'.test_output/merge-public-gates';out.mkdir(exist_ok=False);args=['make','CC=/usr/bin/cc','test-record-array-public','test-record-map-public'];env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',LSAN_OPTIONS='');record={'argv':args,'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sources':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['src/nanoisa/managed_array_shapes.c','src/nanoisa/record_array_origins.inc','src/nanoisa/union_field_analysis.inc','tests/test_record_array_public.py','tests/test_record_map_public.py']},'limits':['I run complete original public ARRAY/MAP targets with all assertions, sanitizer instrumentation, allocation prefixes and120-second per-guest deadlines unchanged. My driver bound is separate. I preserve the frozen c908523c3 bootstrap checkout.']};t=time.monotonic()
with (out/'original.stdout').open('wb') as a,(out/'original.stderr').open('wb') as b:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);record['pid']=p.pid;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 try:record['returncode']=p.wait(timeout=3600)
 except subprocess.TimeoutExpired:record['driver_timeout']=True;os.killpg(p.pid,signal.SIGKILL);record['returncode']=p.wait()
record['elapsed_seconds']=time.monotonic()-t;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
