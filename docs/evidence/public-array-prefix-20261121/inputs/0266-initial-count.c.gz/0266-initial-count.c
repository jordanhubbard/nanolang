#define main original_fault_campaign_main
#include "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/tests/nanoisa/test_record_array_public.c"
#undef main
#include <time.h>
static double seconds(void){struct timespec t;CHECK(clock_gettime(CLOCK_MONOTONIC,&t)==0);return (double)t.tv_sec+(double)t.tv_nsec/1000000000.0;}
int main(void){double t=seconds();Input c;fputs("I begin the original flow1 count control.\n",stderr);public_flow(&c,TAG_INT,0);fprintf(stderr,"I finish fixture at %.6f seconds.\n",seconds()-t);CHECK(ra_live==0 && ra_bytes==0);VmState vm;vm_init(&vm,&c.m);fprintf(stderr,"I finish init at %.6f seconds.\n",seconds()-t);ra_calls=0;CHECK(vm_execute(&vm)==VM_OK);size_t total=ra_calls;fprintf(stderr,"I finish execute at %.6f seconds.\n",seconds()-t);vm_destroy(&vm);CHECK(ra_live==0 && ra_bytes==0);printf("allocations=%zu peak=%zu elapsed=%.6f\n",total,ra_peak,seconds()-t);return 0;}
