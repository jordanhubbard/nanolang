include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(NANOISA_OBJECTS) $(NANOISA_UTF8)
	@printf '%s\n' '$(NANOISA_OBJECTS) $(NANOISA_UTF8)' > /home/jkh/nanolang-qualification/sdk-description-435-linux/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/sdk-description-435-linux/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/sdk-description-435-linux/ordinary/ldflags.txt
