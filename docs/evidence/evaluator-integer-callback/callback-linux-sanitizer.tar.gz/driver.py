import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();config=sys.argv[3];report.mkdir(exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path(__file__).with_name('supervisor.py');tree=ast.parse(base.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','write','inventory','run')];assert len(nodes)==4
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));
for node in nodes:
 if node.name=='run':
  for item in node.body:
   if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets):item.value=ast.Constant(value=1200)
module=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(module,str(base),'exec'));(report/'effective-supervisor.py').write_text(ast.unparse(module));shutil.copyfile(__file__,report/'driver.py')
files=(root/'.qualification-tracked').read_text().splitlines()
def source():return {p:sha(root/p) for p in files}
darwin=sys.platform=='darwin'
cc=('/opt/homebrew/opt/llvm/bin/clang' if config=='sanitizer' else '/usr/bin/clang') if darwin else '/usr/bin/gcc'
paths={n:shutil.which(n) for n in ('make','ar','ld','nm','ps','python3')};paths.update(compiler=cc,driver=__file__,supervisor=str(base),driver_python=sys.executable)
if darwin:
 paths.update(xcrun='/usr/bin/xcrun',libcrypto='/opt/homebrew/opt/openssl@3/lib/libcrypto.dylib')
 paths['compiler_actual']=subprocess.check_output(['xcrun','--find','clang'],text=True).strip() if config=='ordinary' else cc
else:
 for n in ('cc1','collect2','libasan.so','libubsan.so'):
  p=subprocess.check_output([cc,('-print-prog-name=' if n in ('cc1','collect2') else '-print-file-name=')+n],text=True).strip()
  if Path(p).is_file():paths[n]=p
def tools():return {n:{'path':str(Path(p).resolve()),'sha256':sha(p)} for n,p in paths.items()}
phases=set();results=[]
os.environ['ASAN_OPTIONS']='detect_leaks=1';os.environ['UBSAN_OPTIONS']='halt_on_error=1';os.environ['LSAN_OPTIONS']=''
flags='-Wall -Wextra -Werror -std=c99 -g -Isrc -D_GNU_SOURCE';link='-lm -lcrypto'
if darwin:
 sdk=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip();flags+=' -isysroot '+sdk+' -I/opt/homebrew/opt/openssl@3/include';link+=' -L/opt/homebrew/opt/openssl@3/lib';write('sdk.json',{'path':sdk,'version':subprocess.check_output(['xcrun','--show-sdk-version'],text=True).strip()})
if config=='sanitizer':flags+=' -fsanitize=address,undefined -fno-omit-frame-pointer';link+=' -fsanitize=address,undefined'
write('attribution.json',{'source':'dfd7e53a3cb5b4499708e8ae6c798f5c5dc88f31','config':config,'phase_bound':1200,'instrumentation':config,'LSan':True})


controls=report/'controls';controls.mkdir();shims=controls/'shims';shims.mkdir();shim=shims/'rm'
shim.write_text('#!'+sys.executable+'\n'+"import os,sys,shutil,hashlib,json\nfrom pathlib import Path\nsource=Path(os.environ['QUALIFIED_INNER_BINARY']).resolve()\nif source.exists() and any(Path(a).resolve()==source for a in sys.argv[1:] if not a.startswith('-')):\n dest=Path(os.environ['QUALIFIED_RETAIN_DIR']);dest.mkdir(parents=True,exist_ok=True)\n digest=hashlib.file_digest(source.open('rb'),'sha256').hexdigest()\n shutil.copy2(source,dest/source.name)\n assert hashlib.file_digest((dest/source.name).open('rb'),'sha256').hexdigest()==digest\n (dest/'retention.json').write_text(json.dumps({'source':str(source),'argv':sys.argv[1:],'sha256':digest,'bytes':source.stat().st_size,'mode':source.stat().st_mode&511},indent=2)+'\\n')\nos.execv('/bin/rm',['/bin/rm',*sys.argv[1:]])\n")
shim.chmod(0o755);paths.update(removal_wrapper=str(shim),real_rm='/bin/rm')
os.environ['PATH']=str(shims)+os.pathsep+os.environ['PATH']
os.environ['QUALIFIED_INNER_BINARY']=str(root/'tests/test_integer_negation_eval');os.environ['QUALIFIED_RETAIN_DIR']=str(controls/'retained')

for target in ('test-integer-negation-eval',):
 run(target,['make','-j2',target,'CC='+cc,'CFLAGS='+flags,'LDFLAGS='+link])
write('final.json',{'status':'PASS','results':results})
