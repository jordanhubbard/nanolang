/* I invoke the actual production qualification predicate with retained reports. */
#include "/home/jkh/.worktrees/nanolang/service-module-integration/src/module_builder.c"
int main(int argc, char **argv) {
    if (argc != 3) return 97;
    for (int i = 1; i < argc; ++i) {
        FILE *file = fopen(argv[i], "rb");
        if (!file) return 98;
        char version[8193];
        size_t size = fread(version, 1, sizeof(version)-1, file);
        if (ferror(file) || !feof(file) || fclose(file)) return 99;
        version[size] = 0;
        printf("%d\n", module_assembler_version_supported(version));
    }
    return 0;
}
