include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	@printf '%s\n' '$(COMMON_OBJECTS) $(RUNTIME_OBJECTS)' > /home/jkh/nanolang-qualification/record-names-51d-linux/sanitized/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/record-names-51d-linux/sanitized/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/record-names-51d-linux/sanitized/ldflags.txt
