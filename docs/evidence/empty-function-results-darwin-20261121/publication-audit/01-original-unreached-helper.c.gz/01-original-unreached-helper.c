I retain my prior output.
