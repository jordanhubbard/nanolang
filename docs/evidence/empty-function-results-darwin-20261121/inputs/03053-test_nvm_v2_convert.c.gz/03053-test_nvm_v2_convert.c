/*
 * Unit tests for the NvmModule <-> v2 bridge.
 *
 * The bridge is what lets v2 be adopted without rewriting every producer at
 * once, so what matters is fidelity: a v1 module converted to v2, serialized,
 * read back, and converted to v1 again must be the same module. The two places
 * that can silently lose information are the string pool -- v1 strings carry
 * explicit lengths and may hold embedded zero bytes -- and the signature table,
 * where deduplication has to be exact or signature-index comparison stops being
 * a valid equality test.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "nvm_v2_sections.h"
#include "nvm_format.h"
#include "isa.h"
#include "verifier.h"

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, what) do { \
    if (cond) { g_pass++; } \
    else { g_fail++; printf("  FAIL: %s  (%s:%d)\n", (what), __FILE__, __LINE__); } \
} while (0)

#define CHECK_RESULT(actual, expected, what) do { \
    NvmV2Result _a = (actual), _e = (expected); \
    if (_a == _e) { g_pass++; } \
    else { g_fail++; printf("  FAIL: %s -- expected %s, got %s  (%s:%d)\n", \
        (what), nvm_v2_result_name(_e), nvm_v2_result_name(_a), __FILE__, __LINE__); } \
} while (0)

/* A v1 module with two identically-shaped functions, one differently-shaped,
 * an import, a module ref, a debug entry, and a string holding a zero byte. */
static NvmModule *build_v1(void) {
    NvmModule *m = nvm_module_new();
    if (!m) return NULL;

    uint32_t s_add  = nvm_add_string(m, "add", 3);
    uint32_t s_sub  = nvm_add_string(m, "sub", 3);
    uint32_t s_main = nvm_add_string(m, "main", 4);
    uint32_t s_bin  = nvm_add_string(m, "a\0b", 3);   /* embedded zero */
    uint32_t s_libc = nvm_add_string(m, "libc", 4);
    uint32_t s_puts = nvm_add_string(m, "puts", 4);
    (void)s_bin;

    static const uint8_t code[12] = { 1,2,3,4,5,6,7,8,9,10,11,12 };
    nvm_append_code(m, code, sizeof code);

    /* add and sub have the same shape; main differs. */
    NvmFunctionEntry f;
    memset(&f, 0, sizeof f);
    f.name_idx = s_add; f.arity = 2; f.code_offset = 0; f.code_length = 4;
    f.local_count = 2; f.upvalue_count = 0;
    f.result_tag = TAG_INT; f.result_count = 1;
    nvm_add_function(m, &f);

    f.name_idx = s_sub; f.code_offset = 4; f.code_length = 4;
    nvm_add_function(m, &f);

    memset(&f, 0, sizeof f);
    f.name_idx = s_main; f.arity = 0; f.code_offset = 8; f.code_length = 4;
    f.local_count = 1; f.upvalue_count = 0;
    f.result_tag = TAG_VOID; f.result_count = 0;
    nvm_add_function(m, &f);

    const uint8_t ptypes[1] = { TAG_STRING };
    nvm_add_import(m, s_libc, s_puts, 1, TAG_INT, ptypes);

    nvm_add_module_ref(m, s_libc);
    nvm_add_debug_entry(m, 0, 17, 3);
    m->header.entry_point = 2;   /* main */
    m->header.flags = NVM_FLAG_HAS_MAIN | NVM_FLAG_NEEDS_EXTERN |
                      NVM_FLAG_DEBUG_INFO;
    m->struct_count = 2;
    m->enum_count = 1;
    m->union_count = 3;
    return m;
}

/* Every v1 header flag restates something v2 encodes structurally, so the
 * bridge derives them rather than carrying them. Getting this wrong is not
 * subtle: without HAS_MAIN the VM refuses the module outright with "No entry
 * point defined", which is exactly how the gap was found. */
static void test_header_flags_are_derived(void) {
    NvmModule *v1 = build_v1();
    if (!v1) { g_fail++; printf("  FAIL: fixture\n"); return; }
    NvmV2Module v2;
    NvmModule *back = NULL;
    nvm_v2_from_nvm_module(v1, &v2);
    CHECK_RESULT(nvm_v2_to_nvm_module(&v2, &back), NVM_V2_OK, "converts back");
    if (back) {
        CHECK((back->header.flags & NVM_FLAG_HAS_MAIN) != 0,
              "HAS_MAIN comes back from the presence of an entry point");
        CHECK((back->header.flags & NVM_FLAG_NEEDS_EXTERN) != 0,
              "NEEDS_EXTERN comes back from the import table");
        CHECK((back->header.flags & NVM_FLAG_DEBUG_INFO) != 0,
              "DEBUG_INFO comes back from the debug table");
        CHECK(back->struct_count == 2 && back->enum_count == 1 &&
              back->union_count == 3,
              "the type-definition counts the verifier bounds against survive");
        nvm_module_free(back);
    } else { g_fail += 4; printf("  FAIL: no module\n"); }
    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

/* A module with no main leaves entry_point at 0 and clears the flag. Reading
 * the field alone would make it claim function 0 as its entry. */
static void test_a_module_without_main_gains_no_entry_point(void) {
    NvmModule *v1 = build_v1();
    if (!v1) { g_fail++; printf("  FAIL: fixture\n"); return; }
    v1->header.flags &= ~(uint32_t)NVM_FLAG_HAS_MAIN;
    v1->header.entry_point = 0;
    NvmV2Module v2;
    nvm_v2_from_nvm_module(v1, &v2);
    CHECK(v2.entry_point == NVM_V2_NO_ENTRY_POINT,
          "a main-less module does not claim function 0 as its entry");
    NvmModule *back = NULL;
    nvm_v2_to_nvm_module(&v2, &back);
    if (back) {
        CHECK((back->header.flags & NVM_FLAG_HAS_MAIN) == 0,
              "and does not gain HAS_MAIN on the way back");
        nvm_module_free(back);
    } else { g_fail++; printf("  FAIL: no module\n"); }
    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

static void test_round_trip_through_v2(void) {
    NvmModule *v1 = build_v1();
    CHECK(v1 != NULL, "the v1 fixture builds");
    if (!v1) return;

    NvmV2Module v2;
    CHECK_RESULT(nvm_v2_from_nvm_module(v1, &v2), NVM_V2_OK, "converts to v2");

    size_t need = 0;
    CHECK_RESULT(nvm_v2_module_serialize(&v2, NULL, 0, &need), NVM_V2_OK, "sizes");
    uint8_t *buf = malloc(need);
    CHECK(buf != NULL, "allocates");
    if (!buf) { nvm_v2_module_free(&v2); nvm_module_free(v1); return; }

    size_t n = 0;
    CHECK_RESULT(nvm_v2_module_serialize(&v2, buf, need, &n), NVM_V2_OK, "serializes");

    /* Everything the bridge produced must satisfy the same cross-section rules
     * a hand-built module does -- otherwise the bridge is a way to smuggle an
     * invalid module past the validator. */
    NvmV2Module back;
    CHECK_RESULT(nvm_v2_module_deserialize(buf, n, &back), NVM_V2_OK,
                 "the converted module passes cross-section validation");

    NvmModule *v1b = NULL;
    CHECK_RESULT(nvm_v2_to_nvm_module(&back, &v1b), NVM_V2_OK, "converts back to v1");
    CHECK(v1b != NULL, "produces a v1 module");

    if (v1b) {
        CHECK(v1b->function_count == 3, "three functions survive");
        CHECK(v1b->import_count == 1, "one import survives");
        CHECK(v1b->module_ref_count == 1, "one module ref survives");
        CHECK(v1b->code_size == 12, "the code section survives");
        CHECK(v1b->debug_count == 1, "the debug entry survives");
        CHECK(v1b->header.entry_point == 2, "the entry point survives");

        if (v1b->function_count == 3) {
            CHECK(v1b->functions[0].arity == 2, "arity survives");
            CHECK(v1b->functions[0].result_tag == TAG_INT, "result tag survives");
            CHECK(v1b->functions[0].result_count == 1, "result count survives");
            CHECK(v1b->functions[2].result_count == 0, "a void function stays void");
            CHECK(v1b->functions[1].code_offset == 4, "code offsets survive");
            CHECK(v1b->functions[0].local_count == 2, "local count survives");
        } else { g_fail += 6; printf("  FAIL: function table did not survive\n"); }

        /* The embedded zero is the whole reason the string pool carries
         * explicit lengths; strlen would have truncated this to one byte. */
        bool found_binary = false;
        for (uint32_t i = 0; i < v1b->string_count; i++) {
            if (v1b->string_lengths[i] == 3 &&
                memcmp(v1b->strings[i], "a\0b", 3) == 0) { found_binary = true; break; }
        }
        CHECK(found_binary, "a string with an embedded zero survives the round trip");

        if (v1b->import_count == 1) {
            CHECK(v1b->imports[0].param_count == 1, "import arity survives");
            CHECK(v1b->imports[0].return_type == TAG_INT, "import return type survives");
            CHECK(v1b->import_param_types && v1b->import_param_types[0] &&
                  v1b->import_param_types[0][0] == TAG_STRING,
                  "import parameter tags survive");
        } else { g_fail += 3; printf("  FAIL: import did not survive\n"); }

        nvm_module_free(v1b);
    }

    nvm_v2_module_free(&back);
    free(buf);
    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

static void test_identical_shapes_share_a_signature(void) {
    NvmModule *v1 = build_v1();
    if (!v1) { g_fail++; printf("  FAIL: fixture\n"); return; }

    NvmV2Module v2;
    CHECK_RESULT(nvm_v2_from_nvm_module(v1, &v2), NVM_V2_OK, "converts");

    CHECK(v2.functions.count == 3, "three functions");
    if (v2.functions.count == 3) {
        CHECK(v2.functions.items[0].signature_idx == v2.functions.items[1].signature_idx,
              "two identically-shaped functions share one signature entry");
        CHECK(v2.functions.items[0].signature_idx != v2.functions.items[2].signature_idx,
              "a differently-shaped function gets its own");
    } else { g_fail += 2; printf("  FAIL: functions missing\n"); }

    /* add/sub, main, and the import's (string)->int shape: three distinct
     * signatures, not five. If dedup were incomplete the count would rise and
     * comparing signature indices would stop meaning "same type". */
    CHECK(v2.signatures.count == 3, "exactly three distinct signatures are emitted");

    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

static void test_empty_module_converts(void) {
    NvmModule *v1 = nvm_module_new();
    if (!v1) { g_fail++; printf("  FAIL: fixture\n"); return; }
    NvmV2Module v2;
    CHECK_RESULT(nvm_v2_from_nvm_module(v1, &v2), NVM_V2_OK, "an empty module converts");
    CHECK(v2.functions.count == 0, "no functions");
    CHECK(v2.entry_point == NVM_V2_NO_ENTRY_POINT,
          "an empty module has no entry point rather than function 0");

    uint8_t buf[512]; size_t n = 0;
    CHECK_RESULT(nvm_v2_module_serialize(&v2, buf, sizeof buf, &n), NVM_V2_OK,
                 "and serializes");
    NvmV2Module back;
    CHECK_RESULT(nvm_v2_module_deserialize(buf, n, &back), NVM_V2_OK,
                 "and reads back");
    nvm_v2_module_free(&back);
    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

/* The producer computes the operand depth and the loader confirms it. The
 * fixture's bytecode is arbitrary bytes rather than real instructions, so the
 * verifier rejects it -- which is the case worth pinning: a function with no
 * honest depth declares 0, meaning "nothing to check", instead of a guess that
 * the confirming side would then enforce. */
static void test_an_unverifiable_function_declares_no_depth(void) {
    NvmModule *v1 = build_v1();
    if (!v1) { g_fail++; printf("  FAIL: fixture\n"); return; }
    NvmV2Module v2;
    nvm_v2_from_nvm_module(v1, &v2);
    for (uint32_t i = 0; i < v2.functions.count; i++) {
        uint16_t declared = v2.functions.items[i].max_stack;
        uint16_t computed = 0;
        bool verifies = nvm_verify_function_max_stack(v1, i, &computed).ok;
        CHECK(verifies ? declared == computed : declared == 0,
              verifies ? "a verifiable function declares the depth the verifier computes"
                       : "an unverifiable function declares 0 rather than a guess");
    }
    nvm_v2_module_free(&v2);
    nvm_module_free(v1);
}

static void test_import_kinds_and_bindings(void) {
    NvmModule *m = nvm_module_new();
    const char *path = "/cache/.nano-gen-abcdef/libanswer.so";
    uint32_t p = nvm_add_string(m, path, (uint32_t)strlen(path));
    uint32_t f = nvm_add_string(m, "answer", 6);
    nvm_add_import(m, p, f, 0, TAG_INT, NULL);
    for (uint8_t kind = NVM_IMPORT_FFI; kind <= NVM_IMPORT_ARTIFACT; kind++) {
        m->imports[0].kind = kind;
        NvmV2Module v2;
        CHECK_RESULT(nvm_v2_from_nvm_module(m, &v2), NVM_V2_OK, "I convert the import kind");
        uint8_t bytes[2048]; size_t size = 0;
        CHECK_RESULT(nvm_v2_module_serialize(&v2, bytes, sizeof bytes, &size), NVM_V2_OK,
                     "I serialize the import kind");
        NvmV2Module decoded;
        CHECK_RESULT(nvm_v2_module_deserialize(bytes, size, &decoded), NVM_V2_OK,
                     "I decode the import kind");
        NvmModule *back = NULL;
        CHECK_RESULT(nvm_v2_to_nvm_module(&decoded, &back), NVM_V2_OK, "I restore the import kind");
        if (back) {
            CHECK(back->imports[0].kind == kind, "I preserve the kind");
            CHECK(strcmp(nvm_get_string(back, back->imports[0].module_name_idx), path) == 0,
                  "I preserve the exact artifact path");
            nvm_module_free(back);
        }
        uint32_t legacy_size = 99;
        uint8_t *legacy = nvm_serialize(m, &legacy_size);
        CHECK(kind == NVM_IMPORT_FFI ? legacy != NULL : legacy == NULL && legacy_size == 0,
              "I reject lossy legacy output");
        free(legacy);
        nvm_v2_module_free(&decoded);
        nvm_v2_module_free(&v2);
    }
    const char *invalid[] = {"relative.so", "", "/a\0hidden"};
    uint32_t lengths[] = {11, 0, 9};
    for (int i = 0; i < 3; i++) {
        m->imports[0].module_name_idx = nvm_add_string(m, invalid[i], lengths[i]);
        CHECK(!nvm_verify(m).ok, "I reject an invalid artifact path in memory");
        NvmV2Module v2;
        CHECK_RESULT(nvm_v2_from_nvm_module(m, &v2), NVM_V2_OK, "I construct invalid path fixture");
        uint8_t bytes[2048]; size_t size = 0;
        CHECK_RESULT(nvm_v2_module_serialize(&v2, bytes, sizeof bytes, &size), NVM_V2_OK,
                     "I encode the invalid fixture");
        NvmV2Module decoded;
        CHECK(nvm_v2_module_deserialize(bytes, size, &decoded) != NVM_V2_OK,
              "I reject an invalid artifact path while loading");
        nvm_v2_module_free(&v2);
    }
    nvm_module_free(m);
}

static void test_parameter_tags_survive(void) {
    NvmModule *m = build_v1();
    CHECK(m != NULL, "I allocate a typed signature fixture");
    if (!m) return;
    uint8_t first[] = {TAG_INT, TAG_FLOAT};
    uint8_t second[] = {TAG_FLOAT, TAG_INT};
    CHECK(nvm_set_function_param_types(m, 0, first, 2), "I accept declared parameters");
    CHECK(nvm_set_function_param_types(m, 1, second, 2), "I accept distinct parameters");
    first[0] = TAG_BOOL;
    CHECK(m->function_param_types[0][0] == TAG_INT, "I own a copy of the declaration");
    CHECK(!nvm_set_function_param_types(m, 0, first, 1), "I reject wrong arity");
    CHECK(!nvm_set_function_param_types(m, 0, NULL, 2), "I reject missing tags");
    first[0] = TAG_COUNT;
    CHECK(!nvm_set_function_param_types(m, 0, first, 2), "I reject invalid tags");
    CHECK(m->function_param_types[0][0] == TAG_INT, "I preserve tags after rejected updates");
    CHECK(!nvm_set_function_param_types(m, UINT32_MAX, first, 2), "I reject invalid functions");
    NvmV2Module v2;
    CHECK_RESULT(nvm_v2_from_nvm_module(m, &v2), NVM_V2_OK, "I convert typed functions");
    CHECK(v2.functions.items[0].signature_idx != v2.functions.items[1].signature_idx,
          "I do not intern distinct parameter types as the same signature");
    size_t length = 0;
    CHECK_RESULT(nvm_v2_module_serialize(&v2, NULL, 0, &length), NVM_V2_OK, "I size typed bytes");
    uint8_t *bytes = malloc(length);
    CHECK(bytes != NULL, "I allocate typed bytes");
    if (bytes) {
        CHECK_RESULT(nvm_v2_module_serialize(&v2, bytes, length, &length), NVM_V2_OK,
                     "I serialize typed signatures");
        NvmV2Module decoded;
        NvmV2Result r = nvm_v2_module_deserialize(bytes, length, &decoded);
        CHECK_RESULT(r, NVM_V2_OK, "I decode typed signatures");
        if (r == NVM_V2_OK) {
            NvmModule *back = NULL;
            CHECK_RESULT(nvm_v2_to_nvm_module(&decoded, &back), NVM_V2_OK,
                         "I restore typed signatures to the execution module");
            if (back) {
                CHECK(back->function_param_types[0][0] == TAG_INT &&
                      back->function_param_types[0][1] == TAG_FLOAT &&
                      back->function_param_types[1][0] == TAG_FLOAT &&
                      back->function_param_types[1][1] == TAG_INT,
                      "I preserve exact parameter order across the wire");
                nvm_module_free(back);
            }
            nvm_v2_module_free(&decoded);
        }
        free(bytes);
    }
    nvm_v2_module_free(&v2);
    /* I cross multiple capacity boundaries without losing earlier tags. */
    NvmFunctionEntry f = m->functions[0];
    for (unsigned i = 0; i < 100; i++) {
        uint32_t idx = nvm_add_function(m, &f);
        CHECK(idx == i + 3, "I grow the function table");
        CHECK(nvm_set_function_param_types(m, idx, second, 2), "I populate a grown tag slot");
    }
    CHECK(m->function_param_types[0][0] == TAG_INT &&
          m->function_param_types[102][0] == TAG_FLOAT, "I preserve old and new tags during growth");
    nvm_module_free(m);
}

static void test_reused_signature_pool_keeps_undeclared_parameters_void(void) {
    NvmModule *m = nvm_module_new();
    CHECK(m != NULL, "I allocate the signature reuse fixture");
    if (!m) return;
    const uint8_t code[] = {OP_PUSH_I64, 0,0,0,0,0,0,0,0, OP_RET};
    CHECK(nvm_append_code(m, code, sizeof code) == 0, "I retain one valid shared body");
    const uint16_t arities[] = {2, 2, 3, 3, 4};
    const uint8_t declared[] = {TAG_STRING, TAG_BOOL};
    for (uint32_t i = 0; i < 5; ++i) {
        char name[32];
        snprintf(name, sizeof name, "signature_%u", i);
        NvmFunctionEntry f = {0};
        f.name_idx = nvm_add_string(m, name, (uint32_t)strlen(name));
        f.arity = f.local_count = arities[i];
        f.code_length = sizeof code;
        f.result_tag = TAG_INT; f.result_count = 1;
        CHECK(nvm_add_function(m, &f) == i, "I retain fixture function order");
        if (i < 2) CHECK(nvm_set_function_param_types(m, i, declared, 2),
                         "I declare only the first duplicate pair's tags");
    }
    uint32_t library = nvm_add_string(m, "fixture", 7);
    for (uint32_t i = 0; i < 3; ++i) {
        char name[32]; snprintf(name, sizeof name, "import_%u", i);
        uint32_t symbol = nvm_add_string(m, name, (uint32_t)strlen(name));
        CHECK(nvm_add_import(m, library, symbol, (uint16_t)(i + 2), TAG_INT,
                             i == 0 ? declared : NULL) == i,
              "I mix declared and absent import parameters after duplicate functions");
    }
    NvmV2Module v2;
    CHECK_RESULT(nvm_v2_from_nvm_module(m, &v2), NVM_V2_OK, "I convert reused signature storage");
    CHECK(v2.signatures.count == 3, "I intern both duplicate pairs exactly");
    for (uint32_t i = 0; i < 5; ++i) {
        const NvmV2Signature *sig = &v2.signatures.items[v2.functions.items[i].signature_idx];
        CHECK(sig->param_count == arities[i], "I preserve each arity");
        for (uint16_t p = 0; p < arities[i]; ++p)
            CHECK(sig->param_tags[p] == (i < 2 ? declared[p] : TAG_VOID),
                  "I never turn stale result or declaration bytes into parameter evidence");
    }
    for (uint32_t i = 0; i < 3; ++i) {
        const NvmV2Signature *sig = &v2.signatures.items[v2.imports.items[i].signature_idx];
        for (uint16_t p = 0; p < i + 2; ++p)
            CHECK(sig->param_tags[p] == (i == 0 ? declared[p] : TAG_VOID),
                  "I never invent import ABI tags from rewound storage");
    }
    size_t size = 0, used = 0;
    CHECK_RESULT(nvm_v2_module_serialize(&v2, NULL, 0, &size), NVM_V2_OK, "I size the wire round trip");
    uint8_t *bytes = malloc(size);
    CHECK(bytes != NULL, "I allocate the wire round trip");
    if (bytes) {
        CHECK_RESULT(nvm_v2_module_serialize(&v2, bytes, size, &used), NVM_V2_OK,
                     "I serialize exact and absent declarations");
        NvmV2Module decoded;
        CHECK_RESULT(nvm_v2_module_deserialize(bytes, used, &decoded), NVM_V2_OK,
                     "I decode exact and absent declarations");
        NvmModule *back = NULL;
        CHECK_RESULT(nvm_v2_to_nvm_module(&decoded, &back), NVM_V2_OK,
                     "I restore exact and absent declarations");
        if (back) {
            for (uint32_t i = 0; i < 5; ++i)
                for (uint16_t p = 0; p < arities[i]; ++p)
                    CHECK(back->function_param_types[i][p] == (i < 2 ? declared[p] : TAG_VOID),
                          "I preserve parameter proof boundaries across the wire");
            for (uint32_t i = 0; i < 3; ++i)
                for (uint16_t p = 0; p < i + 2; ++p)
                    CHECK(back->import_param_types[i][p] == (i == 0 ? declared[p] : TAG_VOID),
                          "I preserve absent import tags across the wire");
            nvm_module_free(back);
        }
        nvm_v2_module_free(&decoded);
        free(bytes);
    }
    nvm_v2_module_free(&v2);
    nvm_module_free(m);
}

int main(void) {
    printf("\n[nvm_v2_convert] NvmModule <-> v2 bridge tests...\n\n");
    test_round_trip_through_v2();
    test_parameter_tags_survive();
    test_reused_signature_pool_keeps_undeclared_parameters_void();
    test_import_kinds_and_bindings();
    test_header_flags_are_derived();
    test_a_module_without_main_gains_no_entry_point();
    test_identical_shapes_share_a_signature();
    test_empty_module_converts();
    test_an_unverifiable_function_declares_no_depth();
    printf("\n=== %d passed, %d failed ===\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
