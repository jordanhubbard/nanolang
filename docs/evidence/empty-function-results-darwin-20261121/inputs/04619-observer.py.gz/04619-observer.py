from pathlib import Path
import sys,os,subprocess,json,hashlib,time,signal,traceback,shutil,platform
pin=sys.argv[1];expected_path=Path(sys.argv[2]);primary=Path('/Users/jkh/Src/nanolang')
root=Path('/Users/jkh/.worktrees/nanolang/empty-function-results-20261121')
out=root.with_name(root.name+'-control');assert not root.exists() and not out.exists()
out.mkdir(parents=True);shutil.copy2(__file__,out/'observer.py');shutil.copy2(expected_path,out/'expected-sources.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
record=dict(pin=pin,root=str(root),controller_pid=os.getpid(),python=sys.version,platform=platform.platform(),steps=[],status='running',limits=['I qualify the empty-result structural repair through the original complete public-verifier/VM gates and four product methods including five source routes in a separate sparse checkout. Only docs/evidence is excluded; all3559 guarded source/test/spec/Make inputs must match Linux exactly. I use the actual frozen bdffa4ccc qualified native Stage1; this is not a new current-head bootstrap or installed-isolation test. Ordinary shadows retain10 seconds. I preserve every existing frozen root, primary dirty work and stashes. The peer released heavy-gate deferral after its terminal c908 run.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def git(*args,cwd=primary):return subprocess.check_output(['git',*args],cwd=cwd)
def primary_guard():
 paths=git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0');files={}
 for raw in paths:
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','HEAD')),cached=sha(git('diff','--cached','--binary','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)
original=primary_guard();record['primary_before']=original;save()
base_env=dict(os.environ,PATH='/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',MAKEFLAGS='-j1')
def step(name,args,cwd,env=base_env,timeout=3600):
 item=dict(name=name,argv=list(map(str,args)),cwd=str(cwd));record['steps'].append(item);save();started=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=a,stderr=b,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['elapsed_seconds']=time.monotonic()-started;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError(f'{name} failed with {item["returncode"]}')
 return item
expected=json.loads(expected_path.read_text())
def sources():
 actual={name:sha((root/name).read_bytes()) for name in expected};assert actual==expected,[name for name in expected if actual[name]!=expected[name]]
 return actual
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=None;tools={}
def guards():
 assert sources()==expected
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 if tools:assert {name:sha((root/name).read_bytes()) for name in tools}==tools
 assert primary_guard()==original
try:
 origin='git@github.com:jordanhubbard/nanolang.git'
 step('clone',['git','clone','--shared','--no-checkout',primary,root],primary,timeout=600)
 step('origin',['git','remote','set-url','origin',origin],root,timeout=60)
 step('promisor',['git','config','remote.origin.promisor','true'],root,timeout=60)
 step('filter',['git','config','remote.origin.partialclonefilter','blob:none'],root,timeout=60)
 step('fetch',['git','fetch','--filter=blob:none','--no-tags','origin',pin],root,timeout=600)
 step('sparse-init',['git','sparse-checkout','init','--no-cone'],root,timeout=60)
 patterns=Path(git('rev-parse','--git-path','info/sparse-checkout',cwd=root).decode().strip())
 if not patterns.is_absolute():patterns=root/patterns
 patterns.write_text('/*\n!/docs/evidence/\n')
 step('checkout',['git','checkout','--detach',pin],root,timeout=600)
 assert git('rev-parse','HEAD',cwd=root).decode().strip()==pin
 record['source_hashes']=sources();record['source_map_sha256']=sha(expected_path.read_bytes());save()
 sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
 b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 compiler=frozen/'bin/nanoc_stage1';record['provider']=dict(pin=git('rev-parse','HEAD',cwd=frozen).decode().strip(),compiler=str(compiler),compiler_sha256=sha(compiler.read_bytes()),receipt=str(frozen/'bin/nanoc_bootstrap.json'),receipt_sha256=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes()),hosts=b.manifest['hosts'])
 env=dict(base_env,NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(root/'.test_output/ordinary-verifier-module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(compiler))
 for name in ['NANOLANG_TRANSLATOR_SOURCE_MODULE','NANO_CC','NANOLANG_BOOTSTRAP_NO_CC','NANO_AS_CAPTURE_HELPER']:env.pop(name,None)
 record['gate_environment']={name:env.get(name) for name in ['PATH','CC','MAKEFLAGS','NANOLANG_ROOT','NANO_MODULE_PATH','NANO_BUILD_CACHE','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']};save();guards()
 step('build-tools',['make','CC=/usr/bin/cc','bin/nanoc_c','nano_virt','nano_vm','bin/nanoisa','nvm2c','nvm2c-runtime'],root,env,timeout=1800)
 guards()
 step('verifier',['make','CC=/usr/bin/cc','test-verifier'],root,env);guards()
 step('vm-identifiers',['make','CC=/usr/bin/cc','test-nanovm','test-embedded-nano-identifiers'],root,env);guards()
 tools={name:sha((root/name).read_bytes()) for name in ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o']};record['tools']=tools;save();guards()
 step('products',['python3','-m','unittest','-v','tests.test_empty_function_results'],root,env);guards()
 import shlex
 lines=(out/'verifier.stdout').read_text().replace(chr(92)+chr(10),' ').splitlines()
 matches=[shlex.split(line) for line in lines if line.startswith('/usr/bin/cc ') and 'tests/nanoisa/test_verifier.c' in shlex.split(line)];assert matches
 args=[arg for arg in matches[-1] if arg not in ['obj/nanoisa/verifier.o','obj/nanoisa/verifier_types.o','obj/nanovm/vm_decode.o','obj/nanoisa/isa.o']]
 executable=out/'test-verifier-sanitized';args[args.index('-o')+1]=str(executable)
 args+=['src/nanoisa/verifier.c','src/nanoisa/verifier_types.c','src/nanovm/vm_decode.c','src/nanoisa/isa.c','-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
 step('sanitizers-build',args,root,env);step('sanitizers',[executable],root,env,timeout=120);guards()
 assert 'All 101 tests passed.' in (out/'verifier.stdout').read_text()
 assert 'All 101 tests passed.' in (out/'sanitizers.stdout').read_text()
 assert '569591 passed, 0 failed' in (out/'vm-identifiers.stdout').read_text()
 linux=json.loads(Path(sys.argv[3]).read_text());paired={}
 for work in re.findall(r'I retain empty-result products at (\S+)',(out/'products.stdout').read_text()):
  p=Path(work);m=json.loads((p/'manifest.json').read_text());name=m['test'].rsplit('.',1)[-1]
  assert m['cases']==linux[name]['cases']
  for case in m['cases']:assert sha((p/(case['name']+'.nvm')).read_bytes())==case['sha256']
  if 'routes' in m:assert len(m['routes'])==5
  paired[name]=dict(work=str(p),cases=len(m['cases']),linux_case_bytes_identical=True,routes=len(m.get('routes',[])))
 assert len(paired)==4;record['paired']=paired
 record['status']='passed';record['primary_after']=primary_guard();assert record['primary_after']==original
except BaseException as error:
 record['status']='failed';record['error']=repr(error);(out/'exception').write_text(traceback.format_exc())
finally:
 try:
  assert primary_guard()==original;record['primary_preserved']=True
  if b:guards();record['original_bootstrap_guards_unchanged']=True
 except BaseException as error:record['status']='failed';record['guard_error']=repr(error)
 save();print(json.dumps(dict(status=record['status'],manifest=str(out/'manifest.json'))),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
