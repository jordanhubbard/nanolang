from pathlib import Path
import ast,sys,os,json,hashlib,subprocess,re,time,shutil,gzip
root=Path('/Users/jkh/.worktrees/nanolang/empty-function-results-20261121');control=root.with_name(root.name+'-control');prior=json.loads((control/'manifest.json').read_text())
assert prior['status']=='failed' and prior['error']=='''NameError("name 're' is not defined")'''
assert all(s.get('returncode')==0 for s in prior['steps']) and prior['primary_preserved'] and prior['original_bootstrap_guards_unchanged']
out=root.with_name(root.name+'-finalization');out.mkdir(exist_ok=False);shutil.copy2(__file__,out/'observer.py');sha=lambda b:hashlib.sha256(b).hexdigest();primary=Path('/Users/jkh/Src/nanolang')
nodes=[n for n in ast.parse((control/'observer.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['git','primary_guard']];assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(control/'observer.py'),'exec'))
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load()
def guards():
 assert {name:sha((root/name).read_bytes()) for name in prior['source_hashes']}==prior['source_hashes']
 assert {name:sha((root/name).read_bytes()) for name in prior['tools']}==prior['tools']
 assert primary_guard()==prior['primary_before'];b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
guards();linux=json.loads(Path(sys.argv[1]).read_text());paired={};works=[]
for path in re.findall(r'I retain empty-result products at (\S+)',(control/'products.stdout').read_text()):
 p=Path(path);works.append(p);m=json.loads((p/'manifest.json').read_text());name=m['test'].rsplit('.',1)[-1];assert m['cases']==linux[name]['cases']
 for case in m['cases']:assert sha((p/(case['name']+'.nvm')).read_bytes())==case['sha256']
 if 'routes' in m:assert len(m['routes'])==5
 paired[name]=dict(work=str(p),cases=len(m['cases']),routes=len(m.get('routes',[])),linux_case_bytes_identical=True)
assert len(paired)==4 and sum(v['cases'] for v in paired.values())==143
assert 'All 101 tests passed.' in (control/'verifier.stdout').read_text();assert 'All 101 tests passed.' in (control/'sanitizers.stdout').read_text();assert '569591 passed, 0 failed' in (control/'vm-identifiers.stdout').read_text()
record=dict(status='passed',pid=os.getpid(),paired=paired,source_pin=prior['pin'],previous_manifest_sha256=sha((control/'manifest.json').read_bytes()),source_test_gates_unchanged=True,limits=['I complete pairing/archival after all original product gates passed and the first observer omitted its re import. I preserve the original failed bookkeeping manifest and rerun no product gate. Targeted C sanitizers do not establish full-provider or Darwin LeakSanitizer coverage.'])
oldroot=Path('/Users/jkh/.worktrees/nanolang/ordinary-verifier-components-20261121');old_record=json.loads((oldroot.with_name(oldroot.name+'-control-v2')/'manifest.json').read_text());oldvm=oldroot/'bin/nano_vm';assert sha(oldvm.read_bytes())==old_record['tools']['bin/nano_vm']
bad=Path(paired['test_result_bodies_refuse_before_execution']['work'])/'v2-declared-0-tag-1-count-1.nvm';record['baseline']=dict(pin=old_record['pin'],vm_sha256=sha(oldvm.read_bytes()),verifier_source_sha256=sha((oldroot/'src/nanoisa/verifier.c').read_bytes()),input_sha256=sha(bad.read_bytes()),steps=[])
for mode,args,expected in [('verify',[oldvm,'--verify-only',bad],0),('execute',[oldvm,bad],1)]:
 r=subprocess.run(args,cwd=root,capture_output=True,timeout=30);(out/('baseline-'+mode+'.stdout')).write_bytes(r.stdout);(out/('baseline-'+mode+'.stderr')).write_bytes(r.stderr);record['baseline']['steps'].append(dict(mode=mode,argv=list(map(str,args)),returncode=r.returncode));assert r.returncode==expected
 if mode=='execute':assert b'Function 0 returned 0 values, expected 1' in r.stderr
assert sha(oldvm.read_bytes())==old_record['tools']['bin/nano_vm']
shutil.copy2(oldvm,out/'baseline-nano_vm');shutil.copy2(oldroot/'src/nanoisa/verifier.c',out/'baseline-verifier.c');guards();record['all_guards_unchanged']=True;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
archive=root.with_name(root.name+'-archive');(archive/'inputs').mkdir(parents=True,exist_ok=False);paths={Path(__file__).resolve()}
for folder in [control,out,*works]:paths.update(p for p in folder.rglob('*') if p.is_file())
paths.update(root/name for name in prior['source_hashes']);paths.update(root/name for name in prior['tools'])
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(p) for p in b.manifest['hosts'])
files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(archive/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(archive/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
receipt=dict(issue=1174,pin=prior['pin'],root=str(root),source_hashes=prior['source_hashes'],tools=prior['tools'],provider=prior['provider'],steps=prior['steps'],paired=paired,baseline=record['baseline'],product_controller_status=prior['status'],product_controller_error=prior['error'],finalization=record,files=files)
(archive/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
for e in files:
 packed=(archive/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
guards();summary=dict(status='passed',files=len(files),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((archive/p).stat().st_size for p in seen.values()),sources=len(prior['source_hashes']),archive=str(archive));(archive/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
subprocess.run(['tar','-cf',str(archive)+'.tar','-C',str(archive.parent),archive.name],check=True,timeout=600)
