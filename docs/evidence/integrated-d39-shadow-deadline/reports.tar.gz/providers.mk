include Makefile.gnu
.PHONY: qualified-cseed
qualified-cseed: CFLAGS += $(SANITIZE_FLAGS)
qualified-cseed: LDFLAGS += $(SANITIZE_FLAGS)
qualified-cseed: $(COMPILER)
	@printf '%s\n' '$(COMPILER_OBJECTS)' > /home/jkh/nanolang-qualification/integrated-d39-full-typecheck/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/integrated-d39-full-typecheck/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/integrated-d39-full-typecheck/ldflags.txt
