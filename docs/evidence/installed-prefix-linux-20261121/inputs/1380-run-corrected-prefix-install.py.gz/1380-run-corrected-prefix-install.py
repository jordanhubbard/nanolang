from pathlib import Path
import json,os,subprocess,time,sys,tempfile,hashlib,signal
root=Path.cwd();build=root/'.test_output/installed-tool-discovery';m=json.loads((build/'build-manifest.json').read_text());assert all(step.get('returncode')==0 for step in m['steps']);compiler=build/'nanoc';assert compiler.is_file() and not compiler.is_symlink();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(compiler)==m['products'][str(compiler)];assert sha(root/'src_nano/nanoc_v06.nano')==m['source_sha256'];out=root/'.test_output/corrected-prefix-install';out.mkdir(exist_ok=False);frozen=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.load();artifacts=list(b.manifest['artifacts']);b.check_inputs();b.check_artifacts(artifacts)
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_BUILD_CACHE=str(out/'module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',LSAN_OPTIONS='');record=dict(compiler_sha256=sha(compiler),steps=[],limits=['I qualify a development source-built compiler, not new Stage1/Stage2 or a fixed point. My actual installer consumes that explicit completed file with Make --old-file so it cannot replace it with its generic compiler symlink recipe. I use the original ten-second ordinary shadow deadline and preserve the separate successful c908523c3 bootstrap guards. My broader GCC13 public gate remains failed.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,cwd=root,child_env=None,timeout=1800):
 t=time.monotonic();entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd));record['steps'].append(entry);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(entry['argv'],cwd=cwd,env=child_env or env,stdout=a,stderr=c,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:entry['timeout']=True;os.killpg(p.pid,signal.SIGKILL);entry['returncode']=p.wait()
 entry['elapsed_seconds']=time.monotonic()-t;save();assert entry['returncode']==0,entry
try:
 testenv=dict(env,NANOLANG_SELFHOST_COMPILER=str(compiler))
 run(['/usr/bin/python3',root/'.test_output/run-installed-ordinary-cli.py'],'ordinary-deadline-cli-product',child_env=testenv)
 external=Path(tempfile.mkdtemp(prefix='nano-corrected-prefix-'));prefix=external/'prefix';client=external/'client';client.mkdir();record.update(external=str(external),prefix=str(prefix));save()
 run(['make','CC=/usr/bin/cc','--old-file='+str(compiler),'COMPILER='+str(compiler),'PREFIX='+str(prefix),'install'],'actual-make-install')
 assert sha(prefix/'bin/nanoc')==sha(compiler)==record['compiler_sha256']
 source=client/'input.nano';source.write_text('fn answer()->int{return 42}\nshadow answer{assert (== (answer) 42)}\nfn main()->int{assert (== (answer) 42) (println "fresh-prefix-ok") return 0}\n')
 clean=dict(env,PATH=str(prefix/'bin')+':/usr/bin:/bin',TMPDIR=str(client),NANO_BUILD_CACHE=str(external/'module-cache'),NANO_CC='/bin/false')
 for name in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM']:clean.pop(name,None)
 run([prefix/'bin/nanoc',source,'--emit-nvm','-o',client/'program.nvm'],'external-installed-module',cwd=client,child_env=clean,timeout=180)
 run([prefix/'bin/nano_vm','--verify-only',client/'program.nvm'],'external-module-verify',cwd=client,child_env=clean,timeout=30)
 run([prefix/'bin/nano_vm',client/'program.nvm'],'external-module-execute',cwd=client,child_env=clean,timeout=30)
 run([prefix/'bin/nanoc',source,'--target','native','-o',client/'program.native'],'external-installed-native',cwd=client,child_env=dict(clean,NANO_CC='/usr/bin/cc'),timeout=180)
 run([client/'program.native'],'external-native-execute',cwd=client,child_env=clean,timeout=30)
 for label in ['external-module-execute','external-native-execute']:assert (out/(label+'.stdout')).read_text()=='fresh-prefix-ok\n'
 record['external_products']={str(p):sha(p) for p in client.iterdir() if p.is_file()};save()
finally:
 try:b.check_inputs();b.check_artifacts(artifacts);record['original_bootstrap_guards_unchanged']=True
 except Exception as error:record['original_bootstrap_guard_failure']=repr(error)
 save()
