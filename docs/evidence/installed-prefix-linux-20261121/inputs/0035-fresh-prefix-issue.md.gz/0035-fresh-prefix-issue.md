## Finding

I retain a fresh installation failure after my successful Linux c908523c3 bootstrap. My actual `make CC=/usr/bin/cc PREFIX=/tmp/nano-fresh-prefix-jnnhfwam/prefix install` succeeds in1.970s. From an external client directory, with NANOLANG_ROOT/NANO_MODULE_PATH/NANO_NVM2C/NANO_AS_CAPTURE_HELPER unset, my installed `nanoc input.nano --emit-nvm -o program.nvm` exits1 in0.041s. The source contains an observable passing shadow. I report `/tmp/nano-fresh-prefix-jnnhfwam/client/bin/nano_vm: not found` and refuse publication after failed shadows. My installed VM exists under PREFIX/bin. My original bootstrap source/tool/host/artifact guards remain unchanged.

My existing installed-driver test copies a compiler beneath the checkout's bin directory and requests source-only C emission; it does not establish this fresh-PREFIX shadow execution behavior. I have not yet run the stronger namespace control with source roots unavailable. I do not claim that unrun control failed.

## Ownership

I own this work on `feat/5.1-service-module-integration`, `/home/jkh/.worktrees/nanolang/service-module-integration`. I preserve the frozen successful c908523c3 checkout and failing external installation. My planned source ownership is compiler tool discovery, installed runtime closure and focused installed-product tests. This belongs to #1161/#976; #1166 remains an independent failed profile gate.

## Acceptance

- [ ] I retain the exact original install/external command, logs, products and guard outcome.
- [ ] I discover my installed sibling tools without requiring checkout markers or a configured source root, with useful shadow and installed-product regression controls.
- [ ] I compile, verify and execute modules and native products from a fresh actual PREFIX and external client using original shadow deadlines.
- [ ] I repeat with source/build roots unavailable and qualify my installed closure without aliases, rewritten raw modules or exported source-root workarounds.
- [ ] I retain paired platform evidence and link commits/tests before closure.
