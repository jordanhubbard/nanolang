# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 2







typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[8u];
} NvmFileNominalBindings;
NvmServiceResult nvm_file_nominal_check(const NvmFileNominalBindings *);

NvmServiceResult nvm_file_nominal_decode(const uint8_t *,size_t,NvmFileNominalBindings *);


NvmServiceResult nvm_file_nominal_encode(const NvmFileNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_FILE_NOMINAL_DESCRIBED, NVM_FILE_NOMINAL_INVALID,
    NVM_FILE_NOMINAL_LIMIT, NVM_FILE_NOMINAL_MEMORY
} NvmFileNominalStatus;
typedef enum {
    NVM_FILE_CATEGORY_UNKNOWN, NVM_FILE_CATEGORY_FILE,
    NVM_FILE_CATEGORY_OPEN_RESULT, NVM_FILE_CATEGORY_SCALAR_RESULT,
    NVM_FILE_CATEGORY_RECORD
} NvmFileCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmFileCategory category;
} NvmFileNominalLayout;
typedef struct NvmFileNominalPlan NvmFileNominalPlan;




NvmFileNominalStatus nvm_file_nominal_plan(const NvmModule *,NvmFileNominalPlan **);
void nvm_file_nominal_plan_free(NvmFileNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_file_nominal_layout_count(const NvmFileNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_layout(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_type(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_source(const NvmFileNominalPlan *,uint8_t,uint32_t,NvmFileNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_import(const NvmFileNominalPlan *,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[9u];
} NvmSocketNominalBindings;
NvmServiceResult nvm_socket_nominal_check(const NvmSocketNominalBindings *);

NvmServiceResult nvm_socket_nominal_decode(const uint8_t *,size_t,NvmSocketNominalBindings *);


NvmServiceResult nvm_socket_nominal_encode(const NvmSocketNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_SOCKET_NOMINAL_DESCRIBED, NVM_SOCKET_NOMINAL_INVALID,
    NVM_SOCKET_NOMINAL_LIMIT, NVM_SOCKET_NOMINAL_MEMORY
} NvmSocketNominalStatus;
typedef enum {
    NVM_SOCKET_CATEGORY_UNKNOWN, NVM_SOCKET_CATEGORY_CONN,
    NVM_SOCKET_CATEGORY_CONNECT_RESULT, NVM_SOCKET_CATEGORY_SCALAR_RESULT,
    NVM_SOCKET_CATEGORY_RECORD
} NvmSocketCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmSocketCategory category;
} NvmSocketNominalLayout;
typedef struct NvmSocketNominalPlan NvmSocketNominalPlan;




NvmSocketNominalStatus nvm_socket_nominal_plan(const NvmModule *,NvmSocketNominalPlan **);
void nvm_socket_nominal_plan_free(NvmSocketNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_socket_nominal_layout_count(const NvmSocketNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_layout(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_type(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_source(const NvmSocketNominalPlan *,uint8_t,uint32_t,NvmSocketNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_import(const NvmSocketNominalPlan *,uint32_t,uint32_t *);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
typedef struct {
    uint32_t catalog;
    uint32_t imports[5], layouts[9];
} NvmServiceInstance;
typedef struct {
    uint32_t count;
    NvmServiceInstance instances[64u];
} NvmMultiNominalBindings;






uint32_t nvm_multi_nominal_catalog_types(uint32_t catalog);
uint32_t nvm_multi_nominal_catalog_methods(uint32_t catalog);
NvmServiceResult nvm_multi_nominal_check(const NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_decode(const uint8_t *,size_t,NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_encode(const NvmMultiNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum { NVM_MULTI_NOMINAL_DESCRIBED, NVM_MULTI_NOMINAL_INVALID,
    NVM_MULTI_NOMINAL_LIMIT, NVM_MULTI_NOMINAL_MEMORY } NvmMultiNominalStatus;
typedef struct {
    uint32_t global_index, instance, catalog, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
} NvmMultiNominalLayout;
typedef struct NvmMultiNominalPlan NvmMultiNominalPlan;


NvmMultiNominalStatus nvm_multi_nominal_plan(const NvmModule *,NvmMultiNominalPlan **);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_storage_bound(uint32_t,size_t *);
uint32_t nvm_multi_nominal_layout_count(const NvmMultiNominalPlan *);
void nvm_multi_nominal_plan_free(NvmMultiNominalPlan *);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_layout(const NvmMultiNominalPlan *,uint32_t,NvmMultiNominalLayout *);

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_type(const NvmMultiNominalPlan *,uint32_t,uint32_t,NvmMultiNominalLayout *);

# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_import(const NvmMultiNominalPlan *,uint32_t,uint32_t,uint32_t *);
uint32_t nvm_multi_nominal_instance_count(const NvmMultiNominalPlan *);
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 2




typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_socket_plan_free(NlSocketPlan *);
size_t nl_socket_plan_storage_size(void);
const char *nl_socket_plan_interface(const NlSocketPlan *);
size_t nl_socket_plan_method_count(const NlSocketPlan *);
size_t nl_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_socket_catalog_interface(void);
const NlServicePlanMethod *nl_socket_catalog_method(size_t);
const NlServicePlanType *nl_socket_catalog_type(size_t);
# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1






typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2




# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_bindings_present(const NvmModule *);

# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_service_bindings_present(const NvmV2Module *);



# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_file_instructions_present(const NvmModule *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_file_instructions_present(const NvmV2Module *);


# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_execution_pending(const NvmModule *);


NvmV2Result nvm_service_bindings_validate(const NvmModule *);
NvmV2Result nvm_v2_service_bindings_validate(const NvmV2Module *);



NvmV2Result nvm_service_bindings_attach(NvmModule *, const NlFilePlan *,
                                       const NvmServiceBindings *);


NvmV2Result nvm_file_nominal_attach(NvmModule *,const NlFilePlan *,
                                   const NvmFileNominalBindings *);

NvmV2Result nvm_socket_nominal_attach(NvmModule *,const NlSocketPlan *,const NvmSocketNominalBindings *);
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 1
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 2




typedef struct {
    
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
        ok;
    char error_msg[256];
} NvmVerifyResult;
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify(const NvmModule *mod);







typedef enum {
    NVM_PROFILE_GENERAL = 0,
    NVM_PROFILE_CLOSED_SCALAR = 1,
    NVM_PROFILE_CLOSED_LITERAL_STRINGS = 2,
    NVM_PROFILE_CLOSED_MANAGED_STRINGS = 3,


    NVM_PROFILE_PORTABLE_FILE_READ = 5,
    NVM_PROFILE_PORTABLE_READ_TEXT = 4
} NvmVerifyProfile;
NvmVerifyResult nvm_verify_profile(const NvmModule *mod, NvmVerifyProfile profile);



NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod);



# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
    nvm_uses_owned_transfers(const NvmModule *mod);



NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx);


NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx);
# 99 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_function_types(const NvmModule *mod, uint32_t fn_idx,
                                          const VmDecodedFunction *decoded,
                                          uint16_t max_depth,
                                          char *error, size_t error_size);

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack);





NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count);
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count);
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/isa.h" 1
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4

# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 2




# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
static inline unsigned nvm_portable_file_read_import(const NvmModule *m,uint32_t index) {
    if(!m || index>=m->import_count || !m->imports || !m->import_param_types ||
       !m->strings || !m->string_lengths)return 
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                                               0
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                                                    ;
    const NvmImportEntry *imp=&m->imports[index];
    if(imp->module_name_idx>=m->string_count || imp->function_name_idx>=m->string_count ||
       imp->kind!=NVM_IMPORT_FFI || imp->param_count!=1 || (imp->return_type!=TAG_STRING && imp->return_type!=TAG_ARRAY) ||
       !m->import_param_types[index] || m->import_param_types[index][0]!=TAG_STRING ||
       m->string_lengths[imp->module_name_idx])return 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                                                     0
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                                                          ;
    const char *name=m->strings[imp->function_name_idx];
    if(!name)return 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                   0
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                        ;
    static const char *const names[]={"file_read","vm_file_read","nl_os_file_read"};
    for(size_t i=0;i<sizeof names/sizeof names[0];i++) {
        size_t n=strlen(names[i]);
        if(imp->return_type==TAG_STRING && m->string_lengths[imp->function_name_idx]==n && !memcmp(name,names[i],n))return 1;
        if(imp->return_type==TAG_ARRAY && m->string_lengths[imp->function_name_idx]==n+6 &&
           !memcmp(name,names[i],n) && !memcmp(name+n,"_bytes",6))return 2;
    }
    return 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
          0
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
               ;
}
static inline 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
             _Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                  nvm_portable_read_import_exact(const NvmModule *m,uint32_t index) {
    return nvm_portable_file_read_import(m,index)==1;
}
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_array_shapes.h" 1






typedef enum {
    NVM_ARRAY_ELIGIBLE, NVM_ARRAY_UNRESOLVED, NVM_ARRAY_INVALID,
    NVM_ARRAY_LIMIT, NVM_ARRAY_MEMORY
} NvmArrayEligibilityStatus;
typedef struct {
    uint32_t function, pc;
    uint16_t child_tags;
    uint8_t declared_tag, packed;
} NvmArrayOrigin;
typedef struct {
    uint32_t origin_count, checked_writes;

    uint32_t runtime_tag_checks;
    NvmArrayOrigin origins[64];
} NvmArrayEligibilityReport;

typedef struct {
    NvmArrayEligibilityReport arrays;
    uint64_t child_origins[64];
    uint8_t child_unknown[64];
} NvmArrayGraphEligibilityReport;
typedef struct {
    NvmArrayEligibilityStatus status;
    uint32_t function, pc;
    char message[192];
} NvmArrayEligibilityResult;

NvmArrayEligibilityResult nvm_analyze_managed_arrays(
    const NvmModule *module, NvmArrayEligibilityReport **out);
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report);

NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(
    const NvmModule *module, NvmArrayGraphEligibilityReport **out);
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report);



NvmArrayEligibilityResult nvm_select_managed_array_mode(
    const NvmModule *module, int *graph_required);
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 1






typedef struct NvmOrdinaryArrayAuthority NvmOrdinaryArrayAuthority;
typedef enum { NVM_OAA_DESCRIBED, NVM_OAA_UNKNOWN, NVM_OAA_INVALID,
               NVM_OAA_LIMIT, NVM_OAA_MEMORY } NvmOrdinaryArrayStatus;
typedef struct { NvmOrdinaryArrayStatus status; uint32_t layout, field;
                 const char *message; } NvmOrdinaryArrayResult;
typedef struct { uint32_t layouts, types, bindings; } NvmOrdinaryArrayCounts;
typedef struct { uint8_t tag; uint32_t referent; } NvmOrdinaryArrayType;
typedef struct { uint32_t layout; uint16_t field; uint32_t element_type; } NvmOrdinaryArrayBinding;
NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(const NvmModule *, NvmOrdinaryArrayAuthority **);
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *, NvmOrdinaryArrayCounts *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayType *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayBinding *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 2



typedef struct NvmOwnershipDeclarationPlan NvmOwnershipDeclarationPlan;
typedef enum {
    NVM_DECL_PREPARED, NVM_DECL_UNKNOWN, NVM_DECL_INVALID,
    NVM_DECL_LIMIT, NVM_DECL_MEMORY
} NvmDeclarationStatus;
typedef struct { NvmDeclarationStatus status; const char *message; } NvmDeclarationResult;
typedef struct { uint32_t layouts, types, bindings, unions, variants; } NvmDeclarationCounts;
typedef struct { uint8_t kind, flags; uint16_t fields; uint32_t name; } NvmDeclarationLayout;
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *,NvmOwnershipDeclarationPlan **);
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *,NvmDeclarationCounts *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *,uint32_t,NvmDeclarationLayout *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayType *);

# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 2


# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 340 "/usr/include/stdlib.h" 3 4
extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 8 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 2





# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
typedef struct {
    uint64_t bytes, peak, work;
    
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
        limited, memory;
} NvmRecordArrayBudget;
static inline 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_bytes(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->bytes>(64UL*1024*1024) || n>(64UL*1024*1024)-b->bytes){b->limited=
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                   1
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                       ;return 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                               0
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                                    ;}
    b->bytes+=n;if(b->peak<b->bytes)b->peak=b->bytes;return 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                           1
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                               ;
}
static inline 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_steps(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->work>16777216UL || n>16777216UL -b->work){b->limited=
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                 1
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                     ;return 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                             0
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                                  ;}
    b->work+=n;return 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                     1
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                         ;
}
static inline void *nvm_ra_alloc(NvmRecordArrayBudget *b,size_t n,size_t width) {
    if(width && n>
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                 (18446744073709551615UL)
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                         /width){if(b)b->limited=
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                 1
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                     ;return 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                             ((void *)0)
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                 ;}
    if(!nvm_ra_bytes(b,(uint64_t)n*width))return 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                ((void *)0)
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                    ;
    void *p=calloc(n,width);if(!p && n && width && b)b->memory=
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                              1
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                  ;return p;
}


typedef struct {
    NvmOwnershipDeclarationPlan *declarations;
    uint32_t functions;
    VmDecodedFunction decoded[256];
    uint16_t stacks[256];
} NvmRecordArrayStructure;

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
    nvm_record_array_opcode_supported(uint8_t);
NvmArrayEligibilityResult nvm_record_array_structure_prepare(
    const NvmModule *,NvmRecordArrayBudget *,NvmRecordArrayStructure **);
void nvm_record_array_structure_free(NvmRecordArrayStructure *);
NvmVerifyResult nvm_verify_function_types_record_array(
    const NvmModule *,uint32_t,const VmDecodedFunction *,uint16_t,NvmRecordArrayBudget *);
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_plan.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_plan.h"
typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 2


typedef struct {
    uint64_t origins;
    uint16_t tags;
    uint8_t unknown;
} NvmRecordValueOrigins;
typedef enum { NVM_HEAP_ORIGIN_ARRAY, NVM_HEAP_ORIGIN_RECORD } NvmHeapOriginKind;
typedef struct {
    uint32_t function, pc;
    uint32_t record_ordinal, layout_index, field_start;
    uint16_t field_count;
    uint8_t kind, declared_tag, packed;
    NvmRecordValueOrigins children;
} NvmRecordHeapOrigin;
typedef struct {
    uint32_t origin_count, field_value_count, checked_field_writes;
    uint32_t checked_array_writes, runtime_tag_checks;
    NvmRecordHeapOrigin origins[64];
    NvmRecordValueOrigins *fields;
} NvmRecordEligibilityReport;



NvmArrayEligibilityResult nvm_analyze_managed_records(
    const NvmModule *module, NvmRecordEligibilityReport **out);
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report);


typedef enum { NVM_MANAGED_LEAF, NVM_MANAGED_ARRAY_GRAPH, NVM_MANAGED_RECORD } NvmManagedHeapMode;
typedef struct {
    NvmManagedHeapMode mode;
    NvmRecordPlan *records;
    NvmRecordEligibilityReport *fields;
} NvmManagedHeapPlan;
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *, int mutable_arrays,
                                                 NvmManagedHeapPlan **out);
void nvm_managed_heap_plan_free(NvmManagedHeapPlan *);
NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *, NvmManagedHeapPlan **);
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 1







typedef struct NvmRecordArrayOrigins NvmRecordArrayOrigins;
typedef struct {
    uint32_t origins, fields, checked_field_writes, checked_array_writes, runtime_tag_checks;
    uint64_t work_reserved, peak_bytes_reserved;
} NvmRecordArrayOriginCounts;
NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *,NvmRecordArrayOrigins **);
void nvm_record_array_origins_free(NvmRecordArrayOrigins *);

# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *,NvmRecordArrayOriginCounts *);

# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origin(const NvmRecordArrayOrigins *,uint32_t,NvmRecordHeapOrigin *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *,uint32_t,NvmRecordValueOrigins *);
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
static inline uint16_t nvm_record_array_requirement(uint8_t depth,uint8_t leaf) {
    if(leaf<TAG_INT || leaf>TAG_STRING)return 0;
    if(depth==1)return (uint16_t)(1u<<leaf);
    if(depth==2) {
        switch(leaf) {
        case TAG_INT:return ((uint16_t)(1u << TAG_ARRAY));
        case TAG_U8:return ((uint16_t)(1u << 9));
        case TAG_FLOAT:return ((uint16_t)(1u << 10));
        case TAG_BOOL:return ((uint16_t)(1u << 11));
        case TAG_STRING:return ((uint16_t)(1u << 8));
        }
    }
    if(depth==3)return leaf==TAG_STRING?((uint16_t)(1u << 6)):(uint16_t)(1u<<(11u+leaf));
    return 0;
}
static inline uint8_t nvm_record_array_requirement_depth(uint16_t requirement) {
    for(uint8_t depth=1;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(requirement==nvm_record_array_requirement(depth,leaf))return depth;
    return 0;
}

static inline uint8_t nvm_record_array_requirement_leaf(uint16_t requirement) {
    switch(requirement) {
    case ((uint16_t)(1u << 12)):case ((uint16_t)(1u << TAG_ARRAY)):return TAG_INT;
    case ((uint16_t)(1u << 13)):case ((uint16_t)(1u << 9)):return TAG_U8;
    case ((uint16_t)(1u << 14)):case ((uint16_t)(1u << 10)):return TAG_FLOAT;
    case ((uint16_t)(1u << 15)):case ((uint16_t)(1u << 11)):return TAG_BOOL;
    case ((uint16_t)(1u << 6)):case ((uint16_t)(1u << 8)):return TAG_STRING;
    default:return TAG_VOID;
    }
}

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *,uint32_t,uint16_t *);

# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *,NvmDeclarationCounts *);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *,uint32_t,NvmDeclarationLayout *);

# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmV2LayoutField *);

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayType *);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayBinding *);

# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 2





typedef struct NvmRecordArrayExecutionPlan NvmRecordArrayExecutionPlan;
typedef enum {
    NVM_RA_ROOT_SCALAR, NVM_RA_ROOT_CONSTANT, NVM_RA_ROOT_LOAD,
    NVM_RA_ROOT_STORE, NVM_RA_ROOT_DUP, NVM_RA_ROOT_SWAP, NVM_RA_ROOT_DROP,
    NVM_RA_ROOT_BRANCH, NVM_RA_ROOT_CALL, NVM_RA_ROOT_RETURN,
    NVM_RA_ROOT_STRING, NVM_RA_ROOT_CONSTRUCT, NVM_RA_ROOT_GET,
    NVM_RA_ROOT_SET, NVM_RA_ROOT_ARRAY_PUSH, NVM_RA_ROOT_ARRAY_POP,
    NVM_RA_ROOT_ARRAY_COPY, NVM_RA_ROOT_TAIL
} NvmRecordArrayRootRecipe;
enum {

    NVM_RA_CHECK_TAGS=1u, NVM_RA_CHECK_BOUNDS=2u, NVM_RA_CHECK_NOMINAL=4u,
    NVM_RA_SAFEPOINT_BEFORE=8u, NVM_RA_STAGE_OPERANDS=16u,
    NVM_RA_RETAIN_BEFORE_RELEASE=32u, NVM_RA_FIRST_ERROR_CLEANUP=64u
};
typedef struct {
    uint32_t functions, instructions, globals, initializer, entry, frame_limit;
    uint32_t strings, sections, metadata, debug, records;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordArrayExecutionCounts;
typedef struct {
    NvmFunctionEntry signature;
    uint32_t instruction_start, instruction_count;
    uint16_t maximum_stack;
    uint8_t parameter_tags_present;
} NvmRecordArrayExecutionFunction;



typedef struct {
    uint32_t function, pc, next_pc, successors[2], callee;
    uint16_t pops, pushes, obligations;
    uint8_t opcode, recipe, successor_count, operand_count;
    uint8_t operand_types[4];
    uint64_t operand_bits[4];
} NvmRecordArrayExecutionInstruction;
typedef struct {
    uint32_t ordinal, layout;
    uint16_t fields;
} NvmRecordArrayExecutionDescriptor;
typedef enum {
    NVM_RA_SNAPSHOT_CODE, NVM_RA_SNAPSHOT_LAYOUTS, NVM_RA_SNAPSHOT_OWNERSHIP,
    NVM_RA_SNAPSHOT_STRING
} NvmRecordArraySnapshotKind;
NvmArrayEligibilityResult nvm_prepare_record_array_execution(
    const NvmModule *, NvmRecordArrayExecutionPlan **);
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *);

# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 56 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 58 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionInstruction *);

# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionDescriptor *);

# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *,NvmHeader *);

# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *,uint32_t,NvmSectionEntry *);

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *,uint32_t,NvmMetadataEntry *);

# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDebugEntry *);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayOriginCounts *);

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordHeapOrigin *);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t *);

# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *,NvmDeclarationCounts *);

# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayType *);

# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 76 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 2



# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_admission.h"
    nvm_record_array_candidate(const NvmModule *);


NvmArrayEligibilityResult nvm_record_array_admit(const NvmModule *,NvmRecordArrayExecutionPlan **);
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
typedef struct NvmRecordMapFrozenContext NvmRecordMapFrozenContext;
typedef struct {
    uint32_t origins,map_origins,fields,checked_map_operations;
    uint64_t peak_bytes_reserved,work_reserved;
} NvmRecordMapCounts;
NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *,NvmRecordMapFrozenContext **);
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *);

# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *,NvmRecordMapCounts *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *,uint32_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordHeapOrigin *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordValueOrigins *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 2


typedef struct NvmRecordMapExecutionPlan NvmRecordMapExecutionPlan;
typedef enum { NVM_RM_NONE, NVM_RM_NEW, NVM_RM_SET, NVM_RM_GET,
               NVM_RM_HAS, NVM_RM_LEN, NVM_RM_DELETE } NvmRecordMapOperation;
typedef struct {
    NvmRecordArrayExecutionCounts carrier;
    NvmRecordMapCounts maps;
} NvmRecordMapExecutionCounts;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    uint16_t key_tags,value_tags,result_tags;
    uint8_t map_operation;
} NvmRecordMapExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *,NvmRecordMapExecutionPlan **);




# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *,uint8_t *);
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *,NvmRecordMapExecutionCounts *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *,uint32_t,NvmRecordMapExecutionInstruction *);

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *,uint32_t,uint8_t *,uint8_t *);

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out);

# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out);

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out);

# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out);

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out);

# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 2





typedef enum { NVM_RECORD_MAP_ABSENT, NVM_RECORD_MAP_PRESENT,
    NVM_RECORD_MAP_INVALID, NVM_RECORD_MAP_LIMIT, NVM_RECORD_MAP_DEFER } NvmRecordMapRoute;
NvmRecordMapRoute nvm_record_map_route(const NvmModule *);


# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h"
    nvm_record_map_wire_selected(const NvmV2Module *);
static inline 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_admission.h"
                  nvm_record_map_selected(NvmRecordMapRoute r) {
    return r==NVM_RECORD_MAP_PRESENT || r==NVM_RECORD_MAP_INVALID || r==NVM_RECORD_MAP_LIMIT;
}


NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *,NvmRecordMapExecutionPlan **);
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h" 1






# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/passive.h"
    nvm_passive_valid(const NvmModule *module);
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 1







# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 7 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h"
    nvm_layouts_have_facts(const NvmV2Layouts *layouts);



# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/retained_layouts.h"
    nvm_retained_layouts_valid(const NvmModule *module);


NvmV2Result nvm_retain_layouts(NvmModule *module, const NvmV2Layouts *layouts);
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
typedef struct {
    
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
        ok;
    uint32_t byte_offset;
    uint32_t reachable;
    uint32_t visits;
    char message[192];
} NvmAffineAnalysis;

typedef struct {
    
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
   _Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
        reachable;
    uint8_t top_tag;
    uint16_t stack_depth;
    uint16_t unpack_count;
    uint32_t byte_offset;
} NvmAffineInstructionFact;




NvmAffineAnalysis nvm_affine_analyze_instructions(const NvmModule *module,
    uint32_t function, NvmAffineInstructionFact *facts, uint32_t capacity);




# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
    nvm_affine_value_call_graph(const NvmModule *module);
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_bytecode.h"
NvmAffineAnalysis nvm_affine_analyze_function(const NvmModule *module,
                                              uint32_t function);
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
typedef enum {
    NVM_REFERENCE_SHARED = 1,
    NVM_REFERENCE_EXCLUSIVE = 2
} NvmReferenceMode;

typedef struct {
    uint64_t invocation;
    uint16_t local;
    uint32_t root_layout;
    const uint16_t *fields;
    uint16_t field_count;
    uint32_t referent_layout;
    NvmReferenceMode mode;
} NvmReferencePlace;






# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_place_valid(const NvmV2Layouts *layouts,
                               uint32_t authoritative_root_layout,
                               const NvmReferencePlace *place);





# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_places_overlap(const NvmReferencePlace *a,
                                  const NvmReferencePlace *b);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_holds_conflict(const NvmReferencePlace *a,
                                 const NvmReferencePlace *b);



# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_owner_access_conflicts(const NvmReferencePlace *hold,
                                          const NvmReferencePlace *access,
                                          
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
                                         _Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/reference_places.h"
                                              write_or_move);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 2







typedef struct NvmAffineState NvmAffineState;
NvmAffineState *nvm_affine_state_create(const NvmModule *module,
                                       uint32_t function, uint32_t references);
NvmAffineState *nvm_affine_state_clone(const NvmAffineState *state);




NvmAffineState *nvm_affine_handler_enter(const NvmAffineState *state,
                                         uint32_t key_idx,uint16_t first);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_suspend(const NvmAffineState *state);
void nvm_affine_state_free(NvmAffineState *state);


# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_complete_unions(const NvmAffineState *state);


# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_array_types(const NvmAffineState *state);

# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_equal(const NvmAffineState *a, const NvmAffineState *b);



# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_meet_initialization(NvmAffineState *destination,
                                          const NvmAffineState *incoming,
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                        _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                             *changed);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_define(NvmAffineState *state, uint16_t local);


# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_define(NvmAffineState *state, uint16_t local);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_move(NvmAffineState *state, uint16_t source, uint16_t destination);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_pack(NvmAffineState *state, uint16_t destination,
                      const uint16_t *fields, uint16_t count);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_unpack(NvmAffineState *state, uint16_t source,
                        const uint16_t *fields, uint16_t count);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owner_access(const NvmAffineState *state, uint16_t root,
                              const uint16_t *path, uint16_t count, 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                   _Bool 
# 44 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                        write);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_begin(NvmAffineState *state);

# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_end(NvmAffineState *state);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_borrow(NvmAffineState *state, uint32_t reference,
                        uint16_t root, const uint16_t *path, uint16_t count,
                        NvmReferenceMode mode);

# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reborrow(NvmAffineState *state, uint32_t reference,
                          uint32_t parent, NvmReferenceMode mode);

# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_access(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write);

# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_field(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 55 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write, uint8_t *tag);




# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit(const NvmAffineState *state, uint16_t result);



# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_info(const NvmAffineState *state, uint16_t local,
                            uint8_t *tag, uint8_t *mode);

# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_scalar(const NvmAffineState *state, uint8_t tag);
typedef struct { uint8_t tag; uint32_t layout; } NvmAffineType;

# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_types_equal(const NvmAffineState *,NvmAffineType,NvmAffineType);

# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_define(NvmAffineState *,uint16_t local,uint32_t element);



# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_element(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_type(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_tag_type(const NvmAffineState *,uint8_t,NvmAffineType *);

# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_resume(const NvmAffineState *state,NvmAffineType result);






# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 81 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_type_is_owned(const NvmAffineState *state,NvmAffineType type);

# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 82 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_is_copyable(const NvmAffineState *state,uint32_t layout);

# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_define(NvmAffineState *state,uint16_t local,uint32_t layout);

# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_local_fields(const NvmAffineState *state,uint16_t local,
    NvmAffineType *fields,uint16_t capacity,uint16_t *count);

# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_take_local(NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 87 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_put_local(NvmAffineState *state, uint16_t local, NvmAffineType type);

# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_type(const NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_fields(const NvmAffineState *state, uint32_t layout,
                               NvmAffineType *fields, uint16_t capacity, uint16_t *count);



# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_define(NvmAffineState *state,uint16_t local,
                              uint32_t layout,uint16_t variant);




# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 98 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_pack(NvmAffineState *state,uint16_t destination,uint16_t variant,
                            const uint16_t *fields,uint16_t count);

# 100 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 100 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_unpack(NvmAffineState *state,uint16_t source,uint16_t variant,
                              const uint16_t *fields,uint16_t count);

# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_refine(NvmAffineState *state,uint16_t local,uint16_t variant);

# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 103 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_variant(const NvmAffineState *state,uint16_t local,
                               uint16_t *variant);

# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_fields(const NvmAffineState *state,uint32_t layout,
                              uint16_t variant,NvmAffineType *fields,
                              uint16_t capacity,uint16_t *count);

# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 108 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_type(const NvmAffineState *state, NvmAffineType type);






# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 114 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_bind_caller(NvmAffineState *callee,const NvmAffineState *caller,
                             uint32_t reference);

# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_at(const NvmAffineState *state,uint16_t parameter,
                               NvmAffineType *type,NvmReferenceMode *mode);
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"

# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_result(const NvmAffineState *state,NvmAffineType *type,
                              uint16_t *field_count);



# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_parameters(const NvmAffineState *state,
                                  NvmAffineType *types,uint16_t capacity,uint16_t *count);



# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 134 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_consuming_parameters(const NvmAffineState *state,
                                      NvmAffineType *types,uint16_t capacity,uint16_t *count);


# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 137 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_parameter_type(const NvmAffineState *state,NvmAffineType *type);

# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_type(const NvmAffineState *state,NvmAffineType *type,
                                 NvmReferenceMode *mode);
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 1
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 2

# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 85 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) __attribute__ ((__warn_unused_result__));
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__));

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));
# 442 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                          __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                         __attribute__ ((__warn_unused_result__));
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
    __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) __attribute__ ((__warn_unused_result__));






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern int __sprintf_chk (char *__restrict __s, int __flag, size_t __slen,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));
extern int __vsprintf_chk (char *__restrict __s, int __flag, size_t __slen,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));



extern int __snprintf_chk (char *__restrict __s, size_t __n, int __flag,
      size_t __slen, const char *__restrict __format,
      ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int __vsnprintf_chk (char *__restrict __s, size_t __n, int __flag,
       size_t __slen, const char *__restrict __format,
       __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));





extern int __fprintf_chk (FILE *__restrict __stream, int __flag,
     const char *__restrict __format, ...)
    __attribute__ ((__nonnull__ (1)));
extern int __printf_chk (int __flag, const char *__restrict __format, ...);
extern int __vfprintf_chk (FILE *__restrict __stream, int __flag,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nonnull__ (1)));
extern int __vprintf_chk (int __flag, const char *__restrict __format,
     __gnuc_va_list __ap);


extern int __dprintf_chk (int __fd, int __flag, const char *__restrict __fmt,
     ...) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __vdprintf_chk (int __fd, int __flag,
      const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 3, 0)));




extern int __asprintf_chk (char **__restrict __ptr, int __flag,
      const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4))) __attribute__ ((__warn_unused_result__));
extern int __vasprintf_chk (char **__restrict __ptr, int __flag,
       const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0))) __attribute__ ((__warn_unused_result__));
extern int __obstack_printf_chk (struct obstack *__restrict __obstack,
     int __flag, const char *__restrict __format,
     ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __obstack_vprintf_chk (struct obstack *__restrict __obstack,
      int __flag,
      const char *__restrict __format,
      __gnuc_va_list __args)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 96 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern char *__fgets_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets called with bigger size than length " "of destination buffer")))
                                 ;

extern char *__fgets_chk (char *__restrict __s, size_t __size, int __n,
     FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));

extern size_t __fread_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread")


            __attribute__ ((__warn_unused_result__));
extern size_t __fread_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread called with bigger size * nmemb than length " "of destination buffer")))
                                 ;

extern size_t __fread_chk (void *__restrict __ptr, size_t __ptrlen,
      size_t __size, size_t __n,
      FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));


extern char *__fgets_unlocked_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets_unlocked")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_unlocked_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_unlocked_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets_unlocked called with bigger size than length " "of destination buffer")))
                                 ;


extern char *__fgets_unlocked_chk (char *__restrict __s, size_t __size,
       int __n, FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));




extern size_t __fread_unlocked_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread_unlocked")


                     __attribute__ ((__warn_unused_result__));
extern size_t __fread_unlocked_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_unlocked_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread_unlocked called with bigger size * nmemb than " "length of destination buffer")))
                                        ;

extern size_t __fread_unlocked_chk (void *__restrict __ptr, size_t __ptrlen,
        size_t __size, size_t __n,
        FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));
# 965 "/usr/include/stdio.h" 2 3 4
# 976 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 1 3 4
# 46 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return getc (stdin);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





extern __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


extern __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




extern __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return putc (__c, stdout);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


extern __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) __ssize_t
getline (char **__lineptr, size_t *__n, FILE *__stream)
{
  return __getdelim (__lineptr, __n, '\n', __stream);
}





extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0010) != 0);
}


extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0020) != 0);
}
# 977 "/usr/include/stdio.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) sprintf (char *__restrict __s, const char *__restrict __fmt, ...)
{
  return __builtin___sprintf_chk (__s, 3 - 1,
      __builtin_dynamic_object_size (__s, 1), __fmt,
      __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsprintf (char *__restrict __s, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsprintf_chk (__s, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) snprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, ...)

{
  return __builtin___snprintf_chk (__s, __n, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt,
       __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsnprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsnprintf_chk (__s, __n, 3 - 1,
        __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
fprintf (FILE *__restrict __stream, const char *__restrict __fmt, ...)
{
  return __fprintf_chk (__stream, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
printf (const char *__restrict __fmt, ...)
{
  return __printf_chk (3 - 1, __fmt, __builtin_va_arg_pack ());
}







extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __ap)
{

  return __vfprintf_chk (stdout, 3 - 1, __fmt, __ap);



}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
vfprintf (FILE *__restrict __stream,
   const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vfprintf_chk (__stream, 3 - 1, __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
dprintf (int __fd, const char *__restrict __fmt, ...)
{
  return __dprintf_chk (__fd, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vdprintf (int __fd, const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vdprintf_chk (__fd, 3 - 1, __fmt, __ap);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)
{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) __asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)

{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_printf (struct obstack *__restrict __obstack, const char *__restrict __fmt, ...)

{
  return __obstack_printf_chk (__obstack, 3 - 1, __fmt,
          __builtin_va_arg_pack ());
}
# 165 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vasprintf (char **__restrict __ptr, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __vasprintf_chk (__ptr, 3 - 1, __fmt, __ap);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_vprintf (struct obstack *__restrict __obstack, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __obstack_vprintf_chk (__obstack, 3 - 1, __fmt,
    __ap);
}
# 194 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_chk_warn (__s, sz, __n, __stream);
  return __fgets_chk (__s, sz, __n, __stream);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread (void *__restrict __ptr, size_t __size, size_t __n,
       FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    return __fread_alias (__ptr, __size, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_chk (__ptr, sz, __size, __n, __stream);
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets_unlocked (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_unlocked_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_unlocked_chk_warn (__s, sz, __n, __stream);
  return __fgets_unlocked_chk (__s, sz, __n, __stream);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread_unlocked (void *__restrict __ptr, size_t __size, size_t __n,
  FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    {

      if (__builtin_constant_p (__size)
   && __builtin_constant_p (__n)
   && (__size | __n) < (((size_t) 1) << (8 * sizeof (size_t) / 2))
   && __size * __n <= 8)
 {
   size_t __cnt = __size * __n;
   char *__cptr = (char *) __ptr;
   if (__cnt == 0)
     return 0;

   for (; __cnt > 0; --__cnt)
     {
       int __c = getc_unlocked (__stream);
       if (__c == (-1))
  break;
       *__cptr++ = __c;
     }
   return (__cptr - (char *) __ptr) / __size;
 }

      return __fread_unlocked_alias (__ptr, __size, __n, __stream);
    }
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_unlocked_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_unlocked_chk (__ptr, sz, __size, __n, __stream);

}
# 981 "/usr/include/stdio.h" 2 3 4



# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 2







# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
typedef struct VmString VmString;
typedef struct VmBString VmBString;
typedef struct VmArray VmArray;
typedef struct VmStruct VmStruct;
typedef struct VmUnion VmUnion;
typedef struct VmTuple VmTuple;
typedef struct VmHashMap VmHashMap;
typedef struct VmClosure VmClosure;





typedef struct {
    uint8_t tag;


    uint32_t callable_module;
    union {
        int64_t i64;
        double f64;
        uint8_t u8;
        
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
       _Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                boolean;
        int32_t enum_val;
        uint32_t fn_idx;
        uint32_t proxy_id;


        VmString *string;
        VmArray *array;
        VmStruct *sval;
        VmUnion *uval;
        VmTuple *tuple;
        VmHashMap *hashmap;
        VmClosure *closure;
        void *obj;
    } as;
} NanoValue;





static inline NanoValue val_void(void) {
    NanoValue v = {0};
    v.tag = TAG_VOID;
    return v;
}

static inline NanoValue val_int(int64_t n) {
    NanoValue v = {0};
    v.tag = TAG_INT;
    v.as.i64 = n;
    return v;
}

static inline NanoValue val_float(double d) {
    NanoValue v = {0};
    v.tag = TAG_FLOAT;
    v.as.f64 = d;
    return v;
}

static inline NanoValue val_bool(
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
                                _Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                                     b) {
    NanoValue v = {0};
    v.tag = TAG_BOOL;
    v.as.boolean = b;
    return v;
}

static inline NanoValue val_u8(uint8_t b) {
    NanoValue v = {0};
    v.tag = TAG_U8;
    v.as.u8 = b;
    return v;
}

static inline NanoValue val_string(VmString *s) {
    NanoValue v = {0};
    v.tag = TAG_STRING;
    v.as.string = s;
    return v;
}

static inline NanoValue val_bstring(VmBString *s) {
    NanoValue v = {0};
    v.tag = TAG_BSTRING;
    v.as.obj = s;
    return v;
}

static inline NanoValue val_array(VmArray *a) {
    NanoValue v = {0};
    v.tag = TAG_ARRAY;
    v.as.array = a;
    return v;
}

static inline NanoValue val_struct(VmStruct *s) {
    NanoValue v = {0};
    v.tag = TAG_STRUCT;
    v.as.sval = s;
    return v;
}

static inline NanoValue val_enum(int32_t variant) {
    NanoValue v = {0};
    v.tag = TAG_ENUM;
    v.as.enum_val = variant;
    return v;
}

static inline NanoValue val_union(VmUnion *u) {
    NanoValue v = {0};
    v.tag = TAG_UNION;
    v.as.uval = u;
    return v;
}

static inline NanoValue val_function(uint32_t fn_idx) {
    NanoValue v = {0};
    v.tag = TAG_FUNCTION;
    v.callable_module = 1;
    v.as.fn_idx = fn_idx;
    return v;
}

static inline NanoValue val_function_owned(uint32_t fn_idx, uint32_t module_id) {
    NanoValue v = val_function(fn_idx);
    v.callable_module = module_id;
    return v;
}

static inline NanoValue val_tuple(VmTuple *t) {
    NanoValue v = {0};
    v.tag = TAG_TUPLE;
    v.as.tuple = t;
    return v;
}

static inline NanoValue val_hashmap(VmHashMap *h) {
    NanoValue v = {0};
    v.tag = TAG_HASHMAP;
    v.as.hashmap = h;
    return v;
}

static inline NanoValue val_closure(VmClosure *c) {
    NanoValue v = {0};
    v.tag = TAG_CLOSURE;
    v.as.closure = c;
    return v;
}





static inline 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_int(NanoValue v) { return v.tag == TAG_INT; }
static inline 
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_float(NanoValue v) { return v.tag == TAG_FLOAT; }
static inline 
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 181 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_bool(NanoValue v) { return v.tag == TAG_BOOL; }
static inline 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_string(NanoValue v) { return v.tag == TAG_STRING; }
static inline 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 183 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_array(NanoValue v) { return v.tag == TAG_ARRAY; }
static inline 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_struct(NanoValue v) { return v.tag == TAG_STRUCT; }
static inline 
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 185 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_union(NanoValue v) { return v.tag == TAG_UNION; }
static inline 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 186 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_tuple(NanoValue v) { return v.tag == TAG_TUPLE; }
static inline 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 187 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_hashmap(NanoValue v) { return v.tag == TAG_HASHMAP; }
static inline 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_function(NanoValue v) {
    return v.tag == TAG_FUNCTION || v.tag == TAG_CLOSURE;
}
static inline 
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_void(NanoValue v) { return v.tag == TAG_VOID; }
static inline 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
             _Bool 
# 192 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
                  val_is_heap_obj(NanoValue v) {
    return v.tag == TAG_STRING || v.tag == TAG_BSTRING || v.tag == TAG_ARRAY || v.tag == TAG_STRUCT ||
           v.tag == TAG_UNION || v.tag == TAG_TUPLE || v.tag == TAG_HASHMAP ||
           v.tag == TAG_CLOSURE;
}






void val_print(NanoValue v, FILE *out);


void val_println(NanoValue v);



# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
_Bool 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
    val_equal(NanoValue a, NanoValue b);


int val_compare(NanoValue a, NanoValue b);



# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h" 3 4
_Bool 
# 215 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/value.h"
    val_truthy(NanoValue v);


char *val_to_cstring(NanoValue v);
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 1
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 2
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
        is_utf8;
    
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
        null_terminated;
} nl_string_t;


static inline void nl_string_free_owned_storage(nl_string_t *str) {
    if (!str) return;
    free(str->data);
    free(str);
}
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
nl_string_t* nl_string_new(const char *cstr);





nl_string_t* nl_string_new_binary(const void *data, size_t length);





nl_string_t* nl_string_from_utf8(const char *utf8_data, size_t length);




nl_string_t* nl_string_with_capacity(size_t capacity);




void nl_string_free(nl_string_t *str);
# 78 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
size_t nl_string_length(const nl_string_t *str);




char nl_string_byte_at(const nl_string_t *str, size_t index);





# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_byte_at_safe(const nl_string_t *str, size_t index, char *out);





nl_string_t* nl_string_concat(const nl_string_t *a, const nl_string_t *b);





nl_string_t* nl_string_substring(const nl_string_t *str, size_t start, size_t length);





# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_equals(const nl_string_t *a, const nl_string_t *b);





# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 110 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_equals_cstr(const nl_string_t *str, const char *cstr);
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"

# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
    nl_string_validate_utf8(nl_string_t *str);






int64_t nl_string_utf8_length(const nl_string_t *str);





int32_t nl_string_utf8_char_at(const nl_string_t *str, size_t char_index);




nl_string_t* nl_string_utf8_substring(const nl_string_t *str, size_t char_start, size_t char_length);
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
const char* nl_string_to_cstr(nl_string_t *str);




const void* nl_string_to_binary(const nl_string_t *str, size_t *out_length);





void nl_string_ensure_null_terminated(nl_string_t *str);
# 170 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
void nl_string_reserve(nl_string_t *str, size_t new_capacity);




void nl_string_shrink_to_fit(nl_string_t *str);




nl_string_t* nl_string_clone(const nl_string_t *str);
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
int64_t nl_cstr_length(const char *s);


char *nl_cstr_concat(const char *a, const char *b);


char *nl_cstr_substring(const char *s, int64_t start, int64_t len);



# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 203 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nl_string.h"
           nl_cstr_contains(const char *haystack, const char *needle);


int64_t nl_cstr_index_of(const char *haystack, const char *needle);
int64_t nl_cstr_last_index_of(const char *haystack, const char *needle);


int64_t nl_cstr_char_at(const char *s, int64_t index);


char *nl_cstr_from_char(int64_t code);
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 2
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
typedef struct VmHeapHeader {
    uint32_t ref_count;
    uint8_t obj_type;
    uint8_t colour;
    uint8_t buffered;
} VmHeapHeader;






struct VmString {
    VmHeapHeader header;
    uint32_t length;
    uint32_t hash;
    struct VmString *intern_next;
    char data[];
};


struct VmBString {
    VmHeapHeader header;
    nl_string_t *value;
};
# 72 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
struct VmArray {
    VmHeapHeader header;
    uint8_t elem_type;
    uint8_t unboxed;
    uint32_t length;
    uint32_t capacity;
    NanoValue *elements;
    void *packed;
};




# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_array_type_unboxable(uint8_t elem_type);


size_t vm_array_elem_size(uint8_t elem_type);


struct VmStruct {
    VmHeapHeader header;
    uint32_t def_idx;
    uint32_t field_count;
    VmString **field_names;
    NanoValue *fields;
};


struct VmUnion {
    VmHeapHeader header;
    uint32_t def_idx;
    uint16_t variant;
    uint16_t field_count;
    NanoValue *fields;
};


struct VmTuple {
    VmHeapHeader header;
    uint32_t count;
    NanoValue elements[];
};


struct VmClosure {
    VmHeapHeader header;
    uint32_t fn_idx;
    uint32_t callable_module;
    uint16_t capture_count;
    NanoValue captures[];
};


typedef struct VmHMEntry {
    uint8_t state;
    NanoValue key;
    NanoValue value;
} VmHMEntry;


struct VmHashMap {
    VmHeapHeader header;
    uint8_t key_type;
    uint8_t val_type;
    uint32_t count;
    uint32_t tombstone_count;
    uint32_t bucket_count;
    VmHMEntry *entries;
};





typedef struct {
    size_t allocated;
    size_t freed;
    size_t num_objects;
    uint64_t allocation_calls;
    uint64_t retain_calls;
    uint64_t release_calls;
} VmHeapStats;

typedef struct VmHeap {
    VmHeapStats stats;



    VmString **intern_buckets;
    uint32_t intern_bucket_count;
    uint32_t intern_count;





    void **cycle_buf;
    uint32_t cycle_count;
    uint32_t cycle_capacity;
    uint64_t cycles_collected;
    
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
   _Bool 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
              gc_running;






} VmHeap;
# 194 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
uint64_t vm_gc_collect_cycles(VmHeap *heap);




void vm_gc_note_suspect(VmHeap *heap, NanoValue v);


void vm_gc_maybe_collect(VmHeap *heap);
void vm_gc_cycle_buffer_free(VmHeap *heap);


void vm_heap_init(VmHeap *heap);
void vm_heap_destroy(VmHeap *heap);


void vm_retain(VmHeap *heap, NanoValue v);
void vm_release(VmHeap *heap, NanoValue v);


VmBString *vm_bstring_adopt(VmHeap *heap, nl_string_t *owned);
void vm_bstring_clear(VmHeap *heap, VmBString *value);


VmString *vm_string_new(VmHeap *heap, const char *data, uint32_t length);
VmString *vm_string_concat(VmHeap *heap, VmString *a, VmString *b);
VmString *vm_string_substr(VmHeap *heap, VmString *s, uint32_t start, uint32_t len);


const char *vmstring_cstr(VmString *s);
uint32_t vmstring_len(VmString *s);

# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 225 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vmstring_equal(VmString *a, VmString *b);
int vmstring_compare(VmString *a, VmString *b);

# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 227 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vmstring_contains(VmString *haystack, VmString *needle);



int64_t vmstring_find(VmString *haystack, VmString *needle);
VmString *vmstring_char_at(VmHeap *heap, VmString *s, uint32_t index);


VmArray *vm_array_new(VmHeap *heap, uint8_t elem_type, uint32_t initial_capacity);


# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_array_push(VmHeap *heap, VmArray *a, NanoValue v);
NanoValue vm_array_pop(VmArray *a);
NanoValue vm_array_get(VmArray *a, uint32_t index);
void vm_array_set(VmArray *a, uint32_t index, NanoValue v);


void vm_array_swap_scalar_storage(VmArray *a, VmArray *b);
VmArray *vm_array_slice(VmHeap *heap, VmArray *a, uint32_t start, uint32_t end);







void vm_array_remove(VmHeap *heap, VmArray *a, uint32_t index);


VmStruct *vm_struct_new(VmHeap *heap, uint32_t def_idx, uint32_t field_count);


VmUnion *vm_union_new(VmHeap *heap, uint32_t def_idx, uint16_t variant, uint16_t field_count);


VmTuple *vm_tuple_new(VmHeap *heap, uint32_t count);


VmClosure *vm_closure_new(VmHeap *heap, uint32_t fn_idx, uint16_t capture_count);


VmHashMap *vm_hashmap_new(VmHeap *heap, uint8_t key_type, uint8_t val_type);
NanoValue vm_hashmap_get(VmHashMap *m, NanoValue key);


# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 270 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_hashmap_set(VmHeap *heap, VmHashMap *m, NanoValue key, NanoValue value);

# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 271 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_hashmap_has(VmHashMap *m, NanoValue key);
void vm_hashmap_delete(VmHeap *heap, VmHashMap *m, NanoValue key);
VmArray *vm_hashmap_keys(VmHeap *heap, VmHashMap *m);
VmArray *vm_hashmap_values(VmHeap *heap, VmHashMap *m);




# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
_Bool 
# 278 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
    vm_string_replacement_length(uint32_t source_length, uint32_t needle_length,
                                  uint32_t replacement_length, uint64_t count,
                                  uint32_t *out);
VmString *vm_string_from_int(VmHeap *heap, int64_t v);
VmString *vm_string_from_float(VmHeap *heap, double v);
VmString *vm_string_from_bool(VmHeap *heap, 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h" 3 4
                                           _Bool 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/heap.h"
                                                v);
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1
# 13 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 1
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
typedef enum {
    VM_SUPER_NONE = 0,

    VM_SUPER_LOAD_LOCAL_FIELD,
    VM_SUPER__COUNT
} VmSuperOp;
# 84 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
typedef struct {
    
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
   _Bool 
# 85 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
        fuse_load_local_field;
} VmDispatchProfile;


VmDispatchProfile vm_dispatch_profile_none(void);



VmDispatchProfile vm_dispatch_profile_all(void);



typedef struct {
    DecodedInstruction instruction;
    VmCallHandle call_handle;
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t next_index;
    uint32_t branch_target;
    uint32_t branch_target_offset;
    uint32_t call_target;




    uint16_t super_op;
    uint16_t super_operand;
} VmDispatchInstruction;

typedef struct {
    VmDispatchInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;

    uint32_t *offset_to_index;
} VmDispatchFunction;

typedef struct {
    VmDispatchFunction *functions;
    uint32_t function_count;
} VmDispatchModule;






typedef struct {
    const VmDispatchFunction *function;
    uint32_t index;
} VmDispatchCursor;





# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 140 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_build_function(const VmDecodedFunction *decoded,
                                VmDispatchProfile profile,
                                VmDispatchFunction *out,
                                char error[256]);




# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 147 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_build_module(const VmDecodedModule *decoded,
                              VmDispatchProfile profile,
                              VmDispatchModule *out,
                              char error[256]);

void vm_dispatch_function_free(VmDispatchFunction *function);
void vm_dispatch_module_free(VmDispatchModule *module);




# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h" 3 4
_Bool 
# 157 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm_dispatch.h"
    vm_dispatch_seek(VmDispatchCursor *cursor,
                      const VmDispatchFunction *function,
                      uint32_t byte_offset);


const VmDispatchInstruction *vm_dispatch_current(const VmDispatchCursor *cursor);


const VmDispatchInstruction *vm_dispatch_advance(VmDispatchCursor *cursor);
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/ownership_contracts.h" 1
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nano_callback.h" 1
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/nano_callback.h"
typedef enum {
    NANO_CALLBACK_VOID = 0,
    NANO_CALLBACK_INT = 1,
    NANO_CALLBACK_FLOAT = 2,
    NANO_CALLBACK_BOOL = 3,
    NANO_CALLBACK_BYTE = 4,
    NANO_CALLBACK_POINTER = 5
} NanoCallbackTag;

typedef struct {
    uint32_t tag;
    union { int64_t integer; double number; uint8_t byte; void *pointer; } as;
} NanoCallbackValue;

typedef struct {
    uint32_t argument_count;
    uint32_t result_tag;
    uint32_t argument_tags[16u];
} NanoCallbackSignature;

typedef enum {
    NANO_CALLBACK_OK = 0,
    NANO_CALLBACK_CANCELLED,
    NANO_CALLBACK_TYPE_ERROR,
    NANO_CALLBACK_EXECUTION_ERROR,
    NANO_CALLBACK_WRONG_THREAD,
    NANO_CALLBACK_BUSY
} NanoCallbackStatus;

typedef struct NanoCallbackV1 NanoCallbackV1;
struct NanoCallbackV1 {
    uint32_t abi_version;
    NanoCallbackSignature signature;
    void (*retain)(NanoCallbackV1 *callback);
    void (*release)(NanoCallbackV1 *callback);
    NanoCallbackStatus (*invoke)(NanoCallbackV1 *callback,
        const NanoCallbackValue *arguments, uint32_t count,
        NanoCallbackValue *result);
};
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 2


typedef struct NanoCallbackRuntime NanoCallbackRuntime;
typedef NanoCallbackStatus (*NanoCallbackExecute)(void *payload,
    const NanoCallbackValue *arguments, uint32_t count,
    NanoCallbackValue *result);
typedef void (*NanoCallbackDrop)(void *payload);




NanoCallbackRuntime *nano_callback_runtime_create(void);
NanoCallbackV1 *nano_callback_create(NanoCallbackRuntime *runtime,
    const NanoCallbackSignature *signature, NanoCallbackExecute execute,
    NanoCallbackDrop drop, void *payload);




int nano_callback_pump(NanoCallbackRuntime *runtime, 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h" 3 4
                                                    _Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/../runtime/callback_runtime.h"
                                                         wait);


void nano_callback_wake(NanoCallbackRuntime *runtime);
void nano_callback_collect(NanoCallbackRuntime *runtime);
NanoCallbackStatus nano_callback_close(NanoCallbackRuntime *runtime);
NanoCallbackStatus nano_callback_runtime_destroy(NanoCallbackRuntime *runtime);
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 1 "/usr/include/pthread.h" 1 3 4
# 22 "/usr/include/pthread.h" 3 4
# 1 "/usr/include/sched.h" 1 3 4
# 29 "/usr/include/sched.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 30 "/usr/include/sched.h" 2 3 4
# 43 "/usr/include/sched.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/sched.h" 1 3 4
# 80 "/usr/include/aarch64-linux-gnu/bits/sched.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 3 4

# 23 "/usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h" 3 4
struct sched_param
{
  int sched_priority;
};
# 81 "/usr/include/aarch64-linux-gnu/bits/sched.h" 2 3 4





extern int clone (int (*__fn) (void *__arg), void *__child_stack,
    int __flags, void *__arg, ...) __attribute__ ((__nothrow__ , __leaf__));


extern int unshare (int __flags) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getcpu (void) __attribute__ ((__nothrow__ , __leaf__));


extern int getcpu (unsigned int *, unsigned int *) __attribute__ ((__nothrow__ , __leaf__));


extern int setns (int __fd, int __nstype) __attribute__ ((__nothrow__ , __leaf__));



# 44 "/usr/include/sched.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 3 4
typedef unsigned long int __cpu_mask;






typedef struct
{
  __cpu_mask __bits[1024 / (8 * sizeof (__cpu_mask))];
} cpu_set_t;
# 115 "/usr/include/aarch64-linux-gnu/bits/cpu-set.h" 3 4


extern int __sched_cpucount (size_t __setsize, const cpu_set_t *__setp)
     __attribute__ ((__nothrow__ , __leaf__));
extern cpu_set_t *__sched_cpualloc (size_t __count) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern void __sched_cpufree (cpu_set_t *__set) __attribute__ ((__nothrow__ , __leaf__));


# 45 "/usr/include/sched.h" 2 3 4









extern int sched_setparam (__pid_t __pid, const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getparam (__pid_t __pid, struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_setscheduler (__pid_t __pid, int __policy,
          const struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getscheduler (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_yield (void) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_get_priority_max (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_get_priority_min (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));



extern int sched_rr_get_interval (__pid_t __pid, struct timespec *__t) __attribute__ ((__nothrow__ , __leaf__));
# 130 "/usr/include/sched.h" 3 4
extern int sched_setaffinity (__pid_t __pid, size_t __cpusetsize,
         const cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_getaffinity (__pid_t __pid, size_t __cpusetsize,
         cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));



# 23 "/usr/include/pthread.h" 2 3 4
# 1 "/usr/include/time.h" 1 3 4
# 29 "/usr/include/time.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 30 "/usr/include/time.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/time.h" 1 3 4
# 73 "/usr/include/aarch64-linux-gnu/bits/time.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timex.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/timex.h" 3 4
struct timex
{
# 58 "/usr/include/aarch64-linux-gnu/bits/timex.h" 3 4
  unsigned int modes;
  __syscall_slong_t offset;
  __syscall_slong_t freq;
  __syscall_slong_t maxerror;
  __syscall_slong_t esterror;
  int status;
  __syscall_slong_t constant;
  __syscall_slong_t precision;
  __syscall_slong_t tolerance;
  struct timeval time;
  __syscall_slong_t tick;
  __syscall_slong_t ppsfreq;
  __syscall_slong_t jitter;
  int shift;
  __syscall_slong_t stabil;
  __syscall_slong_t jitcnt;
  __syscall_slong_t calcnt;
  __syscall_slong_t errcnt;
  __syscall_slong_t stbcnt;

  int tai;


  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32;

};
# 74 "/usr/include/aarch64-linux-gnu/bits/time.h" 2 3 4




extern int clock_adjtime (__clockid_t __clock_id, struct timex *__utx) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 90 "/usr/include/aarch64-linux-gnu/bits/time.h" 3 4

# 34 "/usr/include/time.h" 2 3 4





# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_tm.h" 1 3 4






struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;


  long int tm_gmtoff;
  const char *tm_zone;




};
# 40 "/usr/include/time.h" 2 3 4
# 48 "/usr/include/time.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_itimerspec.h" 1 3 4







struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };
# 49 "/usr/include/time.h" 2 3 4
struct sigevent;
# 68 "/usr/include/time.h" 3 4




extern clock_t clock (void) __attribute__ ((__nothrow__ , __leaf__));



extern time_t time (time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));


extern double difftime (time_t __time1, time_t __time0)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
# 100 "/usr/include/time.h" 3 4
extern size_t strftime (char *__restrict __s, size_t __maxsize,
   const char *__restrict __format,
   const struct tm *__restrict __tp)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3, 4)));




extern char *strptime (const char *__restrict __s,
         const char *__restrict __fmt, struct tm *__tp)
     __attribute__ ((__nothrow__ , __leaf__));






extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     const char *__restrict __format,
     const struct tm *__restrict __tp,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));



extern char *strptime_l (const char *__restrict __s,
    const char *__restrict __fmt, struct tm *__tp,
    locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));






extern struct tm *gmtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));



extern struct tm *localtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
# 155 "/usr/include/time.h" 3 4
extern struct tm *gmtime_r (const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));



extern struct tm *localtime_r (const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));
# 180 "/usr/include/time.h" 3 4
extern char *asctime (const struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));



extern char *ctime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
# 198 "/usr/include/time.h" 3 4
extern char *asctime_r (const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



extern char *ctime_r (const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));
# 218 "/usr/include/time.h" 3 4
extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;




extern char *tzname[2];



extern void tzset (void) __attribute__ ((__nothrow__ , __leaf__));



extern int daylight;
extern long int timezone;
# 247 "/usr/include/time.h" 3 4
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
# 264 "/usr/include/time.h" 3 4
extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));







extern int dysize (int __year) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 282 "/usr/include/time.h" 3 4
extern int nanosleep (const struct timespec *__requested_time,
        struct timespec *__remaining);


extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__ , __leaf__));


extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int clock_settime (clockid_t __clock_id, const struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 324 "/usr/include/time.h" 3 4
extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       const struct timespec *__req,
       struct timespec *__rem);
# 339 "/usr/include/time.h" 3 4
extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__ , __leaf__));




extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__ , __leaf__));


extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));



extern int timer_settime (timer_t __timerid, int __flags,
     const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__ , __leaf__));


extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__ , __leaf__));
# 377 "/usr/include/time.h" 3 4
extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));






extern int timespec_get (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 400 "/usr/include/time.h" 3 4
extern int timespec_getres (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
# 426 "/usr/include/time.h" 3 4
extern int getdate_err;
# 435 "/usr/include/time.h" 3 4
extern struct tm *getdate (const char *__string);
# 449 "/usr/include/time.h" 3 4
extern int getdate_r (const char *__restrict __string,
        struct tm *__restrict __resbufp);



# 24 "/usr/include/pthread.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/setjmp.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/bits/setjmp.h" 3 4
__extension__ typedef unsigned long long __jmp_buf [22];
# 28 "/usr/include/pthread.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 29 "/usr/include/pthread.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 3 4
struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };
# 32 "/usr/include/pthread.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4

extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 34 "/usr/include/pthread.h" 2 3 4



enum
{
  PTHREAD_CREATE_JOINABLE,

  PTHREAD_CREATE_DETACHED

};



enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP

  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL



  , PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_TIMED_NP

};




enum
{
  PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_ROBUST,
  PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST
};





enum
{
  PTHREAD_PRIO_NONE,
  PTHREAD_PRIO_INHERIT,
  PTHREAD_PRIO_PROTECT
};
# 104 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP
};
# 124 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_INHERIT_SCHED,

  PTHREAD_EXPLICIT_SCHED

};



enum
{
  PTHREAD_SCOPE_SYSTEM,

  PTHREAD_SCOPE_PROCESS

};



enum
{
  PTHREAD_PROCESS_PRIVATE,

  PTHREAD_PROCESS_SHARED

};
# 159 "/usr/include/pthread.h" 3 4
struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);
  void *__arg;
  int __canceltype;
  struct _pthread_cleanup_buffer *__prev;
};


enum
{
  PTHREAD_CANCEL_ENABLE,

  PTHREAD_CANCEL_DISABLE

};
enum
{
  PTHREAD_CANCEL_DEFERRED,

  PTHREAD_CANCEL_ASYNCHRONOUS

};
# 197 "/usr/include/pthread.h" 3 4





extern int pthread_create (pthread_t *__restrict __newthread,
      const pthread_attr_t *__restrict __attr,
      void *(*__start_routine) (void *),
      void *__restrict __arg) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));





extern void pthread_exit (void *__retval) __attribute__ ((__noreturn__));







extern int pthread_join (pthread_t __th, void **__thread_return);




extern int pthread_tryjoin_np (pthread_t __th, void **__thread_return) __attribute__ ((__nothrow__ , __leaf__));
# 233 "/usr/include/pthread.h" 3 4
extern int pthread_timedjoin_np (pthread_t __th, void **__thread_return,
     const struct timespec *__abstime);
# 243 "/usr/include/pthread.h" 3 4
extern int pthread_clockjoin_np (pthread_t __th, void **__thread_return,
                                 clockid_t __clockid,
     const struct timespec *__abstime);
# 269 "/usr/include/pthread.h" 3 4
extern int pthread_detach (pthread_t __th) __attribute__ ((__nothrow__ , __leaf__));



extern pthread_t pthread_self (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int pthread_equal (pthread_t __thread1, pthread_t __thread2)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));







extern int pthread_attr_init (pthread_attr_t *__attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_destroy (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getdetachstate (const pthread_attr_t *__attr,
     int *__detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setdetachstate (pthread_attr_t *__attr,
     int __detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getguardsize (const pthread_attr_t *__attr,
          size_t *__guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setguardsize (pthread_attr_t *__attr,
          size_t __guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getschedparam (const pthread_attr_t *__restrict __attr,
           struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedparam (pthread_attr_t *__restrict __attr,
           const struct sched_param *__restrict
           __param) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_getschedpolicy (const pthread_attr_t *__restrict
     __attr, int *__restrict __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedpolicy (pthread_attr_t *__attr, int __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getinheritsched (const pthread_attr_t *__restrict
      __attr, int *__restrict __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setinheritsched (pthread_attr_t *__attr,
      int __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getscope (const pthread_attr_t *__restrict __attr,
      int *__restrict __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setscope (pthread_attr_t *__attr, int __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getstackaddr (const pthread_attr_t *__restrict
          __attr, void **__restrict __stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__deprecated__));





extern int pthread_attr_setstackaddr (pthread_attr_t *__attr,
          void *__stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__));


extern int pthread_attr_getstacksize (const pthread_attr_t *__restrict
          __attr, size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_attr_setstacksize (pthread_attr_t *__attr,
          size_t __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getstack (const pthread_attr_t *__restrict __attr,
      void **__restrict __stackaddr,
      size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3)));




extern int pthread_attr_setstack (pthread_attr_t *__attr, void *__stackaddr,
      size_t __stacksize) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int pthread_attr_setaffinity_np (pthread_attr_t *__attr,
     size_t __cpusetsize,
     const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern int pthread_attr_getaffinity_np (const pthread_attr_t *__attr,
     size_t __cpusetsize,
     cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));


extern int pthread_getattr_default_np (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_setsigmask_np (pthread_attr_t *__attr,
           const __sigset_t *sigmask);




extern int pthread_attr_getsigmask_np (const pthread_attr_t *__attr,
           __sigset_t *sigmask);







extern int pthread_setattr_default_np (const pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_getattr_np (pthread_t __th, pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));







extern int pthread_setschedparam (pthread_t __target_thread, int __policy,
      const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));


extern int pthread_getschedparam (pthread_t __target_thread,
      int *__restrict __policy,
      struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));


extern int pthread_setschedprio (pthread_t __target_thread, int __prio)
     __attribute__ ((__nothrow__ , __leaf__));




extern int pthread_getname_np (pthread_t __target_thread, char *__buf,
          size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int pthread_setname_np (pthread_t __target_thread, const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





extern int pthread_getconcurrency (void) __attribute__ ((__nothrow__ , __leaf__));


extern int pthread_setconcurrency (int __level) __attribute__ ((__nothrow__ , __leaf__));



extern int pthread_yield (void) __attribute__ ((__nothrow__ , __leaf__));

extern int pthread_yield (void) __asm__ ("" "sched_yield") __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("pthread_yield is deprecated, use sched_yield instead")))
                                                      ;







extern int pthread_setaffinity_np (pthread_t __th, size_t __cpusetsize,
       const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));


extern int pthread_getaffinity_np (pthread_t __th, size_t __cpusetsize,
       cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 509 "/usr/include/pthread.h" 3 4
extern int pthread_once (pthread_once_t *__once_control,
    void (*__init_routine) (void)) __attribute__ ((__nonnull__ (1, 2)));
# 521 "/usr/include/pthread.h" 3 4
extern int pthread_setcancelstate (int __state, int *__oldstate);



extern int pthread_setcanceltype (int __type, int *__oldtype);


extern int pthread_cancel (pthread_t __th);




extern void pthread_testcancel (void);




struct __cancel_jmp_buf_tag
{
  __jmp_buf __cancel_jmp_buf;
  int __mask_was_saved;
};

typedef struct
{
  struct __cancel_jmp_buf_tag __cancel_jmp_buf[1];
  void *__pad[4];
} __pthread_unwind_buf_t __attribute__ ((__aligned__));
# 557 "/usr/include/pthread.h" 3 4
struct __pthread_cleanup_frame
{
  void (*__cancel_routine) (void *);
  void *__cancel_arg;
  int __do_it;
  int __cancel_type;
};
# 697 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel (__pthread_unwind_buf_t *__buf)
     ;
# 709 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel (__pthread_unwind_buf_t *__buf)
  ;
# 732 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel_defer (__pthread_unwind_buf_t *__buf)
     ;
# 745 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel_restore (__pthread_unwind_buf_t *__buf)
  ;



extern void __pthread_unwind_next (__pthread_unwind_buf_t *__buf)
     __attribute__ ((__noreturn__))

     __attribute__ ((__weak__))

     ;
# 766 "/usr/include/pthread.h" 3 4
extern int __sigsetjmp_cancel (struct __cancel_jmp_buf_tag __env[1], int __savemask) __asm__ ("" "__sigsetjmp") __attribute__ ((__nothrow__))


                     __attribute__ ((__returns_twice__));
# 781 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_init (pthread_mutex_t *__mutex,
          const pthread_mutexattr_t *__mutexattr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_trylock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_lock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_mutex_timedlock (pthread_mutex_t *__restrict __mutex,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 817 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_clocklock (pthread_mutex_t *__restrict __mutex,
        clockid_t __clockid,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 835 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_unlock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutex_getprioceiling (const pthread_mutex_t *
      __restrict __mutex,
      int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutex_setprioceiling (pthread_mutex_t *__restrict __mutex,
      int __prioceiling,
      int *__restrict __old_ceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));




extern int pthread_mutex_consistent (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_consistent_np (pthread_mutex_t *) __asm__ ("" "pthread_mutex_consistent") __attribute__ ((__nothrow__ , __leaf__))
                                __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutex_consistent_np is deprecated, use pthread_mutex_consistent")))
                                                                         ;
# 874 "/usr/include/pthread.h" 3 4
extern int pthread_mutexattr_init (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getpshared (const pthread_mutexattr_t *
      __restrict __attr,
      int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
      int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_gettype (const pthread_mutexattr_t *__restrict
          __attr, int *__restrict __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getprotocol (const pthread_mutexattr_t *
       __restrict __attr,
       int *__restrict __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutexattr_setprotocol (pthread_mutexattr_t *__attr,
       int __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getprioceiling (const pthread_mutexattr_t *
          __restrict __attr,
          int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setprioceiling (pthread_mutexattr_t *__attr,
          int __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getrobust (const pthread_mutexattr_t *__attr,
     int *__robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_getrobust_np (pthread_mutexattr_t *, int *) __asm__ ("" "pthread_mutexattr_getrobust") __attribute__ ((__nothrow__ , __leaf__))

                                   __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_getrobust_np is deprecated, use pthread_mutexattr_getrobust")))
                                                                               ;






extern int pthread_mutexattr_setrobust (pthread_mutexattr_t *__attr,
     int __robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_setrobust_np (pthread_mutexattr_t *, int) __asm__ ("" "pthread_mutexattr_setrobust") __attribute__ ((__nothrow__ , __leaf__))

                                   __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_setrobust_np is deprecated, use pthread_mutexattr_setrobust")))
                                                                               ;
# 967 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_init (pthread_rwlock_t *__restrict __rwlock,
    const pthread_rwlockattr_t *__restrict
    __attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_destroy (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_rdlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_tryrdlock (pthread_rwlock_t *__rwlock)
  __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedrdlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1004 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockrdlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1023 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_wrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_trywrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedwrlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1051 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockwrlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1071 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_unlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int pthread_rwlockattr_init (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_destroy (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getpshared (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setpshared (pthread_rwlockattr_t *__attr,
       int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getkind_np (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pref)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setkind_np (pthread_rwlockattr_t *__attr,
       int __pref) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int pthread_cond_init (pthread_cond_t *__restrict __cond,
         const pthread_condattr_t *__restrict __cond_attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_destroy (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_signal (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_broadcast (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_cond_wait (pthread_cond_t *__restrict __cond,
         pthread_mutex_t *__restrict __mutex)
     __attribute__ ((__nonnull__ (1, 2)));
# 1145 "/usr/include/pthread.h" 3 4
extern int pthread_cond_timedwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 3)));
# 1171 "/usr/include/pthread.h" 3 4
extern int pthread_cond_clockwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       __clockid_t __clock_id,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 4)));
# 1194 "/usr/include/pthread.h" 3 4
extern int pthread_condattr_init (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_destroy (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_getpshared (const pthread_condattr_t *
     __restrict __attr,
     int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setpshared (pthread_condattr_t *__attr,
     int __pshared) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_condattr_getclock (const pthread_condattr_t *
          __restrict __attr,
          __clockid_t *__restrict __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setclock (pthread_condattr_t *__attr,
          __clockid_t __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1230 "/usr/include/pthread.h" 3 4
extern int pthread_spin_init (pthread_spinlock_t *__lock, int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_destroy (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_lock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_trylock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_unlock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_barrier_init (pthread_barrier_t *__restrict __barrier,
     const pthread_barrierattr_t *__restrict
     __attr, unsigned int __count)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_destroy (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_wait (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_barrierattr_init (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_destroy (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_getpshared (const pthread_barrierattr_t *
        __restrict __attr,
        int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_barrierattr_setpshared (pthread_barrierattr_t *__attr,
        int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1297 "/usr/include/pthread.h" 3 4
extern int pthread_key_create (pthread_key_t *__key,
          void (*__destr_function) (void *))
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_key_delete (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));


extern void *pthread_getspecific (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));


extern int pthread_setspecific (pthread_key_t __key,
    const void *__pointer)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__access__ (__none__, 2)));




extern int pthread_getcpuclockid (pthread_t __thread_id,
      __clockid_t *__clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 1332 "/usr/include/pthread.h" 3 4
extern int pthread_atfork (void (*__prepare) (void),
      void (*__parent) (void),
      void (*__child) (void)) __attribute__ ((__nothrow__ , __leaf__));




extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) pthread_equal (pthread_t __thread1, pthread_t __thread2)
{
  return __thread1 == __thread2;
}



# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 2
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"

# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
typedef struct {
    uint32_t key;
    uint64_t count;
    
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        used;
} VmProfileTriple;

typedef struct {
    
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        enabled;
    
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        has_previous;
    
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        has_previous_pair;
    uint8_t previous;
    uint16_t previous_pair;
    uint64_t retired;
    uint64_t opcode_counts[256];
    uint64_t pair_counts[256 * 256];
    VmProfileTriple triples[4096];
    uint64_t branches;
    uint64_t branches_taken;
    uint64_t direct_calls;
    uint64_t indirect_calls;
    uint64_t extern_calls;
    uint64_t module_calls;
    uint64_t traps;
    uint64_t ffi_request_bytes;
    uint64_t ffi_response_bytes;
    uint64_t ffi_elapsed_ns;
    uint64_t ffi_failures;
    uint32_t max_stack_depth;
    uint32_t max_frame_depth;
} VmProfile;

typedef struct {
    VmString **strings;
    uint32_t count;
} VmModuleConstants;





typedef struct {
    uint32_t effect_owner;
    uint16_t effect_local_start;
    uint32_t fn_idx;
    uint32_t return_ip;
    uint32_t instruction_ip;
    uint32_t stack_base;
    uint16_t local_count;
    VmClosure *closure;






    NanoValue owned_callable;
    const NvmModule *module;
    uint32_t current_line;
    uint32_t current_col;
} VmCallFrame;





typedef enum {
    VM_OK = 0,
    VM_ERR_STACK_OVERFLOW,
    VM_ERR_STACK_UNDERFLOW,
    VM_ERR_CALL_DEPTH,
    VM_ERR_INVALID_OPCODE,
    VM_ERR_TYPE_ERROR,
    VM_ERR_OUT_OF_BOUNDS,
    VM_ERR_DIV_ZERO,
    VM_ERR_ASSERT_FAILED,
    VM_ERR_UNDEFINED_GLOBAL,
    VM_ERR_UNDEFINED_FUNCTION,
    VM_ERR_NOT_IMPLEMENTED,
    VM_ERR_MEMORY,
    VM_ERR_DECODE
} VmResult;





typedef struct {
    const NvmModule *module;
    uint32_t operation, target, owner;
    uint16_t parameter_start, parameter_count;
} VmEffectHandler;



typedef struct {
    uint16_t root;
    uint32_t region;
    
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        exclusive;
    uint32_t path;
    uint16_t parent;
    
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 129 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        live;
    uint16_t origin_frame;
    uint64_t origin_generation;
} VmReferenceSlot;
typedef struct {
    VmReferenceSlot slots[256];
    uint32_t region;
    
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        active;
    uint64_t generation;
} VmReferenceActivation;

typedef struct VmState {

    const NvmModule *module;
    const NvmModule *root_module;
    VmDecodedModule decoded_module;
    
# 145 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 145 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        decoded_module_valid;


    
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 148 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        module_calls_resolved;

    uint64_t module_revision;
    VmDispatchModule dispatch_module;
    
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        dispatch_module_valid;







    
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        verified; VmModuleConstants module_constants;


    NanoValue *stack;
    uint32_t stack_size;
    uint32_t stack_capacity;


    VmCallFrame frames[1024];
    uint32_t frame_count;
    VmReferenceActivation references, callee_references;


    VmReferenceActivation value_references[8u -2];

    VmReferenceActivation *effect_references[1024 -8u];
    uint64_t reference_generation;
    VmEffectHandler handlers[1024];
    uint32_t handler_count;
    uint32_t activation_floor;
    pthread_t owner_thread;
    NanoCallbackRuntime *callbacks;
    
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 182 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        callbacks_closed;
    VmResult callback_error;
    char callback_error_msg[256];


    uint32_t ip;
    uint32_t current_fn;






    NanoValue *globals;
    uint32_t global_capacity;
    uint32_t global_count;


    uint8_t *memory;
    uint64_t memory_size;


    VmHeap heap;


    const NvmModule **linked_modules;
    VmDecodedModule *decoded_linked_modules;
    
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 209 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        *decoded_linked_modules_valid;
    VmDispatchModule *dispatch_linked_modules;
    
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 211 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        *dispatch_linked_modules_valid;
    VmModuleConstants *linked_module_constants;
    uint32_t linked_module_count;
    uint32_t linked_module_capacity;


    FILE *output;


    
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 220 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        isolate_ffi;

    
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 222 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        halt_requested;


    int cop_in_fd;
    int cop_out_fd;
    int cop_pid;


    struct CopMailbox *cop_mailbox;
    size_t cop_mailbox_size;
    int cop_sig_send_fd;
    int cop_sig_recv_fd;
    int cop_timeout_ms;


    VmResult last_error;
    char error_msg[256];



    
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 242 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        debug_mode;


    
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
   _Bool 
# 245 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
        opcode_trace;


    VmProfile profile;




    VmDispatchProfile dispatch_profile;
} VmState;
# 269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
typedef enum {
    TRAP_NONE = 0,
    TRAP_EXTERN_CALL,
    TRAP_PRINT,
    TRAP_ASSERT,
    TRAP_HALT,
    TRAP_ERROR,
    TRAP_YIELD
} VmTrapType;

typedef struct {
    VmTrapType type;
    union {
        struct { uint32_t import_idx; NanoValue args[16]; int argc; } extern_call;
        struct { NanoValue value; 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                 _Bool 
# 283 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                      newline; } print;
        struct { NanoValue condition; } assert_check;
        struct { VmResult code; } error;
    } data;
} VmTrap;






void vm_init(VmState *vm, const NvmModule *module);


void vm_destroy(VmState *vm);




VmResult vm_execute(VmState *vm);




VmResult vm_call_function(VmState *vm, uint32_t fn_idx, NanoValue *args, uint16_t arg_count);







VmResult vm_invoke(VmState *vm, uint32_t fn_idx, const NanoValue *args,
                   uint16_t arg_count, NanoValue *out_result);





VmResult vm_invoke_callable(VmState *vm, NanoValue callable, const NanoValue *args,
                            uint16_t arg_count, NanoValue *out_result);



NanoCallbackV1 *vm_callback_create(VmState *vm, NanoValue callable,
                                  const NvmCallbackContract *contract);
int vm_callback_pump(VmState *vm, 
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                 _Bool 
# 329 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                      wait);
NanoCallbackStatus vm_callback_shutdown(VmState *vm);




VmTrap vm_core_execute(VmState *vm);


NanoValue vm_get_result(VmState *vm);


void vm_profile_enable(VmState *vm, 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
                                   _Bool 
# 341 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
                                        enabled);





void vm_set_dispatch_profile(VmState *vm, VmDispatchProfile profile);



# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_profile_write_json(const VmState *vm, FILE *out);


const char *vm_error_string(VmResult result);



uint32_t vm_link_module(VmState *vm, const NvmModule *mod);




# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 361 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_callable_target(const VmState *vm, NanoValue callable,
                        const NvmModule **module, uint32_t *function_index);



uint32_t vm_link_named_module(VmState *vm, const char *name,
                              const NvmModule *mod);





# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 372 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_ensure_globals(VmState *vm, uint32_t count);






# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 378 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_resolve_module_calls(VmState *vm);


void vm_invalidate_module(VmState *vm, const NvmModule *module);
void vm_invalidate_decoded_module(VmState *vm, const NvmModule *module);



# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_rebuild_module(VmState *vm, const NvmModule *module);
VmResult vm_rebuild_decoded_module(VmState *vm, const NvmModule *module);




# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 390 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_sync_new_functions(VmState *vm, const NvmModule *module);


void vm_request_halt(VmState *vm);



# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h" 3 4
_Bool 
# 396 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
    vm_memory_resize(VmState *vm, uint64_t size);
# 407 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/../nanovm/vm.h"
void vm_stack_trace(const VmState *vm, FILE *out);
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2







static NvmVerifyResult ok_result(void) {
    return (NvmVerifyResult){ .ok = 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                   1
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                       , .error_msg = "" };
}

static NvmVerifyResult fail(const char *fmt, ...) {
    NvmVerifyResult r = { .ok = 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                               0 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                     };
    va_list ap;
    
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   __builtin_va_start(
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
   ap
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   ,
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
   fmt
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   )
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                    ;
    vsnprintf(r.error_msg, 256, fmt, ap);
    
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   __builtin_va_end(
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
   ap
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   )
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
             ;
    return r;
}

static 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
      _Bool 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
           instruction_index_at(const VmDecodedFunction *decoded,
                                 uint32_t byte_offset, uint32_t *index) {
    if (byte_offset == decoded->code_size) {
        *index = decoded->instruction_count;
        return 
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
              1
# 53 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                  ;
    }
    const VmDecodedInstruction *instruction =
        vm_decoded_function_at(decoded, byte_offset);
    if (!instruction) return 
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                            0
# 57 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                 ;
    *index = (uint32_t)(instruction - decoded->instructions);
    return 
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
          1
# 59 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              ;
}






static NvmVerifyResult verify_stack_heights(const NvmModule *mod,
                                            const VmDecodedFunction *decoded,
                                            uint32_t fn_idx,
                                            uint16_t *out_max_stack) {
    int32_t *heights = malloc((decoded->instruction_count + 1) * sizeof(*heights));
    uint32_t *work = malloc((decoded->instruction_count + 1) * sizeof(*work));
    if (!heights || !work) {
        free(heights);
        free(work);
        return fail("function[%u] could not allocate stack verifier state", fn_idx);
    }







    int32_t *owed = malloc((decoded->instruction_count + 1) * sizeof(*owed));
    if (!owed) {
        free(heights);
        free(work);
        return fail("function[%u] could not allocate stack verifier state", fn_idx);
    }
    for (uint32_t i = 0; i <= decoded->instruction_count; i++) owed[i] = -1;
    owed[0] = 0;

    int32_t max_depth = 0;
    for (uint32_t i = 0; i <= decoded->instruction_count; i++) heights[i] = -1;
    uint32_t head = 0, tail = 0;
    heights[0] = 0;
    work[tail++] = 0;

    while (head < tail) {
        uint32_t index = work[head++];
        if (index == decoded->instruction_count) continue;
        const VmDecodedInstruction *decoded_instruction = &decoded->instructions[index];
        const DecodedInstruction *instruction = &decoded_instruction->instruction;
        const InstructionInfo *info = isa_get_info(instruction->opcode);
        int32_t pop_count = info->pop_count;
        int32_t push_count = info->push_count;
        switch (instruction->opcode) {
        case OP_CALL:
        case OP_TAIL_CALL: {
            const NvmFunctionEntry *callee =
                &mod->functions[instruction->operands[0].u32];
            pop_count = callee->arity;
            push_count = callee->result_count;
            break;
        }
        case OP_CALL_EXTERN: {
            const NvmImportEntry *import =
                &mod->imports[instruction->operands[0].u32];
            pop_count = import->param_count;
            push_count = import->return_type == TAG_VOID ? 0 : 1;
            break;
        }
        case OP_CLOSURE_NEW:
            pop_count = instruction->operands[1].u16;
            push_count = 1;
            break;
        case OP_STRUCT_LITERAL:
            pop_count = instruction->operands[1].u16;
            push_count = 1;
            break;
        case OP_UNION_CONSTRUCT:
            pop_count = instruction->operands[2].u16;
            push_count = 1;
            break;
        case OP_TUPLE_NEW:
            pop_count = instruction->operands[0].u16;
            push_count = 1;
            break;
        case OP_AGG_PACK:
            pop_count = instruction->operands[3].u16;
            push_count = 1;
            break;
        case OP_ARR_LITERAL:
            pop_count = instruction->operands[1].u16;
            push_count = 1;
            break;
        case OP_CALL_INDIRECT:



            pop_count = (int32_t)instruction->operands[0].u16 + 1;
            push_count = instruction->operands[1].u16;
            break;
        case OP_CALL_MODULE:





            pop_count = instruction->operands[2].u16;
            push_count = instruction->operands[3].u16;
            break;
        case OP_PERFORM:
            pop_count = instruction->operands[1].u16;
            push_count = 1;
            break;
        case OP_RET:


            pop_count = mod->functions[fn_idx].result_count;
            push_count = 0;
            break;




        case OP_PICK:
            pop_count = instruction->operands[0].u16 + 1;
            push_count = instruction->operands[0].u16 + 2;
            break;
        case OP_ROLL:
            pop_count = instruction->operands[0].u16 + 1;
            push_count = instruction->operands[0].u16 + 1;
            break;
        default:
            break;
        }






        if (pop_count < 0 || push_count < 0) {
            free(heights);
            free(work);
            free(owed);
            return fail("function[%u] %s at offset %u has no known stack effect",
                        fn_idx, info->name, decoded_instruction->byte_offset);
        }
        int32_t before = heights[index];





        if (instruction->opcode == OP_RET
                && before != (int32_t)mod->functions[fn_idx].result_count) {
            free(heights);
            free(work);
            free(owed);
            return fail("function[%u] returns with %d values at offset %u but declares %u",
                        fn_idx, before, decoded_instruction->byte_offset,
                        mod->functions[fn_idx].result_count);
        }

        if (instruction->opcode == OP_HANDLER_PUSH && owed[index] != 0) {
            free(heights); free(work); free(owed);
            return fail("I cannot install a nonlocal-return handler across outstanding explicit retains.");
        }
        if (instruction->opcode == OP_EFFECT_RESUME && (before != 1 || owed[index] != 0)) {
            free(heights); free(work); free(owed);
            return fail("I require one result and balanced ownership when resuming an effect.");
        }
        if (before < pop_count) {
            free(heights);
            free(work);
            free(owed);
            return fail("function[%u] stack underflow at offset %u (%s needs %d, has %d)",
                        fn_idx, decoded_instruction->byte_offset, info->name,
                        pop_count, before);
        }
        int32_t after = before - pop_count + push_count;


        int32_t owed_before = owed[index];
        int32_t owed_after = owed_before;
        if (instruction->opcode == OP_GC_RETAIN) owed_after++;
        else if (instruction->opcode == OP_GC_RELEASE) owed_after--;
        if (owed_after < 0) {
            free(heights);
            free(work);
            free(owed);
            return fail("function[%u] releases a reference it does not hold at offset %u",
                        fn_idx, decoded_instruction->byte_offset);
        }
        if (instruction->opcode == OP_RET && owed_before != 0) {
            free(heights);
            free(work);
            free(owed);
            return fail("function[%u] returns at offset %u still holding %d retained reference(s)",
                        fn_idx, decoded_instruction->byte_offset, owed_before);
        }



        if (before > max_depth) max_depth = before;
        if (after > max_depth) max_depth = after;
        uint32_t successors[2];
        uint32_t successor_count = 0;
        uint8_t opcode = instruction->opcode;
        if (opcode == OP_JMP || opcode == OP_JMP_TRUE || opcode == OP_JMP_FALSE
                || opcode == OP_MATCH_TAG || opcode == OP_HANDLER_PUSH) {
# 275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
            uint32_t base = mod->functions[fn_idx].code_offset;
            uint32_t target = decoded_instruction->resolved_target;
            uint32_t target_index;
            if (target < base
                    || !instruction_index_at(decoded, target - base, &target_index)) {
                free(heights);
                free(work);
                free(owed);
                return fail("function[%u] branch at offset %u targets %u, which is "
                            "not an instruction boundary in this function",
                            fn_idx, decoded_instruction->byte_offset, target);
            }
            successors[successor_count++] = target_index;
        }
        if (opcode != OP_JMP && opcode != OP_RET && opcode != OP_TAIL_CALL
                && opcode != OP_HALT && opcode != OP_EFFECT_RESUME) {
            successors[successor_count++] = index + 1;
        }
        for (uint32_t i = 0; i < successor_count; i++) {
            uint32_t successor = successors[i];
            int32_t successor_height = opcode == OP_HANDLER_PUSH && i == 0 ? 0 : after;
            int32_t successor_owed = opcode == OP_HANDLER_PUSH && i == 0 ? 0 : owed_after;






            if (successor == decoded->instruction_count) {
                if (owed_after != 0) {
                    free(heights);
                    free(work);
                    free(owed);
                    return fail("function[%u] reaches its end after offset %u still holding "
                                "%d retained reference(s)",
                                fn_idx, decoded_instruction->byte_offset, owed_after);
                }
                if (after != (int32_t)mod->functions[fn_idx].result_count) {
                    free(heights);
                    free(work);
                    free(owed);
                    return fail("function[%u] reaches its end after offset %u with %d values "
                                "but declares %u",
                                fn_idx, decoded_instruction->byte_offset, after,
                                mod->functions[fn_idx].result_count);
                }
                continue;
            }
            if (heights[successor] < 0) {
                heights[successor] = successor_height;
                owed[successor] = successor_owed;
                work[tail++] = successor;
            } else if (owed[successor] != successor_owed) {
                uint32_t offset = decoded->instructions[successor].byte_offset;
                int32_t existing = owed[successor];
                free(heights);
                free(work);
                free(owed);
                return fail("function[%u] incompatible ownership balance at offset %u (%d and %d)",
                            fn_idx, offset, existing, successor_owed);
            } else if (heights[successor] != successor_height) {
                uint32_t offset = successor == decoded->instruction_count
                    ? decoded->code_size : decoded->instructions[successor].byte_offset;
                int32_t existing = heights[successor];
                free(heights);
                free(work);
                free(owed);
                return fail("function[%u] incompatible stack heights at offset %u (%d and %d)",
                            fn_idx, offset, existing, successor_height);
            }
        }
    }
    free(heights);
    free(work);
    free(owed);




    if ((uint32_t)mod->functions[fn_idx].local_count + (uint32_t)max_depth > 
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                            (65535)
# 354 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                      )
        return fail("function[%u] frame needs %u slots (%u locals + operand depth %d), "
                    "more than a frame can address",
                    fn_idx,
                    (uint32_t)mod->functions[fn_idx].local_count + (uint32_t)max_depth,
                    mod->functions[fn_idx].local_count, max_depth);

    if (out_max_stack) {
        if (max_depth > 
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                       (65535)
# 362 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                 )
            return fail("function[%u] maximum operand depth %d exceeds %u",
                        fn_idx, max_depth, (unsigned)
# 364 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                    (65535)
# 364 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                              );
        *out_max_stack = (uint16_t)max_depth;
    }
    return ok_result();
}







static NvmVerifyResult verify_module_ranges(const NvmModule *mod) {
    if (!mod) return fail("module is NULL");
    if (nvm_service_execution_pending(mod))
        return fail("I require reviewed service lifetime and dispatch admission before execution");
    if (!mod->code && mod->code_size > 0)
        return fail("code pointer is NULL but code_size=%u", mod->code_size);


    if (mod->header.flags & (1 << 0)) {
        if (mod->header.entry_point >= mod->function_count)
            return fail("entry_point %u >= function_count %u",
                        mod->header.entry_point, mod->function_count);
    }


    for (uint32_t i = 0; i < mod->function_count; i++) {
        const NvmFunctionEntry *fn = &mod->functions[i];
        if (fn->code_offset > mod->code_size)
            return fail("function[%u] code_offset %u > code_size %u",
                        i, fn->code_offset, mod->code_size);

        if (fn->code_length > mod->code_size - fn->code_offset)
            return fail("function[%u] code range exceeds code_size: offset %u, length %u, code_size %u",
                        i, fn->code_offset, fn->code_length, mod->code_size);
        if (fn->name_idx >= mod->string_count)
            return fail("function[%u] name_idx %u >= string_count %u",
                        i, fn->name_idx, mod->string_count);
        if (fn->result_tag >= TAG_COUNT)
            return fail("function[%u] result_tag %u is invalid",
                        i, fn->result_tag);
        if (mod->function_param_types && mod->function_param_types[i]) {
            for (uint16_t p = 0; p < fn->arity; p++) {
                if (mod->function_param_types[i][p] >= TAG_COUNT)
                    return fail("I found an invalid parameter tag in function[%u] parameter[%u]", i, p);
            }
        }
        if ((fn->result_count == 0) != (fn->result_tag == TAG_VOID))
            return fail("function[%u] result signature must be void/0 or non-void/nonzero", i);
        if (fn->local_count < fn->arity)
            return fail("function[%u] local_count %u is smaller than arity %u",
                        i, fn->local_count, fn->arity);



        if (fn->code_length != 0) {
            uint32_t fn_end = fn->code_offset + fn->code_length;
            for (uint32_t j = 0; j < i; j++) {
                const NvmFunctionEntry *other = &mod->functions[j];
                if (other->code_length == 0) continue;


                uint32_t other_end = other->code_offset + other->code_length;
                if (fn->code_offset < other_end && other->code_offset < fn_end)
                    return fail("function[%u] code range overlaps function[%u]", i, j);
            }
        }
    }

    return ok_result();
}

static NvmVerifyResult verify_module_contracts_and_imports(const NvmModule *mod) {
    if (!nvm_passive_valid(mod))
        return fail("I found invalid passive eligibility metadata");

    if (!nvm_callback_contracts_valid(mod))
        return fail("I found an invalid retained callback import contract");





    for (uint32_t i = 0; i < mod->import_count; i++) {
        const NvmImportEntry *imp = &mod->imports[i];
        if (imp->module_name_idx >= mod->string_count)
            return fail("import[%u] module_name_idx %u >= string_count %u",
                        i, imp->module_name_idx, mod->string_count);
        if (imp->function_name_idx >= mod->string_count)
            return fail("import[%u] function_name_idx %u >= string_count %u",
                        i, imp->function_name_idx, mod->string_count);
        if (imp->kind > NVM_IMPORT_ARTIFACT)
            return fail("import[%u] has unknown kind %u", i, imp->kind);
        if (imp->kind == NVM_IMPORT_ARTIFACT) {
            const char *path = nvm_get_string(mod, imp->module_name_idx);
            if (!path || path[0] != '/' || strlen(path) != nvm_get_string_len(mod, imp->module_name_idx))
                return fail("import[%u] artifact path must be absolute and contain no NUL", i);
        }
        if (imp->return_type >= TAG_COUNT)
            return fail("import[%u] return_type %u is not a valid value tag",
                        i, imp->return_type);
        if (imp->param_count > 16)
            return fail("import[%u] param_count %u exceeds the foreign-call "
                        "argument limit of %u",
                        i, imp->param_count, (unsigned)16);
        if (imp->param_count > 0 && !mod->import_param_types[i])
            return fail("import[%u] declares %u params but has no param type array",
                        i, imp->param_count);
        for (uint16_t p = 0; p < imp->param_count; p++) {
            uint8_t tag = mod->import_param_types[i][p];
            if (tag >= TAG_COUNT)
                return fail("import[%u] param[%u] type %u is not a valid value tag",
                            i, p, tag);
        }
    }

    return ok_result();
}

static NvmVerifyResult verify_structure_checked(const NvmModule *mod, 
# 484 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                     _Bool 
# 484 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                          affine_only,
                                        
# 485 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                       _Bool 
# 485 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                            *owned_admitted, 
# 485 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                             _Bool 
# 485 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                  mixed_composed) {
    if (owned_admitted) *owned_admitted=
# 486 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                       0
# 486 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                            ;
    
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        admitted=
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                 0
# 487 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                      ;
    NvmVerifyResult ranges = verify_module_ranges(mod);
    if (!ranges.ok) return ranges;

    
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        needs_ownership = 
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                          0
# 491 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                               ;
    if (!mixed_composed && nvm_ownership_contracts_validate(mod, &needs_ownership) != NVM_V2_OK)
        return fail("I found invalid ownership declarations");
    if (needs_ownership && !affine_only) {
        for (uint32_t i=0;i<mod->function_count;i++) {
            NvmAffineAnalysis analysis=nvm_affine_analyze_function(mod,i);
            if (!analysis.ok) return fail("I refuse reference lifetime and ownership instruction dataflow in function[%u] at %u: %s",
                                          i,analysis.byte_offset,analysis.message);
        }
        NvmVerifyResult admission = nvm_verify_owned_module(mod);
        if (!admission.ok) return admission;
        admitted=
# 502 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                1
# 502 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                    ;
    }

    if (!nvm_retained_layouts_valid(mod))
        return fail("I found invalid retained layout metadata");

    NvmVerifyResult contracts = verify_module_contracts_and_imports(mod);
    if (!contracts.ok) return contracts;

    if (owned_admitted) *owned_admitted=admitted;
    return ok_result();
}



static NvmVerifyResult verify_structure(const NvmModule *mod, 
# 517 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                             _Bool 
# 517 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                  affine_only,
                                        
# 518 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                       _Bool 
# 518 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                            *owned_admitted) {
    return verify_structure_checked(mod,affine_only,owned_admitted,
# 519 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                  0
# 519 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                       );
}
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_layout_view.h" 1





typedef enum {
    NVM_MIXED_UNKNOWN, NVM_MIXED_RESOURCE,
    NVM_MIXED_ORDINARY_STRUCTURAL, NVM_MIXED_PENDING_ARRAY_PROOF
} NvmMixedLayoutClass;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count, managed_count;
    uint32_t source_to_global[256u];
    uint32_t global_to_source[256u];
    uint32_t managed_to_global[256u];
    uint32_t global_to_managed[256u];
    NvmMixedLayoutClass classes[256u];
    uint8_t *ownership;
    uint32_t ownership_size;
} NvmMixedLayoutView;

NvmRecordPlanResult nvm_describe_mixed_layouts(const NvmModule *, NvmMixedLayoutView **);
void nvm_mixed_layout_view_free(NvmMixedLayoutView *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 2




typedef enum {
    NVM_MIXED_SHAPE_PROVED, NVM_MIXED_SHAPE_UNRESOLVED,
    NVM_MIXED_SHAPE_INVALID, NVM_MIXED_SHAPE_LIMIT, NVM_MIXED_SHAPE_MEMORY
} NvmMixedShapeStatus;
typedef struct {
    NvmMixedShapeStatus status;
    uint32_t function, pc;
    const char *message;
} NvmMixedShapeResult;
typedef struct {
    uint16_t tags;
    uint64_t origins;
} NvmMixedFieldFact;
typedef struct {
    uint32_t function, pc, global_layout, source_record, field_start;
    uint16_t field_count;
    uint8_t tag;
} NvmMixedFloatOrigin;
typedef struct {
    uint32_t function, pc;
    uint16_t read_tags;
    uint16_t required_tags, actual_tags;
} NvmMixedScalarObligation;
typedef struct {
    NvmMixedLayoutView *view;
    uint32_t origin_count, field_count, obligation_count, checked_writes;
    
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 3 4
   _Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_float_proof.h"
        requires_affine_verification;
    NvmMixedFloatOrigin origins[64u];
    NvmMixedFieldFact *fields;
    NvmMixedScalarObligation obligations[4096u];
} NvmMixedFloatProof;


NvmMixedShapeResult nvm_analyze_mixed_float_origins(const NvmModule *, NvmMixedFloatProof **);
void nvm_mixed_float_proof_free(NvmMixedFloatProof *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 2

typedef enum { NVM_MIXED_CHECK_FLOAT, NVM_MIXED_COMPARE_VALUE } NvmMixedScalarPolicy;
typedef struct {
    uint32_t function, pc;
    uint16_t operand, actual_tags, required_tags;
    NvmMixedScalarPolicy policy;
} NvmMixedScalarCheck;
typedef struct {
    NvmMixedFloatProof *shape;
    uint32_t checked_functions, checked_instructions, visits, check_count;
    uint16_t max_stack[8];
    uint32_t managed_count;
    uint32_t global_to_managed[256u];
    uint32_t managed_to_global[256u];
    NvmMixedScalarCheck checks[(2u * 4096u)];
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h"
        affine_checked;
    
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples.h"
        runtime_admitted;
} NvmMixedSamplesProof;




NvmMixedShapeResult nvm_analyze_mixed_samples(const NvmModule *, NvmMixedSamplesProof **);
void nvm_mixed_samples_proof_free(NvmMixedSamplesProof *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 2




typedef struct NvmMixedSamplesPlan NvmMixedSamplesPlan;
typedef enum {
    NVM_MIXED_VALUE_UNAVAILABLE, NVM_MIXED_VALUE_SCALAR,
    NVM_MIXED_VALUE_OWNER, NVM_MIXED_VALUE_ORDINARY
} NvmMixedValueCategory;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_layout;
    NvmMixedValueCategory category;
} NvmMixedDeclaration;
typedef struct {
    uint16_t parameter_count, local_count, max_stack;
    NvmMixedDeclaration parameters[8], result;
    uint16_t result_fields;
} NvmMixedSignature;
typedef struct {
    uint32_t source_record, global_layout, managed_record, field_count;
} NvmMixedRecordIdentity;
typedef struct {
    const uint8_t *layouts, *ownership;
    uint32_t layout_size, ownership_size;
} NvmMixedTransport;





# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_candidate(const NvmModule *);



NvmMixedShapeResult nvm_mixed_samples_admit(const NvmModule *, NvmMixedSamplesPlan **out);
NvmMixedShapeResult nvm_mixed_samples_prepare(const NvmModule *, NvmMixedSamplesPlan **out);
void nvm_mixed_samples_plan_free(NvmMixedSamplesPlan *);

# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_signature(const NvmMixedSamplesPlan *, uint32_t function,
                                 NvmMixedSignature *out);

# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_local(const NvmMixedSamplesPlan *, uint32_t function,
                             uint16_t local, NvmMixedDeclaration *out);

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_record(const NvmMixedSamplesPlan *, uint32_t source_record,
                              NvmMixedRecordIdentity *out);

# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_internal.h"
    nvm_mixed_samples_transport(const NvmMixedSamplesPlan *, NvmMixedTransport *out);

const NvmMixedSamplesProof *nvm_mixed_samples_obligations(const NvmMixedSamplesPlan *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
typedef struct NvmOwnedArrayLayouts NvmOwnedArrayLayouts;
typedef struct {
    uint32_t layouts, source_records, managed_records, leaf_paths;
} NvmOwnedArrayLayoutCounts;
typedef struct {
    uint32_t global_layout, source_record, managed_record, field_count;
    uint32_t path_start, path_count;
    uint8_t flags, owner_depth;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
        has_array, has_string, whole_root_borrow_unsuitable;
} NvmOwnedArrayLayoutFact;
typedef struct {
    uint32_t root_layout, terminal_layout;
    uint16_t length;
    uint8_t tag;
    uint16_t fields[32u];
} NvmOwnedArrayLeafPath;
typedef struct {
    const uint8_t *layouts, *ownership;
    uint32_t layout_size, ownership_size;
} NvmOwnedArrayTransport;



NvmRecordPlanResult nvm_describe_owned_array_layouts(const NvmModule *, NvmOwnedArrayLayouts **out);
void nvm_owned_array_layouts_free(NvmOwnedArrayLayouts *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_counts(const NvmOwnedArrayLayouts *, NvmOwnedArrayLayoutCounts *out);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_fact(const NvmOwnedArrayLayouts *, uint32_t global, NvmOwnedArrayLayoutFact *out);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_source_layout(const NvmOwnedArrayLayouts *, uint32_t source, uint32_t *out_global);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_managed_layout(const NvmOwnedArrayLayouts *, uint32_t managed, uint32_t *out_global);

# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_leaf_path(const NvmOwnedArrayLayouts *, uint32_t path, NvmOwnedArrayLeafPath *out);

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_field(const NvmOwnedArrayLayouts *, uint32_t global, uint16_t field, NvmV2LayoutField *out);

# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_transport(const NvmOwnedArrayLayouts *, NvmOwnedArrayTransport *out);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 2



typedef struct NvmOwnedArrayOrigins NvmOwnedArrayOrigins;
typedef enum { NVM_OWNER_ORIGIN_PROVED, NVM_OWNER_ORIGIN_UNRESOLVED,
    NVM_OWNER_ORIGIN_INVALID, NVM_OWNER_ORIGIN_LIMIT, NVM_OWNER_ORIGIN_MEMORY
} NvmOwnerOriginStatus;
typedef struct { NvmOwnerOriginStatus status; uint32_t function, pc; const char *message; } NvmOwnerOriginResult;
typedef struct { uint64_t words[5u]; } NvmOwnerOriginSet;
typedef struct { uint32_t function, pc; uint8_t opcode; } NvmOwnerOriginSite;
typedef struct { uint16_t ordinal; NvmOwnedArrayLeafPath path; NvmOwnerOriginSet origins; } NvmOwnerOriginPath;
typedef struct {
    uint32_t formal_count, result_count;
    
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
        reachable, conditional;
    NvmOwnerOriginSet required;
} NvmOwnerOriginSummary;
typedef struct { uint32_t functions, sites, obligations; } NvmOwnerOriginCounts;
typedef struct {
    uint32_t function, pc;
    uint16_t actual_tags, required_tags, read_tags;

    uint16_t operand_actual[2], operand_required[2];
    uint8_t opcode, operand_count, runtime_checks;
} NvmOwnerOriginObligation;


NvmOwnerOriginResult nvm_analyze_owned_array_origins(const NvmModule *, NvmOwnedArrayOrigins **);
void nvm_owned_array_origins_free(NvmOwnedArrayOrigins *);

# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_counts(const NvmOwnedArrayOrigins *, NvmOwnerOriginCounts *);

# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_site(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSite *);

# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_summary(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSummary *);

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_input(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_result(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_obligation(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 2

typedef struct NvmOwnedArrayPlan NvmOwnedArrayPlan;
typedef enum { NVM_OWNER_AUTH_PREPARED, NVM_OWNER_AUTH_UNRESOLVED,
    NVM_OWNER_AUTH_INVALID, NVM_OWNER_AUTH_LIMIT, NVM_OWNER_AUTH_MEMORY
} NvmOwnerAuthorityStatus;
typedef struct { NvmOwnerAuthorityStatus status; uint32_t function, pc; const char *message; } NvmOwnerAuthorityResult;
typedef struct { uint8_t tag, mode; uint32_t global_layout; 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
                                                           _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
                                                                owner; } NvmOwnerDeclaration;
typedef struct {
    uint16_t local_count, parameter_count, max_stack, result_fields;
    NvmOwnerDeclaration result, parameters[8];
} NvmOwnerSignature;
typedef struct { uint32_t functions, instructions, persisted_cells, visits, work; } NvmOwnerAuthorityCounts;


NvmOwnerAuthorityResult nvm_prepare_owned_array_authority(const NvmModule *, NvmOwnedArrayPlan **);
void nvm_owned_array_plan_free(NvmOwnedArrayPlan *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_counts(const NvmOwnedArrayPlan *, NvmOwnerAuthorityCounts *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_signature(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerSignature *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_local(const NvmOwnedArrayPlan *, uint32_t, uint16_t, NvmOwnerDeclaration *);

# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_layout(const NvmOwnedArrayPlan *, uint32_t, NvmOwnedArrayLayoutFact *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_source(const NvmOwnedArrayPlan *, uint32_t, uint32_t *);

# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_transport(const NvmOwnedArrayPlan *, NvmOwnedArrayTransport *);

# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_obligation(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admission.h" 2


typedef enum { NVM_OWNER_ARRAY_NOT_SELECTED, NVM_OWNER_ARRAY_SELECTED,
    NVM_OWNER_ARRAY_INVALID } NvmOwnedArrayRoute;
NvmOwnedArrayRoute nvm_owned_array_route(const NvmModule *);



NvmOwnerAuthorityResult nvm_owned_array_admit(const NvmModule *, NvmOwnedArrayPlan **out);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h" 2



typedef struct {
    const NvmModule *module;
    
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h"
        pending;
} NvmServiceClassification;
NvmServiceClassification nvm_service_classify(const NvmModule *module);


# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h"
    nvm_service_pending_classified(const NvmModule *module,
                                    const NvmServiceClassification *facts);
NvmOwnedArrayRoute nvm_owned_array_route_classified(
    const NvmModule *module, const NvmServiceClassification *facts);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/service_classification_private.h"
    nvm_mixed_samples_candidate_classified(
    const NvmModule *module, const NvmServiceClassification *facts);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 2
struct NvmMixedSamplesPlan {
    NvmMixedSamplesProof *proof;
    NvmMixedSignature functions[8];
    NvmMixedDeclaration locals[8][256];
    uint32_t function_count;
    uint8_t *layout_bytes;
    uint32_t layout_size;
};
static NvmMixedShapeResult mp_result(NvmMixedShapeStatus status,const char *message) {
    return (NvmMixedShapeResult){status,0,0,message};
}
void nvm_mixed_samples_plan_free(NvmMixedSamplesPlan *p) {
    if(p){nvm_mixed_samples_proof_free(p->proof);free(p->layout_bytes);free(p);}
}
static 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
      _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
           mp_declaration(NvmV2Cursor *c,const NvmMixedSamplesProof *proof,
                            NvmMixedDeclaration *out) {
    NvmMixedDeclaration d={0};uint16_t reserved;
    if(nvm_v2_u8(c,&d.tag)!=NVM_V2_OK || nvm_v2_u8(c,&d.mode)!=NVM_V2_OK ||
       nvm_v2_u16(c,&reserved)!=NVM_V2_OK || reserved || d.mode ||
       nvm_v2_u32(c,&d.global_layout)!=NVM_V2_OK)return 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                       0
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                            ;
    const NvmMixedLayoutView *v=proof->shape->view;
    if(d.tag==TAG_STRUCT) {
        if(d.global_layout>=v->layouts.count)return 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                   0
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                        ;
        if(v->classes[d.global_layout]==NVM_MIXED_RESOURCE)d.category=NVM_MIXED_VALUE_OWNER;
        else if(proof->global_to_managed[d.global_layout]!=0xFFFFFFFFu)
            d.category=NVM_MIXED_VALUE_ORDINARY;

    } else if(d.global_layout==0xFFFFFFFFu) {
        if(d.tag==TAG_ARRAY)d.category=NVM_MIXED_VALUE_ORDINARY;
        else if(d.tag==TAG_INT || d.tag==TAG_BOOL || d.tag==TAG_U8 ||
                d.tag==TAG_FLOAT || d.tag==TAG_VOID)d.category=NVM_MIXED_VALUE_SCALAR;
        else return 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                   0
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                        ;
    } else return 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                 0
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                      ;
    *out=d;return 
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                 1
# 38 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                     ;
}
static 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
      _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
           mp_value_signature(NvmMixedDeclaration d,
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                    _Bool 
# 40 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                         result) {
    if(d.mode)return 
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                    0
# 41 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                         ;
    if(d.category==NVM_MIXED_VALUE_OWNER)return d.tag==TAG_STRUCT;
    return d.category==NVM_MIXED_VALUE_SCALAR && (d.tag==TAG_INT || d.tag==TAG_BOOL ||
           d.tag==TAG_U8 || (result && d.tag==TAG_VOID));
}
static 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
      _Bool 
# 46 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
           mp_signatures(const NvmModule *module,NvmMixedSamplesPlan *p) {
    const NvmMixedLayoutView *v=p->proof->shape->view;
    NvmV2Cursor c;uint32_t version,count,functions;const uint8_t *flags;
    nvm_v2_cursor_init(&c,v->ownership,v->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK ||
       (version!=1u && version!=2u) ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count!=v->layouts.count ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK || nvm_v2_align4(&c)!=NVM_V2_OK ||
       nvm_v2_u32(&c,&functions)!=NVM_V2_OK || functions!=module->function_count)return 
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                       0
# 54 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                            ;
    p->function_count=functions;
    for(uint32_t f=0;f<functions;f++) {
        const NvmFunctionEntry *fn=&module->functions[f];NvmMixedSignature *sig=&p->functions[f];
        if(nvm_v2_u16(&c,&sig->local_count)!=NVM_V2_OK || sig->local_count>256 ||
           nvm_v2_u16(&c,&sig->parameter_count)!=NVM_V2_OK || sig->parameter_count>8 ||
           sig->parameter_count>sig->local_count || sig->parameter_count!=fn->arity ||
           sig->local_count!=fn->local_count || !mp_declaration(&c,p->proof,&sig->result) ||
           !mp_value_signature(sig->result,
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                          1
# 62 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                              ) || sig->result.tag!=fn->result_tag ||
           fn->result_count!=(sig->result.tag==TAG_VOID?0:1))return 
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                   0
# 63 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                        ;
        sig->max_stack=p->proof->max_stack[f];
        if((uint32_t)sig->local_count+sig->max_stack>
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                    (65535)
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                              )return 
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                      0
# 65 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                           ;
        if(sig->result.category==NVM_MIXED_VALUE_OWNER)
            sig->result_fields=v->layouts.items[sig->result.global_layout].field_count;
        for(uint16_t n=0;n<sig->local_count;n++) {
            if(!mp_declaration(&c,p->proof,&p->locals[f][n]))return 
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                   0
# 69 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                        ;
            if(n<sig->parameter_count) {
                if(!mp_value_signature(p->locals[f][n],
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                      0
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                           ))return 
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                    0
# 71 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                         ;
                sig->parameters[n]=p->locals[f][n];
                if(module->function_param_types && module->function_param_types[f] &&
                   module->function_param_types[f][n]!=sig->parameters[n].tag)return 
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                    0
# 74 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                         ;
            }
        }
    }


    return 
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
          1
# 80 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
              ;
}
NvmMixedShapeResult nvm_mixed_samples_prepare(const NvmModule *module,NvmMixedSamplesPlan **out) {
    if(!out)return mp_result(NVM_MIXED_SHAPE_INVALID,"I require an output for private mixed preparation.");
    if(nvm_service_execution_pending(module))
        return mp_result(NVM_MIXED_SHAPE_UNRESOLVED,"I refuse service contracts before mixed preparation.");
    NvmMixedSamplesProof *proof=
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                               ((void *)0)
# 86 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                   ;
    NvmMixedShapeResult r=nvm_analyze_mixed_samples(module,&proof);
    if(r.status!=NVM_MIXED_SHAPE_PROVED)return r;
    
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
   _Bool 
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
        owner=
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
              0
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                   ,array=
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                          0
# 89 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                               ;
    for(uint32_t n=0;n<proof->shape->view->layouts.count;n++)
        owner|=proof->shape->view->classes[n]==NVM_MIXED_RESOURCE;
    for(uint32_t n=0;n<proof->shape->origin_count;n++)array|=proof->shape->origins[n].tag==TAG_ARRAY;


    if(!owner || !array || !proof->managed_count) {
        nvm_mixed_samples_proof_free(proof);
        return mp_result(NVM_MIXED_SHAPE_UNRESOLVED,"I require an owner and proved ordinary FLOAT-array record graph.");
    }


    NvmVerifyResult structure=verify_structure_checked(module,
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                             1
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                 ,
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                  ((void *)0)
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                      ,
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                       1
# 101 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                           );
    if(!structure.ok || !nvm_metadata_valid(module)) {
        nvm_mixed_samples_proof_free(proof);
        return mp_result(NVM_MIXED_SHAPE_INVALID,"I require complete common structure for private mixed preparation.");
    }
    NvmMixedSamplesPlan *p=calloc(1,sizeof *p);
    if(!p){nvm_mixed_samples_proof_free(proof);return mp_result(NVM_MIXED_SHAPE_MEMORY,"I could not allocate my private mixed plan.");}
    p->proof=proof;
    if(!mp_signatures(module,p)) {
        nvm_mixed_samples_plan_free(p);
        return mp_result(NVM_MIXED_SHAPE_INVALID,"I require exact checked mixed signature transport.");
    }
    p->layout_bytes=malloc(module->layout_size);
    if(!p->layout_bytes){nvm_mixed_samples_plan_free(p);return mp_result(NVM_MIXED_SHAPE_MEMORY,"I could not retain my mixed layout transport.");}
    memcpy(p->layout_bytes,module->layout_data,module->layout_size);p->layout_size=module->layout_size;
    *out=p;
    return mp_result(NVM_MIXED_SHAPE_PROVED,"I prepared mixed facts; runtime checks and admission remain unavailable.");
}

# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 119 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_signature(const NvmMixedSamplesPlan *p,uint32_t f,NvmMixedSignature *out) {
    if(!p || !out || f>=p->function_count)return 
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                0
# 120 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                     ;
    *out=p->functions[f];return 
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                               1
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                   ;
}

# 123 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 123 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_local(const NvmMixedSamplesPlan *p,uint32_t f,uint16_t local,NvmMixedDeclaration *out) {
    if(!p || !out || f>=p->function_count || local>=p->functions[f].local_count)return 
# 124 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                      0
# 124 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                           ;
    *out=p->locals[f][local];return 
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                   1
# 125 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                       ;
}

# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 127 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_record(const NvmMixedSamplesPlan *p,uint32_t source,NvmMixedRecordIdentity *out) {
    if(!p || !out)return 
# 128 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                        0
# 128 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                             ;
    const NvmMixedLayoutView *v=p->proof->shape->view;
    if(source>=v->record_count)return 
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                     0
# 130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                          ;
    uint32_t global=v->source_to_global[source];
    if(global>=v->layouts.count)return 
# 132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                      0
# 132 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                           ;
    uint32_t managed=p->proof->global_to_managed[global];
    if(managed==0xFFFFFFFFu || managed>=p->proof->managed_count ||
       p->proof->managed_to_global[managed]!=global || v->classes[global]==NVM_MIXED_RESOURCE)return 
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                                    0
# 135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                                         ;
    *out=(NvmMixedRecordIdentity){source,global,managed,v->layouts.items[global].field_count};return 
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                                    1
# 136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                                        ;
}

# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 138 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_transport(const NvmMixedSamplesPlan *p,NvmMixedTransport *out) {
    if(!p || !out)return 
# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                        0
# 139 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                             ;
    const NvmMixedLayoutView *v=p->proof->shape->view;
    *out=(NvmMixedTransport){p->layout_bytes,v->ownership,p->layout_size,v->ownership_size};return 
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                                                  1
# 141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                                      ;
}
const NvmMixedSamplesProof *nvm_mixed_samples_obligations(const NvmMixedSamplesPlan *p) {
    return p?p->proof:
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                     ((void *)0)
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                         ;
}




# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 149 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_candidate(const NvmModule *module) {
    return nvm_mixed_samples_candidate_classified(module, 
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                         ((void *)0)
# 150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                             );
}

# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
_Bool 
# 152 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
    nvm_mixed_samples_candidate_classified(
    const NvmModule *module, const NvmServiceClassification *facts) {
    if(!module || nvm_service_pending_classified(module,facts) ||
       !module->ownership_data || !module->layout_data)return 
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                             0
# 155 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                  ;
    NvmV2Cursor c;uint32_t version,count,layout_count;const uint8_t *flags;
    nvm_v2_cursor_init(&c,module->ownership_data,module->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK ||
       (version!=1u && version!=2u) ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count>256u ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK)return 
# 161 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                     0
# 161 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                          ;
    
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
   _Bool 
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
        resource=
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                 0
# 162 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                      ;for(uint32_t n=0;n<count;n++)resource|=(flags[n]&2u)!=0;
    if(!resource)return 
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                       0
# 163 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                            ;
    nvm_v2_cursor_init(&c,module->layout_data,module->layout_size);
    if(nvm_v2_u32(&c,&layout_count)!=NVM_V2_OK || layout_count!=count)return 
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                                            0
# 165 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                                                 ;
    uint32_t total=0;
    for(uint32_t n=0;n<count;n++) {
        uint8_t kind,reserved;uint16_t fields;uint32_t name;const uint8_t *bytes;
        if(nvm_v2_u8(&c,&kind)!=NVM_V2_OK || nvm_v2_u8(&c,&reserved)!=NVM_V2_OK ||
           nvm_v2_u16(&c,&fields)!=NVM_V2_OK || nvm_v2_u32(&c,&name)!=NVM_V2_OK ||
           fields>65536u -total)return 
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                         0
# 171 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                              ;
        total+=fields;
        for(uint16_t f=0;f<fields;f++) {
            if(nvm_v2_take(&c,12,&bytes)!=NVM_V2_OK)return 
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                          0
# 174 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                               ;
            if(bytes[0]==TAG_ARRAY)return 
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                         1
# 175 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                             ;
        }
    }
    return 
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
          0
# 178 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
               ;
}
NvmMixedShapeResult nvm_mixed_samples_admit(const NvmModule *module,NvmMixedSamplesPlan **out) {
    if(!out)return mp_result(NVM_MIXED_SHAPE_INVALID,"I require an output for mixed admission.");
    if(!nvm_mixed_samples_candidate(module))
        return mp_result(NVM_MIXED_SHAPE_UNRESOLVED,"I require the explicit mixed Samples candidate.");
    NvmMixedSamplesPlan *plan=
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                             ((void *)0)
# 184 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                 ;
    NvmMixedShapeResult result=nvm_mixed_samples_prepare(module,&plan);
    if(result.status!=NVM_MIXED_SHAPE_PROVED)return result;
    uint8_t entry=plan->functions[0].result.tag;
    
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
   _Bool 
# 188 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
        supported=entry==TAG_INT || entry==TAG_BOOL || entry==TAG_U8;
    for(uint32_t f=0;f<module->function_count;f++) {
        const char *name=nvm_get_string(module,module->functions[f].name_idx);
        if(name && !strcmp(name,"__init__"))supported=
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                                                     0
# 191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                                          ;
    }
    if(!supported) {
        nvm_mixed_samples_plan_free(plan);
        return mp_result(NVM_MIXED_SHAPE_UNRESOLVED,"I require a scalar mixed entry without initializer functions.");
    }
    *out=plan;
    return mp_result(NVM_MIXED_SHAPE_PROVED,"I admit my closed mixed runtime with exact scalar checks and owner obligations.");
}
static NvmVerifyResult verify_mixed_samples(const NvmModule *module,uint32_t function,
                                           uint16_t *out_max_stack) {
    NvmMixedSamplesPlan *plan=
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc" 3 4
                             ((void *)0)
# 202 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/mixed_samples_prepare.inc"
                                 ;
    NvmMixedShapeResult result=nvm_mixed_samples_admit(module,&plan);
    if(result.status!=NVM_MIXED_SHAPE_PROVED)
        return fail("I refuse mixed admission (status %u) at function %u offset %u: %s",
                    (unsigned)result.status,result.function,result.pc,result.message);
    if(function>=plan->function_count){nvm_mixed_samples_plan_free(plan);return fail("I require an existing mixed function index");}
    uint16_t max_stack=plan->functions[function].max_stack;
    nvm_mixed_samples_plan_free(plan);
    if(out_max_stack)*out_max_stack=max_stack;
    return ok_result();
}
# 522 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 1


# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_authority_internal.h" 1





typedef struct {
    NvmOwnedArrayOrigins *origins;
    NvmOwnedArrayLayouts *layouts;
    NvmOwnerAuthorityCounts counts;
    NvmOwnerSignature signatures[8];
    NvmOwnerDeclaration locals[8][256];
    NvmOwnerOriginObligation obligations[4096];
} NvmOwnerLifetimeFacts;
NvmOwnerAuthorityResult nvm_analyze_owned_array_lifetimes(const NvmModule *, NvmOwnerLifetimeFacts **);
void nvm_owned_array_lifetime_facts_free(NvmOwnerLifetimeFacts *);
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 2
struct NvmOwnedArrayPlan { NvmOwnerLifetimeFacts *facts; };
void nvm_owned_array_plan_free(NvmOwnedArrayPlan *p) {
    if(!p)return;
    nvm_owned_array_lifetime_facts_free(p->facts);free(p);
}
NvmOwnerAuthorityResult nvm_prepare_owned_array_authority(const NvmModule *module,NvmOwnedArrayPlan **out) {
    if(!out)return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_INVALID,0,0,"I require an output for private owner preparation."};

    NvmOwnerLifetimeFacts *facts=
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                ((void *)0)
# 12 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                    ;
    NvmOwnerAuthorityResult result=nvm_analyze_owned_array_lifetimes(module,&facts);
    if(result.status!=NVM_OWNER_AUTH_PREPARED)return result;


    NvmVerifyResult structure=verify_structure_checked(module,
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                             1
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                                 ,
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                                  ((void *)0)
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                                      ,
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                                       1
# 17 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                                           );
    if(!structure.ok || !nvm_metadata_valid(module)) {
        nvm_owned_array_lifetime_facts_free(facts);
        return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_INVALID,0,0,"I require complete common structure and metadata for owner preparation."};
    }
    NvmOwnedArrayPlan *p=calloc(1,sizeof *p);
    if(!p){nvm_owned_array_lifetime_facts_free(facts);return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_MEMORY,0,0,"I could not allocate the private owner plan."};}
    p->facts=facts;*out=p;
    return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_PREPARED,0,0,"I prepared private origin, lifetime, scalar and structural facts; I grant no runtime permission."};
}

# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_counts(const NvmOwnedArrayPlan *p,NvmOwnerAuthorityCounts *out) {
    if(!p || !out)return 
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                        0
# 28 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                             ;
    *out=p->facts->counts;return 
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                1
# 29 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                    ;
}

# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_signature(const NvmOwnedArrayPlan *p,uint32_t f,NvmOwnerSignature *out) {
    if(!p || !out || f>=p->facts->counts.functions)return 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                         0
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                              ;
    *out=p->facts->signatures[f];return 
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                       1
# 33 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                           ;
}

# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_local(const NvmOwnedArrayPlan *p,uint32_t f,uint16_t local,NvmOwnerDeclaration *out) {
    if(!p || !out || f>=p->facts->counts.functions || local>=p->facts->signatures[f].local_count)return 
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                                                                       0
# 36 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                                                                            ;
    *out=p->facts->locals[f][local];return 
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                          1
# 37 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                              ;
}

# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_layout(const NvmOwnedArrayPlan *p,uint32_t global,NvmOwnedArrayLayoutFact *out) {
    return p && nvm_owned_array_layout_fact(p->facts->layouts,global,out);
}

# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_source(const NvmOwnedArrayPlan *p,uint32_t source,uint32_t *out) {
    return p && nvm_owned_array_source_layout(p->facts->layouts,source,out);
}

# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_transport(const NvmOwnedArrayPlan *p,NvmOwnedArrayTransport *out) {
    return p && nvm_owned_array_transport(p->facts->layouts,out);
}

# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
    nvm_owned_array_plan_obligation(const NvmOwnedArrayPlan *p,uint32_t n,NvmOwnerOriginObligation *out) {
    if(!p || !out || n>=p->facts->counts.instructions)return 
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                                            0
# 49 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                                                 ;
    *out=p->facts->obligations[n];return 
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc" 3 4
                                        1
# 50 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_prepare.inc"
                                            ;
}
# 525 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 1


NvmOwnedArrayRoute nvm_owned_array_route(const NvmModule *m) {
    return nvm_owned_array_route_classified(m, 
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                              ((void *)0)
# 4 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                                  );
}
NvmOwnedArrayRoute nvm_owned_array_route_classified(
    const NvmModule *m, const NvmServiceClassification *facts) {
    if(!m || nvm_service_pending_classified(m,facts))return NVM_OWNER_ARRAY_NOT_SELECTED;
    if(!m->ownership_data && !m->ownership_size)return NVM_OWNER_ARRAY_NOT_SELECTED;
    if(!m->ownership_data || !m->ownership_size)
        return NVM_OWNER_ARRAY_INVALID;
    NvmV2Cursor c;uint32_t version,count,layouts;const uint8_t *flags;
    nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK ||
       (version!=1u && version!=2u &&
        version!=3u) ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count>256u ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK)return NVM_OWNER_ARRAY_INVALID;
    
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
        resource=
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                 0
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                      ;
    for(uint32_t n=0;n<count;n++)resource|=(flags[n]&2u)!=0;
    if(!resource)return NVM_OWNER_ARRAY_NOT_SELECTED;
    for(uint32_t n=0;n<count;n++)
        if((flags[n]&~(1u|2u)) ||
           ((flags[n]&2u) && !(flags[n]&1u)))
            return NVM_OWNER_ARRAY_INVALID;
    uint32_t functions;
    if(nvm_v2_align4(&c)!=NVM_V2_OK || nvm_v2_u32(&c,&functions)!=NVM_V2_OK ||
       functions!=m->function_count)return NVM_OWNER_ARRAY_INVALID;
    if(!m->layout_data || !m->layout_size)return NVM_OWNER_ARRAY_INVALID;
    nvm_v2_cursor_init(&c,m->layout_data,m->layout_size);
    if(nvm_v2_u32(&c,&layouts)!=NVM_V2_OK || layouts!=count)return NVM_OWNER_ARRAY_INVALID;
    uint32_t total=0;
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                    _Bool 
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                         selected=
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                  0
# 32 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                       ;
    for(uint32_t n=0;n<count;n++) {
        uint8_t kind,reserved;uint16_t fields;uint32_t name;const uint8_t *field;
        if(nvm_v2_u8(&c,&kind)!=NVM_V2_OK || nvm_v2_u8(&c,&reserved)!=NVM_V2_OK ||
           nvm_v2_u16(&c,&fields)!=NVM_V2_OK || nvm_v2_u32(&c,&name)!=NVM_V2_OK ||
           fields>65536u -total || reserved || kind>NVM_V2_LAYOUT_ENUM)
            return NVM_OWNER_ARRAY_INVALID;
        total+=fields;
        for(uint16_t f=0;f<fields;f++) {
            if(nvm_v2_take(&c,12,&field)!=NVM_V2_OK || field[0]>=TAG_COUNT ||
               field[1] || field[2] || field[3])return NVM_OWNER_ARRAY_INVALID;
            if((flags[n]&2u) && field[0]==TAG_ARRAY)selected=
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                                                             1
# 43 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                                                                 ;
        }
    }
    if(c.pos!=c.size)return NVM_OWNER_ARRAY_INVALID;


    if(selected && version==3u)return NVM_OWNER_ARRAY_INVALID;
    return selected?NVM_OWNER_ARRAY_SELECTED:NVM_OWNER_ARRAY_NOT_SELECTED;
}



static NvmOwnerAuthorityStatus owner_array_parameter_view(const NvmModule *m,
        NvmModule *view,uint8_t *rows[8],uint8_t tags[8][8]) {
    if(!m->function_count || !m->functions)return NVM_OWNER_AUTH_INVALID;
    if(m->function_count>8)return NVM_OWNER_AUTH_LIMIT;
    NvmV2Cursor c;uint32_t version,count;const uint8_t *flags;
    nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK ||
       (version!=1u && version!=2u) ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count>256u ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK || nvm_v2_align4(&c)!=NVM_V2_OK ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count!=m->function_count)
        return NVM_OWNER_AUTH_INVALID;
    for(uint32_t f=0;f<count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];uint16_t locals,params;
        if(fn->arity>8 || fn->local_count>256)return NVM_OWNER_AUTH_LIMIT;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK ||
           locals!=fn->local_count || params!=fn->arity || params>locals)
            return NVM_OWNER_AUTH_INVALID;
        rows[f]=tags[f];
        for(uint32_t n=0;n<=(uint32_t)locals;n++) {
            const uint8_t *descriptor;
            if(nvm_v2_take(&c,8,&descriptor)!=NVM_V2_OK)return NVM_OWNER_AUTH_INVALID;
            if(!n || n>params)continue;
            uint8_t tag=descriptor[0];
            if(tag!=TAG_INT && tag!=TAG_BOOL && tag!=TAG_U8 &&
               tag!=TAG_STRING && tag!=TAG_STRUCT)return NVM_OWNER_AUTH_UNRESOLVED;
            if(m->function_param_types && m->function_param_types[f]) {
                uint8_t supplied=m->function_param_types[f][n-1];
                if(supplied!=TAG_VOID && supplied!=tag)return NVM_OWNER_AUTH_UNRESOLVED;
            }
            tags[f][n-1]=tag;
        }
    }
    *view=*m;view->function_param_types=rows;
    return NVM_OWNER_AUTH_PREPARED;
}
NvmOwnerAuthorityResult nvm_owned_array_admit(const NvmModule *m,NvmOwnedArrayPlan **out) {
    if(!out)return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_INVALID,0,0,"I require an owner ARRAY admission output."};
    if(nvm_service_execution_pending(m))
        return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_UNRESOLVED,0,0,"I refuse service contracts before owner ARRAY admission."};
    NvmOwnedArrayRoute route=nvm_owned_array_route(m);
    if(route!=NVM_OWNER_ARRAY_SELECTED)
        return (NvmOwnerAuthorityResult){route==NVM_OWNER_ARRAY_INVALID?NVM_OWNER_AUTH_INVALID:NVM_OWNER_AUTH_UNRESOLVED,0,0,"I require an exact owner ARRAY candidate."};
    uint8_t tags[8][8]={{0}};uint8_t *rows[8]={0};NvmModule view;
    NvmOwnerAuthorityStatus prepared=owner_array_parameter_view(m,&view,rows,tags);
    if(prepared!=NVM_OWNER_AUTH_PREPARED)
        return (NvmOwnerAuthorityResult){prepared,0,0,"I require bounded exact owner ARRAY parameter declarations."};


    NvmOwnedArrayPlan *p=
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                        ((void *)0)
# 104 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                            ;NvmOwnerAuthorityResult r=nvm_prepare_owned_array_authority(&view,&p);
    if(r.status!=NVM_OWNER_AUTH_PREPARED)return r;
    NvmOwnerSignature entry;
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                           _Bool 
# 106 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                supported=nvm_owned_array_plan_signature(p,0,&entry) &&
        !entry.parameter_count && (entry.result.tag==TAG_INT || entry.result.tag==TAG_BOOL || entry.result.tag==TAG_U8) &&
        (m->header.flags&(1 << 0)) && m->header.entry_point==0;
    for(uint32_t f=0;f<m->function_count;f++) {
        const char *name=nvm_get_string(m,m->functions[f].name_idx);
        if(name && !strcmp(name,"__init__"))supported=
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                                     0
# 111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                                          ;
        NvmOwnerSignature signature;
        if(!nvm_owned_array_plan_signature(p,f,&signature)){supported=
# 113 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                                                     0
# 113 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                                                          ;continue;}
        if(m->function_param_types && m->function_param_types[f])
            for(uint16_t n=0;n<signature.parameter_count;n++) {
                uint8_t declared=m->function_param_types[f][n];
                if(declared!=TAG_VOID && declared!=signature.parameters[n].tag)supported=
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                                                                                        0
# 117 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                                                                             ;
            }
    }
    if(!supported){nvm_owned_array_plan_free(p);return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_UNRESOLVED,0,0,"I require exact owner ARRAY parameter tags and a no-argument scalar entry without initializers."};}
    *out=p;return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_PREPARED,0,0,"I admit exact owner ARRAY runtime authority."};
}
static NvmVerifyResult verify_owned_arrays(const NvmModule *m,uint32_t function,uint16_t *depth) {
    NvmOwnedArrayPlan *p=
# 124 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                        ((void *)0)
# 124 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                            ;NvmOwnerAuthorityResult r=nvm_owned_array_admit(m,&p);
    if(r.status!=NVM_OWNER_AUTH_PREPARED)return fail("I refuse owner ARRAY admission (status %u) at function %u offset %u: %s",(unsigned)r.status,r.function,r.pc,r.message);
    NvmOwnerSignature signature;
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc" 3 4
                               _Bool 
# 126 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/owned_array_admit.inc"
                                    valid=nvm_owned_array_plan_signature(p,function,&signature);
    nvm_owned_array_plan_free(p);
    if(!valid)return fail("I require an existing owner ARRAY function index");
    if(depth)*depth=signature.max_stack;
    return ok_result();
}
# 526 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2







static NvmVerifyResult verify_function_body(const NvmModule *mod, uint32_t fn_idx,
                                           const NvmModule *const *linked_modules,
                                           uint32_t linked_count,
                                           uint16_t *out_max_stack, NvmRecordArrayBudget *budget,
                                           VmDecodedFunction *kept) {
    const NvmFunctionEntry *fn = &mod->functions[fn_idx];
    VmDecodedFunction decoded;
    char decode_error[256];
    if (!vm_decode_function(mod, fn_idx, &decoded, decode_error))
        return fail("%s", decode_error);







    for (uint32_t i = 0; i < decoded.instruction_count; i++) {
        if(!nvm_ra_steps(budget,8))do { NvmVerifyResult result = fail("I reached my private operand-check work bound."); vm_decoded_function_free(&decoded); return result; } while (0);
        uint32_t pos = decoded.instructions[i].byte_offset;
        DecodedInstruction instr = decoded.instructions[i].instruction;

        const InstructionInfo *info = isa_get_info(instr.opcode);
        if (!info)
            do { NvmVerifyResult result = fail("function[%u] unknown opcode 0x%02x at offset %u", fn_idx, instr.opcode, fn->code_offset + pos); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                     ;


        switch (instr.opcode) {

        case OP_BORROW_PATH_SHARED: case OP_BORROW_PATH_EXCLUSIVE:
        case OP_REBORROW_SHARED: case OP_REBORROW_EXCLUSIVE:
        case OP_REGION_BEGIN: case OP_REGION_END:
        case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE: case OP_REF_GET: case OP_REF_SET:
        case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL:
        case OP_OWN_PACK: case OP_OWN_UNPACK_LOCAL: {
            NvmAffineAnalysis analysis=nvm_affine_analyze_function(mod,fn_idx);
            if (!analysis.ok) do { NvmVerifyResult result = fail("I refuse reference lifetime and ownership instruction dataflow: %s",analysis.message); vm_decoded_function_free(&decoded); return result; } while (0);
            do { NvmVerifyResult result = fail("I require owned-transfer execution semantics before execution"); vm_decoded_function_free(&decoded); return result; } while (0);
        }


        case OP_JMP:
        case OP_JMP_TRUE:
        case OP_JMP_FALSE: {
            int32_t offset = instr.operands[0].i32;
            int64_t target = (int64_t)pos + offset;
            if (target < 0 || target > 
# 580 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                      (4294967295U)
                    
# 581 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                   || !vm_decoded_function_has_boundary(&decoded,
                                                         (uint32_t)target)) {
                do { NvmVerifyResult result = fail("function[%u] jump at offset %u targets %ld " "(not an instruction boundary)", fn_idx, fn->code_offset + pos, (long)target); vm_decoded_function_free(&decoded); return result; } while (0)


                                                                ;
            }
            break;
        }

        case OP_HANDLER_PUSH:
            if (instr.operands[0].u32 >= mod->string_count ||
                (uint32_t)instr.operands[2].u16 + instr.operands[3].u16 > fn->local_count)
                do { NvmVerifyResult result = fail("I require valid handler names and parameter slots."); vm_decoded_function_free(&decoded); return result; } while (0);
            if (decoded.instructions[i].resolved_target >= fn->code_offset + fn->code_length)
                do { NvmVerifyResult result = fail("I require an executable handler arm."); vm_decoded_function_free(&decoded); return result; } while (0);
            break;
        case OP_PERFORM:
            if (instr.operands[0].u32 >= mod->string_count)
                do { NvmVerifyResult result = fail("I require a valid effect operation name."); vm_decoded_function_free(&decoded); return result; } while (0);
            break;

        case OP_MATCH_TAG: {
            int32_t offset = instr.operands[1].i32;
            int64_t target = (int64_t)pos + offset;
            if (target < 0 || target > 
# 606 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                      (4294967295U)
                    
# 607 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                   || !vm_decoded_function_has_boundary(&decoded,
                                                         (uint32_t)target)) {
                do { NvmVerifyResult result = fail("function[%u] match_tag at offset %u targets %ld " "(not an instruction boundary)", fn_idx, fn->code_offset + pos, (long)target); vm_decoded_function_free(&decoded); return result; } while (0)


                                                                ;
            }
            break;
        }






        case OP_CALL:
        case OP_TAIL_CALL: {
            uint32_t fn_target = instr.operands[0].u32;
            if (fn_target >= mod->function_count)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: fn_idx %u >= function_count %u", fn_idx, info->name, fn->code_offset + pos, fn_target, mod->function_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                            ;
            if (instr.opcode == OP_TAIL_CALL) {
                const NvmFunctionEntry *callee = &mod->functions[fn_target];
                if (callee->result_count != fn->result_count
                        || callee->result_tag != fn->result_tag)
                    do { NvmVerifyResult result = fail("function[%u] OP_TAIL_CALL at offset %u has incompatible result signature", fn_idx, fn->code_offset + pos); vm_decoded_function_free(&decoded); return result; } while (0)
                                                               ;
            }
            break;
        }
# 647 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        case OP_CALL_MODULE: {
            uint32_t mod_target = instr.operands[0].u32;
            uint32_t fn_target = instr.operands[1].u32;
            if (linked_count > 0) {
                if (mod_target >= linked_count)
                    do { NvmVerifyResult result = fail("function[%u] OP_CALL_MODULE at offset %u: module_idx %u >= linked_count %u", fn_idx, fn->code_offset + pos, mod_target, linked_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                         ;
                const NvmModule *target = linked_modules[mod_target];
                if (!target)
                    do { NvmVerifyResult result = fail("function[%u] OP_CALL_MODULE at offset %u: linked module %u is unresolved", fn_idx, fn->code_offset + pos, mod_target); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                           ;
                if (fn_target >= target->function_count)
                    do { NvmVerifyResult result = fail("function[%u] OP_CALL_MODULE at offset %u: fn_idx %u >= linked function_count %u", fn_idx, fn->code_offset + pos, fn_target, target->function_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                                  ;



                const NvmFunctionEntry *callee = &target->functions[fn_target];
                if (instr.operands[2].u16 != callee->arity)
                    do { NvmVerifyResult result = fail("function[%u] OP_CALL_MODULE at offset %u declares arity %u but linked callee takes %u", fn_idx, fn->code_offset + pos, instr.operands[2].u16, callee->arity); vm_decoded_function_free(&decoded); return result; } while (0)

                                                                      ;
                if (instr.operands[3].u16 != callee->result_count)
                    do { NvmVerifyResult result = fail("function[%u] OP_CALL_MODULE at offset %u declares %u results but linked callee returns %u", fn_idx, fn->code_offset + pos, instr.operands[3].u16, callee->result_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                                             ;
            }
            break;
        }

        case OP_CLOSURE_NEW: {
            uint32_t fn_target = instr.operands[0].u32;
            if (fn_target >= mod->function_count)
                do { NvmVerifyResult result = fail("function[%u] OP_CLOSURE_NEW at offset %u: fn_idx %u >= function_count %u", fn_idx, fn->code_offset + pos, fn_target, mod->function_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                           ;
            if (instr.operands[1].u16 != mod->functions[fn_target].upvalue_count)
                do { NvmVerifyResult result = fail("function[%u] OP_CLOSURE_NEW at offset %u: capture_count %u does not match upvalue_count %u", fn_idx, fn->code_offset + pos, instr.operands[1].u16, mod->functions[fn_target].upvalue_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                                     ;
            break;
        }

        case OP_FUNCREF: {
            uint32_t fn_target = instr.operands[0].u32;
            if (fn_target >= mod->function_count)
                do { NvmVerifyResult result = fail("function[%u] OP_FUNCREF at offset %u: fn_idx %u >= function_count %u", fn_idx, fn->code_offset + pos, fn_target, mod->function_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                           ;
            break;
        }


        case OP_PUSH_STR: {
            uint32_t str_idx = instr.operands[0].u32;
            if (str_idx >= mod->string_count)
                do { NvmVerifyResult result = fail("function[%u] OP_PUSH_STR at offset %u: str_idx %u >= string_count %u", fn_idx, fn->code_offset + pos, str_idx, mod->string_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                       ;
            break;
        }


        case OP_CALL_EXTERN: {
            uint32_t imp_idx = instr.operands[0].u32;
            if (imp_idx >= mod->import_count)
                do { NvmVerifyResult result = fail("function[%u] OP_CALL_EXTERN at offset %u: import_idx %u >= import_count %u", fn_idx, fn->code_offset + pos, imp_idx, mod->import_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                       ;
            break;
        }


        case OP_LOAD_GLOBAL:
        case OP_STORE_GLOBAL: {
            uint32_t idx = instr.operands[0].u32;
            if (idx >= 4096)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: global index %u >= limit %u", fn_idx, info->name, fn->code_offset + pos, idx, 4096); vm_decoded_function_free(&decoded); return result; } while (0)

                                                 ;
            break;
        }


        case OP_LOAD_LOCAL:
        case OP_STORE_LOCAL: {
            uint16_t slot = instr.operands[0].u16;
            if (slot >= fn->local_count)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: slot %u >= local_count %u", fn_idx, info->name, fn->code_offset + pos, slot, fn->local_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                   ;
            break;
        }


        case OP_LOAD_UPVALUE:
        case OP_STORE_UPVALUE: {


            uint16_t idx = instr.operands[1].u16;
            if (instr.operands[0].u16 != 0)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: upvalue depth must be zero", fn_idx, info->name, fn->code_offset + pos); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                       ;
            if (idx >= fn->upvalue_count)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: upvalue index %u >= upvalue_count %u", fn_idx, info->name, fn->code_offset + pos, idx, fn->upvalue_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                    ;
            break;
        }


        case OP_STRUCT_NEW:
        case OP_STRUCT_LITERAL: {
            if (mod->struct_count > 0) {
                uint32_t def_idx = instr.operands[0].u32;
                if (def_idx >= mod->struct_count)
                    do { NvmVerifyResult result = fail("function[%u] %s at offset %u: struct def_idx %u >= struct_count %u", fn_idx, info->name, fn->code_offset + pos, def_idx, mod->struct_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                            ;
            }
            break;
        }


        case OP_ENUM_VAL: {
            if (mod->enum_count > 0) {
                uint32_t def_idx = instr.operands[0].u32;
                if (def_idx >= mod->enum_count)
                    do { NvmVerifyResult result = fail("function[%u] %s at offset %u: enum def_idx %u >= enum_count %u", fn_idx, info->name, fn->code_offset + pos, def_idx, mod->enum_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                          ;
            }
            break;
        }


        case OP_UNION_CONSTRUCT: {
            if (mod->union_count > 0) {
                uint32_t def_idx = instr.operands[0].u32;
                if (def_idx >= mod->union_count)
                    do { NvmVerifyResult result = fail("function[%u] %s at offset %u: union def_idx %u >= union_count %u", fn_idx, info->name, fn->code_offset + pos, def_idx, mod->union_count); vm_decoded_function_free(&decoded); return result; } while (0)

                                                           ;
            }
            break;
        }

        case OP_AGG_PACK: {
            uint8_t kind = instr.operands[0].u8;
            uint32_t layout = instr.operands[1].u32;
            if (kind > AGG_TUPLE)
                do { NvmVerifyResult result = fail("function[%u] AGG_PACK at offset %u: invalid kind %u", fn_idx, fn->code_offset + pos, kind); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                 ;
            if (kind == AGG_RECORD && mod->struct_count > 0
                    && layout >= mod->struct_count)
                do { NvmVerifyResult result = fail("function[%u] AGG_PACK record layout %u >= struct_count %u", fn_idx, layout, mod->struct_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                               ;
            if (kind == AGG_VARIANT && mod->union_count > 0
                    && layout >= mod->union_count)
                do { NvmVerifyResult result = fail("function[%u] AGG_PACK variant layout %u >= union_count %u", fn_idx, layout, mod->union_count); vm_decoded_function_free(&decoded); return result; } while (0)
                                                              ;
            break;
        }






        case OP_ARR_NEW:
        case OP_TYPE_CHECK: {
            uint8_t tag = instr.operands[0].u8;
            if (tag >= TAG_COUNT)
                do { NvmVerifyResult result = fail("function[%u] %s at offset %u: type tag %u >= TAG_COUNT %u", fn_idx, info->name, fn->code_offset + pos, tag, (unsigned)TAG_COUNT); vm_decoded_function_free(&decoded); return result; } while (0)

                                                      ; break;
        }

        case OP_HM_NEW: {
            uint8_t key_tag = instr.operands[0].u8;
            uint8_t val_tag = instr.operands[1].u8;
            if (key_tag >= TAG_COUNT)
                do { NvmVerifyResult result = fail("function[%u] OP_HM_NEW at offset %u: key tag %u >= TAG_COUNT %u", fn_idx, fn->code_offset + pos, key_tag, (unsigned)TAG_COUNT); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                         ;
            if (val_tag >= TAG_COUNT)
                do { NvmVerifyResult result = fail("function[%u] OP_HM_NEW at offset %u: value tag %u >= TAG_COUNT %u", fn_idx, fn->code_offset + pos, val_tag, (unsigned)TAG_COUNT); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                         ;
            break;
        }

        case OP_ARR_LITERAL: {
            uint8_t tag = instr.operands[0].u8;
            if (tag >= TAG_COUNT)
                do { NvmVerifyResult result = fail("function[%u] OP_ARR_LITERAL at offset %u: element tag %u >= TAG_COUNT %u", fn_idx, fn->code_offset + pos, tag, (unsigned)TAG_COUNT); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                                     ;
            break;
        }

        default: {
# 869 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
            if (instr.opcode >= 0xff)
                do { NvmVerifyResult result = fail("function[%u] opcode 0x%02x at offset %u is outside the primary plane", fn_idx, instr.opcode, fn->code_offset + pos); vm_decoded_function_free(&decoded); return result; } while (0)
                                                                         ;
            break;
        }
        }

    }


    uint16_t proven_depth = 0;
    uint64_t scratch=(uint64_t)(decoded.instruction_count+1)*3u*sizeof(int32_t);
    if(!nvm_ra_bytes(budget,scratch) || !nvm_ra_steps(budget,(uint64_t)(decoded.instruction_count+1)*32u))
        return vm_decoded_function_free(&decoded),fail("I reached my private stack-check budget.");
    NvmVerifyResult stack_result =
        verify_stack_heights(mod, &decoded, fn_idx, &proven_depth);
    if(budget)budget->bytes-=scratch;
    if(budget && proven_depth>256) {
        vm_decoded_function_free(&decoded);budget->limited=
# 887 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                          1
# 887 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                              ;return fail("I reached my private stack bound.");
    }


    if (stack_result.ok)
        stack_result = budget?nvm_verify_function_types_record_array(mod,fn_idx,&decoded,proven_depth,budget):
            nvm_verify_function_types(mod, fn_idx, &decoded,proven_depth,
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                        ((void *)0)
# 893 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                            ,0);
    if (stack_result.ok && out_max_stack) *out_max_stack = proven_depth;
    if(stack_result.ok && kept)*kept=decoded;
    else vm_decoded_function_free(&decoded);
    return stack_result;
}

static NvmVerifyResult verify_record_arrays(const NvmModule *mod,uint32_t function,
                                             uint16_t *out_depth,const uint16_t *declared) {
    NvmRecordArrayExecutionPlan *plan=
# 902 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                     ((void *)0)
# 902 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                         ;
    NvmArrayEligibilityResult prepared=nvm_record_array_admit(mod,&plan);
    if(prepared.status!=NVM_ARRAY_ELIGIBLE)return fail("I refuse record-array admission: %s",prepared.message);
    NvmRecordArrayExecutionCounts counts;NvmVerifyResult result=ok_result();uint16_t depth=0;
    if(!nvm_record_array_execution_counts(plan,&counts) ||
       (function!=
# 907 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                 (4294967295U) 
# 907 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                            && function>=counts.functions))result=fail("I require an existing record-array function.");
    else for(uint32_t f=0;f<counts.functions;f++) {
        NvmRecordArrayExecutionFunction info;
        if(!nvm_record_array_execution_function(plan,f,&info)) {result=fail("I require complete record-array function facts.");break;}
        if(declared && declared[f] && declared[f]<info.maximum_stack) {
            result=fail("function %u declares max_stack %u but reaches %u",f,declared[f],info.maximum_stack);break;
        }
        if(f==function)depth=info.maximum_stack;
    }
    nvm_record_array_execution_free(plan);
    if(result.ok && out_depth)*out_depth=depth;
    return result;
}


static NvmVerifyResult verify_record_maps(const NvmModule *m,uint32_t function,
        uint16_t *out_depth,const uint16_t *declared) {
    NvmRecordMapExecutionPlan *p=
# 924 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                ((void *)0)
# 924 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                    ;
    NvmArrayEligibilityResult admitted=nvm_record_map_admit(m,&p);
    if(admitted.status!=NVM_ARRAY_ELIGIBLE)return fail("I refuse record-map admission: %s",admitted.message);
    NvmRecordMapExecutionCounts c;uint16_t depth=0;NvmVerifyResult result=ok_result();
    if(!nvm_record_map_execution_counts(p,&c) ||
       (function!=
# 929 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                 (4294967295U) 
# 929 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                            && function>=c.carrier.functions))result=fail("I require an existing record-map function.");
    else for(uint32_t i=0;i<c.carrier.functions;i++) {
        NvmRecordArrayExecutionFunction f;
        if(!nvm_record_map_execution_function(p,i,&f)){result=fail("I require complete record-map function facts.");break;}
        if(declared && declared[i] && declared[i]<f.maximum_stack) {
            result=fail("function %u declares max_stack %u but reaches %u",i,declared[i],f.maximum_stack);break;
        }
        if(i==function)depth=f.maximum_stack;
    }
    nvm_record_map_execution_free(p);
    if(result.ok && out_depth)*out_depth=depth;
    return result;
}

static NvmVerifyResult verify_function_impl(const NvmModule *mod, uint32_t fn_idx,
                                           const NvmModule *const *linked_modules,
                                           uint32_t linked_count,
                                           uint16_t *out_max_stack) {
    if(nvm_service_execution_pending(mod))
        return fail("I refuse service contracts before mixed execution selection");
    for(uint32_t i=0;i<linked_count;i++)
        if(!linked_modules || nvm_record_map_selected(nvm_record_map_route(linked_modules[i])))
            return fail("I refuse record-map authority in linked verification.");
    if(nvm_record_map_selected(nvm_record_map_route(mod))) {
        if(linked_count)return fail("I refuse linked record-map execution contracts.");
        return verify_record_maps(mod,fn_idx,out_max_stack,
# 954 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                          ((void *)0)
# 954 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                              );
    }
    if(nvm_owned_array_route(mod)!=NVM_OWNER_ARRAY_NOT_SELECTED) {
        if(linked_count)return fail("I refuse linked owner ARRAY execution contracts");
        return verify_owned_arrays(mod,fn_idx,out_max_stack);
    }
    if(nvm_mixed_samples_candidate(mod)) {
        if(linked_count)return fail("I refuse linked mixed ownership execution contracts");
        return verify_mixed_samples(mod,fn_idx,out_max_stack);
    }
    if(nvm_record_array_candidate(mod)) {
        if(linked_count)return fail("I refuse linked record-array execution contracts.");
        return verify_record_arrays(mod,fn_idx,out_max_stack,
# 966 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                            ((void *)0)
# 966 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                );
    }
    for(uint32_t i=0;i<linked_count;i++)
        if(!linked_modules || nvm_record_array_candidate(linked_modules[i]))
            return fail("I refuse record-array candidates in linked function verification.");
    
# 971 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 971 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        owned_admitted=
# 971 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                       0
# 971 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                            ;
    NvmVerifyResult structure = verify_structure(mod, 
# 972 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                     0
# 972 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                          , &owned_admitted);
    if (!structure.ok) return structure;
    if (fn_idx >= mod->function_count)
        return fail("function index %u >= function_count %u",
                    fn_idx, mod->function_count);
    if (mod->ownership_size && (owned_admitted || nvm_verify_owned_module(mod).ok)) {
        if (linked_count) return fail("I refuse linked ownership execution contracts");
        if (out_max_stack) *out_max_stack = 256u;
        return ok_result();
    }
    return verify_function_body(mod, fn_idx, linked_modules, linked_count, out_max_stack,
# 982 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                        ((void *)0)
# 982 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                            ,
# 982 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                             ((void *)0)
# 982 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                 );
}

# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 1
# 9 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
typedef struct NvmMapDeclarationPlan NvmMapDeclarationPlan;
typedef enum { NVM_MAP_ABSENT, NVM_MAP_DESCRIBED, NVM_MAP_INVALID,
               NVM_MAP_LIMIT, NVM_MAP_MEMORY } NvmMapDeclarationStatus;
typedef struct { NvmMapDeclarationStatus status; const char *message; } NvmMapDeclarationResult;
typedef struct { uint32_t scalars,pairs,bindings; } NvmMapDeclarationCounts;
typedef struct { uint32_t key_type,value_type; } NvmMapDeclarationPair;
typedef struct { uint32_t layout; uint16_t field; uint32_t pair; } NvmMapDeclarationBinding;
NvmMapDeclarationResult nvm_prepare_map_declarations(const NvmModule *,NvmMapDeclarationPlan **);
void nvm_map_declarations_free(NvmMapDeclarationPlan *);

# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_counts(const NvmMapDeclarationPlan *,NvmMapDeclarationCounts *);

# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_scalar(const NvmMapDeclarationPlan *,uint32_t,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_pair(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationPair *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_binding(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationBinding *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_field(const NvmMapDeclarationPlan *,uint32_t,uint16_t,NvmMapDeclarationPair *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 2

NvmMapDeclarationResult nvm_prepare_map_declarations_split(const NvmModule *,
    NvmMapDeclarationPlan **,NvmOwnershipDeclarationPlan **);
NvmArrayEligibilityResult nvm_record_map_structure_prepare(const NvmModule *,
    NvmRecordArrayBudget *,NvmRecordArrayStructure **,NvmMapDeclarationPlan **);
static inline 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 3 4
             _Bool 
# 10 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_map_structure_private.h"
                  nvm_record_map_opcode(uint8_t op) {
    return op==OP_HM_NEW || op==OP_HM_SET || op==OP_HM_GET ||
           op==OP_HM_HAS || op==OP_HM_LEN || op==OP_HM_DELETE;
}
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc" 2

void nvm_record_array_structure_free(NvmRecordArrayStructure *p) {
    if(!p)return;
    for(uint32_t i=0;i<p->functions;i++)vm_decoded_function_free(&p->decoded[i]);
    nvm_ownership_declarations_free(p->declarations);free(p);
}
static NvmArrayEligibilityResult ra_result(NvmArrayEligibilityStatus status,uint32_t fn,
                                           const char *message) {
    NvmArrayEligibilityResult r={.status=status,.function=fn};
    snprintf(r.message,sizeof r.message,"%s",message);return r;
}
static NvmArrayEligibilityResult record_structure_prepare(const NvmModule *m,
        NvmRecordArrayBudget *b,NvmRecordArrayStructure **out,NvmMapDeclarationPlan **map_out) {
    if(!m || !b || !out)return ra_result(NVM_ARRAY_INVALID,0,"I require private preparation inputs.");

    if(b->bytes || b->work || b->peak || b->limited || b->memory)
        return ra_result(NVM_ARRAY_INVALID,0,"I require fresh private accounting.");


    if(!nvm_ra_bytes(b,65536) || !nvm_ra_steps(b,65536))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my fixed scratch reservation.");
    if(m->service_data || m->service_size || m->import_count || m->module_ref_count ||
       m->passive_data || m->passive_size || m->callback_contract_count)
        return ra_result(NVM_ARRAY_UNRESOLVED,0,"I require a closed ordinary module without host contracts.");
    if(m->function_count>256 || m->string_count>4096 || m->code_size>16u*1024u*1024u)
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my private module bound.");
    if(!m->function_count || !m->functions || (m->code_size && !m->code) ||
       (m->string_count && (!m->strings || !m->string_lengths)) ||
       m->section_count>16 || m->header.section_count>16)
        return ra_result(NVM_ARRAY_INVALID,0,"I require consistent original module storage.");
    if(m->header.magic[0]!='N' || m->header.magic[1]!='V' ||
       m->header.magic[2]!='M' || m->header.magic[3]!=0x01 ||
       m->header.format_version!=2 ||
       (m->header.flags&~((1 << 0)|(1 << 1)|(1 << 2))))
        return ra_result(NVM_ARRAY_INVALID,0,"I require the original in-memory module header.");
    if(!(m->header.flags&(1 << 0)) || m->header.entry_point>=m->function_count)
        return ra_result(NVM_ARRAY_UNRESOLVED,0,"I require a bounded module entry.");
    for(uint32_t i=0;i<m->string_count;i++) {
        if(!m->strings[i])return ra_result(NVM_ARRAY_INVALID,0,"I require a present counted string.");
        if(!nvm_ra_steps(b,(uint64_t)m->string_lengths[i]+1))
            return ra_result(NVM_ARRAY_LIMIT,0,"I reached my counted-string work bound.");
        if(m->strings[i][m->string_lengths[i]]!='\0')
            return ra_result(NVM_ARRAY_INVALID,0,"I require terminated counted strings.");
    }
    if(!nvm_ra_steps(b,(uint64_t)m->metadata_count*32u+1))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my metadata work bound.");
    if(!nvm_metadata_valid(m))return ra_result(NVM_ARRAY_INVALID,0,"I require consistent source metadata.");
    uint32_t counts[256]={0};uint32_t total=0;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        const NvmFunctionEntry *f=&m->functions[fi];
        if(!f->code_length && f->result_count)
            return ra_result(NVM_ARRAY_INVALID,fi,"I require a value-producing body for a declared result.");
        if(f->local_count>256)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my local bound.");
        if(f->upvalue_count || f->result_count>1 ||
           !(f->result_tag<=TAG_STRING || f->result_tag==TAG_ARRAY || f->result_tag==TAG_STRUCT))
            return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I require ordinary direct-call signatures.");
        if(f->code_offset>m->code_size || f->code_length>m->code_size-f->code_offset)
            return ra_result(NVM_ARRAY_INVALID,fi,"I require bounded original code ranges.");
        if(!nvm_ra_steps(b,(uint64_t)f->code_length+256u+m->function_count))
            return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my structural scan bound.");
        for(uint16_t p=0;p<f->arity;p++) {
            if(p>=256)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my parameter bound.");
            uint8_t tag=m->function_param_types && m->function_param_types[fi]?m->function_param_types[fi][p]:TAG_VOID;
            if(!(tag<=TAG_STRING || tag==TAG_ARRAY || tag==TAG_STRUCT))
                return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I require ordinary parameter tags.");
        }
        for(uint32_t pc=0;pc<f->code_length;) {
            DecodedInstruction in;uint32_t width=isa_decode(m->code+f->code_offset+pc,f->code_length-pc,&in);
            if(!width)return ra_result(NVM_ARRAY_INVALID,fi,"I require decodable original instructions.");
            if(++total>65536)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my instruction bound.");
            counts[fi]++;
            if((!nvm_record_array_opcode_supported(in.opcode) && !(map_out && nvm_record_map_opcode(in.opcode))) ||
               (in.opcode==OP_AGG_PACK && (in.operands[0].u8!=AGG_RECORD || in.operands[2].u16)))
                return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I have no ordinary record-array transfer for this opcode.");
            if((in.opcode==OP_LOAD_GLOBAL || in.opcode==OP_STORE_GLOBAL) && in.operands[0].u32>=256)
                return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my global bound.");
            pc+=width;
        }
    }



    for(uint32_t fi=0;fi<m->function_count;fi++)
        if(!nvm_ra_steps(b,(uint64_t)m->functions[fi].code_length+
                            m->functions[fi].arity+m->function_count+32u))
            return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my shared structural rescan bound.");


    if(!nvm_ra_steps(b,32))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my empty contract-check bound.");
    NvmVerifyResult r=verify_module_ranges(m);
    if(!r.ok)return ra_result(NVM_ARRAY_INVALID,0,r.error_msg);
    r=verify_module_contracts_and_imports(m);
    if(!r.ok)return ra_result(NVM_ARRAY_INVALID,0,r.error_msg);


    if(!nvm_ra_bytes(b,16UL*1024*1024) || !nvm_ra_steps(b,1048576))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my declaration reservation bound.");
    NvmRecordArrayStructure *p=nvm_ra_alloc(b,1,sizeof *p);
    if(!p)return ra_result(b->limited?NVM_ARRAY_LIMIT:NVM_ARRAY_MEMORY,0,"I could not allocate private structure.");
    NvmMapDeclarationPlan *maps=
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc" 3 4
                               ((void *)0)
# 102 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc"
                                   ;
    NvmDeclarationResult declarations;
    if(map_out) {

        if(!nvm_ra_bytes(b,2UL*1024*1024) || !nvm_ra_steps(b,4UL*1024*1024)) {
            nvm_record_array_structure_free(p);
            return ra_result(NVM_ARRAY_LIMIT,0,"I reached my map declaration overlap bound.");
        }
        NvmMapDeclarationResult r=nvm_prepare_map_declarations_split(m,&maps,&p->declarations);
        declarations=(NvmDeclarationResult){r.status==NVM_MAP_DESCRIBED?NVM_DECL_PREPARED:
            r.status==NVM_MAP_MEMORY?NVM_DECL_MEMORY:r.status==NVM_MAP_LIMIT?NVM_DECL_LIMIT:
            r.status==NVM_MAP_ABSENT?NVM_DECL_UNKNOWN:NVM_DECL_INVALID,r.message};
    } else declarations=nvm_prepare_ownership_declarations(m,&p->declarations);
    if(declarations.status!=NVM_DECL_PREPARED) {
        nvm_map_declarations_free(maps);nvm_record_array_structure_free(p);
        return ra_result(declarations.status==NVM_DECL_MEMORY?NVM_ARRAY_MEMORY:
            declarations.status==NVM_DECL_LIMIT?NVM_ARRAY_LIMIT:
            declarations.status==NVM_DECL_UNKNOWN?NVM_ARRAY_UNRESOLVED:NVM_ARRAY_INVALID,0,declarations.message);
    }
    p->functions=m->function_count;
    for(uint32_t fi=0;fi<p->functions;fi++) {
        uint64_t capacity=16;while(capacity<counts[fi])capacity*=2;


        uint64_t decoded=(uint64_t)(m->functions[fi].code_length+1)*5u+
            (counts[fi]?capacity*3u*sizeof(VmDecodedInstruction):0);
        if(!nvm_ra_bytes(b,decoded) || !nvm_ra_steps(b,(uint64_t)m->functions[fi].code_length+counts[fi]*16u)) {
            nvm_map_declarations_free(maps);nvm_record_array_structure_free(p);return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my decoded storage bound.");
        }
        r=verify_function_body(m,fi,
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc" 3 4
                                   ((void *)0)
# 131 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc"
                                       ,0,&p->stacks[fi],b,&p->decoded[fi]);
        if(!r.ok) {
            nvm_map_declarations_free(maps);nvm_record_array_structure_free(p);
            return ra_result(b->limited?NVM_ARRAY_LIMIT:b->memory || strstr(r.error_msg,"allocat")?
                NVM_ARRAY_MEMORY:NVM_ARRAY_INVALID,fi,r.error_msg);
        }
    }
    if(map_out)*map_out=maps;
    *out=p;return ra_result(NVM_ARRAY_ELIGIBLE,0,"I copied bounded structure, not executable authority.");
}

NvmArrayEligibilityResult nvm_record_array_structure_prepare(const NvmModule *m,
        NvmRecordArrayBudget *b,NvmRecordArrayStructure **out) {
    return record_structure_prepare(m,b,out,
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc" 3 4
                                           ((void *)0)
# 144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_array_structure.inc"
                                               );
}
NvmArrayEligibilityResult nvm_record_map_structure_prepare(const NvmModule *m,
        NvmRecordArrayBudget *b,NvmRecordArrayStructure **out,NvmMapDeclarationPlan **maps) {
    if(!maps)return ra_result(NVM_ARRAY_INVALID,0,"I require a map declaration output.");
    return record_structure_prepare(m,b,out,maps);
}
# 986 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 1
# 11 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
typedef struct NvmUnionFieldDeclarations NvmUnionFieldDeclarations;
typedef enum { NVM_UFD_PREPARED, NVM_UFD_UNKNOWN, NVM_UFD_INVALID,
               NVM_UFD_LIMIT, NVM_UFD_MEMORY } NvmUnionFieldDeclarationStatus;
typedef struct {
    NvmUnionFieldDeclarationStatus status;
    const char *message;
    uint64_t bytes_reserved, work_reserved;
} NvmUnionFieldDeclarationResult;
NvmUnionFieldDeclarationResult nvm_union_field_declarations_prepare(const NvmModule *,NvmUnionFieldDeclarations **);
void nvm_union_field_declarations_free(NvmUnionFieldDeclarations *);

# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_layout(const NvmUnionFieldDeclarations *,uint32_t,NvmDeclarationLayout *);

# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_field(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmV2LayoutField *);

# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_variant(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_nominal(const NvmUnionFieldDeclarations *,uint8_t,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure_private.h" 2







typedef struct {
    NvmRecordArrayStructure *carrier;
    NvmUnionFieldDeclarations *declarations;
} NvmRecordUnionStructure;
NvmArrayEligibilityResult nvm_record_union_structure_prepare(
    const NvmModule *,NvmRecordArrayBudget *,NvmRecordUnionStructure **);
void nvm_record_union_structure_free(NvmRecordUnionStructure *);
# 2 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure.inc" 2

void nvm_record_union_structure_free(NvmRecordUnionStructure *p) {
    if(!p)return;
    nvm_record_array_structure_free(p->carrier);
    nvm_union_field_declarations_free(p->declarations);
    free(p);
}
NvmArrayEligibilityResult nvm_record_union_structure_prepare(const NvmModule *m,
        NvmRecordArrayBudget *b,NvmRecordUnionStructure **out) {
    if(!m || !b || !out)return ra_result(NVM_ARRAY_INVALID,0,"I require private preparation inputs.");

    if(b->bytes || b->work || b->peak || b->limited || b->memory)
        return ra_result(NVM_ARRAY_INVALID,0,"I require fresh private accounting.");


    if(!nvm_ra_bytes(b,65536) || !nvm_ra_steps(b,65536))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my fixed scratch reservation.");
    if(m->service_data || m->service_size || m->import_count || m->module_ref_count ||
       m->passive_data || m->passive_size || m->callback_contract_count)
        return ra_result(NVM_ARRAY_UNRESOLVED,0,"I require a closed ordinary module without host contracts.");
    if(m->function_count>256 || m->string_count>4096 || m->code_size>16u*1024u*1024u)
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my private module bound.");
    if(!m->function_count || !m->functions || (m->code_size && !m->code) ||
       (m->string_count && (!m->strings || !m->string_lengths)) ||
       m->section_count>16 || m->header.section_count>16)
        return ra_result(NVM_ARRAY_INVALID,0,"I require consistent original module storage.");
    if(m->header.magic[0]!='N' || m->header.magic[1]!='V' ||
       m->header.magic[2]!='M' || m->header.magic[3]!=0x01 ||
       m->header.format_version!=2 ||
       (m->header.flags&~((1 << 0)|(1 << 1)|(1 << 2))))
        return ra_result(NVM_ARRAY_INVALID,0,"I require the original in-memory module header.");
    if(!(m->header.flags&(1 << 0)) || m->header.entry_point>=m->function_count)
        return ra_result(NVM_ARRAY_UNRESOLVED,0,"I require a bounded module entry.");
    for(uint32_t i=0;i<m->string_count;i++) {
        if(!m->strings[i])return ra_result(NVM_ARRAY_INVALID,0,"I require a present counted string.");
        if(!nvm_ra_steps(b,(uint64_t)m->string_lengths[i]+1))
            return ra_result(NVM_ARRAY_LIMIT,0,"I reached my counted-string work bound.");
        if(m->strings[i][m->string_lengths[i]]!='\0')
            return ra_result(NVM_ARRAY_INVALID,0,"I require terminated counted strings.");
    }
    if(!nvm_ra_steps(b,(uint64_t)m->metadata_count*32u+1))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my metadata work bound.");
    if(!nvm_metadata_valid(m))return ra_result(NVM_ARRAY_INVALID,0,"I require consistent source metadata.");
    uint32_t counts[256]={0};uint32_t total=0;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        const NvmFunctionEntry *f=&m->functions[fi];
        if(!f->code_length && f->result_count)
            return ra_result(NVM_ARRAY_INVALID,fi,"I require a value-producing body for a declared result.");
        if(f->local_count>256)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my local bound.");
        if(f->upvalue_count || f->result_count>1 ||
           !(f->result_tag<=TAG_STRING || f->result_tag==TAG_ARRAY || f->result_tag==TAG_STRUCT || f->result_tag==TAG_UNION))
            return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I require ordinary direct-call signatures.");
        if(f->code_offset>m->code_size || f->code_length>m->code_size-f->code_offset)
            return ra_result(NVM_ARRAY_INVALID,fi,"I require bounded original code ranges.");
        if(!nvm_ra_steps(b,(uint64_t)f->code_length+256u+m->function_count))
            return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my structural scan bound.");
        for(uint16_t p=0;p<f->arity;p++) {
            if(p>=256)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my parameter bound.");
            uint8_t tag=m->function_param_types && m->function_param_types[fi]?m->function_param_types[fi][p]:TAG_VOID;
            if(!(tag<=TAG_STRING || tag==TAG_ARRAY || tag==TAG_STRUCT || tag==TAG_UNION))
                return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I require ordinary parameter tags.");
        }
        for(uint32_t pc=0;pc<f->code_length;) {
            DecodedInstruction in;uint32_t width=isa_decode(m->code+f->code_offset+pc,f->code_length-pc,&in);
            if(!width)return ra_result(NVM_ARRAY_INVALID,fi,"I require decodable original instructions.");
            if(++total>65536)return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my instruction bound.");
            counts[fi]++;
            if((!nvm_record_array_opcode_supported(in.opcode) && in.opcode!=OP_AGG_TAG && in.opcode!=OP_HALT) ||
               (in.opcode==OP_AGG_PACK && ((in.operands[0].u8!=AGG_RECORD && in.operands[0].u8!=AGG_VARIANT) || (in.operands[0].u8==AGG_RECORD && in.operands[2].u16))))
                return ra_result(NVM_ARRAY_UNRESOLVED,fi,"I have no ordinary union-field transfer for this opcode.");
            if((in.opcode==OP_LOAD_GLOBAL || in.opcode==OP_STORE_GLOBAL) && in.operands[0].u32>=256)
                return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my global bound.");
            pc+=width;
        }
    }



    for(uint32_t fi=0;fi<m->function_count;fi++)
        if(!nvm_ra_steps(b,(uint64_t)m->functions[fi].code_length+
                            m->functions[fi].arity+m->function_count+32u))
            return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my shared structural rescan bound.");


    if(!nvm_ra_steps(b,32))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my empty contract-check bound.");
    NvmVerifyResult r=verify_module_ranges(m);
    if(!r.ok)return ra_result(NVM_ARRAY_INVALID,0,r.error_msg);
    r=verify_module_contracts_and_imports(m);
    if(!r.ok)return ra_result(NVM_ARRAY_INVALID,0,r.error_msg);


    if(!nvm_ra_bytes(b,16UL*1024*1024) || !nvm_ra_steps(b,1048576))
        return ra_result(NVM_ARRAY_LIMIT,0,"I reached my declaration reservation bound.");
    NvmRecordUnionStructure *u=nvm_ra_alloc(b,1,sizeof *u);
    if(!u)return ra_result(b->limited?NVM_ARRAY_LIMIT:NVM_ARRAY_MEMORY,0,"I could not allocate union structure owner.");
    u->carrier=nvm_ra_alloc(b,1,sizeof *u->carrier);
    if(!u->carrier) {
        nvm_record_union_structure_free(u);
        return ra_result(b->limited?NVM_ARRAY_LIMIT:NVM_ARRAY_MEMORY,0,"I could not allocate union structure carrier.");
    }
    NvmUnionFieldDeclarationResult declarations=nvm_union_field_declarations_prepare(m,&u->declarations);
    if(declarations.status!=NVM_UFD_PREPARED) {
        nvm_record_union_structure_free(u);
        return ra_result(declarations.status==NVM_UFD_MEMORY?NVM_ARRAY_MEMORY:
            declarations.status==NVM_UFD_LIMIT?NVM_ARRAY_LIMIT:
            declarations.status==NVM_UFD_UNKNOWN?NVM_ARRAY_UNRESOLVED:NVM_ARRAY_INVALID,0,declarations.message);
    }
    NvmRecordArrayStructure *p=u->carrier;
    p->functions=m->function_count;
    for(uint32_t fi=0;fi<p->functions;fi++) {
        uint64_t capacity=16;while(capacity<counts[fi])capacity*=2;


        uint64_t decoded=(uint64_t)(m->functions[fi].code_length+1)*5u+
            (counts[fi]?capacity*3u*sizeof(VmDecodedInstruction):0);
        if(!nvm_ra_bytes(b,decoded) || !nvm_ra_steps(b,(uint64_t)m->functions[fi].code_length+counts[fi]*16u)) {
            nvm_record_union_structure_free(u);return ra_result(NVM_ARRAY_LIMIT,fi,"I reached my decoded storage bound.");
        }
        r=verify_function_body(m,fi,
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure.inc" 3 4
                                   ((void *)0)
# 121 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/record_union_structure.inc"
                                       ,0,&p->stacks[fi],b,&p->decoded[fi]);
        if(!r.ok) {
            nvm_record_union_structure_free(u);
            return ra_result(b->limited?NVM_ARRAY_LIMIT:b->memory || strstr(r.error_msg,"allocat")?
                NVM_ARRAY_MEMORY:NVM_ARRAY_INVALID,fi,r.error_msg);
        }
    }
    *out=u;return ra_result(NVM_ARRAY_ELIGIBLE,0,"I copied bounded structure, not executable authority.");
}
# 987 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 2

NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx) {
    NvmVerifyResult structure=verify_structure(mod,
# 989 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                  1
# 989 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                      ,
# 989 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                       ((void *)0)
# 989 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                           );
    if (!structure.ok) return structure;
    NvmAffineAnalysis analysis=nvm_affine_analyze_function(mod,fn_idx);
    if (!analysis.ok) return fail("I refuse reference lifetime and ownership instruction dataflow at %u: %s",
                                  analysis.byte_offset,analysis.message);
    return ok_result();
}



# 998 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
_Bool 
# 998 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
    nvm_uses_owned_transfers(const NvmModule *mod) {
    if (!mod) return 
# 999 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                    1
# 999 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                        ;
    if (mod->function_count && !mod->functions) return 
# 1000 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                      1
# 1000 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                          ;
    for (uint32_t f=0;f<mod->function_count;f++) {
        const NvmFunctionEntry *fn=&mod->functions[f];
        if (fn->code_offset>mod->code_size || fn->code_length>mod->code_size-fn->code_offset ||
            (fn->code_length && !mod->code)) return 
# 1004 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                   1
# 1004 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                       ;
        uint32_t offset=0;
        while (offset<fn->code_length) {
            DecodedInstruction instruction;
            uint32_t count=isa_decode(mod->code+fn->code_offset+offset,fn->code_length-offset,&instruction);
            if (!count) break;
            if ((instruction.opcode>=OP_OWN_MOVE_LOCAL && instruction.opcode<=OP_CALL_REF) ||
                (instruction.opcode>=OP_REGION_BEGIN && instruction.opcode<=OP_REBORROW_EXCLUSIVE)) return 
# 1011 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                          1
# 1011 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                              ;
            offset+=count;
        }
    }
    return 
# 1015 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
          0
# 1015 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
               ;
}


static 
# 1019 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
      _Bool 
# 1019 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
           owned_runtime_opcode(uint8_t op,
# 1019 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                           _Bool 
# 1019 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                value_graph) {
    switch (op) {
    case OP_HALT: case OP_CALL: case OP_CALL_REF: case OP_MATCH_TAG:
    case OP_BORROW_PATH_SHARED: case OP_BORROW_PATH_EXCLUSIVE:
    case OP_REBORROW_SHARED: case OP_REBORROW_EXCLUSIVE:
    case OP_REGION_BEGIN: case OP_REGION_END:
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE: case OP_REF_GET: case OP_REF_SET:
    case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL: case OP_OWN_PACK: case OP_OWN_UNPACK_LOCAL:
    case OP_NOP: case OP_PUSH_I64: case OP_PUSH_U8: case OP_PUSH_BOOL: case OP_PUSH_F64:
    case OP_DUP: case OP_POP: case OP_SWAP: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_AGG_PACK: case OP_AGG_GET: case OP_AGG_TAG: case OP_STRUCT_GET:
    case OP_ADD: case OP_SUB: case OP_MUL:
    case OP_DIV: case OP_MOD: case OP_NEG: case OP_EQ: case OP_NE: case OP_LT:
    case OP_LE: case OP_GT: case OP_GE: case OP_AND: case OP_OR: case OP_NOT:
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV: case OP_F64_NEG:
    case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE: case OP_RET: case OP_ASSERT:
        return 
# 1036 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
              1
# 1036 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                  ;
    case OP_HANDLER_PUSH: case OP_HANDLER_POP: case OP_PERFORM: case OP_EFFECT_RESUME:
    case OP_PUSH_VOID:
    case OP_PUSH_STR: case OP_PRINT: case OP_PRINTLN:
    case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL:
        return value_graph;
    default: return 
# 1042 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                   0
# 1042 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                        ;
    }
}

NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod) {
    NvmVerifyResult structure = verify_structure(mod, 
# 1047 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                     1
# 1047 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                         ,
# 1047 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                          ((void *)0)
# 1047 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                              );
    if (!structure.ok) return structure;
    if (!mod->ownership_size || (!mod->function_count || mod->function_count>8u) || mod->header.entry_point != 0 ||
        mod->import_count || mod->module_ref_count || mod->callback_contract_count || mod->passive_size)
        return fail("I require standalone ownership instruction execution semantics without linked contracts");
    uint32_t globals;NvmOwnershipGlobal global_types[256u];
    if (nvm_ownership_globals(mod,global_types,256u,&globals)!=NVM_V2_OK)
        return fail("I require exact global declarations before owned execution");
    for (uint32_t g=0;g<globals;g++)
        if (global_types[g].tag==TAG_STRUCT || (global_types[g].tag==TAG_UNION &&
            (mod->ownership_data[8+global_types[g].layout]&2u)))
            return fail("I require explicit record/resource global transfers and lifetime");
    
# 1059 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1059 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        value_graph=nvm_affine_value_call_graph(mod);
    if (!value_graph && mod->function_count>2)
        return fail("I require a bounded acyclic value graph or my separate borrowed helper");
    for(uint32_t function=0;function<mod->function_count;function++) {
        const NvmFunctionEntry *fn=&mod->functions[function];
        const char *name=nvm_get_string(mod,fn->name_idx);
        if ((function ? ((!value_graph && !fn->arity) || fn->arity>8u) : fn->arity!=0) || fn->upvalue_count ||
            ((!function || !value_graph) && (fn->result_count!=1 ||
             (fn->result_tag!=TAG_INT && fn->result_tag!=TAG_BOOL && fn->result_tag!=TAG_U8))) ||
            fn->local_count>256u || (name && !strcmp(name,"__init__")))
            return fail("I require a scalar entry and exact bounded value-result helper signatures");
        NvmAffineState *state=nvm_affine_state_create(mod,function,fn->local_count);
        if(!state) return fail("I require complete ownership local declarations");
        if(nvm_affine_has_array_types(state)) {
            nvm_affine_state_free(state);
            return fail("I require matched collection runtime cleanup before typed-array execution");
        }
        NvmAffineType result;uint16_t fields=0;
        
# 1077 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
       _Bool 
# 1077 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
            valid=nvm_affine_value_result(state,&result,&fields);
        for(uint16_t i=0;i<fn->local_count;i++) {
            NvmAffineType type;NvmReferenceMode mode;
            if(function && !value_graph && i<fn->arity) {
                if(!nvm_affine_parameter_at(state,i,&type,&mode)) valid=
# 1081 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                       0
# 1081 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                            ;
            } else if(!nvm_affine_local_type(state,i,&type) ||
                (type.tag!=TAG_INT && type.tag!=TAG_BOOL && type.tag!=TAG_U8 &&
                 type.tag!=TAG_STRUCT && type.tag!=TAG_UNION &&
                 !(i>=fn->arity && type.tag==TAG_FLOAT &&
                                           type.layout==0xFFFFFFFFu) &&
                 !(value_graph && type.tag==TAG_STRING &&
                                           type.layout==0xFFFFFFFFu))) valid=
# 1088 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                0
# 1088 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                     ;
        }
        nvm_affine_state_free(state);
        if(!valid) return fail("I require value entry locals and exact borrowed or consuming value helper parameters");
    }
    NvmV2Layouts layouts = {0};
    if (nvm_v2_layouts_decode(mod->layout_data, mod->layout_size, &layouts) != NVM_V2_OK)
        return fail("I require complete owned record layouts");
    
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        supported = 
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                    1
# 1096 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                        ;
    uint32_t union_ordinal=0;
    for (uint32_t i=0; i<layouts.count; i++) {
        const NvmV2Layout *layout = &layouts.items[i];
        if (layout->kind==NVM_V2_LAYOUT_UNION) {
            NvmUnionVariantFact fact;
            if ((mod->ownership_data[8+i] &&
                 !(mod->ownership_data[8+i]&1u)) ||
                nvm_ownership_union_variant(mod,union_ordinal,0,&fact)!=NVM_V2_OK ||
                fact.layout!=i) supported=
# 1105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                         0
# 1105 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                              ;
            union_ordinal++;
            continue;
        }
        if (!(mod->ownership_data[8+i] & 1u) ||
            layout->kind != NVM_V2_LAYOUT_STRUCT || layout->field_count > 256u)
            supported = 
# 1111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                       0
# 1111 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                            ;
        for (uint16_t f=0; f<layout->field_count; f++) {
            uint8_t tag=layout->fields[f].type_tag;

            uint32_t child=layout->fields[f].nested_idx;
            if(child!=0xFFFFFFFFu && child>=i) supported=
# 1116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                            0
# 1116 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                 ;
            if (tag!=TAG_INT && tag!=TAG_BOOL && tag!=TAG_U8 && tag!=TAG_STRUCT && tag!=TAG_UNION &&
                !(value_graph && tag==TAG_STRING && child==0xFFFFFFFFu)) supported=
# 1118 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                      0
# 1118 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                           ;
        }
    }
    nvm_v2_layouts_free(&layouts);
    if (!supported) return fail("I require exact scalar, retained STRING or owned-child record fields before execution");
    
# 1123 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1123 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        transfer=globals!=0;
    for(uint32_t function=0;function<mod->function_count;function++) {
        VmDecodedFunction decoded;char error[256];
        if(!vm_decode_function(mod,function,&decoded,error)) return fail("%s",error);
        for(uint32_t i=0;i<decoded.instruction_count;i++) {
            const DecodedInstruction *in=&decoded.instructions[i].instruction;
            uint8_t op=in->opcode;
            if(op>=OP_OWN_MOVE_LOCAL && op<=OP_OWN_UNPACK_LOCAL) transfer=
# 1130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                         1
# 1130 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                             ;




            if(op==OP_AGG_PACK && in->operands[0].u8==AGG_VARIANT) transfer=
# 1135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                           1
# 1135 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                               ;
            if(!owned_runtime_opcode(op,value_graph)) supported=
# 1136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                               0
# 1136 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                    ;
            if(op==OP_PUSH_STR) {
                uint32_t index=in->operands[0].u32;
                if(index>=mod->string_count || !mod->strings || !mod->string_lengths ||
                   !mod->strings[index] ||
                   memchr(mod->strings[index],'\0',mod->string_lengths[index])) supported=
# 1141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                         0
# 1141 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                              ;
            }
            if(op==OP_CALL_REF && (function || value_graph || mod->function_count!=2 || in->operands[0].u32!=1)) supported=
# 1143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                                          0
# 1143 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                                               ;
            if(op==OP_CALL && (!value_graph || !in->operands[0].u32 || in->operands[0].u32>=mod->function_count)) supported=
# 1144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                                           0
# 1144 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                                                ;
            if(function && !value_graph && (op==OP_AGG_GET || op==OP_STRUCT_GET || (
                ((op==OP_LOAD_LOCAL || op==OP_STORE_LOCAL || op==OP_OWN_MOVE_LOCAL ||
                  op==OP_OWN_STORE_LOCAL || op==OP_OWN_UNPACK_LOCAL) && in->operands[0].u16<mod->functions[function].arity) ||
                ((op==OP_BORROW_LOCAL_SHARED || op==OP_BORROW_LOCAL_EXCLUSIVE ||
                  op==OP_BORROW_PATH_SHARED || op==OP_BORROW_PATH_EXCLUSIVE) &&
                 in->operands[1].u16<mod->functions[function].arity)))) supported=
# 1150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                 0
# 1150 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                      ;
        }
        vm_decoded_function_free(&decoded);
        if(function && !nvm_affine_analyze_function(mod,function).ok) supported=
# 1153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                               0
# 1153 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                    ;
    }
    if(!supported || !transfer) return fail("I require explicit owned entry execution and a non-escaping scalar helper");
    return nvm_verify_affine_function(mod, 0);
}

NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx) {
    return verify_function_impl(mod, fn_idx, 
# 1160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                            ((void *)0)
# 1160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                , 0, 
# 1160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                     ((void *)0)
# 1160 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                         );
}

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack) {
    return verify_function_impl(mod, fn_idx, 
# 1166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                            ((void *)0)
# 1166 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                , 0, out_max_stack);
}







static NvmVerifyResult verify_functions_with_structure(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count,
                                  const uint16_t *declared_depths) {
    
# 1179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        owned_admitted = 
# 1179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                         0
# 1179 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                              ;
    NvmVerifyResult r = verify_structure(mod, 
# 1180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                             0
# 1180 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                  , &owned_admitted);
    if (!r.ok) return r;
    if (!owned_admitted && mod->function_count && mod->ownership_size)
        owned_admitted = nvm_verify_owned_module(mod).ok;
    if (owned_admitted && linked_count)
        return fail("I refuse linked ownership execution contracts");
    for (uint32_t i = 0; i < mod->function_count; ++i) {
        if (declared_depths && !declared_depths[i]) continue;
        uint16_t depth = 256u;
        if (!owned_admitted) {
            r = verify_function_body(mod, i, linked_modules, linked_count,
                                     declared_depths ? &depth : 
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                               ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                   , 
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                     ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                         , 
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                           ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                               );
            if (!r.ok) return r;
        }
        if (declared_depths && declared_depths[i] < depth)
            return fail("function %u declares max_stack %u but reaches %u",
                        i, (unsigned)declared_depths[i], (unsigned)depth);
    }
    return ok_result();
}

NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count) {
    if (!mod || count != mod->function_count || (count && !declared_depths))
        return fail("I require one declared stack depth per function");
    
# 1206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        selected = 
# 1206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                   0
# 1206 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                        ;
    for (uint32_t i = 0; i < count; ++i) selected |= declared_depths[i] != 0;


    if(nvm_record_map_selected(nvm_record_map_route(mod)))return verify_record_maps(mod,
# 1210 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                       (4294967295U)
# 1210 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                 ,
# 1210 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                  ((void *)0)
# 1210 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                      ,declared_depths);
    if (!selected) return ok_result();
    if (nvm_service_execution_pending(mod))
        return fail("I refuse service contracts before mixed execution selection");
    if(nvm_record_array_candidate(mod))return verify_record_arrays(mod,
# 1214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                      (4294967295U)
# 1214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                ,
# 1214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                 ((void *)0)
# 1214 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                     ,declared_depths);
    if (nvm_owned_array_route(mod) != NVM_OWNER_ARRAY_NOT_SELECTED ||
        nvm_mixed_samples_candidate(mod)) {

        for (uint32_t i = 0; i < count; ++i) {
            if (!declared_depths[i]) continue;
            uint16_t depth = 0;
            NvmVerifyResult r = verify_function_impl(mod, i, 
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                            ((void *)0)
# 1221 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                , 0, &depth);
            if (!r.ok) return r;
            if (declared_depths[i] < depth)
                return fail("function %u declares max_stack %u but reaches %u",
                            i, (unsigned)declared_depths[i], (unsigned)depth);
        }
        return ok_result();
    }
    return verify_functions_with_structure(mod, 
# 1229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                               ((void *)0)
# 1229 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                   , 0, declared_depths);
}

NvmVerifyResult nvm_verify(const NvmModule *mod) {
    if(nvm_service_execution_pending(mod))
        return fail("I refuse service contracts before mixed execution selection");
    if(nvm_record_map_selected(nvm_record_map_route(mod)))return verify_record_maps(mod,
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                       (4294967295U)
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                 ,
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                  ((void *)0)
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                      ,
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                       ((void *)0)
# 1235 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                           );
    if(nvm_owned_array_route(mod)!=NVM_OWNER_ARRAY_NOT_SELECTED)return verify_owned_arrays(mod,0,
# 1236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                                ((void *)0)
# 1236 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                                    );
    if(nvm_mixed_samples_candidate(mod))return verify_mixed_samples(mod,0,
# 1237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                         ((void *)0)
# 1237 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                             );
    if(nvm_record_array_candidate(mod))return verify_record_arrays(mod,
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                      (4294967295U)
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                ,
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                 ((void *)0)
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                     ,
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                                      ((void *)0)
# 1238 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                          );
    return verify_functions_with_structure(mod, 
# 1239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                               ((void *)0)
# 1239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                   , 0, 
# 1239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                        ((void *)0)
# 1239 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                            );
}

NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count) {
    if (linked_count > 0 && !linked_modules)
        return fail("linked_count %u but linked_modules table is NULL", linked_count);

    for (uint32_t i=0; i<linked_count; i++)
        if (nvm_service_execution_pending(linked_modules[i]))
            return fail("I refuse linked service contracts before reviewed dispatch admission");
    if(nvm_service_execution_pending(mod))
        return fail("I refuse service contracts before mixed execution selection");
    for(uint32_t i=0;i<linked_count;i++)
        if(nvm_record_map_selected(nvm_record_map_route(linked_modules[i])))
            return fail("I refuse record-map authority in linked verification.");
    if(nvm_record_map_selected(nvm_record_map_route(mod))) {
        if(linked_count)return fail("I refuse linked record-map execution contracts.");
        return verify_record_maps(mod,
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                     (4294967295U)
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                               ,
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                ((void *)0)
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                    ,
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                     ((void *)0)
# 1258 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                         );
    }
    for(uint32_t i=0;i<linked_count;i++)
        if(nvm_owned_array_route(linked_modules[i])!=NVM_OWNER_ARRAY_NOT_SELECTED)
            return fail("I refuse an owner ARRAY candidate or invalid descriptor in a linked graph");
    if(nvm_owned_array_route(mod)!=NVM_OWNER_ARRAY_NOT_SELECTED) {
        if(linked_count)return fail("I refuse linked owner ARRAY execution contracts");
        return verify_owned_arrays(mod,0,
# 1265 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                        ((void *)0)
# 1265 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                            );
    }
    if(nvm_mixed_samples_candidate(mod)) {
        if(linked_count)return fail("I refuse linked mixed ownership execution contracts");
        return verify_mixed_samples(mod,0,
# 1269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                         ((void *)0)
# 1269 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                             );
    }
    for(uint32_t i=0;i<linked_count;i++)if(nvm_record_array_candidate(linked_modules[i]))
        return fail("I refuse a record-array module in a linked graph.");
    if(nvm_record_array_candidate(mod)) {
        if(linked_count)return fail("I refuse linked record-array execution contracts.");
        return verify_record_arrays(mod,
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                       (4294967295U)
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                 ,
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                  ((void *)0)
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                      ,
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                       ((void *)0)
# 1275 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                           );
    }
    if (linked_count) {
        for(uint32_t i=0;i<linked_count;i++)if(nvm_mixed_samples_candidate(linked_modules[i]))
            return fail("I refuse a mixed module in a linked graph");
        
# 1280 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
       _Bool 
# 1280 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
            needs = 
# 1280 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                    0
# 1280 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                         ;
        if (mod && ((nvm_ownership_contracts_validate(mod, &needs)==NVM_V2_OK && needs) || nvm_uses_owned_transfers(mod)))
            return fail("I refuse linked ownership execution contracts");
        for (uint32_t i=0; i<linked_count; i++) {
            needs=
# 1284 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                 0
# 1284 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                      ;
            if (linked_modules[i] && ((nvm_ownership_contracts_validate(linked_modules[i], &needs)==NVM_V2_OK && needs) || nvm_uses_owned_transfers(linked_modules[i])))
                return fail("I refuse linked ownership execution contracts");
        }
    }
    return verify_functions_with_structure(mod, linked_modules, linked_count, 
# 1289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                                                             ((void *)0)
# 1289 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                                                                 );
}


static int profile_scalar(uint8_t tag) { return tag == TAG_INT || tag == TAG_U8 || tag == TAG_BOOL || tag == TAG_VOID || tag == TAG_FLOAT || tag == TAG_ENUM; }
static int profile_supported(uint8_t op) {
    switch (op) {
    case OP_ENUM_VAL: case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL:
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV:
    case OP_F64_NEG: case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT:
    case OP_F64_LE: case OP_F64_GT: case OP_F64_GE: case OP_PUSH_F64:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_CAST_BOOL: case OP_AND: case OP_OR: case OP_NOT:
    case OP_F64_FROM_BITS: case OP_F64_TO_BITS:
    case OP_CAST_INT: case OP_CAST_FLOAT: case OP_CAST_U8:
    case OP_NOP: case OP_PUSH_U8: case OP_PUSH_I64: case OP_PUSH_BOOL: case OP_PUSH_VOID:
    case OP_DUP: case OP_POP: case OP_SWAP: case OP_ROT3:
    case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S: case OP_I64_REM_S:
    case OP_I64_NEG: case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
    case OP_I64_GT_S: case OP_I64_GE_S: case OP_BOOL_AND: case OP_BOOL_OR: case OP_BOOL_NOT:
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE: case OP_CALL: case OP_RET:
    case OP_ASSERT: case OP_TYPE_CHECK: return 1;
    default: return 0;
    }
}
NvmVerifyResult nvm_verify_profile(const NvmModule *m, NvmVerifyProfile profile) {
    if (profile != NVM_PROFILE_GENERAL && profile != NVM_PROFILE_CLOSED_SCALAR &&
        profile != NVM_PROFILE_CLOSED_LITERAL_STRINGS &&
        profile != NVM_PROFILE_CLOSED_MANAGED_STRINGS && profile != NVM_PROFILE_PORTABLE_READ_TEXT && profile != NVM_PROFILE_PORTABLE_FILE_READ)
        return fail("I do not recognize verifier profile %d", (int)profile);
    NvmVerifyResult verified = nvm_verify(m);
    if (!verified.ok || profile == NVM_PROFILE_GENERAL) return verified;
    if(nvm_owned_array_route(m)!=NVM_OWNER_ARRAY_NOT_SELECTED)return fail("I keep owner ARRAY candidates outside closed backend profiles");
    if(nvm_mixed_samples_candidate(m))return fail("I keep mixed ownership outside closed backend profiles");
    if(nvm_record_map_selected(nvm_record_map_route(m)))return fail("I keep record-map authority outside unqualified backend profiles.");
    if(nvm_record_array_candidate(m))return fail("I keep record-array authority outside unqualified backend profiles.");
    const 
# 1327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
         _Bool 
# 1327 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              portable_bytes = profile == NVM_PROFILE_PORTABLE_FILE_READ;
    const 
# 1328 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
         _Bool 
# 1328 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              portable_read = profile == NVM_PROFILE_PORTABLE_READ_TEXT || portable_bytes;
    if(portable_read) {
        if(!m->import_count || m->callback_contract_count)
            return fail("I require explicit portable read-text declarations without callbacks");
        for(uint32_t i=0;i<m->import_count;i++)
            if(!(portable_bytes?nvm_portable_file_read_import(m,i):nvm_portable_read_import_exact(m,i)))return fail("I require exact portable read-text import %u",i);
    }
    const 
# 1335 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
         _Bool 
# 1335 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              record_profile = profile == NVM_PROFILE_CLOSED_MANAGED_STRINGS &&
        (m->struct_count || m->layout_size || m->ownership_size);
    if ((!portable_read && m->import_count) || m->module_ref_count || m->union_count || m->passive_size ||
        (!record_profile && (m->struct_count || m->ownership_size || m->layout_size)))
        return fail("I support only closed scalar modules without imports, nominal layouts or ownership/passive contracts");
    if (!(m->header.flags & (1 << 0)))
        return fail("I require an explicit executable entry point");
    if (m->functions[m->header.entry_point].result_count != 1 ||
        (m->functions[m->header.entry_point].result_tag != TAG_INT &&
         m->functions[m->header.entry_point].result_tag != TAG_BOOL))
        return fail("I require an integer/bool executable entry result");
    if (m->functions[m->header.entry_point].arity)
        return fail("I require a zero-argument scalar entry point");
    const 
# 1348 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
         _Bool 
# 1348 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              managed_profile = profile == NVM_PROFILE_CLOSED_MANAGED_STRINGS || portable_read;
    const 
# 1349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
         _Bool 
# 1349 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
              literal_profile = profile == NVM_PROFILE_CLOSED_LITERAL_STRINGS || managed_profile;
    
# 1350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        has_strings = 
# 1350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                      0
# 1350 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                           ;
    
# 1351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1351 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        mutable_arrays = portable_bytes;
    
# 1352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        needs_string_runtime = 
# 1352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                               0
# 1352 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                    ;
    
# 1353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
   _Bool 
# 1353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
        initializer_seen = 
# 1353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                           0
# 1353 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                ;
    for (uint32_t i = 0; i < m->function_count; ++i) {
        const NvmFunctionEntry *f = &m->functions[i];
        const char *name = nvm_get_string(m, f->name_idx);
        if (!initializer_seen && name && !strcmp(name, "__init__")) {
            initializer_seen = 
# 1358 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                              1
# 1358 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                  ;
            if (f->arity)
                return fail("I require a zero-argument scalar module initializer");
        }
        if (f->upvalue_count || !((f->result_count == 0 && f->result_tag == TAG_VOID) ||
            (f->result_count == 1 && (f->result_tag == TAG_INT || f->result_tag == TAG_U8 || f->result_tag == TAG_ENUM || f->result_tag == TAG_BOOL || f->result_tag == TAG_FLOAT ||
             (literal_profile && f->result_tag == TAG_STRING) || (managed_profile && f->result_tag == TAG_ARRAY) || (record_profile && f->result_tag == TAG_STRUCT)))))
            return fail("I require zero void results or one admitted closed-profile result and no captures in function %u", i);
        has_strings |= f->result_count && f->result_tag == TAG_STRING;
        for (uint16_t p = 0; p < f->arity; ++p) {
            if (!m->function_param_types || !m->function_param_types[i]) {
                if(portable_read)return fail("I require explicit portable function parameter tags");
                continue;
            }
            uint8_t tag = m->function_param_types[i][p];
            has_strings |= tag == TAG_STRING;
            if (!profile_scalar(tag) && !(literal_profile && tag == TAG_STRING) && !(managed_profile && tag == TAG_ARRAY) && !(record_profile && tag == TAG_STRUCT))
                return fail("I require admitted closed-profile parameters in function %u", i);
        }
        for (uint32_t pc = 0; pc < f->code_length;) {
            DecodedInstruction ins = {0};
            uint32_t width = isa_decode(m->code + f->code_offset + pc, f->code_length - pc, &ins);
            mutable_arrays |= ins.opcode == OP_ARR_NEW || ins.opcode == OP_ARR_PUSH ||
                              ins.opcode == OP_ARR_SET || ins.opcode == OP_ARR_POP ||
                              ins.opcode == OP_ARR_LITERAL || ins.opcode == OP_ARR_SLICE;
            has_strings |= ins.opcode == OP_PUSH_STR || ins.opcode == OP_STR_CONCAT || ins.opcode == OP_STR_SUBSTR || ins.opcode == OP_CAST_STRING;
            needs_string_runtime |= !managed_profile && (ins.opcode == OP_ADD || ins.opcode == OP_CAST_INT || ins.opcode == OP_CAST_FLOAT);
            
# 1385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
           _Bool 
# 1385 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                literal_op = literal_profile && (ins.opcode == OP_PUSH_STR ||
                              ins.opcode == OP_STR_LEN || ins.opcode == OP_STR_EQ ||
                              (managed_profile && (ins.opcode == OP_ARR_LITERAL || ins.opcode == OP_ARR_SLICE || ins.opcode == OP_ARR_NEW || ins.opcode == OP_ARR_PUSH || ins.opcode == OP_ARR_SET || ins.opcode == OP_ARR_POP || ins.opcode == OP_STR_SPLIT || ins.opcode == OP_ARR_GET || ins.opcode == OP_ARR_LEN || ins.opcode == OP_STR_REPLACE || ins.opcode == OP_STR_FROM_INT || ins.opcode == OP_STR_FROM_FLOAT || ins.opcode == OP_STR_TO_LOWER || ins.opcode == OP_STR_TO_UPPER || ins.opcode == OP_STR_CHAR_AT || ins.opcode == OP_STR_TRIM || ins.opcode == OP_STR_CONCAT || ins.opcode == OP_STR_SUBSTR || ins.opcode == OP_CAST_STRING ||
                               ins.opcode == OP_STR_CONTAINS || ins.opcode == OP_STR_STARTS_WITH || ins.opcode == OP_STR_ENDS_WITH)));
            
# 1389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
           _Bool 
# 1389 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                record_op = record_profile && (ins.opcode == OP_STRUCT_NEW ||
                ins.opcode == OP_STRUCT_LITERAL || ins.opcode == OP_STRUCT_GET ||
                ins.opcode == OP_STRUCT_SET || ins.opcode == OP_AGG_PACK ||
                ins.opcode == OP_AGG_GET || ins.opcode == OP_AGG_SET);
            if (!width || (!profile_supported(ins.opcode) && !literal_op && !record_op && !(portable_read && ins.opcode==OP_CALL_EXTERN))) return fail("I do not support opcode 0x%02x at function %u offset %u in my scalar LLVM profile", ins.opcode, i, pc);
            pc += width;
        }
    }
    if (mutable_arrays || record_profile) {
        NvmManagedHeapPlan *plan = 
# 1398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c" 3 4
                                  ((void *)0)
# 1398 "/home/jkh/.worktrees/nanolang/service-module-integration/modules/file_product/../../src/nanoisa/verifier.c"
                                      ;
        NvmArrayEligibilityResult arrays = portable_bytes ? nvm_select_portable_read_heap(m, &plan) :
            nvm_select_managed_heap(m, mutable_arrays, &plan);
        nvm_managed_heap_plan_free(plan);
        if (arrays.status != NVM_ARRAY_ELIGIBLE)
            return fail("I cannot establish mutable array eligibility (status %u) at function %u offset %u: %s",
                        (unsigned)arrays.status, arrays.function, arrays.pc, arrays.message);
    }
    if (has_strings && needs_string_runtime)
        return fail("I refuse ADD/CAST_INT/CAST_FLOAT in the literal-string profile");
    return ok_result();
}
