	.arch armv8-a
	.file	"file_source_catalog.c"
	.text
	.align	2
	.global	nl_service_source_catalog_id
	.type	nl_service_source_catalog_id, %function
nl_service_source_catalog_id:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L2
	mov	x0, 0
	b	.L3
.L2:
	bl	nl_source_catalog_private_file_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, 24]
	bl	strcmp
	cmp	w0, 0
	bne	.L4
	mov	x0, 1
	b	.L3
.L4:
	bl	nl_source_catalog_private_socket_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, 24]
	bl	strcmp
	cmp	w0, 0
	bne	.L5
	mov	x0, 2
	b	.L3
.L5:
	bl	nl_source_catalog_private_websocket_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, 24]
	bl	strcmp
	cmp	w0, 0
	bne	.L6
	mov	x0, 3
	b	.L3
.L6:
	mov	x0, 0
.L3:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	nl_service_source_catalog_id, .-nl_service_source_catalog_id
	.align	2
	.global	nl_service_source_catalog_count
	.type	nl_service_source_catalog_count, %function
nl_service_source_catalog_count:
.LFB1:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	str	x1, [sp]
	ldr	x0, [sp, 8]
	cmp	x0, 1
	bne	.L8
	ldr	x0, [sp]
	cmp	x0, 1
	beq	.L9
	ldr	x0, [sp]
	cmp	x0, 2
	bne	.L10
	mov	x0, 5
	b	.L13
.L10:
	mov	x0, -1
	b	.L13
.L9:
	mov	x0, 8
	b	.L13
.L8:
	ldr	x0, [sp, 8]
	cmp	x0, 2
	bne	.L14
	ldr	x0, [sp]
	cmp	x0, 1
	beq	.L15
	ldr	x0, [sp]
	cmp	x0, 2
	bne	.L16
	mov	x0, 5
	b	.L13
.L16:
	mov	x0, -1
	b	.L13
.L15:
	mov	x0, 9
	b	.L13
.L14:
	ldr	x0, [sp, 8]
	cmp	x0, 3
	bne	.L19
	ldr	x0, [sp]
	cmp	x0, 1
	beq	.L20
	ldr	x0, [sp]
	cmp	x0, 2
	bne	.L21
	mov	x0, 4
	b	.L13
.L21:
	mov	x0, -1
	b	.L13
.L20:
	mov	x0, 7
	b	.L13
.L19:
	mov	x0, -1
.L13:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE1:
	.size	nl_service_source_catalog_count, .-nl_service_source_catalog_count
	.section	.rodata
	.align	3
.LC1:
	.string	""
	.text
	.align	2
	.type	source_interface, %function
source_interface:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	ldr	x0, [sp, 24]
	cmp	x0, 1
	bne	.L25
	bl	nl_source_catalog_private_file_catalog_interface
	b	.L31
.L25:
	ldr	x0, [sp, 24]
	cmp	x0, 2
	bne	.L27
	bl	nl_source_catalog_private_socket_catalog_interface
	b	.L31
.L27:
	ldr	x0, [sp, 24]
	cmp	x0, 3
	bne	.L29
	bl	nl_source_catalog_private_websocket_catalog_interface
	b	.L31
.L29:
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
.L31:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	source_interface, .-source_interface
	.align	2
	.type	source_type, %function
source_type:
.LFB3:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 1
	bne	.L33
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_file_catalog_type
	b	.L37
.L33:
	ldr	x0, [sp, 24]
	cmp	x0, 2
	bne	.L35
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_socket_catalog_type
	b	.L37
.L35:
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_websocket_catalog_type
.L37:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE3:
	.size	source_type, .-source_type
	.align	2
	.type	source_method, %function
source_method:
.LFB4:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 1
	bne	.L39
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_file_catalog_method
	b	.L43
.L39:
	ldr	x0, [sp, 24]
	cmp	x0, 2
	bne	.L41
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_socket_catalog_method
	b	.L43
.L41:
	ldr	x0, [sp, 16]
	bl	nl_source_catalog_private_websocket_catalog_method
.L43:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE4:
	.size	source_method, .-source_method
	.align	2
	.global	nl_service_source_catalog_string
	.type	nl_service_source_catalog_string, %function
nl_service_source_catalog_string:
.LFB5:
	.cfi_startproc
	stp	x29, x30, [sp, -112]!
	.cfi_def_cfa_offset 112
	.cfi_offset 29, -112
	.cfi_offset 30, -104
	mov	x29, sp
	str	x0, [sp, 56]
	str	x1, [sp, 48]
	str	x2, [sp, 40]
	str	x3, [sp, 32]
	str	x4, [sp, 24]
	str	xzr, [sp, 72]
	ldr	x0, [sp, 48]
	cmp	x0, 0
	bne	.L45
	ldr	x0, [sp, 40]
	cmp	x0, 0
	bne	.L45
	ldr	x0, [sp, 32]
	cmp	x0, 0
	bne	.L45
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L45
	ldr	x0, [sp, 56]
	bl	source_interface
	str	x0, [sp, 72]
.L45:
	ldr	x0, [sp, 48]
	cmp	x0, 1
	bne	.L46
	ldr	x0, [sp, 40]
	cmp	x0, 0
	blt	.L46
	mov	x1, 1
	ldr	x0, [sp, 56]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 40]
	cmp	x0, x1
	bge	.L46
	ldr	x0, [sp, 24]
	cmp	x0, 0
	blt	.L46
	ldr	x0, [sp, 40]
	mov	x1, x0
	ldr	x0, [sp, 56]
	bl	source_type
	str	x0, [sp, 80]
	ldr	x0, [sp, 32]
	cmp	x0, 0
	bne	.L47
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L47
	ldr	x0, [sp, 80]
	ldr	x0, [x0]
	str	x0, [sp, 72]
	b	.L46
.L47:
	ldr	x0, [sp, 32]
	cmp	x0, 1
	bne	.L48
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L48
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 8]
	str	x0, [sp, 72]
	b	.L46
.L48:
	ldr	x0, [sp, 80]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 24]
	cmp	x1, x0
	bls	.L46
	ldr	x0, [sp, 80]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 24]
	lsl	x0, x0, 5
	add	x0, x1, x0
	str	x0, [sp, 88]
	ldr	x0, [sp, 32]
	cmp	x0, 2
	bne	.L49
	ldr	x0, [sp, 88]
	ldr	x0, [x0]
	str	x0, [sp, 72]
	b	.L46
.L49:
	ldr	x0, [sp, 32]
	cmp	x0, 3
	bne	.L50
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 8]
	str	x0, [sp, 72]
	b	.L46
.L50:
	ldr	x0, [sp, 32]
	cmp	x0, 4
	bne	.L46
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 16]
	str	x0, [sp, 72]
.L46:
	ldr	x0, [sp, 48]
	cmp	x0, 2
	bne	.L51
	ldr	x0, [sp, 40]
	cmp	x0, 0
	blt	.L51
	mov	x1, 2
	ldr	x0, [sp, 56]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 40]
	cmp	x0, x1
	bge	.L51
	ldr	x0, [sp, 24]
	cmp	x0, 0
	blt	.L51
	ldr	x0, [sp, 40]
	mov	x1, x0
	ldr	x0, [sp, 56]
	bl	source_method
	str	x0, [sp, 96]
	ldr	x0, [sp, 32]
	cmp	x0, 0
	bne	.L52
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L52
	ldr	x0, [sp, 96]
	ldr	x0, [x0]
	str	x0, [sp, 72]
	b	.L51
.L52:
	ldr	x0, [sp, 32]
	cmp	x0, 1
	bne	.L53
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L53
	ldr	x0, [sp, 96]
	ldr	x0, [x0, 8]
	str	x0, [sp, 72]
	b	.L51
.L53:
	ldr	x0, [sp, 32]
	cmp	x0, 2
	bne	.L54
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L54
	ldr	x0, [sp, 96]
	ldr	x0, [x0, 16]
	str	x0, [sp, 72]
	b	.L51
.L54:
	ldr	x0, [sp, 32]
	cmp	x0, 3
	bne	.L55
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L55
	ldr	x0, [sp, 96]
	ldr	x0, [x0, 24]
	str	x0, [sp, 72]
	b	.L51
.L55:
	ldr	x0, [sp, 32]
	cmp	x0, 7
	bne	.L56
	ldr	x0, [sp, 24]
	cmp	x0, 1
	bgt	.L56
	ldr	x1, [sp, 96]
	ldr	x0, [sp, 24]
	add	x0, x0, 4
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x0, [x0, 8]
	str	x0, [sp, 72]
	b	.L51
.L56:
	ldr	x0, [sp, 96]
	ldr	x1, [x0, 56]
	ldr	x0, [sp, 24]
	cmp	x1, x0
	bls	.L51
	ldr	x0, [sp, 96]
	ldr	x2, [x0, 48]
	ldr	x1, [sp, 24]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 104]
	ldr	x0, [sp, 32]
	cmp	x0, 4
	bne	.L57
	ldr	x0, [sp, 104]
	ldr	x0, [x0]
	str	x0, [sp, 72]
	b	.L51
.L57:
	ldr	x0, [sp, 32]
	cmp	x0, 5
	bne	.L58
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 8]
	str	x0, [sp, 72]
	b	.L51
.L58:
	ldr	x0, [sp, 32]
	cmp	x0, 6
	bne	.L51
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 16]
	str	x0, [sp, 72]
.L51:
	ldr	x0, [sp, 72]
	cmp	x0, 0
	beq	.L59
	ldr	x0, [sp, 72]
	b	.L61
.L59:
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
.L61:
	ldp	x29, x30, [sp], 112
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE5:
	.size	nl_service_source_catalog_string, .-nl_service_source_catalog_string
	.align	2
	.global	nl_service_source_catalog_number
	.type	nl_service_source_catalog_number, %function
nl_service_source_catalog_number:
.LFB6:
	.cfi_startproc
	stp	x29, x30, [sp, -96]!
	.cfi_def_cfa_offset 96
	.cfi_offset 29, -96
	.cfi_offset 30, -88
	mov	x29, sp
	str	x0, [sp, 56]
	str	x1, [sp, 48]
	str	x2, [sp, 40]
	str	x3, [sp, 32]
	str	x4, [sp, 24]
	ldr	x0, [sp, 48]
	cmp	x0, 1
	bne	.L63
	ldr	x0, [sp, 40]
	cmp	x0, 0
	blt	.L63
	mov	x1, 1
	ldr	x0, [sp, 56]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 40]
	cmp	x0, x1
	bge	.L63
	ldr	x0, [sp, 24]
	cmp	x0, 0
	blt	.L63
	ldr	x0, [sp, 40]
	mov	x1, x0
	ldr	x0, [sp, 56]
	bl	source_type
	str	x0, [sp, 72]
	ldr	x0, [sp, 32]
	cmp	x0, 0
	bne	.L64
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L64
	ldr	x0, [sp, 72]
	ldr	w0, [x0, 16]
	uxtw	x0, w0
	b	.L65
.L64:
	ldr	x0, [sp, 32]
	cmp	x0, 1
	bne	.L66
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L66
	ldr	x0, [sp, 72]
	ldr	x0, [x0, 32]
	b	.L65
.L66:
	ldr	x0, [sp, 32]
	cmp	x0, 2
	bne	.L63
	ldr	x0, [sp, 72]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 24]
	cmp	x1, x0
	bls	.L63
	ldr	x0, [sp, 72]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 24]
	lsl	x0, x0, 5
	add	x0, x1, x0
	ldr	w0, [x0, 24]
	uxtw	x0, w0
	b	.L65
.L63:
	ldr	x0, [sp, 48]
	cmp	x0, 2
	bne	.L67
	ldr	x0, [sp, 40]
	cmp	x0, 0
	blt	.L67
	mov	x1, 2
	ldr	x0, [sp, 56]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 40]
	cmp	x0, x1
	bge	.L67
	ldr	x0, [sp, 24]
	cmp	x0, 0
	blt	.L67
	ldr	x0, [sp, 40]
	mov	x1, x0
	ldr	x0, [sp, 56]
	bl	source_method
	str	x0, [sp, 80]
	ldr	x0, [sp, 32]
	cmp	x0, 0
	bne	.L68
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L68
	ldr	x0, [sp, 80]
	ldr	w0, [x0, 32]
	uxtw	x0, w0
	b	.L65
.L68:
	ldr	x0, [sp, 32]
	cmp	x0, 1
	bne	.L69
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L69
	ldr	x0, [sp, 80]
	ldr	w0, [x0, 36]
	uxtw	x0, w0
	b	.L65
.L69:
	ldr	x0, [sp, 32]
	cmp	x0, 2
	bne	.L70
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L70
	ldr	x0, [sp, 80]
	ldr	w0, [x0, 40]
	uxtw	x0, w0
	b	.L65
.L70:
	ldr	x0, [sp, 32]
	cmp	x0, 3
	bne	.L71
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L71
	ldr	x0, [sp, 80]
	ldr	w0, [x0, 44]
	uxtw	x0, w0
	b	.L65
.L71:
	ldr	x0, [sp, 32]
	cmp	x0, 4
	bne	.L72
	ldr	x0, [sp, 24]
	cmp	x0, 0
	bne	.L72
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 56]
	b	.L65
.L72:
	ldr	x0, [sp, 32]
	cmp	x0, 10
	bne	.L73
	ldr	x0, [sp, 24]
	cmp	x0, 1
	bgt	.L73
	ldr	x1, [sp, 80]
	ldr	x0, [sp, 24]
	add	x0, x0, 4
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	w0, [x0]
	uxtw	x0, w0
	b	.L65
.L73:
	ldr	x0, [sp, 80]
	ldr	x1, [x0, 56]
	ldr	x0, [sp, 24]
	cmp	x1, x0
	bls	.L67
	ldr	x0, [sp, 80]
	ldr	x2, [x0, 48]
	ldr	x1, [sp, 24]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 88]
	ldr	x0, [sp, 32]
	cmp	x0, 5
	bne	.L74
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 24]
	uxtw	x0, w0
	b	.L65
.L74:
	ldr	x0, [sp, 32]
	cmp	x0, 6
	bne	.L75
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 28]
	uxtw	x0, w0
	b	.L65
.L75:
	ldr	x0, [sp, 32]
	cmp	x0, 7
	bne	.L76
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 32]
	uxtw	x0, w0
	b	.L65
.L76:
	ldr	x0, [sp, 32]
	cmp	x0, 8
	bne	.L77
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 36]
	uxtw	x0, w0
	b	.L65
.L77:
	ldr	x0, [sp, 32]
	cmp	x0, 9
	bne	.L67
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 40]
	uxtw	x0, w0
	b	.L65
.L67:
	mov	x0, -1
.L65:
	ldp	x29, x30, [sp], 96
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE6:
	.size	nl_service_source_catalog_number, .-nl_service_source_catalog_number
	.align	2
	.type	catalog_text, %function
catalog_text:
.LFB7:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 16]
	bl	strlen
	str	x0, [sp, 40]
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	ldrb	w0, [x0, 8]
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L79
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	ldr	x0, [x0]
	mov	x1, 32768
	sub	x0, x1, x0
	ldr	x1, [sp, 40]
	cmp	x1, x0
	bcc	.L80
.L79:
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	strb	wzr, [x0, 8]
	b	.L78
.L80:
	ldr	x1, [sp, 24]
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	ldr	x0, [x0]
	add	x0, x1, x0
	ldr	x2, [sp, 40]
	ldr	x1, [sp, 16]
	bl	memcpy
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	ldr	x1, [x0]
	ldr	x0, [sp, 40]
	add	x1, x1, x0
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	str	x1, [x0]
	ldr	x0, [sp, 24]
	add	x0, x0, 32768
	ldr	x0, [x0]
	ldr	x1, [sp, 24]
	strb	wzr, [x1, x0]
.L78:
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE7:
	.size	catalog_text, .-catalog_text
	.section	.rodata
	.align	3
.LC2:
	.string	"#%ld;"
	.text
	.align	2
	.type	catalog_number, %function
catalog_number:
.LFB8:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, 64]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 64
	str	x0, [sp, 8]
	str	x1, [sp]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 56]
	mov	x1, 0
	add	x4, sp, 24
	ldr	x3, [sp]
	adrp	x0, .LC2
	add	x2, x0, :lo12:.LC2
	mov	x1, 32
	mov	x0, x4
	bl	snprintf
	str	w0, [sp, 20]
	ldr	w0, [sp, 20]
	cmp	w0, 0
	blt	.L83
	ldr	w0, [sp, 20]
	cmp	w0, 31
	bls	.L84
.L83:
	ldr	x0, [sp, 8]
	add	x0, x0, 32768
	strb	wzr, [x0, 8]
	b	.L82
.L84:
	add	x0, sp, 24
	mov	x1, x0
	ldr	x0, [sp, 8]
	bl	catalog_text
.L82:
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 56]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	beq	.L87
	bl	__stack_chk_fail
.L87:
	ldp	x29, x30, [sp, 64]
	add	sp, sp, 80
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE8:
	.size	catalog_number, .-catalog_number
	.section	.rodata
	.align	3
.LC3:
	.string	"%zu:"
	.align	3
.LC4:
	.string	";"
	.text
	.align	2
	.type	catalog_string, %function
catalog_string:
.LFB9:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, 64]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 64
	str	x0, [sp, 8]
	str	x1, [sp]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 56]
	mov	x1, 0
	ldr	x0, [sp]
	bl	strlen
	add	x4, sp, 24
	mov	x3, x0
	adrp	x0, .LC3
	add	x2, x0, :lo12:.LC3
	mov	x1, 32
	mov	x0, x4
	bl	snprintf
	str	w0, [sp, 20]
	ldr	w0, [sp, 20]
	cmp	w0, 0
	blt	.L89
	ldr	w0, [sp, 20]
	cmp	w0, 31
	bls	.L90
.L89:
	ldr	x0, [sp, 8]
	add	x0, x0, 32768
	strb	wzr, [x0, 8]
	b	.L88
.L90:
	add	x0, sp, 24
	mov	x1, x0
	ldr	x0, [sp, 8]
	bl	catalog_text
	ldr	x1, [sp]
	ldr	x0, [sp, 8]
	bl	catalog_text
	adrp	x0, .LC4
	add	x1, x0, :lo12:.LC4
	ldr	x0, [sp, 8]
	bl	catalog_text
.L88:
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 56]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	beq	.L93
	bl	__stack_chk_fail
.L93:
	ldp	x29, x30, [sp, 64]
	add	sp, sp, 80
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE9:
	.size	catalog_string, .-catalog_string
	.section	.rodata
	.align	3
.LC5:
	.string	"socket-source-catalog1;"
	.align	3
.LC6:
	.string	"websocket-source-catalog1;"
	.align	3
.LC7:
	.string	"file-source-catalog1;"
	.text
	.align	2
	.global	nl_service_source_catalog_view
	.type	nl_service_source_catalog_view, %function
nl_service_source_catalog_view:
.LFB10:
	.cfi_startproc
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x29, sp
	mov	x13, 32944
	sub	sp, sp, x13
	.cfi_def_cfa_offset 32960
	str	xzr, [sp, 1024]
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	str	x2, [sp, 8]
	str	x3, [sp]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	add	x1, sp, 32768
	ldr	x2, [x0]
	str	x2, [x1, 168]
	mov	x2, 0
	ldr	x0, [sp]
	cmp	x0, 0
	beq	.L95
	ldr	x0, [sp, 16]
	cmp	x0, 0
	bne	.L96
	ldr	x0, [sp, 8]
	cmp	x0, 0
	bne	.L95
.L96:
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_count
	cmp	x0, 0
	bge	.L97
.L95:
	mov	w0, 0
	b	.L130
.L97:
	adrp	x0, .LC0
	add	x1, x0, :lo12:.LC0
	add	x0, sp, 152
	mov	x3, x1
	mov	x1, 32784
	mov	x2, x1
	mov	x1, x3
	bl	memcpy
	ldr	x0, [sp, 24]
	cmp	x0, 1
	beq	.L99
	ldr	x0, [sp, 24]
	cmp	x0, 2
	bne	.L100
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	b	.L102
.L100:
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	b	.L102
.L99:
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
.L102:
	add	x2, sp, 152
	mov	x1, x0
	mov	x0, x2
	bl	catalog_text
	ldr	x0, [sp, 24]
	bl	source_interface
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	str	xzr, [sp, 40]
	b	.L103
.L112:
	str	xzr, [sp, 48]
	b	.L104
.L105:
	mov	x4, 0
	ldr	x3, [sp, 48]
	ldr	x2, [sp, 40]
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	ldr	x0, [sp, 48]
	add	x0, x0, 1
	str	x0, [sp, 48]
.L104:
	ldr	x0, [sp, 48]
	cmp	x0, 1
	ble	.L105
	str	xzr, [sp, 56]
	b	.L106
.L107:
	mov	x4, 0
	ldr	x3, [sp, 56]
	ldr	x2, [sp, 40]
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	ldr	x0, [sp, 56]
	add	x0, x0, 1
	str	x0, [sp, 56]
.L106:
	ldr	x0, [sp, 56]
	cmp	x0, 1
	ble	.L107
	mov	x4, 0
	mov	x3, 1
	ldr	x2, [sp, 40]
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	str	x0, [sp, 144]
	str	xzr, [sp, 64]
	b	.L108
.L111:
	mov	x0, 2
	str	x0, [sp, 72]
	b	.L109
.L110:
	ldr	x4, [sp, 64]
	ldr	x3, [sp, 72]
	ldr	x2, [sp, 40]
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	ldr	x0, [sp, 72]
	add	x0, x0, 1
	str	x0, [sp, 72]
.L109:
	ldr	x0, [sp, 72]
	cmp	x0, 4
	ble	.L110
	ldr	x4, [sp, 64]
	mov	x3, 2
	ldr	x2, [sp, 40]
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	ldr	x0, [sp, 64]
	add	x0, x0, 1
	str	x0, [sp, 64]
.L108:
	ldr	x1, [sp, 64]
	ldr	x0, [sp, 144]
	cmp	x1, x0
	blt	.L111
	ldr	x0, [sp, 40]
	add	x0, x0, 1
	str	x0, [sp, 40]
.L103:
	mov	x1, 1
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 40]
	cmp	x0, x1
	blt	.L112
	str	xzr, [sp, 80]
	b	.L113
.L126:
	str	xzr, [sp, 88]
	b	.L114
.L115:
	mov	x4, 0
	ldr	x3, [sp, 88]
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	ldr	x0, [sp, 88]
	add	x0, x0, 1
	str	x0, [sp, 88]
.L114:
	ldr	x0, [sp, 88]
	cmp	x0, 3
	ble	.L115
	str	xzr, [sp, 96]
	b	.L116
.L117:
	mov	x4, 0
	ldr	x3, [sp, 96]
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	ldr	x0, [sp, 96]
	add	x0, x0, 1
	str	x0, [sp, 96]
.L116:
	ldr	x0, [sp, 96]
	cmp	x0, 4
	ble	.L117
	mov	x4, 0
	mov	x3, 4
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	str	x0, [sp, 136]
	str	xzr, [sp, 104]
	b	.L118
.L123:
	mov	x0, 4
	str	x0, [sp, 112]
	b	.L119
.L120:
	ldr	x4, [sp, 104]
	ldr	x3, [sp, 112]
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	ldr	x0, [sp, 112]
	add	x0, x0, 1
	str	x0, [sp, 112]
.L119:
	ldr	x0, [sp, 112]
	cmp	x0, 6
	ble	.L120
	mov	x0, 5
	str	x0, [sp, 120]
	b	.L121
.L122:
	ldr	x4, [sp, 104]
	ldr	x3, [sp, 120]
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	ldr	x0, [sp, 120]
	add	x0, x0, 1
	str	x0, [sp, 120]
.L121:
	ldr	x0, [sp, 120]
	cmp	x0, 9
	ble	.L122
	ldr	x0, [sp, 104]
	add	x0, x0, 1
	str	x0, [sp, 104]
.L118:
	ldr	x1, [sp, 104]
	ldr	x0, [sp, 136]
	cmp	x1, x0
	blt	.L123
	str	xzr, [sp, 128]
	b	.L124
.L125:
	ldr	x4, [sp, 128]
	mov	x3, 10
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_number
	ldr	x4, [sp, 128]
	mov	x3, 7
	ldr	x2, [sp, 80]
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, 152
	bl	catalog_string
	ldr	x0, [sp, 128]
	add	x0, x0, 1
	str	x0, [sp, 128]
.L124:
	ldr	x0, [sp, 128]
	cmp	x0, 1
	ble	.L125
	ldr	x0, [sp, 80]
	add	x0, x0, 1
	str	x0, [sp, 80]
.L113:
	mov	x1, 2
	ldr	x0, [sp, 24]
	bl	nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, 80]
	cmp	x0, x1
	blt	.L126
	add	x0, sp, 32768
	ldrb	w0, [x0, 160]
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L127
	ldr	x0, [sp, 16]
	cmp	x0, 0
	beq	.L128
	add	x0, sp, 32768
	ldr	x0, [x0, 152]
	ldr	x1, [sp, 8]
	cmp	x1, x0
	bhi	.L128
.L127:
	mov	w0, 0
	b	.L130
.L128:
	ldr	x0, [sp, 16]
	cmp	x0, 0
	beq	.L129
	add	x0, sp, 32768
	ldr	x0, [x0, 152]
	add	x1, x0, 1
	add	x0, sp, 152
	mov	x2, x1
	mov	x1, x0
	ldr	x0, [sp, 16]
	bl	memcpy
.L129:
	add	x0, sp, 32768
	ldr	x0, [x0, 152]
	add	x1, x0, 1
	ldr	x0, [sp]
	str	x1, [x0]
	mov	w0, 1
.L130:
	mov	w1, w0
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	add	x3, sp, 32768
	ldr	x4, [x3, 168]
	ldr	x2, [x0]
	subs	x4, x4, x2
	mov	x2, 0
	beq	.L131
	bl	__stack_chk_fail
.L131:
	mov	w0, w1
	mov	x13, 32944
	add	sp, sp, x13
	.cfi_def_cfa_offset 16
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE10:
	.size	nl_service_source_catalog_view, .-nl_service_source_catalog_view
	.section	.rodata
	.align	3
.LC0:
	.string	""
	.string	""
	.zero	32766
	.xword	0
	.byte	1
	.zero	7
	.text
	.align	2
	.global	nl_file_source_catalog_string
	.type	nl_file_source_catalog_string, %function
nl_file_source_catalog_string:
.LFB11:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 40]
	str	x1, [sp, 32]
	str	x2, [sp, 24]
	str	x3, [sp, 16]
	ldr	x4, [sp, 16]
	ldr	x3, [sp, 24]
	ldr	x2, [sp, 32]
	ldr	x1, [sp, 40]
	mov	x0, 1
	bl	nl_service_source_catalog_string
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE11:
	.size	nl_file_source_catalog_string, .-nl_file_source_catalog_string
	.align	2
	.global	nl_file_source_catalog_number
	.type	nl_file_source_catalog_number, %function
nl_file_source_catalog_number:
.LFB12:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 40]
	str	x1, [sp, 32]
	str	x2, [sp, 24]
	str	x3, [sp, 16]
	ldr	x4, [sp, 16]
	ldr	x3, [sp, 24]
	ldr	x2, [sp, 32]
	ldr	x1, [sp, 40]
	mov	x0, 1
	bl	nl_service_source_catalog_number
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE12:
	.size	nl_file_source_catalog_number, .-nl_file_source_catalog_number
	.align	2
	.global	nl_file_source_catalog_view
	.type	nl_file_source_catalog_view, %function
nl_file_source_catalog_view:
.LFB13:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 40]
	str	x1, [sp, 32]
	str	x2, [sp, 24]
	ldr	x3, [sp, 24]
	ldr	x2, [sp, 32]
	ldr	x1, [sp, 40]
	mov	x0, 1
	bl	nl_service_source_catalog_view
	and	w0, w0, 255
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE13:
	.size	nl_file_source_catalog_view, .-nl_file_source_catalog_view
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
