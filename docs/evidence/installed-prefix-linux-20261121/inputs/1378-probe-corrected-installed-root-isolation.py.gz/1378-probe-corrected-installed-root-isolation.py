from pathlib import Path
import json,os,subprocess,time,sys,hashlib
root=Path.cwd();previous=json.loads((root/'.test_output/corrected-prefix-install/manifest.json').read_text());assert previous.get('original_bootstrap_guards_unchanged');assert previous['steps'][-1]['label']=='external-native-execute' and all(s.get('returncode')==0 for s in previous['steps']);external=Path(previous['external']);prefix=Path(previous['prefix']);client=external/'client';out=root/'.test_output/corrected-installed-root-isolation';out.mkdir(exist_ok=False)
hidden=[Path('/home/jkh/.worktrees/nanolang'),Path('/home/jkh/Src/nanolang'),Path('/home/jkh/Src/nanolang-callable-ownership')];hidden=[p for p in hidden if p.is_dir()];assert all(not prefix.is_relative_to(p) for p in hidden);base=['/bin/bwrap','--bind','/','/','--proc','/proc','--dev','/dev','--bind',str(external),str(external)]
for p in hidden:base+=['--tmpfs',str(p)]
base+=['--chdir',str(client),'--'];env=dict(os.environ,PATH=str(prefix/'bin')+':/usr/bin:/bin',CC='/usr/bin/cc',NANO_CC='/bin/false',NANO_BUILD_CACHE=str(external/'isolation-cache'),TMPDIR=str(client),NANO_SHADOW_TIMEOUT_SECONDS='10')
for key in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER','NANO_VM']:env.pop(key,None)
record=dict(prefix=str(prefix),external=str(external),hidden_roots=list(map(str,hidden)),compiler_sha256=hashlib.sha256((prefix/'bin/nanoc').read_bytes()).hexdigest(),steps=[],limits=['I require the independent corrected development CLI/install/external probes to pass with unchanged original bootstrap guards. I retain the failed GCC13 public gate separately; this does not grant full profile or release acceptance. This fresh-process namespace keeps normal filesystem permissions and hides known NanoLang source/build trees only; prefix, client, system libraries and separate cache remain available. A namespace setup refusal is not a product defect.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,child_env=env):
 start=time.monotonic();command=base+list(map(str,argv))
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(command,cwd=client,env=child_env,stdout=a,stderr=b,timeout=180)
 record['steps'].append(dict(label=label,argv=command,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));save();return r.returncode
if run(['/usr/bin/true'],'namespace-setup'):raise RuntimeError('I could not establish the namespace control; I make no product claim.')
if run([prefix/'bin/nanoc',client/'input.nano','--emit-nvm','-o',client/'isolated.nvm'],'installed-module'):raise RuntimeError('I retain the installed compiler refusal with source/build roots unavailable.')
assert run([prefix/'bin/nano_vm','--verify-only',client/'isolated.nvm'],'verify-module')==0
assert run([prefix/'bin/nano_vm',client/'isolated.nvm'],'execute-module')==0
native=dict(env,NANO_CC='/usr/bin/cc')
assert run([prefix/'bin/nanoc',client/'input.nano','--target','native','-o',client/'isolated.native'],'installed-native',native)==0
assert run([client/'isolated.native'],'execute-native')==0
for name in ['execute-module','execute-native']:assert (out/(name+'.stdout')).read_text()=='fresh-prefix-ok\n'
record['products']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in client.glob('isolated*') if p.is_file()};save();print('I passed actual fresh-prefix module/native execution with known source/build roots unavailable.')
