from pathlib import Path
import os,subprocess,json,time,signal,hashlib
root=Path.cwd();out=root/'.test_output/installed-tool-discovery';tools=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/bin');env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(tools/'nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='30');record={'limits':['I build a development compiler from the changed source with the genuine C seed, original30-second complete compiler shadow deadline and1800-second build commands. I do not replace qualified Stage1/Stage2 artifacts or claim a new raw fixed point.'],'steps':[],'source_sha256':hashlib.sha256((root/'src_nano/nanoc_v06.nano').read_bytes()).hexdigest(),'tools':{str(tools/name):hashlib.sha256((tools/name).read_bytes()).hexdigest() for name in ['nano_virt','nano_vm','nvm2c','nano_aot_runtime.o','nano_as_capture.so']}}
def save():(out/'build-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args):
 t=time.monotonic();r={'label':label,'argv':list(map(str,args))};record['steps'].append(r);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(r['argv'],cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);r['pid']=p.pid;save()
  try:r['returncode']=p.wait(timeout=1800)
  except subprocess.TimeoutExpired:r['timeout']=True;os.killpg(p.pid,signal.SIGKILL);r['returncode']=p.wait()
 r['elapsed_seconds']=time.monotonic()-t;save();assert r['returncode']==0,label
run('source-seed',[tools/'nano_virt','src_nano/nanoc_v06.nano','--emit-nvm','--strip-debug','-o',out/'compiler.nvm'])
run('verify',[tools/'nano_vm','--verify-only',out/'compiler.nvm'])
run('translate',[tools/'nvm2c',out/'compiler.nvm','-o',out/'compiler.c'])
run('native',['/usr/bin/cc','-std=c11','-O1',out/'compiler.c',tools/'nano_aot_runtime.o','-lm','-rdynamic','-ldl','-o',out/'nanoc'])
record['products']={str(out/name):hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['compiler.nvm','compiler.c','nanoc']};save()
testenv=dict(env,NANOLANG_SELFHOST_COMPILER=str(out/'nanoc'));t=time.monotonic()
with (out/'corrected-tests.stdout').open('wb') as a,(out/'corrected-tests.stderr').open('wb') as b:r=subprocess.run(['/usr/bin/python3','-m','unittest','-v','tests.test_selfhost_cli','tests.test_selfhost_nanoisa_product'],cwd=root,env=testenv,stdout=a,stderr=b,timeout=1800)
record['tests']={'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t};save();assert r.returncode==0
print(json.dumps(record))
