from pathlib import Path
import gzip,hashlib,json,sys
root=Path.cwd();frozen=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');dest=root/'docs/evidence/installed-prefix-linux-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__).resolve()};sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));guards={'original_bootstrap_guards_unchanged':True,'development_host_bytes_unchanged':True}
for folder in ['installed-tool-discovery','corrected-prefix-install','corrected-installed-root-isolation']:
 directory=root/'.test_output'/folder
 paths.update(p for p in directory.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(directory).parts)
for folder in ['independent-fresh-prefix']:
 paths.update(p for p in (frozen/'.test_output'/folder).rglob('*') if p.is_file())
for name in ['build-installed-discovery-compiler.py','build-installed-discovery-compiler.log','run-installed-ordinary-cli.py','run-corrected-prefix-install.py','run-corrected-prefix-install.log','probe-corrected-installed-root-isolation.py','probe-corrected-installed-root-isolation.log','fresh-prefix-issue.md','prefix-progress-issue.md']:
 p=root/'.test_output'/name
 if p.is_file():paths.add(p)
for name in ['run-independent-fresh-prefix.py','run-independent-fresh-prefix.log']:
 p=frozen/'.test_output'/name
 if p.is_file():paths.add(p)
for manifest in [frozen/'.test_output/independent-fresh-prefix/manifest.json',root/'.test_output/corrected-prefix-install/manifest.json']:
 m=json.loads(manifest.read_text());paths.update(p for p in Path(m['external']).rglob('*') if p.is_file())
m=json.loads((root/'.test_output/installed-tool-discovery/host-closure.json').read_text())
for name,h in m['libraries'].items():
 library=Path(name);assert hashlib.sha256(library.read_bytes()).hexdigest()==h;paths.update(p for p in library.parent.rglob('*') if p.is_file())
for name in ['Makefile.gnu','src_nano/nanoc_v06.nano','src_nano/compiler/native_product.nano','tests/test_selfhost_cli.py','tests/test_selfhost_nanoisa_product.py']:
 paths.add(root/name);paths.add(frozen/name)
sha=lambda raw:hashlib.sha256(raw).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);packed=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:packed.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=packed
 data=packed.read_bytes();entries.append(dict(path=str(p),artifact=str(packed.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(data),compressed_bytes=len(data)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,guards=guards),indent=2)+'\n')
for e in entries:
 data=(dest/e['artifact']).read_bytes();assert sha(data)==e['compressed_sha256'] and sha(gzip.decompress(data))==e['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum(p.stat().st_size for p in seen.values()),guards=guards)))
