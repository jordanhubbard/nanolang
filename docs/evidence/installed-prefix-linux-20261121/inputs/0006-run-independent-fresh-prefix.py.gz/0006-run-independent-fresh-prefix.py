from pathlib import Path
import json,os,subprocess,time,sys,tempfile,hashlib
root=Path.cwd();out=root/'.test_output/independent-fresh-prefix';out.mkdir(exist_ok=False);sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(root,1800,30);b.load();artifacts=list(b.manifest['artifacts']);b.check_artifacts(artifacts);env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_BUILD_CACHE=str(out/'module-cache'),LSAN_OPTIONS='');env.pop('NANO_CC',None);env.pop('NANO_NVM2C',None);env.pop('NANOLANG_ROOT',None);record=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),original_receipt_sha256=digest(root/'bin/nanoc_bootstrap.json'),steps=[],limits=['I run fresh-PREFIX acceptance independently after the public ARRAY profile failed its original deadline. The profile and #1166 remain open. I preserve the successful bootstrap. Post-bootstrap clients use a separate cache. I retain failed original checks and do not reset guard markers or grant Literate AI/full release authority.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,cwd=root,child_env=None,timeout=3600):
 t=time.monotonic();entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd));record['steps'].append(entry);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(entry['argv'],cwd=cwd,env=child_env or env,stdout=a,stderr=c);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  finally:entry['elapsed_seconds']=time.monotonic()-t;save()
 if entry['returncode']:raise RuntimeError(entry)
try:
 external=Path(tempfile.mkdtemp(prefix='nano-fresh-prefix-'));prefix=external/'prefix';client=external/'client';client.mkdir();record.update(external=str(external),prefix=str(prefix));save()
 run(['make','CC=/usr/bin/cc','PREFIX='+str(prefix),'install'],'actual-make-install',timeout=1800)
 source=client/'input.nano';source.write_text('fn answer()->int{return 42}\nshadow answer{assert (== (answer) 42)}\nfn main()->int{assert (== (answer) 42) (println "fresh-prefix-ok") return 0}\n')
 clean=dict(env,PATH=str(prefix/'bin')+':/usr/bin:/bin',TMPDIR=str(client),NANO_BUILD_CACHE=str(external/'module-cache'),NANO_CC='/bin/false')
 for name in ['NANOLANG_ROOT','NANO_MODULE_PATH','NANO_NVM2C','NANO_AS_CAPTURE_HELPER']:clean.pop(name,None)
 run([prefix/'bin/nanoc',source,'--emit-nvm','-o',client/'program.nvm'],'external-installed-module',cwd=client,child_env=clean,timeout=180)
 run([prefix/'bin/nano_vm','--verify-only',client/'program.nvm'],'external-module-verify',cwd=client,child_env=clean,timeout=30)
 run([prefix/'bin/nano_vm',client/'program.nvm'],'external-module-execute',cwd=client,child_env=clean,timeout=30)
 native=dict(clean,NANO_CC='/usr/bin/cc')
 run([prefix/'bin/nanoc',source,'--target','native','-o',client/'program.native'],'external-installed-native',cwd=client,child_env=native,timeout=180)
 run([client/'program.native'],'external-native-execute',cwd=client,child_env=clean,timeout=30)
 for label in ['external-module-execute','external-native-execute']:assert (out/(label+'.stdout')).read_text()=='fresh-prefix-ok\n'
 record['external_products']={str(p):digest(p) for p in client.iterdir() if p.is_file()};save()
finally:
 try:
  b.check_inputs();b.check_artifacts(artifacts);record['original_bootstrap_guards_unchanged']=True
 except Exception as error:record['original_bootstrap_guard_failure']=repr(error)
 save()
print('I passed this independent actual fresh-PREFIX external module/native control; public profile acceptance remains open.')
