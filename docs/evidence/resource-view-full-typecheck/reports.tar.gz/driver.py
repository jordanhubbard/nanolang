import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker='corrected-resource-full-typecheck'
# This bounded gate proves preparation only; it cannot produce a passing worker result.
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("180",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
files=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p and not p.startswith('docs/evidence/')]
assert len(files)>3000 and all((root/p).is_file() for p in files)
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)

os.environ['NANO_SHADOW_TIMING']='1'
os.environ['NANO_CFLAGS']='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
os.environ['NANO_VERBOSE_BUILD']='1'
sample=root/'src_nano/typecheck_driver.nano'
paths.update(compiler=str(root/'bin/nanoc'),compiler_cseed=str(root/'bin/nanoc_c'),assembler_capture=str(root/'bin/nano_as_capture.so'),sample=str(sample))
prior=json.loads(Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-reports/sanitize-artifacts.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '946d18d56813fd897ffa4bc9dad9df26597b8449'
assert (root/'bin/nanoc').resolve()==root/'bin/nanoc_c'
for name in ['nanoc_c','nano_as_capture.so']:
 assert sha(root/'bin'/name)==prior[str(Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-source')/'bin'/name)]['sha256']
original=Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-reports/original-stage2-typecheck.log')
assert 'NANO_SHADOW_TIMING ' not in original.read_text(errors='replace')
write('attribution.json',{'scope':'corrected946 full original typecheck invocation; original53cc compiler/capture, default imported shadows,60s deadline; no selection-overlay compiler; standalone component acceptance only','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_sha256':sha(root/'bin/nanoc_c'),'compiler_alias':os.readlink(root/'bin/nanoc'),'original_log_sha256':sha(original),'original_timing_records':0,'expected_completed_shadows':604,'original_imported_shadows':596,'additive_imported_shadows':7,'root_shadows':1,'shadow_bound':60,'diagnostic_outer_bound':180,'original_perl_alarm':600,'deviations':['NANO_SHADOW_TIMING=1','output executable redirected to private report path','additional stricter180s owned-descendant supervisor'],'environment':{k:os.environ.get(k) for k in ('ASAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','NANO_SHADOW_TIMING','NANO_CFLAGS','NANO_VERBOSE_BUILD')}})
cmd=[paths['perl'],'-e','alarm 600; exec @ARGV; die "I cannot execute the requested command: $!\n"','bin/nanoc','src_nano/typecheck_driver.nano','-o',str(report/'sample')]
try:
 run('original-typecheck',cmd)
 passed_log=(report/'original-typecheck.log').read_text(errors='replace')
 ends=[json.loads(line.split('NANO_SHADOW_TIMING ',1)[1]) for line in passed_log.splitlines() if line.startswith('NANO_SHADOW_TIMING ') and '"phase":"shadow_end"' in line]
 assert len(ends)==604 and all(v['status']==0 for v in ends)
 assert len([line for line in passed_log.splitlines() if line.startswith('NANO_SHADOW_TIMING ') and '"phase":"module_init_start"' in line])==20
 write('full-selection-validation.json',{'pass':True,'completed_shadows':len(ends),'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'full_ci_preparation_pass':False})
finally:
 log_path=report/'original-typecheck.log'
 if log_path.exists():
  log=log_path.read_text(errors='replace')
  records=[];malformed=[]
  for line in log.splitlines():
   if 'NANO_SHADOW_TIMING ' not in line:continue
   text=line.split('NANO_SHADOW_TIMING ',1)[1]
   try:records.append(json.loads(text))
   except json.JSONDecodeError:malformed.append(line)
  labels=re.findall(r'Testing (.*?)\.\.\.',log)
  starts={};completed=[]
  for record in records:
   key=(record['source'],record['item'],record['ordinal'])
   if record['phase']=='shadow_start':starts[key]=record
   elif record['phase']=='shadow_end':
    first=starts.pop(key,None)
    if first:
     elapsed=record['wall_sec']-first['wall_sec']+(record['wall_nsec']-first['wall_nsec'])/1e9
     completed.append({'source':key[0],'item':key[1],'ordinal':key[2],'seconds':elapsed,'status':record['status']})
  write('timing-attribution.json',{'records':records,'malformed_records':malformed,'loaded_module_counts':re.findall(r'Loaded (\d+) module',log),'completed_shadows':completed,'unfinished_shadows':list(starts.values()),'labels':labels,'scope':'source/item/ordinal authoritative; buffered stdout labels retained without ordinal joins; complete component result is separate validation file'})
  write('retained-diagnostic-products.json',inventory([report]))
