from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys

from tests.test_nanolang_translator_passive import cases
from tests.nanolang_translator_routes import checked


def observe(*args):
    p = subprocess.run(args, capture_output=True, text=True)
    return dict(returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)


if len(sys.argv) > 1 and sys.argv[1] == "--corpus":
    widths = list(map(int, checked(["obj/nvm2c_module_reference", "--widths"]).splitlines()))
    corpus = cases(widths)
    root = Path(".test_output/passive-record-corpus")
    root.mkdir(exist_ok=True)
    paths = []
    for i, (_, data, _) in enumerate(corpus):
        p = root / f"case-{i}.bin"
        p.write_bytes(data)
        paths.append(p)
    values = []
    for i in range(0, len(paths), 64):
        values += checked([".test_output/passive-record-reference-asan", *paths[i:i + 64]], timeout=60).splitlines()
    assert len(values) == len(corpus)
    records = []
    for (name, data, expected), value in zip(corpus, values):
        if expected is not None:
            assert value == str(int(expected)), (name, expected, value)
        records.append(dict(name=name, bytes_hex=data.hex(), sha256=hashlib.sha256(data).hexdigest(),
                            explicit=expected, actual_c=int(value)))
    Path(".test_output/passive-record-corpus.json").write_text(json.dumps(records, separators=(",", ":")) + "\n")
    print("I retained", len(records), "actual C ASan/UBSan decisions and all case bytes; explicit controls:",
          sum(x["explicit"] is not None for x in records))
else:
    sources = ["src_nano/nvm2c/passive.nano", "tests/test_nanolang_translator_passive_calls.py", "tests/nanoisa/fixtures/passive_par.nano", "tests/nanoisa/fixtures/passive_flow.nano", "src_nano/nvm2c/passive_calls.nano", "src_nano/nvm2c/instructions.nano",
               "src_nano/nvm2c/container.nano", "src_nano/nvm2c/isa_metadata.nano",
               "tests/nvm2c_passive_driver.nano", "tests/nvm2c_passive_reference.c",
               "tests/test_nanolang_translator_passive.py", "tests/nanolang_translator_routes.py",
               "tests/native_process.py", "Makefile.gnu", "src/nanoisa/passive.c",
               "src/nanoisa/passive_calls.inc", "src/nanoisa/isa.c", "src/nanoisa/isa.h", "spec/nanoisa.yaml"]
    tools = ["bin/nanoc_c", "bin/nano_virt", "bin/nano_vm", "bin/nvm2c", "bin/nano_aot_runtime.o",
             "obj/nvm2c_passive_reference", "obj/nvm2c_module_reference",
             ".test_output/passive-record-reference-asan", ".test_output/legacy-globals-source-final"]
    record = dict(commit=observe("git", "rev-parse", "HEAD"), status=observe("git", "status", "--short"),
                  uname=observe("uname", "-a"), platform=platform.platform(), cc=observe("cc", "--version"),
                  python=sys.version,
                  source_sha256={s: hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},
                  post_run_tool_sha256={s: hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in tools},
                  limits=["I record post-run observations, not a full SDK closure.",
                          "My reused development NanoLang driver was built at602dc495e with the C seed.",
                          "My C/native/VM source producers are unchanged since that driver checkpoint.",
                          "My generated-C routes instrument generated code, with an ordinary AOT runtime.",
                          "My ASan/UBSan oracle instruments both passive analysis and ISA decoding.",
                          "My unittest products are temporary and not archived.",
                          "My independent corpus receipt is regenerated deterministically from the final test.",
                          "I validate passive claims only, not whole-module conversion or execution authority."])
    if sys.platform == "darwin":
        record["sdk"] = observe("xcrun", "--sdk", "macosx", "--show-sdk-version")
        record["sdk_path"] = observe("xcrun", "--sdk", "macosx", "--show-sdk-path")
        record["os"] = observe("sw_vers")
    Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + "\n")
