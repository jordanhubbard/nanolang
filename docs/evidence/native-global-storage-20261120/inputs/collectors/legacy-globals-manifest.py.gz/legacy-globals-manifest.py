from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys


def command(*args):
    process = subprocess.run(args, capture_output=True, text=True)
    return {"returncode": process.returncode, "stdout": process.stdout,
            "stderr": process.stderr}


sources = subprocess.check_output(
    ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", "602dc495e"],
    text=True).splitlines()
sources += [str(path) for path in sorted(Path("src_nano/nvm2c").glob("*.nano"))]
sources += ["tests/eval_global_bindings.nano", "tests/test_nanolang_translator_module.py"]
tools = ["bin/nanoc_c", "bin/nano_virt", "bin/nano_vm", "bin/nvm2c",
         "bin/nano_aot_runtime.o", ".test_output/legacy-globals-source-final"]
record = {
    "implementation": command("git", "rev-parse", "HEAD"),
    "status": command("git", "status", "--short"),
    "platform": platform.platform(), "uname": command("uname", "-a"),
    "cc": command("cc", "--version"), "python": sys.version,
    "source_sha256": {name: hashlib.sha256(Path(name).read_bytes()).hexdigest()
                      for name in sources},
    "post_run_tool_sha256": {
        name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in tools},
    "limits": [
        "I record post-run observations, not a complete SDK closure.",
        "My unittest products are temporary and not archived.",
        "My development NanoLang driver is C-seed-built, not a raw fixed point.",
        "My decoder routes instrument generated C with an ordinary AOT runtime.",
        "My native-product sanitizer route does not instrument the compiler process.",
        "I retain two C-seed shadow refusals and the separate full evaluator leak issue.",
    ],
}
if sys.platform == "darwin":
    record["sdk"] = command("xcrun", "--sdk", "macosx", "--show-sdk-version")
    record["sdk_path"] = command("xcrun", "--sdk", "macosx", "--show-sdk-path")
    record["os"] = command("sw_vers")
Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + "\n")
