#ifndef NANOLANG_H
#define NANOLANG_H

// Define _POSIX_C_SOURCE only if not already defined
// Some systems (like Ubuntu) define this in their headers
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include <assert.h>

#include "generated/compiler_schema.h"

/* Backtrace support for assertions */
#ifdef __APPLE__
#include <execinfo.h>
#include <unistd.h>
#elif defined(__linux__)
#include <execinfo.h>
#include <unistd.h>
#endif

/* Forward declarations */
typedef struct Value Value;
struct FunctionSignature;  /* Forward declaration - typedef defined with struct */

/* Include dynamic array and GC struct for GC support - needs to be after Value forward declaration */
#include "runtime/dyn_array.h"
#include "runtime/gc_struct.h"

/* Value types */
typedef enum {
    VAL_INT,
    VAL_FLOAT,
    VAL_BOOL,
    VAL_STRING,
    VAL_ARRAY,
    VAL_DYN_ARRAY,  /* Dynamic arrays (GC-managed) */
    VAL_STRUCT,     /* Struct values (stack-allocated) */
    VAL_GC_STRUCT,  /* GC-managed struct (heap-allocated) */
    VAL_UNION,      /* Union values (tagged unions) */
    VAL_FUNCTION,   /* Function values (for first-class functions) */
    VAL_TUPLE,      /* Tuple values: (1, "hello", true) */
    VAL_COROUTINE,  /* Coroutine handle (int_val = scheduler id) */
    VAL_VOID,
    VAL_BSTRING  /* I keep binary strings distinct from STRING and opaque integers. */
} ValueType;

/* Array structure */
typedef struct {
    ValueType element_type;  /* Type of elements in the array */
    int length;              /* Number of elements */
    int capacity;            /* Allocated capacity */
    void *data;              /* Pointer to array data */
    bool is_byte_array;       /* I preserve U8 identity while retaining INT-sized slots. */
} Array;

/* Struct value structure */
typedef struct {
    char *struct_name;       /* Name of struct type (e.g., "Point") */
    char **field_names;      /* Array of field names */
    Value *field_values;     /* Array of field values */
    int field_count;         /* Number of fields */
    bool packed_names;       /* I own one allocation for type and field names. */
} StructValue;

StructValue *allocate_struct_carrier(const char *name, char **fields, int field_count);
void release_struct_carrier_names(StructValue *record);

/* Union value (tagged union) */
typedef struct {
    char *union_name;        /* Name of union type (e.g., "Status", "Result") */
    int variant_index;       /* Index of the active variant */
    char *variant_name;      /* Name of the active variant (e.g., "Ok", "Error") */
    char **field_names;      /* Array of field names for this variant */
    Value *field_values;     /* Array of field values for this variant */
    int field_count;         /* Number of fields in this variant */
} UnionValue;

/* Tuple value structure */
typedef struct {
    Value *elements;          /* Array of values */
    int element_count;        /* Number of elements */
} TupleValue;

/* Type information */
typedef enum {
    TYPE_INT,
    TYPE_U8,          /* Unsigned 8-bit integer (byte) */
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_STRING,
    TYPE_BSTRING,      /* Binary string (nl_string_t*) - length-explicit, UTF-8 */
    TYPE_VOID,
    TYPE_ARRAY,
    TYPE_STRUCT,
    TYPE_ENUM,
    TYPE_UNION,
    TYPE_GENERIC,      /* Generic type (e.g., List<T> before instantiation) */
    TYPE_LIST_INT,
    TYPE_LIST_STRING,
    TYPE_LIST_TOKEN,
    TYPE_LIST_GENERIC, /* Generic list with user-defined type: List<Point>, List<Player>, etc. */
    TYPE_HASHMAP,      /* Generic HashMap<K,V> */
    TYPE_FUNCTION,     /* Function type: fn(int, int) -> int */
    TYPE_TUPLE,        /* Tuple type: (int, string, bool) */
    TYPE_OPAQUE,       /* Opaque C pointer type: GLFWwindow, SDL_Window, etc. */
    TYPE_OPEN_RECORD,  /* Row-polymorphic record: {f1:T1, f2:T2 | r} */
    TYPE_UNKNOWN,
    TYPE_BORROW_SHARED, /* Parser annotation; lowering remains guarded. */
    TYPE_BORROW_MUT,
    TYPE_LIST_BOOL      /* Boolean list: List<bool>, full list runtime. */
} Type;

/* Extended type information for arrays and generics */
typedef struct TypeInfo {
    Type base_type;
    /* I retain service origin separately from visible spelling and opaque tags.
     * Zero declaration is the ordinary-type sentinel. These fields own no heap. */
    uint32_t service_declaration, service_module, service_ordinal, service_category;
    struct TypeInfo *element_type;  /* For arrays: array<int> has element_type = int */
    
    /* For generic types: List<int> */
    char *generic_name;              /* e.g., "List" */
    struct TypeInfo **type_params;   /* e.g., [TypeInfo{TYPE_INT}] */
    int type_param_count;            /* Number of type parameters */
    
    /* For tuple types: (int, string, bool) */
    Type *tuple_types;               /* Array of tuple element types */
    struct TypeInfo **tuple_elements; /* I own complete element annotations. */
    char **tuple_type_names;         /* For struct/enum/union tuple elements */
    int tuple_element_count;         /* Number of tuple elements */
    
    /* For opaque types: GLFWwindow, SDL_Window */
    char *opaque_type_name;          /* e.g., "GLFWwindow" */
    
    /* For function types: fn(int, int) -> int */
    struct FunctionSignature *fn_sig;  /* Function signature with param/return types */

    /* For row-polymorphic record types: { name: String, age: Int | r }
     * When is_open_row is true, the record has an unconstrained row variable
     * (represented by row_var_name, e.g. "r") that allows extension.
     * row_field_names / row_field_types are the known fields; row_field_count
     * is the number of fields.  row_var_name == NULL means a closed record.
     */
    bool   is_open_row;        /* True if this is an open/extensible row type */
    char  *row_var_name;       /* Name of the row variable, e.g. "r" (NULL = closed) */
    char **row_field_names;    /* Field names array (NULL-terminated or row_field_count) */
    Type  *row_field_types;    /* Field types parallel to row_field_names */
    struct TypeInfo **row_field_type_info; /* I own complete row field annotations. */
    char **row_field_type_names; /* Struct/enum names for TYPE_STRUCT fields */
    int    row_field_count;    /* Number of known fields */

    /* Type-scheme generalization: ∀ type variables (HM inference)
     * When type_var_count > 0, this TypeInfo represents a polymorphic type scheme.
     * type_var_names holds the quantified variables, e.g. ["a", "b"].
     * Display: ∀a. List<a>
     */
    char **type_var_names;     /* Quantified type variable names (for display) */
    int    type_var_count;     /* Number of quantified type variables */
} TypeInfo;

/* Value structure */
struct Value {
    ValueType type;
    bool is_return;  /* Flag to propagate return statements through control flow */
    bool is_break;   /* Flag to propagate break statements through control flow */
    bool is_continue;/* Flag to propagate continue statements through control flow */
    const void *return_target; /* Borrowed active interpreter call; valid only with is_return. */
    union {
        long long int_val;
        double float_val;
        bool bool_val;
        char *string_val;
        void *bstring_val;     /* Managed interpreter binary-string owner shell. */
        Array *array_val;
        DynArray *dyn_array_val;    /* Dynamic array (GC-managed) */
        StructValue *struct_val;    /* Struct values (stack) */
        GCStruct *gc_struct_val;    /* GC-managed struct (heap) */
        UnionValue *union_val;      /* Union values (tagged unions) */
        struct {
            char *function_name;       /* Name of the function */
            struct FunctionSignature *signature;  /* Function signature */
        } function_val;  /* Function values */
        TupleValue *tuple_val;  /* Tuple values */
    } as;
};

/* AST node types */
typedef enum {
    AST_NUMBER,
    AST_FLOAT,
    AST_STRING,
    AST_BOOL,
    AST_IDENTIFIER,
    AST_PREFIX_OP,
    AST_CALL,
    AST_MODULE_QUALIFIED_CALL,  /* Module-qualified call: (Module.function args...) */
    AST_ARRAY_LITERAL,
    AST_LET,
    AST_SET,
    AST_IF,
    AST_COND,
    AST_WHILE,
    AST_FOR,
    AST_RETURN,
    AST_BREAK,
    AST_CONTINUE,
    AST_BLOCK,
    AST_FUNCTION,
    AST_SHADOW,
    AST_PROGRAM,
    AST_PRINT,
    AST_ASSERT,
    AST_STRUCT_DEF,
    AST_STRUCT_LITERAL,
    AST_FIELD_ACCESS,
    AST_ENUM_DEF,
    AST_UNION_DEF,
    AST_UNION_CONSTRUCT,
    AST_MATCH,
    AST_IMPORT,
    AST_MODULE_DECL,       /* Module declaration: module module_name */
    AST_OPAQUE_TYPE,       /* Opaque type declaration: opaque type TypeName */
    AST_TUPLE_LITERAL,     /* Tuple literal: (1, "hello", true) */
    AST_TUPLE_INDEX,       /* Tuple index access: tuple.0, tuple.1 */
    AST_QUALIFIED_NAME,    /* Qualified name: module::symbol or std::io::read_file */
    AST_UNSAFE_BLOCK,      /* Unsafe block: unsafe { ... } */
    AST_TRY_OP,            /* Postfix ? try operator: expr? */
    AST_PAR_BLOCK,         /* Parallel block: par { let a = ..., let b = ... } */
    AST_EFFECT_DECL,       /* Effect declaration: effect IO { print : String -> Unit } */
    AST_HANDLE_EXPR,       /* Handle expression: handle { expr } with { op args -> ... } */

    /* ── row-poly / effect extension nodes ──────────────────────────────── */
    AST_PAR_LET,           /* Parallel let binding (from par-let pass)       */
    AST_EFFECT_HANDLER,    /* Extended handle expression (row-poly compat)    */
    AST_EFFECT_OP,         /* perform Foo.op arg                              */
    AST_ASYNC_FN,          /* async fn declaration: async fn name(...) -> T { body } */
    AST_AWAIT,             /* await expression: await expr */
    AST_SERVICE_DECL       /* Counted, unresolved File service declaration */
} ASTNodeType;

/* Forward declaration */
typedef struct ASTNode ASTNode;

/* Function signature for function types: fn(int, string) -> bool */
typedef struct FunctionSignature {
    Type *param_types;           /* Array of parameter types */
    int param_count;             /* Number of parameters */
    char **param_struct_names;   /* For struct/enum/union parameters */
    TypeInfo **param_type_info;  /* Owned complete parameter annotations */
    TypeInfo *return_type_info;  /* Owned complete return annotation */
    Type return_type;            /* Return type */
    char *return_struct_name;    /* For struct/enum/union return */
    struct FunctionSignature *return_fn_sig;  /* For function return types: fn() -> fn() -> int */
} FunctionSignature;

/* Parameter structure */
typedef struct {
    char *name;
    Type type;
    char *struct_type_name;  /* For TYPE_STRUCT: which struct (e.g., "Point") */
    Type element_type;       /* For TYPE_ARRAY: element type (e.g., TYPE_INT for array<int>) */
    FunctionSignature *fn_sig;   /* For TYPE_FUNCTION: function signature */
    TypeInfo *type_info;     /* For generic types: Result<int, string> */
} Parameter;

/* AST node structure */
struct ASTNode {
    ASTNodeType type;
    int line;
    int column;
    /* Closing brace for parsed lexical blocks; zero for unlocated nodes. */
    int scope_end_line;
    int scope_end_column;
    /* I borrow the hoisted anonymous declaration at its lexical expression.
     * The program owns that declaration; this link does not own or free it. */
    ASTNode *lambda_definition;
    ASTNode *checked_global; /* I borrow the exact checked global declaration, never its storage. */
    bool checked_function_name; /* I resolved this spelling to a declaration, not a value binding. */
    ASTNode *affine_use_owner; /* Borrowed exact checked source function. */
    uint64_t affine_use_epoch;
    unsigned char checked_affine_use; /* 0 unknown, 1 observe, 2 consume. */
    char *contextual_func_name; /* Owned native specialization selected for this function value. */
    union {
        long long number;
        double float_val;
        char *string_val;
        bool bool_val;
        char *identifier;
        struct {
            TokenType op;
            ASTNode **args;
            int arg_count;
        } prefix_op;
        struct {
            int borrow_mode;     /* Syntactic address expression: 0 ordinary, 1 shared, 2 exclusive. */
            char *name;           /* Function name (for regular calls) */
            ASTNode *func_expr;   /* Function expression (for calls like ((func_call) arg1 arg2)) */
            ASTNode **args;
            int arg_count;
            char *return_struct_type_name;  /* For calls that return struct types (e.g., list_Point_get) */
            Type map_key_type; /* Checked scalar constructor context. */
            Type map_value_type;
            bool map_context_checked;
            FunctionSignature *checked_signature; /* Owned indirect-call context after lexical checking. */
            char *concrete_func_name;  /* For generic function calls: monomorphized name (e.g., "identity_int") */
        } call;
        struct {
            char *module_alias;       /* Module alias (e.g., "Vec" from "as Vec") */
            char *function_name;      /* Function name (e.g., "add") */
            ASTNode **args;
            int arg_count;
            char *return_struct_type_name;  /* For calls that return struct types */
            FunctionSignature *checked_signature; /* Owned concrete qualified-call context. */
        } module_qualified_call;
        struct {
            ASTNode **elements;
            int element_count;
            Type element_type;  /* Type of array elements */
            bool has_element_annotation; /* I retain a checked contextual storage kind. */
        } array_literal;
        struct {
            char *name;
            Type var_type;
            char *type_name;         /* For TYPE_STRUCT/TYPE_UNION: actual type name (e.g., "Status", "Point") */
            Type element_type;       /* For TYPE_ARRAY: element type (e.g., TYPE_INT for array<int>) */
            FunctionSignature *fn_sig;  /* For TYPE_FUNCTION: function signature */
            TypeInfo *type_info;     /* For generic types: Result<int, string>, List<Point>, etc. */
            bool is_mut;
            bool is_pub;
            ASTNode *value;
            bool is_generated; /* I omit parser-owned temporaries from original-name metadata. */
            bool is_destructure;
            bool is_destructure_projection;
            int destructure_count;
            char **destructure_names;
        } let;
        struct {
            char *name;
            ASTNode *value;
            char *field_name; /* Optional scalar field of an exclusive referent. */
            bool qualified_global; /* I checked alias.field as one imported global binding. */
        } set;
        struct {
            ASTNode *condition;
            ASTNode *then_branch;
            ASTNode *else_branch;
        } if_stmt;
        struct {
            ASTNode **conditions;   /* Array of condition expressions */
            ASTNode **values;       /* Array of value expressions */
            int clause_count;       /* Number of (condition, value) pairs */
            ASTNode *else_value;    /* Mandatory else clause */
        } cond_expr;
        struct {
            ASTNode *condition;
            ASTNode *body;
        } while_stmt;
        struct {
            char *var_name;
            ASTNode *range_expr;
            ASTNode *body;
        } for_stmt;
        struct {
            ASTNode *value;
        } return_stmt;
        struct {
            ASTNode **statements;
            int count;
        } block;
        struct {
            char *name;
            Parameter *params;
            int param_count;
            Type return_type;
            Type return_element_type;       /* For TYPE_ARRAY returns */
            char *return_struct_type_name;  /* For TYPE_STRUCT returns */
            FunctionSignature *return_fn_sig;  /* For TYPE_FUNCTION returns */
            TypeInfo *return_type_info;  /* For TYPE_TUPLE returns: stores element types */
            ASTNode *body;
            bool is_extern;  /* Mark external C functions */
            bool is_anonymous; /* I instantiate this declaration at its expression. */
            bool is_pub;     /* Visibility: public (pub) vs private */
            bool is_gpu;     /* @gpu annotation: emit as PTX kernel */
            unsigned char checked_affine; /* 0 unknown, 1 resource checker completed. */
            uint64_t affine_check_epoch;
            uint64_t affine_completed_epoch;
            bool is_pure;    /* pure fn: no mutation, no I/O, only pure callees */
            char **effect_names;  /* Algebraic effects this fn may perform: ["IO", "Err"] */
            int   effect_count;
        } function;
        struct {
            char *function_name;
            ASTNode *body;
        } shadow;
        struct {
            ASTNode **items;
            int count;
        } program;
        struct {
            ASTNode *expr;
            bool is_println;
        } print;
        struct {
            ASTNode *condition;
        } assert;
        struct {
            char *name;               // Struct name
            char *original_name;      /* Source spelling before module binding */
            char **field_names;       // Array of field names
            Type *field_types;        // Array of field types
            char **field_type_names;  // For TYPE_STRUCT/TYPE_UNION fields: actual type names
            Type *field_element_types;  // For TYPE_ARRAY fields: element type
            TypeInfo **field_type_info; /* Owned complete field annotations. */
            int field_count;          // Number of fields
            bool is_pub;              // Visibility: public (pub) vs private
            bool is_resource;         // Resource type: affine semantics (use at most once)
            bool is_extern;           // External C type: do not emit definition
        } struct_def;
        struct {
            char *struct_name;        // Name of struct type
            char **field_names;       // Array of field names (for initialization)
            ASTNode **field_values;   // Array of field value expressions
            int field_count;          // Number of fields
            ASTNode *spread_source;   // For {..base, extra:val}: source to spread (NULL if none)
        } struct_literal;
        struct {
            ASTNode *object;          // The struct instance expression
            char *field_name;         // The field being accessed
            TypeInfo *resolved_type_info; /* Owned concrete union payload type. */
        } field_access;
        struct {
            char *name;               // Enum name
            char *original_name;      /* I retain the source spelling after module binding. */
            char **variant_names;     // Array of variant names
            int *variant_values;      // Array of variant values (or NULL for auto)
            int variant_count;        // Number of variants
            bool is_pub;              // Visibility: public (pub) vs private
            bool is_extern;           // External C type: do not emit definition
        } enum_def;
        
        /* Union definition: union Color { Red {}, Blue { intensity: int } } 
         * Generic union: union Result<T, E> { Ok { value: T }, Err { error: E } } */
        struct {
            char *name;
            char *original_name;      /* I retain my source spelling after owner binding. */
            int variant_count;
            char **variant_names;
            int *variant_field_counts;
            char ***variant_field_names;
            Type **variant_field_types;
            char ***variant_field_type_names;  // For TYPE_STRUCT/TYPE_UNION fields: actual type names
            TypeInfo ***variant_field_type_info; /* Owned complete payload annotations. */
            bool is_pub;              // Visibility: public (pub) vs private
            bool is_extern;           // External C type: do not emit definition
            char **generic_params;    // Generic parameter names: ["T", "E"]
            int generic_param_count;  // Number of generic parameters
        } union_def;
        
        /* Union construction: Color.Red {} or Color.Blue { intensity: 5 } */
        struct {
            char *union_name;
            char *variant_name;
            int field_count;
            char **field_names;
            ASTNode **field_values;
            TypeInfo *type_info;  /* For generic unions: full instantiation info (e.g., Result<int, string>) */
        } union_construct;
        
        /* Match expression: match c { Red(r) => ..., Blue(b) => ... } */
        struct {
            ASTNode *expr;
            int arm_count;
            char **pattern_variants;
            char **pattern_bindings;
            ASTNode **arm_bodies;
            ASTNode **guard_exprs;  /* Per-arm guard: NULL if no guard, or boolean expression */
            char *union_type_name;  /* Filled during typechecking */
            Type checked_scrutinee_type; /* Exact int/union domain accepted by typechecking. */
            bool scrutinee_type_checked;
            unsigned char checked_coverage; /* 0 unknown, 1 total int, 2 total union. */
            Type result_type;       /* Checked arm value, independent of function return */
            bool result_type_checked;
        } match_expr;
        /* Import statement: import "module.nano" as alias or from "module.nano" import sym1, sym2 */
        struct {
            char *module_path;      /* Path to module file (e.g., "math.nano" or "utils/math.nano") */
            char *module_alias;     /* Optional module alias (for "module ... as alias") */
            bool is_unsafe;         /* true for "unsafe module" */
            bool is_selective;      /* true for "from...import" syntax */
            bool is_wildcard;       /* true for "from...import *" syntax */
            bool is_pub_use;        /* true for "pub use" (re-export) */
            char **import_symbols;  /* NULL or array of symbol names for selective import */
            char **import_aliases;  /* NULL or array of alias names (aligned with import_symbols) */
            int import_symbol_count;/* Number of symbols in selective import */
        } import_stmt;
        /* Module declaration: module module_name */
        struct {
            char *name;             /* Explicit module name */
        } module_decl;
        /* Qualified name: module::symbol, std::io::fs::read_file */
        struct {
            char **name_parts;      /* Array of name segments: ["std", "io", "fs", "read_file"] */
            int part_count;         /* Number of segments */
        } qualified_name;
        /* Opaque type declaration: opaque type TypeName */
        struct {
            char *name;            /* Type name (e.g., "GLFWwindow", "SDL_Window") */
        } opaque_type;
        struct {
            char *interface_id;
            char *document_path;
            int64_t interface_bytes, path_bytes;
            int64_t catalog_version;
            int64_t origin_index; /* -1 until the module resolver binds origin */
        } service_decl;
        /* Tuple literal: (1, "hello", true) */
        struct {
            ASTNode **elements;    /* Array of element expressions */
            int element_count;     /* Number of elements */
            Type *element_types;   /* Types of each element (filled by type checker) */
            TypeInfo *type_info;   /* I own the checked recursive tuple shape. */
        } tuple_literal;
        /* Tuple index access: tuple.0, tuple.1 */
        struct {
            ASTNode *tuple;        /* The tuple expression */
            int index;             /* The index being accessed (0, 1, 2, ...) */
        } tuple_index;
        /* Unsafe block: unsafe { ... } */
        struct {
            ASTNode **statements;  /* Statements in the unsafe block */
            int count;             /* Number of statements */
        } unsafe_block;
        /* Postfix ? try operator: expr? */
        struct {
            ASTNode *operand;       /* The expression being try-unwrapped */
            char *union_type_name;  /* Filled by typechecker: C union name (e.g. "Result") */
            char *ok_field_name;    /* Filled by typechecker: first field of Ok variant */
        } try_op;
        /* Parallel block: par { let a = ..., let b = ... } */
        struct {
            ASTNode **bindings;    /* Let-binding statements (AST_LET nodes) */
            int count;             /* Number of bindings */
            bool is_flow;          /* Source order is retained; execution uses the graph order. */
        } par_block;


        /* Effect declaration: effect IO { print : String -> Unit; read : Unit -> String } */
        struct {
            char *effect_name;          /* e.g., "IO" */
            int op_count;               /* Number of operations */
            char **op_names;            /* Operation names: ["print", "read"] */
            Parameter **op_params;      /* Parameter list for each operation */
            int *op_param_counts;       /* Param count for each operation */
            Type *op_return_types;      /* Return type for each operation */
            TypeInfo **op_return_type_infos; /* I own complete operation results. */
            char **op_return_type_names;/* For struct return types */
            bool is_pub;
            /* Alternative simple-type layout (used by parse_effect_def) */
            Type  *op_param_types;      /* Simplified: one param type per op */
            char **op_param_type_names; /* Struct/union name overrides for params */
        } effect_decl;

        /* Handle expression: handle { body } with { print s -> ...; read () -> ... } */
        struct {
            ASTNode *body;              /* Expression whose effects are handled */
            char *effect_name;          /* Which effect this handle block handles (filled by TC) */
            int handler_count;          /* Number of operation handlers */
            char **handler_op_names;    /* Operation names being handled */
            char ***handler_param_names;/* Parameter names for each handler */
            int *handler_param_counts;  /* Parameter count for each handler */
            ASTNode **handler_bodies;   /* Handler body expressions */
        } handle_expr;

        /* ── Row-poly / effect extension union fields ─────────────────────── */

        /* AST_PAR_LET: parallel let bindings (extended form with names/values/body) */
        struct {
            char    **names;       /* Binding names */
            ASTNode **values;      /* Binding value expressions */
            int       count;       /* Number of bindings */
            ASTNode  *body;        /* Body expression evaluated after 'in' */
            bool     *independent; /* Per-binding independence flag (set by par_let_pass) */
        } par_let;

        /* AST_EFFECT_HANDLER: extended handle expression (row-poly compat) */
        struct {
            ASTNode  *body;
            char     *effect_name;         /* Which effect is being handled */
            ASTNode **handler_bodies;
            char    **handler_op_names;
            char    **handler_param_names;
            int       handler_count;
        } effect_handler;

        /* AST_EFFECT_OP: perform Foo.op(args...) */
        struct {
            char    *effect_name;
            char    *op_name;
            ASTNode **args;
            int arg_count;
        } effect_op;

        /* AST_ASYNC_FN — async function declaration (wraps a normal function node) */
        struct {
            ASTNode *function;      /* The underlying AST_FUNCTION node */
        } async_fn;

        /* AST_AWAIT — await expression */
        struct {
            ASTNode *expr;          /* Expression being awaited */
        } await_expr;
    } as;
};

/* Resource use state for affine types */
typedef enum {
    RESOURCE_UNUSED,    /* Resource variable declared but not yet used */
    RESOURCE_USED,      /* Resource variable used (read/passed as argument) */
    RESOURCE_CONSUMED   /* Resource variable consumed (ownership transferred) */
} ResourceUseState;

/* Symbol table entry for variables */
typedef struct {
    char *name;
    Type type;
    char *struct_type_name;  /* For TYPE_STRUCT: which struct (e.g., "Point", "Color") */
    Type element_type;       /* For TYPE_ARRAY: element type (e.g., TYPE_INT for array<int>) */
    TypeInfo *type_info;     /* For complex types (tuples, generics, etc.) - full type information */
    bool is_mut;
    Value value;
    bool is_global;     /* Top-level binding, not a retained function local */
    ASTNode *global_declaration; /* Borrowed checked declaration; aliases share this identity. */
    bool is_used;        /* Track if variable is ever used (for warnings) */
    bool is_resource;    /* True if this variable's type is a resource type */
    ResourceUseState resource_state;  /* For resource types: track usage state */
    bool from_c_header;  /* True if this constant was loaded from a C header #define */
    int def_line;        /* Line where variable was defined */
    int def_column;      /* Column where variable was defined */
    int flow_start_line; /* Graph lexical start, separate from definition diagnostics */
    int flow_start_column;
    int scope_end_line;  /* Exclusive source bound; zero for unbounded symbols */
    int scope_end_column;
    /* Source file the definition came from, or NULL for symbols with no file
     * (builtins, and anything registered without a location).
     *
     * Line numbers are only comparable within a file. Without this, a lookup
     * that picks "the most recent symbol defined at or before this line"
     * compares a line number from one file against a definition in another,
     * and quietly returns an unrelated variable that happens to sit at a lower
     * line in some other module. Not owned: it points at a path string the
     * caller keeps alive for the compilation. */
    const char *def_file;
} Symbol;

/* Function table entry */
typedef struct {
    char *name;
    Parameter *params;
    int param_count;
    Type return_type;
    Type return_element_type;       /* For TYPE_ARRAY returns */
    char *return_struct_type_name;  /* For TYPE_STRUCT returns: which struct */
    FunctionSignature *return_fn_sig;  /* For TYPE_FUNCTION returns: function signature */
    TypeInfo *return_type_info;  /* For TYPE_TUPLE returns: tuple element types */
    ASTNode *body;
    ASTNode *shadow_test;
    ASTNode *lexical_scope; /* Borrowed enclosing block for named local functions. */
    bool is_extern;  /* Mark external C functions */
    bool is_gpu;     /* @gpu annotation: function targets GPU / PTX */
    bool is_async;   /* Mark async functions (declared with `async fn`) */
    bool is_pure;    /* pure fn: no mutation, no I/O, only pure callees */
    bool is_pub;     /* Visibility: public (true) vs private (false) - default false */
    char *module_name;  /* Module this function belongs to (NULL for global) */
    const char *source_file; /* Borrowed source owner for checked function bodies. */
    char *alias_of;  /* For import aliases: original function name (NULL if not alias) */

    /* Memory semantics annotations (for module metadata and tooling) */
    bool returns_gc_managed;     /* True if return value is GC-tracked (e.g., strings) */
    bool requires_manual_free;   /* True if return value needs explicit free (e.g., opaque handles) */
    bool returns_borrowed;       /* True if return is borrowed ref (e.g., Json.get) - don't wrap/free */
    char *cleanup_function;      /* Name of cleanup function if requires_manual_free (e.g., "regex_free") */

    /* Algebraic effects this function may perform */
    char **effect_names;
    int    effect_count;
} Function;

/* Struct definition entry */
typedef struct {
    char *name;
    char *original_name;
    char **field_names;
    Type *field_types;
    char **field_type_names;  /* For TYPE_STRUCT/TYPE_UNION fields: actual type name (e.g., "Vec3") */
    Type *field_element_types;  /* For TYPE_ARRAY fields: element type (e.g., TYPE_STRING for array<string>) */
    TypeInfo **field_type_info; /* Borrowed from the defining AST. */
    int field_count;
    bool is_pub;     /* Visibility: public (true) vs private (false) - default false */
    bool is_resource;  /* Resource type: affine semantics (use at most once) */
    bool is_extern;    /* External C type: do not emit definition */
    char *module_name;  /* Module this struct belongs to (NULL for global) */
} StructDef;

/* Enum definition entry */
typedef struct {
    char *name;
    char *original_name;
    char **variant_names;
    int *variant_values;
    int variant_count;
    bool is_pub;     /* Visibility: public (true) vs private (false) - default false */
    bool is_extern;   /* External C type: do not emit definition */
    char *module_name;  /* Module this enum belongs to (NULL for global) */
} EnumDef;

/* Union definition entry */
typedef struct {
    char *name;
    char *original_name; /* I own the source spelling independently of the AST. */
    int variant_count;
    char **variant_names;
    int *variant_field_counts;
    char ***variant_field_names;
    Type **variant_field_types;
    char ***variant_field_type_names;  /* For TYPE_STRUCT/TYPE_UNION fields: actual type names */
    TypeInfo ***variant_field_type_info; /* Owned complete payload annotations. */
    bool is_pub;     /* Visibility: public (true) vs private (false) - default false */
    bool is_extern;   /* External C type: do not emit definition */
    char *module_name;  /* Module this union belongs to (NULL for global) */
    char **generic_params;    /* Generic parameter names: ["T", "E"] for Result<T, E> */
    int generic_param_count;  /* Number of generic parameters (0 for non-generic) */
} UnionDef;

/* Opaque type definition entry (for C pointer types) */
typedef struct {
    char *name;            /* Type name in nanolang (e.g., "GLFWwindow") */
    char *c_type_name;     /* C type with pointer (e.g., "GLFWwindow*") */
} OpaqueTypeDef;

/* Effect operation signature */
typedef struct {
    char *name;              /* Operation name (e.g., "print") */
    Parameter *params;       /* Parameters */
    int param_count;
    Type return_type;        /* Return type */
    char *return_type_name;  /* For struct return types */
    TypeInfo *return_type_info; /* I borrow the complete declaration annotation. */
} EffectOp;

/* Effect definition entry: effect IO { print : String -> Unit } */
typedef struct {
    char *name;              /* Effect name (e.g., "IO") */
    char *original_name;     /* I retain the source spelling before module qualification. */
    EffectOp *ops;           /* Operations */
    int op_count;
    bool is_pub;
    char *module_name;       /* Module this effect belongs to (NULL for global) */
} EffectDef;

/* Constant definition entry (from C headers or nanolang) */
typedef struct {
    char *name;
    int64_t value;      /* Integer constant value */
    Type type;          /* TYPE_INT for now, could expand to TYPE_FLOAT, TYPE_STRING later */
} ConstantDef;

/* Generic type instantiation (for monomorphization) */
typedef struct {
    char *generic_name;        /* e.g., "List" */
    Type *type_args;           /* e.g., [TYPE_INT] or [TYPE_LIST_GENERIC] */
    int type_arg_count;        /* Number of type arguments */
    char **type_arg_names;     /* e.g., ["Point"] for user types, NULL for primitives */
    char *concrete_name;       /* e.g., "List_int" or "List_Point" (generated name) */
    TypeInfo *type_info;       /* Owned concrete union payload substitution context. */
} GenericInstantiation;

/* Generic function instantiation (for user-defined generic functions like fn identity(x: T) -> T) */
typedef struct {
    char *orig_name;         /* Original function name: "identity" */
    char *mono_name;         /* Monomorphized name: "identity_int" */
    char **var_names;        /* Type variable names: ["T"] */
    Type *bound_types;       /* Concrete types: [TYPE_INT] */
    char **bound_type_names; /* For TYPE_STRUCT bounds: ["Point"]; NULL for primitives */
    int binding_count;       /* Number of unique type variables */
    FunctionSignature *signature; /* Owned complete contextual signature, or NULL for legacy instances. */
} GenericFuncInstance;

/* Module namespace for import aliases */
typedef struct {
    char *alias;               /* Module alias name (e.g., "Math", "Lexer") */
    char *owner_module;        /* Declaring module; NULL is the root namespace. */
    char *module_name;         /* Original module name */
    char **function_names;     /* Functions from this module */
    int function_count;
    char **struct_names;       /* Structs from this module */
    int struct_count;
    char **enum_names;         /* Enums from this module */
    int enum_count;
    char **union_names;        /* Unions from this module */
    int union_count;
} ModuleNamespace;

/* Module metadata for introspection */
typedef struct {
    char *name;                /* Module name (e.g., "sdl", "vector2d") */
    char *path;                /* Module file path */
    bool is_unsafe;            /* Is this module marked unsafe? */
    bool has_ffi;              /* Does this module contain extern functions? */
    char **exported_functions; /* List of exported function names */
    int function_count;
    char **exported_structs;   /* List of exported struct names */
    int struct_count;
} ModuleInfo;

/* Selective import tracking */
typedef struct {
    char *module_path;         /* Module file path */
    char **imported_symbols;   /* Symbols explicitly imported (NULL = all/wildcard) */
    int symbol_count;          /* Number of imported symbols (0 = wildcard) */
    bool is_wildcard;          /* true for "from module import *" */
} SelectiveImport;

/* Import tracking in Environment */
typedef struct {
    SelectiveImport *imports;
    int import_count;
    int import_capacity;
} ImportTracker;

/* I keep imported enum names as references, not duplicate declarations. */
typedef struct EnumImport {
    char *name;
    char *owner_module;
    char *target_name;
    struct EnumImport *next;
} EnumImport;

typedef struct EffectImport {
    char *name;
    char *owner_module;
    char *target_name;
    struct EffectImport *next;
} EffectImport;

typedef struct GlobalImport {
    const char *owner_file;
    const char *name;
    ASTNode *declaration;
    struct GlobalImport *next;
} GlobalImport;

/* Environment for variable and function storage */
typedef struct {
    Symbol *symbols;
    GlobalImport *global_imports;
    int symbol_count;
    int symbol_capacity;
    struct EnvCheckerAllocation *checker_allocations; /* Explicit checker-owned storage, independent of slots. */
    struct EnvSymbolIndex *symbol_index; /* Owned optional name index; slots remain authoritative. */
    Function *functions;
    struct EnvSymbolIndex *function_index; /* I index names; declarations remain authoritative. */
    int function_count;
    int function_capacity;
    StructDef *structs;
    int struct_count;
    int struct_capacity;
    EnumDef *enums;
    int enum_count;
    int enum_capacity;
    UnionDef *unions;
    int union_count;
    int union_capacity;
    OpaqueTypeDef *opaque_types;
    int opaque_type_count;
    int opaque_type_capacity;
    EffectDef *effects;          /* Registered algebraic effects */
    int effect_count;
    int effect_capacity;
    GenericInstantiation *generic_instances;
    int generic_instance_count;
    int generic_instance_capacity;
    GenericFuncInstance *generic_func_instances;   /* User-defined generic function instances */
    int generic_func_instance_count;
    int generic_func_instance_capacity;
    EnumImport *enum_imports;
    EffectImport *effect_imports;
    ModuleNamespace *namespaces;  /* Module alias → symbols mapping */
    int namespace_count;
    int namespace_capacity;
    char *current_module;  /* Currently active module name (NULL for global scope) */
    ImportTracker *import_tracker;  /* Track selective imports */
    bool builtins_registered;  /* Flag to prevent duplicate builtin registration */
    ModuleInfo *modules;  /* Module metadata for introspection */
    int module_count;
    int module_capacity;
    bool emit_module_metadata;  /* Emit ___module_* metadata functions in transpiled C (disable for module objects) */
    bool emit_c_main;  /* Emit C main()/g_argc/g_argv wrapper in transpiled C (disable for module objects) */
    bool current_module_is_unsafe;  /* Is the current module context unsafe? */
    /* Phase 3: Module safety warning flags */
    bool warn_unsafe_imports;  /* Warn when importing unsafe modules */
    bool warn_unsafe_calls;    /* Warn when calling functions from unsafe modules */
    bool warn_ffi;             /* Warn on any FFI call */
    bool forbid_unsafe;        /* Error (not warn) on unsafe modules */
    bool profile_gprof;        /* Enable gprof profiling analysis at exit */
    bool profile;              /* --profile: inject instrumented timing hooks into generated C */
    bool trace;                /* --trace: inject generated-C function-call tracing hooks */
    bool profile_runtime;      /* --profile-runtime: also emit flamegraph collapsed-stack .nano.prof file */

    const char *profile_output_path;     /* --profile-output: write structured JSON to this file (NULL = stdout only) */
    const char *profile_flamegraph_path; /* --profile-runtime <path>: write flamegraph .nano.prof (NULL = <input>.nano.prof) */
    bool suppress_shadow_warnings;  /* Suppress missing shadow test warnings (for test harnesses) */
    bool gpu_target;               /* --target ptx: suppress main() requirement and shadow warnings */

    /* Algebraic effects registry (opaque pointer; cast to EffectRegistry* in effects.c) */
    void *effect_registry;

    /* File whose code is being processed; stamped onto definitions and used to
     * keep source-position lookups inside one file. Borrowed, not owned. */
    const char *current_file;
    /* I own canonical origins for service-bearing source modules separately
     * from their declared names and import aliases. Indices remain stable. */
    char *service_origins[16];
    int service_origin_count;
    struct NlFileSourceSnapshots *service_inputs;
    struct NlServiceBodyCheck *service_bodies; /* Owned nominal body facts; not execution authority. */
    struct NlServiceOwnershipCheck *service_ownership; /* Owned lexical transfer facts. */
    struct NlServiceNamespace *service_namespace;
    int service_import_depth;
    size_t service_snapshot_indices[16];
    bool service_snapshot_bound[16];
    struct CheckedBorrowLedger *checked_borrow_facts; /* Owned only during checked emission. */
} Environment;

/* Function declarations */

/* Lexer */
Token *tokenize(const char *source, int *token_count);
void free_tokens(Token *tokens, int count);
const char *token_type_name(TokenType type);
const char *lexer_last_error_id(void);
const char *parser_last_error_id(void);

/* Parser */
typedef struct {
    Token *tokens;
    int count;
    int pos;
    int recursion_depth;  /* Track recursion depth to prevent stack overflow */
    int error_count;
    int last_error_line;
    int last_error_column;
    const char *last_error_message;
    /* Lambda hoisting: anonymous functions collected during expression parsing */
    struct ASTNode **lambda_functions;
    int lambda_count;
    int lambda_capacity;
} Stage1Parser;

ASTNode *parse_program(Token *tokens, int token_count);
bool ast_has_service_declaration(const ASTNode *program);
bool bind_service_origin(ASTNode *program, Environment *env, const char *source_file);
bool acquire_service_input(ASTNode *program, Environment *env);
bool ast_is_value_expression(ASTNodeType type);
bool ast_always_returns(const ASTNode *node);
ASTNode *parse_repl_input(Token *tokens, int token_count);  /* REPL variant: accepts statements at top level */
void free_ast(ASTNode *node);

/* Type Checker */
bool type_check(ASTNode *program, Environment *env);
bool type_check_module(ASTNode *program, Environment *env);  /* Type check without requiring main */
bool type_check_root_shadows(ASTNode *program, Environment *env);
/* I borrow checked callback metadata for map result allocation during lowering. */
Type map_transform_result_type(ASTNode *callback, Environment *env);
Type filter_predicate_element_type(ASTNode *callback, Environment *env);
unsigned typecheck_advisory_effects(Environment *env, ASTNode *body);
void typecheck_set_current_file(const char *path);
Type check_expression(ASTNode *expr, Environment *env);

/* Shadow-Test Runner */
bool run_shadow_tests(ASTNode *program, Environment *env, bool verbose);

/* Interpreter */
bool run_program(ASTNode *program, Environment *env);
Value call_function(const char *name, Value *args, int arg_count, Environment *env);
/* REPL support */
Value repl_eval_node(ASTNode *node, Environment *env);
void  repl_print_value(Value val);

/* C Transpiler */
char *transpile_to_c(ASTNode *program, Environment *env, const char *input_file);

/* Environment */
Environment *create_environment(void);
/* I invalidate cached names before replacing/appending symbols outside env_define_var. */
void env_symbol_index_invalidate(Environment *env);

/* The file whose code is currently being processed.
 *
 * Symbol lookups that reason about source position are only meaningful inside
 * one file, so definitions are stamped with this and located lookups ignore
 * symbols from elsewhere. Callers that walk a specific file's AST -- the
 * typechecker entering a module, codegen compiling an imported module's
 * bodies -- set it around that walk and restore it after. The string is
 * borrowed, not copied. */
void env_set_current_file(Environment *env, const char *path);
const char *env_current_file(Environment *env);
void free_environment(Environment *env);
/* Transfer one newly allocated checker-only block; NULL is a no-op.
 * Borrowed AST/signature blocks and runtime values must never enter this registry. */
void *env_own_checker_allocation(Environment *env, void *allocation);
bool env_import_global(Environment *env, const char *owner_file, const char *name, ASTNode *declaration);
const GlobalImport *env_lookup_global_import(Environment *env, const char *name);
const GlobalImport *env_lookup_global_import_at(Environment *env, const char *owner_file, const char *name);
Symbol *env_global_import_symbol(Environment *env, const char *name);
ASTNode *env_qualified_import_literal(Environment *env, ASTNode *expr);
Symbol *env_global_import_symbol_at(Environment *env, const char *owner_file, const char *name);
void env_define_var(Environment *env, const char *name, Type type, bool is_mut, Value value);
void env_define_string_copy(Environment *env, const char *name, Type type, bool is_mut, const char *text);
void env_define_var_with_element_type(Environment *env, const char *name, Type type, Type element_type, bool is_mut, Value value);
void env_define_var_with_type_info(Environment *env, const char *name, Type type, Type element_type, TypeInfo *type_info, bool is_mut, Value value);

/* I reclaim static-array containers and their owned elements when the
 * interpreter environment is torn down. Aliased containers are released once. */
void env_reclaim_static_arrays(Environment *env);

/* Diagnostic: number of static-array containers reclaimed at teardown. */
size_t env_static_array_reclaim_count(void);
Symbol *env_get_var(Environment *env, const char *name);
Symbol *env_get_declared_global(Environment *env, const ASTNode *declaration);
Symbol *env_get_var_visible_at(Environment *env, const char *name, int line, int column);
/* I accept the value just evaluated from this exact expression. */
void env_define_evaluated_var(Environment *env, const char *name, Type type, Type element_type,
                              TypeInfo *type_info, bool is_mut, Value value, ASTNode *expression);
void env_set_evaluated_var(Environment *env, const char *name, Value value, ASTNode *expression);
void env_set_evaluated_binding(Environment *env, Symbol *binding, Value value, ASTNode *expression);
void env_set_var(Environment *env, const char *name, Value value);
void env_define_function(Environment *env, Function func);
Function *env_get_function(Environment *env, const char *name);
Function *env_get_function_at(Environment *env, const char *name, int line, int column);
bool env_array_push_is_builtin(Environment *env, int line, int column);
const char *env_array_operation(Environment *env, ASTNode *call);
bool is_builtin_function(const char *name);
void env_define_struct(Environment *env, StructDef struct_def);
StructDef *env_get_struct(Environment *env, const char *name);
StructDef *env_get_struct_owned(Environment *env, const char *name, const char *owner);
bool bind_nominal_records(ASTNode *program, Environment *env);
bool bind_service_annotations(ASTNode *program, Environment *env, const char *source);
void env_register_namespace(Environment *env, const char *alias, const char *module_name,
                            char **function_names, int function_count,
                            char **struct_names, int struct_count,
                            char **enum_names, int enum_count,
                            char **union_names, int union_count);
/* Module introspection */
void env_register_module(Environment *env, const char *name, const char *path, bool is_unsafe);
ModuleInfo *env_get_module(Environment *env, const char *name);
bool env_is_current_module_unsafe(Environment *env);
void env_mark_module_has_ffi(Environment *env, const char *name);
void env_add_module_exported_function(Environment *env, const char *module_name, const char *function_name);
void env_add_module_exported_struct(Environment *env, const char *module_name, const char *struct_name);
void env_define_enum(Environment *env, EnumDef enum_def);
EnumDef *env_get_enum(Environment *env, const char *name);
bool env_import_enum(Environment *env, const char *alias, const EnumDef *target);
void env_register_list_instantiation(Environment *env, const char *element_type);
void env_register_hashmap_instantiation(Environment *env, const char *key_type, const char *value_type);
/* I return an owned recursive C specialization spelling. */
char *typeinfo_to_generic_arg_name(TypeInfo *info);
void env_register_union_instantiation(Environment *env, const char *union_name,
                                      const char **type_args, int type_arg_count);
int env_get_enum_variant(Environment *env, const char *variant_name);
/* I take ownership of a newly registered union and its allocated metadata. */
void env_define_union(Environment *env, UnionDef union_def);
UnionDef *env_get_union(Environment *env, const char *name);
void env_define_opaque_type(Environment *env, const char *name);
OpaqueTypeDef *env_get_opaque_type(Environment *env, const char *name);
int env_get_union_variant_index(Environment *env, const char *union_name, const char *variant_name);

/* Generic function instantiation registry */
void env_register_generic_func_instance(Environment *env, const char *orig_name, const char *mono_name,
                                         const char **var_names, Type *bound_types, const char **bound_type_names,
                                         int binding_count);

/* Effect system */
void env_define_effect(Environment *env, EffectDef effect_def);
EffectDef *env_get_effect(Environment *env, const char *name);
EffectDef *env_get_effect_owned(Environment *env, const char *name, const char *owner);
bool env_import_effect(Environment *env, const char *alias, const EffectDef *target);
bool env_effect_visible(Environment *env, const EffectDef *effect);
EffectOp *effect_get_op(EffectDef *effect, const char *op_name);

/* Utilities */
Type token_to_type(TokenType token);
const char *type_to_string(Type type);
Value create_int(long long val);
Value create_float(double val);
Value create_bool(bool val);
Value create_string(const char *val);
char *nl_unescape_string(const char *raw);
Value create_void(void);
Value create_array(ValueType elem_type, int length, int capacity);
Value create_struct(const char *struct_name, char **field_names, Value *field_values, int field_count);
Value create_union(const char *union_name, int variant_index, const char *variant_name, 
                   char **field_names, Value *field_values, int field_count);
Value create_function(const char *function_name, FunctionSignature *signature);

/* Function signature helpers */
FunctionSignature *create_function_signature(Type *param_types, int param_count, Type return_type);
FunctionSignature *function_signature_from_function(const Function *function);
FunctionSignature *copy_function_signature(const FunctionSignature *signature);
FunctionSignature *copy_contextual_callable_signature(ASTNode *value, Environment *env,
                                                      const FunctionSignature *expected);
void free_function_signature(FunctionSignature *sig);
bool function_signatures_equal(FunctionSignature *sig1, FunctionSignature *sig2);
bool type_infos_equal(const TypeInfo *left, const TypeInfo *right);
void free_type_info(TypeInfo *info);
TypeInfo *copy_payload_type_info(const TypeInfo *info);
const TypeInfo *tuple_element_info(const TypeInfo *info, int index, TypeInfo *fallback);
const TypeInfo *row_field_info(const TypeInfo *info, int index, TypeInfo *fallback);
void free_payload_type_info(TypeInfo *info);
TypeInfo *resolve_union_payload_type_info(const UnionDef *def, int arm, int field, const TypeInfo *arguments);

/* Tuple helpers */
Value create_tuple(Value *elements, int element_count);
void free_tuple(TupleValue *tuple);

/* Module loading */
typedef struct {
    char **module_paths;
    int count;
    int capacity;
} ModuleList;

bool type_check_shadow_scope(ASTNode *program, Environment *env, ModuleList *modules,
                             const char *input_file, bool include_imports);
bool run_shadow_tests_scope(ASTNode *program, Environment *env, ModuleList *modules,
                            const char *input_file, bool include_imports, bool verbose);

ModuleList *create_module_list(void);
void free_module_list(ModuleList *list);
void module_list_add(ModuleList *list, const char *module_path);
const char *resolve_module_path(const char *module_path, const char *current_file);
char *find_module_in_paths(const char *module_name);
char *unpack_module_package(const char *package_path, char *temp_dir_out, size_t temp_dir_size);
ASTNode *load_module(const char *module_path, Environment *env);
ASTNode *load_module_from_package(const char *package_path, Environment *env, char *temp_dir_out, size_t temp_dir_size);
ASTNode *get_cached_module_ast(const char *module_path);
char *module_program_name(ASTNode *program, const char *module_path);
int64_t module_get_import_count(const char *module_path);
const char *module_get_import_path(const char *module_path, int64_t index);
const char *module_generate_forward_declarations(const char *module_path);
bool process_imports(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file);
/* Only independently lowering File consumers may opt into retained facts. */
bool process_imports_for_service(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file);
void clear_module_cache(void);
bool compile_module_to_object(const char *module_path,
                              const char *output_obj,
                              Environment *env,
                              bool verbose,
                              char **extra_compile_flags,
                              size_t extra_compile_flags_count);
/* I return an owned module object fragment; callers free it on success or failure. */
bool module_is_ffi_only(const char *module_path);
bool compile_modules(ModuleList *modules, Environment *env, char **module_objs_buffer, char *compile_flags_buffer, size_t compile_flags_buffer_size, bool verbose);

/* Module metadata for serialization */
typedef struct {
    char *module_name;
    int function_count;
    Function *functions;  /* Array of function signatures */
    int struct_count;
    StructDef *structs;
    int enum_count;
    EnumDef *enums;
    int union_count;
    UnionDef *unions;
    int constant_count;
    ConstantDef *constants;  /* Constants from C headers (#define) or nanolang (let) */
} ModuleMetadata;

/* Module metadata serialization */
ModuleMetadata *extract_module_metadata(Environment *env, const char *module_name);
void free_module_metadata(ModuleMetadata *meta);
char *serialize_module_metadata_to_c(ModuleMetadata *meta);
char *serialize_module_metadata_for_source(ModuleMetadata *meta, const char *source);
bool deserialize_module_metadata_from_c(const char *c_code, ModuleMetadata **meta_out);
bool embed_metadata_in_module_c(char *c_code, ModuleMetadata *meta, size_t buffer_size);

/* Safe string utility functions - always use these instead of unsafe libc functions */
/* These functions handle NULL pointers gracefully and use bounded operations */

/* Safe strlen - returns 0 if str is NULL */
static inline size_t safe_strlen(const char *str) {
    return str ? strlen(str) : 0;
}

/* Safe strnlen - returns 0 if str is NULL, bounded by maxlen */
static inline size_t safe_strnlen(const char *str, size_t maxlen) {
    if (!str) return 0;
    size_t len = 0;
    while (len < maxlen && str[len] != '\0') len++;
    return len;
}

/* Safe strcmp - returns 0 if either string is NULL, otherwise compares */
static inline int safe_strcmp(const char *s1, const char *s2) {
    if (!s1 && !s2) return 0;
    if (!s1 || !s2) return (s1 ? 1 : -1);
    return strcmp(s1, s2);
}

/* Safe strncmp - returns 0 if either string is NULL, otherwise compares up to n chars */
static inline int safe_strncmp(const char *s1, const char *s2, size_t n) {
    if (!s1 && !s2) return 0;
    if (!s1 || !s2) return (s1 ? 1 : -1);
    return strncmp(s1, s2, n);
}

/* Safe strcpy replacement - use strncpy with explicit null termination */
static inline char *safe_strncpy(char *dest, const char *src, size_t dest_size) {
    if (!dest || dest_size == 0) return dest;
    if (!src) {
        dest[0] = '\0';
        return dest;
    }
    size_t src_len = safe_strnlen(src, dest_size - 1);
    memcpy(dest, src, src_len);
    dest[src_len] = '\0';
    return dest;
}

/* Safe strcat replacement - use memcpy with bounds checking */
static inline char *safe_strncat(char *dest, const char *src, size_t dest_size) {
    if (!dest || dest_size == 0) return dest;
    if (!src) return dest;
    size_t dest_len = safe_strnlen(dest, dest_size);
    if (dest_len >= dest_size - 1) return dest; /* No room */
    size_t avail = dest_size - dest_len - 1;
    size_t src_len = safe_strnlen(src, avail);
    memcpy(dest + dest_len, src, src_len);
    dest[dest_len + src_len] = '\0';
    return dest;
}

/* Helper to sanitize string arguments for format strings - replaces NULL with "(NULL)" */
static inline const char *safe_format_string(const char *str) {
    return str ? str : "(NULL)";
}

/* Safe fprintf wrapper - uses vsnprintf with buffer and NULL checks */
/* NOTE: For %s format specifiers, use safe_format_string() on string arguments */
static inline int safe_fprintf(FILE *stream, const char *format, ...) {
    assert(stream != NULL);
    assert(format != NULL);
    if (!stream || !format) return -1;
    
    char buffer[4096];
    va_list args;
    va_start(args, format);
    int result = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    if (result < 0) return -1;
    if (result >= (int)sizeof(buffer)) {
        /* Truncated - use a larger buffer */
        char *large_buffer = malloc(result + 1);
        if (!large_buffer) return -1;
        va_start(args, format);
        vsnprintf(large_buffer, result + 1, format, args);
        va_end(args);
        fputs(large_buffer, stream);
        free(large_buffer);
        return result;
    }
    
    fputs(buffer, stream);
    return result;
}

/* Safe sprintf replacement - always use snprintf with explicit size */
static inline int safe_snprintf(char *dest, size_t dest_size, const char *format, ...) {
    assert(dest != NULL);
    assert(format != NULL);
    if (!dest || dest_size == 0 || !format) return -1;
    
    va_list args;
    va_start(args, format);
    int result = vsnprintf(dest, dest_size, format, args);
    va_end(args);
    
    if (result >= (int)dest_size) {
        dest[dest_size - 1] = '\0'; /* Ensure null termination */
    }
    return result;
}

/* Safe printf wrapper */
static inline int safe_printf(const char *format, ...) {
    assert(format != NULL);
    if (!format) return -1;
    
    char buffer[4096];
    va_list args;
    va_start(args, format);
    int result = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    if (result < 0) return -1;
    if (result >= (int)sizeof(buffer)) {
        char *large_buffer = malloc(result + 1);
        if (!large_buffer) return -1;
        va_start(args, format);
        vsnprintf(large_buffer, result + 1, format, args);
        va_end(args);
        fputs(large_buffer, stdout);
        free(large_buffer);
        return result;
    }
    
    fputs(buffer, stdout);
    return result;
}

/* Print backtrace to stderr */
static inline void print_backtrace(void) {
#if defined(__APPLE__) || defined(__linux__)
    void *array[64];
    int size = backtrace(array, 64);
    char **symbols = backtrace_symbols(array, size);
    
    if (symbols) {
        safe_fprintf(stderr, "\n=== Backtrace ===\n");
        for (int i = 0; i < size; i++) {
            safe_fprintf(stderr, "  [%d] %s\n", i, safe_format_string(symbols[i]));
        }
        safe_fprintf(stderr, "==================\n\n");
        free(symbols);
    } else {
        safe_fprintf(stderr, "\n=== Backtrace (symbols unavailable) ===\n");
        safe_fprintf(stderr, "  %d stack frames\n", size);
        safe_fprintf(stderr, "========================================\n\n");
    }
#else
    safe_fprintf(stderr, "\n=== Backtrace not available on this platform ===\n\n");
#endif
}

/* Don't redefine assert - use standard library version */
/* Enhanced assert macro with backtrace */
#ifdef NDEBUG
/* #define assert(expr) ((void)0) */
#else
/* #define assert(expr) \
    do { \
        if (!(expr)) { \
            safe_fprintf(stderr, "\nAssertion failed: %s\n", #expr); \
            safe_fprintf(stderr, "File: %s, Line: %d\n", __FILE__, __LINE__); \
            print_backtrace(); \
            abort(); \
        } \
    } while(0) */
#endif

/* Project root resolution (set by main.c, used by module.c for CWD-independent paths) */
const char *get_project_root(void);

/* GPU intrinsic stubs — forward declarations for C code generated from gpu fn bodies.
 * Defined in modules/gpu/cuda_runtime.c; stubs return 0/void on the host.
 * The PTX backend emits real special-register reads for these when targeting GPU. */
int64_t nl_gpu_thread_id_x(void);
int64_t nl_gpu_thread_id_y(void);
int64_t nl_gpu_thread_id_z(void);
int64_t nl_gpu_block_id_x(void);
int64_t nl_gpu_block_id_y(void);
int64_t nl_gpu_block_id_z(void);
int64_t nl_gpu_block_dim_x(void);
int64_t nl_gpu_block_dim_y(void);
int64_t nl_gpu_block_dim_z(void);
int64_t nl_gpu_grid_dim_x(void);
int64_t nl_gpu_grid_dim_y(void);
int64_t nl_gpu_grid_dim_z(void);
int64_t nl_gpu_global_id_x(void);
int64_t nl_gpu_global_id_y(void);
void    nl_gpu_barrier(void);
/* GPU global memory intrinsics (PTX ld.global / st.global) */
int64_t nl_gpu_load(int64_t ptr);
void    nl_gpu_store(int64_t ptr, int64_t val);
double  nl_gpu_load_float(int64_t ptr);
void    nl_gpu_store_float(int64_t ptr, double val);

bool passive_expression_reads_name(const ASTNode *node, const char *name);
int *passive_binding_order(const ASTNode *block); /* Owned result; NULL refuses the graph. */

#endif /* NANOLANG_H */
