"""I retain original REPL inputs, case directories and native observations."""
from pathlib import Path
import os,sys,json,time,tempfile,unittest,traceback,base64
r=Path.cwd();out=Path(sys.argv[1]);out.mkdir(exist_ok=True);sys.path.insert(0,str(r));import tests.native_process as native
original=native.run_captured;calls=[];original_tempdir=tempfile.TemporaryDirectory
class RetainedDirectory(original_tempdir):
 def __init__(self,*args,**kwargs):
  if kwargs.get('dir') is None:kwargs['dir']=str(out)
  super().__init__(*args,**kwargs);self._finalizer.detach()
 def cleanup(self):pass
tempfile.TemporaryDirectory=RetainedDirectory
def captured(args,*a,**kw):
 i=len(calls);row=dict(args=list(map(str,args)),timeout=kw.get('timeout'),cwd=str(kw.get('cwd',r)));calls.append(row)
 source=kw.get('stdin')
 if source is not None:
  raw=os.pread(source.fileno(),os.fstat(source.fileno()).st_size,0);(out/(str(i)+'-stdin')).write_bytes(raw)
 t=time.monotonic()
 try:
  result=original(args,*a,**kw);row['exit']=result.returncode
  (out/(str(i)+'-stdout')).write_bytes(result.stdout);(out/(str(i)+'-stderr')).write_bytes(result.stderr)
  return result
 except BaseException as e:row['exception']=repr(e);raise
 finally:
  row['seconds']=time.monotonic()-t;(out/'calls.json').write_text(json.dumps(calls,indent=2)+'\n')
native.run_captured=captured
suite=unittest.defaultTestLoader.loadTestsFromNames(sys.argv[2:]);start=time.monotonic()
with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
summary=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),seconds=time.monotonic()-start,calls=len(calls),modules=sys.argv[2:]);(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True);sys.exit(0 if result.wasSuccessful() else 1)
