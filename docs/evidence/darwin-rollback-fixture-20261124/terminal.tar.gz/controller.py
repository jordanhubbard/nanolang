"""I qualify a pinned source in three new local Darwin worktrees."""
from pathlib import Path
import os,sys,json,time,subprocess,hashlib,shlex,signal,traceback,resource,shutil
w=Path(__file__).resolve().parent;cfg=json.loads((w/'config.json').read_text());pre=json.loads((w/'preflight.json').read_text());pin=cfg['pin'];env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0');removed={k:env.pop(k) for k in cfg['remove_overrides'] if k in env};env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1',TMPDIR=str(w/'tmp'));(w/'tmp').mkdir(exist_ok=True);cc=pre['tools']['cc']['path'];make=pre['tools']['make']['path'];git=pre['tools']['git']['path'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();q=dict(source_pin=pin,work=str(w),host=pre['host'],profiles=[],commands=[],health=[],source_stages=[],removed_build_overrides=removed,leak_sanitizer='unsupported Darwin; original platform guard detect_leaks=0',make_trace='not available in installed GNU Make3.81; original recipes and command output retained',terminal=False,ordinary_ownership_enabled=False,raw_bootstrap=False,whole_release=False)
def save():(w/'result.json').write_text(json.dumps(q,indent=2)+'\n')
def run(label,args,cwd=w,timeout=180,extra=None,input=None):
 e=dict(env);e.update(extra or {});start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (w/(label+'.stdout')).open('wb') as out,(w/(label+'.stderr')).open('wb') as err:
  p=subprocess.Popen(list(map(str,args)),cwd=cwd,env=e,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);row=dict(label=label,args=list(map(str,args)),cwd=str(cwd),timeout=timeout,pid=p.pid);q['commands'].append(row);save();print(label,'LIVE',p.pid,flush=True)
  try:
   if input is not None:p.communicate(input=input,timeout=timeout)
   else:p.wait(timeout=timeout)
   row.update(exit=p.returncode,timed_out=False)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);row.update(exit=p.wait(),timed_out=True)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(seconds=time.monotonic()-start,user_seconds=after.ru_utime-before.ru_utime,system_seconds=after.ru_stime-before.ru_stime);save();print(label,'TERMINAL',row['exit'],row['seconds'],flush=True);return row
def checked(*a,**kw):
 row=run(*a,**kw);assert row['exit']==0 and not row['timed_out'],(row['label'],row['exit']);return row
def guard(tree):return {name:sha(tree/name) for name in cfg['sources']}
def outputs(tree):return {str(p.relative_to(tree)):dict(bytes=p.stat().st_size,sha256=sha(p)) for name in ['obj','lib','bin'] for p in sorted((tree/name).rglob('*')) if p.is_file()}
def health(label):
 r=dict(label=label,loadavg=os.getloadavg(),native=[],rounds=[]);p=subprocess.run(['/bin/ps','-axo','pid=,command='],env=env,capture_output=True,text=True,timeout=15)
 for line in p.stdout.splitlines():
  bits=line.strip().split(None,1)
  if len(bits)!=2 or int(bits[0])==os.getpid():continue
  name=bits[1].lower();first=name.split()[0] if name else ''
  if ('nanolang' in name and str(w).lower() not in name) or os.path.basename(first).startswith(('nanoc','nano_vm','nano_virt','nanoisa','nvm2c')):r['native'].append(line.strip())
 q['health'].append(r);save();assert not r['native'],r['native'];assert os.statvfs(w).f_bavail*os.statvfs(w).f_frsize>10*1024**3
 for n in range(3):
  start=time.monotonic();cpu=time.process_time();count=0
  while time.monotonic()-start<1.5:hashlib.sha256(b'x'*4096).digest();count+=1
  wall=time.monotonic()-start;used=time.process_time()-cpu;item=dict(round=n,wall=wall,cpu=used,share=used/wall,iterations=count);r['rounds'].append(item);save();assert used>=1 and used/wall>=.75,item
 print(label,'ADMITTED',[round(v['share'],4) for v in r['rounds']],flush=True)
rc=2;save()
try:
 assert pre['admitted'];tools={v['path']:sha(v['path']) for v in pre['tools'].values()};tools[pre['actual_clang']]=sha(pre['actual_clang'])
 for name in ['as','ld','ar','git']:
  p=subprocess.run(['/usr/bin/xcrun','--find',name],env=env,capture_output=True,text=True,timeout=15)
  if p.returncode==0 and Path(p.stdout.strip()).is_file():tools[p.stdout.strip()]=sha(p.stdout.strip())
 for name in ['SDKSettings.json','SDKSettings.plist']:
  p=Path(pre['sdk'])/name
  if p.is_file():tools[str(p)]=sha(p)
 q['tools_before']=tools;save();normal=w/'source-normal';checked('git-init',[git,'init','-q',normal]);checked('git-remote',[git,'remote','add','origin','https://github.com/jordanhubbard/nanolang.git'],cwd=normal);checked('git-promisor',[git,'config','remote.origin.promisor','true'],cwd=normal);checked('git-filter',[git,'config','remote.origin.partialclonefilter','blob:none'],cwd=normal);checked('git-fetch',[git,'fetch','--depth=1','--filter=blob:none','origin',pin],cwd=normal,timeout=300)
 plan=w/'provider-plan.mk';names=['CFLAGS','LDFLAGS','COMPILER_OBJECTS','REPL_OBJECTS','DARWIN_SDKROOT','LIBFFI_CFLAGS','OPENSSL_PREFIX'];plan.write_text('\n'.join('$(info __PLAN_'+name+'__ $('+name+'))' for name in names)+'\n.PHONY: qualification_plan\nqualification_plan:\n\t@:\n');(w/'environment.c').write_text(cfg['private_shim'])
 targets=['test-gc-shutdown-sanitizers','test-env-scoping','test-source-c-imports','test-checker-owned-contexts','test-module-rejection-rollback','test-repl-callable-lifetimes','test-repl-state','test-repl-session']
 for mode in ['normal','san','production']:
  tree=w/('source-'+mode)
  if mode!='normal':checked(mode+'-worktree',[git,'worktree','add','--detach','--no-checkout',tree,pin],cwd=normal)
  checked(mode+'-sparse',[git,'sparse-checkout','set','--no-cone','--stdin'],cwd=tree,input=('\n'.join(cfg['sparse_patterns'])+'\n').encode());checked(mode+'-checkout',[git,'reset','--hard',pin],cwd=tree);profile=dict(mode=mode,tree=str(tree),initial_outputs={n:(tree/n).exists() for n in ['obj','lib','bin']});q['profiles'].append(profile);assert not any(profile['initial_outputs'].values());profile['before']=guard(tree);assert profile['before']==cfg['sources'];save();health(mode+'-build')
  flags=cfg['flags'][mode];base=[make,'-j1','-f','Makefile.gnu','--no-print-directory','CC='+cc,'CFLAGS='+' '.join(flags)];profile['base']=base;checked(mode+'-plan',base+['-f',str(plan),'qualification_plan'],cwd=tree);variables={}
  for line in (w/(mode+'-plan.stdout')).read_text().splitlines():
   if line.startswith('__PLAN_'):name,value=line[7:].split('__',1);variables[name]=value.strip()
  assert set(variables)==set(names);profile['variables']=variables;save();profile['build']=checked(mode+'-build',base+['bin/nanoc_c','bin/nano_vm','bin/nvm2c','bin/nanoisa'],cwd=tree,timeout=1800);assert guard(tree)==profile['before'];image=tree/'bin/nanoc_c';raw=image.read_bytes()[:32];assert raw[:4]==b'\xcf\xfa\xed\xfe' and int.from_bytes(raw[4:8],'little')==0x100000c;profile['image_sha256']=sha(image);checked(mode+'-help',[image,'--help'],cwd=tree,timeout=10)
  if mode=='normal':
   checked('normal-tool-controls',[sys.executable,w/'observe-tools.py',tree,w/'tool-cases'],cwd=tree,timeout=180);q['tool_controls']=json.loads((w/'tool-cases/result.json').read_text());assert q['tool_controls']==dict(tests=1,failures=0,errors=0,skips=0,calls=20);save()
  cases=w/(mode+'-source-cases');cases.mkdir();profile['source_cases']=str(cases);profile['focused']=checked(mode+'-focused',base+targets,cwd=tree,timeout=600,extra=dict(NANO_SOURCE_C_OUTPUT_ROOT=str(cases)));profile['after_focused']=guard(tree);assert profile['before']==profile['after_focused'];profile['outputs']=outputs(tree);save()
  effective=[cc,*shlex.split(variables['CFLAGS'])];factory=w/(mode+'-environment.o');adapter=w/(mode+'-shim.o');checked(mode+'-factory',effective+['-Dcreate_environment=nano_repl_legacy_environment','-c','src/env.c','-o',factory],cwd=tree);checked(mode+'-shim',effective+['-c',w/'environment.c','-o',adapter],cwd=tree);objects=shlex.split(variables['REPL_OBJECTS']);assert objects.count('obj/env.o')==1;objects=[str(factory) if p=='obj/env.o' else p for p in objects]+[str(adapter)];private_repl=tree/'bin/nanolang_private';checked(mode+'-private-repl-link',base+['REPL_BINARY=bin/nanolang_private','REPL_OBJECTS='+' '.join(objects),'bin/nanolang_private'],cwd=tree)
  observed=w/(mode+'-private-repl-cases');checked(mode+'-private41',[sys.executable,w/'observe-repl.py',observed,'tests.test_repl_callable_lifetimes','tests.test_repl_state','tests.test_repl_session','tests.test_repl_admission'],cwd=tree,timeout=180,extra=dict(NANO_REPL=str(private_repl),NANO_REPL_SAVE_FAULTS=str(tree/'obj/repl_save_faults.so')));profile['private_repl']=json.loads((observed/'result.json').read_text());assert profile['private_repl']['tests']==41 and profile['private_repl']['failures']==profile['private_repl']['errors']==0;profile['private_repl_image']=dict(path=str(private_repl),sha256=sha(private_repl));profile['after_private_repl']=guard(tree);assert profile['before']==profile['after_private_repl'];save()
  if mode=='normal':
   objects=shlex.split(variables['COMPILER_OBJECTS']);assert objects.count('obj/env.o')==1;objects=[str(factory) if p=='obj/env.o' else p for p in objects]+[str(adapter)];checked('private-compiler-link',base+['COMPILER_C=bin/nanoc_private','COMPILER_OBJECTS='+' '.join(objects),'bin/nanoc_private'],cwd=tree);q['private_compiler_image']=dict(path=str(tree/'bin/nanoc_private'),sha256=sha(tree/'bin/nanoc_private'));q['normal_base']=base;save()
 normal_profile=q['profiles'][0];tree=Path(normal_profile['tree'])
 for name,image in [('ordinary',tree/'bin/nanoc_c'),('private',tree/'bin/nanoc_private')]:
  health(name+'-source');folder=w/(name+'-source');folder.mkdir();row=run(name+'-source',[image,tree/'src_nano/nanoc_v06.nano','-o',folder/'seed'],cwd=tree,timeout=600,extra=dict(NANO_SHADOW_TRACE='1',NANO_SHADOW_PHASE_TRACE='1'));events=[]
  for line in (w/(name+'-source.stderr')).read_text(errors='replace').splitlines():
   try:events.append(json.loads(line))
   except ValueError:pass
  stage=dict(name=name,command=row,starts=sum(e.get('event')=='shadow-start' for e in events),completions=sum(e.get('event')=='shadow-complete' for e in events),failed_shadows=[e for e in events if e.get('event')=='shadow-complete' and e.get('failures',0)>0],phases=[e for e in events if e.get('event')=='cseed-shadow-phase'],after=guard(tree));q['source_stages'].append(stage);save();assert stage['after']==cfg['sources'];assert row['exit']==0 and not row['timed_out'] and stage['starts']==stage['completions']==1306 and not stage['failed_shadows'];stage['product']=dict(path=str(folder/'seed'),bytes=(folder/'seed').stat().st_size,sha256=sha(folder/'seed'));stage['help']=checked(name+'-seed-help',[folder/'seed','--help'],cwd=tree,timeout=10);save()
 q['tools_after']={p:sha(p) for p in tools};assert tools==q['tools_after'];rc=0
except BaseException as error:
 q['exception']=repr(error);(w/'exception.log').write_text(traceback.format_exc());print('I retain terminal',repr(error),flush=True)
finally:
 if 'tools_before' in q:q['tools_at_terminal']={p:sha(p) for p in q['tools_before']}
 q.update(terminal=True,controller_exit=rc);save()
sys.exit(rc)
