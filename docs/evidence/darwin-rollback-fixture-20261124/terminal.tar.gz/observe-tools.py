"""I retain one original VM/native test without changing its assertions or limits."""
from pathlib import Path
import sys,tempfile,unittest,json,time
r=Path.cwd();sys.path.insert(0,str(r));root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir();original=tempfile.TemporaryDirectory
class RetainedDirectory(original):
 def __init__(self,*a,**kw):
  if kw.get('dir') is None:kw['dir']=out
  super().__init__(*a,**kw);self._finalizer.detach()
 def cleanup(self):pass
tempfile.TemporaryDirectory=RetainedDirectory
import tests.test_one_ir_compiler as m
m.ROOT=root;run=m.run_captured;calls=[]
def observe(args,**kw):
 row=dict(args=list(map(str,args)),timeout=kw.get('timeout'),cwd=str(kw.get('cwd',r)));calls.append(row);t=time.monotonic()
 try:
  result=run(args,**kw);row['exit']=result.returncode;(out/(str(len(calls)-1)+'.stdout')).write_bytes(result.stdout);(out/(str(len(calls)-1)+'.stderr')).write_bytes(result.stderr);return result
 finally:row['seconds']=time.monotonic()-t;(out/'calls.json').write_text(json.dumps(calls,indent=2)+'\n')
m.run_captured=observe
suite=unittest.TestSuite([m.OneIrCompiler('test_void_locals_preserve_tags_through_calls_and_tail_restarts')])
with (out/'tests.log').open('w') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
q=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),calls=len(calls));(out/'result.json').write_text(json.dumps(q,indent=2)+'\n');print(q,flush=True);sys.exit(0 if result.wasSuccessful() else 1)
