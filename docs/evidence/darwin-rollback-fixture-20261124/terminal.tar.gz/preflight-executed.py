"""I admit only a new local Darwin qualification root, never a NAS path."""
from pathlib import Path
import os,json,platform,subprocess,time,tempfile,shutil,hashlib,sys
root=Path(tempfile.mkdtemp(prefix='nanolang-source-qual-20261124-',dir='/private/tmp'));env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0');keys=['NANOLANG_ROOT','NANOLANG_COMPILER','NANOLANG_SELFHOST_COMPILER','NANO_CC','CC','CFLAGS','CXXFLAGS','LDFLAGS','CPPFLAGS','NANO_CFLAGS','NANO_LDFLAGS','NANO_SHADOW_TIMEOUT_SECONDS','NANO_SHADOW_ROOT_ONLY','NANO_LLM_SHADOW_JSON','CPATH','C_INCLUDE_PATH','LIBRARY_PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','PKG_CONFIG_PATH','SDKROOT','DEVELOPER_DIR'];removed={k:env.pop(k) for k in keys if k in env};q=dict(root=str(root),host=platform.node(),system=platform.system(),machine=platform.machine(),loadavg=os.getloadavg(),removed_build_overrides=removed,rounds=[],native=[],tools={},commands=[],admitted=False);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save():(root/'preflight.json').write_text(json.dumps(q,indent=2)+'\n')
def command(label,args,timeout=15):
 t=time.monotonic();p=subprocess.run(args,cwd=root,env=env,capture_output=True,timeout=timeout);(root/(label+'.stdout')).write_bytes(p.stdout);(root/(label+'.stderr')).write_bytes(p.stderr);q['commands'].append(dict(label=label,args=args,exit=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,p.stderr.decode(errors='replace');return p.stdout.decode()
save()
try:
 assert q['system']=='Darwin' and q['machine']=='arm64';s=os.statvfs(root);q['free_bytes']=s.f_bavail*s.f_frsize;assert q['free_bytes']>15*1024**3
 process=command('processes',['/bin/ps','-axo','pid=,command='])
 for line in process.splitlines():
  parts=line.strip().split(None,1)
  if len(parts)!=2:continue
  lower=parts[1].lower()
  if 'nanolang' in lower or any('/'+n in lower for n in ['nanoc','nano_vm','nano_virt','nvm2c']):q['native'].append(line.strip())
 assert not q['native'],q['native']
 q['vm_stat']=command('vm-stat',['/usr/bin/vm_stat']);q['cpu_memory']=command('cpu-memory',['/usr/sbin/sysctl','-n','hw.ncpu','hw.memsize']);save()
 for n in range(3):
  t=time.monotonic();cpu=time.process_time();count=0
  while time.monotonic()-t<1.5:hashlib.sha256(b'x'*4096).digest();count+=1
  wall=time.monotonic()-t;used=time.process_time()-cpu;row=dict(round=n,wall=wall,cpu=used,share=used/wall,iterations=count);q['rounds'].append(row);save();assert used>=1 and used/wall>=.75,row
 for name in ['git','cc','pkg-config','ar','as','ld','xcrun']:
  p=shutil.which(name,path=env['PATH']);assert p,name;q['tools'][name]=dict(path=p,sha256=sha(p))
 make=shutil.which('gmake',path=env['PATH']) or shutil.which('make',path=env['PATH']);assert make;q['tools']['make']=dict(path=make,sha256=sha(make));q['make_version']=command('make-version',[make,'--version']);assert 'GNU Make' in q['make_version'];q['cc_version']=command('cc-version',[q['tools']['cc']['path'],'--version']);q['sdk']=command('sdk',['/usr/bin/xcrun','--show-sdk-path']).strip();q['actual_clang']=command('actual-clang',['/usr/bin/xcrun','--find','clang']).strip();q['actual_clang_sha256']=sha(q['actual_clang']);q['pkg_flags']=command('pkg-flags',[q['tools']['pkg-config']['path'],'--cflags','--libs','openssl','libffi']);q['os_version']=command('os-version',['/usr/bin/sw_vers']);q['admitted']=True;save()
except BaseException as e:q['exception']=repr(e);save()
print(json.dumps(q,indent=2),flush=True);sys.exit(0 if q['admitted'] else 1)
