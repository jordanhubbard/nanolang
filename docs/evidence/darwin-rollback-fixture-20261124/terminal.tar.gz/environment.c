/* I enable the existing full collector only in this private qualification image. */
#include "nanolang.h"
#include "eval/carrier_runtime.h"
#include <stdio.h>
#include <stdlib.h>
extern Environment *nano_repl_legacy_environment(void);
Environment *create_environment(void) {
    Environment *env = nano_repl_legacy_environment();
    if (!env_carrier_enable(env) || !env_carrier_enable_collection(env, NULL, 0)) {
        fputs("I cannot enable private REPL collector qualification.\n", stderr);
        exit(1);
    }
    return env;
}
