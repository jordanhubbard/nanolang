	.file	"answer.c"
	.text
	.globl	nano_build_answer               # -- Begin function nano_build_answer
	.p2align	4
	.type	nano_build_answer,@function
nano_build_answer:                      # @nano_build_answer
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	movl	$42, %eax
	popq	%rbp
	.cfi_def_cfa %rsp, 8
	retq
.Lfunc_end0:
	.size	nano_build_answer, .Lfunc_end0-nano_build_answer
	.cfi_endproc
                                        # -- End function
	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
