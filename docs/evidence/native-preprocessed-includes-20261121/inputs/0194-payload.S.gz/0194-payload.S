#define INSTRUCTION nop
.include "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/1/native-nop-include-plain/debug macro.s"
.text
INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
