#define INSTRUCTION nop
.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-original-includes/debug macro.s"
.text
step INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
read_payload "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-original-includes/debug payload.bin"
