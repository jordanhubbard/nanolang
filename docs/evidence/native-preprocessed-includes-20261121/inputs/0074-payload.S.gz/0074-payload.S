#define INSTRUCTION nop
.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-step/debug macro.s"
.text
step INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
