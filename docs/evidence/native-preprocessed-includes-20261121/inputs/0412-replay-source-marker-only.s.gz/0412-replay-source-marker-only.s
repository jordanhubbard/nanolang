# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-plain/payload.S"

.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-plain/debug macro.s"
.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
