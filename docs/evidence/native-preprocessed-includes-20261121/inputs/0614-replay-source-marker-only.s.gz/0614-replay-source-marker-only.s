# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/1/native-nop-include-step/payload.S"

.include "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/1/native-nop-include-step/debug macro.s"
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
