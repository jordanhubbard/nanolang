from pathlib import Path
import gzip,hashlib,json
base=Path('.test_output');dest=Path('docs/evidence/native-preprocessed-includes-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__),Path('scripts/ci_source_capture_diagnostic.py')}
for name in ['native-preprocessed-44945288089','native-includes-44947026342','native-replay-44950231043','native-includes-local-controls','source-capture-diagnostic']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
sha=lambda b:hashlib.sha256(b).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,limits=['I retain native selected-tool provenance failures and diagnostic counterfactuals without changing admission or original assertions.']),indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
