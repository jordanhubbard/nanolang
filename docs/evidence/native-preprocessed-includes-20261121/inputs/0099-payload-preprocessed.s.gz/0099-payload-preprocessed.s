# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/payload.S"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 409 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/payload.S" 2

.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
