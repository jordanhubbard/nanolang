# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-inline-step/payload.S"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 409 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-inline-step/payload.S" 2

.macro read_payload path
.incbin "\path"
.endm
.macro step operation
\operation
.endm
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
