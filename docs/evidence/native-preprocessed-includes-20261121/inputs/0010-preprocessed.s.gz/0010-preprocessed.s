# 0 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/native-nop-include-plain/payload.S"
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/native-nop-include-plain//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/native-nop-include-plain/payload.S"

.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/native-nop-include-plain/debug macro.s"
.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
