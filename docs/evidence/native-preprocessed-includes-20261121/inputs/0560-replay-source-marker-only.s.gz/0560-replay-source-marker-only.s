# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/payload.S"

.include "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/debug macro.s"
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
read_payload "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/debug payload.bin"
