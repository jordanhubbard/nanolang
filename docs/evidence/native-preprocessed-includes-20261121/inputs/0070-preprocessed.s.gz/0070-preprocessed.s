# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-plain/payload.S"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 409 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-plain/payload.S" 2

.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-plain/debug macro.s"
.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
