# 0 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/payload.S"
# 1 "/home/runner/work/nanolang/nanolang//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/0/payload.S"

.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
