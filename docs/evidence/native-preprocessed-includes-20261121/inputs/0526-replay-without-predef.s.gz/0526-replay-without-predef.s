# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-include-step/payload.S"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-include-step//"
# 0 "<built-in>"
# 0 "<command-line>"
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-include-step/payload.S"

.include "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-include-step/debug macro.s"
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
