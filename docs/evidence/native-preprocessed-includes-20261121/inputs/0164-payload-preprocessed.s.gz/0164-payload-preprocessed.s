# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/payload.S"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/payload.S"

.text
nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
