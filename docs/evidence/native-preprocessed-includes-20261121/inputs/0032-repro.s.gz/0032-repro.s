# 1 "payload.S"
.macro read_payload path
.incbin "\path"
.endm
.macro step operation
\operation
.endm
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
