# 1 "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-step/payload.S"

.include "/home/runner/work/nanolang/nanolang/.test_output/source-capture-diagnostic/1/native-nop-include-step/debug macro.s"
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
