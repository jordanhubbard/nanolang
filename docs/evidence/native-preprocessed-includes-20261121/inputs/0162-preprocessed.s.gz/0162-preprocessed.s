# 0 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/payload.S"
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/payload.S"

.include "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/debug macro.s"
.text
step nop
.data
.globl snapshot_payload
snapshot_payload:
read_payload "/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/source-capture-diagnostic/0/native-nop-original-includes/debug payload.bin"
