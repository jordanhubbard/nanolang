#define INSTRUCTION nop
.macro read_payload path
.incbin "\path"
.endm
.macro step operation
\operation
.endm
.text
step INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
.byte 42
