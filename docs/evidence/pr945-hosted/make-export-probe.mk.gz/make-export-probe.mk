LDFLAGS = default
override LDFLAGS += appended
all:
	@printf "make origin=%s value=%s\n" "$(origin LDFLAGS)" "$(LDFLAGS)"
	@python3 -c 'import os; print("environment LDFLAGS="+repr(os.environ.get("LDFLAGS")))'
