.PHONY: artifact-loader-controls
artifact-loader-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /home/jkh/nanolang-qualification/loader-91dc-linux/ordinary/source/tests/nanovm/test_loader_fork_admission.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /home/jkh/nanolang-qualification/loader-91dc-linux/ordinary/tmp/nano-compiler-support-adapters-z6ijdkdp/loader-controls
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /home/jkh/nanolang-qualification/loader-91dc-linux/ordinary/source/tests/native_sdk_probe.c -DNANO_SDK_PROBE_CAPTURE_EXIT $(LDFLAGS) -o /home/jkh/nanolang-qualification/loader-91dc-linux/ordinary/tmp/nano-compiler-support-adapters-z6ijdkdp/sdk-probe
