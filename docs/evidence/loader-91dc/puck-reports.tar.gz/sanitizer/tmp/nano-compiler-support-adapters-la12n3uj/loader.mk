.PHONY: artifact-loader-controls
artifact-loader-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/loader-91dc-puck/sanitizer/source/tests/nanovm/test_loader_fork_admission.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /Users/jkh/nanolang-qualification/loader-91dc-puck/sanitizer/tmp/nano-compiler-support-adapters-la12n3uj/loader-controls
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/loader-91dc-puck/sanitizer/source/tests/native_sdk_probe.c -DNANO_SDK_PROBE_CAPTURE_EXIT $(LDFLAGS) -o /Users/jkh/nanolang-qualification/loader-91dc-puck/sanitizer/tmp/nano-compiler-support-adapters-la12n3uj/sdk-probe
