.PHONY: artifact-loader-controls
artifact-loader-controls:
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/loader-91dc-puck/ordinary/source/tests/nanovm/test_loader_fork_admission.c $(OBJ_DIR)/runtime/module_build_dir.o $(LDFLAGS) -o /Users/jkh/nanolang-qualification/loader-91dc-puck/ordinary/tmp/nano-compiler-support-adapters-txfgpy0g/loader-controls
	$(CC) $(CFLAGS) -D_GNU_SOURCE -pthread /Users/jkh/nanolang-qualification/loader-91dc-puck/ordinary/source/tests/native_sdk_probe.c -DNANO_SDK_PROBE_CAPTURE_EXIT $(LDFLAGS) -o /Users/jkh/nanolang-qualification/loader-91dc-puck/ordinary/tmp/nano-compiler-support-adapters-txfgpy0g/sdk-probe
