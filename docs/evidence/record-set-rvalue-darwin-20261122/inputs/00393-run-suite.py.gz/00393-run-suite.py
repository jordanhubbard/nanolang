from pathlib import Path
import os,sys,json,time,tempfile,subprocess,unittest,traceback
out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False)
original_temporary=tempfile.TemporaryDirectory
original_run=subprocess.run
counter=0;commands=[]
def retained(*args,**kwargs):
 kwargs['delete']=False
 return original_temporary(*args,**kwargs)
def observed(*args,**kwargs):
 global counter
 index=counter;counter+=1;start=time.monotonic();item=dict(index=index,args=list(map(str,args[0])),timeout=kwargs.get('timeout'))
 try:
  result=original_run(*args,**kwargs);item['returncode']=result.returncode
  for stream in ('stdout','stderr'):
   value=getattr(result,stream)
   if value is not None:(out/(str(index)+'.'+stream)).write_bytes(value.encode() if isinstance(value,str) else value)
  return result
 except BaseException as error:
  item['error']=repr(error)
  if isinstance(error,subprocess.TimeoutExpired):
   for stream in ('stdout','stderr'):
    value=getattr(error,stream)
    if value is not None:(out/(str(index)+'.partial.'+stream)).write_bytes(value.encode() if isinstance(value,str) else value)
  raise
 finally:
  item['seconds']=time.monotonic()-start;commands.append(item);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
tempfile.TemporaryDirectory=retained;subprocess.run=observed
names=['tests.test_cseed_record_array_literals','tests.test_native_record_names','tests.test_native_call_argument_order','tests.test_native_mutable_record_arrays']
suite=unittest.defaultTestLoader.loadTestsFromNames(names);count=suite.countTestCases();assert count==19,count
start=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(suite)
record=dict(modules=names,discovered=count,ran=r.testsRun,failures=r.failures,errors=r.errors,skipped=r.skipped,successful=r.wasSuccessful(),seconds=time.monotonic()-start)
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(0 if r.wasSuccessful() and r.testsRun==19 and not r.skipped else 1)
