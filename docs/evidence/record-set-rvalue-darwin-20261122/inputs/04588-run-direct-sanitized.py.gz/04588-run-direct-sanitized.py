from pathlib import Path
import os,sys,json,time,subprocess,hashlib,platform
root=Path.cwd();control=Path(sys.argv[1]);out=control/'direct-sanitized';out.mkdir(exist_ok=False)
files=[p for p in (control/'tmp').rglob('main.nano') if 'set position 9' in p.read_text()];assert len(files)==1,files
source=files[0];env=dict(os.environ,NANO_CFLAGS='-fsanitize=address,undefined -fno-sanitize-recover=all')
if sys.platform=='darwin':env['ASAN_OPTIONS']='detect_leaks=0'
record=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),environment={k:env.get(k) for k in ['NANO_CFLAGS','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},steps=[],scope='I instrument the actual emitted native C and directly compiled runtime for the unchanged setter fixture. Prebuilt linked modules/providers retain ordinary instrumentation; I claim no all-provider or Darwin LeakSanitizer coverage.')
for name,args in [('compile',[root/'bin/nanoc_c',source,'--keep-c','-o',out/'native']),('execute',[out/'native'])]:
 t=time.monotonic();r=subprocess.run(list(map(str,args)),env=env,capture_output=True,timeout=120);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);record['steps'].append(dict(name=name,argv=list(map(str,args)),returncode=r.returncode,seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,r.stderr.decode(errors='replace')
record['passed']=True;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
