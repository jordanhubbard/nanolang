def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def write(n, v):
    (report / n).write_text(json.dumps(v, sort_keys=True, indent=2) + '\n')

def inventory(extra=()):
    entries = {}
    paths = []
    for directory in ('obj', 'bin', 'lib'):
        if (root / directory).exists():
            paths += list((root / directory).rglob('*'))
    for directory in extra:
        if Path(directory).is_dir():
            paths += list(Path(directory).rglob('*'))
    for p in paths:
        if not p.is_file():
            continue
        if p.is_relative_to(root) and p.suffix not in ('.o', '.a', '.so', '.dylib', '.ll', '.bc', '.h', '.json') and (not os.access(p, os.X_OK)):
            continue
        digest = sha(p)
        dest = artifacts / digest
        if not dest.exists():
            shared = None
            for prior in ():
                candidate = Path('/tmp/nanolang-record-vm-' + prior + '-' + ('puck' if darwin else 'linux')) / 'artifacts' / digest
                if candidate.is_file() and sha(candidate) == digest:
                    shared = candidate
                    break
            if shared is not None:
                os.link(shared, dest)
            elif not p.is_relative_to(root):
                os.link(p, dest)
            else:
                shutil.copyfile(p, dest)
        entries[str(p)] = {'sha256': digest, 'artifact': str(dest)}
    return entries

def run(label, cmd, extra=None):
    if phases and label not in phases:
        return
    free = shutil.disk_usage(report).free
    write(label + '-space-before.json', {'free_bytes': free, 'minimum_bytes': 2147483648})
    if free < 2147483648:
        write(label + '-terminal.json', {'launched': False, 'reason': 'capacity preflight', 'free_bytes': free})
        raise SystemExit(125)
    before = source()
    toolbefore = tools()
    write(label + '-source-before.json', before)
    write(label + '-tools-before.json', toolbefore)
    write(label + '-inputs-before.json', inventory())
    env = dict(os.environ)
    env.update(extra or {})
    write(label + '-command.json', {'argv': cmd, 'selectors': {k: v for k, v in env.items() if k.startswith(('NANO_', 'FILE_', 'WRAPPER_', 'ORDINARY_', 'DECLARATION_', 'RECORD_ARRAY_', 'RECORD_GENERATED_', 'RECORD_LLVM_')) or k in ('CC', 'SDKROOT', 'LIBRARY_PATH', 'NMS_NATIVE_CLANG_FLAGS', 'LSAN_OPTIONS')}})
    phase_bound = max(0, min(1200 if label == 'tests' else 1800, int(worker_deadline - time.monotonic())))
    start = time.monotonic()
    proc = None
    timed_out = False
    errors = []
    signals = []
    group_gone = None
    owned = {}
    nested_signals = []
    nested_remaining = []
    with (report / (label + '.log')).open('wb') as out:
        try:
            proc = subprocess.Popen(cmd, env=env, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)

            def process_rows():
                rows = {}
                for line in subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,args='], text=True).splitlines():
                    fields = line.strip().split(None, 8)
                    if len(fields) == 9:
                        rows[int(fields[0])] = {'parent': int(fields[1]), 'group': int(fields[2]), 'started': ' '.join(fields[3:8]), 'command': fields[8]}
                return rows
            deadline = time.monotonic() + phase_bound
            while proc.poll() is None:
                rows = process_rows()
                descendants = {proc.pid}
                for _ in range(len(rows) + 1):
                    more = {pid for pid, row in rows.items() if row['parent'] in descendants}
                    if more <= descendants:
                        break
                    descendants.update(more)
                for pid in descendants:
                    if pid in rows:
                        owned[pid] = rows[pid]
                free = shutil.disk_usage(report).free
                if free < 1610612736:
                    write(label + '-capacity-stop.json', {'free_bytes': free, 'minimum_bytes': 1610612736})
                    errors.append('active output capacity guard')
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    timed_out = True
                    break
                try:
                    proc.wait(timeout=min(1, remaining))
                except subprocess.TimeoutExpired:
                    pass
        except Exception as error:
            errors.append(type(error).__name__ + ': ' + str(error))
        finally:
            if proc is not None:

                def exists():
                    try:
                        os.killpg(proc.pid, 0)
                        return True
                    except ProcessLookupError:
                        return False
                    except OSError as error:
                        errors.append(str(error))
                        return True
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    if not exists():
                        break
                    try:
                        os.killpg(proc.pid, sig)
                        signals.append(sig.name)
                    except ProcessLookupError:
                        pass
                    except OSError as error:
                        errors.append(str(error))
                    deadline = time.monotonic() + 5
                    while time.monotonic() < deadline:
                        proc.poll()
                        if not exists():
                            break
                        time.sleep(0.05)
                group_gone = not exists()
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    rows = process_rows()
                    groups = {row['group'] for pid, row in rows.items() if pid in owned and row['started'] == owned[pid]['started'] and (row['group'] != proc.pid)}
                    for group in groups:
                        try:
                            os.killpg(group, sig)
                            nested_signals.append({'group': group, 'signal': sig.name})
                        except ProcessLookupError:
                            pass
                        except OSError as error:
                            errors.append(str(error))
                    if groups:
                        time.sleep(0.2)
                limit = time.monotonic() + 5
                while True:
                    rows = process_rows()
                    nested_remaining = [{'pid': pid, **row} for pid, row in rows.items() if pid in owned and row['started'] == owned[pid]['started'] and (pid != proc.pid)]
                    if not nested_remaining or time.monotonic() >= limit:
                        break
                    time.sleep(0.05)
                write(label + '-nested-processes.json', {'owned': owned, 'cleanup': nested_signals, 'remaining': nested_remaining})
                if nested_remaining:
                    errors.append('nested processes remain after bounded cleanup')
            code = proc.poll() if proc else None
            write(label + '-terminal.json', {'timeout': timed_out, 'bound': phase_bound, 'returncode': code, 'launched': proc is not None, 'leader_reaped': code is not None, 'group_disappeared': group_gone, 'cleanup_signals': signals, 'errors': errors})
    completed = subprocess.CompletedProcess(cmd, 124 if timed_out else code if code is not None and (not errors) and group_gone else 125)
    result = {'phase': label, 'status': completed.returncode, 'seconds': round(time.monotonic() - start, 3)}
    results.append(result)
    write('results.json', results)
    after = source()
    toolafter = tools()
    write(label + '-source-after.json', after)
    write(label + '-tools-after.json', toolafter)
    text = (report / (label + '.log')).read_text(errors='replace')
    dirs = re.findall('I retain [^\\n]*? artifacts at (\\S+)', text)
    dirs += re.findall('(/(?:tmp|var/folders)/[^\\s\\\'\\"]*nano-[^\\s\\\'\\"]+)', text)
    write(label + '-artifacts.json', inventory([*dirs, report / 'controls', report / 'package-artifacts']))
    print(json.dumps(result), flush=True)
    assert before == after and toolbefore == toolafter, 'source or host tools changed during phase'
    if completed.returncode:
        sys.exit(completed.returncode)
