import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker=sys.argv[3]
assert worker in ('forth','source')
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("max(0, min(1200 if label == 'tests' else 1800, int(worker_deadline-time.monotonic())))",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
files=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p and not p.startswith('docs/evidence/')]
assert len(files)>3000 and all((root/p).is_file() for p in files)
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)
write('attribution.json',{'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'worker':worker,'worker_bound':1800,'test_bound':1200,'sparse_omission':'docs/evidence only; exact Git source input set retained','base_supervisor_sha256':sha(base),'driver_sha256':sha(__file__),'effective_supervisor_sha256':sha(report/'effective-supervisor.py'),'environment':{k:os.environ.get(k) for k in ('CC','CFLAGS','LDFLAGS','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','PATH')}})
worker_deadline=time.monotonic()+1800
planner=str(root/'scripts/ci_sanitizer_partitions.py');proof=report/'worker';manifest=proof/'plan.json'
def invoke(label,action,extra=()):
 cmd=[sys.executable,planner,action,'--output',str(proof)]
 if action!='plan':cmd+=['--manifest',str(manifest),'--worker',worker]
 run(label,cmd+list(extra))
try:
 invoke('plan','plan');invoke('verify','verify');invoke('before','snapshot',['--phase','before'])
 invoke('sanitize','command',['--phase','sanitize']);invoke('bootstrap','command',['--phase','bootstrap'])
 if worker=='source':invoke('providers','command',['--phase','providers'])
 invoke('prepared','snapshot',['--phase','prepared']);invoke('tests','command',['--phase','tests'])
finally:
 # Retain the terminal's actual surviving providers even when a dependent phase stopped.
 end=subprocess.run([sys.executable,planner,'snapshot','--output',str(proof),'--manifest',str(manifest),'--worker',worker,'--phase','after'],capture_output=True,timeout=60)
 (report/'after-snapshot.stdout').write_bytes(end.stdout);(report/'after-snapshot.stderr').write_bytes(end.stderr)
 statuses={r['phase']:{'outcome':'success' if r['status']==0 else 'failure'} for r in results};statuses['after']={'outcome':'success' if end.returncode==0 else 'failure'}
 env=dict(os.environ,CI_SANITIZER_STEPS=json.dumps(statuses));result=subprocess.run([sys.executable,planner,'result','--output',str(proof),'--manifest',str(manifest),'--worker',worker],env=env,capture_output=True,timeout=60)
 (report/'worker-result.stderr').write_bytes(result.stderr);write('local-result.json',{'result_returncode':result.returncode,'phase_results':results,'seconds':1800-(worker_deadline-time.monotonic())})
