#define _GNU_SOURCE 1
#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <math.h>
#include "runtime/nl_string.h"
#ifdef __wasm__
#  include "runtime/refcount_gc.h"
#  define gc_alloc_string(len)   nl_rc_str_new(NULL, (len))
#  define gc_retain(p)           nl_rc_retain(p)
#  define gc_release(p)          nl_rc_release(p)
#else
#  include "runtime/gc.h"
#endif
#include "runtime/dyn_array.h"
#include "runtime/native_array_abi.h"
#ifndef __wasm__
#  include "nanolang.h"
#endif

/* Headers from imported modules (sorted by priority) */
#include "fs.h"  /* priority: 0 */
#include "process.h"  /* priority: 0 */

/* nanolang runtime */
#include "runtime/list_int.h"
#include "runtime/native_record_list.h"
#include "runtime/list_string.h"
#include "runtime/list_token.h"
#include "runtime/token_helpers.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <libgen.h>
#include <sys/wait.h>
#include <spawn.h>
#include <fcntl.h>
/* fs.h forward declarations */
DynArray* fs_walkdir(const char* root);
const char* path_normalize(const char* path);
const char* path_join(const char* a, const char* b);
const char* path_basename(const char* path);
const char* path_dirname(const char* path);
int64_t  fs_mkdir_p(const char* path);
const char* path_relpath(const char* target, const char* base);
const char* file_read(const char* path);
int64_t  file_write(const char* path, const char* content);
int64_t  file_append(const char* path, const char* content);
bool     file_exists(const char* path);
int64_t  file_delete(const char* path);
int64_t  file_copy(const char* src, const char* dst);
int64_t  dir_copy(const char* src, const char* dst);
int64_t  nl_os_process_spawn(const char* command);
int64_t  nl_os_process_is_running(int64_t pid);
int64_t  nl_os_process_wait(int64_t pid);
DynArray* nl_os_process_spawn_with_pipes(const char* command);
const char* nl_os_fd_read_available(int64_t fd);
int64_t  nl_os_fd_close(int64_t fd);

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-const-variable"

/* ========== OS Standard Library ========== */

#include "runtime/file_text.h"
static const char* nl_os_file_read(const char* path) {
    char* text = nl_read_file_text(path);
    if (!text) return gc_alloc_string(0);
    size_t length = strlen(text);
    char* result = gc_alloc_string(length);
    if (result) memcpy(result, text, length + 1);
    free(text);
    return result;
}

#include "runtime/file_bytes.h"
static DynArray* nl_os_file_read_bytes(const char* path) {
    return nl_read_file_bytes(path);
}

#include "runtime/file_write.h"
static int64_t nl_os_file_write(const char* path, const char* content) {
    return nl_write_file_text(path, content, "w");
}

static int64_t nl_os_file_append(const char* path, const char* content) {
    return nl_write_file_text(path, content, "a");
}

static int64_t nl_os_file_remove(const char* path) {
    return remove(path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_delete(const char* path) {
    return nl_os_file_remove(path);
}

static int64_t nl_os_file_rename(const char* old_path, const char* new_path) {
    return rename(old_path, new_path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_size(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (int64_t)st.st_size;
}

static bool nl_os_file_exists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static char* nl_os_tmp_dir(void) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    size_t len = strlen(tmp);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, tmp, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_";
    char templ[1024];
    snprintf(templ, sizeof(templ), "%s/%sXXXXXX", tmp, p);
    int fd = mkstemp(templ);
    if (fd < 0) return gc_alloc_string(0);
    close(fd);
    size_t len = strlen(templ);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, templ, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp_dir(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_dir_";
    char path[1024];
    for (int i = 0; i < 100; i++) {
        snprintf(path, sizeof(path), "%s/%s%lld_%d", tmp, p, (long long)time(NULL), i);
        if (mkdir(path, 0700) == 0) {
            size_t len = strlen(path);
            char* out = gc_alloc_string(len);
            if (!out) return gc_alloc_string(0);
            memcpy(out, path, len);
            out[len] = '\0';
            return out;
        }
    }
    return gc_alloc_string(0);
}

static int64_t nl_os_dir_create(const char* path) {
    return mkdir(path, 0755) == 0 ? 0 : -1;
}

static int64_t nl_os_dir_remove(const char* path) {
    return rmdir(path) == 0 ? 0 : -1;
}

static char* nl_os_dir_list(const char* path) {
    DIR* dir = opendir(path);
    if (!dir) return gc_alloc_string(0);
    size_t capacity = 4096;
    size_t used = 0;
    char* buffer = gc_alloc_string(capacity);
    if (!buffer) { closedir(dir); return gc_alloc_string(0); }
    buffer[0] = '\0';
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        size_t name_len = strlen(entry->d_name);
        size_t needed = used + name_len + 2; /* +1 for newline, +1 for null */
        if (needed > capacity) {
            capacity = needed * 2;
            char* new_buffer = gc_alloc_string(capacity);
            if (!new_buffer) { gc_release(buffer); closedir(dir); return gc_alloc_string(0); }
            memcpy(new_buffer, buffer, used);
            gc_release(buffer);
            buffer = new_buffer;
        }
        memcpy(buffer + used, entry->d_name, name_len);
        used += name_len;
        buffer[used++] = '\n';
        buffer[used] = '\0';
    }
    closedir(dir);
    return buffer;
}

static bool nl_os_dir_exists(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_getcwd(void) {
    char temp_buffer[1024];
    if (getcwd(temp_buffer, sizeof(temp_buffer)) == NULL) {
        return gc_alloc_string(0);
    }
    size_t len = strlen(temp_buffer);
    char* buffer = gc_alloc_string(len);
    if (buffer) memcpy(buffer, temp_buffer, len + 1);
    return buffer ? buffer : gc_alloc_string(0);
}

static int64_t nl_os_chdir(const char* path) {
    return chdir(path) == 0 ? 0 : -1;
}

#include "runtime/directory_walk.h"
static DynArray* nl_os_walkdir(const char* root) {
    return nl_fs_walkdir(root);
}

static bool nl_os_path_isfile(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISREG(st.st_mode);
}

static bool nl_os_path_isdir(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_path_join(const char* a, const char* b) {
    size_t len_a = strlen(a);
    size_t len_b = strlen(b);
    size_t total_len = len_a + len_b + 2; /* +1 for '/', +1 for null */
    char* buffer = gc_alloc_string(total_len);
    if (!buffer) return gc_alloc_string(0);
    if (len_a == 0) {
        snprintf(buffer, total_len, "%s", b);
    } else if (a[len_a - 1] == '/') {
        snprintf(buffer, total_len, "%s%s", a, b);
    } else {
        snprintf(buffer, total_len, "%s/%s", a, b);
    }
    return buffer;
}

static char* nl_os_path_basename(const char* path) {
    char* path_copy = strdup(path);
    char* base = basename(path_copy);
    size_t len = strlen(base);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, base, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

static char* nl_os_path_dirname(const char* path) {
    char* path_copy = strdup(path);
    char* dir = dirname(path_copy);
    size_t len = strlen(dir);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, dir, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

#include "runtime/path_normalize.h"
static char* nl_os_path_normalize(const char* path) {
    if (!path) return gc_alloc_string(0);
    char* normalized = nl_normalize_path(path);
    if (!normalized) return gc_alloc_string(0);
    size_t length = strlen(normalized);
    char* out = gc_alloc_string(length);
    if (out) memcpy(out, normalized, length + 1);
    free(normalized);
    return out ? out : gc_alloc_string(0);
}

static int64_t nl_os_system(const char* command) {
    return system(command);
}

static void nl_os_exit(int64_t code) {
    exit((int)code);
}

static const char* nl_os_getenv(const char* name) {
    const char* value = getenv(name);
    return value ? value : "";
}

/* system() wrapper - stdlib system() available via stdlib.h */
static inline int64_t nl_exec_shell(const char* cmd) {
    return (int64_t)system(cmd);
}

/* isatty() wrapper - avoids int64_t type clash with unistd.h */
static inline int64_t nl_isatty(int64_t fd) {
    return (int64_t)isatty((int)fd);
}

/* Capture stdout from a shell command */
static inline const char* nl_exec_capture(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "";
    char* out = (char*)malloc(65536);
    if (!out) { pclose(pipe); return ""; }
    size_t total = 0;
    while (total < 65535) {
        size_t n = fread(out + total, 1, 65535 - total, pipe);
        if (n == 0) break;
        total += n;
    }
    out[total] = '\0';
    pclose(pipe);
    return out;
}

#include "runtime/process_capture.h"
#ifndef NANOLANG_STD_PROCESS_H
static DynArray* nl_os_process_run(const char* command) {
    return nl_process_run_capture(command);
}
#endif /* NANOLANG_STD_PROCESS_H */

/* ========== End OS Standard Library ========== */

/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Advanced String Operations ========== */

static int64_t char_at(const char* s, int64_t index) {
    /* Safety: Bound string scan to 64MB */
    int len = strnlen(s, 64*1024*1024);
    if (index < 0 || index >= len) {
        fprintf(stderr, "Error: Index %lld out of bounds (string length %d)\n", (long long)index, len);
        return 0;
    }
    return (unsigned char)s[index];
}

static char* string_from_char(int64_t c) {
    char* buffer = gc_alloc_string(1);
    if (!buffer) return "";
    buffer[0] = (char)c;
    buffer[1] = '\0';
    return buffer;
}

static bool is_digit(int64_t c) {
    return c >= '0' && c <= '9';
}

static bool is_alpha(int64_t c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_alnum(int64_t c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_whitespace(int64_t c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

static bool is_upper(int64_t c) {
    return c >= 'A' && c <= 'Z';
}

static bool is_lower(int64_t c) {
    return c >= 'a' && c <= 'z';
}

static char* int_to_string(int64_t n) {
    char* buffer = gc_alloc_string(31);
    if (!buffer) return "";
    snprintf(buffer, 32, "%lld", (long long)n);
    return buffer;
}

static char* float_to_string(double x) {
    char* buffer = gc_alloc_string(63);
    if (!buffer) return "";
    nano_rt_f64_format(buffer, 64, x);
    /* Ensure at least one decimal place for whole-number floats
     * so 0.0 -> "0.0" rather than "0" */
    if (!strchr(buffer, '.') && !strchr(buffer, 'e')
            && !strchr(buffer, 'n') && !strchr(buffer, 'i')) {
        size_t len = strlen(buffer);
        if (len + 2 < 64) { buffer[len] = '.'; buffer[len+1] = '0'; buffer[len+2] = '\0'; }
    }
    return buffer;
}

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} nl_fmt_sb_t;

static void nl_fmt_sb_ensure(nl_fmt_sb_t *sb, size_t extra) {
    if (!sb) return;
    size_t needed = sb->len + extra + 1;
    if (needed <= sb->cap) return;
    size_t new_cap = sb->cap ? sb->cap : 128;
    while (new_cap < needed) new_cap *= 2;
    char *new_buf = realloc(sb->buf, new_cap);
    if (!new_buf) return;
    sb->buf = new_buf;
    sb->cap = new_cap;
}

static nl_fmt_sb_t nl_fmt_sb_new(size_t initial_cap) {
    nl_fmt_sb_t sb = {0};
    sb.cap = initial_cap ? initial_cap : 128;
    sb.buf = (char*)malloc(sb.cap);
    sb.len = 0;
    if (sb.buf) sb.buf[0] = '\0';
    return sb;
}

static void nl_fmt_sb_append_cstr(nl_fmt_sb_t *sb, const char *s) {
    if (!sb || !s) return;
    size_t n = strlen(s);
    nl_fmt_sb_ensure(sb, n);
    if (!sb->buf) return;
    memcpy(sb->buf + sb->len, s, n);
    sb->len += n;
    sb->buf[sb->len] = '\0';
}

static void nl_fmt_sb_append_char(nl_fmt_sb_t *sb, char c) {
    if (!sb) return;
    nl_fmt_sb_ensure(sb, 1);
    if (!sb->buf) return;
    sb->buf[sb->len++] = c;
    sb->buf[sb->len] = '\0';
}

static char* nl_fmt_sb_build(nl_fmt_sb_t *sb) {
    if (!sb || !sb->buf) return "";
    return sb->buf;
}

static const char* nl_to_string_int(int64_t v) { return int_to_string(v); }
static const char* nl_to_string_float(double v) { return float_to_string(v); }
static const char* nl_to_string_bool(bool v) { return v ? "true" : "false"; }
static const char* nl_to_string_string(const char* v) { return v ? v : ""; }

static const char* nl_to_string_array(DynArray* arr) {
    if (!arr) return "[]";
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_char(&sb, '[');
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    for (int64_t i = 0; i < len; i++) {
        if (i > 0) nl_fmt_sb_append_cstr(&sb, ", ");
        switch (t) {
            case ELEM_INT: {
                const char* s = nl_to_string_int(dyn_array_get_int(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_U8: {
                const char* s = nl_to_string_int((int64_t)dyn_array_get_u8(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_FLOAT: {
                const char* s = nl_to_string_float(dyn_array_get_float(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_BOOL: {
                nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(dyn_array_get_bool(arr, i)));
                break;
            }
            case ELEM_STRING: {
                nl_fmt_sb_append_char(&sb, '"');
                nl_fmt_sb_append_cstr(&sb, nl_to_string_string(dyn_array_get_string(arr, i)));
                nl_fmt_sb_append_char(&sb, '"');
                break;
            }
            case ELEM_ARRAY: {
                const char* s = nl_to_string_array(dyn_array_get_array(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_STRUCT: {
                nl_fmt_sb_append_cstr(&sb, "<struct>");
                break;
            }
            default: {
                nl_fmt_sb_append_cstr(&sb, "?");
                break;
            }
        }
    }
    nl_fmt_sb_append_char(&sb, ']');
    return nl_fmt_sb_build(&sb);
}

static const char* nl_str_concat(const char* s1, const char* s2);
static DynArray* nl_array_add(DynArray* a, DynArray* b);
static DynArray* nl_array_sub(DynArray* a, DynArray* b);
static DynArray* nl_array_mul(DynArray* a, DynArray* b);
static DynArray* nl_array_div(DynArray* a, DynArray* b);
static DynArray* nl_array_mod(DynArray* a, DynArray* b);

static void nl_array_assert_compatible(DynArray* a, DynArray* b) {
    assert(a && b);
    assert(dyn_array_length(a) == dyn_array_length(b));
    assert(dyn_array_get_elem_type(a) == dyn_array_get_elem_type(b));
}

static DynArray* nl_array_add(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)+dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_STRING: for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), dyn_array_get_string(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_add(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_add: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_sub(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)-dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_sub(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_sub: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mul(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)*dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mul(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mul: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_div(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)/dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_div(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_div: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mod(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)%dyn_array_get_int(b,i)); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mod(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mod: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_add_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) + s);
    return out;
}

static DynArray* nl_array_radd_scalar_int(int64_t s, DynArray* a) { return nl_array_add_scalar_int(a, s); }

static DynArray* nl_array_sub_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) - s);
    return out;
}

static DynArray* nl_array_rsub_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s - dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mul_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) * s);
    return out;
}

static DynArray* nl_array_rmul_scalar_int(int64_t s, DynArray* a) { return nl_array_mul_scalar_int(a, s); }

static DynArray* nl_array_div_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) / s);
    return out;
}

static DynArray* nl_array_rdiv_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s / dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mod_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) % s);
    return out;
}

static DynArray* nl_array_rmod_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s % dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_add_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_float(double s, DynArray* a) { return nl_array_add_scalar_float(a, s); }

static DynArray* nl_array_sub_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rsub_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_mul_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rmul_scalar_float(double s, DynArray* a) { return nl_array_mul_scalar_float(a, s); }

static DynArray* nl_array_div_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rdiv_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_add_scalar_string(DynArray* a, const char* s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_string(const char* s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(s, dyn_array_get_string(a,i)));
    return out;
}

static int64_t string_to_int(const char* s) {
    return strtoll(s, NULL, 10);
}

#include "runtime/binary64_parse.h"
static double string_to_float(const char* s) { return nl_binary64_prefix(s); }

static int64_t digit_value(int64_t c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    return -1;
}

static int64_t char_to_lower(int64_t c) {
    if (c >= 'A' && c <= 'Z') {
    return c + 32;
    }
    return c;
}

static int64_t char_to_upper(int64_t c) {
    if (c >= 'a' && c <= 'z') {
        return c - 32;
    }
    return c;
}

#include "runtime/string_edges.h"
static const char* nl_str_trim_left(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t start = 0;
    while (start < len && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n' || s[start] == '\r')) start++;
    size_t new_len = len - start;
    char* result = gc_alloc_string(new_len);
    if (!result) return "";
    memcpy(result, s + start, new_len);
    result[new_len] = '\0';
    return result;
}

static const char* nl_str_trim_right(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t end = len;
    while (end > 0 && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n' || s[end-1] == '\r')) end--;
    char* result = gc_alloc_string(end);
    if (!result) return "";
    memcpy(result, s, end);
    result[end] = '\0';
    return result;
}

static const char* nl_str_to_lower(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_to_upper(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_replace(const char* s, const char* old_str, const char* new_str) {
    if (!s || !old_str || !new_str) return s ? s : "";
    size_t old_len = strlen(old_str);
    size_t s_len = strlen(s);
    if (old_len == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    size_t new_len = strlen(new_str);
    int64_t count = 0;
    const char* p = s;
    const char* found;
    while ((found = strstr(p, old_str)) != NULL) { count++; p = found + old_len; }
    if (count == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    int64_t result_len = (int64_t)s_len + count * ((int64_t)new_len - (int64_t)old_len);
    if (result_len < 0) return "";
    char* result = gc_alloc_string((size_t)result_len);
    if (!result) return "";
    const char* src = s;
    char* dst = result;
    while ((found = strstr(src, old_str)) != NULL) {
        size_t seg_len = (size_t)(found - src);
        memcpy(dst, src, seg_len);
        dst += seg_len;
        memcpy(dst, new_str, new_len);
        dst += new_len;
        src = found + old_len;
    }
    size_t rest = strlen(src);
    memcpy(dst, src, rest);
    dst[rest] = '\0';
    return result;
}

static DynArray* nl_str_split(const char* str, const char* delim) {
    DynArray* result = dyn_array_new(ELEM_STRING);
    if (!result) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    if (!str) return result;
    size_t delim_len = strlen(delim);
    if (delim_len == 0) {
        size_t str_len = strnlen(str, 64*1024*1024);
        for (size_t i = 0; i < str_len; i++) {
            char* ch = gc_alloc_string(1);
            if (!ch) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
            ch[0] = str[i]; ch[1] = '\0';
            dyn_array_push_string(result, ch);
        }
        return result;
    }
    const char* start = str;
    const char* found;
    while ((found = strstr(start, delim)) != NULL) {
        size_t seg_len = (size_t)(found - start);
        char* seg = gc_alloc_string(seg_len);
        if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
        memcpy(seg, start, seg_len);
        seg[seg_len] = '\0';
        dyn_array_push_string(result, seg);
        start = found + delim_len;
    }
    size_t rest_len = strlen(start);
    char* seg = gc_alloc_string(rest_len);
    if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    {
        memcpy(seg, start, rest_len);
        seg[rest_len] = '\0';
        dyn_array_push_string(result, seg);
    }
    return result;
}

static const char* nl_str_join(DynArray* arr, const char* delim) {
    if (!arr) return "";
    int64_t count = dyn_array_length(arr);
    if (count == 0) return "";
    size_t delim_len = strlen(delim);
    size_t total = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) total += strlen(s);
        if (i < count - 1) total += delim_len;
    }
    char* result = gc_alloc_string(total);
    if (!result) return "";
    size_t pos = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) { size_t slen = strlen(s); memcpy(result + pos, s, slen); pos += slen; }
        if (i < count - 1) { memcpy(result + pos, delim, delim_len); pos += delim_len; }
    }
    result[pos] = '\0';
    return result;
}

static const char* nl_format(const char *fmt, int n_args, ...) {
    if (!fmt) return "";
    va_list ap;
    va_start(ap, n_args);
    nl_fmt_sb_t out = nl_fmt_sb_new(128);
    const char *p = fmt;
    int used = 0;
    while (*p) {
        if (*p == '%' && (p[1] == 's' || p[1] == 'd' || p[1] == 'f' || p[1] == 'g') && used < n_args) {
            const char *arg = va_arg(ap, const char *);
            if (arg) nl_fmt_sb_append_cstr(&out, arg);
            used++;
            p += 2;
        } else {
            nl_fmt_sb_append_char(&out, *p++);
        }
    }
    va_end(ap);
    char *result = gc_alloc_string(out.len);
    if (result && out.buf) { memcpy(result, out.buf, out.len + 1); }
    if (out.buf) free(out.buf);
    return result ? result : "";
}

/* ========== End Advanced String Operations ========== */

/* ========== Timing Utilities ========== */

#include <sys/time.h>
#ifdef __MACH__
#include <mach/mach_time.h>
#endif

/* Get current time in microseconds since epoch */
static int64_t nl_timing_get_microseconds(void) {
#ifdef CLOCK_REALTIME
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ((int64_t)ts.tv_sec * 1000000LL) + (int64_t)(ts.tv_nsec / 1000);
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((int64_t)tv.tv_sec * 1000000LL) + (int64_t)tv.tv_usec;
#endif
}

/* Get high-resolution time in nanoseconds */
static int64_t nl_timing_get_nanoseconds(void) {
#ifdef __MACH__
    static mach_timebase_info_data_t timebase;
    static int initialized = 0;
    if (!initialized) {
        mach_timebase_info(&timebase);
        initialized = 1;
    }
    uint64_t mach_time = mach_absolute_time();
    return (int64_t)((mach_time * timebase.numer) / timebase.denom);
#elif defined(CLOCK_MONOTONIC)
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((int64_t)ts.tv_sec * 1000000000LL) + (int64_t)ts.tv_nsec;
#else
    return nl_timing_get_microseconds() * 1000LL;
#endif
}

/* Convenience: current time in milliseconds */
static int64_t nl_get_time_ms(void) { return nl_timing_get_microseconds() / 1000LL; }

/* ========== End Timing Utilities ========== */

/* ========== Console I/O Utilities ========== */

/* Read a line from stdin, returns heap-allocated string */
/* Static to avoid duplicate symbols when linking multiple modules */
static const char* nl_read_line(void) {
    char buffer[4096];
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty ? empty : "";
    }
    /* Remove trailing newline if present */
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len-1] == '\n') {
        buffer[len-1] = '\0';
        len--;
    }
    char* result = malloc(len + 1);
    if (!result) return "";
    memcpy(result, buffer, len + 1);
    return result;
}

/* ========== End Console I/O Utilities ========== */

#include <string.h>
static inline double nl_float_from_bits(int64_t value) { uint64_t bits = (uint64_t)value; double result; (void)sizeof(char[sizeof(result) == sizeof(bits) ? 1 : -1]); memcpy(&result, &bits, sizeof(result)); return result; }
static inline int64_t nl_float_to_bits(double value) { uint64_t bits; (void)sizeof(char[sizeof(value) == sizeof(bits) ? 1 : -1]); memcpy(&bits, &value, sizeof(bits)); return bits <= (9223372036854775807L) ? (int64_t)bits : -1 - (int64_t)((18446744073709551615UL) - bits); }
/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Math and Utility Built-in Functions ========== */

#define nl_abs(x) _Generic((x), \
    double: (double)((x) < 0.0 ? -(x) : (x)), \
    default: (int64_t)((x) < 0 ? -(x) : (x)))

#define nl_min(a, b) _Generic((a), \
    double: (double)((a) < (b) ? (a) : (b)), \
    default: (int64_t)((a) < (b) ? (a) : (b)))

#define nl_max(a, b) _Generic((a), \
    double: (double)((a) > (b) ? (a) : (b)), \
    default: (int64_t)((a) > (b) ? (a) : (b)))

/* Trigonometric functions */
static double nl_sin(double x) { return sin(x); }
static double nl_cos(double x) { return cos(x); }
static double nl_tan(double x) { return tan(x); }
static double nl_atan2(double y, double x) { return atan2(y, x); }

/* Power and root functions */
static double nl_sqrt(double x) { return sqrt(x); }
static double nl_pow(double base, double exp) { return pow(base, exp); }

/* Rounding functions */
static double nl_floor(double x) { return floor(x); }
static double nl_ceil(double x) { return ceil(x); }
static double nl_round(double x) { return round(x); }

static int64_t nl_cast_int(double x) { if (!(x >= -0x1p63 && x < 0x1p63)) { fputs("I cannot convert this float to int: I require a finite value in [-2^63, 2^63).\n", stderr); exit(EXIT_FAILURE); } return (int64_t)x; }
static int64_t nl_cast_int_from_int(int64_t x) { return x; }
static double nl_cast_float(int64_t x) { return (double)x; }
static double nl_cast_float_from_float(double x) { return x; }
static void* nl_null_opaque() { return NULL; }
static int64_t nl_cast_bool_to_int(bool x) { return x ? 1 : 0; }
static bool nl_cast_bool(int64_t x) { return x != 0; }
static int64_t nano_rt_idiv(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return INT64_MIN; return a / b; }
static int64_t nano_rt_imod(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return 0; return a % b; }

static void nl_println(void* value_ptr) {
    (void)value_ptr; /* Unused - actual implementation uses type info from checker */
}

static void nl_print_int(int64_t value) {
    printf("%lld", (long long)value);
}

static void nl_print_float(double value) {
    nano_rt_f64_print(stdout, value);
}

static void nl_print_string(const char* value) {
    printf("%s", value);
}

static void nl_print_bool(bool value) {
    printf(value ? "true" : "false");
}

static void nl_println_int(int64_t value) {
    printf("%lld\n", (long long)value);
}

static void nl_println_float(double value) {
    nano_rt_f64_print(stdout, value); fputc('\n', stdout);
}

static void nl_println_string(const char* value) {
    printf("%s\n", value);
}

/* Dynamic array runtime (using GC) - LEGACY */
#include "runtime/gc.h"
#include "runtime/dyn_array.h"
#include "runtime/nl_string.h"

static DynArray* dynarray_literal_int(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int64_t val = va_arg(args, int64_t);
        dyn_array_push_int(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_u8(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_U8);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* default promotion */
        dyn_array_push_u8(arr, (uint8_t)val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_float(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        double val = va_arg(args, double);
        dyn_array_push_float(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_string(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        const char* val = va_arg(args, const char*);
        dyn_array_push_string(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_bool(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* bool promotes to int */
        dyn_array_push_bool(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static DynArray* nl_array_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static double nl_array_pop(DynArray* arr) {
    bool success = false;
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_pop_u8(arr, &success);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_pop_int(arr, &success);
    } else {
        return dyn_array_pop_float(arr, &success);
    }
}

static int64_t nl_array_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static DynArray* nl_array_remove_at(DynArray* arr, int64_t index) {
    return dyn_array_remove_at(arr, index);
}

static int64_t nl_array_at_int(DynArray* arr, int64_t idx) {
    return dyn_array_get_int(arr, idx);
}

static uint8_t nl_array_at_u8(DynArray* arr, int64_t idx) {
    return dyn_array_get_u8(arr, idx);
}

static double nl_array_at_float(DynArray* arr, int64_t idx) {
    return dyn_array_get_float(arr, idx);
}

static const char* nl_array_at_string(DynArray* arr, int64_t idx) {
    return dyn_array_get_string(arr, idx);
}

static bool nl_array_at_bool(DynArray* arr, int64_t idx) {
    return dyn_array_get_bool(arr, idx);
}

static void nl_array_set_int(DynArray* arr, int64_t idx, int64_t val) {
    dyn_array_set_int(arr, idx, val);
}

static void nl_array_set_u8(DynArray* arr, int64_t idx, uint8_t val) {
    dyn_array_set_u8(arr, idx, val);
}

static void nl_array_set_float(DynArray* arr, int64_t idx, double val) {
    dyn_array_set_float(arr, idx, val);
}

static void nl_array_set_string(DynArray* arr, int64_t idx, const char* val) {
    dyn_array_set_string(arr, idx, val);
}

static void nl_array_set_bool(DynArray* arr, int64_t idx, bool val) {
    dyn_array_set_bool(arr, idx, val);
}

static DynArray* nl_array_at_array(DynArray* arr, int64_t idx) {
    return dyn_array_get_array(arr, idx);
}

static void nl_array_set_array(DynArray* arr, int64_t idx, DynArray* val) {
    dyn_array_set_array(arr, idx, val);
}

static DynArray* nl_array_new_int(int64_t size, int64_t default_val) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_int(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_float(int64_t size, double default_val) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_float(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_string(int64_t size, const char* default_val) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_string(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_bool(int64_t size, bool default_val) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_bool(arr, default_val);
    }
    return arr;
}

static int64_t dynarray_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static double dynarray_at_for_transpiler(DynArray* arr, int64_t idx) {
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_get_u8(arr, idx);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_get_int(arr, idx);
    } else {
        return dyn_array_get_float(arr, idx);
    }
}

/* bstring helpers (nl_string_t wrappers) */
static nl_string_t* bstr_new(const char* cstr) {
    if (!cstr) cstr = "";
    return nl_string_new(cstr);
}

static nl_string_t* bstr_new_binary(DynArray* bytes) {
    if (!bytes || dyn_array_get_elem_type(bytes) != ELEM_U8) {
        return nl_string_new_binary("", 0);
    }
    int64_t len = dyn_array_length(bytes);
    if (len <= 0) {
        return nl_string_new_binary("", 0);
    }
    uint8_t* buffer = malloc((size_t)len);
    if (!buffer) {
        return nl_string_new_binary("", 0);
    }
    for (int64_t i = 0; i < len; i++) {
        buffer[i] = dyn_array_get_u8(bytes, i);
    }
    nl_string_t* result = nl_string_new_binary(buffer, (size_t)len);
    free(buffer);
    return result;
}

static size_t bstr_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_length(str);
}

static int64_t bstr_byte_at(nl_string_t* str, int64_t index) {
    if (!str || index < 0 || (size_t)index >= nl_string_length(str)) {
        return 0;
    }
    return (unsigned char)nl_string_byte_at(str, (size_t)index);
}

static nl_string_t* bstr_concat(nl_string_t* a, nl_string_t* b) {
    if (!a && !b) return nl_string_new("");
    if (!a) return nl_string_clone(b);
    if (!b) return nl_string_clone(a);
    return nl_string_concat(a, b);
}

static nl_string_t* bstr_substring(nl_string_t* str, int64_t start, int64_t length) {
    if (!str || start < 0 || length < 0) {
        return nl_string_new("");
    }
    size_t len = nl_string_length(str);
    if ((size_t)start > len) {
        start = (int64_t)len;
    }
    if ((size_t)(start + length) > len) {
        length = (int64_t)len - start;
    }
    return nl_string_substring(str, (size_t)start, (size_t)length);
}

static bool bstr_equals(nl_string_t* a, nl_string_t* b) {
    if (!a || !b) return a == b;
    return nl_string_equals(a, b);
}

static bool bstr_validate_utf8(nl_string_t* str) {
    if (!str) return false;
    return nl_string_validate_utf8(str);
}

static int64_t bstr_utf8_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_utf8_length(str);
}

static int64_t bstr_utf8_char_at(nl_string_t* str, int64_t char_index) {
    if (!str || char_index < 0) return -1;
    return nl_string_utf8_char_at(str, (size_t)char_index);
}

static const char* bstr_to_cstr(nl_string_t* str) {
    if (!str) return "";
    return nl_string_to_cstr(str);
}

static void bstr_free(nl_string_t* str) {
    if (str) {
        nl_string_free(str);
    }
}

/* String concatenation - use strnlen for safety */
static const char* nl_str_concat(const char* s1, const char* s2) {
    /* Safety: Bound string scan to 64MB */
    size_t len1 = strnlen(s1, 64*1024*1024);
    size_t len2 = strnlen(s2, 64*1024*1024);
    char* result = gc_alloc_string(len1 + len2);
    if (!result) return "";
    memcpy(result, s1, len1);
    memcpy(result + len1, s2, len2);
    result[len1 + len2] = '\0';
    return result;
}

/* String substring - use strnlen for safety */
static const char* nl_str_substring(const char* str, int64_t start, int64_t length) {
    /* Safety: Bound string scan to 64MB */
    int64_t str_len = strnlen(str, 64*1024*1024);
    if (start < 0 || start > str_len || length < 0) return "";
    if (start == str_len) return "";
    if (start + length > str_len) length = str_len - start;
    char* result = gc_alloc_string(length);
    if (!result) return "";
    strncpy(result, str + start, length);
    result[length] = '\0';
    return result;
}

/* String contains */
static bool nl_str_contains(const char* str, const char* substr) {
    return strstr(str, substr) != NULL;
}

/* String equals */
static bool nl_str_equals(const char* s1, const char* s2) {
    return strcmp(s1, s2) == 0;
}

/* String starts_with */
static bool nl_str_starts_with(const char* s, const char* prefix) {
    if (!s || !prefix) return false;
    size_t slen = strnlen(s, 64*1024*1024);
    size_t plen = strnlen(prefix, 64*1024*1024);
    if (plen > slen) return false;
    return strncmp(s, prefix, plen) == 0;
}

/* String ends_with */
#include "runtime/string_edges.h"
#include "runtime/string_search.h"
static DynArray* nl_bytes_from_string(const char* s) {
    DynArray* out = dyn_array_new(ELEM_U8);
    if (!out) return NULL;
    if (!s) return out;
    size_t len = strnlen(s, 64*1024*1024);
    for (size_t i = 0; i < len; i++) {
        dyn_array_push_u8(out, (uint8_t)(unsigned char)s[i]);
    }
    return out;
}

static const char* nl_string_from_bytes(DynArray* bytes) {
    if (!bytes) return "";
    if (dyn_array_get_elem_type(bytes) != ELEM_U8) return "";
    int64_t len = dyn_array_length(bytes);
    if (len < 0) return "";
    char* out = gc_alloc_string((size_t)len);
    if (!out) return "";
    for (int64_t i = 0; i < len; i++) {
        out[i] = (char)dyn_array_get_u8(bytes, i);
    }
    out[len] = '\0';
    return out;
}

static DynArray* nl_array_slice(DynArray* arr, int64_t start, int64_t length) {
    if (!arr) return dyn_array_new(ELEM_INT);
    if (start < 0) start = 0;
    if (length < 0) length = 0;
    int64_t len = dyn_array_length(arr);
    if (start > len) start = len;
    if (length > len - start) length = len - start;
    int64_t end = start + length;
    if (end > len) end = len;
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = start; i < end; i++) {
        switch (t) {
            case ELEM_U8: dyn_array_push_u8(out, dyn_array_get_u8(arr, i)); break;
            case ELEM_INT: dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT: dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL: dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            case ELEM_ARRAY: dyn_array_push_array(out, dyn_array_get_array(arr, i)); break;
            case ELEM_STRUCT: dyn_array_push_struct(out, dyn_array_get_struct(arr, i), (size_t)arr->elem_size); break;
            default: assert(false && "nl_array_slice: unsupported element type");
        }
    }
    return out;
}

static void nl_println_bool(bool value) {
    printf("%s\n", value ? "true" : "false");
}

static void nl_print_array(DynArray* arr) {
    printf("[");
    for (int i = 0; i < arr->length; i++) {
        if (i > 0) printf(", ");
        switch (arr->elem_type) {
            case ELEM_INT:
                printf("%lld", (long long)((int64_t*)arr->data)[i]);
                break;
            case ELEM_U8:
                printf("%u", (unsigned)((uint8_t*)arr->data)[i]);
                break;
            case ELEM_FLOAT:
                nano_rt_f64_print(stdout, ((double*)arr->data)[i]);
                break;
            default:
                printf("?");
                break;
        }
    }
    printf("]");
}

static void nl_println_array(DynArray* arr) {
    nl_print_array(arr);
    printf("\n");
}

/* ========== Array Operations (With Bounds Checking!) ========== */

static DynArray* nl_array_sort(DynArray* arr) {
    return dyn_array_sorted(arr);
}

static DynArray* nl_array_reverse(DynArray* arr) {
    if (!arr) return dyn_array_new(ELEM_INT);
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = len - 1; i >= 0; i--) {
        switch (t) {
            case ELEM_INT:    dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT:  dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL:   dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            default: dyn_array_push_int(out, 0); break;
        }
    }
    return out;
}

static bool nl_array_contains(DynArray* arr, int64_t elem) {
    if (!arr) return false;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return true;
    }
    return false;
}

static int64_t nl_array_index_of(DynArray* arr, int64_t elem) {
    if (!arr) return -1;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return i;
    }
    return -1;
}

/* ========== End Array Operations ========== */

/* ========== End Math and Utility Built-in Functions ========== */

/* ========== Coroutine Runtime Builtins ========== */
#include "coroutine.h"

typedef struct { void *fn; int64_t args[8]; int nargs; } NlSpawnCtx;
static Value nl_coro_spawn_trampoline(void *raw, int coro_id) {
    (void)coro_id;
    NlSpawnCtx *ctx = (NlSpawnCtx *)raw;
    Value v; memset(&v, 0, sizeof(v)); v.type = VAL_INT;
    switch (ctx->nargs) {
        case 0: v.as.int_val = ((int64_t(*)(void))ctx->fn)(); break;
        case 1: v.as.int_val = ((int64_t(*)(int64_t))ctx->fn)(ctx->args[0]); break;
        case 2: v.as.int_val = ((int64_t(*)(int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1]); break;
        case 3: v.as.int_val = ((int64_t(*)(int64_t,int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1],ctx->args[2]); break;
        default: break;
    }
    return v;
}

static int64_t nl_coro_spawn_n(void *fn, int nargs, int64_t a0, int64_t a1, int64_t a2) {
    nano_scheduler_init();
    NlSpawnCtx *ctx = (NlSpawnCtx *)malloc(sizeof(NlSpawnCtx));
    if (!ctx) return -1;
    ctx->fn = fn; ctx->nargs = nargs;
    ctx->args[0] = a0; ctx->args[1] = a1; ctx->args[2] = a2;
    return (int64_t)nano_coro_spawn(nl_coro_spawn_trampoline, ctx);
}
/* nl_coro_spawn: select correct overload by argument count */
#define _nl_cs0(fn)           nl_coro_spawn_n((void*)(fn),0,0LL,0LL,0LL)
#define _nl_cs1(fn,a)         nl_coro_spawn_n((void*)(fn),1,(int64_t)(a),0LL,0LL)
#define _nl_cs2(fn,a,b)       nl_coro_spawn_n((void*)(fn),2,(int64_t)(a),(int64_t)(b),0LL)
#define _nl_cs3(fn,a,b,c)     nl_coro_spawn_n((void*)(fn),3,(int64_t)(a),(int64_t)(b),(int64_t)(c))
#define _nl_cs_pick(_1,_2,_3,_4,X,...) X
#define nl_coro_spawn(fn,...) _nl_cs_pick(fn,##__VA_ARGS__,_nl_cs3,_nl_cs2,_nl_cs1,_nl_cs0)(fn,##__VA_ARGS__)

/* nl_scheduler_run(): drain all pending coroutines */
static void nl_scheduler_run(void) {
    nano_scheduler_init();
    nano_scheduler_run_until_done();
}

/* nl_scheduler_step(): run one step */
static int64_t nl_scheduler_step(void) {
    nano_scheduler_init();
    return nano_scheduler_step() ? 1 : 0;
}

/* nl_coro_result(id): get result value of completed coroutine */
static int64_t nl_coro_result(int64_t id) {
    Value v = nano_coro_result((int)id);
    return v.as.int_val;
}

/* nl_coro_done(id): 1 if coroutine completed */
static int64_t nl_coro_done(int64_t id) {
    return nano_coro_is_done((int)id) ? 1 : 0;
}

/* nl_coro_yield(): cooperative yield hint */
static void nl_coro_yield(void) { nano_coro_yield(); }
/* ========== End Coroutine Runtime Builtins ========== */

/* ========== Enum Definitions ========== */

typedef enum {
    nl_LexerTokenType_TOKEN_EOF = 0,
    nl_LexerTokenType_TOKEN_NUMBER = 1,
    nl_LexerTokenType_TOKEN_FLOAT = 2,
    nl_LexerTokenType_TOKEN_STRING = 3,
    nl_LexerTokenType_TOKEN_IDENTIFIER = 4,
    nl_LexerTokenType_TOKEN_TRUE = 5,
    nl_LexerTokenType_TOKEN_FALSE = 6,
    nl_LexerTokenType_TOKEN_LPAREN = 7,
    nl_LexerTokenType_TOKEN_RPAREN = 8,
    nl_LexerTokenType_TOKEN_LBRACE = 9,
    nl_LexerTokenType_TOKEN_RBRACE = 10,
    nl_LexerTokenType_TOKEN_LBRACKET = 11,
    nl_LexerTokenType_TOKEN_RBRACKET = 12,
    nl_LexerTokenType_TOKEN_COMMA = 13,
    nl_LexerTokenType_TOKEN_COLON = 14,
    nl_LexerTokenType_TOKEN_DOUBLE_COLON = 15,
    nl_LexerTokenType_TOKEN_ARROW = 16,
    nl_LexerTokenType_TOKEN_ASSIGN = 17,
    nl_LexerTokenType_TOKEN_DOT = 18,
    nl_LexerTokenType_TOKEN_MODULE = 19,
    nl_LexerTokenType_TOKEN_PUB = 20,
    nl_LexerTokenType_TOKEN_FROM = 21,
    nl_LexerTokenType_TOKEN_USE = 22,
    nl_LexerTokenType_TOKEN_EXTERN = 23,
    nl_LexerTokenType_TOKEN_FN = 24,
    nl_LexerTokenType_TOKEN_LET = 25,
    nl_LexerTokenType_TOKEN_MUT = 26,
    nl_LexerTokenType_TOKEN_SET = 27,
    nl_LexerTokenType_TOKEN_IF = 28,
    nl_LexerTokenType_TOKEN_ELSE = 29,
    nl_LexerTokenType_TOKEN_COND = 30,
    nl_LexerTokenType_TOKEN_WHILE = 31,
    nl_LexerTokenType_TOKEN_FOR = 32,
    nl_LexerTokenType_TOKEN_IN = 33,
    nl_LexerTokenType_TOKEN_RETURN = 34,
    nl_LexerTokenType_TOKEN_BREAK = 35,
    nl_LexerTokenType_TOKEN_CONTINUE = 36,
    nl_LexerTokenType_TOKEN_ASSERT = 37,
    nl_LexerTokenType_TOKEN_SHADOW = 38,
    nl_LexerTokenType_TOKEN_REQUIRES = 39,
    nl_LexerTokenType_TOKEN_ENSURES = 40,
    nl_LexerTokenType_TOKEN_PRINT = 41,
    nl_LexerTokenType_TOKEN_ARRAY = 42,
    nl_LexerTokenType_TOKEN_STRUCT = 43,
    nl_LexerTokenType_TOKEN_ENUM = 44,
    nl_LexerTokenType_TOKEN_UNION = 45,
    nl_LexerTokenType_TOKEN_MATCH = 46,
    nl_LexerTokenType_TOKEN_IMPORT = 47,
    nl_LexerTokenType_TOKEN_AS = 48,
    nl_LexerTokenType_TOKEN_OPAQUE = 49,
    nl_LexerTokenType_TOKEN_TYPE_INT = 50,
    nl_LexerTokenType_TOKEN_TYPE_U8 = 51,
    nl_LexerTokenType_TOKEN_TYPE_FLOAT = 52,
    nl_LexerTokenType_TOKEN_TYPE_BOOL = 53,
    nl_LexerTokenType_TOKEN_TYPE_STRING = 54,
    nl_LexerTokenType_TOKEN_TYPE_BSTRING = 55,
    nl_LexerTokenType_TOKEN_TYPE_VOID = 56,
    nl_LexerTokenType_TOKEN_PLUS = 57,
    nl_LexerTokenType_TOKEN_MINUS = 58,
    nl_LexerTokenType_TOKEN_STAR = 59,
    nl_LexerTokenType_TOKEN_SLASH = 60,
    nl_LexerTokenType_TOKEN_PERCENT = 61,
    nl_LexerTokenType_TOKEN_EQ = 62,
    nl_LexerTokenType_TOKEN_NE = 63,
    nl_LexerTokenType_TOKEN_LT = 64,
    nl_LexerTokenType_TOKEN_LE = 65,
    nl_LexerTokenType_TOKEN_GT = 66,
    nl_LexerTokenType_TOKEN_GE = 67,
    nl_LexerTokenType_TOKEN_AND = 68,
    nl_LexerTokenType_TOKEN_OR = 69,
    nl_LexerTokenType_TOKEN_NOT = 70,
    nl_LexerTokenType_TOKEN_RANGE = 71,
    nl_LexerTokenType_TOKEN_UNSAFE = 72,
    nl_LexerTokenType_TOKEN_RESOURCE = 73,
    nl_LexerTokenType_TOKEN_PIPE = 74,
    nl_LexerTokenType_TOKEN_GRAMMAR = 75,
    nl_LexerTokenType_TOKEN_LARROW = 76,
    nl_LexerTokenType_TOKEN_QUESTION = 77,
    nl_LexerTokenType_TOKEN_PAR = 78,
    nl_LexerTokenType_TOKEN_BAR = 79,
    nl_LexerTokenType_TOKEN_EFFECT = 80,
    nl_LexerTokenType_TOKEN_HANDLE = 81,
    nl_LexerTokenType_TOKEN_WITH = 82,
    nl_LexerTokenType_TOKEN_RESUME = 83,
    nl_LexerTokenType_TOKEN_GPU = 84,
    nl_LexerTokenType_TOKEN_ASYNC = 85,
    nl_LexerTokenType_TOKEN_AWAIT = 86,
    nl_LexerTokenType_TOKEN_PURE = 87,
    nl_LexerTokenType_TOKEN_AMPERSAND = 88
} nl_LexerTokenType;

typedef enum {
    nl_ParseNodeType_PNODE_NUMBER = 0,
    nl_ParseNodeType_PNODE_FLOAT = 1,
    nl_ParseNodeType_PNODE_STRING = 2,
    nl_ParseNodeType_PNODE_BOOL = 3,
    nl_ParseNodeType_PNODE_IDENTIFIER = 4,
    nl_ParseNodeType_PNODE_BINARY_OP = 5,
    nl_ParseNodeType_PNODE_CALL = 6,
    nl_ParseNodeType_PNODE_ARRAY_LITERAL = 7,
    nl_ParseNodeType_PNODE_LET = 8,
    nl_ParseNodeType_PNODE_SET = 9,
    nl_ParseNodeType_PNODE_IF = 10,
    nl_ParseNodeType_PNODE_COND = 11,
    nl_ParseNodeType_PNODE_WHILE = 12,
    nl_ParseNodeType_PNODE_FOR = 13,
    nl_ParseNodeType_PNODE_RETURN = 14,
    nl_ParseNodeType_PNODE_BREAK = 15,
    nl_ParseNodeType_PNODE_CONTINUE = 16,
    nl_ParseNodeType_PNODE_BLOCK = 17,
    nl_ParseNodeType_PNODE_PRINT = 18,
    nl_ParseNodeType_PNODE_ASSERT = 19,
    nl_ParseNodeType_PNODE_PROGRAM = 20,
    nl_ParseNodeType_PNODE_FUNCTION = 21,
    nl_ParseNodeType_PNODE_SHADOW = 22,
    nl_ParseNodeType_PNODE_STRUCT_DEF = 23,
    nl_ParseNodeType_PNODE_STRUCT_LITERAL = 24,
    nl_ParseNodeType_PNODE_FIELD_ACCESS = 25,
    nl_ParseNodeType_PNODE_ENUM_DEF = 26,
    nl_ParseNodeType_PNODE_UNION_DEF = 27,
    nl_ParseNodeType_PNODE_UNION_CONSTRUCT = 28,
    nl_ParseNodeType_PNODE_MATCH = 29,
    nl_ParseNodeType_PNODE_IMPORT = 30,
    nl_ParseNodeType_PNODE_OPAQUE_TYPE = 31,
    nl_ParseNodeType_PNODE_TUPLE_LITERAL = 32,
    nl_ParseNodeType_PNODE_TUPLE_INDEX = 33,
    nl_ParseNodeType_PNODE_STRUCT = 34,
    nl_ParseNodeType_PNODE_ENUM = 35,
    nl_ParseNodeType_PNODE_UNION = 36,
    nl_ParseNodeType_PNODE_UNSAFE_BLOCK = 37,
    nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL = 38,
    nl_ParseNodeType_PNODE_GRAMMAR = 39,
    nl_ParseNodeType_PNODE_PAR_BLOCK = 40,
    nl_ParseNodeType_PNODE_EFFECT_DECL = 41,
    nl_ParseNodeType_PNODE_HANDLE_EXPR = 42,
    nl_ParseNodeType_PNODE_ASYNC_FN = 43,
    nl_ParseNodeType_PNODE_SERVICE_DECL = 44
} nl_ParseNodeType;

typedef enum {
    nl_TypeKind_TYPE_INT = 0,
    nl_TypeKind_TYPE_FLOAT = 1,
    nl_TypeKind_TYPE_BOOL = 2,
    nl_TypeKind_TYPE_STRING = 3,
    nl_TypeKind_TYPE_VOID = 4,
    nl_TypeKind_TYPE_ARRAY = 5,
    nl_TypeKind_TYPE_STRUCT = 6,
    nl_TypeKind_TYPE_ENUM = 7,
    nl_TypeKind_TYPE_UNION = 8,
    nl_TypeKind_TYPE_GENERIC = 9,
    nl_TypeKind_TYPE_LIST_INT = 10,
    nl_TypeKind_TYPE_LIST_STRING = 11,
    nl_TypeKind_TYPE_LIST_TOKEN = 12,
    nl_TypeKind_TYPE_LIST_GENERIC = 13,
    nl_TypeKind_TYPE_FUNCTION = 14,
    nl_TypeKind_TYPE_TUPLE = 15,
    nl_TypeKind_TYPE_OPAQUE = 16,
    nl_TypeKind_TYPE_UNKNOWN = 17
} nl_TypeKind;

/* ========== End Enum Definitions ========== */

#ifndef FORWARD_DEFINED_List_CompilerDiagnostic
#define FORWARD_DEFINED_List_CompilerDiagnostic
typedef struct List_CompilerDiagnostic List_CompilerDiagnostic;
#endif
#ifndef FORWARD_DEFINED_List_LexerToken
#define FORWARD_DEFINED_List_LexerToken
typedef struct List_LexerToken List_LexerToken;
#endif
#ifndef FORWARD_DEFINED_List_ASTStmtRef
#define FORWARD_DEFINED_List_ASTStmtRef
typedef struct List_ASTStmtRef List_ASTStmtRef;
#endif
#ifndef FORWARD_DEFINED_List_ASTNumber
#define FORWARD_DEFINED_List_ASTNumber
typedef struct List_ASTNumber List_ASTNumber;
#endif
#ifndef FORWARD_DEFINED_List_ASTFloat
#define FORWARD_DEFINED_List_ASTFloat
typedef struct List_ASTFloat List_ASTFloat;
#endif
#ifndef FORWARD_DEFINED_List_ASTString
#define FORWARD_DEFINED_List_ASTString
typedef struct List_ASTString List_ASTString;
#endif
#ifndef FORWARD_DEFINED_List_ASTBool
#define FORWARD_DEFINED_List_ASTBool
typedef struct List_ASTBool List_ASTBool;
#endif
#ifndef FORWARD_DEFINED_List_ASTIdentifier
#define FORWARD_DEFINED_List_ASTIdentifier
typedef struct List_ASTIdentifier List_ASTIdentifier;
#endif
#ifndef FORWARD_DEFINED_List_ASTBinaryOp
#define FORWARD_DEFINED_List_ASTBinaryOp
typedef struct List_ASTBinaryOp List_ASTBinaryOp;
#endif
#ifndef FORWARD_DEFINED_List_ASTCall
#define FORWARD_DEFINED_List_ASTCall
typedef struct List_ASTCall List_ASTCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTModuleQualifiedCall
#define FORWARD_DEFINED_List_ASTModuleQualifiedCall
typedef struct List_ASTModuleQualifiedCall List_ASTModuleQualifiedCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTArrayLiteral
#define FORWARD_DEFINED_List_ASTArrayLiteral
typedef struct List_ASTArrayLiteral List_ASTArrayLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTLet
#define FORWARD_DEFINED_List_ASTLet
typedef struct List_ASTLet List_ASTLet;
#endif
#ifndef FORWARD_DEFINED_List_ASTSet
#define FORWARD_DEFINED_List_ASTSet
typedef struct List_ASTSet List_ASTSet;
#endif
#ifndef FORWARD_DEFINED_List_ASTIf
#define FORWARD_DEFINED_List_ASTIf
typedef struct List_ASTIf List_ASTIf;
#endif
#ifndef FORWARD_DEFINED_List_ASTWhile
#define FORWARD_DEFINED_List_ASTWhile
typedef struct List_ASTWhile List_ASTWhile;
#endif
#ifndef FORWARD_DEFINED_List_ASTFor
#define FORWARD_DEFINED_List_ASTFor
typedef struct List_ASTFor List_ASTFor;
#endif
#ifndef FORWARD_DEFINED_List_ASTReturn
#define FORWARD_DEFINED_List_ASTReturn
typedef struct List_ASTReturn List_ASTReturn;
#endif
#ifndef FORWARD_DEFINED_List_ASTBlock
#define FORWARD_DEFINED_List_ASTBlock
typedef struct List_ASTBlock List_ASTBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnsafeBlock
#define FORWARD_DEFINED_List_ASTUnsafeBlock
typedef struct List_ASTUnsafeBlock List_ASTUnsafeBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTPrint
#define FORWARD_DEFINED_List_ASTPrint
typedef struct List_ASTPrint List_ASTPrint;
#endif
#ifndef FORWARD_DEFINED_List_ASTAssert
#define FORWARD_DEFINED_List_ASTAssert
typedef struct List_ASTAssert List_ASTAssert;
#endif
#ifndef FORWARD_DEFINED_List_ASTFunction
#define FORWARD_DEFINED_List_ASTFunction
typedef struct List_ASTFunction List_ASTFunction;
#endif
#ifndef FORWARD_DEFINED_List_ASTShadow
#define FORWARD_DEFINED_List_ASTShadow
typedef struct List_ASTShadow List_ASTShadow;
#endif
#ifndef FORWARD_DEFINED_List_ASTStruct
#define FORWARD_DEFINED_List_ASTStruct
typedef struct List_ASTStruct List_ASTStruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTStructLiteral
#define FORWARD_DEFINED_List_ASTStructLiteral
typedef struct List_ASTStructLiteral List_ASTStructLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTFieldAccess
#define FORWARD_DEFINED_List_ASTFieldAccess
typedef struct List_ASTFieldAccess List_ASTFieldAccess;
#endif
#ifndef FORWARD_DEFINED_List_ASTEnum
#define FORWARD_DEFINED_List_ASTEnum
typedef struct List_ASTEnum List_ASTEnum;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnion
#define FORWARD_DEFINED_List_ASTUnion
typedef struct List_ASTUnion List_ASTUnion;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnionConstruct
#define FORWARD_DEFINED_List_ASTUnionConstruct
typedef struct List_ASTUnionConstruct List_ASTUnionConstruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTMatch
#define FORWARD_DEFINED_List_ASTMatch
typedef struct List_ASTMatch List_ASTMatch;
#endif
#ifndef FORWARD_DEFINED_List_ASTImport
#define FORWARD_DEFINED_List_ASTImport
typedef struct List_ASTImport List_ASTImport;
#endif
#ifndef FORWARD_DEFINED_List_ASTOpaqueType
#define FORWARD_DEFINED_List_ASTOpaqueType
typedef struct List_ASTOpaqueType List_ASTOpaqueType;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleLiteral
#define FORWARD_DEFINED_List_ASTTupleLiteral
typedef struct List_ASTTupleLiteral List_ASTTupleLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleIndex
#define FORWARD_DEFINED_List_ASTTupleIndex
typedef struct List_ASTTupleIndex List_ASTTupleIndex;
#endif
#ifndef FORWARD_DEFINED_List_ASTServiceDecl
#define FORWARD_DEFINED_List_ASTServiceDecl
typedef struct List_ASTServiceDecl List_ASTServiceDecl;
#endif
/* ========== Struct and Union Definitions ========== */

/* ========== End Struct and Union Definitions ========== */

/* ========== Auto-Generated Struct Metadata ========== */

/* ========== End Struct Metadata ========== */

#include "runtime/list_CompilerDiagnostic.h"
#include "runtime/list_LexerToken.h"
#include "runtime/list_ASTStmtRef.h"
#include "runtime/list_ASTNumber.h"
#include "runtime/list_ASTFloat.h"
#include "runtime/list_ASTString.h"
#include "runtime/list_ASTBool.h"
#include "runtime/list_ASTIdentifier.h"
#include "runtime/list_ASTBinaryOp.h"
#include "runtime/list_ASTCall.h"
#include "runtime/list_ASTModuleQualifiedCall.h"
#include "runtime/list_ASTArrayLiteral.h"
#include "runtime/list_ASTLet.h"
#include "runtime/list_ASTSet.h"
#include "runtime/list_ASTIf.h"
#include "runtime/list_ASTWhile.h"
#include "runtime/list_ASTFor.h"
#include "runtime/list_ASTReturn.h"
#include "runtime/list_ASTBlock.h"
#include "runtime/list_ASTUnsafeBlock.h"
#include "runtime/list_ASTPrint.h"
#include "runtime/list_ASTAssert.h"
#include "runtime/list_ASTFunction.h"
#include "runtime/list_ASTShadow.h"
#include "runtime/list_ASTStruct.h"
#include "runtime/list_ASTStructLiteral.h"
#include "runtime/list_ASTFieldAccess.h"
#include "runtime/list_ASTEnum.h"
#include "runtime/list_ASTUnion.h"
#include "runtime/list_ASTUnionConstruct.h"
#include "runtime/list_ASTMatch.h"
#include "runtime/list_ASTImport.h"
#include "runtime/list_ASTOpaqueType.h"
#include "runtime/list_ASTTupleLiteral.h"
#include "runtime/list_ASTTupleIndex.h"
#include "runtime/list_ASTServiceDecl.h"
/* ========== HashMap Runtime (Generated) ========== */

static uint64_t nl_hashmap_hash_string(const char *s) {
    if (!s) return 0;
    uint64_t hash = 1469598103934665603ULL;
    while (*s) { hash ^= (uint8_t)(*s++); hash *= 1099511628211ULL; }
    return hash;
}

static uint64_t nl_hashmap_hash_int(int64_t x) {
    uint64_t z = (uint64_t)x;
    z ^= z >> 33;
    z *= 0xff51afd7ed558ccdULL;
    z ^= z >> 33;
    z *= 0xc4ceb9fe1a85ec53ULL;
    z ^= z >> 33;
    return z;
}

static bool nl_hashmap_key_eq_string(const char *a, const char *b) {
    if (a == b) return true;
    if (!a || !b) return false;
    return strcmp(a, b) == 0;
}

/* (no HashMap instantiations) */

/* ========== End HashMap Runtime (Generated) ========== */

/* ========== To-String Helpers ========== */

/* To-String forward declarations */
static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v);
static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v);
static const char* nl_to_string_TypeKind(nl_TypeKind v);
static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v);
static const char* nl_to_string_CompilerPhase(CompilerPhase v);

static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v) {
    switch (v) {
        case nl_LexerTokenType_TOKEN_EOF: return "LexerTokenType.TOKEN_EOF";
        case nl_LexerTokenType_TOKEN_NUMBER: return "LexerTokenType.TOKEN_NUMBER";
        case nl_LexerTokenType_TOKEN_FLOAT: return "LexerTokenType.TOKEN_FLOAT";
        case nl_LexerTokenType_TOKEN_STRING: return "LexerTokenType.TOKEN_STRING";
        case nl_LexerTokenType_TOKEN_IDENTIFIER: return "LexerTokenType.TOKEN_IDENTIFIER";
        case nl_LexerTokenType_TOKEN_TRUE: return "LexerTokenType.TOKEN_TRUE";
        case nl_LexerTokenType_TOKEN_FALSE: return "LexerTokenType.TOKEN_FALSE";
        case nl_LexerTokenType_TOKEN_LPAREN: return "LexerTokenType.TOKEN_LPAREN";
        case nl_LexerTokenType_TOKEN_RPAREN: return "LexerTokenType.TOKEN_RPAREN";
        case nl_LexerTokenType_TOKEN_LBRACE: return "LexerTokenType.TOKEN_LBRACE";
        case nl_LexerTokenType_TOKEN_RBRACE: return "LexerTokenType.TOKEN_RBRACE";
        case nl_LexerTokenType_TOKEN_LBRACKET: return "LexerTokenType.TOKEN_LBRACKET";
        case nl_LexerTokenType_TOKEN_RBRACKET: return "LexerTokenType.TOKEN_RBRACKET";
        case nl_LexerTokenType_TOKEN_COMMA: return "LexerTokenType.TOKEN_COMMA";
        case nl_LexerTokenType_TOKEN_COLON: return "LexerTokenType.TOKEN_COLON";
        case nl_LexerTokenType_TOKEN_DOUBLE_COLON: return "LexerTokenType.TOKEN_DOUBLE_COLON";
        case nl_LexerTokenType_TOKEN_ARROW: return "LexerTokenType.TOKEN_ARROW";
        case nl_LexerTokenType_TOKEN_ASSIGN: return "LexerTokenType.TOKEN_ASSIGN";
        case nl_LexerTokenType_TOKEN_DOT: return "LexerTokenType.TOKEN_DOT";
        case nl_LexerTokenType_TOKEN_MODULE: return "LexerTokenType.TOKEN_MODULE";
        case nl_LexerTokenType_TOKEN_PUB: return "LexerTokenType.TOKEN_PUB";
        case nl_LexerTokenType_TOKEN_FROM: return "LexerTokenType.TOKEN_FROM";
        case nl_LexerTokenType_TOKEN_USE: return "LexerTokenType.TOKEN_USE";
        case nl_LexerTokenType_TOKEN_EXTERN: return "LexerTokenType.TOKEN_EXTERN";
        case nl_LexerTokenType_TOKEN_FN: return "LexerTokenType.TOKEN_FN";
        case nl_LexerTokenType_TOKEN_LET: return "LexerTokenType.TOKEN_LET";
        case nl_LexerTokenType_TOKEN_MUT: return "LexerTokenType.TOKEN_MUT";
        case nl_LexerTokenType_TOKEN_SET: return "LexerTokenType.TOKEN_SET";
        case nl_LexerTokenType_TOKEN_IF: return "LexerTokenType.TOKEN_IF";
        case nl_LexerTokenType_TOKEN_ELSE: return "LexerTokenType.TOKEN_ELSE";
        case nl_LexerTokenType_TOKEN_COND: return "LexerTokenType.TOKEN_COND";
        case nl_LexerTokenType_TOKEN_WHILE: return "LexerTokenType.TOKEN_WHILE";
        case nl_LexerTokenType_TOKEN_FOR: return "LexerTokenType.TOKEN_FOR";
        case nl_LexerTokenType_TOKEN_IN: return "LexerTokenType.TOKEN_IN";
        case nl_LexerTokenType_TOKEN_RETURN: return "LexerTokenType.TOKEN_RETURN";
        case nl_LexerTokenType_TOKEN_BREAK: return "LexerTokenType.TOKEN_BREAK";
        case nl_LexerTokenType_TOKEN_CONTINUE: return "LexerTokenType.TOKEN_CONTINUE";
        case nl_LexerTokenType_TOKEN_ASSERT: return "LexerTokenType.TOKEN_ASSERT";
        case nl_LexerTokenType_TOKEN_SHADOW: return "LexerTokenType.TOKEN_SHADOW";
        case nl_LexerTokenType_TOKEN_REQUIRES: return "LexerTokenType.TOKEN_REQUIRES";
        case nl_LexerTokenType_TOKEN_ENSURES: return "LexerTokenType.TOKEN_ENSURES";
        case nl_LexerTokenType_TOKEN_PRINT: return "LexerTokenType.TOKEN_PRINT";
        case nl_LexerTokenType_TOKEN_ARRAY: return "LexerTokenType.TOKEN_ARRAY";
        case nl_LexerTokenType_TOKEN_STRUCT: return "LexerTokenType.TOKEN_STRUCT";
        case nl_LexerTokenType_TOKEN_ENUM: return "LexerTokenType.TOKEN_ENUM";
        case nl_LexerTokenType_TOKEN_UNION: return "LexerTokenType.TOKEN_UNION";
        case nl_LexerTokenType_TOKEN_MATCH: return "LexerTokenType.TOKEN_MATCH";
        case nl_LexerTokenType_TOKEN_IMPORT: return "LexerTokenType.TOKEN_IMPORT";
        case nl_LexerTokenType_TOKEN_AS: return "LexerTokenType.TOKEN_AS";
        case nl_LexerTokenType_TOKEN_OPAQUE: return "LexerTokenType.TOKEN_OPAQUE";
        case nl_LexerTokenType_TOKEN_TYPE_INT: return "LexerTokenType.TOKEN_TYPE_INT";
        case nl_LexerTokenType_TOKEN_TYPE_U8: return "LexerTokenType.TOKEN_TYPE_U8";
        case nl_LexerTokenType_TOKEN_TYPE_FLOAT: return "LexerTokenType.TOKEN_TYPE_FLOAT";
        case nl_LexerTokenType_TOKEN_TYPE_BOOL: return "LexerTokenType.TOKEN_TYPE_BOOL";
        case nl_LexerTokenType_TOKEN_TYPE_STRING: return "LexerTokenType.TOKEN_TYPE_STRING";
        case nl_LexerTokenType_TOKEN_TYPE_BSTRING: return "LexerTokenType.TOKEN_TYPE_BSTRING";
        case nl_LexerTokenType_TOKEN_TYPE_VOID: return "LexerTokenType.TOKEN_TYPE_VOID";
        case nl_LexerTokenType_TOKEN_PLUS: return "LexerTokenType.TOKEN_PLUS";
        case nl_LexerTokenType_TOKEN_MINUS: return "LexerTokenType.TOKEN_MINUS";
        case nl_LexerTokenType_TOKEN_STAR: return "LexerTokenType.TOKEN_STAR";
        case nl_LexerTokenType_TOKEN_SLASH: return "LexerTokenType.TOKEN_SLASH";
        case nl_LexerTokenType_TOKEN_PERCENT: return "LexerTokenType.TOKEN_PERCENT";
        case nl_LexerTokenType_TOKEN_EQ: return "LexerTokenType.TOKEN_EQ";
        case nl_LexerTokenType_TOKEN_NE: return "LexerTokenType.TOKEN_NE";
        case nl_LexerTokenType_TOKEN_LT: return "LexerTokenType.TOKEN_LT";
        case nl_LexerTokenType_TOKEN_LE: return "LexerTokenType.TOKEN_LE";
        case nl_LexerTokenType_TOKEN_GT: return "LexerTokenType.TOKEN_GT";
        case nl_LexerTokenType_TOKEN_GE: return "LexerTokenType.TOKEN_GE";
        case nl_LexerTokenType_TOKEN_AND: return "LexerTokenType.TOKEN_AND";
        case nl_LexerTokenType_TOKEN_OR: return "LexerTokenType.TOKEN_OR";
        case nl_LexerTokenType_TOKEN_NOT: return "LexerTokenType.TOKEN_NOT";
        case nl_LexerTokenType_TOKEN_RANGE: return "LexerTokenType.TOKEN_RANGE";
        case nl_LexerTokenType_TOKEN_UNSAFE: return "LexerTokenType.TOKEN_UNSAFE";
        case nl_LexerTokenType_TOKEN_RESOURCE: return "LexerTokenType.TOKEN_RESOURCE";
        case nl_LexerTokenType_TOKEN_PIPE: return "LexerTokenType.TOKEN_PIPE";
        case nl_LexerTokenType_TOKEN_GRAMMAR: return "LexerTokenType.TOKEN_GRAMMAR";
        case nl_LexerTokenType_TOKEN_LARROW: return "LexerTokenType.TOKEN_LARROW";
        case nl_LexerTokenType_TOKEN_QUESTION: return "LexerTokenType.TOKEN_QUESTION";
        case nl_LexerTokenType_TOKEN_PAR: return "LexerTokenType.TOKEN_PAR";
        case nl_LexerTokenType_TOKEN_BAR: return "LexerTokenType.TOKEN_BAR";
        case nl_LexerTokenType_TOKEN_EFFECT: return "LexerTokenType.TOKEN_EFFECT";
        case nl_LexerTokenType_TOKEN_HANDLE: return "LexerTokenType.TOKEN_HANDLE";
        case nl_LexerTokenType_TOKEN_WITH: return "LexerTokenType.TOKEN_WITH";
        case nl_LexerTokenType_TOKEN_RESUME: return "LexerTokenType.TOKEN_RESUME";
        case nl_LexerTokenType_TOKEN_GPU: return "LexerTokenType.TOKEN_GPU";
        case nl_LexerTokenType_TOKEN_ASYNC: return "LexerTokenType.TOKEN_ASYNC";
        case nl_LexerTokenType_TOKEN_AWAIT: return "LexerTokenType.TOKEN_AWAIT";
        case nl_LexerTokenType_TOKEN_PURE: return "LexerTokenType.TOKEN_PURE";
        case nl_LexerTokenType_TOKEN_AMPERSAND: return "LexerTokenType.TOKEN_AMPERSAND";
        default: return "LexerTokenType.<unknown>";
    }
}

static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v) {
    switch (v) {
        case nl_ParseNodeType_PNODE_NUMBER: return "ParseNodeType.PNODE_NUMBER";
        case nl_ParseNodeType_PNODE_FLOAT: return "ParseNodeType.PNODE_FLOAT";
        case nl_ParseNodeType_PNODE_STRING: return "ParseNodeType.PNODE_STRING";
        case nl_ParseNodeType_PNODE_BOOL: return "ParseNodeType.PNODE_BOOL";
        case nl_ParseNodeType_PNODE_IDENTIFIER: return "ParseNodeType.PNODE_IDENTIFIER";
        case nl_ParseNodeType_PNODE_BINARY_OP: return "ParseNodeType.PNODE_BINARY_OP";
        case nl_ParseNodeType_PNODE_CALL: return "ParseNodeType.PNODE_CALL";
        case nl_ParseNodeType_PNODE_ARRAY_LITERAL: return "ParseNodeType.PNODE_ARRAY_LITERAL";
        case nl_ParseNodeType_PNODE_LET: return "ParseNodeType.PNODE_LET";
        case nl_ParseNodeType_PNODE_SET: return "ParseNodeType.PNODE_SET";
        case nl_ParseNodeType_PNODE_IF: return "ParseNodeType.PNODE_IF";
        case nl_ParseNodeType_PNODE_COND: return "ParseNodeType.PNODE_COND";
        case nl_ParseNodeType_PNODE_WHILE: return "ParseNodeType.PNODE_WHILE";
        case nl_ParseNodeType_PNODE_FOR: return "ParseNodeType.PNODE_FOR";
        case nl_ParseNodeType_PNODE_RETURN: return "ParseNodeType.PNODE_RETURN";
        case nl_ParseNodeType_PNODE_BREAK: return "ParseNodeType.PNODE_BREAK";
        case nl_ParseNodeType_PNODE_CONTINUE: return "ParseNodeType.PNODE_CONTINUE";
        case nl_ParseNodeType_PNODE_BLOCK: return "ParseNodeType.PNODE_BLOCK";
        case nl_ParseNodeType_PNODE_PRINT: return "ParseNodeType.PNODE_PRINT";
        case nl_ParseNodeType_PNODE_ASSERT: return "ParseNodeType.PNODE_ASSERT";
        case nl_ParseNodeType_PNODE_PROGRAM: return "ParseNodeType.PNODE_PROGRAM";
        case nl_ParseNodeType_PNODE_FUNCTION: return "ParseNodeType.PNODE_FUNCTION";
        case nl_ParseNodeType_PNODE_SHADOW: return "ParseNodeType.PNODE_SHADOW";
        case nl_ParseNodeType_PNODE_STRUCT_DEF: return "ParseNodeType.PNODE_STRUCT_DEF";
        case nl_ParseNodeType_PNODE_STRUCT_LITERAL: return "ParseNodeType.PNODE_STRUCT_LITERAL";
        case nl_ParseNodeType_PNODE_FIELD_ACCESS: return "ParseNodeType.PNODE_FIELD_ACCESS";
        case nl_ParseNodeType_PNODE_ENUM_DEF: return "ParseNodeType.PNODE_ENUM_DEF";
        case nl_ParseNodeType_PNODE_UNION_DEF: return "ParseNodeType.PNODE_UNION_DEF";
        case nl_ParseNodeType_PNODE_UNION_CONSTRUCT: return "ParseNodeType.PNODE_UNION_CONSTRUCT";
        case nl_ParseNodeType_PNODE_MATCH: return "ParseNodeType.PNODE_MATCH";
        case nl_ParseNodeType_PNODE_IMPORT: return "ParseNodeType.PNODE_IMPORT";
        case nl_ParseNodeType_PNODE_OPAQUE_TYPE: return "ParseNodeType.PNODE_OPAQUE_TYPE";
        case nl_ParseNodeType_PNODE_TUPLE_LITERAL: return "ParseNodeType.PNODE_TUPLE_LITERAL";
        case nl_ParseNodeType_PNODE_TUPLE_INDEX: return "ParseNodeType.PNODE_TUPLE_INDEX";
        case nl_ParseNodeType_PNODE_STRUCT: return "ParseNodeType.PNODE_STRUCT";
        case nl_ParseNodeType_PNODE_ENUM: return "ParseNodeType.PNODE_ENUM";
        case nl_ParseNodeType_PNODE_UNION: return "ParseNodeType.PNODE_UNION";
        case nl_ParseNodeType_PNODE_UNSAFE_BLOCK: return "ParseNodeType.PNODE_UNSAFE_BLOCK";
        case nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL: return "ParseNodeType.PNODE_MODULE_QUALIFIED_CALL";
        case nl_ParseNodeType_PNODE_GRAMMAR: return "ParseNodeType.PNODE_GRAMMAR";
        case nl_ParseNodeType_PNODE_PAR_BLOCK: return "ParseNodeType.PNODE_PAR_BLOCK";
        case nl_ParseNodeType_PNODE_EFFECT_DECL: return "ParseNodeType.PNODE_EFFECT_DECL";
        case nl_ParseNodeType_PNODE_HANDLE_EXPR: return "ParseNodeType.PNODE_HANDLE_EXPR";
        case nl_ParseNodeType_PNODE_ASYNC_FN: return "ParseNodeType.PNODE_ASYNC_FN";
        case nl_ParseNodeType_PNODE_SERVICE_DECL: return "ParseNodeType.PNODE_SERVICE_DECL";
        default: return "ParseNodeType.<unknown>";
    }
}

static const char* nl_to_string_TypeKind(nl_TypeKind v) {
    switch (v) {
        case nl_TypeKind_TYPE_INT: return "TypeKind.TYPE_INT";
        case nl_TypeKind_TYPE_FLOAT: return "TypeKind.TYPE_FLOAT";
        case nl_TypeKind_TYPE_BOOL: return "TypeKind.TYPE_BOOL";
        case nl_TypeKind_TYPE_STRING: return "TypeKind.TYPE_STRING";
        case nl_TypeKind_TYPE_VOID: return "TypeKind.TYPE_VOID";
        case nl_TypeKind_TYPE_ARRAY: return "TypeKind.TYPE_ARRAY";
        case nl_TypeKind_TYPE_STRUCT: return "TypeKind.TYPE_STRUCT";
        case nl_TypeKind_TYPE_ENUM: return "TypeKind.TYPE_ENUM";
        case nl_TypeKind_TYPE_UNION: return "TypeKind.TYPE_UNION";
        case nl_TypeKind_TYPE_GENERIC: return "TypeKind.TYPE_GENERIC";
        case nl_TypeKind_TYPE_LIST_INT: return "TypeKind.TYPE_LIST_INT";
        case nl_TypeKind_TYPE_LIST_STRING: return "TypeKind.TYPE_LIST_STRING";
        case nl_TypeKind_TYPE_LIST_TOKEN: return "TypeKind.TYPE_LIST_TOKEN";
        case nl_TypeKind_TYPE_LIST_GENERIC: return "TypeKind.TYPE_LIST_GENERIC";
        case nl_TypeKind_TYPE_FUNCTION: return "TypeKind.TYPE_FUNCTION";
        case nl_TypeKind_TYPE_TUPLE: return "TypeKind.TYPE_TUPLE";
        case nl_TypeKind_TYPE_OPAQUE: return "TypeKind.TYPE_OPAQUE";
        case nl_TypeKind_TYPE_UNKNOWN: return "TypeKind.TYPE_UNKNOWN";
        default: return "TypeKind.<unknown>";
    }
}

static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v) {
    switch (v) {
        case DiagnosticSeverity_DIAG_INFO: return "DiagnosticSeverity.DIAG_INFO";
        case DiagnosticSeverity_DIAG_WARNING: return "DiagnosticSeverity.DIAG_WARNING";
        case DiagnosticSeverity_DIAG_ERROR: return "DiagnosticSeverity.DIAG_ERROR";
        default: return "DiagnosticSeverity.<unknown>";
    }
}

static const char* nl_to_string_CompilerPhase(CompilerPhase v) {
    switch (v) {
        case CompilerPhase_PHASE_LEXER: return "CompilerPhase.PHASE_LEXER";
        case CompilerPhase_PHASE_PARSER: return "CompilerPhase.PHASE_PARSER";
        case CompilerPhase_PHASE_TYPECHECK: return "CompilerPhase.PHASE_TYPECHECK";
        case CompilerPhase_PHASE_TRANSPILER: return "CompilerPhase.PHASE_TRANSPILER";
        case CompilerPhase_PHASE_RUNTIME: return "CompilerPhase.PHASE_RUNTIME";
        default: return "CompilerPhase.<unknown>";
    }
}

/* ========== End To-String Helpers ========== */

/* External C function declarations */
extern DynArray* fs_walkdir(const char* _root);
extern const char* path_normalize(const char* _path);
extern const char* path_canonical(const char* _path);
extern const char* path_join(const char* _a, const char* _b);
extern const char* path_basename(const char* _path);
extern const char* path_dirname(const char* _path);
extern const char* file_read(const char* _path);
extern int64_t file_write(const char* _path, const char* _content);
extern int64_t file_append(const char* _path, const char* _content);
extern bool file_exists(const char* _path);
extern int64_t file_delete(const char* _path);

/* Forward declarations for imported module functions */
extern int64_t token_value_bytes__token_literal_value_bytes(const char* raw);
extern CompilerSourceLocation diagnostics__diag_location(const char* file, int64_t line, int64_t column);
extern CompilerSourceLocation diagnostics__diag_location_empty();
extern CompilerDiagnostic diagnostics__diag_new(int64_t phase, int64_t severity, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_simple(int64_t phase, int64_t severity, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_error(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_error_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_warning(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_warning_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_info(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_info_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_lexer_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_parser_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_typecheck_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_transpiler_error(const char* code, const char* message, CompilerSourceLocation location);
extern List_CompilerDiagnostic* diagnostics__diag_list_new();
extern void diagnostics__diag_list_add(List_CompilerDiagnostic* list, CompilerDiagnostic diag);
extern int64_t diagnostics__diag_list_count(List_CompilerDiagnostic* list);
extern CompilerDiagnostic diagnostics__diag_list_get(List_CompilerDiagnostic* list, int64_t index);
extern bool diagnostics__diag_list_has_errors(List_CompilerDiagnostic* list);
extern const char* diagnostics__diag_make_type_error(const char* expected_type, const char* found_type);
extern const char* diagnostics__diag_make_undefined_error(const char* name);
extern const char* diagnostics__diag_id_io_open();
extern const char* diagnostics__diag_id_lex_failed();
extern const char* diagnostics__diag_id_parse_failed();
extern const char* diagnostics__diag_id_import_failed();
extern const char* diagnostics__diag_id_type_failed();
extern const char* diagnostics__diag_id_mod_compile();
extern const char* diagnostics__diag_id_shadow_failed();
extern const char* diagnostics__diag_id_trans_failed();
extern const char* diagnostics__diag_id_c_temp();
extern const char* diagnostics__diag_id_cc_cmd();
extern const char* diagnostics__diag_id_cc_failed();
extern const char* diagnostics__diag_id_src_utf8();
extern const char* diagnostics__diag_en(const char* code);
extern DynArray* fs_walkdir(const char* _root);
extern const char* path_normalize(const char* _path);
extern const char* path_canonical(const char* _path);
extern const char* path_join(const char* _a, const char* _b);
extern const char* path_basename(const char* _path);
extern const char* path_dirname(const char* _path);
extern const char* path_relpath(const char* _target, const char* _base);
extern const char* file_read(const char* _path);
extern int64_t file_write(const char* _path, const char* _content);
extern int64_t file_append(const char* _path, const char* _content);
extern bool file_exists(const char* _path);
extern int64_t file_delete(const char* _path);
extern int64_t fs_mkdir_p(const char* _path);
extern int64_t file_copy(const char* _src, const char* _dst);
extern int64_t dir_copy(const char* _src, const char* _dst);
extern DynArray* std_fs__walkdir(const char* root);
extern const char* std_fs__normalize(const char* path);
extern const char* std_fs__canonical(const char* path);
extern const char* std_fs__join(const char* a, const char* b);
extern const char* std_fs__basename(const char* path);
extern const char* std_fs__dirname(const char* path);
extern const char* std_fs__relpath(const char* target, const char* base);
extern const char* std_fs__cwd();
extern bool std_fs__glob_match_impl(const char* pattern, int64_t pi, const char* text, int64_t ti);
extern bool std_fs__glob_match(const char* pattern, const char* text);
extern DynArray* std_fs__glob(const char* root, const char* pattern);
extern const char* std_fs__read(const char* path);
extern int64_t std_fs__write(const char* path, const char* content);
extern int64_t std_fs__append(const char* path, const char* content);
extern bool std_fs__exists(const char* path);
extern int64_t std_fs__delete(const char* path);
extern int64_t std_fs__mkdir_p(const char* path);
extern int64_t std_fs__copy_file(const char* src, const char* dst);
extern int64_t std_fs__copy_dir(const char* src, const char* dst);

/* Forward declarations for program functions */
bool lexer__is_identifier_start(int64_t c);
bool lexer__is_identifier_char(int64_t c);
bool lexer__is_whitespace_char(int64_t c);
bool lexer__is_digit_char(int64_t c);
int64_t lexer__keyword_group1(const char* s);
int64_t lexer__keyword_group2(const char* s);
int64_t lexer__keyword_group3(const char* s);
int64_t lexer__keyword_group4(const char* s);
int64_t lexer__keyword_group5(const char* s);
int64_t lexer__keyword_or_identifier(const char* s);
void lexer__push_tok(List_LexerToken* tokens, int64_t token_type, const char* value, int64_t line, int64_t column);
int64_t lexer__process_string(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
int64_t lexer__process_number(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
int64_t lexer__process_grammar_body(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
int64_t lexer__process_identifier(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
int64_t lexer__process_char_literal(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
void lexer__emit_fstring_part_tokens(const char* part_text, int64_t is_expr, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column);
int64_t lexer__process_fstring(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column);
List_LexerToken* lexer__tokenize_string(const char* source, const char* file_name, List_CompilerDiagnostic* diags);
List_LexerToken* lexer__tokenize_file(const char* path, List_CompilerDiagnostic* diags);

/* Top-level globals */

bool lexer__is_identifier_start(int64_t c) {
#line 15 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return (((((((c) >= (65LL)) && ((c) <= (90LL)))) || ((((c) >= (97LL)) && ((c) <= (122LL)))))) || ((c) == (95LL)));
}

bool lexer__is_identifier_char(int64_t c) {
#line 30 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return ((({ __auto_type __nl_arg_52_0 = c; lexer__is_identifier_start(__nl_arg_52_0); })) || ((((c) >= (48LL)) && ((c) <= (57LL)))));
}

bool lexer__is_whitespace_char(int64_t c) {
#line 44 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return (((((((c) == (32LL)) || ((c) == (9LL)))) || ((c) == (10LL)))) || ((c) == (13LL)));
}

bool lexer__is_digit_char(int64_t c) {
#line 56 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return (((c) >= (48LL)) && ((c) <= (57LL)));
}

int64_t lexer__keyword_group1(const char* s) {
#line 69 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "break") == 0))     {
#line 69 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_BREAK;
    }
#line 70 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "continue") == 0))     {
#line 70 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_CONTINUE;
    }
#line 71 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "module") == 0))     {
#line 71 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_MODULE;
    }
    else     {
#line 72 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((strcmp(s, "pub") == 0))         {
#line 72 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return nl_LexerTokenType_TOKEN_PUB;
        }
        else         {
#line 73 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((strcmp(s, "from") == 0))             {
#line 73 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return nl_LexerTokenType_TOKEN_FROM;
            }
            else             {
#line 74 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((strcmp(s, "use") == 0))                 {
#line 74 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    return nl_LexerTokenType_TOKEN_USE;
                }
                else                 {
#line 75 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    return -1LL;
                }
            }
        }
    }
}

int64_t lexer__keyword_group2(const char* s) {
#line 93 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "par") == 0))     {
#line 93 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_PAR;
    }
#line 94 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "extern") == 0))     {
#line 94 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_EXTERN;
    }
    else     {
#line 95 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((strcmp(s, "fn") == 0))         {
#line 95 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return nl_LexerTokenType_TOKEN_FN;
        }
        else         {
#line 96 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((strcmp(s, "let") == 0))             {
#line 96 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return nl_LexerTokenType_TOKEN_LET;
            }
            else             {
#line 97 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((strcmp(s, "mut") == 0))                 {
#line 97 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    return nl_LexerTokenType_TOKEN_MUT;
                }
                else                 {
#line 98 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((strcmp(s, "set") == 0))                     {
#line 98 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        return nl_LexerTokenType_TOKEN_SET;
                    }
                    else                     {
#line 99 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((strcmp(s, "if") == 0))                         {
#line 99 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            return nl_LexerTokenType_TOKEN_IF;
                        }
                        else                         {
#line 100 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            if ((strcmp(s, "else") == 0))                             {
#line 100 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                return nl_LexerTokenType_TOKEN_ELSE;
                            }
                            else                             {
#line 101 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                if ((strcmp(s, "while") == 0))                                 {
#line 101 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    return nl_LexerTokenType_TOKEN_WHILE;
                                }
                                else                                 {
#line 102 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    if ((strcmp(s, "for") == 0))                                     {
#line 102 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                        return nl_LexerTokenType_TOKEN_FOR;
                                    }
                                    else                                     {
#line 103 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                        if ((strcmp(s, "in") == 0))                                         {
#line 103 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                            return nl_LexerTokenType_TOKEN_IN;
                                        }
                                        else                                         {
#line 104 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                            if ((strcmp(s, "return") == 0))                                             {
#line 104 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                return nl_LexerTokenType_TOKEN_RETURN;
                                            }
                                            else                                             {
#line 105 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                if ((strcmp(s, "assert") == 0))                                                 {
#line 105 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                    return nl_LexerTokenType_TOKEN_ASSERT;
                                                }
                                                else                                                 {
#line 106 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                    if ((strcmp(s, "shadow") == 0))                                                     {
#line 106 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                        return nl_LexerTokenType_TOKEN_SHADOW;
                                                    }
                                                    else                                                     {
#line 107 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                        if ((strcmp(s, "requires") == 0))                                                         {
#line 107 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                            return nl_LexerTokenType_TOKEN_REQUIRES;
                                                        }
                                                        else                                                         {
#line 108 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                            if ((strcmp(s, "ensures") == 0))                                                             {
#line 108 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                return nl_LexerTokenType_TOKEN_ENSURES;
                                                            }
                                                            else                                                             {
#line 109 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                if ((strcmp(s, "array") == 0))                                                                 {
#line 109 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    return nl_LexerTokenType_TOKEN_ARRAY;
                                                                }
                                                                else                                                                 {
#line 110 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    if ((strcmp(s, "struct") == 0))                                                                     {
#line 110 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        return nl_LexerTokenType_TOKEN_STRUCT;
                                                                    }
                                                                    else                                                                     {
#line 111 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        if ((strcmp(s, "enum") == 0))                                                                         {
#line 111 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            return nl_LexerTokenType_TOKEN_ENUM;
                                                                        }
                                                                        else                                                                         {
#line 112 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            if ((strcmp(s, "union") == 0))                                                                             {
#line 112 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                return nl_LexerTokenType_TOKEN_UNION;
                                                                            }
                                                                            else                                                                             {
#line 113 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                if ((strcmp(s, "match") == 0))                                                                                 {
#line 113 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                    return nl_LexerTokenType_TOKEN_MATCH;
                                                                                }
                                                                                else                                                                                 {
#line 114 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                    if ((strcmp(s, "import") == 0))                                                                                     {
#line 114 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                        return nl_LexerTokenType_TOKEN_IMPORT;
                                                                                    }
                                                                                    else                                                                                     {
#line 115 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                        if ((strcmp(s, "as") == 0))                                                                                         {
#line 115 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                            return nl_LexerTokenType_TOKEN_AS;
                                                                                        }
                                                                                        else                                                                                         {
#line 116 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                            if ((strcmp(s, "opaque") == 0))                                                                                             {
#line 116 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                return nl_LexerTokenType_TOKEN_OPAQUE;
                                                                                            }
                                                                                            else                                                                                             {
#line 117 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                if ((strcmp(s, "unsafe") == 0))                                                                                                 {
#line 117 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                    return nl_LexerTokenType_TOKEN_UNSAFE;
                                                                                                }
                                                                                                else                                                                                                 {
#line 118 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                    if ((strcmp(s, "pure") == 0))                                                                                                     {
#line 118 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                        return nl_LexerTokenType_TOKEN_PURE;
                                                                                                    }
                                                                                                    else                                                                                                     {
#line 119 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                        if ((strcmp(s, "resource") == 0))                                                                                                         {
#line 119 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                            return nl_LexerTokenType_TOKEN_RESOURCE;
                                                                                                        }
                                                                                                        else                                                                                                         {
#line 120 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                            if ((strcmp(s, "true") == 0))                                                                                                             {
#line 120 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                return nl_LexerTokenType_TOKEN_TRUE;
                                                                                                            }
                                                                                                            else                                                                                                             {
#line 121 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                if ((strcmp(s, "false") == 0))                                                                                                                 {
#line 121 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                    return nl_LexerTokenType_TOKEN_FALSE;
                                                                                                                }
                                                                                                                else                                                                                                                 {
#line 122 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                    return -1LL;
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

int64_t lexer__keyword_group3(const char* s) {
#line 168 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "int") == 0))     {
#line 168 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_TYPE_INT;
    }
    else     {
#line 169 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((strcmp(s, "u8") == 0))         {
#line 169 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return nl_LexerTokenType_TOKEN_TYPE_U8;
        }
        else         {
#line 170 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((strcmp(s, "float") == 0))             {
#line 170 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return nl_LexerTokenType_TOKEN_TYPE_FLOAT;
            }
            else             {
#line 171 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((strcmp(s, "bool") == 0))                 {
#line 171 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    return nl_LexerTokenType_TOKEN_TYPE_BOOL;
                }
                else                 {
#line 172 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((strcmp(s, "string") == 0))                     {
#line 172 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        return nl_LexerTokenType_TOKEN_TYPE_STRING;
                    }
                    else                     {
#line 173 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((strcmp(s, "bstring") == 0))                         {
#line 173 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            return nl_LexerTokenType_TOKEN_TYPE_BSTRING;
                        }
                        else                         {
#line 174 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            if ((strcmp(s, "void") == 0))                             {
#line 174 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                return nl_LexerTokenType_TOKEN_TYPE_VOID;
                            }
                            else                             {
#line 175 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                return -1LL;
                            }
                        }
                    }
                }
            }
        }
    }
}

int64_t lexer__keyword_group4(const char* s) {
#line 196 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "and") == 0))     {
#line 196 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_AND;
    }
    else     {
#line 197 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((strcmp(s, "or") == 0))         {
#line 197 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return nl_LexerTokenType_TOKEN_OR;
        }
        else         {
#line 198 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((strcmp(s, "not") == 0))             {
#line 198 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return nl_LexerTokenType_TOKEN_NOT;
            }
            else             {
#line 199 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return -1LL;
            }
        }
    }
}

int64_t lexer__keyword_group5(const char* s) {
#line 213 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((strcmp(s, "grammar") == 0))     {
#line 213 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return nl_LexerTokenType_TOKEN_GRAMMAR;
    }
    else     {
#line 214 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
}

int64_t lexer__keyword_or_identifier(const char* s) {
#line 224 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t t1 = ({ __auto_type __nl_arg_53_0 = s; lexer__keyword_group1(__nl_arg_53_0); });
#line 225 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((t1) != (-1LL))     {
#line 226 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return t1;
    }
    else     {
#line 228 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t t2 = ({ __auto_type __nl_arg_54_0 = s; lexer__keyword_group2(__nl_arg_54_0); });
#line 229 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((t2) != (-1LL))         {
#line 230 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return t2;
        }
        else         {
#line 232 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            int64_t t3 = ({ __auto_type __nl_arg_55_0 = s; lexer__keyword_group3(__nl_arg_55_0); });
#line 233 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((t3) != (-1LL))             {
#line 234 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                return t3;
            }
            else             {
#line 236 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                int64_t t4 = ({ __auto_type __nl_arg_56_0 = s; lexer__keyword_group4(__nl_arg_56_0); });
#line 237 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((t4) != (-1LL))                 {
#line 238 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    return t4;
                }
                else                 {
#line 240 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    int64_t t5 = ({ __auto_type __nl_arg_57_0 = s; lexer__keyword_group5(__nl_arg_57_0); });
#line 241 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((t5) != (-1LL))                     {
#line 242 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        return t5;
                    }
                    else                     {
#line 244 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        return nl_LexerTokenType_TOKEN_IDENTIFIER;
                    }
                }
            }
        }
    }
}

void lexer__push_tok(List_LexerToken* tokens, int64_t token_type, const char* value, int64_t line, int64_t column) {
#line 261 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t value_bytes = ({ __auto_type __nl_arg_58_0 = value; nl_cstr_length(__nl_arg_58_0); });
#line 262 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((token_type) == (nl_LexerTokenType_TOKEN_STRING))     {
#line 263 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        value_bytes = ({ __auto_type __nl_arg_59_0 = value; token_value_bytes__token_literal_value_bytes(__nl_arg_59_0); });
    }
#line 265 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    LexerToken tok = (LexerToken){.token_type = token_type, .value = value, .line = line, .column = column, .value_bytes = value_bytes};
#line 266 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    ({ __auto_type __nl_arg_60_0 = tokens; __auto_type __nl_arg_60_1 = tok; if (!__nl_arg_60_0) nl_record_list_fail(); nl_list_LexerToken_push(__nl_arg_60_0, __nl_arg_60_1); });
}

int64_t lexer__process_string(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column) {
#line 281 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = ((i) + (1LL));
#line 282 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t start = pos;
#line 283 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && ((({ __auto_type __nl_arg_61_0 = source; __auto_type __nl_arg_61_1 = pos; char_at(__nl_arg_61_0, __nl_arg_61_1); })) != (34LL))))     {
#line 284 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((((({ __auto_type __nl_arg_62_0 = source; __auto_type __nl_arg_62_1 = pos; char_at(__nl_arg_62_0, __nl_arg_62_1); })) == (92LL)) && ((((pos) + (1LL))) < (len))))         {
#line 285 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            pos = ((pos) + (2LL));
        }
        else         {
#line 287 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            pos = ((pos) + (1LL));
        }
    }
#line 290 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((pos) >= (len))     {
#line 291 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
    else     {
#line 293 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t str_length = ((pos) - (start));
#line 294 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        const char* str_value = ({ __auto_type __nl_arg_63_0 = source; __auto_type __nl_arg_63_1 = start; __auto_type __nl_arg_63_2 = str_length; nl_str_substring(__nl_arg_63_0, __nl_arg_63_1, __nl_arg_63_2); });
#line 295 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_64_0 = tokens; __auto_type __nl_arg_64_1 = nl_LexerTokenType_TOKEN_STRING; __auto_type __nl_arg_64_2 = str_value; __auto_type __nl_arg_64_3 = line; __auto_type __nl_arg_64_4 = column; lexer__push_tok(__nl_arg_64_0, __nl_arg_64_1, __nl_arg_64_2, __nl_arg_64_3, __nl_arg_64_4); });
#line 296 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return ((pos) + (1LL));
    }
}

int64_t lexer__process_number(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column) {
#line 309 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = i;
#line 310 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t start = pos;
#line 311 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((({ __auto_type __nl_arg_65_0 = source; __auto_type __nl_arg_65_1 = pos; char_at(__nl_arg_65_0, __nl_arg_65_1); })) == (45LL))     {
#line 312 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
    }
    else     {
#line 314 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        nl_print_string("");
    }
#line 317 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && (({ __auto_type __nl_arg_66_0 = ({ __auto_type __nl_arg_67_0 = source; __auto_type __nl_arg_67_1 = pos; char_at(__nl_arg_67_0, __nl_arg_67_1); }); lexer__is_digit_char(__nl_arg_66_0); }))))     {
#line 318 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
    }
#line 321 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((((((pos) < (len)) && ((({ __auto_type __nl_arg_68_0 = source; __auto_type __nl_arg_68_1 = pos; char_at(__nl_arg_68_0, __nl_arg_68_1); })) == (46LL)))) && ((((((pos) + (1LL))) < (len)) && (({ __auto_type __nl_arg_69_0 = ({ __auto_type __nl_arg_70_0 = source; __auto_type __nl_arg_70_1 = ((pos) + (1LL)); char_at(__nl_arg_70_0, __nl_arg_70_1); }); lexer__is_digit_char(__nl_arg_69_0); }))))))     {
#line 322 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
#line 323 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        while ((((pos) < (len)) && (({ __auto_type __nl_arg_71_0 = ({ __auto_type __nl_arg_72_0 = source; __auto_type __nl_arg_72_1 = pos; char_at(__nl_arg_72_0, __nl_arg_72_1); }); lexer__is_digit_char(__nl_arg_71_0); }))))         {
#line 324 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            pos = ((pos) + (1LL));
        }
#line 326 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t float_length = ((pos) - (start));
#line 327 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        const char* float_value = ({ __auto_type __nl_arg_73_0 = source; __auto_type __nl_arg_73_1 = start; __auto_type __nl_arg_73_2 = float_length; nl_str_substring(__nl_arg_73_0, __nl_arg_73_1, __nl_arg_73_2); });
#line 328 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_74_0 = tokens; __auto_type __nl_arg_74_1 = nl_LexerTokenType_TOKEN_FLOAT; __auto_type __nl_arg_74_2 = float_value; __auto_type __nl_arg_74_3 = line; __auto_type __nl_arg_74_4 = column; lexer__push_tok(__nl_arg_74_0, __nl_arg_74_1, __nl_arg_74_2, __nl_arg_74_3, __nl_arg_74_4); });
#line 329 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return pos;
    }
    else     {
#line 331 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t num_length = ((pos) - (start));
#line 332 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        const char* num_value = ({ __auto_type __nl_arg_75_0 = source; __auto_type __nl_arg_75_1 = start; __auto_type __nl_arg_75_2 = num_length; nl_str_substring(__nl_arg_75_0, __nl_arg_75_1, __nl_arg_75_2); });
#line 333 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_76_0 = tokens; __auto_type __nl_arg_76_1 = nl_LexerTokenType_TOKEN_NUMBER; __auto_type __nl_arg_76_2 = num_value; __auto_type __nl_arg_76_3 = line; __auto_type __nl_arg_76_4 = column; lexer__push_tok(__nl_arg_76_0, __nl_arg_76_1, __nl_arg_76_2, __nl_arg_76_3, __nl_arg_76_4); });
#line 334 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return pos;
    }
}

int64_t lexer__process_grammar_body(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column) {
#line 353 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = i;
#line 355 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && (({ __auto_type __nl_arg_77_0 = ({ __auto_type __nl_arg_78_0 = source; __auto_type __nl_arg_78_1 = pos; char_at(__nl_arg_78_0, __nl_arg_78_1); }); lexer__is_whitespace_char(__nl_arg_77_0); }))))     {
#line 356 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
    }
#line 359 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((((pos) >= (len)) || ((({ __auto_type __nl_arg_79_0 = source; __auto_type __nl_arg_79_1 = pos; char_at(__nl_arg_79_0, __nl_arg_79_1); })) != (123LL))))     {
#line 360 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return i;
    }
    else     {
#line 362 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        nl_print_string("");
    }
#line 364 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    pos = ((pos) + (1LL));
#line 365 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t body_start = pos;
#line 366 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t depth = 1LL;
#line 367 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && ((depth) > (0LL))))     {
#line 368 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t c = ({ __auto_type __nl_arg_80_0 = source; __auto_type __nl_arg_80_1 = pos; char_at(__nl_arg_80_0, __nl_arg_80_1); });
#line 369 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((c) == (123LL))         {
#line 370 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            depth = ((depth) + (1LL));
        }
        else         {
#line 372 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((c) == (125LL))             {
#line 373 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                depth = ((depth) - (1LL));
            }
            else             {
#line 375 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                nl_print_string("");
            }
        }
#line 378 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((depth) > (0LL))         {
#line 379 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            pos = ((pos) + (1LL));
        }
    }
#line 383 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t body_len = ((pos) - (body_start));
#line 384 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    const char* body = ({ __auto_type __nl_arg_81_0 = source; __auto_type __nl_arg_81_1 = body_start; __auto_type __nl_arg_81_2 = body_len; nl_str_substring(__nl_arg_81_0, __nl_arg_81_1, __nl_arg_81_2); });
#line 386 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    LexerToken body_token = (LexerToken){.token_type = nl_LexerTokenType_TOKEN_STRING, .value = body, .line = line, .column = column, .value_bytes = body_len};
#line 387 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    ({ __auto_type __nl_arg_82_0 = tokens; __auto_type __nl_arg_82_1 = body_token; if (!__nl_arg_82_0) nl_record_list_fail(); nl_list_LexerToken_push(__nl_arg_82_0, __nl_arg_82_1); });
#line 388 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return ((pos) + (1LL));
}

int64_t lexer__process_identifier(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column) {
#line 403 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = i;
#line 404 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t start = pos;
#line 405 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && (({ __auto_type __nl_arg_83_0 = ({ __auto_type __nl_arg_84_0 = source; __auto_type __nl_arg_84_1 = pos; char_at(__nl_arg_84_0, __nl_arg_84_1); }); lexer__is_identifier_char(__nl_arg_83_0); }))))     {
#line 406 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
    }
#line 408 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t id_length = ((pos) - (start));
#line 409 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    const char* id_value = ({ __auto_type __nl_arg_85_0 = source; __auto_type __nl_arg_85_1 = start; __auto_type __nl_arg_85_2 = id_length; nl_str_substring(__nl_arg_85_0, __nl_arg_85_1, __nl_arg_85_2); });
#line 410 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t token_type = ({ __auto_type __nl_arg_86_0 = id_value; lexer__keyword_or_identifier(__nl_arg_86_0); });
#line 411 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    ({ __auto_type __nl_arg_87_0 = tokens; __auto_type __nl_arg_87_1 = token_type; __auto_type __nl_arg_87_2 = id_value; __auto_type __nl_arg_87_3 = line; __auto_type __nl_arg_87_4 = column; lexer__push_tok(__nl_arg_87_0, __nl_arg_87_1, __nl_arg_87_2, __nl_arg_87_3, __nl_arg_87_4); });
#line 413 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((token_type) == (nl_LexerTokenType_TOKEN_GRAMMAR))     {
#line 414 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return ({ __auto_type __nl_arg_88_0 = source; __auto_type __nl_arg_88_1 = pos; __auto_type __nl_arg_88_2 = len; __auto_type __nl_arg_88_3 = tokens; __auto_type __nl_arg_88_4 = line; __auto_type __nl_arg_88_5 = column; lexer__process_grammar_body(__nl_arg_88_0, __nl_arg_88_1, __nl_arg_88_2, __nl_arg_88_3, __nl_arg_88_4, __nl_arg_88_5); });
    }
    else     {
#line 416 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return pos;
    }
}

int64_t lexer__process_char_literal(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column) {
#line 444 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = ((i) + (1LL));
#line 445 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((pos) >= (len))     {
#line 446 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
    else     {
#line 448 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        nl_print_string("");
    }
#line 451 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t ch = ({ __auto_type __nl_arg_89_0 = source; __auto_type __nl_arg_89_1 = pos; char_at(__nl_arg_89_0, __nl_arg_89_1); });
#line 452 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((ch) == (92LL))     {
#line 453 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        pos = ((pos) + (1LL));
#line 454 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((pos) >= (len))         {
#line 455 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            return -1LL;
        }
        else         {
#line 457 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            nl_print_string("");
        }
#line 459 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t esc = ({ __auto_type __nl_arg_90_0 = source; __auto_type __nl_arg_90_1 = pos; char_at(__nl_arg_90_0, __nl_arg_90_1); });
#line 460 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((esc) == (110LL))         {
#line 460 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            ch = 10LL;
        }
        else         {
#line 461 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((esc) == (116LL))             {
#line 461 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ch = 9LL;
            }
            else             {
#line 462 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((esc) == (114LL))                 {
#line 462 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    ch = 13LL;
                }
                else                 {
#line 463 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((esc) == (48LL))                     {
#line 463 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        ch = 0LL;
                    }
                    else                     {
#line 464 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((esc) == (92LL))                         {
#line 464 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            ch = 92LL;
                        }
                        else                         {
#line 465 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            if ((esc) == (39LL))                             {
#line 465 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                ch = 39LL;
                            }
                            else                             {
#line 466 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                if ((esc) == (34LL))                                 {
#line 466 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    ch = 34LL;
                                }
                                else                                 {
#line 467 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    ch = esc;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else     {
#line 470 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        nl_print_string("");
    }
#line 473 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    pos = ((pos) + (1LL));
#line 474 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((pos) >= (len))     {
#line 475 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
    else     {
#line 477 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        nl_print_string("");
    }
#line 480 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((({ __auto_type __nl_arg_91_0 = source; __auto_type __nl_arg_91_1 = pos; char_at(__nl_arg_91_0, __nl_arg_91_1); })) != (39LL))     {
#line 481 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
    else     {
#line 483 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        const char* value_str = ({ __auto_type __nl_arg_92_0 = ch; int_to_string(__nl_arg_92_0); });
#line 484 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_93_0 = tokens; __auto_type __nl_arg_93_1 = nl_LexerTokenType_TOKEN_NUMBER; __auto_type __nl_arg_93_2 = value_str; __auto_type __nl_arg_93_3 = line; __auto_type __nl_arg_93_4 = column; lexer__push_tok(__nl_arg_93_0, __nl_arg_93_1, __nl_arg_93_2, __nl_arg_93_3, __nl_arg_93_4); });
#line 485 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return ((pos) + (1LL));
    }
}

void lexer__emit_fstring_part_tokens(const char* part_text, int64_t is_expr, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column) {
#line 502 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((is_expr) != (0LL))     {
#line 504 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_94_0 = tokens; __auto_type __nl_arg_94_1 = nl_LexerTokenType_TOKEN_LPAREN; __auto_type __nl_arg_94_2 = ""; __auto_type __nl_arg_94_3 = line; __auto_type __nl_arg_94_4 = column; lexer__push_tok(__nl_arg_94_0, __nl_arg_94_1, __nl_arg_94_2, __nl_arg_94_3, __nl_arg_94_4); });
#line 505 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_95_0 = tokens; __auto_type __nl_arg_95_1 = nl_LexerTokenType_TOKEN_IDENTIFIER; __auto_type __nl_arg_95_2 = "to_string"; __auto_type __nl_arg_95_3 = line; __auto_type __nl_arg_95_4 = column; lexer__push_tok(__nl_arg_95_0, __nl_arg_95_1, __nl_arg_95_2, __nl_arg_95_3, __nl_arg_95_4); });
#line 506 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        List_LexerToken* sub_tokens = ({ __auto_type __nl_arg_96_0 = part_text; __auto_type __nl_arg_96_1 = file_name; __auto_type __nl_arg_96_2 = diags; lexer__tokenize_string(__nl_arg_96_0, __nl_arg_96_1, __nl_arg_96_2); });
#line 507 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t n = ({ __auto_type __nl_arg_97_0 = sub_tokens; if (!__nl_arg_97_0) nl_record_list_fail(); nl_list_LexerToken_length(__nl_arg_97_0); });
#line 508 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t k = 0LL;
#line 509 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        while ((k) < (n))         {
#line 510 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            LexerToken tok = ({ __auto_type __nl_arg_98_0 = sub_tokens; __auto_type __nl_arg_98_1 = k; if (!__nl_arg_98_0) nl_record_list_fail(); __nl_arg_98_1 = nl_native_list_index(__nl_arg_98_1, nl_list_LexerToken_length(__nl_arg_98_0), false); nl_list_LexerToken_get(__nl_arg_98_0, __nl_arg_98_1); });
#line 511 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((tok.token_type) != (nl_LexerTokenType_TOKEN_EOF))             {
#line 512 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_99_0 = tokens; __auto_type __nl_arg_99_1 = tok; if (!__nl_arg_99_0) nl_record_list_fail(); nl_list_LexerToken_push(__nl_arg_99_0, __nl_arg_99_1); });
            }
            else             {
#line 514 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                nl_print_string("");
            }
#line 516 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            k = ((k) + (1LL));
        }
#line 518 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_100_0 = tokens; __auto_type __nl_arg_100_1 = nl_LexerTokenType_TOKEN_RPAREN; __auto_type __nl_arg_100_2 = ""; __auto_type __nl_arg_100_3 = line; __auto_type __nl_arg_100_4 = column; lexer__push_tok(__nl_arg_100_0, __nl_arg_100_1, __nl_arg_100_2, __nl_arg_100_3, __nl_arg_100_4); });
    }
    else     {
#line 521 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_101_0 = tokens; __auto_type __nl_arg_101_1 = nl_LexerTokenType_TOKEN_STRING; __auto_type __nl_arg_101_2 = part_text; __auto_type __nl_arg_101_3 = line; __auto_type __nl_arg_101_4 = column; lexer__push_tok(__nl_arg_101_0, __nl_arg_101_1, __nl_arg_101_2, __nl_arg_101_3, __nl_arg_101_4); });
    }
}

int64_t lexer__process_fstring(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column) {
#line 549 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t pos = ((i) + (2LL));
#line 551 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    List_string* part_texts = ({ list_string_new(); });
#line 552 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    List_int* part_is_exprs = ({ list_int_new(); });
#line 554 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t part_start = pos;
#line 555 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    bool found_end = false;
#line 557 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((((pos) < (len)) && ((!found_end))))     {
#line 558 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t c = ({ __auto_type __nl_arg_104_0 = source; __auto_type __nl_arg_104_1 = pos; char_at(__nl_arg_104_0, __nl_arg_104_1); });
#line 559 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((c) == (34LL))         {
#line 561 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            const char* text = ({ __auto_type __nl_arg_105_0 = source; __auto_type __nl_arg_105_1 = part_start; __auto_type __nl_arg_105_2 = ((pos) - (part_start)); nl_str_substring(__nl_arg_105_0, __nl_arg_105_1, __nl_arg_105_2); });
#line 562 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((({ __auto_type __nl_arg_106_0 = text; nl_cstr_length(__nl_arg_106_0); })) != (0LL))             {
#line 563 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_107_0 = part_texts; __auto_type __nl_arg_107_1 = text; if (!__nl_arg_107_0) nl_record_list_fail(); list_string_push(__nl_arg_107_0, __nl_arg_107_1); });
#line 564 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_108_0 = part_is_exprs; __auto_type __nl_arg_108_1 = 0LL; if (!__nl_arg_108_0) nl_record_list_fail(); list_int_push(__nl_arg_108_0, __nl_arg_108_1); });
            }
            else             {
#line 566 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                nl_print_string("");
            }
#line 568 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            pos = ((pos) + (1LL));
#line 569 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            found_end = true;
        }
        else         {
#line 571 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((((c) == (92LL)) && ((((pos) + (1LL))) < (len))))             {
#line 573 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                pos = ((pos) + (2LL));
            }
            else             {
#line 575 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((c) == (123LL))                 {
#line 578 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    const char* text = ({ __auto_type __nl_arg_109_0 = source; __auto_type __nl_arg_109_1 = part_start; __auto_type __nl_arg_109_2 = ((pos) - (part_start)); nl_str_substring(__nl_arg_109_0, __nl_arg_109_1, __nl_arg_109_2); });
#line 579 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((({ __auto_type __nl_arg_110_0 = text; nl_cstr_length(__nl_arg_110_0); })) != (0LL))                     {
#line 580 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        ({ __auto_type __nl_arg_111_0 = part_texts; __auto_type __nl_arg_111_1 = text; if (!__nl_arg_111_0) nl_record_list_fail(); list_string_push(__nl_arg_111_0, __nl_arg_111_1); });
#line 581 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        ({ __auto_type __nl_arg_112_0 = part_is_exprs; __auto_type __nl_arg_112_1 = 0LL; if (!__nl_arg_112_0) nl_record_list_fail(); list_int_push(__nl_arg_112_0, __nl_arg_112_1); });
                    }
                    else                     {
#line 583 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        nl_print_string("");
                    }
#line 586 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    int64_t expr_start = ((pos) + (1LL));
#line 587 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    int64_t depth = 1LL;
#line 588 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    pos = ((pos) + (1LL));
#line 589 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    while ((((pos) < (len)) && ((depth) > (0LL))))                     {
#line 590 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        int64_t cc = ({ __auto_type __nl_arg_113_0 = source; __auto_type __nl_arg_113_1 = pos; char_at(__nl_arg_113_0, __nl_arg_113_1); });
#line 591 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((cc) == (123LL))                         {
#line 592 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            depth = ((depth) + (1LL));
                        }
                        else                         {
#line 594 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            nl_print_string("");
                        }
#line 596 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((cc) == (125LL))                         {
#line 597 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            depth = ((depth) - (1LL));
                        }
                        else                         {
#line 599 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            nl_print_string("");
                        }
#line 601 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        pos = ((pos) + (1LL));
                    }
#line 603 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((depth) == (0LL))                     {
#line 605 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        const char* expr_text = ({ __auto_type __nl_arg_114_0 = source; __auto_type __nl_arg_114_1 = expr_start; __auto_type __nl_arg_114_2 = ((((pos) - (1LL))) - (expr_start)); nl_str_substring(__nl_arg_114_0, __nl_arg_114_1, __nl_arg_114_2); });
#line 606 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((({ __auto_type __nl_arg_115_0 = expr_text; nl_cstr_length(__nl_arg_115_0); })) != (0LL))                         {
#line 607 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            ({ __auto_type __nl_arg_116_0 = part_texts; __auto_type __nl_arg_116_1 = expr_text; if (!__nl_arg_116_0) nl_record_list_fail(); list_string_push(__nl_arg_116_0, __nl_arg_116_1); });
#line 608 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            ({ __auto_type __nl_arg_117_0 = part_is_exprs; __auto_type __nl_arg_117_1 = 1LL; if (!__nl_arg_117_0) nl_record_list_fail(); list_int_push(__nl_arg_117_0, __nl_arg_117_1); });
                        }
                        else                         {
#line 610 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            nl_print_string("");
                        }
#line 612 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        part_start = pos;
                    }
                    else                     {
#line 614 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        CompilerDiagnostic diag = ({ __auto_type __nl_arg_118_0 = "L0004"; __auto_type __nl_arg_118_1 = "Unclosed '{' in f-string interpolation"; __auto_type __nl_arg_118_2 = ({ __auto_type __nl_arg_119_0 = file_name; __auto_type __nl_arg_119_1 = line; __auto_type __nl_arg_119_2 = column; diagnostics__diag_location(__nl_arg_119_0, __nl_arg_119_1, __nl_arg_119_2); }); diagnostics__diag_lexer_error(__nl_arg_118_0, __nl_arg_118_1, __nl_arg_118_2); });
#line 615 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        ({ __auto_type __nl_arg_120_0 = diags; __auto_type __nl_arg_120_1 = diag; diagnostics__diag_list_add(__nl_arg_120_0, __nl_arg_120_1); });
#line 616 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        return -1LL;
                    }
                }
                else                 {
#line 619 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    pos = ((pos) + (1LL));
                }
            }
        }
    }
#line 625 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((!found_end))     {
#line 626 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        CompilerDiagnostic diag = ({ __auto_type __nl_arg_121_0 = "L0002"; __auto_type __nl_arg_121_1 = "Unterminated f-string literal"; __auto_type __nl_arg_121_2 = ({ __auto_type __nl_arg_122_0 = file_name; __auto_type __nl_arg_122_1 = line; __auto_type __nl_arg_122_2 = column; diagnostics__diag_location(__nl_arg_122_0, __nl_arg_122_1, __nl_arg_122_2); }); diagnostics__diag_lexer_error(__nl_arg_121_0, __nl_arg_121_1, __nl_arg_121_2); });
#line 627 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_123_0 = diags; __auto_type __nl_arg_123_1 = diag; diagnostics__diag_list_add(__nl_arg_123_0, __nl_arg_123_1); });
#line 628 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return -1LL;
    }
#line 632 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t n = ({ __auto_type __nl_arg_124_0 = part_texts; if (!__nl_arg_124_0) nl_record_list_fail(); list_string_length(__nl_arg_124_0); });
#line 633 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if ((n) == (0LL))     {
#line 635 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        ({ __auto_type __nl_arg_125_0 = tokens; __auto_type __nl_arg_125_1 = nl_LexerTokenType_TOKEN_STRING; __auto_type __nl_arg_125_2 = ""; __auto_type __nl_arg_125_3 = line; __auto_type __nl_arg_125_4 = column; lexer__push_tok(__nl_arg_125_0, __nl_arg_125_1, __nl_arg_125_2, __nl_arg_125_3, __nl_arg_125_4); });
    }
    else     {
#line 637 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if ((n) == (1LL))         {
#line 639 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            const char* text = ({ __auto_type __nl_arg_126_0 = part_texts; __auto_type __nl_arg_126_1 = 0LL; if (!__nl_arg_126_0) nl_record_list_fail(); __nl_arg_126_1 = nl_native_list_index(__nl_arg_126_1, list_string_length(__nl_arg_126_0), false); list_string_get(__nl_arg_126_0, __nl_arg_126_1); });
#line 640 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            int64_t is_expr = ({ __auto_type __nl_arg_127_0 = part_is_exprs; __auto_type __nl_arg_127_1 = 0LL; if (!__nl_arg_127_0) nl_record_list_fail(); __nl_arg_127_1 = nl_native_list_index(__nl_arg_127_1, list_int_length(__nl_arg_127_0), false); list_int_get(__nl_arg_127_0, __nl_arg_127_1); });
#line 641 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            ({ __auto_type __nl_arg_128_0 = text; __auto_type __nl_arg_128_1 = is_expr; __auto_type __nl_arg_128_2 = tokens; __auto_type __nl_arg_128_3 = diags; __auto_type __nl_arg_128_4 = file_name; __auto_type __nl_arg_128_5 = line; __auto_type __nl_arg_128_6 = column; lexer__emit_fstring_part_tokens(__nl_arg_128_0, __nl_arg_128_1, __nl_arg_128_2, __nl_arg_128_3, __nl_arg_128_4, __nl_arg_128_5, __nl_arg_128_6); });
        }
        else         {
#line 649 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            int64_t k = 0LL;
#line 650 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            while ((k) < (((n) - (1LL))))             {
#line 651 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_129_0 = tokens; __auto_type __nl_arg_129_1 = nl_LexerTokenType_TOKEN_LPAREN; __auto_type __nl_arg_129_2 = ""; __auto_type __nl_arg_129_3 = line; __auto_type __nl_arg_129_4 = column; lexer__push_tok(__nl_arg_129_0, __nl_arg_129_1, __nl_arg_129_2, __nl_arg_129_3, __nl_arg_129_4); });
#line 652 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_130_0 = tokens; __auto_type __nl_arg_130_1 = nl_LexerTokenType_TOKEN_IDENTIFIER; __auto_type __nl_arg_130_2 = "str_concat"; __auto_type __nl_arg_130_3 = line; __auto_type __nl_arg_130_4 = column; lexer__push_tok(__nl_arg_130_0, __nl_arg_130_1, __nl_arg_130_2, __nl_arg_130_3, __nl_arg_130_4); });
#line 653 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                const char* text = ({ __auto_type __nl_arg_131_0 = part_texts; __auto_type __nl_arg_131_1 = k; if (!__nl_arg_131_0) nl_record_list_fail(); __nl_arg_131_1 = nl_native_list_index(__nl_arg_131_1, list_string_length(__nl_arg_131_0), false); list_string_get(__nl_arg_131_0, __nl_arg_131_1); });
#line 654 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                int64_t is_expr = ({ __auto_type __nl_arg_132_0 = part_is_exprs; __auto_type __nl_arg_132_1 = k; if (!__nl_arg_132_0) nl_record_list_fail(); __nl_arg_132_1 = nl_native_list_index(__nl_arg_132_1, list_int_length(__nl_arg_132_0), false); list_int_get(__nl_arg_132_0, __nl_arg_132_1); });
#line 655 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_133_0 = text; __auto_type __nl_arg_133_1 = is_expr; __auto_type __nl_arg_133_2 = tokens; __auto_type __nl_arg_133_3 = diags; __auto_type __nl_arg_133_4 = file_name; __auto_type __nl_arg_133_5 = line; __auto_type __nl_arg_133_6 = column; lexer__emit_fstring_part_tokens(__nl_arg_133_0, __nl_arg_133_1, __nl_arg_133_2, __nl_arg_133_3, __nl_arg_133_4, __nl_arg_133_5, __nl_arg_133_6); });
#line 656 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                k = ((k) + (1LL));
            }
#line 659 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            const char* last_text = ({ __auto_type __nl_arg_134_0 = part_texts; __auto_type __nl_arg_134_1 = ((n) - (1LL)); if (!__nl_arg_134_0) nl_record_list_fail(); __nl_arg_134_1 = nl_native_list_index(__nl_arg_134_1, list_string_length(__nl_arg_134_0), false); list_string_get(__nl_arg_134_0, __nl_arg_134_1); });
#line 660 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            int64_t last_is_expr = ({ __auto_type __nl_arg_135_0 = part_is_exprs; __auto_type __nl_arg_135_1 = ((n) - (1LL)); if (!__nl_arg_135_0) nl_record_list_fail(); __nl_arg_135_1 = nl_native_list_index(__nl_arg_135_1, list_int_length(__nl_arg_135_0), false); list_int_get(__nl_arg_135_0, __nl_arg_135_1); });
#line 661 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            ({ __auto_type __nl_arg_136_0 = last_text; __auto_type __nl_arg_136_1 = last_is_expr; __auto_type __nl_arg_136_2 = tokens; __auto_type __nl_arg_136_3 = diags; __auto_type __nl_arg_136_4 = file_name; __auto_type __nl_arg_136_5 = line; __auto_type __nl_arg_136_6 = column; lexer__emit_fstring_part_tokens(__nl_arg_136_0, __nl_arg_136_1, __nl_arg_136_2, __nl_arg_136_3, __nl_arg_136_4, __nl_arg_136_5, __nl_arg_136_6); });
#line 663 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            int64_t k2 = 0LL;
#line 664 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            while ((k2) < (((n) - (1LL))))             {
#line 665 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                ({ __auto_type __nl_arg_137_0 = tokens; __auto_type __nl_arg_137_1 = nl_LexerTokenType_TOKEN_RPAREN; __auto_type __nl_arg_137_2 = ""; __auto_type __nl_arg_137_3 = line; __auto_type __nl_arg_137_4 = column; lexer__push_tok(__nl_arg_137_0, __nl_arg_137_1, __nl_arg_137_2, __nl_arg_137_3, __nl_arg_137_4); });
#line 666 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                k2 = ((k2) + (1LL));
            }
        }
    }
#line 671 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return pos;
}

List_LexerToken* lexer__tokenize_string(const char* source, const char* file_name, List_CompilerDiagnostic* diags) {
#line 687 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    List_LexerToken* tokens = ({ nl_list_LexerToken_new(); });
#line 688 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t i = 0LL;
#line 689 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t len = ({ __auto_type __nl_arg_139_0 = source; nl_cstr_length(__nl_arg_139_0); });
#line 690 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t line = 1LL;
#line 691 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t column = 1LL;
#line 692 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    int64_t line_start = 0LL;
#line 693 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    bool lex_failed = false;
#line 695 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    while ((i) < (len))     {
#line 696 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        int64_t c = ({ __auto_type __nl_arg_140_0 = source; __auto_type __nl_arg_140_1 = i; char_at(__nl_arg_140_0, __nl_arg_140_1); });
#line 698 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        if (({ __auto_type __nl_arg_141_0 = c; lexer__is_whitespace_char(__nl_arg_141_0); }))         {
#line 699 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((c) == (10LL))             {
#line 700 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                line = ((line) + (1LL));
#line 701 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                line_start = ((i) + (1LL));
            }
#line 704 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            i = ((i) + (1LL));
        }
        else         {
#line 707 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
            if ((c) == (35LL))             {
#line 708 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                while ((((i) < (len)) && ((({ __auto_type __nl_arg_142_0 = source; __auto_type __nl_arg_142_1 = i; char_at(__nl_arg_142_0, __nl_arg_142_1); })) != (10LL))))                 {
#line 709 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    i = ((i) + (1LL));
                }
            }
            else             {
#line 713 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                if ((((c) == (47LL)) && ((((((i) + (1LL))) < (len)) && ((({ __auto_type __nl_arg_143_0 = source; __auto_type __nl_arg_143_1 = ((i) + (1LL)); char_at(__nl_arg_143_0, __nl_arg_143_1); })) == (42LL))))))                 {
#line 714 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    i = ((i) + (2LL));
#line 715 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    bool done_comment = false;
#line 716 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    while ((((i) < (len)) && ((!done_comment))))                     {
#line 717 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        int64_t cc = ({ __auto_type __nl_arg_144_0 = source; __auto_type __nl_arg_144_1 = i; char_at(__nl_arg_144_0, __nl_arg_144_1); });
#line 718 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((cc) == (10LL))                         {
#line 719 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            line = ((line) + (1LL));
#line 720 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            line_start = ((i) + (1LL));
                        }
                        else                         {
#line 722 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            nl_print_string("");
                        }
#line 724 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((((cc) == (42LL)) && ((((((i) + (1LL))) < (len)) && ((({ __auto_type __nl_arg_145_0 = source; __auto_type __nl_arg_145_1 = ((i) + (1LL)); char_at(__nl_arg_145_0, __nl_arg_145_1); })) == (47LL))))))                         {
#line 725 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            i = ((i) + (2LL));
#line 726 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            done_comment = true;
                        }
                        else                         {
#line 728 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            i = ((i) + (1LL));
                        }
                    }
                }
                else                 {
#line 732 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    column = ((((i) + (1LL))) - (line_start));
#line 734 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                    if ((((((i) + (1LL))) < (len)) && ((((c) == (58LL)) && ((({ __auto_type __nl_arg_146_0 = source; __auto_type __nl_arg_146_1 = ((i) + (1LL)); char_at(__nl_arg_146_0, __nl_arg_146_1); })) == (58LL))))))                     {
#line 735 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        ({ __auto_type __nl_arg_147_0 = tokens; __auto_type __nl_arg_147_1 = nl_LexerTokenType_TOKEN_DOUBLE_COLON; __auto_type __nl_arg_147_2 = ""; __auto_type __nl_arg_147_3 = line; __auto_type __nl_arg_147_4 = column; lexer__push_tok(__nl_arg_147_0, __nl_arg_147_1, __nl_arg_147_2, __nl_arg_147_3, __nl_arg_147_4); });
#line 736 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        i = ((i) + (2LL));
                    }
                    else                     {
#line 738 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                        if ((((((i) + (1LL))) < (len)) && ((((c) == (45LL)) && ((({ __auto_type __nl_arg_148_0 = source; __auto_type __nl_arg_148_1 = ((i) + (1LL)); char_at(__nl_arg_148_0, __nl_arg_148_1); })) == (62LL))))))                         {
#line 739 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            ({ __auto_type __nl_arg_149_0 = tokens; __auto_type __nl_arg_149_1 = nl_LexerTokenType_TOKEN_ARROW; __auto_type __nl_arg_149_2 = ""; __auto_type __nl_arg_149_3 = line; __auto_type __nl_arg_149_4 = column; lexer__push_tok(__nl_arg_149_0, __nl_arg_149_1, __nl_arg_149_2, __nl_arg_149_3, __nl_arg_149_4); });
#line 740 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            i = ((i) + (2LL));
                        }
                        else                         {
#line 742 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                            if ((((((i) + (1LL))) < (len)) && ((((c) == (61LL)) && ((({ __auto_type __nl_arg_150_0 = source; __auto_type __nl_arg_150_1 = ((i) + (1LL)); char_at(__nl_arg_150_0, __nl_arg_150_1); })) == (62LL))))))                             {
#line 743 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                ({ __auto_type __nl_arg_151_0 = tokens; __auto_type __nl_arg_151_1 = nl_LexerTokenType_TOKEN_ARROW; __auto_type __nl_arg_151_2 = ""; __auto_type __nl_arg_151_3 = line; __auto_type __nl_arg_151_4 = column; lexer__push_tok(__nl_arg_151_0, __nl_arg_151_1, __nl_arg_151_2, __nl_arg_151_3, __nl_arg_151_4); });
#line 744 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                i = ((i) + (2LL));
                            }
                            else                             {
#line 746 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                if ((((((i) + (1LL))) < (len)) && ((((c) == (61LL)) && ((({ __auto_type __nl_arg_152_0 = source; __auto_type __nl_arg_152_1 = ((i) + (1LL)); char_at(__nl_arg_152_0, __nl_arg_152_1); })) == (61LL))))))                                 {
#line 747 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    ({ __auto_type __nl_arg_153_0 = tokens; __auto_type __nl_arg_153_1 = nl_LexerTokenType_TOKEN_EQ; __auto_type __nl_arg_153_2 = ""; __auto_type __nl_arg_153_3 = line; __auto_type __nl_arg_153_4 = column; lexer__push_tok(__nl_arg_153_0, __nl_arg_153_1, __nl_arg_153_2, __nl_arg_153_3, __nl_arg_153_4); });
#line 748 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    i = ((i) + (2LL));
                                }
                                else                                 {
#line 750 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                    if ((((((i) + (1LL))) < (len)) && ((((c) == (33LL)) && ((({ __auto_type __nl_arg_154_0 = source; __auto_type __nl_arg_154_1 = ((i) + (1LL)); char_at(__nl_arg_154_0, __nl_arg_154_1); })) == (61LL))))))                                     {
#line 751 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                        ({ __auto_type __nl_arg_155_0 = tokens; __auto_type __nl_arg_155_1 = nl_LexerTokenType_TOKEN_NE; __auto_type __nl_arg_155_2 = ""; __auto_type __nl_arg_155_3 = line; __auto_type __nl_arg_155_4 = column; lexer__push_tok(__nl_arg_155_0, __nl_arg_155_1, __nl_arg_155_2, __nl_arg_155_3, __nl_arg_155_4); });
#line 752 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                        i = ((i) + (2LL));
                                    }
                                    else                                     {
#line 754 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                        if ((((((i) + (1LL))) < (len)) && ((((c) == (60LL)) && ((({ __auto_type __nl_arg_156_0 = source; __auto_type __nl_arg_156_1 = ((i) + (1LL)); char_at(__nl_arg_156_0, __nl_arg_156_1); })) == (61LL))))))                                         {
#line 755 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                            ({ __auto_type __nl_arg_157_0 = tokens; __auto_type __nl_arg_157_1 = nl_LexerTokenType_TOKEN_LE; __auto_type __nl_arg_157_2 = ""; __auto_type __nl_arg_157_3 = line; __auto_type __nl_arg_157_4 = column; lexer__push_tok(__nl_arg_157_0, __nl_arg_157_1, __nl_arg_157_2, __nl_arg_157_3, __nl_arg_157_4); });
#line 756 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                            i = ((i) + (2LL));
                                        }
                                        else                                         {
#line 758 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                            if ((((((i) + (1LL))) < (len)) && ((((c) == (62LL)) && ((({ __auto_type __nl_arg_158_0 = source; __auto_type __nl_arg_158_1 = ((i) + (1LL)); char_at(__nl_arg_158_0, __nl_arg_158_1); })) == (61LL))))))                                             {
#line 759 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                ({ __auto_type __nl_arg_159_0 = tokens; __auto_type __nl_arg_159_1 = nl_LexerTokenType_TOKEN_GE; __auto_type __nl_arg_159_2 = ""; __auto_type __nl_arg_159_3 = line; __auto_type __nl_arg_159_4 = column; lexer__push_tok(__nl_arg_159_0, __nl_arg_159_1, __nl_arg_159_2, __nl_arg_159_3, __nl_arg_159_4); });
#line 760 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                i = ((i) + (2LL));
                                            }
                                            else                                             {
#line 763 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                if ((((((i) + (1LL))) < (len)) && ((((c) == (124LL)) && ((({ __auto_type __nl_arg_160_0 = source; __auto_type __nl_arg_160_1 = ((i) + (1LL)); char_at(__nl_arg_160_0, __nl_arg_160_1); })) == (62LL))))))                                                 {
#line 764 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                    ({ __auto_type __nl_arg_161_0 = tokens; __auto_type __nl_arg_161_1 = nl_LexerTokenType_TOKEN_PIPE; __auto_type __nl_arg_161_2 = ""; __auto_type __nl_arg_161_3 = line; __auto_type __nl_arg_161_4 = column; lexer__push_tok(__nl_arg_161_0, __nl_arg_161_1, __nl_arg_161_2, __nl_arg_161_3, __nl_arg_161_4); });
#line 765 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                    i = ((i) + (2LL));
                                                }
                                                else                                                 {
#line 768 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                    if ((((((i) + (1LL))) < (len)) && ((((c) == (60LL)) && ((({ __auto_type __nl_arg_162_0 = source; __auto_type __nl_arg_162_1 = ((i) + (1LL)); char_at(__nl_arg_162_0, __nl_arg_162_1); })) == (45LL))))))                                                     {
#line 769 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                        ({ __auto_type __nl_arg_163_0 = tokens; __auto_type __nl_arg_163_1 = nl_LexerTokenType_TOKEN_LARROW; __auto_type __nl_arg_163_2 = ""; __auto_type __nl_arg_163_3 = line; __auto_type __nl_arg_163_4 = column; lexer__push_tok(__nl_arg_163_0, __nl_arg_163_1, __nl_arg_163_2, __nl_arg_163_3, __nl_arg_163_4); });
#line 770 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                        i = ((i) + (2LL));
                                                    }
                                                    else                                                     {
#line 773 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                        if ((c) == (63LL))                                                         {
#line 774 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                            ({ __auto_type __nl_arg_164_0 = tokens; __auto_type __nl_arg_164_1 = nl_LexerTokenType_TOKEN_QUESTION; __auto_type __nl_arg_164_2 = ""; __auto_type __nl_arg_164_3 = line; __auto_type __nl_arg_164_4 = column; lexer__push_tok(__nl_arg_164_0, __nl_arg_164_1, __nl_arg_164_2, __nl_arg_164_3, __nl_arg_164_4); });
#line 775 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                            i = ((i) + (1LL));
                                                        }
                                                        else                                                         {
#line 778 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                            if ((c) == (61LL))                                                             {
#line 779 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                ({ __auto_type __nl_arg_165_0 = tokens; __auto_type __nl_arg_165_1 = nl_LexerTokenType_TOKEN_ASSIGN; __auto_type __nl_arg_165_2 = ""; __auto_type __nl_arg_165_3 = line; __auto_type __nl_arg_165_4 = column; lexer__push_tok(__nl_arg_165_0, __nl_arg_165_1, __nl_arg_165_2, __nl_arg_165_3, __nl_arg_165_4); });
#line 780 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                i = ((i) + (1LL));
                                                            }
                                                            else                                                             {
#line 782 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                int64_t new_pos = -1LL;
#line 783 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                if ((c) == (39LL))                                                                 {
#line 784 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    new_pos = ({ __auto_type __nl_arg_166_0 = source; __auto_type __nl_arg_166_1 = i; __auto_type __nl_arg_166_2 = len; __auto_type __nl_arg_166_3 = tokens; __auto_type __nl_arg_166_4 = line; __auto_type __nl_arg_166_5 = column; lexer__process_char_literal(__nl_arg_166_0, __nl_arg_166_1, __nl_arg_166_2, __nl_arg_166_3, __nl_arg_166_4, __nl_arg_166_5); });
#line 785 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    if ((new_pos) == (-1LL))                                                                     {
#line 786 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        CompilerDiagnostic diag = ({ __auto_type __nl_arg_167_0 = "L0001"; __auto_type __nl_arg_167_1 = "Unterminated or invalid character literal"; __auto_type __nl_arg_167_2 = ({ __auto_type __nl_arg_168_0 = file_name; __auto_type __nl_arg_168_1 = line; __auto_type __nl_arg_168_2 = column; diagnostics__diag_location(__nl_arg_168_0, __nl_arg_168_1, __nl_arg_168_2); }); diagnostics__diag_lexer_error(__nl_arg_167_0, __nl_arg_167_1, __nl_arg_167_2); });
#line 787 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        ({ __auto_type __nl_arg_169_0 = diags; __auto_type __nl_arg_169_1 = diag; diagnostics__diag_list_add(__nl_arg_169_0, __nl_arg_169_1); });
                                                                    }
                                                                    else                                                                     {
#line 788 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        nl_print_string("");
                                                                    }
                                                                }
                                                                else                                                                 {
#line 790 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    if ((c) == (34LL))                                                                     {
#line 791 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        new_pos = ({ __auto_type __nl_arg_170_0 = source; __auto_type __nl_arg_170_1 = i; __auto_type __nl_arg_170_2 = len; __auto_type __nl_arg_170_3 = tokens; __auto_type __nl_arg_170_4 = line; __auto_type __nl_arg_170_5 = column; lexer__process_string(__nl_arg_170_0, __nl_arg_170_1, __nl_arg_170_2, __nl_arg_170_3, __nl_arg_170_4, __nl_arg_170_5); });
#line 792 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        if ((new_pos) == (-1LL))                                                                         {
#line 793 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            CompilerDiagnostic diag = ({ __auto_type __nl_arg_171_0 = "L0002"; __auto_type __nl_arg_171_1 = "Unterminated string literal"; __auto_type __nl_arg_171_2 = ({ __auto_type __nl_arg_172_0 = file_name; __auto_type __nl_arg_172_1 = line; __auto_type __nl_arg_172_2 = column; diagnostics__diag_location(__nl_arg_172_0, __nl_arg_172_1, __nl_arg_172_2); }); diagnostics__diag_lexer_error(__nl_arg_171_0, __nl_arg_171_1, __nl_arg_171_2); });
#line 794 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            ({ __auto_type __nl_arg_173_0 = diags; __auto_type __nl_arg_173_1 = diag; diagnostics__diag_list_add(__nl_arg_173_0, __nl_arg_173_1); });
                                                                        }
                                                                        else                                                                         {
#line 795 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            nl_print_string("");
                                                                        }
                                                                    }
                                                                    else                                                                     {
#line 797 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        if (((({ __auto_type __nl_arg_174_0 = c; lexer__is_digit_char(__nl_arg_174_0); })) || ((((((c) == (45LL)) && ((((i) + (1LL))) < (len)))) && (({ __auto_type __nl_arg_175_0 = ({ __auto_type __nl_arg_176_0 = source; __auto_type __nl_arg_176_1 = ((i) + (1LL)); char_at(__nl_arg_176_0, __nl_arg_176_1); }); lexer__is_digit_char(__nl_arg_175_0); }))))))                                                                         {
#line 798 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            new_pos = ({ __auto_type __nl_arg_177_0 = source; __auto_type __nl_arg_177_1 = i; __auto_type __nl_arg_177_2 = len; __auto_type __nl_arg_177_3 = tokens; __auto_type __nl_arg_177_4 = line; __auto_type __nl_arg_177_5 = column; lexer__process_number(__nl_arg_177_0, __nl_arg_177_1, __nl_arg_177_2, __nl_arg_177_3, __nl_arg_177_4, __nl_arg_177_5); });
                                                                        }
                                                                        else                                                                         {
#line 801 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            if ((((c) == (102LL)) && ((((((i) + (1LL))) < (len)) && ((({ __auto_type __nl_arg_178_0 = source; __auto_type __nl_arg_178_1 = ((i) + (1LL)); char_at(__nl_arg_178_0, __nl_arg_178_1); })) == (34LL))))))                                                                             {
#line 802 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                new_pos = ({ __auto_type __nl_arg_179_0 = source; __auto_type __nl_arg_179_1 = i; __auto_type __nl_arg_179_2 = len; __auto_type __nl_arg_179_3 = tokens; __auto_type __nl_arg_179_4 = diags; __auto_type __nl_arg_179_5 = file_name; __auto_type __nl_arg_179_6 = line; __auto_type __nl_arg_179_7 = column; lexer__process_fstring(__nl_arg_179_0, __nl_arg_179_1, __nl_arg_179_2, __nl_arg_179_3, __nl_arg_179_4, __nl_arg_179_5, __nl_arg_179_6, __nl_arg_179_7); });
                                                                            }
                                                                            else                                                                             {
#line 804 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                if (({ __auto_type __nl_arg_180_0 = c; lexer__is_identifier_start(__nl_arg_180_0); }))                                                                                 {
#line 805 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                    new_pos = ({ __auto_type __nl_arg_181_0 = source; __auto_type __nl_arg_181_1 = i; __auto_type __nl_arg_181_2 = len; __auto_type __nl_arg_181_3 = tokens; __auto_type __nl_arg_181_4 = line; __auto_type __nl_arg_181_5 = column; lexer__process_identifier(__nl_arg_181_0, __nl_arg_181_1, __nl_arg_181_2, __nl_arg_181_3, __nl_arg_181_4, __nl_arg_181_5); });
                                                                                }
                                                                                else                                                                                 {
#line 807 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                    if ((c) == (40LL))                                                                                     {
#line 808 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                        ({ __auto_type __nl_arg_182_0 = tokens; __auto_type __nl_arg_182_1 = nl_LexerTokenType_TOKEN_LPAREN; __auto_type __nl_arg_182_2 = ""; __auto_type __nl_arg_182_3 = line; __auto_type __nl_arg_182_4 = column; lexer__push_tok(__nl_arg_182_0, __nl_arg_182_1, __nl_arg_182_2, __nl_arg_182_3, __nl_arg_182_4); });
#line 809 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                        new_pos = ((i) + (1LL));
                                                                                    }
                                                                                    else                                                                                     {
#line 811 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                        if ((c) == (41LL))                                                                                         {
#line 812 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                            ({ __auto_type __nl_arg_183_0 = tokens; __auto_type __nl_arg_183_1 = nl_LexerTokenType_TOKEN_RPAREN; __auto_type __nl_arg_183_2 = ""; __auto_type __nl_arg_183_3 = line; __auto_type __nl_arg_183_4 = column; lexer__push_tok(__nl_arg_183_0, __nl_arg_183_1, __nl_arg_183_2, __nl_arg_183_3, __nl_arg_183_4); });
#line 813 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                            new_pos = ((i) + (1LL));
                                                                                        }
                                                                                        else                                                                                         {
#line 815 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                            if ((c) == (123LL))                                                                                             {
#line 816 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                ({ __auto_type __nl_arg_184_0 = tokens; __auto_type __nl_arg_184_1 = nl_LexerTokenType_TOKEN_LBRACE; __auto_type __nl_arg_184_2 = ""; __auto_type __nl_arg_184_3 = line; __auto_type __nl_arg_184_4 = column; lexer__push_tok(__nl_arg_184_0, __nl_arg_184_1, __nl_arg_184_2, __nl_arg_184_3, __nl_arg_184_4); });
#line 817 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                new_pos = ((i) + (1LL));
                                                                                            }
                                                                                            else                                                                                             {
#line 819 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                if ((c) == (125LL))                                                                                                 {
#line 820 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                    ({ __auto_type __nl_arg_185_0 = tokens; __auto_type __nl_arg_185_1 = nl_LexerTokenType_TOKEN_RBRACE; __auto_type __nl_arg_185_2 = ""; __auto_type __nl_arg_185_3 = line; __auto_type __nl_arg_185_4 = column; lexer__push_tok(__nl_arg_185_0, __nl_arg_185_1, __nl_arg_185_2, __nl_arg_185_3, __nl_arg_185_4); });
#line 821 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                    new_pos = ((i) + (1LL));
                                                                                                }
                                                                                                else                                                                                                 {
#line 823 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                    if ((c) == (91LL))                                                                                                     {
#line 824 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                        ({ __auto_type __nl_arg_186_0 = tokens; __auto_type __nl_arg_186_1 = nl_LexerTokenType_TOKEN_LBRACKET; __auto_type __nl_arg_186_2 = ""; __auto_type __nl_arg_186_3 = line; __auto_type __nl_arg_186_4 = column; lexer__push_tok(__nl_arg_186_0, __nl_arg_186_1, __nl_arg_186_2, __nl_arg_186_3, __nl_arg_186_4); });
#line 825 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                        new_pos = ((i) + (1LL));
                                                                                                    }
                                                                                                    else                                                                                                     {
#line 827 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                        if ((c) == (93LL))                                                                                                         {
#line 828 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                            ({ __auto_type __nl_arg_187_0 = tokens; __auto_type __nl_arg_187_1 = nl_LexerTokenType_TOKEN_RBRACKET; __auto_type __nl_arg_187_2 = ""; __auto_type __nl_arg_187_3 = line; __auto_type __nl_arg_187_4 = column; lexer__push_tok(__nl_arg_187_0, __nl_arg_187_1, __nl_arg_187_2, __nl_arg_187_3, __nl_arg_187_4); });
#line 829 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                            new_pos = ((i) + (1LL));
                                                                                                        }
                                                                                                        else                                                                                                         {
#line 831 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                            if ((c) == (44LL))                                                                                                             {
#line 832 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                ({ __auto_type __nl_arg_188_0 = tokens; __auto_type __nl_arg_188_1 = nl_LexerTokenType_TOKEN_COMMA; __auto_type __nl_arg_188_2 = ""; __auto_type __nl_arg_188_3 = line; __auto_type __nl_arg_188_4 = column; lexer__push_tok(__nl_arg_188_0, __nl_arg_188_1, __nl_arg_188_2, __nl_arg_188_3, __nl_arg_188_4); });
#line 833 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                new_pos = ((i) + (1LL));
                                                                                                            }
                                                                                                            else                                                                                                             {
#line 835 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                if ((((c) == (58LL)) || ((c) == (38LL))))                                                                                                                 {
#line 836 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                    if ((c) == (38LL))                                                                                                                     {
#line 837 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                        ({ __auto_type __nl_arg_189_0 = tokens; __auto_type __nl_arg_189_1 = nl_LexerTokenType_TOKEN_AMPERSAND; __auto_type __nl_arg_189_2 = ""; __auto_type __nl_arg_189_3 = line; __auto_type __nl_arg_189_4 = column; lexer__push_tok(__nl_arg_189_0, __nl_arg_189_1, __nl_arg_189_2, __nl_arg_189_3, __nl_arg_189_4); });
                                                                                                                    }
                                                                                                                    else                                                                                                                     {
#line 839 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                        ({ __auto_type __nl_arg_190_0 = tokens; __auto_type __nl_arg_190_1 = nl_LexerTokenType_TOKEN_COLON; __auto_type __nl_arg_190_2 = ""; __auto_type __nl_arg_190_3 = line; __auto_type __nl_arg_190_4 = column; lexer__push_tok(__nl_arg_190_0, __nl_arg_190_1, __nl_arg_190_2, __nl_arg_190_3, __nl_arg_190_4); });
                                                                                                                    }
#line 841 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                    new_pos = ((i) + (1LL));
                                                                                                                }
                                                                                                                else                                                                                                                 {
#line 843 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                    if ((c) == (46LL))                                                                                                                     {
#line 844 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                        ({ __auto_type __nl_arg_191_0 = tokens; __auto_type __nl_arg_191_1 = nl_LexerTokenType_TOKEN_DOT; __auto_type __nl_arg_191_2 = ""; __auto_type __nl_arg_191_3 = line; __auto_type __nl_arg_191_4 = column; lexer__push_tok(__nl_arg_191_0, __nl_arg_191_1, __nl_arg_191_2, __nl_arg_191_3, __nl_arg_191_4); });
#line 845 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                        new_pos = ((i) + (1LL));
                                                                                                                    }
                                                                                                                    else                                                                                                                     {
#line 847 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                        if ((c) == (43LL))                                                                                                                         {
#line 848 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                            ({ __auto_type __nl_arg_192_0 = tokens; __auto_type __nl_arg_192_1 = nl_LexerTokenType_TOKEN_PLUS; __auto_type __nl_arg_192_2 = ""; __auto_type __nl_arg_192_3 = line; __auto_type __nl_arg_192_4 = column; lexer__push_tok(__nl_arg_192_0, __nl_arg_192_1, __nl_arg_192_2, __nl_arg_192_3, __nl_arg_192_4); });
#line 849 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                            new_pos = ((i) + (1LL));
                                                                                                                        }
                                                                                                                        else                                                                                                                         {
#line 851 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                            if ((c) == (45LL))                                                                                                                             {
#line 852 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                ({ __auto_type __nl_arg_193_0 = tokens; __auto_type __nl_arg_193_1 = nl_LexerTokenType_TOKEN_MINUS; __auto_type __nl_arg_193_2 = ""; __auto_type __nl_arg_193_3 = line; __auto_type __nl_arg_193_4 = column; lexer__push_tok(__nl_arg_193_0, __nl_arg_193_1, __nl_arg_193_2, __nl_arg_193_3, __nl_arg_193_4); });
#line 853 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                new_pos = ((i) + (1LL));
                                                                                                                            }
                                                                                                                            else                                                                                                                             {
#line 855 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                if ((c) == (42LL))                                                                                                                                 {
#line 856 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                    ({ __auto_type __nl_arg_194_0 = tokens; __auto_type __nl_arg_194_1 = nl_LexerTokenType_TOKEN_STAR; __auto_type __nl_arg_194_2 = ""; __auto_type __nl_arg_194_3 = line; __auto_type __nl_arg_194_4 = column; lexer__push_tok(__nl_arg_194_0, __nl_arg_194_1, __nl_arg_194_2, __nl_arg_194_3, __nl_arg_194_4); });
#line 857 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                    new_pos = ((i) + (1LL));
                                                                                                                                }
                                                                                                                                else                                                                                                                                 {
#line 859 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                    if ((c) == (47LL))                                                                                                                                     {
#line 860 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                        ({ __auto_type __nl_arg_195_0 = tokens; __auto_type __nl_arg_195_1 = nl_LexerTokenType_TOKEN_SLASH; __auto_type __nl_arg_195_2 = ""; __auto_type __nl_arg_195_3 = line; __auto_type __nl_arg_195_4 = column; lexer__push_tok(__nl_arg_195_0, __nl_arg_195_1, __nl_arg_195_2, __nl_arg_195_3, __nl_arg_195_4); });
#line 861 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                        new_pos = ((i) + (1LL));
                                                                                                                                    }
                                                                                                                                    else                                                                                                                                     {
#line 863 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                        if ((c) == (37LL))                                                                                                                                         {
#line 864 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                            ({ __auto_type __nl_arg_196_0 = tokens; __auto_type __nl_arg_196_1 = nl_LexerTokenType_TOKEN_PERCENT; __auto_type __nl_arg_196_2 = ""; __auto_type __nl_arg_196_3 = line; __auto_type __nl_arg_196_4 = column; lexer__push_tok(__nl_arg_196_0, __nl_arg_196_1, __nl_arg_196_2, __nl_arg_196_3, __nl_arg_196_4); });
#line 865 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                            new_pos = ((i) + (1LL));
                                                                                                                                        }
                                                                                                                                        else                                                                                                                                         {
#line 867 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                            if ((c) == (60LL))                                                                                                                                             {
#line 868 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                ({ __auto_type __nl_arg_197_0 = tokens; __auto_type __nl_arg_197_1 = nl_LexerTokenType_TOKEN_LT; __auto_type __nl_arg_197_2 = ""; __auto_type __nl_arg_197_3 = line; __auto_type __nl_arg_197_4 = column; lexer__push_tok(__nl_arg_197_0, __nl_arg_197_1, __nl_arg_197_2, __nl_arg_197_3, __nl_arg_197_4); });
#line 869 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                new_pos = ((i) + (1LL));
                                                                                                                                            }
                                                                                                                                            else                                                                                                                                             {
#line 871 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                if ((c) == (62LL))                                                                                                                                                 {
#line 872 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    ({ __auto_type __nl_arg_198_0 = tokens; __auto_type __nl_arg_198_1 = nl_LexerTokenType_TOKEN_GT; __auto_type __nl_arg_198_2 = ""; __auto_type __nl_arg_198_3 = line; __auto_type __nl_arg_198_4 = column; lexer__push_tok(__nl_arg_198_0, __nl_arg_198_1, __nl_arg_198_2, __nl_arg_198_3, __nl_arg_198_4); });
#line 873 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    new_pos = ((i) + (1LL));
                                                                                                                                                }
                                                                                                                                                else                                                                                                                                                 {
#line 876 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    CompilerDiagnostic diag = ({ __auto_type __nl_arg_199_0 = "L0003"; __auto_type __nl_arg_199_1 = "Unexpected character"; __auto_type __nl_arg_199_2 = ({ __auto_type __nl_arg_200_0 = file_name; __auto_type __nl_arg_200_1 = line; __auto_type __nl_arg_200_2 = column; diagnostics__diag_location(__nl_arg_200_0, __nl_arg_200_1, __nl_arg_200_2); }); diagnostics__diag_lexer_error(__nl_arg_199_0, __nl_arg_199_1, __nl_arg_199_2); });
#line 877 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    ({ __auto_type __nl_arg_201_0 = diags; __auto_type __nl_arg_201_1 = diag; diagnostics__diag_list_add(__nl_arg_201_0, __nl_arg_201_1); });
#line 878 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    lex_failed = true;
#line 879 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    new_pos = ((i) + (1LL));
#line 880 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                    if ((c) >= (192LL))                                                                                                                                                     {
#line 881 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                        while ((((new_pos) < (len)) && ((((({ __auto_type __nl_arg_202_0 = source; __auto_type __nl_arg_202_1 = new_pos; char_at(__nl_arg_202_0, __nl_arg_202_1); })) >= (128LL)) && ((({ __auto_type __nl_arg_203_0 = source; __auto_type __nl_arg_203_1 = new_pos; char_at(__nl_arg_203_0, __nl_arg_203_1); })) <= (191LL))))))                                                                                                                                                         {
#line 882 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                                                                                                            new_pos = ((new_pos) + (1LL));
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
#line 907 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                if ((new_pos) == (-1LL))                                                                 {
#line 908 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    i = len;
                                                                }
                                                                else                                                                 {
#line 911 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                    while ((i) < (new_pos))                                                                     {
#line 912 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        if ((({ __auto_type __nl_arg_204_0 = source; __auto_type __nl_arg_204_1 = i; char_at(__nl_arg_204_0, __nl_arg_204_1); })) == (10LL))                                                                         {
#line 913 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            line = ((line) + (1LL));
#line 914 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                            line_start = ((i) + (1LL));
                                                                        }
#line 916 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
                                                                        i = ((i) + (1LL));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
#line 927 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    if (lex_failed)     {
#line 928 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
        return ({ nl_list_LexerToken_new(); });
    }
#line 930 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    ({ __auto_type __nl_arg_206_0 = tokens; __auto_type __nl_arg_206_1 = nl_LexerTokenType_TOKEN_EOF; __auto_type __nl_arg_206_2 = ""; __auto_type __nl_arg_206_3 = line; __auto_type __nl_arg_206_4 = column; lexer__push_tok(__nl_arg_206_0, __nl_arg_206_1, __nl_arg_206_2, __nl_arg_206_3, __nl_arg_206_4); });
#line 931 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return tokens;
}

List_LexerToken* lexer__tokenize_file(const char* path, List_CompilerDiagnostic* diags) {
#line 935 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    const char* source = ({ __auto_type __nl_arg_207_0 = path; std_fs__read(__nl_arg_207_0); });
#line 936 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/lexer.nano"
    return ({ __auto_type __nl_arg_208_0 = source; __auto_type __nl_arg_208_1 = path; __auto_type __nl_arg_208_2 = diags; lexer__tokenize_string(__nl_arg_208_0, __nl_arg_208_1, __nl_arg_208_2); });
}


#pragma GCC diagnostic pop
/* Module metadata - automatically generated */
#include "nanolang.h"

static TypeInfo _type_infos[6];
static Function _module_functions[318];
static Parameter _module_params[351];

static void _init_module_metadata(void) __attribute__((constructor));
static void _init_module_metadata(void) {
    _type_infos[0].base_type = 7;
    _type_infos[0].element_type = &_type_infos[3];
    _type_infos[0].generic_name = NULL;
    _type_infos[0].tuple_types = NULL;
    _type_infos[0].tuple_type_names = NULL;
    _type_infos[0].tuple_element_count = 0;
    _type_infos[0].opaque_type_name = NULL;
    _type_infos[0].row_var_name = NULL;
    _type_infos[0].row_field_count = 0;
    _type_infos[0].is_open_row = false;
    _type_infos[0].type_var_count = 0;
    _type_infos[1].base_type = 7;
    _type_infos[1].element_type = &_type_infos[4];
    _type_infos[1].generic_name = NULL;
    _type_infos[1].tuple_types = NULL;
    _type_infos[1].tuple_type_names = NULL;
    _type_infos[1].tuple_element_count = 0;
    _type_infos[1].opaque_type_name = NULL;
    _type_infos[1].row_var_name = NULL;
    _type_infos[1].row_field_count = 0;
    _type_infos[1].is_open_row = false;
    _type_infos[1].type_var_count = 0;
    _type_infos[2].base_type = 7;
    _type_infos[2].element_type = &_type_infos[5];
    _type_infos[2].generic_name = NULL;
    _type_infos[2].tuple_types = NULL;
    _type_infos[2].tuple_type_names = NULL;
    _type_infos[2].tuple_element_count = 0;
    _type_infos[2].opaque_type_name = NULL;
    _type_infos[2].row_var_name = NULL;
    _type_infos[2].row_field_count = 0;
    _type_infos[2].is_open_row = false;
    _type_infos[2].type_var_count = 0;
    _type_infos[3].base_type = 4;
    _type_infos[3].generic_name = NULL;
    _type_infos[3].tuple_types = NULL;
    _type_infos[3].tuple_type_names = NULL;
    _type_infos[3].tuple_element_count = 0;
    _type_infos[3].opaque_type_name = NULL;
    _type_infos[3].row_var_name = NULL;
    _type_infos[3].row_field_count = 0;
    _type_infos[3].is_open_row = false;
    _type_infos[3].type_var_count = 0;
    _type_infos[4].base_type = 4;
    _type_infos[4].generic_name = NULL;
    _type_infos[4].tuple_types = NULL;
    _type_infos[4].tuple_type_names = NULL;
    _type_infos[4].tuple_element_count = 0;
    _type_infos[4].opaque_type_name = NULL;
    _type_infos[4].row_var_name = NULL;
    _type_infos[4].row_field_count = 0;
    _type_infos[4].is_open_row = false;
    _type_infos[4].type_var_count = 0;
    _type_infos[5].base_type = 4;
    _type_infos[5].generic_name = NULL;
    _type_infos[5].tuple_types = NULL;
    _type_infos[5].tuple_type_names = NULL;
    _type_infos[5].tuple_element_count = 0;
    _type_infos[5].opaque_type_name = NULL;
    _type_infos[5].row_var_name = NULL;
    _type_infos[5].row_field_count = 0;
    _type_infos[5].is_open_row = false;
    _type_infos[5].type_var_count = 0;
    /* Function: range */
    _module_functions[0].name = "range";
    _module_functions[0].param_count = 0;
    _module_functions[0].return_type = 6;
    _module_functions[0].return_struct_type_name = NULL;
    _module_functions[0].return_fn_sig = NULL;
    _module_functions[0].return_type_info = NULL;
    _module_functions[0].body = NULL;
    _module_functions[0].shadow_test = NULL;
    _module_functions[0].is_extern = false;
    _module_functions[0].returns_gc_managed = false;
    _module_functions[0].requires_manual_free = false;
    _module_functions[0].returns_borrowed = false;
    _module_functions[0].cleanup_function = NULL;
    _module_functions[0].params = NULL;

    /* Function: abs */
    _module_functions[1].name = "abs";
    _module_functions[1].param_count = 0;
    _module_functions[1].return_type = 0;
    _module_functions[1].return_struct_type_name = NULL;
    _module_functions[1].return_fn_sig = NULL;
    _module_functions[1].return_type_info = NULL;
    _module_functions[1].body = NULL;
    _module_functions[1].shadow_test = NULL;
    _module_functions[1].is_extern = false;
    _module_functions[1].returns_gc_managed = false;
    _module_functions[1].requires_manual_free = false;
    _module_functions[1].returns_borrowed = false;
    _module_functions[1].cleanup_function = NULL;
    _module_functions[1].params = NULL;

    /* Function: min */
    _module_functions[2].name = "min";
    _module_functions[2].param_count = 0;
    _module_functions[2].return_type = 0;
    _module_functions[2].return_struct_type_name = NULL;
    _module_functions[2].return_fn_sig = NULL;
    _module_functions[2].return_type_info = NULL;
    _module_functions[2].body = NULL;
    _module_functions[2].shadow_test = NULL;
    _module_functions[2].is_extern = false;
    _module_functions[2].returns_gc_managed = false;
    _module_functions[2].requires_manual_free = false;
    _module_functions[2].returns_borrowed = false;
    _module_functions[2].cleanup_function = NULL;
    _module_functions[2].params = NULL;

    /* Function: max */
    _module_functions[3].name = "max";
    _module_functions[3].param_count = 0;
    _module_functions[3].return_type = 0;
    _module_functions[3].return_struct_type_name = NULL;
    _module_functions[3].return_fn_sig = NULL;
    _module_functions[3].return_type_info = NULL;
    _module_functions[3].body = NULL;
    _module_functions[3].shadow_test = NULL;
    _module_functions[3].is_extern = false;
    _module_functions[3].returns_gc_managed = false;
    _module_functions[3].requires_manual_free = false;
    _module_functions[3].returns_borrowed = false;
    _module_functions[3].cleanup_function = NULL;
    _module_functions[3].params = NULL;

    /* Function: print */
    _module_functions[4].name = "print";
    _module_functions[4].param_count = 0;
    _module_functions[4].return_type = 6;
    _module_functions[4].return_struct_type_name = NULL;
    _module_functions[4].return_fn_sig = NULL;
    _module_functions[4].return_type_info = NULL;
    _module_functions[4].body = NULL;
    _module_functions[4].shadow_test = NULL;
    _module_functions[4].is_extern = false;
    _module_functions[4].returns_gc_managed = false;
    _module_functions[4].requires_manual_free = false;
    _module_functions[4].returns_borrowed = false;
    _module_functions[4].cleanup_function = NULL;
    _module_functions[4].params = NULL;

    /* Function: println */
    _module_functions[5].name = "println";
    _module_functions[5].param_count = 0;
    _module_functions[5].return_type = 6;
    _module_functions[5].return_struct_type_name = NULL;
    _module_functions[5].return_fn_sig = NULL;
    _module_functions[5].return_type_info = NULL;
    _module_functions[5].body = NULL;
    _module_functions[5].shadow_test = NULL;
    _module_functions[5].is_extern = false;
    _module_functions[5].returns_gc_managed = false;
    _module_functions[5].requires_manual_free = false;
    _module_functions[5].returns_borrowed = false;
    _module_functions[5].cleanup_function = NULL;
    _module_functions[5].params = NULL;

    /* Function: sqrt */
    _module_functions[6].name = "sqrt";
    _module_functions[6].param_count = 0;
    _module_functions[6].return_type = 2;
    _module_functions[6].return_struct_type_name = NULL;
    _module_functions[6].return_fn_sig = NULL;
    _module_functions[6].return_type_info = NULL;
    _module_functions[6].body = NULL;
    _module_functions[6].shadow_test = NULL;
    _module_functions[6].is_extern = false;
    _module_functions[6].returns_gc_managed = false;
    _module_functions[6].requires_manual_free = false;
    _module_functions[6].returns_borrowed = false;
    _module_functions[6].cleanup_function = NULL;
    _module_functions[6].params = NULL;

    /* Function: pow */
    _module_functions[7].name = "pow";
    _module_functions[7].param_count = 0;
    _module_functions[7].return_type = 2;
    _module_functions[7].return_struct_type_name = NULL;
    _module_functions[7].return_fn_sig = NULL;
    _module_functions[7].return_type_info = NULL;
    _module_functions[7].body = NULL;
    _module_functions[7].shadow_test = NULL;
    _module_functions[7].is_extern = false;
    _module_functions[7].returns_gc_managed = false;
    _module_functions[7].requires_manual_free = false;
    _module_functions[7].returns_borrowed = false;
    _module_functions[7].cleanup_function = NULL;
    _module_functions[7].params = NULL;

    /* Function: floor */
    _module_functions[8].name = "floor";
    _module_functions[8].param_count = 0;
    _module_functions[8].return_type = 2;
    _module_functions[8].return_struct_type_name = NULL;
    _module_functions[8].return_fn_sig = NULL;
    _module_functions[8].return_type_info = NULL;
    _module_functions[8].body = NULL;
    _module_functions[8].shadow_test = NULL;
    _module_functions[8].is_extern = false;
    _module_functions[8].returns_gc_managed = false;
    _module_functions[8].requires_manual_free = false;
    _module_functions[8].returns_borrowed = false;
    _module_functions[8].cleanup_function = NULL;
    _module_functions[8].params = NULL;

    /* Function: ceil */
    _module_functions[9].name = "ceil";
    _module_functions[9].param_count = 0;
    _module_functions[9].return_type = 2;
    _module_functions[9].return_struct_type_name = NULL;
    _module_functions[9].return_fn_sig = NULL;
    _module_functions[9].return_type_info = NULL;
    _module_functions[9].body = NULL;
    _module_functions[9].shadow_test = NULL;
    _module_functions[9].is_extern = false;
    _module_functions[9].returns_gc_managed = false;
    _module_functions[9].requires_manual_free = false;
    _module_functions[9].returns_borrowed = false;
    _module_functions[9].cleanup_function = NULL;
    _module_functions[9].params = NULL;

    /* Function: round */
    _module_functions[10].name = "round";
    _module_functions[10].param_count = 0;
    _module_functions[10].return_type = 2;
    _module_functions[10].return_struct_type_name = NULL;
    _module_functions[10].return_fn_sig = NULL;
    _module_functions[10].return_type_info = NULL;
    _module_functions[10].body = NULL;
    _module_functions[10].shadow_test = NULL;
    _module_functions[10].is_extern = false;
    _module_functions[10].returns_gc_managed = false;
    _module_functions[10].requires_manual_free = false;
    _module_functions[10].returns_borrowed = false;
    _module_functions[10].cleanup_function = NULL;
    _module_functions[10].params = NULL;

    /* Function: sin */
    _module_functions[11].name = "sin";
    _module_functions[11].param_count = 0;
    _module_functions[11].return_type = 2;
    _module_functions[11].return_struct_type_name = NULL;
    _module_functions[11].return_fn_sig = NULL;
    _module_functions[11].return_type_info = NULL;
    _module_functions[11].body = NULL;
    _module_functions[11].shadow_test = NULL;
    _module_functions[11].is_extern = false;
    _module_functions[11].returns_gc_managed = false;
    _module_functions[11].requires_manual_free = false;
    _module_functions[11].returns_borrowed = false;
    _module_functions[11].cleanup_function = NULL;
    _module_functions[11].params = NULL;

    /* Function: cos */
    _module_functions[12].name = "cos";
    _module_functions[12].param_count = 0;
    _module_functions[12].return_type = 2;
    _module_functions[12].return_struct_type_name = NULL;
    _module_functions[12].return_fn_sig = NULL;
    _module_functions[12].return_type_info = NULL;
    _module_functions[12].body = NULL;
    _module_functions[12].shadow_test = NULL;
    _module_functions[12].is_extern = false;
    _module_functions[12].returns_gc_managed = false;
    _module_functions[12].requires_manual_free = false;
    _module_functions[12].returns_borrowed = false;
    _module_functions[12].cleanup_function = NULL;
    _module_functions[12].params = NULL;

    /* Function: tan */
    _module_functions[13].name = "tan";
    _module_functions[13].param_count = 0;
    _module_functions[13].return_type = 2;
    _module_functions[13].return_struct_type_name = NULL;
    _module_functions[13].return_fn_sig = NULL;
    _module_functions[13].return_type_info = NULL;
    _module_functions[13].body = NULL;
    _module_functions[13].shadow_test = NULL;
    _module_functions[13].is_extern = false;
    _module_functions[13].returns_gc_managed = false;
    _module_functions[13].requires_manual_free = false;
    _module_functions[13].returns_borrowed = false;
    _module_functions[13].cleanup_function = NULL;
    _module_functions[13].params = NULL;

    /* Function: str_length */
    _module_functions[14].name = "str_length";
    _module_functions[14].param_count = 0;
    _module_functions[14].return_type = 0;
    _module_functions[14].return_struct_type_name = NULL;
    _module_functions[14].return_fn_sig = NULL;
    _module_functions[14].return_type_info = NULL;
    _module_functions[14].body = NULL;
    _module_functions[14].shadow_test = NULL;
    _module_functions[14].is_extern = false;
    _module_functions[14].returns_gc_managed = false;
    _module_functions[14].requires_manual_free = false;
    _module_functions[14].returns_borrowed = false;
    _module_functions[14].cleanup_function = NULL;
    _module_functions[14].params = NULL;

    /* Function: str_concat */
    _module_functions[15].name = "str_concat";
    _module_functions[15].param_count = 0;
    _module_functions[15].return_type = 4;
    _module_functions[15].return_struct_type_name = NULL;
    _module_functions[15].return_fn_sig = NULL;
    _module_functions[15].return_type_info = NULL;
    _module_functions[15].body = NULL;
    _module_functions[15].shadow_test = NULL;
    _module_functions[15].is_extern = false;
    _module_functions[15].returns_gc_managed = true;
    _module_functions[15].requires_manual_free = false;
    _module_functions[15].returns_borrowed = false;
    _module_functions[15].cleanup_function = NULL;
    _module_functions[15].params = NULL;

    /* Function: str_substring */
    _module_functions[16].name = "str_substring";
    _module_functions[16].param_count = 0;
    _module_functions[16].return_type = 4;
    _module_functions[16].return_struct_type_name = NULL;
    _module_functions[16].return_fn_sig = NULL;
    _module_functions[16].return_type_info = NULL;
    _module_functions[16].body = NULL;
    _module_functions[16].shadow_test = NULL;
    _module_functions[16].is_extern = false;
    _module_functions[16].returns_gc_managed = true;
    _module_functions[16].requires_manual_free = false;
    _module_functions[16].returns_borrowed = false;
    _module_functions[16].cleanup_function = NULL;
    _module_functions[16].params = NULL;

    /* Function: str_contains */
    _module_functions[17].name = "str_contains";
    _module_functions[17].param_count = 0;
    _module_functions[17].return_type = 3;
    _module_functions[17].return_struct_type_name = NULL;
    _module_functions[17].return_fn_sig = NULL;
    _module_functions[17].return_type_info = NULL;
    _module_functions[17].body = NULL;
    _module_functions[17].shadow_test = NULL;
    _module_functions[17].is_extern = false;
    _module_functions[17].returns_gc_managed = false;
    _module_functions[17].requires_manual_free = false;
    _module_functions[17].returns_borrowed = false;
    _module_functions[17].cleanup_function = NULL;
    _module_functions[17].params = NULL;

    /* Function: str_equals */
    _module_functions[18].name = "str_equals";
    _module_functions[18].param_count = 0;
    _module_functions[18].return_type = 3;
    _module_functions[18].return_struct_type_name = NULL;
    _module_functions[18].return_fn_sig = NULL;
    _module_functions[18].return_type_info = NULL;
    _module_functions[18].body = NULL;
    _module_functions[18].shadow_test = NULL;
    _module_functions[18].is_extern = false;
    _module_functions[18].returns_gc_managed = false;
    _module_functions[18].requires_manual_free = false;
    _module_functions[18].returns_borrowed = false;
    _module_functions[18].cleanup_function = NULL;
    _module_functions[18].params = NULL;

    /* Function: format */
    _module_functions[19].name = "format";
    _module_functions[19].param_count = 0;
    _module_functions[19].return_type = 4;
    _module_functions[19].return_struct_type_name = NULL;
    _module_functions[19].return_fn_sig = NULL;
    _module_functions[19].return_type_info = NULL;
    _module_functions[19].body = NULL;
    _module_functions[19].shadow_test = NULL;
    _module_functions[19].is_extern = false;
    _module_functions[19].returns_gc_managed = true;
    _module_functions[19].requires_manual_free = false;
    _module_functions[19].returns_borrowed = false;
    _module_functions[19].cleanup_function = NULL;
    _module_functions[19].params = NULL;

    /* Function: at */
    _module_functions[20].name = "at";
    _module_functions[20].param_count = 0;
    _module_functions[20].return_type = 21;
    _module_functions[20].return_struct_type_name = NULL;
    _module_functions[20].return_fn_sig = NULL;
    _module_functions[20].return_type_info = NULL;
    _module_functions[20].body = NULL;
    _module_functions[20].shadow_test = NULL;
    _module_functions[20].is_extern = false;
    _module_functions[20].returns_gc_managed = false;
    _module_functions[20].requires_manual_free = false;
    _module_functions[20].returns_borrowed = false;
    _module_functions[20].cleanup_function = NULL;
    _module_functions[20].params = NULL;

    /* Function: array_length */
    _module_functions[21].name = "array_length";
    _module_functions[21].param_count = 0;
    _module_functions[21].return_type = 0;
    _module_functions[21].return_struct_type_name = NULL;
    _module_functions[21].return_fn_sig = NULL;
    _module_functions[21].return_type_info = NULL;
    _module_functions[21].body = NULL;
    _module_functions[21].shadow_test = NULL;
    _module_functions[21].is_extern = false;
    _module_functions[21].returns_gc_managed = false;
    _module_functions[21].requires_manual_free = false;
    _module_functions[21].returns_borrowed = false;
    _module_functions[21].cleanup_function = NULL;
    _module_functions[21].params = NULL;

    /* Function: array_new */
    _module_functions[22].name = "array_new";
    _module_functions[22].param_count = 0;
    _module_functions[22].return_type = 7;
    _module_functions[22].return_struct_type_name = NULL;
    _module_functions[22].return_fn_sig = NULL;
    _module_functions[22].return_type_info = NULL;
    _module_functions[22].body = NULL;
    _module_functions[22].shadow_test = NULL;
    _module_functions[22].is_extern = false;
    _module_functions[22].returns_gc_managed = false;
    _module_functions[22].requires_manual_free = false;
    _module_functions[22].returns_borrowed = false;
    _module_functions[22].cleanup_function = NULL;
    _module_functions[22].params = NULL;

    /* Function: array_set */
    _module_functions[23].name = "array_set";
    _module_functions[23].param_count = 0;
    _module_functions[23].return_type = 6;
    _module_functions[23].return_struct_type_name = NULL;
    _module_functions[23].return_fn_sig = NULL;
    _module_functions[23].return_type_info = NULL;
    _module_functions[23].body = NULL;
    _module_functions[23].shadow_test = NULL;
    _module_functions[23].is_extern = false;
    _module_functions[23].returns_gc_managed = false;
    _module_functions[23].requires_manual_free = false;
    _module_functions[23].returns_borrowed = false;
    _module_functions[23].cleanup_function = NULL;
    _module_functions[23].params = NULL;

    /* Function: map */
    _module_functions[24].name = "map";
    _module_functions[24].param_count = 0;
    _module_functions[24].return_type = 7;
    _module_functions[24].return_struct_type_name = NULL;
    _module_functions[24].return_fn_sig = NULL;
    _module_functions[24].return_type_info = NULL;
    _module_functions[24].body = NULL;
    _module_functions[24].shadow_test = NULL;
    _module_functions[24].is_extern = false;
    _module_functions[24].returns_gc_managed = false;
    _module_functions[24].requires_manual_free = false;
    _module_functions[24].returns_borrowed = false;
    _module_functions[24].cleanup_function = NULL;
    _module_functions[24].params = NULL;

    /* Function: reduce */
    _module_functions[25].name = "reduce";
    _module_functions[25].param_count = 0;
    _module_functions[25].return_type = 21;
    _module_functions[25].return_struct_type_name = NULL;
    _module_functions[25].return_fn_sig = NULL;
    _module_functions[25].return_type_info = NULL;
    _module_functions[25].body = NULL;
    _module_functions[25].shadow_test = NULL;
    _module_functions[25].is_extern = false;
    _module_functions[25].returns_gc_managed = false;
    _module_functions[25].requires_manual_free = false;
    _module_functions[25].returns_borrowed = false;
    _module_functions[25].cleanup_function = NULL;
    _module_functions[25].params = NULL;

    /* Function: getcwd */
    _module_functions[26].name = "getcwd";
    _module_functions[26].param_count = 0;
    _module_functions[26].return_type = 4;
    _module_functions[26].return_struct_type_name = NULL;
    _module_functions[26].return_fn_sig = NULL;
    _module_functions[26].return_type_info = NULL;
    _module_functions[26].body = NULL;
    _module_functions[26].shadow_test = NULL;
    _module_functions[26].is_extern = false;
    _module_functions[26].returns_gc_managed = true;
    _module_functions[26].requires_manual_free = false;
    _module_functions[26].returns_borrowed = false;
    _module_functions[26].cleanup_function = NULL;
    _module_functions[26].params = NULL;

    /* Function: getenv */
    _module_functions[27].name = "getenv";
    _module_functions[27].param_count = 0;
    _module_functions[27].return_type = 4;
    _module_functions[27].return_struct_type_name = NULL;
    _module_functions[27].return_fn_sig = NULL;
    _module_functions[27].return_type_info = NULL;
    _module_functions[27].body = NULL;
    _module_functions[27].shadow_test = NULL;
    _module_functions[27].is_extern = false;
    _module_functions[27].returns_gc_managed = true;
    _module_functions[27].requires_manual_free = false;
    _module_functions[27].returns_borrowed = false;
    _module_functions[27].cleanup_function = NULL;
    _module_functions[27].params = NULL;

    /* Function: dir_list */
    _module_functions[28].name = "dir_list";
    _module_functions[28].param_count = 0;
    _module_functions[28].return_type = 7;
    _module_functions[28].return_struct_type_name = NULL;
    _module_functions[28].return_fn_sig = NULL;
    _module_functions[28].return_type_info = NULL;
    _module_functions[28].body = NULL;
    _module_functions[28].shadow_test = NULL;
    _module_functions[28].is_extern = false;
    _module_functions[28].returns_gc_managed = false;
    _module_functions[28].requires_manual_free = false;
    _module_functions[28].returns_borrowed = false;
    _module_functions[28].cleanup_function = NULL;
    _module_functions[28].params = NULL;

    /* Function: process_run */
    _module_functions[29].name = "process_run";
    _module_functions[29].param_count = 0;
    _module_functions[29].return_type = 7;
    _module_functions[29].return_struct_type_name = NULL;
    _module_functions[29].return_fn_sig = NULL;
    _module_functions[29].return_type_info = NULL;
    _module_functions[29].body = NULL;
    _module_functions[29].shadow_test = NULL;
    _module_functions[29].is_extern = false;
    _module_functions[29].returns_gc_managed = false;
    _module_functions[29].requires_manual_free = false;
    _module_functions[29].returns_borrowed = false;
    _module_functions[29].cleanup_function = NULL;
    _module_functions[29].params = NULL;

    /* Function: tmp_dir */
    _module_functions[30].name = "tmp_dir";
    _module_functions[30].param_count = 0;
    _module_functions[30].return_type = 4;
    _module_functions[30].return_struct_type_name = NULL;
    _module_functions[30].return_fn_sig = NULL;
    _module_functions[30].return_type_info = NULL;
    _module_functions[30].body = NULL;
    _module_functions[30].shadow_test = NULL;
    _module_functions[30].is_extern = false;
    _module_functions[30].returns_gc_managed = true;
    _module_functions[30].requires_manual_free = false;
    _module_functions[30].returns_borrowed = false;
    _module_functions[30].cleanup_function = NULL;
    _module_functions[30].params = NULL;

    /* Function: mktemp */
    _module_functions[31].name = "mktemp";
    _module_functions[31].param_count = 0;
    _module_functions[31].return_type = 4;
    _module_functions[31].return_struct_type_name = NULL;
    _module_functions[31].return_fn_sig = NULL;
    _module_functions[31].return_type_info = NULL;
    _module_functions[31].body = NULL;
    _module_functions[31].shadow_test = NULL;
    _module_functions[31].is_extern = false;
    _module_functions[31].returns_gc_managed = true;
    _module_functions[31].requires_manual_free = false;
    _module_functions[31].returns_borrowed = false;
    _module_functions[31].cleanup_function = NULL;
    _module_functions[31].params = NULL;

    /* Function: mktemp_dir */
    _module_functions[32].name = "mktemp_dir";
    _module_functions[32].param_count = 0;
    _module_functions[32].return_type = 4;
    _module_functions[32].return_struct_type_name = NULL;
    _module_functions[32].return_fn_sig = NULL;
    _module_functions[32].return_type_info = NULL;
    _module_functions[32].body = NULL;
    _module_functions[32].shadow_test = NULL;
    _module_functions[32].is_extern = false;
    _module_functions[32].returns_gc_managed = true;
    _module_functions[32].requires_manual_free = false;
    _module_functions[32].returns_borrowed = false;
    _module_functions[32].cleanup_function = NULL;
    _module_functions[32].params = NULL;

    /* Function: char_at */
    _module_functions[33].name = "char_at";
    _module_functions[33].param_count = 0;
    _module_functions[33].return_type = 0;
    _module_functions[33].return_struct_type_name = NULL;
    _module_functions[33].return_fn_sig = NULL;
    _module_functions[33].return_type_info = NULL;
    _module_functions[33].body = NULL;
    _module_functions[33].shadow_test = NULL;
    _module_functions[33].is_extern = false;
    _module_functions[33].returns_gc_managed = false;
    _module_functions[33].requires_manual_free = false;
    _module_functions[33].returns_borrowed = false;
    _module_functions[33].cleanup_function = NULL;
    _module_functions[33].params = NULL;

    /* Function: string_from_char */
    _module_functions[34].name = "string_from_char";
    _module_functions[34].param_count = 0;
    _module_functions[34].return_type = 4;
    _module_functions[34].return_struct_type_name = NULL;
    _module_functions[34].return_fn_sig = NULL;
    _module_functions[34].return_type_info = NULL;
    _module_functions[34].body = NULL;
    _module_functions[34].shadow_test = NULL;
    _module_functions[34].is_extern = false;
    _module_functions[34].returns_gc_managed = true;
    _module_functions[34].requires_manual_free = false;
    _module_functions[34].returns_borrowed = false;
    _module_functions[34].cleanup_function = NULL;
    _module_functions[34].params = NULL;

    /* Function: is_digit */
    _module_functions[35].name = "is_digit";
    _module_functions[35].param_count = 0;
    _module_functions[35].return_type = 3;
    _module_functions[35].return_struct_type_name = NULL;
    _module_functions[35].return_fn_sig = NULL;
    _module_functions[35].return_type_info = NULL;
    _module_functions[35].body = NULL;
    _module_functions[35].shadow_test = NULL;
    _module_functions[35].is_extern = false;
    _module_functions[35].returns_gc_managed = false;
    _module_functions[35].requires_manual_free = false;
    _module_functions[35].returns_borrowed = false;
    _module_functions[35].cleanup_function = NULL;
    _module_functions[35].params = NULL;

    /* Function: is_alpha */
    _module_functions[36].name = "is_alpha";
    _module_functions[36].param_count = 0;
    _module_functions[36].return_type = 3;
    _module_functions[36].return_struct_type_name = NULL;
    _module_functions[36].return_fn_sig = NULL;
    _module_functions[36].return_type_info = NULL;
    _module_functions[36].body = NULL;
    _module_functions[36].shadow_test = NULL;
    _module_functions[36].is_extern = false;
    _module_functions[36].returns_gc_managed = false;
    _module_functions[36].requires_manual_free = false;
    _module_functions[36].returns_borrowed = false;
    _module_functions[36].cleanup_function = NULL;
    _module_functions[36].params = NULL;

    /* Function: is_alnum */
    _module_functions[37].name = "is_alnum";
    _module_functions[37].param_count = 0;
    _module_functions[37].return_type = 3;
    _module_functions[37].return_struct_type_name = NULL;
    _module_functions[37].return_fn_sig = NULL;
    _module_functions[37].return_type_info = NULL;
    _module_functions[37].body = NULL;
    _module_functions[37].shadow_test = NULL;
    _module_functions[37].is_extern = false;
    _module_functions[37].returns_gc_managed = false;
    _module_functions[37].requires_manual_free = false;
    _module_functions[37].returns_borrowed = false;
    _module_functions[37].cleanup_function = NULL;
    _module_functions[37].params = NULL;

    /* Function: is_whitespace */
    _module_functions[38].name = "is_whitespace";
    _module_functions[38].param_count = 0;
    _module_functions[38].return_type = 3;
    _module_functions[38].return_struct_type_name = NULL;
    _module_functions[38].return_fn_sig = NULL;
    _module_functions[38].return_type_info = NULL;
    _module_functions[38].body = NULL;
    _module_functions[38].shadow_test = NULL;
    _module_functions[38].is_extern = false;
    _module_functions[38].returns_gc_managed = false;
    _module_functions[38].requires_manual_free = false;
    _module_functions[38].returns_borrowed = false;
    _module_functions[38].cleanup_function = NULL;
    _module_functions[38].params = NULL;

    /* Function: is_upper */
    _module_functions[39].name = "is_upper";
    _module_functions[39].param_count = 0;
    _module_functions[39].return_type = 3;
    _module_functions[39].return_struct_type_name = NULL;
    _module_functions[39].return_fn_sig = NULL;
    _module_functions[39].return_type_info = NULL;
    _module_functions[39].body = NULL;
    _module_functions[39].shadow_test = NULL;
    _module_functions[39].is_extern = false;
    _module_functions[39].returns_gc_managed = false;
    _module_functions[39].requires_manual_free = false;
    _module_functions[39].returns_borrowed = false;
    _module_functions[39].cleanup_function = NULL;
    _module_functions[39].params = NULL;

    /* Function: is_lower */
    _module_functions[40].name = "is_lower";
    _module_functions[40].param_count = 0;
    _module_functions[40].return_type = 3;
    _module_functions[40].return_struct_type_name = NULL;
    _module_functions[40].return_fn_sig = NULL;
    _module_functions[40].return_type_info = NULL;
    _module_functions[40].body = NULL;
    _module_functions[40].shadow_test = NULL;
    _module_functions[40].is_extern = false;
    _module_functions[40].returns_gc_managed = false;
    _module_functions[40].requires_manual_free = false;
    _module_functions[40].returns_borrowed = false;
    _module_functions[40].cleanup_function = NULL;
    _module_functions[40].params = NULL;

    /* Function: int_to_string */
    _module_functions[41].name = "int_to_string";
    _module_functions[41].param_count = 0;
    _module_functions[41].return_type = 4;
    _module_functions[41].return_struct_type_name = NULL;
    _module_functions[41].return_fn_sig = NULL;
    _module_functions[41].return_type_info = NULL;
    _module_functions[41].body = NULL;
    _module_functions[41].shadow_test = NULL;
    _module_functions[41].is_extern = false;
    _module_functions[41].returns_gc_managed = true;
    _module_functions[41].requires_manual_free = false;
    _module_functions[41].returns_borrowed = false;
    _module_functions[41].cleanup_function = NULL;
    _module_functions[41].params = NULL;

    /* Function: string_to_int */
    _module_functions[42].name = "string_to_int";
    _module_functions[42].param_count = 0;
    _module_functions[42].return_type = 0;
    _module_functions[42].return_struct_type_name = NULL;
    _module_functions[42].return_fn_sig = NULL;
    _module_functions[42].return_type_info = NULL;
    _module_functions[42].body = NULL;
    _module_functions[42].shadow_test = NULL;
    _module_functions[42].is_extern = false;
    _module_functions[42].returns_gc_managed = false;
    _module_functions[42].requires_manual_free = false;
    _module_functions[42].returns_borrowed = false;
    _module_functions[42].cleanup_function = NULL;
    _module_functions[42].params = NULL;

    /* Function: digit_value */
    _module_functions[43].name = "digit_value";
    _module_functions[43].param_count = 0;
    _module_functions[43].return_type = 0;
    _module_functions[43].return_struct_type_name = NULL;
    _module_functions[43].return_fn_sig = NULL;
    _module_functions[43].return_type_info = NULL;
    _module_functions[43].body = NULL;
    _module_functions[43].shadow_test = NULL;
    _module_functions[43].is_extern = false;
    _module_functions[43].returns_gc_managed = false;
    _module_functions[43].requires_manual_free = false;
    _module_functions[43].returns_borrowed = false;
    _module_functions[43].cleanup_function = NULL;
    _module_functions[43].params = NULL;

    /* Function: char_to_lower */
    _module_functions[44].name = "char_to_lower";
    _module_functions[44].param_count = 0;
    _module_functions[44].return_type = 0;
    _module_functions[44].return_struct_type_name = NULL;
    _module_functions[44].return_fn_sig = NULL;
    _module_functions[44].return_type_info = NULL;
    _module_functions[44].body = NULL;
    _module_functions[44].shadow_test = NULL;
    _module_functions[44].is_extern = false;
    _module_functions[44].returns_gc_managed = false;
    _module_functions[44].requires_manual_free = false;
    _module_functions[44].returns_borrowed = false;
    _module_functions[44].cleanup_function = NULL;
    _module_functions[44].params = NULL;

    /* Function: char_to_upper */
    _module_functions[45].name = "char_to_upper";
    _module_functions[45].param_count = 0;
    _module_functions[45].return_type = 0;
    _module_functions[45].return_struct_type_name = NULL;
    _module_functions[45].return_fn_sig = NULL;
    _module_functions[45].return_type_info = NULL;
    _module_functions[45].body = NULL;
    _module_functions[45].shadow_test = NULL;
    _module_functions[45].is_extern = false;
    _module_functions[45].returns_gc_managed = false;
    _module_functions[45].requires_manual_free = false;
    _module_functions[45].returns_borrowed = false;
    _module_functions[45].cleanup_function = NULL;
    _module_functions[45].params = NULL;

    /* Function: list_int_new */
    _module_functions[46].name = "list_int_new";
    _module_functions[46].param_count = 0;
    _module_functions[46].return_type = 12;
    _module_functions[46].return_struct_type_name = NULL;
    _module_functions[46].return_fn_sig = NULL;
    _module_functions[46].return_type_info = NULL;
    _module_functions[46].body = NULL;
    _module_functions[46].shadow_test = NULL;
    _module_functions[46].is_extern = false;
    _module_functions[46].returns_gc_managed = false;
    _module_functions[46].requires_manual_free = false;
    _module_functions[46].returns_borrowed = false;
    _module_functions[46].cleanup_function = NULL;
    _module_functions[46].params = NULL;

    /* Function: list_int_with_capacity */
    _module_functions[47].name = "list_int_with_capacity";
    _module_functions[47].param_count = 0;
    _module_functions[47].return_type = 12;
    _module_functions[47].return_struct_type_name = NULL;
    _module_functions[47].return_fn_sig = NULL;
    _module_functions[47].return_type_info = NULL;
    _module_functions[47].body = NULL;
    _module_functions[47].shadow_test = NULL;
    _module_functions[47].is_extern = false;
    _module_functions[47].returns_gc_managed = false;
    _module_functions[47].requires_manual_free = false;
    _module_functions[47].returns_borrowed = false;
    _module_functions[47].cleanup_function = NULL;
    _module_functions[47].params = NULL;

    /* Function: list_int_push */
    _module_functions[48].name = "list_int_push";
    _module_functions[48].param_count = 0;
    _module_functions[48].return_type = 6;
    _module_functions[48].return_struct_type_name = NULL;
    _module_functions[48].return_fn_sig = NULL;
    _module_functions[48].return_type_info = NULL;
    _module_functions[48].body = NULL;
    _module_functions[48].shadow_test = NULL;
    _module_functions[48].is_extern = false;
    _module_functions[48].returns_gc_managed = false;
    _module_functions[48].requires_manual_free = false;
    _module_functions[48].returns_borrowed = false;
    _module_functions[48].cleanup_function = NULL;
    _module_functions[48].params = NULL;

    /* Function: list_int_pop */
    _module_functions[49].name = "list_int_pop";
    _module_functions[49].param_count = 0;
    _module_functions[49].return_type = 0;
    _module_functions[49].return_struct_type_name = NULL;
    _module_functions[49].return_fn_sig = NULL;
    _module_functions[49].return_type_info = NULL;
    _module_functions[49].body = NULL;
    _module_functions[49].shadow_test = NULL;
    _module_functions[49].is_extern = false;
    _module_functions[49].returns_gc_managed = false;
    _module_functions[49].requires_manual_free = false;
    _module_functions[49].returns_borrowed = false;
    _module_functions[49].cleanup_function = NULL;
    _module_functions[49].params = NULL;

    /* Function: list_int_get */
    _module_functions[50].name = "list_int_get";
    _module_functions[50].param_count = 0;
    _module_functions[50].return_type = 0;
    _module_functions[50].return_struct_type_name = NULL;
    _module_functions[50].return_fn_sig = NULL;
    _module_functions[50].return_type_info = NULL;
    _module_functions[50].body = NULL;
    _module_functions[50].shadow_test = NULL;
    _module_functions[50].is_extern = false;
    _module_functions[50].returns_gc_managed = false;
    _module_functions[50].requires_manual_free = false;
    _module_functions[50].returns_borrowed = false;
    _module_functions[50].cleanup_function = NULL;
    _module_functions[50].params = NULL;

    /* Function: list_int_set */
    _module_functions[51].name = "list_int_set";
    _module_functions[51].param_count = 0;
    _module_functions[51].return_type = 6;
    _module_functions[51].return_struct_type_name = NULL;
    _module_functions[51].return_fn_sig = NULL;
    _module_functions[51].return_type_info = NULL;
    _module_functions[51].body = NULL;
    _module_functions[51].shadow_test = NULL;
    _module_functions[51].is_extern = false;
    _module_functions[51].returns_gc_managed = false;
    _module_functions[51].requires_manual_free = false;
    _module_functions[51].returns_borrowed = false;
    _module_functions[51].cleanup_function = NULL;
    _module_functions[51].params = NULL;

    /* Function: list_int_insert */
    _module_functions[52].name = "list_int_insert";
    _module_functions[52].param_count = 0;
    _module_functions[52].return_type = 6;
    _module_functions[52].return_struct_type_name = NULL;
    _module_functions[52].return_fn_sig = NULL;
    _module_functions[52].return_type_info = NULL;
    _module_functions[52].body = NULL;
    _module_functions[52].shadow_test = NULL;
    _module_functions[52].is_extern = false;
    _module_functions[52].returns_gc_managed = false;
    _module_functions[52].requires_manual_free = false;
    _module_functions[52].returns_borrowed = false;
    _module_functions[52].cleanup_function = NULL;
    _module_functions[52].params = NULL;

    /* Function: list_int_remove */
    _module_functions[53].name = "list_int_remove";
    _module_functions[53].param_count = 0;
    _module_functions[53].return_type = 0;
    _module_functions[53].return_struct_type_name = NULL;
    _module_functions[53].return_fn_sig = NULL;
    _module_functions[53].return_type_info = NULL;
    _module_functions[53].body = NULL;
    _module_functions[53].shadow_test = NULL;
    _module_functions[53].is_extern = false;
    _module_functions[53].returns_gc_managed = false;
    _module_functions[53].requires_manual_free = false;
    _module_functions[53].returns_borrowed = false;
    _module_functions[53].cleanup_function = NULL;
    _module_functions[53].params = NULL;

    /* Function: list_int_length */
    _module_functions[54].name = "list_int_length";
    _module_functions[54].param_count = 0;
    _module_functions[54].return_type = 0;
    _module_functions[54].return_struct_type_name = NULL;
    _module_functions[54].return_fn_sig = NULL;
    _module_functions[54].return_type_info = NULL;
    _module_functions[54].body = NULL;
    _module_functions[54].shadow_test = NULL;
    _module_functions[54].is_extern = false;
    _module_functions[54].returns_gc_managed = false;
    _module_functions[54].requires_manual_free = false;
    _module_functions[54].returns_borrowed = false;
    _module_functions[54].cleanup_function = NULL;
    _module_functions[54].params = NULL;

    /* Function: list_int_capacity */
    _module_functions[55].name = "list_int_capacity";
    _module_functions[55].param_count = 0;
    _module_functions[55].return_type = 0;
    _module_functions[55].return_struct_type_name = NULL;
    _module_functions[55].return_fn_sig = NULL;
    _module_functions[55].return_type_info = NULL;
    _module_functions[55].body = NULL;
    _module_functions[55].shadow_test = NULL;
    _module_functions[55].is_extern = false;
    _module_functions[55].returns_gc_managed = false;
    _module_functions[55].requires_manual_free = false;
    _module_functions[55].returns_borrowed = false;
    _module_functions[55].cleanup_function = NULL;
    _module_functions[55].params = NULL;

    /* Function: list_int_is_empty */
    _module_functions[56].name = "list_int_is_empty";
    _module_functions[56].param_count = 0;
    _module_functions[56].return_type = 3;
    _module_functions[56].return_struct_type_name = NULL;
    _module_functions[56].return_fn_sig = NULL;
    _module_functions[56].return_type_info = NULL;
    _module_functions[56].body = NULL;
    _module_functions[56].shadow_test = NULL;
    _module_functions[56].is_extern = false;
    _module_functions[56].returns_gc_managed = false;
    _module_functions[56].requires_manual_free = false;
    _module_functions[56].returns_borrowed = false;
    _module_functions[56].cleanup_function = NULL;
    _module_functions[56].params = NULL;

    /* Function: list_int_clear */
    _module_functions[57].name = "list_int_clear";
    _module_functions[57].param_count = 0;
    _module_functions[57].return_type = 6;
    _module_functions[57].return_struct_type_name = NULL;
    _module_functions[57].return_fn_sig = NULL;
    _module_functions[57].return_type_info = NULL;
    _module_functions[57].body = NULL;
    _module_functions[57].shadow_test = NULL;
    _module_functions[57].is_extern = false;
    _module_functions[57].returns_gc_managed = false;
    _module_functions[57].requires_manual_free = false;
    _module_functions[57].returns_borrowed = false;
    _module_functions[57].cleanup_function = NULL;
    _module_functions[57].params = NULL;

    /* Function: list_int_free */
    _module_functions[58].name = "list_int_free";
    _module_functions[58].param_count = 0;
    _module_functions[58].return_type = 6;
    _module_functions[58].return_struct_type_name = NULL;
    _module_functions[58].return_fn_sig = NULL;
    _module_functions[58].return_type_info = NULL;
    _module_functions[58].body = NULL;
    _module_functions[58].shadow_test = NULL;
    _module_functions[58].is_extern = false;
    _module_functions[58].returns_gc_managed = false;
    _module_functions[58].requires_manual_free = false;
    _module_functions[58].returns_borrowed = false;
    _module_functions[58].cleanup_function = NULL;
    _module_functions[58].params = NULL;

    /* Function: list_string_new */
    _module_functions[59].name = "list_string_new";
    _module_functions[59].param_count = 0;
    _module_functions[59].return_type = 13;
    _module_functions[59].return_struct_type_name = NULL;
    _module_functions[59].return_fn_sig = NULL;
    _module_functions[59].return_type_info = NULL;
    _module_functions[59].body = NULL;
    _module_functions[59].shadow_test = NULL;
    _module_functions[59].is_extern = false;
    _module_functions[59].returns_gc_managed = false;
    _module_functions[59].requires_manual_free = false;
    _module_functions[59].returns_borrowed = false;
    _module_functions[59].cleanup_function = NULL;
    _module_functions[59].params = NULL;

    /* Function: list_string_with_capacity */
    _module_functions[60].name = "list_string_with_capacity";
    _module_functions[60].param_count = 0;
    _module_functions[60].return_type = 13;
    _module_functions[60].return_struct_type_name = NULL;
    _module_functions[60].return_fn_sig = NULL;
    _module_functions[60].return_type_info = NULL;
    _module_functions[60].body = NULL;
    _module_functions[60].shadow_test = NULL;
    _module_functions[60].is_extern = false;
    _module_functions[60].returns_gc_managed = false;
    _module_functions[60].requires_manual_free = false;
    _module_functions[60].returns_borrowed = false;
    _module_functions[60].cleanup_function = NULL;
    _module_functions[60].params = NULL;

    /* Function: list_string_push */
    _module_functions[61].name = "list_string_push";
    _module_functions[61].param_count = 0;
    _module_functions[61].return_type = 6;
    _module_functions[61].return_struct_type_name = NULL;
    _module_functions[61].return_fn_sig = NULL;
    _module_functions[61].return_type_info = NULL;
    _module_functions[61].body = NULL;
    _module_functions[61].shadow_test = NULL;
    _module_functions[61].is_extern = false;
    _module_functions[61].returns_gc_managed = false;
    _module_functions[61].requires_manual_free = false;
    _module_functions[61].returns_borrowed = false;
    _module_functions[61].cleanup_function = NULL;
    _module_functions[61].params = NULL;

    /* Function: list_string_pop */
    _module_functions[62].name = "list_string_pop";
    _module_functions[62].param_count = 0;
    _module_functions[62].return_type = 4;
    _module_functions[62].return_struct_type_name = NULL;
    _module_functions[62].return_fn_sig = NULL;
    _module_functions[62].return_type_info = NULL;
    _module_functions[62].body = NULL;
    _module_functions[62].shadow_test = NULL;
    _module_functions[62].is_extern = false;
    _module_functions[62].returns_gc_managed = true;
    _module_functions[62].requires_manual_free = false;
    _module_functions[62].returns_borrowed = false;
    _module_functions[62].cleanup_function = NULL;
    _module_functions[62].params = NULL;

    /* Function: list_string_get */
    _module_functions[63].name = "list_string_get";
    _module_functions[63].param_count = 0;
    _module_functions[63].return_type = 4;
    _module_functions[63].return_struct_type_name = NULL;
    _module_functions[63].return_fn_sig = NULL;
    _module_functions[63].return_type_info = NULL;
    _module_functions[63].body = NULL;
    _module_functions[63].shadow_test = NULL;
    _module_functions[63].is_extern = false;
    _module_functions[63].returns_gc_managed = true;
    _module_functions[63].requires_manual_free = false;
    _module_functions[63].returns_borrowed = false;
    _module_functions[63].cleanup_function = NULL;
    _module_functions[63].params = NULL;

    /* Function: list_string_set */
    _module_functions[64].name = "list_string_set";
    _module_functions[64].param_count = 0;
    _module_functions[64].return_type = 6;
    _module_functions[64].return_struct_type_name = NULL;
    _module_functions[64].return_fn_sig = NULL;
    _module_functions[64].return_type_info = NULL;
    _module_functions[64].body = NULL;
    _module_functions[64].shadow_test = NULL;
    _module_functions[64].is_extern = false;
    _module_functions[64].returns_gc_managed = false;
    _module_functions[64].requires_manual_free = false;
    _module_functions[64].returns_borrowed = false;
    _module_functions[64].cleanup_function = NULL;
    _module_functions[64].params = NULL;

    /* Function: list_string_insert */
    _module_functions[65].name = "list_string_insert";
    _module_functions[65].param_count = 0;
    _module_functions[65].return_type = 6;
    _module_functions[65].return_struct_type_name = NULL;
    _module_functions[65].return_fn_sig = NULL;
    _module_functions[65].return_type_info = NULL;
    _module_functions[65].body = NULL;
    _module_functions[65].shadow_test = NULL;
    _module_functions[65].is_extern = false;
    _module_functions[65].returns_gc_managed = false;
    _module_functions[65].requires_manual_free = false;
    _module_functions[65].returns_borrowed = false;
    _module_functions[65].cleanup_function = NULL;
    _module_functions[65].params = NULL;

    /* Function: list_string_remove */
    _module_functions[66].name = "list_string_remove";
    _module_functions[66].param_count = 0;
    _module_functions[66].return_type = 4;
    _module_functions[66].return_struct_type_name = NULL;
    _module_functions[66].return_fn_sig = NULL;
    _module_functions[66].return_type_info = NULL;
    _module_functions[66].body = NULL;
    _module_functions[66].shadow_test = NULL;
    _module_functions[66].is_extern = false;
    _module_functions[66].returns_gc_managed = true;
    _module_functions[66].requires_manual_free = false;
    _module_functions[66].returns_borrowed = false;
    _module_functions[66].cleanup_function = NULL;
    _module_functions[66].params = NULL;

    /* Function: list_string_length */
    _module_functions[67].name = "list_string_length";
    _module_functions[67].param_count = 0;
    _module_functions[67].return_type = 0;
    _module_functions[67].return_struct_type_name = NULL;
    _module_functions[67].return_fn_sig = NULL;
    _module_functions[67].return_type_info = NULL;
    _module_functions[67].body = NULL;
    _module_functions[67].shadow_test = NULL;
    _module_functions[67].is_extern = false;
    _module_functions[67].returns_gc_managed = false;
    _module_functions[67].requires_manual_free = false;
    _module_functions[67].returns_borrowed = false;
    _module_functions[67].cleanup_function = NULL;
    _module_functions[67].params = NULL;

    /* Function: list_string_capacity */
    _module_functions[68].name = "list_string_capacity";
    _module_functions[68].param_count = 0;
    _module_functions[68].return_type = 0;
    _module_functions[68].return_struct_type_name = NULL;
    _module_functions[68].return_fn_sig = NULL;
    _module_functions[68].return_type_info = NULL;
    _module_functions[68].body = NULL;
    _module_functions[68].shadow_test = NULL;
    _module_functions[68].is_extern = false;
    _module_functions[68].returns_gc_managed = false;
    _module_functions[68].requires_manual_free = false;
    _module_functions[68].returns_borrowed = false;
    _module_functions[68].cleanup_function = NULL;
    _module_functions[68].params = NULL;

    /* Function: list_string_is_empty */
    _module_functions[69].name = "list_string_is_empty";
    _module_functions[69].param_count = 0;
    _module_functions[69].return_type = 3;
    _module_functions[69].return_struct_type_name = NULL;
    _module_functions[69].return_fn_sig = NULL;
    _module_functions[69].return_type_info = NULL;
    _module_functions[69].body = NULL;
    _module_functions[69].shadow_test = NULL;
    _module_functions[69].is_extern = false;
    _module_functions[69].returns_gc_managed = false;
    _module_functions[69].requires_manual_free = false;
    _module_functions[69].returns_borrowed = false;
    _module_functions[69].cleanup_function = NULL;
    _module_functions[69].params = NULL;

    /* Function: list_string_clear */
    _module_functions[70].name = "list_string_clear";
    _module_functions[70].param_count = 0;
    _module_functions[70].return_type = 6;
    _module_functions[70].return_struct_type_name = NULL;
    _module_functions[70].return_fn_sig = NULL;
    _module_functions[70].return_type_info = NULL;
    _module_functions[70].body = NULL;
    _module_functions[70].shadow_test = NULL;
    _module_functions[70].is_extern = false;
    _module_functions[70].returns_gc_managed = false;
    _module_functions[70].requires_manual_free = false;
    _module_functions[70].returns_borrowed = false;
    _module_functions[70].cleanup_function = NULL;
    _module_functions[70].params = NULL;

    /* Function: list_string_free */
    _module_functions[71].name = "list_string_free";
    _module_functions[71].param_count = 0;
    _module_functions[71].return_type = 6;
    _module_functions[71].return_struct_type_name = NULL;
    _module_functions[71].return_fn_sig = NULL;
    _module_functions[71].return_type_info = NULL;
    _module_functions[71].body = NULL;
    _module_functions[71].shadow_test = NULL;
    _module_functions[71].is_extern = false;
    _module_functions[71].returns_gc_managed = false;
    _module_functions[71].requires_manual_free = false;
    _module_functions[71].returns_borrowed = false;
    _module_functions[71].cleanup_function = NULL;
    _module_functions[71].params = NULL;

    /* Function: nl_list_Token_new */
    _module_functions[72].name = "nl_list_Token_new";
    _module_functions[72].param_count = 0;
    _module_functions[72].return_type = 14;
    _module_functions[72].return_struct_type_name = NULL;
    _module_functions[72].return_fn_sig = NULL;
    _module_functions[72].return_type_info = NULL;
    _module_functions[72].body = NULL;
    _module_functions[72].shadow_test = NULL;
    _module_functions[72].is_extern = false;
    _module_functions[72].returns_gc_managed = false;
    _module_functions[72].requires_manual_free = false;
    _module_functions[72].returns_borrowed = false;
    _module_functions[72].cleanup_function = NULL;
    _module_functions[72].params = NULL;

    /* Function: nl_list_Token_with_capacity */
    _module_functions[73].name = "nl_list_Token_with_capacity";
    _module_functions[73].param_count = 0;
    _module_functions[73].return_type = 14;
    _module_functions[73].return_struct_type_name = NULL;
    _module_functions[73].return_fn_sig = NULL;
    _module_functions[73].return_type_info = NULL;
    _module_functions[73].body = NULL;
    _module_functions[73].shadow_test = NULL;
    _module_functions[73].is_extern = false;
    _module_functions[73].returns_gc_managed = false;
    _module_functions[73].requires_manual_free = false;
    _module_functions[73].returns_borrowed = false;
    _module_functions[73].cleanup_function = NULL;
    _module_functions[73].params = NULL;

    /* Function: nl_list_Token_push */
    _module_functions[74].name = "nl_list_Token_push";
    _module_functions[74].param_count = 0;
    _module_functions[74].return_type = 6;
    _module_functions[74].return_struct_type_name = NULL;
    _module_functions[74].return_fn_sig = NULL;
    _module_functions[74].return_type_info = NULL;
    _module_functions[74].body = NULL;
    _module_functions[74].shadow_test = NULL;
    _module_functions[74].is_extern = false;
    _module_functions[74].returns_gc_managed = false;
    _module_functions[74].requires_manual_free = false;
    _module_functions[74].returns_borrowed = false;
    _module_functions[74].cleanup_function = NULL;
    _module_functions[74].params = NULL;

    /* Function: nl_list_Token_pop */
    _module_functions[75].name = "nl_list_Token_pop";
    _module_functions[75].param_count = 0;
    _module_functions[75].return_type = 8;
    _module_functions[75].return_struct_type_name = NULL;
    _module_functions[75].return_fn_sig = NULL;
    _module_functions[75].return_type_info = NULL;
    _module_functions[75].body = NULL;
    _module_functions[75].shadow_test = NULL;
    _module_functions[75].is_extern = false;
    _module_functions[75].returns_gc_managed = false;
    _module_functions[75].requires_manual_free = false;
    _module_functions[75].returns_borrowed = false;
    _module_functions[75].cleanup_function = NULL;
    _module_functions[75].params = NULL;

    /* Function: nl_list_Token_get */
    _module_functions[76].name = "nl_list_Token_get";
    _module_functions[76].param_count = 0;
    _module_functions[76].return_type = 8;
    _module_functions[76].return_struct_type_name = NULL;
    _module_functions[76].return_fn_sig = NULL;
    _module_functions[76].return_type_info = NULL;
    _module_functions[76].body = NULL;
    _module_functions[76].shadow_test = NULL;
    _module_functions[76].is_extern = false;
    _module_functions[76].returns_gc_managed = false;
    _module_functions[76].requires_manual_free = false;
    _module_functions[76].returns_borrowed = false;
    _module_functions[76].cleanup_function = NULL;
    _module_functions[76].params = NULL;

    /* Function: nl_list_Token_set */
    _module_functions[77].name = "nl_list_Token_set";
    _module_functions[77].param_count = 0;
    _module_functions[77].return_type = 6;
    _module_functions[77].return_struct_type_name = NULL;
    _module_functions[77].return_fn_sig = NULL;
    _module_functions[77].return_type_info = NULL;
    _module_functions[77].body = NULL;
    _module_functions[77].shadow_test = NULL;
    _module_functions[77].is_extern = false;
    _module_functions[77].returns_gc_managed = false;
    _module_functions[77].requires_manual_free = false;
    _module_functions[77].returns_borrowed = false;
    _module_functions[77].cleanup_function = NULL;
    _module_functions[77].params = NULL;

    /* Function: nl_list_Token_insert */
    _module_functions[78].name = "nl_list_Token_insert";
    _module_functions[78].param_count = 0;
    _module_functions[78].return_type = 6;
    _module_functions[78].return_struct_type_name = NULL;
    _module_functions[78].return_fn_sig = NULL;
    _module_functions[78].return_type_info = NULL;
    _module_functions[78].body = NULL;
    _module_functions[78].shadow_test = NULL;
    _module_functions[78].is_extern = false;
    _module_functions[78].returns_gc_managed = false;
    _module_functions[78].requires_manual_free = false;
    _module_functions[78].returns_borrowed = false;
    _module_functions[78].cleanup_function = NULL;
    _module_functions[78].params = NULL;

    /* Function: nl_list_Token_remove */
    _module_functions[79].name = "nl_list_Token_remove";
    _module_functions[79].param_count = 0;
    _module_functions[79].return_type = 8;
    _module_functions[79].return_struct_type_name = NULL;
    _module_functions[79].return_fn_sig = NULL;
    _module_functions[79].return_type_info = NULL;
    _module_functions[79].body = NULL;
    _module_functions[79].shadow_test = NULL;
    _module_functions[79].is_extern = false;
    _module_functions[79].returns_gc_managed = false;
    _module_functions[79].requires_manual_free = false;
    _module_functions[79].returns_borrowed = false;
    _module_functions[79].cleanup_function = NULL;
    _module_functions[79].params = NULL;

    /* Function: nl_list_Token_length */
    _module_functions[80].name = "nl_list_Token_length";
    _module_functions[80].param_count = 0;
    _module_functions[80].return_type = 0;
    _module_functions[80].return_struct_type_name = NULL;
    _module_functions[80].return_fn_sig = NULL;
    _module_functions[80].return_type_info = NULL;
    _module_functions[80].body = NULL;
    _module_functions[80].shadow_test = NULL;
    _module_functions[80].is_extern = false;
    _module_functions[80].returns_gc_managed = false;
    _module_functions[80].requires_manual_free = false;
    _module_functions[80].returns_borrowed = false;
    _module_functions[80].cleanup_function = NULL;
    _module_functions[80].params = NULL;

    /* Function: nl_list_Token_capacity */
    _module_functions[81].name = "nl_list_Token_capacity";
    _module_functions[81].param_count = 0;
    _module_functions[81].return_type = 0;
    _module_functions[81].return_struct_type_name = NULL;
    _module_functions[81].return_fn_sig = NULL;
    _module_functions[81].return_type_info = NULL;
    _module_functions[81].body = NULL;
    _module_functions[81].shadow_test = NULL;
    _module_functions[81].is_extern = false;
    _module_functions[81].returns_gc_managed = false;
    _module_functions[81].requires_manual_free = false;
    _module_functions[81].returns_borrowed = false;
    _module_functions[81].cleanup_function = NULL;
    _module_functions[81].params = NULL;

    /* Function: nl_list_Token_is_empty */
    _module_functions[82].name = "nl_list_Token_is_empty";
    _module_functions[82].param_count = 0;
    _module_functions[82].return_type = 3;
    _module_functions[82].return_struct_type_name = NULL;
    _module_functions[82].return_fn_sig = NULL;
    _module_functions[82].return_type_info = NULL;
    _module_functions[82].body = NULL;
    _module_functions[82].shadow_test = NULL;
    _module_functions[82].is_extern = false;
    _module_functions[82].returns_gc_managed = false;
    _module_functions[82].requires_manual_free = false;
    _module_functions[82].returns_borrowed = false;
    _module_functions[82].cleanup_function = NULL;
    _module_functions[82].params = NULL;

    /* Function: nl_list_Token_clear */
    _module_functions[83].name = "nl_list_Token_clear";
    _module_functions[83].param_count = 0;
    _module_functions[83].return_type = 6;
    _module_functions[83].return_struct_type_name = NULL;
    _module_functions[83].return_fn_sig = NULL;
    _module_functions[83].return_type_info = NULL;
    _module_functions[83].body = NULL;
    _module_functions[83].shadow_test = NULL;
    _module_functions[83].is_extern = false;
    _module_functions[83].returns_gc_managed = false;
    _module_functions[83].requires_manual_free = false;
    _module_functions[83].returns_borrowed = false;
    _module_functions[83].cleanup_function = NULL;
    _module_functions[83].params = NULL;

    /* Function: nl_list_Token_free */
    _module_functions[84].name = "nl_list_Token_free";
    _module_functions[84].param_count = 0;
    _module_functions[84].return_type = 6;
    _module_functions[84].return_struct_type_name = NULL;
    _module_functions[84].return_fn_sig = NULL;
    _module_functions[84].return_type_info = NULL;
    _module_functions[84].body = NULL;
    _module_functions[84].shadow_test = NULL;
    _module_functions[84].is_extern = false;
    _module_functions[84].returns_gc_managed = false;
    _module_functions[84].requires_manual_free = false;
    _module_functions[84].returns_borrowed = false;
    _module_functions[84].cleanup_function = NULL;
    _module_functions[84].params = NULL;

    /* Function: List_CompilerDiagnostic_new */
    _module_functions[85].name = "List_CompilerDiagnostic_new";
    _module_functions[85].param_count = 0;
    _module_functions[85].return_type = 15;
    _module_functions[85].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[85].return_fn_sig = NULL;
    _module_functions[85].return_type_info = NULL;
    _module_functions[85].body = NULL;
    _module_functions[85].shadow_test = NULL;
    _module_functions[85].is_extern = true;
    _module_functions[85].returns_gc_managed = false;
    _module_functions[85].requires_manual_free = false;
    _module_functions[85].returns_borrowed = false;
    _module_functions[85].cleanup_function = NULL;
    _module_functions[85].params = NULL;

    /* Function: List_CompilerDiagnostic_push */
    _module_functions[86].name = "List_CompilerDiagnostic_push";
    _module_functions[86].param_count = 2;
    _module_functions[86].return_type = 6;
    _module_functions[86].return_struct_type_name = NULL;
    _module_functions[86].return_fn_sig = NULL;
    _module_functions[86].return_type_info = NULL;
    _module_functions[86].body = NULL;
    _module_functions[86].shadow_test = NULL;
    _module_functions[86].is_extern = true;
    _module_functions[86].returns_gc_managed = false;
    _module_functions[86].requires_manual_free = false;
    _module_functions[86].returns_borrowed = false;
    _module_functions[86].cleanup_function = NULL;
    _module_functions[86].params = &_module_params[0];
    _module_params[0].name = "list";
    _module_params[0].type = 15;
    _module_params[0].struct_type_name = "CompilerDiagnostic";
    _module_params[0].element_type = 21;
    _module_params[0].fn_sig = NULL;
    _module_params[1].name = "value";
    _module_params[1].type = 8;
    _module_params[1].struct_type_name = "CompilerDiagnostic";
    _module_params[1].element_type = 21;
    _module_params[1].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_get */
    _module_functions[87].name = "List_CompilerDiagnostic_get";
    _module_functions[87].param_count = 2;
    _module_functions[87].return_type = 8;
    _module_functions[87].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[87].return_fn_sig = NULL;
    _module_functions[87].return_type_info = NULL;
    _module_functions[87].body = NULL;
    _module_functions[87].shadow_test = NULL;
    _module_functions[87].is_extern = true;
    _module_functions[87].returns_gc_managed = false;
    _module_functions[87].requires_manual_free = false;
    _module_functions[87].returns_borrowed = false;
    _module_functions[87].cleanup_function = NULL;
    _module_functions[87].params = &_module_params[2];
    _module_params[2].name = "list";
    _module_params[2].type = 15;
    _module_params[2].struct_type_name = "CompilerDiagnostic";
    _module_params[2].element_type = 21;
    _module_params[2].fn_sig = NULL;
    _module_params[3].name = "index";
    _module_params[3].type = 0;
    _module_params[3].struct_type_name = NULL;
    _module_params[3].element_type = 21;
    _module_params[3].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_length */
    _module_functions[88].name = "List_CompilerDiagnostic_length";
    _module_functions[88].param_count = 1;
    _module_functions[88].return_type = 0;
    _module_functions[88].return_struct_type_name = NULL;
    _module_functions[88].return_fn_sig = NULL;
    _module_functions[88].return_type_info = NULL;
    _module_functions[88].body = NULL;
    _module_functions[88].shadow_test = NULL;
    _module_functions[88].is_extern = true;
    _module_functions[88].returns_gc_managed = false;
    _module_functions[88].requires_manual_free = false;
    _module_functions[88].returns_borrowed = false;
    _module_functions[88].cleanup_function = NULL;
    _module_functions[88].params = &_module_params[4];
    _module_params[4].name = "list";
    _module_params[4].type = 15;
    _module_params[4].struct_type_name = "CompilerDiagnostic";
    _module_params[4].element_type = 21;
    _module_params[4].fn_sig = NULL;

    /* Function: List_LexerToken_new */
    _module_functions[89].name = "List_LexerToken_new";
    _module_functions[89].param_count = 0;
    _module_functions[89].return_type = 15;
    _module_functions[89].return_struct_type_name = "LexerToken";
    _module_functions[89].return_fn_sig = NULL;
    _module_functions[89].return_type_info = NULL;
    _module_functions[89].body = NULL;
    _module_functions[89].shadow_test = NULL;
    _module_functions[89].is_extern = true;
    _module_functions[89].returns_gc_managed = false;
    _module_functions[89].requires_manual_free = false;
    _module_functions[89].returns_borrowed = false;
    _module_functions[89].cleanup_function = NULL;
    _module_functions[89].params = NULL;

    /* Function: List_LexerToken_push */
    _module_functions[90].name = "List_LexerToken_push";
    _module_functions[90].param_count = 2;
    _module_functions[90].return_type = 6;
    _module_functions[90].return_struct_type_name = NULL;
    _module_functions[90].return_fn_sig = NULL;
    _module_functions[90].return_type_info = NULL;
    _module_functions[90].body = NULL;
    _module_functions[90].shadow_test = NULL;
    _module_functions[90].is_extern = true;
    _module_functions[90].returns_gc_managed = false;
    _module_functions[90].requires_manual_free = false;
    _module_functions[90].returns_borrowed = false;
    _module_functions[90].cleanup_function = NULL;
    _module_functions[90].params = &_module_params[5];
    _module_params[5].name = "list";
    _module_params[5].type = 15;
    _module_params[5].struct_type_name = "LexerToken";
    _module_params[5].element_type = 21;
    _module_params[5].fn_sig = NULL;
    _module_params[6].name = "value";
    _module_params[6].type = 8;
    _module_params[6].struct_type_name = "LexerToken";
    _module_params[6].element_type = 21;
    _module_params[6].fn_sig = NULL;

    /* Function: List_LexerToken_get */
    _module_functions[91].name = "List_LexerToken_get";
    _module_functions[91].param_count = 2;
    _module_functions[91].return_type = 8;
    _module_functions[91].return_struct_type_name = "LexerToken";
    _module_functions[91].return_fn_sig = NULL;
    _module_functions[91].return_type_info = NULL;
    _module_functions[91].body = NULL;
    _module_functions[91].shadow_test = NULL;
    _module_functions[91].is_extern = true;
    _module_functions[91].returns_gc_managed = false;
    _module_functions[91].requires_manual_free = false;
    _module_functions[91].returns_borrowed = false;
    _module_functions[91].cleanup_function = NULL;
    _module_functions[91].params = &_module_params[7];
    _module_params[7].name = "list";
    _module_params[7].type = 15;
    _module_params[7].struct_type_name = "LexerToken";
    _module_params[7].element_type = 21;
    _module_params[7].fn_sig = NULL;
    _module_params[8].name = "index";
    _module_params[8].type = 0;
    _module_params[8].struct_type_name = NULL;
    _module_params[8].element_type = 21;
    _module_params[8].fn_sig = NULL;

    /* Function: List_LexerToken_length */
    _module_functions[92].name = "List_LexerToken_length";
    _module_functions[92].param_count = 1;
    _module_functions[92].return_type = 0;
    _module_functions[92].return_struct_type_name = NULL;
    _module_functions[92].return_fn_sig = NULL;
    _module_functions[92].return_type_info = NULL;
    _module_functions[92].body = NULL;
    _module_functions[92].shadow_test = NULL;
    _module_functions[92].is_extern = true;
    _module_functions[92].returns_gc_managed = false;
    _module_functions[92].requires_manual_free = false;
    _module_functions[92].returns_borrowed = false;
    _module_functions[92].cleanup_function = NULL;
    _module_functions[92].params = &_module_params[9];
    _module_params[9].name = "list";
    _module_params[9].type = 15;
    _module_params[9].struct_type_name = "LexerToken";
    _module_params[9].element_type = 21;
    _module_params[9].fn_sig = NULL;

    /* Function: List_ASTStmtRef_new */
    _module_functions[93].name = "List_ASTStmtRef_new";
    _module_functions[93].param_count = 0;
    _module_functions[93].return_type = 15;
    _module_functions[93].return_struct_type_name = "ASTStmtRef";
    _module_functions[93].return_fn_sig = NULL;
    _module_functions[93].return_type_info = NULL;
    _module_functions[93].body = NULL;
    _module_functions[93].shadow_test = NULL;
    _module_functions[93].is_extern = true;
    _module_functions[93].returns_gc_managed = false;
    _module_functions[93].requires_manual_free = false;
    _module_functions[93].returns_borrowed = false;
    _module_functions[93].cleanup_function = NULL;
    _module_functions[93].params = NULL;

    /* Function: List_ASTStmtRef_push */
    _module_functions[94].name = "List_ASTStmtRef_push";
    _module_functions[94].param_count = 2;
    _module_functions[94].return_type = 6;
    _module_functions[94].return_struct_type_name = NULL;
    _module_functions[94].return_fn_sig = NULL;
    _module_functions[94].return_type_info = NULL;
    _module_functions[94].body = NULL;
    _module_functions[94].shadow_test = NULL;
    _module_functions[94].is_extern = true;
    _module_functions[94].returns_gc_managed = false;
    _module_functions[94].requires_manual_free = false;
    _module_functions[94].returns_borrowed = false;
    _module_functions[94].cleanup_function = NULL;
    _module_functions[94].params = &_module_params[10];
    _module_params[10].name = "list";
    _module_params[10].type = 15;
    _module_params[10].struct_type_name = "ASTStmtRef";
    _module_params[10].element_type = 21;
    _module_params[10].fn_sig = NULL;
    _module_params[11].name = "value";
    _module_params[11].type = 8;
    _module_params[11].struct_type_name = "ASTStmtRef";
    _module_params[11].element_type = 21;
    _module_params[11].fn_sig = NULL;

    /* Function: List_ASTStmtRef_get */
    _module_functions[95].name = "List_ASTStmtRef_get";
    _module_functions[95].param_count = 2;
    _module_functions[95].return_type = 8;
    _module_functions[95].return_struct_type_name = "ASTStmtRef";
    _module_functions[95].return_fn_sig = NULL;
    _module_functions[95].return_type_info = NULL;
    _module_functions[95].body = NULL;
    _module_functions[95].shadow_test = NULL;
    _module_functions[95].is_extern = true;
    _module_functions[95].returns_gc_managed = false;
    _module_functions[95].requires_manual_free = false;
    _module_functions[95].returns_borrowed = false;
    _module_functions[95].cleanup_function = NULL;
    _module_functions[95].params = &_module_params[12];
    _module_params[12].name = "list";
    _module_params[12].type = 15;
    _module_params[12].struct_type_name = "ASTStmtRef";
    _module_params[12].element_type = 21;
    _module_params[12].fn_sig = NULL;
    _module_params[13].name = "index";
    _module_params[13].type = 0;
    _module_params[13].struct_type_name = NULL;
    _module_params[13].element_type = 21;
    _module_params[13].fn_sig = NULL;

    /* Function: List_ASTStmtRef_length */
    _module_functions[96].name = "List_ASTStmtRef_length";
    _module_functions[96].param_count = 1;
    _module_functions[96].return_type = 0;
    _module_functions[96].return_struct_type_name = NULL;
    _module_functions[96].return_fn_sig = NULL;
    _module_functions[96].return_type_info = NULL;
    _module_functions[96].body = NULL;
    _module_functions[96].shadow_test = NULL;
    _module_functions[96].is_extern = true;
    _module_functions[96].returns_gc_managed = false;
    _module_functions[96].requires_manual_free = false;
    _module_functions[96].returns_borrowed = false;
    _module_functions[96].cleanup_function = NULL;
    _module_functions[96].params = &_module_params[14];
    _module_params[14].name = "list";
    _module_params[14].type = 15;
    _module_params[14].struct_type_name = "ASTStmtRef";
    _module_params[14].element_type = 21;
    _module_params[14].fn_sig = NULL;

    /* Function: List_ASTNumber_new */
    _module_functions[97].name = "List_ASTNumber_new";
    _module_functions[97].param_count = 0;
    _module_functions[97].return_type = 15;
    _module_functions[97].return_struct_type_name = "ASTNumber";
    _module_functions[97].return_fn_sig = NULL;
    _module_functions[97].return_type_info = NULL;
    _module_functions[97].body = NULL;
    _module_functions[97].shadow_test = NULL;
    _module_functions[97].is_extern = true;
    _module_functions[97].returns_gc_managed = false;
    _module_functions[97].requires_manual_free = false;
    _module_functions[97].returns_borrowed = false;
    _module_functions[97].cleanup_function = NULL;
    _module_functions[97].params = NULL;

    /* Function: List_ASTNumber_push */
    _module_functions[98].name = "List_ASTNumber_push";
    _module_functions[98].param_count = 2;
    _module_functions[98].return_type = 6;
    _module_functions[98].return_struct_type_name = NULL;
    _module_functions[98].return_fn_sig = NULL;
    _module_functions[98].return_type_info = NULL;
    _module_functions[98].body = NULL;
    _module_functions[98].shadow_test = NULL;
    _module_functions[98].is_extern = true;
    _module_functions[98].returns_gc_managed = false;
    _module_functions[98].requires_manual_free = false;
    _module_functions[98].returns_borrowed = false;
    _module_functions[98].cleanup_function = NULL;
    _module_functions[98].params = &_module_params[15];
    _module_params[15].name = "list";
    _module_params[15].type = 15;
    _module_params[15].struct_type_name = "ASTNumber";
    _module_params[15].element_type = 21;
    _module_params[15].fn_sig = NULL;
    _module_params[16].name = "value";
    _module_params[16].type = 8;
    _module_params[16].struct_type_name = "ASTNumber";
    _module_params[16].element_type = 21;
    _module_params[16].fn_sig = NULL;

    /* Function: List_ASTNumber_get */
    _module_functions[99].name = "List_ASTNumber_get";
    _module_functions[99].param_count = 2;
    _module_functions[99].return_type = 8;
    _module_functions[99].return_struct_type_name = "ASTNumber";
    _module_functions[99].return_fn_sig = NULL;
    _module_functions[99].return_type_info = NULL;
    _module_functions[99].body = NULL;
    _module_functions[99].shadow_test = NULL;
    _module_functions[99].is_extern = true;
    _module_functions[99].returns_gc_managed = false;
    _module_functions[99].requires_manual_free = false;
    _module_functions[99].returns_borrowed = false;
    _module_functions[99].cleanup_function = NULL;
    _module_functions[99].params = &_module_params[17];
    _module_params[17].name = "list";
    _module_params[17].type = 15;
    _module_params[17].struct_type_name = "ASTNumber";
    _module_params[17].element_type = 21;
    _module_params[17].fn_sig = NULL;
    _module_params[18].name = "index";
    _module_params[18].type = 0;
    _module_params[18].struct_type_name = NULL;
    _module_params[18].element_type = 21;
    _module_params[18].fn_sig = NULL;

    /* Function: List_ASTNumber_length */
    _module_functions[100].name = "List_ASTNumber_length";
    _module_functions[100].param_count = 1;
    _module_functions[100].return_type = 0;
    _module_functions[100].return_struct_type_name = NULL;
    _module_functions[100].return_fn_sig = NULL;
    _module_functions[100].return_type_info = NULL;
    _module_functions[100].body = NULL;
    _module_functions[100].shadow_test = NULL;
    _module_functions[100].is_extern = true;
    _module_functions[100].returns_gc_managed = false;
    _module_functions[100].requires_manual_free = false;
    _module_functions[100].returns_borrowed = false;
    _module_functions[100].cleanup_function = NULL;
    _module_functions[100].params = &_module_params[19];
    _module_params[19].name = "list";
    _module_params[19].type = 15;
    _module_params[19].struct_type_name = "ASTNumber";
    _module_params[19].element_type = 21;
    _module_params[19].fn_sig = NULL;

    /* Function: List_ASTFloat_new */
    _module_functions[101].name = "List_ASTFloat_new";
    _module_functions[101].param_count = 0;
    _module_functions[101].return_type = 15;
    _module_functions[101].return_struct_type_name = "ASTFloat";
    _module_functions[101].return_fn_sig = NULL;
    _module_functions[101].return_type_info = NULL;
    _module_functions[101].body = NULL;
    _module_functions[101].shadow_test = NULL;
    _module_functions[101].is_extern = true;
    _module_functions[101].returns_gc_managed = false;
    _module_functions[101].requires_manual_free = false;
    _module_functions[101].returns_borrowed = false;
    _module_functions[101].cleanup_function = NULL;
    _module_functions[101].params = NULL;

    /* Function: List_ASTFloat_push */
    _module_functions[102].name = "List_ASTFloat_push";
    _module_functions[102].param_count = 2;
    _module_functions[102].return_type = 6;
    _module_functions[102].return_struct_type_name = NULL;
    _module_functions[102].return_fn_sig = NULL;
    _module_functions[102].return_type_info = NULL;
    _module_functions[102].body = NULL;
    _module_functions[102].shadow_test = NULL;
    _module_functions[102].is_extern = true;
    _module_functions[102].returns_gc_managed = false;
    _module_functions[102].requires_manual_free = false;
    _module_functions[102].returns_borrowed = false;
    _module_functions[102].cleanup_function = NULL;
    _module_functions[102].params = &_module_params[20];
    _module_params[20].name = "list";
    _module_params[20].type = 15;
    _module_params[20].struct_type_name = "ASTFloat";
    _module_params[20].element_type = 21;
    _module_params[20].fn_sig = NULL;
    _module_params[21].name = "value";
    _module_params[21].type = 8;
    _module_params[21].struct_type_name = "ASTFloat";
    _module_params[21].element_type = 21;
    _module_params[21].fn_sig = NULL;

    /* Function: List_ASTFloat_get */
    _module_functions[103].name = "List_ASTFloat_get";
    _module_functions[103].param_count = 2;
    _module_functions[103].return_type = 8;
    _module_functions[103].return_struct_type_name = "ASTFloat";
    _module_functions[103].return_fn_sig = NULL;
    _module_functions[103].return_type_info = NULL;
    _module_functions[103].body = NULL;
    _module_functions[103].shadow_test = NULL;
    _module_functions[103].is_extern = true;
    _module_functions[103].returns_gc_managed = false;
    _module_functions[103].requires_manual_free = false;
    _module_functions[103].returns_borrowed = false;
    _module_functions[103].cleanup_function = NULL;
    _module_functions[103].params = &_module_params[22];
    _module_params[22].name = "list";
    _module_params[22].type = 15;
    _module_params[22].struct_type_name = "ASTFloat";
    _module_params[22].element_type = 21;
    _module_params[22].fn_sig = NULL;
    _module_params[23].name = "index";
    _module_params[23].type = 0;
    _module_params[23].struct_type_name = NULL;
    _module_params[23].element_type = 21;
    _module_params[23].fn_sig = NULL;

    /* Function: List_ASTFloat_length */
    _module_functions[104].name = "List_ASTFloat_length";
    _module_functions[104].param_count = 1;
    _module_functions[104].return_type = 0;
    _module_functions[104].return_struct_type_name = NULL;
    _module_functions[104].return_fn_sig = NULL;
    _module_functions[104].return_type_info = NULL;
    _module_functions[104].body = NULL;
    _module_functions[104].shadow_test = NULL;
    _module_functions[104].is_extern = true;
    _module_functions[104].returns_gc_managed = false;
    _module_functions[104].requires_manual_free = false;
    _module_functions[104].returns_borrowed = false;
    _module_functions[104].cleanup_function = NULL;
    _module_functions[104].params = &_module_params[24];
    _module_params[24].name = "list";
    _module_params[24].type = 15;
    _module_params[24].struct_type_name = "ASTFloat";
    _module_params[24].element_type = 21;
    _module_params[24].fn_sig = NULL;

    /* Function: List_ASTString_new */
    _module_functions[105].name = "List_ASTString_new";
    _module_functions[105].param_count = 0;
    _module_functions[105].return_type = 15;
    _module_functions[105].return_struct_type_name = "ASTString";
    _module_functions[105].return_fn_sig = NULL;
    _module_functions[105].return_type_info = NULL;
    _module_functions[105].body = NULL;
    _module_functions[105].shadow_test = NULL;
    _module_functions[105].is_extern = true;
    _module_functions[105].returns_gc_managed = false;
    _module_functions[105].requires_manual_free = false;
    _module_functions[105].returns_borrowed = false;
    _module_functions[105].cleanup_function = NULL;
    _module_functions[105].params = NULL;

    /* Function: List_ASTString_push */
    _module_functions[106].name = "List_ASTString_push";
    _module_functions[106].param_count = 2;
    _module_functions[106].return_type = 6;
    _module_functions[106].return_struct_type_name = NULL;
    _module_functions[106].return_fn_sig = NULL;
    _module_functions[106].return_type_info = NULL;
    _module_functions[106].body = NULL;
    _module_functions[106].shadow_test = NULL;
    _module_functions[106].is_extern = true;
    _module_functions[106].returns_gc_managed = false;
    _module_functions[106].requires_manual_free = false;
    _module_functions[106].returns_borrowed = false;
    _module_functions[106].cleanup_function = NULL;
    _module_functions[106].params = &_module_params[25];
    _module_params[25].name = "list";
    _module_params[25].type = 15;
    _module_params[25].struct_type_name = "ASTString";
    _module_params[25].element_type = 21;
    _module_params[25].fn_sig = NULL;
    _module_params[26].name = "value";
    _module_params[26].type = 8;
    _module_params[26].struct_type_name = "ASTString";
    _module_params[26].element_type = 21;
    _module_params[26].fn_sig = NULL;

    /* Function: List_ASTString_get */
    _module_functions[107].name = "List_ASTString_get";
    _module_functions[107].param_count = 2;
    _module_functions[107].return_type = 8;
    _module_functions[107].return_struct_type_name = "ASTString";
    _module_functions[107].return_fn_sig = NULL;
    _module_functions[107].return_type_info = NULL;
    _module_functions[107].body = NULL;
    _module_functions[107].shadow_test = NULL;
    _module_functions[107].is_extern = true;
    _module_functions[107].returns_gc_managed = false;
    _module_functions[107].requires_manual_free = false;
    _module_functions[107].returns_borrowed = false;
    _module_functions[107].cleanup_function = NULL;
    _module_functions[107].params = &_module_params[27];
    _module_params[27].name = "list";
    _module_params[27].type = 15;
    _module_params[27].struct_type_name = "ASTString";
    _module_params[27].element_type = 21;
    _module_params[27].fn_sig = NULL;
    _module_params[28].name = "index";
    _module_params[28].type = 0;
    _module_params[28].struct_type_name = NULL;
    _module_params[28].element_type = 21;
    _module_params[28].fn_sig = NULL;

    /* Function: List_ASTString_length */
    _module_functions[108].name = "List_ASTString_length";
    _module_functions[108].param_count = 1;
    _module_functions[108].return_type = 0;
    _module_functions[108].return_struct_type_name = NULL;
    _module_functions[108].return_fn_sig = NULL;
    _module_functions[108].return_type_info = NULL;
    _module_functions[108].body = NULL;
    _module_functions[108].shadow_test = NULL;
    _module_functions[108].is_extern = true;
    _module_functions[108].returns_gc_managed = false;
    _module_functions[108].requires_manual_free = false;
    _module_functions[108].returns_borrowed = false;
    _module_functions[108].cleanup_function = NULL;
    _module_functions[108].params = &_module_params[29];
    _module_params[29].name = "list";
    _module_params[29].type = 15;
    _module_params[29].struct_type_name = "ASTString";
    _module_params[29].element_type = 21;
    _module_params[29].fn_sig = NULL;

    /* Function: List_ASTBool_new */
    _module_functions[109].name = "List_ASTBool_new";
    _module_functions[109].param_count = 0;
    _module_functions[109].return_type = 15;
    _module_functions[109].return_struct_type_name = "ASTBool";
    _module_functions[109].return_fn_sig = NULL;
    _module_functions[109].return_type_info = NULL;
    _module_functions[109].body = NULL;
    _module_functions[109].shadow_test = NULL;
    _module_functions[109].is_extern = true;
    _module_functions[109].returns_gc_managed = false;
    _module_functions[109].requires_manual_free = false;
    _module_functions[109].returns_borrowed = false;
    _module_functions[109].cleanup_function = NULL;
    _module_functions[109].params = NULL;

    /* Function: List_ASTBool_push */
    _module_functions[110].name = "List_ASTBool_push";
    _module_functions[110].param_count = 2;
    _module_functions[110].return_type = 6;
    _module_functions[110].return_struct_type_name = NULL;
    _module_functions[110].return_fn_sig = NULL;
    _module_functions[110].return_type_info = NULL;
    _module_functions[110].body = NULL;
    _module_functions[110].shadow_test = NULL;
    _module_functions[110].is_extern = true;
    _module_functions[110].returns_gc_managed = false;
    _module_functions[110].requires_manual_free = false;
    _module_functions[110].returns_borrowed = false;
    _module_functions[110].cleanup_function = NULL;
    _module_functions[110].params = &_module_params[30];
    _module_params[30].name = "list";
    _module_params[30].type = 15;
    _module_params[30].struct_type_name = "ASTBool";
    _module_params[30].element_type = 21;
    _module_params[30].fn_sig = NULL;
    _module_params[31].name = "value";
    _module_params[31].type = 8;
    _module_params[31].struct_type_name = "ASTBool";
    _module_params[31].element_type = 21;
    _module_params[31].fn_sig = NULL;

    /* Function: List_ASTBool_get */
    _module_functions[111].name = "List_ASTBool_get";
    _module_functions[111].param_count = 2;
    _module_functions[111].return_type = 8;
    _module_functions[111].return_struct_type_name = "ASTBool";
    _module_functions[111].return_fn_sig = NULL;
    _module_functions[111].return_type_info = NULL;
    _module_functions[111].body = NULL;
    _module_functions[111].shadow_test = NULL;
    _module_functions[111].is_extern = true;
    _module_functions[111].returns_gc_managed = false;
    _module_functions[111].requires_manual_free = false;
    _module_functions[111].returns_borrowed = false;
    _module_functions[111].cleanup_function = NULL;
    _module_functions[111].params = &_module_params[32];
    _module_params[32].name = "list";
    _module_params[32].type = 15;
    _module_params[32].struct_type_name = "ASTBool";
    _module_params[32].element_type = 21;
    _module_params[32].fn_sig = NULL;
    _module_params[33].name = "index";
    _module_params[33].type = 0;
    _module_params[33].struct_type_name = NULL;
    _module_params[33].element_type = 21;
    _module_params[33].fn_sig = NULL;

    /* Function: List_ASTBool_length */
    _module_functions[112].name = "List_ASTBool_length";
    _module_functions[112].param_count = 1;
    _module_functions[112].return_type = 0;
    _module_functions[112].return_struct_type_name = NULL;
    _module_functions[112].return_fn_sig = NULL;
    _module_functions[112].return_type_info = NULL;
    _module_functions[112].body = NULL;
    _module_functions[112].shadow_test = NULL;
    _module_functions[112].is_extern = true;
    _module_functions[112].returns_gc_managed = false;
    _module_functions[112].requires_manual_free = false;
    _module_functions[112].returns_borrowed = false;
    _module_functions[112].cleanup_function = NULL;
    _module_functions[112].params = &_module_params[34];
    _module_params[34].name = "list";
    _module_params[34].type = 15;
    _module_params[34].struct_type_name = "ASTBool";
    _module_params[34].element_type = 21;
    _module_params[34].fn_sig = NULL;

    /* Function: List_ASTIdentifier_new */
    _module_functions[113].name = "List_ASTIdentifier_new";
    _module_functions[113].param_count = 0;
    _module_functions[113].return_type = 15;
    _module_functions[113].return_struct_type_name = "ASTIdentifier";
    _module_functions[113].return_fn_sig = NULL;
    _module_functions[113].return_type_info = NULL;
    _module_functions[113].body = NULL;
    _module_functions[113].shadow_test = NULL;
    _module_functions[113].is_extern = true;
    _module_functions[113].returns_gc_managed = false;
    _module_functions[113].requires_manual_free = false;
    _module_functions[113].returns_borrowed = false;
    _module_functions[113].cleanup_function = NULL;
    _module_functions[113].params = NULL;

    /* Function: List_ASTIdentifier_push */
    _module_functions[114].name = "List_ASTIdentifier_push";
    _module_functions[114].param_count = 2;
    _module_functions[114].return_type = 6;
    _module_functions[114].return_struct_type_name = NULL;
    _module_functions[114].return_fn_sig = NULL;
    _module_functions[114].return_type_info = NULL;
    _module_functions[114].body = NULL;
    _module_functions[114].shadow_test = NULL;
    _module_functions[114].is_extern = true;
    _module_functions[114].returns_gc_managed = false;
    _module_functions[114].requires_manual_free = false;
    _module_functions[114].returns_borrowed = false;
    _module_functions[114].cleanup_function = NULL;
    _module_functions[114].params = &_module_params[35];
    _module_params[35].name = "list";
    _module_params[35].type = 15;
    _module_params[35].struct_type_name = "ASTIdentifier";
    _module_params[35].element_type = 21;
    _module_params[35].fn_sig = NULL;
    _module_params[36].name = "value";
    _module_params[36].type = 8;
    _module_params[36].struct_type_name = "ASTIdentifier";
    _module_params[36].element_type = 21;
    _module_params[36].fn_sig = NULL;

    /* Function: List_ASTIdentifier_get */
    _module_functions[115].name = "List_ASTIdentifier_get";
    _module_functions[115].param_count = 2;
    _module_functions[115].return_type = 8;
    _module_functions[115].return_struct_type_name = "ASTIdentifier";
    _module_functions[115].return_fn_sig = NULL;
    _module_functions[115].return_type_info = NULL;
    _module_functions[115].body = NULL;
    _module_functions[115].shadow_test = NULL;
    _module_functions[115].is_extern = true;
    _module_functions[115].returns_gc_managed = false;
    _module_functions[115].requires_manual_free = false;
    _module_functions[115].returns_borrowed = false;
    _module_functions[115].cleanup_function = NULL;
    _module_functions[115].params = &_module_params[37];
    _module_params[37].name = "list";
    _module_params[37].type = 15;
    _module_params[37].struct_type_name = "ASTIdentifier";
    _module_params[37].element_type = 21;
    _module_params[37].fn_sig = NULL;
    _module_params[38].name = "index";
    _module_params[38].type = 0;
    _module_params[38].struct_type_name = NULL;
    _module_params[38].element_type = 21;
    _module_params[38].fn_sig = NULL;

    /* Function: List_ASTIdentifier_length */
    _module_functions[116].name = "List_ASTIdentifier_length";
    _module_functions[116].param_count = 1;
    _module_functions[116].return_type = 0;
    _module_functions[116].return_struct_type_name = NULL;
    _module_functions[116].return_fn_sig = NULL;
    _module_functions[116].return_type_info = NULL;
    _module_functions[116].body = NULL;
    _module_functions[116].shadow_test = NULL;
    _module_functions[116].is_extern = true;
    _module_functions[116].returns_gc_managed = false;
    _module_functions[116].requires_manual_free = false;
    _module_functions[116].returns_borrowed = false;
    _module_functions[116].cleanup_function = NULL;
    _module_functions[116].params = &_module_params[39];
    _module_params[39].name = "list";
    _module_params[39].type = 15;
    _module_params[39].struct_type_name = "ASTIdentifier";
    _module_params[39].element_type = 21;
    _module_params[39].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_new */
    _module_functions[117].name = "List_ASTBinaryOp_new";
    _module_functions[117].param_count = 0;
    _module_functions[117].return_type = 15;
    _module_functions[117].return_struct_type_name = "ASTBinaryOp";
    _module_functions[117].return_fn_sig = NULL;
    _module_functions[117].return_type_info = NULL;
    _module_functions[117].body = NULL;
    _module_functions[117].shadow_test = NULL;
    _module_functions[117].is_extern = true;
    _module_functions[117].returns_gc_managed = false;
    _module_functions[117].requires_manual_free = false;
    _module_functions[117].returns_borrowed = false;
    _module_functions[117].cleanup_function = NULL;
    _module_functions[117].params = NULL;

    /* Function: List_ASTBinaryOp_push */
    _module_functions[118].name = "List_ASTBinaryOp_push";
    _module_functions[118].param_count = 2;
    _module_functions[118].return_type = 6;
    _module_functions[118].return_struct_type_name = NULL;
    _module_functions[118].return_fn_sig = NULL;
    _module_functions[118].return_type_info = NULL;
    _module_functions[118].body = NULL;
    _module_functions[118].shadow_test = NULL;
    _module_functions[118].is_extern = true;
    _module_functions[118].returns_gc_managed = false;
    _module_functions[118].requires_manual_free = false;
    _module_functions[118].returns_borrowed = false;
    _module_functions[118].cleanup_function = NULL;
    _module_functions[118].params = &_module_params[40];
    _module_params[40].name = "list";
    _module_params[40].type = 15;
    _module_params[40].struct_type_name = "ASTBinaryOp";
    _module_params[40].element_type = 21;
    _module_params[40].fn_sig = NULL;
    _module_params[41].name = "value";
    _module_params[41].type = 8;
    _module_params[41].struct_type_name = "ASTBinaryOp";
    _module_params[41].element_type = 21;
    _module_params[41].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_get */
    _module_functions[119].name = "List_ASTBinaryOp_get";
    _module_functions[119].param_count = 2;
    _module_functions[119].return_type = 8;
    _module_functions[119].return_struct_type_name = "ASTBinaryOp";
    _module_functions[119].return_fn_sig = NULL;
    _module_functions[119].return_type_info = NULL;
    _module_functions[119].body = NULL;
    _module_functions[119].shadow_test = NULL;
    _module_functions[119].is_extern = true;
    _module_functions[119].returns_gc_managed = false;
    _module_functions[119].requires_manual_free = false;
    _module_functions[119].returns_borrowed = false;
    _module_functions[119].cleanup_function = NULL;
    _module_functions[119].params = &_module_params[42];
    _module_params[42].name = "list";
    _module_params[42].type = 15;
    _module_params[42].struct_type_name = "ASTBinaryOp";
    _module_params[42].element_type = 21;
    _module_params[42].fn_sig = NULL;
    _module_params[43].name = "index";
    _module_params[43].type = 0;
    _module_params[43].struct_type_name = NULL;
    _module_params[43].element_type = 21;
    _module_params[43].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_length */
    _module_functions[120].name = "List_ASTBinaryOp_length";
    _module_functions[120].param_count = 1;
    _module_functions[120].return_type = 0;
    _module_functions[120].return_struct_type_name = NULL;
    _module_functions[120].return_fn_sig = NULL;
    _module_functions[120].return_type_info = NULL;
    _module_functions[120].body = NULL;
    _module_functions[120].shadow_test = NULL;
    _module_functions[120].is_extern = true;
    _module_functions[120].returns_gc_managed = false;
    _module_functions[120].requires_manual_free = false;
    _module_functions[120].returns_borrowed = false;
    _module_functions[120].cleanup_function = NULL;
    _module_functions[120].params = &_module_params[44];
    _module_params[44].name = "list";
    _module_params[44].type = 15;
    _module_params[44].struct_type_name = "ASTBinaryOp";
    _module_params[44].element_type = 21;
    _module_params[44].fn_sig = NULL;

    /* Function: List_ASTCall_new */
    _module_functions[121].name = "List_ASTCall_new";
    _module_functions[121].param_count = 0;
    _module_functions[121].return_type = 15;
    _module_functions[121].return_struct_type_name = "ASTCall";
    _module_functions[121].return_fn_sig = NULL;
    _module_functions[121].return_type_info = NULL;
    _module_functions[121].body = NULL;
    _module_functions[121].shadow_test = NULL;
    _module_functions[121].is_extern = true;
    _module_functions[121].returns_gc_managed = false;
    _module_functions[121].requires_manual_free = false;
    _module_functions[121].returns_borrowed = false;
    _module_functions[121].cleanup_function = NULL;
    _module_functions[121].params = NULL;

    /* Function: List_ASTCall_push */
    _module_functions[122].name = "List_ASTCall_push";
    _module_functions[122].param_count = 2;
    _module_functions[122].return_type = 6;
    _module_functions[122].return_struct_type_name = NULL;
    _module_functions[122].return_fn_sig = NULL;
    _module_functions[122].return_type_info = NULL;
    _module_functions[122].body = NULL;
    _module_functions[122].shadow_test = NULL;
    _module_functions[122].is_extern = true;
    _module_functions[122].returns_gc_managed = false;
    _module_functions[122].requires_manual_free = false;
    _module_functions[122].returns_borrowed = false;
    _module_functions[122].cleanup_function = NULL;
    _module_functions[122].params = &_module_params[45];
    _module_params[45].name = "list";
    _module_params[45].type = 15;
    _module_params[45].struct_type_name = "ASTCall";
    _module_params[45].element_type = 21;
    _module_params[45].fn_sig = NULL;
    _module_params[46].name = "value";
    _module_params[46].type = 8;
    _module_params[46].struct_type_name = "ASTCall";
    _module_params[46].element_type = 21;
    _module_params[46].fn_sig = NULL;

    /* Function: List_ASTCall_get */
    _module_functions[123].name = "List_ASTCall_get";
    _module_functions[123].param_count = 2;
    _module_functions[123].return_type = 8;
    _module_functions[123].return_struct_type_name = "ASTCall";
    _module_functions[123].return_fn_sig = NULL;
    _module_functions[123].return_type_info = NULL;
    _module_functions[123].body = NULL;
    _module_functions[123].shadow_test = NULL;
    _module_functions[123].is_extern = true;
    _module_functions[123].returns_gc_managed = false;
    _module_functions[123].requires_manual_free = false;
    _module_functions[123].returns_borrowed = false;
    _module_functions[123].cleanup_function = NULL;
    _module_functions[123].params = &_module_params[47];
    _module_params[47].name = "list";
    _module_params[47].type = 15;
    _module_params[47].struct_type_name = "ASTCall";
    _module_params[47].element_type = 21;
    _module_params[47].fn_sig = NULL;
    _module_params[48].name = "index";
    _module_params[48].type = 0;
    _module_params[48].struct_type_name = NULL;
    _module_params[48].element_type = 21;
    _module_params[48].fn_sig = NULL;

    /* Function: List_ASTCall_length */
    _module_functions[124].name = "List_ASTCall_length";
    _module_functions[124].param_count = 1;
    _module_functions[124].return_type = 0;
    _module_functions[124].return_struct_type_name = NULL;
    _module_functions[124].return_fn_sig = NULL;
    _module_functions[124].return_type_info = NULL;
    _module_functions[124].body = NULL;
    _module_functions[124].shadow_test = NULL;
    _module_functions[124].is_extern = true;
    _module_functions[124].returns_gc_managed = false;
    _module_functions[124].requires_manual_free = false;
    _module_functions[124].returns_borrowed = false;
    _module_functions[124].cleanup_function = NULL;
    _module_functions[124].params = &_module_params[49];
    _module_params[49].name = "list";
    _module_params[49].type = 15;
    _module_params[49].struct_type_name = "ASTCall";
    _module_params[49].element_type = 21;
    _module_params[49].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_new */
    _module_functions[125].name = "List_ASTModuleQualifiedCall_new";
    _module_functions[125].param_count = 0;
    _module_functions[125].return_type = 15;
    _module_functions[125].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[125].return_fn_sig = NULL;
    _module_functions[125].return_type_info = NULL;
    _module_functions[125].body = NULL;
    _module_functions[125].shadow_test = NULL;
    _module_functions[125].is_extern = true;
    _module_functions[125].returns_gc_managed = false;
    _module_functions[125].requires_manual_free = false;
    _module_functions[125].returns_borrowed = false;
    _module_functions[125].cleanup_function = NULL;
    _module_functions[125].params = NULL;

    /* Function: List_ASTModuleQualifiedCall_push */
    _module_functions[126].name = "List_ASTModuleQualifiedCall_push";
    _module_functions[126].param_count = 2;
    _module_functions[126].return_type = 6;
    _module_functions[126].return_struct_type_name = NULL;
    _module_functions[126].return_fn_sig = NULL;
    _module_functions[126].return_type_info = NULL;
    _module_functions[126].body = NULL;
    _module_functions[126].shadow_test = NULL;
    _module_functions[126].is_extern = true;
    _module_functions[126].returns_gc_managed = false;
    _module_functions[126].requires_manual_free = false;
    _module_functions[126].returns_borrowed = false;
    _module_functions[126].cleanup_function = NULL;
    _module_functions[126].params = &_module_params[50];
    _module_params[50].name = "list";
    _module_params[50].type = 15;
    _module_params[50].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[50].element_type = 21;
    _module_params[50].fn_sig = NULL;
    _module_params[51].name = "value";
    _module_params[51].type = 8;
    _module_params[51].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[51].element_type = 21;
    _module_params[51].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_get */
    _module_functions[127].name = "List_ASTModuleQualifiedCall_get";
    _module_functions[127].param_count = 2;
    _module_functions[127].return_type = 8;
    _module_functions[127].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[127].return_fn_sig = NULL;
    _module_functions[127].return_type_info = NULL;
    _module_functions[127].body = NULL;
    _module_functions[127].shadow_test = NULL;
    _module_functions[127].is_extern = true;
    _module_functions[127].returns_gc_managed = false;
    _module_functions[127].requires_manual_free = false;
    _module_functions[127].returns_borrowed = false;
    _module_functions[127].cleanup_function = NULL;
    _module_functions[127].params = &_module_params[52];
    _module_params[52].name = "list";
    _module_params[52].type = 15;
    _module_params[52].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[52].element_type = 21;
    _module_params[52].fn_sig = NULL;
    _module_params[53].name = "index";
    _module_params[53].type = 0;
    _module_params[53].struct_type_name = NULL;
    _module_params[53].element_type = 21;
    _module_params[53].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_length */
    _module_functions[128].name = "List_ASTModuleQualifiedCall_length";
    _module_functions[128].param_count = 1;
    _module_functions[128].return_type = 0;
    _module_functions[128].return_struct_type_name = NULL;
    _module_functions[128].return_fn_sig = NULL;
    _module_functions[128].return_type_info = NULL;
    _module_functions[128].body = NULL;
    _module_functions[128].shadow_test = NULL;
    _module_functions[128].is_extern = true;
    _module_functions[128].returns_gc_managed = false;
    _module_functions[128].requires_manual_free = false;
    _module_functions[128].returns_borrowed = false;
    _module_functions[128].cleanup_function = NULL;
    _module_functions[128].params = &_module_params[54];
    _module_params[54].name = "list";
    _module_params[54].type = 15;
    _module_params[54].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[54].element_type = 21;
    _module_params[54].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_new */
    _module_functions[129].name = "List_ASTArrayLiteral_new";
    _module_functions[129].param_count = 0;
    _module_functions[129].return_type = 15;
    _module_functions[129].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[129].return_fn_sig = NULL;
    _module_functions[129].return_type_info = NULL;
    _module_functions[129].body = NULL;
    _module_functions[129].shadow_test = NULL;
    _module_functions[129].is_extern = true;
    _module_functions[129].returns_gc_managed = false;
    _module_functions[129].requires_manual_free = false;
    _module_functions[129].returns_borrowed = false;
    _module_functions[129].cleanup_function = NULL;
    _module_functions[129].params = NULL;

    /* Function: List_ASTArrayLiteral_push */
    _module_functions[130].name = "List_ASTArrayLiteral_push";
    _module_functions[130].param_count = 2;
    _module_functions[130].return_type = 6;
    _module_functions[130].return_struct_type_name = NULL;
    _module_functions[130].return_fn_sig = NULL;
    _module_functions[130].return_type_info = NULL;
    _module_functions[130].body = NULL;
    _module_functions[130].shadow_test = NULL;
    _module_functions[130].is_extern = true;
    _module_functions[130].returns_gc_managed = false;
    _module_functions[130].requires_manual_free = false;
    _module_functions[130].returns_borrowed = false;
    _module_functions[130].cleanup_function = NULL;
    _module_functions[130].params = &_module_params[55];
    _module_params[55].name = "list";
    _module_params[55].type = 15;
    _module_params[55].struct_type_name = "ASTArrayLiteral";
    _module_params[55].element_type = 21;
    _module_params[55].fn_sig = NULL;
    _module_params[56].name = "value";
    _module_params[56].type = 8;
    _module_params[56].struct_type_name = "ASTArrayLiteral";
    _module_params[56].element_type = 21;
    _module_params[56].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_get */
    _module_functions[131].name = "List_ASTArrayLiteral_get";
    _module_functions[131].param_count = 2;
    _module_functions[131].return_type = 8;
    _module_functions[131].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[131].return_fn_sig = NULL;
    _module_functions[131].return_type_info = NULL;
    _module_functions[131].body = NULL;
    _module_functions[131].shadow_test = NULL;
    _module_functions[131].is_extern = true;
    _module_functions[131].returns_gc_managed = false;
    _module_functions[131].requires_manual_free = false;
    _module_functions[131].returns_borrowed = false;
    _module_functions[131].cleanup_function = NULL;
    _module_functions[131].params = &_module_params[57];
    _module_params[57].name = "list";
    _module_params[57].type = 15;
    _module_params[57].struct_type_name = "ASTArrayLiteral";
    _module_params[57].element_type = 21;
    _module_params[57].fn_sig = NULL;
    _module_params[58].name = "index";
    _module_params[58].type = 0;
    _module_params[58].struct_type_name = NULL;
    _module_params[58].element_type = 21;
    _module_params[58].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_length */
    _module_functions[132].name = "List_ASTArrayLiteral_length";
    _module_functions[132].param_count = 1;
    _module_functions[132].return_type = 0;
    _module_functions[132].return_struct_type_name = NULL;
    _module_functions[132].return_fn_sig = NULL;
    _module_functions[132].return_type_info = NULL;
    _module_functions[132].body = NULL;
    _module_functions[132].shadow_test = NULL;
    _module_functions[132].is_extern = true;
    _module_functions[132].returns_gc_managed = false;
    _module_functions[132].requires_manual_free = false;
    _module_functions[132].returns_borrowed = false;
    _module_functions[132].cleanup_function = NULL;
    _module_functions[132].params = &_module_params[59];
    _module_params[59].name = "list";
    _module_params[59].type = 15;
    _module_params[59].struct_type_name = "ASTArrayLiteral";
    _module_params[59].element_type = 21;
    _module_params[59].fn_sig = NULL;

    /* Function: List_ASTLet_new */
    _module_functions[133].name = "List_ASTLet_new";
    _module_functions[133].param_count = 0;
    _module_functions[133].return_type = 15;
    _module_functions[133].return_struct_type_name = "ASTLet";
    _module_functions[133].return_fn_sig = NULL;
    _module_functions[133].return_type_info = NULL;
    _module_functions[133].body = NULL;
    _module_functions[133].shadow_test = NULL;
    _module_functions[133].is_extern = true;
    _module_functions[133].returns_gc_managed = false;
    _module_functions[133].requires_manual_free = false;
    _module_functions[133].returns_borrowed = false;
    _module_functions[133].cleanup_function = NULL;
    _module_functions[133].params = NULL;

    /* Function: List_ASTLet_push */
    _module_functions[134].name = "List_ASTLet_push";
    _module_functions[134].param_count = 2;
    _module_functions[134].return_type = 6;
    _module_functions[134].return_struct_type_name = NULL;
    _module_functions[134].return_fn_sig = NULL;
    _module_functions[134].return_type_info = NULL;
    _module_functions[134].body = NULL;
    _module_functions[134].shadow_test = NULL;
    _module_functions[134].is_extern = true;
    _module_functions[134].returns_gc_managed = false;
    _module_functions[134].requires_manual_free = false;
    _module_functions[134].returns_borrowed = false;
    _module_functions[134].cleanup_function = NULL;
    _module_functions[134].params = &_module_params[60];
    _module_params[60].name = "list";
    _module_params[60].type = 15;
    _module_params[60].struct_type_name = "ASTLet";
    _module_params[60].element_type = 21;
    _module_params[60].fn_sig = NULL;
    _module_params[61].name = "value";
    _module_params[61].type = 8;
    _module_params[61].struct_type_name = "ASTLet";
    _module_params[61].element_type = 21;
    _module_params[61].fn_sig = NULL;

    /* Function: List_ASTLet_get */
    _module_functions[135].name = "List_ASTLet_get";
    _module_functions[135].param_count = 2;
    _module_functions[135].return_type = 8;
    _module_functions[135].return_struct_type_name = "ASTLet";
    _module_functions[135].return_fn_sig = NULL;
    _module_functions[135].return_type_info = NULL;
    _module_functions[135].body = NULL;
    _module_functions[135].shadow_test = NULL;
    _module_functions[135].is_extern = true;
    _module_functions[135].returns_gc_managed = false;
    _module_functions[135].requires_manual_free = false;
    _module_functions[135].returns_borrowed = false;
    _module_functions[135].cleanup_function = NULL;
    _module_functions[135].params = &_module_params[62];
    _module_params[62].name = "list";
    _module_params[62].type = 15;
    _module_params[62].struct_type_name = "ASTLet";
    _module_params[62].element_type = 21;
    _module_params[62].fn_sig = NULL;
    _module_params[63].name = "index";
    _module_params[63].type = 0;
    _module_params[63].struct_type_name = NULL;
    _module_params[63].element_type = 21;
    _module_params[63].fn_sig = NULL;

    /* Function: List_ASTLet_length */
    _module_functions[136].name = "List_ASTLet_length";
    _module_functions[136].param_count = 1;
    _module_functions[136].return_type = 0;
    _module_functions[136].return_struct_type_name = NULL;
    _module_functions[136].return_fn_sig = NULL;
    _module_functions[136].return_type_info = NULL;
    _module_functions[136].body = NULL;
    _module_functions[136].shadow_test = NULL;
    _module_functions[136].is_extern = true;
    _module_functions[136].returns_gc_managed = false;
    _module_functions[136].requires_manual_free = false;
    _module_functions[136].returns_borrowed = false;
    _module_functions[136].cleanup_function = NULL;
    _module_functions[136].params = &_module_params[64];
    _module_params[64].name = "list";
    _module_params[64].type = 15;
    _module_params[64].struct_type_name = "ASTLet";
    _module_params[64].element_type = 21;
    _module_params[64].fn_sig = NULL;

    /* Function: List_ASTSet_new */
    _module_functions[137].name = "List_ASTSet_new";
    _module_functions[137].param_count = 0;
    _module_functions[137].return_type = 15;
    _module_functions[137].return_struct_type_name = "ASTSet";
    _module_functions[137].return_fn_sig = NULL;
    _module_functions[137].return_type_info = NULL;
    _module_functions[137].body = NULL;
    _module_functions[137].shadow_test = NULL;
    _module_functions[137].is_extern = true;
    _module_functions[137].returns_gc_managed = false;
    _module_functions[137].requires_manual_free = false;
    _module_functions[137].returns_borrowed = false;
    _module_functions[137].cleanup_function = NULL;
    _module_functions[137].params = NULL;

    /* Function: List_ASTSet_push */
    _module_functions[138].name = "List_ASTSet_push";
    _module_functions[138].param_count = 2;
    _module_functions[138].return_type = 6;
    _module_functions[138].return_struct_type_name = NULL;
    _module_functions[138].return_fn_sig = NULL;
    _module_functions[138].return_type_info = NULL;
    _module_functions[138].body = NULL;
    _module_functions[138].shadow_test = NULL;
    _module_functions[138].is_extern = true;
    _module_functions[138].returns_gc_managed = false;
    _module_functions[138].requires_manual_free = false;
    _module_functions[138].returns_borrowed = false;
    _module_functions[138].cleanup_function = NULL;
    _module_functions[138].params = &_module_params[65];
    _module_params[65].name = "list";
    _module_params[65].type = 15;
    _module_params[65].struct_type_name = "ASTSet";
    _module_params[65].element_type = 21;
    _module_params[65].fn_sig = NULL;
    _module_params[66].name = "value";
    _module_params[66].type = 8;
    _module_params[66].struct_type_name = "ASTSet";
    _module_params[66].element_type = 21;
    _module_params[66].fn_sig = NULL;

    /* Function: List_ASTSet_get */
    _module_functions[139].name = "List_ASTSet_get";
    _module_functions[139].param_count = 2;
    _module_functions[139].return_type = 8;
    _module_functions[139].return_struct_type_name = "ASTSet";
    _module_functions[139].return_fn_sig = NULL;
    _module_functions[139].return_type_info = NULL;
    _module_functions[139].body = NULL;
    _module_functions[139].shadow_test = NULL;
    _module_functions[139].is_extern = true;
    _module_functions[139].returns_gc_managed = false;
    _module_functions[139].requires_manual_free = false;
    _module_functions[139].returns_borrowed = false;
    _module_functions[139].cleanup_function = NULL;
    _module_functions[139].params = &_module_params[67];
    _module_params[67].name = "list";
    _module_params[67].type = 15;
    _module_params[67].struct_type_name = "ASTSet";
    _module_params[67].element_type = 21;
    _module_params[67].fn_sig = NULL;
    _module_params[68].name = "index";
    _module_params[68].type = 0;
    _module_params[68].struct_type_name = NULL;
    _module_params[68].element_type = 21;
    _module_params[68].fn_sig = NULL;

    /* Function: List_ASTSet_length */
    _module_functions[140].name = "List_ASTSet_length";
    _module_functions[140].param_count = 1;
    _module_functions[140].return_type = 0;
    _module_functions[140].return_struct_type_name = NULL;
    _module_functions[140].return_fn_sig = NULL;
    _module_functions[140].return_type_info = NULL;
    _module_functions[140].body = NULL;
    _module_functions[140].shadow_test = NULL;
    _module_functions[140].is_extern = true;
    _module_functions[140].returns_gc_managed = false;
    _module_functions[140].requires_manual_free = false;
    _module_functions[140].returns_borrowed = false;
    _module_functions[140].cleanup_function = NULL;
    _module_functions[140].params = &_module_params[69];
    _module_params[69].name = "list";
    _module_params[69].type = 15;
    _module_params[69].struct_type_name = "ASTSet";
    _module_params[69].element_type = 21;
    _module_params[69].fn_sig = NULL;

    /* Function: List_ASTIf_new */
    _module_functions[141].name = "List_ASTIf_new";
    _module_functions[141].param_count = 0;
    _module_functions[141].return_type = 15;
    _module_functions[141].return_struct_type_name = "ASTIf";
    _module_functions[141].return_fn_sig = NULL;
    _module_functions[141].return_type_info = NULL;
    _module_functions[141].body = NULL;
    _module_functions[141].shadow_test = NULL;
    _module_functions[141].is_extern = true;
    _module_functions[141].returns_gc_managed = false;
    _module_functions[141].requires_manual_free = false;
    _module_functions[141].returns_borrowed = false;
    _module_functions[141].cleanup_function = NULL;
    _module_functions[141].params = NULL;

    /* Function: List_ASTIf_push */
    _module_functions[142].name = "List_ASTIf_push";
    _module_functions[142].param_count = 2;
    _module_functions[142].return_type = 6;
    _module_functions[142].return_struct_type_name = NULL;
    _module_functions[142].return_fn_sig = NULL;
    _module_functions[142].return_type_info = NULL;
    _module_functions[142].body = NULL;
    _module_functions[142].shadow_test = NULL;
    _module_functions[142].is_extern = true;
    _module_functions[142].returns_gc_managed = false;
    _module_functions[142].requires_manual_free = false;
    _module_functions[142].returns_borrowed = false;
    _module_functions[142].cleanup_function = NULL;
    _module_functions[142].params = &_module_params[70];
    _module_params[70].name = "list";
    _module_params[70].type = 15;
    _module_params[70].struct_type_name = "ASTIf";
    _module_params[70].element_type = 21;
    _module_params[70].fn_sig = NULL;
    _module_params[71].name = "value";
    _module_params[71].type = 8;
    _module_params[71].struct_type_name = "ASTIf";
    _module_params[71].element_type = 21;
    _module_params[71].fn_sig = NULL;

    /* Function: List_ASTIf_get */
    _module_functions[143].name = "List_ASTIf_get";
    _module_functions[143].param_count = 2;
    _module_functions[143].return_type = 8;
    _module_functions[143].return_struct_type_name = "ASTIf";
    _module_functions[143].return_fn_sig = NULL;
    _module_functions[143].return_type_info = NULL;
    _module_functions[143].body = NULL;
    _module_functions[143].shadow_test = NULL;
    _module_functions[143].is_extern = true;
    _module_functions[143].returns_gc_managed = false;
    _module_functions[143].requires_manual_free = false;
    _module_functions[143].returns_borrowed = false;
    _module_functions[143].cleanup_function = NULL;
    _module_functions[143].params = &_module_params[72];
    _module_params[72].name = "list";
    _module_params[72].type = 15;
    _module_params[72].struct_type_name = "ASTIf";
    _module_params[72].element_type = 21;
    _module_params[72].fn_sig = NULL;
    _module_params[73].name = "index";
    _module_params[73].type = 0;
    _module_params[73].struct_type_name = NULL;
    _module_params[73].element_type = 21;
    _module_params[73].fn_sig = NULL;

    /* Function: List_ASTIf_length */
    _module_functions[144].name = "List_ASTIf_length";
    _module_functions[144].param_count = 1;
    _module_functions[144].return_type = 0;
    _module_functions[144].return_struct_type_name = NULL;
    _module_functions[144].return_fn_sig = NULL;
    _module_functions[144].return_type_info = NULL;
    _module_functions[144].body = NULL;
    _module_functions[144].shadow_test = NULL;
    _module_functions[144].is_extern = true;
    _module_functions[144].returns_gc_managed = false;
    _module_functions[144].requires_manual_free = false;
    _module_functions[144].returns_borrowed = false;
    _module_functions[144].cleanup_function = NULL;
    _module_functions[144].params = &_module_params[74];
    _module_params[74].name = "list";
    _module_params[74].type = 15;
    _module_params[74].struct_type_name = "ASTIf";
    _module_params[74].element_type = 21;
    _module_params[74].fn_sig = NULL;

    /* Function: List_ASTWhile_new */
    _module_functions[145].name = "List_ASTWhile_new";
    _module_functions[145].param_count = 0;
    _module_functions[145].return_type = 15;
    _module_functions[145].return_struct_type_name = "ASTWhile";
    _module_functions[145].return_fn_sig = NULL;
    _module_functions[145].return_type_info = NULL;
    _module_functions[145].body = NULL;
    _module_functions[145].shadow_test = NULL;
    _module_functions[145].is_extern = true;
    _module_functions[145].returns_gc_managed = false;
    _module_functions[145].requires_manual_free = false;
    _module_functions[145].returns_borrowed = false;
    _module_functions[145].cleanup_function = NULL;
    _module_functions[145].params = NULL;

    /* Function: List_ASTWhile_push */
    _module_functions[146].name = "List_ASTWhile_push";
    _module_functions[146].param_count = 2;
    _module_functions[146].return_type = 6;
    _module_functions[146].return_struct_type_name = NULL;
    _module_functions[146].return_fn_sig = NULL;
    _module_functions[146].return_type_info = NULL;
    _module_functions[146].body = NULL;
    _module_functions[146].shadow_test = NULL;
    _module_functions[146].is_extern = true;
    _module_functions[146].returns_gc_managed = false;
    _module_functions[146].requires_manual_free = false;
    _module_functions[146].returns_borrowed = false;
    _module_functions[146].cleanup_function = NULL;
    _module_functions[146].params = &_module_params[75];
    _module_params[75].name = "list";
    _module_params[75].type = 15;
    _module_params[75].struct_type_name = "ASTWhile";
    _module_params[75].element_type = 21;
    _module_params[75].fn_sig = NULL;
    _module_params[76].name = "value";
    _module_params[76].type = 8;
    _module_params[76].struct_type_name = "ASTWhile";
    _module_params[76].element_type = 21;
    _module_params[76].fn_sig = NULL;

    /* Function: List_ASTWhile_get */
    _module_functions[147].name = "List_ASTWhile_get";
    _module_functions[147].param_count = 2;
    _module_functions[147].return_type = 8;
    _module_functions[147].return_struct_type_name = "ASTWhile";
    _module_functions[147].return_fn_sig = NULL;
    _module_functions[147].return_type_info = NULL;
    _module_functions[147].body = NULL;
    _module_functions[147].shadow_test = NULL;
    _module_functions[147].is_extern = true;
    _module_functions[147].returns_gc_managed = false;
    _module_functions[147].requires_manual_free = false;
    _module_functions[147].returns_borrowed = false;
    _module_functions[147].cleanup_function = NULL;
    _module_functions[147].params = &_module_params[77];
    _module_params[77].name = "list";
    _module_params[77].type = 15;
    _module_params[77].struct_type_name = "ASTWhile";
    _module_params[77].element_type = 21;
    _module_params[77].fn_sig = NULL;
    _module_params[78].name = "index";
    _module_params[78].type = 0;
    _module_params[78].struct_type_name = NULL;
    _module_params[78].element_type = 21;
    _module_params[78].fn_sig = NULL;

    /* Function: List_ASTWhile_length */
    _module_functions[148].name = "List_ASTWhile_length";
    _module_functions[148].param_count = 1;
    _module_functions[148].return_type = 0;
    _module_functions[148].return_struct_type_name = NULL;
    _module_functions[148].return_fn_sig = NULL;
    _module_functions[148].return_type_info = NULL;
    _module_functions[148].body = NULL;
    _module_functions[148].shadow_test = NULL;
    _module_functions[148].is_extern = true;
    _module_functions[148].returns_gc_managed = false;
    _module_functions[148].requires_manual_free = false;
    _module_functions[148].returns_borrowed = false;
    _module_functions[148].cleanup_function = NULL;
    _module_functions[148].params = &_module_params[79];
    _module_params[79].name = "list";
    _module_params[79].type = 15;
    _module_params[79].struct_type_name = "ASTWhile";
    _module_params[79].element_type = 21;
    _module_params[79].fn_sig = NULL;

    /* Function: List_ASTFor_new */
    _module_functions[149].name = "List_ASTFor_new";
    _module_functions[149].param_count = 0;
    _module_functions[149].return_type = 15;
    _module_functions[149].return_struct_type_name = "ASTFor";
    _module_functions[149].return_fn_sig = NULL;
    _module_functions[149].return_type_info = NULL;
    _module_functions[149].body = NULL;
    _module_functions[149].shadow_test = NULL;
    _module_functions[149].is_extern = true;
    _module_functions[149].returns_gc_managed = false;
    _module_functions[149].requires_manual_free = false;
    _module_functions[149].returns_borrowed = false;
    _module_functions[149].cleanup_function = NULL;
    _module_functions[149].params = NULL;

    /* Function: List_ASTFor_push */
    _module_functions[150].name = "List_ASTFor_push";
    _module_functions[150].param_count = 2;
    _module_functions[150].return_type = 6;
    _module_functions[150].return_struct_type_name = NULL;
    _module_functions[150].return_fn_sig = NULL;
    _module_functions[150].return_type_info = NULL;
    _module_functions[150].body = NULL;
    _module_functions[150].shadow_test = NULL;
    _module_functions[150].is_extern = true;
    _module_functions[150].returns_gc_managed = false;
    _module_functions[150].requires_manual_free = false;
    _module_functions[150].returns_borrowed = false;
    _module_functions[150].cleanup_function = NULL;
    _module_functions[150].params = &_module_params[80];
    _module_params[80].name = "list";
    _module_params[80].type = 15;
    _module_params[80].struct_type_name = "ASTFor";
    _module_params[80].element_type = 21;
    _module_params[80].fn_sig = NULL;
    _module_params[81].name = "value";
    _module_params[81].type = 8;
    _module_params[81].struct_type_name = "ASTFor";
    _module_params[81].element_type = 21;
    _module_params[81].fn_sig = NULL;

    /* Function: List_ASTFor_get */
    _module_functions[151].name = "List_ASTFor_get";
    _module_functions[151].param_count = 2;
    _module_functions[151].return_type = 8;
    _module_functions[151].return_struct_type_name = "ASTFor";
    _module_functions[151].return_fn_sig = NULL;
    _module_functions[151].return_type_info = NULL;
    _module_functions[151].body = NULL;
    _module_functions[151].shadow_test = NULL;
    _module_functions[151].is_extern = true;
    _module_functions[151].returns_gc_managed = false;
    _module_functions[151].requires_manual_free = false;
    _module_functions[151].returns_borrowed = false;
    _module_functions[151].cleanup_function = NULL;
    _module_functions[151].params = &_module_params[82];
    _module_params[82].name = "list";
    _module_params[82].type = 15;
    _module_params[82].struct_type_name = "ASTFor";
    _module_params[82].element_type = 21;
    _module_params[82].fn_sig = NULL;
    _module_params[83].name = "index";
    _module_params[83].type = 0;
    _module_params[83].struct_type_name = NULL;
    _module_params[83].element_type = 21;
    _module_params[83].fn_sig = NULL;

    /* Function: List_ASTFor_length */
    _module_functions[152].name = "List_ASTFor_length";
    _module_functions[152].param_count = 1;
    _module_functions[152].return_type = 0;
    _module_functions[152].return_struct_type_name = NULL;
    _module_functions[152].return_fn_sig = NULL;
    _module_functions[152].return_type_info = NULL;
    _module_functions[152].body = NULL;
    _module_functions[152].shadow_test = NULL;
    _module_functions[152].is_extern = true;
    _module_functions[152].returns_gc_managed = false;
    _module_functions[152].requires_manual_free = false;
    _module_functions[152].returns_borrowed = false;
    _module_functions[152].cleanup_function = NULL;
    _module_functions[152].params = &_module_params[84];
    _module_params[84].name = "list";
    _module_params[84].type = 15;
    _module_params[84].struct_type_name = "ASTFor";
    _module_params[84].element_type = 21;
    _module_params[84].fn_sig = NULL;

    /* Function: List_ASTReturn_new */
    _module_functions[153].name = "List_ASTReturn_new";
    _module_functions[153].param_count = 0;
    _module_functions[153].return_type = 15;
    _module_functions[153].return_struct_type_name = "ASTReturn";
    _module_functions[153].return_fn_sig = NULL;
    _module_functions[153].return_type_info = NULL;
    _module_functions[153].body = NULL;
    _module_functions[153].shadow_test = NULL;
    _module_functions[153].is_extern = true;
    _module_functions[153].returns_gc_managed = false;
    _module_functions[153].requires_manual_free = false;
    _module_functions[153].returns_borrowed = false;
    _module_functions[153].cleanup_function = NULL;
    _module_functions[153].params = NULL;

    /* Function: List_ASTReturn_push */
    _module_functions[154].name = "List_ASTReturn_push";
    _module_functions[154].param_count = 2;
    _module_functions[154].return_type = 6;
    _module_functions[154].return_struct_type_name = NULL;
    _module_functions[154].return_fn_sig = NULL;
    _module_functions[154].return_type_info = NULL;
    _module_functions[154].body = NULL;
    _module_functions[154].shadow_test = NULL;
    _module_functions[154].is_extern = true;
    _module_functions[154].returns_gc_managed = false;
    _module_functions[154].requires_manual_free = false;
    _module_functions[154].returns_borrowed = false;
    _module_functions[154].cleanup_function = NULL;
    _module_functions[154].params = &_module_params[85];
    _module_params[85].name = "list";
    _module_params[85].type = 15;
    _module_params[85].struct_type_name = "ASTReturn";
    _module_params[85].element_type = 21;
    _module_params[85].fn_sig = NULL;
    _module_params[86].name = "value";
    _module_params[86].type = 8;
    _module_params[86].struct_type_name = "ASTReturn";
    _module_params[86].element_type = 21;
    _module_params[86].fn_sig = NULL;

    /* Function: List_ASTReturn_get */
    _module_functions[155].name = "List_ASTReturn_get";
    _module_functions[155].param_count = 2;
    _module_functions[155].return_type = 8;
    _module_functions[155].return_struct_type_name = "ASTReturn";
    _module_functions[155].return_fn_sig = NULL;
    _module_functions[155].return_type_info = NULL;
    _module_functions[155].body = NULL;
    _module_functions[155].shadow_test = NULL;
    _module_functions[155].is_extern = true;
    _module_functions[155].returns_gc_managed = false;
    _module_functions[155].requires_manual_free = false;
    _module_functions[155].returns_borrowed = false;
    _module_functions[155].cleanup_function = NULL;
    _module_functions[155].params = &_module_params[87];
    _module_params[87].name = "list";
    _module_params[87].type = 15;
    _module_params[87].struct_type_name = "ASTReturn";
    _module_params[87].element_type = 21;
    _module_params[87].fn_sig = NULL;
    _module_params[88].name = "index";
    _module_params[88].type = 0;
    _module_params[88].struct_type_name = NULL;
    _module_params[88].element_type = 21;
    _module_params[88].fn_sig = NULL;

    /* Function: List_ASTReturn_length */
    _module_functions[156].name = "List_ASTReturn_length";
    _module_functions[156].param_count = 1;
    _module_functions[156].return_type = 0;
    _module_functions[156].return_struct_type_name = NULL;
    _module_functions[156].return_fn_sig = NULL;
    _module_functions[156].return_type_info = NULL;
    _module_functions[156].body = NULL;
    _module_functions[156].shadow_test = NULL;
    _module_functions[156].is_extern = true;
    _module_functions[156].returns_gc_managed = false;
    _module_functions[156].requires_manual_free = false;
    _module_functions[156].returns_borrowed = false;
    _module_functions[156].cleanup_function = NULL;
    _module_functions[156].params = &_module_params[89];
    _module_params[89].name = "list";
    _module_params[89].type = 15;
    _module_params[89].struct_type_name = "ASTReturn";
    _module_params[89].element_type = 21;
    _module_params[89].fn_sig = NULL;

    /* Function: List_ASTBlock_new */
    _module_functions[157].name = "List_ASTBlock_new";
    _module_functions[157].param_count = 0;
    _module_functions[157].return_type = 15;
    _module_functions[157].return_struct_type_name = "ASTBlock";
    _module_functions[157].return_fn_sig = NULL;
    _module_functions[157].return_type_info = NULL;
    _module_functions[157].body = NULL;
    _module_functions[157].shadow_test = NULL;
    _module_functions[157].is_extern = true;
    _module_functions[157].returns_gc_managed = false;
    _module_functions[157].requires_manual_free = false;
    _module_functions[157].returns_borrowed = false;
    _module_functions[157].cleanup_function = NULL;
    _module_functions[157].params = NULL;

    /* Function: List_ASTBlock_push */
    _module_functions[158].name = "List_ASTBlock_push";
    _module_functions[158].param_count = 2;
    _module_functions[158].return_type = 6;
    _module_functions[158].return_struct_type_name = NULL;
    _module_functions[158].return_fn_sig = NULL;
    _module_functions[158].return_type_info = NULL;
    _module_functions[158].body = NULL;
    _module_functions[158].shadow_test = NULL;
    _module_functions[158].is_extern = true;
    _module_functions[158].returns_gc_managed = false;
    _module_functions[158].requires_manual_free = false;
    _module_functions[158].returns_borrowed = false;
    _module_functions[158].cleanup_function = NULL;
    _module_functions[158].params = &_module_params[90];
    _module_params[90].name = "list";
    _module_params[90].type = 15;
    _module_params[90].struct_type_name = "ASTBlock";
    _module_params[90].element_type = 21;
    _module_params[90].fn_sig = NULL;
    _module_params[91].name = "value";
    _module_params[91].type = 8;
    _module_params[91].struct_type_name = "ASTBlock";
    _module_params[91].element_type = 21;
    _module_params[91].fn_sig = NULL;

    /* Function: List_ASTBlock_get */
    _module_functions[159].name = "List_ASTBlock_get";
    _module_functions[159].param_count = 2;
    _module_functions[159].return_type = 8;
    _module_functions[159].return_struct_type_name = "ASTBlock";
    _module_functions[159].return_fn_sig = NULL;
    _module_functions[159].return_type_info = NULL;
    _module_functions[159].body = NULL;
    _module_functions[159].shadow_test = NULL;
    _module_functions[159].is_extern = true;
    _module_functions[159].returns_gc_managed = false;
    _module_functions[159].requires_manual_free = false;
    _module_functions[159].returns_borrowed = false;
    _module_functions[159].cleanup_function = NULL;
    _module_functions[159].params = &_module_params[92];
    _module_params[92].name = "list";
    _module_params[92].type = 15;
    _module_params[92].struct_type_name = "ASTBlock";
    _module_params[92].element_type = 21;
    _module_params[92].fn_sig = NULL;
    _module_params[93].name = "index";
    _module_params[93].type = 0;
    _module_params[93].struct_type_name = NULL;
    _module_params[93].element_type = 21;
    _module_params[93].fn_sig = NULL;

    /* Function: List_ASTBlock_length */
    _module_functions[160].name = "List_ASTBlock_length";
    _module_functions[160].param_count = 1;
    _module_functions[160].return_type = 0;
    _module_functions[160].return_struct_type_name = NULL;
    _module_functions[160].return_fn_sig = NULL;
    _module_functions[160].return_type_info = NULL;
    _module_functions[160].body = NULL;
    _module_functions[160].shadow_test = NULL;
    _module_functions[160].is_extern = true;
    _module_functions[160].returns_gc_managed = false;
    _module_functions[160].requires_manual_free = false;
    _module_functions[160].returns_borrowed = false;
    _module_functions[160].cleanup_function = NULL;
    _module_functions[160].params = &_module_params[94];
    _module_params[94].name = "list";
    _module_params[94].type = 15;
    _module_params[94].struct_type_name = "ASTBlock";
    _module_params[94].element_type = 21;
    _module_params[94].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_new */
    _module_functions[161].name = "List_ASTUnsafeBlock_new";
    _module_functions[161].param_count = 0;
    _module_functions[161].return_type = 15;
    _module_functions[161].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[161].return_fn_sig = NULL;
    _module_functions[161].return_type_info = NULL;
    _module_functions[161].body = NULL;
    _module_functions[161].shadow_test = NULL;
    _module_functions[161].is_extern = true;
    _module_functions[161].returns_gc_managed = false;
    _module_functions[161].requires_manual_free = false;
    _module_functions[161].returns_borrowed = false;
    _module_functions[161].cleanup_function = NULL;
    _module_functions[161].params = NULL;

    /* Function: List_ASTUnsafeBlock_push */
    _module_functions[162].name = "List_ASTUnsafeBlock_push";
    _module_functions[162].param_count = 2;
    _module_functions[162].return_type = 6;
    _module_functions[162].return_struct_type_name = NULL;
    _module_functions[162].return_fn_sig = NULL;
    _module_functions[162].return_type_info = NULL;
    _module_functions[162].body = NULL;
    _module_functions[162].shadow_test = NULL;
    _module_functions[162].is_extern = true;
    _module_functions[162].returns_gc_managed = false;
    _module_functions[162].requires_manual_free = false;
    _module_functions[162].returns_borrowed = false;
    _module_functions[162].cleanup_function = NULL;
    _module_functions[162].params = &_module_params[95];
    _module_params[95].name = "list";
    _module_params[95].type = 15;
    _module_params[95].struct_type_name = "ASTUnsafeBlock";
    _module_params[95].element_type = 21;
    _module_params[95].fn_sig = NULL;
    _module_params[96].name = "value";
    _module_params[96].type = 8;
    _module_params[96].struct_type_name = "ASTUnsafeBlock";
    _module_params[96].element_type = 21;
    _module_params[96].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_get */
    _module_functions[163].name = "List_ASTUnsafeBlock_get";
    _module_functions[163].param_count = 2;
    _module_functions[163].return_type = 8;
    _module_functions[163].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[163].return_fn_sig = NULL;
    _module_functions[163].return_type_info = NULL;
    _module_functions[163].body = NULL;
    _module_functions[163].shadow_test = NULL;
    _module_functions[163].is_extern = true;
    _module_functions[163].returns_gc_managed = false;
    _module_functions[163].requires_manual_free = false;
    _module_functions[163].returns_borrowed = false;
    _module_functions[163].cleanup_function = NULL;
    _module_functions[163].params = &_module_params[97];
    _module_params[97].name = "list";
    _module_params[97].type = 15;
    _module_params[97].struct_type_name = "ASTUnsafeBlock";
    _module_params[97].element_type = 21;
    _module_params[97].fn_sig = NULL;
    _module_params[98].name = "index";
    _module_params[98].type = 0;
    _module_params[98].struct_type_name = NULL;
    _module_params[98].element_type = 21;
    _module_params[98].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_length */
    _module_functions[164].name = "List_ASTUnsafeBlock_length";
    _module_functions[164].param_count = 1;
    _module_functions[164].return_type = 0;
    _module_functions[164].return_struct_type_name = NULL;
    _module_functions[164].return_fn_sig = NULL;
    _module_functions[164].return_type_info = NULL;
    _module_functions[164].body = NULL;
    _module_functions[164].shadow_test = NULL;
    _module_functions[164].is_extern = true;
    _module_functions[164].returns_gc_managed = false;
    _module_functions[164].requires_manual_free = false;
    _module_functions[164].returns_borrowed = false;
    _module_functions[164].cleanup_function = NULL;
    _module_functions[164].params = &_module_params[99];
    _module_params[99].name = "list";
    _module_params[99].type = 15;
    _module_params[99].struct_type_name = "ASTUnsafeBlock";
    _module_params[99].element_type = 21;
    _module_params[99].fn_sig = NULL;

    /* Function: List_ASTPrint_new */
    _module_functions[165].name = "List_ASTPrint_new";
    _module_functions[165].param_count = 0;
    _module_functions[165].return_type = 15;
    _module_functions[165].return_struct_type_name = "ASTPrint";
    _module_functions[165].return_fn_sig = NULL;
    _module_functions[165].return_type_info = NULL;
    _module_functions[165].body = NULL;
    _module_functions[165].shadow_test = NULL;
    _module_functions[165].is_extern = true;
    _module_functions[165].returns_gc_managed = false;
    _module_functions[165].requires_manual_free = false;
    _module_functions[165].returns_borrowed = false;
    _module_functions[165].cleanup_function = NULL;
    _module_functions[165].params = NULL;

    /* Function: List_ASTPrint_push */
    _module_functions[166].name = "List_ASTPrint_push";
    _module_functions[166].param_count = 2;
    _module_functions[166].return_type = 6;
    _module_functions[166].return_struct_type_name = NULL;
    _module_functions[166].return_fn_sig = NULL;
    _module_functions[166].return_type_info = NULL;
    _module_functions[166].body = NULL;
    _module_functions[166].shadow_test = NULL;
    _module_functions[166].is_extern = true;
    _module_functions[166].returns_gc_managed = false;
    _module_functions[166].requires_manual_free = false;
    _module_functions[166].returns_borrowed = false;
    _module_functions[166].cleanup_function = NULL;
    _module_functions[166].params = &_module_params[100];
    _module_params[100].name = "list";
    _module_params[100].type = 15;
    _module_params[100].struct_type_name = "ASTPrint";
    _module_params[100].element_type = 21;
    _module_params[100].fn_sig = NULL;
    _module_params[101].name = "value";
    _module_params[101].type = 8;
    _module_params[101].struct_type_name = "ASTPrint";
    _module_params[101].element_type = 21;
    _module_params[101].fn_sig = NULL;

    /* Function: List_ASTPrint_get */
    _module_functions[167].name = "List_ASTPrint_get";
    _module_functions[167].param_count = 2;
    _module_functions[167].return_type = 8;
    _module_functions[167].return_struct_type_name = "ASTPrint";
    _module_functions[167].return_fn_sig = NULL;
    _module_functions[167].return_type_info = NULL;
    _module_functions[167].body = NULL;
    _module_functions[167].shadow_test = NULL;
    _module_functions[167].is_extern = true;
    _module_functions[167].returns_gc_managed = false;
    _module_functions[167].requires_manual_free = false;
    _module_functions[167].returns_borrowed = false;
    _module_functions[167].cleanup_function = NULL;
    _module_functions[167].params = &_module_params[102];
    _module_params[102].name = "list";
    _module_params[102].type = 15;
    _module_params[102].struct_type_name = "ASTPrint";
    _module_params[102].element_type = 21;
    _module_params[102].fn_sig = NULL;
    _module_params[103].name = "index";
    _module_params[103].type = 0;
    _module_params[103].struct_type_name = NULL;
    _module_params[103].element_type = 21;
    _module_params[103].fn_sig = NULL;

    /* Function: List_ASTPrint_length */
    _module_functions[168].name = "List_ASTPrint_length";
    _module_functions[168].param_count = 1;
    _module_functions[168].return_type = 0;
    _module_functions[168].return_struct_type_name = NULL;
    _module_functions[168].return_fn_sig = NULL;
    _module_functions[168].return_type_info = NULL;
    _module_functions[168].body = NULL;
    _module_functions[168].shadow_test = NULL;
    _module_functions[168].is_extern = true;
    _module_functions[168].returns_gc_managed = false;
    _module_functions[168].requires_manual_free = false;
    _module_functions[168].returns_borrowed = false;
    _module_functions[168].cleanup_function = NULL;
    _module_functions[168].params = &_module_params[104];
    _module_params[104].name = "list";
    _module_params[104].type = 15;
    _module_params[104].struct_type_name = "ASTPrint";
    _module_params[104].element_type = 21;
    _module_params[104].fn_sig = NULL;

    /* Function: List_ASTAssert_new */
    _module_functions[169].name = "List_ASTAssert_new";
    _module_functions[169].param_count = 0;
    _module_functions[169].return_type = 15;
    _module_functions[169].return_struct_type_name = "ASTAssert";
    _module_functions[169].return_fn_sig = NULL;
    _module_functions[169].return_type_info = NULL;
    _module_functions[169].body = NULL;
    _module_functions[169].shadow_test = NULL;
    _module_functions[169].is_extern = true;
    _module_functions[169].returns_gc_managed = false;
    _module_functions[169].requires_manual_free = false;
    _module_functions[169].returns_borrowed = false;
    _module_functions[169].cleanup_function = NULL;
    _module_functions[169].params = NULL;

    /* Function: List_ASTAssert_push */
    _module_functions[170].name = "List_ASTAssert_push";
    _module_functions[170].param_count = 2;
    _module_functions[170].return_type = 6;
    _module_functions[170].return_struct_type_name = NULL;
    _module_functions[170].return_fn_sig = NULL;
    _module_functions[170].return_type_info = NULL;
    _module_functions[170].body = NULL;
    _module_functions[170].shadow_test = NULL;
    _module_functions[170].is_extern = true;
    _module_functions[170].returns_gc_managed = false;
    _module_functions[170].requires_manual_free = false;
    _module_functions[170].returns_borrowed = false;
    _module_functions[170].cleanup_function = NULL;
    _module_functions[170].params = &_module_params[105];
    _module_params[105].name = "list";
    _module_params[105].type = 15;
    _module_params[105].struct_type_name = "ASTAssert";
    _module_params[105].element_type = 21;
    _module_params[105].fn_sig = NULL;
    _module_params[106].name = "value";
    _module_params[106].type = 8;
    _module_params[106].struct_type_name = "ASTAssert";
    _module_params[106].element_type = 21;
    _module_params[106].fn_sig = NULL;

    /* Function: List_ASTAssert_get */
    _module_functions[171].name = "List_ASTAssert_get";
    _module_functions[171].param_count = 2;
    _module_functions[171].return_type = 8;
    _module_functions[171].return_struct_type_name = "ASTAssert";
    _module_functions[171].return_fn_sig = NULL;
    _module_functions[171].return_type_info = NULL;
    _module_functions[171].body = NULL;
    _module_functions[171].shadow_test = NULL;
    _module_functions[171].is_extern = true;
    _module_functions[171].returns_gc_managed = false;
    _module_functions[171].requires_manual_free = false;
    _module_functions[171].returns_borrowed = false;
    _module_functions[171].cleanup_function = NULL;
    _module_functions[171].params = &_module_params[107];
    _module_params[107].name = "list";
    _module_params[107].type = 15;
    _module_params[107].struct_type_name = "ASTAssert";
    _module_params[107].element_type = 21;
    _module_params[107].fn_sig = NULL;
    _module_params[108].name = "index";
    _module_params[108].type = 0;
    _module_params[108].struct_type_name = NULL;
    _module_params[108].element_type = 21;
    _module_params[108].fn_sig = NULL;

    /* Function: List_ASTAssert_length */
    _module_functions[172].name = "List_ASTAssert_length";
    _module_functions[172].param_count = 1;
    _module_functions[172].return_type = 0;
    _module_functions[172].return_struct_type_name = NULL;
    _module_functions[172].return_fn_sig = NULL;
    _module_functions[172].return_type_info = NULL;
    _module_functions[172].body = NULL;
    _module_functions[172].shadow_test = NULL;
    _module_functions[172].is_extern = true;
    _module_functions[172].returns_gc_managed = false;
    _module_functions[172].requires_manual_free = false;
    _module_functions[172].returns_borrowed = false;
    _module_functions[172].cleanup_function = NULL;
    _module_functions[172].params = &_module_params[109];
    _module_params[109].name = "list";
    _module_params[109].type = 15;
    _module_params[109].struct_type_name = "ASTAssert";
    _module_params[109].element_type = 21;
    _module_params[109].fn_sig = NULL;

    /* Function: List_ASTFunction_new */
    _module_functions[173].name = "List_ASTFunction_new";
    _module_functions[173].param_count = 0;
    _module_functions[173].return_type = 15;
    _module_functions[173].return_struct_type_name = "ASTFunction";
    _module_functions[173].return_fn_sig = NULL;
    _module_functions[173].return_type_info = NULL;
    _module_functions[173].body = NULL;
    _module_functions[173].shadow_test = NULL;
    _module_functions[173].is_extern = true;
    _module_functions[173].returns_gc_managed = false;
    _module_functions[173].requires_manual_free = false;
    _module_functions[173].returns_borrowed = false;
    _module_functions[173].cleanup_function = NULL;
    _module_functions[173].params = NULL;

    /* Function: List_ASTFunction_push */
    _module_functions[174].name = "List_ASTFunction_push";
    _module_functions[174].param_count = 2;
    _module_functions[174].return_type = 6;
    _module_functions[174].return_struct_type_name = NULL;
    _module_functions[174].return_fn_sig = NULL;
    _module_functions[174].return_type_info = NULL;
    _module_functions[174].body = NULL;
    _module_functions[174].shadow_test = NULL;
    _module_functions[174].is_extern = true;
    _module_functions[174].returns_gc_managed = false;
    _module_functions[174].requires_manual_free = false;
    _module_functions[174].returns_borrowed = false;
    _module_functions[174].cleanup_function = NULL;
    _module_functions[174].params = &_module_params[110];
    _module_params[110].name = "list";
    _module_params[110].type = 15;
    _module_params[110].struct_type_name = "ASTFunction";
    _module_params[110].element_type = 21;
    _module_params[110].fn_sig = NULL;
    _module_params[111].name = "value";
    _module_params[111].type = 8;
    _module_params[111].struct_type_name = "ASTFunction";
    _module_params[111].element_type = 21;
    _module_params[111].fn_sig = NULL;

    /* Function: List_ASTFunction_get */
    _module_functions[175].name = "List_ASTFunction_get";
    _module_functions[175].param_count = 2;
    _module_functions[175].return_type = 8;
    _module_functions[175].return_struct_type_name = "ASTFunction";
    _module_functions[175].return_fn_sig = NULL;
    _module_functions[175].return_type_info = NULL;
    _module_functions[175].body = NULL;
    _module_functions[175].shadow_test = NULL;
    _module_functions[175].is_extern = true;
    _module_functions[175].returns_gc_managed = false;
    _module_functions[175].requires_manual_free = false;
    _module_functions[175].returns_borrowed = false;
    _module_functions[175].cleanup_function = NULL;
    _module_functions[175].params = &_module_params[112];
    _module_params[112].name = "list";
    _module_params[112].type = 15;
    _module_params[112].struct_type_name = "ASTFunction";
    _module_params[112].element_type = 21;
    _module_params[112].fn_sig = NULL;
    _module_params[113].name = "index";
    _module_params[113].type = 0;
    _module_params[113].struct_type_name = NULL;
    _module_params[113].element_type = 21;
    _module_params[113].fn_sig = NULL;

    /* Function: List_ASTFunction_length */
    _module_functions[176].name = "List_ASTFunction_length";
    _module_functions[176].param_count = 1;
    _module_functions[176].return_type = 0;
    _module_functions[176].return_struct_type_name = NULL;
    _module_functions[176].return_fn_sig = NULL;
    _module_functions[176].return_type_info = NULL;
    _module_functions[176].body = NULL;
    _module_functions[176].shadow_test = NULL;
    _module_functions[176].is_extern = true;
    _module_functions[176].returns_gc_managed = false;
    _module_functions[176].requires_manual_free = false;
    _module_functions[176].returns_borrowed = false;
    _module_functions[176].cleanup_function = NULL;
    _module_functions[176].params = &_module_params[114];
    _module_params[114].name = "list";
    _module_params[114].type = 15;
    _module_params[114].struct_type_name = "ASTFunction";
    _module_params[114].element_type = 21;
    _module_params[114].fn_sig = NULL;

    /* Function: List_ASTShadow_new */
    _module_functions[177].name = "List_ASTShadow_new";
    _module_functions[177].param_count = 0;
    _module_functions[177].return_type = 15;
    _module_functions[177].return_struct_type_name = "ASTShadow";
    _module_functions[177].return_fn_sig = NULL;
    _module_functions[177].return_type_info = NULL;
    _module_functions[177].body = NULL;
    _module_functions[177].shadow_test = NULL;
    _module_functions[177].is_extern = true;
    _module_functions[177].returns_gc_managed = false;
    _module_functions[177].requires_manual_free = false;
    _module_functions[177].returns_borrowed = false;
    _module_functions[177].cleanup_function = NULL;
    _module_functions[177].params = NULL;

    /* Function: List_ASTShadow_push */
    _module_functions[178].name = "List_ASTShadow_push";
    _module_functions[178].param_count = 2;
    _module_functions[178].return_type = 6;
    _module_functions[178].return_struct_type_name = NULL;
    _module_functions[178].return_fn_sig = NULL;
    _module_functions[178].return_type_info = NULL;
    _module_functions[178].body = NULL;
    _module_functions[178].shadow_test = NULL;
    _module_functions[178].is_extern = true;
    _module_functions[178].returns_gc_managed = false;
    _module_functions[178].requires_manual_free = false;
    _module_functions[178].returns_borrowed = false;
    _module_functions[178].cleanup_function = NULL;
    _module_functions[178].params = &_module_params[115];
    _module_params[115].name = "list";
    _module_params[115].type = 15;
    _module_params[115].struct_type_name = "ASTShadow";
    _module_params[115].element_type = 21;
    _module_params[115].fn_sig = NULL;
    _module_params[116].name = "value";
    _module_params[116].type = 8;
    _module_params[116].struct_type_name = "ASTShadow";
    _module_params[116].element_type = 21;
    _module_params[116].fn_sig = NULL;

    /* Function: List_ASTShadow_get */
    _module_functions[179].name = "List_ASTShadow_get";
    _module_functions[179].param_count = 2;
    _module_functions[179].return_type = 8;
    _module_functions[179].return_struct_type_name = "ASTShadow";
    _module_functions[179].return_fn_sig = NULL;
    _module_functions[179].return_type_info = NULL;
    _module_functions[179].body = NULL;
    _module_functions[179].shadow_test = NULL;
    _module_functions[179].is_extern = true;
    _module_functions[179].returns_gc_managed = false;
    _module_functions[179].requires_manual_free = false;
    _module_functions[179].returns_borrowed = false;
    _module_functions[179].cleanup_function = NULL;
    _module_functions[179].params = &_module_params[117];
    _module_params[117].name = "list";
    _module_params[117].type = 15;
    _module_params[117].struct_type_name = "ASTShadow";
    _module_params[117].element_type = 21;
    _module_params[117].fn_sig = NULL;
    _module_params[118].name = "index";
    _module_params[118].type = 0;
    _module_params[118].struct_type_name = NULL;
    _module_params[118].element_type = 21;
    _module_params[118].fn_sig = NULL;

    /* Function: List_ASTShadow_length */
    _module_functions[180].name = "List_ASTShadow_length";
    _module_functions[180].param_count = 1;
    _module_functions[180].return_type = 0;
    _module_functions[180].return_struct_type_name = NULL;
    _module_functions[180].return_fn_sig = NULL;
    _module_functions[180].return_type_info = NULL;
    _module_functions[180].body = NULL;
    _module_functions[180].shadow_test = NULL;
    _module_functions[180].is_extern = true;
    _module_functions[180].returns_gc_managed = false;
    _module_functions[180].requires_manual_free = false;
    _module_functions[180].returns_borrowed = false;
    _module_functions[180].cleanup_function = NULL;
    _module_functions[180].params = &_module_params[119];
    _module_params[119].name = "list";
    _module_params[119].type = 15;
    _module_params[119].struct_type_name = "ASTShadow";
    _module_params[119].element_type = 21;
    _module_params[119].fn_sig = NULL;

    /* Function: List_ASTStruct_new */
    _module_functions[181].name = "List_ASTStruct_new";
    _module_functions[181].param_count = 0;
    _module_functions[181].return_type = 15;
    _module_functions[181].return_struct_type_name = "ASTStruct";
    _module_functions[181].return_fn_sig = NULL;
    _module_functions[181].return_type_info = NULL;
    _module_functions[181].body = NULL;
    _module_functions[181].shadow_test = NULL;
    _module_functions[181].is_extern = true;
    _module_functions[181].returns_gc_managed = false;
    _module_functions[181].requires_manual_free = false;
    _module_functions[181].returns_borrowed = false;
    _module_functions[181].cleanup_function = NULL;
    _module_functions[181].params = NULL;

    /* Function: List_ASTStruct_push */
    _module_functions[182].name = "List_ASTStruct_push";
    _module_functions[182].param_count = 2;
    _module_functions[182].return_type = 6;
    _module_functions[182].return_struct_type_name = NULL;
    _module_functions[182].return_fn_sig = NULL;
    _module_functions[182].return_type_info = NULL;
    _module_functions[182].body = NULL;
    _module_functions[182].shadow_test = NULL;
    _module_functions[182].is_extern = true;
    _module_functions[182].returns_gc_managed = false;
    _module_functions[182].requires_manual_free = false;
    _module_functions[182].returns_borrowed = false;
    _module_functions[182].cleanup_function = NULL;
    _module_functions[182].params = &_module_params[120];
    _module_params[120].name = "list";
    _module_params[120].type = 15;
    _module_params[120].struct_type_name = "ASTStruct";
    _module_params[120].element_type = 21;
    _module_params[120].fn_sig = NULL;
    _module_params[121].name = "value";
    _module_params[121].type = 8;
    _module_params[121].struct_type_name = "ASTStruct";
    _module_params[121].element_type = 21;
    _module_params[121].fn_sig = NULL;

    /* Function: List_ASTStruct_get */
    _module_functions[183].name = "List_ASTStruct_get";
    _module_functions[183].param_count = 2;
    _module_functions[183].return_type = 8;
    _module_functions[183].return_struct_type_name = "ASTStruct";
    _module_functions[183].return_fn_sig = NULL;
    _module_functions[183].return_type_info = NULL;
    _module_functions[183].body = NULL;
    _module_functions[183].shadow_test = NULL;
    _module_functions[183].is_extern = true;
    _module_functions[183].returns_gc_managed = false;
    _module_functions[183].requires_manual_free = false;
    _module_functions[183].returns_borrowed = false;
    _module_functions[183].cleanup_function = NULL;
    _module_functions[183].params = &_module_params[122];
    _module_params[122].name = "list";
    _module_params[122].type = 15;
    _module_params[122].struct_type_name = "ASTStruct";
    _module_params[122].element_type = 21;
    _module_params[122].fn_sig = NULL;
    _module_params[123].name = "index";
    _module_params[123].type = 0;
    _module_params[123].struct_type_name = NULL;
    _module_params[123].element_type = 21;
    _module_params[123].fn_sig = NULL;

    /* Function: List_ASTStruct_length */
    _module_functions[184].name = "List_ASTStruct_length";
    _module_functions[184].param_count = 1;
    _module_functions[184].return_type = 0;
    _module_functions[184].return_struct_type_name = NULL;
    _module_functions[184].return_fn_sig = NULL;
    _module_functions[184].return_type_info = NULL;
    _module_functions[184].body = NULL;
    _module_functions[184].shadow_test = NULL;
    _module_functions[184].is_extern = true;
    _module_functions[184].returns_gc_managed = false;
    _module_functions[184].requires_manual_free = false;
    _module_functions[184].returns_borrowed = false;
    _module_functions[184].cleanup_function = NULL;
    _module_functions[184].params = &_module_params[124];
    _module_params[124].name = "list";
    _module_params[124].type = 15;
    _module_params[124].struct_type_name = "ASTStruct";
    _module_params[124].element_type = 21;
    _module_params[124].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_new */
    _module_functions[185].name = "List_ASTStructLiteral_new";
    _module_functions[185].param_count = 0;
    _module_functions[185].return_type = 15;
    _module_functions[185].return_struct_type_name = "ASTStructLiteral";
    _module_functions[185].return_fn_sig = NULL;
    _module_functions[185].return_type_info = NULL;
    _module_functions[185].body = NULL;
    _module_functions[185].shadow_test = NULL;
    _module_functions[185].is_extern = true;
    _module_functions[185].returns_gc_managed = false;
    _module_functions[185].requires_manual_free = false;
    _module_functions[185].returns_borrowed = false;
    _module_functions[185].cleanup_function = NULL;
    _module_functions[185].params = NULL;

    /* Function: List_ASTStructLiteral_push */
    _module_functions[186].name = "List_ASTStructLiteral_push";
    _module_functions[186].param_count = 2;
    _module_functions[186].return_type = 6;
    _module_functions[186].return_struct_type_name = NULL;
    _module_functions[186].return_fn_sig = NULL;
    _module_functions[186].return_type_info = NULL;
    _module_functions[186].body = NULL;
    _module_functions[186].shadow_test = NULL;
    _module_functions[186].is_extern = true;
    _module_functions[186].returns_gc_managed = false;
    _module_functions[186].requires_manual_free = false;
    _module_functions[186].returns_borrowed = false;
    _module_functions[186].cleanup_function = NULL;
    _module_functions[186].params = &_module_params[125];
    _module_params[125].name = "list";
    _module_params[125].type = 15;
    _module_params[125].struct_type_name = "ASTStructLiteral";
    _module_params[125].element_type = 21;
    _module_params[125].fn_sig = NULL;
    _module_params[126].name = "value";
    _module_params[126].type = 8;
    _module_params[126].struct_type_name = "ASTStructLiteral";
    _module_params[126].element_type = 21;
    _module_params[126].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_get */
    _module_functions[187].name = "List_ASTStructLiteral_get";
    _module_functions[187].param_count = 2;
    _module_functions[187].return_type = 8;
    _module_functions[187].return_struct_type_name = "ASTStructLiteral";
    _module_functions[187].return_fn_sig = NULL;
    _module_functions[187].return_type_info = NULL;
    _module_functions[187].body = NULL;
    _module_functions[187].shadow_test = NULL;
    _module_functions[187].is_extern = true;
    _module_functions[187].returns_gc_managed = false;
    _module_functions[187].requires_manual_free = false;
    _module_functions[187].returns_borrowed = false;
    _module_functions[187].cleanup_function = NULL;
    _module_functions[187].params = &_module_params[127];
    _module_params[127].name = "list";
    _module_params[127].type = 15;
    _module_params[127].struct_type_name = "ASTStructLiteral";
    _module_params[127].element_type = 21;
    _module_params[127].fn_sig = NULL;
    _module_params[128].name = "index";
    _module_params[128].type = 0;
    _module_params[128].struct_type_name = NULL;
    _module_params[128].element_type = 21;
    _module_params[128].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_length */
    _module_functions[188].name = "List_ASTStructLiteral_length";
    _module_functions[188].param_count = 1;
    _module_functions[188].return_type = 0;
    _module_functions[188].return_struct_type_name = NULL;
    _module_functions[188].return_fn_sig = NULL;
    _module_functions[188].return_type_info = NULL;
    _module_functions[188].body = NULL;
    _module_functions[188].shadow_test = NULL;
    _module_functions[188].is_extern = true;
    _module_functions[188].returns_gc_managed = false;
    _module_functions[188].requires_manual_free = false;
    _module_functions[188].returns_borrowed = false;
    _module_functions[188].cleanup_function = NULL;
    _module_functions[188].params = &_module_params[129];
    _module_params[129].name = "list";
    _module_params[129].type = 15;
    _module_params[129].struct_type_name = "ASTStructLiteral";
    _module_params[129].element_type = 21;
    _module_params[129].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_new */
    _module_functions[189].name = "List_ASTFieldAccess_new";
    _module_functions[189].param_count = 0;
    _module_functions[189].return_type = 15;
    _module_functions[189].return_struct_type_name = "ASTFieldAccess";
    _module_functions[189].return_fn_sig = NULL;
    _module_functions[189].return_type_info = NULL;
    _module_functions[189].body = NULL;
    _module_functions[189].shadow_test = NULL;
    _module_functions[189].is_extern = true;
    _module_functions[189].returns_gc_managed = false;
    _module_functions[189].requires_manual_free = false;
    _module_functions[189].returns_borrowed = false;
    _module_functions[189].cleanup_function = NULL;
    _module_functions[189].params = NULL;

    /* Function: List_ASTFieldAccess_push */
    _module_functions[190].name = "List_ASTFieldAccess_push";
    _module_functions[190].param_count = 2;
    _module_functions[190].return_type = 6;
    _module_functions[190].return_struct_type_name = NULL;
    _module_functions[190].return_fn_sig = NULL;
    _module_functions[190].return_type_info = NULL;
    _module_functions[190].body = NULL;
    _module_functions[190].shadow_test = NULL;
    _module_functions[190].is_extern = true;
    _module_functions[190].returns_gc_managed = false;
    _module_functions[190].requires_manual_free = false;
    _module_functions[190].returns_borrowed = false;
    _module_functions[190].cleanup_function = NULL;
    _module_functions[190].params = &_module_params[130];
    _module_params[130].name = "list";
    _module_params[130].type = 15;
    _module_params[130].struct_type_name = "ASTFieldAccess";
    _module_params[130].element_type = 21;
    _module_params[130].fn_sig = NULL;
    _module_params[131].name = "value";
    _module_params[131].type = 8;
    _module_params[131].struct_type_name = "ASTFieldAccess";
    _module_params[131].element_type = 21;
    _module_params[131].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_get */
    _module_functions[191].name = "List_ASTFieldAccess_get";
    _module_functions[191].param_count = 2;
    _module_functions[191].return_type = 8;
    _module_functions[191].return_struct_type_name = "ASTFieldAccess";
    _module_functions[191].return_fn_sig = NULL;
    _module_functions[191].return_type_info = NULL;
    _module_functions[191].body = NULL;
    _module_functions[191].shadow_test = NULL;
    _module_functions[191].is_extern = true;
    _module_functions[191].returns_gc_managed = false;
    _module_functions[191].requires_manual_free = false;
    _module_functions[191].returns_borrowed = false;
    _module_functions[191].cleanup_function = NULL;
    _module_functions[191].params = &_module_params[132];
    _module_params[132].name = "list";
    _module_params[132].type = 15;
    _module_params[132].struct_type_name = "ASTFieldAccess";
    _module_params[132].element_type = 21;
    _module_params[132].fn_sig = NULL;
    _module_params[133].name = "index";
    _module_params[133].type = 0;
    _module_params[133].struct_type_name = NULL;
    _module_params[133].element_type = 21;
    _module_params[133].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_length */
    _module_functions[192].name = "List_ASTFieldAccess_length";
    _module_functions[192].param_count = 1;
    _module_functions[192].return_type = 0;
    _module_functions[192].return_struct_type_name = NULL;
    _module_functions[192].return_fn_sig = NULL;
    _module_functions[192].return_type_info = NULL;
    _module_functions[192].body = NULL;
    _module_functions[192].shadow_test = NULL;
    _module_functions[192].is_extern = true;
    _module_functions[192].returns_gc_managed = false;
    _module_functions[192].requires_manual_free = false;
    _module_functions[192].returns_borrowed = false;
    _module_functions[192].cleanup_function = NULL;
    _module_functions[192].params = &_module_params[134];
    _module_params[134].name = "list";
    _module_params[134].type = 15;
    _module_params[134].struct_type_name = "ASTFieldAccess";
    _module_params[134].element_type = 21;
    _module_params[134].fn_sig = NULL;

    /* Function: List_ASTEnum_new */
    _module_functions[193].name = "List_ASTEnum_new";
    _module_functions[193].param_count = 0;
    _module_functions[193].return_type = 15;
    _module_functions[193].return_struct_type_name = "ASTEnum";
    _module_functions[193].return_fn_sig = NULL;
    _module_functions[193].return_type_info = NULL;
    _module_functions[193].body = NULL;
    _module_functions[193].shadow_test = NULL;
    _module_functions[193].is_extern = true;
    _module_functions[193].returns_gc_managed = false;
    _module_functions[193].requires_manual_free = false;
    _module_functions[193].returns_borrowed = false;
    _module_functions[193].cleanup_function = NULL;
    _module_functions[193].params = NULL;

    /* Function: List_ASTEnum_push */
    _module_functions[194].name = "List_ASTEnum_push";
    _module_functions[194].param_count = 2;
    _module_functions[194].return_type = 6;
    _module_functions[194].return_struct_type_name = NULL;
    _module_functions[194].return_fn_sig = NULL;
    _module_functions[194].return_type_info = NULL;
    _module_functions[194].body = NULL;
    _module_functions[194].shadow_test = NULL;
    _module_functions[194].is_extern = true;
    _module_functions[194].returns_gc_managed = false;
    _module_functions[194].requires_manual_free = false;
    _module_functions[194].returns_borrowed = false;
    _module_functions[194].cleanup_function = NULL;
    _module_functions[194].params = &_module_params[135];
    _module_params[135].name = "list";
    _module_params[135].type = 15;
    _module_params[135].struct_type_name = "ASTEnum";
    _module_params[135].element_type = 21;
    _module_params[135].fn_sig = NULL;
    _module_params[136].name = "value";
    _module_params[136].type = 8;
    _module_params[136].struct_type_name = "ASTEnum";
    _module_params[136].element_type = 21;
    _module_params[136].fn_sig = NULL;

    /* Function: List_ASTEnum_get */
    _module_functions[195].name = "List_ASTEnum_get";
    _module_functions[195].param_count = 2;
    _module_functions[195].return_type = 8;
    _module_functions[195].return_struct_type_name = "ASTEnum";
    _module_functions[195].return_fn_sig = NULL;
    _module_functions[195].return_type_info = NULL;
    _module_functions[195].body = NULL;
    _module_functions[195].shadow_test = NULL;
    _module_functions[195].is_extern = true;
    _module_functions[195].returns_gc_managed = false;
    _module_functions[195].requires_manual_free = false;
    _module_functions[195].returns_borrowed = false;
    _module_functions[195].cleanup_function = NULL;
    _module_functions[195].params = &_module_params[137];
    _module_params[137].name = "list";
    _module_params[137].type = 15;
    _module_params[137].struct_type_name = "ASTEnum";
    _module_params[137].element_type = 21;
    _module_params[137].fn_sig = NULL;
    _module_params[138].name = "index";
    _module_params[138].type = 0;
    _module_params[138].struct_type_name = NULL;
    _module_params[138].element_type = 21;
    _module_params[138].fn_sig = NULL;

    /* Function: List_ASTEnum_length */
    _module_functions[196].name = "List_ASTEnum_length";
    _module_functions[196].param_count = 1;
    _module_functions[196].return_type = 0;
    _module_functions[196].return_struct_type_name = NULL;
    _module_functions[196].return_fn_sig = NULL;
    _module_functions[196].return_type_info = NULL;
    _module_functions[196].body = NULL;
    _module_functions[196].shadow_test = NULL;
    _module_functions[196].is_extern = true;
    _module_functions[196].returns_gc_managed = false;
    _module_functions[196].requires_manual_free = false;
    _module_functions[196].returns_borrowed = false;
    _module_functions[196].cleanup_function = NULL;
    _module_functions[196].params = &_module_params[139];
    _module_params[139].name = "list";
    _module_params[139].type = 15;
    _module_params[139].struct_type_name = "ASTEnum";
    _module_params[139].element_type = 21;
    _module_params[139].fn_sig = NULL;

    /* Function: List_ASTUnion_new */
    _module_functions[197].name = "List_ASTUnion_new";
    _module_functions[197].param_count = 0;
    _module_functions[197].return_type = 15;
    _module_functions[197].return_struct_type_name = "ASTUnion";
    _module_functions[197].return_fn_sig = NULL;
    _module_functions[197].return_type_info = NULL;
    _module_functions[197].body = NULL;
    _module_functions[197].shadow_test = NULL;
    _module_functions[197].is_extern = true;
    _module_functions[197].returns_gc_managed = false;
    _module_functions[197].requires_manual_free = false;
    _module_functions[197].returns_borrowed = false;
    _module_functions[197].cleanup_function = NULL;
    _module_functions[197].params = NULL;

    /* Function: List_ASTUnion_push */
    _module_functions[198].name = "List_ASTUnion_push";
    _module_functions[198].param_count = 2;
    _module_functions[198].return_type = 6;
    _module_functions[198].return_struct_type_name = NULL;
    _module_functions[198].return_fn_sig = NULL;
    _module_functions[198].return_type_info = NULL;
    _module_functions[198].body = NULL;
    _module_functions[198].shadow_test = NULL;
    _module_functions[198].is_extern = true;
    _module_functions[198].returns_gc_managed = false;
    _module_functions[198].requires_manual_free = false;
    _module_functions[198].returns_borrowed = false;
    _module_functions[198].cleanup_function = NULL;
    _module_functions[198].params = &_module_params[140];
    _module_params[140].name = "list";
    _module_params[140].type = 15;
    _module_params[140].struct_type_name = "ASTUnion";
    _module_params[140].element_type = 21;
    _module_params[140].fn_sig = NULL;
    _module_params[141].name = "value";
    _module_params[141].type = 8;
    _module_params[141].struct_type_name = "ASTUnion";
    _module_params[141].element_type = 21;
    _module_params[141].fn_sig = NULL;

    /* Function: List_ASTUnion_get */
    _module_functions[199].name = "List_ASTUnion_get";
    _module_functions[199].param_count = 2;
    _module_functions[199].return_type = 8;
    _module_functions[199].return_struct_type_name = "ASTUnion";
    _module_functions[199].return_fn_sig = NULL;
    _module_functions[199].return_type_info = NULL;
    _module_functions[199].body = NULL;
    _module_functions[199].shadow_test = NULL;
    _module_functions[199].is_extern = true;
    _module_functions[199].returns_gc_managed = false;
    _module_functions[199].requires_manual_free = false;
    _module_functions[199].returns_borrowed = false;
    _module_functions[199].cleanup_function = NULL;
    _module_functions[199].params = &_module_params[142];
    _module_params[142].name = "list";
    _module_params[142].type = 15;
    _module_params[142].struct_type_name = "ASTUnion";
    _module_params[142].element_type = 21;
    _module_params[142].fn_sig = NULL;
    _module_params[143].name = "index";
    _module_params[143].type = 0;
    _module_params[143].struct_type_name = NULL;
    _module_params[143].element_type = 21;
    _module_params[143].fn_sig = NULL;

    /* Function: List_ASTUnion_length */
    _module_functions[200].name = "List_ASTUnion_length";
    _module_functions[200].param_count = 1;
    _module_functions[200].return_type = 0;
    _module_functions[200].return_struct_type_name = NULL;
    _module_functions[200].return_fn_sig = NULL;
    _module_functions[200].return_type_info = NULL;
    _module_functions[200].body = NULL;
    _module_functions[200].shadow_test = NULL;
    _module_functions[200].is_extern = true;
    _module_functions[200].returns_gc_managed = false;
    _module_functions[200].requires_manual_free = false;
    _module_functions[200].returns_borrowed = false;
    _module_functions[200].cleanup_function = NULL;
    _module_functions[200].params = &_module_params[144];
    _module_params[144].name = "list";
    _module_params[144].type = 15;
    _module_params[144].struct_type_name = "ASTUnion";
    _module_params[144].element_type = 21;
    _module_params[144].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_new */
    _module_functions[201].name = "List_ASTUnionConstruct_new";
    _module_functions[201].param_count = 0;
    _module_functions[201].return_type = 15;
    _module_functions[201].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[201].return_fn_sig = NULL;
    _module_functions[201].return_type_info = NULL;
    _module_functions[201].body = NULL;
    _module_functions[201].shadow_test = NULL;
    _module_functions[201].is_extern = true;
    _module_functions[201].returns_gc_managed = false;
    _module_functions[201].requires_manual_free = false;
    _module_functions[201].returns_borrowed = false;
    _module_functions[201].cleanup_function = NULL;
    _module_functions[201].params = NULL;

    /* Function: List_ASTUnionConstruct_push */
    _module_functions[202].name = "List_ASTUnionConstruct_push";
    _module_functions[202].param_count = 2;
    _module_functions[202].return_type = 6;
    _module_functions[202].return_struct_type_name = NULL;
    _module_functions[202].return_fn_sig = NULL;
    _module_functions[202].return_type_info = NULL;
    _module_functions[202].body = NULL;
    _module_functions[202].shadow_test = NULL;
    _module_functions[202].is_extern = true;
    _module_functions[202].returns_gc_managed = false;
    _module_functions[202].requires_manual_free = false;
    _module_functions[202].returns_borrowed = false;
    _module_functions[202].cleanup_function = NULL;
    _module_functions[202].params = &_module_params[145];
    _module_params[145].name = "list";
    _module_params[145].type = 15;
    _module_params[145].struct_type_name = "ASTUnionConstruct";
    _module_params[145].element_type = 21;
    _module_params[145].fn_sig = NULL;
    _module_params[146].name = "value";
    _module_params[146].type = 8;
    _module_params[146].struct_type_name = "ASTUnionConstruct";
    _module_params[146].element_type = 21;
    _module_params[146].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_get */
    _module_functions[203].name = "List_ASTUnionConstruct_get";
    _module_functions[203].param_count = 2;
    _module_functions[203].return_type = 8;
    _module_functions[203].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[203].return_fn_sig = NULL;
    _module_functions[203].return_type_info = NULL;
    _module_functions[203].body = NULL;
    _module_functions[203].shadow_test = NULL;
    _module_functions[203].is_extern = true;
    _module_functions[203].returns_gc_managed = false;
    _module_functions[203].requires_manual_free = false;
    _module_functions[203].returns_borrowed = false;
    _module_functions[203].cleanup_function = NULL;
    _module_functions[203].params = &_module_params[147];
    _module_params[147].name = "list";
    _module_params[147].type = 15;
    _module_params[147].struct_type_name = "ASTUnionConstruct";
    _module_params[147].element_type = 21;
    _module_params[147].fn_sig = NULL;
    _module_params[148].name = "index";
    _module_params[148].type = 0;
    _module_params[148].struct_type_name = NULL;
    _module_params[148].element_type = 21;
    _module_params[148].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_length */
    _module_functions[204].name = "List_ASTUnionConstruct_length";
    _module_functions[204].param_count = 1;
    _module_functions[204].return_type = 0;
    _module_functions[204].return_struct_type_name = NULL;
    _module_functions[204].return_fn_sig = NULL;
    _module_functions[204].return_type_info = NULL;
    _module_functions[204].body = NULL;
    _module_functions[204].shadow_test = NULL;
    _module_functions[204].is_extern = true;
    _module_functions[204].returns_gc_managed = false;
    _module_functions[204].requires_manual_free = false;
    _module_functions[204].returns_borrowed = false;
    _module_functions[204].cleanup_function = NULL;
    _module_functions[204].params = &_module_params[149];
    _module_params[149].name = "list";
    _module_params[149].type = 15;
    _module_params[149].struct_type_name = "ASTUnionConstruct";
    _module_params[149].element_type = 21;
    _module_params[149].fn_sig = NULL;

    /* Function: List_ASTMatch_new */
    _module_functions[205].name = "List_ASTMatch_new";
    _module_functions[205].param_count = 0;
    _module_functions[205].return_type = 15;
    _module_functions[205].return_struct_type_name = "ASTMatch";
    _module_functions[205].return_fn_sig = NULL;
    _module_functions[205].return_type_info = NULL;
    _module_functions[205].body = NULL;
    _module_functions[205].shadow_test = NULL;
    _module_functions[205].is_extern = true;
    _module_functions[205].returns_gc_managed = false;
    _module_functions[205].requires_manual_free = false;
    _module_functions[205].returns_borrowed = false;
    _module_functions[205].cleanup_function = NULL;
    _module_functions[205].params = NULL;

    /* Function: List_ASTMatch_push */
    _module_functions[206].name = "List_ASTMatch_push";
    _module_functions[206].param_count = 2;
    _module_functions[206].return_type = 6;
    _module_functions[206].return_struct_type_name = NULL;
    _module_functions[206].return_fn_sig = NULL;
    _module_functions[206].return_type_info = NULL;
    _module_functions[206].body = NULL;
    _module_functions[206].shadow_test = NULL;
    _module_functions[206].is_extern = true;
    _module_functions[206].returns_gc_managed = false;
    _module_functions[206].requires_manual_free = false;
    _module_functions[206].returns_borrowed = false;
    _module_functions[206].cleanup_function = NULL;
    _module_functions[206].params = &_module_params[150];
    _module_params[150].name = "list";
    _module_params[150].type = 15;
    _module_params[150].struct_type_name = "ASTMatch";
    _module_params[150].element_type = 21;
    _module_params[150].fn_sig = NULL;
    _module_params[151].name = "value";
    _module_params[151].type = 8;
    _module_params[151].struct_type_name = "ASTMatch";
    _module_params[151].element_type = 21;
    _module_params[151].fn_sig = NULL;

    /* Function: List_ASTMatch_get */
    _module_functions[207].name = "List_ASTMatch_get";
    _module_functions[207].param_count = 2;
    _module_functions[207].return_type = 8;
    _module_functions[207].return_struct_type_name = "ASTMatch";
    _module_functions[207].return_fn_sig = NULL;
    _module_functions[207].return_type_info = NULL;
    _module_functions[207].body = NULL;
    _module_functions[207].shadow_test = NULL;
    _module_functions[207].is_extern = true;
    _module_functions[207].returns_gc_managed = false;
    _module_functions[207].requires_manual_free = false;
    _module_functions[207].returns_borrowed = false;
    _module_functions[207].cleanup_function = NULL;
    _module_functions[207].params = &_module_params[152];
    _module_params[152].name = "list";
    _module_params[152].type = 15;
    _module_params[152].struct_type_name = "ASTMatch";
    _module_params[152].element_type = 21;
    _module_params[152].fn_sig = NULL;
    _module_params[153].name = "index";
    _module_params[153].type = 0;
    _module_params[153].struct_type_name = NULL;
    _module_params[153].element_type = 21;
    _module_params[153].fn_sig = NULL;

    /* Function: List_ASTMatch_length */
    _module_functions[208].name = "List_ASTMatch_length";
    _module_functions[208].param_count = 1;
    _module_functions[208].return_type = 0;
    _module_functions[208].return_struct_type_name = NULL;
    _module_functions[208].return_fn_sig = NULL;
    _module_functions[208].return_type_info = NULL;
    _module_functions[208].body = NULL;
    _module_functions[208].shadow_test = NULL;
    _module_functions[208].is_extern = true;
    _module_functions[208].returns_gc_managed = false;
    _module_functions[208].requires_manual_free = false;
    _module_functions[208].returns_borrowed = false;
    _module_functions[208].cleanup_function = NULL;
    _module_functions[208].params = &_module_params[154];
    _module_params[154].name = "list";
    _module_params[154].type = 15;
    _module_params[154].struct_type_name = "ASTMatch";
    _module_params[154].element_type = 21;
    _module_params[154].fn_sig = NULL;

    /* Function: List_ASTImport_new */
    _module_functions[209].name = "List_ASTImport_new";
    _module_functions[209].param_count = 0;
    _module_functions[209].return_type = 15;
    _module_functions[209].return_struct_type_name = "ASTImport";
    _module_functions[209].return_fn_sig = NULL;
    _module_functions[209].return_type_info = NULL;
    _module_functions[209].body = NULL;
    _module_functions[209].shadow_test = NULL;
    _module_functions[209].is_extern = true;
    _module_functions[209].returns_gc_managed = false;
    _module_functions[209].requires_manual_free = false;
    _module_functions[209].returns_borrowed = false;
    _module_functions[209].cleanup_function = NULL;
    _module_functions[209].params = NULL;

    /* Function: List_ASTImport_push */
    _module_functions[210].name = "List_ASTImport_push";
    _module_functions[210].param_count = 2;
    _module_functions[210].return_type = 6;
    _module_functions[210].return_struct_type_name = NULL;
    _module_functions[210].return_fn_sig = NULL;
    _module_functions[210].return_type_info = NULL;
    _module_functions[210].body = NULL;
    _module_functions[210].shadow_test = NULL;
    _module_functions[210].is_extern = true;
    _module_functions[210].returns_gc_managed = false;
    _module_functions[210].requires_manual_free = false;
    _module_functions[210].returns_borrowed = false;
    _module_functions[210].cleanup_function = NULL;
    _module_functions[210].params = &_module_params[155];
    _module_params[155].name = "list";
    _module_params[155].type = 15;
    _module_params[155].struct_type_name = "ASTImport";
    _module_params[155].element_type = 21;
    _module_params[155].fn_sig = NULL;
    _module_params[156].name = "value";
    _module_params[156].type = 8;
    _module_params[156].struct_type_name = "ASTImport";
    _module_params[156].element_type = 21;
    _module_params[156].fn_sig = NULL;

    /* Function: List_ASTImport_get */
    _module_functions[211].name = "List_ASTImport_get";
    _module_functions[211].param_count = 2;
    _module_functions[211].return_type = 8;
    _module_functions[211].return_struct_type_name = "ASTImport";
    _module_functions[211].return_fn_sig = NULL;
    _module_functions[211].return_type_info = NULL;
    _module_functions[211].body = NULL;
    _module_functions[211].shadow_test = NULL;
    _module_functions[211].is_extern = true;
    _module_functions[211].returns_gc_managed = false;
    _module_functions[211].requires_manual_free = false;
    _module_functions[211].returns_borrowed = false;
    _module_functions[211].cleanup_function = NULL;
    _module_functions[211].params = &_module_params[157];
    _module_params[157].name = "list";
    _module_params[157].type = 15;
    _module_params[157].struct_type_name = "ASTImport";
    _module_params[157].element_type = 21;
    _module_params[157].fn_sig = NULL;
    _module_params[158].name = "index";
    _module_params[158].type = 0;
    _module_params[158].struct_type_name = NULL;
    _module_params[158].element_type = 21;
    _module_params[158].fn_sig = NULL;

    /* Function: List_ASTImport_length */
    _module_functions[212].name = "List_ASTImport_length";
    _module_functions[212].param_count = 1;
    _module_functions[212].return_type = 0;
    _module_functions[212].return_struct_type_name = NULL;
    _module_functions[212].return_fn_sig = NULL;
    _module_functions[212].return_type_info = NULL;
    _module_functions[212].body = NULL;
    _module_functions[212].shadow_test = NULL;
    _module_functions[212].is_extern = true;
    _module_functions[212].returns_gc_managed = false;
    _module_functions[212].requires_manual_free = false;
    _module_functions[212].returns_borrowed = false;
    _module_functions[212].cleanup_function = NULL;
    _module_functions[212].params = &_module_params[159];
    _module_params[159].name = "list";
    _module_params[159].type = 15;
    _module_params[159].struct_type_name = "ASTImport";
    _module_params[159].element_type = 21;
    _module_params[159].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_new */
    _module_functions[213].name = "List_ASTOpaqueType_new";
    _module_functions[213].param_count = 0;
    _module_functions[213].return_type = 15;
    _module_functions[213].return_struct_type_name = "ASTOpaqueType";
    _module_functions[213].return_fn_sig = NULL;
    _module_functions[213].return_type_info = NULL;
    _module_functions[213].body = NULL;
    _module_functions[213].shadow_test = NULL;
    _module_functions[213].is_extern = true;
    _module_functions[213].returns_gc_managed = false;
    _module_functions[213].requires_manual_free = false;
    _module_functions[213].returns_borrowed = false;
    _module_functions[213].cleanup_function = NULL;
    _module_functions[213].params = NULL;

    /* Function: List_ASTOpaqueType_push */
    _module_functions[214].name = "List_ASTOpaqueType_push";
    _module_functions[214].param_count = 2;
    _module_functions[214].return_type = 6;
    _module_functions[214].return_struct_type_name = NULL;
    _module_functions[214].return_fn_sig = NULL;
    _module_functions[214].return_type_info = NULL;
    _module_functions[214].body = NULL;
    _module_functions[214].shadow_test = NULL;
    _module_functions[214].is_extern = true;
    _module_functions[214].returns_gc_managed = false;
    _module_functions[214].requires_manual_free = false;
    _module_functions[214].returns_borrowed = false;
    _module_functions[214].cleanup_function = NULL;
    _module_functions[214].params = &_module_params[160];
    _module_params[160].name = "list";
    _module_params[160].type = 15;
    _module_params[160].struct_type_name = "ASTOpaqueType";
    _module_params[160].element_type = 21;
    _module_params[160].fn_sig = NULL;
    _module_params[161].name = "value";
    _module_params[161].type = 8;
    _module_params[161].struct_type_name = "ASTOpaqueType";
    _module_params[161].element_type = 21;
    _module_params[161].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_get */
    _module_functions[215].name = "List_ASTOpaqueType_get";
    _module_functions[215].param_count = 2;
    _module_functions[215].return_type = 8;
    _module_functions[215].return_struct_type_name = "ASTOpaqueType";
    _module_functions[215].return_fn_sig = NULL;
    _module_functions[215].return_type_info = NULL;
    _module_functions[215].body = NULL;
    _module_functions[215].shadow_test = NULL;
    _module_functions[215].is_extern = true;
    _module_functions[215].returns_gc_managed = false;
    _module_functions[215].requires_manual_free = false;
    _module_functions[215].returns_borrowed = false;
    _module_functions[215].cleanup_function = NULL;
    _module_functions[215].params = &_module_params[162];
    _module_params[162].name = "list";
    _module_params[162].type = 15;
    _module_params[162].struct_type_name = "ASTOpaqueType";
    _module_params[162].element_type = 21;
    _module_params[162].fn_sig = NULL;
    _module_params[163].name = "index";
    _module_params[163].type = 0;
    _module_params[163].struct_type_name = NULL;
    _module_params[163].element_type = 21;
    _module_params[163].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_length */
    _module_functions[216].name = "List_ASTOpaqueType_length";
    _module_functions[216].param_count = 1;
    _module_functions[216].return_type = 0;
    _module_functions[216].return_struct_type_name = NULL;
    _module_functions[216].return_fn_sig = NULL;
    _module_functions[216].return_type_info = NULL;
    _module_functions[216].body = NULL;
    _module_functions[216].shadow_test = NULL;
    _module_functions[216].is_extern = true;
    _module_functions[216].returns_gc_managed = false;
    _module_functions[216].requires_manual_free = false;
    _module_functions[216].returns_borrowed = false;
    _module_functions[216].cleanup_function = NULL;
    _module_functions[216].params = &_module_params[164];
    _module_params[164].name = "list";
    _module_params[164].type = 15;
    _module_params[164].struct_type_name = "ASTOpaqueType";
    _module_params[164].element_type = 21;
    _module_params[164].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_new */
    _module_functions[217].name = "List_ASTTupleLiteral_new";
    _module_functions[217].param_count = 0;
    _module_functions[217].return_type = 15;
    _module_functions[217].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[217].return_fn_sig = NULL;
    _module_functions[217].return_type_info = NULL;
    _module_functions[217].body = NULL;
    _module_functions[217].shadow_test = NULL;
    _module_functions[217].is_extern = true;
    _module_functions[217].returns_gc_managed = false;
    _module_functions[217].requires_manual_free = false;
    _module_functions[217].returns_borrowed = false;
    _module_functions[217].cleanup_function = NULL;
    _module_functions[217].params = NULL;

    /* Function: List_ASTTupleLiteral_push */
    _module_functions[218].name = "List_ASTTupleLiteral_push";
    _module_functions[218].param_count = 2;
    _module_functions[218].return_type = 6;
    _module_functions[218].return_struct_type_name = NULL;
    _module_functions[218].return_fn_sig = NULL;
    _module_functions[218].return_type_info = NULL;
    _module_functions[218].body = NULL;
    _module_functions[218].shadow_test = NULL;
    _module_functions[218].is_extern = true;
    _module_functions[218].returns_gc_managed = false;
    _module_functions[218].requires_manual_free = false;
    _module_functions[218].returns_borrowed = false;
    _module_functions[218].cleanup_function = NULL;
    _module_functions[218].params = &_module_params[165];
    _module_params[165].name = "list";
    _module_params[165].type = 15;
    _module_params[165].struct_type_name = "ASTTupleLiteral";
    _module_params[165].element_type = 21;
    _module_params[165].fn_sig = NULL;
    _module_params[166].name = "value";
    _module_params[166].type = 8;
    _module_params[166].struct_type_name = "ASTTupleLiteral";
    _module_params[166].element_type = 21;
    _module_params[166].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_get */
    _module_functions[219].name = "List_ASTTupleLiteral_get";
    _module_functions[219].param_count = 2;
    _module_functions[219].return_type = 8;
    _module_functions[219].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[219].return_fn_sig = NULL;
    _module_functions[219].return_type_info = NULL;
    _module_functions[219].body = NULL;
    _module_functions[219].shadow_test = NULL;
    _module_functions[219].is_extern = true;
    _module_functions[219].returns_gc_managed = false;
    _module_functions[219].requires_manual_free = false;
    _module_functions[219].returns_borrowed = false;
    _module_functions[219].cleanup_function = NULL;
    _module_functions[219].params = &_module_params[167];
    _module_params[167].name = "list";
    _module_params[167].type = 15;
    _module_params[167].struct_type_name = "ASTTupleLiteral";
    _module_params[167].element_type = 21;
    _module_params[167].fn_sig = NULL;
    _module_params[168].name = "index";
    _module_params[168].type = 0;
    _module_params[168].struct_type_name = NULL;
    _module_params[168].element_type = 21;
    _module_params[168].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_length */
    _module_functions[220].name = "List_ASTTupleLiteral_length";
    _module_functions[220].param_count = 1;
    _module_functions[220].return_type = 0;
    _module_functions[220].return_struct_type_name = NULL;
    _module_functions[220].return_fn_sig = NULL;
    _module_functions[220].return_type_info = NULL;
    _module_functions[220].body = NULL;
    _module_functions[220].shadow_test = NULL;
    _module_functions[220].is_extern = true;
    _module_functions[220].returns_gc_managed = false;
    _module_functions[220].requires_manual_free = false;
    _module_functions[220].returns_borrowed = false;
    _module_functions[220].cleanup_function = NULL;
    _module_functions[220].params = &_module_params[169];
    _module_params[169].name = "list";
    _module_params[169].type = 15;
    _module_params[169].struct_type_name = "ASTTupleLiteral";
    _module_params[169].element_type = 21;
    _module_params[169].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_new */
    _module_functions[221].name = "List_ASTTupleIndex_new";
    _module_functions[221].param_count = 0;
    _module_functions[221].return_type = 15;
    _module_functions[221].return_struct_type_name = "ASTTupleIndex";
    _module_functions[221].return_fn_sig = NULL;
    _module_functions[221].return_type_info = NULL;
    _module_functions[221].body = NULL;
    _module_functions[221].shadow_test = NULL;
    _module_functions[221].is_extern = true;
    _module_functions[221].returns_gc_managed = false;
    _module_functions[221].requires_manual_free = false;
    _module_functions[221].returns_borrowed = false;
    _module_functions[221].cleanup_function = NULL;
    _module_functions[221].params = NULL;

    /* Function: List_ASTTupleIndex_push */
    _module_functions[222].name = "List_ASTTupleIndex_push";
    _module_functions[222].param_count = 2;
    _module_functions[222].return_type = 6;
    _module_functions[222].return_struct_type_name = NULL;
    _module_functions[222].return_fn_sig = NULL;
    _module_functions[222].return_type_info = NULL;
    _module_functions[222].body = NULL;
    _module_functions[222].shadow_test = NULL;
    _module_functions[222].is_extern = true;
    _module_functions[222].returns_gc_managed = false;
    _module_functions[222].requires_manual_free = false;
    _module_functions[222].returns_borrowed = false;
    _module_functions[222].cleanup_function = NULL;
    _module_functions[222].params = &_module_params[170];
    _module_params[170].name = "list";
    _module_params[170].type = 15;
    _module_params[170].struct_type_name = "ASTTupleIndex";
    _module_params[170].element_type = 21;
    _module_params[170].fn_sig = NULL;
    _module_params[171].name = "value";
    _module_params[171].type = 8;
    _module_params[171].struct_type_name = "ASTTupleIndex";
    _module_params[171].element_type = 21;
    _module_params[171].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_get */
    _module_functions[223].name = "List_ASTTupleIndex_get";
    _module_functions[223].param_count = 2;
    _module_functions[223].return_type = 8;
    _module_functions[223].return_struct_type_name = "ASTTupleIndex";
    _module_functions[223].return_fn_sig = NULL;
    _module_functions[223].return_type_info = NULL;
    _module_functions[223].body = NULL;
    _module_functions[223].shadow_test = NULL;
    _module_functions[223].is_extern = true;
    _module_functions[223].returns_gc_managed = false;
    _module_functions[223].requires_manual_free = false;
    _module_functions[223].returns_borrowed = false;
    _module_functions[223].cleanup_function = NULL;
    _module_functions[223].params = &_module_params[172];
    _module_params[172].name = "list";
    _module_params[172].type = 15;
    _module_params[172].struct_type_name = "ASTTupleIndex";
    _module_params[172].element_type = 21;
    _module_params[172].fn_sig = NULL;
    _module_params[173].name = "index";
    _module_params[173].type = 0;
    _module_params[173].struct_type_name = NULL;
    _module_params[173].element_type = 21;
    _module_params[173].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_length */
    _module_functions[224].name = "List_ASTTupleIndex_length";
    _module_functions[224].param_count = 1;
    _module_functions[224].return_type = 0;
    _module_functions[224].return_struct_type_name = NULL;
    _module_functions[224].return_fn_sig = NULL;
    _module_functions[224].return_type_info = NULL;
    _module_functions[224].body = NULL;
    _module_functions[224].shadow_test = NULL;
    _module_functions[224].is_extern = true;
    _module_functions[224].returns_gc_managed = false;
    _module_functions[224].requires_manual_free = false;
    _module_functions[224].returns_borrowed = false;
    _module_functions[224].cleanup_function = NULL;
    _module_functions[224].params = &_module_params[174];
    _module_params[174].name = "list";
    _module_params[174].type = 15;
    _module_params[174].struct_type_name = "ASTTupleIndex";
    _module_params[174].element_type = 21;
    _module_params[174].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_new */
    _module_functions[225].name = "List_ASTServiceDecl_new";
    _module_functions[225].param_count = 0;
    _module_functions[225].return_type = 15;
    _module_functions[225].return_struct_type_name = "ASTServiceDecl";
    _module_functions[225].return_fn_sig = NULL;
    _module_functions[225].return_type_info = NULL;
    _module_functions[225].body = NULL;
    _module_functions[225].shadow_test = NULL;
    _module_functions[225].is_extern = true;
    _module_functions[225].returns_gc_managed = false;
    _module_functions[225].requires_manual_free = false;
    _module_functions[225].returns_borrowed = false;
    _module_functions[225].cleanup_function = NULL;
    _module_functions[225].params = NULL;

    /* Function: List_ASTServiceDecl_push */
    _module_functions[226].name = "List_ASTServiceDecl_push";
    _module_functions[226].param_count = 2;
    _module_functions[226].return_type = 6;
    _module_functions[226].return_struct_type_name = NULL;
    _module_functions[226].return_fn_sig = NULL;
    _module_functions[226].return_type_info = NULL;
    _module_functions[226].body = NULL;
    _module_functions[226].shadow_test = NULL;
    _module_functions[226].is_extern = true;
    _module_functions[226].returns_gc_managed = false;
    _module_functions[226].requires_manual_free = false;
    _module_functions[226].returns_borrowed = false;
    _module_functions[226].cleanup_function = NULL;
    _module_functions[226].params = &_module_params[175];
    _module_params[175].name = "list";
    _module_params[175].type = 15;
    _module_params[175].struct_type_name = "ASTServiceDecl";
    _module_params[175].element_type = 21;
    _module_params[175].fn_sig = NULL;
    _module_params[176].name = "value";
    _module_params[176].type = 8;
    _module_params[176].struct_type_name = "ASTServiceDecl";
    _module_params[176].element_type = 21;
    _module_params[176].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_get */
    _module_functions[227].name = "List_ASTServiceDecl_get";
    _module_functions[227].param_count = 2;
    _module_functions[227].return_type = 8;
    _module_functions[227].return_struct_type_name = "ASTServiceDecl";
    _module_functions[227].return_fn_sig = NULL;
    _module_functions[227].return_type_info = NULL;
    _module_functions[227].body = NULL;
    _module_functions[227].shadow_test = NULL;
    _module_functions[227].is_extern = true;
    _module_functions[227].returns_gc_managed = false;
    _module_functions[227].requires_manual_free = false;
    _module_functions[227].returns_borrowed = false;
    _module_functions[227].cleanup_function = NULL;
    _module_functions[227].params = &_module_params[177];
    _module_params[177].name = "list";
    _module_params[177].type = 15;
    _module_params[177].struct_type_name = "ASTServiceDecl";
    _module_params[177].element_type = 21;
    _module_params[177].fn_sig = NULL;
    _module_params[178].name = "index";
    _module_params[178].type = 0;
    _module_params[178].struct_type_name = NULL;
    _module_params[178].element_type = 21;
    _module_params[178].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_length */
    _module_functions[228].name = "List_ASTServiceDecl_length";
    _module_functions[228].param_count = 1;
    _module_functions[228].return_type = 0;
    _module_functions[228].return_struct_type_name = NULL;
    _module_functions[228].return_fn_sig = NULL;
    _module_functions[228].return_type_info = NULL;
    _module_functions[228].body = NULL;
    _module_functions[228].shadow_test = NULL;
    _module_functions[228].is_extern = true;
    _module_functions[228].returns_gc_managed = false;
    _module_functions[228].requires_manual_free = false;
    _module_functions[228].returns_borrowed = false;
    _module_functions[228].cleanup_function = NULL;
    _module_functions[228].params = &_module_params[179];
    _module_params[179].name = "list";
    _module_params[179].type = 15;
    _module_params[179].struct_type_name = "ASTServiceDecl";
    _module_params[179].element_type = 21;
    _module_params[179].fn_sig = NULL;

    /* Function: token_literal_value_bytes */
    _module_functions[229].name = "token_literal_value_bytes";
    _module_functions[229].param_count = 1;
    _module_functions[229].return_type = 0;
    _module_functions[229].return_struct_type_name = NULL;
    _module_functions[229].return_fn_sig = NULL;
    _module_functions[229].return_type_info = NULL;
    _module_functions[229].body = NULL;
    _module_functions[229].shadow_test = NULL;
    _module_functions[229].is_extern = false;
    _module_functions[229].returns_gc_managed = false;
    _module_functions[229].requires_manual_free = false;
    _module_functions[229].returns_borrowed = false;
    _module_functions[229].cleanup_function = NULL;
    _module_functions[229].params = &_module_params[180];
    _module_params[180].name = "raw";
    _module_params[180].type = 4;
    _module_params[180].struct_type_name = NULL;
    _module_params[180].element_type = 21;
    _module_params[180].fn_sig = NULL;

    /* Function: diag_location */
    _module_functions[230].name = "diag_location";
    _module_functions[230].param_count = 3;
    _module_functions[230].return_type = 8;
    _module_functions[230].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[230].return_fn_sig = NULL;
    _module_functions[230].return_type_info = NULL;
    _module_functions[230].body = NULL;
    _module_functions[230].shadow_test = NULL;
    _module_functions[230].is_extern = false;
    _module_functions[230].returns_gc_managed = false;
    _module_functions[230].requires_manual_free = false;
    _module_functions[230].returns_borrowed = false;
    _module_functions[230].cleanup_function = NULL;
    _module_functions[230].params = &_module_params[181];
    _module_params[181].name = "file";
    _module_params[181].type = 4;
    _module_params[181].struct_type_name = NULL;
    _module_params[181].element_type = 21;
    _module_params[181].fn_sig = NULL;
    _module_params[182].name = "line";
    _module_params[182].type = 0;
    _module_params[182].struct_type_name = NULL;
    _module_params[182].element_type = 21;
    _module_params[182].fn_sig = NULL;
    _module_params[183].name = "column";
    _module_params[183].type = 0;
    _module_params[183].struct_type_name = NULL;
    _module_params[183].element_type = 21;
    _module_params[183].fn_sig = NULL;

    /* Function: diag_location_empty */
    _module_functions[231].name = "diag_location_empty";
    _module_functions[231].param_count = 0;
    _module_functions[231].return_type = 8;
    _module_functions[231].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[231].return_fn_sig = NULL;
    _module_functions[231].return_type_info = NULL;
    _module_functions[231].body = NULL;
    _module_functions[231].shadow_test = NULL;
    _module_functions[231].is_extern = false;
    _module_functions[231].returns_gc_managed = false;
    _module_functions[231].requires_manual_free = false;
    _module_functions[231].returns_borrowed = false;
    _module_functions[231].cleanup_function = NULL;
    _module_functions[231].params = NULL;

    /* Function: diag_new */
    _module_functions[232].name = "diag_new";
    _module_functions[232].param_count = 5;
    _module_functions[232].return_type = 8;
    _module_functions[232].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[232].return_fn_sig = NULL;
    _module_functions[232].return_type_info = NULL;
    _module_functions[232].body = NULL;
    _module_functions[232].shadow_test = NULL;
    _module_functions[232].is_extern = false;
    _module_functions[232].returns_gc_managed = false;
    _module_functions[232].requires_manual_free = false;
    _module_functions[232].returns_borrowed = false;
    _module_functions[232].cleanup_function = NULL;
    _module_functions[232].params = &_module_params[184];
    _module_params[184].name = "phase";
    _module_params[184].type = 0;
    _module_params[184].struct_type_name = NULL;
    _module_params[184].element_type = 21;
    _module_params[184].fn_sig = NULL;
    _module_params[185].name = "severity";
    _module_params[185].type = 0;
    _module_params[185].struct_type_name = NULL;
    _module_params[185].element_type = 21;
    _module_params[185].fn_sig = NULL;
    _module_params[186].name = "code";
    _module_params[186].type = 4;
    _module_params[186].struct_type_name = NULL;
    _module_params[186].element_type = 21;
    _module_params[186].fn_sig = NULL;
    _module_params[187].name = "message";
    _module_params[187].type = 4;
    _module_params[187].struct_type_name = NULL;
    _module_params[187].element_type = 21;
    _module_params[187].fn_sig = NULL;
    _module_params[188].name = "location";
    _module_params[188].type = 8;
    _module_params[188].struct_type_name = "CompilerSourceLocation";
    _module_params[188].element_type = 21;
    _module_params[188].fn_sig = NULL;

    /* Function: diag_simple */
    _module_functions[233].name = "diag_simple";
    _module_functions[233].param_count = 4;
    _module_functions[233].return_type = 8;
    _module_functions[233].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[233].return_fn_sig = NULL;
    _module_functions[233].return_type_info = NULL;
    _module_functions[233].body = NULL;
    _module_functions[233].shadow_test = NULL;
    _module_functions[233].is_extern = false;
    _module_functions[233].returns_gc_managed = false;
    _module_functions[233].requires_manual_free = false;
    _module_functions[233].returns_borrowed = false;
    _module_functions[233].cleanup_function = NULL;
    _module_functions[233].params = &_module_params[189];
    _module_params[189].name = "phase";
    _module_params[189].type = 0;
    _module_params[189].struct_type_name = NULL;
    _module_params[189].element_type = 21;
    _module_params[189].fn_sig = NULL;
    _module_params[190].name = "severity";
    _module_params[190].type = 0;
    _module_params[190].struct_type_name = NULL;
    _module_params[190].element_type = 21;
    _module_params[190].fn_sig = NULL;
    _module_params[191].name = "code";
    _module_params[191].type = 4;
    _module_params[191].struct_type_name = NULL;
    _module_params[191].element_type = 21;
    _module_params[191].fn_sig = NULL;
    _module_params[192].name = "message";
    _module_params[192].type = 4;
    _module_params[192].struct_type_name = NULL;
    _module_params[192].element_type = 21;
    _module_params[192].fn_sig = NULL;

    /* Function: diag_error */
    _module_functions[234].name = "diag_error";
    _module_functions[234].param_count = 4;
    _module_functions[234].return_type = 8;
    _module_functions[234].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[234].return_fn_sig = NULL;
    _module_functions[234].return_type_info = NULL;
    _module_functions[234].body = NULL;
    _module_functions[234].shadow_test = NULL;
    _module_functions[234].is_extern = false;
    _module_functions[234].returns_gc_managed = false;
    _module_functions[234].requires_manual_free = false;
    _module_functions[234].returns_borrowed = false;
    _module_functions[234].cleanup_function = NULL;
    _module_functions[234].params = &_module_params[193];
    _module_params[193].name = "phase";
    _module_params[193].type = 0;
    _module_params[193].struct_type_name = NULL;
    _module_params[193].element_type = 21;
    _module_params[193].fn_sig = NULL;
    _module_params[194].name = "code";
    _module_params[194].type = 4;
    _module_params[194].struct_type_name = NULL;
    _module_params[194].element_type = 21;
    _module_params[194].fn_sig = NULL;
    _module_params[195].name = "message";
    _module_params[195].type = 4;
    _module_params[195].struct_type_name = NULL;
    _module_params[195].element_type = 21;
    _module_params[195].fn_sig = NULL;
    _module_params[196].name = "location";
    _module_params[196].type = 8;
    _module_params[196].struct_type_name = "CompilerSourceLocation";
    _module_params[196].element_type = 21;
    _module_params[196].fn_sig = NULL;

    /* Function: diag_error_simple */
    _module_functions[235].name = "diag_error_simple";
    _module_functions[235].param_count = 3;
    _module_functions[235].return_type = 8;
    _module_functions[235].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[235].return_fn_sig = NULL;
    _module_functions[235].return_type_info = NULL;
    _module_functions[235].body = NULL;
    _module_functions[235].shadow_test = NULL;
    _module_functions[235].is_extern = false;
    _module_functions[235].returns_gc_managed = false;
    _module_functions[235].requires_manual_free = false;
    _module_functions[235].returns_borrowed = false;
    _module_functions[235].cleanup_function = NULL;
    _module_functions[235].params = &_module_params[197];
    _module_params[197].name = "phase";
    _module_params[197].type = 0;
    _module_params[197].struct_type_name = NULL;
    _module_params[197].element_type = 21;
    _module_params[197].fn_sig = NULL;
    _module_params[198].name = "code";
    _module_params[198].type = 4;
    _module_params[198].struct_type_name = NULL;
    _module_params[198].element_type = 21;
    _module_params[198].fn_sig = NULL;
    _module_params[199].name = "message";
    _module_params[199].type = 4;
    _module_params[199].struct_type_name = NULL;
    _module_params[199].element_type = 21;
    _module_params[199].fn_sig = NULL;

    /* Function: diag_warning */
    _module_functions[236].name = "diag_warning";
    _module_functions[236].param_count = 4;
    _module_functions[236].return_type = 8;
    _module_functions[236].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[236].return_fn_sig = NULL;
    _module_functions[236].return_type_info = NULL;
    _module_functions[236].body = NULL;
    _module_functions[236].shadow_test = NULL;
    _module_functions[236].is_extern = false;
    _module_functions[236].returns_gc_managed = false;
    _module_functions[236].requires_manual_free = false;
    _module_functions[236].returns_borrowed = false;
    _module_functions[236].cleanup_function = NULL;
    _module_functions[236].params = &_module_params[200];
    _module_params[200].name = "phase";
    _module_params[200].type = 0;
    _module_params[200].struct_type_name = NULL;
    _module_params[200].element_type = 21;
    _module_params[200].fn_sig = NULL;
    _module_params[201].name = "code";
    _module_params[201].type = 4;
    _module_params[201].struct_type_name = NULL;
    _module_params[201].element_type = 21;
    _module_params[201].fn_sig = NULL;
    _module_params[202].name = "message";
    _module_params[202].type = 4;
    _module_params[202].struct_type_name = NULL;
    _module_params[202].element_type = 21;
    _module_params[202].fn_sig = NULL;
    _module_params[203].name = "location";
    _module_params[203].type = 8;
    _module_params[203].struct_type_name = "CompilerSourceLocation";
    _module_params[203].element_type = 21;
    _module_params[203].fn_sig = NULL;

    /* Function: diag_warning_simple */
    _module_functions[237].name = "diag_warning_simple";
    _module_functions[237].param_count = 3;
    _module_functions[237].return_type = 8;
    _module_functions[237].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[237].return_fn_sig = NULL;
    _module_functions[237].return_type_info = NULL;
    _module_functions[237].body = NULL;
    _module_functions[237].shadow_test = NULL;
    _module_functions[237].is_extern = false;
    _module_functions[237].returns_gc_managed = false;
    _module_functions[237].requires_manual_free = false;
    _module_functions[237].returns_borrowed = false;
    _module_functions[237].cleanup_function = NULL;
    _module_functions[237].params = &_module_params[204];
    _module_params[204].name = "phase";
    _module_params[204].type = 0;
    _module_params[204].struct_type_name = NULL;
    _module_params[204].element_type = 21;
    _module_params[204].fn_sig = NULL;
    _module_params[205].name = "code";
    _module_params[205].type = 4;
    _module_params[205].struct_type_name = NULL;
    _module_params[205].element_type = 21;
    _module_params[205].fn_sig = NULL;
    _module_params[206].name = "message";
    _module_params[206].type = 4;
    _module_params[206].struct_type_name = NULL;
    _module_params[206].element_type = 21;
    _module_params[206].fn_sig = NULL;

    /* Function: diag_info */
    _module_functions[238].name = "diag_info";
    _module_functions[238].param_count = 4;
    _module_functions[238].return_type = 8;
    _module_functions[238].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[238].return_fn_sig = NULL;
    _module_functions[238].return_type_info = NULL;
    _module_functions[238].body = NULL;
    _module_functions[238].shadow_test = NULL;
    _module_functions[238].is_extern = false;
    _module_functions[238].returns_gc_managed = false;
    _module_functions[238].requires_manual_free = false;
    _module_functions[238].returns_borrowed = false;
    _module_functions[238].cleanup_function = NULL;
    _module_functions[238].params = &_module_params[207];
    _module_params[207].name = "phase";
    _module_params[207].type = 0;
    _module_params[207].struct_type_name = NULL;
    _module_params[207].element_type = 21;
    _module_params[207].fn_sig = NULL;
    _module_params[208].name = "code";
    _module_params[208].type = 4;
    _module_params[208].struct_type_name = NULL;
    _module_params[208].element_type = 21;
    _module_params[208].fn_sig = NULL;
    _module_params[209].name = "message";
    _module_params[209].type = 4;
    _module_params[209].struct_type_name = NULL;
    _module_params[209].element_type = 21;
    _module_params[209].fn_sig = NULL;
    _module_params[210].name = "location";
    _module_params[210].type = 8;
    _module_params[210].struct_type_name = "CompilerSourceLocation";
    _module_params[210].element_type = 21;
    _module_params[210].fn_sig = NULL;

    /* Function: diag_info_simple */
    _module_functions[239].name = "diag_info_simple";
    _module_functions[239].param_count = 3;
    _module_functions[239].return_type = 8;
    _module_functions[239].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[239].return_fn_sig = NULL;
    _module_functions[239].return_type_info = NULL;
    _module_functions[239].body = NULL;
    _module_functions[239].shadow_test = NULL;
    _module_functions[239].is_extern = false;
    _module_functions[239].returns_gc_managed = false;
    _module_functions[239].requires_manual_free = false;
    _module_functions[239].returns_borrowed = false;
    _module_functions[239].cleanup_function = NULL;
    _module_functions[239].params = &_module_params[211];
    _module_params[211].name = "phase";
    _module_params[211].type = 0;
    _module_params[211].struct_type_name = NULL;
    _module_params[211].element_type = 21;
    _module_params[211].fn_sig = NULL;
    _module_params[212].name = "code";
    _module_params[212].type = 4;
    _module_params[212].struct_type_name = NULL;
    _module_params[212].element_type = 21;
    _module_params[212].fn_sig = NULL;
    _module_params[213].name = "message";
    _module_params[213].type = 4;
    _module_params[213].struct_type_name = NULL;
    _module_params[213].element_type = 21;
    _module_params[213].fn_sig = NULL;

    /* Function: diag_lexer_error */
    _module_functions[240].name = "diag_lexer_error";
    _module_functions[240].param_count = 3;
    _module_functions[240].return_type = 8;
    _module_functions[240].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[240].return_fn_sig = NULL;
    _module_functions[240].return_type_info = NULL;
    _module_functions[240].body = NULL;
    _module_functions[240].shadow_test = NULL;
    _module_functions[240].is_extern = false;
    _module_functions[240].returns_gc_managed = false;
    _module_functions[240].requires_manual_free = false;
    _module_functions[240].returns_borrowed = false;
    _module_functions[240].cleanup_function = NULL;
    _module_functions[240].params = &_module_params[214];
    _module_params[214].name = "code";
    _module_params[214].type = 4;
    _module_params[214].struct_type_name = NULL;
    _module_params[214].element_type = 21;
    _module_params[214].fn_sig = NULL;
    _module_params[215].name = "message";
    _module_params[215].type = 4;
    _module_params[215].struct_type_name = NULL;
    _module_params[215].element_type = 21;
    _module_params[215].fn_sig = NULL;
    _module_params[216].name = "location";
    _module_params[216].type = 8;
    _module_params[216].struct_type_name = "CompilerSourceLocation";
    _module_params[216].element_type = 21;
    _module_params[216].fn_sig = NULL;

    /* Function: diag_parser_error */
    _module_functions[241].name = "diag_parser_error";
    _module_functions[241].param_count = 3;
    _module_functions[241].return_type = 8;
    _module_functions[241].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[241].return_fn_sig = NULL;
    _module_functions[241].return_type_info = NULL;
    _module_functions[241].body = NULL;
    _module_functions[241].shadow_test = NULL;
    _module_functions[241].is_extern = false;
    _module_functions[241].returns_gc_managed = false;
    _module_functions[241].requires_manual_free = false;
    _module_functions[241].returns_borrowed = false;
    _module_functions[241].cleanup_function = NULL;
    _module_functions[241].params = &_module_params[217];
    _module_params[217].name = "code";
    _module_params[217].type = 4;
    _module_params[217].struct_type_name = NULL;
    _module_params[217].element_type = 21;
    _module_params[217].fn_sig = NULL;
    _module_params[218].name = "message";
    _module_params[218].type = 4;
    _module_params[218].struct_type_name = NULL;
    _module_params[218].element_type = 21;
    _module_params[218].fn_sig = NULL;
    _module_params[219].name = "location";
    _module_params[219].type = 8;
    _module_params[219].struct_type_name = "CompilerSourceLocation";
    _module_params[219].element_type = 21;
    _module_params[219].fn_sig = NULL;

    /* Function: diag_typecheck_error */
    _module_functions[242].name = "diag_typecheck_error";
    _module_functions[242].param_count = 3;
    _module_functions[242].return_type = 8;
    _module_functions[242].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[242].return_fn_sig = NULL;
    _module_functions[242].return_type_info = NULL;
    _module_functions[242].body = NULL;
    _module_functions[242].shadow_test = NULL;
    _module_functions[242].is_extern = false;
    _module_functions[242].returns_gc_managed = false;
    _module_functions[242].requires_manual_free = false;
    _module_functions[242].returns_borrowed = false;
    _module_functions[242].cleanup_function = NULL;
    _module_functions[242].params = &_module_params[220];
    _module_params[220].name = "code";
    _module_params[220].type = 4;
    _module_params[220].struct_type_name = NULL;
    _module_params[220].element_type = 21;
    _module_params[220].fn_sig = NULL;
    _module_params[221].name = "message";
    _module_params[221].type = 4;
    _module_params[221].struct_type_name = NULL;
    _module_params[221].element_type = 21;
    _module_params[221].fn_sig = NULL;
    _module_params[222].name = "location";
    _module_params[222].type = 8;
    _module_params[222].struct_type_name = "CompilerSourceLocation";
    _module_params[222].element_type = 21;
    _module_params[222].fn_sig = NULL;

    /* Function: diag_transpiler_error */
    _module_functions[243].name = "diag_transpiler_error";
    _module_functions[243].param_count = 3;
    _module_functions[243].return_type = 8;
    _module_functions[243].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[243].return_fn_sig = NULL;
    _module_functions[243].return_type_info = NULL;
    _module_functions[243].body = NULL;
    _module_functions[243].shadow_test = NULL;
    _module_functions[243].is_extern = false;
    _module_functions[243].returns_gc_managed = false;
    _module_functions[243].requires_manual_free = false;
    _module_functions[243].returns_borrowed = false;
    _module_functions[243].cleanup_function = NULL;
    _module_functions[243].params = &_module_params[223];
    _module_params[223].name = "code";
    _module_params[223].type = 4;
    _module_params[223].struct_type_name = NULL;
    _module_params[223].element_type = 21;
    _module_params[223].fn_sig = NULL;
    _module_params[224].name = "message";
    _module_params[224].type = 4;
    _module_params[224].struct_type_name = NULL;
    _module_params[224].element_type = 21;
    _module_params[224].fn_sig = NULL;
    _module_params[225].name = "location";
    _module_params[225].type = 8;
    _module_params[225].struct_type_name = "CompilerSourceLocation";
    _module_params[225].element_type = 21;
    _module_params[225].fn_sig = NULL;

    /* Function: diag_list_new */
    _module_functions[244].name = "diag_list_new";
    _module_functions[244].param_count = 0;
    _module_functions[244].return_type = 15;
    _module_functions[244].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[244].return_fn_sig = NULL;
    _module_functions[244].return_type_info = NULL;
    _module_functions[244].body = NULL;
    _module_functions[244].shadow_test = NULL;
    _module_functions[244].is_extern = false;
    _module_functions[244].returns_gc_managed = false;
    _module_functions[244].requires_manual_free = false;
    _module_functions[244].returns_borrowed = false;
    _module_functions[244].cleanup_function = NULL;
    _module_functions[244].params = NULL;

    /* Function: diag_list_add */
    _module_functions[245].name = "diag_list_add";
    _module_functions[245].param_count = 2;
    _module_functions[245].return_type = 6;
    _module_functions[245].return_struct_type_name = NULL;
    _module_functions[245].return_fn_sig = NULL;
    _module_functions[245].return_type_info = NULL;
    _module_functions[245].body = NULL;
    _module_functions[245].shadow_test = NULL;
    _module_functions[245].is_extern = false;
    _module_functions[245].returns_gc_managed = false;
    _module_functions[245].requires_manual_free = false;
    _module_functions[245].returns_borrowed = false;
    _module_functions[245].cleanup_function = NULL;
    _module_functions[245].params = &_module_params[226];
    _module_params[226].name = "list";
    _module_params[226].type = 15;
    _module_params[226].struct_type_name = "CompilerDiagnostic";
    _module_params[226].element_type = 21;
    _module_params[226].fn_sig = NULL;
    _module_params[227].name = "diag";
    _module_params[227].type = 8;
    _module_params[227].struct_type_name = "CompilerDiagnostic";
    _module_params[227].element_type = 21;
    _module_params[227].fn_sig = NULL;

    /* Function: diag_list_count */
    _module_functions[246].name = "diag_list_count";
    _module_functions[246].param_count = 1;
    _module_functions[246].return_type = 0;
    _module_functions[246].return_struct_type_name = NULL;
    _module_functions[246].return_fn_sig = NULL;
    _module_functions[246].return_type_info = NULL;
    _module_functions[246].body = NULL;
    _module_functions[246].shadow_test = NULL;
    _module_functions[246].is_extern = false;
    _module_functions[246].returns_gc_managed = false;
    _module_functions[246].requires_manual_free = false;
    _module_functions[246].returns_borrowed = false;
    _module_functions[246].cleanup_function = NULL;
    _module_functions[246].params = &_module_params[228];
    _module_params[228].name = "list";
    _module_params[228].type = 15;
    _module_params[228].struct_type_name = "CompilerDiagnostic";
    _module_params[228].element_type = 21;
    _module_params[228].fn_sig = NULL;

    /* Function: diag_list_get */
    _module_functions[247].name = "diag_list_get";
    _module_functions[247].param_count = 2;
    _module_functions[247].return_type = 8;
    _module_functions[247].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[247].return_fn_sig = NULL;
    _module_functions[247].return_type_info = NULL;
    _module_functions[247].body = NULL;
    _module_functions[247].shadow_test = NULL;
    _module_functions[247].is_extern = false;
    _module_functions[247].returns_gc_managed = false;
    _module_functions[247].requires_manual_free = false;
    _module_functions[247].returns_borrowed = false;
    _module_functions[247].cleanup_function = NULL;
    _module_functions[247].params = &_module_params[229];
    _module_params[229].name = "list";
    _module_params[229].type = 15;
    _module_params[229].struct_type_name = "CompilerDiagnostic";
    _module_params[229].element_type = 21;
    _module_params[229].fn_sig = NULL;
    _module_params[230].name = "index";
    _module_params[230].type = 0;
    _module_params[230].struct_type_name = NULL;
    _module_params[230].element_type = 21;
    _module_params[230].fn_sig = NULL;

    /* Function: diag_list_has_errors */
    _module_functions[248].name = "diag_list_has_errors";
    _module_functions[248].param_count = 1;
    _module_functions[248].return_type = 3;
    _module_functions[248].return_struct_type_name = NULL;
    _module_functions[248].return_fn_sig = NULL;
    _module_functions[248].return_type_info = NULL;
    _module_functions[248].body = NULL;
    _module_functions[248].shadow_test = NULL;
    _module_functions[248].is_extern = false;
    _module_functions[248].returns_gc_managed = false;
    _module_functions[248].requires_manual_free = false;
    _module_functions[248].returns_borrowed = false;
    _module_functions[248].cleanup_function = NULL;
    _module_functions[248].params = &_module_params[231];
    _module_params[231].name = "list";
    _module_params[231].type = 15;
    _module_params[231].struct_type_name = "CompilerDiagnostic";
    _module_params[231].element_type = 21;
    _module_params[231].fn_sig = NULL;

    /* Function: diag_make_type_error */
    _module_functions[249].name = "diag_make_type_error";
    _module_functions[249].param_count = 2;
    _module_functions[249].return_type = 4;
    _module_functions[249].return_struct_type_name = NULL;
    _module_functions[249].return_fn_sig = NULL;
    _module_functions[249].return_type_info = NULL;
    _module_functions[249].body = NULL;
    _module_functions[249].shadow_test = NULL;
    _module_functions[249].is_extern = false;
    _module_functions[249].returns_gc_managed = true;
    _module_functions[249].requires_manual_free = false;
    _module_functions[249].returns_borrowed = false;
    _module_functions[249].cleanup_function = NULL;
    _module_functions[249].params = &_module_params[232];
    _module_params[232].name = "expected_type";
    _module_params[232].type = 4;
    _module_params[232].struct_type_name = NULL;
    _module_params[232].element_type = 21;
    _module_params[232].fn_sig = NULL;
    _module_params[233].name = "found_type";
    _module_params[233].type = 4;
    _module_params[233].struct_type_name = NULL;
    _module_params[233].element_type = 21;
    _module_params[233].fn_sig = NULL;

    /* Function: diag_make_undefined_error */
    _module_functions[250].name = "diag_make_undefined_error";
    _module_functions[250].param_count = 1;
    _module_functions[250].return_type = 4;
    _module_functions[250].return_struct_type_name = NULL;
    _module_functions[250].return_fn_sig = NULL;
    _module_functions[250].return_type_info = NULL;
    _module_functions[250].body = NULL;
    _module_functions[250].shadow_test = NULL;
    _module_functions[250].is_extern = false;
    _module_functions[250].returns_gc_managed = true;
    _module_functions[250].requires_manual_free = false;
    _module_functions[250].returns_borrowed = false;
    _module_functions[250].cleanup_function = NULL;
    _module_functions[250].params = &_module_params[234];
    _module_params[234].name = "name";
    _module_params[234].type = 4;
    _module_params[234].struct_type_name = NULL;
    _module_params[234].element_type = 21;
    _module_params[234].fn_sig = NULL;

    /* Function: diag_id_io_open */
    _module_functions[251].name = "diag_id_io_open";
    _module_functions[251].param_count = 0;
    _module_functions[251].return_type = 4;
    _module_functions[251].return_struct_type_name = NULL;
    _module_functions[251].return_fn_sig = NULL;
    _module_functions[251].return_type_info = NULL;
    _module_functions[251].body = NULL;
    _module_functions[251].shadow_test = NULL;
    _module_functions[251].is_extern = false;
    _module_functions[251].returns_gc_managed = true;
    _module_functions[251].requires_manual_free = false;
    _module_functions[251].returns_borrowed = false;
    _module_functions[251].cleanup_function = NULL;
    _module_functions[251].params = NULL;

    /* Function: diag_id_lex_failed */
    _module_functions[252].name = "diag_id_lex_failed";
    _module_functions[252].param_count = 0;
    _module_functions[252].return_type = 4;
    _module_functions[252].return_struct_type_name = NULL;
    _module_functions[252].return_fn_sig = NULL;
    _module_functions[252].return_type_info = NULL;
    _module_functions[252].body = NULL;
    _module_functions[252].shadow_test = NULL;
    _module_functions[252].is_extern = false;
    _module_functions[252].returns_gc_managed = true;
    _module_functions[252].requires_manual_free = false;
    _module_functions[252].returns_borrowed = false;
    _module_functions[252].cleanup_function = NULL;
    _module_functions[252].params = NULL;

    /* Function: diag_id_parse_failed */
    _module_functions[253].name = "diag_id_parse_failed";
    _module_functions[253].param_count = 0;
    _module_functions[253].return_type = 4;
    _module_functions[253].return_struct_type_name = NULL;
    _module_functions[253].return_fn_sig = NULL;
    _module_functions[253].return_type_info = NULL;
    _module_functions[253].body = NULL;
    _module_functions[253].shadow_test = NULL;
    _module_functions[253].is_extern = false;
    _module_functions[253].returns_gc_managed = true;
    _module_functions[253].requires_manual_free = false;
    _module_functions[253].returns_borrowed = false;
    _module_functions[253].cleanup_function = NULL;
    _module_functions[253].params = NULL;

    /* Function: diag_id_import_failed */
    _module_functions[254].name = "diag_id_import_failed";
    _module_functions[254].param_count = 0;
    _module_functions[254].return_type = 4;
    _module_functions[254].return_struct_type_name = NULL;
    _module_functions[254].return_fn_sig = NULL;
    _module_functions[254].return_type_info = NULL;
    _module_functions[254].body = NULL;
    _module_functions[254].shadow_test = NULL;
    _module_functions[254].is_extern = false;
    _module_functions[254].returns_gc_managed = true;
    _module_functions[254].requires_manual_free = false;
    _module_functions[254].returns_borrowed = false;
    _module_functions[254].cleanup_function = NULL;
    _module_functions[254].params = NULL;

    /* Function: diag_id_type_failed */
    _module_functions[255].name = "diag_id_type_failed";
    _module_functions[255].param_count = 0;
    _module_functions[255].return_type = 4;
    _module_functions[255].return_struct_type_name = NULL;
    _module_functions[255].return_fn_sig = NULL;
    _module_functions[255].return_type_info = NULL;
    _module_functions[255].body = NULL;
    _module_functions[255].shadow_test = NULL;
    _module_functions[255].is_extern = false;
    _module_functions[255].returns_gc_managed = true;
    _module_functions[255].requires_manual_free = false;
    _module_functions[255].returns_borrowed = false;
    _module_functions[255].cleanup_function = NULL;
    _module_functions[255].params = NULL;

    /* Function: diag_id_mod_compile */
    _module_functions[256].name = "diag_id_mod_compile";
    _module_functions[256].param_count = 0;
    _module_functions[256].return_type = 4;
    _module_functions[256].return_struct_type_name = NULL;
    _module_functions[256].return_fn_sig = NULL;
    _module_functions[256].return_type_info = NULL;
    _module_functions[256].body = NULL;
    _module_functions[256].shadow_test = NULL;
    _module_functions[256].is_extern = false;
    _module_functions[256].returns_gc_managed = true;
    _module_functions[256].requires_manual_free = false;
    _module_functions[256].returns_borrowed = false;
    _module_functions[256].cleanup_function = NULL;
    _module_functions[256].params = NULL;

    /* Function: diag_id_shadow_failed */
    _module_functions[257].name = "diag_id_shadow_failed";
    _module_functions[257].param_count = 0;
    _module_functions[257].return_type = 4;
    _module_functions[257].return_struct_type_name = NULL;
    _module_functions[257].return_fn_sig = NULL;
    _module_functions[257].return_type_info = NULL;
    _module_functions[257].body = NULL;
    _module_functions[257].shadow_test = NULL;
    _module_functions[257].is_extern = false;
    _module_functions[257].returns_gc_managed = true;
    _module_functions[257].requires_manual_free = false;
    _module_functions[257].returns_borrowed = false;
    _module_functions[257].cleanup_function = NULL;
    _module_functions[257].params = NULL;

    /* Function: diag_id_trans_failed */
    _module_functions[258].name = "diag_id_trans_failed";
    _module_functions[258].param_count = 0;
    _module_functions[258].return_type = 4;
    _module_functions[258].return_struct_type_name = NULL;
    _module_functions[258].return_fn_sig = NULL;
    _module_functions[258].return_type_info = NULL;
    _module_functions[258].body = NULL;
    _module_functions[258].shadow_test = NULL;
    _module_functions[258].is_extern = false;
    _module_functions[258].returns_gc_managed = true;
    _module_functions[258].requires_manual_free = false;
    _module_functions[258].returns_borrowed = false;
    _module_functions[258].cleanup_function = NULL;
    _module_functions[258].params = NULL;

    /* Function: diag_id_c_temp */
    _module_functions[259].name = "diag_id_c_temp";
    _module_functions[259].param_count = 0;
    _module_functions[259].return_type = 4;
    _module_functions[259].return_struct_type_name = NULL;
    _module_functions[259].return_fn_sig = NULL;
    _module_functions[259].return_type_info = NULL;
    _module_functions[259].body = NULL;
    _module_functions[259].shadow_test = NULL;
    _module_functions[259].is_extern = false;
    _module_functions[259].returns_gc_managed = true;
    _module_functions[259].requires_manual_free = false;
    _module_functions[259].returns_borrowed = false;
    _module_functions[259].cleanup_function = NULL;
    _module_functions[259].params = NULL;

    /* Function: diag_id_cc_cmd */
    _module_functions[260].name = "diag_id_cc_cmd";
    _module_functions[260].param_count = 0;
    _module_functions[260].return_type = 4;
    _module_functions[260].return_struct_type_name = NULL;
    _module_functions[260].return_fn_sig = NULL;
    _module_functions[260].return_type_info = NULL;
    _module_functions[260].body = NULL;
    _module_functions[260].shadow_test = NULL;
    _module_functions[260].is_extern = false;
    _module_functions[260].returns_gc_managed = true;
    _module_functions[260].requires_manual_free = false;
    _module_functions[260].returns_borrowed = false;
    _module_functions[260].cleanup_function = NULL;
    _module_functions[260].params = NULL;

    /* Function: diag_id_cc_failed */
    _module_functions[261].name = "diag_id_cc_failed";
    _module_functions[261].param_count = 0;
    _module_functions[261].return_type = 4;
    _module_functions[261].return_struct_type_name = NULL;
    _module_functions[261].return_fn_sig = NULL;
    _module_functions[261].return_type_info = NULL;
    _module_functions[261].body = NULL;
    _module_functions[261].shadow_test = NULL;
    _module_functions[261].is_extern = false;
    _module_functions[261].returns_gc_managed = true;
    _module_functions[261].requires_manual_free = false;
    _module_functions[261].returns_borrowed = false;
    _module_functions[261].cleanup_function = NULL;
    _module_functions[261].params = NULL;

    /* Function: diag_id_src_utf8 */
    _module_functions[262].name = "diag_id_src_utf8";
    _module_functions[262].param_count = 0;
    _module_functions[262].return_type = 4;
    _module_functions[262].return_struct_type_name = NULL;
    _module_functions[262].return_fn_sig = NULL;
    _module_functions[262].return_type_info = NULL;
    _module_functions[262].body = NULL;
    _module_functions[262].shadow_test = NULL;
    _module_functions[262].is_extern = false;
    _module_functions[262].returns_gc_managed = true;
    _module_functions[262].requires_manual_free = false;
    _module_functions[262].returns_borrowed = false;
    _module_functions[262].cleanup_function = NULL;
    _module_functions[262].params = NULL;

    /* Function: diag_en */
    _module_functions[263].name = "diag_en";
    _module_functions[263].param_count = 1;
    _module_functions[263].return_type = 4;
    _module_functions[263].return_struct_type_name = NULL;
    _module_functions[263].return_fn_sig = NULL;
    _module_functions[263].return_type_info = NULL;
    _module_functions[263].body = NULL;
    _module_functions[263].shadow_test = NULL;
    _module_functions[263].is_extern = false;
    _module_functions[263].returns_gc_managed = true;
    _module_functions[263].requires_manual_free = false;
    _module_functions[263].returns_borrowed = false;
    _module_functions[263].cleanup_function = NULL;
    _module_functions[263].params = &_module_params[235];
    _module_params[235].name = "code";
    _module_params[235].type = 4;
    _module_params[235].struct_type_name = NULL;
    _module_params[235].element_type = 21;
    _module_params[235].fn_sig = NULL;

    /* Function: fs_walkdir */
    _module_functions[264].name = "fs_walkdir";
    _module_functions[264].param_count = 1;
    _module_functions[264].return_type = 7;
    _module_functions[264].return_struct_type_name = NULL;
    _module_functions[264].return_fn_sig = NULL;
    _module_functions[264].return_type_info = &_type_infos[0];
    _module_functions[264].body = NULL;
    _module_functions[264].shadow_test = NULL;
    _module_functions[264].is_extern = true;
    _module_functions[264].returns_gc_managed = false;
    _module_functions[264].requires_manual_free = false;
    _module_functions[264].returns_borrowed = false;
    _module_functions[264].cleanup_function = NULL;
    _module_functions[264].params = &_module_params[236];
    _module_params[236].name = "_root";
    _module_params[236].type = 4;
    _module_params[236].struct_type_name = NULL;
    _module_params[236].element_type = 21;
    _module_params[236].fn_sig = NULL;

    /* Function: path_normalize */
    _module_functions[265].name = "path_normalize";
    _module_functions[265].param_count = 1;
    _module_functions[265].return_type = 4;
    _module_functions[265].return_struct_type_name = NULL;
    _module_functions[265].return_fn_sig = NULL;
    _module_functions[265].return_type_info = NULL;
    _module_functions[265].body = NULL;
    _module_functions[265].shadow_test = NULL;
    _module_functions[265].is_extern = true;
    _module_functions[265].returns_gc_managed = true;
    _module_functions[265].requires_manual_free = false;
    _module_functions[265].returns_borrowed = false;
    _module_functions[265].cleanup_function = NULL;
    _module_functions[265].params = &_module_params[237];
    _module_params[237].name = "_path";
    _module_params[237].type = 4;
    _module_params[237].struct_type_name = NULL;
    _module_params[237].element_type = 21;
    _module_params[237].fn_sig = NULL;

    /* Function: path_canonical */
    _module_functions[266].name = "path_canonical";
    _module_functions[266].param_count = 1;
    _module_functions[266].return_type = 4;
    _module_functions[266].return_struct_type_name = NULL;
    _module_functions[266].return_fn_sig = NULL;
    _module_functions[266].return_type_info = NULL;
    _module_functions[266].body = NULL;
    _module_functions[266].shadow_test = NULL;
    _module_functions[266].is_extern = true;
    _module_functions[266].returns_gc_managed = true;
    _module_functions[266].requires_manual_free = false;
    _module_functions[266].returns_borrowed = false;
    _module_functions[266].cleanup_function = NULL;
    _module_functions[266].params = &_module_params[238];
    _module_params[238].name = "_path";
    _module_params[238].type = 4;
    _module_params[238].struct_type_name = NULL;
    _module_params[238].element_type = 21;
    _module_params[238].fn_sig = NULL;

    /* Function: path_join */
    _module_functions[267].name = "path_join";
    _module_functions[267].param_count = 2;
    _module_functions[267].return_type = 4;
    _module_functions[267].return_struct_type_name = NULL;
    _module_functions[267].return_fn_sig = NULL;
    _module_functions[267].return_type_info = NULL;
    _module_functions[267].body = NULL;
    _module_functions[267].shadow_test = NULL;
    _module_functions[267].is_extern = true;
    _module_functions[267].returns_gc_managed = true;
    _module_functions[267].requires_manual_free = false;
    _module_functions[267].returns_borrowed = false;
    _module_functions[267].cleanup_function = NULL;
    _module_functions[267].params = &_module_params[239];
    _module_params[239].name = "_a";
    _module_params[239].type = 4;
    _module_params[239].struct_type_name = NULL;
    _module_params[239].element_type = 21;
    _module_params[239].fn_sig = NULL;
    _module_params[240].name = "_b";
    _module_params[240].type = 4;
    _module_params[240].struct_type_name = NULL;
    _module_params[240].element_type = 21;
    _module_params[240].fn_sig = NULL;

    /* Function: path_basename */
    _module_functions[268].name = "path_basename";
    _module_functions[268].param_count = 1;
    _module_functions[268].return_type = 4;
    _module_functions[268].return_struct_type_name = NULL;
    _module_functions[268].return_fn_sig = NULL;
    _module_functions[268].return_type_info = NULL;
    _module_functions[268].body = NULL;
    _module_functions[268].shadow_test = NULL;
    _module_functions[268].is_extern = true;
    _module_functions[268].returns_gc_managed = true;
    _module_functions[268].requires_manual_free = false;
    _module_functions[268].returns_borrowed = false;
    _module_functions[268].cleanup_function = NULL;
    _module_functions[268].params = &_module_params[241];
    _module_params[241].name = "_path";
    _module_params[241].type = 4;
    _module_params[241].struct_type_name = NULL;
    _module_params[241].element_type = 21;
    _module_params[241].fn_sig = NULL;

    /* Function: path_dirname */
    _module_functions[269].name = "path_dirname";
    _module_functions[269].param_count = 1;
    _module_functions[269].return_type = 4;
    _module_functions[269].return_struct_type_name = NULL;
    _module_functions[269].return_fn_sig = NULL;
    _module_functions[269].return_type_info = NULL;
    _module_functions[269].body = NULL;
    _module_functions[269].shadow_test = NULL;
    _module_functions[269].is_extern = true;
    _module_functions[269].returns_gc_managed = true;
    _module_functions[269].requires_manual_free = false;
    _module_functions[269].returns_borrowed = false;
    _module_functions[269].cleanup_function = NULL;
    _module_functions[269].params = &_module_params[242];
    _module_params[242].name = "_path";
    _module_params[242].type = 4;
    _module_params[242].struct_type_name = NULL;
    _module_params[242].element_type = 21;
    _module_params[242].fn_sig = NULL;

    /* Function: path_relpath */
    _module_functions[270].name = "path_relpath";
    _module_functions[270].param_count = 2;
    _module_functions[270].return_type = 4;
    _module_functions[270].return_struct_type_name = NULL;
    _module_functions[270].return_fn_sig = NULL;
    _module_functions[270].return_type_info = NULL;
    _module_functions[270].body = NULL;
    _module_functions[270].shadow_test = NULL;
    _module_functions[270].is_extern = true;
    _module_functions[270].returns_gc_managed = true;
    _module_functions[270].requires_manual_free = false;
    _module_functions[270].returns_borrowed = false;
    _module_functions[270].cleanup_function = NULL;
    _module_functions[270].params = &_module_params[243];
    _module_params[243].name = "_target";
    _module_params[243].type = 4;
    _module_params[243].struct_type_name = NULL;
    _module_params[243].element_type = 21;
    _module_params[243].fn_sig = NULL;
    _module_params[244].name = "_base";
    _module_params[244].type = 4;
    _module_params[244].struct_type_name = NULL;
    _module_params[244].element_type = 21;
    _module_params[244].fn_sig = NULL;

    /* Function: file_read */
    _module_functions[271].name = "file_read";
    _module_functions[271].param_count = 1;
    _module_functions[271].return_type = 4;
    _module_functions[271].return_struct_type_name = NULL;
    _module_functions[271].return_fn_sig = NULL;
    _module_functions[271].return_type_info = NULL;
    _module_functions[271].body = NULL;
    _module_functions[271].shadow_test = NULL;
    _module_functions[271].is_extern = true;
    _module_functions[271].returns_gc_managed = true;
    _module_functions[271].requires_manual_free = false;
    _module_functions[271].returns_borrowed = false;
    _module_functions[271].cleanup_function = NULL;
    _module_functions[271].params = &_module_params[245];
    _module_params[245].name = "_path";
    _module_params[245].type = 4;
    _module_params[245].struct_type_name = NULL;
    _module_params[245].element_type = 21;
    _module_params[245].fn_sig = NULL;

    /* Function: file_write */
    _module_functions[272].name = "file_write";
    _module_functions[272].param_count = 2;
    _module_functions[272].return_type = 0;
    _module_functions[272].return_struct_type_name = NULL;
    _module_functions[272].return_fn_sig = NULL;
    _module_functions[272].return_type_info = NULL;
    _module_functions[272].body = NULL;
    _module_functions[272].shadow_test = NULL;
    _module_functions[272].is_extern = true;
    _module_functions[272].returns_gc_managed = false;
    _module_functions[272].requires_manual_free = false;
    _module_functions[272].returns_borrowed = false;
    _module_functions[272].cleanup_function = NULL;
    _module_functions[272].params = &_module_params[246];
    _module_params[246].name = "_path";
    _module_params[246].type = 4;
    _module_params[246].struct_type_name = NULL;
    _module_params[246].element_type = 21;
    _module_params[246].fn_sig = NULL;
    _module_params[247].name = "_content";
    _module_params[247].type = 4;
    _module_params[247].struct_type_name = NULL;
    _module_params[247].element_type = 21;
    _module_params[247].fn_sig = NULL;

    /* Function: file_append */
    _module_functions[273].name = "file_append";
    _module_functions[273].param_count = 2;
    _module_functions[273].return_type = 0;
    _module_functions[273].return_struct_type_name = NULL;
    _module_functions[273].return_fn_sig = NULL;
    _module_functions[273].return_type_info = NULL;
    _module_functions[273].body = NULL;
    _module_functions[273].shadow_test = NULL;
    _module_functions[273].is_extern = true;
    _module_functions[273].returns_gc_managed = false;
    _module_functions[273].requires_manual_free = false;
    _module_functions[273].returns_borrowed = false;
    _module_functions[273].cleanup_function = NULL;
    _module_functions[273].params = &_module_params[248];
    _module_params[248].name = "_path";
    _module_params[248].type = 4;
    _module_params[248].struct_type_name = NULL;
    _module_params[248].element_type = 21;
    _module_params[248].fn_sig = NULL;
    _module_params[249].name = "_content";
    _module_params[249].type = 4;
    _module_params[249].struct_type_name = NULL;
    _module_params[249].element_type = 21;
    _module_params[249].fn_sig = NULL;

    /* Function: file_exists */
    _module_functions[274].name = "file_exists";
    _module_functions[274].param_count = 1;
    _module_functions[274].return_type = 3;
    _module_functions[274].return_struct_type_name = NULL;
    _module_functions[274].return_fn_sig = NULL;
    _module_functions[274].return_type_info = NULL;
    _module_functions[274].body = NULL;
    _module_functions[274].shadow_test = NULL;
    _module_functions[274].is_extern = true;
    _module_functions[274].returns_gc_managed = false;
    _module_functions[274].requires_manual_free = false;
    _module_functions[274].returns_borrowed = false;
    _module_functions[274].cleanup_function = NULL;
    _module_functions[274].params = &_module_params[250];
    _module_params[250].name = "_path";
    _module_params[250].type = 4;
    _module_params[250].struct_type_name = NULL;
    _module_params[250].element_type = 21;
    _module_params[250].fn_sig = NULL;

    /* Function: file_delete */
    _module_functions[275].name = "file_delete";
    _module_functions[275].param_count = 1;
    _module_functions[275].return_type = 0;
    _module_functions[275].return_struct_type_name = NULL;
    _module_functions[275].return_fn_sig = NULL;
    _module_functions[275].return_type_info = NULL;
    _module_functions[275].body = NULL;
    _module_functions[275].shadow_test = NULL;
    _module_functions[275].is_extern = true;
    _module_functions[275].returns_gc_managed = false;
    _module_functions[275].requires_manual_free = false;
    _module_functions[275].returns_borrowed = false;
    _module_functions[275].cleanup_function = NULL;
    _module_functions[275].params = &_module_params[251];
    _module_params[251].name = "_path";
    _module_params[251].type = 4;
    _module_params[251].struct_type_name = NULL;
    _module_params[251].element_type = 21;
    _module_params[251].fn_sig = NULL;

    /* Function: fs_mkdir_p */
    _module_functions[276].name = "fs_mkdir_p";
    _module_functions[276].param_count = 1;
    _module_functions[276].return_type = 0;
    _module_functions[276].return_struct_type_name = NULL;
    _module_functions[276].return_fn_sig = NULL;
    _module_functions[276].return_type_info = NULL;
    _module_functions[276].body = NULL;
    _module_functions[276].shadow_test = NULL;
    _module_functions[276].is_extern = true;
    _module_functions[276].returns_gc_managed = false;
    _module_functions[276].requires_manual_free = false;
    _module_functions[276].returns_borrowed = false;
    _module_functions[276].cleanup_function = NULL;
    _module_functions[276].params = &_module_params[252];
    _module_params[252].name = "_path";
    _module_params[252].type = 4;
    _module_params[252].struct_type_name = NULL;
    _module_params[252].element_type = 21;
    _module_params[252].fn_sig = NULL;

    /* Function: file_copy */
    _module_functions[277].name = "file_copy";
    _module_functions[277].param_count = 2;
    _module_functions[277].return_type = 0;
    _module_functions[277].return_struct_type_name = NULL;
    _module_functions[277].return_fn_sig = NULL;
    _module_functions[277].return_type_info = NULL;
    _module_functions[277].body = NULL;
    _module_functions[277].shadow_test = NULL;
    _module_functions[277].is_extern = true;
    _module_functions[277].returns_gc_managed = false;
    _module_functions[277].requires_manual_free = false;
    _module_functions[277].returns_borrowed = false;
    _module_functions[277].cleanup_function = NULL;
    _module_functions[277].params = &_module_params[253];
    _module_params[253].name = "_src";
    _module_params[253].type = 4;
    _module_params[253].struct_type_name = NULL;
    _module_params[253].element_type = 21;
    _module_params[253].fn_sig = NULL;
    _module_params[254].name = "_dst";
    _module_params[254].type = 4;
    _module_params[254].struct_type_name = NULL;
    _module_params[254].element_type = 21;
    _module_params[254].fn_sig = NULL;

    /* Function: dir_copy */
    _module_functions[278].name = "dir_copy";
    _module_functions[278].param_count = 2;
    _module_functions[278].return_type = 0;
    _module_functions[278].return_struct_type_name = NULL;
    _module_functions[278].return_fn_sig = NULL;
    _module_functions[278].return_type_info = NULL;
    _module_functions[278].body = NULL;
    _module_functions[278].shadow_test = NULL;
    _module_functions[278].is_extern = true;
    _module_functions[278].returns_gc_managed = false;
    _module_functions[278].requires_manual_free = false;
    _module_functions[278].returns_borrowed = false;
    _module_functions[278].cleanup_function = NULL;
    _module_functions[278].params = &_module_params[255];
    _module_params[255].name = "_src";
    _module_params[255].type = 4;
    _module_params[255].struct_type_name = NULL;
    _module_params[255].element_type = 21;
    _module_params[255].fn_sig = NULL;
    _module_params[256].name = "_dst";
    _module_params[256].type = 4;
    _module_params[256].struct_type_name = NULL;
    _module_params[256].element_type = 21;
    _module_params[256].fn_sig = NULL;

    /* Function: walkdir */
    _module_functions[279].name = "walkdir";
    _module_functions[279].param_count = 1;
    _module_functions[279].return_type = 7;
    _module_functions[279].return_struct_type_name = NULL;
    _module_functions[279].return_fn_sig = NULL;
    _module_functions[279].return_type_info = &_type_infos[1];
    _module_functions[279].body = NULL;
    _module_functions[279].shadow_test = NULL;
    _module_functions[279].is_extern = false;
    _module_functions[279].returns_gc_managed = false;
    _module_functions[279].requires_manual_free = false;
    _module_functions[279].returns_borrowed = false;
    _module_functions[279].cleanup_function = NULL;
    _module_functions[279].params = &_module_params[257];
    _module_params[257].name = "root";
    _module_params[257].type = 4;
    _module_params[257].struct_type_name = NULL;
    _module_params[257].element_type = 21;
    _module_params[257].fn_sig = NULL;

    /* Function: normalize */
    _module_functions[280].name = "normalize";
    _module_functions[280].param_count = 1;
    _module_functions[280].return_type = 4;
    _module_functions[280].return_struct_type_name = NULL;
    _module_functions[280].return_fn_sig = NULL;
    _module_functions[280].return_type_info = NULL;
    _module_functions[280].body = NULL;
    _module_functions[280].shadow_test = NULL;
    _module_functions[280].is_extern = false;
    _module_functions[280].returns_gc_managed = true;
    _module_functions[280].requires_manual_free = false;
    _module_functions[280].returns_borrowed = false;
    _module_functions[280].cleanup_function = NULL;
    _module_functions[280].params = &_module_params[258];
    _module_params[258].name = "path";
    _module_params[258].type = 4;
    _module_params[258].struct_type_name = NULL;
    _module_params[258].element_type = 21;
    _module_params[258].fn_sig = NULL;

    /* Function: canonical */
    _module_functions[281].name = "canonical";
    _module_functions[281].param_count = 1;
    _module_functions[281].return_type = 4;
    _module_functions[281].return_struct_type_name = NULL;
    _module_functions[281].return_fn_sig = NULL;
    _module_functions[281].return_type_info = NULL;
    _module_functions[281].body = NULL;
    _module_functions[281].shadow_test = NULL;
    _module_functions[281].is_extern = false;
    _module_functions[281].returns_gc_managed = true;
    _module_functions[281].requires_manual_free = false;
    _module_functions[281].returns_borrowed = false;
    _module_functions[281].cleanup_function = NULL;
    _module_functions[281].params = &_module_params[259];
    _module_params[259].name = "path";
    _module_params[259].type = 4;
    _module_params[259].struct_type_name = NULL;
    _module_params[259].element_type = 21;
    _module_params[259].fn_sig = NULL;

    /* Function: join */
    _module_functions[282].name = "join";
    _module_functions[282].param_count = 2;
    _module_functions[282].return_type = 4;
    _module_functions[282].return_struct_type_name = NULL;
    _module_functions[282].return_fn_sig = NULL;
    _module_functions[282].return_type_info = NULL;
    _module_functions[282].body = NULL;
    _module_functions[282].shadow_test = NULL;
    _module_functions[282].is_extern = false;
    _module_functions[282].returns_gc_managed = true;
    _module_functions[282].requires_manual_free = false;
    _module_functions[282].returns_borrowed = false;
    _module_functions[282].cleanup_function = NULL;
    _module_functions[282].params = &_module_params[260];
    _module_params[260].name = "a";
    _module_params[260].type = 4;
    _module_params[260].struct_type_name = NULL;
    _module_params[260].element_type = 21;
    _module_params[260].fn_sig = NULL;
    _module_params[261].name = "b";
    _module_params[261].type = 4;
    _module_params[261].struct_type_name = NULL;
    _module_params[261].element_type = 21;
    _module_params[261].fn_sig = NULL;

    /* Function: basename */
    _module_functions[283].name = "basename";
    _module_functions[283].param_count = 1;
    _module_functions[283].return_type = 4;
    _module_functions[283].return_struct_type_name = NULL;
    _module_functions[283].return_fn_sig = NULL;
    _module_functions[283].return_type_info = NULL;
    _module_functions[283].body = NULL;
    _module_functions[283].shadow_test = NULL;
    _module_functions[283].is_extern = false;
    _module_functions[283].returns_gc_managed = true;
    _module_functions[283].requires_manual_free = false;
    _module_functions[283].returns_borrowed = false;
    _module_functions[283].cleanup_function = NULL;
    _module_functions[283].params = &_module_params[262];
    _module_params[262].name = "path";
    _module_params[262].type = 4;
    _module_params[262].struct_type_name = NULL;
    _module_params[262].element_type = 21;
    _module_params[262].fn_sig = NULL;

    /* Function: dirname */
    _module_functions[284].name = "dirname";
    _module_functions[284].param_count = 1;
    _module_functions[284].return_type = 4;
    _module_functions[284].return_struct_type_name = NULL;
    _module_functions[284].return_fn_sig = NULL;
    _module_functions[284].return_type_info = NULL;
    _module_functions[284].body = NULL;
    _module_functions[284].shadow_test = NULL;
    _module_functions[284].is_extern = false;
    _module_functions[284].returns_gc_managed = true;
    _module_functions[284].requires_manual_free = false;
    _module_functions[284].returns_borrowed = false;
    _module_functions[284].cleanup_function = NULL;
    _module_functions[284].params = &_module_params[263];
    _module_params[263].name = "path";
    _module_params[263].type = 4;
    _module_params[263].struct_type_name = NULL;
    _module_params[263].element_type = 21;
    _module_params[263].fn_sig = NULL;

    /* Function: relpath */
    _module_functions[285].name = "relpath";
    _module_functions[285].param_count = 2;
    _module_functions[285].return_type = 4;
    _module_functions[285].return_struct_type_name = NULL;
    _module_functions[285].return_fn_sig = NULL;
    _module_functions[285].return_type_info = NULL;
    _module_functions[285].body = NULL;
    _module_functions[285].shadow_test = NULL;
    _module_functions[285].is_extern = false;
    _module_functions[285].returns_gc_managed = true;
    _module_functions[285].requires_manual_free = false;
    _module_functions[285].returns_borrowed = false;
    _module_functions[285].cleanup_function = NULL;
    _module_functions[285].params = &_module_params[264];
    _module_params[264].name = "target";
    _module_params[264].type = 4;
    _module_params[264].struct_type_name = NULL;
    _module_params[264].element_type = 21;
    _module_params[264].fn_sig = NULL;
    _module_params[265].name = "base";
    _module_params[265].type = 4;
    _module_params[265].struct_type_name = NULL;
    _module_params[265].element_type = 21;
    _module_params[265].fn_sig = NULL;

    /* Function: cwd */
    _module_functions[286].name = "cwd";
    _module_functions[286].param_count = 0;
    _module_functions[286].return_type = 4;
    _module_functions[286].return_struct_type_name = NULL;
    _module_functions[286].return_fn_sig = NULL;
    _module_functions[286].return_type_info = NULL;
    _module_functions[286].body = NULL;
    _module_functions[286].shadow_test = NULL;
    _module_functions[286].is_extern = false;
    _module_functions[286].returns_gc_managed = true;
    _module_functions[286].requires_manual_free = false;
    _module_functions[286].returns_borrowed = false;
    _module_functions[286].cleanup_function = NULL;
    _module_functions[286].params = NULL;

    /* Function: glob_match_impl */
    _module_functions[287].name = "glob_match_impl";
    _module_functions[287].param_count = 4;
    _module_functions[287].return_type = 3;
    _module_functions[287].return_struct_type_name = NULL;
    _module_functions[287].return_fn_sig = NULL;
    _module_functions[287].return_type_info = NULL;
    _module_functions[287].body = NULL;
    _module_functions[287].shadow_test = NULL;
    _module_functions[287].is_extern = false;
    _module_functions[287].returns_gc_managed = false;
    _module_functions[287].requires_manual_free = false;
    _module_functions[287].returns_borrowed = false;
    _module_functions[287].cleanup_function = NULL;
    _module_functions[287].params = &_module_params[266];
    _module_params[266].name = "pattern";
    _module_params[266].type = 4;
    _module_params[266].struct_type_name = NULL;
    _module_params[266].element_type = 21;
    _module_params[266].fn_sig = NULL;
    _module_params[267].name = "pi";
    _module_params[267].type = 0;
    _module_params[267].struct_type_name = NULL;
    _module_params[267].element_type = 21;
    _module_params[267].fn_sig = NULL;
    _module_params[268].name = "text";
    _module_params[268].type = 4;
    _module_params[268].struct_type_name = NULL;
    _module_params[268].element_type = 21;
    _module_params[268].fn_sig = NULL;
    _module_params[269].name = "ti";
    _module_params[269].type = 0;
    _module_params[269].struct_type_name = NULL;
    _module_params[269].element_type = 21;
    _module_params[269].fn_sig = NULL;

    /* Function: glob_match */
    _module_functions[288].name = "glob_match";
    _module_functions[288].param_count = 2;
    _module_functions[288].return_type = 3;
    _module_functions[288].return_struct_type_name = NULL;
    _module_functions[288].return_fn_sig = NULL;
    _module_functions[288].return_type_info = NULL;
    _module_functions[288].body = NULL;
    _module_functions[288].shadow_test = NULL;
    _module_functions[288].is_extern = false;
    _module_functions[288].returns_gc_managed = false;
    _module_functions[288].requires_manual_free = false;
    _module_functions[288].returns_borrowed = false;
    _module_functions[288].cleanup_function = NULL;
    _module_functions[288].params = &_module_params[270];
    _module_params[270].name = "pattern";
    _module_params[270].type = 4;
    _module_params[270].struct_type_name = NULL;
    _module_params[270].element_type = 21;
    _module_params[270].fn_sig = NULL;
    _module_params[271].name = "text";
    _module_params[271].type = 4;
    _module_params[271].struct_type_name = NULL;
    _module_params[271].element_type = 21;
    _module_params[271].fn_sig = NULL;

    /* Function: glob */
    _module_functions[289].name = "glob";
    _module_functions[289].param_count = 2;
    _module_functions[289].return_type = 7;
    _module_functions[289].return_struct_type_name = NULL;
    _module_functions[289].return_fn_sig = NULL;
    _module_functions[289].return_type_info = &_type_infos[2];
    _module_functions[289].body = NULL;
    _module_functions[289].shadow_test = NULL;
    _module_functions[289].is_extern = false;
    _module_functions[289].returns_gc_managed = false;
    _module_functions[289].requires_manual_free = false;
    _module_functions[289].returns_borrowed = false;
    _module_functions[289].cleanup_function = NULL;
    _module_functions[289].params = &_module_params[272];
    _module_params[272].name = "root";
    _module_params[272].type = 4;
    _module_params[272].struct_type_name = NULL;
    _module_params[272].element_type = 21;
    _module_params[272].fn_sig = NULL;
    _module_params[273].name = "pattern";
    _module_params[273].type = 4;
    _module_params[273].struct_type_name = NULL;
    _module_params[273].element_type = 21;
    _module_params[273].fn_sig = NULL;

    /* Function: read */
    _module_functions[290].name = "read";
    _module_functions[290].param_count = 1;
    _module_functions[290].return_type = 4;
    _module_functions[290].return_struct_type_name = NULL;
    _module_functions[290].return_fn_sig = NULL;
    _module_functions[290].return_type_info = NULL;
    _module_functions[290].body = NULL;
    _module_functions[290].shadow_test = NULL;
    _module_functions[290].is_extern = false;
    _module_functions[290].returns_gc_managed = true;
    _module_functions[290].requires_manual_free = false;
    _module_functions[290].returns_borrowed = false;
    _module_functions[290].cleanup_function = NULL;
    _module_functions[290].params = &_module_params[274];
    _module_params[274].name = "path";
    _module_params[274].type = 4;
    _module_params[274].struct_type_name = NULL;
    _module_params[274].element_type = 21;
    _module_params[274].fn_sig = NULL;

    /* Function: write */
    _module_functions[291].name = "write";
    _module_functions[291].param_count = 2;
    _module_functions[291].return_type = 0;
    _module_functions[291].return_struct_type_name = NULL;
    _module_functions[291].return_fn_sig = NULL;
    _module_functions[291].return_type_info = NULL;
    _module_functions[291].body = NULL;
    _module_functions[291].shadow_test = NULL;
    _module_functions[291].is_extern = false;
    _module_functions[291].returns_gc_managed = false;
    _module_functions[291].requires_manual_free = false;
    _module_functions[291].returns_borrowed = false;
    _module_functions[291].cleanup_function = NULL;
    _module_functions[291].params = &_module_params[275];
    _module_params[275].name = "path";
    _module_params[275].type = 4;
    _module_params[275].struct_type_name = NULL;
    _module_params[275].element_type = 21;
    _module_params[275].fn_sig = NULL;
    _module_params[276].name = "content";
    _module_params[276].type = 4;
    _module_params[276].struct_type_name = NULL;
    _module_params[276].element_type = 21;
    _module_params[276].fn_sig = NULL;

    /* Function: append */
    _module_functions[292].name = "append";
    _module_functions[292].param_count = 2;
    _module_functions[292].return_type = 0;
    _module_functions[292].return_struct_type_name = NULL;
    _module_functions[292].return_fn_sig = NULL;
    _module_functions[292].return_type_info = NULL;
    _module_functions[292].body = NULL;
    _module_functions[292].shadow_test = NULL;
    _module_functions[292].is_extern = false;
    _module_functions[292].returns_gc_managed = false;
    _module_functions[292].requires_manual_free = false;
    _module_functions[292].returns_borrowed = false;
    _module_functions[292].cleanup_function = NULL;
    _module_functions[292].params = &_module_params[277];
    _module_params[277].name = "path";
    _module_params[277].type = 4;
    _module_params[277].struct_type_name = NULL;
    _module_params[277].element_type = 21;
    _module_params[277].fn_sig = NULL;
    _module_params[278].name = "content";
    _module_params[278].type = 4;
    _module_params[278].struct_type_name = NULL;
    _module_params[278].element_type = 21;
    _module_params[278].fn_sig = NULL;

    /* Function: exists */
    _module_functions[293].name = "exists";
    _module_functions[293].param_count = 1;
    _module_functions[293].return_type = 3;
    _module_functions[293].return_struct_type_name = NULL;
    _module_functions[293].return_fn_sig = NULL;
    _module_functions[293].return_type_info = NULL;
    _module_functions[293].body = NULL;
    _module_functions[293].shadow_test = NULL;
    _module_functions[293].is_extern = false;
    _module_functions[293].returns_gc_managed = false;
    _module_functions[293].requires_manual_free = false;
    _module_functions[293].returns_borrowed = false;
    _module_functions[293].cleanup_function = NULL;
    _module_functions[293].params = &_module_params[279];
    _module_params[279].name = "path";
    _module_params[279].type = 4;
    _module_params[279].struct_type_name = NULL;
    _module_params[279].element_type = 21;
    _module_params[279].fn_sig = NULL;

    /* Function: delete */
    _module_functions[294].name = "delete";
    _module_functions[294].param_count = 1;
    _module_functions[294].return_type = 0;
    _module_functions[294].return_struct_type_name = NULL;
    _module_functions[294].return_fn_sig = NULL;
    _module_functions[294].return_type_info = NULL;
    _module_functions[294].body = NULL;
    _module_functions[294].shadow_test = NULL;
    _module_functions[294].is_extern = false;
    _module_functions[294].returns_gc_managed = false;
    _module_functions[294].requires_manual_free = false;
    _module_functions[294].returns_borrowed = false;
    _module_functions[294].cleanup_function = NULL;
    _module_functions[294].params = &_module_params[280];
    _module_params[280].name = "path";
    _module_params[280].type = 4;
    _module_params[280].struct_type_name = NULL;
    _module_params[280].element_type = 21;
    _module_params[280].fn_sig = NULL;

    /* Function: mkdir_p */
    _module_functions[295].name = "mkdir_p";
    _module_functions[295].param_count = 1;
    _module_functions[295].return_type = 0;
    _module_functions[295].return_struct_type_name = NULL;
    _module_functions[295].return_fn_sig = NULL;
    _module_functions[295].return_type_info = NULL;
    _module_functions[295].body = NULL;
    _module_functions[295].shadow_test = NULL;
    _module_functions[295].is_extern = false;
    _module_functions[295].returns_gc_managed = false;
    _module_functions[295].requires_manual_free = false;
    _module_functions[295].returns_borrowed = false;
    _module_functions[295].cleanup_function = NULL;
    _module_functions[295].params = &_module_params[281];
    _module_params[281].name = "path";
    _module_params[281].type = 4;
    _module_params[281].struct_type_name = NULL;
    _module_params[281].element_type = 21;
    _module_params[281].fn_sig = NULL;

    /* Function: copy_file */
    _module_functions[296].name = "copy_file";
    _module_functions[296].param_count = 2;
    _module_functions[296].return_type = 0;
    _module_functions[296].return_struct_type_name = NULL;
    _module_functions[296].return_fn_sig = NULL;
    _module_functions[296].return_type_info = NULL;
    _module_functions[296].body = NULL;
    _module_functions[296].shadow_test = NULL;
    _module_functions[296].is_extern = false;
    _module_functions[296].returns_gc_managed = false;
    _module_functions[296].requires_manual_free = false;
    _module_functions[296].returns_borrowed = false;
    _module_functions[296].cleanup_function = NULL;
    _module_functions[296].params = &_module_params[282];
    _module_params[282].name = "src";
    _module_params[282].type = 4;
    _module_params[282].struct_type_name = NULL;
    _module_params[282].element_type = 21;
    _module_params[282].fn_sig = NULL;
    _module_params[283].name = "dst";
    _module_params[283].type = 4;
    _module_params[283].struct_type_name = NULL;
    _module_params[283].element_type = 21;
    _module_params[283].fn_sig = NULL;

    /* Function: copy_dir */
    _module_functions[297].name = "copy_dir";
    _module_functions[297].param_count = 2;
    _module_functions[297].return_type = 0;
    _module_functions[297].return_struct_type_name = NULL;
    _module_functions[297].return_fn_sig = NULL;
    _module_functions[297].return_type_info = NULL;
    _module_functions[297].body = NULL;
    _module_functions[297].shadow_test = NULL;
    _module_functions[297].is_extern = false;
    _module_functions[297].returns_gc_managed = false;
    _module_functions[297].requires_manual_free = false;
    _module_functions[297].returns_borrowed = false;
    _module_functions[297].cleanup_function = NULL;
    _module_functions[297].params = &_module_params[284];
    _module_params[284].name = "src";
    _module_params[284].type = 4;
    _module_params[284].struct_type_name = NULL;
    _module_params[284].element_type = 21;
    _module_params[284].fn_sig = NULL;
    _module_params[285].name = "dst";
    _module_params[285].type = 4;
    _module_params[285].struct_type_name = NULL;
    _module_params[285].element_type = 21;
    _module_params[285].fn_sig = NULL;

    /* Function: is_identifier_start */
    _module_functions[298].name = "is_identifier_start";
    _module_functions[298].param_count = 1;
    _module_functions[298].return_type = 3;
    _module_functions[298].return_struct_type_name = NULL;
    _module_functions[298].return_fn_sig = NULL;
    _module_functions[298].return_type_info = NULL;
    _module_functions[298].body = NULL;
    _module_functions[298].shadow_test = NULL;
    _module_functions[298].is_extern = false;
    _module_functions[298].returns_gc_managed = false;
    _module_functions[298].requires_manual_free = false;
    _module_functions[298].returns_borrowed = false;
    _module_functions[298].cleanup_function = NULL;
    _module_functions[298].params = &_module_params[286];
    _module_params[286].name = "c";
    _module_params[286].type = 0;
    _module_params[286].struct_type_name = NULL;
    _module_params[286].element_type = 21;
    _module_params[286].fn_sig = NULL;

    /* Function: is_identifier_char */
    _module_functions[299].name = "is_identifier_char";
    _module_functions[299].param_count = 1;
    _module_functions[299].return_type = 3;
    _module_functions[299].return_struct_type_name = NULL;
    _module_functions[299].return_fn_sig = NULL;
    _module_functions[299].return_type_info = NULL;
    _module_functions[299].body = NULL;
    _module_functions[299].shadow_test = NULL;
    _module_functions[299].is_extern = false;
    _module_functions[299].returns_gc_managed = false;
    _module_functions[299].requires_manual_free = false;
    _module_functions[299].returns_borrowed = false;
    _module_functions[299].cleanup_function = NULL;
    _module_functions[299].params = &_module_params[287];
    _module_params[287].name = "c";
    _module_params[287].type = 0;
    _module_params[287].struct_type_name = NULL;
    _module_params[287].element_type = 21;
    _module_params[287].fn_sig = NULL;

    /* Function: is_whitespace_char */
    _module_functions[300].name = "is_whitespace_char";
    _module_functions[300].param_count = 1;
    _module_functions[300].return_type = 3;
    _module_functions[300].return_struct_type_name = NULL;
    _module_functions[300].return_fn_sig = NULL;
    _module_functions[300].return_type_info = NULL;
    _module_functions[300].body = NULL;
    _module_functions[300].shadow_test = NULL;
    _module_functions[300].is_extern = false;
    _module_functions[300].returns_gc_managed = false;
    _module_functions[300].requires_manual_free = false;
    _module_functions[300].returns_borrowed = false;
    _module_functions[300].cleanup_function = NULL;
    _module_functions[300].params = &_module_params[288];
    _module_params[288].name = "c";
    _module_params[288].type = 0;
    _module_params[288].struct_type_name = NULL;
    _module_params[288].element_type = 21;
    _module_params[288].fn_sig = NULL;

    /* Function: is_digit_char */
    _module_functions[301].name = "is_digit_char";
    _module_functions[301].param_count = 1;
    _module_functions[301].return_type = 3;
    _module_functions[301].return_struct_type_name = NULL;
    _module_functions[301].return_fn_sig = NULL;
    _module_functions[301].return_type_info = NULL;
    _module_functions[301].body = NULL;
    _module_functions[301].shadow_test = NULL;
    _module_functions[301].is_extern = false;
    _module_functions[301].returns_gc_managed = false;
    _module_functions[301].requires_manual_free = false;
    _module_functions[301].returns_borrowed = false;
    _module_functions[301].cleanup_function = NULL;
    _module_functions[301].params = &_module_params[289];
    _module_params[289].name = "c";
    _module_params[289].type = 0;
    _module_params[289].struct_type_name = NULL;
    _module_params[289].element_type = 21;
    _module_params[289].fn_sig = NULL;

    /* Function: keyword_group1 */
    _module_functions[302].name = "keyword_group1";
    _module_functions[302].param_count = 1;
    _module_functions[302].return_type = 0;
    _module_functions[302].return_struct_type_name = NULL;
    _module_functions[302].return_fn_sig = NULL;
    _module_functions[302].return_type_info = NULL;
    _module_functions[302].body = NULL;
    _module_functions[302].shadow_test = NULL;
    _module_functions[302].is_extern = false;
    _module_functions[302].returns_gc_managed = false;
    _module_functions[302].requires_manual_free = false;
    _module_functions[302].returns_borrowed = false;
    _module_functions[302].cleanup_function = NULL;
    _module_functions[302].params = &_module_params[290];
    _module_params[290].name = "s";
    _module_params[290].type = 4;
    _module_params[290].struct_type_name = NULL;
    _module_params[290].element_type = 21;
    _module_params[290].fn_sig = NULL;

    /* Function: keyword_group2 */
    _module_functions[303].name = "keyword_group2";
    _module_functions[303].param_count = 1;
    _module_functions[303].return_type = 0;
    _module_functions[303].return_struct_type_name = NULL;
    _module_functions[303].return_fn_sig = NULL;
    _module_functions[303].return_type_info = NULL;
    _module_functions[303].body = NULL;
    _module_functions[303].shadow_test = NULL;
    _module_functions[303].is_extern = false;
    _module_functions[303].returns_gc_managed = false;
    _module_functions[303].requires_manual_free = false;
    _module_functions[303].returns_borrowed = false;
    _module_functions[303].cleanup_function = NULL;
    _module_functions[303].params = &_module_params[291];
    _module_params[291].name = "s";
    _module_params[291].type = 4;
    _module_params[291].struct_type_name = NULL;
    _module_params[291].element_type = 21;
    _module_params[291].fn_sig = NULL;

    /* Function: keyword_group3 */
    _module_functions[304].name = "keyword_group3";
    _module_functions[304].param_count = 1;
    _module_functions[304].return_type = 0;
    _module_functions[304].return_struct_type_name = NULL;
    _module_functions[304].return_fn_sig = NULL;
    _module_functions[304].return_type_info = NULL;
    _module_functions[304].body = NULL;
    _module_functions[304].shadow_test = NULL;
    _module_functions[304].is_extern = false;
    _module_functions[304].returns_gc_managed = false;
    _module_functions[304].requires_manual_free = false;
    _module_functions[304].returns_borrowed = false;
    _module_functions[304].cleanup_function = NULL;
    _module_functions[304].params = &_module_params[292];
    _module_params[292].name = "s";
    _module_params[292].type = 4;
    _module_params[292].struct_type_name = NULL;
    _module_params[292].element_type = 21;
    _module_params[292].fn_sig = NULL;

    /* Function: keyword_group4 */
    _module_functions[305].name = "keyword_group4";
    _module_functions[305].param_count = 1;
    _module_functions[305].return_type = 0;
    _module_functions[305].return_struct_type_name = NULL;
    _module_functions[305].return_fn_sig = NULL;
    _module_functions[305].return_type_info = NULL;
    _module_functions[305].body = NULL;
    _module_functions[305].shadow_test = NULL;
    _module_functions[305].is_extern = false;
    _module_functions[305].returns_gc_managed = false;
    _module_functions[305].requires_manual_free = false;
    _module_functions[305].returns_borrowed = false;
    _module_functions[305].cleanup_function = NULL;
    _module_functions[305].params = &_module_params[293];
    _module_params[293].name = "s";
    _module_params[293].type = 4;
    _module_params[293].struct_type_name = NULL;
    _module_params[293].element_type = 21;
    _module_params[293].fn_sig = NULL;

    /* Function: keyword_group5 */
    _module_functions[306].name = "keyword_group5";
    _module_functions[306].param_count = 1;
    _module_functions[306].return_type = 0;
    _module_functions[306].return_struct_type_name = NULL;
    _module_functions[306].return_fn_sig = NULL;
    _module_functions[306].return_type_info = NULL;
    _module_functions[306].body = NULL;
    _module_functions[306].shadow_test = NULL;
    _module_functions[306].is_extern = false;
    _module_functions[306].returns_gc_managed = false;
    _module_functions[306].requires_manual_free = false;
    _module_functions[306].returns_borrowed = false;
    _module_functions[306].cleanup_function = NULL;
    _module_functions[306].params = &_module_params[294];
    _module_params[294].name = "s";
    _module_params[294].type = 4;
    _module_params[294].struct_type_name = NULL;
    _module_params[294].element_type = 21;
    _module_params[294].fn_sig = NULL;

    /* Function: keyword_or_identifier */
    _module_functions[307].name = "keyword_or_identifier";
    _module_functions[307].param_count = 1;
    _module_functions[307].return_type = 0;
    _module_functions[307].return_struct_type_name = NULL;
    _module_functions[307].return_fn_sig = NULL;
    _module_functions[307].return_type_info = NULL;
    _module_functions[307].body = NULL;
    _module_functions[307].shadow_test = NULL;
    _module_functions[307].is_extern = false;
    _module_functions[307].returns_gc_managed = false;
    _module_functions[307].requires_manual_free = false;
    _module_functions[307].returns_borrowed = false;
    _module_functions[307].cleanup_function = NULL;
    _module_functions[307].params = &_module_params[295];
    _module_params[295].name = "s";
    _module_params[295].type = 4;
    _module_params[295].struct_type_name = NULL;
    _module_params[295].element_type = 21;
    _module_params[295].fn_sig = NULL;

    /* Function: push_tok */
    _module_functions[308].name = "push_tok";
    _module_functions[308].param_count = 5;
    _module_functions[308].return_type = 6;
    _module_functions[308].return_struct_type_name = NULL;
    _module_functions[308].return_fn_sig = NULL;
    _module_functions[308].return_type_info = NULL;
    _module_functions[308].body = NULL;
    _module_functions[308].shadow_test = NULL;
    _module_functions[308].is_extern = false;
    _module_functions[308].returns_gc_managed = false;
    _module_functions[308].requires_manual_free = false;
    _module_functions[308].returns_borrowed = false;
    _module_functions[308].cleanup_function = NULL;
    _module_functions[308].params = &_module_params[296];
    _module_params[296].name = "tokens";
    _module_params[296].type = 15;
    _module_params[296].struct_type_name = "LexerToken";
    _module_params[296].element_type = 21;
    _module_params[296].fn_sig = NULL;
    _module_params[297].name = "token_type";
    _module_params[297].type = 0;
    _module_params[297].struct_type_name = NULL;
    _module_params[297].element_type = 21;
    _module_params[297].fn_sig = NULL;
    _module_params[298].name = "value";
    _module_params[298].type = 4;
    _module_params[298].struct_type_name = NULL;
    _module_params[298].element_type = 21;
    _module_params[298].fn_sig = NULL;
    _module_params[299].name = "line";
    _module_params[299].type = 0;
    _module_params[299].struct_type_name = NULL;
    _module_params[299].element_type = 21;
    _module_params[299].fn_sig = NULL;
    _module_params[300].name = "column";
    _module_params[300].type = 0;
    _module_params[300].struct_type_name = NULL;
    _module_params[300].element_type = 21;
    _module_params[300].fn_sig = NULL;

    /* Function: process_string */
    _module_functions[309].name = "process_string";
    _module_functions[309].param_count = 6;
    _module_functions[309].return_type = 0;
    _module_functions[309].return_struct_type_name = NULL;
    _module_functions[309].return_fn_sig = NULL;
    _module_functions[309].return_type_info = NULL;
    _module_functions[309].body = NULL;
    _module_functions[309].shadow_test = NULL;
    _module_functions[309].is_extern = false;
    _module_functions[309].returns_gc_managed = false;
    _module_functions[309].requires_manual_free = false;
    _module_functions[309].returns_borrowed = false;
    _module_functions[309].cleanup_function = NULL;
    _module_functions[309].params = &_module_params[301];
    _module_params[301].name = "source";
    _module_params[301].type = 4;
    _module_params[301].struct_type_name = NULL;
    _module_params[301].element_type = 21;
    _module_params[301].fn_sig = NULL;
    _module_params[302].name = "i";
    _module_params[302].type = 0;
    _module_params[302].struct_type_name = NULL;
    _module_params[302].element_type = 21;
    _module_params[302].fn_sig = NULL;
    _module_params[303].name = "len";
    _module_params[303].type = 0;
    _module_params[303].struct_type_name = NULL;
    _module_params[303].element_type = 21;
    _module_params[303].fn_sig = NULL;
    _module_params[304].name = "tokens";
    _module_params[304].type = 15;
    _module_params[304].struct_type_name = "LexerToken";
    _module_params[304].element_type = 21;
    _module_params[304].fn_sig = NULL;
    _module_params[305].name = "line";
    _module_params[305].type = 0;
    _module_params[305].struct_type_name = NULL;
    _module_params[305].element_type = 21;
    _module_params[305].fn_sig = NULL;
    _module_params[306].name = "column";
    _module_params[306].type = 0;
    _module_params[306].struct_type_name = NULL;
    _module_params[306].element_type = 21;
    _module_params[306].fn_sig = NULL;

    /* Function: process_number */
    _module_functions[310].name = "process_number";
    _module_functions[310].param_count = 6;
    _module_functions[310].return_type = 0;
    _module_functions[310].return_struct_type_name = NULL;
    _module_functions[310].return_fn_sig = NULL;
    _module_functions[310].return_type_info = NULL;
    _module_functions[310].body = NULL;
    _module_functions[310].shadow_test = NULL;
    _module_functions[310].is_extern = false;
    _module_functions[310].returns_gc_managed = false;
    _module_functions[310].requires_manual_free = false;
    _module_functions[310].returns_borrowed = false;
    _module_functions[310].cleanup_function = NULL;
    _module_functions[310].params = &_module_params[307];
    _module_params[307].name = "source";
    _module_params[307].type = 4;
    _module_params[307].struct_type_name = NULL;
    _module_params[307].element_type = 21;
    _module_params[307].fn_sig = NULL;
    _module_params[308].name = "i";
    _module_params[308].type = 0;
    _module_params[308].struct_type_name = NULL;
    _module_params[308].element_type = 21;
    _module_params[308].fn_sig = NULL;
    _module_params[309].name = "len";
    _module_params[309].type = 0;
    _module_params[309].struct_type_name = NULL;
    _module_params[309].element_type = 21;
    _module_params[309].fn_sig = NULL;
    _module_params[310].name = "tokens";
    _module_params[310].type = 15;
    _module_params[310].struct_type_name = "LexerToken";
    _module_params[310].element_type = 21;
    _module_params[310].fn_sig = NULL;
    _module_params[311].name = "line";
    _module_params[311].type = 0;
    _module_params[311].struct_type_name = NULL;
    _module_params[311].element_type = 21;
    _module_params[311].fn_sig = NULL;
    _module_params[312].name = "column";
    _module_params[312].type = 0;
    _module_params[312].struct_type_name = NULL;
    _module_params[312].element_type = 21;
    _module_params[312].fn_sig = NULL;

    /* Function: process_grammar_body */
    _module_functions[311].name = "process_grammar_body";
    _module_functions[311].param_count = 6;
    _module_functions[311].return_type = 0;
    _module_functions[311].return_struct_type_name = NULL;
    _module_functions[311].return_fn_sig = NULL;
    _module_functions[311].return_type_info = NULL;
    _module_functions[311].body = NULL;
    _module_functions[311].shadow_test = NULL;
    _module_functions[311].is_extern = false;
    _module_functions[311].returns_gc_managed = false;
    _module_functions[311].requires_manual_free = false;
    _module_functions[311].returns_borrowed = false;
    _module_functions[311].cleanup_function = NULL;
    _module_functions[311].params = &_module_params[313];
    _module_params[313].name = "source";
    _module_params[313].type = 4;
    _module_params[313].struct_type_name = NULL;
    _module_params[313].element_type = 21;
    _module_params[313].fn_sig = NULL;
    _module_params[314].name = "i";
    _module_params[314].type = 0;
    _module_params[314].struct_type_name = NULL;
    _module_params[314].element_type = 21;
    _module_params[314].fn_sig = NULL;
    _module_params[315].name = "len";
    _module_params[315].type = 0;
    _module_params[315].struct_type_name = NULL;
    _module_params[315].element_type = 21;
    _module_params[315].fn_sig = NULL;
    _module_params[316].name = "tokens";
    _module_params[316].type = 15;
    _module_params[316].struct_type_name = "LexerToken";
    _module_params[316].element_type = 21;
    _module_params[316].fn_sig = NULL;
    _module_params[317].name = "line";
    _module_params[317].type = 0;
    _module_params[317].struct_type_name = NULL;
    _module_params[317].element_type = 21;
    _module_params[317].fn_sig = NULL;
    _module_params[318].name = "column";
    _module_params[318].type = 0;
    _module_params[318].struct_type_name = NULL;
    _module_params[318].element_type = 21;
    _module_params[318].fn_sig = NULL;

    /* Function: process_identifier */
    _module_functions[312].name = "process_identifier";
    _module_functions[312].param_count = 6;
    _module_functions[312].return_type = 0;
    _module_functions[312].return_struct_type_name = NULL;
    _module_functions[312].return_fn_sig = NULL;
    _module_functions[312].return_type_info = NULL;
    _module_functions[312].body = NULL;
    _module_functions[312].shadow_test = NULL;
    _module_functions[312].is_extern = false;
    _module_functions[312].returns_gc_managed = false;
    _module_functions[312].requires_manual_free = false;
    _module_functions[312].returns_borrowed = false;
    _module_functions[312].cleanup_function = NULL;
    _module_functions[312].params = &_module_params[319];
    _module_params[319].name = "source";
    _module_params[319].type = 4;
    _module_params[319].struct_type_name = NULL;
    _module_params[319].element_type = 21;
    _module_params[319].fn_sig = NULL;
    _module_params[320].name = "i";
    _module_params[320].type = 0;
    _module_params[320].struct_type_name = NULL;
    _module_params[320].element_type = 21;
    _module_params[320].fn_sig = NULL;
    _module_params[321].name = "len";
    _module_params[321].type = 0;
    _module_params[321].struct_type_name = NULL;
    _module_params[321].element_type = 21;
    _module_params[321].fn_sig = NULL;
    _module_params[322].name = "tokens";
    _module_params[322].type = 15;
    _module_params[322].struct_type_name = "LexerToken";
    _module_params[322].element_type = 21;
    _module_params[322].fn_sig = NULL;
    _module_params[323].name = "line";
    _module_params[323].type = 0;
    _module_params[323].struct_type_name = NULL;
    _module_params[323].element_type = 21;
    _module_params[323].fn_sig = NULL;
    _module_params[324].name = "column";
    _module_params[324].type = 0;
    _module_params[324].struct_type_name = NULL;
    _module_params[324].element_type = 21;
    _module_params[324].fn_sig = NULL;

    /* Function: process_char_literal */
    _module_functions[313].name = "process_char_literal";
    _module_functions[313].param_count = 6;
    _module_functions[313].return_type = 0;
    _module_functions[313].return_struct_type_name = NULL;
    _module_functions[313].return_fn_sig = NULL;
    _module_functions[313].return_type_info = NULL;
    _module_functions[313].body = NULL;
    _module_functions[313].shadow_test = NULL;
    _module_functions[313].is_extern = false;
    _module_functions[313].returns_gc_managed = false;
    _module_functions[313].requires_manual_free = false;
    _module_functions[313].returns_borrowed = false;
    _module_functions[313].cleanup_function = NULL;
    _module_functions[313].params = &_module_params[325];
    _module_params[325].name = "source";
    _module_params[325].type = 4;
    _module_params[325].struct_type_name = NULL;
    _module_params[325].element_type = 21;
    _module_params[325].fn_sig = NULL;
    _module_params[326].name = "i";
    _module_params[326].type = 0;
    _module_params[326].struct_type_name = NULL;
    _module_params[326].element_type = 21;
    _module_params[326].fn_sig = NULL;
    _module_params[327].name = "len";
    _module_params[327].type = 0;
    _module_params[327].struct_type_name = NULL;
    _module_params[327].element_type = 21;
    _module_params[327].fn_sig = NULL;
    _module_params[328].name = "tokens";
    _module_params[328].type = 15;
    _module_params[328].struct_type_name = "LexerToken";
    _module_params[328].element_type = 21;
    _module_params[328].fn_sig = NULL;
    _module_params[329].name = "line";
    _module_params[329].type = 0;
    _module_params[329].struct_type_name = NULL;
    _module_params[329].element_type = 21;
    _module_params[329].fn_sig = NULL;
    _module_params[330].name = "column";
    _module_params[330].type = 0;
    _module_params[330].struct_type_name = NULL;
    _module_params[330].element_type = 21;
    _module_params[330].fn_sig = NULL;

    /* Function: emit_fstring_part_tokens */
    _module_functions[314].name = "emit_fstring_part_tokens";
    _module_functions[314].param_count = 7;
    _module_functions[314].return_type = 6;
    _module_functions[314].return_struct_type_name = NULL;
    _module_functions[314].return_fn_sig = NULL;
    _module_functions[314].return_type_info = NULL;
    _module_functions[314].body = NULL;
    _module_functions[314].shadow_test = NULL;
    _module_functions[314].is_extern = false;
    _module_functions[314].returns_gc_managed = false;
    _module_functions[314].requires_manual_free = false;
    _module_functions[314].returns_borrowed = false;
    _module_functions[314].cleanup_function = NULL;
    _module_functions[314].params = &_module_params[331];
    _module_params[331].name = "part_text";
    _module_params[331].type = 4;
    _module_params[331].struct_type_name = NULL;
    _module_params[331].element_type = 21;
    _module_params[331].fn_sig = NULL;
    _module_params[332].name = "is_expr";
    _module_params[332].type = 0;
    _module_params[332].struct_type_name = NULL;
    _module_params[332].element_type = 21;
    _module_params[332].fn_sig = NULL;
    _module_params[333].name = "tokens";
    _module_params[333].type = 15;
    _module_params[333].struct_type_name = "LexerToken";
    _module_params[333].element_type = 21;
    _module_params[333].fn_sig = NULL;
    _module_params[334].name = "diags";
    _module_params[334].type = 15;
    _module_params[334].struct_type_name = "CompilerDiagnostic";
    _module_params[334].element_type = 21;
    _module_params[334].fn_sig = NULL;
    _module_params[335].name = "file_name";
    _module_params[335].type = 4;
    _module_params[335].struct_type_name = NULL;
    _module_params[335].element_type = 21;
    _module_params[335].fn_sig = NULL;
    _module_params[336].name = "line";
    _module_params[336].type = 0;
    _module_params[336].struct_type_name = NULL;
    _module_params[336].element_type = 21;
    _module_params[336].fn_sig = NULL;
    _module_params[337].name = "column";
    _module_params[337].type = 0;
    _module_params[337].struct_type_name = NULL;
    _module_params[337].element_type = 21;
    _module_params[337].fn_sig = NULL;

    /* Function: process_fstring */
    _module_functions[315].name = "process_fstring";
    _module_functions[315].param_count = 8;
    _module_functions[315].return_type = 0;
    _module_functions[315].return_struct_type_name = NULL;
    _module_functions[315].return_fn_sig = NULL;
    _module_functions[315].return_type_info = NULL;
    _module_functions[315].body = NULL;
    _module_functions[315].shadow_test = NULL;
    _module_functions[315].is_extern = false;
    _module_functions[315].returns_gc_managed = false;
    _module_functions[315].requires_manual_free = false;
    _module_functions[315].returns_borrowed = false;
    _module_functions[315].cleanup_function = NULL;
    _module_functions[315].params = &_module_params[338];
    _module_params[338].name = "source";
    _module_params[338].type = 4;
    _module_params[338].struct_type_name = NULL;
    _module_params[338].element_type = 21;
    _module_params[338].fn_sig = NULL;
    _module_params[339].name = "i";
    _module_params[339].type = 0;
    _module_params[339].struct_type_name = NULL;
    _module_params[339].element_type = 21;
    _module_params[339].fn_sig = NULL;
    _module_params[340].name = "len";
    _module_params[340].type = 0;
    _module_params[340].struct_type_name = NULL;
    _module_params[340].element_type = 21;
    _module_params[340].fn_sig = NULL;
    _module_params[341].name = "tokens";
    _module_params[341].type = 15;
    _module_params[341].struct_type_name = "LexerToken";
    _module_params[341].element_type = 21;
    _module_params[341].fn_sig = NULL;
    _module_params[342].name = "diags";
    _module_params[342].type = 15;
    _module_params[342].struct_type_name = "CompilerDiagnostic";
    _module_params[342].element_type = 21;
    _module_params[342].fn_sig = NULL;
    _module_params[343].name = "file_name";
    _module_params[343].type = 4;
    _module_params[343].struct_type_name = NULL;
    _module_params[343].element_type = 21;
    _module_params[343].fn_sig = NULL;
    _module_params[344].name = "line";
    _module_params[344].type = 0;
    _module_params[344].struct_type_name = NULL;
    _module_params[344].element_type = 21;
    _module_params[344].fn_sig = NULL;
    _module_params[345].name = "column";
    _module_params[345].type = 0;
    _module_params[345].struct_type_name = NULL;
    _module_params[345].element_type = 21;
    _module_params[345].fn_sig = NULL;

    /* Function: tokenize_string */
    _module_functions[316].name = "tokenize_string";
    _module_functions[316].param_count = 3;
    _module_functions[316].return_type = 15;
    _module_functions[316].return_struct_type_name = "LexerToken";
    _module_functions[316].return_fn_sig = NULL;
    _module_functions[316].return_type_info = NULL;
    _module_functions[316].body = NULL;
    _module_functions[316].shadow_test = NULL;
    _module_functions[316].is_extern = false;
    _module_functions[316].returns_gc_managed = false;
    _module_functions[316].requires_manual_free = false;
    _module_functions[316].returns_borrowed = false;
    _module_functions[316].cleanup_function = NULL;
    _module_functions[316].params = &_module_params[346];
    _module_params[346].name = "source";
    _module_params[346].type = 4;
    _module_params[346].struct_type_name = NULL;
    _module_params[346].element_type = 21;
    _module_params[346].fn_sig = NULL;
    _module_params[347].name = "file_name";
    _module_params[347].type = 4;
    _module_params[347].struct_type_name = NULL;
    _module_params[347].element_type = 21;
    _module_params[347].fn_sig = NULL;
    _module_params[348].name = "diags";
    _module_params[348].type = 15;
    _module_params[348].struct_type_name = "CompilerDiagnostic";
    _module_params[348].element_type = 21;
    _module_params[348].fn_sig = NULL;

    /* Function: tokenize_file */
    _module_functions[317].name = "tokenize_file";
    _module_functions[317].param_count = 2;
    _module_functions[317].return_type = 15;
    _module_functions[317].return_struct_type_name = "LexerToken";
    _module_functions[317].return_fn_sig = NULL;
    _module_functions[317].return_type_info = NULL;
    _module_functions[317].body = NULL;
    _module_functions[317].shadow_test = NULL;
    _module_functions[317].is_extern = false;
    _module_functions[317].returns_gc_managed = false;
    _module_functions[317].requires_manual_free = false;
    _module_functions[317].returns_borrowed = false;
    _module_functions[317].cleanup_function = NULL;
    _module_functions[317].params = &_module_params[349];
    _module_params[349].name = "path";
    _module_params[349].type = 4;
    _module_params[349].struct_type_name = NULL;
    _module_params[349].element_type = 21;
    _module_params[349].fn_sig = NULL;
    _module_params[350].name = "diags";
    _module_params[350].type = 15;
    _module_params[350].struct_type_name = "CompilerDiagnostic";
    _module_params[350].element_type = 21;
    _module_params[350].fn_sig = NULL;

}

ModuleMetadata _module_metadata_lexer = {
    .module_name = "lexer",
    .function_count = 318,
    .functions = _module_functions,
    .struct_count = 47,
    .structs = NULL,  /* TODO: serialize structs */
    .enum_count = 5,
    .enums = NULL,  /* TODO: serialize enums */
    .union_count = 0,
    .unions = NULL  /* TODO: serialize unions */
};

/* Constants from module */
static const int64_t _module_const_lexer_length = 281474859142960LL;
static const int64_t _module_const_lexer_code = 7738436698542336372LL;
static const int64_t _module_const_lexer_line = 0LL;
static const int64_t _module_const_lexer_column = 0LL;
static const int64_t _module_const_lexer_phase = 0LL;
static const int64_t _module_const_lexer_severity = 0LL;
static const int64_t _module_const_lexer_index = 0LL;
static const int64_t _module_const_lexer_count = 205191309161200LL;
static const int64_t _module_const_lexer_pi = 0LL;
static const int64_t _module_const_lexer_ti = 0LL;
static const int64_t _module_const_lexer_plen = 281474859142944LL;
static const int64_t _module_const_lexer_tlen = 281474859142944LL;
static const int64_t _module_const_lexer_pc = 281474859142944LL;
static const int64_t _module_const_lexer_n = 281474859142944LL;
static const int64_t _module_const_lexer_c = 0LL;
static const int64_t _module_const_lexer_t1 = 205191307986800LL;
static const int64_t _module_const_lexer_t2 = 281474859145376LL;
static const int64_t _module_const_lexer_t3 = 205191308139904LL;
static const int64_t _module_const_lexer_t4 = 16LL;
static const int64_t _module_const_lexer_t5 = 205191322607312LL;
static const int64_t _module_const_lexer_token_type = 0LL;
static const int64_t _module_const_lexer_i = 0LL;
static const int64_t _module_const_lexer_len = 0LL;
static const int64_t _module_const_lexer_start = 274120844928752LL;
static const int64_t _module_const_lexer_str_length = 16LL;
static const int64_t _module_const_lexer_float_length = 32LL;
static const int64_t _module_const_lexer_num_length = 16LL;
static const int64_t _module_const_lexer_body_start = 274120844928752LL;
static const int64_t _module_const_lexer_body_len = 274120844928752LL;
static const int64_t _module_const_lexer_id_length = 274120844928752LL;
static const int64_t _module_const_lexer_esc = 0LL;
static const int64_t _module_const_lexer_is_expr = 0LL;
static const int64_t _module_const_lexer_expr_start = 281474859140192LL;
static const int64_t _module_const_lexer_cc = 281474859138384LL;
static const int64_t _module_const_lexer_last_is_expr = 0LL;

