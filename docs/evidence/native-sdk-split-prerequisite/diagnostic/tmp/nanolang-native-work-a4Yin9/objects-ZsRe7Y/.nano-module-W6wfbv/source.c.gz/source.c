#define _GNU_SOURCE 1
#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <math.h>
#include "runtime/nl_string.h"
#ifdef __wasm__
#  include "runtime/refcount_gc.h"
#  define gc_alloc_string(len)   nl_rc_str_new(NULL, (len))
#  define gc_retain(p)           nl_rc_retain(p)
#  define gc_release(p)          nl_rc_release(p)
#else
#  include "runtime/gc.h"
#endif
#include "runtime/dyn_array.h"
#include "runtime/native_array_abi.h"
#ifndef __wasm__
#  include "nanolang.h"
#endif

/* nanolang runtime */
#include "runtime/list_int.h"
#include "runtime/native_record_list.h"
#include "runtime/list_string.h"
#include "runtime/list_token.h"
#include "runtime/token_helpers.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <libgen.h>
#include <sys/wait.h>
#include <spawn.h>
#include <fcntl.h>
/* fs.h forward declarations */
DynArray* fs_walkdir(const char* root);
const char* path_normalize(const char* path);
const char* path_join(const char* a, const char* b);
const char* path_basename(const char* path);
const char* path_dirname(const char* path);
int64_t  fs_mkdir_p(const char* path);
const char* path_relpath(const char* target, const char* base);
const char* file_read(const char* path);
int64_t  file_write(const char* path, const char* content);
int64_t  file_append(const char* path, const char* content);
bool     file_exists(const char* path);
int64_t  file_delete(const char* path);
int64_t  file_copy(const char* src, const char* dst);
int64_t  dir_copy(const char* src, const char* dst);
int64_t  nl_os_process_spawn(const char* command);
int64_t  nl_os_process_is_running(int64_t pid);
int64_t  nl_os_process_wait(int64_t pid);
DynArray* nl_os_process_spawn_with_pipes(const char* command);
const char* nl_os_fd_read_available(int64_t fd);
int64_t  nl_os_fd_close(int64_t fd);

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-const-variable"

/* ========== OS Standard Library ========== */

#include "runtime/file_text.h"
static const char* nl_os_file_read(const char* path) {
    char* text = nl_read_file_text(path);
    if (!text) return gc_alloc_string(0);
    size_t length = strlen(text);
    char* result = gc_alloc_string(length);
    if (result) memcpy(result, text, length + 1);
    free(text);
    return result;
}

#include "runtime/file_bytes.h"
static DynArray* nl_os_file_read_bytes(const char* path) {
    return nl_read_file_bytes(path);
}

#include "runtime/file_write.h"
static int64_t nl_os_file_write(const char* path, const char* content) {
    return nl_write_file_text(path, content, "w");
}

static int64_t nl_os_file_append(const char* path, const char* content) {
    return nl_write_file_text(path, content, "a");
}

static int64_t nl_os_file_remove(const char* path) {
    return remove(path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_delete(const char* path) {
    return nl_os_file_remove(path);
}

static int64_t nl_os_file_rename(const char* old_path, const char* new_path) {
    return rename(old_path, new_path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_size(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (int64_t)st.st_size;
}

static bool nl_os_file_exists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static char* nl_os_tmp_dir(void) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    size_t len = strlen(tmp);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, tmp, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_";
    char templ[1024];
    snprintf(templ, sizeof(templ), "%s/%sXXXXXX", tmp, p);
    int fd = mkstemp(templ);
    if (fd < 0) return gc_alloc_string(0);
    close(fd);
    size_t len = strlen(templ);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, templ, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp_dir(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_dir_";
    char path[1024];
    for (int i = 0; i < 100; i++) {
        snprintf(path, sizeof(path), "%s/%s%lld_%d", tmp, p, (long long)time(NULL), i);
        if (mkdir(path, 0700) == 0) {
            size_t len = strlen(path);
            char* out = gc_alloc_string(len);
            if (!out) return gc_alloc_string(0);
            memcpy(out, path, len);
            out[len] = '\0';
            return out;
        }
    }
    return gc_alloc_string(0);
}

static int64_t nl_os_dir_create(const char* path) {
    return mkdir(path, 0755) == 0 ? 0 : -1;
}

static int64_t nl_os_dir_remove(const char* path) {
    return rmdir(path) == 0 ? 0 : -1;
}

static char* nl_os_dir_list(const char* path) {
    DIR* dir = opendir(path);
    if (!dir) return gc_alloc_string(0);
    size_t capacity = 4096;
    size_t used = 0;
    char* buffer = gc_alloc_string(capacity);
    if (!buffer) { closedir(dir); return gc_alloc_string(0); }
    buffer[0] = '\0';
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        size_t name_len = strlen(entry->d_name);
        size_t needed = used + name_len + 2; /* +1 for newline, +1 for null */
        if (needed > capacity) {
            capacity = needed * 2;
            char* new_buffer = gc_alloc_string(capacity);
            if (!new_buffer) { gc_release(buffer); closedir(dir); return gc_alloc_string(0); }
            memcpy(new_buffer, buffer, used);
            gc_release(buffer);
            buffer = new_buffer;
        }
        memcpy(buffer + used, entry->d_name, name_len);
        used += name_len;
        buffer[used++] = '\n';
        buffer[used] = '\0';
    }
    closedir(dir);
    return buffer;
}

static bool nl_os_dir_exists(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_getcwd(void) {
    char temp_buffer[1024];
    if (getcwd(temp_buffer, sizeof(temp_buffer)) == NULL) {
        return gc_alloc_string(0);
    }
    size_t len = strlen(temp_buffer);
    char* buffer = gc_alloc_string(len);
    if (buffer) memcpy(buffer, temp_buffer, len + 1);
    return buffer ? buffer : gc_alloc_string(0);
}

static int64_t nl_os_chdir(const char* path) {
    return chdir(path) == 0 ? 0 : -1;
}

#include "runtime/directory_walk.h"
static DynArray* nl_os_walkdir(const char* root) {
    return nl_fs_walkdir(root);
}

static bool nl_os_path_isfile(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISREG(st.st_mode);
}

static bool nl_os_path_isdir(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_path_join(const char* a, const char* b) {
    size_t len_a = strlen(a);
    size_t len_b = strlen(b);
    size_t total_len = len_a + len_b + 2; /* +1 for '/', +1 for null */
    char* buffer = gc_alloc_string(total_len);
    if (!buffer) return gc_alloc_string(0);
    if (len_a == 0) {
        snprintf(buffer, total_len, "%s", b);
    } else if (a[len_a - 1] == '/') {
        snprintf(buffer, total_len, "%s%s", a, b);
    } else {
        snprintf(buffer, total_len, "%s/%s", a, b);
    }
    return buffer;
}

static char* nl_os_path_basename(const char* path) {
    char* path_copy = strdup(path);
    char* base = basename(path_copy);
    size_t len = strlen(base);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, base, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

static char* nl_os_path_dirname(const char* path) {
    char* path_copy = strdup(path);
    char* dir = dirname(path_copy);
    size_t len = strlen(dir);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, dir, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

#include "runtime/path_normalize.h"
static char* nl_os_path_normalize(const char* path) {
    if (!path) return gc_alloc_string(0);
    char* normalized = nl_normalize_path(path);
    if (!normalized) return gc_alloc_string(0);
    size_t length = strlen(normalized);
    char* out = gc_alloc_string(length);
    if (out) memcpy(out, normalized, length + 1);
    free(normalized);
    return out ? out : gc_alloc_string(0);
}

static int64_t nl_os_system(const char* command) {
    return system(command);
}

static void nl_os_exit(int64_t code) {
    exit((int)code);
}

static const char* nl_os_getenv(const char* name) {
    const char* value = getenv(name);
    return value ? value : "";
}

/* system() wrapper - stdlib system() available via stdlib.h */
static inline int64_t nl_exec_shell(const char* cmd) {
    return (int64_t)system(cmd);
}

/* isatty() wrapper - avoids int64_t type clash with unistd.h */
static inline int64_t nl_isatty(int64_t fd) {
    return (int64_t)isatty((int)fd);
}

/* Capture stdout from a shell command */
static inline const char* nl_exec_capture(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "";
    char* out = (char*)malloc(65536);
    if (!out) { pclose(pipe); return ""; }
    size_t total = 0;
    while (total < 65535) {
        size_t n = fread(out + total, 1, 65535 - total, pipe);
        if (n == 0) break;
        total += n;
    }
    out[total] = '\0';
    pclose(pipe);
    return out;
}

#include "runtime/process_capture.h"
#ifndef NANOLANG_STD_PROCESS_H
static DynArray* nl_os_process_run(const char* command) {
    return nl_process_run_capture(command);
}
#endif /* NANOLANG_STD_PROCESS_H */

/* ========== End OS Standard Library ========== */

/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Advanced String Operations ========== */

static int64_t char_at(const char* s, int64_t index) {
    /* Safety: Bound string scan to 64MB */
    int len = strnlen(s, 64*1024*1024);
    if (index < 0 || index >= len) {
        fprintf(stderr, "Error: Index %lld out of bounds (string length %d)\n", (long long)index, len);
        return 0;
    }
    return (unsigned char)s[index];
}

static char* string_from_char(int64_t c) {
    char* buffer = gc_alloc_string(1);
    if (!buffer) return "";
    buffer[0] = (char)c;
    buffer[1] = '\0';
    return buffer;
}

static bool is_digit(int64_t c) {
    return c >= '0' && c <= '9';
}

static bool is_alpha(int64_t c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_alnum(int64_t c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_whitespace(int64_t c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

static bool is_upper(int64_t c) {
    return c >= 'A' && c <= 'Z';
}

static bool is_lower(int64_t c) {
    return c >= 'a' && c <= 'z';
}

static char* int_to_string(int64_t n) {
    char* buffer = gc_alloc_string(31);
    if (!buffer) return "";
    snprintf(buffer, 32, "%lld", (long long)n);
    return buffer;
}

static char* float_to_string(double x) {
    char* buffer = gc_alloc_string(63);
    if (!buffer) return "";
    nano_rt_f64_format(buffer, 64, x);
    /* Ensure at least one decimal place for whole-number floats
     * so 0.0 -> "0.0" rather than "0" */
    if (!strchr(buffer, '.') && !strchr(buffer, 'e')
            && !strchr(buffer, 'n') && !strchr(buffer, 'i')) {
        size_t len = strlen(buffer);
        if (len + 2 < 64) { buffer[len] = '.'; buffer[len+1] = '0'; buffer[len+2] = '\0'; }
    }
    return buffer;
}

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} nl_fmt_sb_t;

static void nl_fmt_sb_ensure(nl_fmt_sb_t *sb, size_t extra) {
    if (!sb) return;
    size_t needed = sb->len + extra + 1;
    if (needed <= sb->cap) return;
    size_t new_cap = sb->cap ? sb->cap : 128;
    while (new_cap < needed) new_cap *= 2;
    char *new_buf = realloc(sb->buf, new_cap);
    if (!new_buf) return;
    sb->buf = new_buf;
    sb->cap = new_cap;
}

static nl_fmt_sb_t nl_fmt_sb_new(size_t initial_cap) {
    nl_fmt_sb_t sb = {0};
    sb.cap = initial_cap ? initial_cap : 128;
    sb.buf = (char*)malloc(sb.cap);
    sb.len = 0;
    if (sb.buf) sb.buf[0] = '\0';
    return sb;
}

static void nl_fmt_sb_append_cstr(nl_fmt_sb_t *sb, const char *s) {
    if (!sb || !s) return;
    size_t n = strlen(s);
    nl_fmt_sb_ensure(sb, n);
    if (!sb->buf) return;
    memcpy(sb->buf + sb->len, s, n);
    sb->len += n;
    sb->buf[sb->len] = '\0';
}

static void nl_fmt_sb_append_char(nl_fmt_sb_t *sb, char c) {
    if (!sb) return;
    nl_fmt_sb_ensure(sb, 1);
    if (!sb->buf) return;
    sb->buf[sb->len++] = c;
    sb->buf[sb->len] = '\0';
}

static char* nl_fmt_sb_build(nl_fmt_sb_t *sb) {
    if (!sb || !sb->buf) return "";
    return sb->buf;
}

static const char* nl_to_string_int(int64_t v) { return int_to_string(v); }
static const char* nl_to_string_float(double v) { return float_to_string(v); }
static const char* nl_to_string_bool(bool v) { return v ? "true" : "false"; }
static const char* nl_to_string_string(const char* v) { return v ? v : ""; }

static const char* nl_to_string_array(DynArray* arr) {
    if (!arr) return "[]";
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_char(&sb, '[');
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    for (int64_t i = 0; i < len; i++) {
        if (i > 0) nl_fmt_sb_append_cstr(&sb, ", ");
        switch (t) {
            case ELEM_INT: {
                const char* s = nl_to_string_int(dyn_array_get_int(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_U8: {
                const char* s = nl_to_string_int((int64_t)dyn_array_get_u8(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_FLOAT: {
                const char* s = nl_to_string_float(dyn_array_get_float(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_BOOL: {
                nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(dyn_array_get_bool(arr, i)));
                break;
            }
            case ELEM_STRING: {
                nl_fmt_sb_append_char(&sb, '"');
                nl_fmt_sb_append_cstr(&sb, nl_to_string_string(dyn_array_get_string(arr, i)));
                nl_fmt_sb_append_char(&sb, '"');
                break;
            }
            case ELEM_ARRAY: {
                const char* s = nl_to_string_array(dyn_array_get_array(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_STRUCT: {
                nl_fmt_sb_append_cstr(&sb, "<struct>");
                break;
            }
            default: {
                nl_fmt_sb_append_cstr(&sb, "?");
                break;
            }
        }
    }
    nl_fmt_sb_append_char(&sb, ']');
    return nl_fmt_sb_build(&sb);
}

static const char* nl_str_concat(const char* s1, const char* s2);
static DynArray* nl_array_add(DynArray* a, DynArray* b);
static DynArray* nl_array_sub(DynArray* a, DynArray* b);
static DynArray* nl_array_mul(DynArray* a, DynArray* b);
static DynArray* nl_array_div(DynArray* a, DynArray* b);
static DynArray* nl_array_mod(DynArray* a, DynArray* b);

static void nl_array_assert_compatible(DynArray* a, DynArray* b) {
    assert(a && b);
    assert(dyn_array_length(a) == dyn_array_length(b));
    assert(dyn_array_get_elem_type(a) == dyn_array_get_elem_type(b));
}

static DynArray* nl_array_add(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)+dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_STRING: for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), dyn_array_get_string(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_add(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_add: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_sub(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)-dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_sub(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_sub: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mul(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)*dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mul(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mul: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_div(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)/dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_div(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_div: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mod(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)%dyn_array_get_int(b,i)); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mod(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mod: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_add_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) + s);
    return out;
}

static DynArray* nl_array_radd_scalar_int(int64_t s, DynArray* a) { return nl_array_add_scalar_int(a, s); }

static DynArray* nl_array_sub_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) - s);
    return out;
}

static DynArray* nl_array_rsub_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s - dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mul_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) * s);
    return out;
}

static DynArray* nl_array_rmul_scalar_int(int64_t s, DynArray* a) { return nl_array_mul_scalar_int(a, s); }

static DynArray* nl_array_div_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) / s);
    return out;
}

static DynArray* nl_array_rdiv_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s / dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mod_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) % s);
    return out;
}

static DynArray* nl_array_rmod_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s % dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_add_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_float(double s, DynArray* a) { return nl_array_add_scalar_float(a, s); }

static DynArray* nl_array_sub_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rsub_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_mul_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rmul_scalar_float(double s, DynArray* a) { return nl_array_mul_scalar_float(a, s); }

static DynArray* nl_array_div_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rdiv_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_add_scalar_string(DynArray* a, const char* s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_string(const char* s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(s, dyn_array_get_string(a,i)));
    return out;
}

static int64_t string_to_int(const char* s) {
    return strtoll(s, NULL, 10);
}

#include "runtime/binary64_parse.h"
static double string_to_float(const char* s) { return nl_binary64_prefix(s); }

static int64_t digit_value(int64_t c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    return -1;
}

static int64_t char_to_lower(int64_t c) {
    if (c >= 'A' && c <= 'Z') {
    return c + 32;
    }
    return c;
}

static int64_t char_to_upper(int64_t c) {
    if (c >= 'a' && c <= 'z') {
        return c - 32;
    }
    return c;
}

#include "runtime/string_edges.h"
static const char* nl_str_trim_left(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t start = 0;
    while (start < len && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n' || s[start] == '\r')) start++;
    size_t new_len = len - start;
    char* result = gc_alloc_string(new_len);
    if (!result) return "";
    memcpy(result, s + start, new_len);
    result[new_len] = '\0';
    return result;
}

static const char* nl_str_trim_right(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t end = len;
    while (end > 0 && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n' || s[end-1] == '\r')) end--;
    char* result = gc_alloc_string(end);
    if (!result) return "";
    memcpy(result, s, end);
    result[end] = '\0';
    return result;
}

static const char* nl_str_to_lower(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_to_upper(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_replace(const char* s, const char* old_str, const char* new_str) {
    if (!s || !old_str || !new_str) return s ? s : "";
    size_t old_len = strlen(old_str);
    size_t s_len = strlen(s);
    if (old_len == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    size_t new_len = strlen(new_str);
    int64_t count = 0;
    const char* p = s;
    const char* found;
    while ((found = strstr(p, old_str)) != NULL) { count++; p = found + old_len; }
    if (count == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    int64_t result_len = (int64_t)s_len + count * ((int64_t)new_len - (int64_t)old_len);
    if (result_len < 0) return "";
    char* result = gc_alloc_string((size_t)result_len);
    if (!result) return "";
    const char* src = s;
    char* dst = result;
    while ((found = strstr(src, old_str)) != NULL) {
        size_t seg_len = (size_t)(found - src);
        memcpy(dst, src, seg_len);
        dst += seg_len;
        memcpy(dst, new_str, new_len);
        dst += new_len;
        src = found + old_len;
    }
    size_t rest = strlen(src);
    memcpy(dst, src, rest);
    dst[rest] = '\0';
    return result;
}

static DynArray* nl_str_split(const char* str, const char* delim) {
    DynArray* result = dyn_array_new(ELEM_STRING);
    if (!result) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    if (!str) return result;
    size_t delim_len = strlen(delim);
    if (delim_len == 0) {
        size_t str_len = strnlen(str, 64*1024*1024);
        for (size_t i = 0; i < str_len; i++) {
            char* ch = gc_alloc_string(1);
            if (!ch) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
            ch[0] = str[i]; ch[1] = '\0';
            dyn_array_push_string(result, ch);
        }
        return result;
    }
    const char* start = str;
    const char* found;
    while ((found = strstr(start, delim)) != NULL) {
        size_t seg_len = (size_t)(found - start);
        char* seg = gc_alloc_string(seg_len);
        if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
        memcpy(seg, start, seg_len);
        seg[seg_len] = '\0';
        dyn_array_push_string(result, seg);
        start = found + delim_len;
    }
    size_t rest_len = strlen(start);
    char* seg = gc_alloc_string(rest_len);
    if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    {
        memcpy(seg, start, rest_len);
        seg[rest_len] = '\0';
        dyn_array_push_string(result, seg);
    }
    return result;
}

static const char* nl_str_join(DynArray* arr, const char* delim) {
    if (!arr) return "";
    int64_t count = dyn_array_length(arr);
    if (count == 0) return "";
    size_t delim_len = strlen(delim);
    size_t total = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) total += strlen(s);
        if (i < count - 1) total += delim_len;
    }
    char* result = gc_alloc_string(total);
    if (!result) return "";
    size_t pos = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) { size_t slen = strlen(s); memcpy(result + pos, s, slen); pos += slen; }
        if (i < count - 1) { memcpy(result + pos, delim, delim_len); pos += delim_len; }
    }
    result[pos] = '\0';
    return result;
}

static const char* nl_format(const char *fmt, int n_args, ...) {
    if (!fmt) return "";
    va_list ap;
    va_start(ap, n_args);
    nl_fmt_sb_t out = nl_fmt_sb_new(128);
    const char *p = fmt;
    int used = 0;
    while (*p) {
        if (*p == '%' && (p[1] == 's' || p[1] == 'd' || p[1] == 'f' || p[1] == 'g') && used < n_args) {
            const char *arg = va_arg(ap, const char *);
            if (arg) nl_fmt_sb_append_cstr(&out, arg);
            used++;
            p += 2;
        } else {
            nl_fmt_sb_append_char(&out, *p++);
        }
    }
    va_end(ap);
    char *result = gc_alloc_string(out.len);
    if (result && out.buf) { memcpy(result, out.buf, out.len + 1); }
    if (out.buf) free(out.buf);
    return result ? result : "";
}

/* ========== End Advanced String Operations ========== */

/* ========== Timing Utilities ========== */

#include <sys/time.h>
#ifdef __MACH__
#include <mach/mach_time.h>
#endif

/* Get current time in microseconds since epoch */
static int64_t nl_timing_get_microseconds(void) {
#ifdef CLOCK_REALTIME
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ((int64_t)ts.tv_sec * 1000000LL) + (int64_t)(ts.tv_nsec / 1000);
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((int64_t)tv.tv_sec * 1000000LL) + (int64_t)tv.tv_usec;
#endif
}

/* Get high-resolution time in nanoseconds */
static int64_t nl_timing_get_nanoseconds(void) {
#ifdef __MACH__
    static mach_timebase_info_data_t timebase;
    static int initialized = 0;
    if (!initialized) {
        mach_timebase_info(&timebase);
        initialized = 1;
    }
    uint64_t mach_time = mach_absolute_time();
    return (int64_t)((mach_time * timebase.numer) / timebase.denom);
#elif defined(CLOCK_MONOTONIC)
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((int64_t)ts.tv_sec * 1000000000LL) + (int64_t)ts.tv_nsec;
#else
    return nl_timing_get_microseconds() * 1000LL;
#endif
}

/* Convenience: current time in milliseconds */
static int64_t nl_get_time_ms(void) { return nl_timing_get_microseconds() / 1000LL; }

/* ========== End Timing Utilities ========== */

/* ========== Console I/O Utilities ========== */

/* Read a line from stdin, returns heap-allocated string */
/* Static to avoid duplicate symbols when linking multiple modules */
static const char* nl_read_line(void) {
    char buffer[4096];
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty ? empty : "";
    }
    /* Remove trailing newline if present */
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len-1] == '\n') {
        buffer[len-1] = '\0';
        len--;
    }
    char* result = malloc(len + 1);
    if (!result) return "";
    memcpy(result, buffer, len + 1);
    return result;
}

/* ========== End Console I/O Utilities ========== */

#include <string.h>
static inline double nl_float_from_bits(int64_t value) { uint64_t bits = (uint64_t)value; double result; (void)sizeof(char[sizeof(result) == sizeof(bits) ? 1 : -1]); memcpy(&result, &bits, sizeof(result)); return result; }
static inline int64_t nl_float_to_bits(double value) { uint64_t bits; (void)sizeof(char[sizeof(value) == sizeof(bits) ? 1 : -1]); memcpy(&bits, &value, sizeof(bits)); return bits <= (9223372036854775807L) ? (int64_t)bits : -1 - (int64_t)((18446744073709551615UL) - bits); }
/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Math and Utility Built-in Functions ========== */

#define nl_abs(x) _Generic((x), \
    double: (double)((x) < 0.0 ? -(x) : (x)), \
    default: (int64_t)((x) < 0 ? -(x) : (x)))

#define nl_min(a, b) _Generic((a), \
    double: (double)((a) < (b) ? (a) : (b)), \
    default: (int64_t)((a) < (b) ? (a) : (b)))

#define nl_max(a, b) _Generic((a), \
    double: (double)((a) > (b) ? (a) : (b)), \
    default: (int64_t)((a) > (b) ? (a) : (b)))

/* Trigonometric functions */
static double nl_sin(double x) { return sin(x); }
static double nl_cos(double x) { return cos(x); }
static double nl_tan(double x) { return tan(x); }
static double nl_atan2(double y, double x) { return atan2(y, x); }

/* Power and root functions */
static double nl_sqrt(double x) { return sqrt(x); }
static double nl_pow(double base, double exp) { return pow(base, exp); }

/* Rounding functions */
static double nl_floor(double x) { return floor(x); }
static double nl_ceil(double x) { return ceil(x); }
static double nl_round(double x) { return round(x); }

static int64_t nl_cast_int(double x) { if (!(x >= -0x1p63 && x < 0x1p63)) { fputs("I cannot convert this float to int: I require a finite value in [-2^63, 2^63).\n", stderr); exit(EXIT_FAILURE); } return (int64_t)x; }
static int64_t nl_cast_int_from_int(int64_t x) { return x; }
static double nl_cast_float(int64_t x) { return (double)x; }
static double nl_cast_float_from_float(double x) { return x; }
static void* nl_null_opaque() { return NULL; }
static int64_t nl_cast_bool_to_int(bool x) { return x ? 1 : 0; }
static bool nl_cast_bool(int64_t x) { return x != 0; }
static int64_t nano_rt_idiv(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return INT64_MIN; return a / b; }
static int64_t nano_rt_imod(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return 0; return a % b; }

static void nl_println(void* value_ptr) {
    (void)value_ptr; /* Unused - actual implementation uses type info from checker */
}

static void nl_print_int(int64_t value) {
    printf("%lld", (long long)value);
}

static void nl_print_float(double value) {
    nano_rt_f64_print(stdout, value);
}

static void nl_print_string(const char* value) {
    printf("%s", value);
}

static void nl_print_bool(bool value) {
    printf(value ? "true" : "false");
}

static void nl_println_int(int64_t value) {
    printf("%lld\n", (long long)value);
}

static void nl_println_float(double value) {
    nano_rt_f64_print(stdout, value); fputc('\n', stdout);
}

static void nl_println_string(const char* value) {
    printf("%s\n", value);
}

/* Dynamic array runtime (using GC) - LEGACY */
#include "runtime/gc.h"
#include "runtime/dyn_array.h"
#include "runtime/nl_string.h"

static DynArray* dynarray_literal_int(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int64_t val = va_arg(args, int64_t);
        dyn_array_push_int(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_u8(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_U8);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* default promotion */
        dyn_array_push_u8(arr, (uint8_t)val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_float(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        double val = va_arg(args, double);
        dyn_array_push_float(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_string(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        const char* val = va_arg(args, const char*);
        dyn_array_push_string(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_bool(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* bool promotes to int */
        dyn_array_push_bool(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static DynArray* nl_array_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static double nl_array_pop(DynArray* arr) {
    bool success = false;
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_pop_u8(arr, &success);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_pop_int(arr, &success);
    } else {
        return dyn_array_pop_float(arr, &success);
    }
}

static int64_t nl_array_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static DynArray* nl_array_remove_at(DynArray* arr, int64_t index) {
    return dyn_array_remove_at(arr, index);
}

static int64_t nl_array_at_int(DynArray* arr, int64_t idx) {
    return dyn_array_get_int(arr, idx);
}

static uint8_t nl_array_at_u8(DynArray* arr, int64_t idx) {
    return dyn_array_get_u8(arr, idx);
}

static double nl_array_at_float(DynArray* arr, int64_t idx) {
    return dyn_array_get_float(arr, idx);
}

static const char* nl_array_at_string(DynArray* arr, int64_t idx) {
    return dyn_array_get_string(arr, idx);
}

static bool nl_array_at_bool(DynArray* arr, int64_t idx) {
    return dyn_array_get_bool(arr, idx);
}

static void nl_array_set_int(DynArray* arr, int64_t idx, int64_t val) {
    dyn_array_set_int(arr, idx, val);
}

static void nl_array_set_u8(DynArray* arr, int64_t idx, uint8_t val) {
    dyn_array_set_u8(arr, idx, val);
}

static void nl_array_set_float(DynArray* arr, int64_t idx, double val) {
    dyn_array_set_float(arr, idx, val);
}

static void nl_array_set_string(DynArray* arr, int64_t idx, const char* val) {
    dyn_array_set_string(arr, idx, val);
}

static void nl_array_set_bool(DynArray* arr, int64_t idx, bool val) {
    dyn_array_set_bool(arr, idx, val);
}

static DynArray* nl_array_at_array(DynArray* arr, int64_t idx) {
    return dyn_array_get_array(arr, idx);
}

static void nl_array_set_array(DynArray* arr, int64_t idx, DynArray* val) {
    dyn_array_set_array(arr, idx, val);
}

static DynArray* nl_array_new_int(int64_t size, int64_t default_val) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_int(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_float(int64_t size, double default_val) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_float(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_string(int64_t size, const char* default_val) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_string(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_bool(int64_t size, bool default_val) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_bool(arr, default_val);
    }
    return arr;
}

static int64_t dynarray_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static double dynarray_at_for_transpiler(DynArray* arr, int64_t idx) {
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_get_u8(arr, idx);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_get_int(arr, idx);
    } else {
        return dyn_array_get_float(arr, idx);
    }
}

/* bstring helpers (nl_string_t wrappers) */
static nl_string_t* bstr_new(const char* cstr) {
    if (!cstr) cstr = "";
    return nl_string_new(cstr);
}

static nl_string_t* bstr_new_binary(DynArray* bytes) {
    if (!bytes || dyn_array_get_elem_type(bytes) != ELEM_U8) {
        return nl_string_new_binary("", 0);
    }
    int64_t len = dyn_array_length(bytes);
    if (len <= 0) {
        return nl_string_new_binary("", 0);
    }
    uint8_t* buffer = malloc((size_t)len);
    if (!buffer) {
        return nl_string_new_binary("", 0);
    }
    for (int64_t i = 0; i < len; i++) {
        buffer[i] = dyn_array_get_u8(bytes, i);
    }
    nl_string_t* result = nl_string_new_binary(buffer, (size_t)len);
    free(buffer);
    return result;
}

static size_t bstr_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_length(str);
}

static int64_t bstr_byte_at(nl_string_t* str, int64_t index) {
    if (!str || index < 0 || (size_t)index >= nl_string_length(str)) {
        return 0;
    }
    return (unsigned char)nl_string_byte_at(str, (size_t)index);
}

static nl_string_t* bstr_concat(nl_string_t* a, nl_string_t* b) {
    if (!a && !b) return nl_string_new("");
    if (!a) return nl_string_clone(b);
    if (!b) return nl_string_clone(a);
    return nl_string_concat(a, b);
}

static nl_string_t* bstr_substring(nl_string_t* str, int64_t start, int64_t length) {
    if (!str || start < 0 || length < 0) {
        return nl_string_new("");
    }
    size_t len = nl_string_length(str);
    if ((size_t)start > len) {
        start = (int64_t)len;
    }
    if ((size_t)(start + length) > len) {
        length = (int64_t)len - start;
    }
    return nl_string_substring(str, (size_t)start, (size_t)length);
}

static bool bstr_equals(nl_string_t* a, nl_string_t* b) {
    if (!a || !b) return a == b;
    return nl_string_equals(a, b);
}

static bool bstr_validate_utf8(nl_string_t* str) {
    if (!str) return false;
    return nl_string_validate_utf8(str);
}

static int64_t bstr_utf8_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_utf8_length(str);
}

static int64_t bstr_utf8_char_at(nl_string_t* str, int64_t char_index) {
    if (!str || char_index < 0) return -1;
    return nl_string_utf8_char_at(str, (size_t)char_index);
}

static const char* bstr_to_cstr(nl_string_t* str) {
    if (!str) return "";
    return nl_string_to_cstr(str);
}

static void bstr_free(nl_string_t* str) {
    if (str) {
        nl_string_free(str);
    }
}

/* String concatenation - use strnlen for safety */
static const char* nl_str_concat(const char* s1, const char* s2) {
    /* Safety: Bound string scan to 64MB */
    size_t len1 = strnlen(s1, 64*1024*1024);
    size_t len2 = strnlen(s2, 64*1024*1024);
    char* result = gc_alloc_string(len1 + len2);
    if (!result) return "";
    memcpy(result, s1, len1);
    memcpy(result + len1, s2, len2);
    result[len1 + len2] = '\0';
    return result;
}

/* String substring - use strnlen for safety */
static const char* nl_str_substring(const char* str, int64_t start, int64_t length) {
    /* Safety: Bound string scan to 64MB */
    int64_t str_len = strnlen(str, 64*1024*1024);
    if (start < 0 || start > str_len || length < 0) return "";
    if (start == str_len) return "";
    if (start + length > str_len) length = str_len - start;
    char* result = gc_alloc_string(length);
    if (!result) return "";
    strncpy(result, str + start, length);
    result[length] = '\0';
    return result;
}

/* String contains */
static bool nl_str_contains(const char* str, const char* substr) {
    return strstr(str, substr) != NULL;
}

/* String equals */
static bool nl_str_equals(const char* s1, const char* s2) {
    return strcmp(s1, s2) == 0;
}

/* String starts_with */
static bool nl_str_starts_with(const char* s, const char* prefix) {
    if (!s || !prefix) return false;
    size_t slen = strnlen(s, 64*1024*1024);
    size_t plen = strnlen(prefix, 64*1024*1024);
    if (plen > slen) return false;
    return strncmp(s, prefix, plen) == 0;
}

/* String ends_with */
#include "runtime/string_edges.h"
#include "runtime/string_search.h"
static DynArray* nl_bytes_from_string(const char* s) {
    DynArray* out = dyn_array_new(ELEM_U8);
    if (!out) return NULL;
    if (!s) return out;
    size_t len = strnlen(s, 64*1024*1024);
    for (size_t i = 0; i < len; i++) {
        dyn_array_push_u8(out, (uint8_t)(unsigned char)s[i]);
    }
    return out;
}

static const char* nl_string_from_bytes(DynArray* bytes) {
    if (!bytes) return "";
    if (dyn_array_get_elem_type(bytes) != ELEM_U8) return "";
    int64_t len = dyn_array_length(bytes);
    if (len < 0) return "";
    char* out = gc_alloc_string((size_t)len);
    if (!out) return "";
    for (int64_t i = 0; i < len; i++) {
        out[i] = (char)dyn_array_get_u8(bytes, i);
    }
    out[len] = '\0';
    return out;
}

static DynArray* nl_array_slice(DynArray* arr, int64_t start, int64_t length) {
    if (!arr) return dyn_array_new(ELEM_INT);
    if (start < 0) start = 0;
    if (length < 0) length = 0;
    int64_t len = dyn_array_length(arr);
    if (start > len) start = len;
    if (length > len - start) length = len - start;
    int64_t end = start + length;
    if (end > len) end = len;
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = start; i < end; i++) {
        switch (t) {
            case ELEM_U8: dyn_array_push_u8(out, dyn_array_get_u8(arr, i)); break;
            case ELEM_INT: dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT: dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL: dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            case ELEM_ARRAY: dyn_array_push_array(out, dyn_array_get_array(arr, i)); break;
            case ELEM_STRUCT: dyn_array_push_struct(out, dyn_array_get_struct(arr, i), (size_t)arr->elem_size); break;
            default: assert(false && "nl_array_slice: unsupported element type");
        }
    }
    return out;
}

static void nl_println_bool(bool value) {
    printf("%s\n", value ? "true" : "false");
}

static void nl_print_array(DynArray* arr) {
    printf("[");
    for (int i = 0; i < arr->length; i++) {
        if (i > 0) printf(", ");
        switch (arr->elem_type) {
            case ELEM_INT:
                printf("%lld", (long long)((int64_t*)arr->data)[i]);
                break;
            case ELEM_U8:
                printf("%u", (unsigned)((uint8_t*)arr->data)[i]);
                break;
            case ELEM_FLOAT:
                nano_rt_f64_print(stdout, ((double*)arr->data)[i]);
                break;
            default:
                printf("?");
                break;
        }
    }
    printf("]");
}

static void nl_println_array(DynArray* arr) {
    nl_print_array(arr);
    printf("\n");
}

/* ========== Array Operations (With Bounds Checking!) ========== */

static DynArray* nl_array_sort(DynArray* arr) {
    return dyn_array_sorted(arr);
}

static DynArray* nl_array_reverse(DynArray* arr) {
    if (!arr) return dyn_array_new(ELEM_INT);
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = len - 1; i >= 0; i--) {
        switch (t) {
            case ELEM_INT:    dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT:  dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL:   dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            default: dyn_array_push_int(out, 0); break;
        }
    }
    return out;
}

static bool nl_array_contains(DynArray* arr, int64_t elem) {
    if (!arr) return false;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return true;
    }
    return false;
}

static int64_t nl_array_index_of(DynArray* arr, int64_t elem) {
    if (!arr) return -1;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return i;
    }
    return -1;
}

/* ========== End Array Operations ========== */

/* ========== End Math and Utility Built-in Functions ========== */

/* ========== Coroutine Runtime Builtins ========== */
#include "coroutine.h"

typedef struct { void *fn; int64_t args[8]; int nargs; } NlSpawnCtx;
static Value nl_coro_spawn_trampoline(void *raw, int coro_id) {
    (void)coro_id;
    NlSpawnCtx *ctx = (NlSpawnCtx *)raw;
    Value v; memset(&v, 0, sizeof(v)); v.type = VAL_INT;
    switch (ctx->nargs) {
        case 0: v.as.int_val = ((int64_t(*)(void))ctx->fn)(); break;
        case 1: v.as.int_val = ((int64_t(*)(int64_t))ctx->fn)(ctx->args[0]); break;
        case 2: v.as.int_val = ((int64_t(*)(int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1]); break;
        case 3: v.as.int_val = ((int64_t(*)(int64_t,int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1],ctx->args[2]); break;
        default: break;
    }
    return v;
}

static int64_t nl_coro_spawn_n(void *fn, int nargs, int64_t a0, int64_t a1, int64_t a2) {
    nano_scheduler_init();
    NlSpawnCtx *ctx = (NlSpawnCtx *)malloc(sizeof(NlSpawnCtx));
    if (!ctx) return -1;
    ctx->fn = fn; ctx->nargs = nargs;
    ctx->args[0] = a0; ctx->args[1] = a1; ctx->args[2] = a2;
    return (int64_t)nano_coro_spawn(nl_coro_spawn_trampoline, ctx);
}
/* nl_coro_spawn: select correct overload by argument count */
#define _nl_cs0(fn)           nl_coro_spawn_n((void*)(fn),0,0LL,0LL,0LL)
#define _nl_cs1(fn,a)         nl_coro_spawn_n((void*)(fn),1,(int64_t)(a),0LL,0LL)
#define _nl_cs2(fn,a,b)       nl_coro_spawn_n((void*)(fn),2,(int64_t)(a),(int64_t)(b),0LL)
#define _nl_cs3(fn,a,b,c)     nl_coro_spawn_n((void*)(fn),3,(int64_t)(a),(int64_t)(b),(int64_t)(c))
#define _nl_cs_pick(_1,_2,_3,_4,X,...) X
#define nl_coro_spawn(fn,...) _nl_cs_pick(fn,##__VA_ARGS__,_nl_cs3,_nl_cs2,_nl_cs1,_nl_cs0)(fn,##__VA_ARGS__)

/* nl_scheduler_run(): drain all pending coroutines */
static void nl_scheduler_run(void) {
    nano_scheduler_init();
    nano_scheduler_run_until_done();
}

/* nl_scheduler_step(): run one step */
static int64_t nl_scheduler_step(void) {
    nano_scheduler_init();
    return nano_scheduler_step() ? 1 : 0;
}

/* nl_coro_result(id): get result value of completed coroutine */
static int64_t nl_coro_result(int64_t id) {
    Value v = nano_coro_result((int)id);
    return v.as.int_val;
}

/* nl_coro_done(id): 1 if coroutine completed */
static int64_t nl_coro_done(int64_t id) {
    return nano_coro_is_done((int)id) ? 1 : 0;
}

/* nl_coro_yield(): cooperative yield hint */
static void nl_coro_yield(void) { nano_coro_yield(); }
/* ========== End Coroutine Runtime Builtins ========== */

/* ========== Enum Definitions ========== */

/* ========== End Enum Definitions ========== */

/* ========== Struct and Union Definitions ========== */

/* ========== End Struct and Union Definitions ========== */

/* ========== Auto-Generated Struct Metadata ========== */

/* ========== End Struct Metadata ========== */

/* ========== HashMap Runtime (Generated) ========== */

static uint64_t nl_hashmap_hash_string(const char *s) {
    if (!s) return 0;
    uint64_t hash = 1469598103934665603ULL;
    while (*s) { hash ^= (uint8_t)(*s++); hash *= 1099511628211ULL; }
    return hash;
}

static uint64_t nl_hashmap_hash_int(int64_t x) {
    uint64_t z = (uint64_t)x;
    z ^= z >> 33;
    z *= 0xff51afd7ed558ccdULL;
    z ^= z >> 33;
    z *= 0xc4ceb9fe1a85ec53ULL;
    z ^= z >> 33;
    return z;
}

static bool nl_hashmap_key_eq_string(const char *a, const char *b) {
    if (a == b) return true;
    if (!a || !b) return false;
    return strcmp(a, b) == 0;
}

/* (no HashMap instantiations) */

/* ========== End HashMap Runtime (Generated) ========== */

/* ========== To-String Helpers ========== */

/* To-String forward declarations */

/* ========== End To-String Helpers ========== */

/* External C function declarations */

/* Forward declarations for imported module functions */

/* Forward declarations for program functions */

/* Top-level globals */


#pragma GCC diagnostic pop
/* Module metadata - automatically generated */
#include "nanolang.h"

static Function _module_functions[85];
static Parameter _module_params[0];

static void _init_module_metadata(void) __attribute__((constructor));
static void _init_module_metadata(void) {
    /* Function: range */
    _module_functions[0].name = "range";
    _module_functions[0].param_count = 0;
    _module_functions[0].return_type = 6;
    _module_functions[0].return_struct_type_name = NULL;
    _module_functions[0].return_fn_sig = NULL;
    _module_functions[0].return_type_info = NULL;
    _module_functions[0].body = NULL;
    _module_functions[0].shadow_test = NULL;
    _module_functions[0].is_extern = false;
    _module_functions[0].returns_gc_managed = false;
    _module_functions[0].requires_manual_free = false;
    _module_functions[0].returns_borrowed = false;
    _module_functions[0].cleanup_function = NULL;
    _module_functions[0].params = NULL;

    /* Function: abs */
    _module_functions[1].name = "abs";
    _module_functions[1].param_count = 0;
    _module_functions[1].return_type = 0;
    _module_functions[1].return_struct_type_name = NULL;
    _module_functions[1].return_fn_sig = NULL;
    _module_functions[1].return_type_info = NULL;
    _module_functions[1].body = NULL;
    _module_functions[1].shadow_test = NULL;
    _module_functions[1].is_extern = false;
    _module_functions[1].returns_gc_managed = false;
    _module_functions[1].requires_manual_free = false;
    _module_functions[1].returns_borrowed = false;
    _module_functions[1].cleanup_function = NULL;
    _module_functions[1].params = NULL;

    /* Function: min */
    _module_functions[2].name = "min";
    _module_functions[2].param_count = 0;
    _module_functions[2].return_type = 0;
    _module_functions[2].return_struct_type_name = NULL;
    _module_functions[2].return_fn_sig = NULL;
    _module_functions[2].return_type_info = NULL;
    _module_functions[2].body = NULL;
    _module_functions[2].shadow_test = NULL;
    _module_functions[2].is_extern = false;
    _module_functions[2].returns_gc_managed = false;
    _module_functions[2].requires_manual_free = false;
    _module_functions[2].returns_borrowed = false;
    _module_functions[2].cleanup_function = NULL;
    _module_functions[2].params = NULL;

    /* Function: max */
    _module_functions[3].name = "max";
    _module_functions[3].param_count = 0;
    _module_functions[3].return_type = 0;
    _module_functions[3].return_struct_type_name = NULL;
    _module_functions[3].return_fn_sig = NULL;
    _module_functions[3].return_type_info = NULL;
    _module_functions[3].body = NULL;
    _module_functions[3].shadow_test = NULL;
    _module_functions[3].is_extern = false;
    _module_functions[3].returns_gc_managed = false;
    _module_functions[3].requires_manual_free = false;
    _module_functions[3].returns_borrowed = false;
    _module_functions[3].cleanup_function = NULL;
    _module_functions[3].params = NULL;

    /* Function: print */
    _module_functions[4].name = "print";
    _module_functions[4].param_count = 0;
    _module_functions[4].return_type = 6;
    _module_functions[4].return_struct_type_name = NULL;
    _module_functions[4].return_fn_sig = NULL;
    _module_functions[4].return_type_info = NULL;
    _module_functions[4].body = NULL;
    _module_functions[4].shadow_test = NULL;
    _module_functions[4].is_extern = false;
    _module_functions[4].returns_gc_managed = false;
    _module_functions[4].requires_manual_free = false;
    _module_functions[4].returns_borrowed = false;
    _module_functions[4].cleanup_function = NULL;
    _module_functions[4].params = NULL;

    /* Function: println */
    _module_functions[5].name = "println";
    _module_functions[5].param_count = 0;
    _module_functions[5].return_type = 6;
    _module_functions[5].return_struct_type_name = NULL;
    _module_functions[5].return_fn_sig = NULL;
    _module_functions[5].return_type_info = NULL;
    _module_functions[5].body = NULL;
    _module_functions[5].shadow_test = NULL;
    _module_functions[5].is_extern = false;
    _module_functions[5].returns_gc_managed = false;
    _module_functions[5].requires_manual_free = false;
    _module_functions[5].returns_borrowed = false;
    _module_functions[5].cleanup_function = NULL;
    _module_functions[5].params = NULL;

    /* Function: sqrt */
    _module_functions[6].name = "sqrt";
    _module_functions[6].param_count = 0;
    _module_functions[6].return_type = 2;
    _module_functions[6].return_struct_type_name = NULL;
    _module_functions[6].return_fn_sig = NULL;
    _module_functions[6].return_type_info = NULL;
    _module_functions[6].body = NULL;
    _module_functions[6].shadow_test = NULL;
    _module_functions[6].is_extern = false;
    _module_functions[6].returns_gc_managed = false;
    _module_functions[6].requires_manual_free = false;
    _module_functions[6].returns_borrowed = false;
    _module_functions[6].cleanup_function = NULL;
    _module_functions[6].params = NULL;

    /* Function: pow */
    _module_functions[7].name = "pow";
    _module_functions[7].param_count = 0;
    _module_functions[7].return_type = 2;
    _module_functions[7].return_struct_type_name = NULL;
    _module_functions[7].return_fn_sig = NULL;
    _module_functions[7].return_type_info = NULL;
    _module_functions[7].body = NULL;
    _module_functions[7].shadow_test = NULL;
    _module_functions[7].is_extern = false;
    _module_functions[7].returns_gc_managed = false;
    _module_functions[7].requires_manual_free = false;
    _module_functions[7].returns_borrowed = false;
    _module_functions[7].cleanup_function = NULL;
    _module_functions[7].params = NULL;

    /* Function: floor */
    _module_functions[8].name = "floor";
    _module_functions[8].param_count = 0;
    _module_functions[8].return_type = 2;
    _module_functions[8].return_struct_type_name = NULL;
    _module_functions[8].return_fn_sig = NULL;
    _module_functions[8].return_type_info = NULL;
    _module_functions[8].body = NULL;
    _module_functions[8].shadow_test = NULL;
    _module_functions[8].is_extern = false;
    _module_functions[8].returns_gc_managed = false;
    _module_functions[8].requires_manual_free = false;
    _module_functions[8].returns_borrowed = false;
    _module_functions[8].cleanup_function = NULL;
    _module_functions[8].params = NULL;

    /* Function: ceil */
    _module_functions[9].name = "ceil";
    _module_functions[9].param_count = 0;
    _module_functions[9].return_type = 2;
    _module_functions[9].return_struct_type_name = NULL;
    _module_functions[9].return_fn_sig = NULL;
    _module_functions[9].return_type_info = NULL;
    _module_functions[9].body = NULL;
    _module_functions[9].shadow_test = NULL;
    _module_functions[9].is_extern = false;
    _module_functions[9].returns_gc_managed = false;
    _module_functions[9].requires_manual_free = false;
    _module_functions[9].returns_borrowed = false;
    _module_functions[9].cleanup_function = NULL;
    _module_functions[9].params = NULL;

    /* Function: round */
    _module_functions[10].name = "round";
    _module_functions[10].param_count = 0;
    _module_functions[10].return_type = 2;
    _module_functions[10].return_struct_type_name = NULL;
    _module_functions[10].return_fn_sig = NULL;
    _module_functions[10].return_type_info = NULL;
    _module_functions[10].body = NULL;
    _module_functions[10].shadow_test = NULL;
    _module_functions[10].is_extern = false;
    _module_functions[10].returns_gc_managed = false;
    _module_functions[10].requires_manual_free = false;
    _module_functions[10].returns_borrowed = false;
    _module_functions[10].cleanup_function = NULL;
    _module_functions[10].params = NULL;

    /* Function: sin */
    _module_functions[11].name = "sin";
    _module_functions[11].param_count = 0;
    _module_functions[11].return_type = 2;
    _module_functions[11].return_struct_type_name = NULL;
    _module_functions[11].return_fn_sig = NULL;
    _module_functions[11].return_type_info = NULL;
    _module_functions[11].body = NULL;
    _module_functions[11].shadow_test = NULL;
    _module_functions[11].is_extern = false;
    _module_functions[11].returns_gc_managed = false;
    _module_functions[11].requires_manual_free = false;
    _module_functions[11].returns_borrowed = false;
    _module_functions[11].cleanup_function = NULL;
    _module_functions[11].params = NULL;

    /* Function: cos */
    _module_functions[12].name = "cos";
    _module_functions[12].param_count = 0;
    _module_functions[12].return_type = 2;
    _module_functions[12].return_struct_type_name = NULL;
    _module_functions[12].return_fn_sig = NULL;
    _module_functions[12].return_type_info = NULL;
    _module_functions[12].body = NULL;
    _module_functions[12].shadow_test = NULL;
    _module_functions[12].is_extern = false;
    _module_functions[12].returns_gc_managed = false;
    _module_functions[12].requires_manual_free = false;
    _module_functions[12].returns_borrowed = false;
    _module_functions[12].cleanup_function = NULL;
    _module_functions[12].params = NULL;

    /* Function: tan */
    _module_functions[13].name = "tan";
    _module_functions[13].param_count = 0;
    _module_functions[13].return_type = 2;
    _module_functions[13].return_struct_type_name = NULL;
    _module_functions[13].return_fn_sig = NULL;
    _module_functions[13].return_type_info = NULL;
    _module_functions[13].body = NULL;
    _module_functions[13].shadow_test = NULL;
    _module_functions[13].is_extern = false;
    _module_functions[13].returns_gc_managed = false;
    _module_functions[13].requires_manual_free = false;
    _module_functions[13].returns_borrowed = false;
    _module_functions[13].cleanup_function = NULL;
    _module_functions[13].params = NULL;

    /* Function: str_length */
    _module_functions[14].name = "str_length";
    _module_functions[14].param_count = 0;
    _module_functions[14].return_type = 0;
    _module_functions[14].return_struct_type_name = NULL;
    _module_functions[14].return_fn_sig = NULL;
    _module_functions[14].return_type_info = NULL;
    _module_functions[14].body = NULL;
    _module_functions[14].shadow_test = NULL;
    _module_functions[14].is_extern = false;
    _module_functions[14].returns_gc_managed = false;
    _module_functions[14].requires_manual_free = false;
    _module_functions[14].returns_borrowed = false;
    _module_functions[14].cleanup_function = NULL;
    _module_functions[14].params = NULL;

    /* Function: str_concat */
    _module_functions[15].name = "str_concat";
    _module_functions[15].param_count = 0;
    _module_functions[15].return_type = 4;
    _module_functions[15].return_struct_type_name = NULL;
    _module_functions[15].return_fn_sig = NULL;
    _module_functions[15].return_type_info = NULL;
    _module_functions[15].body = NULL;
    _module_functions[15].shadow_test = NULL;
    _module_functions[15].is_extern = false;
    _module_functions[15].returns_gc_managed = true;
    _module_functions[15].requires_manual_free = false;
    _module_functions[15].returns_borrowed = false;
    _module_functions[15].cleanup_function = NULL;
    _module_functions[15].params = NULL;

    /* Function: str_substring */
    _module_functions[16].name = "str_substring";
    _module_functions[16].param_count = 0;
    _module_functions[16].return_type = 4;
    _module_functions[16].return_struct_type_name = NULL;
    _module_functions[16].return_fn_sig = NULL;
    _module_functions[16].return_type_info = NULL;
    _module_functions[16].body = NULL;
    _module_functions[16].shadow_test = NULL;
    _module_functions[16].is_extern = false;
    _module_functions[16].returns_gc_managed = true;
    _module_functions[16].requires_manual_free = false;
    _module_functions[16].returns_borrowed = false;
    _module_functions[16].cleanup_function = NULL;
    _module_functions[16].params = NULL;

    /* Function: str_contains */
    _module_functions[17].name = "str_contains";
    _module_functions[17].param_count = 0;
    _module_functions[17].return_type = 3;
    _module_functions[17].return_struct_type_name = NULL;
    _module_functions[17].return_fn_sig = NULL;
    _module_functions[17].return_type_info = NULL;
    _module_functions[17].body = NULL;
    _module_functions[17].shadow_test = NULL;
    _module_functions[17].is_extern = false;
    _module_functions[17].returns_gc_managed = false;
    _module_functions[17].requires_manual_free = false;
    _module_functions[17].returns_borrowed = false;
    _module_functions[17].cleanup_function = NULL;
    _module_functions[17].params = NULL;

    /* Function: str_equals */
    _module_functions[18].name = "str_equals";
    _module_functions[18].param_count = 0;
    _module_functions[18].return_type = 3;
    _module_functions[18].return_struct_type_name = NULL;
    _module_functions[18].return_fn_sig = NULL;
    _module_functions[18].return_type_info = NULL;
    _module_functions[18].body = NULL;
    _module_functions[18].shadow_test = NULL;
    _module_functions[18].is_extern = false;
    _module_functions[18].returns_gc_managed = false;
    _module_functions[18].requires_manual_free = false;
    _module_functions[18].returns_borrowed = false;
    _module_functions[18].cleanup_function = NULL;
    _module_functions[18].params = NULL;

    /* Function: format */
    _module_functions[19].name = "format";
    _module_functions[19].param_count = 0;
    _module_functions[19].return_type = 4;
    _module_functions[19].return_struct_type_name = NULL;
    _module_functions[19].return_fn_sig = NULL;
    _module_functions[19].return_type_info = NULL;
    _module_functions[19].body = NULL;
    _module_functions[19].shadow_test = NULL;
    _module_functions[19].is_extern = false;
    _module_functions[19].returns_gc_managed = true;
    _module_functions[19].requires_manual_free = false;
    _module_functions[19].returns_borrowed = false;
    _module_functions[19].cleanup_function = NULL;
    _module_functions[19].params = NULL;

    /* Function: at */
    _module_functions[20].name = "at";
    _module_functions[20].param_count = 0;
    _module_functions[20].return_type = 21;
    _module_functions[20].return_struct_type_name = NULL;
    _module_functions[20].return_fn_sig = NULL;
    _module_functions[20].return_type_info = NULL;
    _module_functions[20].body = NULL;
    _module_functions[20].shadow_test = NULL;
    _module_functions[20].is_extern = false;
    _module_functions[20].returns_gc_managed = false;
    _module_functions[20].requires_manual_free = false;
    _module_functions[20].returns_borrowed = false;
    _module_functions[20].cleanup_function = NULL;
    _module_functions[20].params = NULL;

    /* Function: array_length */
    _module_functions[21].name = "array_length";
    _module_functions[21].param_count = 0;
    _module_functions[21].return_type = 0;
    _module_functions[21].return_struct_type_name = NULL;
    _module_functions[21].return_fn_sig = NULL;
    _module_functions[21].return_type_info = NULL;
    _module_functions[21].body = NULL;
    _module_functions[21].shadow_test = NULL;
    _module_functions[21].is_extern = false;
    _module_functions[21].returns_gc_managed = false;
    _module_functions[21].requires_manual_free = false;
    _module_functions[21].returns_borrowed = false;
    _module_functions[21].cleanup_function = NULL;
    _module_functions[21].params = NULL;

    /* Function: array_new */
    _module_functions[22].name = "array_new";
    _module_functions[22].param_count = 0;
    _module_functions[22].return_type = 7;
    _module_functions[22].return_struct_type_name = NULL;
    _module_functions[22].return_fn_sig = NULL;
    _module_functions[22].return_type_info = NULL;
    _module_functions[22].body = NULL;
    _module_functions[22].shadow_test = NULL;
    _module_functions[22].is_extern = false;
    _module_functions[22].returns_gc_managed = false;
    _module_functions[22].requires_manual_free = false;
    _module_functions[22].returns_borrowed = false;
    _module_functions[22].cleanup_function = NULL;
    _module_functions[22].params = NULL;

    /* Function: array_set */
    _module_functions[23].name = "array_set";
    _module_functions[23].param_count = 0;
    _module_functions[23].return_type = 6;
    _module_functions[23].return_struct_type_name = NULL;
    _module_functions[23].return_fn_sig = NULL;
    _module_functions[23].return_type_info = NULL;
    _module_functions[23].body = NULL;
    _module_functions[23].shadow_test = NULL;
    _module_functions[23].is_extern = false;
    _module_functions[23].returns_gc_managed = false;
    _module_functions[23].requires_manual_free = false;
    _module_functions[23].returns_borrowed = false;
    _module_functions[23].cleanup_function = NULL;
    _module_functions[23].params = NULL;

    /* Function: map */
    _module_functions[24].name = "map";
    _module_functions[24].param_count = 0;
    _module_functions[24].return_type = 7;
    _module_functions[24].return_struct_type_name = NULL;
    _module_functions[24].return_fn_sig = NULL;
    _module_functions[24].return_type_info = NULL;
    _module_functions[24].body = NULL;
    _module_functions[24].shadow_test = NULL;
    _module_functions[24].is_extern = false;
    _module_functions[24].returns_gc_managed = false;
    _module_functions[24].requires_manual_free = false;
    _module_functions[24].returns_borrowed = false;
    _module_functions[24].cleanup_function = NULL;
    _module_functions[24].params = NULL;

    /* Function: reduce */
    _module_functions[25].name = "reduce";
    _module_functions[25].param_count = 0;
    _module_functions[25].return_type = 21;
    _module_functions[25].return_struct_type_name = NULL;
    _module_functions[25].return_fn_sig = NULL;
    _module_functions[25].return_type_info = NULL;
    _module_functions[25].body = NULL;
    _module_functions[25].shadow_test = NULL;
    _module_functions[25].is_extern = false;
    _module_functions[25].returns_gc_managed = false;
    _module_functions[25].requires_manual_free = false;
    _module_functions[25].returns_borrowed = false;
    _module_functions[25].cleanup_function = NULL;
    _module_functions[25].params = NULL;

    /* Function: getcwd */
    _module_functions[26].name = "getcwd";
    _module_functions[26].param_count = 0;
    _module_functions[26].return_type = 4;
    _module_functions[26].return_struct_type_name = NULL;
    _module_functions[26].return_fn_sig = NULL;
    _module_functions[26].return_type_info = NULL;
    _module_functions[26].body = NULL;
    _module_functions[26].shadow_test = NULL;
    _module_functions[26].is_extern = false;
    _module_functions[26].returns_gc_managed = true;
    _module_functions[26].requires_manual_free = false;
    _module_functions[26].returns_borrowed = false;
    _module_functions[26].cleanup_function = NULL;
    _module_functions[26].params = NULL;

    /* Function: getenv */
    _module_functions[27].name = "getenv";
    _module_functions[27].param_count = 0;
    _module_functions[27].return_type = 4;
    _module_functions[27].return_struct_type_name = NULL;
    _module_functions[27].return_fn_sig = NULL;
    _module_functions[27].return_type_info = NULL;
    _module_functions[27].body = NULL;
    _module_functions[27].shadow_test = NULL;
    _module_functions[27].is_extern = false;
    _module_functions[27].returns_gc_managed = true;
    _module_functions[27].requires_manual_free = false;
    _module_functions[27].returns_borrowed = false;
    _module_functions[27].cleanup_function = NULL;
    _module_functions[27].params = NULL;

    /* Function: dir_list */
    _module_functions[28].name = "dir_list";
    _module_functions[28].param_count = 0;
    _module_functions[28].return_type = 7;
    _module_functions[28].return_struct_type_name = NULL;
    _module_functions[28].return_fn_sig = NULL;
    _module_functions[28].return_type_info = NULL;
    _module_functions[28].body = NULL;
    _module_functions[28].shadow_test = NULL;
    _module_functions[28].is_extern = false;
    _module_functions[28].returns_gc_managed = false;
    _module_functions[28].requires_manual_free = false;
    _module_functions[28].returns_borrowed = false;
    _module_functions[28].cleanup_function = NULL;
    _module_functions[28].params = NULL;

    /* Function: process_run */
    _module_functions[29].name = "process_run";
    _module_functions[29].param_count = 0;
    _module_functions[29].return_type = 7;
    _module_functions[29].return_struct_type_name = NULL;
    _module_functions[29].return_fn_sig = NULL;
    _module_functions[29].return_type_info = NULL;
    _module_functions[29].body = NULL;
    _module_functions[29].shadow_test = NULL;
    _module_functions[29].is_extern = false;
    _module_functions[29].returns_gc_managed = false;
    _module_functions[29].requires_manual_free = false;
    _module_functions[29].returns_borrowed = false;
    _module_functions[29].cleanup_function = NULL;
    _module_functions[29].params = NULL;

    /* Function: tmp_dir */
    _module_functions[30].name = "tmp_dir";
    _module_functions[30].param_count = 0;
    _module_functions[30].return_type = 4;
    _module_functions[30].return_struct_type_name = NULL;
    _module_functions[30].return_fn_sig = NULL;
    _module_functions[30].return_type_info = NULL;
    _module_functions[30].body = NULL;
    _module_functions[30].shadow_test = NULL;
    _module_functions[30].is_extern = false;
    _module_functions[30].returns_gc_managed = true;
    _module_functions[30].requires_manual_free = false;
    _module_functions[30].returns_borrowed = false;
    _module_functions[30].cleanup_function = NULL;
    _module_functions[30].params = NULL;

    /* Function: mktemp */
    _module_functions[31].name = "mktemp";
    _module_functions[31].param_count = 0;
    _module_functions[31].return_type = 4;
    _module_functions[31].return_struct_type_name = NULL;
    _module_functions[31].return_fn_sig = NULL;
    _module_functions[31].return_type_info = NULL;
    _module_functions[31].body = NULL;
    _module_functions[31].shadow_test = NULL;
    _module_functions[31].is_extern = false;
    _module_functions[31].returns_gc_managed = true;
    _module_functions[31].requires_manual_free = false;
    _module_functions[31].returns_borrowed = false;
    _module_functions[31].cleanup_function = NULL;
    _module_functions[31].params = NULL;

    /* Function: mktemp_dir */
    _module_functions[32].name = "mktemp_dir";
    _module_functions[32].param_count = 0;
    _module_functions[32].return_type = 4;
    _module_functions[32].return_struct_type_name = NULL;
    _module_functions[32].return_fn_sig = NULL;
    _module_functions[32].return_type_info = NULL;
    _module_functions[32].body = NULL;
    _module_functions[32].shadow_test = NULL;
    _module_functions[32].is_extern = false;
    _module_functions[32].returns_gc_managed = true;
    _module_functions[32].requires_manual_free = false;
    _module_functions[32].returns_borrowed = false;
    _module_functions[32].cleanup_function = NULL;
    _module_functions[32].params = NULL;

    /* Function: char_at */
    _module_functions[33].name = "char_at";
    _module_functions[33].param_count = 0;
    _module_functions[33].return_type = 0;
    _module_functions[33].return_struct_type_name = NULL;
    _module_functions[33].return_fn_sig = NULL;
    _module_functions[33].return_type_info = NULL;
    _module_functions[33].body = NULL;
    _module_functions[33].shadow_test = NULL;
    _module_functions[33].is_extern = false;
    _module_functions[33].returns_gc_managed = false;
    _module_functions[33].requires_manual_free = false;
    _module_functions[33].returns_borrowed = false;
    _module_functions[33].cleanup_function = NULL;
    _module_functions[33].params = NULL;

    /* Function: string_from_char */
    _module_functions[34].name = "string_from_char";
    _module_functions[34].param_count = 0;
    _module_functions[34].return_type = 4;
    _module_functions[34].return_struct_type_name = NULL;
    _module_functions[34].return_fn_sig = NULL;
    _module_functions[34].return_type_info = NULL;
    _module_functions[34].body = NULL;
    _module_functions[34].shadow_test = NULL;
    _module_functions[34].is_extern = false;
    _module_functions[34].returns_gc_managed = true;
    _module_functions[34].requires_manual_free = false;
    _module_functions[34].returns_borrowed = false;
    _module_functions[34].cleanup_function = NULL;
    _module_functions[34].params = NULL;

    /* Function: is_digit */
    _module_functions[35].name = "is_digit";
    _module_functions[35].param_count = 0;
    _module_functions[35].return_type = 3;
    _module_functions[35].return_struct_type_name = NULL;
    _module_functions[35].return_fn_sig = NULL;
    _module_functions[35].return_type_info = NULL;
    _module_functions[35].body = NULL;
    _module_functions[35].shadow_test = NULL;
    _module_functions[35].is_extern = false;
    _module_functions[35].returns_gc_managed = false;
    _module_functions[35].requires_manual_free = false;
    _module_functions[35].returns_borrowed = false;
    _module_functions[35].cleanup_function = NULL;
    _module_functions[35].params = NULL;

    /* Function: is_alpha */
    _module_functions[36].name = "is_alpha";
    _module_functions[36].param_count = 0;
    _module_functions[36].return_type = 3;
    _module_functions[36].return_struct_type_name = NULL;
    _module_functions[36].return_fn_sig = NULL;
    _module_functions[36].return_type_info = NULL;
    _module_functions[36].body = NULL;
    _module_functions[36].shadow_test = NULL;
    _module_functions[36].is_extern = false;
    _module_functions[36].returns_gc_managed = false;
    _module_functions[36].requires_manual_free = false;
    _module_functions[36].returns_borrowed = false;
    _module_functions[36].cleanup_function = NULL;
    _module_functions[36].params = NULL;

    /* Function: is_alnum */
    _module_functions[37].name = "is_alnum";
    _module_functions[37].param_count = 0;
    _module_functions[37].return_type = 3;
    _module_functions[37].return_struct_type_name = NULL;
    _module_functions[37].return_fn_sig = NULL;
    _module_functions[37].return_type_info = NULL;
    _module_functions[37].body = NULL;
    _module_functions[37].shadow_test = NULL;
    _module_functions[37].is_extern = false;
    _module_functions[37].returns_gc_managed = false;
    _module_functions[37].requires_manual_free = false;
    _module_functions[37].returns_borrowed = false;
    _module_functions[37].cleanup_function = NULL;
    _module_functions[37].params = NULL;

    /* Function: is_whitespace */
    _module_functions[38].name = "is_whitespace";
    _module_functions[38].param_count = 0;
    _module_functions[38].return_type = 3;
    _module_functions[38].return_struct_type_name = NULL;
    _module_functions[38].return_fn_sig = NULL;
    _module_functions[38].return_type_info = NULL;
    _module_functions[38].body = NULL;
    _module_functions[38].shadow_test = NULL;
    _module_functions[38].is_extern = false;
    _module_functions[38].returns_gc_managed = false;
    _module_functions[38].requires_manual_free = false;
    _module_functions[38].returns_borrowed = false;
    _module_functions[38].cleanup_function = NULL;
    _module_functions[38].params = NULL;

    /* Function: is_upper */
    _module_functions[39].name = "is_upper";
    _module_functions[39].param_count = 0;
    _module_functions[39].return_type = 3;
    _module_functions[39].return_struct_type_name = NULL;
    _module_functions[39].return_fn_sig = NULL;
    _module_functions[39].return_type_info = NULL;
    _module_functions[39].body = NULL;
    _module_functions[39].shadow_test = NULL;
    _module_functions[39].is_extern = false;
    _module_functions[39].returns_gc_managed = false;
    _module_functions[39].requires_manual_free = false;
    _module_functions[39].returns_borrowed = false;
    _module_functions[39].cleanup_function = NULL;
    _module_functions[39].params = NULL;

    /* Function: is_lower */
    _module_functions[40].name = "is_lower";
    _module_functions[40].param_count = 0;
    _module_functions[40].return_type = 3;
    _module_functions[40].return_struct_type_name = NULL;
    _module_functions[40].return_fn_sig = NULL;
    _module_functions[40].return_type_info = NULL;
    _module_functions[40].body = NULL;
    _module_functions[40].shadow_test = NULL;
    _module_functions[40].is_extern = false;
    _module_functions[40].returns_gc_managed = false;
    _module_functions[40].requires_manual_free = false;
    _module_functions[40].returns_borrowed = false;
    _module_functions[40].cleanup_function = NULL;
    _module_functions[40].params = NULL;

    /* Function: int_to_string */
    _module_functions[41].name = "int_to_string";
    _module_functions[41].param_count = 0;
    _module_functions[41].return_type = 4;
    _module_functions[41].return_struct_type_name = NULL;
    _module_functions[41].return_fn_sig = NULL;
    _module_functions[41].return_type_info = NULL;
    _module_functions[41].body = NULL;
    _module_functions[41].shadow_test = NULL;
    _module_functions[41].is_extern = false;
    _module_functions[41].returns_gc_managed = true;
    _module_functions[41].requires_manual_free = false;
    _module_functions[41].returns_borrowed = false;
    _module_functions[41].cleanup_function = NULL;
    _module_functions[41].params = NULL;

    /* Function: string_to_int */
    _module_functions[42].name = "string_to_int";
    _module_functions[42].param_count = 0;
    _module_functions[42].return_type = 0;
    _module_functions[42].return_struct_type_name = NULL;
    _module_functions[42].return_fn_sig = NULL;
    _module_functions[42].return_type_info = NULL;
    _module_functions[42].body = NULL;
    _module_functions[42].shadow_test = NULL;
    _module_functions[42].is_extern = false;
    _module_functions[42].returns_gc_managed = false;
    _module_functions[42].requires_manual_free = false;
    _module_functions[42].returns_borrowed = false;
    _module_functions[42].cleanup_function = NULL;
    _module_functions[42].params = NULL;

    /* Function: digit_value */
    _module_functions[43].name = "digit_value";
    _module_functions[43].param_count = 0;
    _module_functions[43].return_type = 0;
    _module_functions[43].return_struct_type_name = NULL;
    _module_functions[43].return_fn_sig = NULL;
    _module_functions[43].return_type_info = NULL;
    _module_functions[43].body = NULL;
    _module_functions[43].shadow_test = NULL;
    _module_functions[43].is_extern = false;
    _module_functions[43].returns_gc_managed = false;
    _module_functions[43].requires_manual_free = false;
    _module_functions[43].returns_borrowed = false;
    _module_functions[43].cleanup_function = NULL;
    _module_functions[43].params = NULL;

    /* Function: char_to_lower */
    _module_functions[44].name = "char_to_lower";
    _module_functions[44].param_count = 0;
    _module_functions[44].return_type = 0;
    _module_functions[44].return_struct_type_name = NULL;
    _module_functions[44].return_fn_sig = NULL;
    _module_functions[44].return_type_info = NULL;
    _module_functions[44].body = NULL;
    _module_functions[44].shadow_test = NULL;
    _module_functions[44].is_extern = false;
    _module_functions[44].returns_gc_managed = false;
    _module_functions[44].requires_manual_free = false;
    _module_functions[44].returns_borrowed = false;
    _module_functions[44].cleanup_function = NULL;
    _module_functions[44].params = NULL;

    /* Function: char_to_upper */
    _module_functions[45].name = "char_to_upper";
    _module_functions[45].param_count = 0;
    _module_functions[45].return_type = 0;
    _module_functions[45].return_struct_type_name = NULL;
    _module_functions[45].return_fn_sig = NULL;
    _module_functions[45].return_type_info = NULL;
    _module_functions[45].body = NULL;
    _module_functions[45].shadow_test = NULL;
    _module_functions[45].is_extern = false;
    _module_functions[45].returns_gc_managed = false;
    _module_functions[45].requires_manual_free = false;
    _module_functions[45].returns_borrowed = false;
    _module_functions[45].cleanup_function = NULL;
    _module_functions[45].params = NULL;

    /* Function: list_int_new */
    _module_functions[46].name = "list_int_new";
    _module_functions[46].param_count = 0;
    _module_functions[46].return_type = 12;
    _module_functions[46].return_struct_type_name = NULL;
    _module_functions[46].return_fn_sig = NULL;
    _module_functions[46].return_type_info = NULL;
    _module_functions[46].body = NULL;
    _module_functions[46].shadow_test = NULL;
    _module_functions[46].is_extern = false;
    _module_functions[46].returns_gc_managed = false;
    _module_functions[46].requires_manual_free = false;
    _module_functions[46].returns_borrowed = false;
    _module_functions[46].cleanup_function = NULL;
    _module_functions[46].params = NULL;

    /* Function: list_int_with_capacity */
    _module_functions[47].name = "list_int_with_capacity";
    _module_functions[47].param_count = 0;
    _module_functions[47].return_type = 12;
    _module_functions[47].return_struct_type_name = NULL;
    _module_functions[47].return_fn_sig = NULL;
    _module_functions[47].return_type_info = NULL;
    _module_functions[47].body = NULL;
    _module_functions[47].shadow_test = NULL;
    _module_functions[47].is_extern = false;
    _module_functions[47].returns_gc_managed = false;
    _module_functions[47].requires_manual_free = false;
    _module_functions[47].returns_borrowed = false;
    _module_functions[47].cleanup_function = NULL;
    _module_functions[47].params = NULL;

    /* Function: list_int_push */
    _module_functions[48].name = "list_int_push";
    _module_functions[48].param_count = 0;
    _module_functions[48].return_type = 6;
    _module_functions[48].return_struct_type_name = NULL;
    _module_functions[48].return_fn_sig = NULL;
    _module_functions[48].return_type_info = NULL;
    _module_functions[48].body = NULL;
    _module_functions[48].shadow_test = NULL;
    _module_functions[48].is_extern = false;
    _module_functions[48].returns_gc_managed = false;
    _module_functions[48].requires_manual_free = false;
    _module_functions[48].returns_borrowed = false;
    _module_functions[48].cleanup_function = NULL;
    _module_functions[48].params = NULL;

    /* Function: list_int_pop */
    _module_functions[49].name = "list_int_pop";
    _module_functions[49].param_count = 0;
    _module_functions[49].return_type = 0;
    _module_functions[49].return_struct_type_name = NULL;
    _module_functions[49].return_fn_sig = NULL;
    _module_functions[49].return_type_info = NULL;
    _module_functions[49].body = NULL;
    _module_functions[49].shadow_test = NULL;
    _module_functions[49].is_extern = false;
    _module_functions[49].returns_gc_managed = false;
    _module_functions[49].requires_manual_free = false;
    _module_functions[49].returns_borrowed = false;
    _module_functions[49].cleanup_function = NULL;
    _module_functions[49].params = NULL;

    /* Function: list_int_get */
    _module_functions[50].name = "list_int_get";
    _module_functions[50].param_count = 0;
    _module_functions[50].return_type = 0;
    _module_functions[50].return_struct_type_name = NULL;
    _module_functions[50].return_fn_sig = NULL;
    _module_functions[50].return_type_info = NULL;
    _module_functions[50].body = NULL;
    _module_functions[50].shadow_test = NULL;
    _module_functions[50].is_extern = false;
    _module_functions[50].returns_gc_managed = false;
    _module_functions[50].requires_manual_free = false;
    _module_functions[50].returns_borrowed = false;
    _module_functions[50].cleanup_function = NULL;
    _module_functions[50].params = NULL;

    /* Function: list_int_set */
    _module_functions[51].name = "list_int_set";
    _module_functions[51].param_count = 0;
    _module_functions[51].return_type = 6;
    _module_functions[51].return_struct_type_name = NULL;
    _module_functions[51].return_fn_sig = NULL;
    _module_functions[51].return_type_info = NULL;
    _module_functions[51].body = NULL;
    _module_functions[51].shadow_test = NULL;
    _module_functions[51].is_extern = false;
    _module_functions[51].returns_gc_managed = false;
    _module_functions[51].requires_manual_free = false;
    _module_functions[51].returns_borrowed = false;
    _module_functions[51].cleanup_function = NULL;
    _module_functions[51].params = NULL;

    /* Function: list_int_insert */
    _module_functions[52].name = "list_int_insert";
    _module_functions[52].param_count = 0;
    _module_functions[52].return_type = 6;
    _module_functions[52].return_struct_type_name = NULL;
    _module_functions[52].return_fn_sig = NULL;
    _module_functions[52].return_type_info = NULL;
    _module_functions[52].body = NULL;
    _module_functions[52].shadow_test = NULL;
    _module_functions[52].is_extern = false;
    _module_functions[52].returns_gc_managed = false;
    _module_functions[52].requires_manual_free = false;
    _module_functions[52].returns_borrowed = false;
    _module_functions[52].cleanup_function = NULL;
    _module_functions[52].params = NULL;

    /* Function: list_int_remove */
    _module_functions[53].name = "list_int_remove";
    _module_functions[53].param_count = 0;
    _module_functions[53].return_type = 0;
    _module_functions[53].return_struct_type_name = NULL;
    _module_functions[53].return_fn_sig = NULL;
    _module_functions[53].return_type_info = NULL;
    _module_functions[53].body = NULL;
    _module_functions[53].shadow_test = NULL;
    _module_functions[53].is_extern = false;
    _module_functions[53].returns_gc_managed = false;
    _module_functions[53].requires_manual_free = false;
    _module_functions[53].returns_borrowed = false;
    _module_functions[53].cleanup_function = NULL;
    _module_functions[53].params = NULL;

    /* Function: list_int_length */
    _module_functions[54].name = "list_int_length";
    _module_functions[54].param_count = 0;
    _module_functions[54].return_type = 0;
    _module_functions[54].return_struct_type_name = NULL;
    _module_functions[54].return_fn_sig = NULL;
    _module_functions[54].return_type_info = NULL;
    _module_functions[54].body = NULL;
    _module_functions[54].shadow_test = NULL;
    _module_functions[54].is_extern = false;
    _module_functions[54].returns_gc_managed = false;
    _module_functions[54].requires_manual_free = false;
    _module_functions[54].returns_borrowed = false;
    _module_functions[54].cleanup_function = NULL;
    _module_functions[54].params = NULL;

    /* Function: list_int_capacity */
    _module_functions[55].name = "list_int_capacity";
    _module_functions[55].param_count = 0;
    _module_functions[55].return_type = 0;
    _module_functions[55].return_struct_type_name = NULL;
    _module_functions[55].return_fn_sig = NULL;
    _module_functions[55].return_type_info = NULL;
    _module_functions[55].body = NULL;
    _module_functions[55].shadow_test = NULL;
    _module_functions[55].is_extern = false;
    _module_functions[55].returns_gc_managed = false;
    _module_functions[55].requires_manual_free = false;
    _module_functions[55].returns_borrowed = false;
    _module_functions[55].cleanup_function = NULL;
    _module_functions[55].params = NULL;

    /* Function: list_int_is_empty */
    _module_functions[56].name = "list_int_is_empty";
    _module_functions[56].param_count = 0;
    _module_functions[56].return_type = 3;
    _module_functions[56].return_struct_type_name = NULL;
    _module_functions[56].return_fn_sig = NULL;
    _module_functions[56].return_type_info = NULL;
    _module_functions[56].body = NULL;
    _module_functions[56].shadow_test = NULL;
    _module_functions[56].is_extern = false;
    _module_functions[56].returns_gc_managed = false;
    _module_functions[56].requires_manual_free = false;
    _module_functions[56].returns_borrowed = false;
    _module_functions[56].cleanup_function = NULL;
    _module_functions[56].params = NULL;

    /* Function: list_int_clear */
    _module_functions[57].name = "list_int_clear";
    _module_functions[57].param_count = 0;
    _module_functions[57].return_type = 6;
    _module_functions[57].return_struct_type_name = NULL;
    _module_functions[57].return_fn_sig = NULL;
    _module_functions[57].return_type_info = NULL;
    _module_functions[57].body = NULL;
    _module_functions[57].shadow_test = NULL;
    _module_functions[57].is_extern = false;
    _module_functions[57].returns_gc_managed = false;
    _module_functions[57].requires_manual_free = false;
    _module_functions[57].returns_borrowed = false;
    _module_functions[57].cleanup_function = NULL;
    _module_functions[57].params = NULL;

    /* Function: list_int_free */
    _module_functions[58].name = "list_int_free";
    _module_functions[58].param_count = 0;
    _module_functions[58].return_type = 6;
    _module_functions[58].return_struct_type_name = NULL;
    _module_functions[58].return_fn_sig = NULL;
    _module_functions[58].return_type_info = NULL;
    _module_functions[58].body = NULL;
    _module_functions[58].shadow_test = NULL;
    _module_functions[58].is_extern = false;
    _module_functions[58].returns_gc_managed = false;
    _module_functions[58].requires_manual_free = false;
    _module_functions[58].returns_borrowed = false;
    _module_functions[58].cleanup_function = NULL;
    _module_functions[58].params = NULL;

    /* Function: list_string_new */
    _module_functions[59].name = "list_string_new";
    _module_functions[59].param_count = 0;
    _module_functions[59].return_type = 13;
    _module_functions[59].return_struct_type_name = NULL;
    _module_functions[59].return_fn_sig = NULL;
    _module_functions[59].return_type_info = NULL;
    _module_functions[59].body = NULL;
    _module_functions[59].shadow_test = NULL;
    _module_functions[59].is_extern = false;
    _module_functions[59].returns_gc_managed = false;
    _module_functions[59].requires_manual_free = false;
    _module_functions[59].returns_borrowed = false;
    _module_functions[59].cleanup_function = NULL;
    _module_functions[59].params = NULL;

    /* Function: list_string_with_capacity */
    _module_functions[60].name = "list_string_with_capacity";
    _module_functions[60].param_count = 0;
    _module_functions[60].return_type = 13;
    _module_functions[60].return_struct_type_name = NULL;
    _module_functions[60].return_fn_sig = NULL;
    _module_functions[60].return_type_info = NULL;
    _module_functions[60].body = NULL;
    _module_functions[60].shadow_test = NULL;
    _module_functions[60].is_extern = false;
    _module_functions[60].returns_gc_managed = false;
    _module_functions[60].requires_manual_free = false;
    _module_functions[60].returns_borrowed = false;
    _module_functions[60].cleanup_function = NULL;
    _module_functions[60].params = NULL;

    /* Function: list_string_push */
    _module_functions[61].name = "list_string_push";
    _module_functions[61].param_count = 0;
    _module_functions[61].return_type = 6;
    _module_functions[61].return_struct_type_name = NULL;
    _module_functions[61].return_fn_sig = NULL;
    _module_functions[61].return_type_info = NULL;
    _module_functions[61].body = NULL;
    _module_functions[61].shadow_test = NULL;
    _module_functions[61].is_extern = false;
    _module_functions[61].returns_gc_managed = false;
    _module_functions[61].requires_manual_free = false;
    _module_functions[61].returns_borrowed = false;
    _module_functions[61].cleanup_function = NULL;
    _module_functions[61].params = NULL;

    /* Function: list_string_pop */
    _module_functions[62].name = "list_string_pop";
    _module_functions[62].param_count = 0;
    _module_functions[62].return_type = 4;
    _module_functions[62].return_struct_type_name = NULL;
    _module_functions[62].return_fn_sig = NULL;
    _module_functions[62].return_type_info = NULL;
    _module_functions[62].body = NULL;
    _module_functions[62].shadow_test = NULL;
    _module_functions[62].is_extern = false;
    _module_functions[62].returns_gc_managed = true;
    _module_functions[62].requires_manual_free = false;
    _module_functions[62].returns_borrowed = false;
    _module_functions[62].cleanup_function = NULL;
    _module_functions[62].params = NULL;

    /* Function: list_string_get */
    _module_functions[63].name = "list_string_get";
    _module_functions[63].param_count = 0;
    _module_functions[63].return_type = 4;
    _module_functions[63].return_struct_type_name = NULL;
    _module_functions[63].return_fn_sig = NULL;
    _module_functions[63].return_type_info = NULL;
    _module_functions[63].body = NULL;
    _module_functions[63].shadow_test = NULL;
    _module_functions[63].is_extern = false;
    _module_functions[63].returns_gc_managed = true;
    _module_functions[63].requires_manual_free = false;
    _module_functions[63].returns_borrowed = false;
    _module_functions[63].cleanup_function = NULL;
    _module_functions[63].params = NULL;

    /* Function: list_string_set */
    _module_functions[64].name = "list_string_set";
    _module_functions[64].param_count = 0;
    _module_functions[64].return_type = 6;
    _module_functions[64].return_struct_type_name = NULL;
    _module_functions[64].return_fn_sig = NULL;
    _module_functions[64].return_type_info = NULL;
    _module_functions[64].body = NULL;
    _module_functions[64].shadow_test = NULL;
    _module_functions[64].is_extern = false;
    _module_functions[64].returns_gc_managed = false;
    _module_functions[64].requires_manual_free = false;
    _module_functions[64].returns_borrowed = false;
    _module_functions[64].cleanup_function = NULL;
    _module_functions[64].params = NULL;

    /* Function: list_string_insert */
    _module_functions[65].name = "list_string_insert";
    _module_functions[65].param_count = 0;
    _module_functions[65].return_type = 6;
    _module_functions[65].return_struct_type_name = NULL;
    _module_functions[65].return_fn_sig = NULL;
    _module_functions[65].return_type_info = NULL;
    _module_functions[65].body = NULL;
    _module_functions[65].shadow_test = NULL;
    _module_functions[65].is_extern = false;
    _module_functions[65].returns_gc_managed = false;
    _module_functions[65].requires_manual_free = false;
    _module_functions[65].returns_borrowed = false;
    _module_functions[65].cleanup_function = NULL;
    _module_functions[65].params = NULL;

    /* Function: list_string_remove */
    _module_functions[66].name = "list_string_remove";
    _module_functions[66].param_count = 0;
    _module_functions[66].return_type = 4;
    _module_functions[66].return_struct_type_name = NULL;
    _module_functions[66].return_fn_sig = NULL;
    _module_functions[66].return_type_info = NULL;
    _module_functions[66].body = NULL;
    _module_functions[66].shadow_test = NULL;
    _module_functions[66].is_extern = false;
    _module_functions[66].returns_gc_managed = true;
    _module_functions[66].requires_manual_free = false;
    _module_functions[66].returns_borrowed = false;
    _module_functions[66].cleanup_function = NULL;
    _module_functions[66].params = NULL;

    /* Function: list_string_length */
    _module_functions[67].name = "list_string_length";
    _module_functions[67].param_count = 0;
    _module_functions[67].return_type = 0;
    _module_functions[67].return_struct_type_name = NULL;
    _module_functions[67].return_fn_sig = NULL;
    _module_functions[67].return_type_info = NULL;
    _module_functions[67].body = NULL;
    _module_functions[67].shadow_test = NULL;
    _module_functions[67].is_extern = false;
    _module_functions[67].returns_gc_managed = false;
    _module_functions[67].requires_manual_free = false;
    _module_functions[67].returns_borrowed = false;
    _module_functions[67].cleanup_function = NULL;
    _module_functions[67].params = NULL;

    /* Function: list_string_capacity */
    _module_functions[68].name = "list_string_capacity";
    _module_functions[68].param_count = 0;
    _module_functions[68].return_type = 0;
    _module_functions[68].return_struct_type_name = NULL;
    _module_functions[68].return_fn_sig = NULL;
    _module_functions[68].return_type_info = NULL;
    _module_functions[68].body = NULL;
    _module_functions[68].shadow_test = NULL;
    _module_functions[68].is_extern = false;
    _module_functions[68].returns_gc_managed = false;
    _module_functions[68].requires_manual_free = false;
    _module_functions[68].returns_borrowed = false;
    _module_functions[68].cleanup_function = NULL;
    _module_functions[68].params = NULL;

    /* Function: list_string_is_empty */
    _module_functions[69].name = "list_string_is_empty";
    _module_functions[69].param_count = 0;
    _module_functions[69].return_type = 3;
    _module_functions[69].return_struct_type_name = NULL;
    _module_functions[69].return_fn_sig = NULL;
    _module_functions[69].return_type_info = NULL;
    _module_functions[69].body = NULL;
    _module_functions[69].shadow_test = NULL;
    _module_functions[69].is_extern = false;
    _module_functions[69].returns_gc_managed = false;
    _module_functions[69].requires_manual_free = false;
    _module_functions[69].returns_borrowed = false;
    _module_functions[69].cleanup_function = NULL;
    _module_functions[69].params = NULL;

    /* Function: list_string_clear */
    _module_functions[70].name = "list_string_clear";
    _module_functions[70].param_count = 0;
    _module_functions[70].return_type = 6;
    _module_functions[70].return_struct_type_name = NULL;
    _module_functions[70].return_fn_sig = NULL;
    _module_functions[70].return_type_info = NULL;
    _module_functions[70].body = NULL;
    _module_functions[70].shadow_test = NULL;
    _module_functions[70].is_extern = false;
    _module_functions[70].returns_gc_managed = false;
    _module_functions[70].requires_manual_free = false;
    _module_functions[70].returns_borrowed = false;
    _module_functions[70].cleanup_function = NULL;
    _module_functions[70].params = NULL;

    /* Function: list_string_free */
    _module_functions[71].name = "list_string_free";
    _module_functions[71].param_count = 0;
    _module_functions[71].return_type = 6;
    _module_functions[71].return_struct_type_name = NULL;
    _module_functions[71].return_fn_sig = NULL;
    _module_functions[71].return_type_info = NULL;
    _module_functions[71].body = NULL;
    _module_functions[71].shadow_test = NULL;
    _module_functions[71].is_extern = false;
    _module_functions[71].returns_gc_managed = false;
    _module_functions[71].requires_manual_free = false;
    _module_functions[71].returns_borrowed = false;
    _module_functions[71].cleanup_function = NULL;
    _module_functions[71].params = NULL;

    /* Function: nl_list_Token_new */
    _module_functions[72].name = "nl_list_Token_new";
    _module_functions[72].param_count = 0;
    _module_functions[72].return_type = 14;
    _module_functions[72].return_struct_type_name = NULL;
    _module_functions[72].return_fn_sig = NULL;
    _module_functions[72].return_type_info = NULL;
    _module_functions[72].body = NULL;
    _module_functions[72].shadow_test = NULL;
    _module_functions[72].is_extern = false;
    _module_functions[72].returns_gc_managed = false;
    _module_functions[72].requires_manual_free = false;
    _module_functions[72].returns_borrowed = false;
    _module_functions[72].cleanup_function = NULL;
    _module_functions[72].params = NULL;

    /* Function: nl_list_Token_with_capacity */
    _module_functions[73].name = "nl_list_Token_with_capacity";
    _module_functions[73].param_count = 0;
    _module_functions[73].return_type = 14;
    _module_functions[73].return_struct_type_name = NULL;
    _module_functions[73].return_fn_sig = NULL;
    _module_functions[73].return_type_info = NULL;
    _module_functions[73].body = NULL;
    _module_functions[73].shadow_test = NULL;
    _module_functions[73].is_extern = false;
    _module_functions[73].returns_gc_managed = false;
    _module_functions[73].requires_manual_free = false;
    _module_functions[73].returns_borrowed = false;
    _module_functions[73].cleanup_function = NULL;
    _module_functions[73].params = NULL;

    /* Function: nl_list_Token_push */
    _module_functions[74].name = "nl_list_Token_push";
    _module_functions[74].param_count = 0;
    _module_functions[74].return_type = 6;
    _module_functions[74].return_struct_type_name = NULL;
    _module_functions[74].return_fn_sig = NULL;
    _module_functions[74].return_type_info = NULL;
    _module_functions[74].body = NULL;
    _module_functions[74].shadow_test = NULL;
    _module_functions[74].is_extern = false;
    _module_functions[74].returns_gc_managed = false;
    _module_functions[74].requires_manual_free = false;
    _module_functions[74].returns_borrowed = false;
    _module_functions[74].cleanup_function = NULL;
    _module_functions[74].params = NULL;

    /* Function: nl_list_Token_pop */
    _module_functions[75].name = "nl_list_Token_pop";
    _module_functions[75].param_count = 0;
    _module_functions[75].return_type = 8;
    _module_functions[75].return_struct_type_name = NULL;
    _module_functions[75].return_fn_sig = NULL;
    _module_functions[75].return_type_info = NULL;
    _module_functions[75].body = NULL;
    _module_functions[75].shadow_test = NULL;
    _module_functions[75].is_extern = false;
    _module_functions[75].returns_gc_managed = false;
    _module_functions[75].requires_manual_free = false;
    _module_functions[75].returns_borrowed = false;
    _module_functions[75].cleanup_function = NULL;
    _module_functions[75].params = NULL;

    /* Function: nl_list_Token_get */
    _module_functions[76].name = "nl_list_Token_get";
    _module_functions[76].param_count = 0;
    _module_functions[76].return_type = 8;
    _module_functions[76].return_struct_type_name = NULL;
    _module_functions[76].return_fn_sig = NULL;
    _module_functions[76].return_type_info = NULL;
    _module_functions[76].body = NULL;
    _module_functions[76].shadow_test = NULL;
    _module_functions[76].is_extern = false;
    _module_functions[76].returns_gc_managed = false;
    _module_functions[76].requires_manual_free = false;
    _module_functions[76].returns_borrowed = false;
    _module_functions[76].cleanup_function = NULL;
    _module_functions[76].params = NULL;

    /* Function: nl_list_Token_set */
    _module_functions[77].name = "nl_list_Token_set";
    _module_functions[77].param_count = 0;
    _module_functions[77].return_type = 6;
    _module_functions[77].return_struct_type_name = NULL;
    _module_functions[77].return_fn_sig = NULL;
    _module_functions[77].return_type_info = NULL;
    _module_functions[77].body = NULL;
    _module_functions[77].shadow_test = NULL;
    _module_functions[77].is_extern = false;
    _module_functions[77].returns_gc_managed = false;
    _module_functions[77].requires_manual_free = false;
    _module_functions[77].returns_borrowed = false;
    _module_functions[77].cleanup_function = NULL;
    _module_functions[77].params = NULL;

    /* Function: nl_list_Token_insert */
    _module_functions[78].name = "nl_list_Token_insert";
    _module_functions[78].param_count = 0;
    _module_functions[78].return_type = 6;
    _module_functions[78].return_struct_type_name = NULL;
    _module_functions[78].return_fn_sig = NULL;
    _module_functions[78].return_type_info = NULL;
    _module_functions[78].body = NULL;
    _module_functions[78].shadow_test = NULL;
    _module_functions[78].is_extern = false;
    _module_functions[78].returns_gc_managed = false;
    _module_functions[78].requires_manual_free = false;
    _module_functions[78].returns_borrowed = false;
    _module_functions[78].cleanup_function = NULL;
    _module_functions[78].params = NULL;

    /* Function: nl_list_Token_remove */
    _module_functions[79].name = "nl_list_Token_remove";
    _module_functions[79].param_count = 0;
    _module_functions[79].return_type = 8;
    _module_functions[79].return_struct_type_name = NULL;
    _module_functions[79].return_fn_sig = NULL;
    _module_functions[79].return_type_info = NULL;
    _module_functions[79].body = NULL;
    _module_functions[79].shadow_test = NULL;
    _module_functions[79].is_extern = false;
    _module_functions[79].returns_gc_managed = false;
    _module_functions[79].requires_manual_free = false;
    _module_functions[79].returns_borrowed = false;
    _module_functions[79].cleanup_function = NULL;
    _module_functions[79].params = NULL;

    /* Function: nl_list_Token_length */
    _module_functions[80].name = "nl_list_Token_length";
    _module_functions[80].param_count = 0;
    _module_functions[80].return_type = 0;
    _module_functions[80].return_struct_type_name = NULL;
    _module_functions[80].return_fn_sig = NULL;
    _module_functions[80].return_type_info = NULL;
    _module_functions[80].body = NULL;
    _module_functions[80].shadow_test = NULL;
    _module_functions[80].is_extern = false;
    _module_functions[80].returns_gc_managed = false;
    _module_functions[80].requires_manual_free = false;
    _module_functions[80].returns_borrowed = false;
    _module_functions[80].cleanup_function = NULL;
    _module_functions[80].params = NULL;

    /* Function: nl_list_Token_capacity */
    _module_functions[81].name = "nl_list_Token_capacity";
    _module_functions[81].param_count = 0;
    _module_functions[81].return_type = 0;
    _module_functions[81].return_struct_type_name = NULL;
    _module_functions[81].return_fn_sig = NULL;
    _module_functions[81].return_type_info = NULL;
    _module_functions[81].body = NULL;
    _module_functions[81].shadow_test = NULL;
    _module_functions[81].is_extern = false;
    _module_functions[81].returns_gc_managed = false;
    _module_functions[81].requires_manual_free = false;
    _module_functions[81].returns_borrowed = false;
    _module_functions[81].cleanup_function = NULL;
    _module_functions[81].params = NULL;

    /* Function: nl_list_Token_is_empty */
    _module_functions[82].name = "nl_list_Token_is_empty";
    _module_functions[82].param_count = 0;
    _module_functions[82].return_type = 3;
    _module_functions[82].return_struct_type_name = NULL;
    _module_functions[82].return_fn_sig = NULL;
    _module_functions[82].return_type_info = NULL;
    _module_functions[82].body = NULL;
    _module_functions[82].shadow_test = NULL;
    _module_functions[82].is_extern = false;
    _module_functions[82].returns_gc_managed = false;
    _module_functions[82].requires_manual_free = false;
    _module_functions[82].returns_borrowed = false;
    _module_functions[82].cleanup_function = NULL;
    _module_functions[82].params = NULL;

    /* Function: nl_list_Token_clear */
    _module_functions[83].name = "nl_list_Token_clear";
    _module_functions[83].param_count = 0;
    _module_functions[83].return_type = 6;
    _module_functions[83].return_struct_type_name = NULL;
    _module_functions[83].return_fn_sig = NULL;
    _module_functions[83].return_type_info = NULL;
    _module_functions[83].body = NULL;
    _module_functions[83].shadow_test = NULL;
    _module_functions[83].is_extern = false;
    _module_functions[83].returns_gc_managed = false;
    _module_functions[83].requires_manual_free = false;
    _module_functions[83].returns_borrowed = false;
    _module_functions[83].cleanup_function = NULL;
    _module_functions[83].params = NULL;

    /* Function: nl_list_Token_free */
    _module_functions[84].name = "nl_list_Token_free";
    _module_functions[84].param_count = 0;
    _module_functions[84].return_type = 6;
    _module_functions[84].return_struct_type_name = NULL;
    _module_functions[84].return_fn_sig = NULL;
    _module_functions[84].return_type_info = NULL;
    _module_functions[84].body = NULL;
    _module_functions[84].shadow_test = NULL;
    _module_functions[84].is_extern = false;
    _module_functions[84].returns_gc_managed = false;
    _module_functions[84].requires_manual_free = false;
    _module_functions[84].returns_borrowed = false;
    _module_functions[84].cleanup_function = NULL;
    _module_functions[84].params = NULL;

}

ModuleMetadata _module_metadata_cjson_provider = {
    .module_name = "cjson_provider",
    .function_count = 85,
    .functions = _module_functions,
    .struct_count = 0,
    .structs = NULL,  /* TODO: serialize structs */
    .enum_count = 0,
    .enums = NULL,  /* TODO: serialize enums */
    .union_count = 0,
    .unions = NULL  /* TODO: serialize unions */
};

