#define _GNU_SOURCE 1
#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <math.h>
#include "runtime/nl_string.h"
#ifdef __wasm__
#  include "runtime/refcount_gc.h"
#  define gc_alloc_string(len)   nl_rc_str_new(NULL, (len))
#  define gc_retain(p)           nl_rc_retain(p)
#  define gc_release(p)          nl_rc_release(p)
#else
#  include "runtime/gc.h"
#endif
#include "runtime/dyn_array.h"
#include "runtime/native_array_abi.h"
#ifndef __wasm__
#  include "nanolang.h"
#endif

/* nanolang runtime */
#include "runtime/list_int.h"
#include "runtime/native_record_list.h"
#include "runtime/list_string.h"
#include "runtime/list_token.h"
#include "runtime/token_helpers.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <libgen.h>
#include <sys/wait.h>
#include <spawn.h>
#include <fcntl.h>
/* fs.h forward declarations */
DynArray* fs_walkdir(const char* root);
const char* path_normalize(const char* path);
const char* path_join(const char* a, const char* b);
const char* path_basename(const char* path);
const char* path_dirname(const char* path);
int64_t  fs_mkdir_p(const char* path);
const char* path_relpath(const char* target, const char* base);
const char* file_read(const char* path);
int64_t  file_write(const char* path, const char* content);
int64_t  file_append(const char* path, const char* content);
bool     file_exists(const char* path);
int64_t  file_delete(const char* path);
int64_t  file_copy(const char* src, const char* dst);
int64_t  dir_copy(const char* src, const char* dst);
int64_t  nl_os_process_spawn(const char* command);
int64_t  nl_os_process_is_running(int64_t pid);
int64_t  nl_os_process_wait(int64_t pid);
DynArray* nl_os_process_spawn_with_pipes(const char* command);
const char* nl_os_fd_read_available(int64_t fd);
int64_t  nl_os_fd_close(int64_t fd);

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-const-variable"

/* ========== OS Standard Library ========== */

#include "runtime/file_text.h"
static const char* nl_os_file_read(const char* path) {
    char* text = nl_read_file_text(path);
    if (!text) return gc_alloc_string(0);
    size_t length = strlen(text);
    char* result = gc_alloc_string(length);
    if (result) memcpy(result, text, length + 1);
    free(text);
    return result;
}

#include "runtime/file_bytes.h"
static DynArray* nl_os_file_read_bytes(const char* path) {
    return nl_read_file_bytes(path);
}

#include "runtime/file_write.h"
static int64_t nl_os_file_write(const char* path, const char* content) {
    return nl_write_file_text(path, content, "w");
}

static int64_t nl_os_file_append(const char* path, const char* content) {
    return nl_write_file_text(path, content, "a");
}

static int64_t nl_os_file_remove(const char* path) {
    return remove(path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_delete(const char* path) {
    return nl_os_file_remove(path);
}

static int64_t nl_os_file_rename(const char* old_path, const char* new_path) {
    return rename(old_path, new_path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_size(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (int64_t)st.st_size;
}

static bool nl_os_file_exists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static char* nl_os_tmp_dir(void) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    size_t len = strlen(tmp);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, tmp, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_";
    char templ[1024];
    snprintf(templ, sizeof(templ), "%s/%sXXXXXX", tmp, p);
    int fd = mkstemp(templ);
    if (fd < 0) return gc_alloc_string(0);
    close(fd);
    size_t len = strlen(templ);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, templ, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp_dir(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_dir_";
    char path[1024];
    for (int i = 0; i < 100; i++) {
        snprintf(path, sizeof(path), "%s/%s%lld_%d", tmp, p, (long long)time(NULL), i);
        if (mkdir(path, 0700) == 0) {
            size_t len = strlen(path);
            char* out = gc_alloc_string(len);
            if (!out) return gc_alloc_string(0);
            memcpy(out, path, len);
            out[len] = '\0';
            return out;
        }
    }
    return gc_alloc_string(0);
}

static int64_t nl_os_dir_create(const char* path) {
    return mkdir(path, 0755) == 0 ? 0 : -1;
}

static int64_t nl_os_dir_remove(const char* path) {
    return rmdir(path) == 0 ? 0 : -1;
}

static char* nl_os_dir_list(const char* path) {
    DIR* dir = opendir(path);
    if (!dir) return gc_alloc_string(0);
    size_t capacity = 4096;
    size_t used = 0;
    char* buffer = gc_alloc_string(capacity);
    if (!buffer) { closedir(dir); return gc_alloc_string(0); }
    buffer[0] = '\0';
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        size_t name_len = strlen(entry->d_name);
        size_t needed = used + name_len + 2; /* +1 for newline, +1 for null */
        if (needed > capacity) {
            capacity = needed * 2;
            char* new_buffer = gc_alloc_string(capacity);
            if (!new_buffer) { gc_release(buffer); closedir(dir); return gc_alloc_string(0); }
            memcpy(new_buffer, buffer, used);
            gc_release(buffer);
            buffer = new_buffer;
        }
        memcpy(buffer + used, entry->d_name, name_len);
        used += name_len;
        buffer[used++] = '\n';
        buffer[used] = '\0';
    }
    closedir(dir);
    return buffer;
}

static bool nl_os_dir_exists(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_getcwd(void) {
    char temp_buffer[1024];
    if (getcwd(temp_buffer, sizeof(temp_buffer)) == NULL) {
        return gc_alloc_string(0);
    }
    size_t len = strlen(temp_buffer);
    char* buffer = gc_alloc_string(len);
    if (buffer) memcpy(buffer, temp_buffer, len + 1);
    return buffer ? buffer : gc_alloc_string(0);
}

static int64_t nl_os_chdir(const char* path) {
    return chdir(path) == 0 ? 0 : -1;
}

#include "runtime/directory_walk.h"
static DynArray* nl_os_walkdir(const char* root) {
    return nl_fs_walkdir(root);
}

static bool nl_os_path_isfile(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISREG(st.st_mode);
}

static bool nl_os_path_isdir(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_path_join(const char* a, const char* b) {
    size_t len_a = strlen(a);
    size_t len_b = strlen(b);
    size_t total_len = len_a + len_b + 2; /* +1 for '/', +1 for null */
    char* buffer = gc_alloc_string(total_len);
    if (!buffer) return gc_alloc_string(0);
    if (len_a == 0) {
        snprintf(buffer, total_len, "%s", b);
    } else if (a[len_a - 1] == '/') {
        snprintf(buffer, total_len, "%s%s", a, b);
    } else {
        snprintf(buffer, total_len, "%s/%s", a, b);
    }
    return buffer;
}

static char* nl_os_path_basename(const char* path) {
    char* path_copy = strdup(path);
    char* base = basename(path_copy);
    size_t len = strlen(base);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, base, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

static char* nl_os_path_dirname(const char* path) {
    char* path_copy = strdup(path);
    char* dir = dirname(path_copy);
    size_t len = strlen(dir);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, dir, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

#include "runtime/path_normalize.h"
static char* nl_os_path_normalize(const char* path) {
    if (!path) return gc_alloc_string(0);
    char* normalized = nl_normalize_path(path);
    if (!normalized) return gc_alloc_string(0);
    size_t length = strlen(normalized);
    char* out = gc_alloc_string(length);
    if (out) memcpy(out, normalized, length + 1);
    free(normalized);
    return out ? out : gc_alloc_string(0);
}

static int64_t nl_os_system(const char* command) {
    return system(command);
}

static void nl_os_exit(int64_t code) {
    exit((int)code);
}

static const char* nl_os_getenv(const char* name) {
    const char* value = getenv(name);
    return value ? value : "";
}

/* system() wrapper - stdlib system() available via stdlib.h */
static inline int64_t nl_exec_shell(const char* cmd) {
    return (int64_t)system(cmd);
}

/* isatty() wrapper - avoids int64_t type clash with unistd.h */
static inline int64_t nl_isatty(int64_t fd) {
    return (int64_t)isatty((int)fd);
}

/* Capture stdout from a shell command */
static inline const char* nl_exec_capture(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "";
    char* out = (char*)malloc(65536);
    if (!out) { pclose(pipe); return ""; }
    size_t total = 0;
    while (total < 65535) {
        size_t n = fread(out + total, 1, 65535 - total, pipe);
        if (n == 0) break;
        total += n;
    }
    out[total] = '\0';
    pclose(pipe);
    return out;
}

#include "runtime/process_capture.h"
#ifndef NANOLANG_STD_PROCESS_H
static DynArray* nl_os_process_run(const char* command) {
    return nl_process_run_capture(command);
}
#endif /* NANOLANG_STD_PROCESS_H */

/* ========== End OS Standard Library ========== */

/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Advanced String Operations ========== */

static int64_t char_at(const char* s, int64_t index) {
    /* Safety: Bound string scan to 64MB */
    int len = strnlen(s, 64*1024*1024);
    if (index < 0 || index >= len) {
        fprintf(stderr, "Error: Index %lld out of bounds (string length %d)\n", (long long)index, len);
        return 0;
    }
    return (unsigned char)s[index];
}

static char* string_from_char(int64_t c) {
    char* buffer = gc_alloc_string(1);
    if (!buffer) return "";
    buffer[0] = (char)c;
    buffer[1] = '\0';
    return buffer;
}

static bool is_digit(int64_t c) {
    return c >= '0' && c <= '9';
}

static bool is_alpha(int64_t c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_alnum(int64_t c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_whitespace(int64_t c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

static bool is_upper(int64_t c) {
    return c >= 'A' && c <= 'Z';
}

static bool is_lower(int64_t c) {
    return c >= 'a' && c <= 'z';
}

static char* int_to_string(int64_t n) {
    char* buffer = gc_alloc_string(31);
    if (!buffer) return "";
    snprintf(buffer, 32, "%lld", (long long)n);
    return buffer;
}

static char* float_to_string(double x) {
    char* buffer = gc_alloc_string(63);
    if (!buffer) return "";
    nano_rt_f64_format(buffer, 64, x);
    /* Ensure at least one decimal place for whole-number floats
     * so 0.0 -> "0.0" rather than "0" */
    if (!strchr(buffer, '.') && !strchr(buffer, 'e')
            && !strchr(buffer, 'n') && !strchr(buffer, 'i')) {
        size_t len = strlen(buffer);
        if (len + 2 < 64) { buffer[len] = '.'; buffer[len+1] = '0'; buffer[len+2] = '\0'; }
    }
    return buffer;
}

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} nl_fmt_sb_t;

static void nl_fmt_sb_ensure(nl_fmt_sb_t *sb, size_t extra) {
    if (!sb) return;
    size_t needed = sb->len + extra + 1;
    if (needed <= sb->cap) return;
    size_t new_cap = sb->cap ? sb->cap : 128;
    while (new_cap < needed) new_cap *= 2;
    char *new_buf = realloc(sb->buf, new_cap);
    if (!new_buf) return;
    sb->buf = new_buf;
    sb->cap = new_cap;
}

static nl_fmt_sb_t nl_fmt_sb_new(size_t initial_cap) {
    nl_fmt_sb_t sb = {0};
    sb.cap = initial_cap ? initial_cap : 128;
    sb.buf = (char*)malloc(sb.cap);
    sb.len = 0;
    if (sb.buf) sb.buf[0] = '\0';
    return sb;
}

static void nl_fmt_sb_append_cstr(nl_fmt_sb_t *sb, const char *s) {
    if (!sb || !s) return;
    size_t n = strlen(s);
    nl_fmt_sb_ensure(sb, n);
    if (!sb->buf) return;
    memcpy(sb->buf + sb->len, s, n);
    sb->len += n;
    sb->buf[sb->len] = '\0';
}

static void nl_fmt_sb_append_char(nl_fmt_sb_t *sb, char c) {
    if (!sb) return;
    nl_fmt_sb_ensure(sb, 1);
    if (!sb->buf) return;
    sb->buf[sb->len++] = c;
    sb->buf[sb->len] = '\0';
}

static char* nl_fmt_sb_build(nl_fmt_sb_t *sb) {
    if (!sb || !sb->buf) return "";
    return sb->buf;
}

static const char* nl_to_string_int(int64_t v) { return int_to_string(v); }
static const char* nl_to_string_float(double v) { return float_to_string(v); }
static const char* nl_to_string_bool(bool v) { return v ? "true" : "false"; }
static const char* nl_to_string_string(const char* v) { return v ? v : ""; }

static const char* nl_to_string_array(DynArray* arr) {
    if (!arr) return "[]";
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_char(&sb, '[');
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    for (int64_t i = 0; i < len; i++) {
        if (i > 0) nl_fmt_sb_append_cstr(&sb, ", ");
        switch (t) {
            case ELEM_INT: {
                const char* s = nl_to_string_int(dyn_array_get_int(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_U8: {
                const char* s = nl_to_string_int((int64_t)dyn_array_get_u8(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_FLOAT: {
                const char* s = nl_to_string_float(dyn_array_get_float(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_BOOL: {
                nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(dyn_array_get_bool(arr, i)));
                break;
            }
            case ELEM_STRING: {
                nl_fmt_sb_append_char(&sb, '"');
                nl_fmt_sb_append_cstr(&sb, nl_to_string_string(dyn_array_get_string(arr, i)));
                nl_fmt_sb_append_char(&sb, '"');
                break;
            }
            case ELEM_ARRAY: {
                const char* s = nl_to_string_array(dyn_array_get_array(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_STRUCT: {
                nl_fmt_sb_append_cstr(&sb, "<struct>");
                break;
            }
            default: {
                nl_fmt_sb_append_cstr(&sb, "?");
                break;
            }
        }
    }
    nl_fmt_sb_append_char(&sb, ']');
    return nl_fmt_sb_build(&sb);
}

static const char* nl_str_concat(const char* s1, const char* s2);
static DynArray* nl_array_add(DynArray* a, DynArray* b);
static DynArray* nl_array_sub(DynArray* a, DynArray* b);
static DynArray* nl_array_mul(DynArray* a, DynArray* b);
static DynArray* nl_array_div(DynArray* a, DynArray* b);
static DynArray* nl_array_mod(DynArray* a, DynArray* b);

static void nl_array_assert_compatible(DynArray* a, DynArray* b) {
    assert(a && b);
    assert(dyn_array_length(a) == dyn_array_length(b));
    assert(dyn_array_get_elem_type(a) == dyn_array_get_elem_type(b));
}

static DynArray* nl_array_add(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)+dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_STRING: for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), dyn_array_get_string(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_add(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_add: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_sub(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)-dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_sub(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_sub: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mul(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)*dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mul(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mul: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_div(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)/dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_div(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_div: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mod(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)%dyn_array_get_int(b,i)); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mod(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mod: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_add_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) + s);
    return out;
}

static DynArray* nl_array_radd_scalar_int(int64_t s, DynArray* a) { return nl_array_add_scalar_int(a, s); }

static DynArray* nl_array_sub_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) - s);
    return out;
}

static DynArray* nl_array_rsub_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s - dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mul_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) * s);
    return out;
}

static DynArray* nl_array_rmul_scalar_int(int64_t s, DynArray* a) { return nl_array_mul_scalar_int(a, s); }

static DynArray* nl_array_div_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) / s);
    return out;
}

static DynArray* nl_array_rdiv_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s / dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mod_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) % s);
    return out;
}

static DynArray* nl_array_rmod_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s % dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_add_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_float(double s, DynArray* a) { return nl_array_add_scalar_float(a, s); }

static DynArray* nl_array_sub_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rsub_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_mul_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rmul_scalar_float(double s, DynArray* a) { return nl_array_mul_scalar_float(a, s); }

static DynArray* nl_array_div_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rdiv_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_add_scalar_string(DynArray* a, const char* s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_string(const char* s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(s, dyn_array_get_string(a,i)));
    return out;
}

static int64_t string_to_int(const char* s) {
    return strtoll(s, NULL, 10);
}

#include "runtime/binary64_parse.h"
static double string_to_float(const char* s) { return nl_binary64_prefix(s); }

static int64_t digit_value(int64_t c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    return -1;
}

static int64_t char_to_lower(int64_t c) {
    if (c >= 'A' && c <= 'Z') {
    return c + 32;
    }
    return c;
}

static int64_t char_to_upper(int64_t c) {
    if (c >= 'a' && c <= 'z') {
        return c - 32;
    }
    return c;
}

#include "runtime/string_edges.h"
static const char* nl_str_trim_left(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t start = 0;
    while (start < len && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n' || s[start] == '\r')) start++;
    size_t new_len = len - start;
    char* result = gc_alloc_string(new_len);
    if (!result) return "";
    memcpy(result, s + start, new_len);
    result[new_len] = '\0';
    return result;
}

static const char* nl_str_trim_right(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t end = len;
    while (end > 0 && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n' || s[end-1] == '\r')) end--;
    char* result = gc_alloc_string(end);
    if (!result) return "";
    memcpy(result, s, end);
    result[end] = '\0';
    return result;
}

static const char* nl_str_to_lower(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_to_upper(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_replace(const char* s, const char* old_str, const char* new_str) {
    if (!s || !old_str || !new_str) return s ? s : "";
    size_t old_len = strlen(old_str);
    size_t s_len = strlen(s);
    if (old_len == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    size_t new_len = strlen(new_str);
    int64_t count = 0;
    const char* p = s;
    const char* found;
    while ((found = strstr(p, old_str)) != NULL) { count++; p = found + old_len; }
    if (count == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    int64_t result_len = (int64_t)s_len + count * ((int64_t)new_len - (int64_t)old_len);
    if (result_len < 0) return "";
    char* result = gc_alloc_string((size_t)result_len);
    if (!result) return "";
    const char* src = s;
    char* dst = result;
    while ((found = strstr(src, old_str)) != NULL) {
        size_t seg_len = (size_t)(found - src);
        memcpy(dst, src, seg_len);
        dst += seg_len;
        memcpy(dst, new_str, new_len);
        dst += new_len;
        src = found + old_len;
    }
    size_t rest = strlen(src);
    memcpy(dst, src, rest);
    dst[rest] = '\0';
    return result;
}

static DynArray* nl_str_split(const char* str, const char* delim) {
    DynArray* result = dyn_array_new(ELEM_STRING);
    if (!result) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    if (!str) return result;
    size_t delim_len = strlen(delim);
    if (delim_len == 0) {
        size_t str_len = strnlen(str, 64*1024*1024);
        for (size_t i = 0; i < str_len; i++) {
            char* ch = gc_alloc_string(1);
            if (!ch) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
            ch[0] = str[i]; ch[1] = '\0';
            dyn_array_push_string(result, ch);
        }
        return result;
    }
    const char* start = str;
    const char* found;
    while ((found = strstr(start, delim)) != NULL) {
        size_t seg_len = (size_t)(found - start);
        char* seg = gc_alloc_string(seg_len);
        if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
        memcpy(seg, start, seg_len);
        seg[seg_len] = '\0';
        dyn_array_push_string(result, seg);
        start = found + delim_len;
    }
    size_t rest_len = strlen(start);
    char* seg = gc_alloc_string(rest_len);
    if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    {
        memcpy(seg, start, rest_len);
        seg[rest_len] = '\0';
        dyn_array_push_string(result, seg);
    }
    return result;
}

static const char* nl_str_join(DynArray* arr, const char* delim) {
    if (!arr) return "";
    int64_t count = dyn_array_length(arr);
    if (count == 0) return "";
    size_t delim_len = strlen(delim);
    size_t total = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) total += strlen(s);
        if (i < count - 1) total += delim_len;
    }
    char* result = gc_alloc_string(total);
    if (!result) return "";
    size_t pos = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) { size_t slen = strlen(s); memcpy(result + pos, s, slen); pos += slen; }
        if (i < count - 1) { memcpy(result + pos, delim, delim_len); pos += delim_len; }
    }
    result[pos] = '\0';
    return result;
}

static const char* nl_format(const char *fmt, int n_args, ...) {
    if (!fmt) return "";
    va_list ap;
    va_start(ap, n_args);
    nl_fmt_sb_t out = nl_fmt_sb_new(128);
    const char *p = fmt;
    int used = 0;
    while (*p) {
        if (*p == '%' && (p[1] == 's' || p[1] == 'd' || p[1] == 'f' || p[1] == 'g') && used < n_args) {
            const char *arg = va_arg(ap, const char *);
            if (arg) nl_fmt_sb_append_cstr(&out, arg);
            used++;
            p += 2;
        } else {
            nl_fmt_sb_append_char(&out, *p++);
        }
    }
    va_end(ap);
    char *result = gc_alloc_string(out.len);
    if (result && out.buf) { memcpy(result, out.buf, out.len + 1); }
    if (out.buf) free(out.buf);
    return result ? result : "";
}

/* ========== End Advanced String Operations ========== */

/* ========== Timing Utilities ========== */

#include <sys/time.h>
#ifdef __MACH__
#include <mach/mach_time.h>
#endif

/* Get current time in microseconds since epoch */
static int64_t nl_timing_get_microseconds(void) {
#ifdef CLOCK_REALTIME
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ((int64_t)ts.tv_sec * 1000000LL) + (int64_t)(ts.tv_nsec / 1000);
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((int64_t)tv.tv_sec * 1000000LL) + (int64_t)tv.tv_usec;
#endif
}

/* Get high-resolution time in nanoseconds */
static int64_t nl_timing_get_nanoseconds(void) {
#ifdef __MACH__
    static mach_timebase_info_data_t timebase;
    static int initialized = 0;
    if (!initialized) {
        mach_timebase_info(&timebase);
        initialized = 1;
    }
    uint64_t mach_time = mach_absolute_time();
    return (int64_t)((mach_time * timebase.numer) / timebase.denom);
#elif defined(CLOCK_MONOTONIC)
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((int64_t)ts.tv_sec * 1000000000LL) + (int64_t)ts.tv_nsec;
#else
    return nl_timing_get_microseconds() * 1000LL;
#endif
}

/* Convenience: current time in milliseconds */
static int64_t nl_get_time_ms(void) { return nl_timing_get_microseconds() / 1000LL; }

/* ========== End Timing Utilities ========== */

/* ========== Console I/O Utilities ========== */

/* Read a line from stdin, returns heap-allocated string */
/* Static to avoid duplicate symbols when linking multiple modules */
static const char* nl_read_line(void) {
    char buffer[4096];
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty ? empty : "";
    }
    /* Remove trailing newline if present */
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len-1] == '\n') {
        buffer[len-1] = '\0';
        len--;
    }
    char* result = malloc(len + 1);
    if (!result) return "";
    memcpy(result, buffer, len + 1);
    return result;
}

/* ========== End Console I/O Utilities ========== */

#include <string.h>
static inline double nl_float_from_bits(int64_t value) { uint64_t bits = (uint64_t)value; double result; (void)sizeof(char[sizeof(result) == sizeof(bits) ? 1 : -1]); memcpy(&result, &bits, sizeof(result)); return result; }
static inline int64_t nl_float_to_bits(double value) { uint64_t bits; (void)sizeof(char[sizeof(value) == sizeof(bits) ? 1 : -1]); memcpy(&bits, &value, sizeof(bits)); return bits <= (9223372036854775807L) ? (int64_t)bits : -1 - (int64_t)((18446744073709551615UL) - bits); }
/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Math and Utility Built-in Functions ========== */

#define nl_abs(x) _Generic((x), \
    double: (double)((x) < 0.0 ? -(x) : (x)), \
    default: (int64_t)((x) < 0 ? -(x) : (x)))

#define nl_min(a, b) _Generic((a), \
    double: (double)((a) < (b) ? (a) : (b)), \
    default: (int64_t)((a) < (b) ? (a) : (b)))

#define nl_max(a, b) _Generic((a), \
    double: (double)((a) > (b) ? (a) : (b)), \
    default: (int64_t)((a) > (b) ? (a) : (b)))

/* Trigonometric functions */
static double nl_sin(double x) { return sin(x); }
static double nl_cos(double x) { return cos(x); }
static double nl_tan(double x) { return tan(x); }
static double nl_atan2(double y, double x) { return atan2(y, x); }

/* Power and root functions */
static double nl_sqrt(double x) { return sqrt(x); }
static double nl_pow(double base, double exp) { return pow(base, exp); }

/* Rounding functions */
static double nl_floor(double x) { return floor(x); }
static double nl_ceil(double x) { return ceil(x); }
static double nl_round(double x) { return round(x); }

static int64_t nl_cast_int(double x) { if (!(x >= -0x1p63 && x < 0x1p63)) { fputs("I cannot convert this float to int: I require a finite value in [-2^63, 2^63).\n", stderr); exit(EXIT_FAILURE); } return (int64_t)x; }
static int64_t nl_cast_int_from_int(int64_t x) { return x; }
static double nl_cast_float(int64_t x) { return (double)x; }
static double nl_cast_float_from_float(double x) { return x; }
static void* nl_null_opaque() { return NULL; }
static int64_t nl_cast_bool_to_int(bool x) { return x ? 1 : 0; }
static bool nl_cast_bool(int64_t x) { return x != 0; }
static int64_t nano_rt_idiv(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return INT64_MIN; return a / b; }
static int64_t nano_rt_imod(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return 0; return a % b; }

static void nl_println(void* value_ptr) {
    (void)value_ptr; /* Unused - actual implementation uses type info from checker */
}

static void nl_print_int(int64_t value) {
    printf("%lld", (long long)value);
}

static void nl_print_float(double value) {
    nano_rt_f64_print(stdout, value);
}

static void nl_print_string(const char* value) {
    printf("%s", value);
}

static void nl_print_bool(bool value) {
    printf(value ? "true" : "false");
}

static void nl_println_int(int64_t value) {
    printf("%lld\n", (long long)value);
}

static void nl_println_float(double value) {
    nano_rt_f64_print(stdout, value); fputc('\n', stdout);
}

static void nl_println_string(const char* value) {
    printf("%s\n", value);
}

/* Dynamic array runtime (using GC) - LEGACY */
#include "runtime/gc.h"
#include "runtime/dyn_array.h"
#include "runtime/nl_string.h"

static DynArray* dynarray_literal_int(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int64_t val = va_arg(args, int64_t);
        dyn_array_push_int(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_u8(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_U8);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* default promotion */
        dyn_array_push_u8(arr, (uint8_t)val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_float(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        double val = va_arg(args, double);
        dyn_array_push_float(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_string(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        const char* val = va_arg(args, const char*);
        dyn_array_push_string(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_bool(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* bool promotes to int */
        dyn_array_push_bool(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static DynArray* nl_array_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static double nl_array_pop(DynArray* arr) {
    bool success = false;
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_pop_u8(arr, &success);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_pop_int(arr, &success);
    } else {
        return dyn_array_pop_float(arr, &success);
    }
}

static int64_t nl_array_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static DynArray* nl_array_remove_at(DynArray* arr, int64_t index) {
    return dyn_array_remove_at(arr, index);
}

static int64_t nl_array_at_int(DynArray* arr, int64_t idx) {
    return dyn_array_get_int(arr, idx);
}

static uint8_t nl_array_at_u8(DynArray* arr, int64_t idx) {
    return dyn_array_get_u8(arr, idx);
}

static double nl_array_at_float(DynArray* arr, int64_t idx) {
    return dyn_array_get_float(arr, idx);
}

static const char* nl_array_at_string(DynArray* arr, int64_t idx) {
    return dyn_array_get_string(arr, idx);
}

static bool nl_array_at_bool(DynArray* arr, int64_t idx) {
    return dyn_array_get_bool(arr, idx);
}

static void nl_array_set_int(DynArray* arr, int64_t idx, int64_t val) {
    dyn_array_set_int(arr, idx, val);
}

static void nl_array_set_u8(DynArray* arr, int64_t idx, uint8_t val) {
    dyn_array_set_u8(arr, idx, val);
}

static void nl_array_set_float(DynArray* arr, int64_t idx, double val) {
    dyn_array_set_float(arr, idx, val);
}

static void nl_array_set_string(DynArray* arr, int64_t idx, const char* val) {
    dyn_array_set_string(arr, idx, val);
}

static void nl_array_set_bool(DynArray* arr, int64_t idx, bool val) {
    dyn_array_set_bool(arr, idx, val);
}

static DynArray* nl_array_at_array(DynArray* arr, int64_t idx) {
    return dyn_array_get_array(arr, idx);
}

static void nl_array_set_array(DynArray* arr, int64_t idx, DynArray* val) {
    dyn_array_set_array(arr, idx, val);
}

static DynArray* nl_array_new_int(int64_t size, int64_t default_val) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_int(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_float(int64_t size, double default_val) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_float(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_string(int64_t size, const char* default_val) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_string(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_bool(int64_t size, bool default_val) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_bool(arr, default_val);
    }
    return arr;
}

static int64_t dynarray_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static double dynarray_at_for_transpiler(DynArray* arr, int64_t idx) {
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_get_u8(arr, idx);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_get_int(arr, idx);
    } else {
        return dyn_array_get_float(arr, idx);
    }
}

/* bstring helpers (nl_string_t wrappers) */
static nl_string_t* bstr_new(const char* cstr) {
    if (!cstr) cstr = "";
    return nl_string_new(cstr);
}

static nl_string_t* bstr_new_binary(DynArray* bytes) {
    if (!bytes || dyn_array_get_elem_type(bytes) != ELEM_U8) {
        return nl_string_new_binary("", 0);
    }
    int64_t len = dyn_array_length(bytes);
    if (len <= 0) {
        return nl_string_new_binary("", 0);
    }
    uint8_t* buffer = malloc((size_t)len);
    if (!buffer) {
        return nl_string_new_binary("", 0);
    }
    for (int64_t i = 0; i < len; i++) {
        buffer[i] = dyn_array_get_u8(bytes, i);
    }
    nl_string_t* result = nl_string_new_binary(buffer, (size_t)len);
    free(buffer);
    return result;
}

static size_t bstr_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_length(str);
}

static int64_t bstr_byte_at(nl_string_t* str, int64_t index) {
    if (!str || index < 0 || (size_t)index >= nl_string_length(str)) {
        return 0;
    }
    return (unsigned char)nl_string_byte_at(str, (size_t)index);
}

static nl_string_t* bstr_concat(nl_string_t* a, nl_string_t* b) {
    if (!a && !b) return nl_string_new("");
    if (!a) return nl_string_clone(b);
    if (!b) return nl_string_clone(a);
    return nl_string_concat(a, b);
}

static nl_string_t* bstr_substring(nl_string_t* str, int64_t start, int64_t length) {
    if (!str || start < 0 || length < 0) {
        return nl_string_new("");
    }
    size_t len = nl_string_length(str);
    if ((size_t)start > len) {
        start = (int64_t)len;
    }
    if ((size_t)(start + length) > len) {
        length = (int64_t)len - start;
    }
    return nl_string_substring(str, (size_t)start, (size_t)length);
}

static bool bstr_equals(nl_string_t* a, nl_string_t* b) {
    if (!a || !b) return a == b;
    return nl_string_equals(a, b);
}

static bool bstr_validate_utf8(nl_string_t* str) {
    if (!str) return false;
    return nl_string_validate_utf8(str);
}

static int64_t bstr_utf8_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_utf8_length(str);
}

static int64_t bstr_utf8_char_at(nl_string_t* str, int64_t char_index) {
    if (!str || char_index < 0) return -1;
    return nl_string_utf8_char_at(str, (size_t)char_index);
}

static const char* bstr_to_cstr(nl_string_t* str) {
    if (!str) return "";
    return nl_string_to_cstr(str);
}

static void bstr_free(nl_string_t* str) {
    if (str) {
        nl_string_free(str);
    }
}

/* String concatenation - use strnlen for safety */
static const char* nl_str_concat(const char* s1, const char* s2) {
    /* Safety: Bound string scan to 64MB */
    size_t len1 = strnlen(s1, 64*1024*1024);
    size_t len2 = strnlen(s2, 64*1024*1024);
    char* result = gc_alloc_string(len1 + len2);
    if (!result) return "";
    memcpy(result, s1, len1);
    memcpy(result + len1, s2, len2);
    result[len1 + len2] = '\0';
    return result;
}

/* String substring - use strnlen for safety */
static const char* nl_str_substring(const char* str, int64_t start, int64_t length) {
    /* Safety: Bound string scan to 64MB */
    int64_t str_len = strnlen(str, 64*1024*1024);
    if (start < 0 || start > str_len || length < 0) return "";
    if (start == str_len) return "";
    if (start + length > str_len) length = str_len - start;
    char* result = gc_alloc_string(length);
    if (!result) return "";
    strncpy(result, str + start, length);
    result[length] = '\0';
    return result;
}

/* String contains */
static bool nl_str_contains(const char* str, const char* substr) {
    return strstr(str, substr) != NULL;
}

/* String equals */
static bool nl_str_equals(const char* s1, const char* s2) {
    return strcmp(s1, s2) == 0;
}

/* String starts_with */
static bool nl_str_starts_with(const char* s, const char* prefix) {
    if (!s || !prefix) return false;
    size_t slen = strnlen(s, 64*1024*1024);
    size_t plen = strnlen(prefix, 64*1024*1024);
    if (plen > slen) return false;
    return strncmp(s, prefix, plen) == 0;
}

/* String ends_with */
#include "runtime/string_edges.h"
#include "runtime/string_search.h"
static DynArray* nl_bytes_from_string(const char* s) {
    DynArray* out = dyn_array_new(ELEM_U8);
    if (!out) return NULL;
    if (!s) return out;
    size_t len = strnlen(s, 64*1024*1024);
    for (size_t i = 0; i < len; i++) {
        dyn_array_push_u8(out, (uint8_t)(unsigned char)s[i]);
    }
    return out;
}

static const char* nl_string_from_bytes(DynArray* bytes) {
    if (!bytes) return "";
    if (dyn_array_get_elem_type(bytes) != ELEM_U8) return "";
    int64_t len = dyn_array_length(bytes);
    if (len < 0) return "";
    char* out = gc_alloc_string((size_t)len);
    if (!out) return "";
    for (int64_t i = 0; i < len; i++) {
        out[i] = (char)dyn_array_get_u8(bytes, i);
    }
    out[len] = '\0';
    return out;
}

static DynArray* nl_array_slice(DynArray* arr, int64_t start, int64_t length) {
    if (!arr) return dyn_array_new(ELEM_INT);
    if (start < 0) start = 0;
    if (length < 0) length = 0;
    int64_t len = dyn_array_length(arr);
    if (start > len) start = len;
    if (length > len - start) length = len - start;
    int64_t end = start + length;
    if (end > len) end = len;
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = start; i < end; i++) {
        switch (t) {
            case ELEM_U8: dyn_array_push_u8(out, dyn_array_get_u8(arr, i)); break;
            case ELEM_INT: dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT: dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL: dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            case ELEM_ARRAY: dyn_array_push_array(out, dyn_array_get_array(arr, i)); break;
            case ELEM_STRUCT: dyn_array_push_struct(out, dyn_array_get_struct(arr, i), (size_t)arr->elem_size); break;
            default: assert(false && "nl_array_slice: unsupported element type");
        }
    }
    return out;
}

static void nl_println_bool(bool value) {
    printf("%s\n", value ? "true" : "false");
}

static void nl_print_array(DynArray* arr) {
    printf("[");
    for (int i = 0; i < arr->length; i++) {
        if (i > 0) printf(", ");
        switch (arr->elem_type) {
            case ELEM_INT:
                printf("%lld", (long long)((int64_t*)arr->data)[i]);
                break;
            case ELEM_U8:
                printf("%u", (unsigned)((uint8_t*)arr->data)[i]);
                break;
            case ELEM_FLOAT:
                nano_rt_f64_print(stdout, ((double*)arr->data)[i]);
                break;
            default:
                printf("?");
                break;
        }
    }
    printf("]");
}

static void nl_println_array(DynArray* arr) {
    nl_print_array(arr);
    printf("\n");
}

/* ========== Array Operations (With Bounds Checking!) ========== */

static DynArray* nl_array_sort(DynArray* arr) {
    return dyn_array_sorted(arr);
}

static DynArray* nl_array_reverse(DynArray* arr) {
    if (!arr) return dyn_array_new(ELEM_INT);
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = len - 1; i >= 0; i--) {
        switch (t) {
            case ELEM_INT:    dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT:  dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL:   dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            default: dyn_array_push_int(out, 0); break;
        }
    }
    return out;
}

static bool nl_array_contains(DynArray* arr, int64_t elem) {
    if (!arr) return false;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return true;
    }
    return false;
}

static int64_t nl_array_index_of(DynArray* arr, int64_t elem) {
    if (!arr) return -1;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return i;
    }
    return -1;
}

/* ========== End Array Operations ========== */

/* ========== End Math and Utility Built-in Functions ========== */

/* ========== Coroutine Runtime Builtins ========== */
#include "coroutine.h"

typedef struct { void *fn; int64_t args[8]; int nargs; } NlSpawnCtx;
static Value nl_coro_spawn_trampoline(void *raw, int coro_id) {
    (void)coro_id;
    NlSpawnCtx *ctx = (NlSpawnCtx *)raw;
    Value v; memset(&v, 0, sizeof(v)); v.type = VAL_INT;
    switch (ctx->nargs) {
        case 0: v.as.int_val = ((int64_t(*)(void))ctx->fn)(); break;
        case 1: v.as.int_val = ((int64_t(*)(int64_t))ctx->fn)(ctx->args[0]); break;
        case 2: v.as.int_val = ((int64_t(*)(int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1]); break;
        case 3: v.as.int_val = ((int64_t(*)(int64_t,int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1],ctx->args[2]); break;
        default: break;
    }
    return v;
}

static int64_t nl_coro_spawn_n(void *fn, int nargs, int64_t a0, int64_t a1, int64_t a2) {
    nano_scheduler_init();
    NlSpawnCtx *ctx = (NlSpawnCtx *)malloc(sizeof(NlSpawnCtx));
    if (!ctx) return -1;
    ctx->fn = fn; ctx->nargs = nargs;
    ctx->args[0] = a0; ctx->args[1] = a1; ctx->args[2] = a2;
    return (int64_t)nano_coro_spawn(nl_coro_spawn_trampoline, ctx);
}
/* nl_coro_spawn: select correct overload by argument count */
#define _nl_cs0(fn)           nl_coro_spawn_n((void*)(fn),0,0LL,0LL,0LL)
#define _nl_cs1(fn,a)         nl_coro_spawn_n((void*)(fn),1,(int64_t)(a),0LL,0LL)
#define _nl_cs2(fn,a,b)       nl_coro_spawn_n((void*)(fn),2,(int64_t)(a),(int64_t)(b),0LL)
#define _nl_cs3(fn,a,b,c)     nl_coro_spawn_n((void*)(fn),3,(int64_t)(a),(int64_t)(b),(int64_t)(c))
#define _nl_cs_pick(_1,_2,_3,_4,X,...) X
#define nl_coro_spawn(fn,...) _nl_cs_pick(fn,##__VA_ARGS__,_nl_cs3,_nl_cs2,_nl_cs1,_nl_cs0)(fn,##__VA_ARGS__)

/* nl_scheduler_run(): drain all pending coroutines */
static void nl_scheduler_run(void) {
    nano_scheduler_init();
    nano_scheduler_run_until_done();
}

/* nl_scheduler_step(): run one step */
static int64_t nl_scheduler_step(void) {
    nano_scheduler_init();
    return nano_scheduler_step() ? 1 : 0;
}

/* nl_coro_result(id): get result value of completed coroutine */
static int64_t nl_coro_result(int64_t id) {
    Value v = nano_coro_result((int)id);
    return v.as.int_val;
}

/* nl_coro_done(id): 1 if coroutine completed */
static int64_t nl_coro_done(int64_t id) {
    return nano_coro_is_done((int)id) ? 1 : 0;
}

/* nl_coro_yield(): cooperative yield hint */
static void nl_coro_yield(void) { nano_coro_yield(); }
/* ========== End Coroutine Runtime Builtins ========== */

/* ========== Enum Definitions ========== */

typedef enum {
    nl_LexerTokenType_TOKEN_EOF = 0,
    nl_LexerTokenType_TOKEN_NUMBER = 1,
    nl_LexerTokenType_TOKEN_FLOAT = 2,
    nl_LexerTokenType_TOKEN_STRING = 3,
    nl_LexerTokenType_TOKEN_IDENTIFIER = 4,
    nl_LexerTokenType_TOKEN_TRUE = 5,
    nl_LexerTokenType_TOKEN_FALSE = 6,
    nl_LexerTokenType_TOKEN_LPAREN = 7,
    nl_LexerTokenType_TOKEN_RPAREN = 8,
    nl_LexerTokenType_TOKEN_LBRACE = 9,
    nl_LexerTokenType_TOKEN_RBRACE = 10,
    nl_LexerTokenType_TOKEN_LBRACKET = 11,
    nl_LexerTokenType_TOKEN_RBRACKET = 12,
    nl_LexerTokenType_TOKEN_COMMA = 13,
    nl_LexerTokenType_TOKEN_COLON = 14,
    nl_LexerTokenType_TOKEN_DOUBLE_COLON = 15,
    nl_LexerTokenType_TOKEN_ARROW = 16,
    nl_LexerTokenType_TOKEN_ASSIGN = 17,
    nl_LexerTokenType_TOKEN_DOT = 18,
    nl_LexerTokenType_TOKEN_MODULE = 19,
    nl_LexerTokenType_TOKEN_PUB = 20,
    nl_LexerTokenType_TOKEN_FROM = 21,
    nl_LexerTokenType_TOKEN_USE = 22,
    nl_LexerTokenType_TOKEN_EXTERN = 23,
    nl_LexerTokenType_TOKEN_FN = 24,
    nl_LexerTokenType_TOKEN_LET = 25,
    nl_LexerTokenType_TOKEN_MUT = 26,
    nl_LexerTokenType_TOKEN_SET = 27,
    nl_LexerTokenType_TOKEN_IF = 28,
    nl_LexerTokenType_TOKEN_ELSE = 29,
    nl_LexerTokenType_TOKEN_COND = 30,
    nl_LexerTokenType_TOKEN_WHILE = 31,
    nl_LexerTokenType_TOKEN_FOR = 32,
    nl_LexerTokenType_TOKEN_IN = 33,
    nl_LexerTokenType_TOKEN_RETURN = 34,
    nl_LexerTokenType_TOKEN_BREAK = 35,
    nl_LexerTokenType_TOKEN_CONTINUE = 36,
    nl_LexerTokenType_TOKEN_ASSERT = 37,
    nl_LexerTokenType_TOKEN_SHADOW = 38,
    nl_LexerTokenType_TOKEN_REQUIRES = 39,
    nl_LexerTokenType_TOKEN_ENSURES = 40,
    nl_LexerTokenType_TOKEN_PRINT = 41,
    nl_LexerTokenType_TOKEN_ARRAY = 42,
    nl_LexerTokenType_TOKEN_STRUCT = 43,
    nl_LexerTokenType_TOKEN_ENUM = 44,
    nl_LexerTokenType_TOKEN_UNION = 45,
    nl_LexerTokenType_TOKEN_MATCH = 46,
    nl_LexerTokenType_TOKEN_IMPORT = 47,
    nl_LexerTokenType_TOKEN_AS = 48,
    nl_LexerTokenType_TOKEN_OPAQUE = 49,
    nl_LexerTokenType_TOKEN_TYPE_INT = 50,
    nl_LexerTokenType_TOKEN_TYPE_U8 = 51,
    nl_LexerTokenType_TOKEN_TYPE_FLOAT = 52,
    nl_LexerTokenType_TOKEN_TYPE_BOOL = 53,
    nl_LexerTokenType_TOKEN_TYPE_STRING = 54,
    nl_LexerTokenType_TOKEN_TYPE_BSTRING = 55,
    nl_LexerTokenType_TOKEN_TYPE_VOID = 56,
    nl_LexerTokenType_TOKEN_PLUS = 57,
    nl_LexerTokenType_TOKEN_MINUS = 58,
    nl_LexerTokenType_TOKEN_STAR = 59,
    nl_LexerTokenType_TOKEN_SLASH = 60,
    nl_LexerTokenType_TOKEN_PERCENT = 61,
    nl_LexerTokenType_TOKEN_EQ = 62,
    nl_LexerTokenType_TOKEN_NE = 63,
    nl_LexerTokenType_TOKEN_LT = 64,
    nl_LexerTokenType_TOKEN_LE = 65,
    nl_LexerTokenType_TOKEN_GT = 66,
    nl_LexerTokenType_TOKEN_GE = 67,
    nl_LexerTokenType_TOKEN_AND = 68,
    nl_LexerTokenType_TOKEN_OR = 69,
    nl_LexerTokenType_TOKEN_NOT = 70,
    nl_LexerTokenType_TOKEN_RANGE = 71,
    nl_LexerTokenType_TOKEN_UNSAFE = 72,
    nl_LexerTokenType_TOKEN_RESOURCE = 73,
    nl_LexerTokenType_TOKEN_PIPE = 74,
    nl_LexerTokenType_TOKEN_GRAMMAR = 75,
    nl_LexerTokenType_TOKEN_LARROW = 76,
    nl_LexerTokenType_TOKEN_QUESTION = 77,
    nl_LexerTokenType_TOKEN_PAR = 78,
    nl_LexerTokenType_TOKEN_BAR = 79,
    nl_LexerTokenType_TOKEN_EFFECT = 80,
    nl_LexerTokenType_TOKEN_HANDLE = 81,
    nl_LexerTokenType_TOKEN_WITH = 82,
    nl_LexerTokenType_TOKEN_RESUME = 83,
    nl_LexerTokenType_TOKEN_GPU = 84,
    nl_LexerTokenType_TOKEN_ASYNC = 85,
    nl_LexerTokenType_TOKEN_AWAIT = 86,
    nl_LexerTokenType_TOKEN_PURE = 87,
    nl_LexerTokenType_TOKEN_AMPERSAND = 88
} nl_LexerTokenType;

typedef enum {
    nl_ParseNodeType_PNODE_NUMBER = 0,
    nl_ParseNodeType_PNODE_FLOAT = 1,
    nl_ParseNodeType_PNODE_STRING = 2,
    nl_ParseNodeType_PNODE_BOOL = 3,
    nl_ParseNodeType_PNODE_IDENTIFIER = 4,
    nl_ParseNodeType_PNODE_BINARY_OP = 5,
    nl_ParseNodeType_PNODE_CALL = 6,
    nl_ParseNodeType_PNODE_ARRAY_LITERAL = 7,
    nl_ParseNodeType_PNODE_LET = 8,
    nl_ParseNodeType_PNODE_SET = 9,
    nl_ParseNodeType_PNODE_IF = 10,
    nl_ParseNodeType_PNODE_COND = 11,
    nl_ParseNodeType_PNODE_WHILE = 12,
    nl_ParseNodeType_PNODE_FOR = 13,
    nl_ParseNodeType_PNODE_RETURN = 14,
    nl_ParseNodeType_PNODE_BREAK = 15,
    nl_ParseNodeType_PNODE_CONTINUE = 16,
    nl_ParseNodeType_PNODE_BLOCK = 17,
    nl_ParseNodeType_PNODE_PRINT = 18,
    nl_ParseNodeType_PNODE_ASSERT = 19,
    nl_ParseNodeType_PNODE_PROGRAM = 20,
    nl_ParseNodeType_PNODE_FUNCTION = 21,
    nl_ParseNodeType_PNODE_SHADOW = 22,
    nl_ParseNodeType_PNODE_STRUCT_DEF = 23,
    nl_ParseNodeType_PNODE_STRUCT_LITERAL = 24,
    nl_ParseNodeType_PNODE_FIELD_ACCESS = 25,
    nl_ParseNodeType_PNODE_ENUM_DEF = 26,
    nl_ParseNodeType_PNODE_UNION_DEF = 27,
    nl_ParseNodeType_PNODE_UNION_CONSTRUCT = 28,
    nl_ParseNodeType_PNODE_MATCH = 29,
    nl_ParseNodeType_PNODE_IMPORT = 30,
    nl_ParseNodeType_PNODE_OPAQUE_TYPE = 31,
    nl_ParseNodeType_PNODE_TUPLE_LITERAL = 32,
    nl_ParseNodeType_PNODE_TUPLE_INDEX = 33,
    nl_ParseNodeType_PNODE_STRUCT = 34,
    nl_ParseNodeType_PNODE_ENUM = 35,
    nl_ParseNodeType_PNODE_UNION = 36,
    nl_ParseNodeType_PNODE_UNSAFE_BLOCK = 37,
    nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL = 38,
    nl_ParseNodeType_PNODE_GRAMMAR = 39,
    nl_ParseNodeType_PNODE_PAR_BLOCK = 40,
    nl_ParseNodeType_PNODE_EFFECT_DECL = 41,
    nl_ParseNodeType_PNODE_HANDLE_EXPR = 42,
    nl_ParseNodeType_PNODE_ASYNC_FN = 43,
    nl_ParseNodeType_PNODE_SERVICE_DECL = 44
} nl_ParseNodeType;

typedef enum {
    nl_TypeKind_TYPE_INT = 0,
    nl_TypeKind_TYPE_FLOAT = 1,
    nl_TypeKind_TYPE_BOOL = 2,
    nl_TypeKind_TYPE_STRING = 3,
    nl_TypeKind_TYPE_VOID = 4,
    nl_TypeKind_TYPE_ARRAY = 5,
    nl_TypeKind_TYPE_STRUCT = 6,
    nl_TypeKind_TYPE_ENUM = 7,
    nl_TypeKind_TYPE_UNION = 8,
    nl_TypeKind_TYPE_GENERIC = 9,
    nl_TypeKind_TYPE_LIST_INT = 10,
    nl_TypeKind_TYPE_LIST_STRING = 11,
    nl_TypeKind_TYPE_LIST_TOKEN = 12,
    nl_TypeKind_TYPE_LIST_GENERIC = 13,
    nl_TypeKind_TYPE_FUNCTION = 14,
    nl_TypeKind_TYPE_TUPLE = 15,
    nl_TypeKind_TYPE_OPAQUE = 16,
    nl_TypeKind_TYPE_UNKNOWN = 17
} nl_TypeKind;

/* ========== End Enum Definitions ========== */

#ifndef FORWARD_DEFINED_List_CompilerDiagnostic
#define FORWARD_DEFINED_List_CompilerDiagnostic
typedef struct List_CompilerDiagnostic List_CompilerDiagnostic;
#endif
#ifndef FORWARD_DEFINED_List_LexerToken
#define FORWARD_DEFINED_List_LexerToken
typedef struct List_LexerToken List_LexerToken;
#endif
#ifndef FORWARD_DEFINED_List_ASTStmtRef
#define FORWARD_DEFINED_List_ASTStmtRef
typedef struct List_ASTStmtRef List_ASTStmtRef;
#endif
#ifndef FORWARD_DEFINED_List_ASTNumber
#define FORWARD_DEFINED_List_ASTNumber
typedef struct List_ASTNumber List_ASTNumber;
#endif
#ifndef FORWARD_DEFINED_List_ASTFloat
#define FORWARD_DEFINED_List_ASTFloat
typedef struct List_ASTFloat List_ASTFloat;
#endif
#ifndef FORWARD_DEFINED_List_ASTString
#define FORWARD_DEFINED_List_ASTString
typedef struct List_ASTString List_ASTString;
#endif
#ifndef FORWARD_DEFINED_List_ASTBool
#define FORWARD_DEFINED_List_ASTBool
typedef struct List_ASTBool List_ASTBool;
#endif
#ifndef FORWARD_DEFINED_List_ASTIdentifier
#define FORWARD_DEFINED_List_ASTIdentifier
typedef struct List_ASTIdentifier List_ASTIdentifier;
#endif
#ifndef FORWARD_DEFINED_List_ASTBinaryOp
#define FORWARD_DEFINED_List_ASTBinaryOp
typedef struct List_ASTBinaryOp List_ASTBinaryOp;
#endif
#ifndef FORWARD_DEFINED_List_ASTCall
#define FORWARD_DEFINED_List_ASTCall
typedef struct List_ASTCall List_ASTCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTModuleQualifiedCall
#define FORWARD_DEFINED_List_ASTModuleQualifiedCall
typedef struct List_ASTModuleQualifiedCall List_ASTModuleQualifiedCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTArrayLiteral
#define FORWARD_DEFINED_List_ASTArrayLiteral
typedef struct List_ASTArrayLiteral List_ASTArrayLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTLet
#define FORWARD_DEFINED_List_ASTLet
typedef struct List_ASTLet List_ASTLet;
#endif
#ifndef FORWARD_DEFINED_List_ASTSet
#define FORWARD_DEFINED_List_ASTSet
typedef struct List_ASTSet List_ASTSet;
#endif
#ifndef FORWARD_DEFINED_List_ASTIf
#define FORWARD_DEFINED_List_ASTIf
typedef struct List_ASTIf List_ASTIf;
#endif
#ifndef FORWARD_DEFINED_List_ASTWhile
#define FORWARD_DEFINED_List_ASTWhile
typedef struct List_ASTWhile List_ASTWhile;
#endif
#ifndef FORWARD_DEFINED_List_ASTFor
#define FORWARD_DEFINED_List_ASTFor
typedef struct List_ASTFor List_ASTFor;
#endif
#ifndef FORWARD_DEFINED_List_ASTReturn
#define FORWARD_DEFINED_List_ASTReturn
typedef struct List_ASTReturn List_ASTReturn;
#endif
#ifndef FORWARD_DEFINED_List_ASTBlock
#define FORWARD_DEFINED_List_ASTBlock
typedef struct List_ASTBlock List_ASTBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnsafeBlock
#define FORWARD_DEFINED_List_ASTUnsafeBlock
typedef struct List_ASTUnsafeBlock List_ASTUnsafeBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTPrint
#define FORWARD_DEFINED_List_ASTPrint
typedef struct List_ASTPrint List_ASTPrint;
#endif
#ifndef FORWARD_DEFINED_List_ASTAssert
#define FORWARD_DEFINED_List_ASTAssert
typedef struct List_ASTAssert List_ASTAssert;
#endif
#ifndef FORWARD_DEFINED_List_ASTFunction
#define FORWARD_DEFINED_List_ASTFunction
typedef struct List_ASTFunction List_ASTFunction;
#endif
#ifndef FORWARD_DEFINED_List_ASTShadow
#define FORWARD_DEFINED_List_ASTShadow
typedef struct List_ASTShadow List_ASTShadow;
#endif
#ifndef FORWARD_DEFINED_List_ASTStruct
#define FORWARD_DEFINED_List_ASTStruct
typedef struct List_ASTStruct List_ASTStruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTStructLiteral
#define FORWARD_DEFINED_List_ASTStructLiteral
typedef struct List_ASTStructLiteral List_ASTStructLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTFieldAccess
#define FORWARD_DEFINED_List_ASTFieldAccess
typedef struct List_ASTFieldAccess List_ASTFieldAccess;
#endif
#ifndef FORWARD_DEFINED_List_ASTEnum
#define FORWARD_DEFINED_List_ASTEnum
typedef struct List_ASTEnum List_ASTEnum;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnion
#define FORWARD_DEFINED_List_ASTUnion
typedef struct List_ASTUnion List_ASTUnion;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnionConstruct
#define FORWARD_DEFINED_List_ASTUnionConstruct
typedef struct List_ASTUnionConstruct List_ASTUnionConstruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTMatch
#define FORWARD_DEFINED_List_ASTMatch
typedef struct List_ASTMatch List_ASTMatch;
#endif
#ifndef FORWARD_DEFINED_List_ASTImport
#define FORWARD_DEFINED_List_ASTImport
typedef struct List_ASTImport List_ASTImport;
#endif
#ifndef FORWARD_DEFINED_List_ASTOpaqueType
#define FORWARD_DEFINED_List_ASTOpaqueType
typedef struct List_ASTOpaqueType List_ASTOpaqueType;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleLiteral
#define FORWARD_DEFINED_List_ASTTupleLiteral
typedef struct List_ASTTupleLiteral List_ASTTupleLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleIndex
#define FORWARD_DEFINED_List_ASTTupleIndex
typedef struct List_ASTTupleIndex List_ASTTupleIndex;
#endif
#ifndef FORWARD_DEFINED_List_ASTServiceDecl
#define FORWARD_DEFINED_List_ASTServiceDecl
typedef struct List_ASTServiceDecl List_ASTServiceDecl;
#endif
/* ========== Struct and Union Definitions ========== */

#ifndef DEFINED_nl___nano_record_706172736572_NameParseResult
#define DEFINED_nl___nano_record_706172736572_NameParseResult
typedef struct nl___nano_record_706172736572_NameParseResult {
    Parser p;
    const char* name;
    bool ok;
} nl___nano_record_706172736572_NameParseResult;
#endif

#ifndef DEFINED_nl___nano_record_706172736572_TypeParseResult
#define DEFINED_nl___nano_record_706172736572_TypeParseResult
typedef struct nl___nano_record_706172736572_TypeParseResult {
    Parser p;
    const char* type_name;
    bool ok;
} nl___nano_record_706172736572_TypeParseResult;
#endif

#ifndef DEFINED_nl___nano_record_706172736572_ParamParseResult
#define DEFINED_nl___nano_record_706172736572_ParamParseResult
typedef struct nl___nano_record_706172736572_ParamParseResult {
    Parser p;
    int64_t param_count;
} nl___nano_record_706172736572_ParamParseResult;
#endif

#ifndef DEFINED_nl___nano_record_706172736572_DefinitionParseResult
#define DEFINED_nl___nano_record_706172736572_DefinitionParseResult
typedef struct nl___nano_record_706172736572_DefinitionParseResult {
    Parser parser;
    int64_t function_index;
} nl___nano_record_706172736572_DefinitionParseResult;
#endif

#ifndef DEFINED_nl___nano_record_706172736572_ParsedDefinition
#define DEFINED_nl___nano_record_706172736572_ParsedDefinition
typedef struct nl___nano_record_706172736572_ParsedDefinition {
    int64_t first_token;
    int64_t after_token;
    bool is_public;
    DynArray* before;
    DynArray* after;
    int64_t result_kind;
    int64_t result_index;
    int64_t function_index;
} nl___nano_record_706172736572_ParsedDefinition;
#endif

#ifndef DEFINED_nl___nano_record_706172736572_ParsedDeclarations
#define DEFINED_nl___nano_record_706172736572_ParsedDeclarations
typedef struct nl___nano_record_706172736572_ParsedDeclarations {
    Parser parser;
    DynArray* definitions;
    bool truncated;
} nl___nano_record_706172736572_ParsedDeclarations;
#endif

/* ========== End Struct and Union Definitions ========== */

/* ========== Auto-Generated Struct Metadata ========== */

inline int64_t ___reflect___nano_record_706172736572_NameParseResult_field_count(void) {
    return 3;
}

inline const char* ___reflect___nano_record_706172736572_NameParseResult_field_name(int64_t index) {
    if (index == 0) { return "p"; }
    else if (index == 1) { return "name"; }
    else if (index == 2) { return "ok"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_NameParseResult_field_type(int64_t index) {
    if (index == 0) { return "Parser"; }
    else if (index == 1) { return "string"; }
    else if (index == 2) { return "bool"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_NameParseResult_has_field(const char* name) {
    if (strcmp(name, "p") == 0) { return 1; }
    else if (strcmp(name, "name") == 0) { return 1; }
    else if (strcmp(name, "ok") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_NameParseResult_field_type_by_name(const char* name) {
    if (strcmp(name, "p") == 0) { return "Parser"; }
    else if (strcmp(name, "name") == 0) { return "string"; }
    else if (strcmp(name, "ok") == 0) { return "bool"; }
    return "";
}

inline int64_t ___reflect___nano_record_706172736572_TypeParseResult_field_count(void) {
    return 3;
}

inline const char* ___reflect___nano_record_706172736572_TypeParseResult_field_name(int64_t index) {
    if (index == 0) { return "p"; }
    else if (index == 1) { return "type_name"; }
    else if (index == 2) { return "ok"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_TypeParseResult_field_type(int64_t index) {
    if (index == 0) { return "Parser"; }
    else if (index == 1) { return "string"; }
    else if (index == 2) { return "bool"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_TypeParseResult_has_field(const char* name) {
    if (strcmp(name, "p") == 0) { return 1; }
    else if (strcmp(name, "type_name") == 0) { return 1; }
    else if (strcmp(name, "ok") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_TypeParseResult_field_type_by_name(const char* name) {
    if (strcmp(name, "p") == 0) { return "Parser"; }
    else if (strcmp(name, "type_name") == 0) { return "string"; }
    else if (strcmp(name, "ok") == 0) { return "bool"; }
    return "";
}

inline int64_t ___reflect___nano_record_706172736572_ParamParseResult_field_count(void) {
    return 2;
}

inline const char* ___reflect___nano_record_706172736572_ParamParseResult_field_name(int64_t index) {
    if (index == 0) { return "p"; }
    else if (index == 1) { return "param_count"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_ParamParseResult_field_type(int64_t index) {
    if (index == 0) { return "Parser"; }
    else if (index == 1) { return "int"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_ParamParseResult_has_field(const char* name) {
    if (strcmp(name, "p") == 0) { return 1; }
    else if (strcmp(name, "param_count") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_ParamParseResult_field_type_by_name(const char* name) {
    if (strcmp(name, "p") == 0) { return "Parser"; }
    else if (strcmp(name, "param_count") == 0) { return "int"; }
    return "";
}

inline int64_t ___reflect___nano_record_706172736572_DefinitionParseResult_field_count(void) {
    return 2;
}

inline const char* ___reflect___nano_record_706172736572_DefinitionParseResult_field_name(int64_t index) {
    if (index == 0) { return "parser"; }
    else if (index == 1) { return "function_index"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_DefinitionParseResult_field_type(int64_t index) {
    if (index == 0) { return "Parser"; }
    else if (index == 1) { return "int"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_DefinitionParseResult_has_field(const char* name) {
    if (strcmp(name, "parser") == 0) { return 1; }
    else if (strcmp(name, "function_index") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_DefinitionParseResult_field_type_by_name(const char* name) {
    if (strcmp(name, "parser") == 0) { return "Parser"; }
    else if (strcmp(name, "function_index") == 0) { return "int"; }
    return "";
}

inline int64_t ___reflect___nano_record_706172736572_ParsedDefinition_field_count(void) {
    return 8;
}

inline const char* ___reflect___nano_record_706172736572_ParsedDefinition_field_name(int64_t index) {
    if (index == 0) { return "first_token"; }
    else if (index == 1) { return "after_token"; }
    else if (index == 2) { return "is_public"; }
    else if (index == 3) { return "before"; }
    else if (index == 4) { return "after"; }
    else if (index == 5) { return "result_kind"; }
    else if (index == 6) { return "result_index"; }
    else if (index == 7) { return "function_index"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_ParsedDefinition_field_type(int64_t index) {
    if (index == 0) { return "int"; }
    else if (index == 1) { return "int"; }
    else if (index == 2) { return "bool"; }
    else if (index == 3) { return "array<int>"; }
    else if (index == 4) { return "array<int>"; }
    else if (index == 5) { return "int"; }
    else if (index == 6) { return "int"; }
    else if (index == 7) { return "int"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_ParsedDefinition_has_field(const char* name) {
    if (strcmp(name, "first_token") == 0) { return 1; }
    else if (strcmp(name, "after_token") == 0) { return 1; }
    else if (strcmp(name, "is_public") == 0) { return 1; }
    else if (strcmp(name, "before") == 0) { return 1; }
    else if (strcmp(name, "after") == 0) { return 1; }
    else if (strcmp(name, "result_kind") == 0) { return 1; }
    else if (strcmp(name, "result_index") == 0) { return 1; }
    else if (strcmp(name, "function_index") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_ParsedDefinition_field_type_by_name(const char* name) {
    if (strcmp(name, "first_token") == 0) { return "int"; }
    else if (strcmp(name, "after_token") == 0) { return "int"; }
    else if (strcmp(name, "is_public") == 0) { return "bool"; }
    else if (strcmp(name, "before") == 0) { return "array<int>"; }
    else if (strcmp(name, "after") == 0) { return "array<int>"; }
    else if (strcmp(name, "result_kind") == 0) { return "int"; }
    else if (strcmp(name, "result_index") == 0) { return "int"; }
    else if (strcmp(name, "function_index") == 0) { return "int"; }
    return "";
}

inline int64_t ___reflect___nano_record_706172736572_ParsedDeclarations_field_count(void) {
    return 3;
}

inline const char* ___reflect___nano_record_706172736572_ParsedDeclarations_field_name(int64_t index) {
    if (index == 0) { return "parser"; }
    else if (index == 1) { return "definitions"; }
    else if (index == 2) { return "truncated"; }
    return "";
}

inline const char* ___reflect___nano_record_706172736572_ParsedDeclarations_field_type(int64_t index) {
    if (index == 0) { return "Parser"; }
    else if (index == 1) { return "array<__nano_record_706172736572_ParsedDefinition>"; }
    else if (index == 2) { return "bool"; }
    return "";
}

inline bool ___reflect___nano_record_706172736572_ParsedDeclarations_has_field(const char* name) {
    if (strcmp(name, "parser") == 0) { return 1; }
    else if (strcmp(name, "definitions") == 0) { return 1; }
    else if (strcmp(name, "truncated") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_706172736572_ParsedDeclarations_field_type_by_name(const char* name) {
    if (strcmp(name, "parser") == 0) { return "Parser"; }
    else if (strcmp(name, "definitions") == 0) { return "array<__nano_record_706172736572_ParsedDefinition>"; }
    else if (strcmp(name, "truncated") == 0) { return "bool"; }
    return "";
}

/* ========== End Struct Metadata ========== */

#include "runtime/list_CompilerDiagnostic.h"
#include "runtime/list_LexerToken.h"
#include "runtime/list_ASTStmtRef.h"
#include "runtime/list_ASTNumber.h"
#include "runtime/list_ASTFloat.h"
#include "runtime/list_ASTString.h"
#include "runtime/list_ASTBool.h"
#include "runtime/list_ASTIdentifier.h"
#include "runtime/list_ASTBinaryOp.h"
#include "runtime/list_ASTCall.h"
#include "runtime/list_ASTModuleQualifiedCall.h"
#include "runtime/list_ASTArrayLiteral.h"
#include "runtime/list_ASTLet.h"
#include "runtime/list_ASTSet.h"
#include "runtime/list_ASTIf.h"
#include "runtime/list_ASTWhile.h"
#include "runtime/list_ASTFor.h"
#include "runtime/list_ASTReturn.h"
#include "runtime/list_ASTBlock.h"
#include "runtime/list_ASTUnsafeBlock.h"
#include "runtime/list_ASTPrint.h"
#include "runtime/list_ASTAssert.h"
#include "runtime/list_ASTFunction.h"
#include "runtime/list_ASTShadow.h"
#include "runtime/list_ASTStruct.h"
#include "runtime/list_ASTStructLiteral.h"
#include "runtime/list_ASTFieldAccess.h"
#include "runtime/list_ASTEnum.h"
#include "runtime/list_ASTUnion.h"
#include "runtime/list_ASTUnionConstruct.h"
#include "runtime/list_ASTMatch.h"
#include "runtime/list_ASTImport.h"
#include "runtime/list_ASTOpaqueType.h"
#include "runtime/list_ASTTupleLiteral.h"
#include "runtime/list_ASTTupleIndex.h"
#include "runtime/list_ASTServiceDecl.h"
/* ========== HashMap Runtime (Generated) ========== */

static uint64_t nl_hashmap_hash_string(const char *s) {
    if (!s) return 0;
    uint64_t hash = 1469598103934665603ULL;
    while (*s) { hash ^= (uint8_t)(*s++); hash *= 1099511628211ULL; }
    return hash;
}

static uint64_t nl_hashmap_hash_int(int64_t x) {
    uint64_t z = (uint64_t)x;
    z ^= z >> 33;
    z *= 0xff51afd7ed558ccdULL;
    z ^= z >> 33;
    z *= 0xc4ceb9fe1a85ec53ULL;
    z ^= z >> 33;
    return z;
}

static bool nl_hashmap_key_eq_string(const char *a, const char *b) {
    if (a == b) return true;
    if (!a || !b) return false;
    return strcmp(a, b) == 0;
}

/* (no HashMap instantiations) */

/* ========== End HashMap Runtime (Generated) ========== */

/* ========== To-String Helpers ========== */

/* To-String forward declarations */
static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v);
static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v);
static const char* nl_to_string_TypeKind(nl_TypeKind v);
static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v);
static const char* nl_to_string_CompilerPhase(CompilerPhase v);
static const char* nl_to_string___nano_record_706172736572_NameParseResult(nl___nano_record_706172736572_NameParseResult v);
static const char* nl_to_string___nano_record_706172736572_TypeParseResult(nl___nano_record_706172736572_TypeParseResult v);
static const char* nl_to_string___nano_record_706172736572_ParamParseResult(nl___nano_record_706172736572_ParamParseResult v);
static const char* nl_to_string___nano_record_706172736572_DefinitionParseResult(nl___nano_record_706172736572_DefinitionParseResult v);
static const char* nl_to_string___nano_record_706172736572_ParsedDefinition(nl___nano_record_706172736572_ParsedDefinition v);
static const char* nl_to_string___nano_record_706172736572_ParsedDeclarations(nl___nano_record_706172736572_ParsedDeclarations v);

static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v) {
    switch (v) {
        case nl_LexerTokenType_TOKEN_EOF: return "LexerTokenType.TOKEN_EOF";
        case nl_LexerTokenType_TOKEN_NUMBER: return "LexerTokenType.TOKEN_NUMBER";
        case nl_LexerTokenType_TOKEN_FLOAT: return "LexerTokenType.TOKEN_FLOAT";
        case nl_LexerTokenType_TOKEN_STRING: return "LexerTokenType.TOKEN_STRING";
        case nl_LexerTokenType_TOKEN_IDENTIFIER: return "LexerTokenType.TOKEN_IDENTIFIER";
        case nl_LexerTokenType_TOKEN_TRUE: return "LexerTokenType.TOKEN_TRUE";
        case nl_LexerTokenType_TOKEN_FALSE: return "LexerTokenType.TOKEN_FALSE";
        case nl_LexerTokenType_TOKEN_LPAREN: return "LexerTokenType.TOKEN_LPAREN";
        case nl_LexerTokenType_TOKEN_RPAREN: return "LexerTokenType.TOKEN_RPAREN";
        case nl_LexerTokenType_TOKEN_LBRACE: return "LexerTokenType.TOKEN_LBRACE";
        case nl_LexerTokenType_TOKEN_RBRACE: return "LexerTokenType.TOKEN_RBRACE";
        case nl_LexerTokenType_TOKEN_LBRACKET: return "LexerTokenType.TOKEN_LBRACKET";
        case nl_LexerTokenType_TOKEN_RBRACKET: return "LexerTokenType.TOKEN_RBRACKET";
        case nl_LexerTokenType_TOKEN_COMMA: return "LexerTokenType.TOKEN_COMMA";
        case nl_LexerTokenType_TOKEN_COLON: return "LexerTokenType.TOKEN_COLON";
        case nl_LexerTokenType_TOKEN_DOUBLE_COLON: return "LexerTokenType.TOKEN_DOUBLE_COLON";
        case nl_LexerTokenType_TOKEN_ARROW: return "LexerTokenType.TOKEN_ARROW";
        case nl_LexerTokenType_TOKEN_ASSIGN: return "LexerTokenType.TOKEN_ASSIGN";
        case nl_LexerTokenType_TOKEN_DOT: return "LexerTokenType.TOKEN_DOT";
        case nl_LexerTokenType_TOKEN_MODULE: return "LexerTokenType.TOKEN_MODULE";
        case nl_LexerTokenType_TOKEN_PUB: return "LexerTokenType.TOKEN_PUB";
        case nl_LexerTokenType_TOKEN_FROM: return "LexerTokenType.TOKEN_FROM";
        case nl_LexerTokenType_TOKEN_USE: return "LexerTokenType.TOKEN_USE";
        case nl_LexerTokenType_TOKEN_EXTERN: return "LexerTokenType.TOKEN_EXTERN";
        case nl_LexerTokenType_TOKEN_FN: return "LexerTokenType.TOKEN_FN";
        case nl_LexerTokenType_TOKEN_LET: return "LexerTokenType.TOKEN_LET";
        case nl_LexerTokenType_TOKEN_MUT: return "LexerTokenType.TOKEN_MUT";
        case nl_LexerTokenType_TOKEN_SET: return "LexerTokenType.TOKEN_SET";
        case nl_LexerTokenType_TOKEN_IF: return "LexerTokenType.TOKEN_IF";
        case nl_LexerTokenType_TOKEN_ELSE: return "LexerTokenType.TOKEN_ELSE";
        case nl_LexerTokenType_TOKEN_COND: return "LexerTokenType.TOKEN_COND";
        case nl_LexerTokenType_TOKEN_WHILE: return "LexerTokenType.TOKEN_WHILE";
        case nl_LexerTokenType_TOKEN_FOR: return "LexerTokenType.TOKEN_FOR";
        case nl_LexerTokenType_TOKEN_IN: return "LexerTokenType.TOKEN_IN";
        case nl_LexerTokenType_TOKEN_RETURN: return "LexerTokenType.TOKEN_RETURN";
        case nl_LexerTokenType_TOKEN_BREAK: return "LexerTokenType.TOKEN_BREAK";
        case nl_LexerTokenType_TOKEN_CONTINUE: return "LexerTokenType.TOKEN_CONTINUE";
        case nl_LexerTokenType_TOKEN_ASSERT: return "LexerTokenType.TOKEN_ASSERT";
        case nl_LexerTokenType_TOKEN_SHADOW: return "LexerTokenType.TOKEN_SHADOW";
        case nl_LexerTokenType_TOKEN_REQUIRES: return "LexerTokenType.TOKEN_REQUIRES";
        case nl_LexerTokenType_TOKEN_ENSURES: return "LexerTokenType.TOKEN_ENSURES";
        case nl_LexerTokenType_TOKEN_PRINT: return "LexerTokenType.TOKEN_PRINT";
        case nl_LexerTokenType_TOKEN_ARRAY: return "LexerTokenType.TOKEN_ARRAY";
        case nl_LexerTokenType_TOKEN_STRUCT: return "LexerTokenType.TOKEN_STRUCT";
        case nl_LexerTokenType_TOKEN_ENUM: return "LexerTokenType.TOKEN_ENUM";
        case nl_LexerTokenType_TOKEN_UNION: return "LexerTokenType.TOKEN_UNION";
        case nl_LexerTokenType_TOKEN_MATCH: return "LexerTokenType.TOKEN_MATCH";
        case nl_LexerTokenType_TOKEN_IMPORT: return "LexerTokenType.TOKEN_IMPORT";
        case nl_LexerTokenType_TOKEN_AS: return "LexerTokenType.TOKEN_AS";
        case nl_LexerTokenType_TOKEN_OPAQUE: return "LexerTokenType.TOKEN_OPAQUE";
        case nl_LexerTokenType_TOKEN_TYPE_INT: return "LexerTokenType.TOKEN_TYPE_INT";
        case nl_LexerTokenType_TOKEN_TYPE_U8: return "LexerTokenType.TOKEN_TYPE_U8";
        case nl_LexerTokenType_TOKEN_TYPE_FLOAT: return "LexerTokenType.TOKEN_TYPE_FLOAT";
        case nl_LexerTokenType_TOKEN_TYPE_BOOL: return "LexerTokenType.TOKEN_TYPE_BOOL";
        case nl_LexerTokenType_TOKEN_TYPE_STRING: return "LexerTokenType.TOKEN_TYPE_STRING";
        case nl_LexerTokenType_TOKEN_TYPE_BSTRING: return "LexerTokenType.TOKEN_TYPE_BSTRING";
        case nl_LexerTokenType_TOKEN_TYPE_VOID: return "LexerTokenType.TOKEN_TYPE_VOID";
        case nl_LexerTokenType_TOKEN_PLUS: return "LexerTokenType.TOKEN_PLUS";
        case nl_LexerTokenType_TOKEN_MINUS: return "LexerTokenType.TOKEN_MINUS";
        case nl_LexerTokenType_TOKEN_STAR: return "LexerTokenType.TOKEN_STAR";
        case nl_LexerTokenType_TOKEN_SLASH: return "LexerTokenType.TOKEN_SLASH";
        case nl_LexerTokenType_TOKEN_PERCENT: return "LexerTokenType.TOKEN_PERCENT";
        case nl_LexerTokenType_TOKEN_EQ: return "LexerTokenType.TOKEN_EQ";
        case nl_LexerTokenType_TOKEN_NE: return "LexerTokenType.TOKEN_NE";
        case nl_LexerTokenType_TOKEN_LT: return "LexerTokenType.TOKEN_LT";
        case nl_LexerTokenType_TOKEN_LE: return "LexerTokenType.TOKEN_LE";
        case nl_LexerTokenType_TOKEN_GT: return "LexerTokenType.TOKEN_GT";
        case nl_LexerTokenType_TOKEN_GE: return "LexerTokenType.TOKEN_GE";
        case nl_LexerTokenType_TOKEN_AND: return "LexerTokenType.TOKEN_AND";
        case nl_LexerTokenType_TOKEN_OR: return "LexerTokenType.TOKEN_OR";
        case nl_LexerTokenType_TOKEN_NOT: return "LexerTokenType.TOKEN_NOT";
        case nl_LexerTokenType_TOKEN_RANGE: return "LexerTokenType.TOKEN_RANGE";
        case nl_LexerTokenType_TOKEN_UNSAFE: return "LexerTokenType.TOKEN_UNSAFE";
        case nl_LexerTokenType_TOKEN_RESOURCE: return "LexerTokenType.TOKEN_RESOURCE";
        case nl_LexerTokenType_TOKEN_PIPE: return "LexerTokenType.TOKEN_PIPE";
        case nl_LexerTokenType_TOKEN_GRAMMAR: return "LexerTokenType.TOKEN_GRAMMAR";
        case nl_LexerTokenType_TOKEN_LARROW: return "LexerTokenType.TOKEN_LARROW";
        case nl_LexerTokenType_TOKEN_QUESTION: return "LexerTokenType.TOKEN_QUESTION";
        case nl_LexerTokenType_TOKEN_PAR: return "LexerTokenType.TOKEN_PAR";
        case nl_LexerTokenType_TOKEN_BAR: return "LexerTokenType.TOKEN_BAR";
        case nl_LexerTokenType_TOKEN_EFFECT: return "LexerTokenType.TOKEN_EFFECT";
        case nl_LexerTokenType_TOKEN_HANDLE: return "LexerTokenType.TOKEN_HANDLE";
        case nl_LexerTokenType_TOKEN_WITH: return "LexerTokenType.TOKEN_WITH";
        case nl_LexerTokenType_TOKEN_RESUME: return "LexerTokenType.TOKEN_RESUME";
        case nl_LexerTokenType_TOKEN_GPU: return "LexerTokenType.TOKEN_GPU";
        case nl_LexerTokenType_TOKEN_ASYNC: return "LexerTokenType.TOKEN_ASYNC";
        case nl_LexerTokenType_TOKEN_AWAIT: return "LexerTokenType.TOKEN_AWAIT";
        case nl_LexerTokenType_TOKEN_PURE: return "LexerTokenType.TOKEN_PURE";
        case nl_LexerTokenType_TOKEN_AMPERSAND: return "LexerTokenType.TOKEN_AMPERSAND";
        default: return "LexerTokenType.<unknown>";
    }
}

static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v) {
    switch (v) {
        case nl_ParseNodeType_PNODE_NUMBER: return "ParseNodeType.PNODE_NUMBER";
        case nl_ParseNodeType_PNODE_FLOAT: return "ParseNodeType.PNODE_FLOAT";
        case nl_ParseNodeType_PNODE_STRING: return "ParseNodeType.PNODE_STRING";
        case nl_ParseNodeType_PNODE_BOOL: return "ParseNodeType.PNODE_BOOL";
        case nl_ParseNodeType_PNODE_IDENTIFIER: return "ParseNodeType.PNODE_IDENTIFIER";
        case nl_ParseNodeType_PNODE_BINARY_OP: return "ParseNodeType.PNODE_BINARY_OP";
        case nl_ParseNodeType_PNODE_CALL: return "ParseNodeType.PNODE_CALL";
        case nl_ParseNodeType_PNODE_ARRAY_LITERAL: return "ParseNodeType.PNODE_ARRAY_LITERAL";
        case nl_ParseNodeType_PNODE_LET: return "ParseNodeType.PNODE_LET";
        case nl_ParseNodeType_PNODE_SET: return "ParseNodeType.PNODE_SET";
        case nl_ParseNodeType_PNODE_IF: return "ParseNodeType.PNODE_IF";
        case nl_ParseNodeType_PNODE_COND: return "ParseNodeType.PNODE_COND";
        case nl_ParseNodeType_PNODE_WHILE: return "ParseNodeType.PNODE_WHILE";
        case nl_ParseNodeType_PNODE_FOR: return "ParseNodeType.PNODE_FOR";
        case nl_ParseNodeType_PNODE_RETURN: return "ParseNodeType.PNODE_RETURN";
        case nl_ParseNodeType_PNODE_BREAK: return "ParseNodeType.PNODE_BREAK";
        case nl_ParseNodeType_PNODE_CONTINUE: return "ParseNodeType.PNODE_CONTINUE";
        case nl_ParseNodeType_PNODE_BLOCK: return "ParseNodeType.PNODE_BLOCK";
        case nl_ParseNodeType_PNODE_PRINT: return "ParseNodeType.PNODE_PRINT";
        case nl_ParseNodeType_PNODE_ASSERT: return "ParseNodeType.PNODE_ASSERT";
        case nl_ParseNodeType_PNODE_PROGRAM: return "ParseNodeType.PNODE_PROGRAM";
        case nl_ParseNodeType_PNODE_FUNCTION: return "ParseNodeType.PNODE_FUNCTION";
        case nl_ParseNodeType_PNODE_SHADOW: return "ParseNodeType.PNODE_SHADOW";
        case nl_ParseNodeType_PNODE_STRUCT_DEF: return "ParseNodeType.PNODE_STRUCT_DEF";
        case nl_ParseNodeType_PNODE_STRUCT_LITERAL: return "ParseNodeType.PNODE_STRUCT_LITERAL";
        case nl_ParseNodeType_PNODE_FIELD_ACCESS: return "ParseNodeType.PNODE_FIELD_ACCESS";
        case nl_ParseNodeType_PNODE_ENUM_DEF: return "ParseNodeType.PNODE_ENUM_DEF";
        case nl_ParseNodeType_PNODE_UNION_DEF: return "ParseNodeType.PNODE_UNION_DEF";
        case nl_ParseNodeType_PNODE_UNION_CONSTRUCT: return "ParseNodeType.PNODE_UNION_CONSTRUCT";
        case nl_ParseNodeType_PNODE_MATCH: return "ParseNodeType.PNODE_MATCH";
        case nl_ParseNodeType_PNODE_IMPORT: return "ParseNodeType.PNODE_IMPORT";
        case nl_ParseNodeType_PNODE_OPAQUE_TYPE: return "ParseNodeType.PNODE_OPAQUE_TYPE";
        case nl_ParseNodeType_PNODE_TUPLE_LITERAL: return "ParseNodeType.PNODE_TUPLE_LITERAL";
        case nl_ParseNodeType_PNODE_TUPLE_INDEX: return "ParseNodeType.PNODE_TUPLE_INDEX";
        case nl_ParseNodeType_PNODE_STRUCT: return "ParseNodeType.PNODE_STRUCT";
        case nl_ParseNodeType_PNODE_ENUM: return "ParseNodeType.PNODE_ENUM";
        case nl_ParseNodeType_PNODE_UNION: return "ParseNodeType.PNODE_UNION";
        case nl_ParseNodeType_PNODE_UNSAFE_BLOCK: return "ParseNodeType.PNODE_UNSAFE_BLOCK";
        case nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL: return "ParseNodeType.PNODE_MODULE_QUALIFIED_CALL";
        case nl_ParseNodeType_PNODE_GRAMMAR: return "ParseNodeType.PNODE_GRAMMAR";
        case nl_ParseNodeType_PNODE_PAR_BLOCK: return "ParseNodeType.PNODE_PAR_BLOCK";
        case nl_ParseNodeType_PNODE_EFFECT_DECL: return "ParseNodeType.PNODE_EFFECT_DECL";
        case nl_ParseNodeType_PNODE_HANDLE_EXPR: return "ParseNodeType.PNODE_HANDLE_EXPR";
        case nl_ParseNodeType_PNODE_ASYNC_FN: return "ParseNodeType.PNODE_ASYNC_FN";
        case nl_ParseNodeType_PNODE_SERVICE_DECL: return "ParseNodeType.PNODE_SERVICE_DECL";
        default: return "ParseNodeType.<unknown>";
    }
}

static const char* nl_to_string_TypeKind(nl_TypeKind v) {
    switch (v) {
        case nl_TypeKind_TYPE_INT: return "TypeKind.TYPE_INT";
        case nl_TypeKind_TYPE_FLOAT: return "TypeKind.TYPE_FLOAT";
        case nl_TypeKind_TYPE_BOOL: return "TypeKind.TYPE_BOOL";
        case nl_TypeKind_TYPE_STRING: return "TypeKind.TYPE_STRING";
        case nl_TypeKind_TYPE_VOID: return "TypeKind.TYPE_VOID";
        case nl_TypeKind_TYPE_ARRAY: return "TypeKind.TYPE_ARRAY";
        case nl_TypeKind_TYPE_STRUCT: return "TypeKind.TYPE_STRUCT";
        case nl_TypeKind_TYPE_ENUM: return "TypeKind.TYPE_ENUM";
        case nl_TypeKind_TYPE_UNION: return "TypeKind.TYPE_UNION";
        case nl_TypeKind_TYPE_GENERIC: return "TypeKind.TYPE_GENERIC";
        case nl_TypeKind_TYPE_LIST_INT: return "TypeKind.TYPE_LIST_INT";
        case nl_TypeKind_TYPE_LIST_STRING: return "TypeKind.TYPE_LIST_STRING";
        case nl_TypeKind_TYPE_LIST_TOKEN: return "TypeKind.TYPE_LIST_TOKEN";
        case nl_TypeKind_TYPE_LIST_GENERIC: return "TypeKind.TYPE_LIST_GENERIC";
        case nl_TypeKind_TYPE_FUNCTION: return "TypeKind.TYPE_FUNCTION";
        case nl_TypeKind_TYPE_TUPLE: return "TypeKind.TYPE_TUPLE";
        case nl_TypeKind_TYPE_OPAQUE: return "TypeKind.TYPE_OPAQUE";
        case nl_TypeKind_TYPE_UNKNOWN: return "TypeKind.TYPE_UNKNOWN";
        default: return "TypeKind.<unknown>";
    }
}

static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v) {
    switch (v) {
        case DiagnosticSeverity_DIAG_INFO: return "DiagnosticSeverity.DIAG_INFO";
        case DiagnosticSeverity_DIAG_WARNING: return "DiagnosticSeverity.DIAG_WARNING";
        case DiagnosticSeverity_DIAG_ERROR: return "DiagnosticSeverity.DIAG_ERROR";
        default: return "DiagnosticSeverity.<unknown>";
    }
}

static const char* nl_to_string_CompilerPhase(CompilerPhase v) {
    switch (v) {
        case CompilerPhase_PHASE_LEXER: return "CompilerPhase.PHASE_LEXER";
        case CompilerPhase_PHASE_PARSER: return "CompilerPhase.PHASE_PARSER";
        case CompilerPhase_PHASE_TYPECHECK: return "CompilerPhase.PHASE_TYPECHECK";
        case CompilerPhase_PHASE_TRANSPILER: return "CompilerPhase.PHASE_TRANSPILER";
        case CompilerPhase_PHASE_RUNTIME: return "CompilerPhase.PHASE_RUNTIME";
        default: return "CompilerPhase.<unknown>";
    }
}

static const char* nl_to_string___nano_record_706172736572_NameParseResult(nl___nano_record_706172736572_NameParseResult v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "NameParseResult { ");
    nl_fmt_sb_append_cstr(&sb, "p: ");
    nl_fmt_sb_append_cstr(&sb, "<extern>");
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "name: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.name));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "ok: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(v.ok));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

static const char* nl_to_string___nano_record_706172736572_TypeParseResult(nl___nano_record_706172736572_TypeParseResult v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "TypeParseResult { ");
    nl_fmt_sb_append_cstr(&sb, "p: ");
    nl_fmt_sb_append_cstr(&sb, "<extern>");
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "type_name: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.type_name));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "ok: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(v.ok));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

static const char* nl_to_string___nano_record_706172736572_ParamParseResult(nl___nano_record_706172736572_ParamParseResult v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "ParamParseResult { ");
    nl_fmt_sb_append_cstr(&sb, "p: ");
    nl_fmt_sb_append_cstr(&sb, "<extern>");
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "param_count: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.param_count));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

static const char* nl_to_string___nano_record_706172736572_DefinitionParseResult(nl___nano_record_706172736572_DefinitionParseResult v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "DefinitionParseResult { ");
    nl_fmt_sb_append_cstr(&sb, "parser: ");
    nl_fmt_sb_append_cstr(&sb, "<extern>");
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "function_index: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.function_index));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

static const char* nl_to_string___nano_record_706172736572_ParsedDefinition(nl___nano_record_706172736572_ParsedDefinition v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "ParsedDefinition { ");
    nl_fmt_sb_append_cstr(&sb, "first_token: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.first_token));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "after_token: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.after_token));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "is_public: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(v.is_public));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "before: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_array(v.before));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "after: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_array(v.after));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "result_kind: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.result_kind));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "result_index: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.result_index));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "function_index: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.function_index));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

static const char* nl_to_string___nano_record_706172736572_ParsedDeclarations(nl___nano_record_706172736572_ParsedDeclarations v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "ParsedDeclarations { ");
    nl_fmt_sb_append_cstr(&sb, "parser: ");
    nl_fmt_sb_append_cstr(&sb, "<extern>");
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "definitions: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_array(v.definitions));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "truncated: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(v.truncated));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

/* ========== End To-String Helpers ========== */

/* External C function declarations */
extern DynArray* fs_walkdir(const char* _root);
extern const char* path_normalize(const char* _path);
extern const char* path_canonical(const char* _path);
extern const char* path_join(const char* _a, const char* _b);
extern const char* path_basename(const char* _path);
extern const char* path_dirname(const char* _path);
extern const char* path_relpath(const char* _target, const char* _base);
extern const char* file_read(const char* _path);
extern int64_t file_write(const char* _path, const char* _content);
extern int64_t file_append(const char* _path, const char* _content);
extern bool file_exists(const char* _path);
extern int64_t file_delete(const char* _path);
extern int64_t fs_mkdir_p(const char* _path);
extern int64_t file_copy(const char* _src, const char* _dst);
extern int64_t dir_copy(const char* _src, const char* _dst);

/* Forward declarations for imported module functions */
extern Parser parser__parser_init_ast_lists();
extern Parser parser__parser_new(List_LexerToken* tokens, int64_t token_count, const char* file_name);
extern int64_t parser__parser_allocate_id(Parser p);
extern bool parser__parser_is_at_end(Parser p);
extern Parser parser__parser_with_position(Parser p, int64_t new_position);
extern Parser parser__parser_advance(Parser p);
extern int64_t parser__parser_position(Parser p);
extern LexerToken parser__parser_current(Parser p);
extern bool parser__parser_match(Parser p, int64_t token_type);
extern Parser parser__parser_expect(Parser p, int64_t token_type);
extern int64_t parser__parser_peek(Parser p, int64_t offset);
extern Parser parser__parser_with_error(Parser p, bool error);
extern bool parser__parser_has_error(Parser p);
extern int64_t parser__token_number();
extern int64_t parser__token_identifier();
extern int64_t parser__token_string();
extern int64_t parser__token_true();
extern int64_t parser__token_false();
extern int64_t parser__token_lparen();
extern int64_t parser__token_rparen();
extern int64_t parser__token_plus();
extern int64_t parser__token_minus();
extern int64_t parser__token_star();
extern int64_t parser__token_slash();
extern int64_t parser__token_eq();
extern int64_t parser__token_ne();
extern int64_t parser__token_lt();
extern int64_t parser__token_le();
extern int64_t parser__token_gt();
extern int64_t parser__token_ge();
extern int64_t parser__token_and();
extern int64_t parser__token_or();
extern int64_t parser__token_comma();
extern int64_t parser__token_lbrace();
extern int64_t parser__token_rbrace();
extern int64_t parser__token_let();
extern int64_t parser__token_if();
extern int64_t parser__token_else();
extern int64_t parser__token_while();
extern int64_t parser__token_return();
extern int64_t parser__token_colon();
extern int64_t parser__token_mut();
extern int64_t parser__token_assign();
extern int64_t parser__token_arrow();
extern int64_t parser__token_fn();
extern int64_t parser__token_extern();
extern int64_t parser__token_set();
extern int64_t parser__token_struct();
extern int64_t parser__token_enum();
extern int64_t parser__token_union();
extern int64_t parser__token_for();
extern int64_t parser__token_in();
extern int64_t parser__token_assert();
extern int64_t parser__token_requires();
extern int64_t parser__token_ensures();
extern int64_t parser__token_unsafe();
extern int64_t parser__token_shadow();
extern int64_t parser__token_match();
extern int64_t parser__token_import();
extern int64_t parser__token_as();
extern int64_t parser__token_pub();
extern int64_t parser__token_pure();
extern int64_t parser__token_opaque();
extern int64_t parser__token_lbracket();
extern int64_t parser__token_rbracket();
extern int64_t parser__token_dot();
extern int64_t parser__token_double_colon();
extern int64_t parser__token_percent();
extern int64_t parser__token_not();
extern int64_t parser__token_pipe();
extern int64_t parser__token_grammar();
extern int64_t parser__token_larrow();
extern int64_t parser__token_question();
extern int64_t parser__token_array();
extern int64_t parser__token_type_int();
extern int64_t parser__token_type_u8();
extern int64_t parser__token_type_float();
extern int64_t parser__token_type_bool();
extern int64_t parser__token_type_string();
extern int64_t parser__token_type_bstring();
extern int64_t parser__token_type_void();
extern nl___nano_record_706172736572_NameParseResult parser__parse_qualified_name(Parser p);
extern nl___nano_record_706172736572_NameParseResult parser__parse_call_name(Parser p);
extern bool parser__is_type_start_token_type(int64_t token_type);
extern nl___nano_record_706172736572_TypeParseResult parser__parse_type_string(Parser p);
extern Parser parser__parser_store_number(Parser p, const char* value, int64_t line, int64_t column);
extern Parser parser__parser_store_string(Parser p, const char* value, int64_t line, int64_t column);
extern Parser parser__parser_store_bool(Parser p, bool value, int64_t line, int64_t column);
extern Parser parser__parser_store_identifier(Parser p, const char* name, int64_t line, int64_t column);
extern Parser parser__parser_store_binary_op(Parser p, int64_t op, int64_t left_id, int64_t right_id, int64_t left_type, int64_t right_type, int64_t line, int64_t column);
extern Parser parser__parser_mark_unary(Parser p);
extern Parser parser__parser_store_call(Parser p, int64_t function_id, int64_t function_type, int64_t arg_start, int64_t arg_count, int64_t line, int64_t column);
extern Parser parser__parser_store_module_qualified_call(Parser p, const char* module_name, const char* function_name, int64_t arg_start, int64_t arg_count, int64_t line, int64_t column);
extern bool parser__name_contains_dot(const char* name);
extern Parser parser__parser_store_call_arg(Parser p, int64_t node_id, int64_t node_type);
extern Parser parser__parser_store_array_element(Parser p, int64_t node_id, int64_t node_type);
extern Parser parser__parse_named_literal(Parser p, const char* name, int64_t line, int64_t column);
extern Parser parser__parse_union_construct(Parser p, const char* union_name, const char* variant_name, int64_t start_line, int64_t start_column);
extern Parser parser__parse_struct_literal(Parser p, const char* struct_name, int64_t start_line, int64_t start_column);
extern Parser parser__parse_cond_expression(Parser p);
extern Parser parser__parse_cond_clauses(Parser p, int64_t line, int64_t column);
extern Parser parser__parser_expect_match_arrow(Parser p);
extern Parser parser__parse_match_guard(Parser p);
extern bool parser__parser_match_arm_unconditional(Parser p, ASTMatch matched, int64_t arm);
extern Parser parser__parse_match(Parser p);
extern Parser parser__parse_primary(Parser p);
extern Parser parser__parse_parenthesized_head(Parser p);
extern bool parser__parenthesized_call_start(Parser p);
extern bool parser__is_binary_op(int64_t token_type);
extern Parser parser__parse_expression_recursive(Parser p, bool left_parsed);
extern Parser parser__parse_expression(Parser p);
extern Parser parser__parser_store_let(Parser p, const char* name, const char* var_type, int64_t value_id, int64_t value_type, bool is_mut, int64_t line, int64_t column);
extern Parser parser__parser_store_set(Parser p, const char* target, const char* field_name, int64_t value_id, int64_t value_type, int64_t line, int64_t column);
extern Parser parser__parser_mark_if_expression(Parser p);
extern Parser parser__parser_store_if(Parser p, int64_t condition_id, int64_t condition_type, int64_t then_body_id, int64_t else_body_id, int64_t line, int64_t column);
extern Parser parser__parser_store_while(Parser p, int64_t condition_id, int64_t condition_type, int64_t body_id, int64_t line, int64_t column);
extern Parser parser__parser_store_for(Parser p, const char* var_name, int64_t iterable_id, int64_t iterable_type, int64_t body_id, int64_t line, int64_t column);
extern Parser parser__parser_finish_array_literal(Parser p, DynArray* ids, DynArray* types, int64_t line, int64_t column);
extern Parser parser__parser_store_array_literal(Parser p, int64_t element_start, int64_t element_count, const char* element_type, int64_t line, int64_t column);
extern bool parser__parser_is_value_expression(int64_t node_type);
extern bool parser__parser_always_returns(Parser parser, int64_t node_id, int64_t node_type);
extern const char* parser__parser_decode_import_path(const char* raw);
extern Parser parser__parser_store_import(Parser p, const char* module_path, const char* module_name, bool is_unsafe, bool is_selective, bool is_wildcard, DynArray* import_symbols, DynArray* import_aliases, int64_t import_symbol_count, int64_t line, int64_t column);
extern Parser parser__parser_store_service(Parser p, const char* interface_id, int64_t interface_bytes, const char* document_path, int64_t path_bytes, int64_t line, int64_t column);
extern Parser parser__parser_store_opaque_type(Parser p, const char* type_name, int64_t line, int64_t column);
extern Parser parser__parser_store_shadow(Parser p, const char* target_name, int64_t body_id, int64_t line, int64_t column);
extern Parser parser__parser_store_field_access(Parser p, int64_t object_id, int64_t object_type, const char* field_name, int64_t line, int64_t column);
extern Parser parser__parser_store_float(Parser p, const char* value, int64_t line, int64_t column);
extern Parser parser__parser_store_return(Parser p, int64_t value_id, int64_t value_type, int64_t line, int64_t column);
extern Parser parser__parser_store_assert(Parser p, int64_t condition_id, int64_t condition_type, int64_t line, int64_t column);
extern Parser parser__parser_store_block(Parser p, List_ASTStmtRef* stmts, int64_t line, int64_t column);
extern Parser parser__parser_wrap_if_in_block(Parser p, int64_t if_id, int64_t line, int64_t column);
extern int64_t parser__expr_kind_to_pnode(int64_t kind);
extern bool parser__parser_starts_owned_pattern(Parser p);
extern Parser parser__parser_mark_owned(Parser p, int64_t idx, bool whole, bool projection, DynArray* names);
extern Parser parser__parse_owned_pattern(Parser p, List_ASTStmtRef* stmts);
extern Parser parser__parse_block_recursive(Parser p, List_ASTStmtRef* stmts, int64_t start_line, int64_t start_column);
extern Parser parser__parse_block(Parser p);
extern Parser parser__parser_store_unsafe_block(Parser p, List_ASTStmtRef* stmts, int64_t line, int64_t column);
extern Parser parser__parse_unsafe_block_recursive(Parser p, List_ASTStmtRef* stmts, int64_t start_line, int64_t start_column);
extern Parser parser__parse_unsafe_block(Parser p);
extern Parser parser__parse_let_body(Parser p, bool is_mut, int64_t start_line, int64_t start_column);
extern Parser parser__parse_tuple_destructure(Parser p, List_ASTStmtRef* stmts, bool is_mut, int64_t line, int64_t column);
extern Parser parser__parse_let_statement(Parser p);
extern Parser parser__parse_block_expression(Parser p);
extern Parser parser__parse_if_expression(Parser p);
extern Parser parser__parse_if_statement(Parser p);
extern Parser parser__parse_while_statement(Parser p);
extern Parser parser__parse_return_statement(Parser p);
extern Parser parser__parse_assert_statement(Parser p);
extern Parser parser__parse_for_statement(Parser p);
extern Parser parser__parser_with_node(Parser p, int64_t kind, int64_t node_id);
extern Parser parser__parser_with_statement(Parser p, int64_t kind);
extern Parser parser__parser_mark_passive(Parser p, bool is_flow);
extern Parser parser__parser_mark_par(Parser p);
extern Parser parser__parse_statement(Parser p);
extern Parser parser__parser_mark_pure(Parser p);
extern Parser parser__parser_store_function(Parser p, const char* name, int64_t param_start, int64_t param_count, const char* return_type, int64_t body_id, int64_t line, int64_t column);
extern Parser parser__parser_store_struct(Parser p, const char* name, int64_t field_count, DynArray* field_names, DynArray* field_types, bool is_resource, bool is_extern, int64_t line, int64_t column);
extern Parser parser__parser_store_enum(Parser p, const char* name, int64_t variant_count, int64_t line, int64_t column, DynArray* variant_names, DynArray* variant_values);
extern Parser parser__parser_store_union(Parser p, const char* name, int64_t variant_count, int64_t line, int64_t column, DynArray* variant_names, DynArray* variant_field_counts, DynArray* variant_field_names, DynArray* variant_field_types, DynArray* generic_params, int64_t generic_param_count);
extern Parser parser__parser_store_union_construct(Parser p, const char* union_name, const char* variant_name, DynArray* field_names, DynArray* field_value_ids, DynArray* field_value_types, int64_t field_count, int64_t line, int64_t column);
extern Parser parser__parser_store_struct_literal(Parser p, const char* type_name, DynArray* field_names, DynArray* field_value_ids, DynArray* field_value_types, int64_t field_count, int64_t line, int64_t column);
extern Parser parser__parser_store_match(Parser p, int64_t scrutinee_id, int64_t scrutinee_type, DynArray* arm_variants, DynArray* arm_bindings, DynArray* arm_body_ids, DynArray* arm_body_types, DynArray* arm_guard_ids, DynArray* arm_guard_types, int64_t arm_count, int64_t line, int64_t column);
extern Parser parser__parser_store_tuple_literal(Parser p, DynArray* element_ids, DynArray* element_types, int64_t element_count, int64_t line, int64_t column);
extern Parser parser__parser_store_tuple_index(Parser p, int64_t tuple_id, int64_t tuple_type, int64_t index, int64_t line, int64_t column);
extern nl___nano_record_706172736572_TypeParseResult parser__parse_parameter_type(Parser p);
extern nl___nano_record_706172736572_ParamParseResult parser__parse_function_params(Parser p, int64_t param_count);
extern Parser parser__parse_extern_function_definition(Parser p);
extern Parser parser__parse_function_definition(Parser p);
extern Parser parser__parse_struct_fields(Parser p, const char* name, bool is_resource, bool is_extern, int64_t start_line, int64_t start_column);
extern Parser parser__parse_struct_definition(Parser p, bool is_extern);
extern Parser parser__parse_enum_variants(Parser p, int64_t variant_count, const char* name, int64_t start_line, int64_t start_column, DynArray* variant_names, DynArray* variant_values, int64_t next_value);
extern Parser parser__parse_enum_definition(Parser p);
extern Parser parser__parse_union_variants(Parser p, int64_t variant_count, const char* name, int64_t start_line, int64_t start_column, DynArray* variant_names, DynArray* variant_field_counts, DynArray* variant_field_names, DynArray* variant_field_types, DynArray* generic_params, int64_t generic_param_count);
extern Parser parser__parse_union_definition(Parser p);
extern Parser parser__parse_import(Parser p);
extern Parser parser__parse_pub_use(Parser p);
extern Parser parser__parse_module_import(Parser p, bool is_unsafe);
extern Parser parser__parse_from_import(Parser p);
extern Parser parser__parse_opaque_type(Parser p);
extern Parser parser__parse_shadow(Parser p);
extern bool parser__parser_service_utf8(const char* text);
extern Parser parser__parse_service_declaration(Parser p);
extern nl___nano_record_706172736572_DefinitionParseResult parser__definition_parse_result(Parser p, bool function);
extern nl___nano_record_706172736572_DefinitionParseResult parser__parse_definition_result(Parser p);
extern Parser parser__parse_definition(Parser p);
extern DynArray* parser__parser_declaration_extents(Parser p);
extern nl___nano_record_706172736572_ParsedDeclarations parser__parse_program_impl(List_LexerToken* tokens, int64_t token_count, const char* file_name, bool capture, int64_t capture_limit);
extern nl___nano_record_706172736572_ParsedDeclarations parser__parse_program_declarations(List_LexerToken* tokens, int64_t token_count, const char* file_name);
extern nl___nano_record_706172736572_ParsedDeclarations parser__parse_program_complete_declarations(List_LexerToken* tokens, int64_t token_count, const char* file_name);
extern Parser parser__parse_program(List_LexerToken* tokens, int64_t token_count, const char* file_name);
extern ASTNumber parser__create_number_node(const char* value, int64_t line, int64_t column);
extern ASTIdentifier parser__create_identifier_node(const char* name, int64_t line, int64_t column);
extern int64_t parser__test_parser_structure();
extern int64_t parser__parser_get_function_count(Parser p);
extern ASTFunction parser__parser_get_function(Parser p, int64_t idx);
extern int64_t parser__parser_get_let_count(Parser p);
extern ASTLet parser__parser_get_let(Parser p, int64_t idx);
extern Parser parser__parser_set_let_var_type(Parser p, int64_t idx, const char* var_type);
extern int64_t parser__parser_get_identifier_count(Parser p);
extern ASTIdentifier parser__parser_get_identifier(Parser p, int64_t idx);
extern int64_t parser__parser_get_number_count(Parser p);
extern ASTNumber parser__parser_get_number(Parser p, int64_t idx);
extern int64_t parser__parser_get_float_count(Parser p);
extern ASTFloat parser__parser_get_float(Parser p, int64_t idx);
extern int64_t parser__parser_get_binary_op_count(Parser p);
extern ASTBinaryOp parser__parser_get_binary_op(Parser p, int64_t idx);
extern int64_t parser__parser_get_return_count(Parser p);
extern ASTReturn parser__parser_get_return(Parser p, int64_t idx);
extern int64_t parser__parser_get_block_count(Parser p);
extern ASTBlock parser__parser_get_block(Parser p, int64_t idx);
extern ASTIf parser__parser_get_if(Parser p, int64_t idx);
extern int64_t parser__parser_get_if_count(Parser p);
extern ASTWhile parser__parser_get_while(Parser p, int64_t idx);
extern int64_t parser__parser_get_while_count(Parser p);
extern ASTFor parser__parser_get_for(Parser p, int64_t idx);
extern ASTUnsafeBlock parser__parser_get_unsafe_block(Parser p, int64_t idx);
extern ASTCall parser__parser_get_call(Parser p, int64_t idx);
extern int64_t parser__parser_get_call_count(Parser p);
extern ASTModuleQualifiedCall parser__parser_get_module_qualified_call(Parser p, int64_t idx);
extern int64_t parser__parser_get_module_qualified_call_count(Parser p);
extern int64_t parser__parser_get_call_arg_count(Parser p);
extern ASTStmtRef parser__parser_get_call_arg(Parser p, int64_t idx);
extern ASTSet parser__parser_get_set(Parser p, int64_t idx);
extern int64_t parser__parser_get_set_count(Parser p);
extern int64_t parser__parser_get_string_count(Parser p);
extern ASTString parser__parser_get_string(Parser p, int64_t idx);
extern int64_t parser__parser_get_bool_count(Parser p);
extern ASTBool parser__parser_get_bool(Parser p, int64_t idx);
extern int64_t parser__parser_get_assert_count(Parser p);
extern ASTAssert parser__parser_get_assert(Parser p, int64_t idx);
extern int64_t parser__parser_get_field_access_count(Parser p);
extern ASTFieldAccess parser__parser_get_field_access(Parser p, int64_t idx);
extern int64_t parser__parser_get_array_literal_count(Parser p);
extern ASTArrayLiteral parser__parser_get_array_literal(Parser p, int64_t idx);
extern Parser parser__parser_set_array_literal_element_type(Parser p, int64_t idx, const char* element_type);
extern int64_t parser__parser_get_array_element_count(Parser p);
extern ASTStmtRef parser__parser_get_array_element(Parser p, int64_t idx);
extern int64_t parser__parser_get_struct_def_count(Parser p);
extern ASTStruct parser__parser_get_struct_def(Parser p, int64_t idx);
extern int64_t parser__parser_get_struct_literal_count(Parser p);
extern ASTStructLiteral parser__parser_get_struct_literal(Parser p, int64_t idx);
extern int64_t parser__parser_get_enum_count(Parser p);
extern ASTEnum parser__parser_get_enum(Parser p, int64_t idx);
extern int64_t parser__parser_get_union_count(Parser p);
extern ASTUnion parser__parser_get_union(Parser p, int64_t idx);
extern int64_t parser__parser_get_union_construct_count(Parser p);
extern ASTUnionConstruct parser__parser_get_union_construct(Parser p, int64_t idx);
extern int64_t parser__parser_get_match_count(Parser p);
extern ASTMatch parser__parser_get_match(Parser p, int64_t idx);
extern int64_t parser__parser_get_tuple_literal_count(Parser p);
extern ASTTupleLiteral parser__parser_get_tuple_literal(Parser p, int64_t idx);
extern int64_t parser__parser_get_tuple_index_count(Parser p);
extern ASTTupleIndex parser__parser_get_tuple_index(Parser p, int64_t idx);
extern int64_t parser__parser_get_service_count(Parser p);
extern ASTServiceDecl parser__parser_get_service(Parser p, int64_t idx);
extern int64_t parser__parser_get_import_count(Parser p);
extern ASTImport parser__parser_get_import(Parser p, int64_t idx);
extern ParsePhaseOutput parser__parse_phase_run(LexPhaseOutput lex_output, const char* file_name);
extern bool lexer__is_identifier_start(int64_t c);
extern bool lexer__is_identifier_char(int64_t c);
extern bool lexer__is_whitespace_char(int64_t c);
extern bool lexer__is_digit_char(int64_t c);
extern int64_t lexer__keyword_group1(const char* s);
extern int64_t lexer__keyword_group2(const char* s);
extern int64_t lexer__keyword_group3(const char* s);
extern int64_t lexer__keyword_group4(const char* s);
extern int64_t lexer__keyword_group5(const char* s);
extern int64_t lexer__keyword_or_identifier(const char* s);
extern void lexer__push_tok(List_LexerToken* tokens, int64_t token_type, const char* value, int64_t line, int64_t column);
extern int64_t lexer__process_string(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
extern int64_t lexer__process_number(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
extern int64_t lexer__process_grammar_body(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
extern int64_t lexer__process_identifier(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
extern int64_t lexer__process_char_literal(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, int64_t line, int64_t column);
extern void lexer__emit_fstring_part_tokens(const char* part_text, int64_t is_expr, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column);
extern int64_t lexer__process_fstring(const char* source, int64_t i, int64_t len, List_LexerToken* tokens, List_CompilerDiagnostic* diags, const char* file_name, int64_t line, int64_t column);
extern List_LexerToken* lexer__tokenize_string(const char* source, const char* file_name, List_CompilerDiagnostic* diags);
extern List_LexerToken* lexer__tokenize_file(const char* path, List_CompilerDiagnostic* diags);
extern CompilerSourceLocation diagnostics__diag_location(const char* file, int64_t line, int64_t column);
extern CompilerSourceLocation diagnostics__diag_location_empty();
extern CompilerDiagnostic diagnostics__diag_new(int64_t phase, int64_t severity, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_simple(int64_t phase, int64_t severity, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_error(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_error_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_warning(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_warning_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_info(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_info_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_lexer_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_parser_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_typecheck_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_transpiler_error(const char* code, const char* message, CompilerSourceLocation location);
extern List_CompilerDiagnostic* diagnostics__diag_list_new();
extern void diagnostics__diag_list_add(List_CompilerDiagnostic* list, CompilerDiagnostic diag);
extern int64_t diagnostics__diag_list_count(List_CompilerDiagnostic* list);
extern CompilerDiagnostic diagnostics__diag_list_get(List_CompilerDiagnostic* list, int64_t index);
extern bool diagnostics__diag_list_has_errors(List_CompilerDiagnostic* list);
extern const char* diagnostics__diag_make_type_error(const char* expected_type, const char* found_type);
extern const char* diagnostics__diag_make_undefined_error(const char* name);
extern const char* diagnostics__diag_id_io_open();
extern const char* diagnostics__diag_id_lex_failed();
extern const char* diagnostics__diag_id_parse_failed();
extern const char* diagnostics__diag_id_import_failed();
extern const char* diagnostics__diag_id_type_failed();
extern const char* diagnostics__diag_id_mod_compile();
extern const char* diagnostics__diag_id_shadow_failed();
extern const char* diagnostics__diag_id_trans_failed();
extern const char* diagnostics__diag_id_c_temp();
extern const char* diagnostics__diag_id_cc_cmd();
extern const char* diagnostics__diag_id_cc_failed();
extern const char* diagnostics__diag_id_src_utf8();
extern const char* diagnostics__diag_en(const char* code);

/* Forward declarations for program functions */
bool passive_graph__passive_reads(Parser parser, int64_t id, int64_t kind, const char* name);
DynArray* passive_graph__passive_order(Parser parser, ASTBlock block);

/* Top-level globals */

bool passive_graph__passive_reads(Parser parser, int64_t id, int64_t kind, const char* name) {
#line 7 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    if ((kind) == (nl_ParseNodeType_PNODE_IDENTIFIER))     {
#line 7 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        return (strcmp(({ __auto_type __nl_arg_2328_0 = parser; __auto_type __nl_arg_2328_1 = id; parser__parser_get_identifier(__nl_arg_2328_0, __nl_arg_2328_1); }).name, name) == 0);
    }
#line 8 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    if ((kind) == (nl_ParseNodeType_PNODE_BINARY_OP))     {
#line 9 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        ASTBinaryOp node = ({ __auto_type __nl_arg_2329_0 = parser; __auto_type __nl_arg_2329_1 = id; parser__parser_get_binary_op(__nl_arg_2329_0, __nl_arg_2329_1); });
#line 10 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        if (node.is_unary)         {
#line 10 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            return ({ __auto_type __nl_arg_2330_0 = parser; __auto_type __nl_arg_2330_1 = node.right; __auto_type __nl_arg_2330_2 = node.right_type; __auto_type __nl_arg_2330_3 = name; passive_graph__passive_reads(__nl_arg_2330_0, __nl_arg_2330_1, __nl_arg_2330_2, __nl_arg_2330_3); });
        }
#line 11 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        return ((({ __auto_type __nl_arg_2331_0 = parser; __auto_type __nl_arg_2331_1 = node.left; __auto_type __nl_arg_2331_2 = node.left_type; __auto_type __nl_arg_2331_3 = name; passive_graph__passive_reads(__nl_arg_2331_0, __nl_arg_2331_1, __nl_arg_2331_2, __nl_arg_2331_3); })) || (({ __auto_type __nl_arg_2332_0 = parser; __auto_type __nl_arg_2332_1 = node.right; __auto_type __nl_arg_2332_2 = node.right_type; __auto_type __nl_arg_2332_3 = name; passive_graph__passive_reads(__nl_arg_2332_0, __nl_arg_2332_1, __nl_arg_2332_2, __nl_arg_2332_3); })));
    }
#line 13 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    if ((((kind) == (nl_ParseNodeType_PNODE_CALL)) || ((kind) == (nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL))))     {
#line 14 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        int64_t start = 0LL;
#line 15 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        int64_t count = 0LL;
#line 16 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        if ((kind) == (nl_ParseNodeType_PNODE_CALL))         {
#line 17 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            ASTCall call = ({ __auto_type __nl_arg_2333_0 = parser; __auto_type __nl_arg_2333_1 = id; parser__parser_get_call(__nl_arg_2333_0, __nl_arg_2333_1); });
#line 18 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            if (({ __auto_type __nl_arg_2334_0 = parser; __auto_type __nl_arg_2334_1 = call.function; __auto_type __nl_arg_2334_2 = call.function_type; __auto_type __nl_arg_2334_3 = name; passive_graph__passive_reads(__nl_arg_2334_0, __nl_arg_2334_1, __nl_arg_2334_2, __nl_arg_2334_3); }))             {
#line 18 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                return true;
            }
#line 19 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            start = call.arg_start;
#line 19 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            count = call.arg_count;
        }
        else         {
#line 21 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            ASTModuleQualifiedCall call = ({ __auto_type __nl_arg_2335_0 = parser; __auto_type __nl_arg_2335_1 = id; parser__parser_get_module_qualified_call(__nl_arg_2335_0, __nl_arg_2335_1); });
#line 22 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            start = call.arg_start;
#line 22 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            count = call.arg_count;
        }
#line 24 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        int64_t i = 0LL;
#line 25 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        while ((i) < (count))         {
#line 26 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            ASTStmtRef arg = ({ __auto_type __nl_arg_2336_0 = parser; __auto_type __nl_arg_2336_1 = ((start) + (i)); parser__parser_get_call_arg(__nl_arg_2336_0, __nl_arg_2336_1); });
#line 27 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            if (({ __auto_type __nl_arg_2337_0 = parser; __auto_type __nl_arg_2337_1 = arg.node_id; __auto_type __nl_arg_2337_2 = arg.node_type; __auto_type __nl_arg_2337_3 = name; passive_graph__passive_reads(__nl_arg_2337_0, __nl_arg_2337_1, __nl_arg_2337_2, __nl_arg_2337_3); }))             {
#line 27 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                return true;
            }
#line 28 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            i = ((i) + (1LL));
        }
    }
#line 31 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    return false;
}

DynArray* passive_graph__passive_order(Parser parser, ASTBlock block) {
#line 42 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    int64_t count = ({ __auto_type __nl_arg_2338_0 = block.statements; if (!__nl_arg_2338_0) nl_record_list_fail(); nl_list_ASTStmtRef_length(__nl_arg_2338_0); });
#line 43 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    DynArray* names = dyn_array_new(ELEM_STRING);
#line 44 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    DynArray* done = dyn_array_new(ELEM_BOOL);
#line 45 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    DynArray* order = dynarray_literal_int(0);
#line 46 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    int64_t i = 0LL;
#line 47 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    while ((i) < (count))     {
#line 48 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        ASTStmtRef stmt = ({ __auto_type __nl_arg_2339_0 = block.statements; __auto_type __nl_arg_2339_1 = i; if (!__nl_arg_2339_0) nl_record_list_fail(); __nl_arg_2339_1 = nl_native_list_index(__nl_arg_2339_1, nl_list_ASTStmtRef_length(__nl_arg_2339_0), false); nl_list_ASTStmtRef_get(__nl_arg_2339_0, __nl_arg_2339_1); });
#line 49 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        if ((stmt.node_type) != (nl_ParseNodeType_PNODE_LET))         {
#line 49 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            return dynarray_literal_int(0);
        }
#line 50 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        ASTLet binding = ({ __auto_type __nl_arg_2340_0 = parser; __auto_type __nl_arg_2340_1 = stmt.node_id; parser__parser_get_let(__nl_arg_2340_0, __nl_arg_2340_1); });
#line 51 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        if (((binding.is_mut) || (binding.is_destructure)))         {
#line 51 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            return dynarray_literal_int(0);
        }
#line 52 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        int64_t j = 0LL;
#line 53 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        while ((j) < (i))         {
#line 54 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            if ((strcmp(nl_array_at_string(names, j), binding.name) == 0))             {
#line 54 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                return dynarray_literal_int(0);
            }
#line 55 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            j = ((j) + (1LL));
        }
#line 57 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        names = ({ __auto_type __nl_arg_2341_0 = names; __auto_type __nl_arg_2341_1 = binding.name; dyn_array_push_string(__nl_arg_2341_0, __nl_arg_2341_1); });
#line 58 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        done = ({ __auto_type __nl_arg_2342_0 = done; __auto_type __nl_arg_2342_1 = false; dyn_array_push_bool(__nl_arg_2342_0, __nl_arg_2342_1); });
#line 59 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        i = ((i) + (1LL));
    }
#line 61 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    if ((!block.is_flow))     {
#line 62 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        i = 0LL;
#line 63 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        while ((i) < (count))         {
#line 63 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            order = ({ __auto_type __nl_arg_2343_0 = order; __auto_type __nl_arg_2343_1 = i; dyn_array_push_int(__nl_arg_2343_0, __nl_arg_2343_1); });
#line 63 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            i = ((i) + (1LL));
        }
#line 64 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        return order;
    }
#line 66 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    int64_t step = 0LL;
#line 67 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    while ((step) < (count))     {
#line 68 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        int64_t next = -1LL;
#line 69 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        i = 0LL;
#line 70 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        while ((((i) < (count)) && ((next) < (0LL))))         {
#line 71 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            if ((!nl_array_at_bool(done, i)))             {
#line 72 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                ASTLet binding = ({ __auto_type __nl_arg_2344_0 = parser; __auto_type __nl_arg_2344_1 = ({ __auto_type __nl_arg_2345_0 = block.statements; __auto_type __nl_arg_2345_1 = i; if (!__nl_arg_2345_0) nl_record_list_fail(); __nl_arg_2345_1 = nl_native_list_index(__nl_arg_2345_1, nl_list_ASTStmtRef_length(__nl_arg_2345_0), false); nl_list_ASTStmtRef_get(__nl_arg_2345_0, __nl_arg_2345_1); }).node_id; parser__parser_get_let(__nl_arg_2344_0, __nl_arg_2344_1); });
#line 73 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                bool ready = true;
#line 74 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                int64_t j = 0LL;
#line 75 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                while ((j) < (count))                 {
#line 76 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                    if (({ __auto_type __nl_arg_2346_0 = parser; __auto_type __nl_arg_2346_1 = binding.value; __auto_type __nl_arg_2346_2 = binding.value_type; __auto_type __nl_arg_2346_3 = nl_array_at_string(names, j); passive_graph__passive_reads(__nl_arg_2346_0, __nl_arg_2346_1, __nl_arg_2346_2, __nl_arg_2346_3); }))                     {
#line 77 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                        if ((!nl_array_at_bool(done, j)))                         {
#line 77 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                            ready = false;
                        }
                    }
#line 79 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                    j = ((j) + (1LL));
                }
#line 81 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                if (ready)                 {
#line 81 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
                    next = i;
                }
            }
#line 83 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            i = ((i) + (1LL));
        }
#line 85 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        if ((next) < (0LL))         {
#line 85 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
            return dynarray_literal_int(0);
        }
#line 86 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        order = ({ __auto_type __nl_arg_2347_0 = order; __auto_type __nl_arg_2347_1 = next; dyn_array_push_int(__nl_arg_2347_0, __nl_arg_2347_1); });
#line 87 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        nl_array_set_bool(done, next, true);
#line 88 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
        step = ((step) + (1LL));
    }
#line 90 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/passive_graph.nano"
    return order;
}


#pragma GCC diagnostic pop
/* Module metadata - automatically generated */
#include "nanolang.h"

static TypeInfo _type_infos[80];
static Function _module_functions[580];
static Parameter _module_params[859];

static void _init_module_metadata(void) __attribute__((constructor));
static void _init_module_metadata(void) {
    _type_infos[0].base_type = 7;
    _type_infos[0].element_type = &_type_infos[40];
    _type_infos[0].generic_name = NULL;
    _type_infos[0].tuple_types = NULL;
    _type_infos[0].tuple_type_names = NULL;
    _type_infos[0].tuple_element_count = 0;
    _type_infos[0].opaque_type_name = NULL;
    _type_infos[0].row_var_name = NULL;
    _type_infos[0].row_field_count = 0;
    _type_infos[0].is_open_row = false;
    _type_infos[0].type_var_count = 0;
    _type_infos[1].base_type = 7;
    _type_infos[1].element_type = &_type_infos[41];
    _type_infos[1].generic_name = NULL;
    _type_infos[1].tuple_types = NULL;
    _type_infos[1].tuple_type_names = NULL;
    _type_infos[1].tuple_element_count = 0;
    _type_infos[1].opaque_type_name = NULL;
    _type_infos[1].row_var_name = NULL;
    _type_infos[1].row_field_count = 0;
    _type_infos[1].is_open_row = false;
    _type_infos[1].type_var_count = 0;
    _type_infos[2].base_type = 7;
    _type_infos[2].element_type = &_type_infos[42];
    _type_infos[2].generic_name = NULL;
    _type_infos[2].tuple_types = NULL;
    _type_infos[2].tuple_type_names = NULL;
    _type_infos[2].tuple_element_count = 0;
    _type_infos[2].opaque_type_name = NULL;
    _type_infos[2].row_var_name = NULL;
    _type_infos[2].row_field_count = 0;
    _type_infos[2].is_open_row = false;
    _type_infos[2].type_var_count = 0;
    _type_infos[3].base_type = 7;
    _type_infos[3].element_type = &_type_infos[43];
    _type_infos[3].generic_name = NULL;
    _type_infos[3].tuple_types = NULL;
    _type_infos[3].tuple_type_names = NULL;
    _type_infos[3].tuple_element_count = 0;
    _type_infos[3].opaque_type_name = NULL;
    _type_infos[3].row_var_name = NULL;
    _type_infos[3].row_field_count = 0;
    _type_infos[3].is_open_row = false;
    _type_infos[3].type_var_count = 0;
    _type_infos[4].base_type = 7;
    _type_infos[4].element_type = &_type_infos[44];
    _type_infos[4].generic_name = NULL;
    _type_infos[4].tuple_types = NULL;
    _type_infos[4].tuple_type_names = NULL;
    _type_infos[4].tuple_element_count = 0;
    _type_infos[4].opaque_type_name = NULL;
    _type_infos[4].row_var_name = NULL;
    _type_infos[4].row_field_count = 0;
    _type_infos[4].is_open_row = false;
    _type_infos[4].type_var_count = 0;
    _type_infos[5].base_type = 7;
    _type_infos[5].element_type = &_type_infos[45];
    _type_infos[5].generic_name = NULL;
    _type_infos[5].tuple_types = NULL;
    _type_infos[5].tuple_type_names = NULL;
    _type_infos[5].tuple_element_count = 0;
    _type_infos[5].opaque_type_name = NULL;
    _type_infos[5].row_var_name = NULL;
    _type_infos[5].row_field_count = 0;
    _type_infos[5].is_open_row = false;
    _type_infos[5].type_var_count = 0;
    _type_infos[6].base_type = 7;
    _type_infos[6].element_type = &_type_infos[46];
    _type_infos[6].generic_name = NULL;
    _type_infos[6].tuple_types = NULL;
    _type_infos[6].tuple_type_names = NULL;
    _type_infos[6].tuple_element_count = 0;
    _type_infos[6].opaque_type_name = NULL;
    _type_infos[6].row_var_name = NULL;
    _type_infos[6].row_field_count = 0;
    _type_infos[6].is_open_row = false;
    _type_infos[6].type_var_count = 0;
    _type_infos[7].base_type = 7;
    _type_infos[7].element_type = &_type_infos[47];
    _type_infos[7].generic_name = NULL;
    _type_infos[7].tuple_types = NULL;
    _type_infos[7].tuple_type_names = NULL;
    _type_infos[7].tuple_element_count = 0;
    _type_infos[7].opaque_type_name = NULL;
    _type_infos[7].row_var_name = NULL;
    _type_infos[7].row_field_count = 0;
    _type_infos[7].is_open_row = false;
    _type_infos[7].type_var_count = 0;
    _type_infos[8].base_type = 7;
    _type_infos[8].element_type = &_type_infos[48];
    _type_infos[8].generic_name = NULL;
    _type_infos[8].tuple_types = NULL;
    _type_infos[8].tuple_type_names = NULL;
    _type_infos[8].tuple_element_count = 0;
    _type_infos[8].opaque_type_name = NULL;
    _type_infos[8].row_var_name = NULL;
    _type_infos[8].row_field_count = 0;
    _type_infos[8].is_open_row = false;
    _type_infos[8].type_var_count = 0;
    _type_infos[9].base_type = 7;
    _type_infos[9].element_type = &_type_infos[49];
    _type_infos[9].generic_name = NULL;
    _type_infos[9].tuple_types = NULL;
    _type_infos[9].tuple_type_names = NULL;
    _type_infos[9].tuple_element_count = 0;
    _type_infos[9].opaque_type_name = NULL;
    _type_infos[9].row_var_name = NULL;
    _type_infos[9].row_field_count = 0;
    _type_infos[9].is_open_row = false;
    _type_infos[9].type_var_count = 0;
    _type_infos[10].base_type = 7;
    _type_infos[10].element_type = &_type_infos[50];
    _type_infos[10].generic_name = NULL;
    _type_infos[10].tuple_types = NULL;
    _type_infos[10].tuple_type_names = NULL;
    _type_infos[10].tuple_element_count = 0;
    _type_infos[10].opaque_type_name = NULL;
    _type_infos[10].row_var_name = NULL;
    _type_infos[10].row_field_count = 0;
    _type_infos[10].is_open_row = false;
    _type_infos[10].type_var_count = 0;
    _type_infos[11].base_type = 7;
    _type_infos[11].element_type = &_type_infos[51];
    _type_infos[11].generic_name = NULL;
    _type_infos[11].tuple_types = NULL;
    _type_infos[11].tuple_type_names = NULL;
    _type_infos[11].tuple_element_count = 0;
    _type_infos[11].opaque_type_name = NULL;
    _type_infos[11].row_var_name = NULL;
    _type_infos[11].row_field_count = 0;
    _type_infos[11].is_open_row = false;
    _type_infos[11].type_var_count = 0;
    _type_infos[12].base_type = 7;
    _type_infos[12].element_type = &_type_infos[52];
    _type_infos[12].generic_name = NULL;
    _type_infos[12].tuple_types = NULL;
    _type_infos[12].tuple_type_names = NULL;
    _type_infos[12].tuple_element_count = 0;
    _type_infos[12].opaque_type_name = NULL;
    _type_infos[12].row_var_name = NULL;
    _type_infos[12].row_field_count = 0;
    _type_infos[12].is_open_row = false;
    _type_infos[12].type_var_count = 0;
    _type_infos[13].base_type = 7;
    _type_infos[13].element_type = &_type_infos[53];
    _type_infos[13].generic_name = NULL;
    _type_infos[13].tuple_types = NULL;
    _type_infos[13].tuple_type_names = NULL;
    _type_infos[13].tuple_element_count = 0;
    _type_infos[13].opaque_type_name = NULL;
    _type_infos[13].row_var_name = NULL;
    _type_infos[13].row_field_count = 0;
    _type_infos[13].is_open_row = false;
    _type_infos[13].type_var_count = 0;
    _type_infos[14].base_type = 7;
    _type_infos[14].element_type = &_type_infos[54];
    _type_infos[14].generic_name = NULL;
    _type_infos[14].tuple_types = NULL;
    _type_infos[14].tuple_type_names = NULL;
    _type_infos[14].tuple_element_count = 0;
    _type_infos[14].opaque_type_name = NULL;
    _type_infos[14].row_var_name = NULL;
    _type_infos[14].row_field_count = 0;
    _type_infos[14].is_open_row = false;
    _type_infos[14].type_var_count = 0;
    _type_infos[15].base_type = 7;
    _type_infos[15].element_type = &_type_infos[55];
    _type_infos[15].generic_name = NULL;
    _type_infos[15].tuple_types = NULL;
    _type_infos[15].tuple_type_names = NULL;
    _type_infos[15].tuple_element_count = 0;
    _type_infos[15].opaque_type_name = NULL;
    _type_infos[15].row_var_name = NULL;
    _type_infos[15].row_field_count = 0;
    _type_infos[15].is_open_row = false;
    _type_infos[15].type_var_count = 0;
    _type_infos[16].base_type = 7;
    _type_infos[16].element_type = &_type_infos[56];
    _type_infos[16].generic_name = NULL;
    _type_infos[16].tuple_types = NULL;
    _type_infos[16].tuple_type_names = NULL;
    _type_infos[16].tuple_element_count = 0;
    _type_infos[16].opaque_type_name = NULL;
    _type_infos[16].row_var_name = NULL;
    _type_infos[16].row_field_count = 0;
    _type_infos[16].is_open_row = false;
    _type_infos[16].type_var_count = 0;
    _type_infos[17].base_type = 7;
    _type_infos[17].element_type = &_type_infos[57];
    _type_infos[17].generic_name = NULL;
    _type_infos[17].tuple_types = NULL;
    _type_infos[17].tuple_type_names = NULL;
    _type_infos[17].tuple_element_count = 0;
    _type_infos[17].opaque_type_name = NULL;
    _type_infos[17].row_var_name = NULL;
    _type_infos[17].row_field_count = 0;
    _type_infos[17].is_open_row = false;
    _type_infos[17].type_var_count = 0;
    _type_infos[18].base_type = 7;
    _type_infos[18].element_type = &_type_infos[58];
    _type_infos[18].generic_name = NULL;
    _type_infos[18].tuple_types = NULL;
    _type_infos[18].tuple_type_names = NULL;
    _type_infos[18].tuple_element_count = 0;
    _type_infos[18].opaque_type_name = NULL;
    _type_infos[18].row_var_name = NULL;
    _type_infos[18].row_field_count = 0;
    _type_infos[18].is_open_row = false;
    _type_infos[18].type_var_count = 0;
    _type_infos[19].base_type = 7;
    _type_infos[19].element_type = &_type_infos[59];
    _type_infos[19].generic_name = NULL;
    _type_infos[19].tuple_types = NULL;
    _type_infos[19].tuple_type_names = NULL;
    _type_infos[19].tuple_element_count = 0;
    _type_infos[19].opaque_type_name = NULL;
    _type_infos[19].row_var_name = NULL;
    _type_infos[19].row_field_count = 0;
    _type_infos[19].is_open_row = false;
    _type_infos[19].type_var_count = 0;
    _type_infos[20].base_type = 7;
    _type_infos[20].element_type = &_type_infos[60];
    _type_infos[20].generic_name = NULL;
    _type_infos[20].tuple_types = NULL;
    _type_infos[20].tuple_type_names = NULL;
    _type_infos[20].tuple_element_count = 0;
    _type_infos[20].opaque_type_name = NULL;
    _type_infos[20].row_var_name = NULL;
    _type_infos[20].row_field_count = 0;
    _type_infos[20].is_open_row = false;
    _type_infos[20].type_var_count = 0;
    _type_infos[21].base_type = 7;
    _type_infos[21].element_type = &_type_infos[61];
    _type_infos[21].generic_name = NULL;
    _type_infos[21].tuple_types = NULL;
    _type_infos[21].tuple_type_names = NULL;
    _type_infos[21].tuple_element_count = 0;
    _type_infos[21].opaque_type_name = NULL;
    _type_infos[21].row_var_name = NULL;
    _type_infos[21].row_field_count = 0;
    _type_infos[21].is_open_row = false;
    _type_infos[21].type_var_count = 0;
    _type_infos[22].base_type = 7;
    _type_infos[22].element_type = &_type_infos[62];
    _type_infos[22].generic_name = NULL;
    _type_infos[22].tuple_types = NULL;
    _type_infos[22].tuple_type_names = NULL;
    _type_infos[22].tuple_element_count = 0;
    _type_infos[22].opaque_type_name = NULL;
    _type_infos[22].row_var_name = NULL;
    _type_infos[22].row_field_count = 0;
    _type_infos[22].is_open_row = false;
    _type_infos[22].type_var_count = 0;
    _type_infos[23].base_type = 7;
    _type_infos[23].element_type = &_type_infos[63];
    _type_infos[23].generic_name = NULL;
    _type_infos[23].tuple_types = NULL;
    _type_infos[23].tuple_type_names = NULL;
    _type_infos[23].tuple_element_count = 0;
    _type_infos[23].opaque_type_name = NULL;
    _type_infos[23].row_var_name = NULL;
    _type_infos[23].row_field_count = 0;
    _type_infos[23].is_open_row = false;
    _type_infos[23].type_var_count = 0;
    _type_infos[24].base_type = 7;
    _type_infos[24].element_type = &_type_infos[64];
    _type_infos[24].generic_name = NULL;
    _type_infos[24].tuple_types = NULL;
    _type_infos[24].tuple_type_names = NULL;
    _type_infos[24].tuple_element_count = 0;
    _type_infos[24].opaque_type_name = NULL;
    _type_infos[24].row_var_name = NULL;
    _type_infos[24].row_field_count = 0;
    _type_infos[24].is_open_row = false;
    _type_infos[24].type_var_count = 0;
    _type_infos[25].base_type = 7;
    _type_infos[25].element_type = &_type_infos[65];
    _type_infos[25].generic_name = NULL;
    _type_infos[25].tuple_types = NULL;
    _type_infos[25].tuple_type_names = NULL;
    _type_infos[25].tuple_element_count = 0;
    _type_infos[25].opaque_type_name = NULL;
    _type_infos[25].row_var_name = NULL;
    _type_infos[25].row_field_count = 0;
    _type_infos[25].is_open_row = false;
    _type_infos[25].type_var_count = 0;
    _type_infos[26].base_type = 7;
    _type_infos[26].element_type = &_type_infos[66];
    _type_infos[26].generic_name = NULL;
    _type_infos[26].tuple_types = NULL;
    _type_infos[26].tuple_type_names = NULL;
    _type_infos[26].tuple_element_count = 0;
    _type_infos[26].opaque_type_name = NULL;
    _type_infos[26].row_var_name = NULL;
    _type_infos[26].row_field_count = 0;
    _type_infos[26].is_open_row = false;
    _type_infos[26].type_var_count = 0;
    _type_infos[27].base_type = 7;
    _type_infos[27].element_type = &_type_infos[67];
    _type_infos[27].generic_name = NULL;
    _type_infos[27].tuple_types = NULL;
    _type_infos[27].tuple_type_names = NULL;
    _type_infos[27].tuple_element_count = 0;
    _type_infos[27].opaque_type_name = NULL;
    _type_infos[27].row_var_name = NULL;
    _type_infos[27].row_field_count = 0;
    _type_infos[27].is_open_row = false;
    _type_infos[27].type_var_count = 0;
    _type_infos[28].base_type = 7;
    _type_infos[28].element_type = &_type_infos[68];
    _type_infos[28].generic_name = NULL;
    _type_infos[28].tuple_types = NULL;
    _type_infos[28].tuple_type_names = NULL;
    _type_infos[28].tuple_element_count = 0;
    _type_infos[28].opaque_type_name = NULL;
    _type_infos[28].row_var_name = NULL;
    _type_infos[28].row_field_count = 0;
    _type_infos[28].is_open_row = false;
    _type_infos[28].type_var_count = 0;
    _type_infos[29].base_type = 7;
    _type_infos[29].element_type = &_type_infos[69];
    _type_infos[29].generic_name = NULL;
    _type_infos[29].tuple_types = NULL;
    _type_infos[29].tuple_type_names = NULL;
    _type_infos[29].tuple_element_count = 0;
    _type_infos[29].opaque_type_name = NULL;
    _type_infos[29].row_var_name = NULL;
    _type_infos[29].row_field_count = 0;
    _type_infos[29].is_open_row = false;
    _type_infos[29].type_var_count = 0;
    _type_infos[30].base_type = 7;
    _type_infos[30].element_type = &_type_infos[70];
    _type_infos[30].generic_name = NULL;
    _type_infos[30].tuple_types = NULL;
    _type_infos[30].tuple_type_names = NULL;
    _type_infos[30].tuple_element_count = 0;
    _type_infos[30].opaque_type_name = NULL;
    _type_infos[30].row_var_name = NULL;
    _type_infos[30].row_field_count = 0;
    _type_infos[30].is_open_row = false;
    _type_infos[30].type_var_count = 0;
    _type_infos[31].base_type = 7;
    _type_infos[31].element_type = &_type_infos[71];
    _type_infos[31].generic_name = NULL;
    _type_infos[31].tuple_types = NULL;
    _type_infos[31].tuple_type_names = NULL;
    _type_infos[31].tuple_element_count = 0;
    _type_infos[31].opaque_type_name = NULL;
    _type_infos[31].row_var_name = NULL;
    _type_infos[31].row_field_count = 0;
    _type_infos[31].is_open_row = false;
    _type_infos[31].type_var_count = 0;
    _type_infos[32].base_type = 7;
    _type_infos[32].element_type = &_type_infos[72];
    _type_infos[32].generic_name = NULL;
    _type_infos[32].tuple_types = NULL;
    _type_infos[32].tuple_type_names = NULL;
    _type_infos[32].tuple_element_count = 0;
    _type_infos[32].opaque_type_name = NULL;
    _type_infos[32].row_var_name = NULL;
    _type_infos[32].row_field_count = 0;
    _type_infos[32].is_open_row = false;
    _type_infos[32].type_var_count = 0;
    _type_infos[33].base_type = 7;
    _type_infos[33].element_type = &_type_infos[73];
    _type_infos[33].generic_name = NULL;
    _type_infos[33].tuple_types = NULL;
    _type_infos[33].tuple_type_names = NULL;
    _type_infos[33].tuple_element_count = 0;
    _type_infos[33].opaque_type_name = NULL;
    _type_infos[33].row_var_name = NULL;
    _type_infos[33].row_field_count = 0;
    _type_infos[33].is_open_row = false;
    _type_infos[33].type_var_count = 0;
    _type_infos[34].base_type = 7;
    _type_infos[34].element_type = &_type_infos[74];
    _type_infos[34].generic_name = NULL;
    _type_infos[34].tuple_types = NULL;
    _type_infos[34].tuple_type_names = NULL;
    _type_infos[34].tuple_element_count = 0;
    _type_infos[34].opaque_type_name = NULL;
    _type_infos[34].row_var_name = NULL;
    _type_infos[34].row_field_count = 0;
    _type_infos[34].is_open_row = false;
    _type_infos[34].type_var_count = 0;
    _type_infos[35].base_type = 7;
    _type_infos[35].element_type = &_type_infos[75];
    _type_infos[35].generic_name = NULL;
    _type_infos[35].tuple_types = NULL;
    _type_infos[35].tuple_type_names = NULL;
    _type_infos[35].tuple_element_count = 0;
    _type_infos[35].opaque_type_name = NULL;
    _type_infos[35].row_var_name = NULL;
    _type_infos[35].row_field_count = 0;
    _type_infos[35].is_open_row = false;
    _type_infos[35].type_var_count = 0;
    _type_infos[36].base_type = 7;
    _type_infos[36].element_type = &_type_infos[76];
    _type_infos[36].generic_name = NULL;
    _type_infos[36].tuple_types = NULL;
    _type_infos[36].tuple_type_names = NULL;
    _type_infos[36].tuple_element_count = 0;
    _type_infos[36].opaque_type_name = NULL;
    _type_infos[36].row_var_name = NULL;
    _type_infos[36].row_field_count = 0;
    _type_infos[36].is_open_row = false;
    _type_infos[36].type_var_count = 0;
    _type_infos[37].base_type = 7;
    _type_infos[37].element_type = &_type_infos[77];
    _type_infos[37].generic_name = NULL;
    _type_infos[37].tuple_types = NULL;
    _type_infos[37].tuple_type_names = NULL;
    _type_infos[37].tuple_element_count = 0;
    _type_infos[37].opaque_type_name = NULL;
    _type_infos[37].row_var_name = NULL;
    _type_infos[37].row_field_count = 0;
    _type_infos[37].is_open_row = false;
    _type_infos[37].type_var_count = 0;
    _type_infos[38].base_type = 7;
    _type_infos[38].element_type = &_type_infos[78];
    _type_infos[38].generic_name = NULL;
    _type_infos[38].tuple_types = NULL;
    _type_infos[38].tuple_type_names = NULL;
    _type_infos[38].tuple_element_count = 0;
    _type_infos[38].opaque_type_name = NULL;
    _type_infos[38].row_var_name = NULL;
    _type_infos[38].row_field_count = 0;
    _type_infos[38].is_open_row = false;
    _type_infos[38].type_var_count = 0;
    _type_infos[39].base_type = 7;
    _type_infos[39].element_type = &_type_infos[79];
    _type_infos[39].generic_name = NULL;
    _type_infos[39].tuple_types = NULL;
    _type_infos[39].tuple_type_names = NULL;
    _type_infos[39].tuple_element_count = 0;
    _type_infos[39].opaque_type_name = NULL;
    _type_infos[39].row_var_name = NULL;
    _type_infos[39].row_field_count = 0;
    _type_infos[39].is_open_row = false;
    _type_infos[39].type_var_count = 0;
    _type_infos[40].base_type = 4;
    _type_infos[40].generic_name = NULL;
    _type_infos[40].tuple_types = NULL;
    _type_infos[40].tuple_type_names = NULL;
    _type_infos[40].tuple_element_count = 0;
    _type_infos[40].opaque_type_name = NULL;
    _type_infos[40].row_var_name = NULL;
    _type_infos[40].row_field_count = 0;
    _type_infos[40].is_open_row = false;
    _type_infos[40].type_var_count = 0;
    _type_infos[41].base_type = 4;
    _type_infos[41].generic_name = NULL;
    _type_infos[41].tuple_types = NULL;
    _type_infos[41].tuple_type_names = NULL;
    _type_infos[41].tuple_element_count = 0;
    _type_infos[41].opaque_type_name = NULL;
    _type_infos[41].row_var_name = NULL;
    _type_infos[41].row_field_count = 0;
    _type_infos[41].is_open_row = false;
    _type_infos[41].type_var_count = 0;
    _type_infos[42].base_type = 4;
    _type_infos[42].generic_name = NULL;
    _type_infos[42].tuple_types = NULL;
    _type_infos[42].tuple_type_names = NULL;
    _type_infos[42].tuple_element_count = 0;
    _type_infos[42].opaque_type_name = NULL;
    _type_infos[42].row_var_name = NULL;
    _type_infos[42].row_field_count = 0;
    _type_infos[42].is_open_row = false;
    _type_infos[42].type_var_count = 0;
    _type_infos[43].base_type = 0;
    _type_infos[43].generic_name = NULL;
    _type_infos[43].tuple_types = NULL;
    _type_infos[43].tuple_type_names = NULL;
    _type_infos[43].tuple_element_count = 0;
    _type_infos[43].opaque_type_name = NULL;
    _type_infos[43].row_var_name = NULL;
    _type_infos[43].row_field_count = 0;
    _type_infos[43].is_open_row = false;
    _type_infos[43].type_var_count = 0;
    _type_infos[44].base_type = 0;
    _type_infos[44].generic_name = NULL;
    _type_infos[44].tuple_types = NULL;
    _type_infos[44].tuple_type_names = NULL;
    _type_infos[44].tuple_element_count = 0;
    _type_infos[44].opaque_type_name = NULL;
    _type_infos[44].row_var_name = NULL;
    _type_infos[44].row_field_count = 0;
    _type_infos[44].is_open_row = false;
    _type_infos[44].type_var_count = 0;
    _type_infos[45].base_type = 4;
    _type_infos[45].generic_name = NULL;
    _type_infos[45].tuple_types = NULL;
    _type_infos[45].tuple_type_names = NULL;
    _type_infos[45].tuple_element_count = 0;
    _type_infos[45].opaque_type_name = NULL;
    _type_infos[45].row_var_name = NULL;
    _type_infos[45].row_field_count = 0;
    _type_infos[45].is_open_row = false;
    _type_infos[45].type_var_count = 0;
    _type_infos[46].base_type = 4;
    _type_infos[46].generic_name = NULL;
    _type_infos[46].tuple_types = NULL;
    _type_infos[46].tuple_type_names = NULL;
    _type_infos[46].tuple_element_count = 0;
    _type_infos[46].opaque_type_name = NULL;
    _type_infos[46].row_var_name = NULL;
    _type_infos[46].row_field_count = 0;
    _type_infos[46].is_open_row = false;
    _type_infos[46].type_var_count = 0;
    _type_infos[47].base_type = 4;
    _type_infos[47].generic_name = NULL;
    _type_infos[47].tuple_types = NULL;
    _type_infos[47].tuple_type_names = NULL;
    _type_infos[47].tuple_element_count = 0;
    _type_infos[47].opaque_type_name = NULL;
    _type_infos[47].row_var_name = NULL;
    _type_infos[47].row_field_count = 0;
    _type_infos[47].is_open_row = false;
    _type_infos[47].type_var_count = 0;
    _type_infos[48].base_type = 4;
    _type_infos[48].generic_name = NULL;
    _type_infos[48].tuple_types = NULL;
    _type_infos[48].tuple_type_names = NULL;
    _type_infos[48].tuple_element_count = 0;
    _type_infos[48].opaque_type_name = NULL;
    _type_infos[48].row_var_name = NULL;
    _type_infos[48].row_field_count = 0;
    _type_infos[48].is_open_row = false;
    _type_infos[48].type_var_count = 0;
    _type_infos[49].base_type = 4;
    _type_infos[49].generic_name = NULL;
    _type_infos[49].tuple_types = NULL;
    _type_infos[49].tuple_type_names = NULL;
    _type_infos[49].tuple_element_count = 0;
    _type_infos[49].opaque_type_name = NULL;
    _type_infos[49].row_var_name = NULL;
    _type_infos[49].row_field_count = 0;
    _type_infos[49].is_open_row = false;
    _type_infos[49].type_var_count = 0;
    _type_infos[50].base_type = 4;
    _type_infos[50].generic_name = NULL;
    _type_infos[50].tuple_types = NULL;
    _type_infos[50].tuple_type_names = NULL;
    _type_infos[50].tuple_element_count = 0;
    _type_infos[50].opaque_type_name = NULL;
    _type_infos[50].row_var_name = NULL;
    _type_infos[50].row_field_count = 0;
    _type_infos[50].is_open_row = false;
    _type_infos[50].type_var_count = 0;
    _type_infos[51].base_type = 0;
    _type_infos[51].generic_name = NULL;
    _type_infos[51].tuple_types = NULL;
    _type_infos[51].tuple_type_names = NULL;
    _type_infos[51].tuple_element_count = 0;
    _type_infos[51].opaque_type_name = NULL;
    _type_infos[51].row_var_name = NULL;
    _type_infos[51].row_field_count = 0;
    _type_infos[51].is_open_row = false;
    _type_infos[51].type_var_count = 0;
    _type_infos[52].base_type = 4;
    _type_infos[52].generic_name = NULL;
    _type_infos[52].tuple_types = NULL;
    _type_infos[52].tuple_type_names = NULL;
    _type_infos[52].tuple_element_count = 0;
    _type_infos[52].opaque_type_name = NULL;
    _type_infos[52].row_var_name = NULL;
    _type_infos[52].row_field_count = 0;
    _type_infos[52].is_open_row = false;
    _type_infos[52].type_var_count = 0;
    _type_infos[53].base_type = 0;
    _type_infos[53].generic_name = NULL;
    _type_infos[53].tuple_types = NULL;
    _type_infos[53].tuple_type_names = NULL;
    _type_infos[53].tuple_element_count = 0;
    _type_infos[53].opaque_type_name = NULL;
    _type_infos[53].row_var_name = NULL;
    _type_infos[53].row_field_count = 0;
    _type_infos[53].is_open_row = false;
    _type_infos[53].type_var_count = 0;
    _type_infos[54].base_type = 4;
    _type_infos[54].generic_name = NULL;
    _type_infos[54].tuple_types = NULL;
    _type_infos[54].tuple_type_names = NULL;
    _type_infos[54].tuple_element_count = 0;
    _type_infos[54].opaque_type_name = NULL;
    _type_infos[54].row_var_name = NULL;
    _type_infos[54].row_field_count = 0;
    _type_infos[54].is_open_row = false;
    _type_infos[54].type_var_count = 0;
    _type_infos[55].base_type = 4;
    _type_infos[55].generic_name = NULL;
    _type_infos[55].tuple_types = NULL;
    _type_infos[55].tuple_type_names = NULL;
    _type_infos[55].tuple_element_count = 0;
    _type_infos[55].opaque_type_name = NULL;
    _type_infos[55].row_var_name = NULL;
    _type_infos[55].row_field_count = 0;
    _type_infos[55].is_open_row = false;
    _type_infos[55].type_var_count = 0;
    _type_infos[56].base_type = 4;
    _type_infos[56].generic_name = NULL;
    _type_infos[56].tuple_types = NULL;
    _type_infos[56].tuple_type_names = NULL;
    _type_infos[56].tuple_element_count = 0;
    _type_infos[56].opaque_type_name = NULL;
    _type_infos[56].row_var_name = NULL;
    _type_infos[56].row_field_count = 0;
    _type_infos[56].is_open_row = false;
    _type_infos[56].type_var_count = 0;
    _type_infos[57].base_type = 4;
    _type_infos[57].generic_name = NULL;
    _type_infos[57].tuple_types = NULL;
    _type_infos[57].tuple_type_names = NULL;
    _type_infos[57].tuple_element_count = 0;
    _type_infos[57].opaque_type_name = NULL;
    _type_infos[57].row_var_name = NULL;
    _type_infos[57].row_field_count = 0;
    _type_infos[57].is_open_row = false;
    _type_infos[57].type_var_count = 0;
    _type_infos[58].base_type = 0;
    _type_infos[58].generic_name = NULL;
    _type_infos[58].tuple_types = NULL;
    _type_infos[58].tuple_type_names = NULL;
    _type_infos[58].tuple_element_count = 0;
    _type_infos[58].opaque_type_name = NULL;
    _type_infos[58].row_var_name = NULL;
    _type_infos[58].row_field_count = 0;
    _type_infos[58].is_open_row = false;
    _type_infos[58].type_var_count = 0;
    _type_infos[59].base_type = 0;
    _type_infos[59].generic_name = NULL;
    _type_infos[59].tuple_types = NULL;
    _type_infos[59].tuple_type_names = NULL;
    _type_infos[59].tuple_element_count = 0;
    _type_infos[59].opaque_type_name = NULL;
    _type_infos[59].row_var_name = NULL;
    _type_infos[59].row_field_count = 0;
    _type_infos[59].is_open_row = false;
    _type_infos[59].type_var_count = 0;
    _type_infos[60].base_type = 4;
    _type_infos[60].generic_name = NULL;
    _type_infos[60].tuple_types = NULL;
    _type_infos[60].tuple_type_names = NULL;
    _type_infos[60].tuple_element_count = 0;
    _type_infos[60].opaque_type_name = NULL;
    _type_infos[60].row_var_name = NULL;
    _type_infos[60].row_field_count = 0;
    _type_infos[60].is_open_row = false;
    _type_infos[60].type_var_count = 0;
    _type_infos[61].base_type = 0;
    _type_infos[61].generic_name = NULL;
    _type_infos[61].tuple_types = NULL;
    _type_infos[61].tuple_type_names = NULL;
    _type_infos[61].tuple_element_count = 0;
    _type_infos[61].opaque_type_name = NULL;
    _type_infos[61].row_var_name = NULL;
    _type_infos[61].row_field_count = 0;
    _type_infos[61].is_open_row = false;
    _type_infos[61].type_var_count = 0;
    _type_infos[62].base_type = 0;
    _type_infos[62].generic_name = NULL;
    _type_infos[62].tuple_types = NULL;
    _type_infos[62].tuple_type_names = NULL;
    _type_infos[62].tuple_element_count = 0;
    _type_infos[62].opaque_type_name = NULL;
    _type_infos[62].row_var_name = NULL;
    _type_infos[62].row_field_count = 0;
    _type_infos[62].is_open_row = false;
    _type_infos[62].type_var_count = 0;
    _type_infos[63].base_type = 4;
    _type_infos[63].generic_name = NULL;
    _type_infos[63].tuple_types = NULL;
    _type_infos[63].tuple_type_names = NULL;
    _type_infos[63].tuple_element_count = 0;
    _type_infos[63].opaque_type_name = NULL;
    _type_infos[63].row_var_name = NULL;
    _type_infos[63].row_field_count = 0;
    _type_infos[63].is_open_row = false;
    _type_infos[63].type_var_count = 0;
    _type_infos[64].base_type = 4;
    _type_infos[64].generic_name = NULL;
    _type_infos[64].tuple_types = NULL;
    _type_infos[64].tuple_type_names = NULL;
    _type_infos[64].tuple_element_count = 0;
    _type_infos[64].opaque_type_name = NULL;
    _type_infos[64].row_var_name = NULL;
    _type_infos[64].row_field_count = 0;
    _type_infos[64].is_open_row = false;
    _type_infos[64].type_var_count = 0;
    _type_infos[65].base_type = 0;
    _type_infos[65].generic_name = NULL;
    _type_infos[65].tuple_types = NULL;
    _type_infos[65].tuple_type_names = NULL;
    _type_infos[65].tuple_element_count = 0;
    _type_infos[65].opaque_type_name = NULL;
    _type_infos[65].row_var_name = NULL;
    _type_infos[65].row_field_count = 0;
    _type_infos[65].is_open_row = false;
    _type_infos[65].type_var_count = 0;
    _type_infos[66].base_type = 0;
    _type_infos[66].generic_name = NULL;
    _type_infos[66].tuple_types = NULL;
    _type_infos[66].tuple_type_names = NULL;
    _type_infos[66].tuple_element_count = 0;
    _type_infos[66].opaque_type_name = NULL;
    _type_infos[66].row_var_name = NULL;
    _type_infos[66].row_field_count = 0;
    _type_infos[66].is_open_row = false;
    _type_infos[66].type_var_count = 0;
    _type_infos[67].base_type = 0;
    _type_infos[67].generic_name = NULL;
    _type_infos[67].tuple_types = NULL;
    _type_infos[67].tuple_type_names = NULL;
    _type_infos[67].tuple_element_count = 0;
    _type_infos[67].opaque_type_name = NULL;
    _type_infos[67].row_var_name = NULL;
    _type_infos[67].row_field_count = 0;
    _type_infos[67].is_open_row = false;
    _type_infos[67].type_var_count = 0;
    _type_infos[68].base_type = 0;
    _type_infos[68].generic_name = NULL;
    _type_infos[68].tuple_types = NULL;
    _type_infos[68].tuple_type_names = NULL;
    _type_infos[68].tuple_element_count = 0;
    _type_infos[68].opaque_type_name = NULL;
    _type_infos[68].row_var_name = NULL;
    _type_infos[68].row_field_count = 0;
    _type_infos[68].is_open_row = false;
    _type_infos[68].type_var_count = 0;
    _type_infos[69].base_type = 0;
    _type_infos[69].generic_name = NULL;
    _type_infos[69].tuple_types = NULL;
    _type_infos[69].tuple_type_names = NULL;
    _type_infos[69].tuple_element_count = 0;
    _type_infos[69].opaque_type_name = NULL;
    _type_infos[69].row_var_name = NULL;
    _type_infos[69].row_field_count = 0;
    _type_infos[69].is_open_row = false;
    _type_infos[69].type_var_count = 0;
    _type_infos[70].base_type = 0;
    _type_infos[70].generic_name = NULL;
    _type_infos[70].tuple_types = NULL;
    _type_infos[70].tuple_type_names = NULL;
    _type_infos[70].tuple_element_count = 0;
    _type_infos[70].opaque_type_name = NULL;
    _type_infos[70].row_var_name = NULL;
    _type_infos[70].row_field_count = 0;
    _type_infos[70].is_open_row = false;
    _type_infos[70].type_var_count = 0;
    _type_infos[71].base_type = 4;
    _type_infos[71].generic_name = NULL;
    _type_infos[71].tuple_types = NULL;
    _type_infos[71].tuple_type_names = NULL;
    _type_infos[71].tuple_element_count = 0;
    _type_infos[71].opaque_type_name = NULL;
    _type_infos[71].row_var_name = NULL;
    _type_infos[71].row_field_count = 0;
    _type_infos[71].is_open_row = false;
    _type_infos[71].type_var_count = 0;
    _type_infos[72].base_type = 0;
    _type_infos[72].generic_name = NULL;
    _type_infos[72].tuple_types = NULL;
    _type_infos[72].tuple_type_names = NULL;
    _type_infos[72].tuple_element_count = 0;
    _type_infos[72].opaque_type_name = NULL;
    _type_infos[72].row_var_name = NULL;
    _type_infos[72].row_field_count = 0;
    _type_infos[72].is_open_row = false;
    _type_infos[72].type_var_count = 0;
    _type_infos[73].base_type = 4;
    _type_infos[73].generic_name = NULL;
    _type_infos[73].tuple_types = NULL;
    _type_infos[73].tuple_type_names = NULL;
    _type_infos[73].tuple_element_count = 0;
    _type_infos[73].opaque_type_name = NULL;
    _type_infos[73].row_var_name = NULL;
    _type_infos[73].row_field_count = 0;
    _type_infos[73].is_open_row = false;
    _type_infos[73].type_var_count = 0;
    _type_infos[74].base_type = 0;
    _type_infos[74].generic_name = NULL;
    _type_infos[74].tuple_types = NULL;
    _type_infos[74].tuple_type_names = NULL;
    _type_infos[74].tuple_element_count = 0;
    _type_infos[74].opaque_type_name = NULL;
    _type_infos[74].row_var_name = NULL;
    _type_infos[74].row_field_count = 0;
    _type_infos[74].is_open_row = false;
    _type_infos[74].type_var_count = 0;
    _type_infos[75].base_type = 4;
    _type_infos[75].generic_name = NULL;
    _type_infos[75].tuple_types = NULL;
    _type_infos[75].tuple_type_names = NULL;
    _type_infos[75].tuple_element_count = 0;
    _type_infos[75].opaque_type_name = NULL;
    _type_infos[75].row_var_name = NULL;
    _type_infos[75].row_field_count = 0;
    _type_infos[75].is_open_row = false;
    _type_infos[75].type_var_count = 0;
    _type_infos[76].base_type = 4;
    _type_infos[76].generic_name = NULL;
    _type_infos[76].tuple_types = NULL;
    _type_infos[76].tuple_type_names = NULL;
    _type_infos[76].tuple_element_count = 0;
    _type_infos[76].opaque_type_name = NULL;
    _type_infos[76].row_var_name = NULL;
    _type_infos[76].row_field_count = 0;
    _type_infos[76].is_open_row = false;
    _type_infos[76].type_var_count = 0;
    _type_infos[77].base_type = 4;
    _type_infos[77].generic_name = NULL;
    _type_infos[77].tuple_types = NULL;
    _type_infos[77].tuple_type_names = NULL;
    _type_infos[77].tuple_element_count = 0;
    _type_infos[77].opaque_type_name = NULL;
    _type_infos[77].row_var_name = NULL;
    _type_infos[77].row_field_count = 0;
    _type_infos[77].is_open_row = false;
    _type_infos[77].type_var_count = 0;
    _type_infos[78].base_type = 0;
    _type_infos[78].generic_name = NULL;
    _type_infos[78].tuple_types = NULL;
    _type_infos[78].tuple_type_names = NULL;
    _type_infos[78].tuple_element_count = 0;
    _type_infos[78].opaque_type_name = NULL;
    _type_infos[78].row_var_name = NULL;
    _type_infos[78].row_field_count = 0;
    _type_infos[78].is_open_row = false;
    _type_infos[78].type_var_count = 0;
    _type_infos[79].base_type = 0;
    _type_infos[79].generic_name = NULL;
    _type_infos[79].tuple_types = NULL;
    _type_infos[79].tuple_type_names = NULL;
    _type_infos[79].tuple_element_count = 0;
    _type_infos[79].opaque_type_name = NULL;
    _type_infos[79].row_var_name = NULL;
    _type_infos[79].row_field_count = 0;
    _type_infos[79].is_open_row = false;
    _type_infos[79].type_var_count = 0;
    /* Function: range */
    _module_functions[0].name = "range";
    _module_functions[0].param_count = 0;
    _module_functions[0].return_type = 6;
    _module_functions[0].return_struct_type_name = NULL;
    _module_functions[0].return_fn_sig = NULL;
    _module_functions[0].return_type_info = NULL;
    _module_functions[0].body = NULL;
    _module_functions[0].shadow_test = NULL;
    _module_functions[0].is_extern = false;
    _module_functions[0].returns_gc_managed = false;
    _module_functions[0].requires_manual_free = false;
    _module_functions[0].returns_borrowed = false;
    _module_functions[0].cleanup_function = NULL;
    _module_functions[0].params = NULL;

    /* Function: abs */
    _module_functions[1].name = "abs";
    _module_functions[1].param_count = 0;
    _module_functions[1].return_type = 0;
    _module_functions[1].return_struct_type_name = NULL;
    _module_functions[1].return_fn_sig = NULL;
    _module_functions[1].return_type_info = NULL;
    _module_functions[1].body = NULL;
    _module_functions[1].shadow_test = NULL;
    _module_functions[1].is_extern = false;
    _module_functions[1].returns_gc_managed = false;
    _module_functions[1].requires_manual_free = false;
    _module_functions[1].returns_borrowed = false;
    _module_functions[1].cleanup_function = NULL;
    _module_functions[1].params = NULL;

    /* Function: min */
    _module_functions[2].name = "min";
    _module_functions[2].param_count = 0;
    _module_functions[2].return_type = 0;
    _module_functions[2].return_struct_type_name = NULL;
    _module_functions[2].return_fn_sig = NULL;
    _module_functions[2].return_type_info = NULL;
    _module_functions[2].body = NULL;
    _module_functions[2].shadow_test = NULL;
    _module_functions[2].is_extern = false;
    _module_functions[2].returns_gc_managed = false;
    _module_functions[2].requires_manual_free = false;
    _module_functions[2].returns_borrowed = false;
    _module_functions[2].cleanup_function = NULL;
    _module_functions[2].params = NULL;

    /* Function: max */
    _module_functions[3].name = "max";
    _module_functions[3].param_count = 0;
    _module_functions[3].return_type = 0;
    _module_functions[3].return_struct_type_name = NULL;
    _module_functions[3].return_fn_sig = NULL;
    _module_functions[3].return_type_info = NULL;
    _module_functions[3].body = NULL;
    _module_functions[3].shadow_test = NULL;
    _module_functions[3].is_extern = false;
    _module_functions[3].returns_gc_managed = false;
    _module_functions[3].requires_manual_free = false;
    _module_functions[3].returns_borrowed = false;
    _module_functions[3].cleanup_function = NULL;
    _module_functions[3].params = NULL;

    /* Function: print */
    _module_functions[4].name = "print";
    _module_functions[4].param_count = 0;
    _module_functions[4].return_type = 6;
    _module_functions[4].return_struct_type_name = NULL;
    _module_functions[4].return_fn_sig = NULL;
    _module_functions[4].return_type_info = NULL;
    _module_functions[4].body = NULL;
    _module_functions[4].shadow_test = NULL;
    _module_functions[4].is_extern = false;
    _module_functions[4].returns_gc_managed = false;
    _module_functions[4].requires_manual_free = false;
    _module_functions[4].returns_borrowed = false;
    _module_functions[4].cleanup_function = NULL;
    _module_functions[4].params = NULL;

    /* Function: println */
    _module_functions[5].name = "println";
    _module_functions[5].param_count = 0;
    _module_functions[5].return_type = 6;
    _module_functions[5].return_struct_type_name = NULL;
    _module_functions[5].return_fn_sig = NULL;
    _module_functions[5].return_type_info = NULL;
    _module_functions[5].body = NULL;
    _module_functions[5].shadow_test = NULL;
    _module_functions[5].is_extern = false;
    _module_functions[5].returns_gc_managed = false;
    _module_functions[5].requires_manual_free = false;
    _module_functions[5].returns_borrowed = false;
    _module_functions[5].cleanup_function = NULL;
    _module_functions[5].params = NULL;

    /* Function: sqrt */
    _module_functions[6].name = "sqrt";
    _module_functions[6].param_count = 0;
    _module_functions[6].return_type = 2;
    _module_functions[6].return_struct_type_name = NULL;
    _module_functions[6].return_fn_sig = NULL;
    _module_functions[6].return_type_info = NULL;
    _module_functions[6].body = NULL;
    _module_functions[6].shadow_test = NULL;
    _module_functions[6].is_extern = false;
    _module_functions[6].returns_gc_managed = false;
    _module_functions[6].requires_manual_free = false;
    _module_functions[6].returns_borrowed = false;
    _module_functions[6].cleanup_function = NULL;
    _module_functions[6].params = NULL;

    /* Function: pow */
    _module_functions[7].name = "pow";
    _module_functions[7].param_count = 0;
    _module_functions[7].return_type = 2;
    _module_functions[7].return_struct_type_name = NULL;
    _module_functions[7].return_fn_sig = NULL;
    _module_functions[7].return_type_info = NULL;
    _module_functions[7].body = NULL;
    _module_functions[7].shadow_test = NULL;
    _module_functions[7].is_extern = false;
    _module_functions[7].returns_gc_managed = false;
    _module_functions[7].requires_manual_free = false;
    _module_functions[7].returns_borrowed = false;
    _module_functions[7].cleanup_function = NULL;
    _module_functions[7].params = NULL;

    /* Function: floor */
    _module_functions[8].name = "floor";
    _module_functions[8].param_count = 0;
    _module_functions[8].return_type = 2;
    _module_functions[8].return_struct_type_name = NULL;
    _module_functions[8].return_fn_sig = NULL;
    _module_functions[8].return_type_info = NULL;
    _module_functions[8].body = NULL;
    _module_functions[8].shadow_test = NULL;
    _module_functions[8].is_extern = false;
    _module_functions[8].returns_gc_managed = false;
    _module_functions[8].requires_manual_free = false;
    _module_functions[8].returns_borrowed = false;
    _module_functions[8].cleanup_function = NULL;
    _module_functions[8].params = NULL;

    /* Function: ceil */
    _module_functions[9].name = "ceil";
    _module_functions[9].param_count = 0;
    _module_functions[9].return_type = 2;
    _module_functions[9].return_struct_type_name = NULL;
    _module_functions[9].return_fn_sig = NULL;
    _module_functions[9].return_type_info = NULL;
    _module_functions[9].body = NULL;
    _module_functions[9].shadow_test = NULL;
    _module_functions[9].is_extern = false;
    _module_functions[9].returns_gc_managed = false;
    _module_functions[9].requires_manual_free = false;
    _module_functions[9].returns_borrowed = false;
    _module_functions[9].cleanup_function = NULL;
    _module_functions[9].params = NULL;

    /* Function: round */
    _module_functions[10].name = "round";
    _module_functions[10].param_count = 0;
    _module_functions[10].return_type = 2;
    _module_functions[10].return_struct_type_name = NULL;
    _module_functions[10].return_fn_sig = NULL;
    _module_functions[10].return_type_info = NULL;
    _module_functions[10].body = NULL;
    _module_functions[10].shadow_test = NULL;
    _module_functions[10].is_extern = false;
    _module_functions[10].returns_gc_managed = false;
    _module_functions[10].requires_manual_free = false;
    _module_functions[10].returns_borrowed = false;
    _module_functions[10].cleanup_function = NULL;
    _module_functions[10].params = NULL;

    /* Function: sin */
    _module_functions[11].name = "sin";
    _module_functions[11].param_count = 0;
    _module_functions[11].return_type = 2;
    _module_functions[11].return_struct_type_name = NULL;
    _module_functions[11].return_fn_sig = NULL;
    _module_functions[11].return_type_info = NULL;
    _module_functions[11].body = NULL;
    _module_functions[11].shadow_test = NULL;
    _module_functions[11].is_extern = false;
    _module_functions[11].returns_gc_managed = false;
    _module_functions[11].requires_manual_free = false;
    _module_functions[11].returns_borrowed = false;
    _module_functions[11].cleanup_function = NULL;
    _module_functions[11].params = NULL;

    /* Function: cos */
    _module_functions[12].name = "cos";
    _module_functions[12].param_count = 0;
    _module_functions[12].return_type = 2;
    _module_functions[12].return_struct_type_name = NULL;
    _module_functions[12].return_fn_sig = NULL;
    _module_functions[12].return_type_info = NULL;
    _module_functions[12].body = NULL;
    _module_functions[12].shadow_test = NULL;
    _module_functions[12].is_extern = false;
    _module_functions[12].returns_gc_managed = false;
    _module_functions[12].requires_manual_free = false;
    _module_functions[12].returns_borrowed = false;
    _module_functions[12].cleanup_function = NULL;
    _module_functions[12].params = NULL;

    /* Function: tan */
    _module_functions[13].name = "tan";
    _module_functions[13].param_count = 0;
    _module_functions[13].return_type = 2;
    _module_functions[13].return_struct_type_name = NULL;
    _module_functions[13].return_fn_sig = NULL;
    _module_functions[13].return_type_info = NULL;
    _module_functions[13].body = NULL;
    _module_functions[13].shadow_test = NULL;
    _module_functions[13].is_extern = false;
    _module_functions[13].returns_gc_managed = false;
    _module_functions[13].requires_manual_free = false;
    _module_functions[13].returns_borrowed = false;
    _module_functions[13].cleanup_function = NULL;
    _module_functions[13].params = NULL;

    /* Function: str_length */
    _module_functions[14].name = "str_length";
    _module_functions[14].param_count = 0;
    _module_functions[14].return_type = 0;
    _module_functions[14].return_struct_type_name = NULL;
    _module_functions[14].return_fn_sig = NULL;
    _module_functions[14].return_type_info = NULL;
    _module_functions[14].body = NULL;
    _module_functions[14].shadow_test = NULL;
    _module_functions[14].is_extern = false;
    _module_functions[14].returns_gc_managed = false;
    _module_functions[14].requires_manual_free = false;
    _module_functions[14].returns_borrowed = false;
    _module_functions[14].cleanup_function = NULL;
    _module_functions[14].params = NULL;

    /* Function: str_concat */
    _module_functions[15].name = "str_concat";
    _module_functions[15].param_count = 0;
    _module_functions[15].return_type = 4;
    _module_functions[15].return_struct_type_name = NULL;
    _module_functions[15].return_fn_sig = NULL;
    _module_functions[15].return_type_info = NULL;
    _module_functions[15].body = NULL;
    _module_functions[15].shadow_test = NULL;
    _module_functions[15].is_extern = false;
    _module_functions[15].returns_gc_managed = true;
    _module_functions[15].requires_manual_free = false;
    _module_functions[15].returns_borrowed = false;
    _module_functions[15].cleanup_function = NULL;
    _module_functions[15].params = NULL;

    /* Function: str_substring */
    _module_functions[16].name = "str_substring";
    _module_functions[16].param_count = 0;
    _module_functions[16].return_type = 4;
    _module_functions[16].return_struct_type_name = NULL;
    _module_functions[16].return_fn_sig = NULL;
    _module_functions[16].return_type_info = NULL;
    _module_functions[16].body = NULL;
    _module_functions[16].shadow_test = NULL;
    _module_functions[16].is_extern = false;
    _module_functions[16].returns_gc_managed = true;
    _module_functions[16].requires_manual_free = false;
    _module_functions[16].returns_borrowed = false;
    _module_functions[16].cleanup_function = NULL;
    _module_functions[16].params = NULL;

    /* Function: str_contains */
    _module_functions[17].name = "str_contains";
    _module_functions[17].param_count = 0;
    _module_functions[17].return_type = 3;
    _module_functions[17].return_struct_type_name = NULL;
    _module_functions[17].return_fn_sig = NULL;
    _module_functions[17].return_type_info = NULL;
    _module_functions[17].body = NULL;
    _module_functions[17].shadow_test = NULL;
    _module_functions[17].is_extern = false;
    _module_functions[17].returns_gc_managed = false;
    _module_functions[17].requires_manual_free = false;
    _module_functions[17].returns_borrowed = false;
    _module_functions[17].cleanup_function = NULL;
    _module_functions[17].params = NULL;

    /* Function: str_equals */
    _module_functions[18].name = "str_equals";
    _module_functions[18].param_count = 0;
    _module_functions[18].return_type = 3;
    _module_functions[18].return_struct_type_name = NULL;
    _module_functions[18].return_fn_sig = NULL;
    _module_functions[18].return_type_info = NULL;
    _module_functions[18].body = NULL;
    _module_functions[18].shadow_test = NULL;
    _module_functions[18].is_extern = false;
    _module_functions[18].returns_gc_managed = false;
    _module_functions[18].requires_manual_free = false;
    _module_functions[18].returns_borrowed = false;
    _module_functions[18].cleanup_function = NULL;
    _module_functions[18].params = NULL;

    /* Function: format */
    _module_functions[19].name = "format";
    _module_functions[19].param_count = 0;
    _module_functions[19].return_type = 4;
    _module_functions[19].return_struct_type_name = NULL;
    _module_functions[19].return_fn_sig = NULL;
    _module_functions[19].return_type_info = NULL;
    _module_functions[19].body = NULL;
    _module_functions[19].shadow_test = NULL;
    _module_functions[19].is_extern = false;
    _module_functions[19].returns_gc_managed = true;
    _module_functions[19].requires_manual_free = false;
    _module_functions[19].returns_borrowed = false;
    _module_functions[19].cleanup_function = NULL;
    _module_functions[19].params = NULL;

    /* Function: at */
    _module_functions[20].name = "at";
    _module_functions[20].param_count = 0;
    _module_functions[20].return_type = 21;
    _module_functions[20].return_struct_type_name = NULL;
    _module_functions[20].return_fn_sig = NULL;
    _module_functions[20].return_type_info = NULL;
    _module_functions[20].body = NULL;
    _module_functions[20].shadow_test = NULL;
    _module_functions[20].is_extern = false;
    _module_functions[20].returns_gc_managed = false;
    _module_functions[20].requires_manual_free = false;
    _module_functions[20].returns_borrowed = false;
    _module_functions[20].cleanup_function = NULL;
    _module_functions[20].params = NULL;

    /* Function: array_length */
    _module_functions[21].name = "array_length";
    _module_functions[21].param_count = 0;
    _module_functions[21].return_type = 0;
    _module_functions[21].return_struct_type_name = NULL;
    _module_functions[21].return_fn_sig = NULL;
    _module_functions[21].return_type_info = NULL;
    _module_functions[21].body = NULL;
    _module_functions[21].shadow_test = NULL;
    _module_functions[21].is_extern = false;
    _module_functions[21].returns_gc_managed = false;
    _module_functions[21].requires_manual_free = false;
    _module_functions[21].returns_borrowed = false;
    _module_functions[21].cleanup_function = NULL;
    _module_functions[21].params = NULL;

    /* Function: array_new */
    _module_functions[22].name = "array_new";
    _module_functions[22].param_count = 0;
    _module_functions[22].return_type = 7;
    _module_functions[22].return_struct_type_name = NULL;
    _module_functions[22].return_fn_sig = NULL;
    _module_functions[22].return_type_info = NULL;
    _module_functions[22].body = NULL;
    _module_functions[22].shadow_test = NULL;
    _module_functions[22].is_extern = false;
    _module_functions[22].returns_gc_managed = false;
    _module_functions[22].requires_manual_free = false;
    _module_functions[22].returns_borrowed = false;
    _module_functions[22].cleanup_function = NULL;
    _module_functions[22].params = NULL;

    /* Function: array_set */
    _module_functions[23].name = "array_set";
    _module_functions[23].param_count = 0;
    _module_functions[23].return_type = 6;
    _module_functions[23].return_struct_type_name = NULL;
    _module_functions[23].return_fn_sig = NULL;
    _module_functions[23].return_type_info = NULL;
    _module_functions[23].body = NULL;
    _module_functions[23].shadow_test = NULL;
    _module_functions[23].is_extern = false;
    _module_functions[23].returns_gc_managed = false;
    _module_functions[23].requires_manual_free = false;
    _module_functions[23].returns_borrowed = false;
    _module_functions[23].cleanup_function = NULL;
    _module_functions[23].params = NULL;

    /* Function: map */
    _module_functions[24].name = "map";
    _module_functions[24].param_count = 0;
    _module_functions[24].return_type = 7;
    _module_functions[24].return_struct_type_name = NULL;
    _module_functions[24].return_fn_sig = NULL;
    _module_functions[24].return_type_info = NULL;
    _module_functions[24].body = NULL;
    _module_functions[24].shadow_test = NULL;
    _module_functions[24].is_extern = false;
    _module_functions[24].returns_gc_managed = false;
    _module_functions[24].requires_manual_free = false;
    _module_functions[24].returns_borrowed = false;
    _module_functions[24].cleanup_function = NULL;
    _module_functions[24].params = NULL;

    /* Function: reduce */
    _module_functions[25].name = "reduce";
    _module_functions[25].param_count = 0;
    _module_functions[25].return_type = 21;
    _module_functions[25].return_struct_type_name = NULL;
    _module_functions[25].return_fn_sig = NULL;
    _module_functions[25].return_type_info = NULL;
    _module_functions[25].body = NULL;
    _module_functions[25].shadow_test = NULL;
    _module_functions[25].is_extern = false;
    _module_functions[25].returns_gc_managed = false;
    _module_functions[25].requires_manual_free = false;
    _module_functions[25].returns_borrowed = false;
    _module_functions[25].cleanup_function = NULL;
    _module_functions[25].params = NULL;

    /* Function: getcwd */
    _module_functions[26].name = "getcwd";
    _module_functions[26].param_count = 0;
    _module_functions[26].return_type = 4;
    _module_functions[26].return_struct_type_name = NULL;
    _module_functions[26].return_fn_sig = NULL;
    _module_functions[26].return_type_info = NULL;
    _module_functions[26].body = NULL;
    _module_functions[26].shadow_test = NULL;
    _module_functions[26].is_extern = false;
    _module_functions[26].returns_gc_managed = true;
    _module_functions[26].requires_manual_free = false;
    _module_functions[26].returns_borrowed = false;
    _module_functions[26].cleanup_function = NULL;
    _module_functions[26].params = NULL;

    /* Function: getenv */
    _module_functions[27].name = "getenv";
    _module_functions[27].param_count = 0;
    _module_functions[27].return_type = 4;
    _module_functions[27].return_struct_type_name = NULL;
    _module_functions[27].return_fn_sig = NULL;
    _module_functions[27].return_type_info = NULL;
    _module_functions[27].body = NULL;
    _module_functions[27].shadow_test = NULL;
    _module_functions[27].is_extern = false;
    _module_functions[27].returns_gc_managed = true;
    _module_functions[27].requires_manual_free = false;
    _module_functions[27].returns_borrowed = false;
    _module_functions[27].cleanup_function = NULL;
    _module_functions[27].params = NULL;

    /* Function: dir_list */
    _module_functions[28].name = "dir_list";
    _module_functions[28].param_count = 0;
    _module_functions[28].return_type = 7;
    _module_functions[28].return_struct_type_name = NULL;
    _module_functions[28].return_fn_sig = NULL;
    _module_functions[28].return_type_info = NULL;
    _module_functions[28].body = NULL;
    _module_functions[28].shadow_test = NULL;
    _module_functions[28].is_extern = false;
    _module_functions[28].returns_gc_managed = false;
    _module_functions[28].requires_manual_free = false;
    _module_functions[28].returns_borrowed = false;
    _module_functions[28].cleanup_function = NULL;
    _module_functions[28].params = NULL;

    /* Function: process_run */
    _module_functions[29].name = "process_run";
    _module_functions[29].param_count = 0;
    _module_functions[29].return_type = 7;
    _module_functions[29].return_struct_type_name = NULL;
    _module_functions[29].return_fn_sig = NULL;
    _module_functions[29].return_type_info = NULL;
    _module_functions[29].body = NULL;
    _module_functions[29].shadow_test = NULL;
    _module_functions[29].is_extern = false;
    _module_functions[29].returns_gc_managed = false;
    _module_functions[29].requires_manual_free = false;
    _module_functions[29].returns_borrowed = false;
    _module_functions[29].cleanup_function = NULL;
    _module_functions[29].params = NULL;

    /* Function: tmp_dir */
    _module_functions[30].name = "tmp_dir";
    _module_functions[30].param_count = 0;
    _module_functions[30].return_type = 4;
    _module_functions[30].return_struct_type_name = NULL;
    _module_functions[30].return_fn_sig = NULL;
    _module_functions[30].return_type_info = NULL;
    _module_functions[30].body = NULL;
    _module_functions[30].shadow_test = NULL;
    _module_functions[30].is_extern = false;
    _module_functions[30].returns_gc_managed = true;
    _module_functions[30].requires_manual_free = false;
    _module_functions[30].returns_borrowed = false;
    _module_functions[30].cleanup_function = NULL;
    _module_functions[30].params = NULL;

    /* Function: mktemp */
    _module_functions[31].name = "mktemp";
    _module_functions[31].param_count = 0;
    _module_functions[31].return_type = 4;
    _module_functions[31].return_struct_type_name = NULL;
    _module_functions[31].return_fn_sig = NULL;
    _module_functions[31].return_type_info = NULL;
    _module_functions[31].body = NULL;
    _module_functions[31].shadow_test = NULL;
    _module_functions[31].is_extern = false;
    _module_functions[31].returns_gc_managed = true;
    _module_functions[31].requires_manual_free = false;
    _module_functions[31].returns_borrowed = false;
    _module_functions[31].cleanup_function = NULL;
    _module_functions[31].params = NULL;

    /* Function: mktemp_dir */
    _module_functions[32].name = "mktemp_dir";
    _module_functions[32].param_count = 0;
    _module_functions[32].return_type = 4;
    _module_functions[32].return_struct_type_name = NULL;
    _module_functions[32].return_fn_sig = NULL;
    _module_functions[32].return_type_info = NULL;
    _module_functions[32].body = NULL;
    _module_functions[32].shadow_test = NULL;
    _module_functions[32].is_extern = false;
    _module_functions[32].returns_gc_managed = true;
    _module_functions[32].requires_manual_free = false;
    _module_functions[32].returns_borrowed = false;
    _module_functions[32].cleanup_function = NULL;
    _module_functions[32].params = NULL;

    /* Function: char_at */
    _module_functions[33].name = "char_at";
    _module_functions[33].param_count = 0;
    _module_functions[33].return_type = 0;
    _module_functions[33].return_struct_type_name = NULL;
    _module_functions[33].return_fn_sig = NULL;
    _module_functions[33].return_type_info = NULL;
    _module_functions[33].body = NULL;
    _module_functions[33].shadow_test = NULL;
    _module_functions[33].is_extern = false;
    _module_functions[33].returns_gc_managed = false;
    _module_functions[33].requires_manual_free = false;
    _module_functions[33].returns_borrowed = false;
    _module_functions[33].cleanup_function = NULL;
    _module_functions[33].params = NULL;

    /* Function: string_from_char */
    _module_functions[34].name = "string_from_char";
    _module_functions[34].param_count = 0;
    _module_functions[34].return_type = 4;
    _module_functions[34].return_struct_type_name = NULL;
    _module_functions[34].return_fn_sig = NULL;
    _module_functions[34].return_type_info = NULL;
    _module_functions[34].body = NULL;
    _module_functions[34].shadow_test = NULL;
    _module_functions[34].is_extern = false;
    _module_functions[34].returns_gc_managed = true;
    _module_functions[34].requires_manual_free = false;
    _module_functions[34].returns_borrowed = false;
    _module_functions[34].cleanup_function = NULL;
    _module_functions[34].params = NULL;

    /* Function: is_digit */
    _module_functions[35].name = "is_digit";
    _module_functions[35].param_count = 0;
    _module_functions[35].return_type = 3;
    _module_functions[35].return_struct_type_name = NULL;
    _module_functions[35].return_fn_sig = NULL;
    _module_functions[35].return_type_info = NULL;
    _module_functions[35].body = NULL;
    _module_functions[35].shadow_test = NULL;
    _module_functions[35].is_extern = false;
    _module_functions[35].returns_gc_managed = false;
    _module_functions[35].requires_manual_free = false;
    _module_functions[35].returns_borrowed = false;
    _module_functions[35].cleanup_function = NULL;
    _module_functions[35].params = NULL;

    /* Function: is_alpha */
    _module_functions[36].name = "is_alpha";
    _module_functions[36].param_count = 0;
    _module_functions[36].return_type = 3;
    _module_functions[36].return_struct_type_name = NULL;
    _module_functions[36].return_fn_sig = NULL;
    _module_functions[36].return_type_info = NULL;
    _module_functions[36].body = NULL;
    _module_functions[36].shadow_test = NULL;
    _module_functions[36].is_extern = false;
    _module_functions[36].returns_gc_managed = false;
    _module_functions[36].requires_manual_free = false;
    _module_functions[36].returns_borrowed = false;
    _module_functions[36].cleanup_function = NULL;
    _module_functions[36].params = NULL;

    /* Function: is_alnum */
    _module_functions[37].name = "is_alnum";
    _module_functions[37].param_count = 0;
    _module_functions[37].return_type = 3;
    _module_functions[37].return_struct_type_name = NULL;
    _module_functions[37].return_fn_sig = NULL;
    _module_functions[37].return_type_info = NULL;
    _module_functions[37].body = NULL;
    _module_functions[37].shadow_test = NULL;
    _module_functions[37].is_extern = false;
    _module_functions[37].returns_gc_managed = false;
    _module_functions[37].requires_manual_free = false;
    _module_functions[37].returns_borrowed = false;
    _module_functions[37].cleanup_function = NULL;
    _module_functions[37].params = NULL;

    /* Function: is_whitespace */
    _module_functions[38].name = "is_whitespace";
    _module_functions[38].param_count = 0;
    _module_functions[38].return_type = 3;
    _module_functions[38].return_struct_type_name = NULL;
    _module_functions[38].return_fn_sig = NULL;
    _module_functions[38].return_type_info = NULL;
    _module_functions[38].body = NULL;
    _module_functions[38].shadow_test = NULL;
    _module_functions[38].is_extern = false;
    _module_functions[38].returns_gc_managed = false;
    _module_functions[38].requires_manual_free = false;
    _module_functions[38].returns_borrowed = false;
    _module_functions[38].cleanup_function = NULL;
    _module_functions[38].params = NULL;

    /* Function: is_upper */
    _module_functions[39].name = "is_upper";
    _module_functions[39].param_count = 0;
    _module_functions[39].return_type = 3;
    _module_functions[39].return_struct_type_name = NULL;
    _module_functions[39].return_fn_sig = NULL;
    _module_functions[39].return_type_info = NULL;
    _module_functions[39].body = NULL;
    _module_functions[39].shadow_test = NULL;
    _module_functions[39].is_extern = false;
    _module_functions[39].returns_gc_managed = false;
    _module_functions[39].requires_manual_free = false;
    _module_functions[39].returns_borrowed = false;
    _module_functions[39].cleanup_function = NULL;
    _module_functions[39].params = NULL;

    /* Function: is_lower */
    _module_functions[40].name = "is_lower";
    _module_functions[40].param_count = 0;
    _module_functions[40].return_type = 3;
    _module_functions[40].return_struct_type_name = NULL;
    _module_functions[40].return_fn_sig = NULL;
    _module_functions[40].return_type_info = NULL;
    _module_functions[40].body = NULL;
    _module_functions[40].shadow_test = NULL;
    _module_functions[40].is_extern = false;
    _module_functions[40].returns_gc_managed = false;
    _module_functions[40].requires_manual_free = false;
    _module_functions[40].returns_borrowed = false;
    _module_functions[40].cleanup_function = NULL;
    _module_functions[40].params = NULL;

    /* Function: int_to_string */
    _module_functions[41].name = "int_to_string";
    _module_functions[41].param_count = 0;
    _module_functions[41].return_type = 4;
    _module_functions[41].return_struct_type_name = NULL;
    _module_functions[41].return_fn_sig = NULL;
    _module_functions[41].return_type_info = NULL;
    _module_functions[41].body = NULL;
    _module_functions[41].shadow_test = NULL;
    _module_functions[41].is_extern = false;
    _module_functions[41].returns_gc_managed = true;
    _module_functions[41].requires_manual_free = false;
    _module_functions[41].returns_borrowed = false;
    _module_functions[41].cleanup_function = NULL;
    _module_functions[41].params = NULL;

    /* Function: string_to_int */
    _module_functions[42].name = "string_to_int";
    _module_functions[42].param_count = 0;
    _module_functions[42].return_type = 0;
    _module_functions[42].return_struct_type_name = NULL;
    _module_functions[42].return_fn_sig = NULL;
    _module_functions[42].return_type_info = NULL;
    _module_functions[42].body = NULL;
    _module_functions[42].shadow_test = NULL;
    _module_functions[42].is_extern = false;
    _module_functions[42].returns_gc_managed = false;
    _module_functions[42].requires_manual_free = false;
    _module_functions[42].returns_borrowed = false;
    _module_functions[42].cleanup_function = NULL;
    _module_functions[42].params = NULL;

    /* Function: digit_value */
    _module_functions[43].name = "digit_value";
    _module_functions[43].param_count = 0;
    _module_functions[43].return_type = 0;
    _module_functions[43].return_struct_type_name = NULL;
    _module_functions[43].return_fn_sig = NULL;
    _module_functions[43].return_type_info = NULL;
    _module_functions[43].body = NULL;
    _module_functions[43].shadow_test = NULL;
    _module_functions[43].is_extern = false;
    _module_functions[43].returns_gc_managed = false;
    _module_functions[43].requires_manual_free = false;
    _module_functions[43].returns_borrowed = false;
    _module_functions[43].cleanup_function = NULL;
    _module_functions[43].params = NULL;

    /* Function: char_to_lower */
    _module_functions[44].name = "char_to_lower";
    _module_functions[44].param_count = 0;
    _module_functions[44].return_type = 0;
    _module_functions[44].return_struct_type_name = NULL;
    _module_functions[44].return_fn_sig = NULL;
    _module_functions[44].return_type_info = NULL;
    _module_functions[44].body = NULL;
    _module_functions[44].shadow_test = NULL;
    _module_functions[44].is_extern = false;
    _module_functions[44].returns_gc_managed = false;
    _module_functions[44].requires_manual_free = false;
    _module_functions[44].returns_borrowed = false;
    _module_functions[44].cleanup_function = NULL;
    _module_functions[44].params = NULL;

    /* Function: char_to_upper */
    _module_functions[45].name = "char_to_upper";
    _module_functions[45].param_count = 0;
    _module_functions[45].return_type = 0;
    _module_functions[45].return_struct_type_name = NULL;
    _module_functions[45].return_fn_sig = NULL;
    _module_functions[45].return_type_info = NULL;
    _module_functions[45].body = NULL;
    _module_functions[45].shadow_test = NULL;
    _module_functions[45].is_extern = false;
    _module_functions[45].returns_gc_managed = false;
    _module_functions[45].requires_manual_free = false;
    _module_functions[45].returns_borrowed = false;
    _module_functions[45].cleanup_function = NULL;
    _module_functions[45].params = NULL;

    /* Function: list_int_new */
    _module_functions[46].name = "list_int_new";
    _module_functions[46].param_count = 0;
    _module_functions[46].return_type = 12;
    _module_functions[46].return_struct_type_name = NULL;
    _module_functions[46].return_fn_sig = NULL;
    _module_functions[46].return_type_info = NULL;
    _module_functions[46].body = NULL;
    _module_functions[46].shadow_test = NULL;
    _module_functions[46].is_extern = false;
    _module_functions[46].returns_gc_managed = false;
    _module_functions[46].requires_manual_free = false;
    _module_functions[46].returns_borrowed = false;
    _module_functions[46].cleanup_function = NULL;
    _module_functions[46].params = NULL;

    /* Function: list_int_with_capacity */
    _module_functions[47].name = "list_int_with_capacity";
    _module_functions[47].param_count = 0;
    _module_functions[47].return_type = 12;
    _module_functions[47].return_struct_type_name = NULL;
    _module_functions[47].return_fn_sig = NULL;
    _module_functions[47].return_type_info = NULL;
    _module_functions[47].body = NULL;
    _module_functions[47].shadow_test = NULL;
    _module_functions[47].is_extern = false;
    _module_functions[47].returns_gc_managed = false;
    _module_functions[47].requires_manual_free = false;
    _module_functions[47].returns_borrowed = false;
    _module_functions[47].cleanup_function = NULL;
    _module_functions[47].params = NULL;

    /* Function: list_int_push */
    _module_functions[48].name = "list_int_push";
    _module_functions[48].param_count = 0;
    _module_functions[48].return_type = 6;
    _module_functions[48].return_struct_type_name = NULL;
    _module_functions[48].return_fn_sig = NULL;
    _module_functions[48].return_type_info = NULL;
    _module_functions[48].body = NULL;
    _module_functions[48].shadow_test = NULL;
    _module_functions[48].is_extern = false;
    _module_functions[48].returns_gc_managed = false;
    _module_functions[48].requires_manual_free = false;
    _module_functions[48].returns_borrowed = false;
    _module_functions[48].cleanup_function = NULL;
    _module_functions[48].params = NULL;

    /* Function: list_int_pop */
    _module_functions[49].name = "list_int_pop";
    _module_functions[49].param_count = 0;
    _module_functions[49].return_type = 0;
    _module_functions[49].return_struct_type_name = NULL;
    _module_functions[49].return_fn_sig = NULL;
    _module_functions[49].return_type_info = NULL;
    _module_functions[49].body = NULL;
    _module_functions[49].shadow_test = NULL;
    _module_functions[49].is_extern = false;
    _module_functions[49].returns_gc_managed = false;
    _module_functions[49].requires_manual_free = false;
    _module_functions[49].returns_borrowed = false;
    _module_functions[49].cleanup_function = NULL;
    _module_functions[49].params = NULL;

    /* Function: list_int_get */
    _module_functions[50].name = "list_int_get";
    _module_functions[50].param_count = 0;
    _module_functions[50].return_type = 0;
    _module_functions[50].return_struct_type_name = NULL;
    _module_functions[50].return_fn_sig = NULL;
    _module_functions[50].return_type_info = NULL;
    _module_functions[50].body = NULL;
    _module_functions[50].shadow_test = NULL;
    _module_functions[50].is_extern = false;
    _module_functions[50].returns_gc_managed = false;
    _module_functions[50].requires_manual_free = false;
    _module_functions[50].returns_borrowed = false;
    _module_functions[50].cleanup_function = NULL;
    _module_functions[50].params = NULL;

    /* Function: list_int_set */
    _module_functions[51].name = "list_int_set";
    _module_functions[51].param_count = 0;
    _module_functions[51].return_type = 6;
    _module_functions[51].return_struct_type_name = NULL;
    _module_functions[51].return_fn_sig = NULL;
    _module_functions[51].return_type_info = NULL;
    _module_functions[51].body = NULL;
    _module_functions[51].shadow_test = NULL;
    _module_functions[51].is_extern = false;
    _module_functions[51].returns_gc_managed = false;
    _module_functions[51].requires_manual_free = false;
    _module_functions[51].returns_borrowed = false;
    _module_functions[51].cleanup_function = NULL;
    _module_functions[51].params = NULL;

    /* Function: list_int_insert */
    _module_functions[52].name = "list_int_insert";
    _module_functions[52].param_count = 0;
    _module_functions[52].return_type = 6;
    _module_functions[52].return_struct_type_name = NULL;
    _module_functions[52].return_fn_sig = NULL;
    _module_functions[52].return_type_info = NULL;
    _module_functions[52].body = NULL;
    _module_functions[52].shadow_test = NULL;
    _module_functions[52].is_extern = false;
    _module_functions[52].returns_gc_managed = false;
    _module_functions[52].requires_manual_free = false;
    _module_functions[52].returns_borrowed = false;
    _module_functions[52].cleanup_function = NULL;
    _module_functions[52].params = NULL;

    /* Function: list_int_remove */
    _module_functions[53].name = "list_int_remove";
    _module_functions[53].param_count = 0;
    _module_functions[53].return_type = 0;
    _module_functions[53].return_struct_type_name = NULL;
    _module_functions[53].return_fn_sig = NULL;
    _module_functions[53].return_type_info = NULL;
    _module_functions[53].body = NULL;
    _module_functions[53].shadow_test = NULL;
    _module_functions[53].is_extern = false;
    _module_functions[53].returns_gc_managed = false;
    _module_functions[53].requires_manual_free = false;
    _module_functions[53].returns_borrowed = false;
    _module_functions[53].cleanup_function = NULL;
    _module_functions[53].params = NULL;

    /* Function: list_int_length */
    _module_functions[54].name = "list_int_length";
    _module_functions[54].param_count = 0;
    _module_functions[54].return_type = 0;
    _module_functions[54].return_struct_type_name = NULL;
    _module_functions[54].return_fn_sig = NULL;
    _module_functions[54].return_type_info = NULL;
    _module_functions[54].body = NULL;
    _module_functions[54].shadow_test = NULL;
    _module_functions[54].is_extern = false;
    _module_functions[54].returns_gc_managed = false;
    _module_functions[54].requires_manual_free = false;
    _module_functions[54].returns_borrowed = false;
    _module_functions[54].cleanup_function = NULL;
    _module_functions[54].params = NULL;

    /* Function: list_int_capacity */
    _module_functions[55].name = "list_int_capacity";
    _module_functions[55].param_count = 0;
    _module_functions[55].return_type = 0;
    _module_functions[55].return_struct_type_name = NULL;
    _module_functions[55].return_fn_sig = NULL;
    _module_functions[55].return_type_info = NULL;
    _module_functions[55].body = NULL;
    _module_functions[55].shadow_test = NULL;
    _module_functions[55].is_extern = false;
    _module_functions[55].returns_gc_managed = false;
    _module_functions[55].requires_manual_free = false;
    _module_functions[55].returns_borrowed = false;
    _module_functions[55].cleanup_function = NULL;
    _module_functions[55].params = NULL;

    /* Function: list_int_is_empty */
    _module_functions[56].name = "list_int_is_empty";
    _module_functions[56].param_count = 0;
    _module_functions[56].return_type = 3;
    _module_functions[56].return_struct_type_name = NULL;
    _module_functions[56].return_fn_sig = NULL;
    _module_functions[56].return_type_info = NULL;
    _module_functions[56].body = NULL;
    _module_functions[56].shadow_test = NULL;
    _module_functions[56].is_extern = false;
    _module_functions[56].returns_gc_managed = false;
    _module_functions[56].requires_manual_free = false;
    _module_functions[56].returns_borrowed = false;
    _module_functions[56].cleanup_function = NULL;
    _module_functions[56].params = NULL;

    /* Function: list_int_clear */
    _module_functions[57].name = "list_int_clear";
    _module_functions[57].param_count = 0;
    _module_functions[57].return_type = 6;
    _module_functions[57].return_struct_type_name = NULL;
    _module_functions[57].return_fn_sig = NULL;
    _module_functions[57].return_type_info = NULL;
    _module_functions[57].body = NULL;
    _module_functions[57].shadow_test = NULL;
    _module_functions[57].is_extern = false;
    _module_functions[57].returns_gc_managed = false;
    _module_functions[57].requires_manual_free = false;
    _module_functions[57].returns_borrowed = false;
    _module_functions[57].cleanup_function = NULL;
    _module_functions[57].params = NULL;

    /* Function: list_int_free */
    _module_functions[58].name = "list_int_free";
    _module_functions[58].param_count = 0;
    _module_functions[58].return_type = 6;
    _module_functions[58].return_struct_type_name = NULL;
    _module_functions[58].return_fn_sig = NULL;
    _module_functions[58].return_type_info = NULL;
    _module_functions[58].body = NULL;
    _module_functions[58].shadow_test = NULL;
    _module_functions[58].is_extern = false;
    _module_functions[58].returns_gc_managed = false;
    _module_functions[58].requires_manual_free = false;
    _module_functions[58].returns_borrowed = false;
    _module_functions[58].cleanup_function = NULL;
    _module_functions[58].params = NULL;

    /* Function: list_string_new */
    _module_functions[59].name = "list_string_new";
    _module_functions[59].param_count = 0;
    _module_functions[59].return_type = 13;
    _module_functions[59].return_struct_type_name = NULL;
    _module_functions[59].return_fn_sig = NULL;
    _module_functions[59].return_type_info = NULL;
    _module_functions[59].body = NULL;
    _module_functions[59].shadow_test = NULL;
    _module_functions[59].is_extern = false;
    _module_functions[59].returns_gc_managed = false;
    _module_functions[59].requires_manual_free = false;
    _module_functions[59].returns_borrowed = false;
    _module_functions[59].cleanup_function = NULL;
    _module_functions[59].params = NULL;

    /* Function: list_string_with_capacity */
    _module_functions[60].name = "list_string_with_capacity";
    _module_functions[60].param_count = 0;
    _module_functions[60].return_type = 13;
    _module_functions[60].return_struct_type_name = NULL;
    _module_functions[60].return_fn_sig = NULL;
    _module_functions[60].return_type_info = NULL;
    _module_functions[60].body = NULL;
    _module_functions[60].shadow_test = NULL;
    _module_functions[60].is_extern = false;
    _module_functions[60].returns_gc_managed = false;
    _module_functions[60].requires_manual_free = false;
    _module_functions[60].returns_borrowed = false;
    _module_functions[60].cleanup_function = NULL;
    _module_functions[60].params = NULL;

    /* Function: list_string_push */
    _module_functions[61].name = "list_string_push";
    _module_functions[61].param_count = 0;
    _module_functions[61].return_type = 6;
    _module_functions[61].return_struct_type_name = NULL;
    _module_functions[61].return_fn_sig = NULL;
    _module_functions[61].return_type_info = NULL;
    _module_functions[61].body = NULL;
    _module_functions[61].shadow_test = NULL;
    _module_functions[61].is_extern = false;
    _module_functions[61].returns_gc_managed = false;
    _module_functions[61].requires_manual_free = false;
    _module_functions[61].returns_borrowed = false;
    _module_functions[61].cleanup_function = NULL;
    _module_functions[61].params = NULL;

    /* Function: list_string_pop */
    _module_functions[62].name = "list_string_pop";
    _module_functions[62].param_count = 0;
    _module_functions[62].return_type = 4;
    _module_functions[62].return_struct_type_name = NULL;
    _module_functions[62].return_fn_sig = NULL;
    _module_functions[62].return_type_info = NULL;
    _module_functions[62].body = NULL;
    _module_functions[62].shadow_test = NULL;
    _module_functions[62].is_extern = false;
    _module_functions[62].returns_gc_managed = true;
    _module_functions[62].requires_manual_free = false;
    _module_functions[62].returns_borrowed = false;
    _module_functions[62].cleanup_function = NULL;
    _module_functions[62].params = NULL;

    /* Function: list_string_get */
    _module_functions[63].name = "list_string_get";
    _module_functions[63].param_count = 0;
    _module_functions[63].return_type = 4;
    _module_functions[63].return_struct_type_name = NULL;
    _module_functions[63].return_fn_sig = NULL;
    _module_functions[63].return_type_info = NULL;
    _module_functions[63].body = NULL;
    _module_functions[63].shadow_test = NULL;
    _module_functions[63].is_extern = false;
    _module_functions[63].returns_gc_managed = true;
    _module_functions[63].requires_manual_free = false;
    _module_functions[63].returns_borrowed = false;
    _module_functions[63].cleanup_function = NULL;
    _module_functions[63].params = NULL;

    /* Function: list_string_set */
    _module_functions[64].name = "list_string_set";
    _module_functions[64].param_count = 0;
    _module_functions[64].return_type = 6;
    _module_functions[64].return_struct_type_name = NULL;
    _module_functions[64].return_fn_sig = NULL;
    _module_functions[64].return_type_info = NULL;
    _module_functions[64].body = NULL;
    _module_functions[64].shadow_test = NULL;
    _module_functions[64].is_extern = false;
    _module_functions[64].returns_gc_managed = false;
    _module_functions[64].requires_manual_free = false;
    _module_functions[64].returns_borrowed = false;
    _module_functions[64].cleanup_function = NULL;
    _module_functions[64].params = NULL;

    /* Function: list_string_insert */
    _module_functions[65].name = "list_string_insert";
    _module_functions[65].param_count = 0;
    _module_functions[65].return_type = 6;
    _module_functions[65].return_struct_type_name = NULL;
    _module_functions[65].return_fn_sig = NULL;
    _module_functions[65].return_type_info = NULL;
    _module_functions[65].body = NULL;
    _module_functions[65].shadow_test = NULL;
    _module_functions[65].is_extern = false;
    _module_functions[65].returns_gc_managed = false;
    _module_functions[65].requires_manual_free = false;
    _module_functions[65].returns_borrowed = false;
    _module_functions[65].cleanup_function = NULL;
    _module_functions[65].params = NULL;

    /* Function: list_string_remove */
    _module_functions[66].name = "list_string_remove";
    _module_functions[66].param_count = 0;
    _module_functions[66].return_type = 4;
    _module_functions[66].return_struct_type_name = NULL;
    _module_functions[66].return_fn_sig = NULL;
    _module_functions[66].return_type_info = NULL;
    _module_functions[66].body = NULL;
    _module_functions[66].shadow_test = NULL;
    _module_functions[66].is_extern = false;
    _module_functions[66].returns_gc_managed = true;
    _module_functions[66].requires_manual_free = false;
    _module_functions[66].returns_borrowed = false;
    _module_functions[66].cleanup_function = NULL;
    _module_functions[66].params = NULL;

    /* Function: list_string_length */
    _module_functions[67].name = "list_string_length";
    _module_functions[67].param_count = 0;
    _module_functions[67].return_type = 0;
    _module_functions[67].return_struct_type_name = NULL;
    _module_functions[67].return_fn_sig = NULL;
    _module_functions[67].return_type_info = NULL;
    _module_functions[67].body = NULL;
    _module_functions[67].shadow_test = NULL;
    _module_functions[67].is_extern = false;
    _module_functions[67].returns_gc_managed = false;
    _module_functions[67].requires_manual_free = false;
    _module_functions[67].returns_borrowed = false;
    _module_functions[67].cleanup_function = NULL;
    _module_functions[67].params = NULL;

    /* Function: list_string_capacity */
    _module_functions[68].name = "list_string_capacity";
    _module_functions[68].param_count = 0;
    _module_functions[68].return_type = 0;
    _module_functions[68].return_struct_type_name = NULL;
    _module_functions[68].return_fn_sig = NULL;
    _module_functions[68].return_type_info = NULL;
    _module_functions[68].body = NULL;
    _module_functions[68].shadow_test = NULL;
    _module_functions[68].is_extern = false;
    _module_functions[68].returns_gc_managed = false;
    _module_functions[68].requires_manual_free = false;
    _module_functions[68].returns_borrowed = false;
    _module_functions[68].cleanup_function = NULL;
    _module_functions[68].params = NULL;

    /* Function: list_string_is_empty */
    _module_functions[69].name = "list_string_is_empty";
    _module_functions[69].param_count = 0;
    _module_functions[69].return_type = 3;
    _module_functions[69].return_struct_type_name = NULL;
    _module_functions[69].return_fn_sig = NULL;
    _module_functions[69].return_type_info = NULL;
    _module_functions[69].body = NULL;
    _module_functions[69].shadow_test = NULL;
    _module_functions[69].is_extern = false;
    _module_functions[69].returns_gc_managed = false;
    _module_functions[69].requires_manual_free = false;
    _module_functions[69].returns_borrowed = false;
    _module_functions[69].cleanup_function = NULL;
    _module_functions[69].params = NULL;

    /* Function: list_string_clear */
    _module_functions[70].name = "list_string_clear";
    _module_functions[70].param_count = 0;
    _module_functions[70].return_type = 6;
    _module_functions[70].return_struct_type_name = NULL;
    _module_functions[70].return_fn_sig = NULL;
    _module_functions[70].return_type_info = NULL;
    _module_functions[70].body = NULL;
    _module_functions[70].shadow_test = NULL;
    _module_functions[70].is_extern = false;
    _module_functions[70].returns_gc_managed = false;
    _module_functions[70].requires_manual_free = false;
    _module_functions[70].returns_borrowed = false;
    _module_functions[70].cleanup_function = NULL;
    _module_functions[70].params = NULL;

    /* Function: list_string_free */
    _module_functions[71].name = "list_string_free";
    _module_functions[71].param_count = 0;
    _module_functions[71].return_type = 6;
    _module_functions[71].return_struct_type_name = NULL;
    _module_functions[71].return_fn_sig = NULL;
    _module_functions[71].return_type_info = NULL;
    _module_functions[71].body = NULL;
    _module_functions[71].shadow_test = NULL;
    _module_functions[71].is_extern = false;
    _module_functions[71].returns_gc_managed = false;
    _module_functions[71].requires_manual_free = false;
    _module_functions[71].returns_borrowed = false;
    _module_functions[71].cleanup_function = NULL;
    _module_functions[71].params = NULL;

    /* Function: nl_list_Token_new */
    _module_functions[72].name = "nl_list_Token_new";
    _module_functions[72].param_count = 0;
    _module_functions[72].return_type = 14;
    _module_functions[72].return_struct_type_name = NULL;
    _module_functions[72].return_fn_sig = NULL;
    _module_functions[72].return_type_info = NULL;
    _module_functions[72].body = NULL;
    _module_functions[72].shadow_test = NULL;
    _module_functions[72].is_extern = false;
    _module_functions[72].returns_gc_managed = false;
    _module_functions[72].requires_manual_free = false;
    _module_functions[72].returns_borrowed = false;
    _module_functions[72].cleanup_function = NULL;
    _module_functions[72].params = NULL;

    /* Function: nl_list_Token_with_capacity */
    _module_functions[73].name = "nl_list_Token_with_capacity";
    _module_functions[73].param_count = 0;
    _module_functions[73].return_type = 14;
    _module_functions[73].return_struct_type_name = NULL;
    _module_functions[73].return_fn_sig = NULL;
    _module_functions[73].return_type_info = NULL;
    _module_functions[73].body = NULL;
    _module_functions[73].shadow_test = NULL;
    _module_functions[73].is_extern = false;
    _module_functions[73].returns_gc_managed = false;
    _module_functions[73].requires_manual_free = false;
    _module_functions[73].returns_borrowed = false;
    _module_functions[73].cleanup_function = NULL;
    _module_functions[73].params = NULL;

    /* Function: nl_list_Token_push */
    _module_functions[74].name = "nl_list_Token_push";
    _module_functions[74].param_count = 0;
    _module_functions[74].return_type = 6;
    _module_functions[74].return_struct_type_name = NULL;
    _module_functions[74].return_fn_sig = NULL;
    _module_functions[74].return_type_info = NULL;
    _module_functions[74].body = NULL;
    _module_functions[74].shadow_test = NULL;
    _module_functions[74].is_extern = false;
    _module_functions[74].returns_gc_managed = false;
    _module_functions[74].requires_manual_free = false;
    _module_functions[74].returns_borrowed = false;
    _module_functions[74].cleanup_function = NULL;
    _module_functions[74].params = NULL;

    /* Function: nl_list_Token_pop */
    _module_functions[75].name = "nl_list_Token_pop";
    _module_functions[75].param_count = 0;
    _module_functions[75].return_type = 8;
    _module_functions[75].return_struct_type_name = NULL;
    _module_functions[75].return_fn_sig = NULL;
    _module_functions[75].return_type_info = NULL;
    _module_functions[75].body = NULL;
    _module_functions[75].shadow_test = NULL;
    _module_functions[75].is_extern = false;
    _module_functions[75].returns_gc_managed = false;
    _module_functions[75].requires_manual_free = false;
    _module_functions[75].returns_borrowed = false;
    _module_functions[75].cleanup_function = NULL;
    _module_functions[75].params = NULL;

    /* Function: nl_list_Token_get */
    _module_functions[76].name = "nl_list_Token_get";
    _module_functions[76].param_count = 0;
    _module_functions[76].return_type = 8;
    _module_functions[76].return_struct_type_name = NULL;
    _module_functions[76].return_fn_sig = NULL;
    _module_functions[76].return_type_info = NULL;
    _module_functions[76].body = NULL;
    _module_functions[76].shadow_test = NULL;
    _module_functions[76].is_extern = false;
    _module_functions[76].returns_gc_managed = false;
    _module_functions[76].requires_manual_free = false;
    _module_functions[76].returns_borrowed = false;
    _module_functions[76].cleanup_function = NULL;
    _module_functions[76].params = NULL;

    /* Function: nl_list_Token_set */
    _module_functions[77].name = "nl_list_Token_set";
    _module_functions[77].param_count = 0;
    _module_functions[77].return_type = 6;
    _module_functions[77].return_struct_type_name = NULL;
    _module_functions[77].return_fn_sig = NULL;
    _module_functions[77].return_type_info = NULL;
    _module_functions[77].body = NULL;
    _module_functions[77].shadow_test = NULL;
    _module_functions[77].is_extern = false;
    _module_functions[77].returns_gc_managed = false;
    _module_functions[77].requires_manual_free = false;
    _module_functions[77].returns_borrowed = false;
    _module_functions[77].cleanup_function = NULL;
    _module_functions[77].params = NULL;

    /* Function: nl_list_Token_insert */
    _module_functions[78].name = "nl_list_Token_insert";
    _module_functions[78].param_count = 0;
    _module_functions[78].return_type = 6;
    _module_functions[78].return_struct_type_name = NULL;
    _module_functions[78].return_fn_sig = NULL;
    _module_functions[78].return_type_info = NULL;
    _module_functions[78].body = NULL;
    _module_functions[78].shadow_test = NULL;
    _module_functions[78].is_extern = false;
    _module_functions[78].returns_gc_managed = false;
    _module_functions[78].requires_manual_free = false;
    _module_functions[78].returns_borrowed = false;
    _module_functions[78].cleanup_function = NULL;
    _module_functions[78].params = NULL;

    /* Function: nl_list_Token_remove */
    _module_functions[79].name = "nl_list_Token_remove";
    _module_functions[79].param_count = 0;
    _module_functions[79].return_type = 8;
    _module_functions[79].return_struct_type_name = NULL;
    _module_functions[79].return_fn_sig = NULL;
    _module_functions[79].return_type_info = NULL;
    _module_functions[79].body = NULL;
    _module_functions[79].shadow_test = NULL;
    _module_functions[79].is_extern = false;
    _module_functions[79].returns_gc_managed = false;
    _module_functions[79].requires_manual_free = false;
    _module_functions[79].returns_borrowed = false;
    _module_functions[79].cleanup_function = NULL;
    _module_functions[79].params = NULL;

    /* Function: nl_list_Token_length */
    _module_functions[80].name = "nl_list_Token_length";
    _module_functions[80].param_count = 0;
    _module_functions[80].return_type = 0;
    _module_functions[80].return_struct_type_name = NULL;
    _module_functions[80].return_fn_sig = NULL;
    _module_functions[80].return_type_info = NULL;
    _module_functions[80].body = NULL;
    _module_functions[80].shadow_test = NULL;
    _module_functions[80].is_extern = false;
    _module_functions[80].returns_gc_managed = false;
    _module_functions[80].requires_manual_free = false;
    _module_functions[80].returns_borrowed = false;
    _module_functions[80].cleanup_function = NULL;
    _module_functions[80].params = NULL;

    /* Function: nl_list_Token_capacity */
    _module_functions[81].name = "nl_list_Token_capacity";
    _module_functions[81].param_count = 0;
    _module_functions[81].return_type = 0;
    _module_functions[81].return_struct_type_name = NULL;
    _module_functions[81].return_fn_sig = NULL;
    _module_functions[81].return_type_info = NULL;
    _module_functions[81].body = NULL;
    _module_functions[81].shadow_test = NULL;
    _module_functions[81].is_extern = false;
    _module_functions[81].returns_gc_managed = false;
    _module_functions[81].requires_manual_free = false;
    _module_functions[81].returns_borrowed = false;
    _module_functions[81].cleanup_function = NULL;
    _module_functions[81].params = NULL;

    /* Function: nl_list_Token_is_empty */
    _module_functions[82].name = "nl_list_Token_is_empty";
    _module_functions[82].param_count = 0;
    _module_functions[82].return_type = 3;
    _module_functions[82].return_struct_type_name = NULL;
    _module_functions[82].return_fn_sig = NULL;
    _module_functions[82].return_type_info = NULL;
    _module_functions[82].body = NULL;
    _module_functions[82].shadow_test = NULL;
    _module_functions[82].is_extern = false;
    _module_functions[82].returns_gc_managed = false;
    _module_functions[82].requires_manual_free = false;
    _module_functions[82].returns_borrowed = false;
    _module_functions[82].cleanup_function = NULL;
    _module_functions[82].params = NULL;

    /* Function: nl_list_Token_clear */
    _module_functions[83].name = "nl_list_Token_clear";
    _module_functions[83].param_count = 0;
    _module_functions[83].return_type = 6;
    _module_functions[83].return_struct_type_name = NULL;
    _module_functions[83].return_fn_sig = NULL;
    _module_functions[83].return_type_info = NULL;
    _module_functions[83].body = NULL;
    _module_functions[83].shadow_test = NULL;
    _module_functions[83].is_extern = false;
    _module_functions[83].returns_gc_managed = false;
    _module_functions[83].requires_manual_free = false;
    _module_functions[83].returns_borrowed = false;
    _module_functions[83].cleanup_function = NULL;
    _module_functions[83].params = NULL;

    /* Function: nl_list_Token_free */
    _module_functions[84].name = "nl_list_Token_free";
    _module_functions[84].param_count = 0;
    _module_functions[84].return_type = 6;
    _module_functions[84].return_struct_type_name = NULL;
    _module_functions[84].return_fn_sig = NULL;
    _module_functions[84].return_type_info = NULL;
    _module_functions[84].body = NULL;
    _module_functions[84].shadow_test = NULL;
    _module_functions[84].is_extern = false;
    _module_functions[84].returns_gc_managed = false;
    _module_functions[84].requires_manual_free = false;
    _module_functions[84].returns_borrowed = false;
    _module_functions[84].cleanup_function = NULL;
    _module_functions[84].params = NULL;

    /* Function: List_CompilerDiagnostic_new */
    _module_functions[85].name = "List_CompilerDiagnostic_new";
    _module_functions[85].param_count = 0;
    _module_functions[85].return_type = 15;
    _module_functions[85].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[85].return_fn_sig = NULL;
    _module_functions[85].return_type_info = NULL;
    _module_functions[85].body = NULL;
    _module_functions[85].shadow_test = NULL;
    _module_functions[85].is_extern = true;
    _module_functions[85].returns_gc_managed = false;
    _module_functions[85].requires_manual_free = false;
    _module_functions[85].returns_borrowed = false;
    _module_functions[85].cleanup_function = NULL;
    _module_functions[85].params = NULL;

    /* Function: List_CompilerDiagnostic_push */
    _module_functions[86].name = "List_CompilerDiagnostic_push";
    _module_functions[86].param_count = 2;
    _module_functions[86].return_type = 6;
    _module_functions[86].return_struct_type_name = NULL;
    _module_functions[86].return_fn_sig = NULL;
    _module_functions[86].return_type_info = NULL;
    _module_functions[86].body = NULL;
    _module_functions[86].shadow_test = NULL;
    _module_functions[86].is_extern = true;
    _module_functions[86].returns_gc_managed = false;
    _module_functions[86].requires_manual_free = false;
    _module_functions[86].returns_borrowed = false;
    _module_functions[86].cleanup_function = NULL;
    _module_functions[86].params = &_module_params[0];
    _module_params[0].name = "list";
    _module_params[0].type = 15;
    _module_params[0].struct_type_name = "CompilerDiagnostic";
    _module_params[0].element_type = 21;
    _module_params[0].fn_sig = NULL;
    _module_params[1].name = "value";
    _module_params[1].type = 8;
    _module_params[1].struct_type_name = "CompilerDiagnostic";
    _module_params[1].element_type = 21;
    _module_params[1].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_get */
    _module_functions[87].name = "List_CompilerDiagnostic_get";
    _module_functions[87].param_count = 2;
    _module_functions[87].return_type = 8;
    _module_functions[87].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[87].return_fn_sig = NULL;
    _module_functions[87].return_type_info = NULL;
    _module_functions[87].body = NULL;
    _module_functions[87].shadow_test = NULL;
    _module_functions[87].is_extern = true;
    _module_functions[87].returns_gc_managed = false;
    _module_functions[87].requires_manual_free = false;
    _module_functions[87].returns_borrowed = false;
    _module_functions[87].cleanup_function = NULL;
    _module_functions[87].params = &_module_params[2];
    _module_params[2].name = "list";
    _module_params[2].type = 15;
    _module_params[2].struct_type_name = "CompilerDiagnostic";
    _module_params[2].element_type = 21;
    _module_params[2].fn_sig = NULL;
    _module_params[3].name = "index";
    _module_params[3].type = 0;
    _module_params[3].struct_type_name = NULL;
    _module_params[3].element_type = 21;
    _module_params[3].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_length */
    _module_functions[88].name = "List_CompilerDiagnostic_length";
    _module_functions[88].param_count = 1;
    _module_functions[88].return_type = 0;
    _module_functions[88].return_struct_type_name = NULL;
    _module_functions[88].return_fn_sig = NULL;
    _module_functions[88].return_type_info = NULL;
    _module_functions[88].body = NULL;
    _module_functions[88].shadow_test = NULL;
    _module_functions[88].is_extern = true;
    _module_functions[88].returns_gc_managed = false;
    _module_functions[88].requires_manual_free = false;
    _module_functions[88].returns_borrowed = false;
    _module_functions[88].cleanup_function = NULL;
    _module_functions[88].params = &_module_params[4];
    _module_params[4].name = "list";
    _module_params[4].type = 15;
    _module_params[4].struct_type_name = "CompilerDiagnostic";
    _module_params[4].element_type = 21;
    _module_params[4].fn_sig = NULL;

    /* Function: List_LexerToken_new */
    _module_functions[89].name = "List_LexerToken_new";
    _module_functions[89].param_count = 0;
    _module_functions[89].return_type = 15;
    _module_functions[89].return_struct_type_name = "LexerToken";
    _module_functions[89].return_fn_sig = NULL;
    _module_functions[89].return_type_info = NULL;
    _module_functions[89].body = NULL;
    _module_functions[89].shadow_test = NULL;
    _module_functions[89].is_extern = true;
    _module_functions[89].returns_gc_managed = false;
    _module_functions[89].requires_manual_free = false;
    _module_functions[89].returns_borrowed = false;
    _module_functions[89].cleanup_function = NULL;
    _module_functions[89].params = NULL;

    /* Function: List_LexerToken_push */
    _module_functions[90].name = "List_LexerToken_push";
    _module_functions[90].param_count = 2;
    _module_functions[90].return_type = 6;
    _module_functions[90].return_struct_type_name = NULL;
    _module_functions[90].return_fn_sig = NULL;
    _module_functions[90].return_type_info = NULL;
    _module_functions[90].body = NULL;
    _module_functions[90].shadow_test = NULL;
    _module_functions[90].is_extern = true;
    _module_functions[90].returns_gc_managed = false;
    _module_functions[90].requires_manual_free = false;
    _module_functions[90].returns_borrowed = false;
    _module_functions[90].cleanup_function = NULL;
    _module_functions[90].params = &_module_params[5];
    _module_params[5].name = "list";
    _module_params[5].type = 15;
    _module_params[5].struct_type_name = "LexerToken";
    _module_params[5].element_type = 21;
    _module_params[5].fn_sig = NULL;
    _module_params[6].name = "value";
    _module_params[6].type = 8;
    _module_params[6].struct_type_name = "LexerToken";
    _module_params[6].element_type = 21;
    _module_params[6].fn_sig = NULL;

    /* Function: List_LexerToken_get */
    _module_functions[91].name = "List_LexerToken_get";
    _module_functions[91].param_count = 2;
    _module_functions[91].return_type = 8;
    _module_functions[91].return_struct_type_name = "LexerToken";
    _module_functions[91].return_fn_sig = NULL;
    _module_functions[91].return_type_info = NULL;
    _module_functions[91].body = NULL;
    _module_functions[91].shadow_test = NULL;
    _module_functions[91].is_extern = true;
    _module_functions[91].returns_gc_managed = false;
    _module_functions[91].requires_manual_free = false;
    _module_functions[91].returns_borrowed = false;
    _module_functions[91].cleanup_function = NULL;
    _module_functions[91].params = &_module_params[7];
    _module_params[7].name = "list";
    _module_params[7].type = 15;
    _module_params[7].struct_type_name = "LexerToken";
    _module_params[7].element_type = 21;
    _module_params[7].fn_sig = NULL;
    _module_params[8].name = "index";
    _module_params[8].type = 0;
    _module_params[8].struct_type_name = NULL;
    _module_params[8].element_type = 21;
    _module_params[8].fn_sig = NULL;

    /* Function: List_LexerToken_length */
    _module_functions[92].name = "List_LexerToken_length";
    _module_functions[92].param_count = 1;
    _module_functions[92].return_type = 0;
    _module_functions[92].return_struct_type_name = NULL;
    _module_functions[92].return_fn_sig = NULL;
    _module_functions[92].return_type_info = NULL;
    _module_functions[92].body = NULL;
    _module_functions[92].shadow_test = NULL;
    _module_functions[92].is_extern = true;
    _module_functions[92].returns_gc_managed = false;
    _module_functions[92].requires_manual_free = false;
    _module_functions[92].returns_borrowed = false;
    _module_functions[92].cleanup_function = NULL;
    _module_functions[92].params = &_module_params[9];
    _module_params[9].name = "list";
    _module_params[9].type = 15;
    _module_params[9].struct_type_name = "LexerToken";
    _module_params[9].element_type = 21;
    _module_params[9].fn_sig = NULL;

    /* Function: List_ASTStmtRef_new */
    _module_functions[93].name = "List_ASTStmtRef_new";
    _module_functions[93].param_count = 0;
    _module_functions[93].return_type = 15;
    _module_functions[93].return_struct_type_name = "ASTStmtRef";
    _module_functions[93].return_fn_sig = NULL;
    _module_functions[93].return_type_info = NULL;
    _module_functions[93].body = NULL;
    _module_functions[93].shadow_test = NULL;
    _module_functions[93].is_extern = true;
    _module_functions[93].returns_gc_managed = false;
    _module_functions[93].requires_manual_free = false;
    _module_functions[93].returns_borrowed = false;
    _module_functions[93].cleanup_function = NULL;
    _module_functions[93].params = NULL;

    /* Function: List_ASTStmtRef_push */
    _module_functions[94].name = "List_ASTStmtRef_push";
    _module_functions[94].param_count = 2;
    _module_functions[94].return_type = 6;
    _module_functions[94].return_struct_type_name = NULL;
    _module_functions[94].return_fn_sig = NULL;
    _module_functions[94].return_type_info = NULL;
    _module_functions[94].body = NULL;
    _module_functions[94].shadow_test = NULL;
    _module_functions[94].is_extern = true;
    _module_functions[94].returns_gc_managed = false;
    _module_functions[94].requires_manual_free = false;
    _module_functions[94].returns_borrowed = false;
    _module_functions[94].cleanup_function = NULL;
    _module_functions[94].params = &_module_params[10];
    _module_params[10].name = "list";
    _module_params[10].type = 15;
    _module_params[10].struct_type_name = "ASTStmtRef";
    _module_params[10].element_type = 21;
    _module_params[10].fn_sig = NULL;
    _module_params[11].name = "value";
    _module_params[11].type = 8;
    _module_params[11].struct_type_name = "ASTStmtRef";
    _module_params[11].element_type = 21;
    _module_params[11].fn_sig = NULL;

    /* Function: List_ASTStmtRef_get */
    _module_functions[95].name = "List_ASTStmtRef_get";
    _module_functions[95].param_count = 2;
    _module_functions[95].return_type = 8;
    _module_functions[95].return_struct_type_name = "ASTStmtRef";
    _module_functions[95].return_fn_sig = NULL;
    _module_functions[95].return_type_info = NULL;
    _module_functions[95].body = NULL;
    _module_functions[95].shadow_test = NULL;
    _module_functions[95].is_extern = true;
    _module_functions[95].returns_gc_managed = false;
    _module_functions[95].requires_manual_free = false;
    _module_functions[95].returns_borrowed = false;
    _module_functions[95].cleanup_function = NULL;
    _module_functions[95].params = &_module_params[12];
    _module_params[12].name = "list";
    _module_params[12].type = 15;
    _module_params[12].struct_type_name = "ASTStmtRef";
    _module_params[12].element_type = 21;
    _module_params[12].fn_sig = NULL;
    _module_params[13].name = "index";
    _module_params[13].type = 0;
    _module_params[13].struct_type_name = NULL;
    _module_params[13].element_type = 21;
    _module_params[13].fn_sig = NULL;

    /* Function: List_ASTStmtRef_length */
    _module_functions[96].name = "List_ASTStmtRef_length";
    _module_functions[96].param_count = 1;
    _module_functions[96].return_type = 0;
    _module_functions[96].return_struct_type_name = NULL;
    _module_functions[96].return_fn_sig = NULL;
    _module_functions[96].return_type_info = NULL;
    _module_functions[96].body = NULL;
    _module_functions[96].shadow_test = NULL;
    _module_functions[96].is_extern = true;
    _module_functions[96].returns_gc_managed = false;
    _module_functions[96].requires_manual_free = false;
    _module_functions[96].returns_borrowed = false;
    _module_functions[96].cleanup_function = NULL;
    _module_functions[96].params = &_module_params[14];
    _module_params[14].name = "list";
    _module_params[14].type = 15;
    _module_params[14].struct_type_name = "ASTStmtRef";
    _module_params[14].element_type = 21;
    _module_params[14].fn_sig = NULL;

    /* Function: List_ASTNumber_new */
    _module_functions[97].name = "List_ASTNumber_new";
    _module_functions[97].param_count = 0;
    _module_functions[97].return_type = 15;
    _module_functions[97].return_struct_type_name = "ASTNumber";
    _module_functions[97].return_fn_sig = NULL;
    _module_functions[97].return_type_info = NULL;
    _module_functions[97].body = NULL;
    _module_functions[97].shadow_test = NULL;
    _module_functions[97].is_extern = true;
    _module_functions[97].returns_gc_managed = false;
    _module_functions[97].requires_manual_free = false;
    _module_functions[97].returns_borrowed = false;
    _module_functions[97].cleanup_function = NULL;
    _module_functions[97].params = NULL;

    /* Function: List_ASTNumber_push */
    _module_functions[98].name = "List_ASTNumber_push";
    _module_functions[98].param_count = 2;
    _module_functions[98].return_type = 6;
    _module_functions[98].return_struct_type_name = NULL;
    _module_functions[98].return_fn_sig = NULL;
    _module_functions[98].return_type_info = NULL;
    _module_functions[98].body = NULL;
    _module_functions[98].shadow_test = NULL;
    _module_functions[98].is_extern = true;
    _module_functions[98].returns_gc_managed = false;
    _module_functions[98].requires_manual_free = false;
    _module_functions[98].returns_borrowed = false;
    _module_functions[98].cleanup_function = NULL;
    _module_functions[98].params = &_module_params[15];
    _module_params[15].name = "list";
    _module_params[15].type = 15;
    _module_params[15].struct_type_name = "ASTNumber";
    _module_params[15].element_type = 21;
    _module_params[15].fn_sig = NULL;
    _module_params[16].name = "value";
    _module_params[16].type = 8;
    _module_params[16].struct_type_name = "ASTNumber";
    _module_params[16].element_type = 21;
    _module_params[16].fn_sig = NULL;

    /* Function: List_ASTNumber_get */
    _module_functions[99].name = "List_ASTNumber_get";
    _module_functions[99].param_count = 2;
    _module_functions[99].return_type = 8;
    _module_functions[99].return_struct_type_name = "ASTNumber";
    _module_functions[99].return_fn_sig = NULL;
    _module_functions[99].return_type_info = NULL;
    _module_functions[99].body = NULL;
    _module_functions[99].shadow_test = NULL;
    _module_functions[99].is_extern = true;
    _module_functions[99].returns_gc_managed = false;
    _module_functions[99].requires_manual_free = false;
    _module_functions[99].returns_borrowed = false;
    _module_functions[99].cleanup_function = NULL;
    _module_functions[99].params = &_module_params[17];
    _module_params[17].name = "list";
    _module_params[17].type = 15;
    _module_params[17].struct_type_name = "ASTNumber";
    _module_params[17].element_type = 21;
    _module_params[17].fn_sig = NULL;
    _module_params[18].name = "index";
    _module_params[18].type = 0;
    _module_params[18].struct_type_name = NULL;
    _module_params[18].element_type = 21;
    _module_params[18].fn_sig = NULL;

    /* Function: List_ASTNumber_length */
    _module_functions[100].name = "List_ASTNumber_length";
    _module_functions[100].param_count = 1;
    _module_functions[100].return_type = 0;
    _module_functions[100].return_struct_type_name = NULL;
    _module_functions[100].return_fn_sig = NULL;
    _module_functions[100].return_type_info = NULL;
    _module_functions[100].body = NULL;
    _module_functions[100].shadow_test = NULL;
    _module_functions[100].is_extern = true;
    _module_functions[100].returns_gc_managed = false;
    _module_functions[100].requires_manual_free = false;
    _module_functions[100].returns_borrowed = false;
    _module_functions[100].cleanup_function = NULL;
    _module_functions[100].params = &_module_params[19];
    _module_params[19].name = "list";
    _module_params[19].type = 15;
    _module_params[19].struct_type_name = "ASTNumber";
    _module_params[19].element_type = 21;
    _module_params[19].fn_sig = NULL;

    /* Function: List_ASTFloat_new */
    _module_functions[101].name = "List_ASTFloat_new";
    _module_functions[101].param_count = 0;
    _module_functions[101].return_type = 15;
    _module_functions[101].return_struct_type_name = "ASTFloat";
    _module_functions[101].return_fn_sig = NULL;
    _module_functions[101].return_type_info = NULL;
    _module_functions[101].body = NULL;
    _module_functions[101].shadow_test = NULL;
    _module_functions[101].is_extern = true;
    _module_functions[101].returns_gc_managed = false;
    _module_functions[101].requires_manual_free = false;
    _module_functions[101].returns_borrowed = false;
    _module_functions[101].cleanup_function = NULL;
    _module_functions[101].params = NULL;

    /* Function: List_ASTFloat_push */
    _module_functions[102].name = "List_ASTFloat_push";
    _module_functions[102].param_count = 2;
    _module_functions[102].return_type = 6;
    _module_functions[102].return_struct_type_name = NULL;
    _module_functions[102].return_fn_sig = NULL;
    _module_functions[102].return_type_info = NULL;
    _module_functions[102].body = NULL;
    _module_functions[102].shadow_test = NULL;
    _module_functions[102].is_extern = true;
    _module_functions[102].returns_gc_managed = false;
    _module_functions[102].requires_manual_free = false;
    _module_functions[102].returns_borrowed = false;
    _module_functions[102].cleanup_function = NULL;
    _module_functions[102].params = &_module_params[20];
    _module_params[20].name = "list";
    _module_params[20].type = 15;
    _module_params[20].struct_type_name = "ASTFloat";
    _module_params[20].element_type = 21;
    _module_params[20].fn_sig = NULL;
    _module_params[21].name = "value";
    _module_params[21].type = 8;
    _module_params[21].struct_type_name = "ASTFloat";
    _module_params[21].element_type = 21;
    _module_params[21].fn_sig = NULL;

    /* Function: List_ASTFloat_get */
    _module_functions[103].name = "List_ASTFloat_get";
    _module_functions[103].param_count = 2;
    _module_functions[103].return_type = 8;
    _module_functions[103].return_struct_type_name = "ASTFloat";
    _module_functions[103].return_fn_sig = NULL;
    _module_functions[103].return_type_info = NULL;
    _module_functions[103].body = NULL;
    _module_functions[103].shadow_test = NULL;
    _module_functions[103].is_extern = true;
    _module_functions[103].returns_gc_managed = false;
    _module_functions[103].requires_manual_free = false;
    _module_functions[103].returns_borrowed = false;
    _module_functions[103].cleanup_function = NULL;
    _module_functions[103].params = &_module_params[22];
    _module_params[22].name = "list";
    _module_params[22].type = 15;
    _module_params[22].struct_type_name = "ASTFloat";
    _module_params[22].element_type = 21;
    _module_params[22].fn_sig = NULL;
    _module_params[23].name = "index";
    _module_params[23].type = 0;
    _module_params[23].struct_type_name = NULL;
    _module_params[23].element_type = 21;
    _module_params[23].fn_sig = NULL;

    /* Function: List_ASTFloat_length */
    _module_functions[104].name = "List_ASTFloat_length";
    _module_functions[104].param_count = 1;
    _module_functions[104].return_type = 0;
    _module_functions[104].return_struct_type_name = NULL;
    _module_functions[104].return_fn_sig = NULL;
    _module_functions[104].return_type_info = NULL;
    _module_functions[104].body = NULL;
    _module_functions[104].shadow_test = NULL;
    _module_functions[104].is_extern = true;
    _module_functions[104].returns_gc_managed = false;
    _module_functions[104].requires_manual_free = false;
    _module_functions[104].returns_borrowed = false;
    _module_functions[104].cleanup_function = NULL;
    _module_functions[104].params = &_module_params[24];
    _module_params[24].name = "list";
    _module_params[24].type = 15;
    _module_params[24].struct_type_name = "ASTFloat";
    _module_params[24].element_type = 21;
    _module_params[24].fn_sig = NULL;

    /* Function: List_ASTString_new */
    _module_functions[105].name = "List_ASTString_new";
    _module_functions[105].param_count = 0;
    _module_functions[105].return_type = 15;
    _module_functions[105].return_struct_type_name = "ASTString";
    _module_functions[105].return_fn_sig = NULL;
    _module_functions[105].return_type_info = NULL;
    _module_functions[105].body = NULL;
    _module_functions[105].shadow_test = NULL;
    _module_functions[105].is_extern = true;
    _module_functions[105].returns_gc_managed = false;
    _module_functions[105].requires_manual_free = false;
    _module_functions[105].returns_borrowed = false;
    _module_functions[105].cleanup_function = NULL;
    _module_functions[105].params = NULL;

    /* Function: List_ASTString_push */
    _module_functions[106].name = "List_ASTString_push";
    _module_functions[106].param_count = 2;
    _module_functions[106].return_type = 6;
    _module_functions[106].return_struct_type_name = NULL;
    _module_functions[106].return_fn_sig = NULL;
    _module_functions[106].return_type_info = NULL;
    _module_functions[106].body = NULL;
    _module_functions[106].shadow_test = NULL;
    _module_functions[106].is_extern = true;
    _module_functions[106].returns_gc_managed = false;
    _module_functions[106].requires_manual_free = false;
    _module_functions[106].returns_borrowed = false;
    _module_functions[106].cleanup_function = NULL;
    _module_functions[106].params = &_module_params[25];
    _module_params[25].name = "list";
    _module_params[25].type = 15;
    _module_params[25].struct_type_name = "ASTString";
    _module_params[25].element_type = 21;
    _module_params[25].fn_sig = NULL;
    _module_params[26].name = "value";
    _module_params[26].type = 8;
    _module_params[26].struct_type_name = "ASTString";
    _module_params[26].element_type = 21;
    _module_params[26].fn_sig = NULL;

    /* Function: List_ASTString_get */
    _module_functions[107].name = "List_ASTString_get";
    _module_functions[107].param_count = 2;
    _module_functions[107].return_type = 8;
    _module_functions[107].return_struct_type_name = "ASTString";
    _module_functions[107].return_fn_sig = NULL;
    _module_functions[107].return_type_info = NULL;
    _module_functions[107].body = NULL;
    _module_functions[107].shadow_test = NULL;
    _module_functions[107].is_extern = true;
    _module_functions[107].returns_gc_managed = false;
    _module_functions[107].requires_manual_free = false;
    _module_functions[107].returns_borrowed = false;
    _module_functions[107].cleanup_function = NULL;
    _module_functions[107].params = &_module_params[27];
    _module_params[27].name = "list";
    _module_params[27].type = 15;
    _module_params[27].struct_type_name = "ASTString";
    _module_params[27].element_type = 21;
    _module_params[27].fn_sig = NULL;
    _module_params[28].name = "index";
    _module_params[28].type = 0;
    _module_params[28].struct_type_name = NULL;
    _module_params[28].element_type = 21;
    _module_params[28].fn_sig = NULL;

    /* Function: List_ASTString_length */
    _module_functions[108].name = "List_ASTString_length";
    _module_functions[108].param_count = 1;
    _module_functions[108].return_type = 0;
    _module_functions[108].return_struct_type_name = NULL;
    _module_functions[108].return_fn_sig = NULL;
    _module_functions[108].return_type_info = NULL;
    _module_functions[108].body = NULL;
    _module_functions[108].shadow_test = NULL;
    _module_functions[108].is_extern = true;
    _module_functions[108].returns_gc_managed = false;
    _module_functions[108].requires_manual_free = false;
    _module_functions[108].returns_borrowed = false;
    _module_functions[108].cleanup_function = NULL;
    _module_functions[108].params = &_module_params[29];
    _module_params[29].name = "list";
    _module_params[29].type = 15;
    _module_params[29].struct_type_name = "ASTString";
    _module_params[29].element_type = 21;
    _module_params[29].fn_sig = NULL;

    /* Function: List_ASTBool_new */
    _module_functions[109].name = "List_ASTBool_new";
    _module_functions[109].param_count = 0;
    _module_functions[109].return_type = 15;
    _module_functions[109].return_struct_type_name = "ASTBool";
    _module_functions[109].return_fn_sig = NULL;
    _module_functions[109].return_type_info = NULL;
    _module_functions[109].body = NULL;
    _module_functions[109].shadow_test = NULL;
    _module_functions[109].is_extern = true;
    _module_functions[109].returns_gc_managed = false;
    _module_functions[109].requires_manual_free = false;
    _module_functions[109].returns_borrowed = false;
    _module_functions[109].cleanup_function = NULL;
    _module_functions[109].params = NULL;

    /* Function: List_ASTBool_push */
    _module_functions[110].name = "List_ASTBool_push";
    _module_functions[110].param_count = 2;
    _module_functions[110].return_type = 6;
    _module_functions[110].return_struct_type_name = NULL;
    _module_functions[110].return_fn_sig = NULL;
    _module_functions[110].return_type_info = NULL;
    _module_functions[110].body = NULL;
    _module_functions[110].shadow_test = NULL;
    _module_functions[110].is_extern = true;
    _module_functions[110].returns_gc_managed = false;
    _module_functions[110].requires_manual_free = false;
    _module_functions[110].returns_borrowed = false;
    _module_functions[110].cleanup_function = NULL;
    _module_functions[110].params = &_module_params[30];
    _module_params[30].name = "list";
    _module_params[30].type = 15;
    _module_params[30].struct_type_name = "ASTBool";
    _module_params[30].element_type = 21;
    _module_params[30].fn_sig = NULL;
    _module_params[31].name = "value";
    _module_params[31].type = 8;
    _module_params[31].struct_type_name = "ASTBool";
    _module_params[31].element_type = 21;
    _module_params[31].fn_sig = NULL;

    /* Function: List_ASTBool_get */
    _module_functions[111].name = "List_ASTBool_get";
    _module_functions[111].param_count = 2;
    _module_functions[111].return_type = 8;
    _module_functions[111].return_struct_type_name = "ASTBool";
    _module_functions[111].return_fn_sig = NULL;
    _module_functions[111].return_type_info = NULL;
    _module_functions[111].body = NULL;
    _module_functions[111].shadow_test = NULL;
    _module_functions[111].is_extern = true;
    _module_functions[111].returns_gc_managed = false;
    _module_functions[111].requires_manual_free = false;
    _module_functions[111].returns_borrowed = false;
    _module_functions[111].cleanup_function = NULL;
    _module_functions[111].params = &_module_params[32];
    _module_params[32].name = "list";
    _module_params[32].type = 15;
    _module_params[32].struct_type_name = "ASTBool";
    _module_params[32].element_type = 21;
    _module_params[32].fn_sig = NULL;
    _module_params[33].name = "index";
    _module_params[33].type = 0;
    _module_params[33].struct_type_name = NULL;
    _module_params[33].element_type = 21;
    _module_params[33].fn_sig = NULL;

    /* Function: List_ASTBool_length */
    _module_functions[112].name = "List_ASTBool_length";
    _module_functions[112].param_count = 1;
    _module_functions[112].return_type = 0;
    _module_functions[112].return_struct_type_name = NULL;
    _module_functions[112].return_fn_sig = NULL;
    _module_functions[112].return_type_info = NULL;
    _module_functions[112].body = NULL;
    _module_functions[112].shadow_test = NULL;
    _module_functions[112].is_extern = true;
    _module_functions[112].returns_gc_managed = false;
    _module_functions[112].requires_manual_free = false;
    _module_functions[112].returns_borrowed = false;
    _module_functions[112].cleanup_function = NULL;
    _module_functions[112].params = &_module_params[34];
    _module_params[34].name = "list";
    _module_params[34].type = 15;
    _module_params[34].struct_type_name = "ASTBool";
    _module_params[34].element_type = 21;
    _module_params[34].fn_sig = NULL;

    /* Function: List_ASTIdentifier_new */
    _module_functions[113].name = "List_ASTIdentifier_new";
    _module_functions[113].param_count = 0;
    _module_functions[113].return_type = 15;
    _module_functions[113].return_struct_type_name = "ASTIdentifier";
    _module_functions[113].return_fn_sig = NULL;
    _module_functions[113].return_type_info = NULL;
    _module_functions[113].body = NULL;
    _module_functions[113].shadow_test = NULL;
    _module_functions[113].is_extern = true;
    _module_functions[113].returns_gc_managed = false;
    _module_functions[113].requires_manual_free = false;
    _module_functions[113].returns_borrowed = false;
    _module_functions[113].cleanup_function = NULL;
    _module_functions[113].params = NULL;

    /* Function: List_ASTIdentifier_push */
    _module_functions[114].name = "List_ASTIdentifier_push";
    _module_functions[114].param_count = 2;
    _module_functions[114].return_type = 6;
    _module_functions[114].return_struct_type_name = NULL;
    _module_functions[114].return_fn_sig = NULL;
    _module_functions[114].return_type_info = NULL;
    _module_functions[114].body = NULL;
    _module_functions[114].shadow_test = NULL;
    _module_functions[114].is_extern = true;
    _module_functions[114].returns_gc_managed = false;
    _module_functions[114].requires_manual_free = false;
    _module_functions[114].returns_borrowed = false;
    _module_functions[114].cleanup_function = NULL;
    _module_functions[114].params = &_module_params[35];
    _module_params[35].name = "list";
    _module_params[35].type = 15;
    _module_params[35].struct_type_name = "ASTIdentifier";
    _module_params[35].element_type = 21;
    _module_params[35].fn_sig = NULL;
    _module_params[36].name = "value";
    _module_params[36].type = 8;
    _module_params[36].struct_type_name = "ASTIdentifier";
    _module_params[36].element_type = 21;
    _module_params[36].fn_sig = NULL;

    /* Function: List_ASTIdentifier_get */
    _module_functions[115].name = "List_ASTIdentifier_get";
    _module_functions[115].param_count = 2;
    _module_functions[115].return_type = 8;
    _module_functions[115].return_struct_type_name = "ASTIdentifier";
    _module_functions[115].return_fn_sig = NULL;
    _module_functions[115].return_type_info = NULL;
    _module_functions[115].body = NULL;
    _module_functions[115].shadow_test = NULL;
    _module_functions[115].is_extern = true;
    _module_functions[115].returns_gc_managed = false;
    _module_functions[115].requires_manual_free = false;
    _module_functions[115].returns_borrowed = false;
    _module_functions[115].cleanup_function = NULL;
    _module_functions[115].params = &_module_params[37];
    _module_params[37].name = "list";
    _module_params[37].type = 15;
    _module_params[37].struct_type_name = "ASTIdentifier";
    _module_params[37].element_type = 21;
    _module_params[37].fn_sig = NULL;
    _module_params[38].name = "index";
    _module_params[38].type = 0;
    _module_params[38].struct_type_name = NULL;
    _module_params[38].element_type = 21;
    _module_params[38].fn_sig = NULL;

    /* Function: List_ASTIdentifier_length */
    _module_functions[116].name = "List_ASTIdentifier_length";
    _module_functions[116].param_count = 1;
    _module_functions[116].return_type = 0;
    _module_functions[116].return_struct_type_name = NULL;
    _module_functions[116].return_fn_sig = NULL;
    _module_functions[116].return_type_info = NULL;
    _module_functions[116].body = NULL;
    _module_functions[116].shadow_test = NULL;
    _module_functions[116].is_extern = true;
    _module_functions[116].returns_gc_managed = false;
    _module_functions[116].requires_manual_free = false;
    _module_functions[116].returns_borrowed = false;
    _module_functions[116].cleanup_function = NULL;
    _module_functions[116].params = &_module_params[39];
    _module_params[39].name = "list";
    _module_params[39].type = 15;
    _module_params[39].struct_type_name = "ASTIdentifier";
    _module_params[39].element_type = 21;
    _module_params[39].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_new */
    _module_functions[117].name = "List_ASTBinaryOp_new";
    _module_functions[117].param_count = 0;
    _module_functions[117].return_type = 15;
    _module_functions[117].return_struct_type_name = "ASTBinaryOp";
    _module_functions[117].return_fn_sig = NULL;
    _module_functions[117].return_type_info = NULL;
    _module_functions[117].body = NULL;
    _module_functions[117].shadow_test = NULL;
    _module_functions[117].is_extern = true;
    _module_functions[117].returns_gc_managed = false;
    _module_functions[117].requires_manual_free = false;
    _module_functions[117].returns_borrowed = false;
    _module_functions[117].cleanup_function = NULL;
    _module_functions[117].params = NULL;

    /* Function: List_ASTBinaryOp_push */
    _module_functions[118].name = "List_ASTBinaryOp_push";
    _module_functions[118].param_count = 2;
    _module_functions[118].return_type = 6;
    _module_functions[118].return_struct_type_name = NULL;
    _module_functions[118].return_fn_sig = NULL;
    _module_functions[118].return_type_info = NULL;
    _module_functions[118].body = NULL;
    _module_functions[118].shadow_test = NULL;
    _module_functions[118].is_extern = true;
    _module_functions[118].returns_gc_managed = false;
    _module_functions[118].requires_manual_free = false;
    _module_functions[118].returns_borrowed = false;
    _module_functions[118].cleanup_function = NULL;
    _module_functions[118].params = &_module_params[40];
    _module_params[40].name = "list";
    _module_params[40].type = 15;
    _module_params[40].struct_type_name = "ASTBinaryOp";
    _module_params[40].element_type = 21;
    _module_params[40].fn_sig = NULL;
    _module_params[41].name = "value";
    _module_params[41].type = 8;
    _module_params[41].struct_type_name = "ASTBinaryOp";
    _module_params[41].element_type = 21;
    _module_params[41].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_get */
    _module_functions[119].name = "List_ASTBinaryOp_get";
    _module_functions[119].param_count = 2;
    _module_functions[119].return_type = 8;
    _module_functions[119].return_struct_type_name = "ASTBinaryOp";
    _module_functions[119].return_fn_sig = NULL;
    _module_functions[119].return_type_info = NULL;
    _module_functions[119].body = NULL;
    _module_functions[119].shadow_test = NULL;
    _module_functions[119].is_extern = true;
    _module_functions[119].returns_gc_managed = false;
    _module_functions[119].requires_manual_free = false;
    _module_functions[119].returns_borrowed = false;
    _module_functions[119].cleanup_function = NULL;
    _module_functions[119].params = &_module_params[42];
    _module_params[42].name = "list";
    _module_params[42].type = 15;
    _module_params[42].struct_type_name = "ASTBinaryOp";
    _module_params[42].element_type = 21;
    _module_params[42].fn_sig = NULL;
    _module_params[43].name = "index";
    _module_params[43].type = 0;
    _module_params[43].struct_type_name = NULL;
    _module_params[43].element_type = 21;
    _module_params[43].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_length */
    _module_functions[120].name = "List_ASTBinaryOp_length";
    _module_functions[120].param_count = 1;
    _module_functions[120].return_type = 0;
    _module_functions[120].return_struct_type_name = NULL;
    _module_functions[120].return_fn_sig = NULL;
    _module_functions[120].return_type_info = NULL;
    _module_functions[120].body = NULL;
    _module_functions[120].shadow_test = NULL;
    _module_functions[120].is_extern = true;
    _module_functions[120].returns_gc_managed = false;
    _module_functions[120].requires_manual_free = false;
    _module_functions[120].returns_borrowed = false;
    _module_functions[120].cleanup_function = NULL;
    _module_functions[120].params = &_module_params[44];
    _module_params[44].name = "list";
    _module_params[44].type = 15;
    _module_params[44].struct_type_name = "ASTBinaryOp";
    _module_params[44].element_type = 21;
    _module_params[44].fn_sig = NULL;

    /* Function: List_ASTCall_new */
    _module_functions[121].name = "List_ASTCall_new";
    _module_functions[121].param_count = 0;
    _module_functions[121].return_type = 15;
    _module_functions[121].return_struct_type_name = "ASTCall";
    _module_functions[121].return_fn_sig = NULL;
    _module_functions[121].return_type_info = NULL;
    _module_functions[121].body = NULL;
    _module_functions[121].shadow_test = NULL;
    _module_functions[121].is_extern = true;
    _module_functions[121].returns_gc_managed = false;
    _module_functions[121].requires_manual_free = false;
    _module_functions[121].returns_borrowed = false;
    _module_functions[121].cleanup_function = NULL;
    _module_functions[121].params = NULL;

    /* Function: List_ASTCall_push */
    _module_functions[122].name = "List_ASTCall_push";
    _module_functions[122].param_count = 2;
    _module_functions[122].return_type = 6;
    _module_functions[122].return_struct_type_name = NULL;
    _module_functions[122].return_fn_sig = NULL;
    _module_functions[122].return_type_info = NULL;
    _module_functions[122].body = NULL;
    _module_functions[122].shadow_test = NULL;
    _module_functions[122].is_extern = true;
    _module_functions[122].returns_gc_managed = false;
    _module_functions[122].requires_manual_free = false;
    _module_functions[122].returns_borrowed = false;
    _module_functions[122].cleanup_function = NULL;
    _module_functions[122].params = &_module_params[45];
    _module_params[45].name = "list";
    _module_params[45].type = 15;
    _module_params[45].struct_type_name = "ASTCall";
    _module_params[45].element_type = 21;
    _module_params[45].fn_sig = NULL;
    _module_params[46].name = "value";
    _module_params[46].type = 8;
    _module_params[46].struct_type_name = "ASTCall";
    _module_params[46].element_type = 21;
    _module_params[46].fn_sig = NULL;

    /* Function: List_ASTCall_get */
    _module_functions[123].name = "List_ASTCall_get";
    _module_functions[123].param_count = 2;
    _module_functions[123].return_type = 8;
    _module_functions[123].return_struct_type_name = "ASTCall";
    _module_functions[123].return_fn_sig = NULL;
    _module_functions[123].return_type_info = NULL;
    _module_functions[123].body = NULL;
    _module_functions[123].shadow_test = NULL;
    _module_functions[123].is_extern = true;
    _module_functions[123].returns_gc_managed = false;
    _module_functions[123].requires_manual_free = false;
    _module_functions[123].returns_borrowed = false;
    _module_functions[123].cleanup_function = NULL;
    _module_functions[123].params = &_module_params[47];
    _module_params[47].name = "list";
    _module_params[47].type = 15;
    _module_params[47].struct_type_name = "ASTCall";
    _module_params[47].element_type = 21;
    _module_params[47].fn_sig = NULL;
    _module_params[48].name = "index";
    _module_params[48].type = 0;
    _module_params[48].struct_type_name = NULL;
    _module_params[48].element_type = 21;
    _module_params[48].fn_sig = NULL;

    /* Function: List_ASTCall_length */
    _module_functions[124].name = "List_ASTCall_length";
    _module_functions[124].param_count = 1;
    _module_functions[124].return_type = 0;
    _module_functions[124].return_struct_type_name = NULL;
    _module_functions[124].return_fn_sig = NULL;
    _module_functions[124].return_type_info = NULL;
    _module_functions[124].body = NULL;
    _module_functions[124].shadow_test = NULL;
    _module_functions[124].is_extern = true;
    _module_functions[124].returns_gc_managed = false;
    _module_functions[124].requires_manual_free = false;
    _module_functions[124].returns_borrowed = false;
    _module_functions[124].cleanup_function = NULL;
    _module_functions[124].params = &_module_params[49];
    _module_params[49].name = "list";
    _module_params[49].type = 15;
    _module_params[49].struct_type_name = "ASTCall";
    _module_params[49].element_type = 21;
    _module_params[49].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_new */
    _module_functions[125].name = "List_ASTModuleQualifiedCall_new";
    _module_functions[125].param_count = 0;
    _module_functions[125].return_type = 15;
    _module_functions[125].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[125].return_fn_sig = NULL;
    _module_functions[125].return_type_info = NULL;
    _module_functions[125].body = NULL;
    _module_functions[125].shadow_test = NULL;
    _module_functions[125].is_extern = true;
    _module_functions[125].returns_gc_managed = false;
    _module_functions[125].requires_manual_free = false;
    _module_functions[125].returns_borrowed = false;
    _module_functions[125].cleanup_function = NULL;
    _module_functions[125].params = NULL;

    /* Function: List_ASTModuleQualifiedCall_push */
    _module_functions[126].name = "List_ASTModuleQualifiedCall_push";
    _module_functions[126].param_count = 2;
    _module_functions[126].return_type = 6;
    _module_functions[126].return_struct_type_name = NULL;
    _module_functions[126].return_fn_sig = NULL;
    _module_functions[126].return_type_info = NULL;
    _module_functions[126].body = NULL;
    _module_functions[126].shadow_test = NULL;
    _module_functions[126].is_extern = true;
    _module_functions[126].returns_gc_managed = false;
    _module_functions[126].requires_manual_free = false;
    _module_functions[126].returns_borrowed = false;
    _module_functions[126].cleanup_function = NULL;
    _module_functions[126].params = &_module_params[50];
    _module_params[50].name = "list";
    _module_params[50].type = 15;
    _module_params[50].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[50].element_type = 21;
    _module_params[50].fn_sig = NULL;
    _module_params[51].name = "value";
    _module_params[51].type = 8;
    _module_params[51].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[51].element_type = 21;
    _module_params[51].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_get */
    _module_functions[127].name = "List_ASTModuleQualifiedCall_get";
    _module_functions[127].param_count = 2;
    _module_functions[127].return_type = 8;
    _module_functions[127].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[127].return_fn_sig = NULL;
    _module_functions[127].return_type_info = NULL;
    _module_functions[127].body = NULL;
    _module_functions[127].shadow_test = NULL;
    _module_functions[127].is_extern = true;
    _module_functions[127].returns_gc_managed = false;
    _module_functions[127].requires_manual_free = false;
    _module_functions[127].returns_borrowed = false;
    _module_functions[127].cleanup_function = NULL;
    _module_functions[127].params = &_module_params[52];
    _module_params[52].name = "list";
    _module_params[52].type = 15;
    _module_params[52].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[52].element_type = 21;
    _module_params[52].fn_sig = NULL;
    _module_params[53].name = "index";
    _module_params[53].type = 0;
    _module_params[53].struct_type_name = NULL;
    _module_params[53].element_type = 21;
    _module_params[53].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_length */
    _module_functions[128].name = "List_ASTModuleQualifiedCall_length";
    _module_functions[128].param_count = 1;
    _module_functions[128].return_type = 0;
    _module_functions[128].return_struct_type_name = NULL;
    _module_functions[128].return_fn_sig = NULL;
    _module_functions[128].return_type_info = NULL;
    _module_functions[128].body = NULL;
    _module_functions[128].shadow_test = NULL;
    _module_functions[128].is_extern = true;
    _module_functions[128].returns_gc_managed = false;
    _module_functions[128].requires_manual_free = false;
    _module_functions[128].returns_borrowed = false;
    _module_functions[128].cleanup_function = NULL;
    _module_functions[128].params = &_module_params[54];
    _module_params[54].name = "list";
    _module_params[54].type = 15;
    _module_params[54].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[54].element_type = 21;
    _module_params[54].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_new */
    _module_functions[129].name = "List_ASTArrayLiteral_new";
    _module_functions[129].param_count = 0;
    _module_functions[129].return_type = 15;
    _module_functions[129].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[129].return_fn_sig = NULL;
    _module_functions[129].return_type_info = NULL;
    _module_functions[129].body = NULL;
    _module_functions[129].shadow_test = NULL;
    _module_functions[129].is_extern = true;
    _module_functions[129].returns_gc_managed = false;
    _module_functions[129].requires_manual_free = false;
    _module_functions[129].returns_borrowed = false;
    _module_functions[129].cleanup_function = NULL;
    _module_functions[129].params = NULL;

    /* Function: List_ASTArrayLiteral_push */
    _module_functions[130].name = "List_ASTArrayLiteral_push";
    _module_functions[130].param_count = 2;
    _module_functions[130].return_type = 6;
    _module_functions[130].return_struct_type_name = NULL;
    _module_functions[130].return_fn_sig = NULL;
    _module_functions[130].return_type_info = NULL;
    _module_functions[130].body = NULL;
    _module_functions[130].shadow_test = NULL;
    _module_functions[130].is_extern = true;
    _module_functions[130].returns_gc_managed = false;
    _module_functions[130].requires_manual_free = false;
    _module_functions[130].returns_borrowed = false;
    _module_functions[130].cleanup_function = NULL;
    _module_functions[130].params = &_module_params[55];
    _module_params[55].name = "list";
    _module_params[55].type = 15;
    _module_params[55].struct_type_name = "ASTArrayLiteral";
    _module_params[55].element_type = 21;
    _module_params[55].fn_sig = NULL;
    _module_params[56].name = "value";
    _module_params[56].type = 8;
    _module_params[56].struct_type_name = "ASTArrayLiteral";
    _module_params[56].element_type = 21;
    _module_params[56].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_get */
    _module_functions[131].name = "List_ASTArrayLiteral_get";
    _module_functions[131].param_count = 2;
    _module_functions[131].return_type = 8;
    _module_functions[131].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[131].return_fn_sig = NULL;
    _module_functions[131].return_type_info = NULL;
    _module_functions[131].body = NULL;
    _module_functions[131].shadow_test = NULL;
    _module_functions[131].is_extern = true;
    _module_functions[131].returns_gc_managed = false;
    _module_functions[131].requires_manual_free = false;
    _module_functions[131].returns_borrowed = false;
    _module_functions[131].cleanup_function = NULL;
    _module_functions[131].params = &_module_params[57];
    _module_params[57].name = "list";
    _module_params[57].type = 15;
    _module_params[57].struct_type_name = "ASTArrayLiteral";
    _module_params[57].element_type = 21;
    _module_params[57].fn_sig = NULL;
    _module_params[58].name = "index";
    _module_params[58].type = 0;
    _module_params[58].struct_type_name = NULL;
    _module_params[58].element_type = 21;
    _module_params[58].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_length */
    _module_functions[132].name = "List_ASTArrayLiteral_length";
    _module_functions[132].param_count = 1;
    _module_functions[132].return_type = 0;
    _module_functions[132].return_struct_type_name = NULL;
    _module_functions[132].return_fn_sig = NULL;
    _module_functions[132].return_type_info = NULL;
    _module_functions[132].body = NULL;
    _module_functions[132].shadow_test = NULL;
    _module_functions[132].is_extern = true;
    _module_functions[132].returns_gc_managed = false;
    _module_functions[132].requires_manual_free = false;
    _module_functions[132].returns_borrowed = false;
    _module_functions[132].cleanup_function = NULL;
    _module_functions[132].params = &_module_params[59];
    _module_params[59].name = "list";
    _module_params[59].type = 15;
    _module_params[59].struct_type_name = "ASTArrayLiteral";
    _module_params[59].element_type = 21;
    _module_params[59].fn_sig = NULL;

    /* Function: List_ASTLet_new */
    _module_functions[133].name = "List_ASTLet_new";
    _module_functions[133].param_count = 0;
    _module_functions[133].return_type = 15;
    _module_functions[133].return_struct_type_name = "ASTLet";
    _module_functions[133].return_fn_sig = NULL;
    _module_functions[133].return_type_info = NULL;
    _module_functions[133].body = NULL;
    _module_functions[133].shadow_test = NULL;
    _module_functions[133].is_extern = true;
    _module_functions[133].returns_gc_managed = false;
    _module_functions[133].requires_manual_free = false;
    _module_functions[133].returns_borrowed = false;
    _module_functions[133].cleanup_function = NULL;
    _module_functions[133].params = NULL;

    /* Function: List_ASTLet_push */
    _module_functions[134].name = "List_ASTLet_push";
    _module_functions[134].param_count = 2;
    _module_functions[134].return_type = 6;
    _module_functions[134].return_struct_type_name = NULL;
    _module_functions[134].return_fn_sig = NULL;
    _module_functions[134].return_type_info = NULL;
    _module_functions[134].body = NULL;
    _module_functions[134].shadow_test = NULL;
    _module_functions[134].is_extern = true;
    _module_functions[134].returns_gc_managed = false;
    _module_functions[134].requires_manual_free = false;
    _module_functions[134].returns_borrowed = false;
    _module_functions[134].cleanup_function = NULL;
    _module_functions[134].params = &_module_params[60];
    _module_params[60].name = "list";
    _module_params[60].type = 15;
    _module_params[60].struct_type_name = "ASTLet";
    _module_params[60].element_type = 21;
    _module_params[60].fn_sig = NULL;
    _module_params[61].name = "value";
    _module_params[61].type = 8;
    _module_params[61].struct_type_name = "ASTLet";
    _module_params[61].element_type = 21;
    _module_params[61].fn_sig = NULL;

    /* Function: List_ASTLet_get */
    _module_functions[135].name = "List_ASTLet_get";
    _module_functions[135].param_count = 2;
    _module_functions[135].return_type = 8;
    _module_functions[135].return_struct_type_name = "ASTLet";
    _module_functions[135].return_fn_sig = NULL;
    _module_functions[135].return_type_info = NULL;
    _module_functions[135].body = NULL;
    _module_functions[135].shadow_test = NULL;
    _module_functions[135].is_extern = true;
    _module_functions[135].returns_gc_managed = false;
    _module_functions[135].requires_manual_free = false;
    _module_functions[135].returns_borrowed = false;
    _module_functions[135].cleanup_function = NULL;
    _module_functions[135].params = &_module_params[62];
    _module_params[62].name = "list";
    _module_params[62].type = 15;
    _module_params[62].struct_type_name = "ASTLet";
    _module_params[62].element_type = 21;
    _module_params[62].fn_sig = NULL;
    _module_params[63].name = "index";
    _module_params[63].type = 0;
    _module_params[63].struct_type_name = NULL;
    _module_params[63].element_type = 21;
    _module_params[63].fn_sig = NULL;

    /* Function: List_ASTLet_length */
    _module_functions[136].name = "List_ASTLet_length";
    _module_functions[136].param_count = 1;
    _module_functions[136].return_type = 0;
    _module_functions[136].return_struct_type_name = NULL;
    _module_functions[136].return_fn_sig = NULL;
    _module_functions[136].return_type_info = NULL;
    _module_functions[136].body = NULL;
    _module_functions[136].shadow_test = NULL;
    _module_functions[136].is_extern = true;
    _module_functions[136].returns_gc_managed = false;
    _module_functions[136].requires_manual_free = false;
    _module_functions[136].returns_borrowed = false;
    _module_functions[136].cleanup_function = NULL;
    _module_functions[136].params = &_module_params[64];
    _module_params[64].name = "list";
    _module_params[64].type = 15;
    _module_params[64].struct_type_name = "ASTLet";
    _module_params[64].element_type = 21;
    _module_params[64].fn_sig = NULL;

    /* Function: List_ASTSet_new */
    _module_functions[137].name = "List_ASTSet_new";
    _module_functions[137].param_count = 0;
    _module_functions[137].return_type = 15;
    _module_functions[137].return_struct_type_name = "ASTSet";
    _module_functions[137].return_fn_sig = NULL;
    _module_functions[137].return_type_info = NULL;
    _module_functions[137].body = NULL;
    _module_functions[137].shadow_test = NULL;
    _module_functions[137].is_extern = true;
    _module_functions[137].returns_gc_managed = false;
    _module_functions[137].requires_manual_free = false;
    _module_functions[137].returns_borrowed = false;
    _module_functions[137].cleanup_function = NULL;
    _module_functions[137].params = NULL;

    /* Function: List_ASTSet_push */
    _module_functions[138].name = "List_ASTSet_push";
    _module_functions[138].param_count = 2;
    _module_functions[138].return_type = 6;
    _module_functions[138].return_struct_type_name = NULL;
    _module_functions[138].return_fn_sig = NULL;
    _module_functions[138].return_type_info = NULL;
    _module_functions[138].body = NULL;
    _module_functions[138].shadow_test = NULL;
    _module_functions[138].is_extern = true;
    _module_functions[138].returns_gc_managed = false;
    _module_functions[138].requires_manual_free = false;
    _module_functions[138].returns_borrowed = false;
    _module_functions[138].cleanup_function = NULL;
    _module_functions[138].params = &_module_params[65];
    _module_params[65].name = "list";
    _module_params[65].type = 15;
    _module_params[65].struct_type_name = "ASTSet";
    _module_params[65].element_type = 21;
    _module_params[65].fn_sig = NULL;
    _module_params[66].name = "value";
    _module_params[66].type = 8;
    _module_params[66].struct_type_name = "ASTSet";
    _module_params[66].element_type = 21;
    _module_params[66].fn_sig = NULL;

    /* Function: List_ASTSet_get */
    _module_functions[139].name = "List_ASTSet_get";
    _module_functions[139].param_count = 2;
    _module_functions[139].return_type = 8;
    _module_functions[139].return_struct_type_name = "ASTSet";
    _module_functions[139].return_fn_sig = NULL;
    _module_functions[139].return_type_info = NULL;
    _module_functions[139].body = NULL;
    _module_functions[139].shadow_test = NULL;
    _module_functions[139].is_extern = true;
    _module_functions[139].returns_gc_managed = false;
    _module_functions[139].requires_manual_free = false;
    _module_functions[139].returns_borrowed = false;
    _module_functions[139].cleanup_function = NULL;
    _module_functions[139].params = &_module_params[67];
    _module_params[67].name = "list";
    _module_params[67].type = 15;
    _module_params[67].struct_type_name = "ASTSet";
    _module_params[67].element_type = 21;
    _module_params[67].fn_sig = NULL;
    _module_params[68].name = "index";
    _module_params[68].type = 0;
    _module_params[68].struct_type_name = NULL;
    _module_params[68].element_type = 21;
    _module_params[68].fn_sig = NULL;

    /* Function: List_ASTSet_length */
    _module_functions[140].name = "List_ASTSet_length";
    _module_functions[140].param_count = 1;
    _module_functions[140].return_type = 0;
    _module_functions[140].return_struct_type_name = NULL;
    _module_functions[140].return_fn_sig = NULL;
    _module_functions[140].return_type_info = NULL;
    _module_functions[140].body = NULL;
    _module_functions[140].shadow_test = NULL;
    _module_functions[140].is_extern = true;
    _module_functions[140].returns_gc_managed = false;
    _module_functions[140].requires_manual_free = false;
    _module_functions[140].returns_borrowed = false;
    _module_functions[140].cleanup_function = NULL;
    _module_functions[140].params = &_module_params[69];
    _module_params[69].name = "list";
    _module_params[69].type = 15;
    _module_params[69].struct_type_name = "ASTSet";
    _module_params[69].element_type = 21;
    _module_params[69].fn_sig = NULL;

    /* Function: List_ASTIf_new */
    _module_functions[141].name = "List_ASTIf_new";
    _module_functions[141].param_count = 0;
    _module_functions[141].return_type = 15;
    _module_functions[141].return_struct_type_name = "ASTIf";
    _module_functions[141].return_fn_sig = NULL;
    _module_functions[141].return_type_info = NULL;
    _module_functions[141].body = NULL;
    _module_functions[141].shadow_test = NULL;
    _module_functions[141].is_extern = true;
    _module_functions[141].returns_gc_managed = false;
    _module_functions[141].requires_manual_free = false;
    _module_functions[141].returns_borrowed = false;
    _module_functions[141].cleanup_function = NULL;
    _module_functions[141].params = NULL;

    /* Function: List_ASTIf_push */
    _module_functions[142].name = "List_ASTIf_push";
    _module_functions[142].param_count = 2;
    _module_functions[142].return_type = 6;
    _module_functions[142].return_struct_type_name = NULL;
    _module_functions[142].return_fn_sig = NULL;
    _module_functions[142].return_type_info = NULL;
    _module_functions[142].body = NULL;
    _module_functions[142].shadow_test = NULL;
    _module_functions[142].is_extern = true;
    _module_functions[142].returns_gc_managed = false;
    _module_functions[142].requires_manual_free = false;
    _module_functions[142].returns_borrowed = false;
    _module_functions[142].cleanup_function = NULL;
    _module_functions[142].params = &_module_params[70];
    _module_params[70].name = "list";
    _module_params[70].type = 15;
    _module_params[70].struct_type_name = "ASTIf";
    _module_params[70].element_type = 21;
    _module_params[70].fn_sig = NULL;
    _module_params[71].name = "value";
    _module_params[71].type = 8;
    _module_params[71].struct_type_name = "ASTIf";
    _module_params[71].element_type = 21;
    _module_params[71].fn_sig = NULL;

    /* Function: List_ASTIf_get */
    _module_functions[143].name = "List_ASTIf_get";
    _module_functions[143].param_count = 2;
    _module_functions[143].return_type = 8;
    _module_functions[143].return_struct_type_name = "ASTIf";
    _module_functions[143].return_fn_sig = NULL;
    _module_functions[143].return_type_info = NULL;
    _module_functions[143].body = NULL;
    _module_functions[143].shadow_test = NULL;
    _module_functions[143].is_extern = true;
    _module_functions[143].returns_gc_managed = false;
    _module_functions[143].requires_manual_free = false;
    _module_functions[143].returns_borrowed = false;
    _module_functions[143].cleanup_function = NULL;
    _module_functions[143].params = &_module_params[72];
    _module_params[72].name = "list";
    _module_params[72].type = 15;
    _module_params[72].struct_type_name = "ASTIf";
    _module_params[72].element_type = 21;
    _module_params[72].fn_sig = NULL;
    _module_params[73].name = "index";
    _module_params[73].type = 0;
    _module_params[73].struct_type_name = NULL;
    _module_params[73].element_type = 21;
    _module_params[73].fn_sig = NULL;

    /* Function: List_ASTIf_length */
    _module_functions[144].name = "List_ASTIf_length";
    _module_functions[144].param_count = 1;
    _module_functions[144].return_type = 0;
    _module_functions[144].return_struct_type_name = NULL;
    _module_functions[144].return_fn_sig = NULL;
    _module_functions[144].return_type_info = NULL;
    _module_functions[144].body = NULL;
    _module_functions[144].shadow_test = NULL;
    _module_functions[144].is_extern = true;
    _module_functions[144].returns_gc_managed = false;
    _module_functions[144].requires_manual_free = false;
    _module_functions[144].returns_borrowed = false;
    _module_functions[144].cleanup_function = NULL;
    _module_functions[144].params = &_module_params[74];
    _module_params[74].name = "list";
    _module_params[74].type = 15;
    _module_params[74].struct_type_name = "ASTIf";
    _module_params[74].element_type = 21;
    _module_params[74].fn_sig = NULL;

    /* Function: List_ASTWhile_new */
    _module_functions[145].name = "List_ASTWhile_new";
    _module_functions[145].param_count = 0;
    _module_functions[145].return_type = 15;
    _module_functions[145].return_struct_type_name = "ASTWhile";
    _module_functions[145].return_fn_sig = NULL;
    _module_functions[145].return_type_info = NULL;
    _module_functions[145].body = NULL;
    _module_functions[145].shadow_test = NULL;
    _module_functions[145].is_extern = true;
    _module_functions[145].returns_gc_managed = false;
    _module_functions[145].requires_manual_free = false;
    _module_functions[145].returns_borrowed = false;
    _module_functions[145].cleanup_function = NULL;
    _module_functions[145].params = NULL;

    /* Function: List_ASTWhile_push */
    _module_functions[146].name = "List_ASTWhile_push";
    _module_functions[146].param_count = 2;
    _module_functions[146].return_type = 6;
    _module_functions[146].return_struct_type_name = NULL;
    _module_functions[146].return_fn_sig = NULL;
    _module_functions[146].return_type_info = NULL;
    _module_functions[146].body = NULL;
    _module_functions[146].shadow_test = NULL;
    _module_functions[146].is_extern = true;
    _module_functions[146].returns_gc_managed = false;
    _module_functions[146].requires_manual_free = false;
    _module_functions[146].returns_borrowed = false;
    _module_functions[146].cleanup_function = NULL;
    _module_functions[146].params = &_module_params[75];
    _module_params[75].name = "list";
    _module_params[75].type = 15;
    _module_params[75].struct_type_name = "ASTWhile";
    _module_params[75].element_type = 21;
    _module_params[75].fn_sig = NULL;
    _module_params[76].name = "value";
    _module_params[76].type = 8;
    _module_params[76].struct_type_name = "ASTWhile";
    _module_params[76].element_type = 21;
    _module_params[76].fn_sig = NULL;

    /* Function: List_ASTWhile_get */
    _module_functions[147].name = "List_ASTWhile_get";
    _module_functions[147].param_count = 2;
    _module_functions[147].return_type = 8;
    _module_functions[147].return_struct_type_name = "ASTWhile";
    _module_functions[147].return_fn_sig = NULL;
    _module_functions[147].return_type_info = NULL;
    _module_functions[147].body = NULL;
    _module_functions[147].shadow_test = NULL;
    _module_functions[147].is_extern = true;
    _module_functions[147].returns_gc_managed = false;
    _module_functions[147].requires_manual_free = false;
    _module_functions[147].returns_borrowed = false;
    _module_functions[147].cleanup_function = NULL;
    _module_functions[147].params = &_module_params[77];
    _module_params[77].name = "list";
    _module_params[77].type = 15;
    _module_params[77].struct_type_name = "ASTWhile";
    _module_params[77].element_type = 21;
    _module_params[77].fn_sig = NULL;
    _module_params[78].name = "index";
    _module_params[78].type = 0;
    _module_params[78].struct_type_name = NULL;
    _module_params[78].element_type = 21;
    _module_params[78].fn_sig = NULL;

    /* Function: List_ASTWhile_length */
    _module_functions[148].name = "List_ASTWhile_length";
    _module_functions[148].param_count = 1;
    _module_functions[148].return_type = 0;
    _module_functions[148].return_struct_type_name = NULL;
    _module_functions[148].return_fn_sig = NULL;
    _module_functions[148].return_type_info = NULL;
    _module_functions[148].body = NULL;
    _module_functions[148].shadow_test = NULL;
    _module_functions[148].is_extern = true;
    _module_functions[148].returns_gc_managed = false;
    _module_functions[148].requires_manual_free = false;
    _module_functions[148].returns_borrowed = false;
    _module_functions[148].cleanup_function = NULL;
    _module_functions[148].params = &_module_params[79];
    _module_params[79].name = "list";
    _module_params[79].type = 15;
    _module_params[79].struct_type_name = "ASTWhile";
    _module_params[79].element_type = 21;
    _module_params[79].fn_sig = NULL;

    /* Function: List_ASTFor_new */
    _module_functions[149].name = "List_ASTFor_new";
    _module_functions[149].param_count = 0;
    _module_functions[149].return_type = 15;
    _module_functions[149].return_struct_type_name = "ASTFor";
    _module_functions[149].return_fn_sig = NULL;
    _module_functions[149].return_type_info = NULL;
    _module_functions[149].body = NULL;
    _module_functions[149].shadow_test = NULL;
    _module_functions[149].is_extern = true;
    _module_functions[149].returns_gc_managed = false;
    _module_functions[149].requires_manual_free = false;
    _module_functions[149].returns_borrowed = false;
    _module_functions[149].cleanup_function = NULL;
    _module_functions[149].params = NULL;

    /* Function: List_ASTFor_push */
    _module_functions[150].name = "List_ASTFor_push";
    _module_functions[150].param_count = 2;
    _module_functions[150].return_type = 6;
    _module_functions[150].return_struct_type_name = NULL;
    _module_functions[150].return_fn_sig = NULL;
    _module_functions[150].return_type_info = NULL;
    _module_functions[150].body = NULL;
    _module_functions[150].shadow_test = NULL;
    _module_functions[150].is_extern = true;
    _module_functions[150].returns_gc_managed = false;
    _module_functions[150].requires_manual_free = false;
    _module_functions[150].returns_borrowed = false;
    _module_functions[150].cleanup_function = NULL;
    _module_functions[150].params = &_module_params[80];
    _module_params[80].name = "list";
    _module_params[80].type = 15;
    _module_params[80].struct_type_name = "ASTFor";
    _module_params[80].element_type = 21;
    _module_params[80].fn_sig = NULL;
    _module_params[81].name = "value";
    _module_params[81].type = 8;
    _module_params[81].struct_type_name = "ASTFor";
    _module_params[81].element_type = 21;
    _module_params[81].fn_sig = NULL;

    /* Function: List_ASTFor_get */
    _module_functions[151].name = "List_ASTFor_get";
    _module_functions[151].param_count = 2;
    _module_functions[151].return_type = 8;
    _module_functions[151].return_struct_type_name = "ASTFor";
    _module_functions[151].return_fn_sig = NULL;
    _module_functions[151].return_type_info = NULL;
    _module_functions[151].body = NULL;
    _module_functions[151].shadow_test = NULL;
    _module_functions[151].is_extern = true;
    _module_functions[151].returns_gc_managed = false;
    _module_functions[151].requires_manual_free = false;
    _module_functions[151].returns_borrowed = false;
    _module_functions[151].cleanup_function = NULL;
    _module_functions[151].params = &_module_params[82];
    _module_params[82].name = "list";
    _module_params[82].type = 15;
    _module_params[82].struct_type_name = "ASTFor";
    _module_params[82].element_type = 21;
    _module_params[82].fn_sig = NULL;
    _module_params[83].name = "index";
    _module_params[83].type = 0;
    _module_params[83].struct_type_name = NULL;
    _module_params[83].element_type = 21;
    _module_params[83].fn_sig = NULL;

    /* Function: List_ASTFor_length */
    _module_functions[152].name = "List_ASTFor_length";
    _module_functions[152].param_count = 1;
    _module_functions[152].return_type = 0;
    _module_functions[152].return_struct_type_name = NULL;
    _module_functions[152].return_fn_sig = NULL;
    _module_functions[152].return_type_info = NULL;
    _module_functions[152].body = NULL;
    _module_functions[152].shadow_test = NULL;
    _module_functions[152].is_extern = true;
    _module_functions[152].returns_gc_managed = false;
    _module_functions[152].requires_manual_free = false;
    _module_functions[152].returns_borrowed = false;
    _module_functions[152].cleanup_function = NULL;
    _module_functions[152].params = &_module_params[84];
    _module_params[84].name = "list";
    _module_params[84].type = 15;
    _module_params[84].struct_type_name = "ASTFor";
    _module_params[84].element_type = 21;
    _module_params[84].fn_sig = NULL;

    /* Function: List_ASTReturn_new */
    _module_functions[153].name = "List_ASTReturn_new";
    _module_functions[153].param_count = 0;
    _module_functions[153].return_type = 15;
    _module_functions[153].return_struct_type_name = "ASTReturn";
    _module_functions[153].return_fn_sig = NULL;
    _module_functions[153].return_type_info = NULL;
    _module_functions[153].body = NULL;
    _module_functions[153].shadow_test = NULL;
    _module_functions[153].is_extern = true;
    _module_functions[153].returns_gc_managed = false;
    _module_functions[153].requires_manual_free = false;
    _module_functions[153].returns_borrowed = false;
    _module_functions[153].cleanup_function = NULL;
    _module_functions[153].params = NULL;

    /* Function: List_ASTReturn_push */
    _module_functions[154].name = "List_ASTReturn_push";
    _module_functions[154].param_count = 2;
    _module_functions[154].return_type = 6;
    _module_functions[154].return_struct_type_name = NULL;
    _module_functions[154].return_fn_sig = NULL;
    _module_functions[154].return_type_info = NULL;
    _module_functions[154].body = NULL;
    _module_functions[154].shadow_test = NULL;
    _module_functions[154].is_extern = true;
    _module_functions[154].returns_gc_managed = false;
    _module_functions[154].requires_manual_free = false;
    _module_functions[154].returns_borrowed = false;
    _module_functions[154].cleanup_function = NULL;
    _module_functions[154].params = &_module_params[85];
    _module_params[85].name = "list";
    _module_params[85].type = 15;
    _module_params[85].struct_type_name = "ASTReturn";
    _module_params[85].element_type = 21;
    _module_params[85].fn_sig = NULL;
    _module_params[86].name = "value";
    _module_params[86].type = 8;
    _module_params[86].struct_type_name = "ASTReturn";
    _module_params[86].element_type = 21;
    _module_params[86].fn_sig = NULL;

    /* Function: List_ASTReturn_get */
    _module_functions[155].name = "List_ASTReturn_get";
    _module_functions[155].param_count = 2;
    _module_functions[155].return_type = 8;
    _module_functions[155].return_struct_type_name = "ASTReturn";
    _module_functions[155].return_fn_sig = NULL;
    _module_functions[155].return_type_info = NULL;
    _module_functions[155].body = NULL;
    _module_functions[155].shadow_test = NULL;
    _module_functions[155].is_extern = true;
    _module_functions[155].returns_gc_managed = false;
    _module_functions[155].requires_manual_free = false;
    _module_functions[155].returns_borrowed = false;
    _module_functions[155].cleanup_function = NULL;
    _module_functions[155].params = &_module_params[87];
    _module_params[87].name = "list";
    _module_params[87].type = 15;
    _module_params[87].struct_type_name = "ASTReturn";
    _module_params[87].element_type = 21;
    _module_params[87].fn_sig = NULL;
    _module_params[88].name = "index";
    _module_params[88].type = 0;
    _module_params[88].struct_type_name = NULL;
    _module_params[88].element_type = 21;
    _module_params[88].fn_sig = NULL;

    /* Function: List_ASTReturn_length */
    _module_functions[156].name = "List_ASTReturn_length";
    _module_functions[156].param_count = 1;
    _module_functions[156].return_type = 0;
    _module_functions[156].return_struct_type_name = NULL;
    _module_functions[156].return_fn_sig = NULL;
    _module_functions[156].return_type_info = NULL;
    _module_functions[156].body = NULL;
    _module_functions[156].shadow_test = NULL;
    _module_functions[156].is_extern = true;
    _module_functions[156].returns_gc_managed = false;
    _module_functions[156].requires_manual_free = false;
    _module_functions[156].returns_borrowed = false;
    _module_functions[156].cleanup_function = NULL;
    _module_functions[156].params = &_module_params[89];
    _module_params[89].name = "list";
    _module_params[89].type = 15;
    _module_params[89].struct_type_name = "ASTReturn";
    _module_params[89].element_type = 21;
    _module_params[89].fn_sig = NULL;

    /* Function: List_ASTBlock_new */
    _module_functions[157].name = "List_ASTBlock_new";
    _module_functions[157].param_count = 0;
    _module_functions[157].return_type = 15;
    _module_functions[157].return_struct_type_name = "ASTBlock";
    _module_functions[157].return_fn_sig = NULL;
    _module_functions[157].return_type_info = NULL;
    _module_functions[157].body = NULL;
    _module_functions[157].shadow_test = NULL;
    _module_functions[157].is_extern = true;
    _module_functions[157].returns_gc_managed = false;
    _module_functions[157].requires_manual_free = false;
    _module_functions[157].returns_borrowed = false;
    _module_functions[157].cleanup_function = NULL;
    _module_functions[157].params = NULL;

    /* Function: List_ASTBlock_push */
    _module_functions[158].name = "List_ASTBlock_push";
    _module_functions[158].param_count = 2;
    _module_functions[158].return_type = 6;
    _module_functions[158].return_struct_type_name = NULL;
    _module_functions[158].return_fn_sig = NULL;
    _module_functions[158].return_type_info = NULL;
    _module_functions[158].body = NULL;
    _module_functions[158].shadow_test = NULL;
    _module_functions[158].is_extern = true;
    _module_functions[158].returns_gc_managed = false;
    _module_functions[158].requires_manual_free = false;
    _module_functions[158].returns_borrowed = false;
    _module_functions[158].cleanup_function = NULL;
    _module_functions[158].params = &_module_params[90];
    _module_params[90].name = "list";
    _module_params[90].type = 15;
    _module_params[90].struct_type_name = "ASTBlock";
    _module_params[90].element_type = 21;
    _module_params[90].fn_sig = NULL;
    _module_params[91].name = "value";
    _module_params[91].type = 8;
    _module_params[91].struct_type_name = "ASTBlock";
    _module_params[91].element_type = 21;
    _module_params[91].fn_sig = NULL;

    /* Function: List_ASTBlock_get */
    _module_functions[159].name = "List_ASTBlock_get";
    _module_functions[159].param_count = 2;
    _module_functions[159].return_type = 8;
    _module_functions[159].return_struct_type_name = "ASTBlock";
    _module_functions[159].return_fn_sig = NULL;
    _module_functions[159].return_type_info = NULL;
    _module_functions[159].body = NULL;
    _module_functions[159].shadow_test = NULL;
    _module_functions[159].is_extern = true;
    _module_functions[159].returns_gc_managed = false;
    _module_functions[159].requires_manual_free = false;
    _module_functions[159].returns_borrowed = false;
    _module_functions[159].cleanup_function = NULL;
    _module_functions[159].params = &_module_params[92];
    _module_params[92].name = "list";
    _module_params[92].type = 15;
    _module_params[92].struct_type_name = "ASTBlock";
    _module_params[92].element_type = 21;
    _module_params[92].fn_sig = NULL;
    _module_params[93].name = "index";
    _module_params[93].type = 0;
    _module_params[93].struct_type_name = NULL;
    _module_params[93].element_type = 21;
    _module_params[93].fn_sig = NULL;

    /* Function: List_ASTBlock_length */
    _module_functions[160].name = "List_ASTBlock_length";
    _module_functions[160].param_count = 1;
    _module_functions[160].return_type = 0;
    _module_functions[160].return_struct_type_name = NULL;
    _module_functions[160].return_fn_sig = NULL;
    _module_functions[160].return_type_info = NULL;
    _module_functions[160].body = NULL;
    _module_functions[160].shadow_test = NULL;
    _module_functions[160].is_extern = true;
    _module_functions[160].returns_gc_managed = false;
    _module_functions[160].requires_manual_free = false;
    _module_functions[160].returns_borrowed = false;
    _module_functions[160].cleanup_function = NULL;
    _module_functions[160].params = &_module_params[94];
    _module_params[94].name = "list";
    _module_params[94].type = 15;
    _module_params[94].struct_type_name = "ASTBlock";
    _module_params[94].element_type = 21;
    _module_params[94].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_new */
    _module_functions[161].name = "List_ASTUnsafeBlock_new";
    _module_functions[161].param_count = 0;
    _module_functions[161].return_type = 15;
    _module_functions[161].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[161].return_fn_sig = NULL;
    _module_functions[161].return_type_info = NULL;
    _module_functions[161].body = NULL;
    _module_functions[161].shadow_test = NULL;
    _module_functions[161].is_extern = true;
    _module_functions[161].returns_gc_managed = false;
    _module_functions[161].requires_manual_free = false;
    _module_functions[161].returns_borrowed = false;
    _module_functions[161].cleanup_function = NULL;
    _module_functions[161].params = NULL;

    /* Function: List_ASTUnsafeBlock_push */
    _module_functions[162].name = "List_ASTUnsafeBlock_push";
    _module_functions[162].param_count = 2;
    _module_functions[162].return_type = 6;
    _module_functions[162].return_struct_type_name = NULL;
    _module_functions[162].return_fn_sig = NULL;
    _module_functions[162].return_type_info = NULL;
    _module_functions[162].body = NULL;
    _module_functions[162].shadow_test = NULL;
    _module_functions[162].is_extern = true;
    _module_functions[162].returns_gc_managed = false;
    _module_functions[162].requires_manual_free = false;
    _module_functions[162].returns_borrowed = false;
    _module_functions[162].cleanup_function = NULL;
    _module_functions[162].params = &_module_params[95];
    _module_params[95].name = "list";
    _module_params[95].type = 15;
    _module_params[95].struct_type_name = "ASTUnsafeBlock";
    _module_params[95].element_type = 21;
    _module_params[95].fn_sig = NULL;
    _module_params[96].name = "value";
    _module_params[96].type = 8;
    _module_params[96].struct_type_name = "ASTUnsafeBlock";
    _module_params[96].element_type = 21;
    _module_params[96].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_get */
    _module_functions[163].name = "List_ASTUnsafeBlock_get";
    _module_functions[163].param_count = 2;
    _module_functions[163].return_type = 8;
    _module_functions[163].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[163].return_fn_sig = NULL;
    _module_functions[163].return_type_info = NULL;
    _module_functions[163].body = NULL;
    _module_functions[163].shadow_test = NULL;
    _module_functions[163].is_extern = true;
    _module_functions[163].returns_gc_managed = false;
    _module_functions[163].requires_manual_free = false;
    _module_functions[163].returns_borrowed = false;
    _module_functions[163].cleanup_function = NULL;
    _module_functions[163].params = &_module_params[97];
    _module_params[97].name = "list";
    _module_params[97].type = 15;
    _module_params[97].struct_type_name = "ASTUnsafeBlock";
    _module_params[97].element_type = 21;
    _module_params[97].fn_sig = NULL;
    _module_params[98].name = "index";
    _module_params[98].type = 0;
    _module_params[98].struct_type_name = NULL;
    _module_params[98].element_type = 21;
    _module_params[98].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_length */
    _module_functions[164].name = "List_ASTUnsafeBlock_length";
    _module_functions[164].param_count = 1;
    _module_functions[164].return_type = 0;
    _module_functions[164].return_struct_type_name = NULL;
    _module_functions[164].return_fn_sig = NULL;
    _module_functions[164].return_type_info = NULL;
    _module_functions[164].body = NULL;
    _module_functions[164].shadow_test = NULL;
    _module_functions[164].is_extern = true;
    _module_functions[164].returns_gc_managed = false;
    _module_functions[164].requires_manual_free = false;
    _module_functions[164].returns_borrowed = false;
    _module_functions[164].cleanup_function = NULL;
    _module_functions[164].params = &_module_params[99];
    _module_params[99].name = "list";
    _module_params[99].type = 15;
    _module_params[99].struct_type_name = "ASTUnsafeBlock";
    _module_params[99].element_type = 21;
    _module_params[99].fn_sig = NULL;

    /* Function: List_ASTPrint_new */
    _module_functions[165].name = "List_ASTPrint_new";
    _module_functions[165].param_count = 0;
    _module_functions[165].return_type = 15;
    _module_functions[165].return_struct_type_name = "ASTPrint";
    _module_functions[165].return_fn_sig = NULL;
    _module_functions[165].return_type_info = NULL;
    _module_functions[165].body = NULL;
    _module_functions[165].shadow_test = NULL;
    _module_functions[165].is_extern = true;
    _module_functions[165].returns_gc_managed = false;
    _module_functions[165].requires_manual_free = false;
    _module_functions[165].returns_borrowed = false;
    _module_functions[165].cleanup_function = NULL;
    _module_functions[165].params = NULL;

    /* Function: List_ASTPrint_push */
    _module_functions[166].name = "List_ASTPrint_push";
    _module_functions[166].param_count = 2;
    _module_functions[166].return_type = 6;
    _module_functions[166].return_struct_type_name = NULL;
    _module_functions[166].return_fn_sig = NULL;
    _module_functions[166].return_type_info = NULL;
    _module_functions[166].body = NULL;
    _module_functions[166].shadow_test = NULL;
    _module_functions[166].is_extern = true;
    _module_functions[166].returns_gc_managed = false;
    _module_functions[166].requires_manual_free = false;
    _module_functions[166].returns_borrowed = false;
    _module_functions[166].cleanup_function = NULL;
    _module_functions[166].params = &_module_params[100];
    _module_params[100].name = "list";
    _module_params[100].type = 15;
    _module_params[100].struct_type_name = "ASTPrint";
    _module_params[100].element_type = 21;
    _module_params[100].fn_sig = NULL;
    _module_params[101].name = "value";
    _module_params[101].type = 8;
    _module_params[101].struct_type_name = "ASTPrint";
    _module_params[101].element_type = 21;
    _module_params[101].fn_sig = NULL;

    /* Function: List_ASTPrint_get */
    _module_functions[167].name = "List_ASTPrint_get";
    _module_functions[167].param_count = 2;
    _module_functions[167].return_type = 8;
    _module_functions[167].return_struct_type_name = "ASTPrint";
    _module_functions[167].return_fn_sig = NULL;
    _module_functions[167].return_type_info = NULL;
    _module_functions[167].body = NULL;
    _module_functions[167].shadow_test = NULL;
    _module_functions[167].is_extern = true;
    _module_functions[167].returns_gc_managed = false;
    _module_functions[167].requires_manual_free = false;
    _module_functions[167].returns_borrowed = false;
    _module_functions[167].cleanup_function = NULL;
    _module_functions[167].params = &_module_params[102];
    _module_params[102].name = "list";
    _module_params[102].type = 15;
    _module_params[102].struct_type_name = "ASTPrint";
    _module_params[102].element_type = 21;
    _module_params[102].fn_sig = NULL;
    _module_params[103].name = "index";
    _module_params[103].type = 0;
    _module_params[103].struct_type_name = NULL;
    _module_params[103].element_type = 21;
    _module_params[103].fn_sig = NULL;

    /* Function: List_ASTPrint_length */
    _module_functions[168].name = "List_ASTPrint_length";
    _module_functions[168].param_count = 1;
    _module_functions[168].return_type = 0;
    _module_functions[168].return_struct_type_name = NULL;
    _module_functions[168].return_fn_sig = NULL;
    _module_functions[168].return_type_info = NULL;
    _module_functions[168].body = NULL;
    _module_functions[168].shadow_test = NULL;
    _module_functions[168].is_extern = true;
    _module_functions[168].returns_gc_managed = false;
    _module_functions[168].requires_manual_free = false;
    _module_functions[168].returns_borrowed = false;
    _module_functions[168].cleanup_function = NULL;
    _module_functions[168].params = &_module_params[104];
    _module_params[104].name = "list";
    _module_params[104].type = 15;
    _module_params[104].struct_type_name = "ASTPrint";
    _module_params[104].element_type = 21;
    _module_params[104].fn_sig = NULL;

    /* Function: List_ASTAssert_new */
    _module_functions[169].name = "List_ASTAssert_new";
    _module_functions[169].param_count = 0;
    _module_functions[169].return_type = 15;
    _module_functions[169].return_struct_type_name = "ASTAssert";
    _module_functions[169].return_fn_sig = NULL;
    _module_functions[169].return_type_info = NULL;
    _module_functions[169].body = NULL;
    _module_functions[169].shadow_test = NULL;
    _module_functions[169].is_extern = true;
    _module_functions[169].returns_gc_managed = false;
    _module_functions[169].requires_manual_free = false;
    _module_functions[169].returns_borrowed = false;
    _module_functions[169].cleanup_function = NULL;
    _module_functions[169].params = NULL;

    /* Function: List_ASTAssert_push */
    _module_functions[170].name = "List_ASTAssert_push";
    _module_functions[170].param_count = 2;
    _module_functions[170].return_type = 6;
    _module_functions[170].return_struct_type_name = NULL;
    _module_functions[170].return_fn_sig = NULL;
    _module_functions[170].return_type_info = NULL;
    _module_functions[170].body = NULL;
    _module_functions[170].shadow_test = NULL;
    _module_functions[170].is_extern = true;
    _module_functions[170].returns_gc_managed = false;
    _module_functions[170].requires_manual_free = false;
    _module_functions[170].returns_borrowed = false;
    _module_functions[170].cleanup_function = NULL;
    _module_functions[170].params = &_module_params[105];
    _module_params[105].name = "list";
    _module_params[105].type = 15;
    _module_params[105].struct_type_name = "ASTAssert";
    _module_params[105].element_type = 21;
    _module_params[105].fn_sig = NULL;
    _module_params[106].name = "value";
    _module_params[106].type = 8;
    _module_params[106].struct_type_name = "ASTAssert";
    _module_params[106].element_type = 21;
    _module_params[106].fn_sig = NULL;

    /* Function: List_ASTAssert_get */
    _module_functions[171].name = "List_ASTAssert_get";
    _module_functions[171].param_count = 2;
    _module_functions[171].return_type = 8;
    _module_functions[171].return_struct_type_name = "ASTAssert";
    _module_functions[171].return_fn_sig = NULL;
    _module_functions[171].return_type_info = NULL;
    _module_functions[171].body = NULL;
    _module_functions[171].shadow_test = NULL;
    _module_functions[171].is_extern = true;
    _module_functions[171].returns_gc_managed = false;
    _module_functions[171].requires_manual_free = false;
    _module_functions[171].returns_borrowed = false;
    _module_functions[171].cleanup_function = NULL;
    _module_functions[171].params = &_module_params[107];
    _module_params[107].name = "list";
    _module_params[107].type = 15;
    _module_params[107].struct_type_name = "ASTAssert";
    _module_params[107].element_type = 21;
    _module_params[107].fn_sig = NULL;
    _module_params[108].name = "index";
    _module_params[108].type = 0;
    _module_params[108].struct_type_name = NULL;
    _module_params[108].element_type = 21;
    _module_params[108].fn_sig = NULL;

    /* Function: List_ASTAssert_length */
    _module_functions[172].name = "List_ASTAssert_length";
    _module_functions[172].param_count = 1;
    _module_functions[172].return_type = 0;
    _module_functions[172].return_struct_type_name = NULL;
    _module_functions[172].return_fn_sig = NULL;
    _module_functions[172].return_type_info = NULL;
    _module_functions[172].body = NULL;
    _module_functions[172].shadow_test = NULL;
    _module_functions[172].is_extern = true;
    _module_functions[172].returns_gc_managed = false;
    _module_functions[172].requires_manual_free = false;
    _module_functions[172].returns_borrowed = false;
    _module_functions[172].cleanup_function = NULL;
    _module_functions[172].params = &_module_params[109];
    _module_params[109].name = "list";
    _module_params[109].type = 15;
    _module_params[109].struct_type_name = "ASTAssert";
    _module_params[109].element_type = 21;
    _module_params[109].fn_sig = NULL;

    /* Function: List_ASTFunction_new */
    _module_functions[173].name = "List_ASTFunction_new";
    _module_functions[173].param_count = 0;
    _module_functions[173].return_type = 15;
    _module_functions[173].return_struct_type_name = "ASTFunction";
    _module_functions[173].return_fn_sig = NULL;
    _module_functions[173].return_type_info = NULL;
    _module_functions[173].body = NULL;
    _module_functions[173].shadow_test = NULL;
    _module_functions[173].is_extern = true;
    _module_functions[173].returns_gc_managed = false;
    _module_functions[173].requires_manual_free = false;
    _module_functions[173].returns_borrowed = false;
    _module_functions[173].cleanup_function = NULL;
    _module_functions[173].params = NULL;

    /* Function: List_ASTFunction_push */
    _module_functions[174].name = "List_ASTFunction_push";
    _module_functions[174].param_count = 2;
    _module_functions[174].return_type = 6;
    _module_functions[174].return_struct_type_name = NULL;
    _module_functions[174].return_fn_sig = NULL;
    _module_functions[174].return_type_info = NULL;
    _module_functions[174].body = NULL;
    _module_functions[174].shadow_test = NULL;
    _module_functions[174].is_extern = true;
    _module_functions[174].returns_gc_managed = false;
    _module_functions[174].requires_manual_free = false;
    _module_functions[174].returns_borrowed = false;
    _module_functions[174].cleanup_function = NULL;
    _module_functions[174].params = &_module_params[110];
    _module_params[110].name = "list";
    _module_params[110].type = 15;
    _module_params[110].struct_type_name = "ASTFunction";
    _module_params[110].element_type = 21;
    _module_params[110].fn_sig = NULL;
    _module_params[111].name = "value";
    _module_params[111].type = 8;
    _module_params[111].struct_type_name = "ASTFunction";
    _module_params[111].element_type = 21;
    _module_params[111].fn_sig = NULL;

    /* Function: List_ASTFunction_get */
    _module_functions[175].name = "List_ASTFunction_get";
    _module_functions[175].param_count = 2;
    _module_functions[175].return_type = 8;
    _module_functions[175].return_struct_type_name = "ASTFunction";
    _module_functions[175].return_fn_sig = NULL;
    _module_functions[175].return_type_info = NULL;
    _module_functions[175].body = NULL;
    _module_functions[175].shadow_test = NULL;
    _module_functions[175].is_extern = true;
    _module_functions[175].returns_gc_managed = false;
    _module_functions[175].requires_manual_free = false;
    _module_functions[175].returns_borrowed = false;
    _module_functions[175].cleanup_function = NULL;
    _module_functions[175].params = &_module_params[112];
    _module_params[112].name = "list";
    _module_params[112].type = 15;
    _module_params[112].struct_type_name = "ASTFunction";
    _module_params[112].element_type = 21;
    _module_params[112].fn_sig = NULL;
    _module_params[113].name = "index";
    _module_params[113].type = 0;
    _module_params[113].struct_type_name = NULL;
    _module_params[113].element_type = 21;
    _module_params[113].fn_sig = NULL;

    /* Function: List_ASTFunction_length */
    _module_functions[176].name = "List_ASTFunction_length";
    _module_functions[176].param_count = 1;
    _module_functions[176].return_type = 0;
    _module_functions[176].return_struct_type_name = NULL;
    _module_functions[176].return_fn_sig = NULL;
    _module_functions[176].return_type_info = NULL;
    _module_functions[176].body = NULL;
    _module_functions[176].shadow_test = NULL;
    _module_functions[176].is_extern = true;
    _module_functions[176].returns_gc_managed = false;
    _module_functions[176].requires_manual_free = false;
    _module_functions[176].returns_borrowed = false;
    _module_functions[176].cleanup_function = NULL;
    _module_functions[176].params = &_module_params[114];
    _module_params[114].name = "list";
    _module_params[114].type = 15;
    _module_params[114].struct_type_name = "ASTFunction";
    _module_params[114].element_type = 21;
    _module_params[114].fn_sig = NULL;

    /* Function: List_ASTShadow_new */
    _module_functions[177].name = "List_ASTShadow_new";
    _module_functions[177].param_count = 0;
    _module_functions[177].return_type = 15;
    _module_functions[177].return_struct_type_name = "ASTShadow";
    _module_functions[177].return_fn_sig = NULL;
    _module_functions[177].return_type_info = NULL;
    _module_functions[177].body = NULL;
    _module_functions[177].shadow_test = NULL;
    _module_functions[177].is_extern = true;
    _module_functions[177].returns_gc_managed = false;
    _module_functions[177].requires_manual_free = false;
    _module_functions[177].returns_borrowed = false;
    _module_functions[177].cleanup_function = NULL;
    _module_functions[177].params = NULL;

    /* Function: List_ASTShadow_push */
    _module_functions[178].name = "List_ASTShadow_push";
    _module_functions[178].param_count = 2;
    _module_functions[178].return_type = 6;
    _module_functions[178].return_struct_type_name = NULL;
    _module_functions[178].return_fn_sig = NULL;
    _module_functions[178].return_type_info = NULL;
    _module_functions[178].body = NULL;
    _module_functions[178].shadow_test = NULL;
    _module_functions[178].is_extern = true;
    _module_functions[178].returns_gc_managed = false;
    _module_functions[178].requires_manual_free = false;
    _module_functions[178].returns_borrowed = false;
    _module_functions[178].cleanup_function = NULL;
    _module_functions[178].params = &_module_params[115];
    _module_params[115].name = "list";
    _module_params[115].type = 15;
    _module_params[115].struct_type_name = "ASTShadow";
    _module_params[115].element_type = 21;
    _module_params[115].fn_sig = NULL;
    _module_params[116].name = "value";
    _module_params[116].type = 8;
    _module_params[116].struct_type_name = "ASTShadow";
    _module_params[116].element_type = 21;
    _module_params[116].fn_sig = NULL;

    /* Function: List_ASTShadow_get */
    _module_functions[179].name = "List_ASTShadow_get";
    _module_functions[179].param_count = 2;
    _module_functions[179].return_type = 8;
    _module_functions[179].return_struct_type_name = "ASTShadow";
    _module_functions[179].return_fn_sig = NULL;
    _module_functions[179].return_type_info = NULL;
    _module_functions[179].body = NULL;
    _module_functions[179].shadow_test = NULL;
    _module_functions[179].is_extern = true;
    _module_functions[179].returns_gc_managed = false;
    _module_functions[179].requires_manual_free = false;
    _module_functions[179].returns_borrowed = false;
    _module_functions[179].cleanup_function = NULL;
    _module_functions[179].params = &_module_params[117];
    _module_params[117].name = "list";
    _module_params[117].type = 15;
    _module_params[117].struct_type_name = "ASTShadow";
    _module_params[117].element_type = 21;
    _module_params[117].fn_sig = NULL;
    _module_params[118].name = "index";
    _module_params[118].type = 0;
    _module_params[118].struct_type_name = NULL;
    _module_params[118].element_type = 21;
    _module_params[118].fn_sig = NULL;

    /* Function: List_ASTShadow_length */
    _module_functions[180].name = "List_ASTShadow_length";
    _module_functions[180].param_count = 1;
    _module_functions[180].return_type = 0;
    _module_functions[180].return_struct_type_name = NULL;
    _module_functions[180].return_fn_sig = NULL;
    _module_functions[180].return_type_info = NULL;
    _module_functions[180].body = NULL;
    _module_functions[180].shadow_test = NULL;
    _module_functions[180].is_extern = true;
    _module_functions[180].returns_gc_managed = false;
    _module_functions[180].requires_manual_free = false;
    _module_functions[180].returns_borrowed = false;
    _module_functions[180].cleanup_function = NULL;
    _module_functions[180].params = &_module_params[119];
    _module_params[119].name = "list";
    _module_params[119].type = 15;
    _module_params[119].struct_type_name = "ASTShadow";
    _module_params[119].element_type = 21;
    _module_params[119].fn_sig = NULL;

    /* Function: List_ASTStruct_new */
    _module_functions[181].name = "List_ASTStruct_new";
    _module_functions[181].param_count = 0;
    _module_functions[181].return_type = 15;
    _module_functions[181].return_struct_type_name = "ASTStruct";
    _module_functions[181].return_fn_sig = NULL;
    _module_functions[181].return_type_info = NULL;
    _module_functions[181].body = NULL;
    _module_functions[181].shadow_test = NULL;
    _module_functions[181].is_extern = true;
    _module_functions[181].returns_gc_managed = false;
    _module_functions[181].requires_manual_free = false;
    _module_functions[181].returns_borrowed = false;
    _module_functions[181].cleanup_function = NULL;
    _module_functions[181].params = NULL;

    /* Function: List_ASTStruct_push */
    _module_functions[182].name = "List_ASTStruct_push";
    _module_functions[182].param_count = 2;
    _module_functions[182].return_type = 6;
    _module_functions[182].return_struct_type_name = NULL;
    _module_functions[182].return_fn_sig = NULL;
    _module_functions[182].return_type_info = NULL;
    _module_functions[182].body = NULL;
    _module_functions[182].shadow_test = NULL;
    _module_functions[182].is_extern = true;
    _module_functions[182].returns_gc_managed = false;
    _module_functions[182].requires_manual_free = false;
    _module_functions[182].returns_borrowed = false;
    _module_functions[182].cleanup_function = NULL;
    _module_functions[182].params = &_module_params[120];
    _module_params[120].name = "list";
    _module_params[120].type = 15;
    _module_params[120].struct_type_name = "ASTStruct";
    _module_params[120].element_type = 21;
    _module_params[120].fn_sig = NULL;
    _module_params[121].name = "value";
    _module_params[121].type = 8;
    _module_params[121].struct_type_name = "ASTStruct";
    _module_params[121].element_type = 21;
    _module_params[121].fn_sig = NULL;

    /* Function: List_ASTStruct_get */
    _module_functions[183].name = "List_ASTStruct_get";
    _module_functions[183].param_count = 2;
    _module_functions[183].return_type = 8;
    _module_functions[183].return_struct_type_name = "ASTStruct";
    _module_functions[183].return_fn_sig = NULL;
    _module_functions[183].return_type_info = NULL;
    _module_functions[183].body = NULL;
    _module_functions[183].shadow_test = NULL;
    _module_functions[183].is_extern = true;
    _module_functions[183].returns_gc_managed = false;
    _module_functions[183].requires_manual_free = false;
    _module_functions[183].returns_borrowed = false;
    _module_functions[183].cleanup_function = NULL;
    _module_functions[183].params = &_module_params[122];
    _module_params[122].name = "list";
    _module_params[122].type = 15;
    _module_params[122].struct_type_name = "ASTStruct";
    _module_params[122].element_type = 21;
    _module_params[122].fn_sig = NULL;
    _module_params[123].name = "index";
    _module_params[123].type = 0;
    _module_params[123].struct_type_name = NULL;
    _module_params[123].element_type = 21;
    _module_params[123].fn_sig = NULL;

    /* Function: List_ASTStruct_length */
    _module_functions[184].name = "List_ASTStruct_length";
    _module_functions[184].param_count = 1;
    _module_functions[184].return_type = 0;
    _module_functions[184].return_struct_type_name = NULL;
    _module_functions[184].return_fn_sig = NULL;
    _module_functions[184].return_type_info = NULL;
    _module_functions[184].body = NULL;
    _module_functions[184].shadow_test = NULL;
    _module_functions[184].is_extern = true;
    _module_functions[184].returns_gc_managed = false;
    _module_functions[184].requires_manual_free = false;
    _module_functions[184].returns_borrowed = false;
    _module_functions[184].cleanup_function = NULL;
    _module_functions[184].params = &_module_params[124];
    _module_params[124].name = "list";
    _module_params[124].type = 15;
    _module_params[124].struct_type_name = "ASTStruct";
    _module_params[124].element_type = 21;
    _module_params[124].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_new */
    _module_functions[185].name = "List_ASTStructLiteral_new";
    _module_functions[185].param_count = 0;
    _module_functions[185].return_type = 15;
    _module_functions[185].return_struct_type_name = "ASTStructLiteral";
    _module_functions[185].return_fn_sig = NULL;
    _module_functions[185].return_type_info = NULL;
    _module_functions[185].body = NULL;
    _module_functions[185].shadow_test = NULL;
    _module_functions[185].is_extern = true;
    _module_functions[185].returns_gc_managed = false;
    _module_functions[185].requires_manual_free = false;
    _module_functions[185].returns_borrowed = false;
    _module_functions[185].cleanup_function = NULL;
    _module_functions[185].params = NULL;

    /* Function: List_ASTStructLiteral_push */
    _module_functions[186].name = "List_ASTStructLiteral_push";
    _module_functions[186].param_count = 2;
    _module_functions[186].return_type = 6;
    _module_functions[186].return_struct_type_name = NULL;
    _module_functions[186].return_fn_sig = NULL;
    _module_functions[186].return_type_info = NULL;
    _module_functions[186].body = NULL;
    _module_functions[186].shadow_test = NULL;
    _module_functions[186].is_extern = true;
    _module_functions[186].returns_gc_managed = false;
    _module_functions[186].requires_manual_free = false;
    _module_functions[186].returns_borrowed = false;
    _module_functions[186].cleanup_function = NULL;
    _module_functions[186].params = &_module_params[125];
    _module_params[125].name = "list";
    _module_params[125].type = 15;
    _module_params[125].struct_type_name = "ASTStructLiteral";
    _module_params[125].element_type = 21;
    _module_params[125].fn_sig = NULL;
    _module_params[126].name = "value";
    _module_params[126].type = 8;
    _module_params[126].struct_type_name = "ASTStructLiteral";
    _module_params[126].element_type = 21;
    _module_params[126].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_get */
    _module_functions[187].name = "List_ASTStructLiteral_get";
    _module_functions[187].param_count = 2;
    _module_functions[187].return_type = 8;
    _module_functions[187].return_struct_type_name = "ASTStructLiteral";
    _module_functions[187].return_fn_sig = NULL;
    _module_functions[187].return_type_info = NULL;
    _module_functions[187].body = NULL;
    _module_functions[187].shadow_test = NULL;
    _module_functions[187].is_extern = true;
    _module_functions[187].returns_gc_managed = false;
    _module_functions[187].requires_manual_free = false;
    _module_functions[187].returns_borrowed = false;
    _module_functions[187].cleanup_function = NULL;
    _module_functions[187].params = &_module_params[127];
    _module_params[127].name = "list";
    _module_params[127].type = 15;
    _module_params[127].struct_type_name = "ASTStructLiteral";
    _module_params[127].element_type = 21;
    _module_params[127].fn_sig = NULL;
    _module_params[128].name = "index";
    _module_params[128].type = 0;
    _module_params[128].struct_type_name = NULL;
    _module_params[128].element_type = 21;
    _module_params[128].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_length */
    _module_functions[188].name = "List_ASTStructLiteral_length";
    _module_functions[188].param_count = 1;
    _module_functions[188].return_type = 0;
    _module_functions[188].return_struct_type_name = NULL;
    _module_functions[188].return_fn_sig = NULL;
    _module_functions[188].return_type_info = NULL;
    _module_functions[188].body = NULL;
    _module_functions[188].shadow_test = NULL;
    _module_functions[188].is_extern = true;
    _module_functions[188].returns_gc_managed = false;
    _module_functions[188].requires_manual_free = false;
    _module_functions[188].returns_borrowed = false;
    _module_functions[188].cleanup_function = NULL;
    _module_functions[188].params = &_module_params[129];
    _module_params[129].name = "list";
    _module_params[129].type = 15;
    _module_params[129].struct_type_name = "ASTStructLiteral";
    _module_params[129].element_type = 21;
    _module_params[129].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_new */
    _module_functions[189].name = "List_ASTFieldAccess_new";
    _module_functions[189].param_count = 0;
    _module_functions[189].return_type = 15;
    _module_functions[189].return_struct_type_name = "ASTFieldAccess";
    _module_functions[189].return_fn_sig = NULL;
    _module_functions[189].return_type_info = NULL;
    _module_functions[189].body = NULL;
    _module_functions[189].shadow_test = NULL;
    _module_functions[189].is_extern = true;
    _module_functions[189].returns_gc_managed = false;
    _module_functions[189].requires_manual_free = false;
    _module_functions[189].returns_borrowed = false;
    _module_functions[189].cleanup_function = NULL;
    _module_functions[189].params = NULL;

    /* Function: List_ASTFieldAccess_push */
    _module_functions[190].name = "List_ASTFieldAccess_push";
    _module_functions[190].param_count = 2;
    _module_functions[190].return_type = 6;
    _module_functions[190].return_struct_type_name = NULL;
    _module_functions[190].return_fn_sig = NULL;
    _module_functions[190].return_type_info = NULL;
    _module_functions[190].body = NULL;
    _module_functions[190].shadow_test = NULL;
    _module_functions[190].is_extern = true;
    _module_functions[190].returns_gc_managed = false;
    _module_functions[190].requires_manual_free = false;
    _module_functions[190].returns_borrowed = false;
    _module_functions[190].cleanup_function = NULL;
    _module_functions[190].params = &_module_params[130];
    _module_params[130].name = "list";
    _module_params[130].type = 15;
    _module_params[130].struct_type_name = "ASTFieldAccess";
    _module_params[130].element_type = 21;
    _module_params[130].fn_sig = NULL;
    _module_params[131].name = "value";
    _module_params[131].type = 8;
    _module_params[131].struct_type_name = "ASTFieldAccess";
    _module_params[131].element_type = 21;
    _module_params[131].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_get */
    _module_functions[191].name = "List_ASTFieldAccess_get";
    _module_functions[191].param_count = 2;
    _module_functions[191].return_type = 8;
    _module_functions[191].return_struct_type_name = "ASTFieldAccess";
    _module_functions[191].return_fn_sig = NULL;
    _module_functions[191].return_type_info = NULL;
    _module_functions[191].body = NULL;
    _module_functions[191].shadow_test = NULL;
    _module_functions[191].is_extern = true;
    _module_functions[191].returns_gc_managed = false;
    _module_functions[191].requires_manual_free = false;
    _module_functions[191].returns_borrowed = false;
    _module_functions[191].cleanup_function = NULL;
    _module_functions[191].params = &_module_params[132];
    _module_params[132].name = "list";
    _module_params[132].type = 15;
    _module_params[132].struct_type_name = "ASTFieldAccess";
    _module_params[132].element_type = 21;
    _module_params[132].fn_sig = NULL;
    _module_params[133].name = "index";
    _module_params[133].type = 0;
    _module_params[133].struct_type_name = NULL;
    _module_params[133].element_type = 21;
    _module_params[133].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_length */
    _module_functions[192].name = "List_ASTFieldAccess_length";
    _module_functions[192].param_count = 1;
    _module_functions[192].return_type = 0;
    _module_functions[192].return_struct_type_name = NULL;
    _module_functions[192].return_fn_sig = NULL;
    _module_functions[192].return_type_info = NULL;
    _module_functions[192].body = NULL;
    _module_functions[192].shadow_test = NULL;
    _module_functions[192].is_extern = true;
    _module_functions[192].returns_gc_managed = false;
    _module_functions[192].requires_manual_free = false;
    _module_functions[192].returns_borrowed = false;
    _module_functions[192].cleanup_function = NULL;
    _module_functions[192].params = &_module_params[134];
    _module_params[134].name = "list";
    _module_params[134].type = 15;
    _module_params[134].struct_type_name = "ASTFieldAccess";
    _module_params[134].element_type = 21;
    _module_params[134].fn_sig = NULL;

    /* Function: List_ASTEnum_new */
    _module_functions[193].name = "List_ASTEnum_new";
    _module_functions[193].param_count = 0;
    _module_functions[193].return_type = 15;
    _module_functions[193].return_struct_type_name = "ASTEnum";
    _module_functions[193].return_fn_sig = NULL;
    _module_functions[193].return_type_info = NULL;
    _module_functions[193].body = NULL;
    _module_functions[193].shadow_test = NULL;
    _module_functions[193].is_extern = true;
    _module_functions[193].returns_gc_managed = false;
    _module_functions[193].requires_manual_free = false;
    _module_functions[193].returns_borrowed = false;
    _module_functions[193].cleanup_function = NULL;
    _module_functions[193].params = NULL;

    /* Function: List_ASTEnum_push */
    _module_functions[194].name = "List_ASTEnum_push";
    _module_functions[194].param_count = 2;
    _module_functions[194].return_type = 6;
    _module_functions[194].return_struct_type_name = NULL;
    _module_functions[194].return_fn_sig = NULL;
    _module_functions[194].return_type_info = NULL;
    _module_functions[194].body = NULL;
    _module_functions[194].shadow_test = NULL;
    _module_functions[194].is_extern = true;
    _module_functions[194].returns_gc_managed = false;
    _module_functions[194].requires_manual_free = false;
    _module_functions[194].returns_borrowed = false;
    _module_functions[194].cleanup_function = NULL;
    _module_functions[194].params = &_module_params[135];
    _module_params[135].name = "list";
    _module_params[135].type = 15;
    _module_params[135].struct_type_name = "ASTEnum";
    _module_params[135].element_type = 21;
    _module_params[135].fn_sig = NULL;
    _module_params[136].name = "value";
    _module_params[136].type = 8;
    _module_params[136].struct_type_name = "ASTEnum";
    _module_params[136].element_type = 21;
    _module_params[136].fn_sig = NULL;

    /* Function: List_ASTEnum_get */
    _module_functions[195].name = "List_ASTEnum_get";
    _module_functions[195].param_count = 2;
    _module_functions[195].return_type = 8;
    _module_functions[195].return_struct_type_name = "ASTEnum";
    _module_functions[195].return_fn_sig = NULL;
    _module_functions[195].return_type_info = NULL;
    _module_functions[195].body = NULL;
    _module_functions[195].shadow_test = NULL;
    _module_functions[195].is_extern = true;
    _module_functions[195].returns_gc_managed = false;
    _module_functions[195].requires_manual_free = false;
    _module_functions[195].returns_borrowed = false;
    _module_functions[195].cleanup_function = NULL;
    _module_functions[195].params = &_module_params[137];
    _module_params[137].name = "list";
    _module_params[137].type = 15;
    _module_params[137].struct_type_name = "ASTEnum";
    _module_params[137].element_type = 21;
    _module_params[137].fn_sig = NULL;
    _module_params[138].name = "index";
    _module_params[138].type = 0;
    _module_params[138].struct_type_name = NULL;
    _module_params[138].element_type = 21;
    _module_params[138].fn_sig = NULL;

    /* Function: List_ASTEnum_length */
    _module_functions[196].name = "List_ASTEnum_length";
    _module_functions[196].param_count = 1;
    _module_functions[196].return_type = 0;
    _module_functions[196].return_struct_type_name = NULL;
    _module_functions[196].return_fn_sig = NULL;
    _module_functions[196].return_type_info = NULL;
    _module_functions[196].body = NULL;
    _module_functions[196].shadow_test = NULL;
    _module_functions[196].is_extern = true;
    _module_functions[196].returns_gc_managed = false;
    _module_functions[196].requires_manual_free = false;
    _module_functions[196].returns_borrowed = false;
    _module_functions[196].cleanup_function = NULL;
    _module_functions[196].params = &_module_params[139];
    _module_params[139].name = "list";
    _module_params[139].type = 15;
    _module_params[139].struct_type_name = "ASTEnum";
    _module_params[139].element_type = 21;
    _module_params[139].fn_sig = NULL;

    /* Function: List_ASTUnion_new */
    _module_functions[197].name = "List_ASTUnion_new";
    _module_functions[197].param_count = 0;
    _module_functions[197].return_type = 15;
    _module_functions[197].return_struct_type_name = "ASTUnion";
    _module_functions[197].return_fn_sig = NULL;
    _module_functions[197].return_type_info = NULL;
    _module_functions[197].body = NULL;
    _module_functions[197].shadow_test = NULL;
    _module_functions[197].is_extern = true;
    _module_functions[197].returns_gc_managed = false;
    _module_functions[197].requires_manual_free = false;
    _module_functions[197].returns_borrowed = false;
    _module_functions[197].cleanup_function = NULL;
    _module_functions[197].params = NULL;

    /* Function: List_ASTUnion_push */
    _module_functions[198].name = "List_ASTUnion_push";
    _module_functions[198].param_count = 2;
    _module_functions[198].return_type = 6;
    _module_functions[198].return_struct_type_name = NULL;
    _module_functions[198].return_fn_sig = NULL;
    _module_functions[198].return_type_info = NULL;
    _module_functions[198].body = NULL;
    _module_functions[198].shadow_test = NULL;
    _module_functions[198].is_extern = true;
    _module_functions[198].returns_gc_managed = false;
    _module_functions[198].requires_manual_free = false;
    _module_functions[198].returns_borrowed = false;
    _module_functions[198].cleanup_function = NULL;
    _module_functions[198].params = &_module_params[140];
    _module_params[140].name = "list";
    _module_params[140].type = 15;
    _module_params[140].struct_type_name = "ASTUnion";
    _module_params[140].element_type = 21;
    _module_params[140].fn_sig = NULL;
    _module_params[141].name = "value";
    _module_params[141].type = 8;
    _module_params[141].struct_type_name = "ASTUnion";
    _module_params[141].element_type = 21;
    _module_params[141].fn_sig = NULL;

    /* Function: List_ASTUnion_get */
    _module_functions[199].name = "List_ASTUnion_get";
    _module_functions[199].param_count = 2;
    _module_functions[199].return_type = 8;
    _module_functions[199].return_struct_type_name = "ASTUnion";
    _module_functions[199].return_fn_sig = NULL;
    _module_functions[199].return_type_info = NULL;
    _module_functions[199].body = NULL;
    _module_functions[199].shadow_test = NULL;
    _module_functions[199].is_extern = true;
    _module_functions[199].returns_gc_managed = false;
    _module_functions[199].requires_manual_free = false;
    _module_functions[199].returns_borrowed = false;
    _module_functions[199].cleanup_function = NULL;
    _module_functions[199].params = &_module_params[142];
    _module_params[142].name = "list";
    _module_params[142].type = 15;
    _module_params[142].struct_type_name = "ASTUnion";
    _module_params[142].element_type = 21;
    _module_params[142].fn_sig = NULL;
    _module_params[143].name = "index";
    _module_params[143].type = 0;
    _module_params[143].struct_type_name = NULL;
    _module_params[143].element_type = 21;
    _module_params[143].fn_sig = NULL;

    /* Function: List_ASTUnion_length */
    _module_functions[200].name = "List_ASTUnion_length";
    _module_functions[200].param_count = 1;
    _module_functions[200].return_type = 0;
    _module_functions[200].return_struct_type_name = NULL;
    _module_functions[200].return_fn_sig = NULL;
    _module_functions[200].return_type_info = NULL;
    _module_functions[200].body = NULL;
    _module_functions[200].shadow_test = NULL;
    _module_functions[200].is_extern = true;
    _module_functions[200].returns_gc_managed = false;
    _module_functions[200].requires_manual_free = false;
    _module_functions[200].returns_borrowed = false;
    _module_functions[200].cleanup_function = NULL;
    _module_functions[200].params = &_module_params[144];
    _module_params[144].name = "list";
    _module_params[144].type = 15;
    _module_params[144].struct_type_name = "ASTUnion";
    _module_params[144].element_type = 21;
    _module_params[144].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_new */
    _module_functions[201].name = "List_ASTUnionConstruct_new";
    _module_functions[201].param_count = 0;
    _module_functions[201].return_type = 15;
    _module_functions[201].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[201].return_fn_sig = NULL;
    _module_functions[201].return_type_info = NULL;
    _module_functions[201].body = NULL;
    _module_functions[201].shadow_test = NULL;
    _module_functions[201].is_extern = true;
    _module_functions[201].returns_gc_managed = false;
    _module_functions[201].requires_manual_free = false;
    _module_functions[201].returns_borrowed = false;
    _module_functions[201].cleanup_function = NULL;
    _module_functions[201].params = NULL;

    /* Function: List_ASTUnionConstruct_push */
    _module_functions[202].name = "List_ASTUnionConstruct_push";
    _module_functions[202].param_count = 2;
    _module_functions[202].return_type = 6;
    _module_functions[202].return_struct_type_name = NULL;
    _module_functions[202].return_fn_sig = NULL;
    _module_functions[202].return_type_info = NULL;
    _module_functions[202].body = NULL;
    _module_functions[202].shadow_test = NULL;
    _module_functions[202].is_extern = true;
    _module_functions[202].returns_gc_managed = false;
    _module_functions[202].requires_manual_free = false;
    _module_functions[202].returns_borrowed = false;
    _module_functions[202].cleanup_function = NULL;
    _module_functions[202].params = &_module_params[145];
    _module_params[145].name = "list";
    _module_params[145].type = 15;
    _module_params[145].struct_type_name = "ASTUnionConstruct";
    _module_params[145].element_type = 21;
    _module_params[145].fn_sig = NULL;
    _module_params[146].name = "value";
    _module_params[146].type = 8;
    _module_params[146].struct_type_name = "ASTUnionConstruct";
    _module_params[146].element_type = 21;
    _module_params[146].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_get */
    _module_functions[203].name = "List_ASTUnionConstruct_get";
    _module_functions[203].param_count = 2;
    _module_functions[203].return_type = 8;
    _module_functions[203].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[203].return_fn_sig = NULL;
    _module_functions[203].return_type_info = NULL;
    _module_functions[203].body = NULL;
    _module_functions[203].shadow_test = NULL;
    _module_functions[203].is_extern = true;
    _module_functions[203].returns_gc_managed = false;
    _module_functions[203].requires_manual_free = false;
    _module_functions[203].returns_borrowed = false;
    _module_functions[203].cleanup_function = NULL;
    _module_functions[203].params = &_module_params[147];
    _module_params[147].name = "list";
    _module_params[147].type = 15;
    _module_params[147].struct_type_name = "ASTUnionConstruct";
    _module_params[147].element_type = 21;
    _module_params[147].fn_sig = NULL;
    _module_params[148].name = "index";
    _module_params[148].type = 0;
    _module_params[148].struct_type_name = NULL;
    _module_params[148].element_type = 21;
    _module_params[148].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_length */
    _module_functions[204].name = "List_ASTUnionConstruct_length";
    _module_functions[204].param_count = 1;
    _module_functions[204].return_type = 0;
    _module_functions[204].return_struct_type_name = NULL;
    _module_functions[204].return_fn_sig = NULL;
    _module_functions[204].return_type_info = NULL;
    _module_functions[204].body = NULL;
    _module_functions[204].shadow_test = NULL;
    _module_functions[204].is_extern = true;
    _module_functions[204].returns_gc_managed = false;
    _module_functions[204].requires_manual_free = false;
    _module_functions[204].returns_borrowed = false;
    _module_functions[204].cleanup_function = NULL;
    _module_functions[204].params = &_module_params[149];
    _module_params[149].name = "list";
    _module_params[149].type = 15;
    _module_params[149].struct_type_name = "ASTUnionConstruct";
    _module_params[149].element_type = 21;
    _module_params[149].fn_sig = NULL;

    /* Function: List_ASTMatch_new */
    _module_functions[205].name = "List_ASTMatch_new";
    _module_functions[205].param_count = 0;
    _module_functions[205].return_type = 15;
    _module_functions[205].return_struct_type_name = "ASTMatch";
    _module_functions[205].return_fn_sig = NULL;
    _module_functions[205].return_type_info = NULL;
    _module_functions[205].body = NULL;
    _module_functions[205].shadow_test = NULL;
    _module_functions[205].is_extern = true;
    _module_functions[205].returns_gc_managed = false;
    _module_functions[205].requires_manual_free = false;
    _module_functions[205].returns_borrowed = false;
    _module_functions[205].cleanup_function = NULL;
    _module_functions[205].params = NULL;

    /* Function: List_ASTMatch_push */
    _module_functions[206].name = "List_ASTMatch_push";
    _module_functions[206].param_count = 2;
    _module_functions[206].return_type = 6;
    _module_functions[206].return_struct_type_name = NULL;
    _module_functions[206].return_fn_sig = NULL;
    _module_functions[206].return_type_info = NULL;
    _module_functions[206].body = NULL;
    _module_functions[206].shadow_test = NULL;
    _module_functions[206].is_extern = true;
    _module_functions[206].returns_gc_managed = false;
    _module_functions[206].requires_manual_free = false;
    _module_functions[206].returns_borrowed = false;
    _module_functions[206].cleanup_function = NULL;
    _module_functions[206].params = &_module_params[150];
    _module_params[150].name = "list";
    _module_params[150].type = 15;
    _module_params[150].struct_type_name = "ASTMatch";
    _module_params[150].element_type = 21;
    _module_params[150].fn_sig = NULL;
    _module_params[151].name = "value";
    _module_params[151].type = 8;
    _module_params[151].struct_type_name = "ASTMatch";
    _module_params[151].element_type = 21;
    _module_params[151].fn_sig = NULL;

    /* Function: List_ASTMatch_get */
    _module_functions[207].name = "List_ASTMatch_get";
    _module_functions[207].param_count = 2;
    _module_functions[207].return_type = 8;
    _module_functions[207].return_struct_type_name = "ASTMatch";
    _module_functions[207].return_fn_sig = NULL;
    _module_functions[207].return_type_info = NULL;
    _module_functions[207].body = NULL;
    _module_functions[207].shadow_test = NULL;
    _module_functions[207].is_extern = true;
    _module_functions[207].returns_gc_managed = false;
    _module_functions[207].requires_manual_free = false;
    _module_functions[207].returns_borrowed = false;
    _module_functions[207].cleanup_function = NULL;
    _module_functions[207].params = &_module_params[152];
    _module_params[152].name = "list";
    _module_params[152].type = 15;
    _module_params[152].struct_type_name = "ASTMatch";
    _module_params[152].element_type = 21;
    _module_params[152].fn_sig = NULL;
    _module_params[153].name = "index";
    _module_params[153].type = 0;
    _module_params[153].struct_type_name = NULL;
    _module_params[153].element_type = 21;
    _module_params[153].fn_sig = NULL;

    /* Function: List_ASTMatch_length */
    _module_functions[208].name = "List_ASTMatch_length";
    _module_functions[208].param_count = 1;
    _module_functions[208].return_type = 0;
    _module_functions[208].return_struct_type_name = NULL;
    _module_functions[208].return_fn_sig = NULL;
    _module_functions[208].return_type_info = NULL;
    _module_functions[208].body = NULL;
    _module_functions[208].shadow_test = NULL;
    _module_functions[208].is_extern = true;
    _module_functions[208].returns_gc_managed = false;
    _module_functions[208].requires_manual_free = false;
    _module_functions[208].returns_borrowed = false;
    _module_functions[208].cleanup_function = NULL;
    _module_functions[208].params = &_module_params[154];
    _module_params[154].name = "list";
    _module_params[154].type = 15;
    _module_params[154].struct_type_name = "ASTMatch";
    _module_params[154].element_type = 21;
    _module_params[154].fn_sig = NULL;

    /* Function: List_ASTImport_new */
    _module_functions[209].name = "List_ASTImport_new";
    _module_functions[209].param_count = 0;
    _module_functions[209].return_type = 15;
    _module_functions[209].return_struct_type_name = "ASTImport";
    _module_functions[209].return_fn_sig = NULL;
    _module_functions[209].return_type_info = NULL;
    _module_functions[209].body = NULL;
    _module_functions[209].shadow_test = NULL;
    _module_functions[209].is_extern = true;
    _module_functions[209].returns_gc_managed = false;
    _module_functions[209].requires_manual_free = false;
    _module_functions[209].returns_borrowed = false;
    _module_functions[209].cleanup_function = NULL;
    _module_functions[209].params = NULL;

    /* Function: List_ASTImport_push */
    _module_functions[210].name = "List_ASTImport_push";
    _module_functions[210].param_count = 2;
    _module_functions[210].return_type = 6;
    _module_functions[210].return_struct_type_name = NULL;
    _module_functions[210].return_fn_sig = NULL;
    _module_functions[210].return_type_info = NULL;
    _module_functions[210].body = NULL;
    _module_functions[210].shadow_test = NULL;
    _module_functions[210].is_extern = true;
    _module_functions[210].returns_gc_managed = false;
    _module_functions[210].requires_manual_free = false;
    _module_functions[210].returns_borrowed = false;
    _module_functions[210].cleanup_function = NULL;
    _module_functions[210].params = &_module_params[155];
    _module_params[155].name = "list";
    _module_params[155].type = 15;
    _module_params[155].struct_type_name = "ASTImport";
    _module_params[155].element_type = 21;
    _module_params[155].fn_sig = NULL;
    _module_params[156].name = "value";
    _module_params[156].type = 8;
    _module_params[156].struct_type_name = "ASTImport";
    _module_params[156].element_type = 21;
    _module_params[156].fn_sig = NULL;

    /* Function: List_ASTImport_get */
    _module_functions[211].name = "List_ASTImport_get";
    _module_functions[211].param_count = 2;
    _module_functions[211].return_type = 8;
    _module_functions[211].return_struct_type_name = "ASTImport";
    _module_functions[211].return_fn_sig = NULL;
    _module_functions[211].return_type_info = NULL;
    _module_functions[211].body = NULL;
    _module_functions[211].shadow_test = NULL;
    _module_functions[211].is_extern = true;
    _module_functions[211].returns_gc_managed = false;
    _module_functions[211].requires_manual_free = false;
    _module_functions[211].returns_borrowed = false;
    _module_functions[211].cleanup_function = NULL;
    _module_functions[211].params = &_module_params[157];
    _module_params[157].name = "list";
    _module_params[157].type = 15;
    _module_params[157].struct_type_name = "ASTImport";
    _module_params[157].element_type = 21;
    _module_params[157].fn_sig = NULL;
    _module_params[158].name = "index";
    _module_params[158].type = 0;
    _module_params[158].struct_type_name = NULL;
    _module_params[158].element_type = 21;
    _module_params[158].fn_sig = NULL;

    /* Function: List_ASTImport_length */
    _module_functions[212].name = "List_ASTImport_length";
    _module_functions[212].param_count = 1;
    _module_functions[212].return_type = 0;
    _module_functions[212].return_struct_type_name = NULL;
    _module_functions[212].return_fn_sig = NULL;
    _module_functions[212].return_type_info = NULL;
    _module_functions[212].body = NULL;
    _module_functions[212].shadow_test = NULL;
    _module_functions[212].is_extern = true;
    _module_functions[212].returns_gc_managed = false;
    _module_functions[212].requires_manual_free = false;
    _module_functions[212].returns_borrowed = false;
    _module_functions[212].cleanup_function = NULL;
    _module_functions[212].params = &_module_params[159];
    _module_params[159].name = "list";
    _module_params[159].type = 15;
    _module_params[159].struct_type_name = "ASTImport";
    _module_params[159].element_type = 21;
    _module_params[159].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_new */
    _module_functions[213].name = "List_ASTOpaqueType_new";
    _module_functions[213].param_count = 0;
    _module_functions[213].return_type = 15;
    _module_functions[213].return_struct_type_name = "ASTOpaqueType";
    _module_functions[213].return_fn_sig = NULL;
    _module_functions[213].return_type_info = NULL;
    _module_functions[213].body = NULL;
    _module_functions[213].shadow_test = NULL;
    _module_functions[213].is_extern = true;
    _module_functions[213].returns_gc_managed = false;
    _module_functions[213].requires_manual_free = false;
    _module_functions[213].returns_borrowed = false;
    _module_functions[213].cleanup_function = NULL;
    _module_functions[213].params = NULL;

    /* Function: List_ASTOpaqueType_push */
    _module_functions[214].name = "List_ASTOpaqueType_push";
    _module_functions[214].param_count = 2;
    _module_functions[214].return_type = 6;
    _module_functions[214].return_struct_type_name = NULL;
    _module_functions[214].return_fn_sig = NULL;
    _module_functions[214].return_type_info = NULL;
    _module_functions[214].body = NULL;
    _module_functions[214].shadow_test = NULL;
    _module_functions[214].is_extern = true;
    _module_functions[214].returns_gc_managed = false;
    _module_functions[214].requires_manual_free = false;
    _module_functions[214].returns_borrowed = false;
    _module_functions[214].cleanup_function = NULL;
    _module_functions[214].params = &_module_params[160];
    _module_params[160].name = "list";
    _module_params[160].type = 15;
    _module_params[160].struct_type_name = "ASTOpaqueType";
    _module_params[160].element_type = 21;
    _module_params[160].fn_sig = NULL;
    _module_params[161].name = "value";
    _module_params[161].type = 8;
    _module_params[161].struct_type_name = "ASTOpaqueType";
    _module_params[161].element_type = 21;
    _module_params[161].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_get */
    _module_functions[215].name = "List_ASTOpaqueType_get";
    _module_functions[215].param_count = 2;
    _module_functions[215].return_type = 8;
    _module_functions[215].return_struct_type_name = "ASTOpaqueType";
    _module_functions[215].return_fn_sig = NULL;
    _module_functions[215].return_type_info = NULL;
    _module_functions[215].body = NULL;
    _module_functions[215].shadow_test = NULL;
    _module_functions[215].is_extern = true;
    _module_functions[215].returns_gc_managed = false;
    _module_functions[215].requires_manual_free = false;
    _module_functions[215].returns_borrowed = false;
    _module_functions[215].cleanup_function = NULL;
    _module_functions[215].params = &_module_params[162];
    _module_params[162].name = "list";
    _module_params[162].type = 15;
    _module_params[162].struct_type_name = "ASTOpaqueType";
    _module_params[162].element_type = 21;
    _module_params[162].fn_sig = NULL;
    _module_params[163].name = "index";
    _module_params[163].type = 0;
    _module_params[163].struct_type_name = NULL;
    _module_params[163].element_type = 21;
    _module_params[163].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_length */
    _module_functions[216].name = "List_ASTOpaqueType_length";
    _module_functions[216].param_count = 1;
    _module_functions[216].return_type = 0;
    _module_functions[216].return_struct_type_name = NULL;
    _module_functions[216].return_fn_sig = NULL;
    _module_functions[216].return_type_info = NULL;
    _module_functions[216].body = NULL;
    _module_functions[216].shadow_test = NULL;
    _module_functions[216].is_extern = true;
    _module_functions[216].returns_gc_managed = false;
    _module_functions[216].requires_manual_free = false;
    _module_functions[216].returns_borrowed = false;
    _module_functions[216].cleanup_function = NULL;
    _module_functions[216].params = &_module_params[164];
    _module_params[164].name = "list";
    _module_params[164].type = 15;
    _module_params[164].struct_type_name = "ASTOpaqueType";
    _module_params[164].element_type = 21;
    _module_params[164].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_new */
    _module_functions[217].name = "List_ASTTupleLiteral_new";
    _module_functions[217].param_count = 0;
    _module_functions[217].return_type = 15;
    _module_functions[217].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[217].return_fn_sig = NULL;
    _module_functions[217].return_type_info = NULL;
    _module_functions[217].body = NULL;
    _module_functions[217].shadow_test = NULL;
    _module_functions[217].is_extern = true;
    _module_functions[217].returns_gc_managed = false;
    _module_functions[217].requires_manual_free = false;
    _module_functions[217].returns_borrowed = false;
    _module_functions[217].cleanup_function = NULL;
    _module_functions[217].params = NULL;

    /* Function: List_ASTTupleLiteral_push */
    _module_functions[218].name = "List_ASTTupleLiteral_push";
    _module_functions[218].param_count = 2;
    _module_functions[218].return_type = 6;
    _module_functions[218].return_struct_type_name = NULL;
    _module_functions[218].return_fn_sig = NULL;
    _module_functions[218].return_type_info = NULL;
    _module_functions[218].body = NULL;
    _module_functions[218].shadow_test = NULL;
    _module_functions[218].is_extern = true;
    _module_functions[218].returns_gc_managed = false;
    _module_functions[218].requires_manual_free = false;
    _module_functions[218].returns_borrowed = false;
    _module_functions[218].cleanup_function = NULL;
    _module_functions[218].params = &_module_params[165];
    _module_params[165].name = "list";
    _module_params[165].type = 15;
    _module_params[165].struct_type_name = "ASTTupleLiteral";
    _module_params[165].element_type = 21;
    _module_params[165].fn_sig = NULL;
    _module_params[166].name = "value";
    _module_params[166].type = 8;
    _module_params[166].struct_type_name = "ASTTupleLiteral";
    _module_params[166].element_type = 21;
    _module_params[166].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_get */
    _module_functions[219].name = "List_ASTTupleLiteral_get";
    _module_functions[219].param_count = 2;
    _module_functions[219].return_type = 8;
    _module_functions[219].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[219].return_fn_sig = NULL;
    _module_functions[219].return_type_info = NULL;
    _module_functions[219].body = NULL;
    _module_functions[219].shadow_test = NULL;
    _module_functions[219].is_extern = true;
    _module_functions[219].returns_gc_managed = false;
    _module_functions[219].requires_manual_free = false;
    _module_functions[219].returns_borrowed = false;
    _module_functions[219].cleanup_function = NULL;
    _module_functions[219].params = &_module_params[167];
    _module_params[167].name = "list";
    _module_params[167].type = 15;
    _module_params[167].struct_type_name = "ASTTupleLiteral";
    _module_params[167].element_type = 21;
    _module_params[167].fn_sig = NULL;
    _module_params[168].name = "index";
    _module_params[168].type = 0;
    _module_params[168].struct_type_name = NULL;
    _module_params[168].element_type = 21;
    _module_params[168].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_length */
    _module_functions[220].name = "List_ASTTupleLiteral_length";
    _module_functions[220].param_count = 1;
    _module_functions[220].return_type = 0;
    _module_functions[220].return_struct_type_name = NULL;
    _module_functions[220].return_fn_sig = NULL;
    _module_functions[220].return_type_info = NULL;
    _module_functions[220].body = NULL;
    _module_functions[220].shadow_test = NULL;
    _module_functions[220].is_extern = true;
    _module_functions[220].returns_gc_managed = false;
    _module_functions[220].requires_manual_free = false;
    _module_functions[220].returns_borrowed = false;
    _module_functions[220].cleanup_function = NULL;
    _module_functions[220].params = &_module_params[169];
    _module_params[169].name = "list";
    _module_params[169].type = 15;
    _module_params[169].struct_type_name = "ASTTupleLiteral";
    _module_params[169].element_type = 21;
    _module_params[169].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_new */
    _module_functions[221].name = "List_ASTTupleIndex_new";
    _module_functions[221].param_count = 0;
    _module_functions[221].return_type = 15;
    _module_functions[221].return_struct_type_name = "ASTTupleIndex";
    _module_functions[221].return_fn_sig = NULL;
    _module_functions[221].return_type_info = NULL;
    _module_functions[221].body = NULL;
    _module_functions[221].shadow_test = NULL;
    _module_functions[221].is_extern = true;
    _module_functions[221].returns_gc_managed = false;
    _module_functions[221].requires_manual_free = false;
    _module_functions[221].returns_borrowed = false;
    _module_functions[221].cleanup_function = NULL;
    _module_functions[221].params = NULL;

    /* Function: List_ASTTupleIndex_push */
    _module_functions[222].name = "List_ASTTupleIndex_push";
    _module_functions[222].param_count = 2;
    _module_functions[222].return_type = 6;
    _module_functions[222].return_struct_type_name = NULL;
    _module_functions[222].return_fn_sig = NULL;
    _module_functions[222].return_type_info = NULL;
    _module_functions[222].body = NULL;
    _module_functions[222].shadow_test = NULL;
    _module_functions[222].is_extern = true;
    _module_functions[222].returns_gc_managed = false;
    _module_functions[222].requires_manual_free = false;
    _module_functions[222].returns_borrowed = false;
    _module_functions[222].cleanup_function = NULL;
    _module_functions[222].params = &_module_params[170];
    _module_params[170].name = "list";
    _module_params[170].type = 15;
    _module_params[170].struct_type_name = "ASTTupleIndex";
    _module_params[170].element_type = 21;
    _module_params[170].fn_sig = NULL;
    _module_params[171].name = "value";
    _module_params[171].type = 8;
    _module_params[171].struct_type_name = "ASTTupleIndex";
    _module_params[171].element_type = 21;
    _module_params[171].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_get */
    _module_functions[223].name = "List_ASTTupleIndex_get";
    _module_functions[223].param_count = 2;
    _module_functions[223].return_type = 8;
    _module_functions[223].return_struct_type_name = "ASTTupleIndex";
    _module_functions[223].return_fn_sig = NULL;
    _module_functions[223].return_type_info = NULL;
    _module_functions[223].body = NULL;
    _module_functions[223].shadow_test = NULL;
    _module_functions[223].is_extern = true;
    _module_functions[223].returns_gc_managed = false;
    _module_functions[223].requires_manual_free = false;
    _module_functions[223].returns_borrowed = false;
    _module_functions[223].cleanup_function = NULL;
    _module_functions[223].params = &_module_params[172];
    _module_params[172].name = "list";
    _module_params[172].type = 15;
    _module_params[172].struct_type_name = "ASTTupleIndex";
    _module_params[172].element_type = 21;
    _module_params[172].fn_sig = NULL;
    _module_params[173].name = "index";
    _module_params[173].type = 0;
    _module_params[173].struct_type_name = NULL;
    _module_params[173].element_type = 21;
    _module_params[173].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_length */
    _module_functions[224].name = "List_ASTTupleIndex_length";
    _module_functions[224].param_count = 1;
    _module_functions[224].return_type = 0;
    _module_functions[224].return_struct_type_name = NULL;
    _module_functions[224].return_fn_sig = NULL;
    _module_functions[224].return_type_info = NULL;
    _module_functions[224].body = NULL;
    _module_functions[224].shadow_test = NULL;
    _module_functions[224].is_extern = true;
    _module_functions[224].returns_gc_managed = false;
    _module_functions[224].requires_manual_free = false;
    _module_functions[224].returns_borrowed = false;
    _module_functions[224].cleanup_function = NULL;
    _module_functions[224].params = &_module_params[174];
    _module_params[174].name = "list";
    _module_params[174].type = 15;
    _module_params[174].struct_type_name = "ASTTupleIndex";
    _module_params[174].element_type = 21;
    _module_params[174].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_new */
    _module_functions[225].name = "List_ASTServiceDecl_new";
    _module_functions[225].param_count = 0;
    _module_functions[225].return_type = 15;
    _module_functions[225].return_struct_type_name = "ASTServiceDecl";
    _module_functions[225].return_fn_sig = NULL;
    _module_functions[225].return_type_info = NULL;
    _module_functions[225].body = NULL;
    _module_functions[225].shadow_test = NULL;
    _module_functions[225].is_extern = true;
    _module_functions[225].returns_gc_managed = false;
    _module_functions[225].requires_manual_free = false;
    _module_functions[225].returns_borrowed = false;
    _module_functions[225].cleanup_function = NULL;
    _module_functions[225].params = NULL;

    /* Function: List_ASTServiceDecl_push */
    _module_functions[226].name = "List_ASTServiceDecl_push";
    _module_functions[226].param_count = 2;
    _module_functions[226].return_type = 6;
    _module_functions[226].return_struct_type_name = NULL;
    _module_functions[226].return_fn_sig = NULL;
    _module_functions[226].return_type_info = NULL;
    _module_functions[226].body = NULL;
    _module_functions[226].shadow_test = NULL;
    _module_functions[226].is_extern = true;
    _module_functions[226].returns_gc_managed = false;
    _module_functions[226].requires_manual_free = false;
    _module_functions[226].returns_borrowed = false;
    _module_functions[226].cleanup_function = NULL;
    _module_functions[226].params = &_module_params[175];
    _module_params[175].name = "list";
    _module_params[175].type = 15;
    _module_params[175].struct_type_name = "ASTServiceDecl";
    _module_params[175].element_type = 21;
    _module_params[175].fn_sig = NULL;
    _module_params[176].name = "value";
    _module_params[176].type = 8;
    _module_params[176].struct_type_name = "ASTServiceDecl";
    _module_params[176].element_type = 21;
    _module_params[176].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_get */
    _module_functions[227].name = "List_ASTServiceDecl_get";
    _module_functions[227].param_count = 2;
    _module_functions[227].return_type = 8;
    _module_functions[227].return_struct_type_name = "ASTServiceDecl";
    _module_functions[227].return_fn_sig = NULL;
    _module_functions[227].return_type_info = NULL;
    _module_functions[227].body = NULL;
    _module_functions[227].shadow_test = NULL;
    _module_functions[227].is_extern = true;
    _module_functions[227].returns_gc_managed = false;
    _module_functions[227].requires_manual_free = false;
    _module_functions[227].returns_borrowed = false;
    _module_functions[227].cleanup_function = NULL;
    _module_functions[227].params = &_module_params[177];
    _module_params[177].name = "list";
    _module_params[177].type = 15;
    _module_params[177].struct_type_name = "ASTServiceDecl";
    _module_params[177].element_type = 21;
    _module_params[177].fn_sig = NULL;
    _module_params[178].name = "index";
    _module_params[178].type = 0;
    _module_params[178].struct_type_name = NULL;
    _module_params[178].element_type = 21;
    _module_params[178].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_length */
    _module_functions[228].name = "List_ASTServiceDecl_length";
    _module_functions[228].param_count = 1;
    _module_functions[228].return_type = 0;
    _module_functions[228].return_struct_type_name = NULL;
    _module_functions[228].return_fn_sig = NULL;
    _module_functions[228].return_type_info = NULL;
    _module_functions[228].body = NULL;
    _module_functions[228].shadow_test = NULL;
    _module_functions[228].is_extern = true;
    _module_functions[228].returns_gc_managed = false;
    _module_functions[228].requires_manual_free = false;
    _module_functions[228].returns_borrowed = false;
    _module_functions[228].cleanup_function = NULL;
    _module_functions[228].params = &_module_params[179];
    _module_params[179].name = "list";
    _module_params[179].type = 15;
    _module_params[179].struct_type_name = "ASTServiceDecl";
    _module_params[179].element_type = 21;
    _module_params[179].fn_sig = NULL;

    /* Function: token_literal_value_bytes */
    _module_functions[229].name = "token_literal_value_bytes";
    _module_functions[229].param_count = 1;
    _module_functions[229].return_type = 0;
    _module_functions[229].return_struct_type_name = NULL;
    _module_functions[229].return_fn_sig = NULL;
    _module_functions[229].return_type_info = NULL;
    _module_functions[229].body = NULL;
    _module_functions[229].shadow_test = NULL;
    _module_functions[229].is_extern = false;
    _module_functions[229].returns_gc_managed = false;
    _module_functions[229].requires_manual_free = false;
    _module_functions[229].returns_borrowed = false;
    _module_functions[229].cleanup_function = NULL;
    _module_functions[229].params = &_module_params[180];
    _module_params[180].name = "raw";
    _module_params[180].type = 4;
    _module_params[180].struct_type_name = NULL;
    _module_params[180].element_type = 21;
    _module_params[180].fn_sig = NULL;

    /* Function: diag_location */
    _module_functions[230].name = "diag_location";
    _module_functions[230].param_count = 3;
    _module_functions[230].return_type = 8;
    _module_functions[230].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[230].return_fn_sig = NULL;
    _module_functions[230].return_type_info = NULL;
    _module_functions[230].body = NULL;
    _module_functions[230].shadow_test = NULL;
    _module_functions[230].is_extern = false;
    _module_functions[230].returns_gc_managed = false;
    _module_functions[230].requires_manual_free = false;
    _module_functions[230].returns_borrowed = false;
    _module_functions[230].cleanup_function = NULL;
    _module_functions[230].params = &_module_params[181];
    _module_params[181].name = "file";
    _module_params[181].type = 4;
    _module_params[181].struct_type_name = NULL;
    _module_params[181].element_type = 21;
    _module_params[181].fn_sig = NULL;
    _module_params[182].name = "line";
    _module_params[182].type = 0;
    _module_params[182].struct_type_name = NULL;
    _module_params[182].element_type = 21;
    _module_params[182].fn_sig = NULL;
    _module_params[183].name = "column";
    _module_params[183].type = 0;
    _module_params[183].struct_type_name = NULL;
    _module_params[183].element_type = 21;
    _module_params[183].fn_sig = NULL;

    /* Function: diag_location_empty */
    _module_functions[231].name = "diag_location_empty";
    _module_functions[231].param_count = 0;
    _module_functions[231].return_type = 8;
    _module_functions[231].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[231].return_fn_sig = NULL;
    _module_functions[231].return_type_info = NULL;
    _module_functions[231].body = NULL;
    _module_functions[231].shadow_test = NULL;
    _module_functions[231].is_extern = false;
    _module_functions[231].returns_gc_managed = false;
    _module_functions[231].requires_manual_free = false;
    _module_functions[231].returns_borrowed = false;
    _module_functions[231].cleanup_function = NULL;
    _module_functions[231].params = NULL;

    /* Function: diag_new */
    _module_functions[232].name = "diag_new";
    _module_functions[232].param_count = 5;
    _module_functions[232].return_type = 8;
    _module_functions[232].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[232].return_fn_sig = NULL;
    _module_functions[232].return_type_info = NULL;
    _module_functions[232].body = NULL;
    _module_functions[232].shadow_test = NULL;
    _module_functions[232].is_extern = false;
    _module_functions[232].returns_gc_managed = false;
    _module_functions[232].requires_manual_free = false;
    _module_functions[232].returns_borrowed = false;
    _module_functions[232].cleanup_function = NULL;
    _module_functions[232].params = &_module_params[184];
    _module_params[184].name = "phase";
    _module_params[184].type = 0;
    _module_params[184].struct_type_name = NULL;
    _module_params[184].element_type = 21;
    _module_params[184].fn_sig = NULL;
    _module_params[185].name = "severity";
    _module_params[185].type = 0;
    _module_params[185].struct_type_name = NULL;
    _module_params[185].element_type = 21;
    _module_params[185].fn_sig = NULL;
    _module_params[186].name = "code";
    _module_params[186].type = 4;
    _module_params[186].struct_type_name = NULL;
    _module_params[186].element_type = 21;
    _module_params[186].fn_sig = NULL;
    _module_params[187].name = "message";
    _module_params[187].type = 4;
    _module_params[187].struct_type_name = NULL;
    _module_params[187].element_type = 21;
    _module_params[187].fn_sig = NULL;
    _module_params[188].name = "location";
    _module_params[188].type = 8;
    _module_params[188].struct_type_name = "CompilerSourceLocation";
    _module_params[188].element_type = 21;
    _module_params[188].fn_sig = NULL;

    /* Function: diag_simple */
    _module_functions[233].name = "diag_simple";
    _module_functions[233].param_count = 4;
    _module_functions[233].return_type = 8;
    _module_functions[233].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[233].return_fn_sig = NULL;
    _module_functions[233].return_type_info = NULL;
    _module_functions[233].body = NULL;
    _module_functions[233].shadow_test = NULL;
    _module_functions[233].is_extern = false;
    _module_functions[233].returns_gc_managed = false;
    _module_functions[233].requires_manual_free = false;
    _module_functions[233].returns_borrowed = false;
    _module_functions[233].cleanup_function = NULL;
    _module_functions[233].params = &_module_params[189];
    _module_params[189].name = "phase";
    _module_params[189].type = 0;
    _module_params[189].struct_type_name = NULL;
    _module_params[189].element_type = 21;
    _module_params[189].fn_sig = NULL;
    _module_params[190].name = "severity";
    _module_params[190].type = 0;
    _module_params[190].struct_type_name = NULL;
    _module_params[190].element_type = 21;
    _module_params[190].fn_sig = NULL;
    _module_params[191].name = "code";
    _module_params[191].type = 4;
    _module_params[191].struct_type_name = NULL;
    _module_params[191].element_type = 21;
    _module_params[191].fn_sig = NULL;
    _module_params[192].name = "message";
    _module_params[192].type = 4;
    _module_params[192].struct_type_name = NULL;
    _module_params[192].element_type = 21;
    _module_params[192].fn_sig = NULL;

    /* Function: diag_error */
    _module_functions[234].name = "diag_error";
    _module_functions[234].param_count = 4;
    _module_functions[234].return_type = 8;
    _module_functions[234].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[234].return_fn_sig = NULL;
    _module_functions[234].return_type_info = NULL;
    _module_functions[234].body = NULL;
    _module_functions[234].shadow_test = NULL;
    _module_functions[234].is_extern = false;
    _module_functions[234].returns_gc_managed = false;
    _module_functions[234].requires_manual_free = false;
    _module_functions[234].returns_borrowed = false;
    _module_functions[234].cleanup_function = NULL;
    _module_functions[234].params = &_module_params[193];
    _module_params[193].name = "phase";
    _module_params[193].type = 0;
    _module_params[193].struct_type_name = NULL;
    _module_params[193].element_type = 21;
    _module_params[193].fn_sig = NULL;
    _module_params[194].name = "code";
    _module_params[194].type = 4;
    _module_params[194].struct_type_name = NULL;
    _module_params[194].element_type = 21;
    _module_params[194].fn_sig = NULL;
    _module_params[195].name = "message";
    _module_params[195].type = 4;
    _module_params[195].struct_type_name = NULL;
    _module_params[195].element_type = 21;
    _module_params[195].fn_sig = NULL;
    _module_params[196].name = "location";
    _module_params[196].type = 8;
    _module_params[196].struct_type_name = "CompilerSourceLocation";
    _module_params[196].element_type = 21;
    _module_params[196].fn_sig = NULL;

    /* Function: diag_error_simple */
    _module_functions[235].name = "diag_error_simple";
    _module_functions[235].param_count = 3;
    _module_functions[235].return_type = 8;
    _module_functions[235].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[235].return_fn_sig = NULL;
    _module_functions[235].return_type_info = NULL;
    _module_functions[235].body = NULL;
    _module_functions[235].shadow_test = NULL;
    _module_functions[235].is_extern = false;
    _module_functions[235].returns_gc_managed = false;
    _module_functions[235].requires_manual_free = false;
    _module_functions[235].returns_borrowed = false;
    _module_functions[235].cleanup_function = NULL;
    _module_functions[235].params = &_module_params[197];
    _module_params[197].name = "phase";
    _module_params[197].type = 0;
    _module_params[197].struct_type_name = NULL;
    _module_params[197].element_type = 21;
    _module_params[197].fn_sig = NULL;
    _module_params[198].name = "code";
    _module_params[198].type = 4;
    _module_params[198].struct_type_name = NULL;
    _module_params[198].element_type = 21;
    _module_params[198].fn_sig = NULL;
    _module_params[199].name = "message";
    _module_params[199].type = 4;
    _module_params[199].struct_type_name = NULL;
    _module_params[199].element_type = 21;
    _module_params[199].fn_sig = NULL;

    /* Function: diag_warning */
    _module_functions[236].name = "diag_warning";
    _module_functions[236].param_count = 4;
    _module_functions[236].return_type = 8;
    _module_functions[236].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[236].return_fn_sig = NULL;
    _module_functions[236].return_type_info = NULL;
    _module_functions[236].body = NULL;
    _module_functions[236].shadow_test = NULL;
    _module_functions[236].is_extern = false;
    _module_functions[236].returns_gc_managed = false;
    _module_functions[236].requires_manual_free = false;
    _module_functions[236].returns_borrowed = false;
    _module_functions[236].cleanup_function = NULL;
    _module_functions[236].params = &_module_params[200];
    _module_params[200].name = "phase";
    _module_params[200].type = 0;
    _module_params[200].struct_type_name = NULL;
    _module_params[200].element_type = 21;
    _module_params[200].fn_sig = NULL;
    _module_params[201].name = "code";
    _module_params[201].type = 4;
    _module_params[201].struct_type_name = NULL;
    _module_params[201].element_type = 21;
    _module_params[201].fn_sig = NULL;
    _module_params[202].name = "message";
    _module_params[202].type = 4;
    _module_params[202].struct_type_name = NULL;
    _module_params[202].element_type = 21;
    _module_params[202].fn_sig = NULL;
    _module_params[203].name = "location";
    _module_params[203].type = 8;
    _module_params[203].struct_type_name = "CompilerSourceLocation";
    _module_params[203].element_type = 21;
    _module_params[203].fn_sig = NULL;

    /* Function: diag_warning_simple */
    _module_functions[237].name = "diag_warning_simple";
    _module_functions[237].param_count = 3;
    _module_functions[237].return_type = 8;
    _module_functions[237].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[237].return_fn_sig = NULL;
    _module_functions[237].return_type_info = NULL;
    _module_functions[237].body = NULL;
    _module_functions[237].shadow_test = NULL;
    _module_functions[237].is_extern = false;
    _module_functions[237].returns_gc_managed = false;
    _module_functions[237].requires_manual_free = false;
    _module_functions[237].returns_borrowed = false;
    _module_functions[237].cleanup_function = NULL;
    _module_functions[237].params = &_module_params[204];
    _module_params[204].name = "phase";
    _module_params[204].type = 0;
    _module_params[204].struct_type_name = NULL;
    _module_params[204].element_type = 21;
    _module_params[204].fn_sig = NULL;
    _module_params[205].name = "code";
    _module_params[205].type = 4;
    _module_params[205].struct_type_name = NULL;
    _module_params[205].element_type = 21;
    _module_params[205].fn_sig = NULL;
    _module_params[206].name = "message";
    _module_params[206].type = 4;
    _module_params[206].struct_type_name = NULL;
    _module_params[206].element_type = 21;
    _module_params[206].fn_sig = NULL;

    /* Function: diag_info */
    _module_functions[238].name = "diag_info";
    _module_functions[238].param_count = 4;
    _module_functions[238].return_type = 8;
    _module_functions[238].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[238].return_fn_sig = NULL;
    _module_functions[238].return_type_info = NULL;
    _module_functions[238].body = NULL;
    _module_functions[238].shadow_test = NULL;
    _module_functions[238].is_extern = false;
    _module_functions[238].returns_gc_managed = false;
    _module_functions[238].requires_manual_free = false;
    _module_functions[238].returns_borrowed = false;
    _module_functions[238].cleanup_function = NULL;
    _module_functions[238].params = &_module_params[207];
    _module_params[207].name = "phase";
    _module_params[207].type = 0;
    _module_params[207].struct_type_name = NULL;
    _module_params[207].element_type = 21;
    _module_params[207].fn_sig = NULL;
    _module_params[208].name = "code";
    _module_params[208].type = 4;
    _module_params[208].struct_type_name = NULL;
    _module_params[208].element_type = 21;
    _module_params[208].fn_sig = NULL;
    _module_params[209].name = "message";
    _module_params[209].type = 4;
    _module_params[209].struct_type_name = NULL;
    _module_params[209].element_type = 21;
    _module_params[209].fn_sig = NULL;
    _module_params[210].name = "location";
    _module_params[210].type = 8;
    _module_params[210].struct_type_name = "CompilerSourceLocation";
    _module_params[210].element_type = 21;
    _module_params[210].fn_sig = NULL;

    /* Function: diag_info_simple */
    _module_functions[239].name = "diag_info_simple";
    _module_functions[239].param_count = 3;
    _module_functions[239].return_type = 8;
    _module_functions[239].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[239].return_fn_sig = NULL;
    _module_functions[239].return_type_info = NULL;
    _module_functions[239].body = NULL;
    _module_functions[239].shadow_test = NULL;
    _module_functions[239].is_extern = false;
    _module_functions[239].returns_gc_managed = false;
    _module_functions[239].requires_manual_free = false;
    _module_functions[239].returns_borrowed = false;
    _module_functions[239].cleanup_function = NULL;
    _module_functions[239].params = &_module_params[211];
    _module_params[211].name = "phase";
    _module_params[211].type = 0;
    _module_params[211].struct_type_name = NULL;
    _module_params[211].element_type = 21;
    _module_params[211].fn_sig = NULL;
    _module_params[212].name = "code";
    _module_params[212].type = 4;
    _module_params[212].struct_type_name = NULL;
    _module_params[212].element_type = 21;
    _module_params[212].fn_sig = NULL;
    _module_params[213].name = "message";
    _module_params[213].type = 4;
    _module_params[213].struct_type_name = NULL;
    _module_params[213].element_type = 21;
    _module_params[213].fn_sig = NULL;

    /* Function: diag_lexer_error */
    _module_functions[240].name = "diag_lexer_error";
    _module_functions[240].param_count = 3;
    _module_functions[240].return_type = 8;
    _module_functions[240].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[240].return_fn_sig = NULL;
    _module_functions[240].return_type_info = NULL;
    _module_functions[240].body = NULL;
    _module_functions[240].shadow_test = NULL;
    _module_functions[240].is_extern = false;
    _module_functions[240].returns_gc_managed = false;
    _module_functions[240].requires_manual_free = false;
    _module_functions[240].returns_borrowed = false;
    _module_functions[240].cleanup_function = NULL;
    _module_functions[240].params = &_module_params[214];
    _module_params[214].name = "code";
    _module_params[214].type = 4;
    _module_params[214].struct_type_name = NULL;
    _module_params[214].element_type = 21;
    _module_params[214].fn_sig = NULL;
    _module_params[215].name = "message";
    _module_params[215].type = 4;
    _module_params[215].struct_type_name = NULL;
    _module_params[215].element_type = 21;
    _module_params[215].fn_sig = NULL;
    _module_params[216].name = "location";
    _module_params[216].type = 8;
    _module_params[216].struct_type_name = "CompilerSourceLocation";
    _module_params[216].element_type = 21;
    _module_params[216].fn_sig = NULL;

    /* Function: diag_parser_error */
    _module_functions[241].name = "diag_parser_error";
    _module_functions[241].param_count = 3;
    _module_functions[241].return_type = 8;
    _module_functions[241].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[241].return_fn_sig = NULL;
    _module_functions[241].return_type_info = NULL;
    _module_functions[241].body = NULL;
    _module_functions[241].shadow_test = NULL;
    _module_functions[241].is_extern = false;
    _module_functions[241].returns_gc_managed = false;
    _module_functions[241].requires_manual_free = false;
    _module_functions[241].returns_borrowed = false;
    _module_functions[241].cleanup_function = NULL;
    _module_functions[241].params = &_module_params[217];
    _module_params[217].name = "code";
    _module_params[217].type = 4;
    _module_params[217].struct_type_name = NULL;
    _module_params[217].element_type = 21;
    _module_params[217].fn_sig = NULL;
    _module_params[218].name = "message";
    _module_params[218].type = 4;
    _module_params[218].struct_type_name = NULL;
    _module_params[218].element_type = 21;
    _module_params[218].fn_sig = NULL;
    _module_params[219].name = "location";
    _module_params[219].type = 8;
    _module_params[219].struct_type_name = "CompilerSourceLocation";
    _module_params[219].element_type = 21;
    _module_params[219].fn_sig = NULL;

    /* Function: diag_typecheck_error */
    _module_functions[242].name = "diag_typecheck_error";
    _module_functions[242].param_count = 3;
    _module_functions[242].return_type = 8;
    _module_functions[242].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[242].return_fn_sig = NULL;
    _module_functions[242].return_type_info = NULL;
    _module_functions[242].body = NULL;
    _module_functions[242].shadow_test = NULL;
    _module_functions[242].is_extern = false;
    _module_functions[242].returns_gc_managed = false;
    _module_functions[242].requires_manual_free = false;
    _module_functions[242].returns_borrowed = false;
    _module_functions[242].cleanup_function = NULL;
    _module_functions[242].params = &_module_params[220];
    _module_params[220].name = "code";
    _module_params[220].type = 4;
    _module_params[220].struct_type_name = NULL;
    _module_params[220].element_type = 21;
    _module_params[220].fn_sig = NULL;
    _module_params[221].name = "message";
    _module_params[221].type = 4;
    _module_params[221].struct_type_name = NULL;
    _module_params[221].element_type = 21;
    _module_params[221].fn_sig = NULL;
    _module_params[222].name = "location";
    _module_params[222].type = 8;
    _module_params[222].struct_type_name = "CompilerSourceLocation";
    _module_params[222].element_type = 21;
    _module_params[222].fn_sig = NULL;

    /* Function: diag_transpiler_error */
    _module_functions[243].name = "diag_transpiler_error";
    _module_functions[243].param_count = 3;
    _module_functions[243].return_type = 8;
    _module_functions[243].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[243].return_fn_sig = NULL;
    _module_functions[243].return_type_info = NULL;
    _module_functions[243].body = NULL;
    _module_functions[243].shadow_test = NULL;
    _module_functions[243].is_extern = false;
    _module_functions[243].returns_gc_managed = false;
    _module_functions[243].requires_manual_free = false;
    _module_functions[243].returns_borrowed = false;
    _module_functions[243].cleanup_function = NULL;
    _module_functions[243].params = &_module_params[223];
    _module_params[223].name = "code";
    _module_params[223].type = 4;
    _module_params[223].struct_type_name = NULL;
    _module_params[223].element_type = 21;
    _module_params[223].fn_sig = NULL;
    _module_params[224].name = "message";
    _module_params[224].type = 4;
    _module_params[224].struct_type_name = NULL;
    _module_params[224].element_type = 21;
    _module_params[224].fn_sig = NULL;
    _module_params[225].name = "location";
    _module_params[225].type = 8;
    _module_params[225].struct_type_name = "CompilerSourceLocation";
    _module_params[225].element_type = 21;
    _module_params[225].fn_sig = NULL;

    /* Function: diag_list_new */
    _module_functions[244].name = "diag_list_new";
    _module_functions[244].param_count = 0;
    _module_functions[244].return_type = 15;
    _module_functions[244].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[244].return_fn_sig = NULL;
    _module_functions[244].return_type_info = NULL;
    _module_functions[244].body = NULL;
    _module_functions[244].shadow_test = NULL;
    _module_functions[244].is_extern = false;
    _module_functions[244].returns_gc_managed = false;
    _module_functions[244].requires_manual_free = false;
    _module_functions[244].returns_borrowed = false;
    _module_functions[244].cleanup_function = NULL;
    _module_functions[244].params = NULL;

    /* Function: diag_list_add */
    _module_functions[245].name = "diag_list_add";
    _module_functions[245].param_count = 2;
    _module_functions[245].return_type = 6;
    _module_functions[245].return_struct_type_name = NULL;
    _module_functions[245].return_fn_sig = NULL;
    _module_functions[245].return_type_info = NULL;
    _module_functions[245].body = NULL;
    _module_functions[245].shadow_test = NULL;
    _module_functions[245].is_extern = false;
    _module_functions[245].returns_gc_managed = false;
    _module_functions[245].requires_manual_free = false;
    _module_functions[245].returns_borrowed = false;
    _module_functions[245].cleanup_function = NULL;
    _module_functions[245].params = &_module_params[226];
    _module_params[226].name = "list";
    _module_params[226].type = 15;
    _module_params[226].struct_type_name = "CompilerDiagnostic";
    _module_params[226].element_type = 21;
    _module_params[226].fn_sig = NULL;
    _module_params[227].name = "diag";
    _module_params[227].type = 8;
    _module_params[227].struct_type_name = "CompilerDiagnostic";
    _module_params[227].element_type = 21;
    _module_params[227].fn_sig = NULL;

    /* Function: diag_list_count */
    _module_functions[246].name = "diag_list_count";
    _module_functions[246].param_count = 1;
    _module_functions[246].return_type = 0;
    _module_functions[246].return_struct_type_name = NULL;
    _module_functions[246].return_fn_sig = NULL;
    _module_functions[246].return_type_info = NULL;
    _module_functions[246].body = NULL;
    _module_functions[246].shadow_test = NULL;
    _module_functions[246].is_extern = false;
    _module_functions[246].returns_gc_managed = false;
    _module_functions[246].requires_manual_free = false;
    _module_functions[246].returns_borrowed = false;
    _module_functions[246].cleanup_function = NULL;
    _module_functions[246].params = &_module_params[228];
    _module_params[228].name = "list";
    _module_params[228].type = 15;
    _module_params[228].struct_type_name = "CompilerDiagnostic";
    _module_params[228].element_type = 21;
    _module_params[228].fn_sig = NULL;

    /* Function: diag_list_get */
    _module_functions[247].name = "diag_list_get";
    _module_functions[247].param_count = 2;
    _module_functions[247].return_type = 8;
    _module_functions[247].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[247].return_fn_sig = NULL;
    _module_functions[247].return_type_info = NULL;
    _module_functions[247].body = NULL;
    _module_functions[247].shadow_test = NULL;
    _module_functions[247].is_extern = false;
    _module_functions[247].returns_gc_managed = false;
    _module_functions[247].requires_manual_free = false;
    _module_functions[247].returns_borrowed = false;
    _module_functions[247].cleanup_function = NULL;
    _module_functions[247].params = &_module_params[229];
    _module_params[229].name = "list";
    _module_params[229].type = 15;
    _module_params[229].struct_type_name = "CompilerDiagnostic";
    _module_params[229].element_type = 21;
    _module_params[229].fn_sig = NULL;
    _module_params[230].name = "index";
    _module_params[230].type = 0;
    _module_params[230].struct_type_name = NULL;
    _module_params[230].element_type = 21;
    _module_params[230].fn_sig = NULL;

    /* Function: diag_list_has_errors */
    _module_functions[248].name = "diag_list_has_errors";
    _module_functions[248].param_count = 1;
    _module_functions[248].return_type = 3;
    _module_functions[248].return_struct_type_name = NULL;
    _module_functions[248].return_fn_sig = NULL;
    _module_functions[248].return_type_info = NULL;
    _module_functions[248].body = NULL;
    _module_functions[248].shadow_test = NULL;
    _module_functions[248].is_extern = false;
    _module_functions[248].returns_gc_managed = false;
    _module_functions[248].requires_manual_free = false;
    _module_functions[248].returns_borrowed = false;
    _module_functions[248].cleanup_function = NULL;
    _module_functions[248].params = &_module_params[231];
    _module_params[231].name = "list";
    _module_params[231].type = 15;
    _module_params[231].struct_type_name = "CompilerDiagnostic";
    _module_params[231].element_type = 21;
    _module_params[231].fn_sig = NULL;

    /* Function: diag_make_type_error */
    _module_functions[249].name = "diag_make_type_error";
    _module_functions[249].param_count = 2;
    _module_functions[249].return_type = 4;
    _module_functions[249].return_struct_type_name = NULL;
    _module_functions[249].return_fn_sig = NULL;
    _module_functions[249].return_type_info = NULL;
    _module_functions[249].body = NULL;
    _module_functions[249].shadow_test = NULL;
    _module_functions[249].is_extern = false;
    _module_functions[249].returns_gc_managed = true;
    _module_functions[249].requires_manual_free = false;
    _module_functions[249].returns_borrowed = false;
    _module_functions[249].cleanup_function = NULL;
    _module_functions[249].params = &_module_params[232];
    _module_params[232].name = "expected_type";
    _module_params[232].type = 4;
    _module_params[232].struct_type_name = NULL;
    _module_params[232].element_type = 21;
    _module_params[232].fn_sig = NULL;
    _module_params[233].name = "found_type";
    _module_params[233].type = 4;
    _module_params[233].struct_type_name = NULL;
    _module_params[233].element_type = 21;
    _module_params[233].fn_sig = NULL;

    /* Function: diag_make_undefined_error */
    _module_functions[250].name = "diag_make_undefined_error";
    _module_functions[250].param_count = 1;
    _module_functions[250].return_type = 4;
    _module_functions[250].return_struct_type_name = NULL;
    _module_functions[250].return_fn_sig = NULL;
    _module_functions[250].return_type_info = NULL;
    _module_functions[250].body = NULL;
    _module_functions[250].shadow_test = NULL;
    _module_functions[250].is_extern = false;
    _module_functions[250].returns_gc_managed = true;
    _module_functions[250].requires_manual_free = false;
    _module_functions[250].returns_borrowed = false;
    _module_functions[250].cleanup_function = NULL;
    _module_functions[250].params = &_module_params[234];
    _module_params[234].name = "name";
    _module_params[234].type = 4;
    _module_params[234].struct_type_name = NULL;
    _module_params[234].element_type = 21;
    _module_params[234].fn_sig = NULL;

    /* Function: diag_id_io_open */
    _module_functions[251].name = "diag_id_io_open";
    _module_functions[251].param_count = 0;
    _module_functions[251].return_type = 4;
    _module_functions[251].return_struct_type_name = NULL;
    _module_functions[251].return_fn_sig = NULL;
    _module_functions[251].return_type_info = NULL;
    _module_functions[251].body = NULL;
    _module_functions[251].shadow_test = NULL;
    _module_functions[251].is_extern = false;
    _module_functions[251].returns_gc_managed = true;
    _module_functions[251].requires_manual_free = false;
    _module_functions[251].returns_borrowed = false;
    _module_functions[251].cleanup_function = NULL;
    _module_functions[251].params = NULL;

    /* Function: diag_id_lex_failed */
    _module_functions[252].name = "diag_id_lex_failed";
    _module_functions[252].param_count = 0;
    _module_functions[252].return_type = 4;
    _module_functions[252].return_struct_type_name = NULL;
    _module_functions[252].return_fn_sig = NULL;
    _module_functions[252].return_type_info = NULL;
    _module_functions[252].body = NULL;
    _module_functions[252].shadow_test = NULL;
    _module_functions[252].is_extern = false;
    _module_functions[252].returns_gc_managed = true;
    _module_functions[252].requires_manual_free = false;
    _module_functions[252].returns_borrowed = false;
    _module_functions[252].cleanup_function = NULL;
    _module_functions[252].params = NULL;

    /* Function: diag_id_parse_failed */
    _module_functions[253].name = "diag_id_parse_failed";
    _module_functions[253].param_count = 0;
    _module_functions[253].return_type = 4;
    _module_functions[253].return_struct_type_name = NULL;
    _module_functions[253].return_fn_sig = NULL;
    _module_functions[253].return_type_info = NULL;
    _module_functions[253].body = NULL;
    _module_functions[253].shadow_test = NULL;
    _module_functions[253].is_extern = false;
    _module_functions[253].returns_gc_managed = true;
    _module_functions[253].requires_manual_free = false;
    _module_functions[253].returns_borrowed = false;
    _module_functions[253].cleanup_function = NULL;
    _module_functions[253].params = NULL;

    /* Function: diag_id_import_failed */
    _module_functions[254].name = "diag_id_import_failed";
    _module_functions[254].param_count = 0;
    _module_functions[254].return_type = 4;
    _module_functions[254].return_struct_type_name = NULL;
    _module_functions[254].return_fn_sig = NULL;
    _module_functions[254].return_type_info = NULL;
    _module_functions[254].body = NULL;
    _module_functions[254].shadow_test = NULL;
    _module_functions[254].is_extern = false;
    _module_functions[254].returns_gc_managed = true;
    _module_functions[254].requires_manual_free = false;
    _module_functions[254].returns_borrowed = false;
    _module_functions[254].cleanup_function = NULL;
    _module_functions[254].params = NULL;

    /* Function: diag_id_type_failed */
    _module_functions[255].name = "diag_id_type_failed";
    _module_functions[255].param_count = 0;
    _module_functions[255].return_type = 4;
    _module_functions[255].return_struct_type_name = NULL;
    _module_functions[255].return_fn_sig = NULL;
    _module_functions[255].return_type_info = NULL;
    _module_functions[255].body = NULL;
    _module_functions[255].shadow_test = NULL;
    _module_functions[255].is_extern = false;
    _module_functions[255].returns_gc_managed = true;
    _module_functions[255].requires_manual_free = false;
    _module_functions[255].returns_borrowed = false;
    _module_functions[255].cleanup_function = NULL;
    _module_functions[255].params = NULL;

    /* Function: diag_id_mod_compile */
    _module_functions[256].name = "diag_id_mod_compile";
    _module_functions[256].param_count = 0;
    _module_functions[256].return_type = 4;
    _module_functions[256].return_struct_type_name = NULL;
    _module_functions[256].return_fn_sig = NULL;
    _module_functions[256].return_type_info = NULL;
    _module_functions[256].body = NULL;
    _module_functions[256].shadow_test = NULL;
    _module_functions[256].is_extern = false;
    _module_functions[256].returns_gc_managed = true;
    _module_functions[256].requires_manual_free = false;
    _module_functions[256].returns_borrowed = false;
    _module_functions[256].cleanup_function = NULL;
    _module_functions[256].params = NULL;

    /* Function: diag_id_shadow_failed */
    _module_functions[257].name = "diag_id_shadow_failed";
    _module_functions[257].param_count = 0;
    _module_functions[257].return_type = 4;
    _module_functions[257].return_struct_type_name = NULL;
    _module_functions[257].return_fn_sig = NULL;
    _module_functions[257].return_type_info = NULL;
    _module_functions[257].body = NULL;
    _module_functions[257].shadow_test = NULL;
    _module_functions[257].is_extern = false;
    _module_functions[257].returns_gc_managed = true;
    _module_functions[257].requires_manual_free = false;
    _module_functions[257].returns_borrowed = false;
    _module_functions[257].cleanup_function = NULL;
    _module_functions[257].params = NULL;

    /* Function: diag_id_trans_failed */
    _module_functions[258].name = "diag_id_trans_failed";
    _module_functions[258].param_count = 0;
    _module_functions[258].return_type = 4;
    _module_functions[258].return_struct_type_name = NULL;
    _module_functions[258].return_fn_sig = NULL;
    _module_functions[258].return_type_info = NULL;
    _module_functions[258].body = NULL;
    _module_functions[258].shadow_test = NULL;
    _module_functions[258].is_extern = false;
    _module_functions[258].returns_gc_managed = true;
    _module_functions[258].requires_manual_free = false;
    _module_functions[258].returns_borrowed = false;
    _module_functions[258].cleanup_function = NULL;
    _module_functions[258].params = NULL;

    /* Function: diag_id_c_temp */
    _module_functions[259].name = "diag_id_c_temp";
    _module_functions[259].param_count = 0;
    _module_functions[259].return_type = 4;
    _module_functions[259].return_struct_type_name = NULL;
    _module_functions[259].return_fn_sig = NULL;
    _module_functions[259].return_type_info = NULL;
    _module_functions[259].body = NULL;
    _module_functions[259].shadow_test = NULL;
    _module_functions[259].is_extern = false;
    _module_functions[259].returns_gc_managed = true;
    _module_functions[259].requires_manual_free = false;
    _module_functions[259].returns_borrowed = false;
    _module_functions[259].cleanup_function = NULL;
    _module_functions[259].params = NULL;

    /* Function: diag_id_cc_cmd */
    _module_functions[260].name = "diag_id_cc_cmd";
    _module_functions[260].param_count = 0;
    _module_functions[260].return_type = 4;
    _module_functions[260].return_struct_type_name = NULL;
    _module_functions[260].return_fn_sig = NULL;
    _module_functions[260].return_type_info = NULL;
    _module_functions[260].body = NULL;
    _module_functions[260].shadow_test = NULL;
    _module_functions[260].is_extern = false;
    _module_functions[260].returns_gc_managed = true;
    _module_functions[260].requires_manual_free = false;
    _module_functions[260].returns_borrowed = false;
    _module_functions[260].cleanup_function = NULL;
    _module_functions[260].params = NULL;

    /* Function: diag_id_cc_failed */
    _module_functions[261].name = "diag_id_cc_failed";
    _module_functions[261].param_count = 0;
    _module_functions[261].return_type = 4;
    _module_functions[261].return_struct_type_name = NULL;
    _module_functions[261].return_fn_sig = NULL;
    _module_functions[261].return_type_info = NULL;
    _module_functions[261].body = NULL;
    _module_functions[261].shadow_test = NULL;
    _module_functions[261].is_extern = false;
    _module_functions[261].returns_gc_managed = true;
    _module_functions[261].requires_manual_free = false;
    _module_functions[261].returns_borrowed = false;
    _module_functions[261].cleanup_function = NULL;
    _module_functions[261].params = NULL;

    /* Function: diag_id_src_utf8 */
    _module_functions[262].name = "diag_id_src_utf8";
    _module_functions[262].param_count = 0;
    _module_functions[262].return_type = 4;
    _module_functions[262].return_struct_type_name = NULL;
    _module_functions[262].return_fn_sig = NULL;
    _module_functions[262].return_type_info = NULL;
    _module_functions[262].body = NULL;
    _module_functions[262].shadow_test = NULL;
    _module_functions[262].is_extern = false;
    _module_functions[262].returns_gc_managed = true;
    _module_functions[262].requires_manual_free = false;
    _module_functions[262].returns_borrowed = false;
    _module_functions[262].cleanup_function = NULL;
    _module_functions[262].params = NULL;

    /* Function: diag_en */
    _module_functions[263].name = "diag_en";
    _module_functions[263].param_count = 1;
    _module_functions[263].return_type = 4;
    _module_functions[263].return_struct_type_name = NULL;
    _module_functions[263].return_fn_sig = NULL;
    _module_functions[263].return_type_info = NULL;
    _module_functions[263].body = NULL;
    _module_functions[263].shadow_test = NULL;
    _module_functions[263].is_extern = false;
    _module_functions[263].returns_gc_managed = true;
    _module_functions[263].requires_manual_free = false;
    _module_functions[263].returns_borrowed = false;
    _module_functions[263].cleanup_function = NULL;
    _module_functions[263].params = &_module_params[235];
    _module_params[235].name = "code";
    _module_params[235].type = 4;
    _module_params[235].struct_type_name = NULL;
    _module_params[235].element_type = 21;
    _module_params[235].fn_sig = NULL;

    /* Function: fs_walkdir */
    _module_functions[264].name = "fs_walkdir";
    _module_functions[264].param_count = 1;
    _module_functions[264].return_type = 7;
    _module_functions[264].return_struct_type_name = NULL;
    _module_functions[264].return_fn_sig = NULL;
    _module_functions[264].return_type_info = &_type_infos[0];
    _module_functions[264].body = NULL;
    _module_functions[264].shadow_test = NULL;
    _module_functions[264].is_extern = true;
    _module_functions[264].returns_gc_managed = false;
    _module_functions[264].requires_manual_free = false;
    _module_functions[264].returns_borrowed = false;
    _module_functions[264].cleanup_function = NULL;
    _module_functions[264].params = &_module_params[236];
    _module_params[236].name = "_root";
    _module_params[236].type = 4;
    _module_params[236].struct_type_name = NULL;
    _module_params[236].element_type = 21;
    _module_params[236].fn_sig = NULL;

    /* Function: path_normalize */
    _module_functions[265].name = "path_normalize";
    _module_functions[265].param_count = 1;
    _module_functions[265].return_type = 4;
    _module_functions[265].return_struct_type_name = NULL;
    _module_functions[265].return_fn_sig = NULL;
    _module_functions[265].return_type_info = NULL;
    _module_functions[265].body = NULL;
    _module_functions[265].shadow_test = NULL;
    _module_functions[265].is_extern = true;
    _module_functions[265].returns_gc_managed = true;
    _module_functions[265].requires_manual_free = false;
    _module_functions[265].returns_borrowed = false;
    _module_functions[265].cleanup_function = NULL;
    _module_functions[265].params = &_module_params[237];
    _module_params[237].name = "_path";
    _module_params[237].type = 4;
    _module_params[237].struct_type_name = NULL;
    _module_params[237].element_type = 21;
    _module_params[237].fn_sig = NULL;

    /* Function: path_canonical */
    _module_functions[266].name = "path_canonical";
    _module_functions[266].param_count = 1;
    _module_functions[266].return_type = 4;
    _module_functions[266].return_struct_type_name = NULL;
    _module_functions[266].return_fn_sig = NULL;
    _module_functions[266].return_type_info = NULL;
    _module_functions[266].body = NULL;
    _module_functions[266].shadow_test = NULL;
    _module_functions[266].is_extern = true;
    _module_functions[266].returns_gc_managed = true;
    _module_functions[266].requires_manual_free = false;
    _module_functions[266].returns_borrowed = false;
    _module_functions[266].cleanup_function = NULL;
    _module_functions[266].params = &_module_params[238];
    _module_params[238].name = "_path";
    _module_params[238].type = 4;
    _module_params[238].struct_type_name = NULL;
    _module_params[238].element_type = 21;
    _module_params[238].fn_sig = NULL;

    /* Function: path_join */
    _module_functions[267].name = "path_join";
    _module_functions[267].param_count = 2;
    _module_functions[267].return_type = 4;
    _module_functions[267].return_struct_type_name = NULL;
    _module_functions[267].return_fn_sig = NULL;
    _module_functions[267].return_type_info = NULL;
    _module_functions[267].body = NULL;
    _module_functions[267].shadow_test = NULL;
    _module_functions[267].is_extern = true;
    _module_functions[267].returns_gc_managed = true;
    _module_functions[267].requires_manual_free = false;
    _module_functions[267].returns_borrowed = false;
    _module_functions[267].cleanup_function = NULL;
    _module_functions[267].params = &_module_params[239];
    _module_params[239].name = "_a";
    _module_params[239].type = 4;
    _module_params[239].struct_type_name = NULL;
    _module_params[239].element_type = 21;
    _module_params[239].fn_sig = NULL;
    _module_params[240].name = "_b";
    _module_params[240].type = 4;
    _module_params[240].struct_type_name = NULL;
    _module_params[240].element_type = 21;
    _module_params[240].fn_sig = NULL;

    /* Function: path_basename */
    _module_functions[268].name = "path_basename";
    _module_functions[268].param_count = 1;
    _module_functions[268].return_type = 4;
    _module_functions[268].return_struct_type_name = NULL;
    _module_functions[268].return_fn_sig = NULL;
    _module_functions[268].return_type_info = NULL;
    _module_functions[268].body = NULL;
    _module_functions[268].shadow_test = NULL;
    _module_functions[268].is_extern = true;
    _module_functions[268].returns_gc_managed = true;
    _module_functions[268].requires_manual_free = false;
    _module_functions[268].returns_borrowed = false;
    _module_functions[268].cleanup_function = NULL;
    _module_functions[268].params = &_module_params[241];
    _module_params[241].name = "_path";
    _module_params[241].type = 4;
    _module_params[241].struct_type_name = NULL;
    _module_params[241].element_type = 21;
    _module_params[241].fn_sig = NULL;

    /* Function: path_dirname */
    _module_functions[269].name = "path_dirname";
    _module_functions[269].param_count = 1;
    _module_functions[269].return_type = 4;
    _module_functions[269].return_struct_type_name = NULL;
    _module_functions[269].return_fn_sig = NULL;
    _module_functions[269].return_type_info = NULL;
    _module_functions[269].body = NULL;
    _module_functions[269].shadow_test = NULL;
    _module_functions[269].is_extern = true;
    _module_functions[269].returns_gc_managed = true;
    _module_functions[269].requires_manual_free = false;
    _module_functions[269].returns_borrowed = false;
    _module_functions[269].cleanup_function = NULL;
    _module_functions[269].params = &_module_params[242];
    _module_params[242].name = "_path";
    _module_params[242].type = 4;
    _module_params[242].struct_type_name = NULL;
    _module_params[242].element_type = 21;
    _module_params[242].fn_sig = NULL;

    /* Function: path_relpath */
    _module_functions[270].name = "path_relpath";
    _module_functions[270].param_count = 2;
    _module_functions[270].return_type = 4;
    _module_functions[270].return_struct_type_name = NULL;
    _module_functions[270].return_fn_sig = NULL;
    _module_functions[270].return_type_info = NULL;
    _module_functions[270].body = NULL;
    _module_functions[270].shadow_test = NULL;
    _module_functions[270].is_extern = true;
    _module_functions[270].returns_gc_managed = true;
    _module_functions[270].requires_manual_free = false;
    _module_functions[270].returns_borrowed = false;
    _module_functions[270].cleanup_function = NULL;
    _module_functions[270].params = &_module_params[243];
    _module_params[243].name = "_target";
    _module_params[243].type = 4;
    _module_params[243].struct_type_name = NULL;
    _module_params[243].element_type = 21;
    _module_params[243].fn_sig = NULL;
    _module_params[244].name = "_base";
    _module_params[244].type = 4;
    _module_params[244].struct_type_name = NULL;
    _module_params[244].element_type = 21;
    _module_params[244].fn_sig = NULL;

    /* Function: file_read */
    _module_functions[271].name = "file_read";
    _module_functions[271].param_count = 1;
    _module_functions[271].return_type = 4;
    _module_functions[271].return_struct_type_name = NULL;
    _module_functions[271].return_fn_sig = NULL;
    _module_functions[271].return_type_info = NULL;
    _module_functions[271].body = NULL;
    _module_functions[271].shadow_test = NULL;
    _module_functions[271].is_extern = true;
    _module_functions[271].returns_gc_managed = true;
    _module_functions[271].requires_manual_free = false;
    _module_functions[271].returns_borrowed = false;
    _module_functions[271].cleanup_function = NULL;
    _module_functions[271].params = &_module_params[245];
    _module_params[245].name = "_path";
    _module_params[245].type = 4;
    _module_params[245].struct_type_name = NULL;
    _module_params[245].element_type = 21;
    _module_params[245].fn_sig = NULL;

    /* Function: file_write */
    _module_functions[272].name = "file_write";
    _module_functions[272].param_count = 2;
    _module_functions[272].return_type = 0;
    _module_functions[272].return_struct_type_name = NULL;
    _module_functions[272].return_fn_sig = NULL;
    _module_functions[272].return_type_info = NULL;
    _module_functions[272].body = NULL;
    _module_functions[272].shadow_test = NULL;
    _module_functions[272].is_extern = true;
    _module_functions[272].returns_gc_managed = false;
    _module_functions[272].requires_manual_free = false;
    _module_functions[272].returns_borrowed = false;
    _module_functions[272].cleanup_function = NULL;
    _module_functions[272].params = &_module_params[246];
    _module_params[246].name = "_path";
    _module_params[246].type = 4;
    _module_params[246].struct_type_name = NULL;
    _module_params[246].element_type = 21;
    _module_params[246].fn_sig = NULL;
    _module_params[247].name = "_content";
    _module_params[247].type = 4;
    _module_params[247].struct_type_name = NULL;
    _module_params[247].element_type = 21;
    _module_params[247].fn_sig = NULL;

    /* Function: file_append */
    _module_functions[273].name = "file_append";
    _module_functions[273].param_count = 2;
    _module_functions[273].return_type = 0;
    _module_functions[273].return_struct_type_name = NULL;
    _module_functions[273].return_fn_sig = NULL;
    _module_functions[273].return_type_info = NULL;
    _module_functions[273].body = NULL;
    _module_functions[273].shadow_test = NULL;
    _module_functions[273].is_extern = true;
    _module_functions[273].returns_gc_managed = false;
    _module_functions[273].requires_manual_free = false;
    _module_functions[273].returns_borrowed = false;
    _module_functions[273].cleanup_function = NULL;
    _module_functions[273].params = &_module_params[248];
    _module_params[248].name = "_path";
    _module_params[248].type = 4;
    _module_params[248].struct_type_name = NULL;
    _module_params[248].element_type = 21;
    _module_params[248].fn_sig = NULL;
    _module_params[249].name = "_content";
    _module_params[249].type = 4;
    _module_params[249].struct_type_name = NULL;
    _module_params[249].element_type = 21;
    _module_params[249].fn_sig = NULL;

    /* Function: file_exists */
    _module_functions[274].name = "file_exists";
    _module_functions[274].param_count = 1;
    _module_functions[274].return_type = 3;
    _module_functions[274].return_struct_type_name = NULL;
    _module_functions[274].return_fn_sig = NULL;
    _module_functions[274].return_type_info = NULL;
    _module_functions[274].body = NULL;
    _module_functions[274].shadow_test = NULL;
    _module_functions[274].is_extern = true;
    _module_functions[274].returns_gc_managed = false;
    _module_functions[274].requires_manual_free = false;
    _module_functions[274].returns_borrowed = false;
    _module_functions[274].cleanup_function = NULL;
    _module_functions[274].params = &_module_params[250];
    _module_params[250].name = "_path";
    _module_params[250].type = 4;
    _module_params[250].struct_type_name = NULL;
    _module_params[250].element_type = 21;
    _module_params[250].fn_sig = NULL;

    /* Function: file_delete */
    _module_functions[275].name = "file_delete";
    _module_functions[275].param_count = 1;
    _module_functions[275].return_type = 0;
    _module_functions[275].return_struct_type_name = NULL;
    _module_functions[275].return_fn_sig = NULL;
    _module_functions[275].return_type_info = NULL;
    _module_functions[275].body = NULL;
    _module_functions[275].shadow_test = NULL;
    _module_functions[275].is_extern = true;
    _module_functions[275].returns_gc_managed = false;
    _module_functions[275].requires_manual_free = false;
    _module_functions[275].returns_borrowed = false;
    _module_functions[275].cleanup_function = NULL;
    _module_functions[275].params = &_module_params[251];
    _module_params[251].name = "_path";
    _module_params[251].type = 4;
    _module_params[251].struct_type_name = NULL;
    _module_params[251].element_type = 21;
    _module_params[251].fn_sig = NULL;

    /* Function: fs_mkdir_p */
    _module_functions[276].name = "fs_mkdir_p";
    _module_functions[276].param_count = 1;
    _module_functions[276].return_type = 0;
    _module_functions[276].return_struct_type_name = NULL;
    _module_functions[276].return_fn_sig = NULL;
    _module_functions[276].return_type_info = NULL;
    _module_functions[276].body = NULL;
    _module_functions[276].shadow_test = NULL;
    _module_functions[276].is_extern = true;
    _module_functions[276].returns_gc_managed = false;
    _module_functions[276].requires_manual_free = false;
    _module_functions[276].returns_borrowed = false;
    _module_functions[276].cleanup_function = NULL;
    _module_functions[276].params = &_module_params[252];
    _module_params[252].name = "_path";
    _module_params[252].type = 4;
    _module_params[252].struct_type_name = NULL;
    _module_params[252].element_type = 21;
    _module_params[252].fn_sig = NULL;

    /* Function: file_copy */
    _module_functions[277].name = "file_copy";
    _module_functions[277].param_count = 2;
    _module_functions[277].return_type = 0;
    _module_functions[277].return_struct_type_name = NULL;
    _module_functions[277].return_fn_sig = NULL;
    _module_functions[277].return_type_info = NULL;
    _module_functions[277].body = NULL;
    _module_functions[277].shadow_test = NULL;
    _module_functions[277].is_extern = true;
    _module_functions[277].returns_gc_managed = false;
    _module_functions[277].requires_manual_free = false;
    _module_functions[277].returns_borrowed = false;
    _module_functions[277].cleanup_function = NULL;
    _module_functions[277].params = &_module_params[253];
    _module_params[253].name = "_src";
    _module_params[253].type = 4;
    _module_params[253].struct_type_name = NULL;
    _module_params[253].element_type = 21;
    _module_params[253].fn_sig = NULL;
    _module_params[254].name = "_dst";
    _module_params[254].type = 4;
    _module_params[254].struct_type_name = NULL;
    _module_params[254].element_type = 21;
    _module_params[254].fn_sig = NULL;

    /* Function: dir_copy */
    _module_functions[278].name = "dir_copy";
    _module_functions[278].param_count = 2;
    _module_functions[278].return_type = 0;
    _module_functions[278].return_struct_type_name = NULL;
    _module_functions[278].return_fn_sig = NULL;
    _module_functions[278].return_type_info = NULL;
    _module_functions[278].body = NULL;
    _module_functions[278].shadow_test = NULL;
    _module_functions[278].is_extern = true;
    _module_functions[278].returns_gc_managed = false;
    _module_functions[278].requires_manual_free = false;
    _module_functions[278].returns_borrowed = false;
    _module_functions[278].cleanup_function = NULL;
    _module_functions[278].params = &_module_params[255];
    _module_params[255].name = "_src";
    _module_params[255].type = 4;
    _module_params[255].struct_type_name = NULL;
    _module_params[255].element_type = 21;
    _module_params[255].fn_sig = NULL;
    _module_params[256].name = "_dst";
    _module_params[256].type = 4;
    _module_params[256].struct_type_name = NULL;
    _module_params[256].element_type = 21;
    _module_params[256].fn_sig = NULL;

    /* Function: walkdir */
    _module_functions[279].name = "walkdir";
    _module_functions[279].param_count = 1;
    _module_functions[279].return_type = 7;
    _module_functions[279].return_struct_type_name = NULL;
    _module_functions[279].return_fn_sig = NULL;
    _module_functions[279].return_type_info = &_type_infos[1];
    _module_functions[279].body = NULL;
    _module_functions[279].shadow_test = NULL;
    _module_functions[279].is_extern = false;
    _module_functions[279].returns_gc_managed = false;
    _module_functions[279].requires_manual_free = false;
    _module_functions[279].returns_borrowed = false;
    _module_functions[279].cleanup_function = NULL;
    _module_functions[279].params = &_module_params[257];
    _module_params[257].name = "root";
    _module_params[257].type = 4;
    _module_params[257].struct_type_name = NULL;
    _module_params[257].element_type = 21;
    _module_params[257].fn_sig = NULL;

    /* Function: normalize */
    _module_functions[280].name = "normalize";
    _module_functions[280].param_count = 1;
    _module_functions[280].return_type = 4;
    _module_functions[280].return_struct_type_name = NULL;
    _module_functions[280].return_fn_sig = NULL;
    _module_functions[280].return_type_info = NULL;
    _module_functions[280].body = NULL;
    _module_functions[280].shadow_test = NULL;
    _module_functions[280].is_extern = false;
    _module_functions[280].returns_gc_managed = true;
    _module_functions[280].requires_manual_free = false;
    _module_functions[280].returns_borrowed = false;
    _module_functions[280].cleanup_function = NULL;
    _module_functions[280].params = &_module_params[258];
    _module_params[258].name = "path";
    _module_params[258].type = 4;
    _module_params[258].struct_type_name = NULL;
    _module_params[258].element_type = 21;
    _module_params[258].fn_sig = NULL;

    /* Function: canonical */
    _module_functions[281].name = "canonical";
    _module_functions[281].param_count = 1;
    _module_functions[281].return_type = 4;
    _module_functions[281].return_struct_type_name = NULL;
    _module_functions[281].return_fn_sig = NULL;
    _module_functions[281].return_type_info = NULL;
    _module_functions[281].body = NULL;
    _module_functions[281].shadow_test = NULL;
    _module_functions[281].is_extern = false;
    _module_functions[281].returns_gc_managed = true;
    _module_functions[281].requires_manual_free = false;
    _module_functions[281].returns_borrowed = false;
    _module_functions[281].cleanup_function = NULL;
    _module_functions[281].params = &_module_params[259];
    _module_params[259].name = "path";
    _module_params[259].type = 4;
    _module_params[259].struct_type_name = NULL;
    _module_params[259].element_type = 21;
    _module_params[259].fn_sig = NULL;

    /* Function: join */
    _module_functions[282].name = "join";
    _module_functions[282].param_count = 2;
    _module_functions[282].return_type = 4;
    _module_functions[282].return_struct_type_name = NULL;
    _module_functions[282].return_fn_sig = NULL;
    _module_functions[282].return_type_info = NULL;
    _module_functions[282].body = NULL;
    _module_functions[282].shadow_test = NULL;
    _module_functions[282].is_extern = false;
    _module_functions[282].returns_gc_managed = true;
    _module_functions[282].requires_manual_free = false;
    _module_functions[282].returns_borrowed = false;
    _module_functions[282].cleanup_function = NULL;
    _module_functions[282].params = &_module_params[260];
    _module_params[260].name = "a";
    _module_params[260].type = 4;
    _module_params[260].struct_type_name = NULL;
    _module_params[260].element_type = 21;
    _module_params[260].fn_sig = NULL;
    _module_params[261].name = "b";
    _module_params[261].type = 4;
    _module_params[261].struct_type_name = NULL;
    _module_params[261].element_type = 21;
    _module_params[261].fn_sig = NULL;

    /* Function: basename */
    _module_functions[283].name = "basename";
    _module_functions[283].param_count = 1;
    _module_functions[283].return_type = 4;
    _module_functions[283].return_struct_type_name = NULL;
    _module_functions[283].return_fn_sig = NULL;
    _module_functions[283].return_type_info = NULL;
    _module_functions[283].body = NULL;
    _module_functions[283].shadow_test = NULL;
    _module_functions[283].is_extern = false;
    _module_functions[283].returns_gc_managed = true;
    _module_functions[283].requires_manual_free = false;
    _module_functions[283].returns_borrowed = false;
    _module_functions[283].cleanup_function = NULL;
    _module_functions[283].params = &_module_params[262];
    _module_params[262].name = "path";
    _module_params[262].type = 4;
    _module_params[262].struct_type_name = NULL;
    _module_params[262].element_type = 21;
    _module_params[262].fn_sig = NULL;

    /* Function: dirname */
    _module_functions[284].name = "dirname";
    _module_functions[284].param_count = 1;
    _module_functions[284].return_type = 4;
    _module_functions[284].return_struct_type_name = NULL;
    _module_functions[284].return_fn_sig = NULL;
    _module_functions[284].return_type_info = NULL;
    _module_functions[284].body = NULL;
    _module_functions[284].shadow_test = NULL;
    _module_functions[284].is_extern = false;
    _module_functions[284].returns_gc_managed = true;
    _module_functions[284].requires_manual_free = false;
    _module_functions[284].returns_borrowed = false;
    _module_functions[284].cleanup_function = NULL;
    _module_functions[284].params = &_module_params[263];
    _module_params[263].name = "path";
    _module_params[263].type = 4;
    _module_params[263].struct_type_name = NULL;
    _module_params[263].element_type = 21;
    _module_params[263].fn_sig = NULL;

    /* Function: relpath */
    _module_functions[285].name = "relpath";
    _module_functions[285].param_count = 2;
    _module_functions[285].return_type = 4;
    _module_functions[285].return_struct_type_name = NULL;
    _module_functions[285].return_fn_sig = NULL;
    _module_functions[285].return_type_info = NULL;
    _module_functions[285].body = NULL;
    _module_functions[285].shadow_test = NULL;
    _module_functions[285].is_extern = false;
    _module_functions[285].returns_gc_managed = true;
    _module_functions[285].requires_manual_free = false;
    _module_functions[285].returns_borrowed = false;
    _module_functions[285].cleanup_function = NULL;
    _module_functions[285].params = &_module_params[264];
    _module_params[264].name = "target";
    _module_params[264].type = 4;
    _module_params[264].struct_type_name = NULL;
    _module_params[264].element_type = 21;
    _module_params[264].fn_sig = NULL;
    _module_params[265].name = "base";
    _module_params[265].type = 4;
    _module_params[265].struct_type_name = NULL;
    _module_params[265].element_type = 21;
    _module_params[265].fn_sig = NULL;

    /* Function: cwd */
    _module_functions[286].name = "cwd";
    _module_functions[286].param_count = 0;
    _module_functions[286].return_type = 4;
    _module_functions[286].return_struct_type_name = NULL;
    _module_functions[286].return_fn_sig = NULL;
    _module_functions[286].return_type_info = NULL;
    _module_functions[286].body = NULL;
    _module_functions[286].shadow_test = NULL;
    _module_functions[286].is_extern = false;
    _module_functions[286].returns_gc_managed = true;
    _module_functions[286].requires_manual_free = false;
    _module_functions[286].returns_borrowed = false;
    _module_functions[286].cleanup_function = NULL;
    _module_functions[286].params = NULL;

    /* Function: glob_match_impl */
    _module_functions[287].name = "glob_match_impl";
    _module_functions[287].param_count = 4;
    _module_functions[287].return_type = 3;
    _module_functions[287].return_struct_type_name = NULL;
    _module_functions[287].return_fn_sig = NULL;
    _module_functions[287].return_type_info = NULL;
    _module_functions[287].body = NULL;
    _module_functions[287].shadow_test = NULL;
    _module_functions[287].is_extern = false;
    _module_functions[287].returns_gc_managed = false;
    _module_functions[287].requires_manual_free = false;
    _module_functions[287].returns_borrowed = false;
    _module_functions[287].cleanup_function = NULL;
    _module_functions[287].params = &_module_params[266];
    _module_params[266].name = "pattern";
    _module_params[266].type = 4;
    _module_params[266].struct_type_name = NULL;
    _module_params[266].element_type = 21;
    _module_params[266].fn_sig = NULL;
    _module_params[267].name = "pi";
    _module_params[267].type = 0;
    _module_params[267].struct_type_name = NULL;
    _module_params[267].element_type = 21;
    _module_params[267].fn_sig = NULL;
    _module_params[268].name = "text";
    _module_params[268].type = 4;
    _module_params[268].struct_type_name = NULL;
    _module_params[268].element_type = 21;
    _module_params[268].fn_sig = NULL;
    _module_params[269].name = "ti";
    _module_params[269].type = 0;
    _module_params[269].struct_type_name = NULL;
    _module_params[269].element_type = 21;
    _module_params[269].fn_sig = NULL;

    /* Function: glob_match */
    _module_functions[288].name = "glob_match";
    _module_functions[288].param_count = 2;
    _module_functions[288].return_type = 3;
    _module_functions[288].return_struct_type_name = NULL;
    _module_functions[288].return_fn_sig = NULL;
    _module_functions[288].return_type_info = NULL;
    _module_functions[288].body = NULL;
    _module_functions[288].shadow_test = NULL;
    _module_functions[288].is_extern = false;
    _module_functions[288].returns_gc_managed = false;
    _module_functions[288].requires_manual_free = false;
    _module_functions[288].returns_borrowed = false;
    _module_functions[288].cleanup_function = NULL;
    _module_functions[288].params = &_module_params[270];
    _module_params[270].name = "pattern";
    _module_params[270].type = 4;
    _module_params[270].struct_type_name = NULL;
    _module_params[270].element_type = 21;
    _module_params[270].fn_sig = NULL;
    _module_params[271].name = "text";
    _module_params[271].type = 4;
    _module_params[271].struct_type_name = NULL;
    _module_params[271].element_type = 21;
    _module_params[271].fn_sig = NULL;

    /* Function: glob */
    _module_functions[289].name = "glob";
    _module_functions[289].param_count = 2;
    _module_functions[289].return_type = 7;
    _module_functions[289].return_struct_type_name = NULL;
    _module_functions[289].return_fn_sig = NULL;
    _module_functions[289].return_type_info = &_type_infos[2];
    _module_functions[289].body = NULL;
    _module_functions[289].shadow_test = NULL;
    _module_functions[289].is_extern = false;
    _module_functions[289].returns_gc_managed = false;
    _module_functions[289].requires_manual_free = false;
    _module_functions[289].returns_borrowed = false;
    _module_functions[289].cleanup_function = NULL;
    _module_functions[289].params = &_module_params[272];
    _module_params[272].name = "root";
    _module_params[272].type = 4;
    _module_params[272].struct_type_name = NULL;
    _module_params[272].element_type = 21;
    _module_params[272].fn_sig = NULL;
    _module_params[273].name = "pattern";
    _module_params[273].type = 4;
    _module_params[273].struct_type_name = NULL;
    _module_params[273].element_type = 21;
    _module_params[273].fn_sig = NULL;

    /* Function: read */
    _module_functions[290].name = "read";
    _module_functions[290].param_count = 1;
    _module_functions[290].return_type = 4;
    _module_functions[290].return_struct_type_name = NULL;
    _module_functions[290].return_fn_sig = NULL;
    _module_functions[290].return_type_info = NULL;
    _module_functions[290].body = NULL;
    _module_functions[290].shadow_test = NULL;
    _module_functions[290].is_extern = false;
    _module_functions[290].returns_gc_managed = true;
    _module_functions[290].requires_manual_free = false;
    _module_functions[290].returns_borrowed = false;
    _module_functions[290].cleanup_function = NULL;
    _module_functions[290].params = &_module_params[274];
    _module_params[274].name = "path";
    _module_params[274].type = 4;
    _module_params[274].struct_type_name = NULL;
    _module_params[274].element_type = 21;
    _module_params[274].fn_sig = NULL;

    /* Function: write */
    _module_functions[291].name = "write";
    _module_functions[291].param_count = 2;
    _module_functions[291].return_type = 0;
    _module_functions[291].return_struct_type_name = NULL;
    _module_functions[291].return_fn_sig = NULL;
    _module_functions[291].return_type_info = NULL;
    _module_functions[291].body = NULL;
    _module_functions[291].shadow_test = NULL;
    _module_functions[291].is_extern = false;
    _module_functions[291].returns_gc_managed = false;
    _module_functions[291].requires_manual_free = false;
    _module_functions[291].returns_borrowed = false;
    _module_functions[291].cleanup_function = NULL;
    _module_functions[291].params = &_module_params[275];
    _module_params[275].name = "path";
    _module_params[275].type = 4;
    _module_params[275].struct_type_name = NULL;
    _module_params[275].element_type = 21;
    _module_params[275].fn_sig = NULL;
    _module_params[276].name = "content";
    _module_params[276].type = 4;
    _module_params[276].struct_type_name = NULL;
    _module_params[276].element_type = 21;
    _module_params[276].fn_sig = NULL;

    /* Function: append */
    _module_functions[292].name = "append";
    _module_functions[292].param_count = 2;
    _module_functions[292].return_type = 0;
    _module_functions[292].return_struct_type_name = NULL;
    _module_functions[292].return_fn_sig = NULL;
    _module_functions[292].return_type_info = NULL;
    _module_functions[292].body = NULL;
    _module_functions[292].shadow_test = NULL;
    _module_functions[292].is_extern = false;
    _module_functions[292].returns_gc_managed = false;
    _module_functions[292].requires_manual_free = false;
    _module_functions[292].returns_borrowed = false;
    _module_functions[292].cleanup_function = NULL;
    _module_functions[292].params = &_module_params[277];
    _module_params[277].name = "path";
    _module_params[277].type = 4;
    _module_params[277].struct_type_name = NULL;
    _module_params[277].element_type = 21;
    _module_params[277].fn_sig = NULL;
    _module_params[278].name = "content";
    _module_params[278].type = 4;
    _module_params[278].struct_type_name = NULL;
    _module_params[278].element_type = 21;
    _module_params[278].fn_sig = NULL;

    /* Function: exists */
    _module_functions[293].name = "exists";
    _module_functions[293].param_count = 1;
    _module_functions[293].return_type = 3;
    _module_functions[293].return_struct_type_name = NULL;
    _module_functions[293].return_fn_sig = NULL;
    _module_functions[293].return_type_info = NULL;
    _module_functions[293].body = NULL;
    _module_functions[293].shadow_test = NULL;
    _module_functions[293].is_extern = false;
    _module_functions[293].returns_gc_managed = false;
    _module_functions[293].requires_manual_free = false;
    _module_functions[293].returns_borrowed = false;
    _module_functions[293].cleanup_function = NULL;
    _module_functions[293].params = &_module_params[279];
    _module_params[279].name = "path";
    _module_params[279].type = 4;
    _module_params[279].struct_type_name = NULL;
    _module_params[279].element_type = 21;
    _module_params[279].fn_sig = NULL;

    /* Function: delete */
    _module_functions[294].name = "delete";
    _module_functions[294].param_count = 1;
    _module_functions[294].return_type = 0;
    _module_functions[294].return_struct_type_name = NULL;
    _module_functions[294].return_fn_sig = NULL;
    _module_functions[294].return_type_info = NULL;
    _module_functions[294].body = NULL;
    _module_functions[294].shadow_test = NULL;
    _module_functions[294].is_extern = false;
    _module_functions[294].returns_gc_managed = false;
    _module_functions[294].requires_manual_free = false;
    _module_functions[294].returns_borrowed = false;
    _module_functions[294].cleanup_function = NULL;
    _module_functions[294].params = &_module_params[280];
    _module_params[280].name = "path";
    _module_params[280].type = 4;
    _module_params[280].struct_type_name = NULL;
    _module_params[280].element_type = 21;
    _module_params[280].fn_sig = NULL;

    /* Function: mkdir_p */
    _module_functions[295].name = "mkdir_p";
    _module_functions[295].param_count = 1;
    _module_functions[295].return_type = 0;
    _module_functions[295].return_struct_type_name = NULL;
    _module_functions[295].return_fn_sig = NULL;
    _module_functions[295].return_type_info = NULL;
    _module_functions[295].body = NULL;
    _module_functions[295].shadow_test = NULL;
    _module_functions[295].is_extern = false;
    _module_functions[295].returns_gc_managed = false;
    _module_functions[295].requires_manual_free = false;
    _module_functions[295].returns_borrowed = false;
    _module_functions[295].cleanup_function = NULL;
    _module_functions[295].params = &_module_params[281];
    _module_params[281].name = "path";
    _module_params[281].type = 4;
    _module_params[281].struct_type_name = NULL;
    _module_params[281].element_type = 21;
    _module_params[281].fn_sig = NULL;

    /* Function: copy_file */
    _module_functions[296].name = "copy_file";
    _module_functions[296].param_count = 2;
    _module_functions[296].return_type = 0;
    _module_functions[296].return_struct_type_name = NULL;
    _module_functions[296].return_fn_sig = NULL;
    _module_functions[296].return_type_info = NULL;
    _module_functions[296].body = NULL;
    _module_functions[296].shadow_test = NULL;
    _module_functions[296].is_extern = false;
    _module_functions[296].returns_gc_managed = false;
    _module_functions[296].requires_manual_free = false;
    _module_functions[296].returns_borrowed = false;
    _module_functions[296].cleanup_function = NULL;
    _module_functions[296].params = &_module_params[282];
    _module_params[282].name = "src";
    _module_params[282].type = 4;
    _module_params[282].struct_type_name = NULL;
    _module_params[282].element_type = 21;
    _module_params[282].fn_sig = NULL;
    _module_params[283].name = "dst";
    _module_params[283].type = 4;
    _module_params[283].struct_type_name = NULL;
    _module_params[283].element_type = 21;
    _module_params[283].fn_sig = NULL;

    /* Function: copy_dir */
    _module_functions[297].name = "copy_dir";
    _module_functions[297].param_count = 2;
    _module_functions[297].return_type = 0;
    _module_functions[297].return_struct_type_name = NULL;
    _module_functions[297].return_fn_sig = NULL;
    _module_functions[297].return_type_info = NULL;
    _module_functions[297].body = NULL;
    _module_functions[297].shadow_test = NULL;
    _module_functions[297].is_extern = false;
    _module_functions[297].returns_gc_managed = false;
    _module_functions[297].requires_manual_free = false;
    _module_functions[297].returns_borrowed = false;
    _module_functions[297].cleanup_function = NULL;
    _module_functions[297].params = &_module_params[284];
    _module_params[284].name = "src";
    _module_params[284].type = 4;
    _module_params[284].struct_type_name = NULL;
    _module_params[284].element_type = 21;
    _module_params[284].fn_sig = NULL;
    _module_params[285].name = "dst";
    _module_params[285].type = 4;
    _module_params[285].struct_type_name = NULL;
    _module_params[285].element_type = 21;
    _module_params[285].fn_sig = NULL;

    /* Function: is_identifier_start */
    _module_functions[298].name = "is_identifier_start";
    _module_functions[298].param_count = 1;
    _module_functions[298].return_type = 3;
    _module_functions[298].return_struct_type_name = NULL;
    _module_functions[298].return_fn_sig = NULL;
    _module_functions[298].return_type_info = NULL;
    _module_functions[298].body = NULL;
    _module_functions[298].shadow_test = NULL;
    _module_functions[298].is_extern = false;
    _module_functions[298].returns_gc_managed = false;
    _module_functions[298].requires_manual_free = false;
    _module_functions[298].returns_borrowed = false;
    _module_functions[298].cleanup_function = NULL;
    _module_functions[298].params = &_module_params[286];
    _module_params[286].name = "c";
    _module_params[286].type = 0;
    _module_params[286].struct_type_name = NULL;
    _module_params[286].element_type = 21;
    _module_params[286].fn_sig = NULL;

    /* Function: is_identifier_char */
    _module_functions[299].name = "is_identifier_char";
    _module_functions[299].param_count = 1;
    _module_functions[299].return_type = 3;
    _module_functions[299].return_struct_type_name = NULL;
    _module_functions[299].return_fn_sig = NULL;
    _module_functions[299].return_type_info = NULL;
    _module_functions[299].body = NULL;
    _module_functions[299].shadow_test = NULL;
    _module_functions[299].is_extern = false;
    _module_functions[299].returns_gc_managed = false;
    _module_functions[299].requires_manual_free = false;
    _module_functions[299].returns_borrowed = false;
    _module_functions[299].cleanup_function = NULL;
    _module_functions[299].params = &_module_params[287];
    _module_params[287].name = "c";
    _module_params[287].type = 0;
    _module_params[287].struct_type_name = NULL;
    _module_params[287].element_type = 21;
    _module_params[287].fn_sig = NULL;

    /* Function: is_whitespace_char */
    _module_functions[300].name = "is_whitespace_char";
    _module_functions[300].param_count = 1;
    _module_functions[300].return_type = 3;
    _module_functions[300].return_struct_type_name = NULL;
    _module_functions[300].return_fn_sig = NULL;
    _module_functions[300].return_type_info = NULL;
    _module_functions[300].body = NULL;
    _module_functions[300].shadow_test = NULL;
    _module_functions[300].is_extern = false;
    _module_functions[300].returns_gc_managed = false;
    _module_functions[300].requires_manual_free = false;
    _module_functions[300].returns_borrowed = false;
    _module_functions[300].cleanup_function = NULL;
    _module_functions[300].params = &_module_params[288];
    _module_params[288].name = "c";
    _module_params[288].type = 0;
    _module_params[288].struct_type_name = NULL;
    _module_params[288].element_type = 21;
    _module_params[288].fn_sig = NULL;

    /* Function: is_digit_char */
    _module_functions[301].name = "is_digit_char";
    _module_functions[301].param_count = 1;
    _module_functions[301].return_type = 3;
    _module_functions[301].return_struct_type_name = NULL;
    _module_functions[301].return_fn_sig = NULL;
    _module_functions[301].return_type_info = NULL;
    _module_functions[301].body = NULL;
    _module_functions[301].shadow_test = NULL;
    _module_functions[301].is_extern = false;
    _module_functions[301].returns_gc_managed = false;
    _module_functions[301].requires_manual_free = false;
    _module_functions[301].returns_borrowed = false;
    _module_functions[301].cleanup_function = NULL;
    _module_functions[301].params = &_module_params[289];
    _module_params[289].name = "c";
    _module_params[289].type = 0;
    _module_params[289].struct_type_name = NULL;
    _module_params[289].element_type = 21;
    _module_params[289].fn_sig = NULL;

    /* Function: keyword_group1 */
    _module_functions[302].name = "keyword_group1";
    _module_functions[302].param_count = 1;
    _module_functions[302].return_type = 0;
    _module_functions[302].return_struct_type_name = NULL;
    _module_functions[302].return_fn_sig = NULL;
    _module_functions[302].return_type_info = NULL;
    _module_functions[302].body = NULL;
    _module_functions[302].shadow_test = NULL;
    _module_functions[302].is_extern = false;
    _module_functions[302].returns_gc_managed = false;
    _module_functions[302].requires_manual_free = false;
    _module_functions[302].returns_borrowed = false;
    _module_functions[302].cleanup_function = NULL;
    _module_functions[302].params = &_module_params[290];
    _module_params[290].name = "s";
    _module_params[290].type = 4;
    _module_params[290].struct_type_name = NULL;
    _module_params[290].element_type = 21;
    _module_params[290].fn_sig = NULL;

    /* Function: keyword_group2 */
    _module_functions[303].name = "keyword_group2";
    _module_functions[303].param_count = 1;
    _module_functions[303].return_type = 0;
    _module_functions[303].return_struct_type_name = NULL;
    _module_functions[303].return_fn_sig = NULL;
    _module_functions[303].return_type_info = NULL;
    _module_functions[303].body = NULL;
    _module_functions[303].shadow_test = NULL;
    _module_functions[303].is_extern = false;
    _module_functions[303].returns_gc_managed = false;
    _module_functions[303].requires_manual_free = false;
    _module_functions[303].returns_borrowed = false;
    _module_functions[303].cleanup_function = NULL;
    _module_functions[303].params = &_module_params[291];
    _module_params[291].name = "s";
    _module_params[291].type = 4;
    _module_params[291].struct_type_name = NULL;
    _module_params[291].element_type = 21;
    _module_params[291].fn_sig = NULL;

    /* Function: keyword_group3 */
    _module_functions[304].name = "keyword_group3";
    _module_functions[304].param_count = 1;
    _module_functions[304].return_type = 0;
    _module_functions[304].return_struct_type_name = NULL;
    _module_functions[304].return_fn_sig = NULL;
    _module_functions[304].return_type_info = NULL;
    _module_functions[304].body = NULL;
    _module_functions[304].shadow_test = NULL;
    _module_functions[304].is_extern = false;
    _module_functions[304].returns_gc_managed = false;
    _module_functions[304].requires_manual_free = false;
    _module_functions[304].returns_borrowed = false;
    _module_functions[304].cleanup_function = NULL;
    _module_functions[304].params = &_module_params[292];
    _module_params[292].name = "s";
    _module_params[292].type = 4;
    _module_params[292].struct_type_name = NULL;
    _module_params[292].element_type = 21;
    _module_params[292].fn_sig = NULL;

    /* Function: keyword_group4 */
    _module_functions[305].name = "keyword_group4";
    _module_functions[305].param_count = 1;
    _module_functions[305].return_type = 0;
    _module_functions[305].return_struct_type_name = NULL;
    _module_functions[305].return_fn_sig = NULL;
    _module_functions[305].return_type_info = NULL;
    _module_functions[305].body = NULL;
    _module_functions[305].shadow_test = NULL;
    _module_functions[305].is_extern = false;
    _module_functions[305].returns_gc_managed = false;
    _module_functions[305].requires_manual_free = false;
    _module_functions[305].returns_borrowed = false;
    _module_functions[305].cleanup_function = NULL;
    _module_functions[305].params = &_module_params[293];
    _module_params[293].name = "s";
    _module_params[293].type = 4;
    _module_params[293].struct_type_name = NULL;
    _module_params[293].element_type = 21;
    _module_params[293].fn_sig = NULL;

    /* Function: keyword_group5 */
    _module_functions[306].name = "keyword_group5";
    _module_functions[306].param_count = 1;
    _module_functions[306].return_type = 0;
    _module_functions[306].return_struct_type_name = NULL;
    _module_functions[306].return_fn_sig = NULL;
    _module_functions[306].return_type_info = NULL;
    _module_functions[306].body = NULL;
    _module_functions[306].shadow_test = NULL;
    _module_functions[306].is_extern = false;
    _module_functions[306].returns_gc_managed = false;
    _module_functions[306].requires_manual_free = false;
    _module_functions[306].returns_borrowed = false;
    _module_functions[306].cleanup_function = NULL;
    _module_functions[306].params = &_module_params[294];
    _module_params[294].name = "s";
    _module_params[294].type = 4;
    _module_params[294].struct_type_name = NULL;
    _module_params[294].element_type = 21;
    _module_params[294].fn_sig = NULL;

    /* Function: keyword_or_identifier */
    _module_functions[307].name = "keyword_or_identifier";
    _module_functions[307].param_count = 1;
    _module_functions[307].return_type = 0;
    _module_functions[307].return_struct_type_name = NULL;
    _module_functions[307].return_fn_sig = NULL;
    _module_functions[307].return_type_info = NULL;
    _module_functions[307].body = NULL;
    _module_functions[307].shadow_test = NULL;
    _module_functions[307].is_extern = false;
    _module_functions[307].returns_gc_managed = false;
    _module_functions[307].requires_manual_free = false;
    _module_functions[307].returns_borrowed = false;
    _module_functions[307].cleanup_function = NULL;
    _module_functions[307].params = &_module_params[295];
    _module_params[295].name = "s";
    _module_params[295].type = 4;
    _module_params[295].struct_type_name = NULL;
    _module_params[295].element_type = 21;
    _module_params[295].fn_sig = NULL;

    /* Function: push_tok */
    _module_functions[308].name = "push_tok";
    _module_functions[308].param_count = 5;
    _module_functions[308].return_type = 6;
    _module_functions[308].return_struct_type_name = NULL;
    _module_functions[308].return_fn_sig = NULL;
    _module_functions[308].return_type_info = NULL;
    _module_functions[308].body = NULL;
    _module_functions[308].shadow_test = NULL;
    _module_functions[308].is_extern = false;
    _module_functions[308].returns_gc_managed = false;
    _module_functions[308].requires_manual_free = false;
    _module_functions[308].returns_borrowed = false;
    _module_functions[308].cleanup_function = NULL;
    _module_functions[308].params = &_module_params[296];
    _module_params[296].name = "tokens";
    _module_params[296].type = 15;
    _module_params[296].struct_type_name = "LexerToken";
    _module_params[296].element_type = 21;
    _module_params[296].fn_sig = NULL;
    _module_params[297].name = "token_type";
    _module_params[297].type = 0;
    _module_params[297].struct_type_name = NULL;
    _module_params[297].element_type = 21;
    _module_params[297].fn_sig = NULL;
    _module_params[298].name = "value";
    _module_params[298].type = 4;
    _module_params[298].struct_type_name = NULL;
    _module_params[298].element_type = 21;
    _module_params[298].fn_sig = NULL;
    _module_params[299].name = "line";
    _module_params[299].type = 0;
    _module_params[299].struct_type_name = NULL;
    _module_params[299].element_type = 21;
    _module_params[299].fn_sig = NULL;
    _module_params[300].name = "column";
    _module_params[300].type = 0;
    _module_params[300].struct_type_name = NULL;
    _module_params[300].element_type = 21;
    _module_params[300].fn_sig = NULL;

    /* Function: process_string */
    _module_functions[309].name = "process_string";
    _module_functions[309].param_count = 6;
    _module_functions[309].return_type = 0;
    _module_functions[309].return_struct_type_name = NULL;
    _module_functions[309].return_fn_sig = NULL;
    _module_functions[309].return_type_info = NULL;
    _module_functions[309].body = NULL;
    _module_functions[309].shadow_test = NULL;
    _module_functions[309].is_extern = false;
    _module_functions[309].returns_gc_managed = false;
    _module_functions[309].requires_manual_free = false;
    _module_functions[309].returns_borrowed = false;
    _module_functions[309].cleanup_function = NULL;
    _module_functions[309].params = &_module_params[301];
    _module_params[301].name = "source";
    _module_params[301].type = 4;
    _module_params[301].struct_type_name = NULL;
    _module_params[301].element_type = 21;
    _module_params[301].fn_sig = NULL;
    _module_params[302].name = "i";
    _module_params[302].type = 0;
    _module_params[302].struct_type_name = NULL;
    _module_params[302].element_type = 21;
    _module_params[302].fn_sig = NULL;
    _module_params[303].name = "len";
    _module_params[303].type = 0;
    _module_params[303].struct_type_name = NULL;
    _module_params[303].element_type = 21;
    _module_params[303].fn_sig = NULL;
    _module_params[304].name = "tokens";
    _module_params[304].type = 15;
    _module_params[304].struct_type_name = "LexerToken";
    _module_params[304].element_type = 21;
    _module_params[304].fn_sig = NULL;
    _module_params[305].name = "line";
    _module_params[305].type = 0;
    _module_params[305].struct_type_name = NULL;
    _module_params[305].element_type = 21;
    _module_params[305].fn_sig = NULL;
    _module_params[306].name = "column";
    _module_params[306].type = 0;
    _module_params[306].struct_type_name = NULL;
    _module_params[306].element_type = 21;
    _module_params[306].fn_sig = NULL;

    /* Function: process_number */
    _module_functions[310].name = "process_number";
    _module_functions[310].param_count = 6;
    _module_functions[310].return_type = 0;
    _module_functions[310].return_struct_type_name = NULL;
    _module_functions[310].return_fn_sig = NULL;
    _module_functions[310].return_type_info = NULL;
    _module_functions[310].body = NULL;
    _module_functions[310].shadow_test = NULL;
    _module_functions[310].is_extern = false;
    _module_functions[310].returns_gc_managed = false;
    _module_functions[310].requires_manual_free = false;
    _module_functions[310].returns_borrowed = false;
    _module_functions[310].cleanup_function = NULL;
    _module_functions[310].params = &_module_params[307];
    _module_params[307].name = "source";
    _module_params[307].type = 4;
    _module_params[307].struct_type_name = NULL;
    _module_params[307].element_type = 21;
    _module_params[307].fn_sig = NULL;
    _module_params[308].name = "i";
    _module_params[308].type = 0;
    _module_params[308].struct_type_name = NULL;
    _module_params[308].element_type = 21;
    _module_params[308].fn_sig = NULL;
    _module_params[309].name = "len";
    _module_params[309].type = 0;
    _module_params[309].struct_type_name = NULL;
    _module_params[309].element_type = 21;
    _module_params[309].fn_sig = NULL;
    _module_params[310].name = "tokens";
    _module_params[310].type = 15;
    _module_params[310].struct_type_name = "LexerToken";
    _module_params[310].element_type = 21;
    _module_params[310].fn_sig = NULL;
    _module_params[311].name = "line";
    _module_params[311].type = 0;
    _module_params[311].struct_type_name = NULL;
    _module_params[311].element_type = 21;
    _module_params[311].fn_sig = NULL;
    _module_params[312].name = "column";
    _module_params[312].type = 0;
    _module_params[312].struct_type_name = NULL;
    _module_params[312].element_type = 21;
    _module_params[312].fn_sig = NULL;

    /* Function: process_grammar_body */
    _module_functions[311].name = "process_grammar_body";
    _module_functions[311].param_count = 6;
    _module_functions[311].return_type = 0;
    _module_functions[311].return_struct_type_name = NULL;
    _module_functions[311].return_fn_sig = NULL;
    _module_functions[311].return_type_info = NULL;
    _module_functions[311].body = NULL;
    _module_functions[311].shadow_test = NULL;
    _module_functions[311].is_extern = false;
    _module_functions[311].returns_gc_managed = false;
    _module_functions[311].requires_manual_free = false;
    _module_functions[311].returns_borrowed = false;
    _module_functions[311].cleanup_function = NULL;
    _module_functions[311].params = &_module_params[313];
    _module_params[313].name = "source";
    _module_params[313].type = 4;
    _module_params[313].struct_type_name = NULL;
    _module_params[313].element_type = 21;
    _module_params[313].fn_sig = NULL;
    _module_params[314].name = "i";
    _module_params[314].type = 0;
    _module_params[314].struct_type_name = NULL;
    _module_params[314].element_type = 21;
    _module_params[314].fn_sig = NULL;
    _module_params[315].name = "len";
    _module_params[315].type = 0;
    _module_params[315].struct_type_name = NULL;
    _module_params[315].element_type = 21;
    _module_params[315].fn_sig = NULL;
    _module_params[316].name = "tokens";
    _module_params[316].type = 15;
    _module_params[316].struct_type_name = "LexerToken";
    _module_params[316].element_type = 21;
    _module_params[316].fn_sig = NULL;
    _module_params[317].name = "line";
    _module_params[317].type = 0;
    _module_params[317].struct_type_name = NULL;
    _module_params[317].element_type = 21;
    _module_params[317].fn_sig = NULL;
    _module_params[318].name = "column";
    _module_params[318].type = 0;
    _module_params[318].struct_type_name = NULL;
    _module_params[318].element_type = 21;
    _module_params[318].fn_sig = NULL;

    /* Function: process_identifier */
    _module_functions[312].name = "process_identifier";
    _module_functions[312].param_count = 6;
    _module_functions[312].return_type = 0;
    _module_functions[312].return_struct_type_name = NULL;
    _module_functions[312].return_fn_sig = NULL;
    _module_functions[312].return_type_info = NULL;
    _module_functions[312].body = NULL;
    _module_functions[312].shadow_test = NULL;
    _module_functions[312].is_extern = false;
    _module_functions[312].returns_gc_managed = false;
    _module_functions[312].requires_manual_free = false;
    _module_functions[312].returns_borrowed = false;
    _module_functions[312].cleanup_function = NULL;
    _module_functions[312].params = &_module_params[319];
    _module_params[319].name = "source";
    _module_params[319].type = 4;
    _module_params[319].struct_type_name = NULL;
    _module_params[319].element_type = 21;
    _module_params[319].fn_sig = NULL;
    _module_params[320].name = "i";
    _module_params[320].type = 0;
    _module_params[320].struct_type_name = NULL;
    _module_params[320].element_type = 21;
    _module_params[320].fn_sig = NULL;
    _module_params[321].name = "len";
    _module_params[321].type = 0;
    _module_params[321].struct_type_name = NULL;
    _module_params[321].element_type = 21;
    _module_params[321].fn_sig = NULL;
    _module_params[322].name = "tokens";
    _module_params[322].type = 15;
    _module_params[322].struct_type_name = "LexerToken";
    _module_params[322].element_type = 21;
    _module_params[322].fn_sig = NULL;
    _module_params[323].name = "line";
    _module_params[323].type = 0;
    _module_params[323].struct_type_name = NULL;
    _module_params[323].element_type = 21;
    _module_params[323].fn_sig = NULL;
    _module_params[324].name = "column";
    _module_params[324].type = 0;
    _module_params[324].struct_type_name = NULL;
    _module_params[324].element_type = 21;
    _module_params[324].fn_sig = NULL;

    /* Function: process_char_literal */
    _module_functions[313].name = "process_char_literal";
    _module_functions[313].param_count = 6;
    _module_functions[313].return_type = 0;
    _module_functions[313].return_struct_type_name = NULL;
    _module_functions[313].return_fn_sig = NULL;
    _module_functions[313].return_type_info = NULL;
    _module_functions[313].body = NULL;
    _module_functions[313].shadow_test = NULL;
    _module_functions[313].is_extern = false;
    _module_functions[313].returns_gc_managed = false;
    _module_functions[313].requires_manual_free = false;
    _module_functions[313].returns_borrowed = false;
    _module_functions[313].cleanup_function = NULL;
    _module_functions[313].params = &_module_params[325];
    _module_params[325].name = "source";
    _module_params[325].type = 4;
    _module_params[325].struct_type_name = NULL;
    _module_params[325].element_type = 21;
    _module_params[325].fn_sig = NULL;
    _module_params[326].name = "i";
    _module_params[326].type = 0;
    _module_params[326].struct_type_name = NULL;
    _module_params[326].element_type = 21;
    _module_params[326].fn_sig = NULL;
    _module_params[327].name = "len";
    _module_params[327].type = 0;
    _module_params[327].struct_type_name = NULL;
    _module_params[327].element_type = 21;
    _module_params[327].fn_sig = NULL;
    _module_params[328].name = "tokens";
    _module_params[328].type = 15;
    _module_params[328].struct_type_name = "LexerToken";
    _module_params[328].element_type = 21;
    _module_params[328].fn_sig = NULL;
    _module_params[329].name = "line";
    _module_params[329].type = 0;
    _module_params[329].struct_type_name = NULL;
    _module_params[329].element_type = 21;
    _module_params[329].fn_sig = NULL;
    _module_params[330].name = "column";
    _module_params[330].type = 0;
    _module_params[330].struct_type_name = NULL;
    _module_params[330].element_type = 21;
    _module_params[330].fn_sig = NULL;

    /* Function: emit_fstring_part_tokens */
    _module_functions[314].name = "emit_fstring_part_tokens";
    _module_functions[314].param_count = 7;
    _module_functions[314].return_type = 6;
    _module_functions[314].return_struct_type_name = NULL;
    _module_functions[314].return_fn_sig = NULL;
    _module_functions[314].return_type_info = NULL;
    _module_functions[314].body = NULL;
    _module_functions[314].shadow_test = NULL;
    _module_functions[314].is_extern = false;
    _module_functions[314].returns_gc_managed = false;
    _module_functions[314].requires_manual_free = false;
    _module_functions[314].returns_borrowed = false;
    _module_functions[314].cleanup_function = NULL;
    _module_functions[314].params = &_module_params[331];
    _module_params[331].name = "part_text";
    _module_params[331].type = 4;
    _module_params[331].struct_type_name = NULL;
    _module_params[331].element_type = 21;
    _module_params[331].fn_sig = NULL;
    _module_params[332].name = "is_expr";
    _module_params[332].type = 0;
    _module_params[332].struct_type_name = NULL;
    _module_params[332].element_type = 21;
    _module_params[332].fn_sig = NULL;
    _module_params[333].name = "tokens";
    _module_params[333].type = 15;
    _module_params[333].struct_type_name = "LexerToken";
    _module_params[333].element_type = 21;
    _module_params[333].fn_sig = NULL;
    _module_params[334].name = "diags";
    _module_params[334].type = 15;
    _module_params[334].struct_type_name = "CompilerDiagnostic";
    _module_params[334].element_type = 21;
    _module_params[334].fn_sig = NULL;
    _module_params[335].name = "file_name";
    _module_params[335].type = 4;
    _module_params[335].struct_type_name = NULL;
    _module_params[335].element_type = 21;
    _module_params[335].fn_sig = NULL;
    _module_params[336].name = "line";
    _module_params[336].type = 0;
    _module_params[336].struct_type_name = NULL;
    _module_params[336].element_type = 21;
    _module_params[336].fn_sig = NULL;
    _module_params[337].name = "column";
    _module_params[337].type = 0;
    _module_params[337].struct_type_name = NULL;
    _module_params[337].element_type = 21;
    _module_params[337].fn_sig = NULL;

    /* Function: process_fstring */
    _module_functions[315].name = "process_fstring";
    _module_functions[315].param_count = 8;
    _module_functions[315].return_type = 0;
    _module_functions[315].return_struct_type_name = NULL;
    _module_functions[315].return_fn_sig = NULL;
    _module_functions[315].return_type_info = NULL;
    _module_functions[315].body = NULL;
    _module_functions[315].shadow_test = NULL;
    _module_functions[315].is_extern = false;
    _module_functions[315].returns_gc_managed = false;
    _module_functions[315].requires_manual_free = false;
    _module_functions[315].returns_borrowed = false;
    _module_functions[315].cleanup_function = NULL;
    _module_functions[315].params = &_module_params[338];
    _module_params[338].name = "source";
    _module_params[338].type = 4;
    _module_params[338].struct_type_name = NULL;
    _module_params[338].element_type = 21;
    _module_params[338].fn_sig = NULL;
    _module_params[339].name = "i";
    _module_params[339].type = 0;
    _module_params[339].struct_type_name = NULL;
    _module_params[339].element_type = 21;
    _module_params[339].fn_sig = NULL;
    _module_params[340].name = "len";
    _module_params[340].type = 0;
    _module_params[340].struct_type_name = NULL;
    _module_params[340].element_type = 21;
    _module_params[340].fn_sig = NULL;
    _module_params[341].name = "tokens";
    _module_params[341].type = 15;
    _module_params[341].struct_type_name = "LexerToken";
    _module_params[341].element_type = 21;
    _module_params[341].fn_sig = NULL;
    _module_params[342].name = "diags";
    _module_params[342].type = 15;
    _module_params[342].struct_type_name = "CompilerDiagnostic";
    _module_params[342].element_type = 21;
    _module_params[342].fn_sig = NULL;
    _module_params[343].name = "file_name";
    _module_params[343].type = 4;
    _module_params[343].struct_type_name = NULL;
    _module_params[343].element_type = 21;
    _module_params[343].fn_sig = NULL;
    _module_params[344].name = "line";
    _module_params[344].type = 0;
    _module_params[344].struct_type_name = NULL;
    _module_params[344].element_type = 21;
    _module_params[344].fn_sig = NULL;
    _module_params[345].name = "column";
    _module_params[345].type = 0;
    _module_params[345].struct_type_name = NULL;
    _module_params[345].element_type = 21;
    _module_params[345].fn_sig = NULL;

    /* Function: tokenize_string */
    _module_functions[316].name = "tokenize_string";
    _module_functions[316].param_count = 3;
    _module_functions[316].return_type = 15;
    _module_functions[316].return_struct_type_name = "LexerToken";
    _module_functions[316].return_fn_sig = NULL;
    _module_functions[316].return_type_info = NULL;
    _module_functions[316].body = NULL;
    _module_functions[316].shadow_test = NULL;
    _module_functions[316].is_extern = false;
    _module_functions[316].returns_gc_managed = false;
    _module_functions[316].requires_manual_free = false;
    _module_functions[316].returns_borrowed = false;
    _module_functions[316].cleanup_function = NULL;
    _module_functions[316].params = &_module_params[346];
    _module_params[346].name = "source";
    _module_params[346].type = 4;
    _module_params[346].struct_type_name = NULL;
    _module_params[346].element_type = 21;
    _module_params[346].fn_sig = NULL;
    _module_params[347].name = "file_name";
    _module_params[347].type = 4;
    _module_params[347].struct_type_name = NULL;
    _module_params[347].element_type = 21;
    _module_params[347].fn_sig = NULL;
    _module_params[348].name = "diags";
    _module_params[348].type = 15;
    _module_params[348].struct_type_name = "CompilerDiagnostic";
    _module_params[348].element_type = 21;
    _module_params[348].fn_sig = NULL;

    /* Function: tokenize_file */
    _module_functions[317].name = "tokenize_file";
    _module_functions[317].param_count = 2;
    _module_functions[317].return_type = 15;
    _module_functions[317].return_struct_type_name = "LexerToken";
    _module_functions[317].return_fn_sig = NULL;
    _module_functions[317].return_type_info = NULL;
    _module_functions[317].body = NULL;
    _module_functions[317].shadow_test = NULL;
    _module_functions[317].is_extern = false;
    _module_functions[317].returns_gc_managed = false;
    _module_functions[317].requires_manual_free = false;
    _module_functions[317].returns_borrowed = false;
    _module_functions[317].cleanup_function = NULL;
    _module_functions[317].params = &_module_params[349];
    _module_params[349].name = "path";
    _module_params[349].type = 4;
    _module_params[349].struct_type_name = NULL;
    _module_params[349].element_type = 21;
    _module_params[349].fn_sig = NULL;
    _module_params[350].name = "diags";
    _module_params[350].type = 15;
    _module_params[350].struct_type_name = "CompilerDiagnostic";
    _module_params[350].element_type = 21;
    _module_params[350].fn_sig = NULL;

    /* Function: parser_init_ast_lists */
    _module_functions[318].name = "parser_init_ast_lists";
    _module_functions[318].param_count = 0;
    _module_functions[318].return_type = 8;
    _module_functions[318].return_struct_type_name = "Parser";
    _module_functions[318].return_fn_sig = NULL;
    _module_functions[318].return_type_info = NULL;
    _module_functions[318].body = NULL;
    _module_functions[318].shadow_test = NULL;
    _module_functions[318].is_extern = false;
    _module_functions[318].returns_gc_managed = false;
    _module_functions[318].requires_manual_free = false;
    _module_functions[318].returns_borrowed = false;
    _module_functions[318].cleanup_function = NULL;
    _module_functions[318].params = NULL;

    /* Function: parser_new */
    _module_functions[319].name = "parser_new";
    _module_functions[319].param_count = 3;
    _module_functions[319].return_type = 8;
    _module_functions[319].return_struct_type_name = "Parser";
    _module_functions[319].return_fn_sig = NULL;
    _module_functions[319].return_type_info = NULL;
    _module_functions[319].body = NULL;
    _module_functions[319].shadow_test = NULL;
    _module_functions[319].is_extern = false;
    _module_functions[319].returns_gc_managed = false;
    _module_functions[319].requires_manual_free = false;
    _module_functions[319].returns_borrowed = false;
    _module_functions[319].cleanup_function = NULL;
    _module_functions[319].params = &_module_params[351];
    _module_params[351].name = "tokens";
    _module_params[351].type = 15;
    _module_params[351].struct_type_name = "LexerToken";
    _module_params[351].element_type = 21;
    _module_params[351].fn_sig = NULL;
    _module_params[352].name = "token_count";
    _module_params[352].type = 0;
    _module_params[352].struct_type_name = NULL;
    _module_params[352].element_type = 21;
    _module_params[352].fn_sig = NULL;
    _module_params[353].name = "file_name";
    _module_params[353].type = 4;
    _module_params[353].struct_type_name = NULL;
    _module_params[353].element_type = 21;
    _module_params[353].fn_sig = NULL;

    /* Function: parser_allocate_id */
    _module_functions[320].name = "parser_allocate_id";
    _module_functions[320].param_count = 1;
    _module_functions[320].return_type = 0;
    _module_functions[320].return_struct_type_name = NULL;
    _module_functions[320].return_fn_sig = NULL;
    _module_functions[320].return_type_info = NULL;
    _module_functions[320].body = NULL;
    _module_functions[320].shadow_test = NULL;
    _module_functions[320].is_extern = false;
    _module_functions[320].returns_gc_managed = false;
    _module_functions[320].requires_manual_free = false;
    _module_functions[320].returns_borrowed = false;
    _module_functions[320].cleanup_function = NULL;
    _module_functions[320].params = &_module_params[354];
    _module_params[354].name = "p";
    _module_params[354].type = 8;
    _module_params[354].struct_type_name = "Parser";
    _module_params[354].element_type = 21;
    _module_params[354].fn_sig = NULL;

    /* Function: parser_is_at_end */
    _module_functions[321].name = "parser_is_at_end";
    _module_functions[321].param_count = 1;
    _module_functions[321].return_type = 3;
    _module_functions[321].return_struct_type_name = NULL;
    _module_functions[321].return_fn_sig = NULL;
    _module_functions[321].return_type_info = NULL;
    _module_functions[321].body = NULL;
    _module_functions[321].shadow_test = NULL;
    _module_functions[321].is_extern = false;
    _module_functions[321].returns_gc_managed = false;
    _module_functions[321].requires_manual_free = false;
    _module_functions[321].returns_borrowed = false;
    _module_functions[321].cleanup_function = NULL;
    _module_functions[321].params = &_module_params[355];
    _module_params[355].name = "p";
    _module_params[355].type = 8;
    _module_params[355].struct_type_name = "Parser";
    _module_params[355].element_type = 21;
    _module_params[355].fn_sig = NULL;

    /* Function: parser_with_position */
    _module_functions[322].name = "parser_with_position";
    _module_functions[322].param_count = 2;
    _module_functions[322].return_type = 8;
    _module_functions[322].return_struct_type_name = "Parser";
    _module_functions[322].return_fn_sig = NULL;
    _module_functions[322].return_type_info = NULL;
    _module_functions[322].body = NULL;
    _module_functions[322].shadow_test = NULL;
    _module_functions[322].is_extern = false;
    _module_functions[322].returns_gc_managed = false;
    _module_functions[322].requires_manual_free = false;
    _module_functions[322].returns_borrowed = false;
    _module_functions[322].cleanup_function = NULL;
    _module_functions[322].params = &_module_params[356];
    _module_params[356].name = "p";
    _module_params[356].type = 8;
    _module_params[356].struct_type_name = "Parser";
    _module_params[356].element_type = 21;
    _module_params[356].fn_sig = NULL;
    _module_params[357].name = "new_position";
    _module_params[357].type = 0;
    _module_params[357].struct_type_name = NULL;
    _module_params[357].element_type = 21;
    _module_params[357].fn_sig = NULL;

    /* Function: parser_advance */
    _module_functions[323].name = "parser_advance";
    _module_functions[323].param_count = 1;
    _module_functions[323].return_type = 8;
    _module_functions[323].return_struct_type_name = "Parser";
    _module_functions[323].return_fn_sig = NULL;
    _module_functions[323].return_type_info = NULL;
    _module_functions[323].body = NULL;
    _module_functions[323].shadow_test = NULL;
    _module_functions[323].is_extern = false;
    _module_functions[323].returns_gc_managed = false;
    _module_functions[323].requires_manual_free = false;
    _module_functions[323].returns_borrowed = false;
    _module_functions[323].cleanup_function = NULL;
    _module_functions[323].params = &_module_params[358];
    _module_params[358].name = "p";
    _module_params[358].type = 8;
    _module_params[358].struct_type_name = "Parser";
    _module_params[358].element_type = 21;
    _module_params[358].fn_sig = NULL;

    /* Function: parser_position */
    _module_functions[324].name = "parser_position";
    _module_functions[324].param_count = 1;
    _module_functions[324].return_type = 0;
    _module_functions[324].return_struct_type_name = NULL;
    _module_functions[324].return_fn_sig = NULL;
    _module_functions[324].return_type_info = NULL;
    _module_functions[324].body = NULL;
    _module_functions[324].shadow_test = NULL;
    _module_functions[324].is_extern = false;
    _module_functions[324].returns_gc_managed = false;
    _module_functions[324].requires_manual_free = false;
    _module_functions[324].returns_borrowed = false;
    _module_functions[324].cleanup_function = NULL;
    _module_functions[324].params = &_module_params[359];
    _module_params[359].name = "p";
    _module_params[359].type = 8;
    _module_params[359].struct_type_name = "Parser";
    _module_params[359].element_type = 21;
    _module_params[359].fn_sig = NULL;

    /* Function: parser_current */
    _module_functions[325].name = "parser_current";
    _module_functions[325].param_count = 1;
    _module_functions[325].return_type = 8;
    _module_functions[325].return_struct_type_name = "LexerToken";
    _module_functions[325].return_fn_sig = NULL;
    _module_functions[325].return_type_info = NULL;
    _module_functions[325].body = NULL;
    _module_functions[325].shadow_test = NULL;
    _module_functions[325].is_extern = false;
    _module_functions[325].returns_gc_managed = false;
    _module_functions[325].requires_manual_free = false;
    _module_functions[325].returns_borrowed = false;
    _module_functions[325].cleanup_function = NULL;
    _module_functions[325].params = &_module_params[360];
    _module_params[360].name = "p";
    _module_params[360].type = 8;
    _module_params[360].struct_type_name = "Parser";
    _module_params[360].element_type = 21;
    _module_params[360].fn_sig = NULL;

    /* Function: parser_match */
    _module_functions[326].name = "parser_match";
    _module_functions[326].param_count = 2;
    _module_functions[326].return_type = 3;
    _module_functions[326].return_struct_type_name = NULL;
    _module_functions[326].return_fn_sig = NULL;
    _module_functions[326].return_type_info = NULL;
    _module_functions[326].body = NULL;
    _module_functions[326].shadow_test = NULL;
    _module_functions[326].is_extern = false;
    _module_functions[326].returns_gc_managed = false;
    _module_functions[326].requires_manual_free = false;
    _module_functions[326].returns_borrowed = false;
    _module_functions[326].cleanup_function = NULL;
    _module_functions[326].params = &_module_params[361];
    _module_params[361].name = "p";
    _module_params[361].type = 8;
    _module_params[361].struct_type_name = "Parser";
    _module_params[361].element_type = 21;
    _module_params[361].fn_sig = NULL;
    _module_params[362].name = "token_type";
    _module_params[362].type = 0;
    _module_params[362].struct_type_name = NULL;
    _module_params[362].element_type = 21;
    _module_params[362].fn_sig = NULL;

    /* Function: parser_expect */
    _module_functions[327].name = "parser_expect";
    _module_functions[327].param_count = 2;
    _module_functions[327].return_type = 8;
    _module_functions[327].return_struct_type_name = "Parser";
    _module_functions[327].return_fn_sig = NULL;
    _module_functions[327].return_type_info = NULL;
    _module_functions[327].body = NULL;
    _module_functions[327].shadow_test = NULL;
    _module_functions[327].is_extern = false;
    _module_functions[327].returns_gc_managed = false;
    _module_functions[327].requires_manual_free = false;
    _module_functions[327].returns_borrowed = false;
    _module_functions[327].cleanup_function = NULL;
    _module_functions[327].params = &_module_params[363];
    _module_params[363].name = "p";
    _module_params[363].type = 8;
    _module_params[363].struct_type_name = "Parser";
    _module_params[363].element_type = 21;
    _module_params[363].fn_sig = NULL;
    _module_params[364].name = "token_type";
    _module_params[364].type = 0;
    _module_params[364].struct_type_name = NULL;
    _module_params[364].element_type = 21;
    _module_params[364].fn_sig = NULL;

    /* Function: parser_peek */
    _module_functions[328].name = "parser_peek";
    _module_functions[328].param_count = 2;
    _module_functions[328].return_type = 0;
    _module_functions[328].return_struct_type_name = NULL;
    _module_functions[328].return_fn_sig = NULL;
    _module_functions[328].return_type_info = NULL;
    _module_functions[328].body = NULL;
    _module_functions[328].shadow_test = NULL;
    _module_functions[328].is_extern = false;
    _module_functions[328].returns_gc_managed = false;
    _module_functions[328].requires_manual_free = false;
    _module_functions[328].returns_borrowed = false;
    _module_functions[328].cleanup_function = NULL;
    _module_functions[328].params = &_module_params[365];
    _module_params[365].name = "p";
    _module_params[365].type = 8;
    _module_params[365].struct_type_name = "Parser";
    _module_params[365].element_type = 21;
    _module_params[365].fn_sig = NULL;
    _module_params[366].name = "offset";
    _module_params[366].type = 0;
    _module_params[366].struct_type_name = NULL;
    _module_params[366].element_type = 21;
    _module_params[366].fn_sig = NULL;

    /* Function: parser_with_error */
    _module_functions[329].name = "parser_with_error";
    _module_functions[329].param_count = 2;
    _module_functions[329].return_type = 8;
    _module_functions[329].return_struct_type_name = "Parser";
    _module_functions[329].return_fn_sig = NULL;
    _module_functions[329].return_type_info = NULL;
    _module_functions[329].body = NULL;
    _module_functions[329].shadow_test = NULL;
    _module_functions[329].is_extern = false;
    _module_functions[329].returns_gc_managed = false;
    _module_functions[329].requires_manual_free = false;
    _module_functions[329].returns_borrowed = false;
    _module_functions[329].cleanup_function = NULL;
    _module_functions[329].params = &_module_params[367];
    _module_params[367].name = "p";
    _module_params[367].type = 8;
    _module_params[367].struct_type_name = "Parser";
    _module_params[367].element_type = 21;
    _module_params[367].fn_sig = NULL;
    _module_params[368].name = "error";
    _module_params[368].type = 3;
    _module_params[368].struct_type_name = NULL;
    _module_params[368].element_type = 21;
    _module_params[368].fn_sig = NULL;

    /* Function: parser_has_error */
    _module_functions[330].name = "parser_has_error";
    _module_functions[330].param_count = 1;
    _module_functions[330].return_type = 3;
    _module_functions[330].return_struct_type_name = NULL;
    _module_functions[330].return_fn_sig = NULL;
    _module_functions[330].return_type_info = NULL;
    _module_functions[330].body = NULL;
    _module_functions[330].shadow_test = NULL;
    _module_functions[330].is_extern = false;
    _module_functions[330].returns_gc_managed = false;
    _module_functions[330].requires_manual_free = false;
    _module_functions[330].returns_borrowed = false;
    _module_functions[330].cleanup_function = NULL;
    _module_functions[330].params = &_module_params[369];
    _module_params[369].name = "p";
    _module_params[369].type = 8;
    _module_params[369].struct_type_name = "Parser";
    _module_params[369].element_type = 21;
    _module_params[369].fn_sig = NULL;

    /* Function: token_number */
    _module_functions[331].name = "token_number";
    _module_functions[331].param_count = 0;
    _module_functions[331].return_type = 0;
    _module_functions[331].return_struct_type_name = NULL;
    _module_functions[331].return_fn_sig = NULL;
    _module_functions[331].return_type_info = NULL;
    _module_functions[331].body = NULL;
    _module_functions[331].shadow_test = NULL;
    _module_functions[331].is_extern = false;
    _module_functions[331].returns_gc_managed = false;
    _module_functions[331].requires_manual_free = false;
    _module_functions[331].returns_borrowed = false;
    _module_functions[331].cleanup_function = NULL;
    _module_functions[331].params = NULL;

    /* Function: token_identifier */
    _module_functions[332].name = "token_identifier";
    _module_functions[332].param_count = 0;
    _module_functions[332].return_type = 0;
    _module_functions[332].return_struct_type_name = NULL;
    _module_functions[332].return_fn_sig = NULL;
    _module_functions[332].return_type_info = NULL;
    _module_functions[332].body = NULL;
    _module_functions[332].shadow_test = NULL;
    _module_functions[332].is_extern = false;
    _module_functions[332].returns_gc_managed = false;
    _module_functions[332].requires_manual_free = false;
    _module_functions[332].returns_borrowed = false;
    _module_functions[332].cleanup_function = NULL;
    _module_functions[332].params = NULL;

    /* Function: token_string */
    _module_functions[333].name = "token_string";
    _module_functions[333].param_count = 0;
    _module_functions[333].return_type = 0;
    _module_functions[333].return_struct_type_name = NULL;
    _module_functions[333].return_fn_sig = NULL;
    _module_functions[333].return_type_info = NULL;
    _module_functions[333].body = NULL;
    _module_functions[333].shadow_test = NULL;
    _module_functions[333].is_extern = false;
    _module_functions[333].returns_gc_managed = false;
    _module_functions[333].requires_manual_free = false;
    _module_functions[333].returns_borrowed = false;
    _module_functions[333].cleanup_function = NULL;
    _module_functions[333].params = NULL;

    /* Function: token_true */
    _module_functions[334].name = "token_true";
    _module_functions[334].param_count = 0;
    _module_functions[334].return_type = 0;
    _module_functions[334].return_struct_type_name = NULL;
    _module_functions[334].return_fn_sig = NULL;
    _module_functions[334].return_type_info = NULL;
    _module_functions[334].body = NULL;
    _module_functions[334].shadow_test = NULL;
    _module_functions[334].is_extern = false;
    _module_functions[334].returns_gc_managed = false;
    _module_functions[334].requires_manual_free = false;
    _module_functions[334].returns_borrowed = false;
    _module_functions[334].cleanup_function = NULL;
    _module_functions[334].params = NULL;

    /* Function: token_false */
    _module_functions[335].name = "token_false";
    _module_functions[335].param_count = 0;
    _module_functions[335].return_type = 0;
    _module_functions[335].return_struct_type_name = NULL;
    _module_functions[335].return_fn_sig = NULL;
    _module_functions[335].return_type_info = NULL;
    _module_functions[335].body = NULL;
    _module_functions[335].shadow_test = NULL;
    _module_functions[335].is_extern = false;
    _module_functions[335].returns_gc_managed = false;
    _module_functions[335].requires_manual_free = false;
    _module_functions[335].returns_borrowed = false;
    _module_functions[335].cleanup_function = NULL;
    _module_functions[335].params = NULL;

    /* Function: token_lparen */
    _module_functions[336].name = "token_lparen";
    _module_functions[336].param_count = 0;
    _module_functions[336].return_type = 0;
    _module_functions[336].return_struct_type_name = NULL;
    _module_functions[336].return_fn_sig = NULL;
    _module_functions[336].return_type_info = NULL;
    _module_functions[336].body = NULL;
    _module_functions[336].shadow_test = NULL;
    _module_functions[336].is_extern = false;
    _module_functions[336].returns_gc_managed = false;
    _module_functions[336].requires_manual_free = false;
    _module_functions[336].returns_borrowed = false;
    _module_functions[336].cleanup_function = NULL;
    _module_functions[336].params = NULL;

    /* Function: token_rparen */
    _module_functions[337].name = "token_rparen";
    _module_functions[337].param_count = 0;
    _module_functions[337].return_type = 0;
    _module_functions[337].return_struct_type_name = NULL;
    _module_functions[337].return_fn_sig = NULL;
    _module_functions[337].return_type_info = NULL;
    _module_functions[337].body = NULL;
    _module_functions[337].shadow_test = NULL;
    _module_functions[337].is_extern = false;
    _module_functions[337].returns_gc_managed = false;
    _module_functions[337].requires_manual_free = false;
    _module_functions[337].returns_borrowed = false;
    _module_functions[337].cleanup_function = NULL;
    _module_functions[337].params = NULL;

    /* Function: token_plus */
    _module_functions[338].name = "token_plus";
    _module_functions[338].param_count = 0;
    _module_functions[338].return_type = 0;
    _module_functions[338].return_struct_type_name = NULL;
    _module_functions[338].return_fn_sig = NULL;
    _module_functions[338].return_type_info = NULL;
    _module_functions[338].body = NULL;
    _module_functions[338].shadow_test = NULL;
    _module_functions[338].is_extern = false;
    _module_functions[338].returns_gc_managed = false;
    _module_functions[338].requires_manual_free = false;
    _module_functions[338].returns_borrowed = false;
    _module_functions[338].cleanup_function = NULL;
    _module_functions[338].params = NULL;

    /* Function: token_minus */
    _module_functions[339].name = "token_minus";
    _module_functions[339].param_count = 0;
    _module_functions[339].return_type = 0;
    _module_functions[339].return_struct_type_name = NULL;
    _module_functions[339].return_fn_sig = NULL;
    _module_functions[339].return_type_info = NULL;
    _module_functions[339].body = NULL;
    _module_functions[339].shadow_test = NULL;
    _module_functions[339].is_extern = false;
    _module_functions[339].returns_gc_managed = false;
    _module_functions[339].requires_manual_free = false;
    _module_functions[339].returns_borrowed = false;
    _module_functions[339].cleanup_function = NULL;
    _module_functions[339].params = NULL;

    /* Function: token_star */
    _module_functions[340].name = "token_star";
    _module_functions[340].param_count = 0;
    _module_functions[340].return_type = 0;
    _module_functions[340].return_struct_type_name = NULL;
    _module_functions[340].return_fn_sig = NULL;
    _module_functions[340].return_type_info = NULL;
    _module_functions[340].body = NULL;
    _module_functions[340].shadow_test = NULL;
    _module_functions[340].is_extern = false;
    _module_functions[340].returns_gc_managed = false;
    _module_functions[340].requires_manual_free = false;
    _module_functions[340].returns_borrowed = false;
    _module_functions[340].cleanup_function = NULL;
    _module_functions[340].params = NULL;

    /* Function: token_slash */
    _module_functions[341].name = "token_slash";
    _module_functions[341].param_count = 0;
    _module_functions[341].return_type = 0;
    _module_functions[341].return_struct_type_name = NULL;
    _module_functions[341].return_fn_sig = NULL;
    _module_functions[341].return_type_info = NULL;
    _module_functions[341].body = NULL;
    _module_functions[341].shadow_test = NULL;
    _module_functions[341].is_extern = false;
    _module_functions[341].returns_gc_managed = false;
    _module_functions[341].requires_manual_free = false;
    _module_functions[341].returns_borrowed = false;
    _module_functions[341].cleanup_function = NULL;
    _module_functions[341].params = NULL;

    /* Function: token_eq */
    _module_functions[342].name = "token_eq";
    _module_functions[342].param_count = 0;
    _module_functions[342].return_type = 0;
    _module_functions[342].return_struct_type_name = NULL;
    _module_functions[342].return_fn_sig = NULL;
    _module_functions[342].return_type_info = NULL;
    _module_functions[342].body = NULL;
    _module_functions[342].shadow_test = NULL;
    _module_functions[342].is_extern = false;
    _module_functions[342].returns_gc_managed = false;
    _module_functions[342].requires_manual_free = false;
    _module_functions[342].returns_borrowed = false;
    _module_functions[342].cleanup_function = NULL;
    _module_functions[342].params = NULL;

    /* Function: token_ne */
    _module_functions[343].name = "token_ne";
    _module_functions[343].param_count = 0;
    _module_functions[343].return_type = 0;
    _module_functions[343].return_struct_type_name = NULL;
    _module_functions[343].return_fn_sig = NULL;
    _module_functions[343].return_type_info = NULL;
    _module_functions[343].body = NULL;
    _module_functions[343].shadow_test = NULL;
    _module_functions[343].is_extern = false;
    _module_functions[343].returns_gc_managed = false;
    _module_functions[343].requires_manual_free = false;
    _module_functions[343].returns_borrowed = false;
    _module_functions[343].cleanup_function = NULL;
    _module_functions[343].params = NULL;

    /* Function: token_lt */
    _module_functions[344].name = "token_lt";
    _module_functions[344].param_count = 0;
    _module_functions[344].return_type = 0;
    _module_functions[344].return_struct_type_name = NULL;
    _module_functions[344].return_fn_sig = NULL;
    _module_functions[344].return_type_info = NULL;
    _module_functions[344].body = NULL;
    _module_functions[344].shadow_test = NULL;
    _module_functions[344].is_extern = false;
    _module_functions[344].returns_gc_managed = false;
    _module_functions[344].requires_manual_free = false;
    _module_functions[344].returns_borrowed = false;
    _module_functions[344].cleanup_function = NULL;
    _module_functions[344].params = NULL;

    /* Function: token_le */
    _module_functions[345].name = "token_le";
    _module_functions[345].param_count = 0;
    _module_functions[345].return_type = 0;
    _module_functions[345].return_struct_type_name = NULL;
    _module_functions[345].return_fn_sig = NULL;
    _module_functions[345].return_type_info = NULL;
    _module_functions[345].body = NULL;
    _module_functions[345].shadow_test = NULL;
    _module_functions[345].is_extern = false;
    _module_functions[345].returns_gc_managed = false;
    _module_functions[345].requires_manual_free = false;
    _module_functions[345].returns_borrowed = false;
    _module_functions[345].cleanup_function = NULL;
    _module_functions[345].params = NULL;

    /* Function: token_gt */
    _module_functions[346].name = "token_gt";
    _module_functions[346].param_count = 0;
    _module_functions[346].return_type = 0;
    _module_functions[346].return_struct_type_name = NULL;
    _module_functions[346].return_fn_sig = NULL;
    _module_functions[346].return_type_info = NULL;
    _module_functions[346].body = NULL;
    _module_functions[346].shadow_test = NULL;
    _module_functions[346].is_extern = false;
    _module_functions[346].returns_gc_managed = false;
    _module_functions[346].requires_manual_free = false;
    _module_functions[346].returns_borrowed = false;
    _module_functions[346].cleanup_function = NULL;
    _module_functions[346].params = NULL;

    /* Function: token_ge */
    _module_functions[347].name = "token_ge";
    _module_functions[347].param_count = 0;
    _module_functions[347].return_type = 0;
    _module_functions[347].return_struct_type_name = NULL;
    _module_functions[347].return_fn_sig = NULL;
    _module_functions[347].return_type_info = NULL;
    _module_functions[347].body = NULL;
    _module_functions[347].shadow_test = NULL;
    _module_functions[347].is_extern = false;
    _module_functions[347].returns_gc_managed = false;
    _module_functions[347].requires_manual_free = false;
    _module_functions[347].returns_borrowed = false;
    _module_functions[347].cleanup_function = NULL;
    _module_functions[347].params = NULL;

    /* Function: token_and */
    _module_functions[348].name = "token_and";
    _module_functions[348].param_count = 0;
    _module_functions[348].return_type = 0;
    _module_functions[348].return_struct_type_name = NULL;
    _module_functions[348].return_fn_sig = NULL;
    _module_functions[348].return_type_info = NULL;
    _module_functions[348].body = NULL;
    _module_functions[348].shadow_test = NULL;
    _module_functions[348].is_extern = false;
    _module_functions[348].returns_gc_managed = false;
    _module_functions[348].requires_manual_free = false;
    _module_functions[348].returns_borrowed = false;
    _module_functions[348].cleanup_function = NULL;
    _module_functions[348].params = NULL;

    /* Function: token_or */
    _module_functions[349].name = "token_or";
    _module_functions[349].param_count = 0;
    _module_functions[349].return_type = 0;
    _module_functions[349].return_struct_type_name = NULL;
    _module_functions[349].return_fn_sig = NULL;
    _module_functions[349].return_type_info = NULL;
    _module_functions[349].body = NULL;
    _module_functions[349].shadow_test = NULL;
    _module_functions[349].is_extern = false;
    _module_functions[349].returns_gc_managed = false;
    _module_functions[349].requires_manual_free = false;
    _module_functions[349].returns_borrowed = false;
    _module_functions[349].cleanup_function = NULL;
    _module_functions[349].params = NULL;

    /* Function: token_comma */
    _module_functions[350].name = "token_comma";
    _module_functions[350].param_count = 0;
    _module_functions[350].return_type = 0;
    _module_functions[350].return_struct_type_name = NULL;
    _module_functions[350].return_fn_sig = NULL;
    _module_functions[350].return_type_info = NULL;
    _module_functions[350].body = NULL;
    _module_functions[350].shadow_test = NULL;
    _module_functions[350].is_extern = false;
    _module_functions[350].returns_gc_managed = false;
    _module_functions[350].requires_manual_free = false;
    _module_functions[350].returns_borrowed = false;
    _module_functions[350].cleanup_function = NULL;
    _module_functions[350].params = NULL;

    /* Function: token_lbrace */
    _module_functions[351].name = "token_lbrace";
    _module_functions[351].param_count = 0;
    _module_functions[351].return_type = 0;
    _module_functions[351].return_struct_type_name = NULL;
    _module_functions[351].return_fn_sig = NULL;
    _module_functions[351].return_type_info = NULL;
    _module_functions[351].body = NULL;
    _module_functions[351].shadow_test = NULL;
    _module_functions[351].is_extern = false;
    _module_functions[351].returns_gc_managed = false;
    _module_functions[351].requires_manual_free = false;
    _module_functions[351].returns_borrowed = false;
    _module_functions[351].cleanup_function = NULL;
    _module_functions[351].params = NULL;

    /* Function: token_rbrace */
    _module_functions[352].name = "token_rbrace";
    _module_functions[352].param_count = 0;
    _module_functions[352].return_type = 0;
    _module_functions[352].return_struct_type_name = NULL;
    _module_functions[352].return_fn_sig = NULL;
    _module_functions[352].return_type_info = NULL;
    _module_functions[352].body = NULL;
    _module_functions[352].shadow_test = NULL;
    _module_functions[352].is_extern = false;
    _module_functions[352].returns_gc_managed = false;
    _module_functions[352].requires_manual_free = false;
    _module_functions[352].returns_borrowed = false;
    _module_functions[352].cleanup_function = NULL;
    _module_functions[352].params = NULL;

    /* Function: token_let */
    _module_functions[353].name = "token_let";
    _module_functions[353].param_count = 0;
    _module_functions[353].return_type = 0;
    _module_functions[353].return_struct_type_name = NULL;
    _module_functions[353].return_fn_sig = NULL;
    _module_functions[353].return_type_info = NULL;
    _module_functions[353].body = NULL;
    _module_functions[353].shadow_test = NULL;
    _module_functions[353].is_extern = false;
    _module_functions[353].returns_gc_managed = false;
    _module_functions[353].requires_manual_free = false;
    _module_functions[353].returns_borrowed = false;
    _module_functions[353].cleanup_function = NULL;
    _module_functions[353].params = NULL;

    /* Function: token_if */
    _module_functions[354].name = "token_if";
    _module_functions[354].param_count = 0;
    _module_functions[354].return_type = 0;
    _module_functions[354].return_struct_type_name = NULL;
    _module_functions[354].return_fn_sig = NULL;
    _module_functions[354].return_type_info = NULL;
    _module_functions[354].body = NULL;
    _module_functions[354].shadow_test = NULL;
    _module_functions[354].is_extern = false;
    _module_functions[354].returns_gc_managed = false;
    _module_functions[354].requires_manual_free = false;
    _module_functions[354].returns_borrowed = false;
    _module_functions[354].cleanup_function = NULL;
    _module_functions[354].params = NULL;

    /* Function: token_else */
    _module_functions[355].name = "token_else";
    _module_functions[355].param_count = 0;
    _module_functions[355].return_type = 0;
    _module_functions[355].return_struct_type_name = NULL;
    _module_functions[355].return_fn_sig = NULL;
    _module_functions[355].return_type_info = NULL;
    _module_functions[355].body = NULL;
    _module_functions[355].shadow_test = NULL;
    _module_functions[355].is_extern = false;
    _module_functions[355].returns_gc_managed = false;
    _module_functions[355].requires_manual_free = false;
    _module_functions[355].returns_borrowed = false;
    _module_functions[355].cleanup_function = NULL;
    _module_functions[355].params = NULL;

    /* Function: token_while */
    _module_functions[356].name = "token_while";
    _module_functions[356].param_count = 0;
    _module_functions[356].return_type = 0;
    _module_functions[356].return_struct_type_name = NULL;
    _module_functions[356].return_fn_sig = NULL;
    _module_functions[356].return_type_info = NULL;
    _module_functions[356].body = NULL;
    _module_functions[356].shadow_test = NULL;
    _module_functions[356].is_extern = false;
    _module_functions[356].returns_gc_managed = false;
    _module_functions[356].requires_manual_free = false;
    _module_functions[356].returns_borrowed = false;
    _module_functions[356].cleanup_function = NULL;
    _module_functions[356].params = NULL;

    /* Function: token_return */
    _module_functions[357].name = "token_return";
    _module_functions[357].param_count = 0;
    _module_functions[357].return_type = 0;
    _module_functions[357].return_struct_type_name = NULL;
    _module_functions[357].return_fn_sig = NULL;
    _module_functions[357].return_type_info = NULL;
    _module_functions[357].body = NULL;
    _module_functions[357].shadow_test = NULL;
    _module_functions[357].is_extern = false;
    _module_functions[357].returns_gc_managed = false;
    _module_functions[357].requires_manual_free = false;
    _module_functions[357].returns_borrowed = false;
    _module_functions[357].cleanup_function = NULL;
    _module_functions[357].params = NULL;

    /* Function: token_colon */
    _module_functions[358].name = "token_colon";
    _module_functions[358].param_count = 0;
    _module_functions[358].return_type = 0;
    _module_functions[358].return_struct_type_name = NULL;
    _module_functions[358].return_fn_sig = NULL;
    _module_functions[358].return_type_info = NULL;
    _module_functions[358].body = NULL;
    _module_functions[358].shadow_test = NULL;
    _module_functions[358].is_extern = false;
    _module_functions[358].returns_gc_managed = false;
    _module_functions[358].requires_manual_free = false;
    _module_functions[358].returns_borrowed = false;
    _module_functions[358].cleanup_function = NULL;
    _module_functions[358].params = NULL;

    /* Function: token_mut */
    _module_functions[359].name = "token_mut";
    _module_functions[359].param_count = 0;
    _module_functions[359].return_type = 0;
    _module_functions[359].return_struct_type_name = NULL;
    _module_functions[359].return_fn_sig = NULL;
    _module_functions[359].return_type_info = NULL;
    _module_functions[359].body = NULL;
    _module_functions[359].shadow_test = NULL;
    _module_functions[359].is_extern = false;
    _module_functions[359].returns_gc_managed = false;
    _module_functions[359].requires_manual_free = false;
    _module_functions[359].returns_borrowed = false;
    _module_functions[359].cleanup_function = NULL;
    _module_functions[359].params = NULL;

    /* Function: token_assign */
    _module_functions[360].name = "token_assign";
    _module_functions[360].param_count = 0;
    _module_functions[360].return_type = 0;
    _module_functions[360].return_struct_type_name = NULL;
    _module_functions[360].return_fn_sig = NULL;
    _module_functions[360].return_type_info = NULL;
    _module_functions[360].body = NULL;
    _module_functions[360].shadow_test = NULL;
    _module_functions[360].is_extern = false;
    _module_functions[360].returns_gc_managed = false;
    _module_functions[360].requires_manual_free = false;
    _module_functions[360].returns_borrowed = false;
    _module_functions[360].cleanup_function = NULL;
    _module_functions[360].params = NULL;

    /* Function: token_arrow */
    _module_functions[361].name = "token_arrow";
    _module_functions[361].param_count = 0;
    _module_functions[361].return_type = 0;
    _module_functions[361].return_struct_type_name = NULL;
    _module_functions[361].return_fn_sig = NULL;
    _module_functions[361].return_type_info = NULL;
    _module_functions[361].body = NULL;
    _module_functions[361].shadow_test = NULL;
    _module_functions[361].is_extern = false;
    _module_functions[361].returns_gc_managed = false;
    _module_functions[361].requires_manual_free = false;
    _module_functions[361].returns_borrowed = false;
    _module_functions[361].cleanup_function = NULL;
    _module_functions[361].params = NULL;

    /* Function: token_fn */
    _module_functions[362].name = "token_fn";
    _module_functions[362].param_count = 0;
    _module_functions[362].return_type = 0;
    _module_functions[362].return_struct_type_name = NULL;
    _module_functions[362].return_fn_sig = NULL;
    _module_functions[362].return_type_info = NULL;
    _module_functions[362].body = NULL;
    _module_functions[362].shadow_test = NULL;
    _module_functions[362].is_extern = false;
    _module_functions[362].returns_gc_managed = false;
    _module_functions[362].requires_manual_free = false;
    _module_functions[362].returns_borrowed = false;
    _module_functions[362].cleanup_function = NULL;
    _module_functions[362].params = NULL;

    /* Function: token_extern */
    _module_functions[363].name = "token_extern";
    _module_functions[363].param_count = 0;
    _module_functions[363].return_type = 0;
    _module_functions[363].return_struct_type_name = NULL;
    _module_functions[363].return_fn_sig = NULL;
    _module_functions[363].return_type_info = NULL;
    _module_functions[363].body = NULL;
    _module_functions[363].shadow_test = NULL;
    _module_functions[363].is_extern = false;
    _module_functions[363].returns_gc_managed = false;
    _module_functions[363].requires_manual_free = false;
    _module_functions[363].returns_borrowed = false;
    _module_functions[363].cleanup_function = NULL;
    _module_functions[363].params = NULL;

    /* Function: token_set */
    _module_functions[364].name = "token_set";
    _module_functions[364].param_count = 0;
    _module_functions[364].return_type = 0;
    _module_functions[364].return_struct_type_name = NULL;
    _module_functions[364].return_fn_sig = NULL;
    _module_functions[364].return_type_info = NULL;
    _module_functions[364].body = NULL;
    _module_functions[364].shadow_test = NULL;
    _module_functions[364].is_extern = false;
    _module_functions[364].returns_gc_managed = false;
    _module_functions[364].requires_manual_free = false;
    _module_functions[364].returns_borrowed = false;
    _module_functions[364].cleanup_function = NULL;
    _module_functions[364].params = NULL;

    /* Function: token_struct */
    _module_functions[365].name = "token_struct";
    _module_functions[365].param_count = 0;
    _module_functions[365].return_type = 0;
    _module_functions[365].return_struct_type_name = NULL;
    _module_functions[365].return_fn_sig = NULL;
    _module_functions[365].return_type_info = NULL;
    _module_functions[365].body = NULL;
    _module_functions[365].shadow_test = NULL;
    _module_functions[365].is_extern = false;
    _module_functions[365].returns_gc_managed = false;
    _module_functions[365].requires_manual_free = false;
    _module_functions[365].returns_borrowed = false;
    _module_functions[365].cleanup_function = NULL;
    _module_functions[365].params = NULL;

    /* Function: token_enum */
    _module_functions[366].name = "token_enum";
    _module_functions[366].param_count = 0;
    _module_functions[366].return_type = 0;
    _module_functions[366].return_struct_type_name = NULL;
    _module_functions[366].return_fn_sig = NULL;
    _module_functions[366].return_type_info = NULL;
    _module_functions[366].body = NULL;
    _module_functions[366].shadow_test = NULL;
    _module_functions[366].is_extern = false;
    _module_functions[366].returns_gc_managed = false;
    _module_functions[366].requires_manual_free = false;
    _module_functions[366].returns_borrowed = false;
    _module_functions[366].cleanup_function = NULL;
    _module_functions[366].params = NULL;

    /* Function: token_union */
    _module_functions[367].name = "token_union";
    _module_functions[367].param_count = 0;
    _module_functions[367].return_type = 0;
    _module_functions[367].return_struct_type_name = NULL;
    _module_functions[367].return_fn_sig = NULL;
    _module_functions[367].return_type_info = NULL;
    _module_functions[367].body = NULL;
    _module_functions[367].shadow_test = NULL;
    _module_functions[367].is_extern = false;
    _module_functions[367].returns_gc_managed = false;
    _module_functions[367].requires_manual_free = false;
    _module_functions[367].returns_borrowed = false;
    _module_functions[367].cleanup_function = NULL;
    _module_functions[367].params = NULL;

    /* Function: token_for */
    _module_functions[368].name = "token_for";
    _module_functions[368].param_count = 0;
    _module_functions[368].return_type = 0;
    _module_functions[368].return_struct_type_name = NULL;
    _module_functions[368].return_fn_sig = NULL;
    _module_functions[368].return_type_info = NULL;
    _module_functions[368].body = NULL;
    _module_functions[368].shadow_test = NULL;
    _module_functions[368].is_extern = false;
    _module_functions[368].returns_gc_managed = false;
    _module_functions[368].requires_manual_free = false;
    _module_functions[368].returns_borrowed = false;
    _module_functions[368].cleanup_function = NULL;
    _module_functions[368].params = NULL;

    /* Function: token_in */
    _module_functions[369].name = "token_in";
    _module_functions[369].param_count = 0;
    _module_functions[369].return_type = 0;
    _module_functions[369].return_struct_type_name = NULL;
    _module_functions[369].return_fn_sig = NULL;
    _module_functions[369].return_type_info = NULL;
    _module_functions[369].body = NULL;
    _module_functions[369].shadow_test = NULL;
    _module_functions[369].is_extern = false;
    _module_functions[369].returns_gc_managed = false;
    _module_functions[369].requires_manual_free = false;
    _module_functions[369].returns_borrowed = false;
    _module_functions[369].cleanup_function = NULL;
    _module_functions[369].params = NULL;

    /* Function: token_assert */
    _module_functions[370].name = "token_assert";
    _module_functions[370].param_count = 0;
    _module_functions[370].return_type = 0;
    _module_functions[370].return_struct_type_name = NULL;
    _module_functions[370].return_fn_sig = NULL;
    _module_functions[370].return_type_info = NULL;
    _module_functions[370].body = NULL;
    _module_functions[370].shadow_test = NULL;
    _module_functions[370].is_extern = false;
    _module_functions[370].returns_gc_managed = false;
    _module_functions[370].requires_manual_free = false;
    _module_functions[370].returns_borrowed = false;
    _module_functions[370].cleanup_function = NULL;
    _module_functions[370].params = NULL;

    /* Function: token_requires */
    _module_functions[371].name = "token_requires";
    _module_functions[371].param_count = 0;
    _module_functions[371].return_type = 0;
    _module_functions[371].return_struct_type_name = NULL;
    _module_functions[371].return_fn_sig = NULL;
    _module_functions[371].return_type_info = NULL;
    _module_functions[371].body = NULL;
    _module_functions[371].shadow_test = NULL;
    _module_functions[371].is_extern = false;
    _module_functions[371].returns_gc_managed = false;
    _module_functions[371].requires_manual_free = false;
    _module_functions[371].returns_borrowed = false;
    _module_functions[371].cleanup_function = NULL;
    _module_functions[371].params = NULL;

    /* Function: token_ensures */
    _module_functions[372].name = "token_ensures";
    _module_functions[372].param_count = 0;
    _module_functions[372].return_type = 0;
    _module_functions[372].return_struct_type_name = NULL;
    _module_functions[372].return_fn_sig = NULL;
    _module_functions[372].return_type_info = NULL;
    _module_functions[372].body = NULL;
    _module_functions[372].shadow_test = NULL;
    _module_functions[372].is_extern = false;
    _module_functions[372].returns_gc_managed = false;
    _module_functions[372].requires_manual_free = false;
    _module_functions[372].returns_borrowed = false;
    _module_functions[372].cleanup_function = NULL;
    _module_functions[372].params = NULL;

    /* Function: token_unsafe */
    _module_functions[373].name = "token_unsafe";
    _module_functions[373].param_count = 0;
    _module_functions[373].return_type = 0;
    _module_functions[373].return_struct_type_name = NULL;
    _module_functions[373].return_fn_sig = NULL;
    _module_functions[373].return_type_info = NULL;
    _module_functions[373].body = NULL;
    _module_functions[373].shadow_test = NULL;
    _module_functions[373].is_extern = false;
    _module_functions[373].returns_gc_managed = false;
    _module_functions[373].requires_manual_free = false;
    _module_functions[373].returns_borrowed = false;
    _module_functions[373].cleanup_function = NULL;
    _module_functions[373].params = NULL;

    /* Function: token_shadow */
    _module_functions[374].name = "token_shadow";
    _module_functions[374].param_count = 0;
    _module_functions[374].return_type = 0;
    _module_functions[374].return_struct_type_name = NULL;
    _module_functions[374].return_fn_sig = NULL;
    _module_functions[374].return_type_info = NULL;
    _module_functions[374].body = NULL;
    _module_functions[374].shadow_test = NULL;
    _module_functions[374].is_extern = false;
    _module_functions[374].returns_gc_managed = false;
    _module_functions[374].requires_manual_free = false;
    _module_functions[374].returns_borrowed = false;
    _module_functions[374].cleanup_function = NULL;
    _module_functions[374].params = NULL;

    /* Function: token_match */
    _module_functions[375].name = "token_match";
    _module_functions[375].param_count = 0;
    _module_functions[375].return_type = 0;
    _module_functions[375].return_struct_type_name = NULL;
    _module_functions[375].return_fn_sig = NULL;
    _module_functions[375].return_type_info = NULL;
    _module_functions[375].body = NULL;
    _module_functions[375].shadow_test = NULL;
    _module_functions[375].is_extern = false;
    _module_functions[375].returns_gc_managed = false;
    _module_functions[375].requires_manual_free = false;
    _module_functions[375].returns_borrowed = false;
    _module_functions[375].cleanup_function = NULL;
    _module_functions[375].params = NULL;

    /* Function: token_import */
    _module_functions[376].name = "token_import";
    _module_functions[376].param_count = 0;
    _module_functions[376].return_type = 0;
    _module_functions[376].return_struct_type_name = NULL;
    _module_functions[376].return_fn_sig = NULL;
    _module_functions[376].return_type_info = NULL;
    _module_functions[376].body = NULL;
    _module_functions[376].shadow_test = NULL;
    _module_functions[376].is_extern = false;
    _module_functions[376].returns_gc_managed = false;
    _module_functions[376].requires_manual_free = false;
    _module_functions[376].returns_borrowed = false;
    _module_functions[376].cleanup_function = NULL;
    _module_functions[376].params = NULL;

    /* Function: token_as */
    _module_functions[377].name = "token_as";
    _module_functions[377].param_count = 0;
    _module_functions[377].return_type = 0;
    _module_functions[377].return_struct_type_name = NULL;
    _module_functions[377].return_fn_sig = NULL;
    _module_functions[377].return_type_info = NULL;
    _module_functions[377].body = NULL;
    _module_functions[377].shadow_test = NULL;
    _module_functions[377].is_extern = false;
    _module_functions[377].returns_gc_managed = false;
    _module_functions[377].requires_manual_free = false;
    _module_functions[377].returns_borrowed = false;
    _module_functions[377].cleanup_function = NULL;
    _module_functions[377].params = NULL;

    /* Function: token_pub */
    _module_functions[378].name = "token_pub";
    _module_functions[378].param_count = 0;
    _module_functions[378].return_type = 0;
    _module_functions[378].return_struct_type_name = NULL;
    _module_functions[378].return_fn_sig = NULL;
    _module_functions[378].return_type_info = NULL;
    _module_functions[378].body = NULL;
    _module_functions[378].shadow_test = NULL;
    _module_functions[378].is_extern = false;
    _module_functions[378].returns_gc_managed = false;
    _module_functions[378].requires_manual_free = false;
    _module_functions[378].returns_borrowed = false;
    _module_functions[378].cleanup_function = NULL;
    _module_functions[378].params = NULL;

    /* Function: token_pure */
    _module_functions[379].name = "token_pure";
    _module_functions[379].param_count = 0;
    _module_functions[379].return_type = 0;
    _module_functions[379].return_struct_type_name = NULL;
    _module_functions[379].return_fn_sig = NULL;
    _module_functions[379].return_type_info = NULL;
    _module_functions[379].body = NULL;
    _module_functions[379].shadow_test = NULL;
    _module_functions[379].is_extern = false;
    _module_functions[379].returns_gc_managed = false;
    _module_functions[379].requires_manual_free = false;
    _module_functions[379].returns_borrowed = false;
    _module_functions[379].cleanup_function = NULL;
    _module_functions[379].params = NULL;

    /* Function: token_opaque */
    _module_functions[380].name = "token_opaque";
    _module_functions[380].param_count = 0;
    _module_functions[380].return_type = 0;
    _module_functions[380].return_struct_type_name = NULL;
    _module_functions[380].return_fn_sig = NULL;
    _module_functions[380].return_type_info = NULL;
    _module_functions[380].body = NULL;
    _module_functions[380].shadow_test = NULL;
    _module_functions[380].is_extern = false;
    _module_functions[380].returns_gc_managed = false;
    _module_functions[380].requires_manual_free = false;
    _module_functions[380].returns_borrowed = false;
    _module_functions[380].cleanup_function = NULL;
    _module_functions[380].params = NULL;

    /* Function: token_lbracket */
    _module_functions[381].name = "token_lbracket";
    _module_functions[381].param_count = 0;
    _module_functions[381].return_type = 0;
    _module_functions[381].return_struct_type_name = NULL;
    _module_functions[381].return_fn_sig = NULL;
    _module_functions[381].return_type_info = NULL;
    _module_functions[381].body = NULL;
    _module_functions[381].shadow_test = NULL;
    _module_functions[381].is_extern = false;
    _module_functions[381].returns_gc_managed = false;
    _module_functions[381].requires_manual_free = false;
    _module_functions[381].returns_borrowed = false;
    _module_functions[381].cleanup_function = NULL;
    _module_functions[381].params = NULL;

    /* Function: token_rbracket */
    _module_functions[382].name = "token_rbracket";
    _module_functions[382].param_count = 0;
    _module_functions[382].return_type = 0;
    _module_functions[382].return_struct_type_name = NULL;
    _module_functions[382].return_fn_sig = NULL;
    _module_functions[382].return_type_info = NULL;
    _module_functions[382].body = NULL;
    _module_functions[382].shadow_test = NULL;
    _module_functions[382].is_extern = false;
    _module_functions[382].returns_gc_managed = false;
    _module_functions[382].requires_manual_free = false;
    _module_functions[382].returns_borrowed = false;
    _module_functions[382].cleanup_function = NULL;
    _module_functions[382].params = NULL;

    /* Function: token_dot */
    _module_functions[383].name = "token_dot";
    _module_functions[383].param_count = 0;
    _module_functions[383].return_type = 0;
    _module_functions[383].return_struct_type_name = NULL;
    _module_functions[383].return_fn_sig = NULL;
    _module_functions[383].return_type_info = NULL;
    _module_functions[383].body = NULL;
    _module_functions[383].shadow_test = NULL;
    _module_functions[383].is_extern = false;
    _module_functions[383].returns_gc_managed = false;
    _module_functions[383].requires_manual_free = false;
    _module_functions[383].returns_borrowed = false;
    _module_functions[383].cleanup_function = NULL;
    _module_functions[383].params = NULL;

    /* Function: token_double_colon */
    _module_functions[384].name = "token_double_colon";
    _module_functions[384].param_count = 0;
    _module_functions[384].return_type = 0;
    _module_functions[384].return_struct_type_name = NULL;
    _module_functions[384].return_fn_sig = NULL;
    _module_functions[384].return_type_info = NULL;
    _module_functions[384].body = NULL;
    _module_functions[384].shadow_test = NULL;
    _module_functions[384].is_extern = false;
    _module_functions[384].returns_gc_managed = false;
    _module_functions[384].requires_manual_free = false;
    _module_functions[384].returns_borrowed = false;
    _module_functions[384].cleanup_function = NULL;
    _module_functions[384].params = NULL;

    /* Function: token_percent */
    _module_functions[385].name = "token_percent";
    _module_functions[385].param_count = 0;
    _module_functions[385].return_type = 0;
    _module_functions[385].return_struct_type_name = NULL;
    _module_functions[385].return_fn_sig = NULL;
    _module_functions[385].return_type_info = NULL;
    _module_functions[385].body = NULL;
    _module_functions[385].shadow_test = NULL;
    _module_functions[385].is_extern = false;
    _module_functions[385].returns_gc_managed = false;
    _module_functions[385].requires_manual_free = false;
    _module_functions[385].returns_borrowed = false;
    _module_functions[385].cleanup_function = NULL;
    _module_functions[385].params = NULL;

    /* Function: token_not */
    _module_functions[386].name = "token_not";
    _module_functions[386].param_count = 0;
    _module_functions[386].return_type = 0;
    _module_functions[386].return_struct_type_name = NULL;
    _module_functions[386].return_fn_sig = NULL;
    _module_functions[386].return_type_info = NULL;
    _module_functions[386].body = NULL;
    _module_functions[386].shadow_test = NULL;
    _module_functions[386].is_extern = false;
    _module_functions[386].returns_gc_managed = false;
    _module_functions[386].requires_manual_free = false;
    _module_functions[386].returns_borrowed = false;
    _module_functions[386].cleanup_function = NULL;
    _module_functions[386].params = NULL;

    /* Function: token_pipe */
    _module_functions[387].name = "token_pipe";
    _module_functions[387].param_count = 0;
    _module_functions[387].return_type = 0;
    _module_functions[387].return_struct_type_name = NULL;
    _module_functions[387].return_fn_sig = NULL;
    _module_functions[387].return_type_info = NULL;
    _module_functions[387].body = NULL;
    _module_functions[387].shadow_test = NULL;
    _module_functions[387].is_extern = false;
    _module_functions[387].returns_gc_managed = false;
    _module_functions[387].requires_manual_free = false;
    _module_functions[387].returns_borrowed = false;
    _module_functions[387].cleanup_function = NULL;
    _module_functions[387].params = NULL;

    /* Function: token_grammar */
    _module_functions[388].name = "token_grammar";
    _module_functions[388].param_count = 0;
    _module_functions[388].return_type = 0;
    _module_functions[388].return_struct_type_name = NULL;
    _module_functions[388].return_fn_sig = NULL;
    _module_functions[388].return_type_info = NULL;
    _module_functions[388].body = NULL;
    _module_functions[388].shadow_test = NULL;
    _module_functions[388].is_extern = false;
    _module_functions[388].returns_gc_managed = false;
    _module_functions[388].requires_manual_free = false;
    _module_functions[388].returns_borrowed = false;
    _module_functions[388].cleanup_function = NULL;
    _module_functions[388].params = NULL;

    /* Function: token_larrow */
    _module_functions[389].name = "token_larrow";
    _module_functions[389].param_count = 0;
    _module_functions[389].return_type = 0;
    _module_functions[389].return_struct_type_name = NULL;
    _module_functions[389].return_fn_sig = NULL;
    _module_functions[389].return_type_info = NULL;
    _module_functions[389].body = NULL;
    _module_functions[389].shadow_test = NULL;
    _module_functions[389].is_extern = false;
    _module_functions[389].returns_gc_managed = false;
    _module_functions[389].requires_manual_free = false;
    _module_functions[389].returns_borrowed = false;
    _module_functions[389].cleanup_function = NULL;
    _module_functions[389].params = NULL;

    /* Function: token_question */
    _module_functions[390].name = "token_question";
    _module_functions[390].param_count = 0;
    _module_functions[390].return_type = 0;
    _module_functions[390].return_struct_type_name = NULL;
    _module_functions[390].return_fn_sig = NULL;
    _module_functions[390].return_type_info = NULL;
    _module_functions[390].body = NULL;
    _module_functions[390].shadow_test = NULL;
    _module_functions[390].is_extern = false;
    _module_functions[390].returns_gc_managed = false;
    _module_functions[390].requires_manual_free = false;
    _module_functions[390].returns_borrowed = false;
    _module_functions[390].cleanup_function = NULL;
    _module_functions[390].params = NULL;

    /* Function: token_array */
    _module_functions[391].name = "token_array";
    _module_functions[391].param_count = 0;
    _module_functions[391].return_type = 0;
    _module_functions[391].return_struct_type_name = NULL;
    _module_functions[391].return_fn_sig = NULL;
    _module_functions[391].return_type_info = NULL;
    _module_functions[391].body = NULL;
    _module_functions[391].shadow_test = NULL;
    _module_functions[391].is_extern = false;
    _module_functions[391].returns_gc_managed = false;
    _module_functions[391].requires_manual_free = false;
    _module_functions[391].returns_borrowed = false;
    _module_functions[391].cleanup_function = NULL;
    _module_functions[391].params = NULL;

    /* Function: token_type_int */
    _module_functions[392].name = "token_type_int";
    _module_functions[392].param_count = 0;
    _module_functions[392].return_type = 0;
    _module_functions[392].return_struct_type_name = NULL;
    _module_functions[392].return_fn_sig = NULL;
    _module_functions[392].return_type_info = NULL;
    _module_functions[392].body = NULL;
    _module_functions[392].shadow_test = NULL;
    _module_functions[392].is_extern = false;
    _module_functions[392].returns_gc_managed = false;
    _module_functions[392].requires_manual_free = false;
    _module_functions[392].returns_borrowed = false;
    _module_functions[392].cleanup_function = NULL;
    _module_functions[392].params = NULL;

    /* Function: token_type_u8 */
    _module_functions[393].name = "token_type_u8";
    _module_functions[393].param_count = 0;
    _module_functions[393].return_type = 0;
    _module_functions[393].return_struct_type_name = NULL;
    _module_functions[393].return_fn_sig = NULL;
    _module_functions[393].return_type_info = NULL;
    _module_functions[393].body = NULL;
    _module_functions[393].shadow_test = NULL;
    _module_functions[393].is_extern = false;
    _module_functions[393].returns_gc_managed = false;
    _module_functions[393].requires_manual_free = false;
    _module_functions[393].returns_borrowed = false;
    _module_functions[393].cleanup_function = NULL;
    _module_functions[393].params = NULL;

    /* Function: token_type_float */
    _module_functions[394].name = "token_type_float";
    _module_functions[394].param_count = 0;
    _module_functions[394].return_type = 0;
    _module_functions[394].return_struct_type_name = NULL;
    _module_functions[394].return_fn_sig = NULL;
    _module_functions[394].return_type_info = NULL;
    _module_functions[394].body = NULL;
    _module_functions[394].shadow_test = NULL;
    _module_functions[394].is_extern = false;
    _module_functions[394].returns_gc_managed = false;
    _module_functions[394].requires_manual_free = false;
    _module_functions[394].returns_borrowed = false;
    _module_functions[394].cleanup_function = NULL;
    _module_functions[394].params = NULL;

    /* Function: token_type_bool */
    _module_functions[395].name = "token_type_bool";
    _module_functions[395].param_count = 0;
    _module_functions[395].return_type = 0;
    _module_functions[395].return_struct_type_name = NULL;
    _module_functions[395].return_fn_sig = NULL;
    _module_functions[395].return_type_info = NULL;
    _module_functions[395].body = NULL;
    _module_functions[395].shadow_test = NULL;
    _module_functions[395].is_extern = false;
    _module_functions[395].returns_gc_managed = false;
    _module_functions[395].requires_manual_free = false;
    _module_functions[395].returns_borrowed = false;
    _module_functions[395].cleanup_function = NULL;
    _module_functions[395].params = NULL;

    /* Function: token_type_string */
    _module_functions[396].name = "token_type_string";
    _module_functions[396].param_count = 0;
    _module_functions[396].return_type = 0;
    _module_functions[396].return_struct_type_name = NULL;
    _module_functions[396].return_fn_sig = NULL;
    _module_functions[396].return_type_info = NULL;
    _module_functions[396].body = NULL;
    _module_functions[396].shadow_test = NULL;
    _module_functions[396].is_extern = false;
    _module_functions[396].returns_gc_managed = false;
    _module_functions[396].requires_manual_free = false;
    _module_functions[396].returns_borrowed = false;
    _module_functions[396].cleanup_function = NULL;
    _module_functions[396].params = NULL;

    /* Function: token_type_bstring */
    _module_functions[397].name = "token_type_bstring";
    _module_functions[397].param_count = 0;
    _module_functions[397].return_type = 0;
    _module_functions[397].return_struct_type_name = NULL;
    _module_functions[397].return_fn_sig = NULL;
    _module_functions[397].return_type_info = NULL;
    _module_functions[397].body = NULL;
    _module_functions[397].shadow_test = NULL;
    _module_functions[397].is_extern = false;
    _module_functions[397].returns_gc_managed = false;
    _module_functions[397].requires_manual_free = false;
    _module_functions[397].returns_borrowed = false;
    _module_functions[397].cleanup_function = NULL;
    _module_functions[397].params = NULL;

    /* Function: token_type_void */
    _module_functions[398].name = "token_type_void";
    _module_functions[398].param_count = 0;
    _module_functions[398].return_type = 0;
    _module_functions[398].return_struct_type_name = NULL;
    _module_functions[398].return_fn_sig = NULL;
    _module_functions[398].return_type_info = NULL;
    _module_functions[398].body = NULL;
    _module_functions[398].shadow_test = NULL;
    _module_functions[398].is_extern = false;
    _module_functions[398].returns_gc_managed = false;
    _module_functions[398].requires_manual_free = false;
    _module_functions[398].returns_borrowed = false;
    _module_functions[398].cleanup_function = NULL;
    _module_functions[398].params = NULL;

    /* Function: parse_qualified_name */
    _module_functions[399].name = "parse_qualified_name";
    _module_functions[399].param_count = 1;
    _module_functions[399].return_type = 8;
    _module_functions[399].return_struct_type_name = "__nano_record_706172736572_NameParseResult";
    _module_functions[399].return_fn_sig = NULL;
    _module_functions[399].return_type_info = NULL;
    _module_functions[399].body = NULL;
    _module_functions[399].shadow_test = NULL;
    _module_functions[399].is_extern = false;
    _module_functions[399].returns_gc_managed = false;
    _module_functions[399].requires_manual_free = false;
    _module_functions[399].returns_borrowed = false;
    _module_functions[399].cleanup_function = NULL;
    _module_functions[399].params = &_module_params[370];
    _module_params[370].name = "p";
    _module_params[370].type = 8;
    _module_params[370].struct_type_name = "Parser";
    _module_params[370].element_type = 21;
    _module_params[370].fn_sig = NULL;

    /* Function: parse_call_name */
    _module_functions[400].name = "parse_call_name";
    _module_functions[400].param_count = 1;
    _module_functions[400].return_type = 8;
    _module_functions[400].return_struct_type_name = "__nano_record_706172736572_NameParseResult";
    _module_functions[400].return_fn_sig = NULL;
    _module_functions[400].return_type_info = NULL;
    _module_functions[400].body = NULL;
    _module_functions[400].shadow_test = NULL;
    _module_functions[400].is_extern = false;
    _module_functions[400].returns_gc_managed = false;
    _module_functions[400].requires_manual_free = false;
    _module_functions[400].returns_borrowed = false;
    _module_functions[400].cleanup_function = NULL;
    _module_functions[400].params = &_module_params[371];
    _module_params[371].name = "p";
    _module_params[371].type = 8;
    _module_params[371].struct_type_name = "Parser";
    _module_params[371].element_type = 21;
    _module_params[371].fn_sig = NULL;

    /* Function: is_type_start_token_type */
    _module_functions[401].name = "is_type_start_token_type";
    _module_functions[401].param_count = 1;
    _module_functions[401].return_type = 3;
    _module_functions[401].return_struct_type_name = NULL;
    _module_functions[401].return_fn_sig = NULL;
    _module_functions[401].return_type_info = NULL;
    _module_functions[401].body = NULL;
    _module_functions[401].shadow_test = NULL;
    _module_functions[401].is_extern = false;
    _module_functions[401].returns_gc_managed = false;
    _module_functions[401].requires_manual_free = false;
    _module_functions[401].returns_borrowed = false;
    _module_functions[401].cleanup_function = NULL;
    _module_functions[401].params = &_module_params[372];
    _module_params[372].name = "token_type";
    _module_params[372].type = 0;
    _module_params[372].struct_type_name = NULL;
    _module_params[372].element_type = 21;
    _module_params[372].fn_sig = NULL;

    /* Function: parse_type_string */
    _module_functions[402].name = "parse_type_string";
    _module_functions[402].param_count = 1;
    _module_functions[402].return_type = 8;
    _module_functions[402].return_struct_type_name = "__nano_record_706172736572_TypeParseResult";
    _module_functions[402].return_fn_sig = NULL;
    _module_functions[402].return_type_info = NULL;
    _module_functions[402].body = NULL;
    _module_functions[402].shadow_test = NULL;
    _module_functions[402].is_extern = false;
    _module_functions[402].returns_gc_managed = false;
    _module_functions[402].requires_manual_free = false;
    _module_functions[402].returns_borrowed = false;
    _module_functions[402].cleanup_function = NULL;
    _module_functions[402].params = &_module_params[373];
    _module_params[373].name = "p";
    _module_params[373].type = 8;
    _module_params[373].struct_type_name = "Parser";
    _module_params[373].element_type = 21;
    _module_params[373].fn_sig = NULL;

    /* Function: parser_store_number */
    _module_functions[403].name = "parser_store_number";
    _module_functions[403].param_count = 4;
    _module_functions[403].return_type = 8;
    _module_functions[403].return_struct_type_name = "Parser";
    _module_functions[403].return_fn_sig = NULL;
    _module_functions[403].return_type_info = NULL;
    _module_functions[403].body = NULL;
    _module_functions[403].shadow_test = NULL;
    _module_functions[403].is_extern = false;
    _module_functions[403].returns_gc_managed = false;
    _module_functions[403].requires_manual_free = false;
    _module_functions[403].returns_borrowed = false;
    _module_functions[403].cleanup_function = NULL;
    _module_functions[403].params = &_module_params[374];
    _module_params[374].name = "p";
    _module_params[374].type = 8;
    _module_params[374].struct_type_name = "Parser";
    _module_params[374].element_type = 21;
    _module_params[374].fn_sig = NULL;
    _module_params[375].name = "value";
    _module_params[375].type = 4;
    _module_params[375].struct_type_name = NULL;
    _module_params[375].element_type = 21;
    _module_params[375].fn_sig = NULL;
    _module_params[376].name = "line";
    _module_params[376].type = 0;
    _module_params[376].struct_type_name = NULL;
    _module_params[376].element_type = 21;
    _module_params[376].fn_sig = NULL;
    _module_params[377].name = "column";
    _module_params[377].type = 0;
    _module_params[377].struct_type_name = NULL;
    _module_params[377].element_type = 21;
    _module_params[377].fn_sig = NULL;

    /* Function: parser_store_string */
    _module_functions[404].name = "parser_store_string";
    _module_functions[404].param_count = 4;
    _module_functions[404].return_type = 8;
    _module_functions[404].return_struct_type_name = "Parser";
    _module_functions[404].return_fn_sig = NULL;
    _module_functions[404].return_type_info = NULL;
    _module_functions[404].body = NULL;
    _module_functions[404].shadow_test = NULL;
    _module_functions[404].is_extern = false;
    _module_functions[404].returns_gc_managed = false;
    _module_functions[404].requires_manual_free = false;
    _module_functions[404].returns_borrowed = false;
    _module_functions[404].cleanup_function = NULL;
    _module_functions[404].params = &_module_params[378];
    _module_params[378].name = "p";
    _module_params[378].type = 8;
    _module_params[378].struct_type_name = "Parser";
    _module_params[378].element_type = 21;
    _module_params[378].fn_sig = NULL;
    _module_params[379].name = "value";
    _module_params[379].type = 4;
    _module_params[379].struct_type_name = NULL;
    _module_params[379].element_type = 21;
    _module_params[379].fn_sig = NULL;
    _module_params[380].name = "line";
    _module_params[380].type = 0;
    _module_params[380].struct_type_name = NULL;
    _module_params[380].element_type = 21;
    _module_params[380].fn_sig = NULL;
    _module_params[381].name = "column";
    _module_params[381].type = 0;
    _module_params[381].struct_type_name = NULL;
    _module_params[381].element_type = 21;
    _module_params[381].fn_sig = NULL;

    /* Function: parser_store_bool */
    _module_functions[405].name = "parser_store_bool";
    _module_functions[405].param_count = 4;
    _module_functions[405].return_type = 8;
    _module_functions[405].return_struct_type_name = "Parser";
    _module_functions[405].return_fn_sig = NULL;
    _module_functions[405].return_type_info = NULL;
    _module_functions[405].body = NULL;
    _module_functions[405].shadow_test = NULL;
    _module_functions[405].is_extern = false;
    _module_functions[405].returns_gc_managed = false;
    _module_functions[405].requires_manual_free = false;
    _module_functions[405].returns_borrowed = false;
    _module_functions[405].cleanup_function = NULL;
    _module_functions[405].params = &_module_params[382];
    _module_params[382].name = "p";
    _module_params[382].type = 8;
    _module_params[382].struct_type_name = "Parser";
    _module_params[382].element_type = 21;
    _module_params[382].fn_sig = NULL;
    _module_params[383].name = "value";
    _module_params[383].type = 3;
    _module_params[383].struct_type_name = NULL;
    _module_params[383].element_type = 21;
    _module_params[383].fn_sig = NULL;
    _module_params[384].name = "line";
    _module_params[384].type = 0;
    _module_params[384].struct_type_name = NULL;
    _module_params[384].element_type = 21;
    _module_params[384].fn_sig = NULL;
    _module_params[385].name = "column";
    _module_params[385].type = 0;
    _module_params[385].struct_type_name = NULL;
    _module_params[385].element_type = 21;
    _module_params[385].fn_sig = NULL;

    /* Function: parser_store_identifier */
    _module_functions[406].name = "parser_store_identifier";
    _module_functions[406].param_count = 4;
    _module_functions[406].return_type = 8;
    _module_functions[406].return_struct_type_name = "Parser";
    _module_functions[406].return_fn_sig = NULL;
    _module_functions[406].return_type_info = NULL;
    _module_functions[406].body = NULL;
    _module_functions[406].shadow_test = NULL;
    _module_functions[406].is_extern = false;
    _module_functions[406].returns_gc_managed = false;
    _module_functions[406].requires_manual_free = false;
    _module_functions[406].returns_borrowed = false;
    _module_functions[406].cleanup_function = NULL;
    _module_functions[406].params = &_module_params[386];
    _module_params[386].name = "p";
    _module_params[386].type = 8;
    _module_params[386].struct_type_name = "Parser";
    _module_params[386].element_type = 21;
    _module_params[386].fn_sig = NULL;
    _module_params[387].name = "name";
    _module_params[387].type = 4;
    _module_params[387].struct_type_name = NULL;
    _module_params[387].element_type = 21;
    _module_params[387].fn_sig = NULL;
    _module_params[388].name = "line";
    _module_params[388].type = 0;
    _module_params[388].struct_type_name = NULL;
    _module_params[388].element_type = 21;
    _module_params[388].fn_sig = NULL;
    _module_params[389].name = "column";
    _module_params[389].type = 0;
    _module_params[389].struct_type_name = NULL;
    _module_params[389].element_type = 21;
    _module_params[389].fn_sig = NULL;

    /* Function: parser_store_binary_op */
    _module_functions[407].name = "parser_store_binary_op";
    _module_functions[407].param_count = 8;
    _module_functions[407].return_type = 8;
    _module_functions[407].return_struct_type_name = "Parser";
    _module_functions[407].return_fn_sig = NULL;
    _module_functions[407].return_type_info = NULL;
    _module_functions[407].body = NULL;
    _module_functions[407].shadow_test = NULL;
    _module_functions[407].is_extern = false;
    _module_functions[407].returns_gc_managed = false;
    _module_functions[407].requires_manual_free = false;
    _module_functions[407].returns_borrowed = false;
    _module_functions[407].cleanup_function = NULL;
    _module_functions[407].params = &_module_params[390];
    _module_params[390].name = "p";
    _module_params[390].type = 8;
    _module_params[390].struct_type_name = "Parser";
    _module_params[390].element_type = 21;
    _module_params[390].fn_sig = NULL;
    _module_params[391].name = "op";
    _module_params[391].type = 0;
    _module_params[391].struct_type_name = NULL;
    _module_params[391].element_type = 21;
    _module_params[391].fn_sig = NULL;
    _module_params[392].name = "left_id";
    _module_params[392].type = 0;
    _module_params[392].struct_type_name = NULL;
    _module_params[392].element_type = 21;
    _module_params[392].fn_sig = NULL;
    _module_params[393].name = "right_id";
    _module_params[393].type = 0;
    _module_params[393].struct_type_name = NULL;
    _module_params[393].element_type = 21;
    _module_params[393].fn_sig = NULL;
    _module_params[394].name = "left_type";
    _module_params[394].type = 0;
    _module_params[394].struct_type_name = NULL;
    _module_params[394].element_type = 21;
    _module_params[394].fn_sig = NULL;
    _module_params[395].name = "right_type";
    _module_params[395].type = 0;
    _module_params[395].struct_type_name = NULL;
    _module_params[395].element_type = 21;
    _module_params[395].fn_sig = NULL;
    _module_params[396].name = "line";
    _module_params[396].type = 0;
    _module_params[396].struct_type_name = NULL;
    _module_params[396].element_type = 21;
    _module_params[396].fn_sig = NULL;
    _module_params[397].name = "column";
    _module_params[397].type = 0;
    _module_params[397].struct_type_name = NULL;
    _module_params[397].element_type = 21;
    _module_params[397].fn_sig = NULL;

    /* Function: parser_mark_unary */
    _module_functions[408].name = "parser_mark_unary";
    _module_functions[408].param_count = 1;
    _module_functions[408].return_type = 8;
    _module_functions[408].return_struct_type_name = "Parser";
    _module_functions[408].return_fn_sig = NULL;
    _module_functions[408].return_type_info = NULL;
    _module_functions[408].body = NULL;
    _module_functions[408].shadow_test = NULL;
    _module_functions[408].is_extern = false;
    _module_functions[408].returns_gc_managed = false;
    _module_functions[408].requires_manual_free = false;
    _module_functions[408].returns_borrowed = false;
    _module_functions[408].cleanup_function = NULL;
    _module_functions[408].params = &_module_params[398];
    _module_params[398].name = "p";
    _module_params[398].type = 8;
    _module_params[398].struct_type_name = "Parser";
    _module_params[398].element_type = 21;
    _module_params[398].fn_sig = NULL;

    /* Function: parser_store_call */
    _module_functions[409].name = "parser_store_call";
    _module_functions[409].param_count = 7;
    _module_functions[409].return_type = 8;
    _module_functions[409].return_struct_type_name = "Parser";
    _module_functions[409].return_fn_sig = NULL;
    _module_functions[409].return_type_info = NULL;
    _module_functions[409].body = NULL;
    _module_functions[409].shadow_test = NULL;
    _module_functions[409].is_extern = false;
    _module_functions[409].returns_gc_managed = false;
    _module_functions[409].requires_manual_free = false;
    _module_functions[409].returns_borrowed = false;
    _module_functions[409].cleanup_function = NULL;
    _module_functions[409].params = &_module_params[399];
    _module_params[399].name = "p";
    _module_params[399].type = 8;
    _module_params[399].struct_type_name = "Parser";
    _module_params[399].element_type = 21;
    _module_params[399].fn_sig = NULL;
    _module_params[400].name = "function_id";
    _module_params[400].type = 0;
    _module_params[400].struct_type_name = NULL;
    _module_params[400].element_type = 21;
    _module_params[400].fn_sig = NULL;
    _module_params[401].name = "function_type";
    _module_params[401].type = 0;
    _module_params[401].struct_type_name = NULL;
    _module_params[401].element_type = 21;
    _module_params[401].fn_sig = NULL;
    _module_params[402].name = "arg_start";
    _module_params[402].type = 0;
    _module_params[402].struct_type_name = NULL;
    _module_params[402].element_type = 21;
    _module_params[402].fn_sig = NULL;
    _module_params[403].name = "arg_count";
    _module_params[403].type = 0;
    _module_params[403].struct_type_name = NULL;
    _module_params[403].element_type = 21;
    _module_params[403].fn_sig = NULL;
    _module_params[404].name = "line";
    _module_params[404].type = 0;
    _module_params[404].struct_type_name = NULL;
    _module_params[404].element_type = 21;
    _module_params[404].fn_sig = NULL;
    _module_params[405].name = "column";
    _module_params[405].type = 0;
    _module_params[405].struct_type_name = NULL;
    _module_params[405].element_type = 21;
    _module_params[405].fn_sig = NULL;

    /* Function: parser_store_module_qualified_call */
    _module_functions[410].name = "parser_store_module_qualified_call";
    _module_functions[410].param_count = 7;
    _module_functions[410].return_type = 8;
    _module_functions[410].return_struct_type_name = "Parser";
    _module_functions[410].return_fn_sig = NULL;
    _module_functions[410].return_type_info = NULL;
    _module_functions[410].body = NULL;
    _module_functions[410].shadow_test = NULL;
    _module_functions[410].is_extern = false;
    _module_functions[410].returns_gc_managed = false;
    _module_functions[410].requires_manual_free = false;
    _module_functions[410].returns_borrowed = false;
    _module_functions[410].cleanup_function = NULL;
    _module_functions[410].params = &_module_params[406];
    _module_params[406].name = "p";
    _module_params[406].type = 8;
    _module_params[406].struct_type_name = "Parser";
    _module_params[406].element_type = 21;
    _module_params[406].fn_sig = NULL;
    _module_params[407].name = "module_name";
    _module_params[407].type = 4;
    _module_params[407].struct_type_name = NULL;
    _module_params[407].element_type = 21;
    _module_params[407].fn_sig = NULL;
    _module_params[408].name = "function_name";
    _module_params[408].type = 4;
    _module_params[408].struct_type_name = NULL;
    _module_params[408].element_type = 21;
    _module_params[408].fn_sig = NULL;
    _module_params[409].name = "arg_start";
    _module_params[409].type = 0;
    _module_params[409].struct_type_name = NULL;
    _module_params[409].element_type = 21;
    _module_params[409].fn_sig = NULL;
    _module_params[410].name = "arg_count";
    _module_params[410].type = 0;
    _module_params[410].struct_type_name = NULL;
    _module_params[410].element_type = 21;
    _module_params[410].fn_sig = NULL;
    _module_params[411].name = "line";
    _module_params[411].type = 0;
    _module_params[411].struct_type_name = NULL;
    _module_params[411].element_type = 21;
    _module_params[411].fn_sig = NULL;
    _module_params[412].name = "column";
    _module_params[412].type = 0;
    _module_params[412].struct_type_name = NULL;
    _module_params[412].element_type = 21;
    _module_params[412].fn_sig = NULL;

    /* Function: name_contains_dot */
    _module_functions[411].name = "name_contains_dot";
    _module_functions[411].param_count = 1;
    _module_functions[411].return_type = 3;
    _module_functions[411].return_struct_type_name = NULL;
    _module_functions[411].return_fn_sig = NULL;
    _module_functions[411].return_type_info = NULL;
    _module_functions[411].body = NULL;
    _module_functions[411].shadow_test = NULL;
    _module_functions[411].is_extern = false;
    _module_functions[411].returns_gc_managed = false;
    _module_functions[411].requires_manual_free = false;
    _module_functions[411].returns_borrowed = false;
    _module_functions[411].cleanup_function = NULL;
    _module_functions[411].params = &_module_params[413];
    _module_params[413].name = "name";
    _module_params[413].type = 4;
    _module_params[413].struct_type_name = NULL;
    _module_params[413].element_type = 21;
    _module_params[413].fn_sig = NULL;

    /* Function: parser_store_call_arg */
    _module_functions[412].name = "parser_store_call_arg";
    _module_functions[412].param_count = 3;
    _module_functions[412].return_type = 8;
    _module_functions[412].return_struct_type_name = "Parser";
    _module_functions[412].return_fn_sig = NULL;
    _module_functions[412].return_type_info = NULL;
    _module_functions[412].body = NULL;
    _module_functions[412].shadow_test = NULL;
    _module_functions[412].is_extern = false;
    _module_functions[412].returns_gc_managed = false;
    _module_functions[412].requires_manual_free = false;
    _module_functions[412].returns_borrowed = false;
    _module_functions[412].cleanup_function = NULL;
    _module_functions[412].params = &_module_params[414];
    _module_params[414].name = "p";
    _module_params[414].type = 8;
    _module_params[414].struct_type_name = "Parser";
    _module_params[414].element_type = 21;
    _module_params[414].fn_sig = NULL;
    _module_params[415].name = "node_id";
    _module_params[415].type = 0;
    _module_params[415].struct_type_name = NULL;
    _module_params[415].element_type = 21;
    _module_params[415].fn_sig = NULL;
    _module_params[416].name = "node_type";
    _module_params[416].type = 0;
    _module_params[416].struct_type_name = NULL;
    _module_params[416].element_type = 21;
    _module_params[416].fn_sig = NULL;

    /* Function: parser_store_array_element */
    _module_functions[413].name = "parser_store_array_element";
    _module_functions[413].param_count = 3;
    _module_functions[413].return_type = 8;
    _module_functions[413].return_struct_type_name = "Parser";
    _module_functions[413].return_fn_sig = NULL;
    _module_functions[413].return_type_info = NULL;
    _module_functions[413].body = NULL;
    _module_functions[413].shadow_test = NULL;
    _module_functions[413].is_extern = false;
    _module_functions[413].returns_gc_managed = false;
    _module_functions[413].requires_manual_free = false;
    _module_functions[413].returns_borrowed = false;
    _module_functions[413].cleanup_function = NULL;
    _module_functions[413].params = &_module_params[417];
    _module_params[417].name = "p";
    _module_params[417].type = 8;
    _module_params[417].struct_type_name = "Parser";
    _module_params[417].element_type = 21;
    _module_params[417].fn_sig = NULL;
    _module_params[418].name = "node_id";
    _module_params[418].type = 0;
    _module_params[418].struct_type_name = NULL;
    _module_params[418].element_type = 21;
    _module_params[418].fn_sig = NULL;
    _module_params[419].name = "node_type";
    _module_params[419].type = 0;
    _module_params[419].struct_type_name = NULL;
    _module_params[419].element_type = 21;
    _module_params[419].fn_sig = NULL;

    /* Function: parse_named_literal */
    _module_functions[414].name = "parse_named_literal";
    _module_functions[414].param_count = 4;
    _module_functions[414].return_type = 8;
    _module_functions[414].return_struct_type_name = "Parser";
    _module_functions[414].return_fn_sig = NULL;
    _module_functions[414].return_type_info = NULL;
    _module_functions[414].body = NULL;
    _module_functions[414].shadow_test = NULL;
    _module_functions[414].is_extern = false;
    _module_functions[414].returns_gc_managed = false;
    _module_functions[414].requires_manual_free = false;
    _module_functions[414].returns_borrowed = false;
    _module_functions[414].cleanup_function = NULL;
    _module_functions[414].params = &_module_params[420];
    _module_params[420].name = "p";
    _module_params[420].type = 8;
    _module_params[420].struct_type_name = "Parser";
    _module_params[420].element_type = 21;
    _module_params[420].fn_sig = NULL;
    _module_params[421].name = "name";
    _module_params[421].type = 4;
    _module_params[421].struct_type_name = NULL;
    _module_params[421].element_type = 21;
    _module_params[421].fn_sig = NULL;
    _module_params[422].name = "line";
    _module_params[422].type = 0;
    _module_params[422].struct_type_name = NULL;
    _module_params[422].element_type = 21;
    _module_params[422].fn_sig = NULL;
    _module_params[423].name = "column";
    _module_params[423].type = 0;
    _module_params[423].struct_type_name = NULL;
    _module_params[423].element_type = 21;
    _module_params[423].fn_sig = NULL;

    /* Function: parse_union_construct */
    _module_functions[415].name = "parse_union_construct";
    _module_functions[415].param_count = 5;
    _module_functions[415].return_type = 8;
    _module_functions[415].return_struct_type_name = "Parser";
    _module_functions[415].return_fn_sig = NULL;
    _module_functions[415].return_type_info = NULL;
    _module_functions[415].body = NULL;
    _module_functions[415].shadow_test = NULL;
    _module_functions[415].is_extern = false;
    _module_functions[415].returns_gc_managed = false;
    _module_functions[415].requires_manual_free = false;
    _module_functions[415].returns_borrowed = false;
    _module_functions[415].cleanup_function = NULL;
    _module_functions[415].params = &_module_params[424];
    _module_params[424].name = "p";
    _module_params[424].type = 8;
    _module_params[424].struct_type_name = "Parser";
    _module_params[424].element_type = 21;
    _module_params[424].fn_sig = NULL;
    _module_params[425].name = "union_name";
    _module_params[425].type = 4;
    _module_params[425].struct_type_name = NULL;
    _module_params[425].element_type = 21;
    _module_params[425].fn_sig = NULL;
    _module_params[426].name = "variant_name";
    _module_params[426].type = 4;
    _module_params[426].struct_type_name = NULL;
    _module_params[426].element_type = 21;
    _module_params[426].fn_sig = NULL;
    _module_params[427].name = "start_line";
    _module_params[427].type = 0;
    _module_params[427].struct_type_name = NULL;
    _module_params[427].element_type = 21;
    _module_params[427].fn_sig = NULL;
    _module_params[428].name = "start_column";
    _module_params[428].type = 0;
    _module_params[428].struct_type_name = NULL;
    _module_params[428].element_type = 21;
    _module_params[428].fn_sig = NULL;

    /* Function: parse_struct_literal */
    _module_functions[416].name = "parse_struct_literal";
    _module_functions[416].param_count = 4;
    _module_functions[416].return_type = 8;
    _module_functions[416].return_struct_type_name = "Parser";
    _module_functions[416].return_fn_sig = NULL;
    _module_functions[416].return_type_info = NULL;
    _module_functions[416].body = NULL;
    _module_functions[416].shadow_test = NULL;
    _module_functions[416].is_extern = false;
    _module_functions[416].returns_gc_managed = false;
    _module_functions[416].requires_manual_free = false;
    _module_functions[416].returns_borrowed = false;
    _module_functions[416].cleanup_function = NULL;
    _module_functions[416].params = &_module_params[429];
    _module_params[429].name = "p";
    _module_params[429].type = 8;
    _module_params[429].struct_type_name = "Parser";
    _module_params[429].element_type = 21;
    _module_params[429].fn_sig = NULL;
    _module_params[430].name = "struct_name";
    _module_params[430].type = 4;
    _module_params[430].struct_type_name = NULL;
    _module_params[430].element_type = 21;
    _module_params[430].fn_sig = NULL;
    _module_params[431].name = "start_line";
    _module_params[431].type = 0;
    _module_params[431].struct_type_name = NULL;
    _module_params[431].element_type = 21;
    _module_params[431].fn_sig = NULL;
    _module_params[432].name = "start_column";
    _module_params[432].type = 0;
    _module_params[432].struct_type_name = NULL;
    _module_params[432].element_type = 21;
    _module_params[432].fn_sig = NULL;

    /* Function: parse_cond_expression */
    _module_functions[417].name = "parse_cond_expression";
    _module_functions[417].param_count = 1;
    _module_functions[417].return_type = 8;
    _module_functions[417].return_struct_type_name = "Parser";
    _module_functions[417].return_fn_sig = NULL;
    _module_functions[417].return_type_info = NULL;
    _module_functions[417].body = NULL;
    _module_functions[417].shadow_test = NULL;
    _module_functions[417].is_extern = false;
    _module_functions[417].returns_gc_managed = false;
    _module_functions[417].requires_manual_free = false;
    _module_functions[417].returns_borrowed = false;
    _module_functions[417].cleanup_function = NULL;
    _module_functions[417].params = &_module_params[433];
    _module_params[433].name = "p";
    _module_params[433].type = 8;
    _module_params[433].struct_type_name = "Parser";
    _module_params[433].element_type = 21;
    _module_params[433].fn_sig = NULL;

    /* Function: parse_cond_clauses */
    _module_functions[418].name = "parse_cond_clauses";
    _module_functions[418].param_count = 3;
    _module_functions[418].return_type = 8;
    _module_functions[418].return_struct_type_name = "Parser";
    _module_functions[418].return_fn_sig = NULL;
    _module_functions[418].return_type_info = NULL;
    _module_functions[418].body = NULL;
    _module_functions[418].shadow_test = NULL;
    _module_functions[418].is_extern = false;
    _module_functions[418].returns_gc_managed = false;
    _module_functions[418].requires_manual_free = false;
    _module_functions[418].returns_borrowed = false;
    _module_functions[418].cleanup_function = NULL;
    _module_functions[418].params = &_module_params[434];
    _module_params[434].name = "p";
    _module_params[434].type = 8;
    _module_params[434].struct_type_name = "Parser";
    _module_params[434].element_type = 21;
    _module_params[434].fn_sig = NULL;
    _module_params[435].name = "line";
    _module_params[435].type = 0;
    _module_params[435].struct_type_name = NULL;
    _module_params[435].element_type = 21;
    _module_params[435].fn_sig = NULL;
    _module_params[436].name = "column";
    _module_params[436].type = 0;
    _module_params[436].struct_type_name = NULL;
    _module_params[436].element_type = 21;
    _module_params[436].fn_sig = NULL;

    /* Function: parser_expect_match_arrow */
    _module_functions[419].name = "parser_expect_match_arrow";
    _module_functions[419].param_count = 1;
    _module_functions[419].return_type = 8;
    _module_functions[419].return_struct_type_name = "Parser";
    _module_functions[419].return_fn_sig = NULL;
    _module_functions[419].return_type_info = NULL;
    _module_functions[419].body = NULL;
    _module_functions[419].shadow_test = NULL;
    _module_functions[419].is_extern = false;
    _module_functions[419].returns_gc_managed = false;
    _module_functions[419].requires_manual_free = false;
    _module_functions[419].returns_borrowed = false;
    _module_functions[419].cleanup_function = NULL;
    _module_functions[419].params = &_module_params[437];
    _module_params[437].name = "p";
    _module_params[437].type = 8;
    _module_params[437].struct_type_name = "Parser";
    _module_params[437].element_type = 21;
    _module_params[437].fn_sig = NULL;

    /* Function: parse_match_guard */
    _module_functions[420].name = "parse_match_guard";
    _module_functions[420].param_count = 1;
    _module_functions[420].return_type = 8;
    _module_functions[420].return_struct_type_name = "Parser";
    _module_functions[420].return_fn_sig = NULL;
    _module_functions[420].return_type_info = NULL;
    _module_functions[420].body = NULL;
    _module_functions[420].shadow_test = NULL;
    _module_functions[420].is_extern = false;
    _module_functions[420].returns_gc_managed = false;
    _module_functions[420].requires_manual_free = false;
    _module_functions[420].returns_borrowed = false;
    _module_functions[420].cleanup_function = NULL;
    _module_functions[420].params = &_module_params[438];
    _module_params[438].name = "p";
    _module_params[438].type = 8;
    _module_params[438].struct_type_name = "Parser";
    _module_params[438].element_type = 21;
    _module_params[438].fn_sig = NULL;

    /* Function: parser_match_arm_unconditional */
    _module_functions[421].name = "parser_match_arm_unconditional";
    _module_functions[421].param_count = 3;
    _module_functions[421].return_type = 3;
    _module_functions[421].return_struct_type_name = NULL;
    _module_functions[421].return_fn_sig = NULL;
    _module_functions[421].return_type_info = NULL;
    _module_functions[421].body = NULL;
    _module_functions[421].shadow_test = NULL;
    _module_functions[421].is_extern = false;
    _module_functions[421].returns_gc_managed = false;
    _module_functions[421].requires_manual_free = false;
    _module_functions[421].returns_borrowed = false;
    _module_functions[421].cleanup_function = NULL;
    _module_functions[421].params = &_module_params[439];
    _module_params[439].name = "p";
    _module_params[439].type = 8;
    _module_params[439].struct_type_name = "Parser";
    _module_params[439].element_type = 21;
    _module_params[439].fn_sig = NULL;
    _module_params[440].name = "matched";
    _module_params[440].type = 8;
    _module_params[440].struct_type_name = "ASTMatch";
    _module_params[440].element_type = 21;
    _module_params[440].fn_sig = NULL;
    _module_params[441].name = "arm";
    _module_params[441].type = 0;
    _module_params[441].struct_type_name = NULL;
    _module_params[441].element_type = 21;
    _module_params[441].fn_sig = NULL;

    /* Function: parse_match */
    _module_functions[422].name = "parse_match";
    _module_functions[422].param_count = 1;
    _module_functions[422].return_type = 8;
    _module_functions[422].return_struct_type_name = "Parser";
    _module_functions[422].return_fn_sig = NULL;
    _module_functions[422].return_type_info = NULL;
    _module_functions[422].body = NULL;
    _module_functions[422].shadow_test = NULL;
    _module_functions[422].is_extern = false;
    _module_functions[422].returns_gc_managed = false;
    _module_functions[422].requires_manual_free = false;
    _module_functions[422].returns_borrowed = false;
    _module_functions[422].cleanup_function = NULL;
    _module_functions[422].params = &_module_params[442];
    _module_params[442].name = "p";
    _module_params[442].type = 8;
    _module_params[442].struct_type_name = "Parser";
    _module_params[442].element_type = 21;
    _module_params[442].fn_sig = NULL;

    /* Function: parse_primary */
    _module_functions[423].name = "parse_primary";
    _module_functions[423].param_count = 1;
    _module_functions[423].return_type = 8;
    _module_functions[423].return_struct_type_name = "Parser";
    _module_functions[423].return_fn_sig = NULL;
    _module_functions[423].return_type_info = NULL;
    _module_functions[423].body = NULL;
    _module_functions[423].shadow_test = NULL;
    _module_functions[423].is_extern = false;
    _module_functions[423].returns_gc_managed = false;
    _module_functions[423].requires_manual_free = false;
    _module_functions[423].returns_borrowed = false;
    _module_functions[423].cleanup_function = NULL;
    _module_functions[423].params = &_module_params[443];
    _module_params[443].name = "p";
    _module_params[443].type = 8;
    _module_params[443].struct_type_name = "Parser";
    _module_params[443].element_type = 21;
    _module_params[443].fn_sig = NULL;

    /* Function: parse_parenthesized_head */
    _module_functions[424].name = "parse_parenthesized_head";
    _module_functions[424].param_count = 1;
    _module_functions[424].return_type = 8;
    _module_functions[424].return_struct_type_name = "Parser";
    _module_functions[424].return_fn_sig = NULL;
    _module_functions[424].return_type_info = NULL;
    _module_functions[424].body = NULL;
    _module_functions[424].shadow_test = NULL;
    _module_functions[424].is_extern = false;
    _module_functions[424].returns_gc_managed = false;
    _module_functions[424].requires_manual_free = false;
    _module_functions[424].returns_borrowed = false;
    _module_functions[424].cleanup_function = NULL;
    _module_functions[424].params = &_module_params[444];
    _module_params[444].name = "p";
    _module_params[444].type = 8;
    _module_params[444].struct_type_name = "Parser";
    _module_params[444].element_type = 21;
    _module_params[444].fn_sig = NULL;

    /* Function: parenthesized_call_start */
    _module_functions[425].name = "parenthesized_call_start";
    _module_functions[425].param_count = 1;
    _module_functions[425].return_type = 3;
    _module_functions[425].return_struct_type_name = NULL;
    _module_functions[425].return_fn_sig = NULL;
    _module_functions[425].return_type_info = NULL;
    _module_functions[425].body = NULL;
    _module_functions[425].shadow_test = NULL;
    _module_functions[425].is_extern = false;
    _module_functions[425].returns_gc_managed = false;
    _module_functions[425].requires_manual_free = false;
    _module_functions[425].returns_borrowed = false;
    _module_functions[425].cleanup_function = NULL;
    _module_functions[425].params = &_module_params[445];
    _module_params[445].name = "p";
    _module_params[445].type = 8;
    _module_params[445].struct_type_name = "Parser";
    _module_params[445].element_type = 21;
    _module_params[445].fn_sig = NULL;

    /* Function: is_binary_op */
    _module_functions[426].name = "is_binary_op";
    _module_functions[426].param_count = 1;
    _module_functions[426].return_type = 3;
    _module_functions[426].return_struct_type_name = NULL;
    _module_functions[426].return_fn_sig = NULL;
    _module_functions[426].return_type_info = NULL;
    _module_functions[426].body = NULL;
    _module_functions[426].shadow_test = NULL;
    _module_functions[426].is_extern = false;
    _module_functions[426].returns_gc_managed = false;
    _module_functions[426].requires_manual_free = false;
    _module_functions[426].returns_borrowed = false;
    _module_functions[426].cleanup_function = NULL;
    _module_functions[426].params = &_module_params[446];
    _module_params[446].name = "token_type";
    _module_params[446].type = 0;
    _module_params[446].struct_type_name = NULL;
    _module_params[446].element_type = 21;
    _module_params[446].fn_sig = NULL;

    /* Function: parse_expression_recursive */
    _module_functions[427].name = "parse_expression_recursive";
    _module_functions[427].param_count = 2;
    _module_functions[427].return_type = 8;
    _module_functions[427].return_struct_type_name = "Parser";
    _module_functions[427].return_fn_sig = NULL;
    _module_functions[427].return_type_info = NULL;
    _module_functions[427].body = NULL;
    _module_functions[427].shadow_test = NULL;
    _module_functions[427].is_extern = false;
    _module_functions[427].returns_gc_managed = false;
    _module_functions[427].requires_manual_free = false;
    _module_functions[427].returns_borrowed = false;
    _module_functions[427].cleanup_function = NULL;
    _module_functions[427].params = &_module_params[447];
    _module_params[447].name = "p";
    _module_params[447].type = 8;
    _module_params[447].struct_type_name = "Parser";
    _module_params[447].element_type = 21;
    _module_params[447].fn_sig = NULL;
    _module_params[448].name = "left_parsed";
    _module_params[448].type = 3;
    _module_params[448].struct_type_name = NULL;
    _module_params[448].element_type = 21;
    _module_params[448].fn_sig = NULL;

    /* Function: parse_expression */
    _module_functions[428].name = "parse_expression";
    _module_functions[428].param_count = 1;
    _module_functions[428].return_type = 8;
    _module_functions[428].return_struct_type_name = "Parser";
    _module_functions[428].return_fn_sig = NULL;
    _module_functions[428].return_type_info = NULL;
    _module_functions[428].body = NULL;
    _module_functions[428].shadow_test = NULL;
    _module_functions[428].is_extern = false;
    _module_functions[428].returns_gc_managed = false;
    _module_functions[428].requires_manual_free = false;
    _module_functions[428].returns_borrowed = false;
    _module_functions[428].cleanup_function = NULL;
    _module_functions[428].params = &_module_params[449];
    _module_params[449].name = "p";
    _module_params[449].type = 8;
    _module_params[449].struct_type_name = "Parser";
    _module_params[449].element_type = 21;
    _module_params[449].fn_sig = NULL;

    /* Function: parser_store_let */
    _module_functions[429].name = "parser_store_let";
    _module_functions[429].param_count = 8;
    _module_functions[429].return_type = 8;
    _module_functions[429].return_struct_type_name = "Parser";
    _module_functions[429].return_fn_sig = NULL;
    _module_functions[429].return_type_info = NULL;
    _module_functions[429].body = NULL;
    _module_functions[429].shadow_test = NULL;
    _module_functions[429].is_extern = false;
    _module_functions[429].returns_gc_managed = false;
    _module_functions[429].requires_manual_free = false;
    _module_functions[429].returns_borrowed = false;
    _module_functions[429].cleanup_function = NULL;
    _module_functions[429].params = &_module_params[450];
    _module_params[450].name = "p";
    _module_params[450].type = 8;
    _module_params[450].struct_type_name = "Parser";
    _module_params[450].element_type = 21;
    _module_params[450].fn_sig = NULL;
    _module_params[451].name = "name";
    _module_params[451].type = 4;
    _module_params[451].struct_type_name = NULL;
    _module_params[451].element_type = 21;
    _module_params[451].fn_sig = NULL;
    _module_params[452].name = "var_type";
    _module_params[452].type = 4;
    _module_params[452].struct_type_name = NULL;
    _module_params[452].element_type = 21;
    _module_params[452].fn_sig = NULL;
    _module_params[453].name = "value_id";
    _module_params[453].type = 0;
    _module_params[453].struct_type_name = NULL;
    _module_params[453].element_type = 21;
    _module_params[453].fn_sig = NULL;
    _module_params[454].name = "value_type";
    _module_params[454].type = 0;
    _module_params[454].struct_type_name = NULL;
    _module_params[454].element_type = 21;
    _module_params[454].fn_sig = NULL;
    _module_params[455].name = "is_mut";
    _module_params[455].type = 3;
    _module_params[455].struct_type_name = NULL;
    _module_params[455].element_type = 21;
    _module_params[455].fn_sig = NULL;
    _module_params[456].name = "line";
    _module_params[456].type = 0;
    _module_params[456].struct_type_name = NULL;
    _module_params[456].element_type = 21;
    _module_params[456].fn_sig = NULL;
    _module_params[457].name = "column";
    _module_params[457].type = 0;
    _module_params[457].struct_type_name = NULL;
    _module_params[457].element_type = 21;
    _module_params[457].fn_sig = NULL;

    /* Function: parser_store_set */
    _module_functions[430].name = "parser_store_set";
    _module_functions[430].param_count = 7;
    _module_functions[430].return_type = 8;
    _module_functions[430].return_struct_type_name = "Parser";
    _module_functions[430].return_fn_sig = NULL;
    _module_functions[430].return_type_info = NULL;
    _module_functions[430].body = NULL;
    _module_functions[430].shadow_test = NULL;
    _module_functions[430].is_extern = false;
    _module_functions[430].returns_gc_managed = false;
    _module_functions[430].requires_manual_free = false;
    _module_functions[430].returns_borrowed = false;
    _module_functions[430].cleanup_function = NULL;
    _module_functions[430].params = &_module_params[458];
    _module_params[458].name = "p";
    _module_params[458].type = 8;
    _module_params[458].struct_type_name = "Parser";
    _module_params[458].element_type = 21;
    _module_params[458].fn_sig = NULL;
    _module_params[459].name = "target";
    _module_params[459].type = 4;
    _module_params[459].struct_type_name = NULL;
    _module_params[459].element_type = 21;
    _module_params[459].fn_sig = NULL;
    _module_params[460].name = "field_name";
    _module_params[460].type = 4;
    _module_params[460].struct_type_name = NULL;
    _module_params[460].element_type = 21;
    _module_params[460].fn_sig = NULL;
    _module_params[461].name = "value_id";
    _module_params[461].type = 0;
    _module_params[461].struct_type_name = NULL;
    _module_params[461].element_type = 21;
    _module_params[461].fn_sig = NULL;
    _module_params[462].name = "value_type";
    _module_params[462].type = 0;
    _module_params[462].struct_type_name = NULL;
    _module_params[462].element_type = 21;
    _module_params[462].fn_sig = NULL;
    _module_params[463].name = "line";
    _module_params[463].type = 0;
    _module_params[463].struct_type_name = NULL;
    _module_params[463].element_type = 21;
    _module_params[463].fn_sig = NULL;
    _module_params[464].name = "column";
    _module_params[464].type = 0;
    _module_params[464].struct_type_name = NULL;
    _module_params[464].element_type = 21;
    _module_params[464].fn_sig = NULL;

    /* Function: parser_mark_if_expression */
    _module_functions[431].name = "parser_mark_if_expression";
    _module_functions[431].param_count = 1;
    _module_functions[431].return_type = 8;
    _module_functions[431].return_struct_type_name = "Parser";
    _module_functions[431].return_fn_sig = NULL;
    _module_functions[431].return_type_info = NULL;
    _module_functions[431].body = NULL;
    _module_functions[431].shadow_test = NULL;
    _module_functions[431].is_extern = false;
    _module_functions[431].returns_gc_managed = false;
    _module_functions[431].requires_manual_free = false;
    _module_functions[431].returns_borrowed = false;
    _module_functions[431].cleanup_function = NULL;
    _module_functions[431].params = &_module_params[465];
    _module_params[465].name = "p";
    _module_params[465].type = 8;
    _module_params[465].struct_type_name = "Parser";
    _module_params[465].element_type = 21;
    _module_params[465].fn_sig = NULL;

    /* Function: parser_store_if */
    _module_functions[432].name = "parser_store_if";
    _module_functions[432].param_count = 7;
    _module_functions[432].return_type = 8;
    _module_functions[432].return_struct_type_name = "Parser";
    _module_functions[432].return_fn_sig = NULL;
    _module_functions[432].return_type_info = NULL;
    _module_functions[432].body = NULL;
    _module_functions[432].shadow_test = NULL;
    _module_functions[432].is_extern = false;
    _module_functions[432].returns_gc_managed = false;
    _module_functions[432].requires_manual_free = false;
    _module_functions[432].returns_borrowed = false;
    _module_functions[432].cleanup_function = NULL;
    _module_functions[432].params = &_module_params[466];
    _module_params[466].name = "p";
    _module_params[466].type = 8;
    _module_params[466].struct_type_name = "Parser";
    _module_params[466].element_type = 21;
    _module_params[466].fn_sig = NULL;
    _module_params[467].name = "condition_id";
    _module_params[467].type = 0;
    _module_params[467].struct_type_name = NULL;
    _module_params[467].element_type = 21;
    _module_params[467].fn_sig = NULL;
    _module_params[468].name = "condition_type";
    _module_params[468].type = 0;
    _module_params[468].struct_type_name = NULL;
    _module_params[468].element_type = 21;
    _module_params[468].fn_sig = NULL;
    _module_params[469].name = "then_body_id";
    _module_params[469].type = 0;
    _module_params[469].struct_type_name = NULL;
    _module_params[469].element_type = 21;
    _module_params[469].fn_sig = NULL;
    _module_params[470].name = "else_body_id";
    _module_params[470].type = 0;
    _module_params[470].struct_type_name = NULL;
    _module_params[470].element_type = 21;
    _module_params[470].fn_sig = NULL;
    _module_params[471].name = "line";
    _module_params[471].type = 0;
    _module_params[471].struct_type_name = NULL;
    _module_params[471].element_type = 21;
    _module_params[471].fn_sig = NULL;
    _module_params[472].name = "column";
    _module_params[472].type = 0;
    _module_params[472].struct_type_name = NULL;
    _module_params[472].element_type = 21;
    _module_params[472].fn_sig = NULL;

    /* Function: parser_store_while */
    _module_functions[433].name = "parser_store_while";
    _module_functions[433].param_count = 6;
    _module_functions[433].return_type = 8;
    _module_functions[433].return_struct_type_name = "Parser";
    _module_functions[433].return_fn_sig = NULL;
    _module_functions[433].return_type_info = NULL;
    _module_functions[433].body = NULL;
    _module_functions[433].shadow_test = NULL;
    _module_functions[433].is_extern = false;
    _module_functions[433].returns_gc_managed = false;
    _module_functions[433].requires_manual_free = false;
    _module_functions[433].returns_borrowed = false;
    _module_functions[433].cleanup_function = NULL;
    _module_functions[433].params = &_module_params[473];
    _module_params[473].name = "p";
    _module_params[473].type = 8;
    _module_params[473].struct_type_name = "Parser";
    _module_params[473].element_type = 21;
    _module_params[473].fn_sig = NULL;
    _module_params[474].name = "condition_id";
    _module_params[474].type = 0;
    _module_params[474].struct_type_name = NULL;
    _module_params[474].element_type = 21;
    _module_params[474].fn_sig = NULL;
    _module_params[475].name = "condition_type";
    _module_params[475].type = 0;
    _module_params[475].struct_type_name = NULL;
    _module_params[475].element_type = 21;
    _module_params[475].fn_sig = NULL;
    _module_params[476].name = "body_id";
    _module_params[476].type = 0;
    _module_params[476].struct_type_name = NULL;
    _module_params[476].element_type = 21;
    _module_params[476].fn_sig = NULL;
    _module_params[477].name = "line";
    _module_params[477].type = 0;
    _module_params[477].struct_type_name = NULL;
    _module_params[477].element_type = 21;
    _module_params[477].fn_sig = NULL;
    _module_params[478].name = "column";
    _module_params[478].type = 0;
    _module_params[478].struct_type_name = NULL;
    _module_params[478].element_type = 21;
    _module_params[478].fn_sig = NULL;

    /* Function: parser_store_for */
    _module_functions[434].name = "parser_store_for";
    _module_functions[434].param_count = 7;
    _module_functions[434].return_type = 8;
    _module_functions[434].return_struct_type_name = "Parser";
    _module_functions[434].return_fn_sig = NULL;
    _module_functions[434].return_type_info = NULL;
    _module_functions[434].body = NULL;
    _module_functions[434].shadow_test = NULL;
    _module_functions[434].is_extern = false;
    _module_functions[434].returns_gc_managed = false;
    _module_functions[434].requires_manual_free = false;
    _module_functions[434].returns_borrowed = false;
    _module_functions[434].cleanup_function = NULL;
    _module_functions[434].params = &_module_params[479];
    _module_params[479].name = "p";
    _module_params[479].type = 8;
    _module_params[479].struct_type_name = "Parser";
    _module_params[479].element_type = 21;
    _module_params[479].fn_sig = NULL;
    _module_params[480].name = "var_name";
    _module_params[480].type = 4;
    _module_params[480].struct_type_name = NULL;
    _module_params[480].element_type = 21;
    _module_params[480].fn_sig = NULL;
    _module_params[481].name = "iterable_id";
    _module_params[481].type = 0;
    _module_params[481].struct_type_name = NULL;
    _module_params[481].element_type = 21;
    _module_params[481].fn_sig = NULL;
    _module_params[482].name = "iterable_type";
    _module_params[482].type = 0;
    _module_params[482].struct_type_name = NULL;
    _module_params[482].element_type = 21;
    _module_params[482].fn_sig = NULL;
    _module_params[483].name = "body_id";
    _module_params[483].type = 0;
    _module_params[483].struct_type_name = NULL;
    _module_params[483].element_type = 21;
    _module_params[483].fn_sig = NULL;
    _module_params[484].name = "line";
    _module_params[484].type = 0;
    _module_params[484].struct_type_name = NULL;
    _module_params[484].element_type = 21;
    _module_params[484].fn_sig = NULL;
    _module_params[485].name = "column";
    _module_params[485].type = 0;
    _module_params[485].struct_type_name = NULL;
    _module_params[485].element_type = 21;
    _module_params[485].fn_sig = NULL;

    /* Function: parser_finish_array_literal */
    _module_functions[435].name = "parser_finish_array_literal";
    _module_functions[435].param_count = 5;
    _module_functions[435].return_type = 8;
    _module_functions[435].return_struct_type_name = "Parser";
    _module_functions[435].return_fn_sig = NULL;
    _module_functions[435].return_type_info = NULL;
    _module_functions[435].body = NULL;
    _module_functions[435].shadow_test = NULL;
    _module_functions[435].is_extern = false;
    _module_functions[435].returns_gc_managed = false;
    _module_functions[435].requires_manual_free = false;
    _module_functions[435].returns_borrowed = false;
    _module_functions[435].cleanup_function = NULL;
    _module_functions[435].params = &_module_params[486];
    _module_params[486].name = "p";
    _module_params[486].type = 8;
    _module_params[486].struct_type_name = "Parser";
    _module_params[486].element_type = 21;
    _module_params[486].fn_sig = NULL;
    _module_params[487].name = "ids";
    _module_params[487].type = 7;
    _module_params[487].struct_type_name = NULL;
    _module_params[487].element_type = 0;
    _module_params[487].fn_sig = NULL;
    _module_params[487].type_info = &_type_infos[3];
    _module_params[488].name = "types";
    _module_params[488].type = 7;
    _module_params[488].struct_type_name = NULL;
    _module_params[488].element_type = 0;
    _module_params[488].fn_sig = NULL;
    _module_params[488].type_info = &_type_infos[4];
    _module_params[489].name = "line";
    _module_params[489].type = 0;
    _module_params[489].struct_type_name = NULL;
    _module_params[489].element_type = 21;
    _module_params[489].fn_sig = NULL;
    _module_params[490].name = "column";
    _module_params[490].type = 0;
    _module_params[490].struct_type_name = NULL;
    _module_params[490].element_type = 21;
    _module_params[490].fn_sig = NULL;

    /* Function: parser_store_array_literal */
    _module_functions[436].name = "parser_store_array_literal";
    _module_functions[436].param_count = 6;
    _module_functions[436].return_type = 8;
    _module_functions[436].return_struct_type_name = "Parser";
    _module_functions[436].return_fn_sig = NULL;
    _module_functions[436].return_type_info = NULL;
    _module_functions[436].body = NULL;
    _module_functions[436].shadow_test = NULL;
    _module_functions[436].is_extern = false;
    _module_functions[436].returns_gc_managed = false;
    _module_functions[436].requires_manual_free = false;
    _module_functions[436].returns_borrowed = false;
    _module_functions[436].cleanup_function = NULL;
    _module_functions[436].params = &_module_params[491];
    _module_params[491].name = "p";
    _module_params[491].type = 8;
    _module_params[491].struct_type_name = "Parser";
    _module_params[491].element_type = 21;
    _module_params[491].fn_sig = NULL;
    _module_params[492].name = "element_start";
    _module_params[492].type = 0;
    _module_params[492].struct_type_name = NULL;
    _module_params[492].element_type = 21;
    _module_params[492].fn_sig = NULL;
    _module_params[493].name = "element_count";
    _module_params[493].type = 0;
    _module_params[493].struct_type_name = NULL;
    _module_params[493].element_type = 21;
    _module_params[493].fn_sig = NULL;
    _module_params[494].name = "element_type";
    _module_params[494].type = 4;
    _module_params[494].struct_type_name = NULL;
    _module_params[494].element_type = 21;
    _module_params[494].fn_sig = NULL;
    _module_params[495].name = "line";
    _module_params[495].type = 0;
    _module_params[495].struct_type_name = NULL;
    _module_params[495].element_type = 21;
    _module_params[495].fn_sig = NULL;
    _module_params[496].name = "column";
    _module_params[496].type = 0;
    _module_params[496].struct_type_name = NULL;
    _module_params[496].element_type = 21;
    _module_params[496].fn_sig = NULL;

    /* Function: parser_is_value_expression */
    _module_functions[437].name = "parser_is_value_expression";
    _module_functions[437].param_count = 1;
    _module_functions[437].return_type = 3;
    _module_functions[437].return_struct_type_name = NULL;
    _module_functions[437].return_fn_sig = NULL;
    _module_functions[437].return_type_info = NULL;
    _module_functions[437].body = NULL;
    _module_functions[437].shadow_test = NULL;
    _module_functions[437].is_extern = false;
    _module_functions[437].returns_gc_managed = false;
    _module_functions[437].requires_manual_free = false;
    _module_functions[437].returns_borrowed = false;
    _module_functions[437].cleanup_function = NULL;
    _module_functions[437].params = &_module_params[497];
    _module_params[497].name = "node_type";
    _module_params[497].type = 0;
    _module_params[497].struct_type_name = NULL;
    _module_params[497].element_type = 21;
    _module_params[497].fn_sig = NULL;

    /* Function: parser_always_returns */
    _module_functions[438].name = "parser_always_returns";
    _module_functions[438].param_count = 3;
    _module_functions[438].return_type = 3;
    _module_functions[438].return_struct_type_name = NULL;
    _module_functions[438].return_fn_sig = NULL;
    _module_functions[438].return_type_info = NULL;
    _module_functions[438].body = NULL;
    _module_functions[438].shadow_test = NULL;
    _module_functions[438].is_extern = false;
    _module_functions[438].returns_gc_managed = false;
    _module_functions[438].requires_manual_free = false;
    _module_functions[438].returns_borrowed = false;
    _module_functions[438].cleanup_function = NULL;
    _module_functions[438].params = &_module_params[498];
    _module_params[498].name = "parser";
    _module_params[498].type = 8;
    _module_params[498].struct_type_name = "Parser";
    _module_params[498].element_type = 21;
    _module_params[498].fn_sig = NULL;
    _module_params[499].name = "node_id";
    _module_params[499].type = 0;
    _module_params[499].struct_type_name = NULL;
    _module_params[499].element_type = 21;
    _module_params[499].fn_sig = NULL;
    _module_params[500].name = "node_type";
    _module_params[500].type = 0;
    _module_params[500].struct_type_name = NULL;
    _module_params[500].element_type = 21;
    _module_params[500].fn_sig = NULL;

    /* Function: parser_decode_import_path */
    _module_functions[439].name = "parser_decode_import_path";
    _module_functions[439].param_count = 1;
    _module_functions[439].return_type = 4;
    _module_functions[439].return_struct_type_name = NULL;
    _module_functions[439].return_fn_sig = NULL;
    _module_functions[439].return_type_info = NULL;
    _module_functions[439].body = NULL;
    _module_functions[439].shadow_test = NULL;
    _module_functions[439].is_extern = false;
    _module_functions[439].returns_gc_managed = true;
    _module_functions[439].requires_manual_free = false;
    _module_functions[439].returns_borrowed = false;
    _module_functions[439].cleanup_function = NULL;
    _module_functions[439].params = &_module_params[501];
    _module_params[501].name = "raw";
    _module_params[501].type = 4;
    _module_params[501].struct_type_name = NULL;
    _module_params[501].element_type = 21;
    _module_params[501].fn_sig = NULL;

    /* Function: parser_store_import */
    _module_functions[440].name = "parser_store_import";
    _module_functions[440].param_count = 11;
    _module_functions[440].return_type = 8;
    _module_functions[440].return_struct_type_name = "Parser";
    _module_functions[440].return_fn_sig = NULL;
    _module_functions[440].return_type_info = NULL;
    _module_functions[440].body = NULL;
    _module_functions[440].shadow_test = NULL;
    _module_functions[440].is_extern = false;
    _module_functions[440].returns_gc_managed = false;
    _module_functions[440].requires_manual_free = false;
    _module_functions[440].returns_borrowed = false;
    _module_functions[440].cleanup_function = NULL;
    _module_functions[440].params = &_module_params[502];
    _module_params[502].name = "p";
    _module_params[502].type = 8;
    _module_params[502].struct_type_name = "Parser";
    _module_params[502].element_type = 21;
    _module_params[502].fn_sig = NULL;
    _module_params[503].name = "module_path";
    _module_params[503].type = 4;
    _module_params[503].struct_type_name = NULL;
    _module_params[503].element_type = 21;
    _module_params[503].fn_sig = NULL;
    _module_params[504].name = "module_name";
    _module_params[504].type = 4;
    _module_params[504].struct_type_name = NULL;
    _module_params[504].element_type = 21;
    _module_params[504].fn_sig = NULL;
    _module_params[505].name = "is_unsafe";
    _module_params[505].type = 3;
    _module_params[505].struct_type_name = NULL;
    _module_params[505].element_type = 21;
    _module_params[505].fn_sig = NULL;
    _module_params[506].name = "is_selective";
    _module_params[506].type = 3;
    _module_params[506].struct_type_name = NULL;
    _module_params[506].element_type = 21;
    _module_params[506].fn_sig = NULL;
    _module_params[507].name = "is_wildcard";
    _module_params[507].type = 3;
    _module_params[507].struct_type_name = NULL;
    _module_params[507].element_type = 21;
    _module_params[507].fn_sig = NULL;
    _module_params[508].name = "import_symbols";
    _module_params[508].type = 7;
    _module_params[508].struct_type_name = NULL;
    _module_params[508].element_type = 4;
    _module_params[508].fn_sig = NULL;
    _module_params[508].type_info = &_type_infos[5];
    _module_params[509].name = "import_aliases";
    _module_params[509].type = 7;
    _module_params[509].struct_type_name = NULL;
    _module_params[509].element_type = 4;
    _module_params[509].fn_sig = NULL;
    _module_params[509].type_info = &_type_infos[6];
    _module_params[510].name = "import_symbol_count";
    _module_params[510].type = 0;
    _module_params[510].struct_type_name = NULL;
    _module_params[510].element_type = 21;
    _module_params[510].fn_sig = NULL;
    _module_params[511].name = "line";
    _module_params[511].type = 0;
    _module_params[511].struct_type_name = NULL;
    _module_params[511].element_type = 21;
    _module_params[511].fn_sig = NULL;
    _module_params[512].name = "column";
    _module_params[512].type = 0;
    _module_params[512].struct_type_name = NULL;
    _module_params[512].element_type = 21;
    _module_params[512].fn_sig = NULL;

    /* Function: parser_store_service */
    _module_functions[441].name = "parser_store_service";
    _module_functions[441].param_count = 7;
    _module_functions[441].return_type = 8;
    _module_functions[441].return_struct_type_name = "Parser";
    _module_functions[441].return_fn_sig = NULL;
    _module_functions[441].return_type_info = NULL;
    _module_functions[441].body = NULL;
    _module_functions[441].shadow_test = NULL;
    _module_functions[441].is_extern = false;
    _module_functions[441].returns_gc_managed = false;
    _module_functions[441].requires_manual_free = false;
    _module_functions[441].returns_borrowed = false;
    _module_functions[441].cleanup_function = NULL;
    _module_functions[441].params = &_module_params[513];
    _module_params[513].name = "p";
    _module_params[513].type = 8;
    _module_params[513].struct_type_name = "Parser";
    _module_params[513].element_type = 21;
    _module_params[513].fn_sig = NULL;
    _module_params[514].name = "interface_id";
    _module_params[514].type = 4;
    _module_params[514].struct_type_name = NULL;
    _module_params[514].element_type = 21;
    _module_params[514].fn_sig = NULL;
    _module_params[515].name = "interface_bytes";
    _module_params[515].type = 0;
    _module_params[515].struct_type_name = NULL;
    _module_params[515].element_type = 21;
    _module_params[515].fn_sig = NULL;
    _module_params[516].name = "document_path";
    _module_params[516].type = 4;
    _module_params[516].struct_type_name = NULL;
    _module_params[516].element_type = 21;
    _module_params[516].fn_sig = NULL;
    _module_params[517].name = "path_bytes";
    _module_params[517].type = 0;
    _module_params[517].struct_type_name = NULL;
    _module_params[517].element_type = 21;
    _module_params[517].fn_sig = NULL;
    _module_params[518].name = "line";
    _module_params[518].type = 0;
    _module_params[518].struct_type_name = NULL;
    _module_params[518].element_type = 21;
    _module_params[518].fn_sig = NULL;
    _module_params[519].name = "column";
    _module_params[519].type = 0;
    _module_params[519].struct_type_name = NULL;
    _module_params[519].element_type = 21;
    _module_params[519].fn_sig = NULL;

    /* Function: parser_store_opaque_type */
    _module_functions[442].name = "parser_store_opaque_type";
    _module_functions[442].param_count = 4;
    _module_functions[442].return_type = 8;
    _module_functions[442].return_struct_type_name = "Parser";
    _module_functions[442].return_fn_sig = NULL;
    _module_functions[442].return_type_info = NULL;
    _module_functions[442].body = NULL;
    _module_functions[442].shadow_test = NULL;
    _module_functions[442].is_extern = false;
    _module_functions[442].returns_gc_managed = false;
    _module_functions[442].requires_manual_free = false;
    _module_functions[442].returns_borrowed = false;
    _module_functions[442].cleanup_function = NULL;
    _module_functions[442].params = &_module_params[520];
    _module_params[520].name = "p";
    _module_params[520].type = 8;
    _module_params[520].struct_type_name = "Parser";
    _module_params[520].element_type = 21;
    _module_params[520].fn_sig = NULL;
    _module_params[521].name = "type_name";
    _module_params[521].type = 4;
    _module_params[521].struct_type_name = NULL;
    _module_params[521].element_type = 21;
    _module_params[521].fn_sig = NULL;
    _module_params[522].name = "line";
    _module_params[522].type = 0;
    _module_params[522].struct_type_name = NULL;
    _module_params[522].element_type = 21;
    _module_params[522].fn_sig = NULL;
    _module_params[523].name = "column";
    _module_params[523].type = 0;
    _module_params[523].struct_type_name = NULL;
    _module_params[523].element_type = 21;
    _module_params[523].fn_sig = NULL;

    /* Function: parser_store_shadow */
    _module_functions[443].name = "parser_store_shadow";
    _module_functions[443].param_count = 5;
    _module_functions[443].return_type = 8;
    _module_functions[443].return_struct_type_name = "Parser";
    _module_functions[443].return_fn_sig = NULL;
    _module_functions[443].return_type_info = NULL;
    _module_functions[443].body = NULL;
    _module_functions[443].shadow_test = NULL;
    _module_functions[443].is_extern = false;
    _module_functions[443].returns_gc_managed = false;
    _module_functions[443].requires_manual_free = false;
    _module_functions[443].returns_borrowed = false;
    _module_functions[443].cleanup_function = NULL;
    _module_functions[443].params = &_module_params[524];
    _module_params[524].name = "p";
    _module_params[524].type = 8;
    _module_params[524].struct_type_name = "Parser";
    _module_params[524].element_type = 21;
    _module_params[524].fn_sig = NULL;
    _module_params[525].name = "target_name";
    _module_params[525].type = 4;
    _module_params[525].struct_type_name = NULL;
    _module_params[525].element_type = 21;
    _module_params[525].fn_sig = NULL;
    _module_params[526].name = "body_id";
    _module_params[526].type = 0;
    _module_params[526].struct_type_name = NULL;
    _module_params[526].element_type = 21;
    _module_params[526].fn_sig = NULL;
    _module_params[527].name = "line";
    _module_params[527].type = 0;
    _module_params[527].struct_type_name = NULL;
    _module_params[527].element_type = 21;
    _module_params[527].fn_sig = NULL;
    _module_params[528].name = "column";
    _module_params[528].type = 0;
    _module_params[528].struct_type_name = NULL;
    _module_params[528].element_type = 21;
    _module_params[528].fn_sig = NULL;

    /* Function: parser_store_field_access */
    _module_functions[444].name = "parser_store_field_access";
    _module_functions[444].param_count = 6;
    _module_functions[444].return_type = 8;
    _module_functions[444].return_struct_type_name = "Parser";
    _module_functions[444].return_fn_sig = NULL;
    _module_functions[444].return_type_info = NULL;
    _module_functions[444].body = NULL;
    _module_functions[444].shadow_test = NULL;
    _module_functions[444].is_extern = false;
    _module_functions[444].returns_gc_managed = false;
    _module_functions[444].requires_manual_free = false;
    _module_functions[444].returns_borrowed = false;
    _module_functions[444].cleanup_function = NULL;
    _module_functions[444].params = &_module_params[529];
    _module_params[529].name = "p";
    _module_params[529].type = 8;
    _module_params[529].struct_type_name = "Parser";
    _module_params[529].element_type = 21;
    _module_params[529].fn_sig = NULL;
    _module_params[530].name = "object_id";
    _module_params[530].type = 0;
    _module_params[530].struct_type_name = NULL;
    _module_params[530].element_type = 21;
    _module_params[530].fn_sig = NULL;
    _module_params[531].name = "object_type";
    _module_params[531].type = 0;
    _module_params[531].struct_type_name = NULL;
    _module_params[531].element_type = 21;
    _module_params[531].fn_sig = NULL;
    _module_params[532].name = "field_name";
    _module_params[532].type = 4;
    _module_params[532].struct_type_name = NULL;
    _module_params[532].element_type = 21;
    _module_params[532].fn_sig = NULL;
    _module_params[533].name = "line";
    _module_params[533].type = 0;
    _module_params[533].struct_type_name = NULL;
    _module_params[533].element_type = 21;
    _module_params[533].fn_sig = NULL;
    _module_params[534].name = "column";
    _module_params[534].type = 0;
    _module_params[534].struct_type_name = NULL;
    _module_params[534].element_type = 21;
    _module_params[534].fn_sig = NULL;

    /* Function: parser_store_float */
    _module_functions[445].name = "parser_store_float";
    _module_functions[445].param_count = 4;
    _module_functions[445].return_type = 8;
    _module_functions[445].return_struct_type_name = "Parser";
    _module_functions[445].return_fn_sig = NULL;
    _module_functions[445].return_type_info = NULL;
    _module_functions[445].body = NULL;
    _module_functions[445].shadow_test = NULL;
    _module_functions[445].is_extern = false;
    _module_functions[445].returns_gc_managed = false;
    _module_functions[445].requires_manual_free = false;
    _module_functions[445].returns_borrowed = false;
    _module_functions[445].cleanup_function = NULL;
    _module_functions[445].params = &_module_params[535];
    _module_params[535].name = "p";
    _module_params[535].type = 8;
    _module_params[535].struct_type_name = "Parser";
    _module_params[535].element_type = 21;
    _module_params[535].fn_sig = NULL;
    _module_params[536].name = "value";
    _module_params[536].type = 4;
    _module_params[536].struct_type_name = NULL;
    _module_params[536].element_type = 21;
    _module_params[536].fn_sig = NULL;
    _module_params[537].name = "line";
    _module_params[537].type = 0;
    _module_params[537].struct_type_name = NULL;
    _module_params[537].element_type = 21;
    _module_params[537].fn_sig = NULL;
    _module_params[538].name = "column";
    _module_params[538].type = 0;
    _module_params[538].struct_type_name = NULL;
    _module_params[538].element_type = 21;
    _module_params[538].fn_sig = NULL;

    /* Function: parser_store_return */
    _module_functions[446].name = "parser_store_return";
    _module_functions[446].param_count = 5;
    _module_functions[446].return_type = 8;
    _module_functions[446].return_struct_type_name = "Parser";
    _module_functions[446].return_fn_sig = NULL;
    _module_functions[446].return_type_info = NULL;
    _module_functions[446].body = NULL;
    _module_functions[446].shadow_test = NULL;
    _module_functions[446].is_extern = false;
    _module_functions[446].returns_gc_managed = false;
    _module_functions[446].requires_manual_free = false;
    _module_functions[446].returns_borrowed = false;
    _module_functions[446].cleanup_function = NULL;
    _module_functions[446].params = &_module_params[539];
    _module_params[539].name = "p";
    _module_params[539].type = 8;
    _module_params[539].struct_type_name = "Parser";
    _module_params[539].element_type = 21;
    _module_params[539].fn_sig = NULL;
    _module_params[540].name = "value_id";
    _module_params[540].type = 0;
    _module_params[540].struct_type_name = NULL;
    _module_params[540].element_type = 21;
    _module_params[540].fn_sig = NULL;
    _module_params[541].name = "value_type";
    _module_params[541].type = 0;
    _module_params[541].struct_type_name = NULL;
    _module_params[541].element_type = 21;
    _module_params[541].fn_sig = NULL;
    _module_params[542].name = "line";
    _module_params[542].type = 0;
    _module_params[542].struct_type_name = NULL;
    _module_params[542].element_type = 21;
    _module_params[542].fn_sig = NULL;
    _module_params[543].name = "column";
    _module_params[543].type = 0;
    _module_params[543].struct_type_name = NULL;
    _module_params[543].element_type = 21;
    _module_params[543].fn_sig = NULL;

    /* Function: parser_store_assert */
    _module_functions[447].name = "parser_store_assert";
    _module_functions[447].param_count = 5;
    _module_functions[447].return_type = 8;
    _module_functions[447].return_struct_type_name = "Parser";
    _module_functions[447].return_fn_sig = NULL;
    _module_functions[447].return_type_info = NULL;
    _module_functions[447].body = NULL;
    _module_functions[447].shadow_test = NULL;
    _module_functions[447].is_extern = false;
    _module_functions[447].returns_gc_managed = false;
    _module_functions[447].requires_manual_free = false;
    _module_functions[447].returns_borrowed = false;
    _module_functions[447].cleanup_function = NULL;
    _module_functions[447].params = &_module_params[544];
    _module_params[544].name = "p";
    _module_params[544].type = 8;
    _module_params[544].struct_type_name = "Parser";
    _module_params[544].element_type = 21;
    _module_params[544].fn_sig = NULL;
    _module_params[545].name = "condition_id";
    _module_params[545].type = 0;
    _module_params[545].struct_type_name = NULL;
    _module_params[545].element_type = 21;
    _module_params[545].fn_sig = NULL;
    _module_params[546].name = "condition_type";
    _module_params[546].type = 0;
    _module_params[546].struct_type_name = NULL;
    _module_params[546].element_type = 21;
    _module_params[546].fn_sig = NULL;
    _module_params[547].name = "line";
    _module_params[547].type = 0;
    _module_params[547].struct_type_name = NULL;
    _module_params[547].element_type = 21;
    _module_params[547].fn_sig = NULL;
    _module_params[548].name = "column";
    _module_params[548].type = 0;
    _module_params[548].struct_type_name = NULL;
    _module_params[548].element_type = 21;
    _module_params[548].fn_sig = NULL;

    /* Function: parser_store_block */
    _module_functions[448].name = "parser_store_block";
    _module_functions[448].param_count = 4;
    _module_functions[448].return_type = 8;
    _module_functions[448].return_struct_type_name = "Parser";
    _module_functions[448].return_fn_sig = NULL;
    _module_functions[448].return_type_info = NULL;
    _module_functions[448].body = NULL;
    _module_functions[448].shadow_test = NULL;
    _module_functions[448].is_extern = false;
    _module_functions[448].returns_gc_managed = false;
    _module_functions[448].requires_manual_free = false;
    _module_functions[448].returns_borrowed = false;
    _module_functions[448].cleanup_function = NULL;
    _module_functions[448].params = &_module_params[549];
    _module_params[549].name = "p";
    _module_params[549].type = 8;
    _module_params[549].struct_type_name = "Parser";
    _module_params[549].element_type = 21;
    _module_params[549].fn_sig = NULL;
    _module_params[550].name = "stmts";
    _module_params[550].type = 15;
    _module_params[550].struct_type_name = "ASTStmtRef";
    _module_params[550].element_type = 21;
    _module_params[550].fn_sig = NULL;
    _module_params[551].name = "line";
    _module_params[551].type = 0;
    _module_params[551].struct_type_name = NULL;
    _module_params[551].element_type = 21;
    _module_params[551].fn_sig = NULL;
    _module_params[552].name = "column";
    _module_params[552].type = 0;
    _module_params[552].struct_type_name = NULL;
    _module_params[552].element_type = 21;
    _module_params[552].fn_sig = NULL;

    /* Function: parser_wrap_if_in_block */
    _module_functions[449].name = "parser_wrap_if_in_block";
    _module_functions[449].param_count = 4;
    _module_functions[449].return_type = 8;
    _module_functions[449].return_struct_type_name = "Parser";
    _module_functions[449].return_fn_sig = NULL;
    _module_functions[449].return_type_info = NULL;
    _module_functions[449].body = NULL;
    _module_functions[449].shadow_test = NULL;
    _module_functions[449].is_extern = false;
    _module_functions[449].returns_gc_managed = false;
    _module_functions[449].requires_manual_free = false;
    _module_functions[449].returns_borrowed = false;
    _module_functions[449].cleanup_function = NULL;
    _module_functions[449].params = &_module_params[553];
    _module_params[553].name = "p";
    _module_params[553].type = 8;
    _module_params[553].struct_type_name = "Parser";
    _module_params[553].element_type = 21;
    _module_params[553].fn_sig = NULL;
    _module_params[554].name = "if_id";
    _module_params[554].type = 0;
    _module_params[554].struct_type_name = NULL;
    _module_params[554].element_type = 21;
    _module_params[554].fn_sig = NULL;
    _module_params[555].name = "line";
    _module_params[555].type = 0;
    _module_params[555].struct_type_name = NULL;
    _module_params[555].element_type = 21;
    _module_params[555].fn_sig = NULL;
    _module_params[556].name = "column";
    _module_params[556].type = 0;
    _module_params[556].struct_type_name = NULL;
    _module_params[556].element_type = 21;
    _module_params[556].fn_sig = NULL;

    /* Function: expr_kind_to_pnode */
    _module_functions[450].name = "expr_kind_to_pnode";
    _module_functions[450].param_count = 1;
    _module_functions[450].return_type = 0;
    _module_functions[450].return_struct_type_name = NULL;
    _module_functions[450].return_fn_sig = NULL;
    _module_functions[450].return_type_info = NULL;
    _module_functions[450].body = NULL;
    _module_functions[450].shadow_test = NULL;
    _module_functions[450].is_extern = false;
    _module_functions[450].returns_gc_managed = false;
    _module_functions[450].requires_manual_free = false;
    _module_functions[450].returns_borrowed = false;
    _module_functions[450].cleanup_function = NULL;
    _module_functions[450].params = &_module_params[557];
    _module_params[557].name = "kind";
    _module_params[557].type = 0;
    _module_params[557].struct_type_name = NULL;
    _module_params[557].element_type = 21;
    _module_params[557].fn_sig = NULL;

    /* Function: parser_starts_owned_pattern */
    _module_functions[451].name = "parser_starts_owned_pattern";
    _module_functions[451].param_count = 1;
    _module_functions[451].return_type = 3;
    _module_functions[451].return_struct_type_name = NULL;
    _module_functions[451].return_fn_sig = NULL;
    _module_functions[451].return_type_info = NULL;
    _module_functions[451].body = NULL;
    _module_functions[451].shadow_test = NULL;
    _module_functions[451].is_extern = false;
    _module_functions[451].returns_gc_managed = false;
    _module_functions[451].requires_manual_free = false;
    _module_functions[451].returns_borrowed = false;
    _module_functions[451].cleanup_function = NULL;
    _module_functions[451].params = &_module_params[558];
    _module_params[558].name = "p";
    _module_params[558].type = 8;
    _module_params[558].struct_type_name = "Parser";
    _module_params[558].element_type = 21;
    _module_params[558].fn_sig = NULL;

    /* Function: parser_mark_owned */
    _module_functions[452].name = "parser_mark_owned";
    _module_functions[452].param_count = 5;
    _module_functions[452].return_type = 8;
    _module_functions[452].return_struct_type_name = "Parser";
    _module_functions[452].return_fn_sig = NULL;
    _module_functions[452].return_type_info = NULL;
    _module_functions[452].body = NULL;
    _module_functions[452].shadow_test = NULL;
    _module_functions[452].is_extern = false;
    _module_functions[452].returns_gc_managed = false;
    _module_functions[452].requires_manual_free = false;
    _module_functions[452].returns_borrowed = false;
    _module_functions[452].cleanup_function = NULL;
    _module_functions[452].params = &_module_params[559];
    _module_params[559].name = "p";
    _module_params[559].type = 8;
    _module_params[559].struct_type_name = "Parser";
    _module_params[559].element_type = 21;
    _module_params[559].fn_sig = NULL;
    _module_params[560].name = "idx";
    _module_params[560].type = 0;
    _module_params[560].struct_type_name = NULL;
    _module_params[560].element_type = 21;
    _module_params[560].fn_sig = NULL;
    _module_params[561].name = "whole";
    _module_params[561].type = 3;
    _module_params[561].struct_type_name = NULL;
    _module_params[561].element_type = 21;
    _module_params[561].fn_sig = NULL;
    _module_params[562].name = "projection";
    _module_params[562].type = 3;
    _module_params[562].struct_type_name = NULL;
    _module_params[562].element_type = 21;
    _module_params[562].fn_sig = NULL;
    _module_params[563].name = "names";
    _module_params[563].type = 7;
    _module_params[563].struct_type_name = NULL;
    _module_params[563].element_type = 4;
    _module_params[563].fn_sig = NULL;
    _module_params[563].type_info = &_type_infos[7];

    /* Function: parse_owned_pattern */
    _module_functions[453].name = "parse_owned_pattern";
    _module_functions[453].param_count = 2;
    _module_functions[453].return_type = 8;
    _module_functions[453].return_struct_type_name = "Parser";
    _module_functions[453].return_fn_sig = NULL;
    _module_functions[453].return_type_info = NULL;
    _module_functions[453].body = NULL;
    _module_functions[453].shadow_test = NULL;
    _module_functions[453].is_extern = false;
    _module_functions[453].returns_gc_managed = false;
    _module_functions[453].requires_manual_free = false;
    _module_functions[453].returns_borrowed = false;
    _module_functions[453].cleanup_function = NULL;
    _module_functions[453].params = &_module_params[564];
    _module_params[564].name = "p";
    _module_params[564].type = 8;
    _module_params[564].struct_type_name = "Parser";
    _module_params[564].element_type = 21;
    _module_params[564].fn_sig = NULL;
    _module_params[565].name = "stmts";
    _module_params[565].type = 15;
    _module_params[565].struct_type_name = "ASTStmtRef";
    _module_params[565].element_type = 21;
    _module_params[565].fn_sig = NULL;

    /* Function: parse_block_recursive */
    _module_functions[454].name = "parse_block_recursive";
    _module_functions[454].param_count = 4;
    _module_functions[454].return_type = 8;
    _module_functions[454].return_struct_type_name = "Parser";
    _module_functions[454].return_fn_sig = NULL;
    _module_functions[454].return_type_info = NULL;
    _module_functions[454].body = NULL;
    _module_functions[454].shadow_test = NULL;
    _module_functions[454].is_extern = false;
    _module_functions[454].returns_gc_managed = false;
    _module_functions[454].requires_manual_free = false;
    _module_functions[454].returns_borrowed = false;
    _module_functions[454].cleanup_function = NULL;
    _module_functions[454].params = &_module_params[566];
    _module_params[566].name = "p";
    _module_params[566].type = 8;
    _module_params[566].struct_type_name = "Parser";
    _module_params[566].element_type = 21;
    _module_params[566].fn_sig = NULL;
    _module_params[567].name = "stmts";
    _module_params[567].type = 15;
    _module_params[567].struct_type_name = "ASTStmtRef";
    _module_params[567].element_type = 21;
    _module_params[567].fn_sig = NULL;
    _module_params[568].name = "start_line";
    _module_params[568].type = 0;
    _module_params[568].struct_type_name = NULL;
    _module_params[568].element_type = 21;
    _module_params[568].fn_sig = NULL;
    _module_params[569].name = "start_column";
    _module_params[569].type = 0;
    _module_params[569].struct_type_name = NULL;
    _module_params[569].element_type = 21;
    _module_params[569].fn_sig = NULL;

    /* Function: parse_block */
    _module_functions[455].name = "parse_block";
    _module_functions[455].param_count = 1;
    _module_functions[455].return_type = 8;
    _module_functions[455].return_struct_type_name = "Parser";
    _module_functions[455].return_fn_sig = NULL;
    _module_functions[455].return_type_info = NULL;
    _module_functions[455].body = NULL;
    _module_functions[455].shadow_test = NULL;
    _module_functions[455].is_extern = false;
    _module_functions[455].returns_gc_managed = false;
    _module_functions[455].requires_manual_free = false;
    _module_functions[455].returns_borrowed = false;
    _module_functions[455].cleanup_function = NULL;
    _module_functions[455].params = &_module_params[570];
    _module_params[570].name = "p";
    _module_params[570].type = 8;
    _module_params[570].struct_type_name = "Parser";
    _module_params[570].element_type = 21;
    _module_params[570].fn_sig = NULL;

    /* Function: parser_store_unsafe_block */
    _module_functions[456].name = "parser_store_unsafe_block";
    _module_functions[456].param_count = 4;
    _module_functions[456].return_type = 8;
    _module_functions[456].return_struct_type_name = "Parser";
    _module_functions[456].return_fn_sig = NULL;
    _module_functions[456].return_type_info = NULL;
    _module_functions[456].body = NULL;
    _module_functions[456].shadow_test = NULL;
    _module_functions[456].is_extern = false;
    _module_functions[456].returns_gc_managed = false;
    _module_functions[456].requires_manual_free = false;
    _module_functions[456].returns_borrowed = false;
    _module_functions[456].cleanup_function = NULL;
    _module_functions[456].params = &_module_params[571];
    _module_params[571].name = "p";
    _module_params[571].type = 8;
    _module_params[571].struct_type_name = "Parser";
    _module_params[571].element_type = 21;
    _module_params[571].fn_sig = NULL;
    _module_params[572].name = "stmts";
    _module_params[572].type = 15;
    _module_params[572].struct_type_name = "ASTStmtRef";
    _module_params[572].element_type = 21;
    _module_params[572].fn_sig = NULL;
    _module_params[573].name = "line";
    _module_params[573].type = 0;
    _module_params[573].struct_type_name = NULL;
    _module_params[573].element_type = 21;
    _module_params[573].fn_sig = NULL;
    _module_params[574].name = "column";
    _module_params[574].type = 0;
    _module_params[574].struct_type_name = NULL;
    _module_params[574].element_type = 21;
    _module_params[574].fn_sig = NULL;

    /* Function: parse_unsafe_block_recursive */
    _module_functions[457].name = "parse_unsafe_block_recursive";
    _module_functions[457].param_count = 4;
    _module_functions[457].return_type = 8;
    _module_functions[457].return_struct_type_name = "Parser";
    _module_functions[457].return_fn_sig = NULL;
    _module_functions[457].return_type_info = NULL;
    _module_functions[457].body = NULL;
    _module_functions[457].shadow_test = NULL;
    _module_functions[457].is_extern = false;
    _module_functions[457].returns_gc_managed = false;
    _module_functions[457].requires_manual_free = false;
    _module_functions[457].returns_borrowed = false;
    _module_functions[457].cleanup_function = NULL;
    _module_functions[457].params = &_module_params[575];
    _module_params[575].name = "p";
    _module_params[575].type = 8;
    _module_params[575].struct_type_name = "Parser";
    _module_params[575].element_type = 21;
    _module_params[575].fn_sig = NULL;
    _module_params[576].name = "stmts";
    _module_params[576].type = 15;
    _module_params[576].struct_type_name = "ASTStmtRef";
    _module_params[576].element_type = 21;
    _module_params[576].fn_sig = NULL;
    _module_params[577].name = "start_line";
    _module_params[577].type = 0;
    _module_params[577].struct_type_name = NULL;
    _module_params[577].element_type = 21;
    _module_params[577].fn_sig = NULL;
    _module_params[578].name = "start_column";
    _module_params[578].type = 0;
    _module_params[578].struct_type_name = NULL;
    _module_params[578].element_type = 21;
    _module_params[578].fn_sig = NULL;

    /* Function: parse_unsafe_block */
    _module_functions[458].name = "parse_unsafe_block";
    _module_functions[458].param_count = 1;
    _module_functions[458].return_type = 8;
    _module_functions[458].return_struct_type_name = "Parser";
    _module_functions[458].return_fn_sig = NULL;
    _module_functions[458].return_type_info = NULL;
    _module_functions[458].body = NULL;
    _module_functions[458].shadow_test = NULL;
    _module_functions[458].is_extern = false;
    _module_functions[458].returns_gc_managed = false;
    _module_functions[458].requires_manual_free = false;
    _module_functions[458].returns_borrowed = false;
    _module_functions[458].cleanup_function = NULL;
    _module_functions[458].params = &_module_params[579];
    _module_params[579].name = "p";
    _module_params[579].type = 8;
    _module_params[579].struct_type_name = "Parser";
    _module_params[579].element_type = 21;
    _module_params[579].fn_sig = NULL;

    /* Function: parse_let_body */
    _module_functions[459].name = "parse_let_body";
    _module_functions[459].param_count = 4;
    _module_functions[459].return_type = 8;
    _module_functions[459].return_struct_type_name = "Parser";
    _module_functions[459].return_fn_sig = NULL;
    _module_functions[459].return_type_info = NULL;
    _module_functions[459].body = NULL;
    _module_functions[459].shadow_test = NULL;
    _module_functions[459].is_extern = false;
    _module_functions[459].returns_gc_managed = false;
    _module_functions[459].requires_manual_free = false;
    _module_functions[459].returns_borrowed = false;
    _module_functions[459].cleanup_function = NULL;
    _module_functions[459].params = &_module_params[580];
    _module_params[580].name = "p";
    _module_params[580].type = 8;
    _module_params[580].struct_type_name = "Parser";
    _module_params[580].element_type = 21;
    _module_params[580].fn_sig = NULL;
    _module_params[581].name = "is_mut";
    _module_params[581].type = 3;
    _module_params[581].struct_type_name = NULL;
    _module_params[581].element_type = 21;
    _module_params[581].fn_sig = NULL;
    _module_params[582].name = "start_line";
    _module_params[582].type = 0;
    _module_params[582].struct_type_name = NULL;
    _module_params[582].element_type = 21;
    _module_params[582].fn_sig = NULL;
    _module_params[583].name = "start_column";
    _module_params[583].type = 0;
    _module_params[583].struct_type_name = NULL;
    _module_params[583].element_type = 21;
    _module_params[583].fn_sig = NULL;

    /* Function: parse_tuple_destructure */
    _module_functions[460].name = "parse_tuple_destructure";
    _module_functions[460].param_count = 5;
    _module_functions[460].return_type = 8;
    _module_functions[460].return_struct_type_name = "Parser";
    _module_functions[460].return_fn_sig = NULL;
    _module_functions[460].return_type_info = NULL;
    _module_functions[460].body = NULL;
    _module_functions[460].shadow_test = NULL;
    _module_functions[460].is_extern = false;
    _module_functions[460].returns_gc_managed = false;
    _module_functions[460].requires_manual_free = false;
    _module_functions[460].returns_borrowed = false;
    _module_functions[460].cleanup_function = NULL;
    _module_functions[460].params = &_module_params[584];
    _module_params[584].name = "p";
    _module_params[584].type = 8;
    _module_params[584].struct_type_name = "Parser";
    _module_params[584].element_type = 21;
    _module_params[584].fn_sig = NULL;
    _module_params[585].name = "stmts";
    _module_params[585].type = 15;
    _module_params[585].struct_type_name = "ASTStmtRef";
    _module_params[585].element_type = 21;
    _module_params[585].fn_sig = NULL;
    _module_params[586].name = "is_mut";
    _module_params[586].type = 3;
    _module_params[586].struct_type_name = NULL;
    _module_params[586].element_type = 21;
    _module_params[586].fn_sig = NULL;
    _module_params[587].name = "line";
    _module_params[587].type = 0;
    _module_params[587].struct_type_name = NULL;
    _module_params[587].element_type = 21;
    _module_params[587].fn_sig = NULL;
    _module_params[588].name = "column";
    _module_params[588].type = 0;
    _module_params[588].struct_type_name = NULL;
    _module_params[588].element_type = 21;
    _module_params[588].fn_sig = NULL;

    /* Function: parse_let_statement */
    _module_functions[461].name = "parse_let_statement";
    _module_functions[461].param_count = 1;
    _module_functions[461].return_type = 8;
    _module_functions[461].return_struct_type_name = "Parser";
    _module_functions[461].return_fn_sig = NULL;
    _module_functions[461].return_type_info = NULL;
    _module_functions[461].body = NULL;
    _module_functions[461].shadow_test = NULL;
    _module_functions[461].is_extern = false;
    _module_functions[461].returns_gc_managed = false;
    _module_functions[461].requires_manual_free = false;
    _module_functions[461].returns_borrowed = false;
    _module_functions[461].cleanup_function = NULL;
    _module_functions[461].params = &_module_params[589];
    _module_params[589].name = "p";
    _module_params[589].type = 8;
    _module_params[589].struct_type_name = "Parser";
    _module_params[589].element_type = 21;
    _module_params[589].fn_sig = NULL;

    /* Function: parse_block_expression */
    _module_functions[462].name = "parse_block_expression";
    _module_functions[462].param_count = 1;
    _module_functions[462].return_type = 8;
    _module_functions[462].return_struct_type_name = "Parser";
    _module_functions[462].return_fn_sig = NULL;
    _module_functions[462].return_type_info = NULL;
    _module_functions[462].body = NULL;
    _module_functions[462].shadow_test = NULL;
    _module_functions[462].is_extern = false;
    _module_functions[462].returns_gc_managed = false;
    _module_functions[462].requires_manual_free = false;
    _module_functions[462].returns_borrowed = false;
    _module_functions[462].cleanup_function = NULL;
    _module_functions[462].params = &_module_params[590];
    _module_params[590].name = "p";
    _module_params[590].type = 8;
    _module_params[590].struct_type_name = "Parser";
    _module_params[590].element_type = 21;
    _module_params[590].fn_sig = NULL;

    /* Function: parse_if_expression */
    _module_functions[463].name = "parse_if_expression";
    _module_functions[463].param_count = 1;
    _module_functions[463].return_type = 8;
    _module_functions[463].return_struct_type_name = "Parser";
    _module_functions[463].return_fn_sig = NULL;
    _module_functions[463].return_type_info = NULL;
    _module_functions[463].body = NULL;
    _module_functions[463].shadow_test = NULL;
    _module_functions[463].is_extern = false;
    _module_functions[463].returns_gc_managed = false;
    _module_functions[463].requires_manual_free = false;
    _module_functions[463].returns_borrowed = false;
    _module_functions[463].cleanup_function = NULL;
    _module_functions[463].params = &_module_params[591];
    _module_params[591].name = "p";
    _module_params[591].type = 8;
    _module_params[591].struct_type_name = "Parser";
    _module_params[591].element_type = 21;
    _module_params[591].fn_sig = NULL;

    /* Function: parse_if_statement */
    _module_functions[464].name = "parse_if_statement";
    _module_functions[464].param_count = 1;
    _module_functions[464].return_type = 8;
    _module_functions[464].return_struct_type_name = "Parser";
    _module_functions[464].return_fn_sig = NULL;
    _module_functions[464].return_type_info = NULL;
    _module_functions[464].body = NULL;
    _module_functions[464].shadow_test = NULL;
    _module_functions[464].is_extern = false;
    _module_functions[464].returns_gc_managed = false;
    _module_functions[464].requires_manual_free = false;
    _module_functions[464].returns_borrowed = false;
    _module_functions[464].cleanup_function = NULL;
    _module_functions[464].params = &_module_params[592];
    _module_params[592].name = "p";
    _module_params[592].type = 8;
    _module_params[592].struct_type_name = "Parser";
    _module_params[592].element_type = 21;
    _module_params[592].fn_sig = NULL;

    /* Function: parse_while_statement */
    _module_functions[465].name = "parse_while_statement";
    _module_functions[465].param_count = 1;
    _module_functions[465].return_type = 8;
    _module_functions[465].return_struct_type_name = "Parser";
    _module_functions[465].return_fn_sig = NULL;
    _module_functions[465].return_type_info = NULL;
    _module_functions[465].body = NULL;
    _module_functions[465].shadow_test = NULL;
    _module_functions[465].is_extern = false;
    _module_functions[465].returns_gc_managed = false;
    _module_functions[465].requires_manual_free = false;
    _module_functions[465].returns_borrowed = false;
    _module_functions[465].cleanup_function = NULL;
    _module_functions[465].params = &_module_params[593];
    _module_params[593].name = "p";
    _module_params[593].type = 8;
    _module_params[593].struct_type_name = "Parser";
    _module_params[593].element_type = 21;
    _module_params[593].fn_sig = NULL;

    /* Function: parse_return_statement */
    _module_functions[466].name = "parse_return_statement";
    _module_functions[466].param_count = 1;
    _module_functions[466].return_type = 8;
    _module_functions[466].return_struct_type_name = "Parser";
    _module_functions[466].return_fn_sig = NULL;
    _module_functions[466].return_type_info = NULL;
    _module_functions[466].body = NULL;
    _module_functions[466].shadow_test = NULL;
    _module_functions[466].is_extern = false;
    _module_functions[466].returns_gc_managed = false;
    _module_functions[466].requires_manual_free = false;
    _module_functions[466].returns_borrowed = false;
    _module_functions[466].cleanup_function = NULL;
    _module_functions[466].params = &_module_params[594];
    _module_params[594].name = "p";
    _module_params[594].type = 8;
    _module_params[594].struct_type_name = "Parser";
    _module_params[594].element_type = 21;
    _module_params[594].fn_sig = NULL;

    /* Function: parse_assert_statement */
    _module_functions[467].name = "parse_assert_statement";
    _module_functions[467].param_count = 1;
    _module_functions[467].return_type = 8;
    _module_functions[467].return_struct_type_name = "Parser";
    _module_functions[467].return_fn_sig = NULL;
    _module_functions[467].return_type_info = NULL;
    _module_functions[467].body = NULL;
    _module_functions[467].shadow_test = NULL;
    _module_functions[467].is_extern = false;
    _module_functions[467].returns_gc_managed = false;
    _module_functions[467].requires_manual_free = false;
    _module_functions[467].returns_borrowed = false;
    _module_functions[467].cleanup_function = NULL;
    _module_functions[467].params = &_module_params[595];
    _module_params[595].name = "p";
    _module_params[595].type = 8;
    _module_params[595].struct_type_name = "Parser";
    _module_params[595].element_type = 21;
    _module_params[595].fn_sig = NULL;

    /* Function: parse_for_statement */
    _module_functions[468].name = "parse_for_statement";
    _module_functions[468].param_count = 1;
    _module_functions[468].return_type = 8;
    _module_functions[468].return_struct_type_name = "Parser";
    _module_functions[468].return_fn_sig = NULL;
    _module_functions[468].return_type_info = NULL;
    _module_functions[468].body = NULL;
    _module_functions[468].shadow_test = NULL;
    _module_functions[468].is_extern = false;
    _module_functions[468].returns_gc_managed = false;
    _module_functions[468].requires_manual_free = false;
    _module_functions[468].returns_borrowed = false;
    _module_functions[468].cleanup_function = NULL;
    _module_functions[468].params = &_module_params[596];
    _module_params[596].name = "p";
    _module_params[596].type = 8;
    _module_params[596].struct_type_name = "Parser";
    _module_params[596].element_type = 21;
    _module_params[596].fn_sig = NULL;

    /* Function: parser_with_node */
    _module_functions[469].name = "parser_with_node";
    _module_functions[469].param_count = 3;
    _module_functions[469].return_type = 8;
    _module_functions[469].return_struct_type_name = "Parser";
    _module_functions[469].return_fn_sig = NULL;
    _module_functions[469].return_type_info = NULL;
    _module_functions[469].body = NULL;
    _module_functions[469].shadow_test = NULL;
    _module_functions[469].is_extern = false;
    _module_functions[469].returns_gc_managed = false;
    _module_functions[469].requires_manual_free = false;
    _module_functions[469].returns_borrowed = false;
    _module_functions[469].cleanup_function = NULL;
    _module_functions[469].params = &_module_params[597];
    _module_params[597].name = "p";
    _module_params[597].type = 8;
    _module_params[597].struct_type_name = "Parser";
    _module_params[597].element_type = 21;
    _module_params[597].fn_sig = NULL;
    _module_params[598].name = "kind";
    _module_params[598].type = 0;
    _module_params[598].struct_type_name = NULL;
    _module_params[598].element_type = 21;
    _module_params[598].fn_sig = NULL;
    _module_params[599].name = "node_id";
    _module_params[599].type = 0;
    _module_params[599].struct_type_name = NULL;
    _module_params[599].element_type = 21;
    _module_params[599].fn_sig = NULL;

    /* Function: parser_with_statement */
    _module_functions[470].name = "parser_with_statement";
    _module_functions[470].param_count = 2;
    _module_functions[470].return_type = 8;
    _module_functions[470].return_struct_type_name = "Parser";
    _module_functions[470].return_fn_sig = NULL;
    _module_functions[470].return_type_info = NULL;
    _module_functions[470].body = NULL;
    _module_functions[470].shadow_test = NULL;
    _module_functions[470].is_extern = false;
    _module_functions[470].returns_gc_managed = false;
    _module_functions[470].requires_manual_free = false;
    _module_functions[470].returns_borrowed = false;
    _module_functions[470].cleanup_function = NULL;
    _module_functions[470].params = &_module_params[600];
    _module_params[600].name = "p";
    _module_params[600].type = 8;
    _module_params[600].struct_type_name = "Parser";
    _module_params[600].element_type = 21;
    _module_params[600].fn_sig = NULL;
    _module_params[601].name = "kind";
    _module_params[601].type = 0;
    _module_params[601].struct_type_name = NULL;
    _module_params[601].element_type = 21;
    _module_params[601].fn_sig = NULL;

    /* Function: parser_mark_passive */
    _module_functions[471].name = "parser_mark_passive";
    _module_functions[471].param_count = 2;
    _module_functions[471].return_type = 8;
    _module_functions[471].return_struct_type_name = "Parser";
    _module_functions[471].return_fn_sig = NULL;
    _module_functions[471].return_type_info = NULL;
    _module_functions[471].body = NULL;
    _module_functions[471].shadow_test = NULL;
    _module_functions[471].is_extern = false;
    _module_functions[471].returns_gc_managed = false;
    _module_functions[471].requires_manual_free = false;
    _module_functions[471].returns_borrowed = false;
    _module_functions[471].cleanup_function = NULL;
    _module_functions[471].params = &_module_params[602];
    _module_params[602].name = "p";
    _module_params[602].type = 8;
    _module_params[602].struct_type_name = "Parser";
    _module_params[602].element_type = 21;
    _module_params[602].fn_sig = NULL;
    _module_params[603].name = "is_flow";
    _module_params[603].type = 3;
    _module_params[603].struct_type_name = NULL;
    _module_params[603].element_type = 21;
    _module_params[603].fn_sig = NULL;

    /* Function: parser_mark_par */
    _module_functions[472].name = "parser_mark_par";
    _module_functions[472].param_count = 1;
    _module_functions[472].return_type = 8;
    _module_functions[472].return_struct_type_name = "Parser";
    _module_functions[472].return_fn_sig = NULL;
    _module_functions[472].return_type_info = NULL;
    _module_functions[472].body = NULL;
    _module_functions[472].shadow_test = NULL;
    _module_functions[472].is_extern = false;
    _module_functions[472].returns_gc_managed = false;
    _module_functions[472].requires_manual_free = false;
    _module_functions[472].returns_borrowed = false;
    _module_functions[472].cleanup_function = NULL;
    _module_functions[472].params = &_module_params[604];
    _module_params[604].name = "p";
    _module_params[604].type = 8;
    _module_params[604].struct_type_name = "Parser";
    _module_params[604].element_type = 21;
    _module_params[604].fn_sig = NULL;

    /* Function: parse_statement */
    _module_functions[473].name = "parse_statement";
    _module_functions[473].param_count = 1;
    _module_functions[473].return_type = 8;
    _module_functions[473].return_struct_type_name = "Parser";
    _module_functions[473].return_fn_sig = NULL;
    _module_functions[473].return_type_info = NULL;
    _module_functions[473].body = NULL;
    _module_functions[473].shadow_test = NULL;
    _module_functions[473].is_extern = false;
    _module_functions[473].returns_gc_managed = false;
    _module_functions[473].requires_manual_free = false;
    _module_functions[473].returns_borrowed = false;
    _module_functions[473].cleanup_function = NULL;
    _module_functions[473].params = &_module_params[605];
    _module_params[605].name = "p";
    _module_params[605].type = 8;
    _module_params[605].struct_type_name = "Parser";
    _module_params[605].element_type = 21;
    _module_params[605].fn_sig = NULL;

    /* Function: parser_mark_pure */
    _module_functions[474].name = "parser_mark_pure";
    _module_functions[474].param_count = 1;
    _module_functions[474].return_type = 8;
    _module_functions[474].return_struct_type_name = "Parser";
    _module_functions[474].return_fn_sig = NULL;
    _module_functions[474].return_type_info = NULL;
    _module_functions[474].body = NULL;
    _module_functions[474].shadow_test = NULL;
    _module_functions[474].is_extern = false;
    _module_functions[474].returns_gc_managed = false;
    _module_functions[474].requires_manual_free = false;
    _module_functions[474].returns_borrowed = false;
    _module_functions[474].cleanup_function = NULL;
    _module_functions[474].params = &_module_params[606];
    _module_params[606].name = "p";
    _module_params[606].type = 8;
    _module_params[606].struct_type_name = "Parser";
    _module_params[606].element_type = 21;
    _module_params[606].fn_sig = NULL;

    /* Function: parser_store_function */
    _module_functions[475].name = "parser_store_function";
    _module_functions[475].param_count = 8;
    _module_functions[475].return_type = 8;
    _module_functions[475].return_struct_type_name = "Parser";
    _module_functions[475].return_fn_sig = NULL;
    _module_functions[475].return_type_info = NULL;
    _module_functions[475].body = NULL;
    _module_functions[475].shadow_test = NULL;
    _module_functions[475].is_extern = false;
    _module_functions[475].returns_gc_managed = false;
    _module_functions[475].requires_manual_free = false;
    _module_functions[475].returns_borrowed = false;
    _module_functions[475].cleanup_function = NULL;
    _module_functions[475].params = &_module_params[607];
    _module_params[607].name = "p";
    _module_params[607].type = 8;
    _module_params[607].struct_type_name = "Parser";
    _module_params[607].element_type = 21;
    _module_params[607].fn_sig = NULL;
    _module_params[608].name = "name";
    _module_params[608].type = 4;
    _module_params[608].struct_type_name = NULL;
    _module_params[608].element_type = 21;
    _module_params[608].fn_sig = NULL;
    _module_params[609].name = "param_start";
    _module_params[609].type = 0;
    _module_params[609].struct_type_name = NULL;
    _module_params[609].element_type = 21;
    _module_params[609].fn_sig = NULL;
    _module_params[610].name = "param_count";
    _module_params[610].type = 0;
    _module_params[610].struct_type_name = NULL;
    _module_params[610].element_type = 21;
    _module_params[610].fn_sig = NULL;
    _module_params[611].name = "return_type";
    _module_params[611].type = 4;
    _module_params[611].struct_type_name = NULL;
    _module_params[611].element_type = 21;
    _module_params[611].fn_sig = NULL;
    _module_params[612].name = "body_id";
    _module_params[612].type = 0;
    _module_params[612].struct_type_name = NULL;
    _module_params[612].element_type = 21;
    _module_params[612].fn_sig = NULL;
    _module_params[613].name = "line";
    _module_params[613].type = 0;
    _module_params[613].struct_type_name = NULL;
    _module_params[613].element_type = 21;
    _module_params[613].fn_sig = NULL;
    _module_params[614].name = "column";
    _module_params[614].type = 0;
    _module_params[614].struct_type_name = NULL;
    _module_params[614].element_type = 21;
    _module_params[614].fn_sig = NULL;

    /* Function: parser_store_struct */
    _module_functions[476].name = "parser_store_struct";
    _module_functions[476].param_count = 9;
    _module_functions[476].return_type = 8;
    _module_functions[476].return_struct_type_name = "Parser";
    _module_functions[476].return_fn_sig = NULL;
    _module_functions[476].return_type_info = NULL;
    _module_functions[476].body = NULL;
    _module_functions[476].shadow_test = NULL;
    _module_functions[476].is_extern = false;
    _module_functions[476].returns_gc_managed = false;
    _module_functions[476].requires_manual_free = false;
    _module_functions[476].returns_borrowed = false;
    _module_functions[476].cleanup_function = NULL;
    _module_functions[476].params = &_module_params[615];
    _module_params[615].name = "p";
    _module_params[615].type = 8;
    _module_params[615].struct_type_name = "Parser";
    _module_params[615].element_type = 21;
    _module_params[615].fn_sig = NULL;
    _module_params[616].name = "name";
    _module_params[616].type = 4;
    _module_params[616].struct_type_name = NULL;
    _module_params[616].element_type = 21;
    _module_params[616].fn_sig = NULL;
    _module_params[617].name = "field_count";
    _module_params[617].type = 0;
    _module_params[617].struct_type_name = NULL;
    _module_params[617].element_type = 21;
    _module_params[617].fn_sig = NULL;
    _module_params[618].name = "field_names";
    _module_params[618].type = 7;
    _module_params[618].struct_type_name = NULL;
    _module_params[618].element_type = 4;
    _module_params[618].fn_sig = NULL;
    _module_params[618].type_info = &_type_infos[8];
    _module_params[619].name = "field_types";
    _module_params[619].type = 7;
    _module_params[619].struct_type_name = NULL;
    _module_params[619].element_type = 4;
    _module_params[619].fn_sig = NULL;
    _module_params[619].type_info = &_type_infos[9];
    _module_params[620].name = "is_resource";
    _module_params[620].type = 3;
    _module_params[620].struct_type_name = NULL;
    _module_params[620].element_type = 21;
    _module_params[620].fn_sig = NULL;
    _module_params[621].name = "is_extern";
    _module_params[621].type = 3;
    _module_params[621].struct_type_name = NULL;
    _module_params[621].element_type = 21;
    _module_params[621].fn_sig = NULL;
    _module_params[622].name = "line";
    _module_params[622].type = 0;
    _module_params[622].struct_type_name = NULL;
    _module_params[622].element_type = 21;
    _module_params[622].fn_sig = NULL;
    _module_params[623].name = "column";
    _module_params[623].type = 0;
    _module_params[623].struct_type_name = NULL;
    _module_params[623].element_type = 21;
    _module_params[623].fn_sig = NULL;

    /* Function: parser_store_enum */
    _module_functions[477].name = "parser_store_enum";
    _module_functions[477].param_count = 7;
    _module_functions[477].return_type = 8;
    _module_functions[477].return_struct_type_name = "Parser";
    _module_functions[477].return_fn_sig = NULL;
    _module_functions[477].return_type_info = NULL;
    _module_functions[477].body = NULL;
    _module_functions[477].shadow_test = NULL;
    _module_functions[477].is_extern = false;
    _module_functions[477].returns_gc_managed = false;
    _module_functions[477].requires_manual_free = false;
    _module_functions[477].returns_borrowed = false;
    _module_functions[477].cleanup_function = NULL;
    _module_functions[477].params = &_module_params[624];
    _module_params[624].name = "p";
    _module_params[624].type = 8;
    _module_params[624].struct_type_name = "Parser";
    _module_params[624].element_type = 21;
    _module_params[624].fn_sig = NULL;
    _module_params[625].name = "name";
    _module_params[625].type = 4;
    _module_params[625].struct_type_name = NULL;
    _module_params[625].element_type = 21;
    _module_params[625].fn_sig = NULL;
    _module_params[626].name = "variant_count";
    _module_params[626].type = 0;
    _module_params[626].struct_type_name = NULL;
    _module_params[626].element_type = 21;
    _module_params[626].fn_sig = NULL;
    _module_params[627].name = "line";
    _module_params[627].type = 0;
    _module_params[627].struct_type_name = NULL;
    _module_params[627].element_type = 21;
    _module_params[627].fn_sig = NULL;
    _module_params[628].name = "column";
    _module_params[628].type = 0;
    _module_params[628].struct_type_name = NULL;
    _module_params[628].element_type = 21;
    _module_params[628].fn_sig = NULL;
    _module_params[629].name = "variant_names";
    _module_params[629].type = 7;
    _module_params[629].struct_type_name = NULL;
    _module_params[629].element_type = 4;
    _module_params[629].fn_sig = NULL;
    _module_params[629].type_info = &_type_infos[10];
    _module_params[630].name = "variant_values";
    _module_params[630].type = 7;
    _module_params[630].struct_type_name = NULL;
    _module_params[630].element_type = 0;
    _module_params[630].fn_sig = NULL;
    _module_params[630].type_info = &_type_infos[11];

    /* Function: parser_store_union */
    _module_functions[478].name = "parser_store_union";
    _module_functions[478].param_count = 11;
    _module_functions[478].return_type = 8;
    _module_functions[478].return_struct_type_name = "Parser";
    _module_functions[478].return_fn_sig = NULL;
    _module_functions[478].return_type_info = NULL;
    _module_functions[478].body = NULL;
    _module_functions[478].shadow_test = NULL;
    _module_functions[478].is_extern = false;
    _module_functions[478].returns_gc_managed = false;
    _module_functions[478].requires_manual_free = false;
    _module_functions[478].returns_borrowed = false;
    _module_functions[478].cleanup_function = NULL;
    _module_functions[478].params = &_module_params[631];
    _module_params[631].name = "p";
    _module_params[631].type = 8;
    _module_params[631].struct_type_name = "Parser";
    _module_params[631].element_type = 21;
    _module_params[631].fn_sig = NULL;
    _module_params[632].name = "name";
    _module_params[632].type = 4;
    _module_params[632].struct_type_name = NULL;
    _module_params[632].element_type = 21;
    _module_params[632].fn_sig = NULL;
    _module_params[633].name = "variant_count";
    _module_params[633].type = 0;
    _module_params[633].struct_type_name = NULL;
    _module_params[633].element_type = 21;
    _module_params[633].fn_sig = NULL;
    _module_params[634].name = "line";
    _module_params[634].type = 0;
    _module_params[634].struct_type_name = NULL;
    _module_params[634].element_type = 21;
    _module_params[634].fn_sig = NULL;
    _module_params[635].name = "column";
    _module_params[635].type = 0;
    _module_params[635].struct_type_name = NULL;
    _module_params[635].element_type = 21;
    _module_params[635].fn_sig = NULL;
    _module_params[636].name = "variant_names";
    _module_params[636].type = 7;
    _module_params[636].struct_type_name = NULL;
    _module_params[636].element_type = 4;
    _module_params[636].fn_sig = NULL;
    _module_params[636].type_info = &_type_infos[12];
    _module_params[637].name = "variant_field_counts";
    _module_params[637].type = 7;
    _module_params[637].struct_type_name = NULL;
    _module_params[637].element_type = 0;
    _module_params[637].fn_sig = NULL;
    _module_params[637].type_info = &_type_infos[13];
    _module_params[638].name = "variant_field_names";
    _module_params[638].type = 7;
    _module_params[638].struct_type_name = NULL;
    _module_params[638].element_type = 4;
    _module_params[638].fn_sig = NULL;
    _module_params[638].type_info = &_type_infos[14];
    _module_params[639].name = "variant_field_types";
    _module_params[639].type = 7;
    _module_params[639].struct_type_name = NULL;
    _module_params[639].element_type = 4;
    _module_params[639].fn_sig = NULL;
    _module_params[639].type_info = &_type_infos[15];
    _module_params[640].name = "generic_params";
    _module_params[640].type = 7;
    _module_params[640].struct_type_name = NULL;
    _module_params[640].element_type = 4;
    _module_params[640].fn_sig = NULL;
    _module_params[640].type_info = &_type_infos[16];
    _module_params[641].name = "generic_param_count";
    _module_params[641].type = 0;
    _module_params[641].struct_type_name = NULL;
    _module_params[641].element_type = 21;
    _module_params[641].fn_sig = NULL;

    /* Function: parser_store_union_construct */
    _module_functions[479].name = "parser_store_union_construct";
    _module_functions[479].param_count = 9;
    _module_functions[479].return_type = 8;
    _module_functions[479].return_struct_type_name = "Parser";
    _module_functions[479].return_fn_sig = NULL;
    _module_functions[479].return_type_info = NULL;
    _module_functions[479].body = NULL;
    _module_functions[479].shadow_test = NULL;
    _module_functions[479].is_extern = false;
    _module_functions[479].returns_gc_managed = false;
    _module_functions[479].requires_manual_free = false;
    _module_functions[479].returns_borrowed = false;
    _module_functions[479].cleanup_function = NULL;
    _module_functions[479].params = &_module_params[642];
    _module_params[642].name = "p";
    _module_params[642].type = 8;
    _module_params[642].struct_type_name = "Parser";
    _module_params[642].element_type = 21;
    _module_params[642].fn_sig = NULL;
    _module_params[643].name = "union_name";
    _module_params[643].type = 4;
    _module_params[643].struct_type_name = NULL;
    _module_params[643].element_type = 21;
    _module_params[643].fn_sig = NULL;
    _module_params[644].name = "variant_name";
    _module_params[644].type = 4;
    _module_params[644].struct_type_name = NULL;
    _module_params[644].element_type = 21;
    _module_params[644].fn_sig = NULL;
    _module_params[645].name = "field_names";
    _module_params[645].type = 7;
    _module_params[645].struct_type_name = NULL;
    _module_params[645].element_type = 4;
    _module_params[645].fn_sig = NULL;
    _module_params[645].type_info = &_type_infos[17];
    _module_params[646].name = "field_value_ids";
    _module_params[646].type = 7;
    _module_params[646].struct_type_name = NULL;
    _module_params[646].element_type = 0;
    _module_params[646].fn_sig = NULL;
    _module_params[646].type_info = &_type_infos[18];
    _module_params[647].name = "field_value_types";
    _module_params[647].type = 7;
    _module_params[647].struct_type_name = NULL;
    _module_params[647].element_type = 0;
    _module_params[647].fn_sig = NULL;
    _module_params[647].type_info = &_type_infos[19];
    _module_params[648].name = "field_count";
    _module_params[648].type = 0;
    _module_params[648].struct_type_name = NULL;
    _module_params[648].element_type = 21;
    _module_params[648].fn_sig = NULL;
    _module_params[649].name = "line";
    _module_params[649].type = 0;
    _module_params[649].struct_type_name = NULL;
    _module_params[649].element_type = 21;
    _module_params[649].fn_sig = NULL;
    _module_params[650].name = "column";
    _module_params[650].type = 0;
    _module_params[650].struct_type_name = NULL;
    _module_params[650].element_type = 21;
    _module_params[650].fn_sig = NULL;

    /* Function: parser_store_struct_literal */
    _module_functions[480].name = "parser_store_struct_literal";
    _module_functions[480].param_count = 8;
    _module_functions[480].return_type = 8;
    _module_functions[480].return_struct_type_name = "Parser";
    _module_functions[480].return_fn_sig = NULL;
    _module_functions[480].return_type_info = NULL;
    _module_functions[480].body = NULL;
    _module_functions[480].shadow_test = NULL;
    _module_functions[480].is_extern = false;
    _module_functions[480].returns_gc_managed = false;
    _module_functions[480].requires_manual_free = false;
    _module_functions[480].returns_borrowed = false;
    _module_functions[480].cleanup_function = NULL;
    _module_functions[480].params = &_module_params[651];
    _module_params[651].name = "p";
    _module_params[651].type = 8;
    _module_params[651].struct_type_name = "Parser";
    _module_params[651].element_type = 21;
    _module_params[651].fn_sig = NULL;
    _module_params[652].name = "type_name";
    _module_params[652].type = 4;
    _module_params[652].struct_type_name = NULL;
    _module_params[652].element_type = 21;
    _module_params[652].fn_sig = NULL;
    _module_params[653].name = "field_names";
    _module_params[653].type = 7;
    _module_params[653].struct_type_name = NULL;
    _module_params[653].element_type = 4;
    _module_params[653].fn_sig = NULL;
    _module_params[653].type_info = &_type_infos[20];
    _module_params[654].name = "field_value_ids";
    _module_params[654].type = 7;
    _module_params[654].struct_type_name = NULL;
    _module_params[654].element_type = 0;
    _module_params[654].fn_sig = NULL;
    _module_params[654].type_info = &_type_infos[21];
    _module_params[655].name = "field_value_types";
    _module_params[655].type = 7;
    _module_params[655].struct_type_name = NULL;
    _module_params[655].element_type = 0;
    _module_params[655].fn_sig = NULL;
    _module_params[655].type_info = &_type_infos[22];
    _module_params[656].name = "field_count";
    _module_params[656].type = 0;
    _module_params[656].struct_type_name = NULL;
    _module_params[656].element_type = 21;
    _module_params[656].fn_sig = NULL;
    _module_params[657].name = "line";
    _module_params[657].type = 0;
    _module_params[657].struct_type_name = NULL;
    _module_params[657].element_type = 21;
    _module_params[657].fn_sig = NULL;
    _module_params[658].name = "column";
    _module_params[658].type = 0;
    _module_params[658].struct_type_name = NULL;
    _module_params[658].element_type = 21;
    _module_params[658].fn_sig = NULL;

    /* Function: parser_store_match */
    _module_functions[481].name = "parser_store_match";
    _module_functions[481].param_count = 12;
    _module_functions[481].return_type = 8;
    _module_functions[481].return_struct_type_name = "Parser";
    _module_functions[481].return_fn_sig = NULL;
    _module_functions[481].return_type_info = NULL;
    _module_functions[481].body = NULL;
    _module_functions[481].shadow_test = NULL;
    _module_functions[481].is_extern = false;
    _module_functions[481].returns_gc_managed = false;
    _module_functions[481].requires_manual_free = false;
    _module_functions[481].returns_borrowed = false;
    _module_functions[481].cleanup_function = NULL;
    _module_functions[481].params = &_module_params[659];
    _module_params[659].name = "p";
    _module_params[659].type = 8;
    _module_params[659].struct_type_name = "Parser";
    _module_params[659].element_type = 21;
    _module_params[659].fn_sig = NULL;
    _module_params[660].name = "scrutinee_id";
    _module_params[660].type = 0;
    _module_params[660].struct_type_name = NULL;
    _module_params[660].element_type = 21;
    _module_params[660].fn_sig = NULL;
    _module_params[661].name = "scrutinee_type";
    _module_params[661].type = 0;
    _module_params[661].struct_type_name = NULL;
    _module_params[661].element_type = 21;
    _module_params[661].fn_sig = NULL;
    _module_params[662].name = "arm_variants";
    _module_params[662].type = 7;
    _module_params[662].struct_type_name = NULL;
    _module_params[662].element_type = 4;
    _module_params[662].fn_sig = NULL;
    _module_params[662].type_info = &_type_infos[23];
    _module_params[663].name = "arm_bindings";
    _module_params[663].type = 7;
    _module_params[663].struct_type_name = NULL;
    _module_params[663].element_type = 4;
    _module_params[663].fn_sig = NULL;
    _module_params[663].type_info = &_type_infos[24];
    _module_params[664].name = "arm_body_ids";
    _module_params[664].type = 7;
    _module_params[664].struct_type_name = NULL;
    _module_params[664].element_type = 0;
    _module_params[664].fn_sig = NULL;
    _module_params[664].type_info = &_type_infos[25];
    _module_params[665].name = "arm_body_types";
    _module_params[665].type = 7;
    _module_params[665].struct_type_name = NULL;
    _module_params[665].element_type = 0;
    _module_params[665].fn_sig = NULL;
    _module_params[665].type_info = &_type_infos[26];
    _module_params[666].name = "arm_guard_ids";
    _module_params[666].type = 7;
    _module_params[666].struct_type_name = NULL;
    _module_params[666].element_type = 0;
    _module_params[666].fn_sig = NULL;
    _module_params[666].type_info = &_type_infos[27];
    _module_params[667].name = "arm_guard_types";
    _module_params[667].type = 7;
    _module_params[667].struct_type_name = NULL;
    _module_params[667].element_type = 0;
    _module_params[667].fn_sig = NULL;
    _module_params[667].type_info = &_type_infos[28];
    _module_params[668].name = "arm_count";
    _module_params[668].type = 0;
    _module_params[668].struct_type_name = NULL;
    _module_params[668].element_type = 21;
    _module_params[668].fn_sig = NULL;
    _module_params[669].name = "line";
    _module_params[669].type = 0;
    _module_params[669].struct_type_name = NULL;
    _module_params[669].element_type = 21;
    _module_params[669].fn_sig = NULL;
    _module_params[670].name = "column";
    _module_params[670].type = 0;
    _module_params[670].struct_type_name = NULL;
    _module_params[670].element_type = 21;
    _module_params[670].fn_sig = NULL;

    /* Function: parser_store_tuple_literal */
    _module_functions[482].name = "parser_store_tuple_literal";
    _module_functions[482].param_count = 6;
    _module_functions[482].return_type = 8;
    _module_functions[482].return_struct_type_name = "Parser";
    _module_functions[482].return_fn_sig = NULL;
    _module_functions[482].return_type_info = NULL;
    _module_functions[482].body = NULL;
    _module_functions[482].shadow_test = NULL;
    _module_functions[482].is_extern = false;
    _module_functions[482].returns_gc_managed = false;
    _module_functions[482].requires_manual_free = false;
    _module_functions[482].returns_borrowed = false;
    _module_functions[482].cleanup_function = NULL;
    _module_functions[482].params = &_module_params[671];
    _module_params[671].name = "p";
    _module_params[671].type = 8;
    _module_params[671].struct_type_name = "Parser";
    _module_params[671].element_type = 21;
    _module_params[671].fn_sig = NULL;
    _module_params[672].name = "element_ids";
    _module_params[672].type = 7;
    _module_params[672].struct_type_name = NULL;
    _module_params[672].element_type = 0;
    _module_params[672].fn_sig = NULL;
    _module_params[672].type_info = &_type_infos[29];
    _module_params[673].name = "element_types";
    _module_params[673].type = 7;
    _module_params[673].struct_type_name = NULL;
    _module_params[673].element_type = 0;
    _module_params[673].fn_sig = NULL;
    _module_params[673].type_info = &_type_infos[30];
    _module_params[674].name = "element_count";
    _module_params[674].type = 0;
    _module_params[674].struct_type_name = NULL;
    _module_params[674].element_type = 21;
    _module_params[674].fn_sig = NULL;
    _module_params[675].name = "line";
    _module_params[675].type = 0;
    _module_params[675].struct_type_name = NULL;
    _module_params[675].element_type = 21;
    _module_params[675].fn_sig = NULL;
    _module_params[676].name = "column";
    _module_params[676].type = 0;
    _module_params[676].struct_type_name = NULL;
    _module_params[676].element_type = 21;
    _module_params[676].fn_sig = NULL;

    /* Function: parser_store_tuple_index */
    _module_functions[483].name = "parser_store_tuple_index";
    _module_functions[483].param_count = 6;
    _module_functions[483].return_type = 8;
    _module_functions[483].return_struct_type_name = "Parser";
    _module_functions[483].return_fn_sig = NULL;
    _module_functions[483].return_type_info = NULL;
    _module_functions[483].body = NULL;
    _module_functions[483].shadow_test = NULL;
    _module_functions[483].is_extern = false;
    _module_functions[483].returns_gc_managed = false;
    _module_functions[483].requires_manual_free = false;
    _module_functions[483].returns_borrowed = false;
    _module_functions[483].cleanup_function = NULL;
    _module_functions[483].params = &_module_params[677];
    _module_params[677].name = "p";
    _module_params[677].type = 8;
    _module_params[677].struct_type_name = "Parser";
    _module_params[677].element_type = 21;
    _module_params[677].fn_sig = NULL;
    _module_params[678].name = "tuple_id";
    _module_params[678].type = 0;
    _module_params[678].struct_type_name = NULL;
    _module_params[678].element_type = 21;
    _module_params[678].fn_sig = NULL;
    _module_params[679].name = "tuple_type";
    _module_params[679].type = 0;
    _module_params[679].struct_type_name = NULL;
    _module_params[679].element_type = 21;
    _module_params[679].fn_sig = NULL;
    _module_params[680].name = "index";
    _module_params[680].type = 0;
    _module_params[680].struct_type_name = NULL;
    _module_params[680].element_type = 21;
    _module_params[680].fn_sig = NULL;
    _module_params[681].name = "line";
    _module_params[681].type = 0;
    _module_params[681].struct_type_name = NULL;
    _module_params[681].element_type = 21;
    _module_params[681].fn_sig = NULL;
    _module_params[682].name = "column";
    _module_params[682].type = 0;
    _module_params[682].struct_type_name = NULL;
    _module_params[682].element_type = 21;
    _module_params[682].fn_sig = NULL;

    /* Function: parse_parameter_type */
    _module_functions[484].name = "parse_parameter_type";
    _module_functions[484].param_count = 1;
    _module_functions[484].return_type = 8;
    _module_functions[484].return_struct_type_name = "__nano_record_706172736572_TypeParseResult";
    _module_functions[484].return_fn_sig = NULL;
    _module_functions[484].return_type_info = NULL;
    _module_functions[484].body = NULL;
    _module_functions[484].shadow_test = NULL;
    _module_functions[484].is_extern = false;
    _module_functions[484].returns_gc_managed = false;
    _module_functions[484].requires_manual_free = false;
    _module_functions[484].returns_borrowed = false;
    _module_functions[484].cleanup_function = NULL;
    _module_functions[484].params = &_module_params[683];
    _module_params[683].name = "p";
    _module_params[683].type = 8;
    _module_params[683].struct_type_name = "Parser";
    _module_params[683].element_type = 21;
    _module_params[683].fn_sig = NULL;

    /* Function: parse_function_params */
    _module_functions[485].name = "parse_function_params";
    _module_functions[485].param_count = 2;
    _module_functions[485].return_type = 8;
    _module_functions[485].return_struct_type_name = "__nano_record_706172736572_ParamParseResult";
    _module_functions[485].return_fn_sig = NULL;
    _module_functions[485].return_type_info = NULL;
    _module_functions[485].body = NULL;
    _module_functions[485].shadow_test = NULL;
    _module_functions[485].is_extern = false;
    _module_functions[485].returns_gc_managed = false;
    _module_functions[485].requires_manual_free = false;
    _module_functions[485].returns_borrowed = false;
    _module_functions[485].cleanup_function = NULL;
    _module_functions[485].params = &_module_params[684];
    _module_params[684].name = "p";
    _module_params[684].type = 8;
    _module_params[684].struct_type_name = "Parser";
    _module_params[684].element_type = 21;
    _module_params[684].fn_sig = NULL;
    _module_params[685].name = "param_count";
    _module_params[685].type = 0;
    _module_params[685].struct_type_name = NULL;
    _module_params[685].element_type = 21;
    _module_params[685].fn_sig = NULL;

    /* Function: parse_extern_function_definition */
    _module_functions[486].name = "parse_extern_function_definition";
    _module_functions[486].param_count = 1;
    _module_functions[486].return_type = 8;
    _module_functions[486].return_struct_type_name = "Parser";
    _module_functions[486].return_fn_sig = NULL;
    _module_functions[486].return_type_info = NULL;
    _module_functions[486].body = NULL;
    _module_functions[486].shadow_test = NULL;
    _module_functions[486].is_extern = false;
    _module_functions[486].returns_gc_managed = false;
    _module_functions[486].requires_manual_free = false;
    _module_functions[486].returns_borrowed = false;
    _module_functions[486].cleanup_function = NULL;
    _module_functions[486].params = &_module_params[686];
    _module_params[686].name = "p";
    _module_params[686].type = 8;
    _module_params[686].struct_type_name = "Parser";
    _module_params[686].element_type = 21;
    _module_params[686].fn_sig = NULL;

    /* Function: parse_function_definition */
    _module_functions[487].name = "parse_function_definition";
    _module_functions[487].param_count = 1;
    _module_functions[487].return_type = 8;
    _module_functions[487].return_struct_type_name = "Parser";
    _module_functions[487].return_fn_sig = NULL;
    _module_functions[487].return_type_info = NULL;
    _module_functions[487].body = NULL;
    _module_functions[487].shadow_test = NULL;
    _module_functions[487].is_extern = false;
    _module_functions[487].returns_gc_managed = false;
    _module_functions[487].requires_manual_free = false;
    _module_functions[487].returns_borrowed = false;
    _module_functions[487].cleanup_function = NULL;
    _module_functions[487].params = &_module_params[687];
    _module_params[687].name = "p";
    _module_params[687].type = 8;
    _module_params[687].struct_type_name = "Parser";
    _module_params[687].element_type = 21;
    _module_params[687].fn_sig = NULL;

    /* Function: parse_struct_fields */
    _module_functions[488].name = "parse_struct_fields";
    _module_functions[488].param_count = 6;
    _module_functions[488].return_type = 8;
    _module_functions[488].return_struct_type_name = "Parser";
    _module_functions[488].return_fn_sig = NULL;
    _module_functions[488].return_type_info = NULL;
    _module_functions[488].body = NULL;
    _module_functions[488].shadow_test = NULL;
    _module_functions[488].is_extern = false;
    _module_functions[488].returns_gc_managed = false;
    _module_functions[488].requires_manual_free = false;
    _module_functions[488].returns_borrowed = false;
    _module_functions[488].cleanup_function = NULL;
    _module_functions[488].params = &_module_params[688];
    _module_params[688].name = "p";
    _module_params[688].type = 8;
    _module_params[688].struct_type_name = "Parser";
    _module_params[688].element_type = 21;
    _module_params[688].fn_sig = NULL;
    _module_params[689].name = "name";
    _module_params[689].type = 4;
    _module_params[689].struct_type_name = NULL;
    _module_params[689].element_type = 21;
    _module_params[689].fn_sig = NULL;
    _module_params[690].name = "is_resource";
    _module_params[690].type = 3;
    _module_params[690].struct_type_name = NULL;
    _module_params[690].element_type = 21;
    _module_params[690].fn_sig = NULL;
    _module_params[691].name = "is_extern";
    _module_params[691].type = 3;
    _module_params[691].struct_type_name = NULL;
    _module_params[691].element_type = 21;
    _module_params[691].fn_sig = NULL;
    _module_params[692].name = "start_line";
    _module_params[692].type = 0;
    _module_params[692].struct_type_name = NULL;
    _module_params[692].element_type = 21;
    _module_params[692].fn_sig = NULL;
    _module_params[693].name = "start_column";
    _module_params[693].type = 0;
    _module_params[693].struct_type_name = NULL;
    _module_params[693].element_type = 21;
    _module_params[693].fn_sig = NULL;

    /* Function: parse_struct_definition */
    _module_functions[489].name = "parse_struct_definition";
    _module_functions[489].param_count = 2;
    _module_functions[489].return_type = 8;
    _module_functions[489].return_struct_type_name = "Parser";
    _module_functions[489].return_fn_sig = NULL;
    _module_functions[489].return_type_info = NULL;
    _module_functions[489].body = NULL;
    _module_functions[489].shadow_test = NULL;
    _module_functions[489].is_extern = false;
    _module_functions[489].returns_gc_managed = false;
    _module_functions[489].requires_manual_free = false;
    _module_functions[489].returns_borrowed = false;
    _module_functions[489].cleanup_function = NULL;
    _module_functions[489].params = &_module_params[694];
    _module_params[694].name = "p";
    _module_params[694].type = 8;
    _module_params[694].struct_type_name = "Parser";
    _module_params[694].element_type = 21;
    _module_params[694].fn_sig = NULL;
    _module_params[695].name = "is_extern";
    _module_params[695].type = 3;
    _module_params[695].struct_type_name = NULL;
    _module_params[695].element_type = 21;
    _module_params[695].fn_sig = NULL;

    /* Function: parse_enum_variants */
    _module_functions[490].name = "parse_enum_variants";
    _module_functions[490].param_count = 8;
    _module_functions[490].return_type = 8;
    _module_functions[490].return_struct_type_name = "Parser";
    _module_functions[490].return_fn_sig = NULL;
    _module_functions[490].return_type_info = NULL;
    _module_functions[490].body = NULL;
    _module_functions[490].shadow_test = NULL;
    _module_functions[490].is_extern = false;
    _module_functions[490].returns_gc_managed = false;
    _module_functions[490].requires_manual_free = false;
    _module_functions[490].returns_borrowed = false;
    _module_functions[490].cleanup_function = NULL;
    _module_functions[490].params = &_module_params[696];
    _module_params[696].name = "p";
    _module_params[696].type = 8;
    _module_params[696].struct_type_name = "Parser";
    _module_params[696].element_type = 21;
    _module_params[696].fn_sig = NULL;
    _module_params[697].name = "variant_count";
    _module_params[697].type = 0;
    _module_params[697].struct_type_name = NULL;
    _module_params[697].element_type = 21;
    _module_params[697].fn_sig = NULL;
    _module_params[698].name = "name";
    _module_params[698].type = 4;
    _module_params[698].struct_type_name = NULL;
    _module_params[698].element_type = 21;
    _module_params[698].fn_sig = NULL;
    _module_params[699].name = "start_line";
    _module_params[699].type = 0;
    _module_params[699].struct_type_name = NULL;
    _module_params[699].element_type = 21;
    _module_params[699].fn_sig = NULL;
    _module_params[700].name = "start_column";
    _module_params[700].type = 0;
    _module_params[700].struct_type_name = NULL;
    _module_params[700].element_type = 21;
    _module_params[700].fn_sig = NULL;
    _module_params[701].name = "variant_names";
    _module_params[701].type = 7;
    _module_params[701].struct_type_name = NULL;
    _module_params[701].element_type = 4;
    _module_params[701].fn_sig = NULL;
    _module_params[701].type_info = &_type_infos[31];
    _module_params[702].name = "variant_values";
    _module_params[702].type = 7;
    _module_params[702].struct_type_name = NULL;
    _module_params[702].element_type = 0;
    _module_params[702].fn_sig = NULL;
    _module_params[702].type_info = &_type_infos[32];
    _module_params[703].name = "next_value";
    _module_params[703].type = 0;
    _module_params[703].struct_type_name = NULL;
    _module_params[703].element_type = 21;
    _module_params[703].fn_sig = NULL;

    /* Function: parse_enum_definition */
    _module_functions[491].name = "parse_enum_definition";
    _module_functions[491].param_count = 1;
    _module_functions[491].return_type = 8;
    _module_functions[491].return_struct_type_name = "Parser";
    _module_functions[491].return_fn_sig = NULL;
    _module_functions[491].return_type_info = NULL;
    _module_functions[491].body = NULL;
    _module_functions[491].shadow_test = NULL;
    _module_functions[491].is_extern = false;
    _module_functions[491].returns_gc_managed = false;
    _module_functions[491].requires_manual_free = false;
    _module_functions[491].returns_borrowed = false;
    _module_functions[491].cleanup_function = NULL;
    _module_functions[491].params = &_module_params[704];
    _module_params[704].name = "p";
    _module_params[704].type = 8;
    _module_params[704].struct_type_name = "Parser";
    _module_params[704].element_type = 21;
    _module_params[704].fn_sig = NULL;

    /* Function: parse_union_variants */
    _module_functions[492].name = "parse_union_variants";
    _module_functions[492].param_count = 11;
    _module_functions[492].return_type = 8;
    _module_functions[492].return_struct_type_name = "Parser";
    _module_functions[492].return_fn_sig = NULL;
    _module_functions[492].return_type_info = NULL;
    _module_functions[492].body = NULL;
    _module_functions[492].shadow_test = NULL;
    _module_functions[492].is_extern = false;
    _module_functions[492].returns_gc_managed = false;
    _module_functions[492].requires_manual_free = false;
    _module_functions[492].returns_borrowed = false;
    _module_functions[492].cleanup_function = NULL;
    _module_functions[492].params = &_module_params[705];
    _module_params[705].name = "p";
    _module_params[705].type = 8;
    _module_params[705].struct_type_name = "Parser";
    _module_params[705].element_type = 21;
    _module_params[705].fn_sig = NULL;
    _module_params[706].name = "variant_count";
    _module_params[706].type = 0;
    _module_params[706].struct_type_name = NULL;
    _module_params[706].element_type = 21;
    _module_params[706].fn_sig = NULL;
    _module_params[707].name = "name";
    _module_params[707].type = 4;
    _module_params[707].struct_type_name = NULL;
    _module_params[707].element_type = 21;
    _module_params[707].fn_sig = NULL;
    _module_params[708].name = "start_line";
    _module_params[708].type = 0;
    _module_params[708].struct_type_name = NULL;
    _module_params[708].element_type = 21;
    _module_params[708].fn_sig = NULL;
    _module_params[709].name = "start_column";
    _module_params[709].type = 0;
    _module_params[709].struct_type_name = NULL;
    _module_params[709].element_type = 21;
    _module_params[709].fn_sig = NULL;
    _module_params[710].name = "variant_names";
    _module_params[710].type = 7;
    _module_params[710].struct_type_name = NULL;
    _module_params[710].element_type = 4;
    _module_params[710].fn_sig = NULL;
    _module_params[710].type_info = &_type_infos[33];
    _module_params[711].name = "variant_field_counts";
    _module_params[711].type = 7;
    _module_params[711].struct_type_name = NULL;
    _module_params[711].element_type = 0;
    _module_params[711].fn_sig = NULL;
    _module_params[711].type_info = &_type_infos[34];
    _module_params[712].name = "variant_field_names";
    _module_params[712].type = 7;
    _module_params[712].struct_type_name = NULL;
    _module_params[712].element_type = 4;
    _module_params[712].fn_sig = NULL;
    _module_params[712].type_info = &_type_infos[35];
    _module_params[713].name = "variant_field_types";
    _module_params[713].type = 7;
    _module_params[713].struct_type_name = NULL;
    _module_params[713].element_type = 4;
    _module_params[713].fn_sig = NULL;
    _module_params[713].type_info = &_type_infos[36];
    _module_params[714].name = "generic_params";
    _module_params[714].type = 7;
    _module_params[714].struct_type_name = NULL;
    _module_params[714].element_type = 4;
    _module_params[714].fn_sig = NULL;
    _module_params[714].type_info = &_type_infos[37];
    _module_params[715].name = "generic_param_count";
    _module_params[715].type = 0;
    _module_params[715].struct_type_name = NULL;
    _module_params[715].element_type = 21;
    _module_params[715].fn_sig = NULL;

    /* Function: parse_union_definition */
    _module_functions[493].name = "parse_union_definition";
    _module_functions[493].param_count = 1;
    _module_functions[493].return_type = 8;
    _module_functions[493].return_struct_type_name = "Parser";
    _module_functions[493].return_fn_sig = NULL;
    _module_functions[493].return_type_info = NULL;
    _module_functions[493].body = NULL;
    _module_functions[493].shadow_test = NULL;
    _module_functions[493].is_extern = false;
    _module_functions[493].returns_gc_managed = false;
    _module_functions[493].requires_manual_free = false;
    _module_functions[493].returns_borrowed = false;
    _module_functions[493].cleanup_function = NULL;
    _module_functions[493].params = &_module_params[716];
    _module_params[716].name = "p";
    _module_params[716].type = 8;
    _module_params[716].struct_type_name = "Parser";
    _module_params[716].element_type = 21;
    _module_params[716].fn_sig = NULL;

    /* Function: parse_import */
    _module_functions[494].name = "parse_import";
    _module_functions[494].param_count = 1;
    _module_functions[494].return_type = 8;
    _module_functions[494].return_struct_type_name = "Parser";
    _module_functions[494].return_fn_sig = NULL;
    _module_functions[494].return_type_info = NULL;
    _module_functions[494].body = NULL;
    _module_functions[494].shadow_test = NULL;
    _module_functions[494].is_extern = false;
    _module_functions[494].returns_gc_managed = false;
    _module_functions[494].requires_manual_free = false;
    _module_functions[494].returns_borrowed = false;
    _module_functions[494].cleanup_function = NULL;
    _module_functions[494].params = &_module_params[717];
    _module_params[717].name = "p";
    _module_params[717].type = 8;
    _module_params[717].struct_type_name = "Parser";
    _module_params[717].element_type = 21;
    _module_params[717].fn_sig = NULL;

    /* Function: parse_pub_use */
    _module_functions[495].name = "parse_pub_use";
    _module_functions[495].param_count = 1;
    _module_functions[495].return_type = 8;
    _module_functions[495].return_struct_type_name = "Parser";
    _module_functions[495].return_fn_sig = NULL;
    _module_functions[495].return_type_info = NULL;
    _module_functions[495].body = NULL;
    _module_functions[495].shadow_test = NULL;
    _module_functions[495].is_extern = false;
    _module_functions[495].returns_gc_managed = false;
    _module_functions[495].requires_manual_free = false;
    _module_functions[495].returns_borrowed = false;
    _module_functions[495].cleanup_function = NULL;
    _module_functions[495].params = &_module_params[718];
    _module_params[718].name = "p";
    _module_params[718].type = 8;
    _module_params[718].struct_type_name = "Parser";
    _module_params[718].element_type = 21;
    _module_params[718].fn_sig = NULL;

    /* Function: parse_module_import */
    _module_functions[496].name = "parse_module_import";
    _module_functions[496].param_count = 2;
    _module_functions[496].return_type = 8;
    _module_functions[496].return_struct_type_name = "Parser";
    _module_functions[496].return_fn_sig = NULL;
    _module_functions[496].return_type_info = NULL;
    _module_functions[496].body = NULL;
    _module_functions[496].shadow_test = NULL;
    _module_functions[496].is_extern = false;
    _module_functions[496].returns_gc_managed = false;
    _module_functions[496].requires_manual_free = false;
    _module_functions[496].returns_borrowed = false;
    _module_functions[496].cleanup_function = NULL;
    _module_functions[496].params = &_module_params[719];
    _module_params[719].name = "p";
    _module_params[719].type = 8;
    _module_params[719].struct_type_name = "Parser";
    _module_params[719].element_type = 21;
    _module_params[719].fn_sig = NULL;
    _module_params[720].name = "is_unsafe";
    _module_params[720].type = 3;
    _module_params[720].struct_type_name = NULL;
    _module_params[720].element_type = 21;
    _module_params[720].fn_sig = NULL;

    /* Function: parse_from_import */
    _module_functions[497].name = "parse_from_import";
    _module_functions[497].param_count = 1;
    _module_functions[497].return_type = 8;
    _module_functions[497].return_struct_type_name = "Parser";
    _module_functions[497].return_fn_sig = NULL;
    _module_functions[497].return_type_info = NULL;
    _module_functions[497].body = NULL;
    _module_functions[497].shadow_test = NULL;
    _module_functions[497].is_extern = false;
    _module_functions[497].returns_gc_managed = false;
    _module_functions[497].requires_manual_free = false;
    _module_functions[497].returns_borrowed = false;
    _module_functions[497].cleanup_function = NULL;
    _module_functions[497].params = &_module_params[721];
    _module_params[721].name = "p";
    _module_params[721].type = 8;
    _module_params[721].struct_type_name = "Parser";
    _module_params[721].element_type = 21;
    _module_params[721].fn_sig = NULL;

    /* Function: parse_opaque_type */
    _module_functions[498].name = "parse_opaque_type";
    _module_functions[498].param_count = 1;
    _module_functions[498].return_type = 8;
    _module_functions[498].return_struct_type_name = "Parser";
    _module_functions[498].return_fn_sig = NULL;
    _module_functions[498].return_type_info = NULL;
    _module_functions[498].body = NULL;
    _module_functions[498].shadow_test = NULL;
    _module_functions[498].is_extern = false;
    _module_functions[498].returns_gc_managed = false;
    _module_functions[498].requires_manual_free = false;
    _module_functions[498].returns_borrowed = false;
    _module_functions[498].cleanup_function = NULL;
    _module_functions[498].params = &_module_params[722];
    _module_params[722].name = "p";
    _module_params[722].type = 8;
    _module_params[722].struct_type_name = "Parser";
    _module_params[722].element_type = 21;
    _module_params[722].fn_sig = NULL;

    /* Function: parse_shadow */
    _module_functions[499].name = "parse_shadow";
    _module_functions[499].param_count = 1;
    _module_functions[499].return_type = 8;
    _module_functions[499].return_struct_type_name = "Parser";
    _module_functions[499].return_fn_sig = NULL;
    _module_functions[499].return_type_info = NULL;
    _module_functions[499].body = NULL;
    _module_functions[499].shadow_test = NULL;
    _module_functions[499].is_extern = false;
    _module_functions[499].returns_gc_managed = false;
    _module_functions[499].requires_manual_free = false;
    _module_functions[499].returns_borrowed = false;
    _module_functions[499].cleanup_function = NULL;
    _module_functions[499].params = &_module_params[723];
    _module_params[723].name = "p";
    _module_params[723].type = 8;
    _module_params[723].struct_type_name = "Parser";
    _module_params[723].element_type = 21;
    _module_params[723].fn_sig = NULL;

    /* Function: parser_service_utf8 */
    _module_functions[500].name = "parser_service_utf8";
    _module_functions[500].param_count = 1;
    _module_functions[500].return_type = 3;
    _module_functions[500].return_struct_type_name = NULL;
    _module_functions[500].return_fn_sig = NULL;
    _module_functions[500].return_type_info = NULL;
    _module_functions[500].body = NULL;
    _module_functions[500].shadow_test = NULL;
    _module_functions[500].is_extern = false;
    _module_functions[500].returns_gc_managed = false;
    _module_functions[500].requires_manual_free = false;
    _module_functions[500].returns_borrowed = false;
    _module_functions[500].cleanup_function = NULL;
    _module_functions[500].params = &_module_params[724];
    _module_params[724].name = "text";
    _module_params[724].type = 4;
    _module_params[724].struct_type_name = NULL;
    _module_params[724].element_type = 21;
    _module_params[724].fn_sig = NULL;

    /* Function: parse_service_declaration */
    _module_functions[501].name = "parse_service_declaration";
    _module_functions[501].param_count = 1;
    _module_functions[501].return_type = 8;
    _module_functions[501].return_struct_type_name = "Parser";
    _module_functions[501].return_fn_sig = NULL;
    _module_functions[501].return_type_info = NULL;
    _module_functions[501].body = NULL;
    _module_functions[501].shadow_test = NULL;
    _module_functions[501].is_extern = false;
    _module_functions[501].returns_gc_managed = false;
    _module_functions[501].requires_manual_free = false;
    _module_functions[501].returns_borrowed = false;
    _module_functions[501].cleanup_function = NULL;
    _module_functions[501].params = &_module_params[725];
    _module_params[725].name = "p";
    _module_params[725].type = 8;
    _module_params[725].struct_type_name = "Parser";
    _module_params[725].element_type = 21;
    _module_params[725].fn_sig = NULL;

    /* Function: definition_parse_result */
    _module_functions[502].name = "definition_parse_result";
    _module_functions[502].param_count = 2;
    _module_functions[502].return_type = 8;
    _module_functions[502].return_struct_type_name = "__nano_record_706172736572_DefinitionParseResult";
    _module_functions[502].return_fn_sig = NULL;
    _module_functions[502].return_type_info = NULL;
    _module_functions[502].body = NULL;
    _module_functions[502].shadow_test = NULL;
    _module_functions[502].is_extern = false;
    _module_functions[502].returns_gc_managed = false;
    _module_functions[502].requires_manual_free = false;
    _module_functions[502].returns_borrowed = false;
    _module_functions[502].cleanup_function = NULL;
    _module_functions[502].params = &_module_params[726];
    _module_params[726].name = "p";
    _module_params[726].type = 8;
    _module_params[726].struct_type_name = "Parser";
    _module_params[726].element_type = 21;
    _module_params[726].fn_sig = NULL;
    _module_params[727].name = "function";
    _module_params[727].type = 3;
    _module_params[727].struct_type_name = NULL;
    _module_params[727].element_type = 21;
    _module_params[727].fn_sig = NULL;

    /* Function: parse_definition_result */
    _module_functions[503].name = "parse_definition_result";
    _module_functions[503].param_count = 1;
    _module_functions[503].return_type = 8;
    _module_functions[503].return_struct_type_name = "__nano_record_706172736572_DefinitionParseResult";
    _module_functions[503].return_fn_sig = NULL;
    _module_functions[503].return_type_info = NULL;
    _module_functions[503].body = NULL;
    _module_functions[503].shadow_test = NULL;
    _module_functions[503].is_extern = false;
    _module_functions[503].returns_gc_managed = false;
    _module_functions[503].requires_manual_free = false;
    _module_functions[503].returns_borrowed = false;
    _module_functions[503].cleanup_function = NULL;
    _module_functions[503].params = &_module_params[728];
    _module_params[728].name = "p";
    _module_params[728].type = 8;
    _module_params[728].struct_type_name = "Parser";
    _module_params[728].element_type = 21;
    _module_params[728].fn_sig = NULL;

    /* Function: parse_definition */
    _module_functions[504].name = "parse_definition";
    _module_functions[504].param_count = 1;
    _module_functions[504].return_type = 8;
    _module_functions[504].return_struct_type_name = "Parser";
    _module_functions[504].return_fn_sig = NULL;
    _module_functions[504].return_type_info = NULL;
    _module_functions[504].body = NULL;
    _module_functions[504].shadow_test = NULL;
    _module_functions[504].is_extern = false;
    _module_functions[504].returns_gc_managed = false;
    _module_functions[504].requires_manual_free = false;
    _module_functions[504].returns_borrowed = false;
    _module_functions[504].cleanup_function = NULL;
    _module_functions[504].params = &_module_params[729];
    _module_params[729].name = "p";
    _module_params[729].type = 8;
    _module_params[729].struct_type_name = "Parser";
    _module_params[729].element_type = 21;
    _module_params[729].fn_sig = NULL;

    /* Function: parser_declaration_extents */
    _module_functions[505].name = "parser_declaration_extents";
    _module_functions[505].param_count = 1;
    _module_functions[505].return_type = 7;
    _module_functions[505].return_struct_type_name = NULL;
    _module_functions[505].return_fn_sig = NULL;
    _module_functions[505].return_type_info = &_type_infos[38];
    _module_functions[505].body = NULL;
    _module_functions[505].shadow_test = NULL;
    _module_functions[505].is_extern = false;
    _module_functions[505].returns_gc_managed = false;
    _module_functions[505].requires_manual_free = false;
    _module_functions[505].returns_borrowed = false;
    _module_functions[505].cleanup_function = NULL;
    _module_functions[505].params = &_module_params[730];
    _module_params[730].name = "p";
    _module_params[730].type = 8;
    _module_params[730].struct_type_name = "Parser";
    _module_params[730].element_type = 21;
    _module_params[730].fn_sig = NULL;

    /* Function: parse_program_impl */
    _module_functions[506].name = "parse_program_impl";
    _module_functions[506].param_count = 5;
    _module_functions[506].return_type = 8;
    _module_functions[506].return_struct_type_name = "__nano_record_706172736572_ParsedDeclarations";
    _module_functions[506].return_fn_sig = NULL;
    _module_functions[506].return_type_info = NULL;
    _module_functions[506].body = NULL;
    _module_functions[506].shadow_test = NULL;
    _module_functions[506].is_extern = false;
    _module_functions[506].returns_gc_managed = false;
    _module_functions[506].requires_manual_free = false;
    _module_functions[506].returns_borrowed = false;
    _module_functions[506].cleanup_function = NULL;
    _module_functions[506].params = &_module_params[731];
    _module_params[731].name = "tokens";
    _module_params[731].type = 15;
    _module_params[731].struct_type_name = "LexerToken";
    _module_params[731].element_type = 21;
    _module_params[731].fn_sig = NULL;
    _module_params[732].name = "token_count";
    _module_params[732].type = 0;
    _module_params[732].struct_type_name = NULL;
    _module_params[732].element_type = 21;
    _module_params[732].fn_sig = NULL;
    _module_params[733].name = "file_name";
    _module_params[733].type = 4;
    _module_params[733].struct_type_name = NULL;
    _module_params[733].element_type = 21;
    _module_params[733].fn_sig = NULL;
    _module_params[734].name = "capture";
    _module_params[734].type = 3;
    _module_params[734].struct_type_name = NULL;
    _module_params[734].element_type = 21;
    _module_params[734].fn_sig = NULL;
    _module_params[735].name = "capture_limit";
    _module_params[735].type = 0;
    _module_params[735].struct_type_name = NULL;
    _module_params[735].element_type = 21;
    _module_params[735].fn_sig = NULL;

    /* Function: parse_program_declarations */
    _module_functions[507].name = "parse_program_declarations";
    _module_functions[507].param_count = 3;
    _module_functions[507].return_type = 8;
    _module_functions[507].return_struct_type_name = "__nano_record_706172736572_ParsedDeclarations";
    _module_functions[507].return_fn_sig = NULL;
    _module_functions[507].return_type_info = NULL;
    _module_functions[507].body = NULL;
    _module_functions[507].shadow_test = NULL;
    _module_functions[507].is_extern = false;
    _module_functions[507].returns_gc_managed = false;
    _module_functions[507].requires_manual_free = false;
    _module_functions[507].returns_borrowed = false;
    _module_functions[507].cleanup_function = NULL;
    _module_functions[507].params = &_module_params[736];
    _module_params[736].name = "tokens";
    _module_params[736].type = 15;
    _module_params[736].struct_type_name = "LexerToken";
    _module_params[736].element_type = 21;
    _module_params[736].fn_sig = NULL;
    _module_params[737].name = "token_count";
    _module_params[737].type = 0;
    _module_params[737].struct_type_name = NULL;
    _module_params[737].element_type = 21;
    _module_params[737].fn_sig = NULL;
    _module_params[738].name = "file_name";
    _module_params[738].type = 4;
    _module_params[738].struct_type_name = NULL;
    _module_params[738].element_type = 21;
    _module_params[738].fn_sig = NULL;

    /* Function: parse_program_complete_declarations */
    _module_functions[508].name = "parse_program_complete_declarations";
    _module_functions[508].param_count = 3;
    _module_functions[508].return_type = 8;
    _module_functions[508].return_struct_type_name = "__nano_record_706172736572_ParsedDeclarations";
    _module_functions[508].return_fn_sig = NULL;
    _module_functions[508].return_type_info = NULL;
    _module_functions[508].body = NULL;
    _module_functions[508].shadow_test = NULL;
    _module_functions[508].is_extern = false;
    _module_functions[508].returns_gc_managed = false;
    _module_functions[508].requires_manual_free = false;
    _module_functions[508].returns_borrowed = false;
    _module_functions[508].cleanup_function = NULL;
    _module_functions[508].params = &_module_params[739];
    _module_params[739].name = "tokens";
    _module_params[739].type = 15;
    _module_params[739].struct_type_name = "LexerToken";
    _module_params[739].element_type = 21;
    _module_params[739].fn_sig = NULL;
    _module_params[740].name = "token_count";
    _module_params[740].type = 0;
    _module_params[740].struct_type_name = NULL;
    _module_params[740].element_type = 21;
    _module_params[740].fn_sig = NULL;
    _module_params[741].name = "file_name";
    _module_params[741].type = 4;
    _module_params[741].struct_type_name = NULL;
    _module_params[741].element_type = 21;
    _module_params[741].fn_sig = NULL;

    /* Function: parse_program */
    _module_functions[509].name = "parse_program";
    _module_functions[509].param_count = 3;
    _module_functions[509].return_type = 8;
    _module_functions[509].return_struct_type_name = "Parser";
    _module_functions[509].return_fn_sig = NULL;
    _module_functions[509].return_type_info = NULL;
    _module_functions[509].body = NULL;
    _module_functions[509].shadow_test = NULL;
    _module_functions[509].is_extern = false;
    _module_functions[509].returns_gc_managed = false;
    _module_functions[509].requires_manual_free = false;
    _module_functions[509].returns_borrowed = false;
    _module_functions[509].cleanup_function = NULL;
    _module_functions[509].params = &_module_params[742];
    _module_params[742].name = "tokens";
    _module_params[742].type = 15;
    _module_params[742].struct_type_name = "LexerToken";
    _module_params[742].element_type = 21;
    _module_params[742].fn_sig = NULL;
    _module_params[743].name = "token_count";
    _module_params[743].type = 0;
    _module_params[743].struct_type_name = NULL;
    _module_params[743].element_type = 21;
    _module_params[743].fn_sig = NULL;
    _module_params[744].name = "file_name";
    _module_params[744].type = 4;
    _module_params[744].struct_type_name = NULL;
    _module_params[744].element_type = 21;
    _module_params[744].fn_sig = NULL;

    /* Function: create_number_node */
    _module_functions[510].name = "create_number_node";
    _module_functions[510].param_count = 3;
    _module_functions[510].return_type = 8;
    _module_functions[510].return_struct_type_name = "ASTNumber";
    _module_functions[510].return_fn_sig = NULL;
    _module_functions[510].return_type_info = NULL;
    _module_functions[510].body = NULL;
    _module_functions[510].shadow_test = NULL;
    _module_functions[510].is_extern = false;
    _module_functions[510].returns_gc_managed = false;
    _module_functions[510].requires_manual_free = false;
    _module_functions[510].returns_borrowed = false;
    _module_functions[510].cleanup_function = NULL;
    _module_functions[510].params = &_module_params[745];
    _module_params[745].name = "value";
    _module_params[745].type = 4;
    _module_params[745].struct_type_name = NULL;
    _module_params[745].element_type = 21;
    _module_params[745].fn_sig = NULL;
    _module_params[746].name = "line";
    _module_params[746].type = 0;
    _module_params[746].struct_type_name = NULL;
    _module_params[746].element_type = 21;
    _module_params[746].fn_sig = NULL;
    _module_params[747].name = "column";
    _module_params[747].type = 0;
    _module_params[747].struct_type_name = NULL;
    _module_params[747].element_type = 21;
    _module_params[747].fn_sig = NULL;

    /* Function: create_identifier_node */
    _module_functions[511].name = "create_identifier_node";
    _module_functions[511].param_count = 3;
    _module_functions[511].return_type = 8;
    _module_functions[511].return_struct_type_name = "ASTIdentifier";
    _module_functions[511].return_fn_sig = NULL;
    _module_functions[511].return_type_info = NULL;
    _module_functions[511].body = NULL;
    _module_functions[511].shadow_test = NULL;
    _module_functions[511].is_extern = false;
    _module_functions[511].returns_gc_managed = false;
    _module_functions[511].requires_manual_free = false;
    _module_functions[511].returns_borrowed = false;
    _module_functions[511].cleanup_function = NULL;
    _module_functions[511].params = &_module_params[748];
    _module_params[748].name = "name";
    _module_params[748].type = 4;
    _module_params[748].struct_type_name = NULL;
    _module_params[748].element_type = 21;
    _module_params[748].fn_sig = NULL;
    _module_params[749].name = "line";
    _module_params[749].type = 0;
    _module_params[749].struct_type_name = NULL;
    _module_params[749].element_type = 21;
    _module_params[749].fn_sig = NULL;
    _module_params[750].name = "column";
    _module_params[750].type = 0;
    _module_params[750].struct_type_name = NULL;
    _module_params[750].element_type = 21;
    _module_params[750].fn_sig = NULL;

    /* Function: test_parser_structure */
    _module_functions[512].name = "test_parser_structure";
    _module_functions[512].param_count = 0;
    _module_functions[512].return_type = 0;
    _module_functions[512].return_struct_type_name = NULL;
    _module_functions[512].return_fn_sig = NULL;
    _module_functions[512].return_type_info = NULL;
    _module_functions[512].body = NULL;
    _module_functions[512].shadow_test = NULL;
    _module_functions[512].is_extern = false;
    _module_functions[512].returns_gc_managed = false;
    _module_functions[512].requires_manual_free = false;
    _module_functions[512].returns_borrowed = false;
    _module_functions[512].cleanup_function = NULL;
    _module_functions[512].params = NULL;

    /* Function: parser_get_function_count */
    _module_functions[513].name = "parser_get_function_count";
    _module_functions[513].param_count = 1;
    _module_functions[513].return_type = 0;
    _module_functions[513].return_struct_type_name = NULL;
    _module_functions[513].return_fn_sig = NULL;
    _module_functions[513].return_type_info = NULL;
    _module_functions[513].body = NULL;
    _module_functions[513].shadow_test = NULL;
    _module_functions[513].is_extern = false;
    _module_functions[513].returns_gc_managed = false;
    _module_functions[513].requires_manual_free = false;
    _module_functions[513].returns_borrowed = false;
    _module_functions[513].cleanup_function = NULL;
    _module_functions[513].params = &_module_params[751];
    _module_params[751].name = "p";
    _module_params[751].type = 8;
    _module_params[751].struct_type_name = "Parser";
    _module_params[751].element_type = 21;
    _module_params[751].fn_sig = NULL;

    /* Function: parser_get_function */
    _module_functions[514].name = "parser_get_function";
    _module_functions[514].param_count = 2;
    _module_functions[514].return_type = 8;
    _module_functions[514].return_struct_type_name = "ASTFunction";
    _module_functions[514].return_fn_sig = NULL;
    _module_functions[514].return_type_info = NULL;
    _module_functions[514].body = NULL;
    _module_functions[514].shadow_test = NULL;
    _module_functions[514].is_extern = false;
    _module_functions[514].returns_gc_managed = false;
    _module_functions[514].requires_manual_free = false;
    _module_functions[514].returns_borrowed = false;
    _module_functions[514].cleanup_function = NULL;
    _module_functions[514].params = &_module_params[752];
    _module_params[752].name = "p";
    _module_params[752].type = 8;
    _module_params[752].struct_type_name = "Parser";
    _module_params[752].element_type = 21;
    _module_params[752].fn_sig = NULL;
    _module_params[753].name = "idx";
    _module_params[753].type = 0;
    _module_params[753].struct_type_name = NULL;
    _module_params[753].element_type = 21;
    _module_params[753].fn_sig = NULL;

    /* Function: parser_get_let_count */
    _module_functions[515].name = "parser_get_let_count";
    _module_functions[515].param_count = 1;
    _module_functions[515].return_type = 0;
    _module_functions[515].return_struct_type_name = NULL;
    _module_functions[515].return_fn_sig = NULL;
    _module_functions[515].return_type_info = NULL;
    _module_functions[515].body = NULL;
    _module_functions[515].shadow_test = NULL;
    _module_functions[515].is_extern = false;
    _module_functions[515].returns_gc_managed = false;
    _module_functions[515].requires_manual_free = false;
    _module_functions[515].returns_borrowed = false;
    _module_functions[515].cleanup_function = NULL;
    _module_functions[515].params = &_module_params[754];
    _module_params[754].name = "p";
    _module_params[754].type = 8;
    _module_params[754].struct_type_name = "Parser";
    _module_params[754].element_type = 21;
    _module_params[754].fn_sig = NULL;

    /* Function: parser_get_let */
    _module_functions[516].name = "parser_get_let";
    _module_functions[516].param_count = 2;
    _module_functions[516].return_type = 8;
    _module_functions[516].return_struct_type_name = "ASTLet";
    _module_functions[516].return_fn_sig = NULL;
    _module_functions[516].return_type_info = NULL;
    _module_functions[516].body = NULL;
    _module_functions[516].shadow_test = NULL;
    _module_functions[516].is_extern = false;
    _module_functions[516].returns_gc_managed = false;
    _module_functions[516].requires_manual_free = false;
    _module_functions[516].returns_borrowed = false;
    _module_functions[516].cleanup_function = NULL;
    _module_functions[516].params = &_module_params[755];
    _module_params[755].name = "p";
    _module_params[755].type = 8;
    _module_params[755].struct_type_name = "Parser";
    _module_params[755].element_type = 21;
    _module_params[755].fn_sig = NULL;
    _module_params[756].name = "idx";
    _module_params[756].type = 0;
    _module_params[756].struct_type_name = NULL;
    _module_params[756].element_type = 21;
    _module_params[756].fn_sig = NULL;

    /* Function: parser_set_let_var_type */
    _module_functions[517].name = "parser_set_let_var_type";
    _module_functions[517].param_count = 3;
    _module_functions[517].return_type = 8;
    _module_functions[517].return_struct_type_name = "Parser";
    _module_functions[517].return_fn_sig = NULL;
    _module_functions[517].return_type_info = NULL;
    _module_functions[517].body = NULL;
    _module_functions[517].shadow_test = NULL;
    _module_functions[517].is_extern = false;
    _module_functions[517].returns_gc_managed = false;
    _module_functions[517].requires_manual_free = false;
    _module_functions[517].returns_borrowed = false;
    _module_functions[517].cleanup_function = NULL;
    _module_functions[517].params = &_module_params[757];
    _module_params[757].name = "p";
    _module_params[757].type = 8;
    _module_params[757].struct_type_name = "Parser";
    _module_params[757].element_type = 21;
    _module_params[757].fn_sig = NULL;
    _module_params[758].name = "idx";
    _module_params[758].type = 0;
    _module_params[758].struct_type_name = NULL;
    _module_params[758].element_type = 21;
    _module_params[758].fn_sig = NULL;
    _module_params[759].name = "var_type";
    _module_params[759].type = 4;
    _module_params[759].struct_type_name = NULL;
    _module_params[759].element_type = 21;
    _module_params[759].fn_sig = NULL;

    /* Function: parser_get_identifier_count */
    _module_functions[518].name = "parser_get_identifier_count";
    _module_functions[518].param_count = 1;
    _module_functions[518].return_type = 0;
    _module_functions[518].return_struct_type_name = NULL;
    _module_functions[518].return_fn_sig = NULL;
    _module_functions[518].return_type_info = NULL;
    _module_functions[518].body = NULL;
    _module_functions[518].shadow_test = NULL;
    _module_functions[518].is_extern = false;
    _module_functions[518].returns_gc_managed = false;
    _module_functions[518].requires_manual_free = false;
    _module_functions[518].returns_borrowed = false;
    _module_functions[518].cleanup_function = NULL;
    _module_functions[518].params = &_module_params[760];
    _module_params[760].name = "p";
    _module_params[760].type = 8;
    _module_params[760].struct_type_name = "Parser";
    _module_params[760].element_type = 21;
    _module_params[760].fn_sig = NULL;

    /* Function: parser_get_identifier */
    _module_functions[519].name = "parser_get_identifier";
    _module_functions[519].param_count = 2;
    _module_functions[519].return_type = 8;
    _module_functions[519].return_struct_type_name = "ASTIdentifier";
    _module_functions[519].return_fn_sig = NULL;
    _module_functions[519].return_type_info = NULL;
    _module_functions[519].body = NULL;
    _module_functions[519].shadow_test = NULL;
    _module_functions[519].is_extern = false;
    _module_functions[519].returns_gc_managed = false;
    _module_functions[519].requires_manual_free = false;
    _module_functions[519].returns_borrowed = false;
    _module_functions[519].cleanup_function = NULL;
    _module_functions[519].params = &_module_params[761];
    _module_params[761].name = "p";
    _module_params[761].type = 8;
    _module_params[761].struct_type_name = "Parser";
    _module_params[761].element_type = 21;
    _module_params[761].fn_sig = NULL;
    _module_params[762].name = "idx";
    _module_params[762].type = 0;
    _module_params[762].struct_type_name = NULL;
    _module_params[762].element_type = 21;
    _module_params[762].fn_sig = NULL;

    /* Function: parser_get_number_count */
    _module_functions[520].name = "parser_get_number_count";
    _module_functions[520].param_count = 1;
    _module_functions[520].return_type = 0;
    _module_functions[520].return_struct_type_name = NULL;
    _module_functions[520].return_fn_sig = NULL;
    _module_functions[520].return_type_info = NULL;
    _module_functions[520].body = NULL;
    _module_functions[520].shadow_test = NULL;
    _module_functions[520].is_extern = false;
    _module_functions[520].returns_gc_managed = false;
    _module_functions[520].requires_manual_free = false;
    _module_functions[520].returns_borrowed = false;
    _module_functions[520].cleanup_function = NULL;
    _module_functions[520].params = &_module_params[763];
    _module_params[763].name = "p";
    _module_params[763].type = 8;
    _module_params[763].struct_type_name = "Parser";
    _module_params[763].element_type = 21;
    _module_params[763].fn_sig = NULL;

    /* Function: parser_get_number */
    _module_functions[521].name = "parser_get_number";
    _module_functions[521].param_count = 2;
    _module_functions[521].return_type = 8;
    _module_functions[521].return_struct_type_name = "ASTNumber";
    _module_functions[521].return_fn_sig = NULL;
    _module_functions[521].return_type_info = NULL;
    _module_functions[521].body = NULL;
    _module_functions[521].shadow_test = NULL;
    _module_functions[521].is_extern = false;
    _module_functions[521].returns_gc_managed = false;
    _module_functions[521].requires_manual_free = false;
    _module_functions[521].returns_borrowed = false;
    _module_functions[521].cleanup_function = NULL;
    _module_functions[521].params = &_module_params[764];
    _module_params[764].name = "p";
    _module_params[764].type = 8;
    _module_params[764].struct_type_name = "Parser";
    _module_params[764].element_type = 21;
    _module_params[764].fn_sig = NULL;
    _module_params[765].name = "idx";
    _module_params[765].type = 0;
    _module_params[765].struct_type_name = NULL;
    _module_params[765].element_type = 21;
    _module_params[765].fn_sig = NULL;

    /* Function: parser_get_float_count */
    _module_functions[522].name = "parser_get_float_count";
    _module_functions[522].param_count = 1;
    _module_functions[522].return_type = 0;
    _module_functions[522].return_struct_type_name = NULL;
    _module_functions[522].return_fn_sig = NULL;
    _module_functions[522].return_type_info = NULL;
    _module_functions[522].body = NULL;
    _module_functions[522].shadow_test = NULL;
    _module_functions[522].is_extern = false;
    _module_functions[522].returns_gc_managed = false;
    _module_functions[522].requires_manual_free = false;
    _module_functions[522].returns_borrowed = false;
    _module_functions[522].cleanup_function = NULL;
    _module_functions[522].params = &_module_params[766];
    _module_params[766].name = "p";
    _module_params[766].type = 8;
    _module_params[766].struct_type_name = "Parser";
    _module_params[766].element_type = 21;
    _module_params[766].fn_sig = NULL;

    /* Function: parser_get_float */
    _module_functions[523].name = "parser_get_float";
    _module_functions[523].param_count = 2;
    _module_functions[523].return_type = 8;
    _module_functions[523].return_struct_type_name = "ASTFloat";
    _module_functions[523].return_fn_sig = NULL;
    _module_functions[523].return_type_info = NULL;
    _module_functions[523].body = NULL;
    _module_functions[523].shadow_test = NULL;
    _module_functions[523].is_extern = false;
    _module_functions[523].returns_gc_managed = false;
    _module_functions[523].requires_manual_free = false;
    _module_functions[523].returns_borrowed = false;
    _module_functions[523].cleanup_function = NULL;
    _module_functions[523].params = &_module_params[767];
    _module_params[767].name = "p";
    _module_params[767].type = 8;
    _module_params[767].struct_type_name = "Parser";
    _module_params[767].element_type = 21;
    _module_params[767].fn_sig = NULL;
    _module_params[768].name = "idx";
    _module_params[768].type = 0;
    _module_params[768].struct_type_name = NULL;
    _module_params[768].element_type = 21;
    _module_params[768].fn_sig = NULL;

    /* Function: parser_get_binary_op_count */
    _module_functions[524].name = "parser_get_binary_op_count";
    _module_functions[524].param_count = 1;
    _module_functions[524].return_type = 0;
    _module_functions[524].return_struct_type_name = NULL;
    _module_functions[524].return_fn_sig = NULL;
    _module_functions[524].return_type_info = NULL;
    _module_functions[524].body = NULL;
    _module_functions[524].shadow_test = NULL;
    _module_functions[524].is_extern = false;
    _module_functions[524].returns_gc_managed = false;
    _module_functions[524].requires_manual_free = false;
    _module_functions[524].returns_borrowed = false;
    _module_functions[524].cleanup_function = NULL;
    _module_functions[524].params = &_module_params[769];
    _module_params[769].name = "p";
    _module_params[769].type = 8;
    _module_params[769].struct_type_name = "Parser";
    _module_params[769].element_type = 21;
    _module_params[769].fn_sig = NULL;

    /* Function: parser_get_binary_op */
    _module_functions[525].name = "parser_get_binary_op";
    _module_functions[525].param_count = 2;
    _module_functions[525].return_type = 8;
    _module_functions[525].return_struct_type_name = "ASTBinaryOp";
    _module_functions[525].return_fn_sig = NULL;
    _module_functions[525].return_type_info = NULL;
    _module_functions[525].body = NULL;
    _module_functions[525].shadow_test = NULL;
    _module_functions[525].is_extern = false;
    _module_functions[525].returns_gc_managed = false;
    _module_functions[525].requires_manual_free = false;
    _module_functions[525].returns_borrowed = false;
    _module_functions[525].cleanup_function = NULL;
    _module_functions[525].params = &_module_params[770];
    _module_params[770].name = "p";
    _module_params[770].type = 8;
    _module_params[770].struct_type_name = "Parser";
    _module_params[770].element_type = 21;
    _module_params[770].fn_sig = NULL;
    _module_params[771].name = "idx";
    _module_params[771].type = 0;
    _module_params[771].struct_type_name = NULL;
    _module_params[771].element_type = 21;
    _module_params[771].fn_sig = NULL;

    /* Function: parser_get_return_count */
    _module_functions[526].name = "parser_get_return_count";
    _module_functions[526].param_count = 1;
    _module_functions[526].return_type = 0;
    _module_functions[526].return_struct_type_name = NULL;
    _module_functions[526].return_fn_sig = NULL;
    _module_functions[526].return_type_info = NULL;
    _module_functions[526].body = NULL;
    _module_functions[526].shadow_test = NULL;
    _module_functions[526].is_extern = false;
    _module_functions[526].returns_gc_managed = false;
    _module_functions[526].requires_manual_free = false;
    _module_functions[526].returns_borrowed = false;
    _module_functions[526].cleanup_function = NULL;
    _module_functions[526].params = &_module_params[772];
    _module_params[772].name = "p";
    _module_params[772].type = 8;
    _module_params[772].struct_type_name = "Parser";
    _module_params[772].element_type = 21;
    _module_params[772].fn_sig = NULL;

    /* Function: parser_get_return */
    _module_functions[527].name = "parser_get_return";
    _module_functions[527].param_count = 2;
    _module_functions[527].return_type = 8;
    _module_functions[527].return_struct_type_name = "ASTReturn";
    _module_functions[527].return_fn_sig = NULL;
    _module_functions[527].return_type_info = NULL;
    _module_functions[527].body = NULL;
    _module_functions[527].shadow_test = NULL;
    _module_functions[527].is_extern = false;
    _module_functions[527].returns_gc_managed = false;
    _module_functions[527].requires_manual_free = false;
    _module_functions[527].returns_borrowed = false;
    _module_functions[527].cleanup_function = NULL;
    _module_functions[527].params = &_module_params[773];
    _module_params[773].name = "p";
    _module_params[773].type = 8;
    _module_params[773].struct_type_name = "Parser";
    _module_params[773].element_type = 21;
    _module_params[773].fn_sig = NULL;
    _module_params[774].name = "idx";
    _module_params[774].type = 0;
    _module_params[774].struct_type_name = NULL;
    _module_params[774].element_type = 21;
    _module_params[774].fn_sig = NULL;

    /* Function: parser_get_block_count */
    _module_functions[528].name = "parser_get_block_count";
    _module_functions[528].param_count = 1;
    _module_functions[528].return_type = 0;
    _module_functions[528].return_struct_type_name = NULL;
    _module_functions[528].return_fn_sig = NULL;
    _module_functions[528].return_type_info = NULL;
    _module_functions[528].body = NULL;
    _module_functions[528].shadow_test = NULL;
    _module_functions[528].is_extern = false;
    _module_functions[528].returns_gc_managed = false;
    _module_functions[528].requires_manual_free = false;
    _module_functions[528].returns_borrowed = false;
    _module_functions[528].cleanup_function = NULL;
    _module_functions[528].params = &_module_params[775];
    _module_params[775].name = "p";
    _module_params[775].type = 8;
    _module_params[775].struct_type_name = "Parser";
    _module_params[775].element_type = 21;
    _module_params[775].fn_sig = NULL;

    /* Function: parser_get_block */
    _module_functions[529].name = "parser_get_block";
    _module_functions[529].param_count = 2;
    _module_functions[529].return_type = 8;
    _module_functions[529].return_struct_type_name = "ASTBlock";
    _module_functions[529].return_fn_sig = NULL;
    _module_functions[529].return_type_info = NULL;
    _module_functions[529].body = NULL;
    _module_functions[529].shadow_test = NULL;
    _module_functions[529].is_extern = false;
    _module_functions[529].returns_gc_managed = false;
    _module_functions[529].requires_manual_free = false;
    _module_functions[529].returns_borrowed = false;
    _module_functions[529].cleanup_function = NULL;
    _module_functions[529].params = &_module_params[776];
    _module_params[776].name = "p";
    _module_params[776].type = 8;
    _module_params[776].struct_type_name = "Parser";
    _module_params[776].element_type = 21;
    _module_params[776].fn_sig = NULL;
    _module_params[777].name = "idx";
    _module_params[777].type = 0;
    _module_params[777].struct_type_name = NULL;
    _module_params[777].element_type = 21;
    _module_params[777].fn_sig = NULL;

    /* Function: parser_get_if */
    _module_functions[530].name = "parser_get_if";
    _module_functions[530].param_count = 2;
    _module_functions[530].return_type = 8;
    _module_functions[530].return_struct_type_name = "ASTIf";
    _module_functions[530].return_fn_sig = NULL;
    _module_functions[530].return_type_info = NULL;
    _module_functions[530].body = NULL;
    _module_functions[530].shadow_test = NULL;
    _module_functions[530].is_extern = false;
    _module_functions[530].returns_gc_managed = false;
    _module_functions[530].requires_manual_free = false;
    _module_functions[530].returns_borrowed = false;
    _module_functions[530].cleanup_function = NULL;
    _module_functions[530].params = &_module_params[778];
    _module_params[778].name = "p";
    _module_params[778].type = 8;
    _module_params[778].struct_type_name = "Parser";
    _module_params[778].element_type = 21;
    _module_params[778].fn_sig = NULL;
    _module_params[779].name = "idx";
    _module_params[779].type = 0;
    _module_params[779].struct_type_name = NULL;
    _module_params[779].element_type = 21;
    _module_params[779].fn_sig = NULL;

    /* Function: parser_get_if_count */
    _module_functions[531].name = "parser_get_if_count";
    _module_functions[531].param_count = 1;
    _module_functions[531].return_type = 0;
    _module_functions[531].return_struct_type_name = NULL;
    _module_functions[531].return_fn_sig = NULL;
    _module_functions[531].return_type_info = NULL;
    _module_functions[531].body = NULL;
    _module_functions[531].shadow_test = NULL;
    _module_functions[531].is_extern = false;
    _module_functions[531].returns_gc_managed = false;
    _module_functions[531].requires_manual_free = false;
    _module_functions[531].returns_borrowed = false;
    _module_functions[531].cleanup_function = NULL;
    _module_functions[531].params = &_module_params[780];
    _module_params[780].name = "p";
    _module_params[780].type = 8;
    _module_params[780].struct_type_name = "Parser";
    _module_params[780].element_type = 21;
    _module_params[780].fn_sig = NULL;

    /* Function: parser_get_while */
    _module_functions[532].name = "parser_get_while";
    _module_functions[532].param_count = 2;
    _module_functions[532].return_type = 8;
    _module_functions[532].return_struct_type_name = "ASTWhile";
    _module_functions[532].return_fn_sig = NULL;
    _module_functions[532].return_type_info = NULL;
    _module_functions[532].body = NULL;
    _module_functions[532].shadow_test = NULL;
    _module_functions[532].is_extern = false;
    _module_functions[532].returns_gc_managed = false;
    _module_functions[532].requires_manual_free = false;
    _module_functions[532].returns_borrowed = false;
    _module_functions[532].cleanup_function = NULL;
    _module_functions[532].params = &_module_params[781];
    _module_params[781].name = "p";
    _module_params[781].type = 8;
    _module_params[781].struct_type_name = "Parser";
    _module_params[781].element_type = 21;
    _module_params[781].fn_sig = NULL;
    _module_params[782].name = "idx";
    _module_params[782].type = 0;
    _module_params[782].struct_type_name = NULL;
    _module_params[782].element_type = 21;
    _module_params[782].fn_sig = NULL;

    /* Function: parser_get_while_count */
    _module_functions[533].name = "parser_get_while_count";
    _module_functions[533].param_count = 1;
    _module_functions[533].return_type = 0;
    _module_functions[533].return_struct_type_name = NULL;
    _module_functions[533].return_fn_sig = NULL;
    _module_functions[533].return_type_info = NULL;
    _module_functions[533].body = NULL;
    _module_functions[533].shadow_test = NULL;
    _module_functions[533].is_extern = false;
    _module_functions[533].returns_gc_managed = false;
    _module_functions[533].requires_manual_free = false;
    _module_functions[533].returns_borrowed = false;
    _module_functions[533].cleanup_function = NULL;
    _module_functions[533].params = &_module_params[783];
    _module_params[783].name = "p";
    _module_params[783].type = 8;
    _module_params[783].struct_type_name = "Parser";
    _module_params[783].element_type = 21;
    _module_params[783].fn_sig = NULL;

    /* Function: parser_get_for */
    _module_functions[534].name = "parser_get_for";
    _module_functions[534].param_count = 2;
    _module_functions[534].return_type = 8;
    _module_functions[534].return_struct_type_name = "ASTFor";
    _module_functions[534].return_fn_sig = NULL;
    _module_functions[534].return_type_info = NULL;
    _module_functions[534].body = NULL;
    _module_functions[534].shadow_test = NULL;
    _module_functions[534].is_extern = false;
    _module_functions[534].returns_gc_managed = false;
    _module_functions[534].requires_manual_free = false;
    _module_functions[534].returns_borrowed = false;
    _module_functions[534].cleanup_function = NULL;
    _module_functions[534].params = &_module_params[784];
    _module_params[784].name = "p";
    _module_params[784].type = 8;
    _module_params[784].struct_type_name = "Parser";
    _module_params[784].element_type = 21;
    _module_params[784].fn_sig = NULL;
    _module_params[785].name = "idx";
    _module_params[785].type = 0;
    _module_params[785].struct_type_name = NULL;
    _module_params[785].element_type = 21;
    _module_params[785].fn_sig = NULL;

    /* Function: parser_get_unsafe_block */
    _module_functions[535].name = "parser_get_unsafe_block";
    _module_functions[535].param_count = 2;
    _module_functions[535].return_type = 8;
    _module_functions[535].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[535].return_fn_sig = NULL;
    _module_functions[535].return_type_info = NULL;
    _module_functions[535].body = NULL;
    _module_functions[535].shadow_test = NULL;
    _module_functions[535].is_extern = false;
    _module_functions[535].returns_gc_managed = false;
    _module_functions[535].requires_manual_free = false;
    _module_functions[535].returns_borrowed = false;
    _module_functions[535].cleanup_function = NULL;
    _module_functions[535].params = &_module_params[786];
    _module_params[786].name = "p";
    _module_params[786].type = 8;
    _module_params[786].struct_type_name = "Parser";
    _module_params[786].element_type = 21;
    _module_params[786].fn_sig = NULL;
    _module_params[787].name = "idx";
    _module_params[787].type = 0;
    _module_params[787].struct_type_name = NULL;
    _module_params[787].element_type = 21;
    _module_params[787].fn_sig = NULL;

    /* Function: parser_get_call */
    _module_functions[536].name = "parser_get_call";
    _module_functions[536].param_count = 2;
    _module_functions[536].return_type = 8;
    _module_functions[536].return_struct_type_name = "ASTCall";
    _module_functions[536].return_fn_sig = NULL;
    _module_functions[536].return_type_info = NULL;
    _module_functions[536].body = NULL;
    _module_functions[536].shadow_test = NULL;
    _module_functions[536].is_extern = false;
    _module_functions[536].returns_gc_managed = false;
    _module_functions[536].requires_manual_free = false;
    _module_functions[536].returns_borrowed = false;
    _module_functions[536].cleanup_function = NULL;
    _module_functions[536].params = &_module_params[788];
    _module_params[788].name = "p";
    _module_params[788].type = 8;
    _module_params[788].struct_type_name = "Parser";
    _module_params[788].element_type = 21;
    _module_params[788].fn_sig = NULL;
    _module_params[789].name = "idx";
    _module_params[789].type = 0;
    _module_params[789].struct_type_name = NULL;
    _module_params[789].element_type = 21;
    _module_params[789].fn_sig = NULL;

    /* Function: parser_get_call_count */
    _module_functions[537].name = "parser_get_call_count";
    _module_functions[537].param_count = 1;
    _module_functions[537].return_type = 0;
    _module_functions[537].return_struct_type_name = NULL;
    _module_functions[537].return_fn_sig = NULL;
    _module_functions[537].return_type_info = NULL;
    _module_functions[537].body = NULL;
    _module_functions[537].shadow_test = NULL;
    _module_functions[537].is_extern = false;
    _module_functions[537].returns_gc_managed = false;
    _module_functions[537].requires_manual_free = false;
    _module_functions[537].returns_borrowed = false;
    _module_functions[537].cleanup_function = NULL;
    _module_functions[537].params = &_module_params[790];
    _module_params[790].name = "p";
    _module_params[790].type = 8;
    _module_params[790].struct_type_name = "Parser";
    _module_params[790].element_type = 21;
    _module_params[790].fn_sig = NULL;

    /* Function: parser_get_module_qualified_call */
    _module_functions[538].name = "parser_get_module_qualified_call";
    _module_functions[538].param_count = 2;
    _module_functions[538].return_type = 8;
    _module_functions[538].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[538].return_fn_sig = NULL;
    _module_functions[538].return_type_info = NULL;
    _module_functions[538].body = NULL;
    _module_functions[538].shadow_test = NULL;
    _module_functions[538].is_extern = false;
    _module_functions[538].returns_gc_managed = false;
    _module_functions[538].requires_manual_free = false;
    _module_functions[538].returns_borrowed = false;
    _module_functions[538].cleanup_function = NULL;
    _module_functions[538].params = &_module_params[791];
    _module_params[791].name = "p";
    _module_params[791].type = 8;
    _module_params[791].struct_type_name = "Parser";
    _module_params[791].element_type = 21;
    _module_params[791].fn_sig = NULL;
    _module_params[792].name = "idx";
    _module_params[792].type = 0;
    _module_params[792].struct_type_name = NULL;
    _module_params[792].element_type = 21;
    _module_params[792].fn_sig = NULL;

    /* Function: parser_get_module_qualified_call_count */
    _module_functions[539].name = "parser_get_module_qualified_call_count";
    _module_functions[539].param_count = 1;
    _module_functions[539].return_type = 0;
    _module_functions[539].return_struct_type_name = NULL;
    _module_functions[539].return_fn_sig = NULL;
    _module_functions[539].return_type_info = NULL;
    _module_functions[539].body = NULL;
    _module_functions[539].shadow_test = NULL;
    _module_functions[539].is_extern = false;
    _module_functions[539].returns_gc_managed = false;
    _module_functions[539].requires_manual_free = false;
    _module_functions[539].returns_borrowed = false;
    _module_functions[539].cleanup_function = NULL;
    _module_functions[539].params = &_module_params[793];
    _module_params[793].name = "p";
    _module_params[793].type = 8;
    _module_params[793].struct_type_name = "Parser";
    _module_params[793].element_type = 21;
    _module_params[793].fn_sig = NULL;

    /* Function: parser_get_call_arg_count */
    _module_functions[540].name = "parser_get_call_arg_count";
    _module_functions[540].param_count = 1;
    _module_functions[540].return_type = 0;
    _module_functions[540].return_struct_type_name = NULL;
    _module_functions[540].return_fn_sig = NULL;
    _module_functions[540].return_type_info = NULL;
    _module_functions[540].body = NULL;
    _module_functions[540].shadow_test = NULL;
    _module_functions[540].is_extern = false;
    _module_functions[540].returns_gc_managed = false;
    _module_functions[540].requires_manual_free = false;
    _module_functions[540].returns_borrowed = false;
    _module_functions[540].cleanup_function = NULL;
    _module_functions[540].params = &_module_params[794];
    _module_params[794].name = "p";
    _module_params[794].type = 8;
    _module_params[794].struct_type_name = "Parser";
    _module_params[794].element_type = 21;
    _module_params[794].fn_sig = NULL;

    /* Function: parser_get_call_arg */
    _module_functions[541].name = "parser_get_call_arg";
    _module_functions[541].param_count = 2;
    _module_functions[541].return_type = 8;
    _module_functions[541].return_struct_type_name = "ASTStmtRef";
    _module_functions[541].return_fn_sig = NULL;
    _module_functions[541].return_type_info = NULL;
    _module_functions[541].body = NULL;
    _module_functions[541].shadow_test = NULL;
    _module_functions[541].is_extern = false;
    _module_functions[541].returns_gc_managed = false;
    _module_functions[541].requires_manual_free = false;
    _module_functions[541].returns_borrowed = false;
    _module_functions[541].cleanup_function = NULL;
    _module_functions[541].params = &_module_params[795];
    _module_params[795].name = "p";
    _module_params[795].type = 8;
    _module_params[795].struct_type_name = "Parser";
    _module_params[795].element_type = 21;
    _module_params[795].fn_sig = NULL;
    _module_params[796].name = "idx";
    _module_params[796].type = 0;
    _module_params[796].struct_type_name = NULL;
    _module_params[796].element_type = 21;
    _module_params[796].fn_sig = NULL;

    /* Function: parser_get_set */
    _module_functions[542].name = "parser_get_set";
    _module_functions[542].param_count = 2;
    _module_functions[542].return_type = 8;
    _module_functions[542].return_struct_type_name = "ASTSet";
    _module_functions[542].return_fn_sig = NULL;
    _module_functions[542].return_type_info = NULL;
    _module_functions[542].body = NULL;
    _module_functions[542].shadow_test = NULL;
    _module_functions[542].is_extern = false;
    _module_functions[542].returns_gc_managed = false;
    _module_functions[542].requires_manual_free = false;
    _module_functions[542].returns_borrowed = false;
    _module_functions[542].cleanup_function = NULL;
    _module_functions[542].params = &_module_params[797];
    _module_params[797].name = "p";
    _module_params[797].type = 8;
    _module_params[797].struct_type_name = "Parser";
    _module_params[797].element_type = 21;
    _module_params[797].fn_sig = NULL;
    _module_params[798].name = "idx";
    _module_params[798].type = 0;
    _module_params[798].struct_type_name = NULL;
    _module_params[798].element_type = 21;
    _module_params[798].fn_sig = NULL;

    /* Function: parser_get_set_count */
    _module_functions[543].name = "parser_get_set_count";
    _module_functions[543].param_count = 1;
    _module_functions[543].return_type = 0;
    _module_functions[543].return_struct_type_name = NULL;
    _module_functions[543].return_fn_sig = NULL;
    _module_functions[543].return_type_info = NULL;
    _module_functions[543].body = NULL;
    _module_functions[543].shadow_test = NULL;
    _module_functions[543].is_extern = false;
    _module_functions[543].returns_gc_managed = false;
    _module_functions[543].requires_manual_free = false;
    _module_functions[543].returns_borrowed = false;
    _module_functions[543].cleanup_function = NULL;
    _module_functions[543].params = &_module_params[799];
    _module_params[799].name = "p";
    _module_params[799].type = 8;
    _module_params[799].struct_type_name = "Parser";
    _module_params[799].element_type = 21;
    _module_params[799].fn_sig = NULL;

    /* Function: parser_get_string_count */
    _module_functions[544].name = "parser_get_string_count";
    _module_functions[544].param_count = 1;
    _module_functions[544].return_type = 0;
    _module_functions[544].return_struct_type_name = NULL;
    _module_functions[544].return_fn_sig = NULL;
    _module_functions[544].return_type_info = NULL;
    _module_functions[544].body = NULL;
    _module_functions[544].shadow_test = NULL;
    _module_functions[544].is_extern = false;
    _module_functions[544].returns_gc_managed = false;
    _module_functions[544].requires_manual_free = false;
    _module_functions[544].returns_borrowed = false;
    _module_functions[544].cleanup_function = NULL;
    _module_functions[544].params = &_module_params[800];
    _module_params[800].name = "p";
    _module_params[800].type = 8;
    _module_params[800].struct_type_name = "Parser";
    _module_params[800].element_type = 21;
    _module_params[800].fn_sig = NULL;

    /* Function: parser_get_string */
    _module_functions[545].name = "parser_get_string";
    _module_functions[545].param_count = 2;
    _module_functions[545].return_type = 8;
    _module_functions[545].return_struct_type_name = "ASTString";
    _module_functions[545].return_fn_sig = NULL;
    _module_functions[545].return_type_info = NULL;
    _module_functions[545].body = NULL;
    _module_functions[545].shadow_test = NULL;
    _module_functions[545].is_extern = false;
    _module_functions[545].returns_gc_managed = false;
    _module_functions[545].requires_manual_free = false;
    _module_functions[545].returns_borrowed = false;
    _module_functions[545].cleanup_function = NULL;
    _module_functions[545].params = &_module_params[801];
    _module_params[801].name = "p";
    _module_params[801].type = 8;
    _module_params[801].struct_type_name = "Parser";
    _module_params[801].element_type = 21;
    _module_params[801].fn_sig = NULL;
    _module_params[802].name = "idx";
    _module_params[802].type = 0;
    _module_params[802].struct_type_name = NULL;
    _module_params[802].element_type = 21;
    _module_params[802].fn_sig = NULL;

    /* Function: parser_get_bool_count */
    _module_functions[546].name = "parser_get_bool_count";
    _module_functions[546].param_count = 1;
    _module_functions[546].return_type = 0;
    _module_functions[546].return_struct_type_name = NULL;
    _module_functions[546].return_fn_sig = NULL;
    _module_functions[546].return_type_info = NULL;
    _module_functions[546].body = NULL;
    _module_functions[546].shadow_test = NULL;
    _module_functions[546].is_extern = false;
    _module_functions[546].returns_gc_managed = false;
    _module_functions[546].requires_manual_free = false;
    _module_functions[546].returns_borrowed = false;
    _module_functions[546].cleanup_function = NULL;
    _module_functions[546].params = &_module_params[803];
    _module_params[803].name = "p";
    _module_params[803].type = 8;
    _module_params[803].struct_type_name = "Parser";
    _module_params[803].element_type = 21;
    _module_params[803].fn_sig = NULL;

    /* Function: parser_get_bool */
    _module_functions[547].name = "parser_get_bool";
    _module_functions[547].param_count = 2;
    _module_functions[547].return_type = 8;
    _module_functions[547].return_struct_type_name = "ASTBool";
    _module_functions[547].return_fn_sig = NULL;
    _module_functions[547].return_type_info = NULL;
    _module_functions[547].body = NULL;
    _module_functions[547].shadow_test = NULL;
    _module_functions[547].is_extern = false;
    _module_functions[547].returns_gc_managed = false;
    _module_functions[547].requires_manual_free = false;
    _module_functions[547].returns_borrowed = false;
    _module_functions[547].cleanup_function = NULL;
    _module_functions[547].params = &_module_params[804];
    _module_params[804].name = "p";
    _module_params[804].type = 8;
    _module_params[804].struct_type_name = "Parser";
    _module_params[804].element_type = 21;
    _module_params[804].fn_sig = NULL;
    _module_params[805].name = "idx";
    _module_params[805].type = 0;
    _module_params[805].struct_type_name = NULL;
    _module_params[805].element_type = 21;
    _module_params[805].fn_sig = NULL;

    /* Function: parser_get_assert_count */
    _module_functions[548].name = "parser_get_assert_count";
    _module_functions[548].param_count = 1;
    _module_functions[548].return_type = 0;
    _module_functions[548].return_struct_type_name = NULL;
    _module_functions[548].return_fn_sig = NULL;
    _module_functions[548].return_type_info = NULL;
    _module_functions[548].body = NULL;
    _module_functions[548].shadow_test = NULL;
    _module_functions[548].is_extern = false;
    _module_functions[548].returns_gc_managed = false;
    _module_functions[548].requires_manual_free = false;
    _module_functions[548].returns_borrowed = false;
    _module_functions[548].cleanup_function = NULL;
    _module_functions[548].params = &_module_params[806];
    _module_params[806].name = "p";
    _module_params[806].type = 8;
    _module_params[806].struct_type_name = "Parser";
    _module_params[806].element_type = 21;
    _module_params[806].fn_sig = NULL;

    /* Function: parser_get_assert */
    _module_functions[549].name = "parser_get_assert";
    _module_functions[549].param_count = 2;
    _module_functions[549].return_type = 8;
    _module_functions[549].return_struct_type_name = "ASTAssert";
    _module_functions[549].return_fn_sig = NULL;
    _module_functions[549].return_type_info = NULL;
    _module_functions[549].body = NULL;
    _module_functions[549].shadow_test = NULL;
    _module_functions[549].is_extern = false;
    _module_functions[549].returns_gc_managed = false;
    _module_functions[549].requires_manual_free = false;
    _module_functions[549].returns_borrowed = false;
    _module_functions[549].cleanup_function = NULL;
    _module_functions[549].params = &_module_params[807];
    _module_params[807].name = "p";
    _module_params[807].type = 8;
    _module_params[807].struct_type_name = "Parser";
    _module_params[807].element_type = 21;
    _module_params[807].fn_sig = NULL;
    _module_params[808].name = "idx";
    _module_params[808].type = 0;
    _module_params[808].struct_type_name = NULL;
    _module_params[808].element_type = 21;
    _module_params[808].fn_sig = NULL;

    /* Function: parser_get_field_access_count */
    _module_functions[550].name = "parser_get_field_access_count";
    _module_functions[550].param_count = 1;
    _module_functions[550].return_type = 0;
    _module_functions[550].return_struct_type_name = NULL;
    _module_functions[550].return_fn_sig = NULL;
    _module_functions[550].return_type_info = NULL;
    _module_functions[550].body = NULL;
    _module_functions[550].shadow_test = NULL;
    _module_functions[550].is_extern = false;
    _module_functions[550].returns_gc_managed = false;
    _module_functions[550].requires_manual_free = false;
    _module_functions[550].returns_borrowed = false;
    _module_functions[550].cleanup_function = NULL;
    _module_functions[550].params = &_module_params[809];
    _module_params[809].name = "p";
    _module_params[809].type = 8;
    _module_params[809].struct_type_name = "Parser";
    _module_params[809].element_type = 21;
    _module_params[809].fn_sig = NULL;

    /* Function: parser_get_field_access */
    _module_functions[551].name = "parser_get_field_access";
    _module_functions[551].param_count = 2;
    _module_functions[551].return_type = 8;
    _module_functions[551].return_struct_type_name = "ASTFieldAccess";
    _module_functions[551].return_fn_sig = NULL;
    _module_functions[551].return_type_info = NULL;
    _module_functions[551].body = NULL;
    _module_functions[551].shadow_test = NULL;
    _module_functions[551].is_extern = false;
    _module_functions[551].returns_gc_managed = false;
    _module_functions[551].requires_manual_free = false;
    _module_functions[551].returns_borrowed = false;
    _module_functions[551].cleanup_function = NULL;
    _module_functions[551].params = &_module_params[810];
    _module_params[810].name = "p";
    _module_params[810].type = 8;
    _module_params[810].struct_type_name = "Parser";
    _module_params[810].element_type = 21;
    _module_params[810].fn_sig = NULL;
    _module_params[811].name = "idx";
    _module_params[811].type = 0;
    _module_params[811].struct_type_name = NULL;
    _module_params[811].element_type = 21;
    _module_params[811].fn_sig = NULL;

    /* Function: parser_get_array_literal_count */
    _module_functions[552].name = "parser_get_array_literal_count";
    _module_functions[552].param_count = 1;
    _module_functions[552].return_type = 0;
    _module_functions[552].return_struct_type_name = NULL;
    _module_functions[552].return_fn_sig = NULL;
    _module_functions[552].return_type_info = NULL;
    _module_functions[552].body = NULL;
    _module_functions[552].shadow_test = NULL;
    _module_functions[552].is_extern = false;
    _module_functions[552].returns_gc_managed = false;
    _module_functions[552].requires_manual_free = false;
    _module_functions[552].returns_borrowed = false;
    _module_functions[552].cleanup_function = NULL;
    _module_functions[552].params = &_module_params[812];
    _module_params[812].name = "p";
    _module_params[812].type = 8;
    _module_params[812].struct_type_name = "Parser";
    _module_params[812].element_type = 21;
    _module_params[812].fn_sig = NULL;

    /* Function: parser_get_array_literal */
    _module_functions[553].name = "parser_get_array_literal";
    _module_functions[553].param_count = 2;
    _module_functions[553].return_type = 8;
    _module_functions[553].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[553].return_fn_sig = NULL;
    _module_functions[553].return_type_info = NULL;
    _module_functions[553].body = NULL;
    _module_functions[553].shadow_test = NULL;
    _module_functions[553].is_extern = false;
    _module_functions[553].returns_gc_managed = false;
    _module_functions[553].requires_manual_free = false;
    _module_functions[553].returns_borrowed = false;
    _module_functions[553].cleanup_function = NULL;
    _module_functions[553].params = &_module_params[813];
    _module_params[813].name = "p";
    _module_params[813].type = 8;
    _module_params[813].struct_type_name = "Parser";
    _module_params[813].element_type = 21;
    _module_params[813].fn_sig = NULL;
    _module_params[814].name = "idx";
    _module_params[814].type = 0;
    _module_params[814].struct_type_name = NULL;
    _module_params[814].element_type = 21;
    _module_params[814].fn_sig = NULL;

    /* Function: parser_set_array_literal_element_type */
    _module_functions[554].name = "parser_set_array_literal_element_type";
    _module_functions[554].param_count = 3;
    _module_functions[554].return_type = 8;
    _module_functions[554].return_struct_type_name = "Parser";
    _module_functions[554].return_fn_sig = NULL;
    _module_functions[554].return_type_info = NULL;
    _module_functions[554].body = NULL;
    _module_functions[554].shadow_test = NULL;
    _module_functions[554].is_extern = false;
    _module_functions[554].returns_gc_managed = false;
    _module_functions[554].requires_manual_free = false;
    _module_functions[554].returns_borrowed = false;
    _module_functions[554].cleanup_function = NULL;
    _module_functions[554].params = &_module_params[815];
    _module_params[815].name = "p";
    _module_params[815].type = 8;
    _module_params[815].struct_type_name = "Parser";
    _module_params[815].element_type = 21;
    _module_params[815].fn_sig = NULL;
    _module_params[816].name = "idx";
    _module_params[816].type = 0;
    _module_params[816].struct_type_name = NULL;
    _module_params[816].element_type = 21;
    _module_params[816].fn_sig = NULL;
    _module_params[817].name = "element_type";
    _module_params[817].type = 4;
    _module_params[817].struct_type_name = NULL;
    _module_params[817].element_type = 21;
    _module_params[817].fn_sig = NULL;

    /* Function: parser_get_array_element_count */
    _module_functions[555].name = "parser_get_array_element_count";
    _module_functions[555].param_count = 1;
    _module_functions[555].return_type = 0;
    _module_functions[555].return_struct_type_name = NULL;
    _module_functions[555].return_fn_sig = NULL;
    _module_functions[555].return_type_info = NULL;
    _module_functions[555].body = NULL;
    _module_functions[555].shadow_test = NULL;
    _module_functions[555].is_extern = false;
    _module_functions[555].returns_gc_managed = false;
    _module_functions[555].requires_manual_free = false;
    _module_functions[555].returns_borrowed = false;
    _module_functions[555].cleanup_function = NULL;
    _module_functions[555].params = &_module_params[818];
    _module_params[818].name = "p";
    _module_params[818].type = 8;
    _module_params[818].struct_type_name = "Parser";
    _module_params[818].element_type = 21;
    _module_params[818].fn_sig = NULL;

    /* Function: parser_get_array_element */
    _module_functions[556].name = "parser_get_array_element";
    _module_functions[556].param_count = 2;
    _module_functions[556].return_type = 8;
    _module_functions[556].return_struct_type_name = "ASTStmtRef";
    _module_functions[556].return_fn_sig = NULL;
    _module_functions[556].return_type_info = NULL;
    _module_functions[556].body = NULL;
    _module_functions[556].shadow_test = NULL;
    _module_functions[556].is_extern = false;
    _module_functions[556].returns_gc_managed = false;
    _module_functions[556].requires_manual_free = false;
    _module_functions[556].returns_borrowed = false;
    _module_functions[556].cleanup_function = NULL;
    _module_functions[556].params = &_module_params[819];
    _module_params[819].name = "p";
    _module_params[819].type = 8;
    _module_params[819].struct_type_name = "Parser";
    _module_params[819].element_type = 21;
    _module_params[819].fn_sig = NULL;
    _module_params[820].name = "idx";
    _module_params[820].type = 0;
    _module_params[820].struct_type_name = NULL;
    _module_params[820].element_type = 21;
    _module_params[820].fn_sig = NULL;

    /* Function: parser_get_struct_def_count */
    _module_functions[557].name = "parser_get_struct_def_count";
    _module_functions[557].param_count = 1;
    _module_functions[557].return_type = 0;
    _module_functions[557].return_struct_type_name = NULL;
    _module_functions[557].return_fn_sig = NULL;
    _module_functions[557].return_type_info = NULL;
    _module_functions[557].body = NULL;
    _module_functions[557].shadow_test = NULL;
    _module_functions[557].is_extern = false;
    _module_functions[557].returns_gc_managed = false;
    _module_functions[557].requires_manual_free = false;
    _module_functions[557].returns_borrowed = false;
    _module_functions[557].cleanup_function = NULL;
    _module_functions[557].params = &_module_params[821];
    _module_params[821].name = "p";
    _module_params[821].type = 8;
    _module_params[821].struct_type_name = "Parser";
    _module_params[821].element_type = 21;
    _module_params[821].fn_sig = NULL;

    /* Function: parser_get_struct_def */
    _module_functions[558].name = "parser_get_struct_def";
    _module_functions[558].param_count = 2;
    _module_functions[558].return_type = 8;
    _module_functions[558].return_struct_type_name = "ASTStruct";
    _module_functions[558].return_fn_sig = NULL;
    _module_functions[558].return_type_info = NULL;
    _module_functions[558].body = NULL;
    _module_functions[558].shadow_test = NULL;
    _module_functions[558].is_extern = false;
    _module_functions[558].returns_gc_managed = false;
    _module_functions[558].requires_manual_free = false;
    _module_functions[558].returns_borrowed = false;
    _module_functions[558].cleanup_function = NULL;
    _module_functions[558].params = &_module_params[822];
    _module_params[822].name = "p";
    _module_params[822].type = 8;
    _module_params[822].struct_type_name = "Parser";
    _module_params[822].element_type = 21;
    _module_params[822].fn_sig = NULL;
    _module_params[823].name = "idx";
    _module_params[823].type = 0;
    _module_params[823].struct_type_name = NULL;
    _module_params[823].element_type = 21;
    _module_params[823].fn_sig = NULL;

    /* Function: parser_get_struct_literal_count */
    _module_functions[559].name = "parser_get_struct_literal_count";
    _module_functions[559].param_count = 1;
    _module_functions[559].return_type = 0;
    _module_functions[559].return_struct_type_name = NULL;
    _module_functions[559].return_fn_sig = NULL;
    _module_functions[559].return_type_info = NULL;
    _module_functions[559].body = NULL;
    _module_functions[559].shadow_test = NULL;
    _module_functions[559].is_extern = false;
    _module_functions[559].returns_gc_managed = false;
    _module_functions[559].requires_manual_free = false;
    _module_functions[559].returns_borrowed = false;
    _module_functions[559].cleanup_function = NULL;
    _module_functions[559].params = &_module_params[824];
    _module_params[824].name = "p";
    _module_params[824].type = 8;
    _module_params[824].struct_type_name = "Parser";
    _module_params[824].element_type = 21;
    _module_params[824].fn_sig = NULL;

    /* Function: parser_get_struct_literal */
    _module_functions[560].name = "parser_get_struct_literal";
    _module_functions[560].param_count = 2;
    _module_functions[560].return_type = 8;
    _module_functions[560].return_struct_type_name = "ASTStructLiteral";
    _module_functions[560].return_fn_sig = NULL;
    _module_functions[560].return_type_info = NULL;
    _module_functions[560].body = NULL;
    _module_functions[560].shadow_test = NULL;
    _module_functions[560].is_extern = false;
    _module_functions[560].returns_gc_managed = false;
    _module_functions[560].requires_manual_free = false;
    _module_functions[560].returns_borrowed = false;
    _module_functions[560].cleanup_function = NULL;
    _module_functions[560].params = &_module_params[825];
    _module_params[825].name = "p";
    _module_params[825].type = 8;
    _module_params[825].struct_type_name = "Parser";
    _module_params[825].element_type = 21;
    _module_params[825].fn_sig = NULL;
    _module_params[826].name = "idx";
    _module_params[826].type = 0;
    _module_params[826].struct_type_name = NULL;
    _module_params[826].element_type = 21;
    _module_params[826].fn_sig = NULL;

    /* Function: parser_get_enum_count */
    _module_functions[561].name = "parser_get_enum_count";
    _module_functions[561].param_count = 1;
    _module_functions[561].return_type = 0;
    _module_functions[561].return_struct_type_name = NULL;
    _module_functions[561].return_fn_sig = NULL;
    _module_functions[561].return_type_info = NULL;
    _module_functions[561].body = NULL;
    _module_functions[561].shadow_test = NULL;
    _module_functions[561].is_extern = false;
    _module_functions[561].returns_gc_managed = false;
    _module_functions[561].requires_manual_free = false;
    _module_functions[561].returns_borrowed = false;
    _module_functions[561].cleanup_function = NULL;
    _module_functions[561].params = &_module_params[827];
    _module_params[827].name = "p";
    _module_params[827].type = 8;
    _module_params[827].struct_type_name = "Parser";
    _module_params[827].element_type = 21;
    _module_params[827].fn_sig = NULL;

    /* Function: parser_get_enum */
    _module_functions[562].name = "parser_get_enum";
    _module_functions[562].param_count = 2;
    _module_functions[562].return_type = 8;
    _module_functions[562].return_struct_type_name = "ASTEnum";
    _module_functions[562].return_fn_sig = NULL;
    _module_functions[562].return_type_info = NULL;
    _module_functions[562].body = NULL;
    _module_functions[562].shadow_test = NULL;
    _module_functions[562].is_extern = false;
    _module_functions[562].returns_gc_managed = false;
    _module_functions[562].requires_manual_free = false;
    _module_functions[562].returns_borrowed = false;
    _module_functions[562].cleanup_function = NULL;
    _module_functions[562].params = &_module_params[828];
    _module_params[828].name = "p";
    _module_params[828].type = 8;
    _module_params[828].struct_type_name = "Parser";
    _module_params[828].element_type = 21;
    _module_params[828].fn_sig = NULL;
    _module_params[829].name = "idx";
    _module_params[829].type = 0;
    _module_params[829].struct_type_name = NULL;
    _module_params[829].element_type = 21;
    _module_params[829].fn_sig = NULL;

    /* Function: parser_get_union_count */
    _module_functions[563].name = "parser_get_union_count";
    _module_functions[563].param_count = 1;
    _module_functions[563].return_type = 0;
    _module_functions[563].return_struct_type_name = NULL;
    _module_functions[563].return_fn_sig = NULL;
    _module_functions[563].return_type_info = NULL;
    _module_functions[563].body = NULL;
    _module_functions[563].shadow_test = NULL;
    _module_functions[563].is_extern = false;
    _module_functions[563].returns_gc_managed = false;
    _module_functions[563].requires_manual_free = false;
    _module_functions[563].returns_borrowed = false;
    _module_functions[563].cleanup_function = NULL;
    _module_functions[563].params = &_module_params[830];
    _module_params[830].name = "p";
    _module_params[830].type = 8;
    _module_params[830].struct_type_name = "Parser";
    _module_params[830].element_type = 21;
    _module_params[830].fn_sig = NULL;

    /* Function: parser_get_union */
    _module_functions[564].name = "parser_get_union";
    _module_functions[564].param_count = 2;
    _module_functions[564].return_type = 8;
    _module_functions[564].return_struct_type_name = "ASTUnion";
    _module_functions[564].return_fn_sig = NULL;
    _module_functions[564].return_type_info = NULL;
    _module_functions[564].body = NULL;
    _module_functions[564].shadow_test = NULL;
    _module_functions[564].is_extern = false;
    _module_functions[564].returns_gc_managed = false;
    _module_functions[564].requires_manual_free = false;
    _module_functions[564].returns_borrowed = false;
    _module_functions[564].cleanup_function = NULL;
    _module_functions[564].params = &_module_params[831];
    _module_params[831].name = "p";
    _module_params[831].type = 8;
    _module_params[831].struct_type_name = "Parser";
    _module_params[831].element_type = 21;
    _module_params[831].fn_sig = NULL;
    _module_params[832].name = "idx";
    _module_params[832].type = 0;
    _module_params[832].struct_type_name = NULL;
    _module_params[832].element_type = 21;
    _module_params[832].fn_sig = NULL;

    /* Function: parser_get_union_construct_count */
    _module_functions[565].name = "parser_get_union_construct_count";
    _module_functions[565].param_count = 1;
    _module_functions[565].return_type = 0;
    _module_functions[565].return_struct_type_name = NULL;
    _module_functions[565].return_fn_sig = NULL;
    _module_functions[565].return_type_info = NULL;
    _module_functions[565].body = NULL;
    _module_functions[565].shadow_test = NULL;
    _module_functions[565].is_extern = false;
    _module_functions[565].returns_gc_managed = false;
    _module_functions[565].requires_manual_free = false;
    _module_functions[565].returns_borrowed = false;
    _module_functions[565].cleanup_function = NULL;
    _module_functions[565].params = &_module_params[833];
    _module_params[833].name = "p";
    _module_params[833].type = 8;
    _module_params[833].struct_type_name = "Parser";
    _module_params[833].element_type = 21;
    _module_params[833].fn_sig = NULL;

    /* Function: parser_get_union_construct */
    _module_functions[566].name = "parser_get_union_construct";
    _module_functions[566].param_count = 2;
    _module_functions[566].return_type = 8;
    _module_functions[566].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[566].return_fn_sig = NULL;
    _module_functions[566].return_type_info = NULL;
    _module_functions[566].body = NULL;
    _module_functions[566].shadow_test = NULL;
    _module_functions[566].is_extern = false;
    _module_functions[566].returns_gc_managed = false;
    _module_functions[566].requires_manual_free = false;
    _module_functions[566].returns_borrowed = false;
    _module_functions[566].cleanup_function = NULL;
    _module_functions[566].params = &_module_params[834];
    _module_params[834].name = "p";
    _module_params[834].type = 8;
    _module_params[834].struct_type_name = "Parser";
    _module_params[834].element_type = 21;
    _module_params[834].fn_sig = NULL;
    _module_params[835].name = "idx";
    _module_params[835].type = 0;
    _module_params[835].struct_type_name = NULL;
    _module_params[835].element_type = 21;
    _module_params[835].fn_sig = NULL;

    /* Function: parser_get_match_count */
    _module_functions[567].name = "parser_get_match_count";
    _module_functions[567].param_count = 1;
    _module_functions[567].return_type = 0;
    _module_functions[567].return_struct_type_name = NULL;
    _module_functions[567].return_fn_sig = NULL;
    _module_functions[567].return_type_info = NULL;
    _module_functions[567].body = NULL;
    _module_functions[567].shadow_test = NULL;
    _module_functions[567].is_extern = false;
    _module_functions[567].returns_gc_managed = false;
    _module_functions[567].requires_manual_free = false;
    _module_functions[567].returns_borrowed = false;
    _module_functions[567].cleanup_function = NULL;
    _module_functions[567].params = &_module_params[836];
    _module_params[836].name = "p";
    _module_params[836].type = 8;
    _module_params[836].struct_type_name = "Parser";
    _module_params[836].element_type = 21;
    _module_params[836].fn_sig = NULL;

    /* Function: parser_get_match */
    _module_functions[568].name = "parser_get_match";
    _module_functions[568].param_count = 2;
    _module_functions[568].return_type = 8;
    _module_functions[568].return_struct_type_name = "ASTMatch";
    _module_functions[568].return_fn_sig = NULL;
    _module_functions[568].return_type_info = NULL;
    _module_functions[568].body = NULL;
    _module_functions[568].shadow_test = NULL;
    _module_functions[568].is_extern = false;
    _module_functions[568].returns_gc_managed = false;
    _module_functions[568].requires_manual_free = false;
    _module_functions[568].returns_borrowed = false;
    _module_functions[568].cleanup_function = NULL;
    _module_functions[568].params = &_module_params[837];
    _module_params[837].name = "p";
    _module_params[837].type = 8;
    _module_params[837].struct_type_name = "Parser";
    _module_params[837].element_type = 21;
    _module_params[837].fn_sig = NULL;
    _module_params[838].name = "idx";
    _module_params[838].type = 0;
    _module_params[838].struct_type_name = NULL;
    _module_params[838].element_type = 21;
    _module_params[838].fn_sig = NULL;

    /* Function: parser_get_tuple_literal_count */
    _module_functions[569].name = "parser_get_tuple_literal_count";
    _module_functions[569].param_count = 1;
    _module_functions[569].return_type = 0;
    _module_functions[569].return_struct_type_name = NULL;
    _module_functions[569].return_fn_sig = NULL;
    _module_functions[569].return_type_info = NULL;
    _module_functions[569].body = NULL;
    _module_functions[569].shadow_test = NULL;
    _module_functions[569].is_extern = false;
    _module_functions[569].returns_gc_managed = false;
    _module_functions[569].requires_manual_free = false;
    _module_functions[569].returns_borrowed = false;
    _module_functions[569].cleanup_function = NULL;
    _module_functions[569].params = &_module_params[839];
    _module_params[839].name = "p";
    _module_params[839].type = 8;
    _module_params[839].struct_type_name = "Parser";
    _module_params[839].element_type = 21;
    _module_params[839].fn_sig = NULL;

    /* Function: parser_get_tuple_literal */
    _module_functions[570].name = "parser_get_tuple_literal";
    _module_functions[570].param_count = 2;
    _module_functions[570].return_type = 8;
    _module_functions[570].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[570].return_fn_sig = NULL;
    _module_functions[570].return_type_info = NULL;
    _module_functions[570].body = NULL;
    _module_functions[570].shadow_test = NULL;
    _module_functions[570].is_extern = false;
    _module_functions[570].returns_gc_managed = false;
    _module_functions[570].requires_manual_free = false;
    _module_functions[570].returns_borrowed = false;
    _module_functions[570].cleanup_function = NULL;
    _module_functions[570].params = &_module_params[840];
    _module_params[840].name = "p";
    _module_params[840].type = 8;
    _module_params[840].struct_type_name = "Parser";
    _module_params[840].element_type = 21;
    _module_params[840].fn_sig = NULL;
    _module_params[841].name = "idx";
    _module_params[841].type = 0;
    _module_params[841].struct_type_name = NULL;
    _module_params[841].element_type = 21;
    _module_params[841].fn_sig = NULL;

    /* Function: parser_get_tuple_index_count */
    _module_functions[571].name = "parser_get_tuple_index_count";
    _module_functions[571].param_count = 1;
    _module_functions[571].return_type = 0;
    _module_functions[571].return_struct_type_name = NULL;
    _module_functions[571].return_fn_sig = NULL;
    _module_functions[571].return_type_info = NULL;
    _module_functions[571].body = NULL;
    _module_functions[571].shadow_test = NULL;
    _module_functions[571].is_extern = false;
    _module_functions[571].returns_gc_managed = false;
    _module_functions[571].requires_manual_free = false;
    _module_functions[571].returns_borrowed = false;
    _module_functions[571].cleanup_function = NULL;
    _module_functions[571].params = &_module_params[842];
    _module_params[842].name = "p";
    _module_params[842].type = 8;
    _module_params[842].struct_type_name = "Parser";
    _module_params[842].element_type = 21;
    _module_params[842].fn_sig = NULL;

    /* Function: parser_get_tuple_index */
    _module_functions[572].name = "parser_get_tuple_index";
    _module_functions[572].param_count = 2;
    _module_functions[572].return_type = 8;
    _module_functions[572].return_struct_type_name = "ASTTupleIndex";
    _module_functions[572].return_fn_sig = NULL;
    _module_functions[572].return_type_info = NULL;
    _module_functions[572].body = NULL;
    _module_functions[572].shadow_test = NULL;
    _module_functions[572].is_extern = false;
    _module_functions[572].returns_gc_managed = false;
    _module_functions[572].requires_manual_free = false;
    _module_functions[572].returns_borrowed = false;
    _module_functions[572].cleanup_function = NULL;
    _module_functions[572].params = &_module_params[843];
    _module_params[843].name = "p";
    _module_params[843].type = 8;
    _module_params[843].struct_type_name = "Parser";
    _module_params[843].element_type = 21;
    _module_params[843].fn_sig = NULL;
    _module_params[844].name = "idx";
    _module_params[844].type = 0;
    _module_params[844].struct_type_name = NULL;
    _module_params[844].element_type = 21;
    _module_params[844].fn_sig = NULL;

    /* Function: parser_get_service_count */
    _module_functions[573].name = "parser_get_service_count";
    _module_functions[573].param_count = 1;
    _module_functions[573].return_type = 0;
    _module_functions[573].return_struct_type_name = NULL;
    _module_functions[573].return_fn_sig = NULL;
    _module_functions[573].return_type_info = NULL;
    _module_functions[573].body = NULL;
    _module_functions[573].shadow_test = NULL;
    _module_functions[573].is_extern = false;
    _module_functions[573].returns_gc_managed = false;
    _module_functions[573].requires_manual_free = false;
    _module_functions[573].returns_borrowed = false;
    _module_functions[573].cleanup_function = NULL;
    _module_functions[573].params = &_module_params[845];
    _module_params[845].name = "p";
    _module_params[845].type = 8;
    _module_params[845].struct_type_name = "Parser";
    _module_params[845].element_type = 21;
    _module_params[845].fn_sig = NULL;

    /* Function: parser_get_service */
    _module_functions[574].name = "parser_get_service";
    _module_functions[574].param_count = 2;
    _module_functions[574].return_type = 8;
    _module_functions[574].return_struct_type_name = "ASTServiceDecl";
    _module_functions[574].return_fn_sig = NULL;
    _module_functions[574].return_type_info = NULL;
    _module_functions[574].body = NULL;
    _module_functions[574].shadow_test = NULL;
    _module_functions[574].is_extern = false;
    _module_functions[574].returns_gc_managed = false;
    _module_functions[574].requires_manual_free = false;
    _module_functions[574].returns_borrowed = false;
    _module_functions[574].cleanup_function = NULL;
    _module_functions[574].params = &_module_params[846];
    _module_params[846].name = "p";
    _module_params[846].type = 8;
    _module_params[846].struct_type_name = "Parser";
    _module_params[846].element_type = 21;
    _module_params[846].fn_sig = NULL;
    _module_params[847].name = "idx";
    _module_params[847].type = 0;
    _module_params[847].struct_type_name = NULL;
    _module_params[847].element_type = 21;
    _module_params[847].fn_sig = NULL;

    /* Function: parser_get_import_count */
    _module_functions[575].name = "parser_get_import_count";
    _module_functions[575].param_count = 1;
    _module_functions[575].return_type = 0;
    _module_functions[575].return_struct_type_name = NULL;
    _module_functions[575].return_fn_sig = NULL;
    _module_functions[575].return_type_info = NULL;
    _module_functions[575].body = NULL;
    _module_functions[575].shadow_test = NULL;
    _module_functions[575].is_extern = false;
    _module_functions[575].returns_gc_managed = false;
    _module_functions[575].requires_manual_free = false;
    _module_functions[575].returns_borrowed = false;
    _module_functions[575].cleanup_function = NULL;
    _module_functions[575].params = &_module_params[848];
    _module_params[848].name = "p";
    _module_params[848].type = 8;
    _module_params[848].struct_type_name = "Parser";
    _module_params[848].element_type = 21;
    _module_params[848].fn_sig = NULL;

    /* Function: parser_get_import */
    _module_functions[576].name = "parser_get_import";
    _module_functions[576].param_count = 2;
    _module_functions[576].return_type = 8;
    _module_functions[576].return_struct_type_name = "ASTImport";
    _module_functions[576].return_fn_sig = NULL;
    _module_functions[576].return_type_info = NULL;
    _module_functions[576].body = NULL;
    _module_functions[576].shadow_test = NULL;
    _module_functions[576].is_extern = false;
    _module_functions[576].returns_gc_managed = false;
    _module_functions[576].requires_manual_free = false;
    _module_functions[576].returns_borrowed = false;
    _module_functions[576].cleanup_function = NULL;
    _module_functions[576].params = &_module_params[849];
    _module_params[849].name = "p";
    _module_params[849].type = 8;
    _module_params[849].struct_type_name = "Parser";
    _module_params[849].element_type = 21;
    _module_params[849].fn_sig = NULL;
    _module_params[850].name = "idx";
    _module_params[850].type = 0;
    _module_params[850].struct_type_name = NULL;
    _module_params[850].element_type = 21;
    _module_params[850].fn_sig = NULL;

    /* Function: parse_phase_run */
    _module_functions[577].name = "parse_phase_run";
    _module_functions[577].param_count = 2;
    _module_functions[577].return_type = 8;
    _module_functions[577].return_struct_type_name = "ParsePhaseOutput";
    _module_functions[577].return_fn_sig = NULL;
    _module_functions[577].return_type_info = NULL;
    _module_functions[577].body = NULL;
    _module_functions[577].shadow_test = NULL;
    _module_functions[577].is_extern = false;
    _module_functions[577].returns_gc_managed = false;
    _module_functions[577].requires_manual_free = false;
    _module_functions[577].returns_borrowed = false;
    _module_functions[577].cleanup_function = NULL;
    _module_functions[577].params = &_module_params[851];
    _module_params[851].name = "lex_output";
    _module_params[851].type = 8;
    _module_params[851].struct_type_name = "LexPhaseOutput";
    _module_params[851].element_type = 21;
    _module_params[851].fn_sig = NULL;
    _module_params[852].name = "file_name";
    _module_params[852].type = 4;
    _module_params[852].struct_type_name = NULL;
    _module_params[852].element_type = 21;
    _module_params[852].fn_sig = NULL;

    /* Function: passive_reads */
    _module_functions[578].name = "passive_reads";
    _module_functions[578].param_count = 4;
    _module_functions[578].return_type = 3;
    _module_functions[578].return_struct_type_name = NULL;
    _module_functions[578].return_fn_sig = NULL;
    _module_functions[578].return_type_info = NULL;
    _module_functions[578].body = NULL;
    _module_functions[578].shadow_test = NULL;
    _module_functions[578].is_extern = false;
    _module_functions[578].returns_gc_managed = false;
    _module_functions[578].requires_manual_free = false;
    _module_functions[578].returns_borrowed = false;
    _module_functions[578].cleanup_function = NULL;
    _module_functions[578].params = &_module_params[853];
    _module_params[853].name = "parser";
    _module_params[853].type = 8;
    _module_params[853].struct_type_name = "Parser";
    _module_params[853].element_type = 21;
    _module_params[853].fn_sig = NULL;
    _module_params[854].name = "id";
    _module_params[854].type = 0;
    _module_params[854].struct_type_name = NULL;
    _module_params[854].element_type = 21;
    _module_params[854].fn_sig = NULL;
    _module_params[855].name = "kind";
    _module_params[855].type = 0;
    _module_params[855].struct_type_name = NULL;
    _module_params[855].element_type = 21;
    _module_params[855].fn_sig = NULL;
    _module_params[856].name = "name";
    _module_params[856].type = 4;
    _module_params[856].struct_type_name = NULL;
    _module_params[856].element_type = 21;
    _module_params[856].fn_sig = NULL;

    /* Function: passive_order */
    _module_functions[579].name = "passive_order";
    _module_functions[579].param_count = 2;
    _module_functions[579].return_type = 7;
    _module_functions[579].return_struct_type_name = NULL;
    _module_functions[579].return_fn_sig = NULL;
    _module_functions[579].return_type_info = &_type_infos[39];
    _module_functions[579].body = NULL;
    _module_functions[579].shadow_test = NULL;
    _module_functions[579].is_extern = false;
    _module_functions[579].returns_gc_managed = false;
    _module_functions[579].requires_manual_free = false;
    _module_functions[579].returns_borrowed = false;
    _module_functions[579].cleanup_function = NULL;
    _module_functions[579].params = &_module_params[857];
    _module_params[857].name = "parser";
    _module_params[857].type = 8;
    _module_params[857].struct_type_name = "Parser";
    _module_params[857].element_type = 21;
    _module_params[857].fn_sig = NULL;
    _module_params[858].name = "block";
    _module_params[858].type = 8;
    _module_params[858].struct_type_name = "ASTBlock";
    _module_params[858].element_type = 21;
    _module_params[858].fn_sig = NULL;

}

ModuleMetadata _module_metadata_passive_graph = {
    .module_name = "passive_graph",
    .function_count = 580,
    .functions = _module_functions,
    .struct_count = 53,
    .structs = NULL,  /* TODO: serialize structs */
    .enum_count = 5,
    .enums = NULL,  /* TODO: serialize enums */
    .union_count = 0,
    .unions = NULL  /* TODO: serialize unions */
};

/* Constants from module */
static const int64_t _module_const_passive_graph_length = 281474859135920LL;
static const int64_t _module_const_passive_graph_code = 7738436698542336372LL;
static const int64_t _module_const_passive_graph_line = 0LL;
static const int64_t _module_const_passive_graph_column = 0LL;
static const int64_t _module_const_passive_graph_phase = 0LL;
static const int64_t _module_const_passive_graph_severity = 0LL;
static const int64_t _module_const_passive_graph_index = 0LL;
static const int64_t _module_const_passive_graph_count = 205191309775824LL;
static const int64_t _module_const_passive_graph_pi = 0LL;
static const int64_t _module_const_passive_graph_ti = 0LL;
static const int64_t _module_const_passive_graph_plen = 281474859135904LL;
static const int64_t _module_const_passive_graph_tlen = 281474859135904LL;
static const int64_t _module_const_passive_graph_pc = 281474859135904LL;
static const int64_t _module_const_passive_graph_n = 281474859135904LL;
static const int64_t _module_const_passive_graph_c = 0LL;
static const int64_t _module_const_passive_graph_t1 = 205191329915424LL;
static const int64_t _module_const_passive_graph_t2 = 281474859138336LL;
static const int64_t _module_const_passive_graph_t3 = 205191332099856LL;
static const int64_t _module_const_passive_graph_t4 = 16LL;
static const int64_t _module_const_passive_graph_t5 = 205191329887600LL;
static const int64_t _module_const_passive_graph_token_type = 0LL;
static const int64_t _module_const_passive_graph_i = 0LL;
static const int64_t _module_const_passive_graph_len = 0LL;
static const int64_t _module_const_passive_graph_start = 274120844928752LL;
static const int64_t _module_const_passive_graph_str_length = 16LL;
static const int64_t _module_const_passive_graph_float_length = 32LL;
static const int64_t _module_const_passive_graph_num_length = 16LL;
static const int64_t _module_const_passive_graph_body_start = 274120844928752LL;
static const int64_t _module_const_passive_graph_body_len = 274120844928752LL;
static const int64_t _module_const_passive_graph_id_length = 274120844928752LL;
static const int64_t _module_const_passive_graph_esc = 0LL;
static const int64_t _module_const_passive_graph_is_expr = 0LL;
static const int64_t _module_const_passive_graph_expr_start = 281474859133152LL;
static const int64_t _module_const_passive_graph_cc = 281474859131344LL;
static const int64_t _module_const_passive_graph_last_is_expr = 0LL;
static const int64_t _module_const_passive_graph_token_count = 0LL;
static const int64_t _module_const_passive_graph_id = 205191332099856LL;
static const int64_t _module_const_passive_graph_new_position = 0LL;
static const int64_t _module_const_passive_graph_offset = 0LL;
static const int64_t _module_const_passive_graph_peek_pos = 205191332099856LL;
static const int64_t _module_const_passive_graph_node_id = 205191332099856LL;
static const int64_t _module_const_passive_graph_op = 0LL;
static const int64_t _module_const_passive_graph_left_id = 0LL;
static const int64_t _module_const_passive_graph_right_id = 0LL;
static const int64_t _module_const_passive_graph_left_type = 0LL;
static const int64_t _module_const_passive_graph_right_type = 0LL;
static const int64_t _module_const_passive_graph_function_id = 0LL;
static const int64_t _module_const_passive_graph_function_type = 0LL;
static const int64_t _module_const_passive_graph_arg_start = 0LL;
static const int64_t _module_const_passive_graph_arg_count = 0LL;
static const int64_t _module_const_passive_graph_node_type = 0LL;
static const int64_t _module_const_passive_graph_start_line = 0LL;
static const int64_t _module_const_passive_graph_start_column = 0LL;
static const int64_t _module_const_passive_graph_cond_id = 158LL;
static const int64_t _module_const_passive_graph_cond_type = 158LL;
static const int64_t _module_const_passive_graph_val_id = 158LL;
static const int64_t _module_const_passive_graph_val_type = 158LL;
static const int64_t _module_const_passive_graph_else_id = 158LL;
static const int64_t _module_const_passive_graph_else_type = 158LL;
static const int64_t _module_const_passive_graph_then_id = 158LL;
static const int64_t _module_const_passive_graph_else_block_id = 158LL;
static const int64_t _module_const_passive_graph_arm = 0LL;
static const int64_t _module_const_passive_graph_scrutinee_id = 158LL;
static const int64_t _module_const_passive_graph_scrutinee_type = 158LL;
static const int64_t _module_const_passive_graph_guard_id = 0LL;
static const int64_t _module_const_passive_graph_guard_type = 0LL;
static const int64_t _module_const_passive_graph_first = 0LL;
static const int64_t _module_const_passive_graph_zero_id = 0LL;
static const int64_t _module_const_passive_graph_elem_id = 158LL;
static const int64_t _module_const_passive_graph_elem_type = 158LL;
static const int64_t _module_const_passive_graph_func_id = 158LL;
static const int64_t _module_const_passive_graph_str_id = 158LL;
static const int64_t _module_const_passive_graph_str_type = 158LL;
static const int64_t _module_const_passive_graph_first_char = 0LL;
static const int64_t _module_const_passive_graph_op_type = 0LL;
static const int64_t _module_const_passive_graph_zero_type = 0LL;
static const int64_t _module_const_passive_graph_arg_id = 158LL;
static const int64_t _module_const_passive_graph_arg_type = 158LL;
static const int64_t _module_const_passive_graph_param_start = 158LL;
static const int64_t _module_const_passive_graph_param_count = 158LL;
static const int64_t _module_const_passive_graph_body_id = 158LL;
static const int64_t _module_const_passive_graph_idx = 0LL;
static const int64_t _module_const_passive_graph_obj_id = 0LL;
static const int64_t _module_const_passive_graph_obj_type = 0LL;
static const int64_t _module_const_passive_graph_lhs_id = 158LL;
static const int64_t _module_const_passive_graph_lhs_type = 158LL;
static const int64_t _module_const_passive_graph_inner_id = 158LL;
static const int64_t _module_const_passive_graph_inner_type = 158LL;
static const int64_t _module_const_passive_graph_try_func_id = 158LL;
static const int64_t _module_const_passive_graph_value_id = 0LL;
static const int64_t _module_const_passive_graph_value_type = 0LL;
static const int64_t _module_const_passive_graph_condition_id = 0LL;
static const int64_t _module_const_passive_graph_condition_type = 0LL;
static const int64_t _module_const_passive_graph_then_body_id = 0LL;
static const int64_t _module_const_passive_graph_else_body_id = 0LL;
static const int64_t _module_const_passive_graph_iterable_id = 0LL;
static const int64_t _module_const_passive_graph_iterable_type = 0LL;
static const int64_t _module_const_passive_graph_element_start = 0LL;
static const int64_t _module_const_passive_graph_element_count = 0LL;
static const int64_t _module_const_passive_graph_import_symbol_count = 0LL;
static const int64_t _module_const_passive_graph_interface_bytes = 0LL;
static const int64_t _module_const_passive_graph_path_bytes = 0LL;
static const int64_t _module_const_passive_graph_object_id = 0LL;
static const int64_t _module_const_passive_graph_object_type = 0LL;
static const int64_t _module_const_passive_graph_if_id = 0LL;
static const int64_t _module_const_passive_graph_kind = 0LL;
static const int64_t _module_const_passive_graph_owner_id = 205191332099856LL;
static const int64_t _module_const_passive_graph_field_id = 16LL;
static const int64_t _module_const_passive_graph_expr_id = 158LL;
static const int64_t _module_const_passive_graph_expr_type = 158LL;
static const int64_t _module_const_passive_graph_temp_let_id = 158LL;
static const int64_t _module_const_passive_graph_temp_ref_id = 16LL;
static const int64_t _module_const_passive_graph_temp_ref_type = 16LL;
static const int64_t _module_const_passive_graph_idx_id = 16LL;
static const int64_t _module_const_passive_graph_idx_type = 16LL;
static const int64_t _module_const_passive_graph_binding_let_id = 16LL;
static const int64_t _module_const_passive_graph_field_count = 0LL;
static const int64_t _module_const_passive_graph_variant_count = 0LL;
static const int64_t _module_const_passive_graph_generic_param_count = 0LL;
static const int64_t _module_const_passive_graph_arm_count = 0LL;
static const int64_t _module_const_passive_graph_tuple_id = 0LL;
static const int64_t _module_const_passive_graph_tuple_type = 0LL;
static const int64_t _module_const_passive_graph_assert_id = 158LL;
static const int64_t _module_const_passive_graph_body_stmts_count = 158LL;
static const int64_t _module_const_passive_graph_next_value = 0LL;
static const int64_t _module_const_passive_graph_size = 205191332099856LL;
static const int64_t _module_const_passive_graph_lead_code = 11LL;
static const int64_t _module_const_passive_graph_continuation = 205191308543872LL;
static const int64_t _module_const_passive_graph_interface_size = 205191332099856LL;
static const int64_t _module_const_passive_graph_path_size = 205191332099856LL;
static const int64_t _module_const_passive_graph_capture_limit = 0LL;
static const int64_t _module_const_passive_graph_before_pos = 0LL;

