#define _GNU_SOURCE 1
#define _DARWIN_C_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <math.h>
#include "runtime/nl_string.h"
#ifdef __wasm__
#  include "runtime/refcount_gc.h"
#  define gc_alloc_string(len)   nl_rc_str_new(NULL, (len))
#  define gc_retain(p)           nl_rc_retain(p)
#  define gc_release(p)          nl_rc_release(p)
#else
#  include "runtime/gc.h"
#endif
#include "runtime/dyn_array.h"
#include "runtime/native_array_abi.h"
#ifndef __wasm__
#  include "nanolang.h"
#endif

/* nanolang runtime */
#include "runtime/list_int.h"
#include "runtime/native_record_list.h"
#include "runtime/list_string.h"
#include "runtime/list_token.h"
#include "runtime/token_helpers.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <libgen.h>
#include <sys/wait.h>
#include <spawn.h>
#include <fcntl.h>
/* fs.h forward declarations */
DynArray* fs_walkdir(const char* root);
const char* path_normalize(const char* path);
const char* path_join(const char* a, const char* b);
const char* path_basename(const char* path);
const char* path_dirname(const char* path);
int64_t  fs_mkdir_p(const char* path);
const char* path_relpath(const char* target, const char* base);
const char* file_read(const char* path);
int64_t  file_write(const char* path, const char* content);
int64_t  file_append(const char* path, const char* content);
bool     file_exists(const char* path);
int64_t  file_delete(const char* path);
int64_t  file_copy(const char* src, const char* dst);
int64_t  dir_copy(const char* src, const char* dst);
int64_t  nl_os_process_spawn(const char* command);
int64_t  nl_os_process_is_running(int64_t pid);
int64_t  nl_os_process_wait(int64_t pid);
DynArray* nl_os_process_spawn_with_pipes(const char* command);
const char* nl_os_fd_read_available(int64_t fd);
int64_t  nl_os_fd_close(int64_t fd);

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-const-variable"

/* ========== OS Standard Library ========== */

#include "runtime/file_text.h"
static const char* nl_os_file_read(const char* path) {
    char* text = nl_read_file_text(path);
    if (!text) return gc_alloc_string(0);
    size_t length = strlen(text);
    char* result = gc_alloc_string(length);
    if (result) memcpy(result, text, length + 1);
    free(text);
    return result;
}

#include "runtime/file_bytes.h"
static DynArray* nl_os_file_read_bytes(const char* path) {
    return nl_read_file_bytes(path);
}

#include "runtime/file_write.h"
static int64_t nl_os_file_write(const char* path, const char* content) {
    return nl_write_file_text(path, content, "w");
}

static int64_t nl_os_file_append(const char* path, const char* content) {
    return nl_write_file_text(path, content, "a");
}

static int64_t nl_os_file_remove(const char* path) {
    return remove(path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_delete(const char* path) {
    return nl_os_file_remove(path);
}

static int64_t nl_os_file_rename(const char* old_path, const char* new_path) {
    return rename(old_path, new_path) == 0 ? 0 : -1;
}

static int64_t nl_os_file_size(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (int64_t)st.st_size;
}

static bool nl_os_file_exists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static char* nl_os_tmp_dir(void) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    size_t len = strlen(tmp);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, tmp, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_";
    char templ[1024];
    snprintf(templ, sizeof(templ), "%s/%sXXXXXX", tmp, p);
    int fd = mkstemp(templ);
    if (fd < 0) return gc_alloc_string(0);
    close(fd);
    size_t len = strlen(templ);
    char* out = gc_alloc_string(len);
    if (!out) return gc_alloc_string(0);
    memcpy(out, templ, len);
    out[len] = '\0';
    return out;
}

static char* nl_os_mktemp_dir(const char* prefix) {
    const char* tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    const char* p = (prefix && prefix[0]) ? prefix : "nanolang_dir_";
    char path[1024];
    for (int i = 0; i < 100; i++) {
        snprintf(path, sizeof(path), "%s/%s%lld_%d", tmp, p, (long long)time(NULL), i);
        if (mkdir(path, 0700) == 0) {
            size_t len = strlen(path);
            char* out = gc_alloc_string(len);
            if (!out) return gc_alloc_string(0);
            memcpy(out, path, len);
            out[len] = '\0';
            return out;
        }
    }
    return gc_alloc_string(0);
}

static int64_t nl_os_dir_create(const char* path) {
    return mkdir(path, 0755) == 0 ? 0 : -1;
}

static int64_t nl_os_dir_remove(const char* path) {
    return rmdir(path) == 0 ? 0 : -1;
}

static char* nl_os_dir_list(const char* path) {
    DIR* dir = opendir(path);
    if (!dir) return gc_alloc_string(0);
    size_t capacity = 4096;
    size_t used = 0;
    char* buffer = gc_alloc_string(capacity);
    if (!buffer) { closedir(dir); return gc_alloc_string(0); }
    buffer[0] = '\0';
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        size_t name_len = strlen(entry->d_name);
        size_t needed = used + name_len + 2; /* +1 for newline, +1 for null */
        if (needed > capacity) {
            capacity = needed * 2;
            char* new_buffer = gc_alloc_string(capacity);
            if (!new_buffer) { gc_release(buffer); closedir(dir); return gc_alloc_string(0); }
            memcpy(new_buffer, buffer, used);
            gc_release(buffer);
            buffer = new_buffer;
        }
        memcpy(buffer + used, entry->d_name, name_len);
        used += name_len;
        buffer[used++] = '\n';
        buffer[used] = '\0';
    }
    closedir(dir);
    return buffer;
}

static bool nl_os_dir_exists(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_getcwd(void) {
    char temp_buffer[1024];
    if (getcwd(temp_buffer, sizeof(temp_buffer)) == NULL) {
        return gc_alloc_string(0);
    }
    size_t len = strlen(temp_buffer);
    char* buffer = gc_alloc_string(len);
    if (buffer) memcpy(buffer, temp_buffer, len + 1);
    return buffer ? buffer : gc_alloc_string(0);
}

static int64_t nl_os_chdir(const char* path) {
    return chdir(path) == 0 ? 0 : -1;
}

#include "runtime/directory_walk.h"
static DynArray* nl_os_walkdir(const char* root) {
    return nl_fs_walkdir(root);
}

static bool nl_os_path_isfile(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISREG(st.st_mode);
}

static bool nl_os_path_isdir(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) return false;
    return S_ISDIR(st.st_mode);
}

static char* nl_os_path_join(const char* a, const char* b) {
    size_t len_a = strlen(a);
    size_t len_b = strlen(b);
    size_t total_len = len_a + len_b + 2; /* +1 for '/', +1 for null */
    char* buffer = gc_alloc_string(total_len);
    if (!buffer) return gc_alloc_string(0);
    if (len_a == 0) {
        snprintf(buffer, total_len, "%s", b);
    } else if (a[len_a - 1] == '/') {
        snprintf(buffer, total_len, "%s%s", a, b);
    } else {
        snprintf(buffer, total_len, "%s/%s", a, b);
    }
    return buffer;
}

static char* nl_os_path_basename(const char* path) {
    char* path_copy = strdup(path);
    char* base = basename(path_copy);
    size_t len = strlen(base);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, base, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

static char* nl_os_path_dirname(const char* path) {
    char* path_copy = strdup(path);
    char* dir = dirname(path_copy);
    size_t len = strlen(dir);
    char* result = gc_alloc_string(len);
    if (result) memcpy(result, dir, len + 1);
    free(path_copy);
    return result ? result : gc_alloc_string(0);
}

#include "runtime/path_normalize.h"
static char* nl_os_path_normalize(const char* path) {
    if (!path) return gc_alloc_string(0);
    char* normalized = nl_normalize_path(path);
    if (!normalized) return gc_alloc_string(0);
    size_t length = strlen(normalized);
    char* out = gc_alloc_string(length);
    if (out) memcpy(out, normalized, length + 1);
    free(normalized);
    return out ? out : gc_alloc_string(0);
}

static int64_t nl_os_system(const char* command) {
    return system(command);
}

static void nl_os_exit(int64_t code) {
    exit((int)code);
}

static const char* nl_os_getenv(const char* name) {
    const char* value = getenv(name);
    return value ? value : "";
}

/* system() wrapper - stdlib system() available via stdlib.h */
static inline int64_t nl_exec_shell(const char* cmd) {
    return (int64_t)system(cmd);
}

/* isatty() wrapper - avoids int64_t type clash with unistd.h */
static inline int64_t nl_isatty(int64_t fd) {
    return (int64_t)isatty((int)fd);
}

/* Capture stdout from a shell command */
static inline const char* nl_exec_capture(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return "";
    char* out = (char*)malloc(65536);
    if (!out) { pclose(pipe); return ""; }
    size_t total = 0;
    while (total < 65535) {
        size_t n = fread(out + total, 1, 65535 - total, pipe);
        if (n == 0) break;
        total += n;
    }
    out[total] = '\0';
    pclose(pipe);
    return out;
}

#include "runtime/process_capture.h"
#ifndef NANOLANG_STD_PROCESS_H
static DynArray* nl_os_process_run(const char* command) {
    return nl_process_run_capture(command);
}
#endif /* NANOLANG_STD_PROCESS_H */

/* ========== End OS Standard Library ========== */

/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Advanced String Operations ========== */

static int64_t char_at(const char* s, int64_t index) {
    /* Safety: Bound string scan to 64MB */
    int len = strnlen(s, 64*1024*1024);
    if (index < 0 || index >= len) {
        fprintf(stderr, "Error: Index %lld out of bounds (string length %d)\n", (long long)index, len);
        return 0;
    }
    return (unsigned char)s[index];
}

static char* string_from_char(int64_t c) {
    char* buffer = gc_alloc_string(1);
    if (!buffer) return "";
    buffer[0] = (char)c;
    buffer[1] = '\0';
    return buffer;
}

static bool is_digit(int64_t c) {
    return c >= '0' && c <= '9';
}

static bool is_alpha(int64_t c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_alnum(int64_t c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool is_whitespace(int64_t c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

static bool is_upper(int64_t c) {
    return c >= 'A' && c <= 'Z';
}

static bool is_lower(int64_t c) {
    return c >= 'a' && c <= 'z';
}

static char* int_to_string(int64_t n) {
    char* buffer = gc_alloc_string(31);
    if (!buffer) return "";
    snprintf(buffer, 32, "%lld", (long long)n);
    return buffer;
}

static char* float_to_string(double x) {
    char* buffer = gc_alloc_string(63);
    if (!buffer) return "";
    nano_rt_f64_format(buffer, 64, x);
    /* Ensure at least one decimal place for whole-number floats
     * so 0.0 -> "0.0" rather than "0" */
    if (!strchr(buffer, '.') && !strchr(buffer, 'e')
            && !strchr(buffer, 'n') && !strchr(buffer, 'i')) {
        size_t len = strlen(buffer);
        if (len + 2 < 64) { buffer[len] = '.'; buffer[len+1] = '0'; buffer[len+2] = '\0'; }
    }
    return buffer;
}

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} nl_fmt_sb_t;

static void nl_fmt_sb_ensure(nl_fmt_sb_t *sb, size_t extra) {
    if (!sb) return;
    size_t needed = sb->len + extra + 1;
    if (needed <= sb->cap) return;
    size_t new_cap = sb->cap ? sb->cap : 128;
    while (new_cap < needed) new_cap *= 2;
    char *new_buf = realloc(sb->buf, new_cap);
    if (!new_buf) return;
    sb->buf = new_buf;
    sb->cap = new_cap;
}

static nl_fmt_sb_t nl_fmt_sb_new(size_t initial_cap) {
    nl_fmt_sb_t sb = {0};
    sb.cap = initial_cap ? initial_cap : 128;
    sb.buf = (char*)malloc(sb.cap);
    sb.len = 0;
    if (sb.buf) sb.buf[0] = '\0';
    return sb;
}

static void nl_fmt_sb_append_cstr(nl_fmt_sb_t *sb, const char *s) {
    if (!sb || !s) return;
    size_t n = strlen(s);
    nl_fmt_sb_ensure(sb, n);
    if (!sb->buf) return;
    memcpy(sb->buf + sb->len, s, n);
    sb->len += n;
    sb->buf[sb->len] = '\0';
}

static void nl_fmt_sb_append_char(nl_fmt_sb_t *sb, char c) {
    if (!sb) return;
    nl_fmt_sb_ensure(sb, 1);
    if (!sb->buf) return;
    sb->buf[sb->len++] = c;
    sb->buf[sb->len] = '\0';
}

static char* nl_fmt_sb_build(nl_fmt_sb_t *sb) {
    if (!sb || !sb->buf) return "";
    return sb->buf;
}

static const char* nl_to_string_int(int64_t v) { return int_to_string(v); }
static const char* nl_to_string_float(double v) { return float_to_string(v); }
static const char* nl_to_string_bool(bool v) { return v ? "true" : "false"; }
static const char* nl_to_string_string(const char* v) { return v ? v : ""; }

static const char* nl_to_string_array(DynArray* arr) {
    if (!arr) return "[]";
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_char(&sb, '[');
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    for (int64_t i = 0; i < len; i++) {
        if (i > 0) nl_fmt_sb_append_cstr(&sb, ", ");
        switch (t) {
            case ELEM_INT: {
                const char* s = nl_to_string_int(dyn_array_get_int(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_U8: {
                const char* s = nl_to_string_int((int64_t)dyn_array_get_u8(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_FLOAT: {
                const char* s = nl_to_string_float(dyn_array_get_float(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_BOOL: {
                nl_fmt_sb_append_cstr(&sb, nl_to_string_bool(dyn_array_get_bool(arr, i)));
                break;
            }
            case ELEM_STRING: {
                nl_fmt_sb_append_char(&sb, '"');
                nl_fmt_sb_append_cstr(&sb, nl_to_string_string(dyn_array_get_string(arr, i)));
                nl_fmt_sb_append_char(&sb, '"');
                break;
            }
            case ELEM_ARRAY: {
                const char* s = nl_to_string_array(dyn_array_get_array(arr, i));
                nl_fmt_sb_append_cstr(&sb, s);
                break;
            }
            case ELEM_STRUCT: {
                nl_fmt_sb_append_cstr(&sb, "<struct>");
                break;
            }
            default: {
                nl_fmt_sb_append_cstr(&sb, "?");
                break;
            }
        }
    }
    nl_fmt_sb_append_char(&sb, ']');
    return nl_fmt_sb_build(&sb);
}

static const char* nl_str_concat(const char* s1, const char* s2);
static DynArray* nl_array_add(DynArray* a, DynArray* b);
static DynArray* nl_array_sub(DynArray* a, DynArray* b);
static DynArray* nl_array_mul(DynArray* a, DynArray* b);
static DynArray* nl_array_div(DynArray* a, DynArray* b);
static DynArray* nl_array_mod(DynArray* a, DynArray* b);

static void nl_array_assert_compatible(DynArray* a, DynArray* b) {
    assert(a && b);
    assert(dyn_array_length(a) == dyn_array_length(b));
    assert(dyn_array_get_elem_type(a) == dyn_array_get_elem_type(b));
}

static DynArray* nl_array_add(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)+dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_STRING: for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), dyn_array_get_string(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_add(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_add: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_sub(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)-dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_sub(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_sub: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mul(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)*dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mul(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mul: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_div(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)/dyn_array_get_int(b,i)); break;
        case ELEM_FLOAT: for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), dyn_array_get_float(b,i))); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_div(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_div: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_mod(DynArray* a, DynArray* b) {
    nl_array_assert_compatible(a, b);
    ElementType t = dyn_array_get_elem_type(a);
    int64_t len = dyn_array_length(a);
    DynArray* out = dyn_array_new(t);
    switch (t) {
        case ELEM_INT: for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i)%dyn_array_get_int(b,i)); break;
        case ELEM_ARRAY: for (int64_t i=0;i<len;i++) dyn_array_push_array(out, nl_array_mod(dyn_array_get_array(a,i), dyn_array_get_array(b,i))); break;
        default: assert(false && "nl_array_mod: unsupported element type");
    }
    return out;
}

static DynArray* nl_array_add_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) + s);
    return out;
}

static DynArray* nl_array_radd_scalar_int(int64_t s, DynArray* a) { return nl_array_add_scalar_int(a, s); }

static DynArray* nl_array_sub_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) - s);
    return out;
}

static DynArray* nl_array_rsub_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s - dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mul_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) * s);
    return out;
}

static DynArray* nl_array_rmul_scalar_int(int64_t s, DynArray* a) { return nl_array_mul_scalar_int(a, s); }

static DynArray* nl_array_div_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) / s);
    return out;
}

static DynArray* nl_array_rdiv_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s / dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_mod_scalar_int(DynArray* a, int64_t s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, dyn_array_get_int(a,i) % s);
    return out;
}

static DynArray* nl_array_rmod_scalar_int(int64_t s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_INT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_INT);
    for (int64_t i=0;i<len;i++) dyn_array_push_int(out, s % dyn_array_get_int(a,i));
    return out;
}

static DynArray* nl_array_add_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_add(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_float(double s, DynArray* a) { return nl_array_add_scalar_float(a, s); }

static DynArray* nl_array_sub_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rsub_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_sub(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_mul_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_mul(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rmul_scalar_float(double s, DynArray* a) { return nl_array_mul_scalar_float(a, s); }

static DynArray* nl_array_div_scalar_float(DynArray* a, double s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(dyn_array_get_float(a,i), s));
    return out;
}

static DynArray* nl_array_rdiv_scalar_float(double s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_FLOAT);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_FLOAT);
    for (int64_t i=0;i<len;i++) dyn_array_push_float(out, nano_rt_f64_div(s, dyn_array_get_float(a,i)));
    return out;
}

static DynArray* nl_array_add_scalar_string(DynArray* a, const char* s) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(dyn_array_get_string(a,i), s));
    return out;
}

static DynArray* nl_array_radd_scalar_string(const char* s, DynArray* a) {
    assert(a); assert(dyn_array_get_elem_type(a) == ELEM_STRING);
    int64_t len = dyn_array_length(a); DynArray* out = dyn_array_new(ELEM_STRING);
    for (int64_t i=0;i<len;i++) dyn_array_push_string(out, nl_str_concat(s, dyn_array_get_string(a,i)));
    return out;
}

static int64_t string_to_int(const char* s) {
    return strtoll(s, NULL, 10);
}

#include "runtime/binary64_parse.h"
static double string_to_float(const char* s) { return nl_binary64_prefix(s); }

static int64_t digit_value(int64_t c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    return -1;
}

static int64_t char_to_lower(int64_t c) {
    if (c >= 'A' && c <= 'Z') {
    return c + 32;
    }
    return c;
}

static int64_t char_to_upper(int64_t c) {
    if (c >= 'a' && c <= 'z') {
        return c - 32;
    }
    return c;
}

#include "runtime/string_edges.h"
static const char* nl_str_trim_left(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t start = 0;
    while (start < len && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n' || s[start] == '\r')) start++;
    size_t new_len = len - start;
    char* result = gc_alloc_string(new_len);
    if (!result) return "";
    memcpy(result, s + start, new_len);
    result[new_len] = '\0';
    return result;
}

static const char* nl_str_trim_right(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    size_t end = len;
    while (end > 0 && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n' || s[end-1] == '\r')) end--;
    char* result = gc_alloc_string(end);
    if (!result) return "";
    memcpy(result, s, end);
    result[end] = '\0';
    return result;
}

static const char* nl_str_to_lower(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_to_upper(const char* s) {
    if (!s) return "";
    size_t len = strnlen(s, 64*1024*1024);
    char* result = gc_alloc_string(len);
    if (!result) return "";
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)s[i];
        result[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : (char)c;
    }
    result[len] = '\0';
    return result;
}

static const char* nl_str_replace(const char* s, const char* old_str, const char* new_str) {
    if (!s || !old_str || !new_str) return s ? s : "";
    size_t old_len = strlen(old_str);
    size_t s_len = strlen(s);
    if (old_len == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    size_t new_len = strlen(new_str);
    int64_t count = 0;
    const char* p = s;
    const char* found;
    while ((found = strstr(p, old_str)) != NULL) { count++; p = found + old_len; }
    if (count == 0) {
        char* copy = gc_alloc_string(s_len);
        if (!copy) return s;
        memcpy(copy, s, s_len + 1);
        return copy;
    }
    int64_t result_len = (int64_t)s_len + count * ((int64_t)new_len - (int64_t)old_len);
    if (result_len < 0) return "";
    char* result = gc_alloc_string((size_t)result_len);
    if (!result) return "";
    const char* src = s;
    char* dst = result;
    while ((found = strstr(src, old_str)) != NULL) {
        size_t seg_len = (size_t)(found - src);
        memcpy(dst, src, seg_len);
        dst += seg_len;
        memcpy(dst, new_str, new_len);
        dst += new_len;
        src = found + old_len;
    }
    size_t rest = strlen(src);
    memcpy(dst, src, rest);
    dst[rest] = '\0';
    return result;
}

static DynArray* nl_str_split(const char* str, const char* delim) {
    DynArray* result = dyn_array_new(ELEM_STRING);
    if (!result) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    if (!str) return result;
    size_t delim_len = strlen(delim);
    if (delim_len == 0) {
        size_t str_len = strnlen(str, 64*1024*1024);
        for (size_t i = 0; i < str_len; i++) {
            char* ch = gc_alloc_string(1);
            if (!ch) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
            ch[0] = str[i]; ch[1] = '\0';
            dyn_array_push_string(result, ch);
        }
        return result;
    }
    const char* start = str;
    const char* found;
    while ((found = strstr(start, delim)) != NULL) {
        size_t seg_len = (size_t)(found - start);
        char* seg = gc_alloc_string(seg_len);
        if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
        memcpy(seg, start, seg_len);
        seg[seg_len] = '\0';
        dyn_array_push_string(result, seg);
        start = found + delim_len;
    }
    size_t rest_len = strlen(start);
    char* seg = gc_alloc_string(rest_len);
    if (!seg) { fprintf(stderr, "I cannot allocate a complete split-string result.\n"); abort(); }
    {
        memcpy(seg, start, rest_len);
        seg[rest_len] = '\0';
        dyn_array_push_string(result, seg);
    }
    return result;
}

static const char* nl_str_join(DynArray* arr, const char* delim) {
    if (!arr) return "";
    int64_t count = dyn_array_length(arr);
    if (count == 0) return "";
    size_t delim_len = strlen(delim);
    size_t total = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) total += strlen(s);
        if (i < count - 1) total += delim_len;
    }
    char* result = gc_alloc_string(total);
    if (!result) return "";
    size_t pos = 0;
    for (int64_t i = 0; i < count; i++) {
        const char* s = dyn_array_get_string(arr, i);
        if (s) { size_t slen = strlen(s); memcpy(result + pos, s, slen); pos += slen; }
        if (i < count - 1) { memcpy(result + pos, delim, delim_len); pos += delim_len; }
    }
    result[pos] = '\0';
    return result;
}

static const char* nl_format(const char *fmt, int n_args, ...) {
    if (!fmt) return "";
    va_list ap;
    va_start(ap, n_args);
    nl_fmt_sb_t out = nl_fmt_sb_new(128);
    const char *p = fmt;
    int used = 0;
    while (*p) {
        if (*p == '%' && (p[1] == 's' || p[1] == 'd' || p[1] == 'f' || p[1] == 'g') && used < n_args) {
            const char *arg = va_arg(ap, const char *);
            if (arg) nl_fmt_sb_append_cstr(&out, arg);
            used++;
            p += 2;
        } else {
            nl_fmt_sb_append_char(&out, *p++);
        }
    }
    va_end(ap);
    char *result = gc_alloc_string(out.len);
    if (result && out.buf) { memcpy(result, out.buf, out.len + 1); }
    if (out.buf) free(out.buf);
    return result ? result : "";
}

/* ========== End Advanced String Operations ========== */

/* ========== Timing Utilities ========== */

#include <sys/time.h>
#ifdef __MACH__
#include <mach/mach_time.h>
#endif

/* Get current time in microseconds since epoch */
static int64_t nl_timing_get_microseconds(void) {
#ifdef CLOCK_REALTIME
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ((int64_t)ts.tv_sec * 1000000LL) + (int64_t)(ts.tv_nsec / 1000);
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((int64_t)tv.tv_sec * 1000000LL) + (int64_t)tv.tv_usec;
#endif
}

/* Get high-resolution time in nanoseconds */
static int64_t nl_timing_get_nanoseconds(void) {
#ifdef __MACH__
    static mach_timebase_info_data_t timebase;
    static int initialized = 0;
    if (!initialized) {
        mach_timebase_info(&timebase);
        initialized = 1;
    }
    uint64_t mach_time = mach_absolute_time();
    return (int64_t)((mach_time * timebase.numer) / timebase.denom);
#elif defined(CLOCK_MONOTONIC)
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((int64_t)ts.tv_sec * 1000000000LL) + (int64_t)ts.tv_nsec;
#else
    return nl_timing_get_microseconds() * 1000LL;
#endif
}

/* Convenience: current time in milliseconds */
static int64_t nl_get_time_ms(void) { return nl_timing_get_microseconds() / 1000LL; }

/* ========== End Timing Utilities ========== */

/* ========== Console I/O Utilities ========== */

/* Read a line from stdin, returns heap-allocated string */
/* Static to avoid duplicate symbols when linking multiple modules */
static const char* nl_read_line(void) {
    char buffer[4096];
    if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty ? empty : "";
    }
    /* Remove trailing newline if present */
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len-1] == '\n') {
        buffer[len-1] = '\0';
        len--;
    }
    char* result = malloc(len + 1);
    if (!result) return "";
    memcpy(result, buffer, len + 1);
    return result;
}

/* ========== End Console I/O Utilities ========== */

#include <string.h>
static inline double nl_float_from_bits(int64_t value) { uint64_t bits = (uint64_t)value; double result; (void)sizeof(char[sizeof(result) == sizeof(bits) ? 1 : -1]); memcpy(&result, &bits, sizeof(result)); return result; }
static inline int64_t nl_float_to_bits(double value) { uint64_t bits; (void)sizeof(char[sizeof(value) == sizeof(bits) ? 1 : -1]); memcpy(&bits, &value, sizeof(bits)); return bits <= (9223372036854775807L) ? (int64_t)bits : -1 - (int64_t)((18446744073709551615UL) - bits); }
/* I canonicalize only scalar binary arithmetic results, never transported bits. */
#ifndef NANOLANG_BINARY64_ARITHMETIC_H
#define NANOLANG_BINARY64_ARITHMETIC_H
#include <float.h>
#include <stdint.h>
#include <string.h>

#if defined(__FAST_MATH__) || (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__)
#error "I require ordinary IEEE arithmetic without fast-math."
#endif
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 double arithmetic."
#endif
#if !defined(FLT_EVAL_METHOD) || FLT_EVAL_METHOD != 0
#error "I require operations evaluated in their binary64 type."
#endif
/* I retain a compile-time storage check in both C99 and C11 output. */
typedef char nano_rt_binary64_storage_guard[
    sizeof(double) == 8 && sizeof(uint64_t) == 8 ? 1 : -1];

#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_ARITHMETIC_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_ARITHMETIC_OPTIONAL
#endif

/* I inspect a rounded result with integer operations, not another FP operation. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_arithmetic_result(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    if ((bits & UINT64_C(0x7ff0000000000000)) == UINT64_C(0x7ff0000000000000) &&
        (bits & UINT64_C(0x000fffffffffffff)) != 0) {
        bits = UINT64_C(0x7ff8000000000000);
        memcpy(&value, &bits, sizeof(value));
    }
    return value;
}

/* Each volatile store/load is a binary64 rounding and noncontraction boundary. */
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_add(double a, double b) {
    volatile double rounded = a + b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_sub(double a, double b) {
    volatile double rounded = a - b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_mul(double a, double b) {
    volatile double rounded = a * b;
    return nano_rt_f64_arithmetic_result(rounded);
}
static inline NL_BINARY64_ARITHMETIC_OPTIONAL double nano_rt_f64_div(double a, double b) {
    uint64_t divisor;
    memcpy(&divisor, &b, sizeof(divisor));
    /* Either signed zero takes precedence even over a signaling NaN numerator. */
    if ((divisor & UINT64_C(0x7fffffffffffffff)) == 0) return 0.0;
    volatile double rounded = a / b;
    return nano_rt_f64_arithmetic_result(rounded);
}
#undef NL_BINARY64_ARITHMETIC_OPTIONAL
#endif
#ifndef NANOLANG_BINARY64_FORMAT_H
#define NANOLANG_BINARY64_FORMAT_H
#include <float.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#if FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024 || DBL_MIN_EXP != -1021
#error "I require binary64 formatting storage."
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL __attribute__((unused))
#else
#define NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return ((void *)0); if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline NL_BINARY64_FORMAT_SOURCE_OPTIONAL int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
#undef NL_BINARY64_FORMAT_SOURCE_OPTIONAL
#endif
/* ========== Math and Utility Built-in Functions ========== */

#define nl_abs(x) _Generic((x), \
    double: (double)((x) < 0.0 ? -(x) : (x)), \
    default: (int64_t)((x) < 0 ? -(x) : (x)))

#define nl_min(a, b) _Generic((a), \
    double: (double)((a) < (b) ? (a) : (b)), \
    default: (int64_t)((a) < (b) ? (a) : (b)))

#define nl_max(a, b) _Generic((a), \
    double: (double)((a) > (b) ? (a) : (b)), \
    default: (int64_t)((a) > (b) ? (a) : (b)))

/* Trigonometric functions */
static double nl_sin(double x) { return sin(x); }
static double nl_cos(double x) { return cos(x); }
static double nl_tan(double x) { return tan(x); }
static double nl_atan2(double y, double x) { return atan2(y, x); }

/* Power and root functions */
static double nl_sqrt(double x) { return sqrt(x); }
static double nl_pow(double base, double exp) { return pow(base, exp); }

/* Rounding functions */
static double nl_floor(double x) { return floor(x); }
static double nl_ceil(double x) { return ceil(x); }
static double nl_round(double x) { return round(x); }

static int64_t nl_cast_int(double x) { if (!(x >= -0x1p63 && x < 0x1p63)) { fputs("I cannot convert this float to int: I require a finite value in [-2^63, 2^63).\n", stderr); exit(EXIT_FAILURE); } return (int64_t)x; }
static int64_t nl_cast_int_from_int(int64_t x) { return x; }
static double nl_cast_float(int64_t x) { return (double)x; }
static double nl_cast_float_from_float(double x) { return x; }
static void* nl_null_opaque() { return NULL; }
static int64_t nl_cast_bool_to_int(bool x) { return x ? 1 : 0; }
static bool nl_cast_bool(int64_t x) { return x != 0; }
static int64_t nano_rt_idiv(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return INT64_MIN; return a / b; }
static int64_t nano_rt_imod(int64_t a, int64_t b) { if (b == 0) return 0; if (a == INT64_MIN && b == -1) return 0; return a % b; }

static void nl_println(void* value_ptr) {
    (void)value_ptr; /* Unused - actual implementation uses type info from checker */
}

static void nl_print_int(int64_t value) {
    printf("%lld", (long long)value);
}

static void nl_print_float(double value) {
    nano_rt_f64_print(stdout, value);
}

static void nl_print_string(const char* value) {
    printf("%s", value);
}

static void nl_print_bool(bool value) {
    printf(value ? "true" : "false");
}

static void nl_println_int(int64_t value) {
    printf("%lld\n", (long long)value);
}

static void nl_println_float(double value) {
    nano_rt_f64_print(stdout, value); fputc('\n', stdout);
}

static void nl_println_string(const char* value) {
    printf("%s\n", value);
}

/* Dynamic array runtime (using GC) - LEGACY */
#include "runtime/gc.h"
#include "runtime/dyn_array.h"
#include "runtime/nl_string.h"

static DynArray* dynarray_literal_int(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int64_t val = va_arg(args, int64_t);
        dyn_array_push_int(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_u8(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_U8);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* default promotion */
        dyn_array_push_u8(arr, (uint8_t)val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_float(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        double val = va_arg(args, double);
        dyn_array_push_float(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_string(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        const char* val = va_arg(args, const char*);
        dyn_array_push_string(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_literal_bool(int count, ...) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    va_list args;
    va_start(args, count);
    for (int i = 0; i < count; i++) {
        int val = va_arg(args, int); /* bool promotes to int */
        dyn_array_push_bool(arr, val);
    }
    va_end(args);
    return arr;
}

static DynArray* dynarray_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static DynArray* nl_array_push(DynArray* arr, double val) {
    if (arr->elem_type == ELEM_U8) {
        return dyn_array_push_u8(arr, (uint8_t)val);
    } else if (arr->elem_type == ELEM_INT) {
        return dyn_array_push_int(arr, (int64_t)val);
    } else {
        return dyn_array_push_float(arr, val);
    }
}

static double nl_array_pop(DynArray* arr) {
    bool success = false;
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_pop_u8(arr, &success);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_pop_int(arr, &success);
    } else {
        return dyn_array_pop_float(arr, &success);
    }
}

static int64_t nl_array_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static DynArray* nl_array_remove_at(DynArray* arr, int64_t index) {
    return dyn_array_remove_at(arr, index);
}

static int64_t nl_array_at_int(DynArray* arr, int64_t idx) {
    return dyn_array_get_int(arr, idx);
}

static uint8_t nl_array_at_u8(DynArray* arr, int64_t idx) {
    return dyn_array_get_u8(arr, idx);
}

static double nl_array_at_float(DynArray* arr, int64_t idx) {
    return dyn_array_get_float(arr, idx);
}

static const char* nl_array_at_string(DynArray* arr, int64_t idx) {
    return dyn_array_get_string(arr, idx);
}

static bool nl_array_at_bool(DynArray* arr, int64_t idx) {
    return dyn_array_get_bool(arr, idx);
}

static void nl_array_set_int(DynArray* arr, int64_t idx, int64_t val) {
    dyn_array_set_int(arr, idx, val);
}

static void nl_array_set_u8(DynArray* arr, int64_t idx, uint8_t val) {
    dyn_array_set_u8(arr, idx, val);
}

static void nl_array_set_float(DynArray* arr, int64_t idx, double val) {
    dyn_array_set_float(arr, idx, val);
}

static void nl_array_set_string(DynArray* arr, int64_t idx, const char* val) {
    dyn_array_set_string(arr, idx, val);
}

static void nl_array_set_bool(DynArray* arr, int64_t idx, bool val) {
    dyn_array_set_bool(arr, idx, val);
}

static DynArray* nl_array_at_array(DynArray* arr, int64_t idx) {
    return dyn_array_get_array(arr, idx);
}

static void nl_array_set_array(DynArray* arr, int64_t idx, DynArray* val) {
    dyn_array_set_array(arr, idx, val);
}

static DynArray* nl_array_new_int(int64_t size, int64_t default_val) {
    DynArray* arr = dyn_array_new(ELEM_INT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_int(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_float(int64_t size, double default_val) {
    DynArray* arr = dyn_array_new(ELEM_FLOAT);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_float(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_string(int64_t size, const char* default_val) {
    DynArray* arr = dyn_array_new(ELEM_STRING);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_string(arr, default_val);
    }
    return arr;
}

static DynArray* nl_array_new_bool(int64_t size, bool default_val) {
    DynArray* arr = dyn_array_new(ELEM_BOOL);
    for (int64_t i = 0; i < size; i++) {
        dyn_array_push_bool(arr, default_val);
    }
    return arr;
}

static int64_t dynarray_length(DynArray* arr) {
    return dyn_array_length(arr);
}

static double dynarray_at_for_transpiler(DynArray* arr, int64_t idx) {
    if (arr->elem_type == ELEM_U8) {
        return (double)dyn_array_get_u8(arr, idx);
    } else if (arr->elem_type == ELEM_INT) {
        return (double)dyn_array_get_int(arr, idx);
    } else {
        return dyn_array_get_float(arr, idx);
    }
}

/* bstring helpers (nl_string_t wrappers) */
static nl_string_t* bstr_new(const char* cstr) {
    if (!cstr) cstr = "";
    return nl_string_new(cstr);
}

static nl_string_t* bstr_new_binary(DynArray* bytes) {
    if (!bytes || dyn_array_get_elem_type(bytes) != ELEM_U8) {
        return nl_string_new_binary("", 0);
    }
    int64_t len = dyn_array_length(bytes);
    if (len <= 0) {
        return nl_string_new_binary("", 0);
    }
    uint8_t* buffer = malloc((size_t)len);
    if (!buffer) {
        return nl_string_new_binary("", 0);
    }
    for (int64_t i = 0; i < len; i++) {
        buffer[i] = dyn_array_get_u8(bytes, i);
    }
    nl_string_t* result = nl_string_new_binary(buffer, (size_t)len);
    free(buffer);
    return result;
}

static size_t bstr_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_length(str);
}

static int64_t bstr_byte_at(nl_string_t* str, int64_t index) {
    if (!str || index < 0 || (size_t)index >= nl_string_length(str)) {
        return 0;
    }
    return (unsigned char)nl_string_byte_at(str, (size_t)index);
}

static nl_string_t* bstr_concat(nl_string_t* a, nl_string_t* b) {
    if (!a && !b) return nl_string_new("");
    if (!a) return nl_string_clone(b);
    if (!b) return nl_string_clone(a);
    return nl_string_concat(a, b);
}

static nl_string_t* bstr_substring(nl_string_t* str, int64_t start, int64_t length) {
    if (!str || start < 0 || length < 0) {
        return nl_string_new("");
    }
    size_t len = nl_string_length(str);
    if ((size_t)start > len) {
        start = (int64_t)len;
    }
    if ((size_t)(start + length) > len) {
        length = (int64_t)len - start;
    }
    return nl_string_substring(str, (size_t)start, (size_t)length);
}

static bool bstr_equals(nl_string_t* a, nl_string_t* b) {
    if (!a || !b) return a == b;
    return nl_string_equals(a, b);
}

static bool bstr_validate_utf8(nl_string_t* str) {
    if (!str) return false;
    return nl_string_validate_utf8(str);
}

static int64_t bstr_utf8_length(nl_string_t* str) {
    if (!str) return 0;
    return nl_string_utf8_length(str);
}

static int64_t bstr_utf8_char_at(nl_string_t* str, int64_t char_index) {
    if (!str || char_index < 0) return -1;
    return nl_string_utf8_char_at(str, (size_t)char_index);
}

static const char* bstr_to_cstr(nl_string_t* str) {
    if (!str) return "";
    return nl_string_to_cstr(str);
}

static void bstr_free(nl_string_t* str) {
    if (str) {
        nl_string_free(str);
    }
}

/* String concatenation - use strnlen for safety */
static const char* nl_str_concat(const char* s1, const char* s2) {
    /* Safety: Bound string scan to 64MB */
    size_t len1 = strnlen(s1, 64*1024*1024);
    size_t len2 = strnlen(s2, 64*1024*1024);
    char* result = gc_alloc_string(len1 + len2);
    if (!result) return "";
    memcpy(result, s1, len1);
    memcpy(result + len1, s2, len2);
    result[len1 + len2] = '\0';
    return result;
}

/* String substring - use strnlen for safety */
static const char* nl_str_substring(const char* str, int64_t start, int64_t length) {
    /* Safety: Bound string scan to 64MB */
    int64_t str_len = strnlen(str, 64*1024*1024);
    if (start < 0 || start > str_len || length < 0) return "";
    if (start == str_len) return "";
    if (start + length > str_len) length = str_len - start;
    char* result = gc_alloc_string(length);
    if (!result) return "";
    strncpy(result, str + start, length);
    result[length] = '\0';
    return result;
}

/* String contains */
static bool nl_str_contains(const char* str, const char* substr) {
    return strstr(str, substr) != NULL;
}

/* String equals */
static bool nl_str_equals(const char* s1, const char* s2) {
    return strcmp(s1, s2) == 0;
}

/* String starts_with */
static bool nl_str_starts_with(const char* s, const char* prefix) {
    if (!s || !prefix) return false;
    size_t slen = strnlen(s, 64*1024*1024);
    size_t plen = strnlen(prefix, 64*1024*1024);
    if (plen > slen) return false;
    return strncmp(s, prefix, plen) == 0;
}

/* String ends_with */
#include "runtime/string_edges.h"
#include "runtime/string_search.h"
static DynArray* nl_bytes_from_string(const char* s) {
    DynArray* out = dyn_array_new(ELEM_U8);
    if (!out) return NULL;
    if (!s) return out;
    size_t len = strnlen(s, 64*1024*1024);
    for (size_t i = 0; i < len; i++) {
        dyn_array_push_u8(out, (uint8_t)(unsigned char)s[i]);
    }
    return out;
}

static const char* nl_string_from_bytes(DynArray* bytes) {
    if (!bytes) return "";
    if (dyn_array_get_elem_type(bytes) != ELEM_U8) return "";
    int64_t len = dyn_array_length(bytes);
    if (len < 0) return "";
    char* out = gc_alloc_string((size_t)len);
    if (!out) return "";
    for (int64_t i = 0; i < len; i++) {
        out[i] = (char)dyn_array_get_u8(bytes, i);
    }
    out[len] = '\0';
    return out;
}

static DynArray* nl_array_slice(DynArray* arr, int64_t start, int64_t length) {
    if (!arr) return dyn_array_new(ELEM_INT);
    if (start < 0) start = 0;
    if (length < 0) length = 0;
    int64_t len = dyn_array_length(arr);
    if (start > len) start = len;
    if (length > len - start) length = len - start;
    int64_t end = start + length;
    if (end > len) end = len;
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = start; i < end; i++) {
        switch (t) {
            case ELEM_U8: dyn_array_push_u8(out, dyn_array_get_u8(arr, i)); break;
            case ELEM_INT: dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT: dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL: dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            case ELEM_ARRAY: dyn_array_push_array(out, dyn_array_get_array(arr, i)); break;
            case ELEM_STRUCT: dyn_array_push_struct(out, dyn_array_get_struct(arr, i), (size_t)arr->elem_size); break;
            default: assert(false && "nl_array_slice: unsupported element type");
        }
    }
    return out;
}

static void nl_println_bool(bool value) {
    printf("%s\n", value ? "true" : "false");
}

static void nl_print_array(DynArray* arr) {
    printf("[");
    for (int i = 0; i < arr->length; i++) {
        if (i > 0) printf(", ");
        switch (arr->elem_type) {
            case ELEM_INT:
                printf("%lld", (long long)((int64_t*)arr->data)[i]);
                break;
            case ELEM_U8:
                printf("%u", (unsigned)((uint8_t*)arr->data)[i]);
                break;
            case ELEM_FLOAT:
                nano_rt_f64_print(stdout, ((double*)arr->data)[i]);
                break;
            default:
                printf("?");
                break;
        }
    }
    printf("]");
}

static void nl_println_array(DynArray* arr) {
    nl_print_array(arr);
    printf("\n");
}

/* ========== Array Operations (With Bounds Checking!) ========== */

static DynArray* nl_array_sort(DynArray* arr) {
    return dyn_array_sorted(arr);
}

static DynArray* nl_array_reverse(DynArray* arr) {
    if (!arr) return dyn_array_new(ELEM_INT);
    int64_t len = dyn_array_length(arr);
    ElementType t = dyn_array_get_elem_type(arr);
    DynArray* out = dyn_array_new(t);
    if (!out) return NULL;
    for (int64_t i = len - 1; i >= 0; i--) {
        switch (t) {
            case ELEM_INT:    dyn_array_push_int(out, dyn_array_get_int(arr, i)); break;
            case ELEM_FLOAT:  dyn_array_push_float(out, dyn_array_get_float(arr, i)); break;
            case ELEM_BOOL:   dyn_array_push_bool(out, dyn_array_get_bool(arr, i)); break;
            case ELEM_STRING: dyn_array_push_string(out, dyn_array_get_string(arr, i)); break;
            default: dyn_array_push_int(out, 0); break;
        }
    }
    return out;
}

static bool nl_array_contains(DynArray* arr, int64_t elem) {
    if (!arr) return false;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return true;
    }
    return false;
}

static int64_t nl_array_index_of(DynArray* arr, int64_t elem) {
    if (!arr) return -1;
    int64_t len = dyn_array_length(arr);
    for (int64_t i = 0; i < len; i++) {
        if (dyn_array_get_int(arr, i) == elem) return i;
    }
    return -1;
}

/* ========== End Array Operations ========== */

/* ========== End Math and Utility Built-in Functions ========== */

/* ========== Coroutine Runtime Builtins ========== */
#include "coroutine.h"

typedef struct { void *fn; int64_t args[8]; int nargs; } NlSpawnCtx;
static Value nl_coro_spawn_trampoline(void *raw, int coro_id) {
    (void)coro_id;
    NlSpawnCtx *ctx = (NlSpawnCtx *)raw;
    Value v; memset(&v, 0, sizeof(v)); v.type = VAL_INT;
    switch (ctx->nargs) {
        case 0: v.as.int_val = ((int64_t(*)(void))ctx->fn)(); break;
        case 1: v.as.int_val = ((int64_t(*)(int64_t))ctx->fn)(ctx->args[0]); break;
        case 2: v.as.int_val = ((int64_t(*)(int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1]); break;
        case 3: v.as.int_val = ((int64_t(*)(int64_t,int64_t,int64_t))ctx->fn)(ctx->args[0],ctx->args[1],ctx->args[2]); break;
        default: break;
    }
    return v;
}

static int64_t nl_coro_spawn_n(void *fn, int nargs, int64_t a0, int64_t a1, int64_t a2) {
    nano_scheduler_init();
    NlSpawnCtx *ctx = (NlSpawnCtx *)malloc(sizeof(NlSpawnCtx));
    if (!ctx) return -1;
    ctx->fn = fn; ctx->nargs = nargs;
    ctx->args[0] = a0; ctx->args[1] = a1; ctx->args[2] = a2;
    return (int64_t)nano_coro_spawn(nl_coro_spawn_trampoline, ctx);
}
/* nl_coro_spawn: select correct overload by argument count */
#define _nl_cs0(fn)           nl_coro_spawn_n((void*)(fn),0,0LL,0LL,0LL)
#define _nl_cs1(fn,a)         nl_coro_spawn_n((void*)(fn),1,(int64_t)(a),0LL,0LL)
#define _nl_cs2(fn,a,b)       nl_coro_spawn_n((void*)(fn),2,(int64_t)(a),(int64_t)(b),0LL)
#define _nl_cs3(fn,a,b,c)     nl_coro_spawn_n((void*)(fn),3,(int64_t)(a),(int64_t)(b),(int64_t)(c))
#define _nl_cs_pick(_1,_2,_3,_4,X,...) X
#define nl_coro_spawn(fn,...) _nl_cs_pick(fn,##__VA_ARGS__,_nl_cs3,_nl_cs2,_nl_cs1,_nl_cs0)(fn,##__VA_ARGS__)

/* nl_scheduler_run(): drain all pending coroutines */
static void nl_scheduler_run(void) {
    nano_scheduler_init();
    nano_scheduler_run_until_done();
}

/* nl_scheduler_step(): run one step */
static int64_t nl_scheduler_step(void) {
    nano_scheduler_init();
    return nano_scheduler_step() ? 1 : 0;
}

/* nl_coro_result(id): get result value of completed coroutine */
static int64_t nl_coro_result(int64_t id) {
    Value v = nano_coro_result((int)id);
    return v.as.int_val;
}

/* nl_coro_done(id): 1 if coroutine completed */
static int64_t nl_coro_done(int64_t id) {
    return nano_coro_is_done((int)id) ? 1 : 0;
}

/* nl_coro_yield(): cooperative yield hint */
static void nl_coro_yield(void) { nano_coro_yield(); }
/* ========== End Coroutine Runtime Builtins ========== */

/* ========== Enum Definitions ========== */

typedef enum {
    nl_LexerTokenType_TOKEN_EOF = 0,
    nl_LexerTokenType_TOKEN_NUMBER = 1,
    nl_LexerTokenType_TOKEN_FLOAT = 2,
    nl_LexerTokenType_TOKEN_STRING = 3,
    nl_LexerTokenType_TOKEN_IDENTIFIER = 4,
    nl_LexerTokenType_TOKEN_TRUE = 5,
    nl_LexerTokenType_TOKEN_FALSE = 6,
    nl_LexerTokenType_TOKEN_LPAREN = 7,
    nl_LexerTokenType_TOKEN_RPAREN = 8,
    nl_LexerTokenType_TOKEN_LBRACE = 9,
    nl_LexerTokenType_TOKEN_RBRACE = 10,
    nl_LexerTokenType_TOKEN_LBRACKET = 11,
    nl_LexerTokenType_TOKEN_RBRACKET = 12,
    nl_LexerTokenType_TOKEN_COMMA = 13,
    nl_LexerTokenType_TOKEN_COLON = 14,
    nl_LexerTokenType_TOKEN_DOUBLE_COLON = 15,
    nl_LexerTokenType_TOKEN_ARROW = 16,
    nl_LexerTokenType_TOKEN_ASSIGN = 17,
    nl_LexerTokenType_TOKEN_DOT = 18,
    nl_LexerTokenType_TOKEN_MODULE = 19,
    nl_LexerTokenType_TOKEN_PUB = 20,
    nl_LexerTokenType_TOKEN_FROM = 21,
    nl_LexerTokenType_TOKEN_USE = 22,
    nl_LexerTokenType_TOKEN_EXTERN = 23,
    nl_LexerTokenType_TOKEN_FN = 24,
    nl_LexerTokenType_TOKEN_LET = 25,
    nl_LexerTokenType_TOKEN_MUT = 26,
    nl_LexerTokenType_TOKEN_SET = 27,
    nl_LexerTokenType_TOKEN_IF = 28,
    nl_LexerTokenType_TOKEN_ELSE = 29,
    nl_LexerTokenType_TOKEN_COND = 30,
    nl_LexerTokenType_TOKEN_WHILE = 31,
    nl_LexerTokenType_TOKEN_FOR = 32,
    nl_LexerTokenType_TOKEN_IN = 33,
    nl_LexerTokenType_TOKEN_RETURN = 34,
    nl_LexerTokenType_TOKEN_BREAK = 35,
    nl_LexerTokenType_TOKEN_CONTINUE = 36,
    nl_LexerTokenType_TOKEN_ASSERT = 37,
    nl_LexerTokenType_TOKEN_SHADOW = 38,
    nl_LexerTokenType_TOKEN_REQUIRES = 39,
    nl_LexerTokenType_TOKEN_ENSURES = 40,
    nl_LexerTokenType_TOKEN_PRINT = 41,
    nl_LexerTokenType_TOKEN_ARRAY = 42,
    nl_LexerTokenType_TOKEN_STRUCT = 43,
    nl_LexerTokenType_TOKEN_ENUM = 44,
    nl_LexerTokenType_TOKEN_UNION = 45,
    nl_LexerTokenType_TOKEN_MATCH = 46,
    nl_LexerTokenType_TOKEN_IMPORT = 47,
    nl_LexerTokenType_TOKEN_AS = 48,
    nl_LexerTokenType_TOKEN_OPAQUE = 49,
    nl_LexerTokenType_TOKEN_TYPE_INT = 50,
    nl_LexerTokenType_TOKEN_TYPE_U8 = 51,
    nl_LexerTokenType_TOKEN_TYPE_FLOAT = 52,
    nl_LexerTokenType_TOKEN_TYPE_BOOL = 53,
    nl_LexerTokenType_TOKEN_TYPE_STRING = 54,
    nl_LexerTokenType_TOKEN_TYPE_BSTRING = 55,
    nl_LexerTokenType_TOKEN_TYPE_VOID = 56,
    nl_LexerTokenType_TOKEN_PLUS = 57,
    nl_LexerTokenType_TOKEN_MINUS = 58,
    nl_LexerTokenType_TOKEN_STAR = 59,
    nl_LexerTokenType_TOKEN_SLASH = 60,
    nl_LexerTokenType_TOKEN_PERCENT = 61,
    nl_LexerTokenType_TOKEN_EQ = 62,
    nl_LexerTokenType_TOKEN_NE = 63,
    nl_LexerTokenType_TOKEN_LT = 64,
    nl_LexerTokenType_TOKEN_LE = 65,
    nl_LexerTokenType_TOKEN_GT = 66,
    nl_LexerTokenType_TOKEN_GE = 67,
    nl_LexerTokenType_TOKEN_AND = 68,
    nl_LexerTokenType_TOKEN_OR = 69,
    nl_LexerTokenType_TOKEN_NOT = 70,
    nl_LexerTokenType_TOKEN_RANGE = 71,
    nl_LexerTokenType_TOKEN_UNSAFE = 72,
    nl_LexerTokenType_TOKEN_RESOURCE = 73,
    nl_LexerTokenType_TOKEN_PIPE = 74,
    nl_LexerTokenType_TOKEN_GRAMMAR = 75,
    nl_LexerTokenType_TOKEN_LARROW = 76,
    nl_LexerTokenType_TOKEN_QUESTION = 77,
    nl_LexerTokenType_TOKEN_PAR = 78,
    nl_LexerTokenType_TOKEN_BAR = 79,
    nl_LexerTokenType_TOKEN_EFFECT = 80,
    nl_LexerTokenType_TOKEN_HANDLE = 81,
    nl_LexerTokenType_TOKEN_WITH = 82,
    nl_LexerTokenType_TOKEN_RESUME = 83,
    nl_LexerTokenType_TOKEN_GPU = 84,
    nl_LexerTokenType_TOKEN_ASYNC = 85,
    nl_LexerTokenType_TOKEN_AWAIT = 86,
    nl_LexerTokenType_TOKEN_PURE = 87,
    nl_LexerTokenType_TOKEN_AMPERSAND = 88
} nl_LexerTokenType;

typedef enum {
    nl_ParseNodeType_PNODE_NUMBER = 0,
    nl_ParseNodeType_PNODE_FLOAT = 1,
    nl_ParseNodeType_PNODE_STRING = 2,
    nl_ParseNodeType_PNODE_BOOL = 3,
    nl_ParseNodeType_PNODE_IDENTIFIER = 4,
    nl_ParseNodeType_PNODE_BINARY_OP = 5,
    nl_ParseNodeType_PNODE_CALL = 6,
    nl_ParseNodeType_PNODE_ARRAY_LITERAL = 7,
    nl_ParseNodeType_PNODE_LET = 8,
    nl_ParseNodeType_PNODE_SET = 9,
    nl_ParseNodeType_PNODE_IF = 10,
    nl_ParseNodeType_PNODE_COND = 11,
    nl_ParseNodeType_PNODE_WHILE = 12,
    nl_ParseNodeType_PNODE_FOR = 13,
    nl_ParseNodeType_PNODE_RETURN = 14,
    nl_ParseNodeType_PNODE_BREAK = 15,
    nl_ParseNodeType_PNODE_CONTINUE = 16,
    nl_ParseNodeType_PNODE_BLOCK = 17,
    nl_ParseNodeType_PNODE_PRINT = 18,
    nl_ParseNodeType_PNODE_ASSERT = 19,
    nl_ParseNodeType_PNODE_PROGRAM = 20,
    nl_ParseNodeType_PNODE_FUNCTION = 21,
    nl_ParseNodeType_PNODE_SHADOW = 22,
    nl_ParseNodeType_PNODE_STRUCT_DEF = 23,
    nl_ParseNodeType_PNODE_STRUCT_LITERAL = 24,
    nl_ParseNodeType_PNODE_FIELD_ACCESS = 25,
    nl_ParseNodeType_PNODE_ENUM_DEF = 26,
    nl_ParseNodeType_PNODE_UNION_DEF = 27,
    nl_ParseNodeType_PNODE_UNION_CONSTRUCT = 28,
    nl_ParseNodeType_PNODE_MATCH = 29,
    nl_ParseNodeType_PNODE_IMPORT = 30,
    nl_ParseNodeType_PNODE_OPAQUE_TYPE = 31,
    nl_ParseNodeType_PNODE_TUPLE_LITERAL = 32,
    nl_ParseNodeType_PNODE_TUPLE_INDEX = 33,
    nl_ParseNodeType_PNODE_STRUCT = 34,
    nl_ParseNodeType_PNODE_ENUM = 35,
    nl_ParseNodeType_PNODE_UNION = 36,
    nl_ParseNodeType_PNODE_UNSAFE_BLOCK = 37,
    nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL = 38,
    nl_ParseNodeType_PNODE_GRAMMAR = 39,
    nl_ParseNodeType_PNODE_PAR_BLOCK = 40,
    nl_ParseNodeType_PNODE_EFFECT_DECL = 41,
    nl_ParseNodeType_PNODE_HANDLE_EXPR = 42,
    nl_ParseNodeType_PNODE_ASYNC_FN = 43,
    nl_ParseNodeType_PNODE_SERVICE_DECL = 44
} nl_ParseNodeType;

typedef enum {
    nl_TypeKind_TYPE_INT = 0,
    nl_TypeKind_TYPE_FLOAT = 1,
    nl_TypeKind_TYPE_BOOL = 2,
    nl_TypeKind_TYPE_STRING = 3,
    nl_TypeKind_TYPE_VOID = 4,
    nl_TypeKind_TYPE_ARRAY = 5,
    nl_TypeKind_TYPE_STRUCT = 6,
    nl_TypeKind_TYPE_ENUM = 7,
    nl_TypeKind_TYPE_UNION = 8,
    nl_TypeKind_TYPE_GENERIC = 9,
    nl_TypeKind_TYPE_LIST_INT = 10,
    nl_TypeKind_TYPE_LIST_STRING = 11,
    nl_TypeKind_TYPE_LIST_TOKEN = 12,
    nl_TypeKind_TYPE_LIST_GENERIC = 13,
    nl_TypeKind_TYPE_FUNCTION = 14,
    nl_TypeKind_TYPE_TUPLE = 15,
    nl_TypeKind_TYPE_OPAQUE = 16,
    nl_TypeKind_TYPE_UNKNOWN = 17
} nl_TypeKind;

/* ========== End Enum Definitions ========== */

#ifndef FORWARD_DEFINED_List_CompilerDiagnostic
#define FORWARD_DEFINED_List_CompilerDiagnostic
typedef struct List_CompilerDiagnostic List_CompilerDiagnostic;
#endif
#ifndef FORWARD_DEFINED_List_LexerToken
#define FORWARD_DEFINED_List_LexerToken
typedef struct List_LexerToken List_LexerToken;
#endif
#ifndef FORWARD_DEFINED_List_ASTStmtRef
#define FORWARD_DEFINED_List_ASTStmtRef
typedef struct List_ASTStmtRef List_ASTStmtRef;
#endif
#ifndef FORWARD_DEFINED_List_ASTNumber
#define FORWARD_DEFINED_List_ASTNumber
typedef struct List_ASTNumber List_ASTNumber;
#endif
#ifndef FORWARD_DEFINED_List_ASTFloat
#define FORWARD_DEFINED_List_ASTFloat
typedef struct List_ASTFloat List_ASTFloat;
#endif
#ifndef FORWARD_DEFINED_List_ASTString
#define FORWARD_DEFINED_List_ASTString
typedef struct List_ASTString List_ASTString;
#endif
#ifndef FORWARD_DEFINED_List_ASTBool
#define FORWARD_DEFINED_List_ASTBool
typedef struct List_ASTBool List_ASTBool;
#endif
#ifndef FORWARD_DEFINED_List_ASTIdentifier
#define FORWARD_DEFINED_List_ASTIdentifier
typedef struct List_ASTIdentifier List_ASTIdentifier;
#endif
#ifndef FORWARD_DEFINED_List_ASTBinaryOp
#define FORWARD_DEFINED_List_ASTBinaryOp
typedef struct List_ASTBinaryOp List_ASTBinaryOp;
#endif
#ifndef FORWARD_DEFINED_List_ASTCall
#define FORWARD_DEFINED_List_ASTCall
typedef struct List_ASTCall List_ASTCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTModuleQualifiedCall
#define FORWARD_DEFINED_List_ASTModuleQualifiedCall
typedef struct List_ASTModuleQualifiedCall List_ASTModuleQualifiedCall;
#endif
#ifndef FORWARD_DEFINED_List_ASTArrayLiteral
#define FORWARD_DEFINED_List_ASTArrayLiteral
typedef struct List_ASTArrayLiteral List_ASTArrayLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTLet
#define FORWARD_DEFINED_List_ASTLet
typedef struct List_ASTLet List_ASTLet;
#endif
#ifndef FORWARD_DEFINED_List_ASTSet
#define FORWARD_DEFINED_List_ASTSet
typedef struct List_ASTSet List_ASTSet;
#endif
#ifndef FORWARD_DEFINED_List_ASTIf
#define FORWARD_DEFINED_List_ASTIf
typedef struct List_ASTIf List_ASTIf;
#endif
#ifndef FORWARD_DEFINED_List_ASTWhile
#define FORWARD_DEFINED_List_ASTWhile
typedef struct List_ASTWhile List_ASTWhile;
#endif
#ifndef FORWARD_DEFINED_List_ASTFor
#define FORWARD_DEFINED_List_ASTFor
typedef struct List_ASTFor List_ASTFor;
#endif
#ifndef FORWARD_DEFINED_List_ASTReturn
#define FORWARD_DEFINED_List_ASTReturn
typedef struct List_ASTReturn List_ASTReturn;
#endif
#ifndef FORWARD_DEFINED_List_ASTBlock
#define FORWARD_DEFINED_List_ASTBlock
typedef struct List_ASTBlock List_ASTBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnsafeBlock
#define FORWARD_DEFINED_List_ASTUnsafeBlock
typedef struct List_ASTUnsafeBlock List_ASTUnsafeBlock;
#endif
#ifndef FORWARD_DEFINED_List_ASTPrint
#define FORWARD_DEFINED_List_ASTPrint
typedef struct List_ASTPrint List_ASTPrint;
#endif
#ifndef FORWARD_DEFINED_List_ASTAssert
#define FORWARD_DEFINED_List_ASTAssert
typedef struct List_ASTAssert List_ASTAssert;
#endif
#ifndef FORWARD_DEFINED_List_ASTFunction
#define FORWARD_DEFINED_List_ASTFunction
typedef struct List_ASTFunction List_ASTFunction;
#endif
#ifndef FORWARD_DEFINED_List_ASTShadow
#define FORWARD_DEFINED_List_ASTShadow
typedef struct List_ASTShadow List_ASTShadow;
#endif
#ifndef FORWARD_DEFINED_List_ASTStruct
#define FORWARD_DEFINED_List_ASTStruct
typedef struct List_ASTStruct List_ASTStruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTStructLiteral
#define FORWARD_DEFINED_List_ASTStructLiteral
typedef struct List_ASTStructLiteral List_ASTStructLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTFieldAccess
#define FORWARD_DEFINED_List_ASTFieldAccess
typedef struct List_ASTFieldAccess List_ASTFieldAccess;
#endif
#ifndef FORWARD_DEFINED_List_ASTEnum
#define FORWARD_DEFINED_List_ASTEnum
typedef struct List_ASTEnum List_ASTEnum;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnion
#define FORWARD_DEFINED_List_ASTUnion
typedef struct List_ASTUnion List_ASTUnion;
#endif
#ifndef FORWARD_DEFINED_List_ASTUnionConstruct
#define FORWARD_DEFINED_List_ASTUnionConstruct
typedef struct List_ASTUnionConstruct List_ASTUnionConstruct;
#endif
#ifndef FORWARD_DEFINED_List_ASTMatch
#define FORWARD_DEFINED_List_ASTMatch
typedef struct List_ASTMatch List_ASTMatch;
#endif
#ifndef FORWARD_DEFINED_List_ASTImport
#define FORWARD_DEFINED_List_ASTImport
typedef struct List_ASTImport List_ASTImport;
#endif
#ifndef FORWARD_DEFINED_List_ASTOpaqueType
#define FORWARD_DEFINED_List_ASTOpaqueType
typedef struct List_ASTOpaqueType List_ASTOpaqueType;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleLiteral
#define FORWARD_DEFINED_List_ASTTupleLiteral
typedef struct List_ASTTupleLiteral List_ASTTupleLiteral;
#endif
#ifndef FORWARD_DEFINED_List_ASTTupleIndex
#define FORWARD_DEFINED_List_ASTTupleIndex
typedef struct List_ASTTupleIndex List_ASTTupleIndex;
#endif
#ifndef FORWARD_DEFINED_List_ASTServiceDecl
#define FORWARD_DEFINED_List_ASTServiceDecl
typedef struct List_ASTServiceDecl List_ASTServiceDecl;
#endif
/* ========== HashMap Forward Declarations ========== */
typedef struct HashMap_string_string HashMap_string_string;
/* ========== End HashMap Forward Declarations ========== */

/* ========== Struct and Union Definitions ========== */

#ifndef DEFINED_nl___nano_record_6572726f725f6d65737361676573_ErrorMessage
#define DEFINED_nl___nano_record_6572726f725f6d65737361676573_ErrorMessage
typedef struct nl___nano_record_6572726f725f6d65737361676573_ErrorMessage {
    const char* title;
    const char* file;
    int64_t line;
    int64_t column;
    const char* problem;
    const char* code_snippet;
    const char* explanation;
    const char* suggestion;
} nl___nano_record_6572726f725f6d65737361676573_ErrorMessage;
#endif

/* ========== End Struct and Union Definitions ========== */

/* ========== Auto-Generated Struct Metadata ========== */

inline int64_t ___reflect___nano_record_6572726f725f6d65737361676573_ErrorMessage_field_count(void) {
    return 8;
}

inline const char* ___reflect___nano_record_6572726f725f6d65737361676573_ErrorMessage_field_name(int64_t index) {
    if (index == 0) { return "title"; }
    else if (index == 1) { return "file"; }
    else if (index == 2) { return "line"; }
    else if (index == 3) { return "column"; }
    else if (index == 4) { return "problem"; }
    else if (index == 5) { return "code_snippet"; }
    else if (index == 6) { return "explanation"; }
    else if (index == 7) { return "suggestion"; }
    return "";
}

inline const char* ___reflect___nano_record_6572726f725f6d65737361676573_ErrorMessage_field_type(int64_t index) {
    if (index == 0) { return "string"; }
    else if (index == 1) { return "string"; }
    else if (index == 2) { return "int"; }
    else if (index == 3) { return "int"; }
    else if (index == 4) { return "string"; }
    else if (index == 5) { return "string"; }
    else if (index == 6) { return "string"; }
    else if (index == 7) { return "string"; }
    return "";
}

inline bool ___reflect___nano_record_6572726f725f6d65737361676573_ErrorMessage_has_field(const char* name) {
    if (strcmp(name, "title") == 0) { return 1; }
    else if (strcmp(name, "file") == 0) { return 1; }
    else if (strcmp(name, "line") == 0) { return 1; }
    else if (strcmp(name, "column") == 0) { return 1; }
    else if (strcmp(name, "problem") == 0) { return 1; }
    else if (strcmp(name, "code_snippet") == 0) { return 1; }
    else if (strcmp(name, "explanation") == 0) { return 1; }
    else if (strcmp(name, "suggestion") == 0) { return 1; }
    return 0;
}

inline const char* ___reflect___nano_record_6572726f725f6d65737361676573_ErrorMessage_field_type_by_name(const char* name) {
    if (strcmp(name, "title") == 0) { return "string"; }
    else if (strcmp(name, "file") == 0) { return "string"; }
    else if (strcmp(name, "line") == 0) { return "int"; }
    else if (strcmp(name, "column") == 0) { return "int"; }
    else if (strcmp(name, "problem") == 0) { return "string"; }
    else if (strcmp(name, "code_snippet") == 0) { return "string"; }
    else if (strcmp(name, "explanation") == 0) { return "string"; }
    else if (strcmp(name, "suggestion") == 0) { return "string"; }
    return "";
}

/* ========== End Struct Metadata ========== */

#include "runtime/list_CompilerDiagnostic.h"
#include "runtime/list_LexerToken.h"
#include "runtime/list_ASTStmtRef.h"
#include "runtime/list_ASTNumber.h"
#include "runtime/list_ASTFloat.h"
#include "runtime/list_ASTString.h"
#include "runtime/list_ASTBool.h"
#include "runtime/list_ASTIdentifier.h"
#include "runtime/list_ASTBinaryOp.h"
#include "runtime/list_ASTCall.h"
#include "runtime/list_ASTModuleQualifiedCall.h"
#include "runtime/list_ASTArrayLiteral.h"
#include "runtime/list_ASTLet.h"
#include "runtime/list_ASTSet.h"
#include "runtime/list_ASTIf.h"
#include "runtime/list_ASTWhile.h"
#include "runtime/list_ASTFor.h"
#include "runtime/list_ASTReturn.h"
#include "runtime/list_ASTBlock.h"
#include "runtime/list_ASTUnsafeBlock.h"
#include "runtime/list_ASTPrint.h"
#include "runtime/list_ASTAssert.h"
#include "runtime/list_ASTFunction.h"
#include "runtime/list_ASTShadow.h"
#include "runtime/list_ASTStruct.h"
#include "runtime/list_ASTStructLiteral.h"
#include "runtime/list_ASTFieldAccess.h"
#include "runtime/list_ASTEnum.h"
#include "runtime/list_ASTUnion.h"
#include "runtime/list_ASTUnionConstruct.h"
#include "runtime/list_ASTMatch.h"
#include "runtime/list_ASTImport.h"
#include "runtime/list_ASTOpaqueType.h"
#include "runtime/list_ASTTupleLiteral.h"
#include "runtime/list_ASTTupleIndex.h"
#include "runtime/list_ASTServiceDecl.h"
/* ========== HashMap Runtime (Generated) ========== */

static uint64_t nl_hashmap_hash_string(const char *s) {
    if (!s) return 0;
    uint64_t hash = 1469598103934665603ULL;
    while (*s) { hash ^= (uint8_t)(*s++); hash *= 1099511628211ULL; }
    return hash;
}

static uint64_t nl_hashmap_hash_int(int64_t x) {
    uint64_t z = (uint64_t)x;
    z ^= z >> 33;
    z *= 0xff51afd7ed558ccdULL;
    z ^= z >> 33;
    z *= 0xc4ceb9fe1a85ec53ULL;
    z ^= z >> 33;
    return z;
}

static bool nl_hashmap_key_eq_string(const char *a, const char *b) {
    if (a == b) return true;
    if (!a || !b) return false;
    return strcmp(a, b) == 0;
}

typedef struct HashMap_string_string_Entry {
    uint8_t state; /* 0=empty, 1=filled, 2=tombstone */
    char* key;
    char* value;
} HashMap_string_string_Entry;

struct HashMap_string_string {
    int64_t capacity;
    int64_t size;
    int64_t tombstones;
    HashMap_string_string_Entry *entries;
};

static HashMap_string_string* nl_hashmap_string_string_alloc(int64_t cap) {
    HashMap_string_string *hm = (HashMap_string_string*)malloc(sizeof(HashMap_string_string));
    if (!hm) return NULL;
    hm->capacity = cap;
    hm->size = 0;
    hm->tombstones = 0;
    hm->entries = (HashMap_string_string_Entry*)calloc((size_t)cap, sizeof(HashMap_string_string_Entry));
    if (!hm->entries) { free(hm); return NULL; }
    return hm;
}

static int64_t nl_hashmap_string_string_find_slot(HashMap_string_string *hm, const char* key, bool *out_found) {
    if (out_found) *out_found = false;
    if (!hm || hm->capacity <= 0) return -1;
    uint64_t h = nl_hashmap_hash_string(key);
    int64_t mask = hm->capacity - 1;
    int64_t idx = (int64_t)(h & (uint64_t)mask);
    int64_t first_tomb = -1;
    for (int64_t probe = 0; probe < hm->capacity; probe++) {
        HashMap_string_string_Entry *e = &hm->entries[idx];
        if (e->state == 0) {
            if (first_tomb != -1) idx = first_tomb;
            return idx;
        }
        if (e->state == 2) {
            if (first_tomb == -1) first_tomb = idx;
        } else {
            if (nl_hashmap_key_eq_string(e->key, key)) { if (out_found) *out_found = true; return idx; }
        }
        idx = (idx + 1) & mask;
    }
    return first_tomb;
}

static void nl_hashmap_string_string_rehash(HashMap_string_string *hm, int64_t new_cap) {
    if (!hm) return;
    if (new_cap < 8) new_cap = 8;
    /* Ensure power-of-two capacity */
    int64_t cap = 1;
    while (cap < new_cap) cap <<= 1;
    HashMap_string_string_Entry *old_entries = hm->entries;
    int64_t old_cap = hm->capacity;
    hm->entries = (HashMap_string_string_Entry*)calloc((size_t)cap, sizeof(HashMap_string_string_Entry));
    if (!hm->entries) { hm->entries = old_entries; return; }
    hm->capacity = cap;
    hm->size = 0;
    hm->tombstones = 0;
    for (int64_t i2 = 0; i2 < old_cap; i2++) {
        HashMap_string_string_Entry *e = &old_entries[i2];
        if (e->state != 1) continue;
        bool found = false;
        int64_t idx = nl_hashmap_string_string_find_slot(hm, e->key, &found);
        if (idx >= 0) { hm->entries[idx] = *e; hm->entries[idx].state = 1; hm->size++; }
    }
    free(old_entries);
}

static HashMap_string_string* nl_hashmap_string_string_new(void) {
    return nl_hashmap_string_string_alloc(16);
}

static void nl_hashmap_string_string_put(HashMap_string_string *hm, const char* key, const char* value) {
    if (!hm) return;
    if ((hm->size + hm->tombstones) * 10 >= hm->capacity * 7) {
        nl_hashmap_string_string_rehash(hm, hm->capacity * 2);
    }
    bool found = false;
    int64_t idx = nl_hashmap_string_string_find_slot(hm, key, &found);
    if (idx < 0) return;
    HashMap_string_string_Entry *e = &hm->entries[idx];
    if (found) {
        if (e->value) free(e->value);
        e->value = value ? strdup(value) : strdup("");
        return;
    }
    if (e->state == 2) { hm->tombstones--; }
    e->state = 1;
    e->key = key ? strdup(key) : strdup("");
    e->value = value ? strdup(value) : strdup("");
    hm->size++;
}

static bool nl_hashmap_string_string_has(HashMap_string_string *hm, const char* key) {
    if (!hm) return false;
    bool found = false;
    int64_t idx = nl_hashmap_string_string_find_slot(hm, key, &found);
    (void)idx;
    return found;
}

static const char* nl_hashmap_string_string_get(HashMap_string_string *hm, const char* key) {
    if (!hm) return "";
    bool found = false;
    int64_t idx = nl_hashmap_string_string_find_slot(hm, key, &found);
    if (!found || idx < 0) return "";
    HashMap_string_string_Entry *e = &hm->entries[idx];
    return e->value ? e->value : "";
}

static void nl_hashmap_string_string_remove(HashMap_string_string *hm, const char* key) {
    if (!hm) return;
    bool found = false;
    int64_t idx = nl_hashmap_string_string_find_slot(hm, key, &found);
    if (!found || idx < 0) return;
    HashMap_string_string_Entry *e = &hm->entries[idx];
    if (e->key) free(e->key);
    if (e->value) free(e->value);
    e->state = 2;
    hm->size--;
    hm->tombstones++;
}

static int64_t nl_hashmap_string_string_length(HashMap_string_string *hm) {
    return hm ? hm->size : 0;
}

static void nl_hashmap_string_string_clear(HashMap_string_string *hm) {
    if (!hm) return;
    for (int64_t i2 = 0; i2 < hm->capacity; i2++) {
        HashMap_string_string_Entry *e = &hm->entries[i2];
        if (e->state != 1) { e->state = 0; continue; }
        if (e->key) free(e->key);
        if (e->value) free(e->value);
        e->state = 0;
    }
    hm->size = 0;
    hm->tombstones = 0;
}

static void nl_hashmap_string_string_free(HashMap_string_string *hm) {
    if (!hm) return;
    nl_hashmap_string_string_clear(hm);
    free(hm->entries);
    free(hm);
}

static DynArray* nl_hashmap_string_string_keys(HashMap_string_string *hm) {
    DynArray* out = dyn_array_new(ELEM_STRING);
    if (!hm) return out;
    for (int64_t i2 = 0; i2 < hm->capacity; i2++) {
        HashMap_string_string_Entry *e = &hm->entries[i2];
        if (e->state != 1) continue;
        dyn_array_push_string(out, e->key);
    }
    return out;
}

static DynArray* nl_hashmap_string_string_values(HashMap_string_string *hm) {
    DynArray* out = dyn_array_new(ELEM_STRING);
    if (!hm) return out;
    for (int64_t i2 = 0; i2 < hm->capacity; i2++) {
        HashMap_string_string_Entry *e = &hm->entries[i2];
        if (e->state != 1) continue;
        dyn_array_push_string(out, e->value);
    }
    return out;
}

/* ========== End HashMap Runtime (Generated) ========== */

/* ========== To-String Helpers ========== */

/* To-String forward declarations */
static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v);
static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v);
static const char* nl_to_string_TypeKind(nl_TypeKind v);
static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v);
static const char* nl_to_string_CompilerPhase(CompilerPhase v);
static const char* nl_to_string___nano_record_6572726f725f6d65737361676573_ErrorMessage(nl___nano_record_6572726f725f6d65737361676573_ErrorMessage v);

static const char* nl_to_string_LexerTokenType(nl_LexerTokenType v) {
    switch (v) {
        case nl_LexerTokenType_TOKEN_EOF: return "LexerTokenType.TOKEN_EOF";
        case nl_LexerTokenType_TOKEN_NUMBER: return "LexerTokenType.TOKEN_NUMBER";
        case nl_LexerTokenType_TOKEN_FLOAT: return "LexerTokenType.TOKEN_FLOAT";
        case nl_LexerTokenType_TOKEN_STRING: return "LexerTokenType.TOKEN_STRING";
        case nl_LexerTokenType_TOKEN_IDENTIFIER: return "LexerTokenType.TOKEN_IDENTIFIER";
        case nl_LexerTokenType_TOKEN_TRUE: return "LexerTokenType.TOKEN_TRUE";
        case nl_LexerTokenType_TOKEN_FALSE: return "LexerTokenType.TOKEN_FALSE";
        case nl_LexerTokenType_TOKEN_LPAREN: return "LexerTokenType.TOKEN_LPAREN";
        case nl_LexerTokenType_TOKEN_RPAREN: return "LexerTokenType.TOKEN_RPAREN";
        case nl_LexerTokenType_TOKEN_LBRACE: return "LexerTokenType.TOKEN_LBRACE";
        case nl_LexerTokenType_TOKEN_RBRACE: return "LexerTokenType.TOKEN_RBRACE";
        case nl_LexerTokenType_TOKEN_LBRACKET: return "LexerTokenType.TOKEN_LBRACKET";
        case nl_LexerTokenType_TOKEN_RBRACKET: return "LexerTokenType.TOKEN_RBRACKET";
        case nl_LexerTokenType_TOKEN_COMMA: return "LexerTokenType.TOKEN_COMMA";
        case nl_LexerTokenType_TOKEN_COLON: return "LexerTokenType.TOKEN_COLON";
        case nl_LexerTokenType_TOKEN_DOUBLE_COLON: return "LexerTokenType.TOKEN_DOUBLE_COLON";
        case nl_LexerTokenType_TOKEN_ARROW: return "LexerTokenType.TOKEN_ARROW";
        case nl_LexerTokenType_TOKEN_ASSIGN: return "LexerTokenType.TOKEN_ASSIGN";
        case nl_LexerTokenType_TOKEN_DOT: return "LexerTokenType.TOKEN_DOT";
        case nl_LexerTokenType_TOKEN_MODULE: return "LexerTokenType.TOKEN_MODULE";
        case nl_LexerTokenType_TOKEN_PUB: return "LexerTokenType.TOKEN_PUB";
        case nl_LexerTokenType_TOKEN_FROM: return "LexerTokenType.TOKEN_FROM";
        case nl_LexerTokenType_TOKEN_USE: return "LexerTokenType.TOKEN_USE";
        case nl_LexerTokenType_TOKEN_EXTERN: return "LexerTokenType.TOKEN_EXTERN";
        case nl_LexerTokenType_TOKEN_FN: return "LexerTokenType.TOKEN_FN";
        case nl_LexerTokenType_TOKEN_LET: return "LexerTokenType.TOKEN_LET";
        case nl_LexerTokenType_TOKEN_MUT: return "LexerTokenType.TOKEN_MUT";
        case nl_LexerTokenType_TOKEN_SET: return "LexerTokenType.TOKEN_SET";
        case nl_LexerTokenType_TOKEN_IF: return "LexerTokenType.TOKEN_IF";
        case nl_LexerTokenType_TOKEN_ELSE: return "LexerTokenType.TOKEN_ELSE";
        case nl_LexerTokenType_TOKEN_COND: return "LexerTokenType.TOKEN_COND";
        case nl_LexerTokenType_TOKEN_WHILE: return "LexerTokenType.TOKEN_WHILE";
        case nl_LexerTokenType_TOKEN_FOR: return "LexerTokenType.TOKEN_FOR";
        case nl_LexerTokenType_TOKEN_IN: return "LexerTokenType.TOKEN_IN";
        case nl_LexerTokenType_TOKEN_RETURN: return "LexerTokenType.TOKEN_RETURN";
        case nl_LexerTokenType_TOKEN_BREAK: return "LexerTokenType.TOKEN_BREAK";
        case nl_LexerTokenType_TOKEN_CONTINUE: return "LexerTokenType.TOKEN_CONTINUE";
        case nl_LexerTokenType_TOKEN_ASSERT: return "LexerTokenType.TOKEN_ASSERT";
        case nl_LexerTokenType_TOKEN_SHADOW: return "LexerTokenType.TOKEN_SHADOW";
        case nl_LexerTokenType_TOKEN_REQUIRES: return "LexerTokenType.TOKEN_REQUIRES";
        case nl_LexerTokenType_TOKEN_ENSURES: return "LexerTokenType.TOKEN_ENSURES";
        case nl_LexerTokenType_TOKEN_PRINT: return "LexerTokenType.TOKEN_PRINT";
        case nl_LexerTokenType_TOKEN_ARRAY: return "LexerTokenType.TOKEN_ARRAY";
        case nl_LexerTokenType_TOKEN_STRUCT: return "LexerTokenType.TOKEN_STRUCT";
        case nl_LexerTokenType_TOKEN_ENUM: return "LexerTokenType.TOKEN_ENUM";
        case nl_LexerTokenType_TOKEN_UNION: return "LexerTokenType.TOKEN_UNION";
        case nl_LexerTokenType_TOKEN_MATCH: return "LexerTokenType.TOKEN_MATCH";
        case nl_LexerTokenType_TOKEN_IMPORT: return "LexerTokenType.TOKEN_IMPORT";
        case nl_LexerTokenType_TOKEN_AS: return "LexerTokenType.TOKEN_AS";
        case nl_LexerTokenType_TOKEN_OPAQUE: return "LexerTokenType.TOKEN_OPAQUE";
        case nl_LexerTokenType_TOKEN_TYPE_INT: return "LexerTokenType.TOKEN_TYPE_INT";
        case nl_LexerTokenType_TOKEN_TYPE_U8: return "LexerTokenType.TOKEN_TYPE_U8";
        case nl_LexerTokenType_TOKEN_TYPE_FLOAT: return "LexerTokenType.TOKEN_TYPE_FLOAT";
        case nl_LexerTokenType_TOKEN_TYPE_BOOL: return "LexerTokenType.TOKEN_TYPE_BOOL";
        case nl_LexerTokenType_TOKEN_TYPE_STRING: return "LexerTokenType.TOKEN_TYPE_STRING";
        case nl_LexerTokenType_TOKEN_TYPE_BSTRING: return "LexerTokenType.TOKEN_TYPE_BSTRING";
        case nl_LexerTokenType_TOKEN_TYPE_VOID: return "LexerTokenType.TOKEN_TYPE_VOID";
        case nl_LexerTokenType_TOKEN_PLUS: return "LexerTokenType.TOKEN_PLUS";
        case nl_LexerTokenType_TOKEN_MINUS: return "LexerTokenType.TOKEN_MINUS";
        case nl_LexerTokenType_TOKEN_STAR: return "LexerTokenType.TOKEN_STAR";
        case nl_LexerTokenType_TOKEN_SLASH: return "LexerTokenType.TOKEN_SLASH";
        case nl_LexerTokenType_TOKEN_PERCENT: return "LexerTokenType.TOKEN_PERCENT";
        case nl_LexerTokenType_TOKEN_EQ: return "LexerTokenType.TOKEN_EQ";
        case nl_LexerTokenType_TOKEN_NE: return "LexerTokenType.TOKEN_NE";
        case nl_LexerTokenType_TOKEN_LT: return "LexerTokenType.TOKEN_LT";
        case nl_LexerTokenType_TOKEN_LE: return "LexerTokenType.TOKEN_LE";
        case nl_LexerTokenType_TOKEN_GT: return "LexerTokenType.TOKEN_GT";
        case nl_LexerTokenType_TOKEN_GE: return "LexerTokenType.TOKEN_GE";
        case nl_LexerTokenType_TOKEN_AND: return "LexerTokenType.TOKEN_AND";
        case nl_LexerTokenType_TOKEN_OR: return "LexerTokenType.TOKEN_OR";
        case nl_LexerTokenType_TOKEN_NOT: return "LexerTokenType.TOKEN_NOT";
        case nl_LexerTokenType_TOKEN_RANGE: return "LexerTokenType.TOKEN_RANGE";
        case nl_LexerTokenType_TOKEN_UNSAFE: return "LexerTokenType.TOKEN_UNSAFE";
        case nl_LexerTokenType_TOKEN_RESOURCE: return "LexerTokenType.TOKEN_RESOURCE";
        case nl_LexerTokenType_TOKEN_PIPE: return "LexerTokenType.TOKEN_PIPE";
        case nl_LexerTokenType_TOKEN_GRAMMAR: return "LexerTokenType.TOKEN_GRAMMAR";
        case nl_LexerTokenType_TOKEN_LARROW: return "LexerTokenType.TOKEN_LARROW";
        case nl_LexerTokenType_TOKEN_QUESTION: return "LexerTokenType.TOKEN_QUESTION";
        case nl_LexerTokenType_TOKEN_PAR: return "LexerTokenType.TOKEN_PAR";
        case nl_LexerTokenType_TOKEN_BAR: return "LexerTokenType.TOKEN_BAR";
        case nl_LexerTokenType_TOKEN_EFFECT: return "LexerTokenType.TOKEN_EFFECT";
        case nl_LexerTokenType_TOKEN_HANDLE: return "LexerTokenType.TOKEN_HANDLE";
        case nl_LexerTokenType_TOKEN_WITH: return "LexerTokenType.TOKEN_WITH";
        case nl_LexerTokenType_TOKEN_RESUME: return "LexerTokenType.TOKEN_RESUME";
        case nl_LexerTokenType_TOKEN_GPU: return "LexerTokenType.TOKEN_GPU";
        case nl_LexerTokenType_TOKEN_ASYNC: return "LexerTokenType.TOKEN_ASYNC";
        case nl_LexerTokenType_TOKEN_AWAIT: return "LexerTokenType.TOKEN_AWAIT";
        case nl_LexerTokenType_TOKEN_PURE: return "LexerTokenType.TOKEN_PURE";
        case nl_LexerTokenType_TOKEN_AMPERSAND: return "LexerTokenType.TOKEN_AMPERSAND";
        default: return "LexerTokenType.<unknown>";
    }
}

static const char* nl_to_string_ParseNodeType(nl_ParseNodeType v) {
    switch (v) {
        case nl_ParseNodeType_PNODE_NUMBER: return "ParseNodeType.PNODE_NUMBER";
        case nl_ParseNodeType_PNODE_FLOAT: return "ParseNodeType.PNODE_FLOAT";
        case nl_ParseNodeType_PNODE_STRING: return "ParseNodeType.PNODE_STRING";
        case nl_ParseNodeType_PNODE_BOOL: return "ParseNodeType.PNODE_BOOL";
        case nl_ParseNodeType_PNODE_IDENTIFIER: return "ParseNodeType.PNODE_IDENTIFIER";
        case nl_ParseNodeType_PNODE_BINARY_OP: return "ParseNodeType.PNODE_BINARY_OP";
        case nl_ParseNodeType_PNODE_CALL: return "ParseNodeType.PNODE_CALL";
        case nl_ParseNodeType_PNODE_ARRAY_LITERAL: return "ParseNodeType.PNODE_ARRAY_LITERAL";
        case nl_ParseNodeType_PNODE_LET: return "ParseNodeType.PNODE_LET";
        case nl_ParseNodeType_PNODE_SET: return "ParseNodeType.PNODE_SET";
        case nl_ParseNodeType_PNODE_IF: return "ParseNodeType.PNODE_IF";
        case nl_ParseNodeType_PNODE_COND: return "ParseNodeType.PNODE_COND";
        case nl_ParseNodeType_PNODE_WHILE: return "ParseNodeType.PNODE_WHILE";
        case nl_ParseNodeType_PNODE_FOR: return "ParseNodeType.PNODE_FOR";
        case nl_ParseNodeType_PNODE_RETURN: return "ParseNodeType.PNODE_RETURN";
        case nl_ParseNodeType_PNODE_BREAK: return "ParseNodeType.PNODE_BREAK";
        case nl_ParseNodeType_PNODE_CONTINUE: return "ParseNodeType.PNODE_CONTINUE";
        case nl_ParseNodeType_PNODE_BLOCK: return "ParseNodeType.PNODE_BLOCK";
        case nl_ParseNodeType_PNODE_PRINT: return "ParseNodeType.PNODE_PRINT";
        case nl_ParseNodeType_PNODE_ASSERT: return "ParseNodeType.PNODE_ASSERT";
        case nl_ParseNodeType_PNODE_PROGRAM: return "ParseNodeType.PNODE_PROGRAM";
        case nl_ParseNodeType_PNODE_FUNCTION: return "ParseNodeType.PNODE_FUNCTION";
        case nl_ParseNodeType_PNODE_SHADOW: return "ParseNodeType.PNODE_SHADOW";
        case nl_ParseNodeType_PNODE_STRUCT_DEF: return "ParseNodeType.PNODE_STRUCT_DEF";
        case nl_ParseNodeType_PNODE_STRUCT_LITERAL: return "ParseNodeType.PNODE_STRUCT_LITERAL";
        case nl_ParseNodeType_PNODE_FIELD_ACCESS: return "ParseNodeType.PNODE_FIELD_ACCESS";
        case nl_ParseNodeType_PNODE_ENUM_DEF: return "ParseNodeType.PNODE_ENUM_DEF";
        case nl_ParseNodeType_PNODE_UNION_DEF: return "ParseNodeType.PNODE_UNION_DEF";
        case nl_ParseNodeType_PNODE_UNION_CONSTRUCT: return "ParseNodeType.PNODE_UNION_CONSTRUCT";
        case nl_ParseNodeType_PNODE_MATCH: return "ParseNodeType.PNODE_MATCH";
        case nl_ParseNodeType_PNODE_IMPORT: return "ParseNodeType.PNODE_IMPORT";
        case nl_ParseNodeType_PNODE_OPAQUE_TYPE: return "ParseNodeType.PNODE_OPAQUE_TYPE";
        case nl_ParseNodeType_PNODE_TUPLE_LITERAL: return "ParseNodeType.PNODE_TUPLE_LITERAL";
        case nl_ParseNodeType_PNODE_TUPLE_INDEX: return "ParseNodeType.PNODE_TUPLE_INDEX";
        case nl_ParseNodeType_PNODE_STRUCT: return "ParseNodeType.PNODE_STRUCT";
        case nl_ParseNodeType_PNODE_ENUM: return "ParseNodeType.PNODE_ENUM";
        case nl_ParseNodeType_PNODE_UNION: return "ParseNodeType.PNODE_UNION";
        case nl_ParseNodeType_PNODE_UNSAFE_BLOCK: return "ParseNodeType.PNODE_UNSAFE_BLOCK";
        case nl_ParseNodeType_PNODE_MODULE_QUALIFIED_CALL: return "ParseNodeType.PNODE_MODULE_QUALIFIED_CALL";
        case nl_ParseNodeType_PNODE_GRAMMAR: return "ParseNodeType.PNODE_GRAMMAR";
        case nl_ParseNodeType_PNODE_PAR_BLOCK: return "ParseNodeType.PNODE_PAR_BLOCK";
        case nl_ParseNodeType_PNODE_EFFECT_DECL: return "ParseNodeType.PNODE_EFFECT_DECL";
        case nl_ParseNodeType_PNODE_HANDLE_EXPR: return "ParseNodeType.PNODE_HANDLE_EXPR";
        case nl_ParseNodeType_PNODE_ASYNC_FN: return "ParseNodeType.PNODE_ASYNC_FN";
        case nl_ParseNodeType_PNODE_SERVICE_DECL: return "ParseNodeType.PNODE_SERVICE_DECL";
        default: return "ParseNodeType.<unknown>";
    }
}

static const char* nl_to_string_TypeKind(nl_TypeKind v) {
    switch (v) {
        case nl_TypeKind_TYPE_INT: return "TypeKind.TYPE_INT";
        case nl_TypeKind_TYPE_FLOAT: return "TypeKind.TYPE_FLOAT";
        case nl_TypeKind_TYPE_BOOL: return "TypeKind.TYPE_BOOL";
        case nl_TypeKind_TYPE_STRING: return "TypeKind.TYPE_STRING";
        case nl_TypeKind_TYPE_VOID: return "TypeKind.TYPE_VOID";
        case nl_TypeKind_TYPE_ARRAY: return "TypeKind.TYPE_ARRAY";
        case nl_TypeKind_TYPE_STRUCT: return "TypeKind.TYPE_STRUCT";
        case nl_TypeKind_TYPE_ENUM: return "TypeKind.TYPE_ENUM";
        case nl_TypeKind_TYPE_UNION: return "TypeKind.TYPE_UNION";
        case nl_TypeKind_TYPE_GENERIC: return "TypeKind.TYPE_GENERIC";
        case nl_TypeKind_TYPE_LIST_INT: return "TypeKind.TYPE_LIST_INT";
        case nl_TypeKind_TYPE_LIST_STRING: return "TypeKind.TYPE_LIST_STRING";
        case nl_TypeKind_TYPE_LIST_TOKEN: return "TypeKind.TYPE_LIST_TOKEN";
        case nl_TypeKind_TYPE_LIST_GENERIC: return "TypeKind.TYPE_LIST_GENERIC";
        case nl_TypeKind_TYPE_FUNCTION: return "TypeKind.TYPE_FUNCTION";
        case nl_TypeKind_TYPE_TUPLE: return "TypeKind.TYPE_TUPLE";
        case nl_TypeKind_TYPE_OPAQUE: return "TypeKind.TYPE_OPAQUE";
        case nl_TypeKind_TYPE_UNKNOWN: return "TypeKind.TYPE_UNKNOWN";
        default: return "TypeKind.<unknown>";
    }
}

static const char* nl_to_string_DiagnosticSeverity(DiagnosticSeverity v) {
    switch (v) {
        case DiagnosticSeverity_DIAG_INFO: return "DiagnosticSeverity.DIAG_INFO";
        case DiagnosticSeverity_DIAG_WARNING: return "DiagnosticSeverity.DIAG_WARNING";
        case DiagnosticSeverity_DIAG_ERROR: return "DiagnosticSeverity.DIAG_ERROR";
        default: return "DiagnosticSeverity.<unknown>";
    }
}

static const char* nl_to_string_CompilerPhase(CompilerPhase v) {
    switch (v) {
        case CompilerPhase_PHASE_LEXER: return "CompilerPhase.PHASE_LEXER";
        case CompilerPhase_PHASE_PARSER: return "CompilerPhase.PHASE_PARSER";
        case CompilerPhase_PHASE_TYPECHECK: return "CompilerPhase.PHASE_TYPECHECK";
        case CompilerPhase_PHASE_TRANSPILER: return "CompilerPhase.PHASE_TRANSPILER";
        case CompilerPhase_PHASE_RUNTIME: return "CompilerPhase.PHASE_RUNTIME";
        default: return "CompilerPhase.<unknown>";
    }
}

static const char* nl_to_string___nano_record_6572726f725f6d65737361676573_ErrorMessage(nl___nano_record_6572726f725f6d65737361676573_ErrorMessage v) {
    nl_fmt_sb_t sb = nl_fmt_sb_new(256);
    nl_fmt_sb_append_cstr(&sb, "ErrorMessage { ");
    nl_fmt_sb_append_cstr(&sb, "title: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.title));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "file: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.file));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "line: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.line));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "column: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_int(v.column));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "problem: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.problem));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "code_snippet: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.code_snippet));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "explanation: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.explanation));
    nl_fmt_sb_append_cstr(&sb, ", ");
    nl_fmt_sb_append_cstr(&sb, "suggestion: ");
    nl_fmt_sb_append_cstr(&sb, nl_to_string_string(v.suggestion));
    nl_fmt_sb_append_cstr(&sb, " }");
    return nl_fmt_sb_build(&sb);
}

/* ========== End To-String Helpers ========== */

/* External C function declarations */

/* Forward declarations for imported module functions */
extern CompilerSourceLocation diagnostics__diag_location(const char* file, int64_t line, int64_t column);
extern CompilerSourceLocation diagnostics__diag_location_empty();
extern CompilerDiagnostic diagnostics__diag_new(int64_t phase, int64_t severity, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_simple(int64_t phase, int64_t severity, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_error(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_error_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_warning(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_warning_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_info(int64_t phase, const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_info_simple(int64_t phase, const char* code, const char* message);
extern CompilerDiagnostic diagnostics__diag_lexer_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_parser_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_typecheck_error(const char* code, const char* message, CompilerSourceLocation location);
extern CompilerDiagnostic diagnostics__diag_transpiler_error(const char* code, const char* message, CompilerSourceLocation location);
extern List_CompilerDiagnostic* diagnostics__diag_list_new();
extern void diagnostics__diag_list_add(List_CompilerDiagnostic* list, CompilerDiagnostic diag);
extern int64_t diagnostics__diag_list_count(List_CompilerDiagnostic* list);
extern CompilerDiagnostic diagnostics__diag_list_get(List_CompilerDiagnostic* list, int64_t index);
extern bool diagnostics__diag_list_has_errors(List_CompilerDiagnostic* list);
extern const char* diagnostics__diag_make_type_error(const char* expected_type, const char* found_type);
extern const char* diagnostics__diag_make_undefined_error(const char* name);
extern const char* diagnostics__diag_id_io_open();
extern const char* diagnostics__diag_id_lex_failed();
extern const char* diagnostics__diag_id_parse_failed();
extern const char* diagnostics__diag_id_import_failed();
extern const char* diagnostics__diag_id_type_failed();
extern const char* diagnostics__diag_id_mod_compile();
extern const char* diagnostics__diag_id_shadow_failed();
extern const char* diagnostics__diag_id_trans_failed();
extern const char* diagnostics__diag_id_c_temp();
extern const char* diagnostics__diag_id_cc_cmd();
extern const char* diagnostics__diag_id_cc_failed();
extern const char* diagnostics__diag_id_src_utf8();
extern const char* diagnostics__diag_en(const char* code);

/* Forward declarations for program functions */
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_message_new(const char* title, const char* file, int64_t line, int64_t column);
const char* error_messages__repeat_string(const char* s, int64_t count);
const char* error_messages__pad_right(const char* s, int64_t target_len);
const char* error_messages__wrap_backticks(const char* value);
const char* error_messages__get_line_from_source(const char* source, int64_t target_line);
const char* error_messages__format_error_elm_style(nl___nano_record_6572726f725f6d65737361676573_ErrorMessage err, const char* source);
HashMap_string_string* error_messages__build_error_explanations();
HashMap_string_string* error_messages__build_error_suggestions();
const char* error_messages__explanation_for_code(const char* code);
const char* error_messages__suggestion_for_code(const char* code);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__diagnostic_to_elm_error(CompilerDiagnostic diag);
const char* error_messages__format_diagnostics_elm_style(List_CompilerDiagnostic* diags, const char* source);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_type_mismatch(const char* file, int64_t line, int64_t column, const char* expected, const char* found, const char* context);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_undefined_variable(const char* file, int64_t line, int64_t column, const char* var_name, List_string* similar_names);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_arity_mismatch(const char* file, int64_t line, int64_t column, const char* function_name, int64_t expected_args, int64_t found_args);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_missing_return(const char* file, int64_t line, int64_t column, const char* function_name, const char* expected_type);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_immutable_assignment(const char* file, int64_t line, int64_t column, const char* var_name);
const char* error_messages__encode_type_mismatch_message(const char* context, const char* expected, const char* found, const char* detail);
const char* error_messages__encode_undefined_name_message(const char* name);
const char* error_messages__encode_wrong_arg_count_message(const char* function_name, int64_t expected_args, int64_t found_args);
const char* error_messages__encode_missing_return_message(const char* function_name, const char* expected_type);
const char* error_messages__encode_immutable_assignment_message(const char* var_name);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_unsafe_required(const char* file, int64_t line, int64_t column, const char* function_name);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_use_after_consume(const char* file, int64_t line, int64_t column, const char* resource_name, int64_t consumed_at_line);
nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_resource_leak(const char* file, int64_t line, int64_t column, const char* resource_name, const char* resource_type);
const char* error_messages__get_error_template(const char* error_code);

/* Top-level globals */

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_message_new(const char* title, const char* file, int64_t line, int64_t column) {
#line 48 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = title, .file = file, .line = line, .column = column, .problem = "", .code_snippet = "", .explanation = "", .suggestion = ""};
}

const char* error_messages__repeat_string(const char* s, int64_t count) {
#line 72 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* out = "";
#line 73 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t i = 0LL;
#line 74 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    while ((i) < (count))     {
#line 75 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, s);
#line 76 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        i = ((i) + (1LL));
    }
#line 78 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return out;
}

const char* error_messages__pad_right(const char* s, int64_t target_len) {
#line 86 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t len = ({ __auto_type __nl_arg_2561_0 = s; nl_cstr_length(__nl_arg_2561_0); });
#line 87 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((len) >= (target_len))     {
#line 88 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return s;
    }
#line 90 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat(s, ({ __auto_type __nl_arg_2562_0 = " "; __auto_type __nl_arg_2562_1 = ((target_len) - (len)); error_messages__repeat_string(__nl_arg_2562_0, __nl_arg_2562_1); }));
}

const char* error_messages__wrap_backticks(const char* value) {
#line 98 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat("`", nl_str_concat(value, "`"));
}

const char* error_messages__get_line_from_source(const char* source, int64_t target_line) {
#line 106 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t current_line = 1LL;
#line 107 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t start_idx = 0LL;
#line 108 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t i = 0LL;
#line 109 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t total_len = ({ __auto_type __nl_arg_2563_0 = source; nl_cstr_length(__nl_arg_2563_0); });
#line 111 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    while ((i) < (total_len))     {
#line 112 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        if ((({ __auto_type __nl_arg_2564_0 = source; __auto_type __nl_arg_2564_1 = i; char_at(__nl_arg_2564_0, __nl_arg_2564_1); })) == (10LL))         {
#line 113 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            if ((current_line) == (target_line))             {
#line 114 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                return ({ __auto_type __nl_arg_2565_0 = source; __auto_type __nl_arg_2565_1 = start_idx; __auto_type __nl_arg_2565_2 = ((i) - (start_idx)); nl_str_substring(__nl_arg_2565_0, __nl_arg_2565_1, __nl_arg_2565_2); });
            }
#line 116 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            current_line = ((current_line) + (1LL));
#line 117 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            start_idx = ((i) + (1LL));
        }
#line 119 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        i = ((i) + (1LL));
    }
#line 122 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((current_line) == (target_line))     {
#line 123 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return ({ __auto_type __nl_arg_2566_0 = source; __auto_type __nl_arg_2566_1 = start_idx; __auto_type __nl_arg_2566_2 = ((total_len) - (start_idx)); nl_str_substring(__nl_arg_2566_0, __nl_arg_2566_1, __nl_arg_2566_2); });
    }
#line 126 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return "";
}

const char* error_messages__format_error_elm_style(nl___nano_record_6572726f725f6d65737361676573_ErrorMessage err, const char* source) {
#line 148 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* out = "";
#line 151 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* header_base = nl_str_concat("-- ", nl_str_concat(err.title, " "));
#line 152 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t dash_count = ((60LL) - (({ __auto_type __nl_arg_2567_0 = header_base; nl_cstr_length(__nl_arg_2567_0); })));
#line 153 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((dash_count) < (5LL))     {
#line 153 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        dash_count = 5LL;
    }
#line 154 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* full_header = nl_str_concat(header_base, nl_str_concat(({ __auto_type __nl_arg_2568_0 = "-"; __auto_type __nl_arg_2568_1 = dash_count; error_messages__repeat_string(__nl_arg_2568_0, __nl_arg_2568_1); }), nl_str_concat(" ", err.file)));
#line 156 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    out = nl_str_concat(full_header, "\n\n");
#line 159 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    out = nl_str_concat(out, nl_str_concat(err.problem, "\n\n"));
#line 162 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((err.line) > (0LL))     {
#line 163 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        const char* line_content = ({ __auto_type __nl_arg_2569_0 = source; __auto_type __nl_arg_2569_1 = err.line; error_messages__get_line_from_source(__nl_arg_2569_0, __nl_arg_2569_1); });
#line 164 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        const char* line_num_str = ({ __auto_type __nl_arg_2570_0 = err.line; int_to_string(__nl_arg_2570_0); });
#line 165 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        const char* padding = ({ __auto_type __nl_arg_2571_0 = " "; __auto_type __nl_arg_2571_1 = ({ __auto_type __nl_arg_2572_0 = line_num_str; nl_cstr_length(__nl_arg_2572_0); }); error_messages__repeat_string(__nl_arg_2571_0, __nl_arg_2571_1); });
#line 167 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, nl_str_concat(line_num_str, nl_str_concat("| ", nl_str_concat(line_content, "\n"))));
#line 168 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, nl_str_concat(padding, nl_str_concat("| ", nl_str_concat(({ __auto_type __nl_arg_2573_0 = " "; __auto_type __nl_arg_2573_1 = ((err.column) - (1LL)); error_messages__repeat_string(__nl_arg_2573_0, __nl_arg_2573_1); }), "^\n\n"))));
    }
#line 172 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(err.explanation, "") != 0))     {
#line 173 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, nl_str_concat(err.explanation, "\n\n"));
    }
#line 177 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(err.suggestion, "") != 0))     {
#line 178 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, nl_str_concat("Hint: ", nl_str_concat(err.suggestion, "\n")));
    }
#line 181 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return out;
}

HashMap_string_string* error_messages__build_error_explanations() {
#line 189 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    HashMap_string_string* m = nl_hashmap_string_string_new();
#line 190 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_0_arg_0 = m; __auto_type __nl_map_0_arg_1 = "E0001"; __auto_type __nl_map_0_arg_2 = "NanoLang enforces explicit types, so the expression must match the expected annotation."; nl_hashmap_string_string_put(__nl_map_0_arg_0, __nl_map_0_arg_1, __nl_map_0_arg_2); });
#line 191 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_1_arg_0 = m; __auto_type __nl_map_1_arg_1 = "E0002"; __auto_type __nl_map_1_arg_2 = "The compiler could not find a declaration with this name in the current scope."; nl_hashmap_string_string_put(__nl_map_1_arg_0, __nl_map_1_arg_1, __nl_map_1_arg_2); });
#line 192 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_2_arg_0 = m; __auto_type __nl_map_2_arg_1 = "E0003"; __auto_type __nl_map_2_arg_2 = "Functions require the exact number of arguments specified in their signature."; nl_hashmap_string_string_put(__nl_map_2_arg_0, __nl_map_2_arg_1, __nl_map_2_arg_2); });
#line 193 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_3_arg_0 = m; __auto_type __nl_map_3_arg_1 = "E0004"; __auto_type __nl_map_3_arg_2 = "Each argument must match the corresponding parameter type declared in the function signature."; nl_hashmap_string_string_put(__nl_map_3_arg_0, __nl_map_3_arg_1, __nl_map_3_arg_2); });
#line 194 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_4_arg_0 = m; __auto_type __nl_map_4_arg_1 = "E0005"; __auto_type __nl_map_4_arg_2 = "Bindings are immutable unless declared with `mut`, so you cannot reassign them."; nl_hashmap_string_string_put(__nl_map_4_arg_0, __nl_map_4_arg_1, __nl_map_4_arg_2); });
#line 195 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return m;
    gc_release(m);
}

HashMap_string_string* error_messages__build_error_suggestions() {
#line 204 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    HashMap_string_string* m = nl_hashmap_string_string_new();
#line 205 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_5_arg_0 = m; __auto_type __nl_map_5_arg_1 = "E0001"; __auto_type __nl_map_5_arg_2 = "Convert the expression to the expected type or change the annotation."; nl_hashmap_string_string_put(__nl_map_5_arg_0, __nl_map_5_arg_1, __nl_map_5_arg_2); });
#line 206 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_6_arg_0 = m; __auto_type __nl_map_6_arg_1 = "E0002"; __auto_type __nl_map_6_arg_2 = "Check for typos or declare the identifier with `let` before using it."; nl_hashmap_string_string_put(__nl_map_6_arg_0, __nl_map_6_arg_1, __nl_map_6_arg_2); });
#line 207 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_7_arg_0 = m; __auto_type __nl_map_7_arg_1 = "E0003"; __auto_type __nl_map_7_arg_2 = "Add the missing arguments or remove extras so the call arity matches the definition."; nl_hashmap_string_string_put(__nl_map_7_arg_0, __nl_map_7_arg_1, __nl_map_7_arg_2); });
#line 208 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_8_arg_0 = m; __auto_type __nl_map_8_arg_1 = "E0004"; __auto_type __nl_map_8_arg_2 = "Convert the argument to the required type or update the function signature if the annotation is wrong."; nl_hashmap_string_string_put(__nl_map_8_arg_0, __nl_map_8_arg_1, __nl_map_8_arg_2); });
#line 209 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    ({ __auto_type __nl_map_9_arg_0 = m; __auto_type __nl_map_9_arg_1 = "E0005"; __auto_type __nl_map_9_arg_2 = "Declare the variable with `mut` or create a new binding instead of reassigning."; nl_hashmap_string_string_put(__nl_map_9_arg_0, __nl_map_9_arg_1, __nl_map_9_arg_2); });
#line 210 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return m;
    gc_release(m);
}

const char* error_messages__explanation_for_code(const char* code) {
#line 219 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    HashMap_string_string* explanations = ({ error_messages__build_error_explanations(); });
#line 220 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if (({ __auto_type __nl_map_10_arg_0 = explanations; __auto_type __nl_map_10_arg_1 = code; nl_hashmap_string_string_has(__nl_map_10_arg_0, __nl_map_10_arg_1); }))     {
#line 221 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return ({ __auto_type __nl_map_11_arg_0 = explanations; __auto_type __nl_map_11_arg_1 = code; nl_hashmap_string_string_get(__nl_map_11_arg_0, __nl_map_11_arg_1); });
    }
    else     {
#line 223 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return "";
    }
    gc_release(explanations);
}

const char* error_messages__suggestion_for_code(const char* code) {
#line 232 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    HashMap_string_string* suggestions = ({ error_messages__build_error_suggestions(); });
#line 233 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if (({ __auto_type __nl_map_12_arg_0 = suggestions; __auto_type __nl_map_12_arg_1 = code; nl_hashmap_string_string_has(__nl_map_12_arg_0, __nl_map_12_arg_1); }))     {
#line 234 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return ({ __auto_type __nl_map_13_arg_0 = suggestions; __auto_type __nl_map_13_arg_1 = code; nl_hashmap_string_string_get(__nl_map_13_arg_0, __nl_map_13_arg_1); });
    }
    else     {
#line 236 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return "";
    }
    gc_release(suggestions);
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__diagnostic_to_elm_error(CompilerDiagnostic diag) {
#line 245 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* title = "INFO";
#line 246 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(diag.code, "E0001") == 0))     {
#line 247 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        title = "TYPE MISMATCH";
    }
    else     {
#line 249 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        if ((strcmp(diag.code, "E0002") == 0))         {
#line 250 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            title = "UNDEFINED IDENTIFIER";
        }
        else         {
#line 252 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            if ((diag.severity) == (2LL))             {
#line 253 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                title = "ERROR";
            }
            else             {
#line 255 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                if ((diag.severity) == (1LL))                 {
#line 256 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                    title = "WARNING";
                }
                else                 {
#line 258 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                    nl_print_string("");
                }
            }
        }
    }
#line 264 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    CompilerSourceLocation loc = diag.location;
#line 265 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = title, .file = loc.file, .line = loc.line, .column = loc.column, .problem = diag.message, .code_snippet = "", .explanation = ({ __auto_type __nl_arg_2576_0 = diag.code; error_messages__explanation_for_code(__nl_arg_2576_0); }), .suggestion = ({ __auto_type __nl_arg_2577_0 = diag.code; error_messages__suggestion_for_code(__nl_arg_2577_0); })};
}

const char* error_messages__format_diagnostics_elm_style(List_CompilerDiagnostic* diags, const char* source) {
#line 286 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* out = "";
#line 287 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t count = ({ __auto_type __nl_arg_2578_0 = diags; diagnostics__diag_list_count(__nl_arg_2578_0); });
#line 288 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t i = 0LL;
#line 290 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    while ((i) < (count))     {
#line 291 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        CompilerDiagnostic diag = ({ __auto_type __nl_arg_2579_0 = diags; __auto_type __nl_arg_2579_1 = i; diagnostics__diag_list_get(__nl_arg_2579_0, __nl_arg_2579_1); });
#line 292 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        nl___nano_record_6572726f725f6d65737361676573_ErrorMessage elm_err = ({ __auto_type __nl_arg_2580_0 = diag; error_messages__diagnostic_to_elm_error(__nl_arg_2580_0); });
#line 293 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, ({ __auto_type __nl_arg_2581_0 = elm_err; __auto_type __nl_arg_2581_1 = source; error_messages__format_error_elm_style(__nl_arg_2581_0, __nl_arg_2581_1); }));
#line 294 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        out = nl_str_concat(out, "\n");
#line 295 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        i = ((i) + (1LL));
    }
#line 298 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return out;
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_type_mismatch(const char* file, int64_t line, int64_t column, const char* expected, const char* found, const char* context) {
#line 330 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = ({ __auto_type __nl_arg_2582_0 = context; __auto_type __nl_arg_2582_1 = expected; __auto_type __nl_arg_2582_2 = found; __auto_type __nl_arg_2582_3 = ""; error_messages__encode_type_mismatch_message(__nl_arg_2582_0, __nl_arg_2582_1, __nl_arg_2582_2, __nl_arg_2582_3); });
#line 331 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = ({ __auto_type __nl_arg_2583_0 = "E0001"; error_messages__explanation_for_code(__nl_arg_2583_0); });
#line 332 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(context, "function_argument") == 0))     {
#line 333 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        explanation = nl_str_concat("The function signature declares this parameter as ", nl_str_concat(({ __auto_type __nl_arg_2584_0 = expected; error_messages__wrap_backticks(__nl_arg_2584_0); }), "."));
    }
    else     {
#line 335 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        if ((strcmp(context, "variable_assignment") == 0))         {
#line 336 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            explanation = nl_str_concat("The variable was declared with type ", nl_str_concat(({ __auto_type __nl_arg_2585_0 = expected; error_messages__wrap_backticks(__nl_arg_2585_0); }), "."));
        }
        else         {
#line 338 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            nl_print_string("");
        }
    }
#line 341 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = ({ __auto_type __nl_arg_2586_0 = "E0001"; error_messages__suggestion_for_code(__nl_arg_2586_0); });
#line 342 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "TYPE MISMATCH", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_undefined_variable(const char* file, int64_t line, int64_t column, const char* var_name, List_string* similar_names) {
#line 367 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = ({ __auto_type __nl_arg_2587_0 = var_name; error_messages__encode_undefined_name_message(__nl_arg_2587_0); });
#line 368 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = ({ __auto_type __nl_arg_2588_0 = "E0002"; error_messages__explanation_for_code(__nl_arg_2588_0); });
#line 369 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    int64_t name_count = ({ __auto_type __nl_arg_2589_0 = similar_names; if (!__nl_arg_2589_0) nl_record_list_fail(); list_string_length(__nl_arg_2589_0); });
#line 370 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = nl_str_concat("Make sure to declare ", nl_str_concat(({ __auto_type __nl_arg_2590_0 = var_name; error_messages__wrap_backticks(__nl_arg_2590_0); }), " with `let` before using it."));
#line 371 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((name_count) > (0LL))     {
#line 372 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        const char* hint = "Did you mean one of these?\n";
#line 373 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        int64_t i = 0LL;
#line 374 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        while ((i) < (name_count))         {
#line 375 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            const char* candidate = ({ __auto_type __nl_arg_2591_0 = similar_names; __auto_type __nl_arg_2591_1 = i; if (!__nl_arg_2591_0) nl_record_list_fail(); __nl_arg_2591_1 = nl_native_list_index(__nl_arg_2591_1, list_string_length(__nl_arg_2591_0), false); list_string_get(__nl_arg_2591_0, __nl_arg_2591_1); });
#line 376 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            hint = nl_str_concat(hint, nl_str_concat("    ", nl_str_concat(candidate, "\n")));
#line 377 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            i = ((i) + (1LL));
        }
#line 379 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        suggestion = hint;
    }
    else     {
#line 381 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        nl_print_string("");
    }
#line 383 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "UNDEFINED VARIABLE", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_arity_mismatch(const char* file, int64_t line, int64_t column, const char* function_name, int64_t expected_args, int64_t found_args) {
#line 410 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = ({ __auto_type __nl_arg_2592_0 = function_name; __auto_type __nl_arg_2592_1 = expected_args; __auto_type __nl_arg_2592_2 = found_args; error_messages__encode_wrong_arg_count_message(__nl_arg_2592_0, __nl_arg_2592_1, __nl_arg_2592_2); });
#line 411 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = nl_str_concat("The function ", nl_str_concat(({ __auto_type __nl_arg_2593_0 = function_name; error_messages__wrap_backticks(__nl_arg_2593_0); }), " requires exactly this many arguments."));
#line 412 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = "Add the missing arguments to match the function signature.";
#line 413 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((found_args) > (expected_args))     {
#line 414 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        suggestion = "Remove the extra arguments to match the function signature.";
    }
    else     {
#line 416 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        nl_print_string("");
    }
#line 418 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "WRONG NUMBER OF ARGUMENTS", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_missing_return(const char* file, int64_t line, int64_t column, const char* function_name, const char* expected_type) {
#line 443 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = ({ __auto_type __nl_arg_2594_0 = function_name; __auto_type __nl_arg_2594_1 = expected_type; error_messages__encode_missing_return_message(__nl_arg_2594_0, __nl_arg_2594_1); });
#line 444 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = "All execution paths in a function must return a value of the declared type. Right now, some branches don't return anything.";
#line 445 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = nl_str_concat("Add a `return` statement to all branches that currently fall through, returning a value of type ", nl_str_concat(({ __auto_type __nl_arg_2595_0 = expected_type; error_messages__wrap_backticks(__nl_arg_2595_0); }), "."));
#line 446 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "MISSING RETURN", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_immutable_assignment(const char* file, int64_t line, int64_t column, const char* var_name) {
#line 470 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = ({ __auto_type __nl_arg_2596_0 = var_name; error_messages__encode_immutable_assignment_message(__nl_arg_2596_0); });
#line 471 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = "In NanoLang, variables are immutable by default. Once you assign a value to an immutable variable, you cannot change it later.";
#line 472 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = nl_str_concat("To make this variable mutable, add the `mut` keyword:\n    let mut ", nl_str_concat(var_name, ": <type> = <value>"));
#line 473 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "CANNOT ASSIGN TO IMMUTABLE VARIABLE", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

const char* error_messages__encode_type_mismatch_message(const char* context, const char* expected, const char* found, const char* detail) {
#line 491 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* expected_label = ({ __auto_type __nl_arg_2597_0 = expected; error_messages__wrap_backticks(__nl_arg_2597_0); });
#line 492 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* found_label = ({ __auto_type __nl_arg_2598_0 = found; error_messages__wrap_backticks(__nl_arg_2598_0); });
#line 493 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* base = nl_str_concat("I expected a value of type ", nl_str_concat(expected_label, nl_str_concat(", but found ", nl_str_concat(found_label, "."))));
#line 494 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(detail, "") != 0))     {
#line 495 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        base = nl_str_concat(detail, nl_str_concat(": ", base));
    }
    else     {
#line 497 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        if ((strcmp(context, "") != 0))         {
#line 498 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            base = nl_str_concat("In ", nl_str_concat(context, nl_str_concat(": ", base)));
        }
    }
#line 501 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return base;
}

const char* error_messages__encode_undefined_name_message(const char* name) {
#line 510 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* name_label = ({ __auto_type __nl_arg_2599_0 = name; error_messages__wrap_backticks(__nl_arg_2599_0); });
#line 511 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat("I cannot find a definition for ", nl_str_concat(name_label, "."));
}

const char* error_messages__encode_wrong_arg_count_message(const char* function_name, int64_t expected_args, int64_t found_args) {
#line 520 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* fn_label = ({ __auto_type __nl_arg_2600_0 = function_name; error_messages__wrap_backticks(__nl_arg_2600_0); });
#line 521 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat("The function ", nl_str_concat(fn_label, nl_str_concat(" expects ", nl_str_concat(({ __auto_type __nl_arg_2601_0 = expected_args; int_to_string(__nl_arg_2601_0); }), nl_str_concat(" argument(s), but I see ", nl_str_concat(({ __auto_type __nl_arg_2602_0 = found_args; int_to_string(__nl_arg_2602_0); }), "."))))));
}

const char* error_messages__encode_missing_return_message(const char* function_name, const char* expected_type) {
#line 530 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* fn_label = ({ __auto_type __nl_arg_2603_0 = function_name; error_messages__wrap_backticks(__nl_arg_2603_0); });
#line 531 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* type_label = ({ __auto_type __nl_arg_2604_0 = expected_type; error_messages__wrap_backticks(__nl_arg_2604_0); });
#line 532 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat("The function ", nl_str_concat(fn_label, nl_str_concat(" promises to return ", nl_str_concat(type_label, ", but this path has no return statement."))));
}

const char* error_messages__encode_immutable_assignment_message(const char* var_name) {
#line 541 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* name_label = ({ __auto_type __nl_arg_2605_0 = var_name; error_messages__wrap_backticks(__nl_arg_2605_0); });
#line 542 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return nl_str_concat("Cannot assign to ", nl_str_concat(name_label, " because it was declared immutable."));
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_unsafe_required(const char* file, int64_t line, int64_t column, const char* function_name) {
#line 557 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = nl_str_concat("The function ", nl_str_concat(({ __auto_type __nl_arg_2606_0 = function_name; error_messages__wrap_backticks(__nl_arg_2606_0); }), " is marked as unsafe and must be called inside an `unsafe` block."));
#line 558 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = "Unsafe functions can cause memory errors or undefined behavior if used incorrectly. NanoLang requires you to explicitly mark where unsafe code is used.";
#line 559 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = nl_str_concat("Wrap the call in an unsafe block:\n    unsafe {\n        (", nl_str_concat(function_name, " ...)\n    }"));
#line 560 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "UNSAFE OPERATION", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_use_after_consume(const char* file, int64_t line, int64_t column, const char* resource_name, int64_t consumed_at_line) {
#line 585 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = nl_str_concat("I cannot use ", nl_str_concat(({ __auto_type __nl_arg_2607_0 = resource_name; error_messages__wrap_backticks(__nl_arg_2607_0); }), nl_str_concat(" because it was already consumed at line ", nl_str_concat(({ __auto_type __nl_arg_2608_0 = consumed_at_line; int_to_string(__nl_arg_2608_0); }), "."))));
#line 586 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = nl_str_concat(({ __auto_type __nl_arg_2609_0 = resource_name; error_messages__wrap_backticks(__nl_arg_2609_0); }), " is a resource type. Resource types can only be used once. After you pass it to a consuming function, you cannot use it again.");
#line 587 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = "Restructure your code so the resource is consumed last, or use a function that borrows instead of consuming.";
#line 588 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "USE AFTER CONSUME", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

nl___nano_record_6572726f725f6d65737361676573_ErrorMessage error_messages__error_resource_leak(const char* file, int64_t line, int64_t column, const char* resource_name, const char* resource_type) {
#line 613 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* problem = nl_str_concat("The resource ", nl_str_concat(({ __auto_type __nl_arg_2610_0 = resource_name; error_messages__wrap_backticks(__nl_arg_2610_0); }), nl_str_concat(" of type ", nl_str_concat(({ __auto_type __nl_arg_2611_0 = resource_type; error_messages__wrap_backticks(__nl_arg_2611_0); }), " was not consumed before the function returns."))));
#line 614 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* explanation = nl_str_concat("Resource types like ", nl_str_concat(({ __auto_type __nl_arg_2612_0 = resource_type; error_messages__wrap_backticks(__nl_arg_2612_0); }), " must be explicitly closed or consumed. This prevents resource leaks (like leaving files open)."));
#line 615 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    const char* suggestion = nl_str_concat("Add a call to consume the resource before returning:\n    unsafe { (close_", nl_str_concat(resource_name, nl_str_concat(" ", nl_str_concat(resource_name, ") }"))));
#line 616 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    return (nl___nano_record_6572726f725f6d65737361676573_ErrorMessage){.title = "RESOURCE LEAK", .file = file, .line = line, .column = column, .problem = problem, .code_snippet = "", .explanation = explanation, .suggestion = suggestion};
}

const char* error_messages__get_error_template(const char* error_code) {
#line 639 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
    if ((strcmp(error_code, "E0001") == 0))     {
#line 640 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        return "TYPE MISMATCH: I expected a value of type `<expected>`, but found `<found>`.";
    }
    else     {
#line 642 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
        if ((strcmp(error_code, "E0002") == 0))         {
#line 643 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            return "UNDEFINED IDENTIFIER: I cannot find a definition for `<name>` in the current scope.";
        }
        else         {
#line 645 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
            if ((strcmp(error_code, "E0003") == 0))             {
#line 646 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                return "WRONG NUMBER OF ARGUMENTS: The function `<name>` expects <n> argument(s), but I see <m>.";
            }
            else             {
#line 648 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                if ((strcmp(error_code, "E0004") == 0))                 {
#line 649 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                    return "ARGUMENT TYPE MISMATCH: Argument <n> of `<fn>` must be `<expected>`, but got `<found>`.";
                }
                else                 {
#line 651 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                    if ((strcmp(error_code, "E0005") == 0))                     {
#line 652 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                        return "IMMUTABLE VARIABLE: Cannot assign to `<name>` because it was declared immutable. Use `let mut` to allow reassignment.";
                    }
                    else                     {
#line 654 "/tmp/nanolang-native-sdk-4e4a1-linux-diagnostic-source/src_nano/compiler/error_messages.nano"
                        return nl_str_concat("Unknown error code: ", error_code);
                    }
                }
            }
        }
    }
}


#pragma GCC diagnostic pop
/* Module metadata - automatically generated */
#include "nanolang.h"

static TypeInfo _type_infos[6];
static Function _module_functions[289];
static Parameter _module_params[305];

static void _init_module_metadata(void) __attribute__((constructor));
static void _init_module_metadata(void) {
    _type_infos[0].base_type = 16;
    _type_infos[0].generic_name = "HashMap";
    static TypeInfo* _type_info_0_params[2];
    _type_info_0_params[0] = &_type_infos[2];
    _type_info_0_params[1] = &_type_infos[3];
    _type_infos[0].type_params = _type_info_0_params;
    _type_infos[0].type_param_count = 2;
    _type_infos[0].tuple_types = NULL;
    _type_infos[0].tuple_type_names = NULL;
    _type_infos[0].tuple_element_count = 0;
    _type_infos[0].opaque_type_name = NULL;
    _type_infos[0].row_var_name = NULL;
    _type_infos[0].row_field_count = 0;
    _type_infos[0].is_open_row = false;
    _type_infos[0].type_var_count = 0;
    _type_infos[1].base_type = 16;
    _type_infos[1].generic_name = "HashMap";
    static TypeInfo* _type_info_1_params[2];
    _type_info_1_params[0] = &_type_infos[4];
    _type_info_1_params[1] = &_type_infos[5];
    _type_infos[1].type_params = _type_info_1_params;
    _type_infos[1].type_param_count = 2;
    _type_infos[1].tuple_types = NULL;
    _type_infos[1].tuple_type_names = NULL;
    _type_infos[1].tuple_element_count = 0;
    _type_infos[1].opaque_type_name = NULL;
    _type_infos[1].row_var_name = NULL;
    _type_infos[1].row_field_count = 0;
    _type_infos[1].is_open_row = false;
    _type_infos[1].type_var_count = 0;
    _type_infos[2].base_type = 4;
    _type_infos[2].generic_name = NULL;
    _type_infos[2].tuple_types = NULL;
    _type_infos[2].tuple_type_names = NULL;
    _type_infos[2].tuple_element_count = 0;
    _type_infos[2].opaque_type_name = NULL;
    _type_infos[2].row_var_name = NULL;
    _type_infos[2].row_field_count = 0;
    _type_infos[2].is_open_row = false;
    _type_infos[2].type_var_count = 0;
    _type_infos[3].base_type = 4;
    _type_infos[3].generic_name = NULL;
    _type_infos[3].tuple_types = NULL;
    _type_infos[3].tuple_type_names = NULL;
    _type_infos[3].tuple_element_count = 0;
    _type_infos[3].opaque_type_name = NULL;
    _type_infos[3].row_var_name = NULL;
    _type_infos[3].row_field_count = 0;
    _type_infos[3].is_open_row = false;
    _type_infos[3].type_var_count = 0;
    _type_infos[4].base_type = 4;
    _type_infos[4].generic_name = NULL;
    _type_infos[4].tuple_types = NULL;
    _type_infos[4].tuple_type_names = NULL;
    _type_infos[4].tuple_element_count = 0;
    _type_infos[4].opaque_type_name = NULL;
    _type_infos[4].row_var_name = NULL;
    _type_infos[4].row_field_count = 0;
    _type_infos[4].is_open_row = false;
    _type_infos[4].type_var_count = 0;
    _type_infos[5].base_type = 4;
    _type_infos[5].generic_name = NULL;
    _type_infos[5].tuple_types = NULL;
    _type_infos[5].tuple_type_names = NULL;
    _type_infos[5].tuple_element_count = 0;
    _type_infos[5].opaque_type_name = NULL;
    _type_infos[5].row_var_name = NULL;
    _type_infos[5].row_field_count = 0;
    _type_infos[5].is_open_row = false;
    _type_infos[5].type_var_count = 0;
    /* Function: range */
    _module_functions[0].name = "range";
    _module_functions[0].param_count = 0;
    _module_functions[0].return_type = 6;
    _module_functions[0].return_struct_type_name = NULL;
    _module_functions[0].return_fn_sig = NULL;
    _module_functions[0].return_type_info = NULL;
    _module_functions[0].body = NULL;
    _module_functions[0].shadow_test = NULL;
    _module_functions[0].is_extern = false;
    _module_functions[0].returns_gc_managed = false;
    _module_functions[0].requires_manual_free = false;
    _module_functions[0].returns_borrowed = false;
    _module_functions[0].cleanup_function = NULL;
    _module_functions[0].params = NULL;

    /* Function: abs */
    _module_functions[1].name = "abs";
    _module_functions[1].param_count = 0;
    _module_functions[1].return_type = 0;
    _module_functions[1].return_struct_type_name = NULL;
    _module_functions[1].return_fn_sig = NULL;
    _module_functions[1].return_type_info = NULL;
    _module_functions[1].body = NULL;
    _module_functions[1].shadow_test = NULL;
    _module_functions[1].is_extern = false;
    _module_functions[1].returns_gc_managed = false;
    _module_functions[1].requires_manual_free = false;
    _module_functions[1].returns_borrowed = false;
    _module_functions[1].cleanup_function = NULL;
    _module_functions[1].params = NULL;

    /* Function: min */
    _module_functions[2].name = "min";
    _module_functions[2].param_count = 0;
    _module_functions[2].return_type = 0;
    _module_functions[2].return_struct_type_name = NULL;
    _module_functions[2].return_fn_sig = NULL;
    _module_functions[2].return_type_info = NULL;
    _module_functions[2].body = NULL;
    _module_functions[2].shadow_test = NULL;
    _module_functions[2].is_extern = false;
    _module_functions[2].returns_gc_managed = false;
    _module_functions[2].requires_manual_free = false;
    _module_functions[2].returns_borrowed = false;
    _module_functions[2].cleanup_function = NULL;
    _module_functions[2].params = NULL;

    /* Function: max */
    _module_functions[3].name = "max";
    _module_functions[3].param_count = 0;
    _module_functions[3].return_type = 0;
    _module_functions[3].return_struct_type_name = NULL;
    _module_functions[3].return_fn_sig = NULL;
    _module_functions[3].return_type_info = NULL;
    _module_functions[3].body = NULL;
    _module_functions[3].shadow_test = NULL;
    _module_functions[3].is_extern = false;
    _module_functions[3].returns_gc_managed = false;
    _module_functions[3].requires_manual_free = false;
    _module_functions[3].returns_borrowed = false;
    _module_functions[3].cleanup_function = NULL;
    _module_functions[3].params = NULL;

    /* Function: print */
    _module_functions[4].name = "print";
    _module_functions[4].param_count = 0;
    _module_functions[4].return_type = 6;
    _module_functions[4].return_struct_type_name = NULL;
    _module_functions[4].return_fn_sig = NULL;
    _module_functions[4].return_type_info = NULL;
    _module_functions[4].body = NULL;
    _module_functions[4].shadow_test = NULL;
    _module_functions[4].is_extern = false;
    _module_functions[4].returns_gc_managed = false;
    _module_functions[4].requires_manual_free = false;
    _module_functions[4].returns_borrowed = false;
    _module_functions[4].cleanup_function = NULL;
    _module_functions[4].params = NULL;

    /* Function: println */
    _module_functions[5].name = "println";
    _module_functions[5].param_count = 0;
    _module_functions[5].return_type = 6;
    _module_functions[5].return_struct_type_name = NULL;
    _module_functions[5].return_fn_sig = NULL;
    _module_functions[5].return_type_info = NULL;
    _module_functions[5].body = NULL;
    _module_functions[5].shadow_test = NULL;
    _module_functions[5].is_extern = false;
    _module_functions[5].returns_gc_managed = false;
    _module_functions[5].requires_manual_free = false;
    _module_functions[5].returns_borrowed = false;
    _module_functions[5].cleanup_function = NULL;
    _module_functions[5].params = NULL;

    /* Function: sqrt */
    _module_functions[6].name = "sqrt";
    _module_functions[6].param_count = 0;
    _module_functions[6].return_type = 2;
    _module_functions[6].return_struct_type_name = NULL;
    _module_functions[6].return_fn_sig = NULL;
    _module_functions[6].return_type_info = NULL;
    _module_functions[6].body = NULL;
    _module_functions[6].shadow_test = NULL;
    _module_functions[6].is_extern = false;
    _module_functions[6].returns_gc_managed = false;
    _module_functions[6].requires_manual_free = false;
    _module_functions[6].returns_borrowed = false;
    _module_functions[6].cleanup_function = NULL;
    _module_functions[6].params = NULL;

    /* Function: pow */
    _module_functions[7].name = "pow";
    _module_functions[7].param_count = 0;
    _module_functions[7].return_type = 2;
    _module_functions[7].return_struct_type_name = NULL;
    _module_functions[7].return_fn_sig = NULL;
    _module_functions[7].return_type_info = NULL;
    _module_functions[7].body = NULL;
    _module_functions[7].shadow_test = NULL;
    _module_functions[7].is_extern = false;
    _module_functions[7].returns_gc_managed = false;
    _module_functions[7].requires_manual_free = false;
    _module_functions[7].returns_borrowed = false;
    _module_functions[7].cleanup_function = NULL;
    _module_functions[7].params = NULL;

    /* Function: floor */
    _module_functions[8].name = "floor";
    _module_functions[8].param_count = 0;
    _module_functions[8].return_type = 2;
    _module_functions[8].return_struct_type_name = NULL;
    _module_functions[8].return_fn_sig = NULL;
    _module_functions[8].return_type_info = NULL;
    _module_functions[8].body = NULL;
    _module_functions[8].shadow_test = NULL;
    _module_functions[8].is_extern = false;
    _module_functions[8].returns_gc_managed = false;
    _module_functions[8].requires_manual_free = false;
    _module_functions[8].returns_borrowed = false;
    _module_functions[8].cleanup_function = NULL;
    _module_functions[8].params = NULL;

    /* Function: ceil */
    _module_functions[9].name = "ceil";
    _module_functions[9].param_count = 0;
    _module_functions[9].return_type = 2;
    _module_functions[9].return_struct_type_name = NULL;
    _module_functions[9].return_fn_sig = NULL;
    _module_functions[9].return_type_info = NULL;
    _module_functions[9].body = NULL;
    _module_functions[9].shadow_test = NULL;
    _module_functions[9].is_extern = false;
    _module_functions[9].returns_gc_managed = false;
    _module_functions[9].requires_manual_free = false;
    _module_functions[9].returns_borrowed = false;
    _module_functions[9].cleanup_function = NULL;
    _module_functions[9].params = NULL;

    /* Function: round */
    _module_functions[10].name = "round";
    _module_functions[10].param_count = 0;
    _module_functions[10].return_type = 2;
    _module_functions[10].return_struct_type_name = NULL;
    _module_functions[10].return_fn_sig = NULL;
    _module_functions[10].return_type_info = NULL;
    _module_functions[10].body = NULL;
    _module_functions[10].shadow_test = NULL;
    _module_functions[10].is_extern = false;
    _module_functions[10].returns_gc_managed = false;
    _module_functions[10].requires_manual_free = false;
    _module_functions[10].returns_borrowed = false;
    _module_functions[10].cleanup_function = NULL;
    _module_functions[10].params = NULL;

    /* Function: sin */
    _module_functions[11].name = "sin";
    _module_functions[11].param_count = 0;
    _module_functions[11].return_type = 2;
    _module_functions[11].return_struct_type_name = NULL;
    _module_functions[11].return_fn_sig = NULL;
    _module_functions[11].return_type_info = NULL;
    _module_functions[11].body = NULL;
    _module_functions[11].shadow_test = NULL;
    _module_functions[11].is_extern = false;
    _module_functions[11].returns_gc_managed = false;
    _module_functions[11].requires_manual_free = false;
    _module_functions[11].returns_borrowed = false;
    _module_functions[11].cleanup_function = NULL;
    _module_functions[11].params = NULL;

    /* Function: cos */
    _module_functions[12].name = "cos";
    _module_functions[12].param_count = 0;
    _module_functions[12].return_type = 2;
    _module_functions[12].return_struct_type_name = NULL;
    _module_functions[12].return_fn_sig = NULL;
    _module_functions[12].return_type_info = NULL;
    _module_functions[12].body = NULL;
    _module_functions[12].shadow_test = NULL;
    _module_functions[12].is_extern = false;
    _module_functions[12].returns_gc_managed = false;
    _module_functions[12].requires_manual_free = false;
    _module_functions[12].returns_borrowed = false;
    _module_functions[12].cleanup_function = NULL;
    _module_functions[12].params = NULL;

    /* Function: tan */
    _module_functions[13].name = "tan";
    _module_functions[13].param_count = 0;
    _module_functions[13].return_type = 2;
    _module_functions[13].return_struct_type_name = NULL;
    _module_functions[13].return_fn_sig = NULL;
    _module_functions[13].return_type_info = NULL;
    _module_functions[13].body = NULL;
    _module_functions[13].shadow_test = NULL;
    _module_functions[13].is_extern = false;
    _module_functions[13].returns_gc_managed = false;
    _module_functions[13].requires_manual_free = false;
    _module_functions[13].returns_borrowed = false;
    _module_functions[13].cleanup_function = NULL;
    _module_functions[13].params = NULL;

    /* Function: str_length */
    _module_functions[14].name = "str_length";
    _module_functions[14].param_count = 0;
    _module_functions[14].return_type = 0;
    _module_functions[14].return_struct_type_name = NULL;
    _module_functions[14].return_fn_sig = NULL;
    _module_functions[14].return_type_info = NULL;
    _module_functions[14].body = NULL;
    _module_functions[14].shadow_test = NULL;
    _module_functions[14].is_extern = false;
    _module_functions[14].returns_gc_managed = false;
    _module_functions[14].requires_manual_free = false;
    _module_functions[14].returns_borrowed = false;
    _module_functions[14].cleanup_function = NULL;
    _module_functions[14].params = NULL;

    /* Function: str_concat */
    _module_functions[15].name = "str_concat";
    _module_functions[15].param_count = 0;
    _module_functions[15].return_type = 4;
    _module_functions[15].return_struct_type_name = NULL;
    _module_functions[15].return_fn_sig = NULL;
    _module_functions[15].return_type_info = NULL;
    _module_functions[15].body = NULL;
    _module_functions[15].shadow_test = NULL;
    _module_functions[15].is_extern = false;
    _module_functions[15].returns_gc_managed = true;
    _module_functions[15].requires_manual_free = false;
    _module_functions[15].returns_borrowed = false;
    _module_functions[15].cleanup_function = NULL;
    _module_functions[15].params = NULL;

    /* Function: str_substring */
    _module_functions[16].name = "str_substring";
    _module_functions[16].param_count = 0;
    _module_functions[16].return_type = 4;
    _module_functions[16].return_struct_type_name = NULL;
    _module_functions[16].return_fn_sig = NULL;
    _module_functions[16].return_type_info = NULL;
    _module_functions[16].body = NULL;
    _module_functions[16].shadow_test = NULL;
    _module_functions[16].is_extern = false;
    _module_functions[16].returns_gc_managed = true;
    _module_functions[16].requires_manual_free = false;
    _module_functions[16].returns_borrowed = false;
    _module_functions[16].cleanup_function = NULL;
    _module_functions[16].params = NULL;

    /* Function: str_contains */
    _module_functions[17].name = "str_contains";
    _module_functions[17].param_count = 0;
    _module_functions[17].return_type = 3;
    _module_functions[17].return_struct_type_name = NULL;
    _module_functions[17].return_fn_sig = NULL;
    _module_functions[17].return_type_info = NULL;
    _module_functions[17].body = NULL;
    _module_functions[17].shadow_test = NULL;
    _module_functions[17].is_extern = false;
    _module_functions[17].returns_gc_managed = false;
    _module_functions[17].requires_manual_free = false;
    _module_functions[17].returns_borrowed = false;
    _module_functions[17].cleanup_function = NULL;
    _module_functions[17].params = NULL;

    /* Function: str_equals */
    _module_functions[18].name = "str_equals";
    _module_functions[18].param_count = 0;
    _module_functions[18].return_type = 3;
    _module_functions[18].return_struct_type_name = NULL;
    _module_functions[18].return_fn_sig = NULL;
    _module_functions[18].return_type_info = NULL;
    _module_functions[18].body = NULL;
    _module_functions[18].shadow_test = NULL;
    _module_functions[18].is_extern = false;
    _module_functions[18].returns_gc_managed = false;
    _module_functions[18].requires_manual_free = false;
    _module_functions[18].returns_borrowed = false;
    _module_functions[18].cleanup_function = NULL;
    _module_functions[18].params = NULL;

    /* Function: format */
    _module_functions[19].name = "format";
    _module_functions[19].param_count = 0;
    _module_functions[19].return_type = 4;
    _module_functions[19].return_struct_type_name = NULL;
    _module_functions[19].return_fn_sig = NULL;
    _module_functions[19].return_type_info = NULL;
    _module_functions[19].body = NULL;
    _module_functions[19].shadow_test = NULL;
    _module_functions[19].is_extern = false;
    _module_functions[19].returns_gc_managed = true;
    _module_functions[19].requires_manual_free = false;
    _module_functions[19].returns_borrowed = false;
    _module_functions[19].cleanup_function = NULL;
    _module_functions[19].params = NULL;

    /* Function: at */
    _module_functions[20].name = "at";
    _module_functions[20].param_count = 0;
    _module_functions[20].return_type = 21;
    _module_functions[20].return_struct_type_name = NULL;
    _module_functions[20].return_fn_sig = NULL;
    _module_functions[20].return_type_info = NULL;
    _module_functions[20].body = NULL;
    _module_functions[20].shadow_test = NULL;
    _module_functions[20].is_extern = false;
    _module_functions[20].returns_gc_managed = false;
    _module_functions[20].requires_manual_free = false;
    _module_functions[20].returns_borrowed = false;
    _module_functions[20].cleanup_function = NULL;
    _module_functions[20].params = NULL;

    /* Function: array_length */
    _module_functions[21].name = "array_length";
    _module_functions[21].param_count = 0;
    _module_functions[21].return_type = 0;
    _module_functions[21].return_struct_type_name = NULL;
    _module_functions[21].return_fn_sig = NULL;
    _module_functions[21].return_type_info = NULL;
    _module_functions[21].body = NULL;
    _module_functions[21].shadow_test = NULL;
    _module_functions[21].is_extern = false;
    _module_functions[21].returns_gc_managed = false;
    _module_functions[21].requires_manual_free = false;
    _module_functions[21].returns_borrowed = false;
    _module_functions[21].cleanup_function = NULL;
    _module_functions[21].params = NULL;

    /* Function: array_new */
    _module_functions[22].name = "array_new";
    _module_functions[22].param_count = 0;
    _module_functions[22].return_type = 7;
    _module_functions[22].return_struct_type_name = NULL;
    _module_functions[22].return_fn_sig = NULL;
    _module_functions[22].return_type_info = NULL;
    _module_functions[22].body = NULL;
    _module_functions[22].shadow_test = NULL;
    _module_functions[22].is_extern = false;
    _module_functions[22].returns_gc_managed = false;
    _module_functions[22].requires_manual_free = false;
    _module_functions[22].returns_borrowed = false;
    _module_functions[22].cleanup_function = NULL;
    _module_functions[22].params = NULL;

    /* Function: array_set */
    _module_functions[23].name = "array_set";
    _module_functions[23].param_count = 0;
    _module_functions[23].return_type = 6;
    _module_functions[23].return_struct_type_name = NULL;
    _module_functions[23].return_fn_sig = NULL;
    _module_functions[23].return_type_info = NULL;
    _module_functions[23].body = NULL;
    _module_functions[23].shadow_test = NULL;
    _module_functions[23].is_extern = false;
    _module_functions[23].returns_gc_managed = false;
    _module_functions[23].requires_manual_free = false;
    _module_functions[23].returns_borrowed = false;
    _module_functions[23].cleanup_function = NULL;
    _module_functions[23].params = NULL;

    /* Function: map */
    _module_functions[24].name = "map";
    _module_functions[24].param_count = 0;
    _module_functions[24].return_type = 7;
    _module_functions[24].return_struct_type_name = NULL;
    _module_functions[24].return_fn_sig = NULL;
    _module_functions[24].return_type_info = NULL;
    _module_functions[24].body = NULL;
    _module_functions[24].shadow_test = NULL;
    _module_functions[24].is_extern = false;
    _module_functions[24].returns_gc_managed = false;
    _module_functions[24].requires_manual_free = false;
    _module_functions[24].returns_borrowed = false;
    _module_functions[24].cleanup_function = NULL;
    _module_functions[24].params = NULL;

    /* Function: reduce */
    _module_functions[25].name = "reduce";
    _module_functions[25].param_count = 0;
    _module_functions[25].return_type = 21;
    _module_functions[25].return_struct_type_name = NULL;
    _module_functions[25].return_fn_sig = NULL;
    _module_functions[25].return_type_info = NULL;
    _module_functions[25].body = NULL;
    _module_functions[25].shadow_test = NULL;
    _module_functions[25].is_extern = false;
    _module_functions[25].returns_gc_managed = false;
    _module_functions[25].requires_manual_free = false;
    _module_functions[25].returns_borrowed = false;
    _module_functions[25].cleanup_function = NULL;
    _module_functions[25].params = NULL;

    /* Function: getcwd */
    _module_functions[26].name = "getcwd";
    _module_functions[26].param_count = 0;
    _module_functions[26].return_type = 4;
    _module_functions[26].return_struct_type_name = NULL;
    _module_functions[26].return_fn_sig = NULL;
    _module_functions[26].return_type_info = NULL;
    _module_functions[26].body = NULL;
    _module_functions[26].shadow_test = NULL;
    _module_functions[26].is_extern = false;
    _module_functions[26].returns_gc_managed = true;
    _module_functions[26].requires_manual_free = false;
    _module_functions[26].returns_borrowed = false;
    _module_functions[26].cleanup_function = NULL;
    _module_functions[26].params = NULL;

    /* Function: getenv */
    _module_functions[27].name = "getenv";
    _module_functions[27].param_count = 0;
    _module_functions[27].return_type = 4;
    _module_functions[27].return_struct_type_name = NULL;
    _module_functions[27].return_fn_sig = NULL;
    _module_functions[27].return_type_info = NULL;
    _module_functions[27].body = NULL;
    _module_functions[27].shadow_test = NULL;
    _module_functions[27].is_extern = false;
    _module_functions[27].returns_gc_managed = true;
    _module_functions[27].requires_manual_free = false;
    _module_functions[27].returns_borrowed = false;
    _module_functions[27].cleanup_function = NULL;
    _module_functions[27].params = NULL;

    /* Function: dir_list */
    _module_functions[28].name = "dir_list";
    _module_functions[28].param_count = 0;
    _module_functions[28].return_type = 7;
    _module_functions[28].return_struct_type_name = NULL;
    _module_functions[28].return_fn_sig = NULL;
    _module_functions[28].return_type_info = NULL;
    _module_functions[28].body = NULL;
    _module_functions[28].shadow_test = NULL;
    _module_functions[28].is_extern = false;
    _module_functions[28].returns_gc_managed = false;
    _module_functions[28].requires_manual_free = false;
    _module_functions[28].returns_borrowed = false;
    _module_functions[28].cleanup_function = NULL;
    _module_functions[28].params = NULL;

    /* Function: process_run */
    _module_functions[29].name = "process_run";
    _module_functions[29].param_count = 0;
    _module_functions[29].return_type = 7;
    _module_functions[29].return_struct_type_name = NULL;
    _module_functions[29].return_fn_sig = NULL;
    _module_functions[29].return_type_info = NULL;
    _module_functions[29].body = NULL;
    _module_functions[29].shadow_test = NULL;
    _module_functions[29].is_extern = false;
    _module_functions[29].returns_gc_managed = false;
    _module_functions[29].requires_manual_free = false;
    _module_functions[29].returns_borrowed = false;
    _module_functions[29].cleanup_function = NULL;
    _module_functions[29].params = NULL;

    /* Function: tmp_dir */
    _module_functions[30].name = "tmp_dir";
    _module_functions[30].param_count = 0;
    _module_functions[30].return_type = 4;
    _module_functions[30].return_struct_type_name = NULL;
    _module_functions[30].return_fn_sig = NULL;
    _module_functions[30].return_type_info = NULL;
    _module_functions[30].body = NULL;
    _module_functions[30].shadow_test = NULL;
    _module_functions[30].is_extern = false;
    _module_functions[30].returns_gc_managed = true;
    _module_functions[30].requires_manual_free = false;
    _module_functions[30].returns_borrowed = false;
    _module_functions[30].cleanup_function = NULL;
    _module_functions[30].params = NULL;

    /* Function: mktemp */
    _module_functions[31].name = "mktemp";
    _module_functions[31].param_count = 0;
    _module_functions[31].return_type = 4;
    _module_functions[31].return_struct_type_name = NULL;
    _module_functions[31].return_fn_sig = NULL;
    _module_functions[31].return_type_info = NULL;
    _module_functions[31].body = NULL;
    _module_functions[31].shadow_test = NULL;
    _module_functions[31].is_extern = false;
    _module_functions[31].returns_gc_managed = true;
    _module_functions[31].requires_manual_free = false;
    _module_functions[31].returns_borrowed = false;
    _module_functions[31].cleanup_function = NULL;
    _module_functions[31].params = NULL;

    /* Function: mktemp_dir */
    _module_functions[32].name = "mktemp_dir";
    _module_functions[32].param_count = 0;
    _module_functions[32].return_type = 4;
    _module_functions[32].return_struct_type_name = NULL;
    _module_functions[32].return_fn_sig = NULL;
    _module_functions[32].return_type_info = NULL;
    _module_functions[32].body = NULL;
    _module_functions[32].shadow_test = NULL;
    _module_functions[32].is_extern = false;
    _module_functions[32].returns_gc_managed = true;
    _module_functions[32].requires_manual_free = false;
    _module_functions[32].returns_borrowed = false;
    _module_functions[32].cleanup_function = NULL;
    _module_functions[32].params = NULL;

    /* Function: char_at */
    _module_functions[33].name = "char_at";
    _module_functions[33].param_count = 0;
    _module_functions[33].return_type = 0;
    _module_functions[33].return_struct_type_name = NULL;
    _module_functions[33].return_fn_sig = NULL;
    _module_functions[33].return_type_info = NULL;
    _module_functions[33].body = NULL;
    _module_functions[33].shadow_test = NULL;
    _module_functions[33].is_extern = false;
    _module_functions[33].returns_gc_managed = false;
    _module_functions[33].requires_manual_free = false;
    _module_functions[33].returns_borrowed = false;
    _module_functions[33].cleanup_function = NULL;
    _module_functions[33].params = NULL;

    /* Function: string_from_char */
    _module_functions[34].name = "string_from_char";
    _module_functions[34].param_count = 0;
    _module_functions[34].return_type = 4;
    _module_functions[34].return_struct_type_name = NULL;
    _module_functions[34].return_fn_sig = NULL;
    _module_functions[34].return_type_info = NULL;
    _module_functions[34].body = NULL;
    _module_functions[34].shadow_test = NULL;
    _module_functions[34].is_extern = false;
    _module_functions[34].returns_gc_managed = true;
    _module_functions[34].requires_manual_free = false;
    _module_functions[34].returns_borrowed = false;
    _module_functions[34].cleanup_function = NULL;
    _module_functions[34].params = NULL;

    /* Function: is_digit */
    _module_functions[35].name = "is_digit";
    _module_functions[35].param_count = 0;
    _module_functions[35].return_type = 3;
    _module_functions[35].return_struct_type_name = NULL;
    _module_functions[35].return_fn_sig = NULL;
    _module_functions[35].return_type_info = NULL;
    _module_functions[35].body = NULL;
    _module_functions[35].shadow_test = NULL;
    _module_functions[35].is_extern = false;
    _module_functions[35].returns_gc_managed = false;
    _module_functions[35].requires_manual_free = false;
    _module_functions[35].returns_borrowed = false;
    _module_functions[35].cleanup_function = NULL;
    _module_functions[35].params = NULL;

    /* Function: is_alpha */
    _module_functions[36].name = "is_alpha";
    _module_functions[36].param_count = 0;
    _module_functions[36].return_type = 3;
    _module_functions[36].return_struct_type_name = NULL;
    _module_functions[36].return_fn_sig = NULL;
    _module_functions[36].return_type_info = NULL;
    _module_functions[36].body = NULL;
    _module_functions[36].shadow_test = NULL;
    _module_functions[36].is_extern = false;
    _module_functions[36].returns_gc_managed = false;
    _module_functions[36].requires_manual_free = false;
    _module_functions[36].returns_borrowed = false;
    _module_functions[36].cleanup_function = NULL;
    _module_functions[36].params = NULL;

    /* Function: is_alnum */
    _module_functions[37].name = "is_alnum";
    _module_functions[37].param_count = 0;
    _module_functions[37].return_type = 3;
    _module_functions[37].return_struct_type_name = NULL;
    _module_functions[37].return_fn_sig = NULL;
    _module_functions[37].return_type_info = NULL;
    _module_functions[37].body = NULL;
    _module_functions[37].shadow_test = NULL;
    _module_functions[37].is_extern = false;
    _module_functions[37].returns_gc_managed = false;
    _module_functions[37].requires_manual_free = false;
    _module_functions[37].returns_borrowed = false;
    _module_functions[37].cleanup_function = NULL;
    _module_functions[37].params = NULL;

    /* Function: is_whitespace */
    _module_functions[38].name = "is_whitespace";
    _module_functions[38].param_count = 0;
    _module_functions[38].return_type = 3;
    _module_functions[38].return_struct_type_name = NULL;
    _module_functions[38].return_fn_sig = NULL;
    _module_functions[38].return_type_info = NULL;
    _module_functions[38].body = NULL;
    _module_functions[38].shadow_test = NULL;
    _module_functions[38].is_extern = false;
    _module_functions[38].returns_gc_managed = false;
    _module_functions[38].requires_manual_free = false;
    _module_functions[38].returns_borrowed = false;
    _module_functions[38].cleanup_function = NULL;
    _module_functions[38].params = NULL;

    /* Function: is_upper */
    _module_functions[39].name = "is_upper";
    _module_functions[39].param_count = 0;
    _module_functions[39].return_type = 3;
    _module_functions[39].return_struct_type_name = NULL;
    _module_functions[39].return_fn_sig = NULL;
    _module_functions[39].return_type_info = NULL;
    _module_functions[39].body = NULL;
    _module_functions[39].shadow_test = NULL;
    _module_functions[39].is_extern = false;
    _module_functions[39].returns_gc_managed = false;
    _module_functions[39].requires_manual_free = false;
    _module_functions[39].returns_borrowed = false;
    _module_functions[39].cleanup_function = NULL;
    _module_functions[39].params = NULL;

    /* Function: is_lower */
    _module_functions[40].name = "is_lower";
    _module_functions[40].param_count = 0;
    _module_functions[40].return_type = 3;
    _module_functions[40].return_struct_type_name = NULL;
    _module_functions[40].return_fn_sig = NULL;
    _module_functions[40].return_type_info = NULL;
    _module_functions[40].body = NULL;
    _module_functions[40].shadow_test = NULL;
    _module_functions[40].is_extern = false;
    _module_functions[40].returns_gc_managed = false;
    _module_functions[40].requires_manual_free = false;
    _module_functions[40].returns_borrowed = false;
    _module_functions[40].cleanup_function = NULL;
    _module_functions[40].params = NULL;

    /* Function: int_to_string */
    _module_functions[41].name = "int_to_string";
    _module_functions[41].param_count = 0;
    _module_functions[41].return_type = 4;
    _module_functions[41].return_struct_type_name = NULL;
    _module_functions[41].return_fn_sig = NULL;
    _module_functions[41].return_type_info = NULL;
    _module_functions[41].body = NULL;
    _module_functions[41].shadow_test = NULL;
    _module_functions[41].is_extern = false;
    _module_functions[41].returns_gc_managed = true;
    _module_functions[41].requires_manual_free = false;
    _module_functions[41].returns_borrowed = false;
    _module_functions[41].cleanup_function = NULL;
    _module_functions[41].params = NULL;

    /* Function: string_to_int */
    _module_functions[42].name = "string_to_int";
    _module_functions[42].param_count = 0;
    _module_functions[42].return_type = 0;
    _module_functions[42].return_struct_type_name = NULL;
    _module_functions[42].return_fn_sig = NULL;
    _module_functions[42].return_type_info = NULL;
    _module_functions[42].body = NULL;
    _module_functions[42].shadow_test = NULL;
    _module_functions[42].is_extern = false;
    _module_functions[42].returns_gc_managed = false;
    _module_functions[42].requires_manual_free = false;
    _module_functions[42].returns_borrowed = false;
    _module_functions[42].cleanup_function = NULL;
    _module_functions[42].params = NULL;

    /* Function: digit_value */
    _module_functions[43].name = "digit_value";
    _module_functions[43].param_count = 0;
    _module_functions[43].return_type = 0;
    _module_functions[43].return_struct_type_name = NULL;
    _module_functions[43].return_fn_sig = NULL;
    _module_functions[43].return_type_info = NULL;
    _module_functions[43].body = NULL;
    _module_functions[43].shadow_test = NULL;
    _module_functions[43].is_extern = false;
    _module_functions[43].returns_gc_managed = false;
    _module_functions[43].requires_manual_free = false;
    _module_functions[43].returns_borrowed = false;
    _module_functions[43].cleanup_function = NULL;
    _module_functions[43].params = NULL;

    /* Function: char_to_lower */
    _module_functions[44].name = "char_to_lower";
    _module_functions[44].param_count = 0;
    _module_functions[44].return_type = 0;
    _module_functions[44].return_struct_type_name = NULL;
    _module_functions[44].return_fn_sig = NULL;
    _module_functions[44].return_type_info = NULL;
    _module_functions[44].body = NULL;
    _module_functions[44].shadow_test = NULL;
    _module_functions[44].is_extern = false;
    _module_functions[44].returns_gc_managed = false;
    _module_functions[44].requires_manual_free = false;
    _module_functions[44].returns_borrowed = false;
    _module_functions[44].cleanup_function = NULL;
    _module_functions[44].params = NULL;

    /* Function: char_to_upper */
    _module_functions[45].name = "char_to_upper";
    _module_functions[45].param_count = 0;
    _module_functions[45].return_type = 0;
    _module_functions[45].return_struct_type_name = NULL;
    _module_functions[45].return_fn_sig = NULL;
    _module_functions[45].return_type_info = NULL;
    _module_functions[45].body = NULL;
    _module_functions[45].shadow_test = NULL;
    _module_functions[45].is_extern = false;
    _module_functions[45].returns_gc_managed = false;
    _module_functions[45].requires_manual_free = false;
    _module_functions[45].returns_borrowed = false;
    _module_functions[45].cleanup_function = NULL;
    _module_functions[45].params = NULL;

    /* Function: list_int_new */
    _module_functions[46].name = "list_int_new";
    _module_functions[46].param_count = 0;
    _module_functions[46].return_type = 12;
    _module_functions[46].return_struct_type_name = NULL;
    _module_functions[46].return_fn_sig = NULL;
    _module_functions[46].return_type_info = NULL;
    _module_functions[46].body = NULL;
    _module_functions[46].shadow_test = NULL;
    _module_functions[46].is_extern = false;
    _module_functions[46].returns_gc_managed = false;
    _module_functions[46].requires_manual_free = false;
    _module_functions[46].returns_borrowed = false;
    _module_functions[46].cleanup_function = NULL;
    _module_functions[46].params = NULL;

    /* Function: list_int_with_capacity */
    _module_functions[47].name = "list_int_with_capacity";
    _module_functions[47].param_count = 0;
    _module_functions[47].return_type = 12;
    _module_functions[47].return_struct_type_name = NULL;
    _module_functions[47].return_fn_sig = NULL;
    _module_functions[47].return_type_info = NULL;
    _module_functions[47].body = NULL;
    _module_functions[47].shadow_test = NULL;
    _module_functions[47].is_extern = false;
    _module_functions[47].returns_gc_managed = false;
    _module_functions[47].requires_manual_free = false;
    _module_functions[47].returns_borrowed = false;
    _module_functions[47].cleanup_function = NULL;
    _module_functions[47].params = NULL;

    /* Function: list_int_push */
    _module_functions[48].name = "list_int_push";
    _module_functions[48].param_count = 0;
    _module_functions[48].return_type = 6;
    _module_functions[48].return_struct_type_name = NULL;
    _module_functions[48].return_fn_sig = NULL;
    _module_functions[48].return_type_info = NULL;
    _module_functions[48].body = NULL;
    _module_functions[48].shadow_test = NULL;
    _module_functions[48].is_extern = false;
    _module_functions[48].returns_gc_managed = false;
    _module_functions[48].requires_manual_free = false;
    _module_functions[48].returns_borrowed = false;
    _module_functions[48].cleanup_function = NULL;
    _module_functions[48].params = NULL;

    /* Function: list_int_pop */
    _module_functions[49].name = "list_int_pop";
    _module_functions[49].param_count = 0;
    _module_functions[49].return_type = 0;
    _module_functions[49].return_struct_type_name = NULL;
    _module_functions[49].return_fn_sig = NULL;
    _module_functions[49].return_type_info = NULL;
    _module_functions[49].body = NULL;
    _module_functions[49].shadow_test = NULL;
    _module_functions[49].is_extern = false;
    _module_functions[49].returns_gc_managed = false;
    _module_functions[49].requires_manual_free = false;
    _module_functions[49].returns_borrowed = false;
    _module_functions[49].cleanup_function = NULL;
    _module_functions[49].params = NULL;

    /* Function: list_int_get */
    _module_functions[50].name = "list_int_get";
    _module_functions[50].param_count = 0;
    _module_functions[50].return_type = 0;
    _module_functions[50].return_struct_type_name = NULL;
    _module_functions[50].return_fn_sig = NULL;
    _module_functions[50].return_type_info = NULL;
    _module_functions[50].body = NULL;
    _module_functions[50].shadow_test = NULL;
    _module_functions[50].is_extern = false;
    _module_functions[50].returns_gc_managed = false;
    _module_functions[50].requires_manual_free = false;
    _module_functions[50].returns_borrowed = false;
    _module_functions[50].cleanup_function = NULL;
    _module_functions[50].params = NULL;

    /* Function: list_int_set */
    _module_functions[51].name = "list_int_set";
    _module_functions[51].param_count = 0;
    _module_functions[51].return_type = 6;
    _module_functions[51].return_struct_type_name = NULL;
    _module_functions[51].return_fn_sig = NULL;
    _module_functions[51].return_type_info = NULL;
    _module_functions[51].body = NULL;
    _module_functions[51].shadow_test = NULL;
    _module_functions[51].is_extern = false;
    _module_functions[51].returns_gc_managed = false;
    _module_functions[51].requires_manual_free = false;
    _module_functions[51].returns_borrowed = false;
    _module_functions[51].cleanup_function = NULL;
    _module_functions[51].params = NULL;

    /* Function: list_int_insert */
    _module_functions[52].name = "list_int_insert";
    _module_functions[52].param_count = 0;
    _module_functions[52].return_type = 6;
    _module_functions[52].return_struct_type_name = NULL;
    _module_functions[52].return_fn_sig = NULL;
    _module_functions[52].return_type_info = NULL;
    _module_functions[52].body = NULL;
    _module_functions[52].shadow_test = NULL;
    _module_functions[52].is_extern = false;
    _module_functions[52].returns_gc_managed = false;
    _module_functions[52].requires_manual_free = false;
    _module_functions[52].returns_borrowed = false;
    _module_functions[52].cleanup_function = NULL;
    _module_functions[52].params = NULL;

    /* Function: list_int_remove */
    _module_functions[53].name = "list_int_remove";
    _module_functions[53].param_count = 0;
    _module_functions[53].return_type = 0;
    _module_functions[53].return_struct_type_name = NULL;
    _module_functions[53].return_fn_sig = NULL;
    _module_functions[53].return_type_info = NULL;
    _module_functions[53].body = NULL;
    _module_functions[53].shadow_test = NULL;
    _module_functions[53].is_extern = false;
    _module_functions[53].returns_gc_managed = false;
    _module_functions[53].requires_manual_free = false;
    _module_functions[53].returns_borrowed = false;
    _module_functions[53].cleanup_function = NULL;
    _module_functions[53].params = NULL;

    /* Function: list_int_length */
    _module_functions[54].name = "list_int_length";
    _module_functions[54].param_count = 0;
    _module_functions[54].return_type = 0;
    _module_functions[54].return_struct_type_name = NULL;
    _module_functions[54].return_fn_sig = NULL;
    _module_functions[54].return_type_info = NULL;
    _module_functions[54].body = NULL;
    _module_functions[54].shadow_test = NULL;
    _module_functions[54].is_extern = false;
    _module_functions[54].returns_gc_managed = false;
    _module_functions[54].requires_manual_free = false;
    _module_functions[54].returns_borrowed = false;
    _module_functions[54].cleanup_function = NULL;
    _module_functions[54].params = NULL;

    /* Function: list_int_capacity */
    _module_functions[55].name = "list_int_capacity";
    _module_functions[55].param_count = 0;
    _module_functions[55].return_type = 0;
    _module_functions[55].return_struct_type_name = NULL;
    _module_functions[55].return_fn_sig = NULL;
    _module_functions[55].return_type_info = NULL;
    _module_functions[55].body = NULL;
    _module_functions[55].shadow_test = NULL;
    _module_functions[55].is_extern = false;
    _module_functions[55].returns_gc_managed = false;
    _module_functions[55].requires_manual_free = false;
    _module_functions[55].returns_borrowed = false;
    _module_functions[55].cleanup_function = NULL;
    _module_functions[55].params = NULL;

    /* Function: list_int_is_empty */
    _module_functions[56].name = "list_int_is_empty";
    _module_functions[56].param_count = 0;
    _module_functions[56].return_type = 3;
    _module_functions[56].return_struct_type_name = NULL;
    _module_functions[56].return_fn_sig = NULL;
    _module_functions[56].return_type_info = NULL;
    _module_functions[56].body = NULL;
    _module_functions[56].shadow_test = NULL;
    _module_functions[56].is_extern = false;
    _module_functions[56].returns_gc_managed = false;
    _module_functions[56].requires_manual_free = false;
    _module_functions[56].returns_borrowed = false;
    _module_functions[56].cleanup_function = NULL;
    _module_functions[56].params = NULL;

    /* Function: list_int_clear */
    _module_functions[57].name = "list_int_clear";
    _module_functions[57].param_count = 0;
    _module_functions[57].return_type = 6;
    _module_functions[57].return_struct_type_name = NULL;
    _module_functions[57].return_fn_sig = NULL;
    _module_functions[57].return_type_info = NULL;
    _module_functions[57].body = NULL;
    _module_functions[57].shadow_test = NULL;
    _module_functions[57].is_extern = false;
    _module_functions[57].returns_gc_managed = false;
    _module_functions[57].requires_manual_free = false;
    _module_functions[57].returns_borrowed = false;
    _module_functions[57].cleanup_function = NULL;
    _module_functions[57].params = NULL;

    /* Function: list_int_free */
    _module_functions[58].name = "list_int_free";
    _module_functions[58].param_count = 0;
    _module_functions[58].return_type = 6;
    _module_functions[58].return_struct_type_name = NULL;
    _module_functions[58].return_fn_sig = NULL;
    _module_functions[58].return_type_info = NULL;
    _module_functions[58].body = NULL;
    _module_functions[58].shadow_test = NULL;
    _module_functions[58].is_extern = false;
    _module_functions[58].returns_gc_managed = false;
    _module_functions[58].requires_manual_free = false;
    _module_functions[58].returns_borrowed = false;
    _module_functions[58].cleanup_function = NULL;
    _module_functions[58].params = NULL;

    /* Function: list_string_new */
    _module_functions[59].name = "list_string_new";
    _module_functions[59].param_count = 0;
    _module_functions[59].return_type = 13;
    _module_functions[59].return_struct_type_name = NULL;
    _module_functions[59].return_fn_sig = NULL;
    _module_functions[59].return_type_info = NULL;
    _module_functions[59].body = NULL;
    _module_functions[59].shadow_test = NULL;
    _module_functions[59].is_extern = false;
    _module_functions[59].returns_gc_managed = false;
    _module_functions[59].requires_manual_free = false;
    _module_functions[59].returns_borrowed = false;
    _module_functions[59].cleanup_function = NULL;
    _module_functions[59].params = NULL;

    /* Function: list_string_with_capacity */
    _module_functions[60].name = "list_string_with_capacity";
    _module_functions[60].param_count = 0;
    _module_functions[60].return_type = 13;
    _module_functions[60].return_struct_type_name = NULL;
    _module_functions[60].return_fn_sig = NULL;
    _module_functions[60].return_type_info = NULL;
    _module_functions[60].body = NULL;
    _module_functions[60].shadow_test = NULL;
    _module_functions[60].is_extern = false;
    _module_functions[60].returns_gc_managed = false;
    _module_functions[60].requires_manual_free = false;
    _module_functions[60].returns_borrowed = false;
    _module_functions[60].cleanup_function = NULL;
    _module_functions[60].params = NULL;

    /* Function: list_string_push */
    _module_functions[61].name = "list_string_push";
    _module_functions[61].param_count = 0;
    _module_functions[61].return_type = 6;
    _module_functions[61].return_struct_type_name = NULL;
    _module_functions[61].return_fn_sig = NULL;
    _module_functions[61].return_type_info = NULL;
    _module_functions[61].body = NULL;
    _module_functions[61].shadow_test = NULL;
    _module_functions[61].is_extern = false;
    _module_functions[61].returns_gc_managed = false;
    _module_functions[61].requires_manual_free = false;
    _module_functions[61].returns_borrowed = false;
    _module_functions[61].cleanup_function = NULL;
    _module_functions[61].params = NULL;

    /* Function: list_string_pop */
    _module_functions[62].name = "list_string_pop";
    _module_functions[62].param_count = 0;
    _module_functions[62].return_type = 4;
    _module_functions[62].return_struct_type_name = NULL;
    _module_functions[62].return_fn_sig = NULL;
    _module_functions[62].return_type_info = NULL;
    _module_functions[62].body = NULL;
    _module_functions[62].shadow_test = NULL;
    _module_functions[62].is_extern = false;
    _module_functions[62].returns_gc_managed = true;
    _module_functions[62].requires_manual_free = false;
    _module_functions[62].returns_borrowed = false;
    _module_functions[62].cleanup_function = NULL;
    _module_functions[62].params = NULL;

    /* Function: list_string_get */
    _module_functions[63].name = "list_string_get";
    _module_functions[63].param_count = 0;
    _module_functions[63].return_type = 4;
    _module_functions[63].return_struct_type_name = NULL;
    _module_functions[63].return_fn_sig = NULL;
    _module_functions[63].return_type_info = NULL;
    _module_functions[63].body = NULL;
    _module_functions[63].shadow_test = NULL;
    _module_functions[63].is_extern = false;
    _module_functions[63].returns_gc_managed = true;
    _module_functions[63].requires_manual_free = false;
    _module_functions[63].returns_borrowed = false;
    _module_functions[63].cleanup_function = NULL;
    _module_functions[63].params = NULL;

    /* Function: list_string_set */
    _module_functions[64].name = "list_string_set";
    _module_functions[64].param_count = 0;
    _module_functions[64].return_type = 6;
    _module_functions[64].return_struct_type_name = NULL;
    _module_functions[64].return_fn_sig = NULL;
    _module_functions[64].return_type_info = NULL;
    _module_functions[64].body = NULL;
    _module_functions[64].shadow_test = NULL;
    _module_functions[64].is_extern = false;
    _module_functions[64].returns_gc_managed = false;
    _module_functions[64].requires_manual_free = false;
    _module_functions[64].returns_borrowed = false;
    _module_functions[64].cleanup_function = NULL;
    _module_functions[64].params = NULL;

    /* Function: list_string_insert */
    _module_functions[65].name = "list_string_insert";
    _module_functions[65].param_count = 0;
    _module_functions[65].return_type = 6;
    _module_functions[65].return_struct_type_name = NULL;
    _module_functions[65].return_fn_sig = NULL;
    _module_functions[65].return_type_info = NULL;
    _module_functions[65].body = NULL;
    _module_functions[65].shadow_test = NULL;
    _module_functions[65].is_extern = false;
    _module_functions[65].returns_gc_managed = false;
    _module_functions[65].requires_manual_free = false;
    _module_functions[65].returns_borrowed = false;
    _module_functions[65].cleanup_function = NULL;
    _module_functions[65].params = NULL;

    /* Function: list_string_remove */
    _module_functions[66].name = "list_string_remove";
    _module_functions[66].param_count = 0;
    _module_functions[66].return_type = 4;
    _module_functions[66].return_struct_type_name = NULL;
    _module_functions[66].return_fn_sig = NULL;
    _module_functions[66].return_type_info = NULL;
    _module_functions[66].body = NULL;
    _module_functions[66].shadow_test = NULL;
    _module_functions[66].is_extern = false;
    _module_functions[66].returns_gc_managed = true;
    _module_functions[66].requires_manual_free = false;
    _module_functions[66].returns_borrowed = false;
    _module_functions[66].cleanup_function = NULL;
    _module_functions[66].params = NULL;

    /* Function: list_string_length */
    _module_functions[67].name = "list_string_length";
    _module_functions[67].param_count = 0;
    _module_functions[67].return_type = 0;
    _module_functions[67].return_struct_type_name = NULL;
    _module_functions[67].return_fn_sig = NULL;
    _module_functions[67].return_type_info = NULL;
    _module_functions[67].body = NULL;
    _module_functions[67].shadow_test = NULL;
    _module_functions[67].is_extern = false;
    _module_functions[67].returns_gc_managed = false;
    _module_functions[67].requires_manual_free = false;
    _module_functions[67].returns_borrowed = false;
    _module_functions[67].cleanup_function = NULL;
    _module_functions[67].params = NULL;

    /* Function: list_string_capacity */
    _module_functions[68].name = "list_string_capacity";
    _module_functions[68].param_count = 0;
    _module_functions[68].return_type = 0;
    _module_functions[68].return_struct_type_name = NULL;
    _module_functions[68].return_fn_sig = NULL;
    _module_functions[68].return_type_info = NULL;
    _module_functions[68].body = NULL;
    _module_functions[68].shadow_test = NULL;
    _module_functions[68].is_extern = false;
    _module_functions[68].returns_gc_managed = false;
    _module_functions[68].requires_manual_free = false;
    _module_functions[68].returns_borrowed = false;
    _module_functions[68].cleanup_function = NULL;
    _module_functions[68].params = NULL;

    /* Function: list_string_is_empty */
    _module_functions[69].name = "list_string_is_empty";
    _module_functions[69].param_count = 0;
    _module_functions[69].return_type = 3;
    _module_functions[69].return_struct_type_name = NULL;
    _module_functions[69].return_fn_sig = NULL;
    _module_functions[69].return_type_info = NULL;
    _module_functions[69].body = NULL;
    _module_functions[69].shadow_test = NULL;
    _module_functions[69].is_extern = false;
    _module_functions[69].returns_gc_managed = false;
    _module_functions[69].requires_manual_free = false;
    _module_functions[69].returns_borrowed = false;
    _module_functions[69].cleanup_function = NULL;
    _module_functions[69].params = NULL;

    /* Function: list_string_clear */
    _module_functions[70].name = "list_string_clear";
    _module_functions[70].param_count = 0;
    _module_functions[70].return_type = 6;
    _module_functions[70].return_struct_type_name = NULL;
    _module_functions[70].return_fn_sig = NULL;
    _module_functions[70].return_type_info = NULL;
    _module_functions[70].body = NULL;
    _module_functions[70].shadow_test = NULL;
    _module_functions[70].is_extern = false;
    _module_functions[70].returns_gc_managed = false;
    _module_functions[70].requires_manual_free = false;
    _module_functions[70].returns_borrowed = false;
    _module_functions[70].cleanup_function = NULL;
    _module_functions[70].params = NULL;

    /* Function: list_string_free */
    _module_functions[71].name = "list_string_free";
    _module_functions[71].param_count = 0;
    _module_functions[71].return_type = 6;
    _module_functions[71].return_struct_type_name = NULL;
    _module_functions[71].return_fn_sig = NULL;
    _module_functions[71].return_type_info = NULL;
    _module_functions[71].body = NULL;
    _module_functions[71].shadow_test = NULL;
    _module_functions[71].is_extern = false;
    _module_functions[71].returns_gc_managed = false;
    _module_functions[71].requires_manual_free = false;
    _module_functions[71].returns_borrowed = false;
    _module_functions[71].cleanup_function = NULL;
    _module_functions[71].params = NULL;

    /* Function: nl_list_Token_new */
    _module_functions[72].name = "nl_list_Token_new";
    _module_functions[72].param_count = 0;
    _module_functions[72].return_type = 14;
    _module_functions[72].return_struct_type_name = NULL;
    _module_functions[72].return_fn_sig = NULL;
    _module_functions[72].return_type_info = NULL;
    _module_functions[72].body = NULL;
    _module_functions[72].shadow_test = NULL;
    _module_functions[72].is_extern = false;
    _module_functions[72].returns_gc_managed = false;
    _module_functions[72].requires_manual_free = false;
    _module_functions[72].returns_borrowed = false;
    _module_functions[72].cleanup_function = NULL;
    _module_functions[72].params = NULL;

    /* Function: nl_list_Token_with_capacity */
    _module_functions[73].name = "nl_list_Token_with_capacity";
    _module_functions[73].param_count = 0;
    _module_functions[73].return_type = 14;
    _module_functions[73].return_struct_type_name = NULL;
    _module_functions[73].return_fn_sig = NULL;
    _module_functions[73].return_type_info = NULL;
    _module_functions[73].body = NULL;
    _module_functions[73].shadow_test = NULL;
    _module_functions[73].is_extern = false;
    _module_functions[73].returns_gc_managed = false;
    _module_functions[73].requires_manual_free = false;
    _module_functions[73].returns_borrowed = false;
    _module_functions[73].cleanup_function = NULL;
    _module_functions[73].params = NULL;

    /* Function: nl_list_Token_push */
    _module_functions[74].name = "nl_list_Token_push";
    _module_functions[74].param_count = 0;
    _module_functions[74].return_type = 6;
    _module_functions[74].return_struct_type_name = NULL;
    _module_functions[74].return_fn_sig = NULL;
    _module_functions[74].return_type_info = NULL;
    _module_functions[74].body = NULL;
    _module_functions[74].shadow_test = NULL;
    _module_functions[74].is_extern = false;
    _module_functions[74].returns_gc_managed = false;
    _module_functions[74].requires_manual_free = false;
    _module_functions[74].returns_borrowed = false;
    _module_functions[74].cleanup_function = NULL;
    _module_functions[74].params = NULL;

    /* Function: nl_list_Token_pop */
    _module_functions[75].name = "nl_list_Token_pop";
    _module_functions[75].param_count = 0;
    _module_functions[75].return_type = 8;
    _module_functions[75].return_struct_type_name = NULL;
    _module_functions[75].return_fn_sig = NULL;
    _module_functions[75].return_type_info = NULL;
    _module_functions[75].body = NULL;
    _module_functions[75].shadow_test = NULL;
    _module_functions[75].is_extern = false;
    _module_functions[75].returns_gc_managed = false;
    _module_functions[75].requires_manual_free = false;
    _module_functions[75].returns_borrowed = false;
    _module_functions[75].cleanup_function = NULL;
    _module_functions[75].params = NULL;

    /* Function: nl_list_Token_get */
    _module_functions[76].name = "nl_list_Token_get";
    _module_functions[76].param_count = 0;
    _module_functions[76].return_type = 8;
    _module_functions[76].return_struct_type_name = NULL;
    _module_functions[76].return_fn_sig = NULL;
    _module_functions[76].return_type_info = NULL;
    _module_functions[76].body = NULL;
    _module_functions[76].shadow_test = NULL;
    _module_functions[76].is_extern = false;
    _module_functions[76].returns_gc_managed = false;
    _module_functions[76].requires_manual_free = false;
    _module_functions[76].returns_borrowed = false;
    _module_functions[76].cleanup_function = NULL;
    _module_functions[76].params = NULL;

    /* Function: nl_list_Token_set */
    _module_functions[77].name = "nl_list_Token_set";
    _module_functions[77].param_count = 0;
    _module_functions[77].return_type = 6;
    _module_functions[77].return_struct_type_name = NULL;
    _module_functions[77].return_fn_sig = NULL;
    _module_functions[77].return_type_info = NULL;
    _module_functions[77].body = NULL;
    _module_functions[77].shadow_test = NULL;
    _module_functions[77].is_extern = false;
    _module_functions[77].returns_gc_managed = false;
    _module_functions[77].requires_manual_free = false;
    _module_functions[77].returns_borrowed = false;
    _module_functions[77].cleanup_function = NULL;
    _module_functions[77].params = NULL;

    /* Function: nl_list_Token_insert */
    _module_functions[78].name = "nl_list_Token_insert";
    _module_functions[78].param_count = 0;
    _module_functions[78].return_type = 6;
    _module_functions[78].return_struct_type_name = NULL;
    _module_functions[78].return_fn_sig = NULL;
    _module_functions[78].return_type_info = NULL;
    _module_functions[78].body = NULL;
    _module_functions[78].shadow_test = NULL;
    _module_functions[78].is_extern = false;
    _module_functions[78].returns_gc_managed = false;
    _module_functions[78].requires_manual_free = false;
    _module_functions[78].returns_borrowed = false;
    _module_functions[78].cleanup_function = NULL;
    _module_functions[78].params = NULL;

    /* Function: nl_list_Token_remove */
    _module_functions[79].name = "nl_list_Token_remove";
    _module_functions[79].param_count = 0;
    _module_functions[79].return_type = 8;
    _module_functions[79].return_struct_type_name = NULL;
    _module_functions[79].return_fn_sig = NULL;
    _module_functions[79].return_type_info = NULL;
    _module_functions[79].body = NULL;
    _module_functions[79].shadow_test = NULL;
    _module_functions[79].is_extern = false;
    _module_functions[79].returns_gc_managed = false;
    _module_functions[79].requires_manual_free = false;
    _module_functions[79].returns_borrowed = false;
    _module_functions[79].cleanup_function = NULL;
    _module_functions[79].params = NULL;

    /* Function: nl_list_Token_length */
    _module_functions[80].name = "nl_list_Token_length";
    _module_functions[80].param_count = 0;
    _module_functions[80].return_type = 0;
    _module_functions[80].return_struct_type_name = NULL;
    _module_functions[80].return_fn_sig = NULL;
    _module_functions[80].return_type_info = NULL;
    _module_functions[80].body = NULL;
    _module_functions[80].shadow_test = NULL;
    _module_functions[80].is_extern = false;
    _module_functions[80].returns_gc_managed = false;
    _module_functions[80].requires_manual_free = false;
    _module_functions[80].returns_borrowed = false;
    _module_functions[80].cleanup_function = NULL;
    _module_functions[80].params = NULL;

    /* Function: nl_list_Token_capacity */
    _module_functions[81].name = "nl_list_Token_capacity";
    _module_functions[81].param_count = 0;
    _module_functions[81].return_type = 0;
    _module_functions[81].return_struct_type_name = NULL;
    _module_functions[81].return_fn_sig = NULL;
    _module_functions[81].return_type_info = NULL;
    _module_functions[81].body = NULL;
    _module_functions[81].shadow_test = NULL;
    _module_functions[81].is_extern = false;
    _module_functions[81].returns_gc_managed = false;
    _module_functions[81].requires_manual_free = false;
    _module_functions[81].returns_borrowed = false;
    _module_functions[81].cleanup_function = NULL;
    _module_functions[81].params = NULL;

    /* Function: nl_list_Token_is_empty */
    _module_functions[82].name = "nl_list_Token_is_empty";
    _module_functions[82].param_count = 0;
    _module_functions[82].return_type = 3;
    _module_functions[82].return_struct_type_name = NULL;
    _module_functions[82].return_fn_sig = NULL;
    _module_functions[82].return_type_info = NULL;
    _module_functions[82].body = NULL;
    _module_functions[82].shadow_test = NULL;
    _module_functions[82].is_extern = false;
    _module_functions[82].returns_gc_managed = false;
    _module_functions[82].requires_manual_free = false;
    _module_functions[82].returns_borrowed = false;
    _module_functions[82].cleanup_function = NULL;
    _module_functions[82].params = NULL;

    /* Function: nl_list_Token_clear */
    _module_functions[83].name = "nl_list_Token_clear";
    _module_functions[83].param_count = 0;
    _module_functions[83].return_type = 6;
    _module_functions[83].return_struct_type_name = NULL;
    _module_functions[83].return_fn_sig = NULL;
    _module_functions[83].return_type_info = NULL;
    _module_functions[83].body = NULL;
    _module_functions[83].shadow_test = NULL;
    _module_functions[83].is_extern = false;
    _module_functions[83].returns_gc_managed = false;
    _module_functions[83].requires_manual_free = false;
    _module_functions[83].returns_borrowed = false;
    _module_functions[83].cleanup_function = NULL;
    _module_functions[83].params = NULL;

    /* Function: nl_list_Token_free */
    _module_functions[84].name = "nl_list_Token_free";
    _module_functions[84].param_count = 0;
    _module_functions[84].return_type = 6;
    _module_functions[84].return_struct_type_name = NULL;
    _module_functions[84].return_fn_sig = NULL;
    _module_functions[84].return_type_info = NULL;
    _module_functions[84].body = NULL;
    _module_functions[84].shadow_test = NULL;
    _module_functions[84].is_extern = false;
    _module_functions[84].returns_gc_managed = false;
    _module_functions[84].requires_manual_free = false;
    _module_functions[84].returns_borrowed = false;
    _module_functions[84].cleanup_function = NULL;
    _module_functions[84].params = NULL;

    /* Function: List_CompilerDiagnostic_new */
    _module_functions[85].name = "List_CompilerDiagnostic_new";
    _module_functions[85].param_count = 0;
    _module_functions[85].return_type = 15;
    _module_functions[85].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[85].return_fn_sig = NULL;
    _module_functions[85].return_type_info = NULL;
    _module_functions[85].body = NULL;
    _module_functions[85].shadow_test = NULL;
    _module_functions[85].is_extern = true;
    _module_functions[85].returns_gc_managed = false;
    _module_functions[85].requires_manual_free = false;
    _module_functions[85].returns_borrowed = false;
    _module_functions[85].cleanup_function = NULL;
    _module_functions[85].params = NULL;

    /* Function: List_CompilerDiagnostic_push */
    _module_functions[86].name = "List_CompilerDiagnostic_push";
    _module_functions[86].param_count = 2;
    _module_functions[86].return_type = 6;
    _module_functions[86].return_struct_type_name = NULL;
    _module_functions[86].return_fn_sig = NULL;
    _module_functions[86].return_type_info = NULL;
    _module_functions[86].body = NULL;
    _module_functions[86].shadow_test = NULL;
    _module_functions[86].is_extern = true;
    _module_functions[86].returns_gc_managed = false;
    _module_functions[86].requires_manual_free = false;
    _module_functions[86].returns_borrowed = false;
    _module_functions[86].cleanup_function = NULL;
    _module_functions[86].params = &_module_params[0];
    _module_params[0].name = "list";
    _module_params[0].type = 15;
    _module_params[0].struct_type_name = "CompilerDiagnostic";
    _module_params[0].element_type = 21;
    _module_params[0].fn_sig = NULL;
    _module_params[1].name = "value";
    _module_params[1].type = 8;
    _module_params[1].struct_type_name = "CompilerDiagnostic";
    _module_params[1].element_type = 21;
    _module_params[1].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_get */
    _module_functions[87].name = "List_CompilerDiagnostic_get";
    _module_functions[87].param_count = 2;
    _module_functions[87].return_type = 8;
    _module_functions[87].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[87].return_fn_sig = NULL;
    _module_functions[87].return_type_info = NULL;
    _module_functions[87].body = NULL;
    _module_functions[87].shadow_test = NULL;
    _module_functions[87].is_extern = true;
    _module_functions[87].returns_gc_managed = false;
    _module_functions[87].requires_manual_free = false;
    _module_functions[87].returns_borrowed = false;
    _module_functions[87].cleanup_function = NULL;
    _module_functions[87].params = &_module_params[2];
    _module_params[2].name = "list";
    _module_params[2].type = 15;
    _module_params[2].struct_type_name = "CompilerDiagnostic";
    _module_params[2].element_type = 21;
    _module_params[2].fn_sig = NULL;
    _module_params[3].name = "index";
    _module_params[3].type = 0;
    _module_params[3].struct_type_name = NULL;
    _module_params[3].element_type = 21;
    _module_params[3].fn_sig = NULL;

    /* Function: List_CompilerDiagnostic_length */
    _module_functions[88].name = "List_CompilerDiagnostic_length";
    _module_functions[88].param_count = 1;
    _module_functions[88].return_type = 0;
    _module_functions[88].return_struct_type_name = NULL;
    _module_functions[88].return_fn_sig = NULL;
    _module_functions[88].return_type_info = NULL;
    _module_functions[88].body = NULL;
    _module_functions[88].shadow_test = NULL;
    _module_functions[88].is_extern = true;
    _module_functions[88].returns_gc_managed = false;
    _module_functions[88].requires_manual_free = false;
    _module_functions[88].returns_borrowed = false;
    _module_functions[88].cleanup_function = NULL;
    _module_functions[88].params = &_module_params[4];
    _module_params[4].name = "list";
    _module_params[4].type = 15;
    _module_params[4].struct_type_name = "CompilerDiagnostic";
    _module_params[4].element_type = 21;
    _module_params[4].fn_sig = NULL;

    /* Function: List_LexerToken_new */
    _module_functions[89].name = "List_LexerToken_new";
    _module_functions[89].param_count = 0;
    _module_functions[89].return_type = 15;
    _module_functions[89].return_struct_type_name = "LexerToken";
    _module_functions[89].return_fn_sig = NULL;
    _module_functions[89].return_type_info = NULL;
    _module_functions[89].body = NULL;
    _module_functions[89].shadow_test = NULL;
    _module_functions[89].is_extern = true;
    _module_functions[89].returns_gc_managed = false;
    _module_functions[89].requires_manual_free = false;
    _module_functions[89].returns_borrowed = false;
    _module_functions[89].cleanup_function = NULL;
    _module_functions[89].params = NULL;

    /* Function: List_LexerToken_push */
    _module_functions[90].name = "List_LexerToken_push";
    _module_functions[90].param_count = 2;
    _module_functions[90].return_type = 6;
    _module_functions[90].return_struct_type_name = NULL;
    _module_functions[90].return_fn_sig = NULL;
    _module_functions[90].return_type_info = NULL;
    _module_functions[90].body = NULL;
    _module_functions[90].shadow_test = NULL;
    _module_functions[90].is_extern = true;
    _module_functions[90].returns_gc_managed = false;
    _module_functions[90].requires_manual_free = false;
    _module_functions[90].returns_borrowed = false;
    _module_functions[90].cleanup_function = NULL;
    _module_functions[90].params = &_module_params[5];
    _module_params[5].name = "list";
    _module_params[5].type = 15;
    _module_params[5].struct_type_name = "LexerToken";
    _module_params[5].element_type = 21;
    _module_params[5].fn_sig = NULL;
    _module_params[6].name = "value";
    _module_params[6].type = 8;
    _module_params[6].struct_type_name = "LexerToken";
    _module_params[6].element_type = 21;
    _module_params[6].fn_sig = NULL;

    /* Function: List_LexerToken_get */
    _module_functions[91].name = "List_LexerToken_get";
    _module_functions[91].param_count = 2;
    _module_functions[91].return_type = 8;
    _module_functions[91].return_struct_type_name = "LexerToken";
    _module_functions[91].return_fn_sig = NULL;
    _module_functions[91].return_type_info = NULL;
    _module_functions[91].body = NULL;
    _module_functions[91].shadow_test = NULL;
    _module_functions[91].is_extern = true;
    _module_functions[91].returns_gc_managed = false;
    _module_functions[91].requires_manual_free = false;
    _module_functions[91].returns_borrowed = false;
    _module_functions[91].cleanup_function = NULL;
    _module_functions[91].params = &_module_params[7];
    _module_params[7].name = "list";
    _module_params[7].type = 15;
    _module_params[7].struct_type_name = "LexerToken";
    _module_params[7].element_type = 21;
    _module_params[7].fn_sig = NULL;
    _module_params[8].name = "index";
    _module_params[8].type = 0;
    _module_params[8].struct_type_name = NULL;
    _module_params[8].element_type = 21;
    _module_params[8].fn_sig = NULL;

    /* Function: List_LexerToken_length */
    _module_functions[92].name = "List_LexerToken_length";
    _module_functions[92].param_count = 1;
    _module_functions[92].return_type = 0;
    _module_functions[92].return_struct_type_name = NULL;
    _module_functions[92].return_fn_sig = NULL;
    _module_functions[92].return_type_info = NULL;
    _module_functions[92].body = NULL;
    _module_functions[92].shadow_test = NULL;
    _module_functions[92].is_extern = true;
    _module_functions[92].returns_gc_managed = false;
    _module_functions[92].requires_manual_free = false;
    _module_functions[92].returns_borrowed = false;
    _module_functions[92].cleanup_function = NULL;
    _module_functions[92].params = &_module_params[9];
    _module_params[9].name = "list";
    _module_params[9].type = 15;
    _module_params[9].struct_type_name = "LexerToken";
    _module_params[9].element_type = 21;
    _module_params[9].fn_sig = NULL;

    /* Function: List_ASTStmtRef_new */
    _module_functions[93].name = "List_ASTStmtRef_new";
    _module_functions[93].param_count = 0;
    _module_functions[93].return_type = 15;
    _module_functions[93].return_struct_type_name = "ASTStmtRef";
    _module_functions[93].return_fn_sig = NULL;
    _module_functions[93].return_type_info = NULL;
    _module_functions[93].body = NULL;
    _module_functions[93].shadow_test = NULL;
    _module_functions[93].is_extern = true;
    _module_functions[93].returns_gc_managed = false;
    _module_functions[93].requires_manual_free = false;
    _module_functions[93].returns_borrowed = false;
    _module_functions[93].cleanup_function = NULL;
    _module_functions[93].params = NULL;

    /* Function: List_ASTStmtRef_push */
    _module_functions[94].name = "List_ASTStmtRef_push";
    _module_functions[94].param_count = 2;
    _module_functions[94].return_type = 6;
    _module_functions[94].return_struct_type_name = NULL;
    _module_functions[94].return_fn_sig = NULL;
    _module_functions[94].return_type_info = NULL;
    _module_functions[94].body = NULL;
    _module_functions[94].shadow_test = NULL;
    _module_functions[94].is_extern = true;
    _module_functions[94].returns_gc_managed = false;
    _module_functions[94].requires_manual_free = false;
    _module_functions[94].returns_borrowed = false;
    _module_functions[94].cleanup_function = NULL;
    _module_functions[94].params = &_module_params[10];
    _module_params[10].name = "list";
    _module_params[10].type = 15;
    _module_params[10].struct_type_name = "ASTStmtRef";
    _module_params[10].element_type = 21;
    _module_params[10].fn_sig = NULL;
    _module_params[11].name = "value";
    _module_params[11].type = 8;
    _module_params[11].struct_type_name = "ASTStmtRef";
    _module_params[11].element_type = 21;
    _module_params[11].fn_sig = NULL;

    /* Function: List_ASTStmtRef_get */
    _module_functions[95].name = "List_ASTStmtRef_get";
    _module_functions[95].param_count = 2;
    _module_functions[95].return_type = 8;
    _module_functions[95].return_struct_type_name = "ASTStmtRef";
    _module_functions[95].return_fn_sig = NULL;
    _module_functions[95].return_type_info = NULL;
    _module_functions[95].body = NULL;
    _module_functions[95].shadow_test = NULL;
    _module_functions[95].is_extern = true;
    _module_functions[95].returns_gc_managed = false;
    _module_functions[95].requires_manual_free = false;
    _module_functions[95].returns_borrowed = false;
    _module_functions[95].cleanup_function = NULL;
    _module_functions[95].params = &_module_params[12];
    _module_params[12].name = "list";
    _module_params[12].type = 15;
    _module_params[12].struct_type_name = "ASTStmtRef";
    _module_params[12].element_type = 21;
    _module_params[12].fn_sig = NULL;
    _module_params[13].name = "index";
    _module_params[13].type = 0;
    _module_params[13].struct_type_name = NULL;
    _module_params[13].element_type = 21;
    _module_params[13].fn_sig = NULL;

    /* Function: List_ASTStmtRef_length */
    _module_functions[96].name = "List_ASTStmtRef_length";
    _module_functions[96].param_count = 1;
    _module_functions[96].return_type = 0;
    _module_functions[96].return_struct_type_name = NULL;
    _module_functions[96].return_fn_sig = NULL;
    _module_functions[96].return_type_info = NULL;
    _module_functions[96].body = NULL;
    _module_functions[96].shadow_test = NULL;
    _module_functions[96].is_extern = true;
    _module_functions[96].returns_gc_managed = false;
    _module_functions[96].requires_manual_free = false;
    _module_functions[96].returns_borrowed = false;
    _module_functions[96].cleanup_function = NULL;
    _module_functions[96].params = &_module_params[14];
    _module_params[14].name = "list";
    _module_params[14].type = 15;
    _module_params[14].struct_type_name = "ASTStmtRef";
    _module_params[14].element_type = 21;
    _module_params[14].fn_sig = NULL;

    /* Function: List_ASTNumber_new */
    _module_functions[97].name = "List_ASTNumber_new";
    _module_functions[97].param_count = 0;
    _module_functions[97].return_type = 15;
    _module_functions[97].return_struct_type_name = "ASTNumber";
    _module_functions[97].return_fn_sig = NULL;
    _module_functions[97].return_type_info = NULL;
    _module_functions[97].body = NULL;
    _module_functions[97].shadow_test = NULL;
    _module_functions[97].is_extern = true;
    _module_functions[97].returns_gc_managed = false;
    _module_functions[97].requires_manual_free = false;
    _module_functions[97].returns_borrowed = false;
    _module_functions[97].cleanup_function = NULL;
    _module_functions[97].params = NULL;

    /* Function: List_ASTNumber_push */
    _module_functions[98].name = "List_ASTNumber_push";
    _module_functions[98].param_count = 2;
    _module_functions[98].return_type = 6;
    _module_functions[98].return_struct_type_name = NULL;
    _module_functions[98].return_fn_sig = NULL;
    _module_functions[98].return_type_info = NULL;
    _module_functions[98].body = NULL;
    _module_functions[98].shadow_test = NULL;
    _module_functions[98].is_extern = true;
    _module_functions[98].returns_gc_managed = false;
    _module_functions[98].requires_manual_free = false;
    _module_functions[98].returns_borrowed = false;
    _module_functions[98].cleanup_function = NULL;
    _module_functions[98].params = &_module_params[15];
    _module_params[15].name = "list";
    _module_params[15].type = 15;
    _module_params[15].struct_type_name = "ASTNumber";
    _module_params[15].element_type = 21;
    _module_params[15].fn_sig = NULL;
    _module_params[16].name = "value";
    _module_params[16].type = 8;
    _module_params[16].struct_type_name = "ASTNumber";
    _module_params[16].element_type = 21;
    _module_params[16].fn_sig = NULL;

    /* Function: List_ASTNumber_get */
    _module_functions[99].name = "List_ASTNumber_get";
    _module_functions[99].param_count = 2;
    _module_functions[99].return_type = 8;
    _module_functions[99].return_struct_type_name = "ASTNumber";
    _module_functions[99].return_fn_sig = NULL;
    _module_functions[99].return_type_info = NULL;
    _module_functions[99].body = NULL;
    _module_functions[99].shadow_test = NULL;
    _module_functions[99].is_extern = true;
    _module_functions[99].returns_gc_managed = false;
    _module_functions[99].requires_manual_free = false;
    _module_functions[99].returns_borrowed = false;
    _module_functions[99].cleanup_function = NULL;
    _module_functions[99].params = &_module_params[17];
    _module_params[17].name = "list";
    _module_params[17].type = 15;
    _module_params[17].struct_type_name = "ASTNumber";
    _module_params[17].element_type = 21;
    _module_params[17].fn_sig = NULL;
    _module_params[18].name = "index";
    _module_params[18].type = 0;
    _module_params[18].struct_type_name = NULL;
    _module_params[18].element_type = 21;
    _module_params[18].fn_sig = NULL;

    /* Function: List_ASTNumber_length */
    _module_functions[100].name = "List_ASTNumber_length";
    _module_functions[100].param_count = 1;
    _module_functions[100].return_type = 0;
    _module_functions[100].return_struct_type_name = NULL;
    _module_functions[100].return_fn_sig = NULL;
    _module_functions[100].return_type_info = NULL;
    _module_functions[100].body = NULL;
    _module_functions[100].shadow_test = NULL;
    _module_functions[100].is_extern = true;
    _module_functions[100].returns_gc_managed = false;
    _module_functions[100].requires_manual_free = false;
    _module_functions[100].returns_borrowed = false;
    _module_functions[100].cleanup_function = NULL;
    _module_functions[100].params = &_module_params[19];
    _module_params[19].name = "list";
    _module_params[19].type = 15;
    _module_params[19].struct_type_name = "ASTNumber";
    _module_params[19].element_type = 21;
    _module_params[19].fn_sig = NULL;

    /* Function: List_ASTFloat_new */
    _module_functions[101].name = "List_ASTFloat_new";
    _module_functions[101].param_count = 0;
    _module_functions[101].return_type = 15;
    _module_functions[101].return_struct_type_name = "ASTFloat";
    _module_functions[101].return_fn_sig = NULL;
    _module_functions[101].return_type_info = NULL;
    _module_functions[101].body = NULL;
    _module_functions[101].shadow_test = NULL;
    _module_functions[101].is_extern = true;
    _module_functions[101].returns_gc_managed = false;
    _module_functions[101].requires_manual_free = false;
    _module_functions[101].returns_borrowed = false;
    _module_functions[101].cleanup_function = NULL;
    _module_functions[101].params = NULL;

    /* Function: List_ASTFloat_push */
    _module_functions[102].name = "List_ASTFloat_push";
    _module_functions[102].param_count = 2;
    _module_functions[102].return_type = 6;
    _module_functions[102].return_struct_type_name = NULL;
    _module_functions[102].return_fn_sig = NULL;
    _module_functions[102].return_type_info = NULL;
    _module_functions[102].body = NULL;
    _module_functions[102].shadow_test = NULL;
    _module_functions[102].is_extern = true;
    _module_functions[102].returns_gc_managed = false;
    _module_functions[102].requires_manual_free = false;
    _module_functions[102].returns_borrowed = false;
    _module_functions[102].cleanup_function = NULL;
    _module_functions[102].params = &_module_params[20];
    _module_params[20].name = "list";
    _module_params[20].type = 15;
    _module_params[20].struct_type_name = "ASTFloat";
    _module_params[20].element_type = 21;
    _module_params[20].fn_sig = NULL;
    _module_params[21].name = "value";
    _module_params[21].type = 8;
    _module_params[21].struct_type_name = "ASTFloat";
    _module_params[21].element_type = 21;
    _module_params[21].fn_sig = NULL;

    /* Function: List_ASTFloat_get */
    _module_functions[103].name = "List_ASTFloat_get";
    _module_functions[103].param_count = 2;
    _module_functions[103].return_type = 8;
    _module_functions[103].return_struct_type_name = "ASTFloat";
    _module_functions[103].return_fn_sig = NULL;
    _module_functions[103].return_type_info = NULL;
    _module_functions[103].body = NULL;
    _module_functions[103].shadow_test = NULL;
    _module_functions[103].is_extern = true;
    _module_functions[103].returns_gc_managed = false;
    _module_functions[103].requires_manual_free = false;
    _module_functions[103].returns_borrowed = false;
    _module_functions[103].cleanup_function = NULL;
    _module_functions[103].params = &_module_params[22];
    _module_params[22].name = "list";
    _module_params[22].type = 15;
    _module_params[22].struct_type_name = "ASTFloat";
    _module_params[22].element_type = 21;
    _module_params[22].fn_sig = NULL;
    _module_params[23].name = "index";
    _module_params[23].type = 0;
    _module_params[23].struct_type_name = NULL;
    _module_params[23].element_type = 21;
    _module_params[23].fn_sig = NULL;

    /* Function: List_ASTFloat_length */
    _module_functions[104].name = "List_ASTFloat_length";
    _module_functions[104].param_count = 1;
    _module_functions[104].return_type = 0;
    _module_functions[104].return_struct_type_name = NULL;
    _module_functions[104].return_fn_sig = NULL;
    _module_functions[104].return_type_info = NULL;
    _module_functions[104].body = NULL;
    _module_functions[104].shadow_test = NULL;
    _module_functions[104].is_extern = true;
    _module_functions[104].returns_gc_managed = false;
    _module_functions[104].requires_manual_free = false;
    _module_functions[104].returns_borrowed = false;
    _module_functions[104].cleanup_function = NULL;
    _module_functions[104].params = &_module_params[24];
    _module_params[24].name = "list";
    _module_params[24].type = 15;
    _module_params[24].struct_type_name = "ASTFloat";
    _module_params[24].element_type = 21;
    _module_params[24].fn_sig = NULL;

    /* Function: List_ASTString_new */
    _module_functions[105].name = "List_ASTString_new";
    _module_functions[105].param_count = 0;
    _module_functions[105].return_type = 15;
    _module_functions[105].return_struct_type_name = "ASTString";
    _module_functions[105].return_fn_sig = NULL;
    _module_functions[105].return_type_info = NULL;
    _module_functions[105].body = NULL;
    _module_functions[105].shadow_test = NULL;
    _module_functions[105].is_extern = true;
    _module_functions[105].returns_gc_managed = false;
    _module_functions[105].requires_manual_free = false;
    _module_functions[105].returns_borrowed = false;
    _module_functions[105].cleanup_function = NULL;
    _module_functions[105].params = NULL;

    /* Function: List_ASTString_push */
    _module_functions[106].name = "List_ASTString_push";
    _module_functions[106].param_count = 2;
    _module_functions[106].return_type = 6;
    _module_functions[106].return_struct_type_name = NULL;
    _module_functions[106].return_fn_sig = NULL;
    _module_functions[106].return_type_info = NULL;
    _module_functions[106].body = NULL;
    _module_functions[106].shadow_test = NULL;
    _module_functions[106].is_extern = true;
    _module_functions[106].returns_gc_managed = false;
    _module_functions[106].requires_manual_free = false;
    _module_functions[106].returns_borrowed = false;
    _module_functions[106].cleanup_function = NULL;
    _module_functions[106].params = &_module_params[25];
    _module_params[25].name = "list";
    _module_params[25].type = 15;
    _module_params[25].struct_type_name = "ASTString";
    _module_params[25].element_type = 21;
    _module_params[25].fn_sig = NULL;
    _module_params[26].name = "value";
    _module_params[26].type = 8;
    _module_params[26].struct_type_name = "ASTString";
    _module_params[26].element_type = 21;
    _module_params[26].fn_sig = NULL;

    /* Function: List_ASTString_get */
    _module_functions[107].name = "List_ASTString_get";
    _module_functions[107].param_count = 2;
    _module_functions[107].return_type = 8;
    _module_functions[107].return_struct_type_name = "ASTString";
    _module_functions[107].return_fn_sig = NULL;
    _module_functions[107].return_type_info = NULL;
    _module_functions[107].body = NULL;
    _module_functions[107].shadow_test = NULL;
    _module_functions[107].is_extern = true;
    _module_functions[107].returns_gc_managed = false;
    _module_functions[107].requires_manual_free = false;
    _module_functions[107].returns_borrowed = false;
    _module_functions[107].cleanup_function = NULL;
    _module_functions[107].params = &_module_params[27];
    _module_params[27].name = "list";
    _module_params[27].type = 15;
    _module_params[27].struct_type_name = "ASTString";
    _module_params[27].element_type = 21;
    _module_params[27].fn_sig = NULL;
    _module_params[28].name = "index";
    _module_params[28].type = 0;
    _module_params[28].struct_type_name = NULL;
    _module_params[28].element_type = 21;
    _module_params[28].fn_sig = NULL;

    /* Function: List_ASTString_length */
    _module_functions[108].name = "List_ASTString_length";
    _module_functions[108].param_count = 1;
    _module_functions[108].return_type = 0;
    _module_functions[108].return_struct_type_name = NULL;
    _module_functions[108].return_fn_sig = NULL;
    _module_functions[108].return_type_info = NULL;
    _module_functions[108].body = NULL;
    _module_functions[108].shadow_test = NULL;
    _module_functions[108].is_extern = true;
    _module_functions[108].returns_gc_managed = false;
    _module_functions[108].requires_manual_free = false;
    _module_functions[108].returns_borrowed = false;
    _module_functions[108].cleanup_function = NULL;
    _module_functions[108].params = &_module_params[29];
    _module_params[29].name = "list";
    _module_params[29].type = 15;
    _module_params[29].struct_type_name = "ASTString";
    _module_params[29].element_type = 21;
    _module_params[29].fn_sig = NULL;

    /* Function: List_ASTBool_new */
    _module_functions[109].name = "List_ASTBool_new";
    _module_functions[109].param_count = 0;
    _module_functions[109].return_type = 15;
    _module_functions[109].return_struct_type_name = "ASTBool";
    _module_functions[109].return_fn_sig = NULL;
    _module_functions[109].return_type_info = NULL;
    _module_functions[109].body = NULL;
    _module_functions[109].shadow_test = NULL;
    _module_functions[109].is_extern = true;
    _module_functions[109].returns_gc_managed = false;
    _module_functions[109].requires_manual_free = false;
    _module_functions[109].returns_borrowed = false;
    _module_functions[109].cleanup_function = NULL;
    _module_functions[109].params = NULL;

    /* Function: List_ASTBool_push */
    _module_functions[110].name = "List_ASTBool_push";
    _module_functions[110].param_count = 2;
    _module_functions[110].return_type = 6;
    _module_functions[110].return_struct_type_name = NULL;
    _module_functions[110].return_fn_sig = NULL;
    _module_functions[110].return_type_info = NULL;
    _module_functions[110].body = NULL;
    _module_functions[110].shadow_test = NULL;
    _module_functions[110].is_extern = true;
    _module_functions[110].returns_gc_managed = false;
    _module_functions[110].requires_manual_free = false;
    _module_functions[110].returns_borrowed = false;
    _module_functions[110].cleanup_function = NULL;
    _module_functions[110].params = &_module_params[30];
    _module_params[30].name = "list";
    _module_params[30].type = 15;
    _module_params[30].struct_type_name = "ASTBool";
    _module_params[30].element_type = 21;
    _module_params[30].fn_sig = NULL;
    _module_params[31].name = "value";
    _module_params[31].type = 8;
    _module_params[31].struct_type_name = "ASTBool";
    _module_params[31].element_type = 21;
    _module_params[31].fn_sig = NULL;

    /* Function: List_ASTBool_get */
    _module_functions[111].name = "List_ASTBool_get";
    _module_functions[111].param_count = 2;
    _module_functions[111].return_type = 8;
    _module_functions[111].return_struct_type_name = "ASTBool";
    _module_functions[111].return_fn_sig = NULL;
    _module_functions[111].return_type_info = NULL;
    _module_functions[111].body = NULL;
    _module_functions[111].shadow_test = NULL;
    _module_functions[111].is_extern = true;
    _module_functions[111].returns_gc_managed = false;
    _module_functions[111].requires_manual_free = false;
    _module_functions[111].returns_borrowed = false;
    _module_functions[111].cleanup_function = NULL;
    _module_functions[111].params = &_module_params[32];
    _module_params[32].name = "list";
    _module_params[32].type = 15;
    _module_params[32].struct_type_name = "ASTBool";
    _module_params[32].element_type = 21;
    _module_params[32].fn_sig = NULL;
    _module_params[33].name = "index";
    _module_params[33].type = 0;
    _module_params[33].struct_type_name = NULL;
    _module_params[33].element_type = 21;
    _module_params[33].fn_sig = NULL;

    /* Function: List_ASTBool_length */
    _module_functions[112].name = "List_ASTBool_length";
    _module_functions[112].param_count = 1;
    _module_functions[112].return_type = 0;
    _module_functions[112].return_struct_type_name = NULL;
    _module_functions[112].return_fn_sig = NULL;
    _module_functions[112].return_type_info = NULL;
    _module_functions[112].body = NULL;
    _module_functions[112].shadow_test = NULL;
    _module_functions[112].is_extern = true;
    _module_functions[112].returns_gc_managed = false;
    _module_functions[112].requires_manual_free = false;
    _module_functions[112].returns_borrowed = false;
    _module_functions[112].cleanup_function = NULL;
    _module_functions[112].params = &_module_params[34];
    _module_params[34].name = "list";
    _module_params[34].type = 15;
    _module_params[34].struct_type_name = "ASTBool";
    _module_params[34].element_type = 21;
    _module_params[34].fn_sig = NULL;

    /* Function: List_ASTIdentifier_new */
    _module_functions[113].name = "List_ASTIdentifier_new";
    _module_functions[113].param_count = 0;
    _module_functions[113].return_type = 15;
    _module_functions[113].return_struct_type_name = "ASTIdentifier";
    _module_functions[113].return_fn_sig = NULL;
    _module_functions[113].return_type_info = NULL;
    _module_functions[113].body = NULL;
    _module_functions[113].shadow_test = NULL;
    _module_functions[113].is_extern = true;
    _module_functions[113].returns_gc_managed = false;
    _module_functions[113].requires_manual_free = false;
    _module_functions[113].returns_borrowed = false;
    _module_functions[113].cleanup_function = NULL;
    _module_functions[113].params = NULL;

    /* Function: List_ASTIdentifier_push */
    _module_functions[114].name = "List_ASTIdentifier_push";
    _module_functions[114].param_count = 2;
    _module_functions[114].return_type = 6;
    _module_functions[114].return_struct_type_name = NULL;
    _module_functions[114].return_fn_sig = NULL;
    _module_functions[114].return_type_info = NULL;
    _module_functions[114].body = NULL;
    _module_functions[114].shadow_test = NULL;
    _module_functions[114].is_extern = true;
    _module_functions[114].returns_gc_managed = false;
    _module_functions[114].requires_manual_free = false;
    _module_functions[114].returns_borrowed = false;
    _module_functions[114].cleanup_function = NULL;
    _module_functions[114].params = &_module_params[35];
    _module_params[35].name = "list";
    _module_params[35].type = 15;
    _module_params[35].struct_type_name = "ASTIdentifier";
    _module_params[35].element_type = 21;
    _module_params[35].fn_sig = NULL;
    _module_params[36].name = "value";
    _module_params[36].type = 8;
    _module_params[36].struct_type_name = "ASTIdentifier";
    _module_params[36].element_type = 21;
    _module_params[36].fn_sig = NULL;

    /* Function: List_ASTIdentifier_get */
    _module_functions[115].name = "List_ASTIdentifier_get";
    _module_functions[115].param_count = 2;
    _module_functions[115].return_type = 8;
    _module_functions[115].return_struct_type_name = "ASTIdentifier";
    _module_functions[115].return_fn_sig = NULL;
    _module_functions[115].return_type_info = NULL;
    _module_functions[115].body = NULL;
    _module_functions[115].shadow_test = NULL;
    _module_functions[115].is_extern = true;
    _module_functions[115].returns_gc_managed = false;
    _module_functions[115].requires_manual_free = false;
    _module_functions[115].returns_borrowed = false;
    _module_functions[115].cleanup_function = NULL;
    _module_functions[115].params = &_module_params[37];
    _module_params[37].name = "list";
    _module_params[37].type = 15;
    _module_params[37].struct_type_name = "ASTIdentifier";
    _module_params[37].element_type = 21;
    _module_params[37].fn_sig = NULL;
    _module_params[38].name = "index";
    _module_params[38].type = 0;
    _module_params[38].struct_type_name = NULL;
    _module_params[38].element_type = 21;
    _module_params[38].fn_sig = NULL;

    /* Function: List_ASTIdentifier_length */
    _module_functions[116].name = "List_ASTIdentifier_length";
    _module_functions[116].param_count = 1;
    _module_functions[116].return_type = 0;
    _module_functions[116].return_struct_type_name = NULL;
    _module_functions[116].return_fn_sig = NULL;
    _module_functions[116].return_type_info = NULL;
    _module_functions[116].body = NULL;
    _module_functions[116].shadow_test = NULL;
    _module_functions[116].is_extern = true;
    _module_functions[116].returns_gc_managed = false;
    _module_functions[116].requires_manual_free = false;
    _module_functions[116].returns_borrowed = false;
    _module_functions[116].cleanup_function = NULL;
    _module_functions[116].params = &_module_params[39];
    _module_params[39].name = "list";
    _module_params[39].type = 15;
    _module_params[39].struct_type_name = "ASTIdentifier";
    _module_params[39].element_type = 21;
    _module_params[39].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_new */
    _module_functions[117].name = "List_ASTBinaryOp_new";
    _module_functions[117].param_count = 0;
    _module_functions[117].return_type = 15;
    _module_functions[117].return_struct_type_name = "ASTBinaryOp";
    _module_functions[117].return_fn_sig = NULL;
    _module_functions[117].return_type_info = NULL;
    _module_functions[117].body = NULL;
    _module_functions[117].shadow_test = NULL;
    _module_functions[117].is_extern = true;
    _module_functions[117].returns_gc_managed = false;
    _module_functions[117].requires_manual_free = false;
    _module_functions[117].returns_borrowed = false;
    _module_functions[117].cleanup_function = NULL;
    _module_functions[117].params = NULL;

    /* Function: List_ASTBinaryOp_push */
    _module_functions[118].name = "List_ASTBinaryOp_push";
    _module_functions[118].param_count = 2;
    _module_functions[118].return_type = 6;
    _module_functions[118].return_struct_type_name = NULL;
    _module_functions[118].return_fn_sig = NULL;
    _module_functions[118].return_type_info = NULL;
    _module_functions[118].body = NULL;
    _module_functions[118].shadow_test = NULL;
    _module_functions[118].is_extern = true;
    _module_functions[118].returns_gc_managed = false;
    _module_functions[118].requires_manual_free = false;
    _module_functions[118].returns_borrowed = false;
    _module_functions[118].cleanup_function = NULL;
    _module_functions[118].params = &_module_params[40];
    _module_params[40].name = "list";
    _module_params[40].type = 15;
    _module_params[40].struct_type_name = "ASTBinaryOp";
    _module_params[40].element_type = 21;
    _module_params[40].fn_sig = NULL;
    _module_params[41].name = "value";
    _module_params[41].type = 8;
    _module_params[41].struct_type_name = "ASTBinaryOp";
    _module_params[41].element_type = 21;
    _module_params[41].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_get */
    _module_functions[119].name = "List_ASTBinaryOp_get";
    _module_functions[119].param_count = 2;
    _module_functions[119].return_type = 8;
    _module_functions[119].return_struct_type_name = "ASTBinaryOp";
    _module_functions[119].return_fn_sig = NULL;
    _module_functions[119].return_type_info = NULL;
    _module_functions[119].body = NULL;
    _module_functions[119].shadow_test = NULL;
    _module_functions[119].is_extern = true;
    _module_functions[119].returns_gc_managed = false;
    _module_functions[119].requires_manual_free = false;
    _module_functions[119].returns_borrowed = false;
    _module_functions[119].cleanup_function = NULL;
    _module_functions[119].params = &_module_params[42];
    _module_params[42].name = "list";
    _module_params[42].type = 15;
    _module_params[42].struct_type_name = "ASTBinaryOp";
    _module_params[42].element_type = 21;
    _module_params[42].fn_sig = NULL;
    _module_params[43].name = "index";
    _module_params[43].type = 0;
    _module_params[43].struct_type_name = NULL;
    _module_params[43].element_type = 21;
    _module_params[43].fn_sig = NULL;

    /* Function: List_ASTBinaryOp_length */
    _module_functions[120].name = "List_ASTBinaryOp_length";
    _module_functions[120].param_count = 1;
    _module_functions[120].return_type = 0;
    _module_functions[120].return_struct_type_name = NULL;
    _module_functions[120].return_fn_sig = NULL;
    _module_functions[120].return_type_info = NULL;
    _module_functions[120].body = NULL;
    _module_functions[120].shadow_test = NULL;
    _module_functions[120].is_extern = true;
    _module_functions[120].returns_gc_managed = false;
    _module_functions[120].requires_manual_free = false;
    _module_functions[120].returns_borrowed = false;
    _module_functions[120].cleanup_function = NULL;
    _module_functions[120].params = &_module_params[44];
    _module_params[44].name = "list";
    _module_params[44].type = 15;
    _module_params[44].struct_type_name = "ASTBinaryOp";
    _module_params[44].element_type = 21;
    _module_params[44].fn_sig = NULL;

    /* Function: List_ASTCall_new */
    _module_functions[121].name = "List_ASTCall_new";
    _module_functions[121].param_count = 0;
    _module_functions[121].return_type = 15;
    _module_functions[121].return_struct_type_name = "ASTCall";
    _module_functions[121].return_fn_sig = NULL;
    _module_functions[121].return_type_info = NULL;
    _module_functions[121].body = NULL;
    _module_functions[121].shadow_test = NULL;
    _module_functions[121].is_extern = true;
    _module_functions[121].returns_gc_managed = false;
    _module_functions[121].requires_manual_free = false;
    _module_functions[121].returns_borrowed = false;
    _module_functions[121].cleanup_function = NULL;
    _module_functions[121].params = NULL;

    /* Function: List_ASTCall_push */
    _module_functions[122].name = "List_ASTCall_push";
    _module_functions[122].param_count = 2;
    _module_functions[122].return_type = 6;
    _module_functions[122].return_struct_type_name = NULL;
    _module_functions[122].return_fn_sig = NULL;
    _module_functions[122].return_type_info = NULL;
    _module_functions[122].body = NULL;
    _module_functions[122].shadow_test = NULL;
    _module_functions[122].is_extern = true;
    _module_functions[122].returns_gc_managed = false;
    _module_functions[122].requires_manual_free = false;
    _module_functions[122].returns_borrowed = false;
    _module_functions[122].cleanup_function = NULL;
    _module_functions[122].params = &_module_params[45];
    _module_params[45].name = "list";
    _module_params[45].type = 15;
    _module_params[45].struct_type_name = "ASTCall";
    _module_params[45].element_type = 21;
    _module_params[45].fn_sig = NULL;
    _module_params[46].name = "value";
    _module_params[46].type = 8;
    _module_params[46].struct_type_name = "ASTCall";
    _module_params[46].element_type = 21;
    _module_params[46].fn_sig = NULL;

    /* Function: List_ASTCall_get */
    _module_functions[123].name = "List_ASTCall_get";
    _module_functions[123].param_count = 2;
    _module_functions[123].return_type = 8;
    _module_functions[123].return_struct_type_name = "ASTCall";
    _module_functions[123].return_fn_sig = NULL;
    _module_functions[123].return_type_info = NULL;
    _module_functions[123].body = NULL;
    _module_functions[123].shadow_test = NULL;
    _module_functions[123].is_extern = true;
    _module_functions[123].returns_gc_managed = false;
    _module_functions[123].requires_manual_free = false;
    _module_functions[123].returns_borrowed = false;
    _module_functions[123].cleanup_function = NULL;
    _module_functions[123].params = &_module_params[47];
    _module_params[47].name = "list";
    _module_params[47].type = 15;
    _module_params[47].struct_type_name = "ASTCall";
    _module_params[47].element_type = 21;
    _module_params[47].fn_sig = NULL;
    _module_params[48].name = "index";
    _module_params[48].type = 0;
    _module_params[48].struct_type_name = NULL;
    _module_params[48].element_type = 21;
    _module_params[48].fn_sig = NULL;

    /* Function: List_ASTCall_length */
    _module_functions[124].name = "List_ASTCall_length";
    _module_functions[124].param_count = 1;
    _module_functions[124].return_type = 0;
    _module_functions[124].return_struct_type_name = NULL;
    _module_functions[124].return_fn_sig = NULL;
    _module_functions[124].return_type_info = NULL;
    _module_functions[124].body = NULL;
    _module_functions[124].shadow_test = NULL;
    _module_functions[124].is_extern = true;
    _module_functions[124].returns_gc_managed = false;
    _module_functions[124].requires_manual_free = false;
    _module_functions[124].returns_borrowed = false;
    _module_functions[124].cleanup_function = NULL;
    _module_functions[124].params = &_module_params[49];
    _module_params[49].name = "list";
    _module_params[49].type = 15;
    _module_params[49].struct_type_name = "ASTCall";
    _module_params[49].element_type = 21;
    _module_params[49].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_new */
    _module_functions[125].name = "List_ASTModuleQualifiedCall_new";
    _module_functions[125].param_count = 0;
    _module_functions[125].return_type = 15;
    _module_functions[125].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[125].return_fn_sig = NULL;
    _module_functions[125].return_type_info = NULL;
    _module_functions[125].body = NULL;
    _module_functions[125].shadow_test = NULL;
    _module_functions[125].is_extern = true;
    _module_functions[125].returns_gc_managed = false;
    _module_functions[125].requires_manual_free = false;
    _module_functions[125].returns_borrowed = false;
    _module_functions[125].cleanup_function = NULL;
    _module_functions[125].params = NULL;

    /* Function: List_ASTModuleQualifiedCall_push */
    _module_functions[126].name = "List_ASTModuleQualifiedCall_push";
    _module_functions[126].param_count = 2;
    _module_functions[126].return_type = 6;
    _module_functions[126].return_struct_type_name = NULL;
    _module_functions[126].return_fn_sig = NULL;
    _module_functions[126].return_type_info = NULL;
    _module_functions[126].body = NULL;
    _module_functions[126].shadow_test = NULL;
    _module_functions[126].is_extern = true;
    _module_functions[126].returns_gc_managed = false;
    _module_functions[126].requires_manual_free = false;
    _module_functions[126].returns_borrowed = false;
    _module_functions[126].cleanup_function = NULL;
    _module_functions[126].params = &_module_params[50];
    _module_params[50].name = "list";
    _module_params[50].type = 15;
    _module_params[50].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[50].element_type = 21;
    _module_params[50].fn_sig = NULL;
    _module_params[51].name = "value";
    _module_params[51].type = 8;
    _module_params[51].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[51].element_type = 21;
    _module_params[51].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_get */
    _module_functions[127].name = "List_ASTModuleQualifiedCall_get";
    _module_functions[127].param_count = 2;
    _module_functions[127].return_type = 8;
    _module_functions[127].return_struct_type_name = "ASTModuleQualifiedCall";
    _module_functions[127].return_fn_sig = NULL;
    _module_functions[127].return_type_info = NULL;
    _module_functions[127].body = NULL;
    _module_functions[127].shadow_test = NULL;
    _module_functions[127].is_extern = true;
    _module_functions[127].returns_gc_managed = false;
    _module_functions[127].requires_manual_free = false;
    _module_functions[127].returns_borrowed = false;
    _module_functions[127].cleanup_function = NULL;
    _module_functions[127].params = &_module_params[52];
    _module_params[52].name = "list";
    _module_params[52].type = 15;
    _module_params[52].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[52].element_type = 21;
    _module_params[52].fn_sig = NULL;
    _module_params[53].name = "index";
    _module_params[53].type = 0;
    _module_params[53].struct_type_name = NULL;
    _module_params[53].element_type = 21;
    _module_params[53].fn_sig = NULL;

    /* Function: List_ASTModuleQualifiedCall_length */
    _module_functions[128].name = "List_ASTModuleQualifiedCall_length";
    _module_functions[128].param_count = 1;
    _module_functions[128].return_type = 0;
    _module_functions[128].return_struct_type_name = NULL;
    _module_functions[128].return_fn_sig = NULL;
    _module_functions[128].return_type_info = NULL;
    _module_functions[128].body = NULL;
    _module_functions[128].shadow_test = NULL;
    _module_functions[128].is_extern = true;
    _module_functions[128].returns_gc_managed = false;
    _module_functions[128].requires_manual_free = false;
    _module_functions[128].returns_borrowed = false;
    _module_functions[128].cleanup_function = NULL;
    _module_functions[128].params = &_module_params[54];
    _module_params[54].name = "list";
    _module_params[54].type = 15;
    _module_params[54].struct_type_name = "ASTModuleQualifiedCall";
    _module_params[54].element_type = 21;
    _module_params[54].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_new */
    _module_functions[129].name = "List_ASTArrayLiteral_new";
    _module_functions[129].param_count = 0;
    _module_functions[129].return_type = 15;
    _module_functions[129].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[129].return_fn_sig = NULL;
    _module_functions[129].return_type_info = NULL;
    _module_functions[129].body = NULL;
    _module_functions[129].shadow_test = NULL;
    _module_functions[129].is_extern = true;
    _module_functions[129].returns_gc_managed = false;
    _module_functions[129].requires_manual_free = false;
    _module_functions[129].returns_borrowed = false;
    _module_functions[129].cleanup_function = NULL;
    _module_functions[129].params = NULL;

    /* Function: List_ASTArrayLiteral_push */
    _module_functions[130].name = "List_ASTArrayLiteral_push";
    _module_functions[130].param_count = 2;
    _module_functions[130].return_type = 6;
    _module_functions[130].return_struct_type_name = NULL;
    _module_functions[130].return_fn_sig = NULL;
    _module_functions[130].return_type_info = NULL;
    _module_functions[130].body = NULL;
    _module_functions[130].shadow_test = NULL;
    _module_functions[130].is_extern = true;
    _module_functions[130].returns_gc_managed = false;
    _module_functions[130].requires_manual_free = false;
    _module_functions[130].returns_borrowed = false;
    _module_functions[130].cleanup_function = NULL;
    _module_functions[130].params = &_module_params[55];
    _module_params[55].name = "list";
    _module_params[55].type = 15;
    _module_params[55].struct_type_name = "ASTArrayLiteral";
    _module_params[55].element_type = 21;
    _module_params[55].fn_sig = NULL;
    _module_params[56].name = "value";
    _module_params[56].type = 8;
    _module_params[56].struct_type_name = "ASTArrayLiteral";
    _module_params[56].element_type = 21;
    _module_params[56].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_get */
    _module_functions[131].name = "List_ASTArrayLiteral_get";
    _module_functions[131].param_count = 2;
    _module_functions[131].return_type = 8;
    _module_functions[131].return_struct_type_name = "ASTArrayLiteral";
    _module_functions[131].return_fn_sig = NULL;
    _module_functions[131].return_type_info = NULL;
    _module_functions[131].body = NULL;
    _module_functions[131].shadow_test = NULL;
    _module_functions[131].is_extern = true;
    _module_functions[131].returns_gc_managed = false;
    _module_functions[131].requires_manual_free = false;
    _module_functions[131].returns_borrowed = false;
    _module_functions[131].cleanup_function = NULL;
    _module_functions[131].params = &_module_params[57];
    _module_params[57].name = "list";
    _module_params[57].type = 15;
    _module_params[57].struct_type_name = "ASTArrayLiteral";
    _module_params[57].element_type = 21;
    _module_params[57].fn_sig = NULL;
    _module_params[58].name = "index";
    _module_params[58].type = 0;
    _module_params[58].struct_type_name = NULL;
    _module_params[58].element_type = 21;
    _module_params[58].fn_sig = NULL;

    /* Function: List_ASTArrayLiteral_length */
    _module_functions[132].name = "List_ASTArrayLiteral_length";
    _module_functions[132].param_count = 1;
    _module_functions[132].return_type = 0;
    _module_functions[132].return_struct_type_name = NULL;
    _module_functions[132].return_fn_sig = NULL;
    _module_functions[132].return_type_info = NULL;
    _module_functions[132].body = NULL;
    _module_functions[132].shadow_test = NULL;
    _module_functions[132].is_extern = true;
    _module_functions[132].returns_gc_managed = false;
    _module_functions[132].requires_manual_free = false;
    _module_functions[132].returns_borrowed = false;
    _module_functions[132].cleanup_function = NULL;
    _module_functions[132].params = &_module_params[59];
    _module_params[59].name = "list";
    _module_params[59].type = 15;
    _module_params[59].struct_type_name = "ASTArrayLiteral";
    _module_params[59].element_type = 21;
    _module_params[59].fn_sig = NULL;

    /* Function: List_ASTLet_new */
    _module_functions[133].name = "List_ASTLet_new";
    _module_functions[133].param_count = 0;
    _module_functions[133].return_type = 15;
    _module_functions[133].return_struct_type_name = "ASTLet";
    _module_functions[133].return_fn_sig = NULL;
    _module_functions[133].return_type_info = NULL;
    _module_functions[133].body = NULL;
    _module_functions[133].shadow_test = NULL;
    _module_functions[133].is_extern = true;
    _module_functions[133].returns_gc_managed = false;
    _module_functions[133].requires_manual_free = false;
    _module_functions[133].returns_borrowed = false;
    _module_functions[133].cleanup_function = NULL;
    _module_functions[133].params = NULL;

    /* Function: List_ASTLet_push */
    _module_functions[134].name = "List_ASTLet_push";
    _module_functions[134].param_count = 2;
    _module_functions[134].return_type = 6;
    _module_functions[134].return_struct_type_name = NULL;
    _module_functions[134].return_fn_sig = NULL;
    _module_functions[134].return_type_info = NULL;
    _module_functions[134].body = NULL;
    _module_functions[134].shadow_test = NULL;
    _module_functions[134].is_extern = true;
    _module_functions[134].returns_gc_managed = false;
    _module_functions[134].requires_manual_free = false;
    _module_functions[134].returns_borrowed = false;
    _module_functions[134].cleanup_function = NULL;
    _module_functions[134].params = &_module_params[60];
    _module_params[60].name = "list";
    _module_params[60].type = 15;
    _module_params[60].struct_type_name = "ASTLet";
    _module_params[60].element_type = 21;
    _module_params[60].fn_sig = NULL;
    _module_params[61].name = "value";
    _module_params[61].type = 8;
    _module_params[61].struct_type_name = "ASTLet";
    _module_params[61].element_type = 21;
    _module_params[61].fn_sig = NULL;

    /* Function: List_ASTLet_get */
    _module_functions[135].name = "List_ASTLet_get";
    _module_functions[135].param_count = 2;
    _module_functions[135].return_type = 8;
    _module_functions[135].return_struct_type_name = "ASTLet";
    _module_functions[135].return_fn_sig = NULL;
    _module_functions[135].return_type_info = NULL;
    _module_functions[135].body = NULL;
    _module_functions[135].shadow_test = NULL;
    _module_functions[135].is_extern = true;
    _module_functions[135].returns_gc_managed = false;
    _module_functions[135].requires_manual_free = false;
    _module_functions[135].returns_borrowed = false;
    _module_functions[135].cleanup_function = NULL;
    _module_functions[135].params = &_module_params[62];
    _module_params[62].name = "list";
    _module_params[62].type = 15;
    _module_params[62].struct_type_name = "ASTLet";
    _module_params[62].element_type = 21;
    _module_params[62].fn_sig = NULL;
    _module_params[63].name = "index";
    _module_params[63].type = 0;
    _module_params[63].struct_type_name = NULL;
    _module_params[63].element_type = 21;
    _module_params[63].fn_sig = NULL;

    /* Function: List_ASTLet_length */
    _module_functions[136].name = "List_ASTLet_length";
    _module_functions[136].param_count = 1;
    _module_functions[136].return_type = 0;
    _module_functions[136].return_struct_type_name = NULL;
    _module_functions[136].return_fn_sig = NULL;
    _module_functions[136].return_type_info = NULL;
    _module_functions[136].body = NULL;
    _module_functions[136].shadow_test = NULL;
    _module_functions[136].is_extern = true;
    _module_functions[136].returns_gc_managed = false;
    _module_functions[136].requires_manual_free = false;
    _module_functions[136].returns_borrowed = false;
    _module_functions[136].cleanup_function = NULL;
    _module_functions[136].params = &_module_params[64];
    _module_params[64].name = "list";
    _module_params[64].type = 15;
    _module_params[64].struct_type_name = "ASTLet";
    _module_params[64].element_type = 21;
    _module_params[64].fn_sig = NULL;

    /* Function: List_ASTSet_new */
    _module_functions[137].name = "List_ASTSet_new";
    _module_functions[137].param_count = 0;
    _module_functions[137].return_type = 15;
    _module_functions[137].return_struct_type_name = "ASTSet";
    _module_functions[137].return_fn_sig = NULL;
    _module_functions[137].return_type_info = NULL;
    _module_functions[137].body = NULL;
    _module_functions[137].shadow_test = NULL;
    _module_functions[137].is_extern = true;
    _module_functions[137].returns_gc_managed = false;
    _module_functions[137].requires_manual_free = false;
    _module_functions[137].returns_borrowed = false;
    _module_functions[137].cleanup_function = NULL;
    _module_functions[137].params = NULL;

    /* Function: List_ASTSet_push */
    _module_functions[138].name = "List_ASTSet_push";
    _module_functions[138].param_count = 2;
    _module_functions[138].return_type = 6;
    _module_functions[138].return_struct_type_name = NULL;
    _module_functions[138].return_fn_sig = NULL;
    _module_functions[138].return_type_info = NULL;
    _module_functions[138].body = NULL;
    _module_functions[138].shadow_test = NULL;
    _module_functions[138].is_extern = true;
    _module_functions[138].returns_gc_managed = false;
    _module_functions[138].requires_manual_free = false;
    _module_functions[138].returns_borrowed = false;
    _module_functions[138].cleanup_function = NULL;
    _module_functions[138].params = &_module_params[65];
    _module_params[65].name = "list";
    _module_params[65].type = 15;
    _module_params[65].struct_type_name = "ASTSet";
    _module_params[65].element_type = 21;
    _module_params[65].fn_sig = NULL;
    _module_params[66].name = "value";
    _module_params[66].type = 8;
    _module_params[66].struct_type_name = "ASTSet";
    _module_params[66].element_type = 21;
    _module_params[66].fn_sig = NULL;

    /* Function: List_ASTSet_get */
    _module_functions[139].name = "List_ASTSet_get";
    _module_functions[139].param_count = 2;
    _module_functions[139].return_type = 8;
    _module_functions[139].return_struct_type_name = "ASTSet";
    _module_functions[139].return_fn_sig = NULL;
    _module_functions[139].return_type_info = NULL;
    _module_functions[139].body = NULL;
    _module_functions[139].shadow_test = NULL;
    _module_functions[139].is_extern = true;
    _module_functions[139].returns_gc_managed = false;
    _module_functions[139].requires_manual_free = false;
    _module_functions[139].returns_borrowed = false;
    _module_functions[139].cleanup_function = NULL;
    _module_functions[139].params = &_module_params[67];
    _module_params[67].name = "list";
    _module_params[67].type = 15;
    _module_params[67].struct_type_name = "ASTSet";
    _module_params[67].element_type = 21;
    _module_params[67].fn_sig = NULL;
    _module_params[68].name = "index";
    _module_params[68].type = 0;
    _module_params[68].struct_type_name = NULL;
    _module_params[68].element_type = 21;
    _module_params[68].fn_sig = NULL;

    /* Function: List_ASTSet_length */
    _module_functions[140].name = "List_ASTSet_length";
    _module_functions[140].param_count = 1;
    _module_functions[140].return_type = 0;
    _module_functions[140].return_struct_type_name = NULL;
    _module_functions[140].return_fn_sig = NULL;
    _module_functions[140].return_type_info = NULL;
    _module_functions[140].body = NULL;
    _module_functions[140].shadow_test = NULL;
    _module_functions[140].is_extern = true;
    _module_functions[140].returns_gc_managed = false;
    _module_functions[140].requires_manual_free = false;
    _module_functions[140].returns_borrowed = false;
    _module_functions[140].cleanup_function = NULL;
    _module_functions[140].params = &_module_params[69];
    _module_params[69].name = "list";
    _module_params[69].type = 15;
    _module_params[69].struct_type_name = "ASTSet";
    _module_params[69].element_type = 21;
    _module_params[69].fn_sig = NULL;

    /* Function: List_ASTIf_new */
    _module_functions[141].name = "List_ASTIf_new";
    _module_functions[141].param_count = 0;
    _module_functions[141].return_type = 15;
    _module_functions[141].return_struct_type_name = "ASTIf";
    _module_functions[141].return_fn_sig = NULL;
    _module_functions[141].return_type_info = NULL;
    _module_functions[141].body = NULL;
    _module_functions[141].shadow_test = NULL;
    _module_functions[141].is_extern = true;
    _module_functions[141].returns_gc_managed = false;
    _module_functions[141].requires_manual_free = false;
    _module_functions[141].returns_borrowed = false;
    _module_functions[141].cleanup_function = NULL;
    _module_functions[141].params = NULL;

    /* Function: List_ASTIf_push */
    _module_functions[142].name = "List_ASTIf_push";
    _module_functions[142].param_count = 2;
    _module_functions[142].return_type = 6;
    _module_functions[142].return_struct_type_name = NULL;
    _module_functions[142].return_fn_sig = NULL;
    _module_functions[142].return_type_info = NULL;
    _module_functions[142].body = NULL;
    _module_functions[142].shadow_test = NULL;
    _module_functions[142].is_extern = true;
    _module_functions[142].returns_gc_managed = false;
    _module_functions[142].requires_manual_free = false;
    _module_functions[142].returns_borrowed = false;
    _module_functions[142].cleanup_function = NULL;
    _module_functions[142].params = &_module_params[70];
    _module_params[70].name = "list";
    _module_params[70].type = 15;
    _module_params[70].struct_type_name = "ASTIf";
    _module_params[70].element_type = 21;
    _module_params[70].fn_sig = NULL;
    _module_params[71].name = "value";
    _module_params[71].type = 8;
    _module_params[71].struct_type_name = "ASTIf";
    _module_params[71].element_type = 21;
    _module_params[71].fn_sig = NULL;

    /* Function: List_ASTIf_get */
    _module_functions[143].name = "List_ASTIf_get";
    _module_functions[143].param_count = 2;
    _module_functions[143].return_type = 8;
    _module_functions[143].return_struct_type_name = "ASTIf";
    _module_functions[143].return_fn_sig = NULL;
    _module_functions[143].return_type_info = NULL;
    _module_functions[143].body = NULL;
    _module_functions[143].shadow_test = NULL;
    _module_functions[143].is_extern = true;
    _module_functions[143].returns_gc_managed = false;
    _module_functions[143].requires_manual_free = false;
    _module_functions[143].returns_borrowed = false;
    _module_functions[143].cleanup_function = NULL;
    _module_functions[143].params = &_module_params[72];
    _module_params[72].name = "list";
    _module_params[72].type = 15;
    _module_params[72].struct_type_name = "ASTIf";
    _module_params[72].element_type = 21;
    _module_params[72].fn_sig = NULL;
    _module_params[73].name = "index";
    _module_params[73].type = 0;
    _module_params[73].struct_type_name = NULL;
    _module_params[73].element_type = 21;
    _module_params[73].fn_sig = NULL;

    /* Function: List_ASTIf_length */
    _module_functions[144].name = "List_ASTIf_length";
    _module_functions[144].param_count = 1;
    _module_functions[144].return_type = 0;
    _module_functions[144].return_struct_type_name = NULL;
    _module_functions[144].return_fn_sig = NULL;
    _module_functions[144].return_type_info = NULL;
    _module_functions[144].body = NULL;
    _module_functions[144].shadow_test = NULL;
    _module_functions[144].is_extern = true;
    _module_functions[144].returns_gc_managed = false;
    _module_functions[144].requires_manual_free = false;
    _module_functions[144].returns_borrowed = false;
    _module_functions[144].cleanup_function = NULL;
    _module_functions[144].params = &_module_params[74];
    _module_params[74].name = "list";
    _module_params[74].type = 15;
    _module_params[74].struct_type_name = "ASTIf";
    _module_params[74].element_type = 21;
    _module_params[74].fn_sig = NULL;

    /* Function: List_ASTWhile_new */
    _module_functions[145].name = "List_ASTWhile_new";
    _module_functions[145].param_count = 0;
    _module_functions[145].return_type = 15;
    _module_functions[145].return_struct_type_name = "ASTWhile";
    _module_functions[145].return_fn_sig = NULL;
    _module_functions[145].return_type_info = NULL;
    _module_functions[145].body = NULL;
    _module_functions[145].shadow_test = NULL;
    _module_functions[145].is_extern = true;
    _module_functions[145].returns_gc_managed = false;
    _module_functions[145].requires_manual_free = false;
    _module_functions[145].returns_borrowed = false;
    _module_functions[145].cleanup_function = NULL;
    _module_functions[145].params = NULL;

    /* Function: List_ASTWhile_push */
    _module_functions[146].name = "List_ASTWhile_push";
    _module_functions[146].param_count = 2;
    _module_functions[146].return_type = 6;
    _module_functions[146].return_struct_type_name = NULL;
    _module_functions[146].return_fn_sig = NULL;
    _module_functions[146].return_type_info = NULL;
    _module_functions[146].body = NULL;
    _module_functions[146].shadow_test = NULL;
    _module_functions[146].is_extern = true;
    _module_functions[146].returns_gc_managed = false;
    _module_functions[146].requires_manual_free = false;
    _module_functions[146].returns_borrowed = false;
    _module_functions[146].cleanup_function = NULL;
    _module_functions[146].params = &_module_params[75];
    _module_params[75].name = "list";
    _module_params[75].type = 15;
    _module_params[75].struct_type_name = "ASTWhile";
    _module_params[75].element_type = 21;
    _module_params[75].fn_sig = NULL;
    _module_params[76].name = "value";
    _module_params[76].type = 8;
    _module_params[76].struct_type_name = "ASTWhile";
    _module_params[76].element_type = 21;
    _module_params[76].fn_sig = NULL;

    /* Function: List_ASTWhile_get */
    _module_functions[147].name = "List_ASTWhile_get";
    _module_functions[147].param_count = 2;
    _module_functions[147].return_type = 8;
    _module_functions[147].return_struct_type_name = "ASTWhile";
    _module_functions[147].return_fn_sig = NULL;
    _module_functions[147].return_type_info = NULL;
    _module_functions[147].body = NULL;
    _module_functions[147].shadow_test = NULL;
    _module_functions[147].is_extern = true;
    _module_functions[147].returns_gc_managed = false;
    _module_functions[147].requires_manual_free = false;
    _module_functions[147].returns_borrowed = false;
    _module_functions[147].cleanup_function = NULL;
    _module_functions[147].params = &_module_params[77];
    _module_params[77].name = "list";
    _module_params[77].type = 15;
    _module_params[77].struct_type_name = "ASTWhile";
    _module_params[77].element_type = 21;
    _module_params[77].fn_sig = NULL;
    _module_params[78].name = "index";
    _module_params[78].type = 0;
    _module_params[78].struct_type_name = NULL;
    _module_params[78].element_type = 21;
    _module_params[78].fn_sig = NULL;

    /* Function: List_ASTWhile_length */
    _module_functions[148].name = "List_ASTWhile_length";
    _module_functions[148].param_count = 1;
    _module_functions[148].return_type = 0;
    _module_functions[148].return_struct_type_name = NULL;
    _module_functions[148].return_fn_sig = NULL;
    _module_functions[148].return_type_info = NULL;
    _module_functions[148].body = NULL;
    _module_functions[148].shadow_test = NULL;
    _module_functions[148].is_extern = true;
    _module_functions[148].returns_gc_managed = false;
    _module_functions[148].requires_manual_free = false;
    _module_functions[148].returns_borrowed = false;
    _module_functions[148].cleanup_function = NULL;
    _module_functions[148].params = &_module_params[79];
    _module_params[79].name = "list";
    _module_params[79].type = 15;
    _module_params[79].struct_type_name = "ASTWhile";
    _module_params[79].element_type = 21;
    _module_params[79].fn_sig = NULL;

    /* Function: List_ASTFor_new */
    _module_functions[149].name = "List_ASTFor_new";
    _module_functions[149].param_count = 0;
    _module_functions[149].return_type = 15;
    _module_functions[149].return_struct_type_name = "ASTFor";
    _module_functions[149].return_fn_sig = NULL;
    _module_functions[149].return_type_info = NULL;
    _module_functions[149].body = NULL;
    _module_functions[149].shadow_test = NULL;
    _module_functions[149].is_extern = true;
    _module_functions[149].returns_gc_managed = false;
    _module_functions[149].requires_manual_free = false;
    _module_functions[149].returns_borrowed = false;
    _module_functions[149].cleanup_function = NULL;
    _module_functions[149].params = NULL;

    /* Function: List_ASTFor_push */
    _module_functions[150].name = "List_ASTFor_push";
    _module_functions[150].param_count = 2;
    _module_functions[150].return_type = 6;
    _module_functions[150].return_struct_type_name = NULL;
    _module_functions[150].return_fn_sig = NULL;
    _module_functions[150].return_type_info = NULL;
    _module_functions[150].body = NULL;
    _module_functions[150].shadow_test = NULL;
    _module_functions[150].is_extern = true;
    _module_functions[150].returns_gc_managed = false;
    _module_functions[150].requires_manual_free = false;
    _module_functions[150].returns_borrowed = false;
    _module_functions[150].cleanup_function = NULL;
    _module_functions[150].params = &_module_params[80];
    _module_params[80].name = "list";
    _module_params[80].type = 15;
    _module_params[80].struct_type_name = "ASTFor";
    _module_params[80].element_type = 21;
    _module_params[80].fn_sig = NULL;
    _module_params[81].name = "value";
    _module_params[81].type = 8;
    _module_params[81].struct_type_name = "ASTFor";
    _module_params[81].element_type = 21;
    _module_params[81].fn_sig = NULL;

    /* Function: List_ASTFor_get */
    _module_functions[151].name = "List_ASTFor_get";
    _module_functions[151].param_count = 2;
    _module_functions[151].return_type = 8;
    _module_functions[151].return_struct_type_name = "ASTFor";
    _module_functions[151].return_fn_sig = NULL;
    _module_functions[151].return_type_info = NULL;
    _module_functions[151].body = NULL;
    _module_functions[151].shadow_test = NULL;
    _module_functions[151].is_extern = true;
    _module_functions[151].returns_gc_managed = false;
    _module_functions[151].requires_manual_free = false;
    _module_functions[151].returns_borrowed = false;
    _module_functions[151].cleanup_function = NULL;
    _module_functions[151].params = &_module_params[82];
    _module_params[82].name = "list";
    _module_params[82].type = 15;
    _module_params[82].struct_type_name = "ASTFor";
    _module_params[82].element_type = 21;
    _module_params[82].fn_sig = NULL;
    _module_params[83].name = "index";
    _module_params[83].type = 0;
    _module_params[83].struct_type_name = NULL;
    _module_params[83].element_type = 21;
    _module_params[83].fn_sig = NULL;

    /* Function: List_ASTFor_length */
    _module_functions[152].name = "List_ASTFor_length";
    _module_functions[152].param_count = 1;
    _module_functions[152].return_type = 0;
    _module_functions[152].return_struct_type_name = NULL;
    _module_functions[152].return_fn_sig = NULL;
    _module_functions[152].return_type_info = NULL;
    _module_functions[152].body = NULL;
    _module_functions[152].shadow_test = NULL;
    _module_functions[152].is_extern = true;
    _module_functions[152].returns_gc_managed = false;
    _module_functions[152].requires_manual_free = false;
    _module_functions[152].returns_borrowed = false;
    _module_functions[152].cleanup_function = NULL;
    _module_functions[152].params = &_module_params[84];
    _module_params[84].name = "list";
    _module_params[84].type = 15;
    _module_params[84].struct_type_name = "ASTFor";
    _module_params[84].element_type = 21;
    _module_params[84].fn_sig = NULL;

    /* Function: List_ASTReturn_new */
    _module_functions[153].name = "List_ASTReturn_new";
    _module_functions[153].param_count = 0;
    _module_functions[153].return_type = 15;
    _module_functions[153].return_struct_type_name = "ASTReturn";
    _module_functions[153].return_fn_sig = NULL;
    _module_functions[153].return_type_info = NULL;
    _module_functions[153].body = NULL;
    _module_functions[153].shadow_test = NULL;
    _module_functions[153].is_extern = true;
    _module_functions[153].returns_gc_managed = false;
    _module_functions[153].requires_manual_free = false;
    _module_functions[153].returns_borrowed = false;
    _module_functions[153].cleanup_function = NULL;
    _module_functions[153].params = NULL;

    /* Function: List_ASTReturn_push */
    _module_functions[154].name = "List_ASTReturn_push";
    _module_functions[154].param_count = 2;
    _module_functions[154].return_type = 6;
    _module_functions[154].return_struct_type_name = NULL;
    _module_functions[154].return_fn_sig = NULL;
    _module_functions[154].return_type_info = NULL;
    _module_functions[154].body = NULL;
    _module_functions[154].shadow_test = NULL;
    _module_functions[154].is_extern = true;
    _module_functions[154].returns_gc_managed = false;
    _module_functions[154].requires_manual_free = false;
    _module_functions[154].returns_borrowed = false;
    _module_functions[154].cleanup_function = NULL;
    _module_functions[154].params = &_module_params[85];
    _module_params[85].name = "list";
    _module_params[85].type = 15;
    _module_params[85].struct_type_name = "ASTReturn";
    _module_params[85].element_type = 21;
    _module_params[85].fn_sig = NULL;
    _module_params[86].name = "value";
    _module_params[86].type = 8;
    _module_params[86].struct_type_name = "ASTReturn";
    _module_params[86].element_type = 21;
    _module_params[86].fn_sig = NULL;

    /* Function: List_ASTReturn_get */
    _module_functions[155].name = "List_ASTReturn_get";
    _module_functions[155].param_count = 2;
    _module_functions[155].return_type = 8;
    _module_functions[155].return_struct_type_name = "ASTReturn";
    _module_functions[155].return_fn_sig = NULL;
    _module_functions[155].return_type_info = NULL;
    _module_functions[155].body = NULL;
    _module_functions[155].shadow_test = NULL;
    _module_functions[155].is_extern = true;
    _module_functions[155].returns_gc_managed = false;
    _module_functions[155].requires_manual_free = false;
    _module_functions[155].returns_borrowed = false;
    _module_functions[155].cleanup_function = NULL;
    _module_functions[155].params = &_module_params[87];
    _module_params[87].name = "list";
    _module_params[87].type = 15;
    _module_params[87].struct_type_name = "ASTReturn";
    _module_params[87].element_type = 21;
    _module_params[87].fn_sig = NULL;
    _module_params[88].name = "index";
    _module_params[88].type = 0;
    _module_params[88].struct_type_name = NULL;
    _module_params[88].element_type = 21;
    _module_params[88].fn_sig = NULL;

    /* Function: List_ASTReturn_length */
    _module_functions[156].name = "List_ASTReturn_length";
    _module_functions[156].param_count = 1;
    _module_functions[156].return_type = 0;
    _module_functions[156].return_struct_type_name = NULL;
    _module_functions[156].return_fn_sig = NULL;
    _module_functions[156].return_type_info = NULL;
    _module_functions[156].body = NULL;
    _module_functions[156].shadow_test = NULL;
    _module_functions[156].is_extern = true;
    _module_functions[156].returns_gc_managed = false;
    _module_functions[156].requires_manual_free = false;
    _module_functions[156].returns_borrowed = false;
    _module_functions[156].cleanup_function = NULL;
    _module_functions[156].params = &_module_params[89];
    _module_params[89].name = "list";
    _module_params[89].type = 15;
    _module_params[89].struct_type_name = "ASTReturn";
    _module_params[89].element_type = 21;
    _module_params[89].fn_sig = NULL;

    /* Function: List_ASTBlock_new */
    _module_functions[157].name = "List_ASTBlock_new";
    _module_functions[157].param_count = 0;
    _module_functions[157].return_type = 15;
    _module_functions[157].return_struct_type_name = "ASTBlock";
    _module_functions[157].return_fn_sig = NULL;
    _module_functions[157].return_type_info = NULL;
    _module_functions[157].body = NULL;
    _module_functions[157].shadow_test = NULL;
    _module_functions[157].is_extern = true;
    _module_functions[157].returns_gc_managed = false;
    _module_functions[157].requires_manual_free = false;
    _module_functions[157].returns_borrowed = false;
    _module_functions[157].cleanup_function = NULL;
    _module_functions[157].params = NULL;

    /* Function: List_ASTBlock_push */
    _module_functions[158].name = "List_ASTBlock_push";
    _module_functions[158].param_count = 2;
    _module_functions[158].return_type = 6;
    _module_functions[158].return_struct_type_name = NULL;
    _module_functions[158].return_fn_sig = NULL;
    _module_functions[158].return_type_info = NULL;
    _module_functions[158].body = NULL;
    _module_functions[158].shadow_test = NULL;
    _module_functions[158].is_extern = true;
    _module_functions[158].returns_gc_managed = false;
    _module_functions[158].requires_manual_free = false;
    _module_functions[158].returns_borrowed = false;
    _module_functions[158].cleanup_function = NULL;
    _module_functions[158].params = &_module_params[90];
    _module_params[90].name = "list";
    _module_params[90].type = 15;
    _module_params[90].struct_type_name = "ASTBlock";
    _module_params[90].element_type = 21;
    _module_params[90].fn_sig = NULL;
    _module_params[91].name = "value";
    _module_params[91].type = 8;
    _module_params[91].struct_type_name = "ASTBlock";
    _module_params[91].element_type = 21;
    _module_params[91].fn_sig = NULL;

    /* Function: List_ASTBlock_get */
    _module_functions[159].name = "List_ASTBlock_get";
    _module_functions[159].param_count = 2;
    _module_functions[159].return_type = 8;
    _module_functions[159].return_struct_type_name = "ASTBlock";
    _module_functions[159].return_fn_sig = NULL;
    _module_functions[159].return_type_info = NULL;
    _module_functions[159].body = NULL;
    _module_functions[159].shadow_test = NULL;
    _module_functions[159].is_extern = true;
    _module_functions[159].returns_gc_managed = false;
    _module_functions[159].requires_manual_free = false;
    _module_functions[159].returns_borrowed = false;
    _module_functions[159].cleanup_function = NULL;
    _module_functions[159].params = &_module_params[92];
    _module_params[92].name = "list";
    _module_params[92].type = 15;
    _module_params[92].struct_type_name = "ASTBlock";
    _module_params[92].element_type = 21;
    _module_params[92].fn_sig = NULL;
    _module_params[93].name = "index";
    _module_params[93].type = 0;
    _module_params[93].struct_type_name = NULL;
    _module_params[93].element_type = 21;
    _module_params[93].fn_sig = NULL;

    /* Function: List_ASTBlock_length */
    _module_functions[160].name = "List_ASTBlock_length";
    _module_functions[160].param_count = 1;
    _module_functions[160].return_type = 0;
    _module_functions[160].return_struct_type_name = NULL;
    _module_functions[160].return_fn_sig = NULL;
    _module_functions[160].return_type_info = NULL;
    _module_functions[160].body = NULL;
    _module_functions[160].shadow_test = NULL;
    _module_functions[160].is_extern = true;
    _module_functions[160].returns_gc_managed = false;
    _module_functions[160].requires_manual_free = false;
    _module_functions[160].returns_borrowed = false;
    _module_functions[160].cleanup_function = NULL;
    _module_functions[160].params = &_module_params[94];
    _module_params[94].name = "list";
    _module_params[94].type = 15;
    _module_params[94].struct_type_name = "ASTBlock";
    _module_params[94].element_type = 21;
    _module_params[94].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_new */
    _module_functions[161].name = "List_ASTUnsafeBlock_new";
    _module_functions[161].param_count = 0;
    _module_functions[161].return_type = 15;
    _module_functions[161].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[161].return_fn_sig = NULL;
    _module_functions[161].return_type_info = NULL;
    _module_functions[161].body = NULL;
    _module_functions[161].shadow_test = NULL;
    _module_functions[161].is_extern = true;
    _module_functions[161].returns_gc_managed = false;
    _module_functions[161].requires_manual_free = false;
    _module_functions[161].returns_borrowed = false;
    _module_functions[161].cleanup_function = NULL;
    _module_functions[161].params = NULL;

    /* Function: List_ASTUnsafeBlock_push */
    _module_functions[162].name = "List_ASTUnsafeBlock_push";
    _module_functions[162].param_count = 2;
    _module_functions[162].return_type = 6;
    _module_functions[162].return_struct_type_name = NULL;
    _module_functions[162].return_fn_sig = NULL;
    _module_functions[162].return_type_info = NULL;
    _module_functions[162].body = NULL;
    _module_functions[162].shadow_test = NULL;
    _module_functions[162].is_extern = true;
    _module_functions[162].returns_gc_managed = false;
    _module_functions[162].requires_manual_free = false;
    _module_functions[162].returns_borrowed = false;
    _module_functions[162].cleanup_function = NULL;
    _module_functions[162].params = &_module_params[95];
    _module_params[95].name = "list";
    _module_params[95].type = 15;
    _module_params[95].struct_type_name = "ASTUnsafeBlock";
    _module_params[95].element_type = 21;
    _module_params[95].fn_sig = NULL;
    _module_params[96].name = "value";
    _module_params[96].type = 8;
    _module_params[96].struct_type_name = "ASTUnsafeBlock";
    _module_params[96].element_type = 21;
    _module_params[96].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_get */
    _module_functions[163].name = "List_ASTUnsafeBlock_get";
    _module_functions[163].param_count = 2;
    _module_functions[163].return_type = 8;
    _module_functions[163].return_struct_type_name = "ASTUnsafeBlock";
    _module_functions[163].return_fn_sig = NULL;
    _module_functions[163].return_type_info = NULL;
    _module_functions[163].body = NULL;
    _module_functions[163].shadow_test = NULL;
    _module_functions[163].is_extern = true;
    _module_functions[163].returns_gc_managed = false;
    _module_functions[163].requires_manual_free = false;
    _module_functions[163].returns_borrowed = false;
    _module_functions[163].cleanup_function = NULL;
    _module_functions[163].params = &_module_params[97];
    _module_params[97].name = "list";
    _module_params[97].type = 15;
    _module_params[97].struct_type_name = "ASTUnsafeBlock";
    _module_params[97].element_type = 21;
    _module_params[97].fn_sig = NULL;
    _module_params[98].name = "index";
    _module_params[98].type = 0;
    _module_params[98].struct_type_name = NULL;
    _module_params[98].element_type = 21;
    _module_params[98].fn_sig = NULL;

    /* Function: List_ASTUnsafeBlock_length */
    _module_functions[164].name = "List_ASTUnsafeBlock_length";
    _module_functions[164].param_count = 1;
    _module_functions[164].return_type = 0;
    _module_functions[164].return_struct_type_name = NULL;
    _module_functions[164].return_fn_sig = NULL;
    _module_functions[164].return_type_info = NULL;
    _module_functions[164].body = NULL;
    _module_functions[164].shadow_test = NULL;
    _module_functions[164].is_extern = true;
    _module_functions[164].returns_gc_managed = false;
    _module_functions[164].requires_manual_free = false;
    _module_functions[164].returns_borrowed = false;
    _module_functions[164].cleanup_function = NULL;
    _module_functions[164].params = &_module_params[99];
    _module_params[99].name = "list";
    _module_params[99].type = 15;
    _module_params[99].struct_type_name = "ASTUnsafeBlock";
    _module_params[99].element_type = 21;
    _module_params[99].fn_sig = NULL;

    /* Function: List_ASTPrint_new */
    _module_functions[165].name = "List_ASTPrint_new";
    _module_functions[165].param_count = 0;
    _module_functions[165].return_type = 15;
    _module_functions[165].return_struct_type_name = "ASTPrint";
    _module_functions[165].return_fn_sig = NULL;
    _module_functions[165].return_type_info = NULL;
    _module_functions[165].body = NULL;
    _module_functions[165].shadow_test = NULL;
    _module_functions[165].is_extern = true;
    _module_functions[165].returns_gc_managed = false;
    _module_functions[165].requires_manual_free = false;
    _module_functions[165].returns_borrowed = false;
    _module_functions[165].cleanup_function = NULL;
    _module_functions[165].params = NULL;

    /* Function: List_ASTPrint_push */
    _module_functions[166].name = "List_ASTPrint_push";
    _module_functions[166].param_count = 2;
    _module_functions[166].return_type = 6;
    _module_functions[166].return_struct_type_name = NULL;
    _module_functions[166].return_fn_sig = NULL;
    _module_functions[166].return_type_info = NULL;
    _module_functions[166].body = NULL;
    _module_functions[166].shadow_test = NULL;
    _module_functions[166].is_extern = true;
    _module_functions[166].returns_gc_managed = false;
    _module_functions[166].requires_manual_free = false;
    _module_functions[166].returns_borrowed = false;
    _module_functions[166].cleanup_function = NULL;
    _module_functions[166].params = &_module_params[100];
    _module_params[100].name = "list";
    _module_params[100].type = 15;
    _module_params[100].struct_type_name = "ASTPrint";
    _module_params[100].element_type = 21;
    _module_params[100].fn_sig = NULL;
    _module_params[101].name = "value";
    _module_params[101].type = 8;
    _module_params[101].struct_type_name = "ASTPrint";
    _module_params[101].element_type = 21;
    _module_params[101].fn_sig = NULL;

    /* Function: List_ASTPrint_get */
    _module_functions[167].name = "List_ASTPrint_get";
    _module_functions[167].param_count = 2;
    _module_functions[167].return_type = 8;
    _module_functions[167].return_struct_type_name = "ASTPrint";
    _module_functions[167].return_fn_sig = NULL;
    _module_functions[167].return_type_info = NULL;
    _module_functions[167].body = NULL;
    _module_functions[167].shadow_test = NULL;
    _module_functions[167].is_extern = true;
    _module_functions[167].returns_gc_managed = false;
    _module_functions[167].requires_manual_free = false;
    _module_functions[167].returns_borrowed = false;
    _module_functions[167].cleanup_function = NULL;
    _module_functions[167].params = &_module_params[102];
    _module_params[102].name = "list";
    _module_params[102].type = 15;
    _module_params[102].struct_type_name = "ASTPrint";
    _module_params[102].element_type = 21;
    _module_params[102].fn_sig = NULL;
    _module_params[103].name = "index";
    _module_params[103].type = 0;
    _module_params[103].struct_type_name = NULL;
    _module_params[103].element_type = 21;
    _module_params[103].fn_sig = NULL;

    /* Function: List_ASTPrint_length */
    _module_functions[168].name = "List_ASTPrint_length";
    _module_functions[168].param_count = 1;
    _module_functions[168].return_type = 0;
    _module_functions[168].return_struct_type_name = NULL;
    _module_functions[168].return_fn_sig = NULL;
    _module_functions[168].return_type_info = NULL;
    _module_functions[168].body = NULL;
    _module_functions[168].shadow_test = NULL;
    _module_functions[168].is_extern = true;
    _module_functions[168].returns_gc_managed = false;
    _module_functions[168].requires_manual_free = false;
    _module_functions[168].returns_borrowed = false;
    _module_functions[168].cleanup_function = NULL;
    _module_functions[168].params = &_module_params[104];
    _module_params[104].name = "list";
    _module_params[104].type = 15;
    _module_params[104].struct_type_name = "ASTPrint";
    _module_params[104].element_type = 21;
    _module_params[104].fn_sig = NULL;

    /* Function: List_ASTAssert_new */
    _module_functions[169].name = "List_ASTAssert_new";
    _module_functions[169].param_count = 0;
    _module_functions[169].return_type = 15;
    _module_functions[169].return_struct_type_name = "ASTAssert";
    _module_functions[169].return_fn_sig = NULL;
    _module_functions[169].return_type_info = NULL;
    _module_functions[169].body = NULL;
    _module_functions[169].shadow_test = NULL;
    _module_functions[169].is_extern = true;
    _module_functions[169].returns_gc_managed = false;
    _module_functions[169].requires_manual_free = false;
    _module_functions[169].returns_borrowed = false;
    _module_functions[169].cleanup_function = NULL;
    _module_functions[169].params = NULL;

    /* Function: List_ASTAssert_push */
    _module_functions[170].name = "List_ASTAssert_push";
    _module_functions[170].param_count = 2;
    _module_functions[170].return_type = 6;
    _module_functions[170].return_struct_type_name = NULL;
    _module_functions[170].return_fn_sig = NULL;
    _module_functions[170].return_type_info = NULL;
    _module_functions[170].body = NULL;
    _module_functions[170].shadow_test = NULL;
    _module_functions[170].is_extern = true;
    _module_functions[170].returns_gc_managed = false;
    _module_functions[170].requires_manual_free = false;
    _module_functions[170].returns_borrowed = false;
    _module_functions[170].cleanup_function = NULL;
    _module_functions[170].params = &_module_params[105];
    _module_params[105].name = "list";
    _module_params[105].type = 15;
    _module_params[105].struct_type_name = "ASTAssert";
    _module_params[105].element_type = 21;
    _module_params[105].fn_sig = NULL;
    _module_params[106].name = "value";
    _module_params[106].type = 8;
    _module_params[106].struct_type_name = "ASTAssert";
    _module_params[106].element_type = 21;
    _module_params[106].fn_sig = NULL;

    /* Function: List_ASTAssert_get */
    _module_functions[171].name = "List_ASTAssert_get";
    _module_functions[171].param_count = 2;
    _module_functions[171].return_type = 8;
    _module_functions[171].return_struct_type_name = "ASTAssert";
    _module_functions[171].return_fn_sig = NULL;
    _module_functions[171].return_type_info = NULL;
    _module_functions[171].body = NULL;
    _module_functions[171].shadow_test = NULL;
    _module_functions[171].is_extern = true;
    _module_functions[171].returns_gc_managed = false;
    _module_functions[171].requires_manual_free = false;
    _module_functions[171].returns_borrowed = false;
    _module_functions[171].cleanup_function = NULL;
    _module_functions[171].params = &_module_params[107];
    _module_params[107].name = "list";
    _module_params[107].type = 15;
    _module_params[107].struct_type_name = "ASTAssert";
    _module_params[107].element_type = 21;
    _module_params[107].fn_sig = NULL;
    _module_params[108].name = "index";
    _module_params[108].type = 0;
    _module_params[108].struct_type_name = NULL;
    _module_params[108].element_type = 21;
    _module_params[108].fn_sig = NULL;

    /* Function: List_ASTAssert_length */
    _module_functions[172].name = "List_ASTAssert_length";
    _module_functions[172].param_count = 1;
    _module_functions[172].return_type = 0;
    _module_functions[172].return_struct_type_name = NULL;
    _module_functions[172].return_fn_sig = NULL;
    _module_functions[172].return_type_info = NULL;
    _module_functions[172].body = NULL;
    _module_functions[172].shadow_test = NULL;
    _module_functions[172].is_extern = true;
    _module_functions[172].returns_gc_managed = false;
    _module_functions[172].requires_manual_free = false;
    _module_functions[172].returns_borrowed = false;
    _module_functions[172].cleanup_function = NULL;
    _module_functions[172].params = &_module_params[109];
    _module_params[109].name = "list";
    _module_params[109].type = 15;
    _module_params[109].struct_type_name = "ASTAssert";
    _module_params[109].element_type = 21;
    _module_params[109].fn_sig = NULL;

    /* Function: List_ASTFunction_new */
    _module_functions[173].name = "List_ASTFunction_new";
    _module_functions[173].param_count = 0;
    _module_functions[173].return_type = 15;
    _module_functions[173].return_struct_type_name = "ASTFunction";
    _module_functions[173].return_fn_sig = NULL;
    _module_functions[173].return_type_info = NULL;
    _module_functions[173].body = NULL;
    _module_functions[173].shadow_test = NULL;
    _module_functions[173].is_extern = true;
    _module_functions[173].returns_gc_managed = false;
    _module_functions[173].requires_manual_free = false;
    _module_functions[173].returns_borrowed = false;
    _module_functions[173].cleanup_function = NULL;
    _module_functions[173].params = NULL;

    /* Function: List_ASTFunction_push */
    _module_functions[174].name = "List_ASTFunction_push";
    _module_functions[174].param_count = 2;
    _module_functions[174].return_type = 6;
    _module_functions[174].return_struct_type_name = NULL;
    _module_functions[174].return_fn_sig = NULL;
    _module_functions[174].return_type_info = NULL;
    _module_functions[174].body = NULL;
    _module_functions[174].shadow_test = NULL;
    _module_functions[174].is_extern = true;
    _module_functions[174].returns_gc_managed = false;
    _module_functions[174].requires_manual_free = false;
    _module_functions[174].returns_borrowed = false;
    _module_functions[174].cleanup_function = NULL;
    _module_functions[174].params = &_module_params[110];
    _module_params[110].name = "list";
    _module_params[110].type = 15;
    _module_params[110].struct_type_name = "ASTFunction";
    _module_params[110].element_type = 21;
    _module_params[110].fn_sig = NULL;
    _module_params[111].name = "value";
    _module_params[111].type = 8;
    _module_params[111].struct_type_name = "ASTFunction";
    _module_params[111].element_type = 21;
    _module_params[111].fn_sig = NULL;

    /* Function: List_ASTFunction_get */
    _module_functions[175].name = "List_ASTFunction_get";
    _module_functions[175].param_count = 2;
    _module_functions[175].return_type = 8;
    _module_functions[175].return_struct_type_name = "ASTFunction";
    _module_functions[175].return_fn_sig = NULL;
    _module_functions[175].return_type_info = NULL;
    _module_functions[175].body = NULL;
    _module_functions[175].shadow_test = NULL;
    _module_functions[175].is_extern = true;
    _module_functions[175].returns_gc_managed = false;
    _module_functions[175].requires_manual_free = false;
    _module_functions[175].returns_borrowed = false;
    _module_functions[175].cleanup_function = NULL;
    _module_functions[175].params = &_module_params[112];
    _module_params[112].name = "list";
    _module_params[112].type = 15;
    _module_params[112].struct_type_name = "ASTFunction";
    _module_params[112].element_type = 21;
    _module_params[112].fn_sig = NULL;
    _module_params[113].name = "index";
    _module_params[113].type = 0;
    _module_params[113].struct_type_name = NULL;
    _module_params[113].element_type = 21;
    _module_params[113].fn_sig = NULL;

    /* Function: List_ASTFunction_length */
    _module_functions[176].name = "List_ASTFunction_length";
    _module_functions[176].param_count = 1;
    _module_functions[176].return_type = 0;
    _module_functions[176].return_struct_type_name = NULL;
    _module_functions[176].return_fn_sig = NULL;
    _module_functions[176].return_type_info = NULL;
    _module_functions[176].body = NULL;
    _module_functions[176].shadow_test = NULL;
    _module_functions[176].is_extern = true;
    _module_functions[176].returns_gc_managed = false;
    _module_functions[176].requires_manual_free = false;
    _module_functions[176].returns_borrowed = false;
    _module_functions[176].cleanup_function = NULL;
    _module_functions[176].params = &_module_params[114];
    _module_params[114].name = "list";
    _module_params[114].type = 15;
    _module_params[114].struct_type_name = "ASTFunction";
    _module_params[114].element_type = 21;
    _module_params[114].fn_sig = NULL;

    /* Function: List_ASTShadow_new */
    _module_functions[177].name = "List_ASTShadow_new";
    _module_functions[177].param_count = 0;
    _module_functions[177].return_type = 15;
    _module_functions[177].return_struct_type_name = "ASTShadow";
    _module_functions[177].return_fn_sig = NULL;
    _module_functions[177].return_type_info = NULL;
    _module_functions[177].body = NULL;
    _module_functions[177].shadow_test = NULL;
    _module_functions[177].is_extern = true;
    _module_functions[177].returns_gc_managed = false;
    _module_functions[177].requires_manual_free = false;
    _module_functions[177].returns_borrowed = false;
    _module_functions[177].cleanup_function = NULL;
    _module_functions[177].params = NULL;

    /* Function: List_ASTShadow_push */
    _module_functions[178].name = "List_ASTShadow_push";
    _module_functions[178].param_count = 2;
    _module_functions[178].return_type = 6;
    _module_functions[178].return_struct_type_name = NULL;
    _module_functions[178].return_fn_sig = NULL;
    _module_functions[178].return_type_info = NULL;
    _module_functions[178].body = NULL;
    _module_functions[178].shadow_test = NULL;
    _module_functions[178].is_extern = true;
    _module_functions[178].returns_gc_managed = false;
    _module_functions[178].requires_manual_free = false;
    _module_functions[178].returns_borrowed = false;
    _module_functions[178].cleanup_function = NULL;
    _module_functions[178].params = &_module_params[115];
    _module_params[115].name = "list";
    _module_params[115].type = 15;
    _module_params[115].struct_type_name = "ASTShadow";
    _module_params[115].element_type = 21;
    _module_params[115].fn_sig = NULL;
    _module_params[116].name = "value";
    _module_params[116].type = 8;
    _module_params[116].struct_type_name = "ASTShadow";
    _module_params[116].element_type = 21;
    _module_params[116].fn_sig = NULL;

    /* Function: List_ASTShadow_get */
    _module_functions[179].name = "List_ASTShadow_get";
    _module_functions[179].param_count = 2;
    _module_functions[179].return_type = 8;
    _module_functions[179].return_struct_type_name = "ASTShadow";
    _module_functions[179].return_fn_sig = NULL;
    _module_functions[179].return_type_info = NULL;
    _module_functions[179].body = NULL;
    _module_functions[179].shadow_test = NULL;
    _module_functions[179].is_extern = true;
    _module_functions[179].returns_gc_managed = false;
    _module_functions[179].requires_manual_free = false;
    _module_functions[179].returns_borrowed = false;
    _module_functions[179].cleanup_function = NULL;
    _module_functions[179].params = &_module_params[117];
    _module_params[117].name = "list";
    _module_params[117].type = 15;
    _module_params[117].struct_type_name = "ASTShadow";
    _module_params[117].element_type = 21;
    _module_params[117].fn_sig = NULL;
    _module_params[118].name = "index";
    _module_params[118].type = 0;
    _module_params[118].struct_type_name = NULL;
    _module_params[118].element_type = 21;
    _module_params[118].fn_sig = NULL;

    /* Function: List_ASTShadow_length */
    _module_functions[180].name = "List_ASTShadow_length";
    _module_functions[180].param_count = 1;
    _module_functions[180].return_type = 0;
    _module_functions[180].return_struct_type_name = NULL;
    _module_functions[180].return_fn_sig = NULL;
    _module_functions[180].return_type_info = NULL;
    _module_functions[180].body = NULL;
    _module_functions[180].shadow_test = NULL;
    _module_functions[180].is_extern = true;
    _module_functions[180].returns_gc_managed = false;
    _module_functions[180].requires_manual_free = false;
    _module_functions[180].returns_borrowed = false;
    _module_functions[180].cleanup_function = NULL;
    _module_functions[180].params = &_module_params[119];
    _module_params[119].name = "list";
    _module_params[119].type = 15;
    _module_params[119].struct_type_name = "ASTShadow";
    _module_params[119].element_type = 21;
    _module_params[119].fn_sig = NULL;

    /* Function: List_ASTStruct_new */
    _module_functions[181].name = "List_ASTStruct_new";
    _module_functions[181].param_count = 0;
    _module_functions[181].return_type = 15;
    _module_functions[181].return_struct_type_name = "ASTStruct";
    _module_functions[181].return_fn_sig = NULL;
    _module_functions[181].return_type_info = NULL;
    _module_functions[181].body = NULL;
    _module_functions[181].shadow_test = NULL;
    _module_functions[181].is_extern = true;
    _module_functions[181].returns_gc_managed = false;
    _module_functions[181].requires_manual_free = false;
    _module_functions[181].returns_borrowed = false;
    _module_functions[181].cleanup_function = NULL;
    _module_functions[181].params = NULL;

    /* Function: List_ASTStruct_push */
    _module_functions[182].name = "List_ASTStruct_push";
    _module_functions[182].param_count = 2;
    _module_functions[182].return_type = 6;
    _module_functions[182].return_struct_type_name = NULL;
    _module_functions[182].return_fn_sig = NULL;
    _module_functions[182].return_type_info = NULL;
    _module_functions[182].body = NULL;
    _module_functions[182].shadow_test = NULL;
    _module_functions[182].is_extern = true;
    _module_functions[182].returns_gc_managed = false;
    _module_functions[182].requires_manual_free = false;
    _module_functions[182].returns_borrowed = false;
    _module_functions[182].cleanup_function = NULL;
    _module_functions[182].params = &_module_params[120];
    _module_params[120].name = "list";
    _module_params[120].type = 15;
    _module_params[120].struct_type_name = "ASTStruct";
    _module_params[120].element_type = 21;
    _module_params[120].fn_sig = NULL;
    _module_params[121].name = "value";
    _module_params[121].type = 8;
    _module_params[121].struct_type_name = "ASTStruct";
    _module_params[121].element_type = 21;
    _module_params[121].fn_sig = NULL;

    /* Function: List_ASTStruct_get */
    _module_functions[183].name = "List_ASTStruct_get";
    _module_functions[183].param_count = 2;
    _module_functions[183].return_type = 8;
    _module_functions[183].return_struct_type_name = "ASTStruct";
    _module_functions[183].return_fn_sig = NULL;
    _module_functions[183].return_type_info = NULL;
    _module_functions[183].body = NULL;
    _module_functions[183].shadow_test = NULL;
    _module_functions[183].is_extern = true;
    _module_functions[183].returns_gc_managed = false;
    _module_functions[183].requires_manual_free = false;
    _module_functions[183].returns_borrowed = false;
    _module_functions[183].cleanup_function = NULL;
    _module_functions[183].params = &_module_params[122];
    _module_params[122].name = "list";
    _module_params[122].type = 15;
    _module_params[122].struct_type_name = "ASTStruct";
    _module_params[122].element_type = 21;
    _module_params[122].fn_sig = NULL;
    _module_params[123].name = "index";
    _module_params[123].type = 0;
    _module_params[123].struct_type_name = NULL;
    _module_params[123].element_type = 21;
    _module_params[123].fn_sig = NULL;

    /* Function: List_ASTStruct_length */
    _module_functions[184].name = "List_ASTStruct_length";
    _module_functions[184].param_count = 1;
    _module_functions[184].return_type = 0;
    _module_functions[184].return_struct_type_name = NULL;
    _module_functions[184].return_fn_sig = NULL;
    _module_functions[184].return_type_info = NULL;
    _module_functions[184].body = NULL;
    _module_functions[184].shadow_test = NULL;
    _module_functions[184].is_extern = true;
    _module_functions[184].returns_gc_managed = false;
    _module_functions[184].requires_manual_free = false;
    _module_functions[184].returns_borrowed = false;
    _module_functions[184].cleanup_function = NULL;
    _module_functions[184].params = &_module_params[124];
    _module_params[124].name = "list";
    _module_params[124].type = 15;
    _module_params[124].struct_type_name = "ASTStruct";
    _module_params[124].element_type = 21;
    _module_params[124].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_new */
    _module_functions[185].name = "List_ASTStructLiteral_new";
    _module_functions[185].param_count = 0;
    _module_functions[185].return_type = 15;
    _module_functions[185].return_struct_type_name = "ASTStructLiteral";
    _module_functions[185].return_fn_sig = NULL;
    _module_functions[185].return_type_info = NULL;
    _module_functions[185].body = NULL;
    _module_functions[185].shadow_test = NULL;
    _module_functions[185].is_extern = true;
    _module_functions[185].returns_gc_managed = false;
    _module_functions[185].requires_manual_free = false;
    _module_functions[185].returns_borrowed = false;
    _module_functions[185].cleanup_function = NULL;
    _module_functions[185].params = NULL;

    /* Function: List_ASTStructLiteral_push */
    _module_functions[186].name = "List_ASTStructLiteral_push";
    _module_functions[186].param_count = 2;
    _module_functions[186].return_type = 6;
    _module_functions[186].return_struct_type_name = NULL;
    _module_functions[186].return_fn_sig = NULL;
    _module_functions[186].return_type_info = NULL;
    _module_functions[186].body = NULL;
    _module_functions[186].shadow_test = NULL;
    _module_functions[186].is_extern = true;
    _module_functions[186].returns_gc_managed = false;
    _module_functions[186].requires_manual_free = false;
    _module_functions[186].returns_borrowed = false;
    _module_functions[186].cleanup_function = NULL;
    _module_functions[186].params = &_module_params[125];
    _module_params[125].name = "list";
    _module_params[125].type = 15;
    _module_params[125].struct_type_name = "ASTStructLiteral";
    _module_params[125].element_type = 21;
    _module_params[125].fn_sig = NULL;
    _module_params[126].name = "value";
    _module_params[126].type = 8;
    _module_params[126].struct_type_name = "ASTStructLiteral";
    _module_params[126].element_type = 21;
    _module_params[126].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_get */
    _module_functions[187].name = "List_ASTStructLiteral_get";
    _module_functions[187].param_count = 2;
    _module_functions[187].return_type = 8;
    _module_functions[187].return_struct_type_name = "ASTStructLiteral";
    _module_functions[187].return_fn_sig = NULL;
    _module_functions[187].return_type_info = NULL;
    _module_functions[187].body = NULL;
    _module_functions[187].shadow_test = NULL;
    _module_functions[187].is_extern = true;
    _module_functions[187].returns_gc_managed = false;
    _module_functions[187].requires_manual_free = false;
    _module_functions[187].returns_borrowed = false;
    _module_functions[187].cleanup_function = NULL;
    _module_functions[187].params = &_module_params[127];
    _module_params[127].name = "list";
    _module_params[127].type = 15;
    _module_params[127].struct_type_name = "ASTStructLiteral";
    _module_params[127].element_type = 21;
    _module_params[127].fn_sig = NULL;
    _module_params[128].name = "index";
    _module_params[128].type = 0;
    _module_params[128].struct_type_name = NULL;
    _module_params[128].element_type = 21;
    _module_params[128].fn_sig = NULL;

    /* Function: List_ASTStructLiteral_length */
    _module_functions[188].name = "List_ASTStructLiteral_length";
    _module_functions[188].param_count = 1;
    _module_functions[188].return_type = 0;
    _module_functions[188].return_struct_type_name = NULL;
    _module_functions[188].return_fn_sig = NULL;
    _module_functions[188].return_type_info = NULL;
    _module_functions[188].body = NULL;
    _module_functions[188].shadow_test = NULL;
    _module_functions[188].is_extern = true;
    _module_functions[188].returns_gc_managed = false;
    _module_functions[188].requires_manual_free = false;
    _module_functions[188].returns_borrowed = false;
    _module_functions[188].cleanup_function = NULL;
    _module_functions[188].params = &_module_params[129];
    _module_params[129].name = "list";
    _module_params[129].type = 15;
    _module_params[129].struct_type_name = "ASTStructLiteral";
    _module_params[129].element_type = 21;
    _module_params[129].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_new */
    _module_functions[189].name = "List_ASTFieldAccess_new";
    _module_functions[189].param_count = 0;
    _module_functions[189].return_type = 15;
    _module_functions[189].return_struct_type_name = "ASTFieldAccess";
    _module_functions[189].return_fn_sig = NULL;
    _module_functions[189].return_type_info = NULL;
    _module_functions[189].body = NULL;
    _module_functions[189].shadow_test = NULL;
    _module_functions[189].is_extern = true;
    _module_functions[189].returns_gc_managed = false;
    _module_functions[189].requires_manual_free = false;
    _module_functions[189].returns_borrowed = false;
    _module_functions[189].cleanup_function = NULL;
    _module_functions[189].params = NULL;

    /* Function: List_ASTFieldAccess_push */
    _module_functions[190].name = "List_ASTFieldAccess_push";
    _module_functions[190].param_count = 2;
    _module_functions[190].return_type = 6;
    _module_functions[190].return_struct_type_name = NULL;
    _module_functions[190].return_fn_sig = NULL;
    _module_functions[190].return_type_info = NULL;
    _module_functions[190].body = NULL;
    _module_functions[190].shadow_test = NULL;
    _module_functions[190].is_extern = true;
    _module_functions[190].returns_gc_managed = false;
    _module_functions[190].requires_manual_free = false;
    _module_functions[190].returns_borrowed = false;
    _module_functions[190].cleanup_function = NULL;
    _module_functions[190].params = &_module_params[130];
    _module_params[130].name = "list";
    _module_params[130].type = 15;
    _module_params[130].struct_type_name = "ASTFieldAccess";
    _module_params[130].element_type = 21;
    _module_params[130].fn_sig = NULL;
    _module_params[131].name = "value";
    _module_params[131].type = 8;
    _module_params[131].struct_type_name = "ASTFieldAccess";
    _module_params[131].element_type = 21;
    _module_params[131].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_get */
    _module_functions[191].name = "List_ASTFieldAccess_get";
    _module_functions[191].param_count = 2;
    _module_functions[191].return_type = 8;
    _module_functions[191].return_struct_type_name = "ASTFieldAccess";
    _module_functions[191].return_fn_sig = NULL;
    _module_functions[191].return_type_info = NULL;
    _module_functions[191].body = NULL;
    _module_functions[191].shadow_test = NULL;
    _module_functions[191].is_extern = true;
    _module_functions[191].returns_gc_managed = false;
    _module_functions[191].requires_manual_free = false;
    _module_functions[191].returns_borrowed = false;
    _module_functions[191].cleanup_function = NULL;
    _module_functions[191].params = &_module_params[132];
    _module_params[132].name = "list";
    _module_params[132].type = 15;
    _module_params[132].struct_type_name = "ASTFieldAccess";
    _module_params[132].element_type = 21;
    _module_params[132].fn_sig = NULL;
    _module_params[133].name = "index";
    _module_params[133].type = 0;
    _module_params[133].struct_type_name = NULL;
    _module_params[133].element_type = 21;
    _module_params[133].fn_sig = NULL;

    /* Function: List_ASTFieldAccess_length */
    _module_functions[192].name = "List_ASTFieldAccess_length";
    _module_functions[192].param_count = 1;
    _module_functions[192].return_type = 0;
    _module_functions[192].return_struct_type_name = NULL;
    _module_functions[192].return_fn_sig = NULL;
    _module_functions[192].return_type_info = NULL;
    _module_functions[192].body = NULL;
    _module_functions[192].shadow_test = NULL;
    _module_functions[192].is_extern = true;
    _module_functions[192].returns_gc_managed = false;
    _module_functions[192].requires_manual_free = false;
    _module_functions[192].returns_borrowed = false;
    _module_functions[192].cleanup_function = NULL;
    _module_functions[192].params = &_module_params[134];
    _module_params[134].name = "list";
    _module_params[134].type = 15;
    _module_params[134].struct_type_name = "ASTFieldAccess";
    _module_params[134].element_type = 21;
    _module_params[134].fn_sig = NULL;

    /* Function: List_ASTEnum_new */
    _module_functions[193].name = "List_ASTEnum_new";
    _module_functions[193].param_count = 0;
    _module_functions[193].return_type = 15;
    _module_functions[193].return_struct_type_name = "ASTEnum";
    _module_functions[193].return_fn_sig = NULL;
    _module_functions[193].return_type_info = NULL;
    _module_functions[193].body = NULL;
    _module_functions[193].shadow_test = NULL;
    _module_functions[193].is_extern = true;
    _module_functions[193].returns_gc_managed = false;
    _module_functions[193].requires_manual_free = false;
    _module_functions[193].returns_borrowed = false;
    _module_functions[193].cleanup_function = NULL;
    _module_functions[193].params = NULL;

    /* Function: List_ASTEnum_push */
    _module_functions[194].name = "List_ASTEnum_push";
    _module_functions[194].param_count = 2;
    _module_functions[194].return_type = 6;
    _module_functions[194].return_struct_type_name = NULL;
    _module_functions[194].return_fn_sig = NULL;
    _module_functions[194].return_type_info = NULL;
    _module_functions[194].body = NULL;
    _module_functions[194].shadow_test = NULL;
    _module_functions[194].is_extern = true;
    _module_functions[194].returns_gc_managed = false;
    _module_functions[194].requires_manual_free = false;
    _module_functions[194].returns_borrowed = false;
    _module_functions[194].cleanup_function = NULL;
    _module_functions[194].params = &_module_params[135];
    _module_params[135].name = "list";
    _module_params[135].type = 15;
    _module_params[135].struct_type_name = "ASTEnum";
    _module_params[135].element_type = 21;
    _module_params[135].fn_sig = NULL;
    _module_params[136].name = "value";
    _module_params[136].type = 8;
    _module_params[136].struct_type_name = "ASTEnum";
    _module_params[136].element_type = 21;
    _module_params[136].fn_sig = NULL;

    /* Function: List_ASTEnum_get */
    _module_functions[195].name = "List_ASTEnum_get";
    _module_functions[195].param_count = 2;
    _module_functions[195].return_type = 8;
    _module_functions[195].return_struct_type_name = "ASTEnum";
    _module_functions[195].return_fn_sig = NULL;
    _module_functions[195].return_type_info = NULL;
    _module_functions[195].body = NULL;
    _module_functions[195].shadow_test = NULL;
    _module_functions[195].is_extern = true;
    _module_functions[195].returns_gc_managed = false;
    _module_functions[195].requires_manual_free = false;
    _module_functions[195].returns_borrowed = false;
    _module_functions[195].cleanup_function = NULL;
    _module_functions[195].params = &_module_params[137];
    _module_params[137].name = "list";
    _module_params[137].type = 15;
    _module_params[137].struct_type_name = "ASTEnum";
    _module_params[137].element_type = 21;
    _module_params[137].fn_sig = NULL;
    _module_params[138].name = "index";
    _module_params[138].type = 0;
    _module_params[138].struct_type_name = NULL;
    _module_params[138].element_type = 21;
    _module_params[138].fn_sig = NULL;

    /* Function: List_ASTEnum_length */
    _module_functions[196].name = "List_ASTEnum_length";
    _module_functions[196].param_count = 1;
    _module_functions[196].return_type = 0;
    _module_functions[196].return_struct_type_name = NULL;
    _module_functions[196].return_fn_sig = NULL;
    _module_functions[196].return_type_info = NULL;
    _module_functions[196].body = NULL;
    _module_functions[196].shadow_test = NULL;
    _module_functions[196].is_extern = true;
    _module_functions[196].returns_gc_managed = false;
    _module_functions[196].requires_manual_free = false;
    _module_functions[196].returns_borrowed = false;
    _module_functions[196].cleanup_function = NULL;
    _module_functions[196].params = &_module_params[139];
    _module_params[139].name = "list";
    _module_params[139].type = 15;
    _module_params[139].struct_type_name = "ASTEnum";
    _module_params[139].element_type = 21;
    _module_params[139].fn_sig = NULL;

    /* Function: List_ASTUnion_new */
    _module_functions[197].name = "List_ASTUnion_new";
    _module_functions[197].param_count = 0;
    _module_functions[197].return_type = 15;
    _module_functions[197].return_struct_type_name = "ASTUnion";
    _module_functions[197].return_fn_sig = NULL;
    _module_functions[197].return_type_info = NULL;
    _module_functions[197].body = NULL;
    _module_functions[197].shadow_test = NULL;
    _module_functions[197].is_extern = true;
    _module_functions[197].returns_gc_managed = false;
    _module_functions[197].requires_manual_free = false;
    _module_functions[197].returns_borrowed = false;
    _module_functions[197].cleanup_function = NULL;
    _module_functions[197].params = NULL;

    /* Function: List_ASTUnion_push */
    _module_functions[198].name = "List_ASTUnion_push";
    _module_functions[198].param_count = 2;
    _module_functions[198].return_type = 6;
    _module_functions[198].return_struct_type_name = NULL;
    _module_functions[198].return_fn_sig = NULL;
    _module_functions[198].return_type_info = NULL;
    _module_functions[198].body = NULL;
    _module_functions[198].shadow_test = NULL;
    _module_functions[198].is_extern = true;
    _module_functions[198].returns_gc_managed = false;
    _module_functions[198].requires_manual_free = false;
    _module_functions[198].returns_borrowed = false;
    _module_functions[198].cleanup_function = NULL;
    _module_functions[198].params = &_module_params[140];
    _module_params[140].name = "list";
    _module_params[140].type = 15;
    _module_params[140].struct_type_name = "ASTUnion";
    _module_params[140].element_type = 21;
    _module_params[140].fn_sig = NULL;
    _module_params[141].name = "value";
    _module_params[141].type = 8;
    _module_params[141].struct_type_name = "ASTUnion";
    _module_params[141].element_type = 21;
    _module_params[141].fn_sig = NULL;

    /* Function: List_ASTUnion_get */
    _module_functions[199].name = "List_ASTUnion_get";
    _module_functions[199].param_count = 2;
    _module_functions[199].return_type = 8;
    _module_functions[199].return_struct_type_name = "ASTUnion";
    _module_functions[199].return_fn_sig = NULL;
    _module_functions[199].return_type_info = NULL;
    _module_functions[199].body = NULL;
    _module_functions[199].shadow_test = NULL;
    _module_functions[199].is_extern = true;
    _module_functions[199].returns_gc_managed = false;
    _module_functions[199].requires_manual_free = false;
    _module_functions[199].returns_borrowed = false;
    _module_functions[199].cleanup_function = NULL;
    _module_functions[199].params = &_module_params[142];
    _module_params[142].name = "list";
    _module_params[142].type = 15;
    _module_params[142].struct_type_name = "ASTUnion";
    _module_params[142].element_type = 21;
    _module_params[142].fn_sig = NULL;
    _module_params[143].name = "index";
    _module_params[143].type = 0;
    _module_params[143].struct_type_name = NULL;
    _module_params[143].element_type = 21;
    _module_params[143].fn_sig = NULL;

    /* Function: List_ASTUnion_length */
    _module_functions[200].name = "List_ASTUnion_length";
    _module_functions[200].param_count = 1;
    _module_functions[200].return_type = 0;
    _module_functions[200].return_struct_type_name = NULL;
    _module_functions[200].return_fn_sig = NULL;
    _module_functions[200].return_type_info = NULL;
    _module_functions[200].body = NULL;
    _module_functions[200].shadow_test = NULL;
    _module_functions[200].is_extern = true;
    _module_functions[200].returns_gc_managed = false;
    _module_functions[200].requires_manual_free = false;
    _module_functions[200].returns_borrowed = false;
    _module_functions[200].cleanup_function = NULL;
    _module_functions[200].params = &_module_params[144];
    _module_params[144].name = "list";
    _module_params[144].type = 15;
    _module_params[144].struct_type_name = "ASTUnion";
    _module_params[144].element_type = 21;
    _module_params[144].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_new */
    _module_functions[201].name = "List_ASTUnionConstruct_new";
    _module_functions[201].param_count = 0;
    _module_functions[201].return_type = 15;
    _module_functions[201].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[201].return_fn_sig = NULL;
    _module_functions[201].return_type_info = NULL;
    _module_functions[201].body = NULL;
    _module_functions[201].shadow_test = NULL;
    _module_functions[201].is_extern = true;
    _module_functions[201].returns_gc_managed = false;
    _module_functions[201].requires_manual_free = false;
    _module_functions[201].returns_borrowed = false;
    _module_functions[201].cleanup_function = NULL;
    _module_functions[201].params = NULL;

    /* Function: List_ASTUnionConstruct_push */
    _module_functions[202].name = "List_ASTUnionConstruct_push";
    _module_functions[202].param_count = 2;
    _module_functions[202].return_type = 6;
    _module_functions[202].return_struct_type_name = NULL;
    _module_functions[202].return_fn_sig = NULL;
    _module_functions[202].return_type_info = NULL;
    _module_functions[202].body = NULL;
    _module_functions[202].shadow_test = NULL;
    _module_functions[202].is_extern = true;
    _module_functions[202].returns_gc_managed = false;
    _module_functions[202].requires_manual_free = false;
    _module_functions[202].returns_borrowed = false;
    _module_functions[202].cleanup_function = NULL;
    _module_functions[202].params = &_module_params[145];
    _module_params[145].name = "list";
    _module_params[145].type = 15;
    _module_params[145].struct_type_name = "ASTUnionConstruct";
    _module_params[145].element_type = 21;
    _module_params[145].fn_sig = NULL;
    _module_params[146].name = "value";
    _module_params[146].type = 8;
    _module_params[146].struct_type_name = "ASTUnionConstruct";
    _module_params[146].element_type = 21;
    _module_params[146].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_get */
    _module_functions[203].name = "List_ASTUnionConstruct_get";
    _module_functions[203].param_count = 2;
    _module_functions[203].return_type = 8;
    _module_functions[203].return_struct_type_name = "ASTUnionConstruct";
    _module_functions[203].return_fn_sig = NULL;
    _module_functions[203].return_type_info = NULL;
    _module_functions[203].body = NULL;
    _module_functions[203].shadow_test = NULL;
    _module_functions[203].is_extern = true;
    _module_functions[203].returns_gc_managed = false;
    _module_functions[203].requires_manual_free = false;
    _module_functions[203].returns_borrowed = false;
    _module_functions[203].cleanup_function = NULL;
    _module_functions[203].params = &_module_params[147];
    _module_params[147].name = "list";
    _module_params[147].type = 15;
    _module_params[147].struct_type_name = "ASTUnionConstruct";
    _module_params[147].element_type = 21;
    _module_params[147].fn_sig = NULL;
    _module_params[148].name = "index";
    _module_params[148].type = 0;
    _module_params[148].struct_type_name = NULL;
    _module_params[148].element_type = 21;
    _module_params[148].fn_sig = NULL;

    /* Function: List_ASTUnionConstruct_length */
    _module_functions[204].name = "List_ASTUnionConstruct_length";
    _module_functions[204].param_count = 1;
    _module_functions[204].return_type = 0;
    _module_functions[204].return_struct_type_name = NULL;
    _module_functions[204].return_fn_sig = NULL;
    _module_functions[204].return_type_info = NULL;
    _module_functions[204].body = NULL;
    _module_functions[204].shadow_test = NULL;
    _module_functions[204].is_extern = true;
    _module_functions[204].returns_gc_managed = false;
    _module_functions[204].requires_manual_free = false;
    _module_functions[204].returns_borrowed = false;
    _module_functions[204].cleanup_function = NULL;
    _module_functions[204].params = &_module_params[149];
    _module_params[149].name = "list";
    _module_params[149].type = 15;
    _module_params[149].struct_type_name = "ASTUnionConstruct";
    _module_params[149].element_type = 21;
    _module_params[149].fn_sig = NULL;

    /* Function: List_ASTMatch_new */
    _module_functions[205].name = "List_ASTMatch_new";
    _module_functions[205].param_count = 0;
    _module_functions[205].return_type = 15;
    _module_functions[205].return_struct_type_name = "ASTMatch";
    _module_functions[205].return_fn_sig = NULL;
    _module_functions[205].return_type_info = NULL;
    _module_functions[205].body = NULL;
    _module_functions[205].shadow_test = NULL;
    _module_functions[205].is_extern = true;
    _module_functions[205].returns_gc_managed = false;
    _module_functions[205].requires_manual_free = false;
    _module_functions[205].returns_borrowed = false;
    _module_functions[205].cleanup_function = NULL;
    _module_functions[205].params = NULL;

    /* Function: List_ASTMatch_push */
    _module_functions[206].name = "List_ASTMatch_push";
    _module_functions[206].param_count = 2;
    _module_functions[206].return_type = 6;
    _module_functions[206].return_struct_type_name = NULL;
    _module_functions[206].return_fn_sig = NULL;
    _module_functions[206].return_type_info = NULL;
    _module_functions[206].body = NULL;
    _module_functions[206].shadow_test = NULL;
    _module_functions[206].is_extern = true;
    _module_functions[206].returns_gc_managed = false;
    _module_functions[206].requires_manual_free = false;
    _module_functions[206].returns_borrowed = false;
    _module_functions[206].cleanup_function = NULL;
    _module_functions[206].params = &_module_params[150];
    _module_params[150].name = "list";
    _module_params[150].type = 15;
    _module_params[150].struct_type_name = "ASTMatch";
    _module_params[150].element_type = 21;
    _module_params[150].fn_sig = NULL;
    _module_params[151].name = "value";
    _module_params[151].type = 8;
    _module_params[151].struct_type_name = "ASTMatch";
    _module_params[151].element_type = 21;
    _module_params[151].fn_sig = NULL;

    /* Function: List_ASTMatch_get */
    _module_functions[207].name = "List_ASTMatch_get";
    _module_functions[207].param_count = 2;
    _module_functions[207].return_type = 8;
    _module_functions[207].return_struct_type_name = "ASTMatch";
    _module_functions[207].return_fn_sig = NULL;
    _module_functions[207].return_type_info = NULL;
    _module_functions[207].body = NULL;
    _module_functions[207].shadow_test = NULL;
    _module_functions[207].is_extern = true;
    _module_functions[207].returns_gc_managed = false;
    _module_functions[207].requires_manual_free = false;
    _module_functions[207].returns_borrowed = false;
    _module_functions[207].cleanup_function = NULL;
    _module_functions[207].params = &_module_params[152];
    _module_params[152].name = "list";
    _module_params[152].type = 15;
    _module_params[152].struct_type_name = "ASTMatch";
    _module_params[152].element_type = 21;
    _module_params[152].fn_sig = NULL;
    _module_params[153].name = "index";
    _module_params[153].type = 0;
    _module_params[153].struct_type_name = NULL;
    _module_params[153].element_type = 21;
    _module_params[153].fn_sig = NULL;

    /* Function: List_ASTMatch_length */
    _module_functions[208].name = "List_ASTMatch_length";
    _module_functions[208].param_count = 1;
    _module_functions[208].return_type = 0;
    _module_functions[208].return_struct_type_name = NULL;
    _module_functions[208].return_fn_sig = NULL;
    _module_functions[208].return_type_info = NULL;
    _module_functions[208].body = NULL;
    _module_functions[208].shadow_test = NULL;
    _module_functions[208].is_extern = true;
    _module_functions[208].returns_gc_managed = false;
    _module_functions[208].requires_manual_free = false;
    _module_functions[208].returns_borrowed = false;
    _module_functions[208].cleanup_function = NULL;
    _module_functions[208].params = &_module_params[154];
    _module_params[154].name = "list";
    _module_params[154].type = 15;
    _module_params[154].struct_type_name = "ASTMatch";
    _module_params[154].element_type = 21;
    _module_params[154].fn_sig = NULL;

    /* Function: List_ASTImport_new */
    _module_functions[209].name = "List_ASTImport_new";
    _module_functions[209].param_count = 0;
    _module_functions[209].return_type = 15;
    _module_functions[209].return_struct_type_name = "ASTImport";
    _module_functions[209].return_fn_sig = NULL;
    _module_functions[209].return_type_info = NULL;
    _module_functions[209].body = NULL;
    _module_functions[209].shadow_test = NULL;
    _module_functions[209].is_extern = true;
    _module_functions[209].returns_gc_managed = false;
    _module_functions[209].requires_manual_free = false;
    _module_functions[209].returns_borrowed = false;
    _module_functions[209].cleanup_function = NULL;
    _module_functions[209].params = NULL;

    /* Function: List_ASTImport_push */
    _module_functions[210].name = "List_ASTImport_push";
    _module_functions[210].param_count = 2;
    _module_functions[210].return_type = 6;
    _module_functions[210].return_struct_type_name = NULL;
    _module_functions[210].return_fn_sig = NULL;
    _module_functions[210].return_type_info = NULL;
    _module_functions[210].body = NULL;
    _module_functions[210].shadow_test = NULL;
    _module_functions[210].is_extern = true;
    _module_functions[210].returns_gc_managed = false;
    _module_functions[210].requires_manual_free = false;
    _module_functions[210].returns_borrowed = false;
    _module_functions[210].cleanup_function = NULL;
    _module_functions[210].params = &_module_params[155];
    _module_params[155].name = "list";
    _module_params[155].type = 15;
    _module_params[155].struct_type_name = "ASTImport";
    _module_params[155].element_type = 21;
    _module_params[155].fn_sig = NULL;
    _module_params[156].name = "value";
    _module_params[156].type = 8;
    _module_params[156].struct_type_name = "ASTImport";
    _module_params[156].element_type = 21;
    _module_params[156].fn_sig = NULL;

    /* Function: List_ASTImport_get */
    _module_functions[211].name = "List_ASTImport_get";
    _module_functions[211].param_count = 2;
    _module_functions[211].return_type = 8;
    _module_functions[211].return_struct_type_name = "ASTImport";
    _module_functions[211].return_fn_sig = NULL;
    _module_functions[211].return_type_info = NULL;
    _module_functions[211].body = NULL;
    _module_functions[211].shadow_test = NULL;
    _module_functions[211].is_extern = true;
    _module_functions[211].returns_gc_managed = false;
    _module_functions[211].requires_manual_free = false;
    _module_functions[211].returns_borrowed = false;
    _module_functions[211].cleanup_function = NULL;
    _module_functions[211].params = &_module_params[157];
    _module_params[157].name = "list";
    _module_params[157].type = 15;
    _module_params[157].struct_type_name = "ASTImport";
    _module_params[157].element_type = 21;
    _module_params[157].fn_sig = NULL;
    _module_params[158].name = "index";
    _module_params[158].type = 0;
    _module_params[158].struct_type_name = NULL;
    _module_params[158].element_type = 21;
    _module_params[158].fn_sig = NULL;

    /* Function: List_ASTImport_length */
    _module_functions[212].name = "List_ASTImport_length";
    _module_functions[212].param_count = 1;
    _module_functions[212].return_type = 0;
    _module_functions[212].return_struct_type_name = NULL;
    _module_functions[212].return_fn_sig = NULL;
    _module_functions[212].return_type_info = NULL;
    _module_functions[212].body = NULL;
    _module_functions[212].shadow_test = NULL;
    _module_functions[212].is_extern = true;
    _module_functions[212].returns_gc_managed = false;
    _module_functions[212].requires_manual_free = false;
    _module_functions[212].returns_borrowed = false;
    _module_functions[212].cleanup_function = NULL;
    _module_functions[212].params = &_module_params[159];
    _module_params[159].name = "list";
    _module_params[159].type = 15;
    _module_params[159].struct_type_name = "ASTImport";
    _module_params[159].element_type = 21;
    _module_params[159].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_new */
    _module_functions[213].name = "List_ASTOpaqueType_new";
    _module_functions[213].param_count = 0;
    _module_functions[213].return_type = 15;
    _module_functions[213].return_struct_type_name = "ASTOpaqueType";
    _module_functions[213].return_fn_sig = NULL;
    _module_functions[213].return_type_info = NULL;
    _module_functions[213].body = NULL;
    _module_functions[213].shadow_test = NULL;
    _module_functions[213].is_extern = true;
    _module_functions[213].returns_gc_managed = false;
    _module_functions[213].requires_manual_free = false;
    _module_functions[213].returns_borrowed = false;
    _module_functions[213].cleanup_function = NULL;
    _module_functions[213].params = NULL;

    /* Function: List_ASTOpaqueType_push */
    _module_functions[214].name = "List_ASTOpaqueType_push";
    _module_functions[214].param_count = 2;
    _module_functions[214].return_type = 6;
    _module_functions[214].return_struct_type_name = NULL;
    _module_functions[214].return_fn_sig = NULL;
    _module_functions[214].return_type_info = NULL;
    _module_functions[214].body = NULL;
    _module_functions[214].shadow_test = NULL;
    _module_functions[214].is_extern = true;
    _module_functions[214].returns_gc_managed = false;
    _module_functions[214].requires_manual_free = false;
    _module_functions[214].returns_borrowed = false;
    _module_functions[214].cleanup_function = NULL;
    _module_functions[214].params = &_module_params[160];
    _module_params[160].name = "list";
    _module_params[160].type = 15;
    _module_params[160].struct_type_name = "ASTOpaqueType";
    _module_params[160].element_type = 21;
    _module_params[160].fn_sig = NULL;
    _module_params[161].name = "value";
    _module_params[161].type = 8;
    _module_params[161].struct_type_name = "ASTOpaqueType";
    _module_params[161].element_type = 21;
    _module_params[161].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_get */
    _module_functions[215].name = "List_ASTOpaqueType_get";
    _module_functions[215].param_count = 2;
    _module_functions[215].return_type = 8;
    _module_functions[215].return_struct_type_name = "ASTOpaqueType";
    _module_functions[215].return_fn_sig = NULL;
    _module_functions[215].return_type_info = NULL;
    _module_functions[215].body = NULL;
    _module_functions[215].shadow_test = NULL;
    _module_functions[215].is_extern = true;
    _module_functions[215].returns_gc_managed = false;
    _module_functions[215].requires_manual_free = false;
    _module_functions[215].returns_borrowed = false;
    _module_functions[215].cleanup_function = NULL;
    _module_functions[215].params = &_module_params[162];
    _module_params[162].name = "list";
    _module_params[162].type = 15;
    _module_params[162].struct_type_name = "ASTOpaqueType";
    _module_params[162].element_type = 21;
    _module_params[162].fn_sig = NULL;
    _module_params[163].name = "index";
    _module_params[163].type = 0;
    _module_params[163].struct_type_name = NULL;
    _module_params[163].element_type = 21;
    _module_params[163].fn_sig = NULL;

    /* Function: List_ASTOpaqueType_length */
    _module_functions[216].name = "List_ASTOpaqueType_length";
    _module_functions[216].param_count = 1;
    _module_functions[216].return_type = 0;
    _module_functions[216].return_struct_type_name = NULL;
    _module_functions[216].return_fn_sig = NULL;
    _module_functions[216].return_type_info = NULL;
    _module_functions[216].body = NULL;
    _module_functions[216].shadow_test = NULL;
    _module_functions[216].is_extern = true;
    _module_functions[216].returns_gc_managed = false;
    _module_functions[216].requires_manual_free = false;
    _module_functions[216].returns_borrowed = false;
    _module_functions[216].cleanup_function = NULL;
    _module_functions[216].params = &_module_params[164];
    _module_params[164].name = "list";
    _module_params[164].type = 15;
    _module_params[164].struct_type_name = "ASTOpaqueType";
    _module_params[164].element_type = 21;
    _module_params[164].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_new */
    _module_functions[217].name = "List_ASTTupleLiteral_new";
    _module_functions[217].param_count = 0;
    _module_functions[217].return_type = 15;
    _module_functions[217].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[217].return_fn_sig = NULL;
    _module_functions[217].return_type_info = NULL;
    _module_functions[217].body = NULL;
    _module_functions[217].shadow_test = NULL;
    _module_functions[217].is_extern = true;
    _module_functions[217].returns_gc_managed = false;
    _module_functions[217].requires_manual_free = false;
    _module_functions[217].returns_borrowed = false;
    _module_functions[217].cleanup_function = NULL;
    _module_functions[217].params = NULL;

    /* Function: List_ASTTupleLiteral_push */
    _module_functions[218].name = "List_ASTTupleLiteral_push";
    _module_functions[218].param_count = 2;
    _module_functions[218].return_type = 6;
    _module_functions[218].return_struct_type_name = NULL;
    _module_functions[218].return_fn_sig = NULL;
    _module_functions[218].return_type_info = NULL;
    _module_functions[218].body = NULL;
    _module_functions[218].shadow_test = NULL;
    _module_functions[218].is_extern = true;
    _module_functions[218].returns_gc_managed = false;
    _module_functions[218].requires_manual_free = false;
    _module_functions[218].returns_borrowed = false;
    _module_functions[218].cleanup_function = NULL;
    _module_functions[218].params = &_module_params[165];
    _module_params[165].name = "list";
    _module_params[165].type = 15;
    _module_params[165].struct_type_name = "ASTTupleLiteral";
    _module_params[165].element_type = 21;
    _module_params[165].fn_sig = NULL;
    _module_params[166].name = "value";
    _module_params[166].type = 8;
    _module_params[166].struct_type_name = "ASTTupleLiteral";
    _module_params[166].element_type = 21;
    _module_params[166].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_get */
    _module_functions[219].name = "List_ASTTupleLiteral_get";
    _module_functions[219].param_count = 2;
    _module_functions[219].return_type = 8;
    _module_functions[219].return_struct_type_name = "ASTTupleLiteral";
    _module_functions[219].return_fn_sig = NULL;
    _module_functions[219].return_type_info = NULL;
    _module_functions[219].body = NULL;
    _module_functions[219].shadow_test = NULL;
    _module_functions[219].is_extern = true;
    _module_functions[219].returns_gc_managed = false;
    _module_functions[219].requires_manual_free = false;
    _module_functions[219].returns_borrowed = false;
    _module_functions[219].cleanup_function = NULL;
    _module_functions[219].params = &_module_params[167];
    _module_params[167].name = "list";
    _module_params[167].type = 15;
    _module_params[167].struct_type_name = "ASTTupleLiteral";
    _module_params[167].element_type = 21;
    _module_params[167].fn_sig = NULL;
    _module_params[168].name = "index";
    _module_params[168].type = 0;
    _module_params[168].struct_type_name = NULL;
    _module_params[168].element_type = 21;
    _module_params[168].fn_sig = NULL;

    /* Function: List_ASTTupleLiteral_length */
    _module_functions[220].name = "List_ASTTupleLiteral_length";
    _module_functions[220].param_count = 1;
    _module_functions[220].return_type = 0;
    _module_functions[220].return_struct_type_name = NULL;
    _module_functions[220].return_fn_sig = NULL;
    _module_functions[220].return_type_info = NULL;
    _module_functions[220].body = NULL;
    _module_functions[220].shadow_test = NULL;
    _module_functions[220].is_extern = true;
    _module_functions[220].returns_gc_managed = false;
    _module_functions[220].requires_manual_free = false;
    _module_functions[220].returns_borrowed = false;
    _module_functions[220].cleanup_function = NULL;
    _module_functions[220].params = &_module_params[169];
    _module_params[169].name = "list";
    _module_params[169].type = 15;
    _module_params[169].struct_type_name = "ASTTupleLiteral";
    _module_params[169].element_type = 21;
    _module_params[169].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_new */
    _module_functions[221].name = "List_ASTTupleIndex_new";
    _module_functions[221].param_count = 0;
    _module_functions[221].return_type = 15;
    _module_functions[221].return_struct_type_name = "ASTTupleIndex";
    _module_functions[221].return_fn_sig = NULL;
    _module_functions[221].return_type_info = NULL;
    _module_functions[221].body = NULL;
    _module_functions[221].shadow_test = NULL;
    _module_functions[221].is_extern = true;
    _module_functions[221].returns_gc_managed = false;
    _module_functions[221].requires_manual_free = false;
    _module_functions[221].returns_borrowed = false;
    _module_functions[221].cleanup_function = NULL;
    _module_functions[221].params = NULL;

    /* Function: List_ASTTupleIndex_push */
    _module_functions[222].name = "List_ASTTupleIndex_push";
    _module_functions[222].param_count = 2;
    _module_functions[222].return_type = 6;
    _module_functions[222].return_struct_type_name = NULL;
    _module_functions[222].return_fn_sig = NULL;
    _module_functions[222].return_type_info = NULL;
    _module_functions[222].body = NULL;
    _module_functions[222].shadow_test = NULL;
    _module_functions[222].is_extern = true;
    _module_functions[222].returns_gc_managed = false;
    _module_functions[222].requires_manual_free = false;
    _module_functions[222].returns_borrowed = false;
    _module_functions[222].cleanup_function = NULL;
    _module_functions[222].params = &_module_params[170];
    _module_params[170].name = "list";
    _module_params[170].type = 15;
    _module_params[170].struct_type_name = "ASTTupleIndex";
    _module_params[170].element_type = 21;
    _module_params[170].fn_sig = NULL;
    _module_params[171].name = "value";
    _module_params[171].type = 8;
    _module_params[171].struct_type_name = "ASTTupleIndex";
    _module_params[171].element_type = 21;
    _module_params[171].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_get */
    _module_functions[223].name = "List_ASTTupleIndex_get";
    _module_functions[223].param_count = 2;
    _module_functions[223].return_type = 8;
    _module_functions[223].return_struct_type_name = "ASTTupleIndex";
    _module_functions[223].return_fn_sig = NULL;
    _module_functions[223].return_type_info = NULL;
    _module_functions[223].body = NULL;
    _module_functions[223].shadow_test = NULL;
    _module_functions[223].is_extern = true;
    _module_functions[223].returns_gc_managed = false;
    _module_functions[223].requires_manual_free = false;
    _module_functions[223].returns_borrowed = false;
    _module_functions[223].cleanup_function = NULL;
    _module_functions[223].params = &_module_params[172];
    _module_params[172].name = "list";
    _module_params[172].type = 15;
    _module_params[172].struct_type_name = "ASTTupleIndex";
    _module_params[172].element_type = 21;
    _module_params[172].fn_sig = NULL;
    _module_params[173].name = "index";
    _module_params[173].type = 0;
    _module_params[173].struct_type_name = NULL;
    _module_params[173].element_type = 21;
    _module_params[173].fn_sig = NULL;

    /* Function: List_ASTTupleIndex_length */
    _module_functions[224].name = "List_ASTTupleIndex_length";
    _module_functions[224].param_count = 1;
    _module_functions[224].return_type = 0;
    _module_functions[224].return_struct_type_name = NULL;
    _module_functions[224].return_fn_sig = NULL;
    _module_functions[224].return_type_info = NULL;
    _module_functions[224].body = NULL;
    _module_functions[224].shadow_test = NULL;
    _module_functions[224].is_extern = true;
    _module_functions[224].returns_gc_managed = false;
    _module_functions[224].requires_manual_free = false;
    _module_functions[224].returns_borrowed = false;
    _module_functions[224].cleanup_function = NULL;
    _module_functions[224].params = &_module_params[174];
    _module_params[174].name = "list";
    _module_params[174].type = 15;
    _module_params[174].struct_type_name = "ASTTupleIndex";
    _module_params[174].element_type = 21;
    _module_params[174].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_new */
    _module_functions[225].name = "List_ASTServiceDecl_new";
    _module_functions[225].param_count = 0;
    _module_functions[225].return_type = 15;
    _module_functions[225].return_struct_type_name = "ASTServiceDecl";
    _module_functions[225].return_fn_sig = NULL;
    _module_functions[225].return_type_info = NULL;
    _module_functions[225].body = NULL;
    _module_functions[225].shadow_test = NULL;
    _module_functions[225].is_extern = true;
    _module_functions[225].returns_gc_managed = false;
    _module_functions[225].requires_manual_free = false;
    _module_functions[225].returns_borrowed = false;
    _module_functions[225].cleanup_function = NULL;
    _module_functions[225].params = NULL;

    /* Function: List_ASTServiceDecl_push */
    _module_functions[226].name = "List_ASTServiceDecl_push";
    _module_functions[226].param_count = 2;
    _module_functions[226].return_type = 6;
    _module_functions[226].return_struct_type_name = NULL;
    _module_functions[226].return_fn_sig = NULL;
    _module_functions[226].return_type_info = NULL;
    _module_functions[226].body = NULL;
    _module_functions[226].shadow_test = NULL;
    _module_functions[226].is_extern = true;
    _module_functions[226].returns_gc_managed = false;
    _module_functions[226].requires_manual_free = false;
    _module_functions[226].returns_borrowed = false;
    _module_functions[226].cleanup_function = NULL;
    _module_functions[226].params = &_module_params[175];
    _module_params[175].name = "list";
    _module_params[175].type = 15;
    _module_params[175].struct_type_name = "ASTServiceDecl";
    _module_params[175].element_type = 21;
    _module_params[175].fn_sig = NULL;
    _module_params[176].name = "value";
    _module_params[176].type = 8;
    _module_params[176].struct_type_name = "ASTServiceDecl";
    _module_params[176].element_type = 21;
    _module_params[176].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_get */
    _module_functions[227].name = "List_ASTServiceDecl_get";
    _module_functions[227].param_count = 2;
    _module_functions[227].return_type = 8;
    _module_functions[227].return_struct_type_name = "ASTServiceDecl";
    _module_functions[227].return_fn_sig = NULL;
    _module_functions[227].return_type_info = NULL;
    _module_functions[227].body = NULL;
    _module_functions[227].shadow_test = NULL;
    _module_functions[227].is_extern = true;
    _module_functions[227].returns_gc_managed = false;
    _module_functions[227].requires_manual_free = false;
    _module_functions[227].returns_borrowed = false;
    _module_functions[227].cleanup_function = NULL;
    _module_functions[227].params = &_module_params[177];
    _module_params[177].name = "list";
    _module_params[177].type = 15;
    _module_params[177].struct_type_name = "ASTServiceDecl";
    _module_params[177].element_type = 21;
    _module_params[177].fn_sig = NULL;
    _module_params[178].name = "index";
    _module_params[178].type = 0;
    _module_params[178].struct_type_name = NULL;
    _module_params[178].element_type = 21;
    _module_params[178].fn_sig = NULL;

    /* Function: List_ASTServiceDecl_length */
    _module_functions[228].name = "List_ASTServiceDecl_length";
    _module_functions[228].param_count = 1;
    _module_functions[228].return_type = 0;
    _module_functions[228].return_struct_type_name = NULL;
    _module_functions[228].return_fn_sig = NULL;
    _module_functions[228].return_type_info = NULL;
    _module_functions[228].body = NULL;
    _module_functions[228].shadow_test = NULL;
    _module_functions[228].is_extern = true;
    _module_functions[228].returns_gc_managed = false;
    _module_functions[228].requires_manual_free = false;
    _module_functions[228].returns_borrowed = false;
    _module_functions[228].cleanup_function = NULL;
    _module_functions[228].params = &_module_params[179];
    _module_params[179].name = "list";
    _module_params[179].type = 15;
    _module_params[179].struct_type_name = "ASTServiceDecl";
    _module_params[179].element_type = 21;
    _module_params[179].fn_sig = NULL;

    /* Function: diag_location */
    _module_functions[229].name = "diag_location";
    _module_functions[229].param_count = 3;
    _module_functions[229].return_type = 8;
    _module_functions[229].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[229].return_fn_sig = NULL;
    _module_functions[229].return_type_info = NULL;
    _module_functions[229].body = NULL;
    _module_functions[229].shadow_test = NULL;
    _module_functions[229].is_extern = false;
    _module_functions[229].returns_gc_managed = false;
    _module_functions[229].requires_manual_free = false;
    _module_functions[229].returns_borrowed = false;
    _module_functions[229].cleanup_function = NULL;
    _module_functions[229].params = &_module_params[180];
    _module_params[180].name = "file";
    _module_params[180].type = 4;
    _module_params[180].struct_type_name = NULL;
    _module_params[180].element_type = 21;
    _module_params[180].fn_sig = NULL;
    _module_params[181].name = "line";
    _module_params[181].type = 0;
    _module_params[181].struct_type_name = NULL;
    _module_params[181].element_type = 21;
    _module_params[181].fn_sig = NULL;
    _module_params[182].name = "column";
    _module_params[182].type = 0;
    _module_params[182].struct_type_name = NULL;
    _module_params[182].element_type = 21;
    _module_params[182].fn_sig = NULL;

    /* Function: diag_location_empty */
    _module_functions[230].name = "diag_location_empty";
    _module_functions[230].param_count = 0;
    _module_functions[230].return_type = 8;
    _module_functions[230].return_struct_type_name = "CompilerSourceLocation";
    _module_functions[230].return_fn_sig = NULL;
    _module_functions[230].return_type_info = NULL;
    _module_functions[230].body = NULL;
    _module_functions[230].shadow_test = NULL;
    _module_functions[230].is_extern = false;
    _module_functions[230].returns_gc_managed = false;
    _module_functions[230].requires_manual_free = false;
    _module_functions[230].returns_borrowed = false;
    _module_functions[230].cleanup_function = NULL;
    _module_functions[230].params = NULL;

    /* Function: diag_new */
    _module_functions[231].name = "diag_new";
    _module_functions[231].param_count = 5;
    _module_functions[231].return_type = 8;
    _module_functions[231].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[231].return_fn_sig = NULL;
    _module_functions[231].return_type_info = NULL;
    _module_functions[231].body = NULL;
    _module_functions[231].shadow_test = NULL;
    _module_functions[231].is_extern = false;
    _module_functions[231].returns_gc_managed = false;
    _module_functions[231].requires_manual_free = false;
    _module_functions[231].returns_borrowed = false;
    _module_functions[231].cleanup_function = NULL;
    _module_functions[231].params = &_module_params[183];
    _module_params[183].name = "phase";
    _module_params[183].type = 0;
    _module_params[183].struct_type_name = NULL;
    _module_params[183].element_type = 21;
    _module_params[183].fn_sig = NULL;
    _module_params[184].name = "severity";
    _module_params[184].type = 0;
    _module_params[184].struct_type_name = NULL;
    _module_params[184].element_type = 21;
    _module_params[184].fn_sig = NULL;
    _module_params[185].name = "code";
    _module_params[185].type = 4;
    _module_params[185].struct_type_name = NULL;
    _module_params[185].element_type = 21;
    _module_params[185].fn_sig = NULL;
    _module_params[186].name = "message";
    _module_params[186].type = 4;
    _module_params[186].struct_type_name = NULL;
    _module_params[186].element_type = 21;
    _module_params[186].fn_sig = NULL;
    _module_params[187].name = "location";
    _module_params[187].type = 8;
    _module_params[187].struct_type_name = "CompilerSourceLocation";
    _module_params[187].element_type = 21;
    _module_params[187].fn_sig = NULL;

    /* Function: diag_simple */
    _module_functions[232].name = "diag_simple";
    _module_functions[232].param_count = 4;
    _module_functions[232].return_type = 8;
    _module_functions[232].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[232].return_fn_sig = NULL;
    _module_functions[232].return_type_info = NULL;
    _module_functions[232].body = NULL;
    _module_functions[232].shadow_test = NULL;
    _module_functions[232].is_extern = false;
    _module_functions[232].returns_gc_managed = false;
    _module_functions[232].requires_manual_free = false;
    _module_functions[232].returns_borrowed = false;
    _module_functions[232].cleanup_function = NULL;
    _module_functions[232].params = &_module_params[188];
    _module_params[188].name = "phase";
    _module_params[188].type = 0;
    _module_params[188].struct_type_name = NULL;
    _module_params[188].element_type = 21;
    _module_params[188].fn_sig = NULL;
    _module_params[189].name = "severity";
    _module_params[189].type = 0;
    _module_params[189].struct_type_name = NULL;
    _module_params[189].element_type = 21;
    _module_params[189].fn_sig = NULL;
    _module_params[190].name = "code";
    _module_params[190].type = 4;
    _module_params[190].struct_type_name = NULL;
    _module_params[190].element_type = 21;
    _module_params[190].fn_sig = NULL;
    _module_params[191].name = "message";
    _module_params[191].type = 4;
    _module_params[191].struct_type_name = NULL;
    _module_params[191].element_type = 21;
    _module_params[191].fn_sig = NULL;

    /* Function: diag_error */
    _module_functions[233].name = "diag_error";
    _module_functions[233].param_count = 4;
    _module_functions[233].return_type = 8;
    _module_functions[233].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[233].return_fn_sig = NULL;
    _module_functions[233].return_type_info = NULL;
    _module_functions[233].body = NULL;
    _module_functions[233].shadow_test = NULL;
    _module_functions[233].is_extern = false;
    _module_functions[233].returns_gc_managed = false;
    _module_functions[233].requires_manual_free = false;
    _module_functions[233].returns_borrowed = false;
    _module_functions[233].cleanup_function = NULL;
    _module_functions[233].params = &_module_params[192];
    _module_params[192].name = "phase";
    _module_params[192].type = 0;
    _module_params[192].struct_type_name = NULL;
    _module_params[192].element_type = 21;
    _module_params[192].fn_sig = NULL;
    _module_params[193].name = "code";
    _module_params[193].type = 4;
    _module_params[193].struct_type_name = NULL;
    _module_params[193].element_type = 21;
    _module_params[193].fn_sig = NULL;
    _module_params[194].name = "message";
    _module_params[194].type = 4;
    _module_params[194].struct_type_name = NULL;
    _module_params[194].element_type = 21;
    _module_params[194].fn_sig = NULL;
    _module_params[195].name = "location";
    _module_params[195].type = 8;
    _module_params[195].struct_type_name = "CompilerSourceLocation";
    _module_params[195].element_type = 21;
    _module_params[195].fn_sig = NULL;

    /* Function: diag_error_simple */
    _module_functions[234].name = "diag_error_simple";
    _module_functions[234].param_count = 3;
    _module_functions[234].return_type = 8;
    _module_functions[234].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[234].return_fn_sig = NULL;
    _module_functions[234].return_type_info = NULL;
    _module_functions[234].body = NULL;
    _module_functions[234].shadow_test = NULL;
    _module_functions[234].is_extern = false;
    _module_functions[234].returns_gc_managed = false;
    _module_functions[234].requires_manual_free = false;
    _module_functions[234].returns_borrowed = false;
    _module_functions[234].cleanup_function = NULL;
    _module_functions[234].params = &_module_params[196];
    _module_params[196].name = "phase";
    _module_params[196].type = 0;
    _module_params[196].struct_type_name = NULL;
    _module_params[196].element_type = 21;
    _module_params[196].fn_sig = NULL;
    _module_params[197].name = "code";
    _module_params[197].type = 4;
    _module_params[197].struct_type_name = NULL;
    _module_params[197].element_type = 21;
    _module_params[197].fn_sig = NULL;
    _module_params[198].name = "message";
    _module_params[198].type = 4;
    _module_params[198].struct_type_name = NULL;
    _module_params[198].element_type = 21;
    _module_params[198].fn_sig = NULL;

    /* Function: diag_warning */
    _module_functions[235].name = "diag_warning";
    _module_functions[235].param_count = 4;
    _module_functions[235].return_type = 8;
    _module_functions[235].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[235].return_fn_sig = NULL;
    _module_functions[235].return_type_info = NULL;
    _module_functions[235].body = NULL;
    _module_functions[235].shadow_test = NULL;
    _module_functions[235].is_extern = false;
    _module_functions[235].returns_gc_managed = false;
    _module_functions[235].requires_manual_free = false;
    _module_functions[235].returns_borrowed = false;
    _module_functions[235].cleanup_function = NULL;
    _module_functions[235].params = &_module_params[199];
    _module_params[199].name = "phase";
    _module_params[199].type = 0;
    _module_params[199].struct_type_name = NULL;
    _module_params[199].element_type = 21;
    _module_params[199].fn_sig = NULL;
    _module_params[200].name = "code";
    _module_params[200].type = 4;
    _module_params[200].struct_type_name = NULL;
    _module_params[200].element_type = 21;
    _module_params[200].fn_sig = NULL;
    _module_params[201].name = "message";
    _module_params[201].type = 4;
    _module_params[201].struct_type_name = NULL;
    _module_params[201].element_type = 21;
    _module_params[201].fn_sig = NULL;
    _module_params[202].name = "location";
    _module_params[202].type = 8;
    _module_params[202].struct_type_name = "CompilerSourceLocation";
    _module_params[202].element_type = 21;
    _module_params[202].fn_sig = NULL;

    /* Function: diag_warning_simple */
    _module_functions[236].name = "diag_warning_simple";
    _module_functions[236].param_count = 3;
    _module_functions[236].return_type = 8;
    _module_functions[236].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[236].return_fn_sig = NULL;
    _module_functions[236].return_type_info = NULL;
    _module_functions[236].body = NULL;
    _module_functions[236].shadow_test = NULL;
    _module_functions[236].is_extern = false;
    _module_functions[236].returns_gc_managed = false;
    _module_functions[236].requires_manual_free = false;
    _module_functions[236].returns_borrowed = false;
    _module_functions[236].cleanup_function = NULL;
    _module_functions[236].params = &_module_params[203];
    _module_params[203].name = "phase";
    _module_params[203].type = 0;
    _module_params[203].struct_type_name = NULL;
    _module_params[203].element_type = 21;
    _module_params[203].fn_sig = NULL;
    _module_params[204].name = "code";
    _module_params[204].type = 4;
    _module_params[204].struct_type_name = NULL;
    _module_params[204].element_type = 21;
    _module_params[204].fn_sig = NULL;
    _module_params[205].name = "message";
    _module_params[205].type = 4;
    _module_params[205].struct_type_name = NULL;
    _module_params[205].element_type = 21;
    _module_params[205].fn_sig = NULL;

    /* Function: diag_info */
    _module_functions[237].name = "diag_info";
    _module_functions[237].param_count = 4;
    _module_functions[237].return_type = 8;
    _module_functions[237].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[237].return_fn_sig = NULL;
    _module_functions[237].return_type_info = NULL;
    _module_functions[237].body = NULL;
    _module_functions[237].shadow_test = NULL;
    _module_functions[237].is_extern = false;
    _module_functions[237].returns_gc_managed = false;
    _module_functions[237].requires_manual_free = false;
    _module_functions[237].returns_borrowed = false;
    _module_functions[237].cleanup_function = NULL;
    _module_functions[237].params = &_module_params[206];
    _module_params[206].name = "phase";
    _module_params[206].type = 0;
    _module_params[206].struct_type_name = NULL;
    _module_params[206].element_type = 21;
    _module_params[206].fn_sig = NULL;
    _module_params[207].name = "code";
    _module_params[207].type = 4;
    _module_params[207].struct_type_name = NULL;
    _module_params[207].element_type = 21;
    _module_params[207].fn_sig = NULL;
    _module_params[208].name = "message";
    _module_params[208].type = 4;
    _module_params[208].struct_type_name = NULL;
    _module_params[208].element_type = 21;
    _module_params[208].fn_sig = NULL;
    _module_params[209].name = "location";
    _module_params[209].type = 8;
    _module_params[209].struct_type_name = "CompilerSourceLocation";
    _module_params[209].element_type = 21;
    _module_params[209].fn_sig = NULL;

    /* Function: diag_info_simple */
    _module_functions[238].name = "diag_info_simple";
    _module_functions[238].param_count = 3;
    _module_functions[238].return_type = 8;
    _module_functions[238].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[238].return_fn_sig = NULL;
    _module_functions[238].return_type_info = NULL;
    _module_functions[238].body = NULL;
    _module_functions[238].shadow_test = NULL;
    _module_functions[238].is_extern = false;
    _module_functions[238].returns_gc_managed = false;
    _module_functions[238].requires_manual_free = false;
    _module_functions[238].returns_borrowed = false;
    _module_functions[238].cleanup_function = NULL;
    _module_functions[238].params = &_module_params[210];
    _module_params[210].name = "phase";
    _module_params[210].type = 0;
    _module_params[210].struct_type_name = NULL;
    _module_params[210].element_type = 21;
    _module_params[210].fn_sig = NULL;
    _module_params[211].name = "code";
    _module_params[211].type = 4;
    _module_params[211].struct_type_name = NULL;
    _module_params[211].element_type = 21;
    _module_params[211].fn_sig = NULL;
    _module_params[212].name = "message";
    _module_params[212].type = 4;
    _module_params[212].struct_type_name = NULL;
    _module_params[212].element_type = 21;
    _module_params[212].fn_sig = NULL;

    /* Function: diag_lexer_error */
    _module_functions[239].name = "diag_lexer_error";
    _module_functions[239].param_count = 3;
    _module_functions[239].return_type = 8;
    _module_functions[239].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[239].return_fn_sig = NULL;
    _module_functions[239].return_type_info = NULL;
    _module_functions[239].body = NULL;
    _module_functions[239].shadow_test = NULL;
    _module_functions[239].is_extern = false;
    _module_functions[239].returns_gc_managed = false;
    _module_functions[239].requires_manual_free = false;
    _module_functions[239].returns_borrowed = false;
    _module_functions[239].cleanup_function = NULL;
    _module_functions[239].params = &_module_params[213];
    _module_params[213].name = "code";
    _module_params[213].type = 4;
    _module_params[213].struct_type_name = NULL;
    _module_params[213].element_type = 21;
    _module_params[213].fn_sig = NULL;
    _module_params[214].name = "message";
    _module_params[214].type = 4;
    _module_params[214].struct_type_name = NULL;
    _module_params[214].element_type = 21;
    _module_params[214].fn_sig = NULL;
    _module_params[215].name = "location";
    _module_params[215].type = 8;
    _module_params[215].struct_type_name = "CompilerSourceLocation";
    _module_params[215].element_type = 21;
    _module_params[215].fn_sig = NULL;

    /* Function: diag_parser_error */
    _module_functions[240].name = "diag_parser_error";
    _module_functions[240].param_count = 3;
    _module_functions[240].return_type = 8;
    _module_functions[240].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[240].return_fn_sig = NULL;
    _module_functions[240].return_type_info = NULL;
    _module_functions[240].body = NULL;
    _module_functions[240].shadow_test = NULL;
    _module_functions[240].is_extern = false;
    _module_functions[240].returns_gc_managed = false;
    _module_functions[240].requires_manual_free = false;
    _module_functions[240].returns_borrowed = false;
    _module_functions[240].cleanup_function = NULL;
    _module_functions[240].params = &_module_params[216];
    _module_params[216].name = "code";
    _module_params[216].type = 4;
    _module_params[216].struct_type_name = NULL;
    _module_params[216].element_type = 21;
    _module_params[216].fn_sig = NULL;
    _module_params[217].name = "message";
    _module_params[217].type = 4;
    _module_params[217].struct_type_name = NULL;
    _module_params[217].element_type = 21;
    _module_params[217].fn_sig = NULL;
    _module_params[218].name = "location";
    _module_params[218].type = 8;
    _module_params[218].struct_type_name = "CompilerSourceLocation";
    _module_params[218].element_type = 21;
    _module_params[218].fn_sig = NULL;

    /* Function: diag_typecheck_error */
    _module_functions[241].name = "diag_typecheck_error";
    _module_functions[241].param_count = 3;
    _module_functions[241].return_type = 8;
    _module_functions[241].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[241].return_fn_sig = NULL;
    _module_functions[241].return_type_info = NULL;
    _module_functions[241].body = NULL;
    _module_functions[241].shadow_test = NULL;
    _module_functions[241].is_extern = false;
    _module_functions[241].returns_gc_managed = false;
    _module_functions[241].requires_manual_free = false;
    _module_functions[241].returns_borrowed = false;
    _module_functions[241].cleanup_function = NULL;
    _module_functions[241].params = &_module_params[219];
    _module_params[219].name = "code";
    _module_params[219].type = 4;
    _module_params[219].struct_type_name = NULL;
    _module_params[219].element_type = 21;
    _module_params[219].fn_sig = NULL;
    _module_params[220].name = "message";
    _module_params[220].type = 4;
    _module_params[220].struct_type_name = NULL;
    _module_params[220].element_type = 21;
    _module_params[220].fn_sig = NULL;
    _module_params[221].name = "location";
    _module_params[221].type = 8;
    _module_params[221].struct_type_name = "CompilerSourceLocation";
    _module_params[221].element_type = 21;
    _module_params[221].fn_sig = NULL;

    /* Function: diag_transpiler_error */
    _module_functions[242].name = "diag_transpiler_error";
    _module_functions[242].param_count = 3;
    _module_functions[242].return_type = 8;
    _module_functions[242].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[242].return_fn_sig = NULL;
    _module_functions[242].return_type_info = NULL;
    _module_functions[242].body = NULL;
    _module_functions[242].shadow_test = NULL;
    _module_functions[242].is_extern = false;
    _module_functions[242].returns_gc_managed = false;
    _module_functions[242].requires_manual_free = false;
    _module_functions[242].returns_borrowed = false;
    _module_functions[242].cleanup_function = NULL;
    _module_functions[242].params = &_module_params[222];
    _module_params[222].name = "code";
    _module_params[222].type = 4;
    _module_params[222].struct_type_name = NULL;
    _module_params[222].element_type = 21;
    _module_params[222].fn_sig = NULL;
    _module_params[223].name = "message";
    _module_params[223].type = 4;
    _module_params[223].struct_type_name = NULL;
    _module_params[223].element_type = 21;
    _module_params[223].fn_sig = NULL;
    _module_params[224].name = "location";
    _module_params[224].type = 8;
    _module_params[224].struct_type_name = "CompilerSourceLocation";
    _module_params[224].element_type = 21;
    _module_params[224].fn_sig = NULL;

    /* Function: diag_list_new */
    _module_functions[243].name = "diag_list_new";
    _module_functions[243].param_count = 0;
    _module_functions[243].return_type = 15;
    _module_functions[243].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[243].return_fn_sig = NULL;
    _module_functions[243].return_type_info = NULL;
    _module_functions[243].body = NULL;
    _module_functions[243].shadow_test = NULL;
    _module_functions[243].is_extern = false;
    _module_functions[243].returns_gc_managed = false;
    _module_functions[243].requires_manual_free = false;
    _module_functions[243].returns_borrowed = false;
    _module_functions[243].cleanup_function = NULL;
    _module_functions[243].params = NULL;

    /* Function: diag_list_add */
    _module_functions[244].name = "diag_list_add";
    _module_functions[244].param_count = 2;
    _module_functions[244].return_type = 6;
    _module_functions[244].return_struct_type_name = NULL;
    _module_functions[244].return_fn_sig = NULL;
    _module_functions[244].return_type_info = NULL;
    _module_functions[244].body = NULL;
    _module_functions[244].shadow_test = NULL;
    _module_functions[244].is_extern = false;
    _module_functions[244].returns_gc_managed = false;
    _module_functions[244].requires_manual_free = false;
    _module_functions[244].returns_borrowed = false;
    _module_functions[244].cleanup_function = NULL;
    _module_functions[244].params = &_module_params[225];
    _module_params[225].name = "list";
    _module_params[225].type = 15;
    _module_params[225].struct_type_name = "CompilerDiagnostic";
    _module_params[225].element_type = 21;
    _module_params[225].fn_sig = NULL;
    _module_params[226].name = "diag";
    _module_params[226].type = 8;
    _module_params[226].struct_type_name = "CompilerDiagnostic";
    _module_params[226].element_type = 21;
    _module_params[226].fn_sig = NULL;

    /* Function: diag_list_count */
    _module_functions[245].name = "diag_list_count";
    _module_functions[245].param_count = 1;
    _module_functions[245].return_type = 0;
    _module_functions[245].return_struct_type_name = NULL;
    _module_functions[245].return_fn_sig = NULL;
    _module_functions[245].return_type_info = NULL;
    _module_functions[245].body = NULL;
    _module_functions[245].shadow_test = NULL;
    _module_functions[245].is_extern = false;
    _module_functions[245].returns_gc_managed = false;
    _module_functions[245].requires_manual_free = false;
    _module_functions[245].returns_borrowed = false;
    _module_functions[245].cleanup_function = NULL;
    _module_functions[245].params = &_module_params[227];
    _module_params[227].name = "list";
    _module_params[227].type = 15;
    _module_params[227].struct_type_name = "CompilerDiagnostic";
    _module_params[227].element_type = 21;
    _module_params[227].fn_sig = NULL;

    /* Function: diag_list_get */
    _module_functions[246].name = "diag_list_get";
    _module_functions[246].param_count = 2;
    _module_functions[246].return_type = 8;
    _module_functions[246].return_struct_type_name = "CompilerDiagnostic";
    _module_functions[246].return_fn_sig = NULL;
    _module_functions[246].return_type_info = NULL;
    _module_functions[246].body = NULL;
    _module_functions[246].shadow_test = NULL;
    _module_functions[246].is_extern = false;
    _module_functions[246].returns_gc_managed = false;
    _module_functions[246].requires_manual_free = false;
    _module_functions[246].returns_borrowed = false;
    _module_functions[246].cleanup_function = NULL;
    _module_functions[246].params = &_module_params[228];
    _module_params[228].name = "list";
    _module_params[228].type = 15;
    _module_params[228].struct_type_name = "CompilerDiagnostic";
    _module_params[228].element_type = 21;
    _module_params[228].fn_sig = NULL;
    _module_params[229].name = "index";
    _module_params[229].type = 0;
    _module_params[229].struct_type_name = NULL;
    _module_params[229].element_type = 21;
    _module_params[229].fn_sig = NULL;

    /* Function: diag_list_has_errors */
    _module_functions[247].name = "diag_list_has_errors";
    _module_functions[247].param_count = 1;
    _module_functions[247].return_type = 3;
    _module_functions[247].return_struct_type_name = NULL;
    _module_functions[247].return_fn_sig = NULL;
    _module_functions[247].return_type_info = NULL;
    _module_functions[247].body = NULL;
    _module_functions[247].shadow_test = NULL;
    _module_functions[247].is_extern = false;
    _module_functions[247].returns_gc_managed = false;
    _module_functions[247].requires_manual_free = false;
    _module_functions[247].returns_borrowed = false;
    _module_functions[247].cleanup_function = NULL;
    _module_functions[247].params = &_module_params[230];
    _module_params[230].name = "list";
    _module_params[230].type = 15;
    _module_params[230].struct_type_name = "CompilerDiagnostic";
    _module_params[230].element_type = 21;
    _module_params[230].fn_sig = NULL;

    /* Function: diag_make_type_error */
    _module_functions[248].name = "diag_make_type_error";
    _module_functions[248].param_count = 2;
    _module_functions[248].return_type = 4;
    _module_functions[248].return_struct_type_name = NULL;
    _module_functions[248].return_fn_sig = NULL;
    _module_functions[248].return_type_info = NULL;
    _module_functions[248].body = NULL;
    _module_functions[248].shadow_test = NULL;
    _module_functions[248].is_extern = false;
    _module_functions[248].returns_gc_managed = true;
    _module_functions[248].requires_manual_free = false;
    _module_functions[248].returns_borrowed = false;
    _module_functions[248].cleanup_function = NULL;
    _module_functions[248].params = &_module_params[231];
    _module_params[231].name = "expected_type";
    _module_params[231].type = 4;
    _module_params[231].struct_type_name = NULL;
    _module_params[231].element_type = 21;
    _module_params[231].fn_sig = NULL;
    _module_params[232].name = "found_type";
    _module_params[232].type = 4;
    _module_params[232].struct_type_name = NULL;
    _module_params[232].element_type = 21;
    _module_params[232].fn_sig = NULL;

    /* Function: diag_make_undefined_error */
    _module_functions[249].name = "diag_make_undefined_error";
    _module_functions[249].param_count = 1;
    _module_functions[249].return_type = 4;
    _module_functions[249].return_struct_type_name = NULL;
    _module_functions[249].return_fn_sig = NULL;
    _module_functions[249].return_type_info = NULL;
    _module_functions[249].body = NULL;
    _module_functions[249].shadow_test = NULL;
    _module_functions[249].is_extern = false;
    _module_functions[249].returns_gc_managed = true;
    _module_functions[249].requires_manual_free = false;
    _module_functions[249].returns_borrowed = false;
    _module_functions[249].cleanup_function = NULL;
    _module_functions[249].params = &_module_params[233];
    _module_params[233].name = "name";
    _module_params[233].type = 4;
    _module_params[233].struct_type_name = NULL;
    _module_params[233].element_type = 21;
    _module_params[233].fn_sig = NULL;

    /* Function: diag_id_io_open */
    _module_functions[250].name = "diag_id_io_open";
    _module_functions[250].param_count = 0;
    _module_functions[250].return_type = 4;
    _module_functions[250].return_struct_type_name = NULL;
    _module_functions[250].return_fn_sig = NULL;
    _module_functions[250].return_type_info = NULL;
    _module_functions[250].body = NULL;
    _module_functions[250].shadow_test = NULL;
    _module_functions[250].is_extern = false;
    _module_functions[250].returns_gc_managed = true;
    _module_functions[250].requires_manual_free = false;
    _module_functions[250].returns_borrowed = false;
    _module_functions[250].cleanup_function = NULL;
    _module_functions[250].params = NULL;

    /* Function: diag_id_lex_failed */
    _module_functions[251].name = "diag_id_lex_failed";
    _module_functions[251].param_count = 0;
    _module_functions[251].return_type = 4;
    _module_functions[251].return_struct_type_name = NULL;
    _module_functions[251].return_fn_sig = NULL;
    _module_functions[251].return_type_info = NULL;
    _module_functions[251].body = NULL;
    _module_functions[251].shadow_test = NULL;
    _module_functions[251].is_extern = false;
    _module_functions[251].returns_gc_managed = true;
    _module_functions[251].requires_manual_free = false;
    _module_functions[251].returns_borrowed = false;
    _module_functions[251].cleanup_function = NULL;
    _module_functions[251].params = NULL;

    /* Function: diag_id_parse_failed */
    _module_functions[252].name = "diag_id_parse_failed";
    _module_functions[252].param_count = 0;
    _module_functions[252].return_type = 4;
    _module_functions[252].return_struct_type_name = NULL;
    _module_functions[252].return_fn_sig = NULL;
    _module_functions[252].return_type_info = NULL;
    _module_functions[252].body = NULL;
    _module_functions[252].shadow_test = NULL;
    _module_functions[252].is_extern = false;
    _module_functions[252].returns_gc_managed = true;
    _module_functions[252].requires_manual_free = false;
    _module_functions[252].returns_borrowed = false;
    _module_functions[252].cleanup_function = NULL;
    _module_functions[252].params = NULL;

    /* Function: diag_id_import_failed */
    _module_functions[253].name = "diag_id_import_failed";
    _module_functions[253].param_count = 0;
    _module_functions[253].return_type = 4;
    _module_functions[253].return_struct_type_name = NULL;
    _module_functions[253].return_fn_sig = NULL;
    _module_functions[253].return_type_info = NULL;
    _module_functions[253].body = NULL;
    _module_functions[253].shadow_test = NULL;
    _module_functions[253].is_extern = false;
    _module_functions[253].returns_gc_managed = true;
    _module_functions[253].requires_manual_free = false;
    _module_functions[253].returns_borrowed = false;
    _module_functions[253].cleanup_function = NULL;
    _module_functions[253].params = NULL;

    /* Function: diag_id_type_failed */
    _module_functions[254].name = "diag_id_type_failed";
    _module_functions[254].param_count = 0;
    _module_functions[254].return_type = 4;
    _module_functions[254].return_struct_type_name = NULL;
    _module_functions[254].return_fn_sig = NULL;
    _module_functions[254].return_type_info = NULL;
    _module_functions[254].body = NULL;
    _module_functions[254].shadow_test = NULL;
    _module_functions[254].is_extern = false;
    _module_functions[254].returns_gc_managed = true;
    _module_functions[254].requires_manual_free = false;
    _module_functions[254].returns_borrowed = false;
    _module_functions[254].cleanup_function = NULL;
    _module_functions[254].params = NULL;

    /* Function: diag_id_mod_compile */
    _module_functions[255].name = "diag_id_mod_compile";
    _module_functions[255].param_count = 0;
    _module_functions[255].return_type = 4;
    _module_functions[255].return_struct_type_name = NULL;
    _module_functions[255].return_fn_sig = NULL;
    _module_functions[255].return_type_info = NULL;
    _module_functions[255].body = NULL;
    _module_functions[255].shadow_test = NULL;
    _module_functions[255].is_extern = false;
    _module_functions[255].returns_gc_managed = true;
    _module_functions[255].requires_manual_free = false;
    _module_functions[255].returns_borrowed = false;
    _module_functions[255].cleanup_function = NULL;
    _module_functions[255].params = NULL;

    /* Function: diag_id_shadow_failed */
    _module_functions[256].name = "diag_id_shadow_failed";
    _module_functions[256].param_count = 0;
    _module_functions[256].return_type = 4;
    _module_functions[256].return_struct_type_name = NULL;
    _module_functions[256].return_fn_sig = NULL;
    _module_functions[256].return_type_info = NULL;
    _module_functions[256].body = NULL;
    _module_functions[256].shadow_test = NULL;
    _module_functions[256].is_extern = false;
    _module_functions[256].returns_gc_managed = true;
    _module_functions[256].requires_manual_free = false;
    _module_functions[256].returns_borrowed = false;
    _module_functions[256].cleanup_function = NULL;
    _module_functions[256].params = NULL;

    /* Function: diag_id_trans_failed */
    _module_functions[257].name = "diag_id_trans_failed";
    _module_functions[257].param_count = 0;
    _module_functions[257].return_type = 4;
    _module_functions[257].return_struct_type_name = NULL;
    _module_functions[257].return_fn_sig = NULL;
    _module_functions[257].return_type_info = NULL;
    _module_functions[257].body = NULL;
    _module_functions[257].shadow_test = NULL;
    _module_functions[257].is_extern = false;
    _module_functions[257].returns_gc_managed = true;
    _module_functions[257].requires_manual_free = false;
    _module_functions[257].returns_borrowed = false;
    _module_functions[257].cleanup_function = NULL;
    _module_functions[257].params = NULL;

    /* Function: diag_id_c_temp */
    _module_functions[258].name = "diag_id_c_temp";
    _module_functions[258].param_count = 0;
    _module_functions[258].return_type = 4;
    _module_functions[258].return_struct_type_name = NULL;
    _module_functions[258].return_fn_sig = NULL;
    _module_functions[258].return_type_info = NULL;
    _module_functions[258].body = NULL;
    _module_functions[258].shadow_test = NULL;
    _module_functions[258].is_extern = false;
    _module_functions[258].returns_gc_managed = true;
    _module_functions[258].requires_manual_free = false;
    _module_functions[258].returns_borrowed = false;
    _module_functions[258].cleanup_function = NULL;
    _module_functions[258].params = NULL;

    /* Function: diag_id_cc_cmd */
    _module_functions[259].name = "diag_id_cc_cmd";
    _module_functions[259].param_count = 0;
    _module_functions[259].return_type = 4;
    _module_functions[259].return_struct_type_name = NULL;
    _module_functions[259].return_fn_sig = NULL;
    _module_functions[259].return_type_info = NULL;
    _module_functions[259].body = NULL;
    _module_functions[259].shadow_test = NULL;
    _module_functions[259].is_extern = false;
    _module_functions[259].returns_gc_managed = true;
    _module_functions[259].requires_manual_free = false;
    _module_functions[259].returns_borrowed = false;
    _module_functions[259].cleanup_function = NULL;
    _module_functions[259].params = NULL;

    /* Function: diag_id_cc_failed */
    _module_functions[260].name = "diag_id_cc_failed";
    _module_functions[260].param_count = 0;
    _module_functions[260].return_type = 4;
    _module_functions[260].return_struct_type_name = NULL;
    _module_functions[260].return_fn_sig = NULL;
    _module_functions[260].return_type_info = NULL;
    _module_functions[260].body = NULL;
    _module_functions[260].shadow_test = NULL;
    _module_functions[260].is_extern = false;
    _module_functions[260].returns_gc_managed = true;
    _module_functions[260].requires_manual_free = false;
    _module_functions[260].returns_borrowed = false;
    _module_functions[260].cleanup_function = NULL;
    _module_functions[260].params = NULL;

    /* Function: diag_id_src_utf8 */
    _module_functions[261].name = "diag_id_src_utf8";
    _module_functions[261].param_count = 0;
    _module_functions[261].return_type = 4;
    _module_functions[261].return_struct_type_name = NULL;
    _module_functions[261].return_fn_sig = NULL;
    _module_functions[261].return_type_info = NULL;
    _module_functions[261].body = NULL;
    _module_functions[261].shadow_test = NULL;
    _module_functions[261].is_extern = false;
    _module_functions[261].returns_gc_managed = true;
    _module_functions[261].requires_manual_free = false;
    _module_functions[261].returns_borrowed = false;
    _module_functions[261].cleanup_function = NULL;
    _module_functions[261].params = NULL;

    /* Function: diag_en */
    _module_functions[262].name = "diag_en";
    _module_functions[262].param_count = 1;
    _module_functions[262].return_type = 4;
    _module_functions[262].return_struct_type_name = NULL;
    _module_functions[262].return_fn_sig = NULL;
    _module_functions[262].return_type_info = NULL;
    _module_functions[262].body = NULL;
    _module_functions[262].shadow_test = NULL;
    _module_functions[262].is_extern = false;
    _module_functions[262].returns_gc_managed = true;
    _module_functions[262].requires_manual_free = false;
    _module_functions[262].returns_borrowed = false;
    _module_functions[262].cleanup_function = NULL;
    _module_functions[262].params = &_module_params[234];
    _module_params[234].name = "code";
    _module_params[234].type = 4;
    _module_params[234].struct_type_name = NULL;
    _module_params[234].element_type = 21;
    _module_params[234].fn_sig = NULL;

    /* Function: error_message_new */
    _module_functions[263].name = "error_message_new";
    _module_functions[263].param_count = 4;
    _module_functions[263].return_type = 8;
    _module_functions[263].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[263].return_fn_sig = NULL;
    _module_functions[263].return_type_info = NULL;
    _module_functions[263].body = NULL;
    _module_functions[263].shadow_test = NULL;
    _module_functions[263].is_extern = false;
    _module_functions[263].returns_gc_managed = false;
    _module_functions[263].requires_manual_free = false;
    _module_functions[263].returns_borrowed = false;
    _module_functions[263].cleanup_function = NULL;
    _module_functions[263].params = &_module_params[235];
    _module_params[235].name = "title";
    _module_params[235].type = 4;
    _module_params[235].struct_type_name = NULL;
    _module_params[235].element_type = 21;
    _module_params[235].fn_sig = NULL;
    _module_params[236].name = "file";
    _module_params[236].type = 4;
    _module_params[236].struct_type_name = NULL;
    _module_params[236].element_type = 21;
    _module_params[236].fn_sig = NULL;
    _module_params[237].name = "line";
    _module_params[237].type = 0;
    _module_params[237].struct_type_name = NULL;
    _module_params[237].element_type = 21;
    _module_params[237].fn_sig = NULL;
    _module_params[238].name = "column";
    _module_params[238].type = 0;
    _module_params[238].struct_type_name = NULL;
    _module_params[238].element_type = 21;
    _module_params[238].fn_sig = NULL;

    /* Function: repeat_string */
    _module_functions[264].name = "repeat_string";
    _module_functions[264].param_count = 2;
    _module_functions[264].return_type = 4;
    _module_functions[264].return_struct_type_name = NULL;
    _module_functions[264].return_fn_sig = NULL;
    _module_functions[264].return_type_info = NULL;
    _module_functions[264].body = NULL;
    _module_functions[264].shadow_test = NULL;
    _module_functions[264].is_extern = false;
    _module_functions[264].returns_gc_managed = true;
    _module_functions[264].requires_manual_free = false;
    _module_functions[264].returns_borrowed = false;
    _module_functions[264].cleanup_function = NULL;
    _module_functions[264].params = &_module_params[239];
    _module_params[239].name = "s";
    _module_params[239].type = 4;
    _module_params[239].struct_type_name = NULL;
    _module_params[239].element_type = 21;
    _module_params[239].fn_sig = NULL;
    _module_params[240].name = "count";
    _module_params[240].type = 0;
    _module_params[240].struct_type_name = NULL;
    _module_params[240].element_type = 21;
    _module_params[240].fn_sig = NULL;

    /* Function: pad_right */
    _module_functions[265].name = "pad_right";
    _module_functions[265].param_count = 2;
    _module_functions[265].return_type = 4;
    _module_functions[265].return_struct_type_name = NULL;
    _module_functions[265].return_fn_sig = NULL;
    _module_functions[265].return_type_info = NULL;
    _module_functions[265].body = NULL;
    _module_functions[265].shadow_test = NULL;
    _module_functions[265].is_extern = false;
    _module_functions[265].returns_gc_managed = true;
    _module_functions[265].requires_manual_free = false;
    _module_functions[265].returns_borrowed = false;
    _module_functions[265].cleanup_function = NULL;
    _module_functions[265].params = &_module_params[241];
    _module_params[241].name = "s";
    _module_params[241].type = 4;
    _module_params[241].struct_type_name = NULL;
    _module_params[241].element_type = 21;
    _module_params[241].fn_sig = NULL;
    _module_params[242].name = "target_len";
    _module_params[242].type = 0;
    _module_params[242].struct_type_name = NULL;
    _module_params[242].element_type = 21;
    _module_params[242].fn_sig = NULL;

    /* Function: wrap_backticks */
    _module_functions[266].name = "wrap_backticks";
    _module_functions[266].param_count = 1;
    _module_functions[266].return_type = 4;
    _module_functions[266].return_struct_type_name = NULL;
    _module_functions[266].return_fn_sig = NULL;
    _module_functions[266].return_type_info = NULL;
    _module_functions[266].body = NULL;
    _module_functions[266].shadow_test = NULL;
    _module_functions[266].is_extern = false;
    _module_functions[266].returns_gc_managed = true;
    _module_functions[266].requires_manual_free = false;
    _module_functions[266].returns_borrowed = false;
    _module_functions[266].cleanup_function = NULL;
    _module_functions[266].params = &_module_params[243];
    _module_params[243].name = "value";
    _module_params[243].type = 4;
    _module_params[243].struct_type_name = NULL;
    _module_params[243].element_type = 21;
    _module_params[243].fn_sig = NULL;

    /* Function: get_line_from_source */
    _module_functions[267].name = "get_line_from_source";
    _module_functions[267].param_count = 2;
    _module_functions[267].return_type = 4;
    _module_functions[267].return_struct_type_name = NULL;
    _module_functions[267].return_fn_sig = NULL;
    _module_functions[267].return_type_info = NULL;
    _module_functions[267].body = NULL;
    _module_functions[267].shadow_test = NULL;
    _module_functions[267].is_extern = false;
    _module_functions[267].returns_gc_managed = true;
    _module_functions[267].requires_manual_free = false;
    _module_functions[267].returns_borrowed = false;
    _module_functions[267].cleanup_function = NULL;
    _module_functions[267].params = &_module_params[244];
    _module_params[244].name = "source";
    _module_params[244].type = 4;
    _module_params[244].struct_type_name = NULL;
    _module_params[244].element_type = 21;
    _module_params[244].fn_sig = NULL;
    _module_params[245].name = "target_line";
    _module_params[245].type = 0;
    _module_params[245].struct_type_name = NULL;
    _module_params[245].element_type = 21;
    _module_params[245].fn_sig = NULL;

    /* Function: format_error_elm_style */
    _module_functions[268].name = "format_error_elm_style";
    _module_functions[268].param_count = 2;
    _module_functions[268].return_type = 4;
    _module_functions[268].return_struct_type_name = NULL;
    _module_functions[268].return_fn_sig = NULL;
    _module_functions[268].return_type_info = NULL;
    _module_functions[268].body = NULL;
    _module_functions[268].shadow_test = NULL;
    _module_functions[268].is_extern = false;
    _module_functions[268].returns_gc_managed = true;
    _module_functions[268].requires_manual_free = false;
    _module_functions[268].returns_borrowed = false;
    _module_functions[268].cleanup_function = NULL;
    _module_functions[268].params = &_module_params[246];
    _module_params[246].name = "err";
    _module_params[246].type = 8;
    _module_params[246].struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_params[246].element_type = 21;
    _module_params[246].fn_sig = NULL;
    _module_params[247].name = "source";
    _module_params[247].type = 4;
    _module_params[247].struct_type_name = NULL;
    _module_params[247].element_type = 21;
    _module_params[247].fn_sig = NULL;

    /* Function: build_error_explanations */
    _module_functions[269].name = "build_error_explanations";
    _module_functions[269].param_count = 0;
    _module_functions[269].return_type = 16;
    _module_functions[269].return_struct_type_name = NULL;
    _module_functions[269].return_fn_sig = NULL;
    _module_functions[269].return_type_info = &_type_infos[0];
    _module_functions[269].body = NULL;
    _module_functions[269].shadow_test = NULL;
    _module_functions[269].is_extern = false;
    _module_functions[269].returns_gc_managed = false;
    _module_functions[269].requires_manual_free = false;
    _module_functions[269].returns_borrowed = false;
    _module_functions[269].cleanup_function = NULL;
    _module_functions[269].params = NULL;

    /* Function: build_error_suggestions */
    _module_functions[270].name = "build_error_suggestions";
    _module_functions[270].param_count = 0;
    _module_functions[270].return_type = 16;
    _module_functions[270].return_struct_type_name = NULL;
    _module_functions[270].return_fn_sig = NULL;
    _module_functions[270].return_type_info = &_type_infos[1];
    _module_functions[270].body = NULL;
    _module_functions[270].shadow_test = NULL;
    _module_functions[270].is_extern = false;
    _module_functions[270].returns_gc_managed = false;
    _module_functions[270].requires_manual_free = false;
    _module_functions[270].returns_borrowed = false;
    _module_functions[270].cleanup_function = NULL;
    _module_functions[270].params = NULL;

    /* Function: explanation_for_code */
    _module_functions[271].name = "explanation_for_code";
    _module_functions[271].param_count = 1;
    _module_functions[271].return_type = 4;
    _module_functions[271].return_struct_type_name = NULL;
    _module_functions[271].return_fn_sig = NULL;
    _module_functions[271].return_type_info = NULL;
    _module_functions[271].body = NULL;
    _module_functions[271].shadow_test = NULL;
    _module_functions[271].is_extern = false;
    _module_functions[271].returns_gc_managed = true;
    _module_functions[271].requires_manual_free = false;
    _module_functions[271].returns_borrowed = false;
    _module_functions[271].cleanup_function = NULL;
    _module_functions[271].params = &_module_params[248];
    _module_params[248].name = "code";
    _module_params[248].type = 4;
    _module_params[248].struct_type_name = NULL;
    _module_params[248].element_type = 21;
    _module_params[248].fn_sig = NULL;

    /* Function: suggestion_for_code */
    _module_functions[272].name = "suggestion_for_code";
    _module_functions[272].param_count = 1;
    _module_functions[272].return_type = 4;
    _module_functions[272].return_struct_type_name = NULL;
    _module_functions[272].return_fn_sig = NULL;
    _module_functions[272].return_type_info = NULL;
    _module_functions[272].body = NULL;
    _module_functions[272].shadow_test = NULL;
    _module_functions[272].is_extern = false;
    _module_functions[272].returns_gc_managed = true;
    _module_functions[272].requires_manual_free = false;
    _module_functions[272].returns_borrowed = false;
    _module_functions[272].cleanup_function = NULL;
    _module_functions[272].params = &_module_params[249];
    _module_params[249].name = "code";
    _module_params[249].type = 4;
    _module_params[249].struct_type_name = NULL;
    _module_params[249].element_type = 21;
    _module_params[249].fn_sig = NULL;

    /* Function: diagnostic_to_elm_error */
    _module_functions[273].name = "diagnostic_to_elm_error";
    _module_functions[273].param_count = 1;
    _module_functions[273].return_type = 8;
    _module_functions[273].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[273].return_fn_sig = NULL;
    _module_functions[273].return_type_info = NULL;
    _module_functions[273].body = NULL;
    _module_functions[273].shadow_test = NULL;
    _module_functions[273].is_extern = false;
    _module_functions[273].returns_gc_managed = false;
    _module_functions[273].requires_manual_free = false;
    _module_functions[273].returns_borrowed = false;
    _module_functions[273].cleanup_function = NULL;
    _module_functions[273].params = &_module_params[250];
    _module_params[250].name = "diag";
    _module_params[250].type = 8;
    _module_params[250].struct_type_name = "CompilerDiagnostic";
    _module_params[250].element_type = 21;
    _module_params[250].fn_sig = NULL;

    /* Function: format_diagnostics_elm_style */
    _module_functions[274].name = "format_diagnostics_elm_style";
    _module_functions[274].param_count = 2;
    _module_functions[274].return_type = 4;
    _module_functions[274].return_struct_type_name = NULL;
    _module_functions[274].return_fn_sig = NULL;
    _module_functions[274].return_type_info = NULL;
    _module_functions[274].body = NULL;
    _module_functions[274].shadow_test = NULL;
    _module_functions[274].is_extern = false;
    _module_functions[274].returns_gc_managed = true;
    _module_functions[274].requires_manual_free = false;
    _module_functions[274].returns_borrowed = false;
    _module_functions[274].cleanup_function = NULL;
    _module_functions[274].params = &_module_params[251];
    _module_params[251].name = "diags";
    _module_params[251].type = 15;
    _module_params[251].struct_type_name = "CompilerDiagnostic";
    _module_params[251].element_type = 21;
    _module_params[251].fn_sig = NULL;
    _module_params[252].name = "source";
    _module_params[252].type = 4;
    _module_params[252].struct_type_name = NULL;
    _module_params[252].element_type = 21;
    _module_params[252].fn_sig = NULL;

    /* Function: error_type_mismatch */
    _module_functions[275].name = "error_type_mismatch";
    _module_functions[275].param_count = 6;
    _module_functions[275].return_type = 8;
    _module_functions[275].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[275].return_fn_sig = NULL;
    _module_functions[275].return_type_info = NULL;
    _module_functions[275].body = NULL;
    _module_functions[275].shadow_test = NULL;
    _module_functions[275].is_extern = false;
    _module_functions[275].returns_gc_managed = false;
    _module_functions[275].requires_manual_free = false;
    _module_functions[275].returns_borrowed = false;
    _module_functions[275].cleanup_function = NULL;
    _module_functions[275].params = &_module_params[253];
    _module_params[253].name = "file";
    _module_params[253].type = 4;
    _module_params[253].struct_type_name = NULL;
    _module_params[253].element_type = 21;
    _module_params[253].fn_sig = NULL;
    _module_params[254].name = "line";
    _module_params[254].type = 0;
    _module_params[254].struct_type_name = NULL;
    _module_params[254].element_type = 21;
    _module_params[254].fn_sig = NULL;
    _module_params[255].name = "column";
    _module_params[255].type = 0;
    _module_params[255].struct_type_name = NULL;
    _module_params[255].element_type = 21;
    _module_params[255].fn_sig = NULL;
    _module_params[256].name = "expected";
    _module_params[256].type = 4;
    _module_params[256].struct_type_name = NULL;
    _module_params[256].element_type = 21;
    _module_params[256].fn_sig = NULL;
    _module_params[257].name = "found";
    _module_params[257].type = 4;
    _module_params[257].struct_type_name = NULL;
    _module_params[257].element_type = 21;
    _module_params[257].fn_sig = NULL;
    _module_params[258].name = "context";
    _module_params[258].type = 4;
    _module_params[258].struct_type_name = NULL;
    _module_params[258].element_type = 21;
    _module_params[258].fn_sig = NULL;

    /* Function: error_undefined_variable */
    _module_functions[276].name = "error_undefined_variable";
    _module_functions[276].param_count = 5;
    _module_functions[276].return_type = 8;
    _module_functions[276].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[276].return_fn_sig = NULL;
    _module_functions[276].return_type_info = NULL;
    _module_functions[276].body = NULL;
    _module_functions[276].shadow_test = NULL;
    _module_functions[276].is_extern = false;
    _module_functions[276].returns_gc_managed = false;
    _module_functions[276].requires_manual_free = false;
    _module_functions[276].returns_borrowed = false;
    _module_functions[276].cleanup_function = NULL;
    _module_functions[276].params = &_module_params[259];
    _module_params[259].name = "file";
    _module_params[259].type = 4;
    _module_params[259].struct_type_name = NULL;
    _module_params[259].element_type = 21;
    _module_params[259].fn_sig = NULL;
    _module_params[260].name = "line";
    _module_params[260].type = 0;
    _module_params[260].struct_type_name = NULL;
    _module_params[260].element_type = 21;
    _module_params[260].fn_sig = NULL;
    _module_params[261].name = "column";
    _module_params[261].type = 0;
    _module_params[261].struct_type_name = NULL;
    _module_params[261].element_type = 21;
    _module_params[261].fn_sig = NULL;
    _module_params[262].name = "var_name";
    _module_params[262].type = 4;
    _module_params[262].struct_type_name = NULL;
    _module_params[262].element_type = 21;
    _module_params[262].fn_sig = NULL;
    _module_params[263].name = "similar_names";
    _module_params[263].type = 13;
    _module_params[263].struct_type_name = NULL;
    _module_params[263].element_type = 21;
    _module_params[263].fn_sig = NULL;

    /* Function: error_arity_mismatch */
    _module_functions[277].name = "error_arity_mismatch";
    _module_functions[277].param_count = 6;
    _module_functions[277].return_type = 8;
    _module_functions[277].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[277].return_fn_sig = NULL;
    _module_functions[277].return_type_info = NULL;
    _module_functions[277].body = NULL;
    _module_functions[277].shadow_test = NULL;
    _module_functions[277].is_extern = false;
    _module_functions[277].returns_gc_managed = false;
    _module_functions[277].requires_manual_free = false;
    _module_functions[277].returns_borrowed = false;
    _module_functions[277].cleanup_function = NULL;
    _module_functions[277].params = &_module_params[264];
    _module_params[264].name = "file";
    _module_params[264].type = 4;
    _module_params[264].struct_type_name = NULL;
    _module_params[264].element_type = 21;
    _module_params[264].fn_sig = NULL;
    _module_params[265].name = "line";
    _module_params[265].type = 0;
    _module_params[265].struct_type_name = NULL;
    _module_params[265].element_type = 21;
    _module_params[265].fn_sig = NULL;
    _module_params[266].name = "column";
    _module_params[266].type = 0;
    _module_params[266].struct_type_name = NULL;
    _module_params[266].element_type = 21;
    _module_params[266].fn_sig = NULL;
    _module_params[267].name = "function_name";
    _module_params[267].type = 4;
    _module_params[267].struct_type_name = NULL;
    _module_params[267].element_type = 21;
    _module_params[267].fn_sig = NULL;
    _module_params[268].name = "expected_args";
    _module_params[268].type = 0;
    _module_params[268].struct_type_name = NULL;
    _module_params[268].element_type = 21;
    _module_params[268].fn_sig = NULL;
    _module_params[269].name = "found_args";
    _module_params[269].type = 0;
    _module_params[269].struct_type_name = NULL;
    _module_params[269].element_type = 21;
    _module_params[269].fn_sig = NULL;

    /* Function: error_missing_return */
    _module_functions[278].name = "error_missing_return";
    _module_functions[278].param_count = 5;
    _module_functions[278].return_type = 8;
    _module_functions[278].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[278].return_fn_sig = NULL;
    _module_functions[278].return_type_info = NULL;
    _module_functions[278].body = NULL;
    _module_functions[278].shadow_test = NULL;
    _module_functions[278].is_extern = false;
    _module_functions[278].returns_gc_managed = false;
    _module_functions[278].requires_manual_free = false;
    _module_functions[278].returns_borrowed = false;
    _module_functions[278].cleanup_function = NULL;
    _module_functions[278].params = &_module_params[270];
    _module_params[270].name = "file";
    _module_params[270].type = 4;
    _module_params[270].struct_type_name = NULL;
    _module_params[270].element_type = 21;
    _module_params[270].fn_sig = NULL;
    _module_params[271].name = "line";
    _module_params[271].type = 0;
    _module_params[271].struct_type_name = NULL;
    _module_params[271].element_type = 21;
    _module_params[271].fn_sig = NULL;
    _module_params[272].name = "column";
    _module_params[272].type = 0;
    _module_params[272].struct_type_name = NULL;
    _module_params[272].element_type = 21;
    _module_params[272].fn_sig = NULL;
    _module_params[273].name = "function_name";
    _module_params[273].type = 4;
    _module_params[273].struct_type_name = NULL;
    _module_params[273].element_type = 21;
    _module_params[273].fn_sig = NULL;
    _module_params[274].name = "expected_type";
    _module_params[274].type = 4;
    _module_params[274].struct_type_name = NULL;
    _module_params[274].element_type = 21;
    _module_params[274].fn_sig = NULL;

    /* Function: error_immutable_assignment */
    _module_functions[279].name = "error_immutable_assignment";
    _module_functions[279].param_count = 4;
    _module_functions[279].return_type = 8;
    _module_functions[279].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[279].return_fn_sig = NULL;
    _module_functions[279].return_type_info = NULL;
    _module_functions[279].body = NULL;
    _module_functions[279].shadow_test = NULL;
    _module_functions[279].is_extern = false;
    _module_functions[279].returns_gc_managed = false;
    _module_functions[279].requires_manual_free = false;
    _module_functions[279].returns_borrowed = false;
    _module_functions[279].cleanup_function = NULL;
    _module_functions[279].params = &_module_params[275];
    _module_params[275].name = "file";
    _module_params[275].type = 4;
    _module_params[275].struct_type_name = NULL;
    _module_params[275].element_type = 21;
    _module_params[275].fn_sig = NULL;
    _module_params[276].name = "line";
    _module_params[276].type = 0;
    _module_params[276].struct_type_name = NULL;
    _module_params[276].element_type = 21;
    _module_params[276].fn_sig = NULL;
    _module_params[277].name = "column";
    _module_params[277].type = 0;
    _module_params[277].struct_type_name = NULL;
    _module_params[277].element_type = 21;
    _module_params[277].fn_sig = NULL;
    _module_params[278].name = "var_name";
    _module_params[278].type = 4;
    _module_params[278].struct_type_name = NULL;
    _module_params[278].element_type = 21;
    _module_params[278].fn_sig = NULL;

    /* Function: encode_type_mismatch_message */
    _module_functions[280].name = "encode_type_mismatch_message";
    _module_functions[280].param_count = 4;
    _module_functions[280].return_type = 4;
    _module_functions[280].return_struct_type_name = NULL;
    _module_functions[280].return_fn_sig = NULL;
    _module_functions[280].return_type_info = NULL;
    _module_functions[280].body = NULL;
    _module_functions[280].shadow_test = NULL;
    _module_functions[280].is_extern = false;
    _module_functions[280].returns_gc_managed = true;
    _module_functions[280].requires_manual_free = false;
    _module_functions[280].returns_borrowed = false;
    _module_functions[280].cleanup_function = NULL;
    _module_functions[280].params = &_module_params[279];
    _module_params[279].name = "context";
    _module_params[279].type = 4;
    _module_params[279].struct_type_name = NULL;
    _module_params[279].element_type = 21;
    _module_params[279].fn_sig = NULL;
    _module_params[280].name = "expected";
    _module_params[280].type = 4;
    _module_params[280].struct_type_name = NULL;
    _module_params[280].element_type = 21;
    _module_params[280].fn_sig = NULL;
    _module_params[281].name = "found";
    _module_params[281].type = 4;
    _module_params[281].struct_type_name = NULL;
    _module_params[281].element_type = 21;
    _module_params[281].fn_sig = NULL;
    _module_params[282].name = "detail";
    _module_params[282].type = 4;
    _module_params[282].struct_type_name = NULL;
    _module_params[282].element_type = 21;
    _module_params[282].fn_sig = NULL;

    /* Function: encode_undefined_name_message */
    _module_functions[281].name = "encode_undefined_name_message";
    _module_functions[281].param_count = 1;
    _module_functions[281].return_type = 4;
    _module_functions[281].return_struct_type_name = NULL;
    _module_functions[281].return_fn_sig = NULL;
    _module_functions[281].return_type_info = NULL;
    _module_functions[281].body = NULL;
    _module_functions[281].shadow_test = NULL;
    _module_functions[281].is_extern = false;
    _module_functions[281].returns_gc_managed = true;
    _module_functions[281].requires_manual_free = false;
    _module_functions[281].returns_borrowed = false;
    _module_functions[281].cleanup_function = NULL;
    _module_functions[281].params = &_module_params[283];
    _module_params[283].name = "name";
    _module_params[283].type = 4;
    _module_params[283].struct_type_name = NULL;
    _module_params[283].element_type = 21;
    _module_params[283].fn_sig = NULL;

    /* Function: encode_wrong_arg_count_message */
    _module_functions[282].name = "encode_wrong_arg_count_message";
    _module_functions[282].param_count = 3;
    _module_functions[282].return_type = 4;
    _module_functions[282].return_struct_type_name = NULL;
    _module_functions[282].return_fn_sig = NULL;
    _module_functions[282].return_type_info = NULL;
    _module_functions[282].body = NULL;
    _module_functions[282].shadow_test = NULL;
    _module_functions[282].is_extern = false;
    _module_functions[282].returns_gc_managed = true;
    _module_functions[282].requires_manual_free = false;
    _module_functions[282].returns_borrowed = false;
    _module_functions[282].cleanup_function = NULL;
    _module_functions[282].params = &_module_params[284];
    _module_params[284].name = "function_name";
    _module_params[284].type = 4;
    _module_params[284].struct_type_name = NULL;
    _module_params[284].element_type = 21;
    _module_params[284].fn_sig = NULL;
    _module_params[285].name = "expected_args";
    _module_params[285].type = 0;
    _module_params[285].struct_type_name = NULL;
    _module_params[285].element_type = 21;
    _module_params[285].fn_sig = NULL;
    _module_params[286].name = "found_args";
    _module_params[286].type = 0;
    _module_params[286].struct_type_name = NULL;
    _module_params[286].element_type = 21;
    _module_params[286].fn_sig = NULL;

    /* Function: encode_missing_return_message */
    _module_functions[283].name = "encode_missing_return_message";
    _module_functions[283].param_count = 2;
    _module_functions[283].return_type = 4;
    _module_functions[283].return_struct_type_name = NULL;
    _module_functions[283].return_fn_sig = NULL;
    _module_functions[283].return_type_info = NULL;
    _module_functions[283].body = NULL;
    _module_functions[283].shadow_test = NULL;
    _module_functions[283].is_extern = false;
    _module_functions[283].returns_gc_managed = true;
    _module_functions[283].requires_manual_free = false;
    _module_functions[283].returns_borrowed = false;
    _module_functions[283].cleanup_function = NULL;
    _module_functions[283].params = &_module_params[287];
    _module_params[287].name = "function_name";
    _module_params[287].type = 4;
    _module_params[287].struct_type_name = NULL;
    _module_params[287].element_type = 21;
    _module_params[287].fn_sig = NULL;
    _module_params[288].name = "expected_type";
    _module_params[288].type = 4;
    _module_params[288].struct_type_name = NULL;
    _module_params[288].element_type = 21;
    _module_params[288].fn_sig = NULL;

    /* Function: encode_immutable_assignment_message */
    _module_functions[284].name = "encode_immutable_assignment_message";
    _module_functions[284].param_count = 1;
    _module_functions[284].return_type = 4;
    _module_functions[284].return_struct_type_name = NULL;
    _module_functions[284].return_fn_sig = NULL;
    _module_functions[284].return_type_info = NULL;
    _module_functions[284].body = NULL;
    _module_functions[284].shadow_test = NULL;
    _module_functions[284].is_extern = false;
    _module_functions[284].returns_gc_managed = true;
    _module_functions[284].requires_manual_free = false;
    _module_functions[284].returns_borrowed = false;
    _module_functions[284].cleanup_function = NULL;
    _module_functions[284].params = &_module_params[289];
    _module_params[289].name = "var_name";
    _module_params[289].type = 4;
    _module_params[289].struct_type_name = NULL;
    _module_params[289].element_type = 21;
    _module_params[289].fn_sig = NULL;

    /* Function: error_unsafe_required */
    _module_functions[285].name = "error_unsafe_required";
    _module_functions[285].param_count = 4;
    _module_functions[285].return_type = 8;
    _module_functions[285].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[285].return_fn_sig = NULL;
    _module_functions[285].return_type_info = NULL;
    _module_functions[285].body = NULL;
    _module_functions[285].shadow_test = NULL;
    _module_functions[285].is_extern = false;
    _module_functions[285].returns_gc_managed = false;
    _module_functions[285].requires_manual_free = false;
    _module_functions[285].returns_borrowed = false;
    _module_functions[285].cleanup_function = NULL;
    _module_functions[285].params = &_module_params[290];
    _module_params[290].name = "file";
    _module_params[290].type = 4;
    _module_params[290].struct_type_name = NULL;
    _module_params[290].element_type = 21;
    _module_params[290].fn_sig = NULL;
    _module_params[291].name = "line";
    _module_params[291].type = 0;
    _module_params[291].struct_type_name = NULL;
    _module_params[291].element_type = 21;
    _module_params[291].fn_sig = NULL;
    _module_params[292].name = "column";
    _module_params[292].type = 0;
    _module_params[292].struct_type_name = NULL;
    _module_params[292].element_type = 21;
    _module_params[292].fn_sig = NULL;
    _module_params[293].name = "function_name";
    _module_params[293].type = 4;
    _module_params[293].struct_type_name = NULL;
    _module_params[293].element_type = 21;
    _module_params[293].fn_sig = NULL;

    /* Function: error_use_after_consume */
    _module_functions[286].name = "error_use_after_consume";
    _module_functions[286].param_count = 5;
    _module_functions[286].return_type = 8;
    _module_functions[286].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[286].return_fn_sig = NULL;
    _module_functions[286].return_type_info = NULL;
    _module_functions[286].body = NULL;
    _module_functions[286].shadow_test = NULL;
    _module_functions[286].is_extern = false;
    _module_functions[286].returns_gc_managed = false;
    _module_functions[286].requires_manual_free = false;
    _module_functions[286].returns_borrowed = false;
    _module_functions[286].cleanup_function = NULL;
    _module_functions[286].params = &_module_params[294];
    _module_params[294].name = "file";
    _module_params[294].type = 4;
    _module_params[294].struct_type_name = NULL;
    _module_params[294].element_type = 21;
    _module_params[294].fn_sig = NULL;
    _module_params[295].name = "line";
    _module_params[295].type = 0;
    _module_params[295].struct_type_name = NULL;
    _module_params[295].element_type = 21;
    _module_params[295].fn_sig = NULL;
    _module_params[296].name = "column";
    _module_params[296].type = 0;
    _module_params[296].struct_type_name = NULL;
    _module_params[296].element_type = 21;
    _module_params[296].fn_sig = NULL;
    _module_params[297].name = "resource_name";
    _module_params[297].type = 4;
    _module_params[297].struct_type_name = NULL;
    _module_params[297].element_type = 21;
    _module_params[297].fn_sig = NULL;
    _module_params[298].name = "consumed_at_line";
    _module_params[298].type = 0;
    _module_params[298].struct_type_name = NULL;
    _module_params[298].element_type = 21;
    _module_params[298].fn_sig = NULL;

    /* Function: error_resource_leak */
    _module_functions[287].name = "error_resource_leak";
    _module_functions[287].param_count = 5;
    _module_functions[287].return_type = 8;
    _module_functions[287].return_struct_type_name = "__nano_record_6572726f725f6d65737361676573_ErrorMessage";
    _module_functions[287].return_fn_sig = NULL;
    _module_functions[287].return_type_info = NULL;
    _module_functions[287].body = NULL;
    _module_functions[287].shadow_test = NULL;
    _module_functions[287].is_extern = false;
    _module_functions[287].returns_gc_managed = false;
    _module_functions[287].requires_manual_free = false;
    _module_functions[287].returns_borrowed = false;
    _module_functions[287].cleanup_function = NULL;
    _module_functions[287].params = &_module_params[299];
    _module_params[299].name = "file";
    _module_params[299].type = 4;
    _module_params[299].struct_type_name = NULL;
    _module_params[299].element_type = 21;
    _module_params[299].fn_sig = NULL;
    _module_params[300].name = "line";
    _module_params[300].type = 0;
    _module_params[300].struct_type_name = NULL;
    _module_params[300].element_type = 21;
    _module_params[300].fn_sig = NULL;
    _module_params[301].name = "column";
    _module_params[301].type = 0;
    _module_params[301].struct_type_name = NULL;
    _module_params[301].element_type = 21;
    _module_params[301].fn_sig = NULL;
    _module_params[302].name = "resource_name";
    _module_params[302].type = 4;
    _module_params[302].struct_type_name = NULL;
    _module_params[302].element_type = 21;
    _module_params[302].fn_sig = NULL;
    _module_params[303].name = "resource_type";
    _module_params[303].type = 4;
    _module_params[303].struct_type_name = NULL;
    _module_params[303].element_type = 21;
    _module_params[303].fn_sig = NULL;

    /* Function: get_error_template */
    _module_functions[288].name = "get_error_template";
    _module_functions[288].param_count = 1;
    _module_functions[288].return_type = 4;
    _module_functions[288].return_struct_type_name = NULL;
    _module_functions[288].return_fn_sig = NULL;
    _module_functions[288].return_type_info = NULL;
    _module_functions[288].body = NULL;
    _module_functions[288].shadow_test = NULL;
    _module_functions[288].is_extern = false;
    _module_functions[288].returns_gc_managed = true;
    _module_functions[288].requires_manual_free = false;
    _module_functions[288].returns_borrowed = false;
    _module_functions[288].cleanup_function = NULL;
    _module_functions[288].params = &_module_params[304];
    _module_params[304].name = "error_code";
    _module_params[304].type = 4;
    _module_params[304].struct_type_name = NULL;
    _module_params[304].element_type = 21;
    _module_params[304].fn_sig = NULL;

}

ModuleMetadata _module_metadata_error_messages = {
    .module_name = "error_messages",
    .function_count = 289,
    .functions = _module_functions,
    .struct_count = 48,
    .structs = NULL,  /* TODO: serialize structs */
    .enum_count = 5,
    .enums = NULL,  /* TODO: serialize enums */
    .union_count = 0,
    .unions = NULL  /* TODO: serialize unions */
};

/* Constants from module */
static const int64_t _module_const_error_messages_line = 0LL;
static const int64_t _module_const_error_messages_column = 0LL;
static const int64_t _module_const_error_messages_phase = 0LL;
static const int64_t _module_const_error_messages_severity = 0LL;
static const int64_t _module_const_error_messages_index = 0LL;
static const int64_t _module_const_error_messages_count = 205191333595648LL;
static const int64_t _module_const_error_messages_target_len = 0LL;
static const int64_t _module_const_error_messages_len = 205191329373472LL;
static const int64_t _module_const_error_messages_target_line = 0LL;
static const int64_t _module_const_error_messages_total_len = 205191329373472LL;
static const int64_t _module_const_error_messages_name_count = 205191329373472LL;
static const int64_t _module_const_error_messages_expected_args = 0LL;
static const int64_t _module_const_error_messages_found_args = 0LL;
static const int64_t _module_const_error_messages_consumed_at_line = 0LL;

