from pathlib import Path
import os,sys,subprocess,json,time,hashlib,signal,traceback,shutil
root=Path.cwd();out=root/'.test_output/module-verifier-20261121/linux';out.mkdir(exist_ok=False);shutil.copy2(__file__,out/'observer.py');sha=lambda raw:hashlib.sha256(raw).hexdigest();frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],text=True).splitlines();names+=['src_nano/nvm2c/module_verifier.nano','tests/nvm2c_module_verifier_driver.nano','tests/nvm2c_module_verifier_reference.c','tests/test_nanolang_translator_module_verifier.py'];expected={name:sha((root/name).read_bytes()) for name in sorted(set(names)) if (root/name).is_file()}
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),status='running',source_hashes=expected,steps=[],provider=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=frozen,text=True).strip(),compiler=str(frozen/'bin/nanoc_stage1'),compiler_sha256=sha((frozen/'bin/nanoc_stage1').read_bytes()),receipt_sha256=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes())),limits=['I qualify the ordinary unlinked whole-module pipeline only; linked/owned/affine/private-profile admission and the full pure C emitter remain required. I use the actual guarded raw-equal bdffa4ccc native Stage1 as a development source producer. Ordinary shadows remain10s, native compilation600s and per-batch guest comparison600s. I allow7200s for the complete two-mode7132-case/five-route observer, with no raw bootstrap job. Puck owns a serial Darwin capture reservation; I start no Darwin gate.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(frozen/'bin/nanoc_stage1'),NANOLANG_MODULE_VERIFIER_PRODUCTS=str(out/'products'));env.pop('NANOLANG_TRANSLATOR_SOURCE_MODULE',None);tools={}
def guards():
 assert {name:sha((root/name).read_bytes()) for name in expected}==expected
 if tools:assert {name:sha((root/name).read_bytes()) for name in tools}==tools
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
def step(name,args,timeout):
 item=dict(name=name,argv=args);record['steps'].append(item);save();start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as c:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=c,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['seconds']=time.monotonic()-start;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError((name,item['returncode']))
try:
 record['gate_environment']={name:env.get(name) for name in ['PATH','CC','NANOLANG_ROOT','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']};save();guards()
 step('tools',['make','CC=/usr/bin/cc','bin/nanoc_c','nano_virt','nano_vm','bin/nanoisa','nvm2c','nvm2c-runtime','obj/nvm2c_module_verifier_reference'],1800)
 tools={name:sha((root/name).read_bytes()) for name in ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so','obj/nvm2c_module_verifier_reference']};record['tools']=tools;save();guards()
 step('products',['make','CC=/usr/bin/cc','test-nanolang-translator-module-verifier'],7200);guards()
 step('identifiers',['make','CC=/usr/bin/cc','test-embedded-nano-identifiers'],600);guards()
 record.update(status='passed',source_and_tool_guards_unchanged=True,provider_guards_unchanged=True)
except BaseException as error:
 record.update(status='failed',error=repr(error));(out/'exception').write_text(traceback.format_exc())
finally:
 try:guards();record['final_guards_unchanged']=True
 except BaseException as error:record.update(status='failed',guard_error=repr(error))
 save()
print(json.dumps({k:v for k,v in record.items() if k not in ['source_hashes','tools']}),flush=True);sys.exit(0 if record['status']=='passed' else 1)
