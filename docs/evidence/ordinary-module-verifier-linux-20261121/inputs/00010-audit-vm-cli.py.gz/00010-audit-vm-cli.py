from pathlib import Path
import sys,json,hashlib,time
root=Path.cwd();sys.path.insert(0,str(root))
from tests.test_nanolang_translator_module_verifier import corpus
from tests.native_process import run_captured
work=root/'.test_output/module-verifier-20261121';out=work/'vm-cli';out.mkdir(exist_ok=False);state=json.loads((work/'linux/manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();tool=root/'bin/nano_vm';assert sha(tool)==state['tools']['bin/nano_vm']
cases,_=corpus();reference=(work/'native-corrected/full-reference.txt').read_text().splitlines();selected=[];randoms=0
for i,case in enumerate(cases):
 name=case[0]
 if name.startswith(('core-','body-','private-','service-','ownership-','import-')) or name=='no-functions':continue
 if name.startswith('multiple-functions-'):
  if randoms>=16:continue
  randoms+=1
 selected.append(i)
records=[];start=time.monotonic()
for i in selected:
 case=cases[i];path=work/'native-corrected/inputs'/f'{i}.nvm';assert path.read_bytes()==case[1]
 p=run_captured([tool,'--verify-only',path],timeout=30,cwd=root);(out/f'{i}.stdout').write_bytes(p.stdout);(out/f'{i}.stderr').write_bytes(p.stderr);expected=reference[i].startswith('1:');assert (p.returncode==0)==expected,(case[0],reference[i],p.returncode,p.stderr[-1000:]);records.append(dict(case=case[0],index=i,input_sha256=sha(path),reference=reference[i],returncode=p.returncode))
assert sha(tool)==state['tools']['bin/nano_vm'];record=dict(status='passed',cases=len(records),seconds=time.monotonic()-start,vm_sha256=sha(tool),records=records,limits=['I compare the actual VM --verify-only consumer on independent ordinary no-import/no-owner/no-linked metadata/body/declaration controls. The separate reference still queries actual public C declared/full APIs. I claim no private or linked execution acceptance.']);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['records','limits']}))
