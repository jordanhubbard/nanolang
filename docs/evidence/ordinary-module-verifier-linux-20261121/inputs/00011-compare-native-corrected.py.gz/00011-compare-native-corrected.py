from pathlib import Path
import sys,json,time,collections
root=Path.cwd();sys.path.insert(0,str(root))
from tests.test_nanolang_translator_module_verifier import corpus
from tests.nanolang_translator_routes import checked
out=root/'.test_output/module-verifier-20261121/native-corrected';(out/'inputs').mkdir(parents=True,exist_ok=False);cases,skipped=corpus();paths=[]
for i,(_,blob,*_) in enumerate(cases):
 p=out/'inputs'/f'{i}.nvm';p.write_bytes(blob);paths.append(p)
start=time.monotonic();counts={};failures=[]
for declarations,column,mode in [(False,2,'full'),(True,3,'declared')]:
 outputs=[]
 for command in [[root/'obj/nvm2c_module_verifier_reference'],[out.parent/'driver-corrected']]:
  lines=[]
  for i in range(0,len(paths),32):lines+=checked([*command,*(['--declared'] if declarations else []),*paths[i:i+32]],timeout=600).splitlines()
  assert len(lines)==len(cases);outputs.append(lines)
  (out/(mode+('-reference' if len(outputs)==1 else '-pure')+'.txt')).write_text('\n'.join(lines)+'\n')
 reference,pure=outputs
 for i,(case,want,value) in enumerate(zip(cases,reference,pure)):
  if value!=want and not(value=='A' and case[4]):failures.append(dict(index=i,case=case[0],mode=mode,reference=want,pure=value))
  if case[column] is not None and value!=case[column]:failures.append(dict(index=i,case=case[0],mode=mode,expected=case[column],pure=value))
 counts[mode]=dict(collections.Counter(v.split(':')[0] for v in pure))
record=dict(cases=len(cases),counts=counts,skipped=skipped,seconds=time.monotonic()-start,failures=failures);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(cases=len(cases),seconds=record['seconds'],counts=counts,failures=failures[:15],total_failures=len(failures))));sys.exit(1 if failures else 0)
