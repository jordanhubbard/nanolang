from pathlib import Path
import shlex,json,hashlib,subprocess,time,os
root=Path.cwd();products=root/'.test_output/record-instructions-4pk9miup';out=root/'.test_output/record-instruction-sanitizers';out.mkdir(exist_ok=False);lines=(root/'.test_output/record-instruction-oracle-build.log').read_text().splitlines();commands=[shlex.split(line) for line in lines if line.startswith('/usr/bin/cc ') and 'tests/nvm2c_record_instructions_reference.c' in line];assert len(commands)==1;argv=commands[0];index=argv.index('-o')+1;argv[index]=str(out/'actual-private-copier');argv[1:1]=['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'];env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1');record=dict(steps=[],limits=['I instrument the actual private managed-array/map copier translation unit and its thin fixture. Other linked providers retain their original ordinary source objects. I compare every complete report with the ordinary actual C oracle; this is targeted C-provider instrumentation.'])
def run(args,label):
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(list(map(str,args)),env=env,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=list(map(str,args)),returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
run(argv,'build-copier');count=len((products/'actual-c.reports').read_text().splitlines());reports=[]
for offset in range(0,count,32):
 label=f'cases-{offset}';run([out/'actual-private-copier',*[products/f'case-{i}.bin' for i in range(offset,min(offset+32,count))]],label);reports.extend((out/(label+'.stdout')).read_text().splitlines())
assert reports==(products/'actual-c.reports').read_text().splitlines();record.update(reports=len(reports),provider_sha256=hashlib.sha256((out/'actual-private-copier').read_bytes()).hexdigest());(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print('I matched all targeted ASan/UBSan/leak-checked actual C copier reports.')
