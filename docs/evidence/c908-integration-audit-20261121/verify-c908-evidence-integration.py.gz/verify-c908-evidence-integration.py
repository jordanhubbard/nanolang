from pathlib import Path
import sys,json,gzip,hashlib,subprocess
root=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();report={'peer':'6a0b4d6d439b7cb6729f96c4ca825b607f32b011','archives':[]}
changed=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines();assert all(p=='docs/ROADMAP.md' or p.startswith('docs/evidence/') for p in changed)
for name in ['allocation-policy-bootstrap-darwin-20261121','c908-darwin-observed-20261121']:
 folder=root/'docs/evidence'/name;manifest=json.loads((folder/'manifest.json').read_text());files=manifest['files'];seen={}
 for entry in files:
  p=folder/entry['artifact']
  if p not in seen:
   packed=p.read_bytes();raw=gzip.decompress(packed);seen[p]=(sha(packed),sha(raw),len(packed),len(raw))
  packed_sha,raw_sha,packed_size,raw_size=seen[p]
  assert (packed_sha,raw_sha,packed_size,raw_size)==(entry['compressed_sha256'],entry['sha256'],entry['compressed_bytes'],entry['bytes']),entry['path']
 def guards(value):
  if isinstance(value,dict):
   if 'match' in value:assert value['match'] is True,value
   for child in value.values():guards(child)
  if isinstance(value,list):
   for child in value:guards(child)
 guards(manifest['guard_checks'])
 by_path={f['path']:f for f in files}
 receipt_path='bin/nanoc_bootstrap.json' if name.startswith('c908-') else str(Path(manifest['bootstrap']['work']).relative_to(manifest['root'])/'manifest.json')
 receipt=by_path.get(receipt_path);assert receipt and receipt['sha256']==manifest['bootstrap_manifest_sha256']
 if not name.startswith('c908-'):assert 'bin/nanoc_bootstrap.json' not in by_path
 if name.startswith('c908-'):
  first=by_path['bin/nanoc_stage1.nvm'];second=by_path['bin/nanoc_stage2.nvm'];assert first['sha256']==second['sha256']=='8b9bdcfc37bbca7e3fbe216e011e4ddf6a8a6cbc673eda91a5a3139517396027';assert first['bytes']==second['bytes']==1033160
  assert manifest['bootstrap']['phase']=='stage2' and manifest['bootstrap']['raw_stage1_stage2_equal'] is True
 report['archives'].append(dict(name=name,files=len(files),unique_artifacts=len(seen),raw_bytes=sum(f['bytes'] for f in files),phase=manifest['bootstrap']['phase']))
frozen=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert b.manifest['phase']=='stage2' and b.manifest['raw_stage1_stage2_equal'] is True
report['linux_receipt_sha256']=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes());assert report['linux_receipt_sha256']=='481cb361040c41531450e2780f96f5f51b92a26b2962a02b420bf937f17b082e'
report['linux_guards_unchanged']=True;report['status']='passed';(root/'.test_output/c908-evidence-integration-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
