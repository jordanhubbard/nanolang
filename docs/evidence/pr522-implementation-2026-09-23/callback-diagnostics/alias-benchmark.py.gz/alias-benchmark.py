import json,os,shlex,statistics,subprocess
from pathlib import Path
b=Path('/tmp/pr522-match-results');clang='/opt/homebrew/opt/llvm/bin/clang'
flags=['-O0','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
(b/'env-before.c').write_bytes(subprocess.check_output(['git','show','85df6126f:src/env.c']))
lines=(b/'full-instrument-recipes.txt').read_text().splitlines()
a=shlex.split(next(l for l in lines if l.startswith('cc ') and ' -c src/env.c ' in l));a[0]=clang;a[a.index('-c')+1]=str(b/'env-before.c');a[a.index('-o')+1]=str(b/'env-before.o');a=[x for x in a if x not in ('-O0','-O1','-O2','-O3')]+flags
subprocess.run(a,check=True)
line=next(l for l in (b/'alias-env-recipes.txt').read_text().splitlines() if l.startswith('cc ') and 'tests/test_env_scoping.c' in l)
base=shlex.split(line)
for mode in ('before','after'):
 a=base.copy();a[0]=clang;a[a.index('-o')+1]=str(b/('alias-benchmark-'+mode));a[a.index('tests/test_env_scoping.c')]=str(b/'alias-benchmark.c');a=[str(b/'compiler-san'/x) if x.endswith('.o') else x for x in a]
 if mode=='before': a=[str(b/'env-before.o') if x==str(b/'compiler-san/obj/env.o') else x for x in a]
 a=[x for x in a if x not in ('-O0','-O1','-O2','-O3')]+flags
 subprocess.run(a,check=True)
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1');results={'before':[],'after':[]}
for trial in range(3):
 for mode in ('before','after'):
  results[mode].append(float(subprocess.check_output([str(b/('alias-benchmark-'+mode))],env=env,text=True)))
print(json.dumps({'seconds':results,'medians':{k:statistics.median(v) for k,v in results.items()}},indent=2))
