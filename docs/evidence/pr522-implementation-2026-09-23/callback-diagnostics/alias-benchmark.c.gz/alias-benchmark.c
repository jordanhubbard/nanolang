#include "nanolang.h"
#include "runtime/gc.h"
#include <assert.h>
#include <stdio.h>
#include <time.h>
int g_argc = 0;
char **g_argv = NULL;
int main(void) {
    gc_init();
    Environment *env = create_environment();
    for (int i=0;i<2048;++i) {
        char name[32];snprintf(name,sizeof name,"global_%d",i);
        env_define_var(env,name,TYPE_INT,false,create_int(i));
    }
    Value text=create_string("shared");
    env_define_var(env,"source",TYPE_STRING,false,text);
    struct timespec start,end;
    assert(!clock_gettime(CLOCK_MONOTONIC,&start));
    for(int i=0;i<20000;++i) {
        char name[32];snprintf(name,sizeof name,"alias_%d",i);
        env_define_var(env,name,TYPE_STRING,false,text);
    }
    assert(!clock_gettime(CLOCK_MONOTONIC,&end));
    printf("%.9f\n",(double)(end.tv_sec-start.tv_sec)+(double)(end.tv_nsec-start.tv_nsec)/1e9);
    free_environment(env);
    assert(gc_get_stats().num_objects==0);
    gc_shutdown();
    return 0;
}
