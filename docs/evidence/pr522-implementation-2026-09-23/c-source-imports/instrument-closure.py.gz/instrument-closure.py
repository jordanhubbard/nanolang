import subprocess,shlex,concurrent.futures
from pathlib import Path
root=Path('/tmp/pr522-match-results/closure-san');root.mkdir(exist_ok=True)
lines=Path('/tmp/pr522-match-results/full-instrument-recipes.txt').read_text().splitlines()
clang='/opt/homebrew/opt/llvm/bin/clang'
flags=['-O0','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
commands=[];objects={}
for line in lines:
 if not line.startswith('cc ') or not any(' -c '+src+' ' in line for src in ['src/main.c','src/c_backend.c','src/module.c']): continue
 args=shlex.split(line);old=args[args.index('-o')+1];out=root/old;out.parent.mkdir(parents=True,exist_ok=True);objects[old]=str(out)
 args[0]=clang;args[args.index('-o')+1]=str(out);args=[a for a in args if a not in ('-O3','-O2','-O1','-O0')]+flags
 commands.append(args)
def build(args):
 r=subprocess.run(args,capture_output=True,text=True)
 if r.returncode: raise RuntimeError(r.stdout+r.stderr)
 return args[args.index('-c')+1]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for source in pool.map(build,commands): print('built',source,flush=True)
line=next(l.strip().rstrip(' \\;') for l in lines if l.strip().startswith('cc ') and ' -o bin/nanoc_c ' in l)
args=shlex.split(line);args[0]=clang;args[args.index('-o')+1]=str(root/'nanoc_c-san')
args=[objects.get(a,a) for a in args if a not in ('-O3','-O2','-O1','-O0')]+flags
subprocess.run(args,check=True)
print('PASS main.c, c_backend.c and module.c instrumented; other objects and libraries ordinary',flush=True)
