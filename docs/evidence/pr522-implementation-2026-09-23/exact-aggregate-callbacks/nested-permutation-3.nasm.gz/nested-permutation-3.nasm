.string "main"
.string "apply"
.string "identity"

.types 0 0 1

.entry 2






.function apply 1 2 0 int 1
  PUSH_I64 7
  ARR_LITERAL 1 1
  ARR_LITERAL 7 1
  LOAD_LOCAL 0
  CALL_INDIRECT 1 1
  STORE_LOCAL 1
  LOAD_LOCAL 1
  PUSH_I64 0
  ARR_GET
  PUSH_I64 0
  ARR_GET
  RET
.end
.function identity 1 1 0 array 1
  LOAD_LOCAL 0
  RET
.end
.function main 0 0 0 int 1
  FUNCREF 1
  CALL 0
  PUSH_I64 7
  I64_SUB
  RET
.end
.parameters 0 function
.parameters 1 array
