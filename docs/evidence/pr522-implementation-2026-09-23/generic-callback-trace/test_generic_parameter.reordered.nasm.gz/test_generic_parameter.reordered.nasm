.string "main"
.string "apply"
.string "read_box"
.string "make_box"

.types 0 0 1

.entry 3








.function make_box 0 1 0 union 1
  PUSH_I64 7
  STORE_LOCAL 0
  LOAD_LOCAL 0
  AGG_PACK 1 0 0 1
  RET
.end
.function read_box 1 2 0 int 1
  LOAD_LOCAL 0
  DUP
  AGG_TAG
  PUSH_I64 0
  EQ
  JMP_FALSE L0
  DUP
  STORE_LOCAL 1
  POP
  LOAD_LOCAL 1
  AGG_GET 0
  RET
  JMP L1
L0:
  POP
  PUSH_BOOL 0
  ASSERT
  HALT
L1:
.end
.function apply 1 1 0 int 1
  CALL 0
  LOAD_LOCAL 0
  CALL_INDIRECT 1 1
  RET
.end
.function main 0 0 0 int 1
  FUNCREF 1
  CALL 2
  PUSH_I64 7
  I64_SUB
  RET
.end

.parameters 2 function
.parameters 1 union
