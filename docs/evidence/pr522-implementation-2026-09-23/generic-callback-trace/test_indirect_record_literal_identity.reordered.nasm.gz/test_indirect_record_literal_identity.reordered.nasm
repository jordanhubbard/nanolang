.string "main"
.string "apply"
.string "read"

.types 1 0 1

.entry 2







.function read 1 1 0 int 1
  LOAD_LOCAL 0
  AGG_GET 0
  RET
.end
.function apply 1 1 0 int 1
  PUSH_I64 7
  AGG_PACK 0 0 0 1
  LOAD_LOCAL 0
  CALL_INDIRECT 1 1
  RET
.end
.function main 0 0 0 int 1
  FUNCREF 0
  CALL 1
  PUSH_I64 7
  I64_SUB
  RET
.end

.parameters 1 function
.parameters 0 struct
