.string ""
.string "nl_functions_array_param: All array<T> parameter tests passed!"
.string "first_string"
.string "join_strings"
.string "nano.local.v1"
.string "\x01\x00\x00\x00\x01\x00\x00\x00\x0c\x00\x00\x00J\x00\x00\x00i"
.string "\x01\x00\x00\x00\x02\x00\x00\x00\x14\x00\x00\x00J\x00\x00\x00acc"
.string "\x01\x00\x00\x00\x03\x00\x00\x00+\x00\x00\x00A\x00\x00\x00prefix"
.string "first_int"
.string "sum_ints"
.string "\x03\x00\x00\x00\x01\x00\x00\x00\x0c\x00\x00\x00R\x00\x00\x00i"
.string "\x03\x00\x00\x00\x02\x00\x00\x00\x18\x00\x00\x00R\x00\x00\x00total"
.string "\x03\x00\x00\x00\x03\x00\x00\x00/\x00\x00\x00I\x00\x00\x00v"
.string "first_float"
.string "first_bool"
.string "main"

.metadata 4 5
.metadata 4 6
.metadata 4 7
.metadata 4 10
.metadata 4 11
.metadata 4 12

.entry 6

.function first_string 1 1 0 string 1
  LOAD_LOCAL 0
  PUSH_I64 0
  ARR_GET
  RET
.end

.parameters 0 array

.function join_strings 1 4 0 string 1
  PUSH_I64 0
  STORE_LOCAL 1
  PUSH_STR 0
  STORE_LOCAL 2
L1:
  LOAD_LOCAL 1
  LOAD_LOCAL 0
  ARR_LEN
  I64_LT_S
  JMP_FALSE L0
  LOAD_LOCAL 0
  LOAD_LOCAL 1
  ARR_GET
  STORE_LOCAL 3
  LOAD_LOCAL 3
  STORE_LOCAL 2
  LOAD_LOCAL 1
  PUSH_I64 1
  I64_ADD
  STORE_LOCAL 1
  JMP L1
L0:
  LOAD_LOCAL 2
  RET
.end

.parameters 1 array

.function first_int 1 1 0 int 1
  LOAD_LOCAL 0
  PUSH_I64 0
  ARR_GET
  RET
.end

.parameters 2 array

.function sum_ints 1 4 0 int 1
  PUSH_I64 0
  STORE_LOCAL 1
  PUSH_I64 0
  STORE_LOCAL 2
L1:
  LOAD_LOCAL 1
  LOAD_LOCAL 0
  ARR_LEN
  I64_LT_S
  JMP_FALSE L0
  LOAD_LOCAL 0
  LOAD_LOCAL 1
  ARR_GET
  STORE_LOCAL 3
  LOAD_LOCAL 2
  LOAD_LOCAL 3
  I64_ADD
  STORE_LOCAL 2
  LOAD_LOCAL 1
  PUSH_I64 1
  I64_ADD
  STORE_LOCAL 1
  JMP L1
L0:
  LOAD_LOCAL 2
  RET
.end

.parameters 3 array

.function first_float 1 1 0 float 1
  LOAD_LOCAL 0
  PUSH_I64 0
  ARR_GET
  RET
.end

.parameters 4 array

.function first_bool 1 1 0 bool 1
  LOAD_LOCAL 0
  PUSH_I64 0
  ARR_GET
  RET
.end

.parameters 5 array

.function main 0 0 0 int 1
  PUSH_STR 1
  PRINTLN
  PUSH_I64 0
  RET
.end

