from pathlib import Path
import os,shlex,subprocess,sys
host='darwin' if sys.platform=='darwin' else 'linux'
lines=Path('.test_output/service-v2-shared-final-'+host+'.log').read_text().splitlines()
line=next(s for s in lines if s.startswith('SERVICE_MODULE_OBJECTS='))
args=shlex.split(line);env=dict(os.environ)
while args and '=' in args[0]:
 key,value=args.pop(0).split('=',1);env[key]=value
objects=shlex.split(env['SERVICE_MODULE_OBJECTS'])
archives=list(dict.fromkeys(x for x in objects if x.endswith('.a')))
env['SERVICE_MODULE_OBJECTS']=shlex.join(x for x in objects if not x.endswith('.a'))
env['SERVICE_MODULE_LDFLAGS']=shlex.join(archives+shlex.split(env['SERVICE_MODULE_LDFLAGS']))
print('I move the unchanged COMMON archives after instrumented users and preserve all original objects, methods, flags and assertions.',flush=True)
subprocess.run([sys.executable,'-m','unittest','-v','tests.test_service_bindings_module'],env=env,check=True)
