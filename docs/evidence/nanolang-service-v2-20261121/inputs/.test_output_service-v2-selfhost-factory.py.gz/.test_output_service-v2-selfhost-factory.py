from pathlib import Path
import hashlib,json,os,subprocess,time
from tests.native_process import run_captured,native_compile_timeout
root=Path.cwd();base=root/'.test_output';seed=base/'service-v2-source-compiler';module=base/'service-v2-selfhosted-compiler.nvm';assert not module.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','src_nano','modules'],text=True).splitlines();before={p:digest(Path(p)) for p in paths}
argv=[str(seed),'src_nano/nanoc_v06.nano','--emit-nvm','-o',str(module)]
record=dict(argv=argv,commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),seed_sha256=digest(seed),source_sha256=before,selection='I retain default dependency and root shadows; I create no stage aliases.',build_budget_seconds=native_compile_timeout())
start=time.monotonic()
try:
 result=run_captured(argv,timeout=600,build=True,cwd=root,text=True)
 (base/'service-v2-darwin-selfhost-factory.stdout').write_text(result.stdout);(base/'service-v2-darwin-selfhost-factory.stderr').write_text(result.stderr);record['returncode']=result.returncode
except BaseException as error:record['error']=repr(error);raise
finally:
 record.update(wall_seconds=time.monotonic()-start,source_hashes_stable=before=={p:digest(Path(p)) for p in paths},module_sha256=digest(module) if module.exists() else None)
 (base/'service-v2-darwin-selfhost-factory.json').write_text(json.dumps(record,indent=2)+'\n');print({k:v for k,v in record.items() if k!='source_sha256'})
