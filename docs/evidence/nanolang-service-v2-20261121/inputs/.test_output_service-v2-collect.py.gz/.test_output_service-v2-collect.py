from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tempfile
from tests.nanolang_translator_routes import checked,build_routes
from tests.test_nanolang_translator_service_v2 import corpus,from_module,packet
from tests.test_nanolang_translator_service_nominal import producer_cases
ROOT=Path.cwd();BASE=ROOT/'.test_output';HOST='darwin' if sys.platform=='darwin' else 'linux'
def digest(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
 raw=(json.dumps(value,separators=(',',':'))+'\n').encode();(BASE/name).write_bytes(gzip.compress(raw,mtime=0))
def observe(*args):
 p=subprocess.run(args,capture_output=True,text=True);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
if sys.argv[1]=='--corpus':
 cases=corpus();reports={}
 with tempfile.TemporaryDirectory(prefix='rich-service-evidence-') as directory:
  groups={}
  for i,(route,_,data,_) in enumerate(cases):
   path=Path(directory)/str(i);path.write_bytes(data);groups.setdefault(route,[]).append((i,path))
  for route,items in groups.items():
   for start in range(0,len(items),32):
    batch=items[start:start+32];out=checked(['obj/nvm2c_service_v2_reference',str(route),*[p for _,p in batch]],timeout=600).splitlines();assert len(out)==len(batch)
    reports.update({i:value for (i,_),value in zip(batch,out)})
 records=[]
 for i,(route,name,data,expected) in enumerate(cases):
  report=reports[i]
  if expected is not None:assert int(report.split('|')[0])==expected,(name,expected,report)
  records.append(dict(route=route,name=name,bytes_hex=data.hex(),sha256=digest(data),explicit_status=expected,actual_c_report=report))
 save('service-v2-'+HOST+'-corpus.json.gz',records);print('I retained',len(records),'rich carriers and complete C reports;',sum(r['explicit_status'] is not None for r in records),'explicit statuses.')
elif sys.argv[1]=='--products':
 root=Path(tempfile.mkdtemp(prefix='service-v2-retained-products-',dir=BASE));producer_cases(root)
 driver=Path(tempfile.mkdtemp(prefix='service-v2-retained-driver-',dir=BASE));routes=build_routes(ROOT/'tests/nvm2c_service_v2_driver.nano',driver);assert len(routes)==5
 records=json.loads((root/'records.json').read_text());assert len(records)==8
 for record in records:
  name=record['module'];mode=1 if record['profile']==4 else 0
  path=root/(name+'.rich');path.write_bytes(packet(from_module((root/name).read_bytes())))
  expected=checked(['obj/nvm2c_service_v2_reference',str(mode),path]);assert expected.startswith('0|')
  record['rich_carrier']=str(path.relative_to(root));record['actual_c_report']=expected;record['routes']={}
  for label,command in routes:
   value=checked([*command,str(mode),path],timeout=600);assert value==expected,(name,label,expected,value);record['routes'][label]=value
 files={str(p.relative_to(root)):dict(sha256=digest(p.read_bytes()),bytes_hex=p.read_bytes().hex()) for p in root.rglob('*') if p.is_file()}
 for row in records:
  for key in ('module','carrier'):assert files[row[key]]['sha256']==row[key+'_sha256']
  for name,h in row['sources'].items():assert files[name]['sha256']==h
 driver_files={str(p.relative_to(driver)):dict(sha256=digest(p.read_bytes()),bytes=len(p.read_bytes())) for p in driver.rglob('*') if p.is_file()}
 save('service-v2-'+HOST+'-products.json.gz',dict(records=records,files=files,driver=str(driver),driver_files=driver_files,metadata_only=True))
 print('I retained eight source modules and',len(files),'files; all five actual routes match all eight reports.')
else:
 sources=subprocess.check_output(['git','ls-files','src','src_nano','Makefile.gnu','tests/test_imported_constructor_identity.py','tests/test_native_record_join_values.py','tests/test_nanolang_translator_service_v2.py','tests/nvm2c_service_v2_reference.c','tests/nvm2c_service_v2_driver.nano','tests/test_nominal_owner_context.c','tests/nanolang_translator_routes.py','tests/native_process.py','tests/test_nanolang_translator_service_nominal.py','tests/test_nanolang_translator_services.py','tests/test_nanolang_translator_ownership.py','tests/test_nanolang_translator_payloads.py','tests/test_nanolang_translator_module.py','tests/test_service_drivers.py','tests/test_socket_service_source.py','tests/test_websocket_service_drivers.py','tests/test_mixed_websocket_source.py','tests/fixtures/nsi_*_plan.json','tests/nanoisa/test_nvm2c.c','tests/nanoisa/test_nvm2c_shape.c','tests/nanoisa/test_nvm2c_callables.c','tests/test_typechecker.c','tests/test_type_infer.c','tests/test_module_metadata.c','tests/test_eval.c','tests/test_checker_metadata_ownership.c'],text=True).splitlines()
 tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_service_v2_reference','obj/nvm2c_service_v2_reference_asan']
 if os.environ.get('NANOLANG_TRANSLATOR_SOURCE_COMPILER'):tools.append(str(Path(os.environ['NANOLANG_TRANSLATOR_SOURCE_COMPILER']).relative_to(ROOT)))
 if HOST=='linux':tools+=['bin/nano_as_capture.so']
 result=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,environment={k:os.environ.get(k) for k in ['NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANO_AS_CAPTURE_HELPER','CC','LDFLAGS','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},source_sha256={s:digest(Path(s).read_bytes()) for s in sources},post_run_tool_sha256={s:digest(Path(s).read_bytes()) for s in tools},limits=['My Linux source compiler is a genuine fresh C-seed-derived development image from nanoc_v06.nano, without stage aliases or omitted dependency shadows. Both fresh Darwin creations fail the original deadline and publish no image. Installed/raw-fixed-point qualification remains open.','I compare rich normal metadata arrays/canonical layout rows, not arbitrary malformed C pointer/count graphs. Only signature parameter/result storage is explicitly absent.','All actual shared/nominal/raw/scanner/layout-adapter providers are instrumented in the C differential oracle. Generated C drivers are instrumented and link an ordinary AOT runtime.','C metadata success grants no full module/flow/lifetime/host/executable authority. All cutover and remaining release requirements remain open.'])
 (BASE/('service-v2-'+HOST+'-manifest.json')).write_text(json.dumps(result,indent=2)+'\n');print('I retained',len(sources),'source hashes and',len(tools),'tool identities.')
