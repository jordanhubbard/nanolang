.types 1 0 0
.entry main
.function choose 1 1 0 struct 1
LOAD_LOCAL 0
JMP_FALSE other
PUSH_F64 1.5
ARR_LITERAL 3 1
PUSH_I64 0
ARR_GET
AGG_PACK 0 0 0 1
JMP joined
other:
PUSH_F64 1.5
AGG_PACK 0 0 0 1
joined:
RET
.end
.function main 0 0 0 int 1
PUSH_BOOL 0
CALL choose
AGG_GET 0
TYPE_CHECK 3
ASSERT
PUSH_BOOL 1
CALL choose
AGG_GET 0
TYPE_CHECK 3
ASSERT
PUSH_I64 0
RET
.end
