from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path.cwd();OUT=ROOT/'docs/evidence/nanolang-service-v2-20261121';(OUT/'inputs').mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=[p for p in Path('.test_output').glob('service-v2-*') if p.is_file() and p.suffix in {'.log','.json','.gz','.py','.mk','.nano','.c','.txt'}]
for name in ['service-v2-join-witness','service-v2-float-join']:
 paths += [p for p in (Path('.test_output')/name).rglob('*') if p.is_file() and p.suffix in {'.nano','.nasm','.nvm','.c'}]
paths += [Path(p) for p in subprocess.check_output(['git','diff','8074ad6a1..a9f831f7e','--name-only'],text=True).splitlines() if p.startswith(('src/','src_nano/','tests/')) or p=='Makefile.gnu']
paths += [Path(p) for p in ['tests/nanolang_translator_routes.py','tests/native_process.py','tests/test_nanolang_translator_service_nominal.py','tests/test_nanolang_translator_services.py','tests/test_nanolang_translator_payloads.py','tests/test_nanolang_translator_module.py','tests/test_parameter_nominal_metadata.py','tests/test_nominal_record_array_contracts.py','tests/test_cseed_single_letter_nominals.py','tests/test_native_optional_array_reads.py','tests/nanoisa/test_nvm2c.c','tests/nanoisa/test_nvm2c_shape.c','tests/nanoisa/test_nvm2c_callables.c','tests/test_typechecker.c','tests/test_type_infer.c','tests/test_module_metadata.c','tests/test_eval.c','tests/test_checker_metadata_ownership.c','tests/test_service_bindings_module.py','tests/nanoisa/test_service_bindings_module.c','tests/nanoisa/test_service_mixed_boundaries.c']]
for directory in Path('.test_output').glob('service-v2-darwin-shadow-profile*'):
 if directory.is_dir(): paths += [p for p in directory.rglob('*') if p.is_file() and (p.suffix in {'.json','.log','.txt','.stdout','.stderr'} or p.name in {'stdout','stderr'})]
 provider=directory/'providers/nanoc_c'
 if provider.is_file():paths.append(provider)
paths += list(Path('src_nano/nvm2c').glob('service*.nano'))
records=[]
for p in sorted(set(paths)):
 raw=p.read_bytes() if str(p).startswith('.test_output/') else subprocess.check_output(['git','show','a9f831f7e:'+str(p)]);packed=gzip.compress(raw,mtime=0);target=OUT/'inputs'/(str(p).replace('/','_')+'.gz');target.write_bytes(packed)
 records.append(dict(path=str(p),artifact=str(target.relative_to(OUT)),sha256=sha(raw),bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
manifest=dict(code_commit='a9f831f7e',files=records,limits=['I retain additional permanent same-source producer qualifications; ordinary unittest temporary products were deleted by their original harness.','I hash development tools and retain producer/module/carrier/witness bytes; I do not archive all tool executables or claim installed release qualification.'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in records:
 raw=gzip.decompress((OUT/row['artifact']).read_bytes());assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
print('I verified',len(records),'retained files,',sum(r['bytes'] for r in records),'uncompressed bytes.')
