from pathlib import Path
import gzip,hashlib,json,subprocess
B=Path('.test_output')
def load(h,s):
 p=B/('service-v2-'+h+'-'+s+'.json.gz');return json.loads(gzip.decompress(p.read_bytes()))
def sha(b):return hashlib.sha256(b).hexdigest()
a,b=load('linux','corpus'),load('darwin','corpus');assert a==b
for row in a:assert sha(bytes.fromhex(row['bytes_hex']))==row['sha256']
manifests={h:json.loads((B/('service-v2-'+h+'-manifest.json')).read_text()) for h in ('linux','darwin')}
assert manifests['linux']['source_sha256']==manifests['darwin']['source_sha256']
for path,digest in manifests['linux']['source_sha256'].items():assert sha(subprocess.check_output(['git','show','a9f831f7e:'+path]))==digest,path
products={h:load(h,'products') for h in ('linux','darwin')}
for h,data in products.items():
 assert len(data['records'])==8
 for path,row in data['files'].items():assert sha(bytes.fromhex(row['bytes_hex']))==row['sha256'],(h,path)
 for row in data['records']:
  assert len(row['routes'])==5 and all(value==row['actual_c_report'] for value in row['routes'].values())
  for name in ('module','carrier'):assert data['files'][row[name]]['sha256']==row[name+'_sha256']
  for path,digest in row['sources'].items():assert data['files'][path]['sha256']==digest
for l,r in zip(products['linux']['records'],products['darwin']['records']):
 assert l['module']==r['module'] and l['sources']==r['sources'] and l['actual_c_report']==r['actual_c_report']
result=dict(synthetic_records=len(a),explicit_statuses=sum(row['explicit_status'] is not None for row in a),independent_corpora_and_c_reports_equal=True,source_hashes_equal=len(manifests['linux']['source_sha256']),git_commit='a9f831f7e',actual_products_per_host=8,actual_routes_per_product=5,producer_sources_equal=True,limits=['I compare metadata, source bindings and independently retained producer products; whole-module selection and installed/raw-fixed-point release acceptance remain open.','The first Darwin source creation fails its ten-second shadow deadline; the separate observed image and full component terminals retain their own records.'])
(B/'service-v2-paired-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
