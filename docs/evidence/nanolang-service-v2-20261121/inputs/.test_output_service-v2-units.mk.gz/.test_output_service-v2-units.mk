include Makefile.gnu
.PHONY: service-v2-original-core service-v2-owner-asan
service-v2-original-core: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	$(CC) $(CFLAGS) -o $(OBJ_DIR)/service_v2_test_typechecker tests/test_typechecker.c $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS)
	$(OBJ_DIR)/service_v2_test_typechecker
	$(CC) $(CFLAGS) -o $(OBJ_DIR)/service_v2_test_infer tests/test_type_infer.c $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS)
	$(OBJ_DIR)/service_v2_test_infer
	$(CC) $(CFLAGS) -o $(OBJ_DIR)/service_v2_test_metadata tests/test_module_metadata.c $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS)
	$(OBJ_DIR)/service_v2_test_metadata
service-v2-owner-asan: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	$(CC) $(CFLAGS) -O1 -fsanitize=address,undefined -fno-sanitize-recover=all -o $(OBJ_DIR)/service_v2_owner_asan tests/test_nominal_owner_context.c src/nominal_types.c $(filter-out $(OBJ_DIR)/nominal_types.o,$(COMMON_OBJECTS)) $(RUNTIME_OBJECTS) $(LDFLAGS)
	$(OBJ_DIR)/service_v2_owner_asan
.PHONY: service-v2-old-compiler
service-v2-old-compiler: $(COMPILER_OBJECTS)
	$(CC) $(CFLAGS) -c .test_output/service-v2-before-first-registration.c -o $(OBJ_DIR)/service_v2_old_nominal.o
	$(CC) $(CFLAGS) -o .test_output/service-v2-old-nanoc $(OBJ_DIR)/service_v2_old_nominal.o $(filter-out $(OBJ_DIR)/nominal_types.o,$(COMPILER_OBJECTS)) $(LDFLAGS)
.PHONY: service-v2-native-core
service-v2-native-core: $(NANOISA_OBJECTS) $(NANOISA_UTF8)
	$(CC) $(CFLAGS) -I$(NANOISA_DIR) -I$(NANOISA_MODULE_DIR) -o $(OBJ_DIR)/service_v2_test_nvm2c tests/nanoisa/test_nvm2c.c $(NANOISA_OBJECTS) $(NANOISA_UTF8) $(LDFLAGS)
	CC="$(CC)" $(OBJ_DIR)/service_v2_test_nvm2c $(BIN_DIR)/nvm2c
.PHONY: service-v2-candidate-translator
service-v2-candidate-translator: $(NANOISA_UTF8)
	$(CC) $(CFLAGS) -c src/nanoisa/nvm2c.c -o $(OBJ_DIR)/service_v2_candidate_nvm2c.o
	$(CC) $(CFLAGS) -o .test_output/service-v2-nvm2c-join $(NVM2C_MAIN_OBJECT) $(OBJ_DIR)/service_v2_candidate_nvm2c.o $(filter-out $(OBJ_DIR)/nanoisa/nvm2c.o,$(NANOISA_OBJECTS)) $(NANOISA_UTF8) $(FILE_CLI_OBJECT) $(FILE_PUBLIC_LIBRARY) lib/libnano_socket_runtime.a lib/libnano_services_runtime.a lib/libnano_websocket_runtime.a $(LDFLAGS)
