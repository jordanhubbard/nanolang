from pathlib import Path
import os,sys,subprocess,json,time,hashlib,traceback,tempfile,unittest,re
from unittest.mock import patch
sys.dont_write_bytecode=True
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def child(root,out,phase):
 sys.path.insert(0,str(root));fixtures=out/'fixtures';fixtures.mkdir();tempfile.tempdir=str(fixtures)
 assert os.environ.get('NANO_AS_CAPTURE_HELPER') is None
 commands=out/'commands';commands.mkdir();rows=[];original_run=subprocess.run;original_tmp=tempfile.TemporaryDirectory
 class Retained(original_tmp):
  def cleanup(self):self._finalizer.detach()
 def recorded(*args,**kwargs):
  i=len(rows);item=dict(argv=list(map(str,args[0] if args else kwargs['args'])),cwd=str(kwargs.get('cwd',root)),timeout=kwargs.get('timeout'),environment={n:(kwargs.get('env') or os.environ).get(n) for n in ['PATH','CC','NANO_CC','NANO_BUILD_CACHE','NANO_AS_CAPTURE_HELPER','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_TEST_SLOW_RECOVERY','NANO_SHADOW_TIMEOUT_SECONDS']});rows.append(item);start=time.monotonic()
  try:
   done=original_run(*args,**kwargs);item['returncode']=done.returncode
   for label in ['stdout','stderr']:
    data=getattr(done,label)
    if data is not None:(commands/f'{i:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   return done
  except BaseException as error:
   item['error']=repr(error)
   if isinstance(error,subprocess.TimeoutExpired):
    for label,data in [('stdout',error.output),('stderr',error.stderr)]:
     if data is not None:(commands/f'{i:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   raise
  finally:item['seconds']=time.monotonic()-start;(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 with patch.object(subprocess,'run',recorded),patch.object(tempfile,'TemporaryDirectory',Retained):
  if phase=='queries':
   import tests.test_gnu_tool_queries as selected
   assert Path(selected.__file__).resolve()==root/'tests/test_gnu_tool_queries.py';suite=unittest.defaultTestLoader.loadTestsFromTestCase(selected.GnuToolQueries);assert suite.countTestCases()==3
  else:
   import tests.test_source_snapshots as selected
   assert Path(selected.__file__).resolve()==root/'tests/test_source_snapshots.py'
   suite=unittest.TestSuite([selected.SourceSnapshots('test_tool_supervisor_rejects_late_completion'),selected.SourceSnapshots('test_tool_supervisor_timing_milestones')]);assert suite.countTestCases()==2
  started=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
 record=dict(phase=phase,imported_file=str(Path(selected.__file__).resolve()),tests_run=result.testsRun,failures=[dict(case=t.id(),traceback=e) for t,e in result.failures],errors=[dict(case=t.id(),traceback=e) for t,e in result.errors],skipped=[(t.id(),reason) for t,reason in result.skipped],successful=result.wasSuccessful(),seconds=time.monotonic()-started)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');return 0 if result.wasSuccessful() else 1

if sys.argv[1]=='--child':sys.exit(child(Path(sys.argv[2]),Path(sys.argv[3]),sys.argv[4]))
role=sys.argv[1];assert role in ['red','green'];root=Path('/home/jkh/.worktrees/nanolang/clang18-eof-reap-20261122');out=Path(__file__).resolve().parent/role;out.mkdir(exist_ok=False)
record=dict(role=role,root=str(root),pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),status='preparing',steps=[],limits=['I qualify only candidate3ef native GNU queries, original late-completion/timing controls and the same100ms shell-only EOF observation with unchanged assertions/deadlines. I run no complete or repeated original capture cohort. Every phase runs in a fresh interpreter and verifies its imported file. I retain every native command stream and test fixture, make no shared source edit, and grant no generic tool/full-suite/release acceptance.'])
assert record['pin']=='3ef446575d2b4c818c96cf83d46c1048f0edf441'
names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],cwd=root,text=True).splitlines();record['source_hashes']={n:sha(root/n) for n in names if (root/n).is_file()};record['source_pins']={}
if role=='red':
 override=json.loads((out.parent/'baseline-source-override.json').read_text());assert record['source_hashes'][override['path']]==override['sha256'];record['source_pins'][override['path']]=override['source_pin']
queries=''.join(record['source_pins'].get(name,record['pin'])+':'+name+'\n' for name in record['source_hashes']).encode();blobs=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=queries);cursor=0
for name,value in record['source_hashes'].items():
 end=blobs.index(b'\n',cursor);header=blobs[cursor:end].split();assert header[1]==b'blob';size=int(header[2]);data=blobs[end+1:end+1+size];assert hashlib.sha256(data).hexdigest()==value,name;cursor=end+1+size;assert blobs[cursor:cursor+1]==b'\n';cursor+=1
assert cursor==len(blobs)
initial_status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root);assert initial_status==(b' M src/module_builder.c\n' if role=='red' else b'');record['initial_status']=initial_status.decode()
tools=out/'tools';tools.mkdir()
for name in ['cc','clang']:(tools/name).symlink_to('/usr/bin/clang-18')
env=dict(os.environ,PATH=str(tools)+':/usr/bin:/bin',CC=str(tools/'cc'),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_SHADOW_TIMEOUT_SECONDS='10',PYTHONDONTWRITEBYTECODE='1')
for n in ['NANO_AS_CAPTURE_HELPER','NANO_CC','NANO_BUILD_CACHE','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_TEST_SLOW_RECOVERY','COMPILER_PATH','NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANOLANG_TRANSLATOR_SOURCE_MODULE']:env.pop(n,None)
record['environment']={n:env.get(n) for n in ['PATH','CC','NANOLANG_ROOT','NANO_AS_CAPTURE_HELPER','NANO_SHADOW_TIMEOUT_SECONDS','NANO_CAPTURE_TIMEOUT_MS','COMPILER_PATH','CMD_TIMEOUT','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']};assert all(record['environment'][n] is None for n in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS'])
record['tools']={'/usr/lib/llvm-18/bin/clang':sha('/usr/lib/llvm-18/bin/clang'),'/usr/bin/aarch64-linux-gnu-as':sha('/usr/bin/aarch64-linux-gnu-as')};assert record['tools']['/usr/lib/llvm-18/bin/clang']=='6d99f6207153b8b2063ace5d2a6177debaf6a6b6f31649e03afac07b98ba0b4d';assert record['tools']['/usr/bin/aarch64-linux-gnu-as']=='1ffda50efb6d91b6b05ef933aced099595c36577594c0296c91161f2d13db374'
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def guards():
 assert {n:sha(root/n) for n in record['source_hashes']}==record['source_hashes'];assert {n:sha(n) for n in record['tools']}==record['tools'];assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==initial_status

def step(name,args,timeout):
 entry=dict(name=name,argv=list(map(str,args)),timeout=timeout);record['steps'].append(entry);save();start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as b:done=subprocess.run(args,cwd=root,env=env,stdout=a,stderr=b,timeout=timeout)
 entry.update(returncode=done.returncode,seconds=time.monotonic()-start);save();print(json.dumps(entry),flush=True);return done.returncode
try:
 save();guards();assert step('build',['make','CC='+str(tools/'cc'),'obj/test_module_generation_probe','bin/nano_as_capture.so'],600)==0
 record['tools'].update({str(root/n):sha(root/n) for n in ['obj/test_module_generation_probe','bin/nano_as_capture.so']});guards()
 query=out/'query-products';query.mkdir();rc=step('queries',['/usr/bin/python3',Path(__file__).resolve(),'--child',root,query,'queries'],60);report=json.loads((query/'result.json').read_text());record['queries']=report
 assert report['tests_run']==3 and not report['errors'] and not report['skipped']
 if role=='red':
  failed={item['case'].split('.')[-1] for item in report['failures']};assert rc==1 and failed=={'test_slow_report_stops_at_the_configured_capture_deadline','test_complete_report_preserves_output_and_actual_query_milestone'}
  record['status']='expected-red'
 else:
  assert rc==0 and report['successful'];guards();cohort=out/'source-products';cohort.mkdir();rc=step('late-completion-and-timing',['/usr/bin/python3',Path(__file__).resolve(),'--child',root,cohort,'source'],600);report=json.loads((cohort/'result.json').read_text());record['late_completion_and_timing']=report;assert rc==0 and report['tests_run']==2 and report['successful'] and not report['skipped'];record['status']='passed'
 command='printf ready; exec 1>&- 2>&-; capture_tick=0; while [ "$capture_tick" -lt 1000 ]; do capture_tick=$((capture_tick+1)); done'
 env['NANO_TRACE_BUILD']='1';env['NANO_CAPTURE_TIMEOUT_MS']='100'
 assert step('eof-shell',[root/'obj/test_module_generation_probe','capture-configured',command],5)==0
 assert (out/'eof-shell.stdout').read_bytes()==b'ready'
 trace=(out/'eof-shell.stderr').read_text();times={}
 for n in ['spawn','first-output','eof','reaped']:
  matches=re.findall('phase=tool-'+n+'-ms expected=1 observed=([0-9]+) accepted=1',trace);assert len(matches)==1;times[n]=int(matches[0])
 record['eof_shell_observation']=dict(command=command,budget_ms=100,milliseconds=times,eof_to_reap_ms=times['reaped']-times['eof'],limits='I record one native Linux observation, not a latency guarantee or a cause of the hosted Clang timeout.')
 env.pop('NANO_TRACE_BUILD');env.pop('NANO_CAPTURE_TIMEOUT_MS')
 guards();record['source_and_tool_guards_unchanged']=True
except BaseException as error:record.update(status='failed',error=repr(error));(out/'exception').write_text(traceback.format_exc())
finally:save()
print(json.dumps({k:v for k,v in record.items() if k not in ['source_hashes','queries','external_and_slow','tools']}),flush=True);sys.exit(0 if record['status'] in ['expected-red','passed'] else 1)
