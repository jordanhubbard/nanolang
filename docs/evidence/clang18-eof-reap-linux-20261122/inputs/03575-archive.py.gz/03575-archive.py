from pathlib import Path
import os,json,hashlib,gzip,stat,subprocess
root=Path('/home/jkh/.worktrees/nanolang/clang18-eof-reap-20261122');control=Path(__file__).resolve().parent
repo=Path('/home/jkh/.worktrees/nanolang/service-module-integration');out=repo/'docs/evidence/clang18-eof-reap-linux-20261122';(out/'inputs').mkdir(parents=True,exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest();baseline=json.loads((control/'green/manifest.json').read_text());expected=baseline['source_hashes'];pin=baseline['pin']
assert pin=='3ef446575d2b4c818c96cf83d46c1048f0edf441' and baseline['status']=='passed' and baseline['source_and_tool_guards_unchanged']
assert baseline['queries']['tests_run']==3 and baseline['queries']['successful'] and baseline['late_completion_and_timing']['tests_run']==2 and baseline['late_completion_and_timing']['successful']
assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha(Path(n).read_bytes())==v for n,v in baseline['tools'].items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
paths={p for p in control.rglob('*') if p.is_file()};paths.update(root/name for name in expected);paths.update(Path(name) for name in baseline['tools']);files=[];seen={};symlinks={str(p):os.readlink(p) for p in control.rglob('*') if p.is_symlink()}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(implementation=pin,source_hashes=expected,files=files,symlinks=symlinks,issue=1159,root=str(root),tools=baseline['tools'],verification=baseline,limits=['I review only the post-EOF interval correction from5bb and independently qualify three original GNU-query plus two original late-completion/timing methods, and one exact shell-only EOF observation at100ms. The candidate preserves fresh clocks/cleanup/output/NUL/size/exit/process-group/reap guards. One native Linux observation records EOF1/reap3ms, not a latency bound or hosted-timeout cause. All source/tool guards and original assertions/deadlines remain unchanged. Original qualification roots are untouched; complete hosted qualification and admission remain with Puck.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_files=len(expected),symlinks=len(symlinks))))
