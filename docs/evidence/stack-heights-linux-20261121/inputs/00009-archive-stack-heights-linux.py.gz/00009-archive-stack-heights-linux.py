from pathlib import Path
import sys,json,subprocess,hashlib,gzip,re
root=Path.cwd();out=root/'docs/evidence/stack-heights-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest();paths={Path(__file__).resolve()}
controller=root/'.test_output/stack-heights-qualified-stage1';state=json.loads((controller/'manifest.json').read_text());assert state['returncode']==0 and state['original_bootstrap_guards_unchanged']
qualified=Path(re.findall(r'I retain ordinary height-walk products at (/[\S]+)',(controller/'stdout').read_text())[0]);cohort=json.loads((qualified/'manifest.json').read_text());assert len(cohort['routes'])==5 and len(cohort['cases'])==3154
# I retain only this component's named terminals/products, rather than copying
# unrelated module caches, existing evidence archives or other workers' roots.
for p in (root/'.test_output').glob('stack-heights-*'):
 if p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file())
 elif p.is_file():paths.add(p)
for name in ['run-stack-heights-qualified-stage1.py','run-stack-heights-c-sanitizers.py']:
 paths.add(root/'.test_output'/name)
for folder in ['src','src_nano','modules','std','stdlib','include','scripts','tests','spec']:
 for name in subprocess.check_output(['git','ls-files',folder],cwd=root,text=True).splitlines():
  p=root/name
  if p.is_file():paths.add(p)
for name in ['src_nano/nvm2c/stack_heights.nano','tests/nvm2c_stack_heights_driver.nano','tests/nvm2c_stack_heights_reference.c','tests/test_nanolang_translator_stack_heights.py','Makefile.gnu','GNUmakefile','docs/NANOLANG_NANOISA_C_TRANSLATOR.md','docs/ROADMAP.md','obj/nvm2c_stack_heights_reference','obj/test_verifier','obj/fixture_identifier_lexer','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nanoisa','bin/nano_aot_runtime.o','bin/nano_as_capture.so']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
for path in b.manifest['hosts']:paths.add(Path(path))
source_map={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths if p.is_relative_to(root) and str(p.relative_to(root)).startswith(('src/','src_nano/','modules/','std/','stdlib/','include/','scripts/','tests/','spec/'))}
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),qualified_work=str(qualified),qualified_provider=state,source_hashes=source_map,limits=['I compare the unchanged actual shared C height/retain helper after safe representable decode/signature/index preconditions. This is not full module/profile/ownership-origin/type/resource admission or pure C emission. I retain all five final routes using the actual guarded qualified bdffa4ccc native Stage1; earlier three-route development products and initial rejected shadow source remain separately identifiable. Ordinary shadows retain10 seconds. I start no Darwin gate while the peer owns its active observed c908523c3 run. Products deleted by original builders are not represented as retained.'])
entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();entries.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=entries;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for e in entries:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum((out/p).stat().st_size for p in seen.values()),source_files=len(source_map),qualified_work=str(qualified))))
