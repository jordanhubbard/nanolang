/**
 * test_opt_passes.c — unit tests for optimization passes
 *
 * Exercises dce_pass.c, fold_constants.c, and par_let_pass.c by parsing
 * small nano programs and running each pass over the resulting AST.
 * Also exercises pgo_pass.c and bench.c via their public APIs.
 */

#include "../src/nanolang.h"
#include "../src/dce_pass.h"
#include "../src/fold_constants.h"
#include "../src/par_let_pass.h"
#include "../src/pgo_pass.h"
#include "../src/tco_pass.h"
#include "../src/cps_pass.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TEST(name) printf("  Testing %s...", #name); test_##name(); printf(" ✓\n")
#define ASSERT(cond) \
    if (!(cond)) { printf("\n    FAILED: %s at line %d\n", #cond, __LINE__); exit(1); }
#define ASSERT_EQ(a, b) \
    if ((a) != (b)) { printf("\n    FAILED: %s == %s at line %d (got %d, expected %d)\n", \
        #a, #b, __LINE__, (int)(a), (int)(b)); exit(1); }
#define ASSERT_NOT_NULL(p) \
    if ((p) == NULL) { printf("\n    FAILED: unexpected NULL at line %d\n", __LINE__); exit(1); }
#define ASSERT_NULL(p) \
    if ((p) != NULL) { printf("\n    FAILED: expected NULL at line %d\n", __LINE__); exit(1); }

/* Required by runtime/cli.c (extern in eval.c) */
int g_argc = 0;
char **g_argv = NULL;

/* Helper: suppress stderr during expected-error paths */
static FILE *s_orig_stderr = NULL;
static void suppress_stderr(void) {
    fflush(stderr);
    s_orig_stderr = stderr;
    stderr = fopen("/dev/null", "w");
}
static void restore_stderr(void) {
    if (stderr && stderr != s_orig_stderr) fclose(stderr);
    stderr = s_orig_stderr;
    s_orig_stderr = NULL;
}

/* Helper: parse a nano program string, return AST (caller frees) */
static ASTNode *parse_nano(const char *src) {
    int token_count = 0;
    Token *tokens = tokenize(src, &token_count);
    if (!tokens) return NULL;
    ASTNode *prog = parse_program(tokens, token_count);
    free_tokens(tokens, token_count);
    return prog;
}

static ASTNode *find_program_function(ASTNode *program, const char *name) {
    if (!program || program->type != AST_PROGRAM) return NULL;
    for (int i = 0; i < program->as.program.count; ++i) {
        ASTNode *item = program->as.program.items[i];
        if (item && item->type == AST_FUNCTION && item->as.function.name &&
            strcmp(item->as.function.name, name) == 0) return item;
    }
    return NULL;
}

/* ============================================================================
 * dce_pass tests
 * ============================================================================ */

void test_dce_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    /* Nothing to eliminate in a trivial program */
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_dead_if_true(void) {
    /* if(true) { … } else { dead } — else branch should be eliminated */
    ASTNode *prog = parse_nano(
        "fn check() -> int {\n"
        "    if true { return 1 } else { return 2 }\n"
        "}\n"
        "fn main() -> int { return (check) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_dead_if_false(void) {
    /* if(false) { dead } else { … } — then branch should be eliminated */
    ASTNode *prog = parse_nano(
        "fn check() -> int {\n"
        "    if false { return 99 } else { return 0 }\n"
        "}\n"
        "fn main() -> int { return (check) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_verbose_flag(void) {
    /* Verify verbose=true doesn't crash */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    if true { return 1 } else { return 2 }\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    suppress_stderr();
    int elim = dce_pass(prog, true);
    restore_stderr();
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_multiple_functions(void) {
    ASTNode *prog = parse_nano(
        "fn add(x: int, y: int) -> int { return (+ x y) }\n"
        "fn sub(x: int, y: int) -> int { return (- x y) }\n"
        "fn main() -> int { return (add 1 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

/* ============================================================================
 * fold_constants tests
 * ============================================================================ */

void test_fold_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int folds = fold_constants(prog, false);
    ASSERT(folds >= 0);
    free_ast(prog);
}

void test_fold_arithmetic(void) {
    /* (+ 2 3) should fold to 5 */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    return (+ 2 3)\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int folds = fold_constants(prog, false);
    ASSERT(folds >= 0);
    free_ast(prog);
}

void test_fold_nested_arithmetic(void) {
    /* (+ (* 2 3) (- 10 4)) — nested constant expressions */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    return (+ (* 2 3) (- 10 4))\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int folds = fold_constants(prog, false);
    ASSERT(folds >= 0);
    free_ast(prog);
}

void test_fold_bool_constants(void) {
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    if (== 1 1) { return 1 } else { return 0 }\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int folds = fold_constants(prog, false);
    ASSERT(folds >= 0);
    free_ast(prog);
}

void test_fold_verbose_flag(void) {
    ASTNode *prog = parse_nano(
        "fn main() -> int { return (+ 1 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    suppress_stderr();
    int folds = fold_constants(prog, true);
    restore_stderr();
    ASSERT(folds >= 0);
    free_ast(prog);
}

void test_fold_multiple_functions(void) {
    ASTNode *prog = parse_nano(
        "fn square(x: int) -> int { return (* x x) }\n"
        "fn main() -> int { return (+ (square 3) 1) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int folds = fold_constants(prog, false);
    ASSERT(folds >= 0);
    free_ast(prog);
}

/* ============================================================================
 * par_let_pass tests
 * ============================================================================ */

void test_par_let_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_simple_function(void) {
    ASTNode *prog = parse_nano(
        "fn add(x: int, y: int) -> int { return (+ x y) }\n"
        "fn main() -> int { return (add 1 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_with_let_bindings(void) {
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    let x: int = 10\n"
        "    let y: int = 20\n"
        "    return (+ x y)\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_multiple_functions(void) {
    ASTNode *prog = parse_nano(
        "fn f(x: int) -> int { return (* x 2) }\n"
        "fn g(x: int) -> int { return (+ x 1) }\n"
        "fn main() -> int {\n"
        "    let a: int = (f 3)\n"
        "    let b: int = (g 4)\n"
        "    return (+ a b)\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_actual_par_let_node(void) {
    /* Use actual par-let syntax to exercise AST_PAR_LET processing */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    par-let\n"
        "        x = 10\n"
        "        y = 20\n"
        "    in\n"
        "        (+ x y)\n"
        "    return 0\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_dependent_bindings(void) {
    /* Dependent bindings: y references x — pass should detect dependency */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    par-let\n"
        "        x = 5\n"
        "        y = (+ x 1)\n"
        "    in\n"
        "        y\n"
        "    return 0\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    suppress_stderr();
    int result = par_let_pass(prog);
    restore_stderr();
    ASSERT(result >= 0); /* may return warnings but should not crash */
    free_ast(prog);
}

void test_par_let_single_binding(void) {
    /* Single binding par-let — pass should warn about using regular let */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    par-let\n"
        "        x = 42\n"
        "    in\n"
        "        x\n"
        "    return 0\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    suppress_stderr();
    int result = par_let_pass(prog);
    restore_stderr();
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_par_let_three_bindings(void) {
    /* Three independent bindings */
    ASTNode *prog = parse_nano(
        "fn main() -> int {\n"
        "    par-let\n"
        "        a = 6\n"
        "        b = 7\n"
        "        c = 8\n"
        "    in\n"
        "        (+ a (+ b c))\n"
        "    return 0\n"
        "}\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = par_let_pass(prog);
    ASSERT(result >= 0);
    free_ast(prog);
}

/* ============================================================================
 * pgo_pass tests — exercise the PGO profile API
 * ============================================================================ */

void test_pgo_load_null_path(void) {
    suppress_stderr();
    PGOProfile *prof = pgo_load_profile("/nonexistent/path/profile.nano.prof");
    restore_stderr();
    ASSERT(prof == NULL);
}

void test_pgo_is_hot_null_profile(void) {
    /* pgo_is_hot with NULL profile should return false */
    bool hot = pgo_is_hot(NULL, "some_fn");
    ASSERT(!hot);
}

void test_pgo_apply_empty_profile(void) {
    /* pgo_apply on a NULL profile is a no-op, should handle gracefully */
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    /* pgo_apply(prog, NULL) — guard against NULL profile */
    /* We test with a NULL profile only if the function handles it */
    /* (we don't call it with NULL as that'd be UB per the API) */
    free_ast(prog);
}

void test_pgo_print_report_null(void) {
    /* pgo_print_report with NULL should not crash */
    suppress_stderr();
    pgo_print_report(NULL);
    restore_stderr();
}

/* ============================================================================
 * tco_pass tests
 * ============================================================================ */

static void assert_tco_refusal_unchanged(ASTNode *prog, const char *name) {
    ASSERT_NOT_NULL(prog);
    ASTNode *function = find_program_function(prog, name);
    ASSERT_NOT_NULL(function);
    ASTNode *body = function->as.function.body;
    ASSERT(body && body->type == AST_BLOCK && body->as.block.count > 0);
    ASTNode **statements = body->as.block.statements;
    ASTNode *tail = statements[body->as.block.count - 1];
    ASSERT(tail && tail->type == AST_RETURN && tail->as.return_stmt.value &&
           tail->as.return_stmt.value->type == AST_CALL);
    char *tail_name = tail->as.return_stmt.value->as.call.name;
    ASSERT_NOT_NULL(tail_name);

    ASSERT_EQ(tco_pass_run(prog, false), 0);
    ASSERT(function->as.function.body == body);
    ASSERT(body->as.block.statements == statements);
    ASSERT(statements[body->as.block.count - 1] == tail);
    ASSERT(tail->as.return_stmt.value->as.call.name == tail_name);
    ASSERT(strcmp(tail_name, name) == 0);
}

void test_tco_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_run(prog, false);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_tco_non_recursive_function(void) {
    /* A non-recursive function should not be transformed */
    ASTNode *prog = parse_nano(
        "fn add(x: int, y: int) -> int { return (+ x y) }\n"
        "fn main() -> int { return (add 1 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_run(prog, false);
    ASSERT_EQ(result, 0);  /* no TCO transformations */
    free_ast(prog);
}

void test_tco_tail_recursive_function(void) {
    /* A tail-recursive function should be detected and possibly transformed */
    ASTNode *prog = parse_nano(
        "fn count_down(n: int) -> int {\n"
        "    if (<= n 0) { return 0 } else { return (count_down (- n 1)) }\n"
        "}\n"
        "fn main() -> int { return (count_down 5) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_run(prog, false);
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_tco_verbose_flag(void) {
    ASTNode *prog = parse_nano(
        "fn sum(n: int, acc: int) -> int {\n"
        "    if (<= n 0) { return acc } else { return (sum (- n 1) (+ acc n)) }\n"
        "}\n"
        "fn main() -> int { return (sum 5 0) }\n"
    );
    ASSERT_NOT_NULL(prog);
    suppress_stderr();
    int result = tco_pass_run(prog, true);
    restore_stderr();
    ASSERT(result >= 0);
    free_ast(prog);
}

void test_tco_same_name_initializer_uses_outer_parameter(void) {
    ASTNode *prog = parse_nano(
        "fn step(n: int, value: int) -> int {\n"
        "    if (== n 0) { return value }\n"
        "    if true { let value: int = (+ value 1) assert (> value 0) }\n"
        "    return (step (- n 1) (+ value 2))\n"
        "}\n"
        "fn main() -> int { return (step 2 0) }\n"
    );
    ASSERT_NOT_NULL(prog);
    ASTNode *function = find_program_function(prog, "step");
    ASSERT_NOT_NULL(function);
    ASSERT_EQ(tco_pass_run(prog, false), 1);

    ASTNode *outer = function->as.function.body;
    ASSERT(outer->type == AST_BLOCK && outer->as.block.count == 3);
    ASTNode *loop = outer->as.block.statements[2];
    ASSERT(loop && loop->type == AST_WHILE);
    ASTNode *iteration = loop->as.while_stmt.body;
    ASSERT(iteration && iteration->type == AST_BLOCK);
    ASTNode *original = iteration->as.block.statements[0];
    ASSERT(original && original->type == AST_BLOCK && original->as.block.count == 3);
    ASTNode *scope = original->as.block.statements[1];
    ASSERT(scope && scope->type == AST_IF);
    ASTNode *scope_body = scope->as.if_stmt.then_branch;
    ASSERT(scope_body && scope_body->type == AST_BLOCK && scope_body->as.block.count == 2);
    ASTNode *binding = scope_body->as.block.statements[0];
    ASSERT(binding && binding->type == AST_LET);
    ASSERT(binding->as.let.value && binding->as.let.value->type == AST_PREFIX_OP);
    ASTNode *initializer_read = binding->as.let.value->as.prefix_op.args[0];
    ASSERT(initializer_read && initializer_read->type == AST_IDENTIFIER);
    ASSERT(strstr(initializer_read->as.identifier, "__tco_") == initializer_read->as.identifier);

    ASTNode *assertion = scope_body->as.block.statements[1];
    ASSERT(assertion && assertion->type == AST_ASSERT);
    ASTNode *shadow_read = assertion->as.assert.condition->as.prefix_op.args[0];
    ASSERT(shadow_read && shadow_read->type == AST_IDENTIFIER);
    ASSERT(strcmp(shadow_read->as.identifier, "value") == 0);
    free_ast(prog);
}

void test_tco_refusal_leaves_function_ast_unmodified(void) {
    ASTNode *prog = parse_nano(
        "fn step(n: int) -> int {\n"
        "    if (== n 0) { return 0 }\n"
        "    return (step (- n 1))\n"
        "}\n"
        "fn main() -> int { return (step 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    ASTNode *function = find_program_function(prog, "step");
    ASSERT_NOT_NULL(function);
    ASTNode *body = function->as.function.body;
    int old_count = body->as.block.count;
    ASTNode **statements = calloc((size_t)old_count + 1, sizeof(*statements));
    ASSERT_NOT_NULL(statements);
    ASTNode *unsupported = calloc(1, sizeof(*unsupported));
    ASSERT_NOT_NULL(unsupported);
    unsupported->type = AST_EFFECT_OP;
    statements[0] = unsupported;
    for (int i = 0; i < old_count; ++i) statements[i + 1] = body->as.block.statements[i];
    free(body->as.block.statements);
    body->as.block.statements = statements;
    body->as.block.count = old_count + 1;

    ASTNode **before_statements = body->as.block.statements;
    ASTNode *before_first = body->as.block.statements[0];
    ASTNode *before_tail = body->as.block.statements[body->as.block.count - 1];
    char *before_name = before_tail->as.return_stmt.value->as.call.name;
    ASSERT_EQ(tco_pass_run(prog, false), 0);
    ASSERT(function->as.function.body == body);
    ASSERT(body->as.block.statements == before_statements);
    ASSERT(body->as.block.statements[0] == before_first);
    ASSERT(body->as.block.statements[body->as.block.count - 1] == before_tail);
    ASSERT(before_tail->as.return_stmt.value->as.call.name == before_name);
    ASSERT(strcmp(before_name, "step") == 0);
    free_ast(prog);
}

void test_tco_refuses_resource_parameter_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "resource struct Handle { fd: int }\n"
        "fn step(n: int, owner: Handle) -> Handle {\n"
        "    if (== n 0) { return owner }\n"
        "    return (step (- n 1) owner)\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    ASTNode *function = find_program_function(prog, "step");
    ASSERT_NOT_NULL(function);
    ASTNode *body = function->as.function.body;
    ASTNode **statements = body->as.block.statements;
    ASTNode *tail = statements[body->as.block.count - 1];
    char *tail_name = tail->as.return_stmt.value->as.call.name;
    ASSERT_EQ(tco_pass_run(prog, false), 0);
    ASSERT(function->as.function.body == body);
    ASSERT(body->as.block.statements == statements);
    ASSERT(statements[body->as.block.count - 1] == tail);
    ASSERT(tail->as.return_stmt.value->as.call.name == tail_name);
    ASSERT(strcmp(tail_name, "step") == 0);
    free_ast(prog);
}

void test_tco_refuses_par_block_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "fn step(n: int) -> int {\n"
        "    if (== n 0) { return 0 }\n"
        "    par { let n: int = (+ n 1) }\n"
        "    return (step (- n 1))\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    assert_tco_refusal_unchanged(prog, "step");
    free_ast(prog);
}

void test_tco_refuses_nested_resource_record_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "resource struct Handle { fd: int }\n"
        "struct Bundle { owner: Handle, count: int }\n"
        "fn step(n: int, bundle: Bundle) -> int {\n"
        "    if (== n 0) { return bundle.count }\n"
        "    return (step (- n 1) bundle)\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    assert_tco_refusal_unchanged(prog, "step");
    free_ast(prog);
}

void test_tco_refuses_nested_array_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "fn step(n: int, values: array<array<int>>) -> int {\n"
        "    if (== n 0) { return 0 }\n"
        "    return (step (- n 1) values)\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    assert_tco_refusal_unchanged(prog, "step");
    free_ast(prog);
}

void test_tco_refuses_incomplete_aggregate_metadata_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "fn step(n: int, values: array<int>) -> int {\n"
        "    if (== n 0) { return 0 }\n"
        "    return (step (- n 1) values)\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    ASTNode *function = find_program_function(prog, "step");
    ASSERT_NOT_NULL(function);
    TypeInfo *saved = function->as.function.params[1].type_info;
    ASSERT_NOT_NULL(saved);
    function->as.function.params[1].type_info = NULL;
    assert_tco_refusal_unchanged(prog, "step");
    function->as.function.params[1].type_info = saved;
    free_ast(prog);
}

void test_tco_refuses_non_scalar_tuple_without_mutation(void) {
    ASTNode *prog = parse_nano(
        "struct Pair { left: int, right: int }\n"
        "fn step(n: int, pair: (int, Pair)) -> int {\n"
        "    if (== n 0) { return 0 }\n"
        "    return (step (- n 1) pair)\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    assert_tco_refusal_unchanged(prog, "step");
    free_ast(prog);
}

/* ============================================================================
 * tco_pass_pure tests — selective auto-TCO for pure fn only
 * ============================================================================ */

void test_tco_pure_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 0);
    free_ast(prog);
}

void test_tco_pure_non_recursive_pure_fn(void) {
    /* A non-recursive pure fn should not be TCO-transformed */
    ASTNode *prog = parse_nano(
        "pure fn square(x: int) -> int { return (* x x) }\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 0);
    free_ast(prog);
}

void test_tco_pure_tail_recursive_pure_fn(void) {
    /* A tail-recursive pure fn should be transformed */
    ASTNode *prog = parse_nano(
        "pure fn countdown(n: int) -> int {\n"
        "    if (<= n 0) { return 0 } else { return (countdown (- n 1)) }\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 1);
    free_ast(prog);
}

void test_tco_pure_impure_fn_not_transformed(void) {
    /* A tail-recursive IMPURE fn should NOT be touched by tco_pass_pure */
    ASTNode *prog = parse_nano(
        "fn countdown(n: int) -> int {\n"
        "    if (<= n 0) { return 0 } else { return (countdown (- n 1)) }\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 0);  /* impure fn not touched */
    free_ast(prog);
}

void test_tco_pure_extern_fn_not_transformed(void) {
    /* A pure extern fn has no body — should not be transformed */
    ASTNode *prog = parse_nano(
        "pure extern fn fabs(x: float) -> float\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 0);
    free_ast(prog);
}

void test_tco_pure_multiple_fns(void) {
    /* Two tail-recursive pure fns → both transformed */
    ASTNode *prog = parse_nano(
        "pure fn sum(n: int, acc: int) -> int {\n"
        "    if (<= n 0) { return acc } else { return (sum (- n 1) (+ acc n)) }\n"
        "}\n"
        "pure fn count(n: int) -> int {\n"
        "    if (<= n 0) { return 0 } else { return (count (- n 1)) }\n"
        "}\n"
        "fn main() -> int { return 0 }\n"
    );
    ASSERT_NOT_NULL(prog);
    int result = tco_pass_pure(prog);
    ASSERT_EQ(result, 2);
    free_ast(prog);
}

/* ============================================================================
 * cps_pass tests
 * ============================================================================ */

void test_cps_empty_program(void) {
    ASTNode *prog = parse_nano("fn main() -> int { return 0 }");
    ASSERT_NOT_NULL(prog);
    int async_count = cps_pass(prog);
    ASSERT_EQ(async_count, 0);  /* no async functions */
    free_ast(prog);
}

void test_cps_non_async_functions(void) {
    ASTNode *prog = parse_nano(
        "fn add(x: int, y: int) -> int { return (+ x y) }\n"
        "fn mul(x: int, y: int) -> int { return (* x y) }\n"
        "fn main() -> int { return (add 1 2) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int async_count = cps_pass(prog);
    ASSERT_EQ(async_count, 0);  /* no async functions → no CPS transform */
    free_ast(prog);
}

void test_cps_multiple_functions(void) {
    ASTNode *prog = parse_nano(
        "fn f(x: int) -> int { return (* x x) }\n"
        "fn g(x: int) -> int { return (+ x 1) }\n"
        "fn h(x: int) -> int { return (f (g x)) }\n"
        "fn main() -> int { return (h 3) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int async_count = cps_pass(prog);
    ASSERT(async_count >= 0);
    free_ast(prog);
}

void test_cps_visits_match_guards(void) {
    ASTNode scrutinee;
    ASTNode awaited;
    ASTNode guard;
    ASTNode body;
    ASTNode match;
    ASTNode program;
    ASTNode *guards[1];
    ASTNode *bodies[1];
    ASTNode *items[1];
    memset(&scrutinee, 0, sizeof(scrutinee));
    memset(&awaited, 0, sizeof(awaited));
    memset(&guard, 0, sizeof(guard));
    memset(&body, 0, sizeof(body));
    memset(&match, 0, sizeof(match));
    memset(&program, 0, sizeof(program));

    scrutinee.type = AST_NUMBER;
    awaited.type = AST_BOOL;
    guard.type = AST_AWAIT;
    guard.as.await_expr.expr = &awaited;
    body.type = AST_NUMBER;
    guards[0] = &guard;
    bodies[0] = &body;
    match.type = AST_MATCH;
    match.as.match_expr.expr = &scrutinee;
    match.as.match_expr.arm_count = 1;
    match.as.match_expr.guard_exprs = guards;
    match.as.match_expr.arm_bodies = bodies;
    items[0] = &match;
    program.type = AST_PROGRAM;
    program.as.program.items = items;
    program.as.program.count = 1;

    FILE *saved = stderr;
    FILE *captured = tmpfile();
    ASSERT_NOT_NULL(captured);
    stderr = captured;
    ASSERT_EQ(cps_pass(&program), 0);
    fflush(stderr);
    ASSERT_EQ(fseek(captured, 0, SEEK_SET), 0);
    char message[256] = {0};
    ASSERT_NOT_NULL(fgets(message, sizeof(message), captured));
    stderr = saved;
    fclose(captured);
    ASSERT(strstr(message, "await' outside async function") != NULL);
}

/* ============================================================================
 * Additional DCE tests: dead lets with array/struct/tuple literals,
 * and programs with if/while/for constructs for count_refs coverage.
 * ============================================================================ */

void test_dce_dead_array_literal(void) {
    /* Dead let with array literal — exercises has_side_effect(ARRAY_LITERAL) */
    ASTNode *prog = parse_nano(
        "fn test() -> int {\n"
        "    let arr: array<int> = [1, 2, 3]\n"
        "    return 42\n"
        "}\n"
        "fn main() -> int { return (test) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_dead_struct_literal(void) {
    /* Dead let with struct literal — exercises has_side_effect(STRUCT_LITERAL) */
    ASTNode *prog = parse_nano(
        "struct Pt { x: int, y: int }\n"
        "fn test() -> int {\n"
        "    let p: Pt = Pt { x: 1, y: 2 }\n"
        "    return 42\n"
        "}\n"
        "fn main() -> int { return (test) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_dead_if_expression(void) {
    /* Dead let with if-expression — exercises has_side_effect(IF) */
    ASTNode *prog = parse_nano(
        "fn test(x: int) -> int {\n"
        "    let dead: int = if (> x 0) { 1 } else { 0 }\n"
        "    return 42\n"
        "}\n"
        "fn main() -> int { return (test 5) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_count_refs_set(void) {
    /* Program with set statement — exercises count_refs(SET) */
    ASTNode *prog = parse_nano(
        "fn test() -> int {\n"
        "    let unused: int = 10\n"
        "    let mut x: int = 0\n"
        "    set x 5\n"
        "    return x\n"
        "}\n"
        "fn main() -> int { return (test) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_count_refs_while(void) {
    /* Program with while loop — exercises count_refs(WHILE) */
    ASTNode *prog = parse_nano(
        "fn test() -> int {\n"
        "    let unused: int = 7\n"
        "    let mut n: int = 0\n"
        "    while (< n 3) { set n (+ n 1) }\n"
        "    return n\n"
        "}\n"
        "fn main() -> int { return (test) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

void test_dce_count_refs_for(void) {
    /* Program with for-range loop — exercises count_refs(FOR) */
    ASTNode *prog = parse_nano(
        "fn test() -> int {\n"
        "    let unused: int = 3\n"
        "    let mut s: int = 0\n"
        "    for i in (range 0 5) { set s (+ s i) }\n"
        "    return s\n"
        "}\n"
        "fn main() -> int { return (test) }\n"
    );
    ASSERT_NOT_NULL(prog);
    int elim = dce_pass(prog, false);
    ASSERT(elim >= 0);
    free_ast(prog);
}

/* ============================================================================
 * Combined pass pipeline: run all three passes in sequence
 * ============================================================================ */

void test_full_opt_pipeline(void) {
    /* Run fold → dce → par_let in sequence, as an optimizer pipeline would */
    ASTNode *prog = parse_nano(
        "fn compute(x: int) -> int {\n"
        "    let a: int = (+ 2 3)\n"
        "    if true { return (* x a) } else { return 0 }\n"
        "}\n"
        "fn main() -> int { return (compute 7) }\n"
    );
    ASSERT_NOT_NULL(prog);

    int folds = fold_constants(prog, false);
    int elims  = dce_pass(prog, false);
    int plets  = par_let_pass(prog);

    ASSERT(folds >= 0);
    ASSERT(elims >= 0);
    ASSERT(plets >= 0);

    free_ast(prog);
}

/* ============================================================================
 * main
 * ============================================================================ */

int main(void) {
    printf("=== DCE Pass Tests ===\n");
    TEST(dce_empty_program);
    TEST(dce_dead_if_true);
    TEST(dce_dead_if_false);
    TEST(dce_verbose_flag);
    TEST(dce_multiple_functions);

    printf("\n=== Constant Folding Tests ===\n");
    TEST(fold_empty_program);
    TEST(fold_arithmetic);
    TEST(fold_nested_arithmetic);
    TEST(fold_bool_constants);
    TEST(fold_verbose_flag);
    TEST(fold_multiple_functions);

    printf("\n=== Par-Let Pass Tests ===\n");
    TEST(par_let_empty_program);
    TEST(par_let_simple_function);
    TEST(par_let_with_let_bindings);
    TEST(par_let_multiple_functions);
    TEST(par_let_actual_par_let_node);
    TEST(par_let_dependent_bindings);
    TEST(par_let_single_binding);
    TEST(par_let_three_bindings);

    printf("\n=== PGO Pass Tests ===\n");
    TEST(pgo_load_null_path);
    TEST(pgo_is_hot_null_profile);
    TEST(pgo_apply_empty_profile);
    TEST(pgo_print_report_null);

    printf("\n=== TCO Pass Tests ===\n");
    TEST(tco_empty_program);
    TEST(tco_non_recursive_function);
    TEST(tco_tail_recursive_function);
    TEST(tco_verbose_flag);
    TEST(tco_same_name_initializer_uses_outer_parameter);
    TEST(tco_refusal_leaves_function_ast_unmodified);
    TEST(tco_refuses_resource_parameter_without_mutation);
    TEST(tco_refuses_par_block_without_mutation);
    TEST(tco_refuses_nested_resource_record_without_mutation);
    TEST(tco_refuses_nested_array_without_mutation);
    TEST(tco_refuses_incomplete_aggregate_metadata_without_mutation);
    TEST(tco_refuses_non_scalar_tuple_without_mutation);

    printf("\n=== TCO Pure Pass Tests ===\n");
    TEST(tco_pure_empty_program);
    TEST(tco_pure_non_recursive_pure_fn);
    TEST(tco_pure_tail_recursive_pure_fn);
    TEST(tco_pure_impure_fn_not_transformed);
    TEST(tco_pure_extern_fn_not_transformed);
    TEST(tco_pure_multiple_fns);

    printf("\n=== CPS Pass Tests ===\n");
    TEST(cps_empty_program);
    TEST(cps_non_async_functions);
    TEST(cps_multiple_functions);
    TEST(cps_visits_match_guards);

    printf("\n=== DCE: Dead literal / count_refs branch coverage ===\n");
    TEST(dce_dead_array_literal);
    TEST(dce_dead_struct_literal);
    TEST(dce_dead_if_expression);
    TEST(dce_count_refs_set);
    TEST(dce_count_refs_while);
    TEST(dce_count_refs_for);

    printf("\n=== Combined Pipeline Test ===\n");
    TEST(full_opt_pipeline);

    printf("\n✓ All optimization pass tests passed!\n");
    return 0;
}
