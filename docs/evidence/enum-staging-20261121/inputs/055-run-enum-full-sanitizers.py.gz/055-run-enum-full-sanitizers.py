from pathlib import Path
import json,subprocess,os,time,shutil
root=Path.cwd();out=root/'.test_output/enum-ownership-full-sanitizers';out.mkdir(exist_ok=False);m=json.loads((root/'.test_output/enum-ownership-baseline/manifest.json').read_text());common=m['argv'][:-2];env=dict(os.environ,**m['environment']);record=dict(steps=[],limits=['I rerun the complete original evaluator with all matching instrumented providers and a rebuilt matching native fixture. Remaining full leaks stay failures under #1149; I claim no matching full before/after total because my enum test now executes three shadows.'])
for label,argv in [('matching-native-helper',common+['-B','obj/test_interpreter_ffi_native.so']),('complete-original',m['argv'][:-1]+['test-eval'])]:
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(argv,env=env,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 if label=='matching-native-helper':assert r.returncode==0
if (root/'tests/test_eval').exists():shutil.copy2(root/'tests/test_eval',out/'actual-complete-driver')
print([(x['label'],x['returncode']) for x in record['steps']])
