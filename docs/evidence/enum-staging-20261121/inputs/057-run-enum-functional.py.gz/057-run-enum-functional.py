from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
root=Path.cwd();out=root/'.test_output/enum-ownership-functional';out.mkdir(exist_ok=False);opts={x.partition('=')[0]:x.partition('=')[2] for x in (root/'.test_output/cycle-test-inputs.log').read_text().splitlines() if x.startswith('CYCLE_TEST_')};env=dict(os.environ,PATH='/usr/bin:/bin:/usr/sbin:/sbin');env.pop('ASAN_OPTIONS',None);common=['make','-f','Makefile.gnu','-j4','CC=/usr/bin/cc','CFLAGS='+opts['CYCLE_TEST_CFLAGS'],'LDFLAGS='+opts['CYCLE_TEST_LDFLAGS']];record=dict(steps=[],source_sha256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['src/eval.c','src/env.c','tests/test_eval.c','tests/test_eval_enum_ownership.c']})
def run(args,label):
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(args,env=env,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
run(common+['-B','obj/test_interpreter_ffi_native.so'],'matching-native-helper')
run(common+['OBJ_DIR=.test_output/obj-enum-functional','test-eval','test-eval-enum-ownership','test-env-scoping'],'complete-functional')
print('I passed my complete original evaluator, repeated-shadow enum and environment scope controls.')
