from pathlib import Path
import subprocess,shlex,json,hashlib,time,os,shutil
root=Path.cwd();out=root/'.test_output/enum-ownership-functional';lines=(out/'complete-functional.stdout').read_text().splitlines();matches=[shlex.split(x) for x in lines if x.startswith('/usr/bin/cc ') and ' -o tests/test_eval ' in x];assert len(matches)==1;args=matches[0];idx=args.index('-o')+1;assert args[idx]=='tests/test_eval';args[idx]=str(out/'retained-test-eval');env=dict(os.environ,PATH='/usr/bin:/bin:/usr/sbin:/sbin');env.pop('ASAN_OPTIONS',None);record=dict(original_cleanup='I preserve the successful original Make terminal; its original recipe removes its test executable. I derive and execute this separately retained driver with the same source/providers/flags and only an explicit output path.',steps=[])
for label,argv in [('link-retained-driver',args),('execute-retained-driver',[args[idx]])]:
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(argv,cwd=root,env=env,stdout=a,stderr=b,timeout=180)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));assert r.returncode==0,label
record['sha256']=hashlib.sha256(Path(args[idx]).read_bytes()).hexdigest();shutil.copy2(root/'.test_output/obj-enum-functional/test_eval_enum_ownership',out/'retained-enum-controls');(out/'retained-driver.json').write_text(json.dumps(record,indent=2)+'\n');print(record['sha256'])
