from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();out=root/'.test_output/enum-ownership-baseline';out.mkdir(exist_ok=False)
source=Path('/home/jkh/.worktrees/nanolang/effect-metadata-ownership/.test_output/effect-metadata-baseline/manifest.json');m=json.loads(source.read_text());args=m['argv'][:-1]+['OBJ_DIR=.test_output/obj-enum-baseline','test-eval-enum-ownership'];env=dict(os.environ,**m['environment']);t=time.monotonic()
with (out/'control.stdout').open('wb') as a,(out/'control.stderr').open('wb') as b:r=subprocess.run(args,env=env,stdout=a,stderr=b,timeout=600)
(out/'manifest.json').write_text(json.dumps(dict(argv=args,environment=m['environment'],returncode=r.returncode,elapsed_seconds=time.monotonic()-t),indent=2)+'\n');print(r.returncode)
