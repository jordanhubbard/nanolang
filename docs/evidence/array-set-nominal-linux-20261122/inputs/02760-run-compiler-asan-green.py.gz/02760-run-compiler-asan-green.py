from pathlib import Path
import os,sys,subprocess,shlex,json,time,hashlib
root=Path.cwd();w=root/'.test_output/array-set-nominal-20261122/preflight';out=w/'compiler-asan-green';out.mkdir(exist_ok=False)
plan=subprocess.check_output(['make','-n','-W','src/transpiler.c','-W','src/typechecker.c','CC=/usr/bin/cc','bin/nanoc_c'],text=True);(out/'build-plan').write_text(plan)
lines=[line.strip().removesuffix('\\').strip().removesuffix(';') for line in plan.splitlines() if line.strip().startswith('/usr/bin/cc ')]
commands=[];objects={};flags=['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
def run(name,args,env=None,timeout=180):
 t=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,env=env,timeout=timeout);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);commands.append(dict(name=name,argv=list(map(str,args)),returncode=r.returncode,seconds=time.monotonic()-t));(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0,r.stderr.decode(errors='replace')
for line in lines:
 args=shlex.split(line)
 if '-c' not in args:continue
 source=args[args.index('-c')+1]
 if source not in ['src/transpiler.c','src/typechecker.c']:continue
 object_name=args[args.index('-o')+1];new=out/Path(object_name).name;objects[object_name]=str(new);args[args.index('-o')+1]=str(new);run(Path(source).stem,args+flags)
assert len(objects)==2
binary=root/'bin/nanoc_c_nominal_asan';args=shlex.split(lines[-1]);args=[objects.get(a,a) for a in args];args[args.index('-o')+1]=str(binary);run('link',args+flags)
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),PYTHONPATH=str(root),ASAN_OPTIONS='detect_leaks=0',NANO_BUILD_CACHE=str(out/'module-cache'),TMPDIR=str(out/'tmp'));(out/'tmp').mkdir()
runner='''import pathlib,tempfile,unittest,json,time
from tests import test_nominal_record_array_mutation as tests
original=tempfile.TemporaryDirectory
def retained(*args,**kwargs):
 kwargs['delete']=False
 return original(*args,**kwargs)
tempfile.TemporaryDirectory=retained
tests.NominalRecordArrayMutation.routes=lambda self:[('c',pathlib.Path(BINARY),[])]
suite=unittest.defaultTestLoader.loadTestsFromModule(tests);assert suite.countTestCases()==4
started=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(suite)
pathlib.Path(RESULT).write_text(json.dumps(dict(discovered=4,ran=r.testsRun,failures=r.failures,errors=r.errors,skipped=r.skipped,successful=r.wasSuccessful(),seconds=time.monotonic()-started),indent=2)+'\\n')
raise SystemExit(0 if r.wasSuccessful() and r.testsRun==4 and not r.skipped else 1)
'''.replace('BINARY',repr(str(binary))).replace('RESULT',repr(str(out/'result.json')))
(out/'runner.py').write_text(runner);run('suite',[sys.executable,'-c',runner],env,1800)
(out/'manifest.json').write_text(json.dumps(dict(passed=True,compiler=str(binary),compiler_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_hashes={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['src/transpiler.c','src/transpiler_iterative_v3_twopass.c','src/typechecker.c','tests/test_nominal_record_array_mutation.py']},environment={k:env.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},scope='I add C-only compiler ASan/UBSan coverage of the complete four-method mutation corpus. Actual typechecker/transpiler TUs are instrumented; linked providers remain ordinary. The unchanged full three-producer acceptance suite is separate.'),indent=2)+'\n')
