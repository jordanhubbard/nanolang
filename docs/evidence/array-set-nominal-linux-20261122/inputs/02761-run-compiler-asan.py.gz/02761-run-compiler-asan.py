from pathlib import Path
import subprocess,shlex,os,time,json
root=Path.cwd();w=root/'.test_output/array-set-nominal-20261122/preflight';out=w/'compiler-asan-red';out.mkdir();commands=[]
lines=[line.strip().removesuffix('\\').strip().removesuffix(';') for line in (w/'asan-build-plan.txt').read_text().splitlines() if line.strip().startswith('/usr/bin/cc ')]
compile=shlex.split(lines[0]);compile[compile.index('obj/transpiler.o')]=str(out/'transpiler.o');compile+=['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
link=shlex.split(lines[-1]);link[link.index('obj/transpiler.o')]=str(out/'transpiler.o');link[link.index('bin/nanoc_c')]=str(out/'nanoc');link+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
(out/'left.nano').write_text('module Left\npub struct Item { a: int }\npub fn items() -> array<Item> { return [Item { a: 1 }] }\nshadow items { assert (== (array_length (items)) 1) }\n')
(out/'main.nano').write_text('module "left.nano" as left\nfn main()->int{(array_set (left.items) 0 left.Item {a:42}) return 0}\nshadow main {assert (== (main) 0)}\n')
for name,args in [('compile',compile),('link',link),('witness',[str(out/'nanoc'),str(out/'main.nano'),'--keep-c','-o',str(out/'native')])]:
 t=time.monotonic();r=subprocess.run(args,cwd=root,capture_output=True,env={**os.environ,'NANOLANG_ROOT':str(root),'CC':'/usr/bin/cc','PATH':'/usr/bin:/bin:/home/jkh/.cargo/bin','ASAN_OPTIONS':'detect_leaks=0'},timeout=180);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);commands.append(dict(name=name,argv=args,returncode=r.returncode,seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,r.returncode,flush=True)
 if name!='witness':assert r.returncode==0,r.stderr.decode(errors='replace')
assert commands[-1]['returncode']!=0
assert b'heap-use-after-free' in (out/'witness.stderr').read_bytes()
