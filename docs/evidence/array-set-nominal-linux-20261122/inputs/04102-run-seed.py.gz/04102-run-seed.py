from pathlib import Path
import os,sys,json,traceback
root=Path.cwd();out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap
class SeedComplete(Exception):pass
b=Bootstrap(root,1800,30);b.env.update(CC='/usr/bin/cc',PATH=os.environ['PATH'],NANO_BUILD_CACHE=str(out/'module-cache'))
record=dict(status='running',scope='I run the original guarded compiler seed generation, full compiler shadows at original30s, verification and host input retention, then stop before any raw Stage1 generation or receipt publication.')
def stop(label,producer):
 assert label=='stage1';b.check_inputs();b.check_artifacts(['nanoc_seed.nvm']);b.save();raise SeedComplete
b.generation=stop
try:
 b.stage1()
 raise RuntimeError('I require the seed-only stop before raw generation.')
except SeedComplete:record['status']='passed'
except BaseException as error:record.update(status='failed',error=repr(error));(out/'exception').write_text(traceback.format_exc())
finally:
 record['bootstrap_work']=str(getattr(b,'work',''));record['bootstrap_manifest']=b.manifest;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],work=record['bootstrap_work'])));sys.exit(0 if record['status']=='passed' else 1)
