/home/jkh/.worktrees/nanolang/service-module-integration/.test_output/array-set-nominal-20261122/preflight/compiler-asan-green/typechecker.o: \
 src/typechecker.c src/nanolang.h src/generated/compiler_schema.h \
 src/runtime/dyn_array.h src/runtime/gc.h src/runtime/dyn_array.h \
 src/runtime/gc_struct.h src/effects.h src/tracing.h \
 src/resource_tracking.h src/colors.h src/builtins_registry.h \
 src/generic_bindings.h src/native_type_key.h src/module_symbol.h \
 src/typechecker_purity.c src/generated/purity_intrinsics.h \
 src/typechecker_passive.c src/generated/reserved_builtin_names.h \
 src/layout_validation.h
src/nanolang.h:
src/generated/compiler_schema.h:
src/runtime/dyn_array.h:
src/runtime/gc.h:
src/runtime/dyn_array.h:
src/runtime/gc_struct.h:
src/effects.h:
src/tracing.h:
src/resource_tracking.h:
src/colors.h:
src/builtins_registry.h:
src/generic_bindings.h:
src/native_type_key.h:
src/module_symbol.h:
src/typechecker_purity.c:
src/generated/purity_intrinsics.h:
src/typechecker_passive.c:
src/generated/reserved_builtin_names.h:
src/layout_validation.h:
