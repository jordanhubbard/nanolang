from pathlib import Path
import sys,json,gzip,hashlib,stat,subprocess,os
host=sys.argv[1];sha=lambda raw:hashlib.sha256(raw).hexdigest()
if host=='linux':
 root=Path.cwd();work=root/'.test_output/array-set-nominal-20261122';control=work/'linux-final';out=root/'docs/evidence/array-set-nominal-linux-20261122';frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sanpath=work/'preflight/compiler-asan-green/manifest.json'
else:
 root=Path('/Users/jkh/.worktrees/nanolang/array-set-nominal-20261122');control=root.with_name(root.name+'-control');work=control;out=root.with_name(root.name+'-archive');frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sanpath=control/'compiler-sanitizers/manifest.json'
state=json.loads((control/'manifest.json').read_text());assert state['status']=='passed';pin=state['pin'];expected=state['source_hashes']
assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items())
san=json.loads(sanpath.read_text());assert san['passed'];assert all(expected[n]==v for n,v in san['source_hashes'].items());assert sha(Path(san['compiler']).read_bytes())==san['compiler_sha256']
verification={}
for label,count in [('mutation',4),('neighbors',25)]:
 r=json.loads((control/label/'result.json').read_text());assert r['successful'] and r['ran']==r['discovered']==count and not(r['failures'] or r['errors'] or r['skipped']);verification[label]=r
paths={p for p in work.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(work).parts and not p.is_symlink()};paths.update(root/n for n in expected);paths.update(root/n for n in state['tools']);paths.add(Path(san['compiler']))
if host=='linux':paths.add(root/'bin/nanoc_c_record_set_asan_red')
seed_controls=[]
for p in work.rglob('manifest.json'):
 if 'module-cache' in p.relative_to(work).parts:continue
 try:d=json.loads(p.read_text())
 except Exception:continue
 if not isinstance(d,dict) or not d.get('bootstrap_work'):continue
 bw=Path(d['bootstrap_work']);bm=d['bootstrap_manifest'];seed_controls.append(dict(control=str(p),status=d['status'],work=str(bw),sources=bm['sources'],artifacts=bm['artifacts'],hosts=bm.get('hosts',{}),steps=bm['steps']))
 paths.update(q for q in bw.rglob('*') if q.is_file() and not q.is_symlink())
 if d['status']!='passed':continue
 assert bm['artifacts'].keys()=={'nanoc_seed.nvm'};assert sha((bw/'seed.nvm').read_bytes())==bm['artifacts']['nanoc_seed.nvm'];assert not (bw/'stage1.nvm').exists()
 for name,value in bm['hosts'].items():assert sha(Path(name).read_bytes())==value;paths.add(Path(name))
 retained=json.loads((bw/'retained-host-inputs.json').read_text())
 for base,names in retained.items():
  base=Path(base)
  for name in names:
   q=base/name;assert q.is_file(),str(q);paths.add(q)
  paths.update(q for q in base.iterdir() if q.is_file() and not q.is_symlink())
assert seed_controls and all(d['status']=='passed' for d in seed_controls)
sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
paths.update(frozen/'bin'/n for n in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']);paths.update(Path(n) for n in b.manifest['hosts'])
for name in ['src_nano/typecheck.nano','src_nano/parser.nano','src_nano/compiler.nano']:
 assert sha((root/name).read_bytes())==sha((frozen/name).read_bytes());paths.add(frozen/name)
if host=='darwin':
 for name in ['/tmp/nanolang-array-set-nominal-20261122.log','/tmp/nanolang-record-set-darwin-health.json','/tmp/nanolang-record-set-darwin-health.py']:
  paths.add(Path(name))
(out/'inputs').mkdir(parents=True,exist_ok=False);files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(implementation=pin,source_hashes=expected,qualification=state,verification=verification,compiler_sanitizers=san,seed_controls=seed_controls,files=files,issues=[1177,1179,1180],limits=['I qualify a finite nominal mutation checkpoint and the copied type-name/lexical callback repairs. The actual new Make4 and all25 original neighbors pass with original deadlines, plus extra four-method C-only typechecker/transpiler ASan/UBSan diagnostics. Other linked providers are ordinary; Darwin LeakSanitizer is not established. Original guarded full compiler seed/shadows30/verify and retained native source/preprocessor/assembler/object inputs pass, then stop before raw Stage1 generation or receipt publication. The frozen bdffa4ccc native source producer and same-byte parser/typechecker/compiler sources are retained. Conditional receiver source admission remains open under1179; this is not full source conformance or full5.1 release acceptance. Original failure/setup/expectation corrections are retained on Linux; all old roots and primary Darwin audit/stashes remain preserved. Caches are omitted except seed host images and every predeclared retained host input.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_files=len(expected))))
