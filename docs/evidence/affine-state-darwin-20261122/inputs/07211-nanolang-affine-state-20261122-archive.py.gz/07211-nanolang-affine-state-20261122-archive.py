from pathlib import Path
import sys,os,json,gzip,hashlib,stat,subprocess
root=Path('/Users/jkh/.worktrees/nanolang/affine-state-20261122');active=root.with_name(root.name+'-control');out=root.with_name(root.name+'-archive');state=json.loads((active/'manifest.json').read_text());assert state['status']=='passed' and state['primary_preserved'] and state['provider_guards_unchanged'] and state['source_and_tool_guards_unchanged'] and state['final_status']==''
sha=lambda raw:hashlib.sha256(raw).hexdigest()
primary=Path('/Users/jkh/Src/nanolang')
def primary_guard():
 def git(*args):return subprocess.check_output(['git',*args],cwd=primary)
 files={}
 for raw in git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0'):
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','--full-index','HEAD')),cached=sha(git('diff','--cached','--binary','--full-index','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)
assert primary_guard()==state['primary_before']==state['primary_after']

expected=state['source_hashes'];assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==state['pin']
products=json.loads((active/'products/manifest.json').read_text());san=json.loads((active/'reference-sanitizers/manifest.json').read_text());assert san['status']=='passed'
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
paths={p for p in active.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(active).parts};symlinks={str(p):os.readlink(p) for p in active.rglob('*') if p.is_symlink()}
paths.update(root/n for n in expected)
for n in [*state['tools'],'obj/fixture_identifier_lexer','obj/test_affine_state','obj/test_affine_state_alloc']:
 p=root/n
 if p.is_file():paths.add(p)
for n in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/n)
paths.update(Path(n) for n in b.manifest['hosts']);paths.update([Path(__file__),Path('/tmp/nanolang-affine-state-20261122.log')])
(out/'inputs').mkdir(parents=True,exist_ok=False);files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(implementation=state['pin'],source_hashes=expected,verification=products,sanitizers=san,provider=state['provider'],files=files,symlinks=symlinks,primary_before=state['primary_before'],primary_after=state['primary_after'],issue=1142,limits=['I qualify only the shared pure affine facts/local transitions and queries through five Darwin routes, all563 ordinary/634 allocation-failure original C controls and targeted actual C sanitizers. The3141-case corpus retains383 independent expectations, full state snapshots, failed-transition/query-output guards and explicit mutable-path isolation checks for installation/cloning/caller binding. I retain native-width/harness D separately from logical transitions. All3577 source/test/spec/Make inputs, tools, primary dirty audit/stashes and the frozen raw-equal bdffa4ccc development producer remain unchanged. Ordinary shadows10s and native/guest600s remain unchanged; no raw bootstrap executes. Instrumented actual state/declaration/retained-layout/reference/layout/cursor/ISA/oracle/unit checks do not instrument every provider or establish Darwin LeakSanitizer support. Language allocation failures are not a C malloc/null equivalence claim; original C allocator-failure assertions remain intact. Private checked-state constructors, affine bytecode/CFG, runtime admission, pure C emission and full5.1 release remain open. Build caches are omitted.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and sha(raw)==e['sha256'] and len(raw)==e['bytes']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert primary_guard()==state['primary_before'];assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_files=len(expected))))
