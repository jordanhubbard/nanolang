/**
 * ffi_loader.h - Unified FFI Module Loading
 *
 * Shared dlopen/dlsym logic used by both the interpreter (interpreter_ffi.c)
 * and the VM (vm_ffi.c). Each caller handles its own marshaling; this layer
 * manages module tracking, library search, and symbol resolution.
 */

#ifndef FFI_LOADER_H
#define FFI_LOADER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/**
 * Loaded module handle (opaque to callers that just need symbol resolution).
 * Callers that need extra per-module data (e.g., interpreter's ModuleBuildMetadata)
 * can store it in user_data.
 */
typedef struct {
    char *name;
    char *path;       /* filesystem path of loaded .so/.dylib */
    void *handle;     /* dlopen handle */
    void *user_data;  /* caller-owned extra data (e.g., metadata) */
} FfiModule;

/**
 * Initialize the FFI loader.
 * Safe to call multiple times; subsequent calls are no-ops.
 * @param verbose  Enable diagnostic messages to stderr.
 * @return true on success.
 */
bool ffi_loader_init(bool verbose);

/**
 * Shut down the registry and release its dlopen references. Images used by
 * retained adapters keep a separate process-lifetime reference.
 * Does NOT free user_data — callers must clean up their own data first
 * via ffi_loader_get_modules().
 */
void ffi_loader_shutdown(void);

/** @return true if the loader has been initialized. */
bool ffi_loader_is_initialized(void);

/**
 * Open a shared library at an explicit filesystem path and register it
 * under @p module_name. If a module with this name is already loaded,
 * returns true immediately (idempotent).
 *
 * @return true if the module is now loaded (either freshly or already).
 */
bool ffi_loader_open(const char *module_name, const char *lib_path);

/**
 * Look up a module by name.
 * @return pointer to the FfiModule entry, or NULL.
 */
FfiModule *ffi_loader_find(const char *module_name);

/**
 * Resolve a symbol by searching (in order):
 *   1. All loaded modules (most-recently-loaded first)
 *   2. The main executable + already-loaded libraries (RTLD_DEFAULT)
 *
 * @return function pointer, or NULL if not found.
 */
void *ffi_loader_resolve(const char *symbol_name);

/**
 * Resolve a symbol, returning which module it was found in (or NULL
 * if found via RTLD_DEFAULT / main executable).
 */
void *ffi_loader_resolve_in(const char *symbol_name, FfiModule **out_module);

/* I resolve only through the named library handle, without global fallback. */
void *ffi_loader_resolve_module(const char *symbol_name, const char *module_name);

/* I accept an optional versioned cleanup companion only from the called
 * function's own image. A missing companion preserves borrowed results. */
bool ffi_loader_string_release(const char *module_name, const char *symbol_name,
                               void *function, void (**release)(const char *),
                               char *error, size_t error_size);
/* I resolve optional provider-owned array cleanup from the function's image.
 * Missing companions preserve existing borrowed-result behavior. */
bool ffi_loader_array_release(const char *module_name, const char *symbol_name,
                              void *function, bool (**release)(void *),
                              char *error, size_t error_size);


/* I check a per-function native array ABI declaration in the function's own
 * loaded image. Missing declarations mean legacy version 1. This checks a
 * trusted native declaration, not the memory safety of arbitrary C code.
 * A NULL module selects the process namespace for legacy logical imports;
 * the declaration must still belong to the supplied function address. */
bool ffi_loader_check_array_abi(const char *module_name, const char *symbol_name,
                                void *function, uint32_t expected,
                                char *error, size_t error_size);

/* I resolve without fallback and retain the selected image until process exit.
 * Native asynchronous code can outlive both the VM and its callback handles. */
void *ffi_loader_resolve_retained(const char *symbol_name, const char *module_name);

/**
 * Access the loaded module array (for callers that need to iterate,
 * e.g., to free user_data before shutdown).
 * @param out_count  receives the number of loaded modules.
 * @return pointer to internal array (valid until next open/shutdown call).
 */
FfiModule *ffi_loader_get_modules(int *out_count);

/**
 * Utility: try to find a shared library for a module using the standard
 * nanolang search paths.  Writes the found path into @p out_path.
 *
 * Search order (for each extension .dylib then .so):
 *   1. nano_module_build_dir(module_dir)/lib<leaf>.<ext>
 *   2. nano_module_build_dir(modules/<normalized>)/lib<leaf>.<ext>
 *   3. nano_module_build_dir(modules/<parent_dir>)/lib<joined>.<ext>
 *   4. nano_module_build_dir(modules/<top_dir>)/lib<top_dir>.<ext>
 *
 * nano_module_build_dir honors NANO_BUILD_CACHE, else <dir>/.build.
 *
 * @param module_name   Raw module name (may include "modules/" prefix, ".nano" suffix)
 * @param module_dir    Optional explicit directory (from interpreter's module path).
 *                      Pass NULL to skip pattern 1.
 * @param out_path      Buffer to receive the found path.
 * @param path_size     Size of out_path buffer.
 * @return true if a library file was found on disk.
 */
bool ffi_loader_find_library(const char *module_name, const char *module_dir,
                             char *out_path, size_t path_size);

#endif /* FFI_LOADER_H */
