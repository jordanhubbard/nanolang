/* I test ownership storage growth and fail-closed allocation boundaries. */
#include "resource_tracking.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static size_t allocations, attempts, fail_at;
static void *checked_malloc(size_t size) {
    if (++attempts == fail_at) return NULL;
    void *result = malloc(size);
    if (result) allocations++;
    return result;
}
static void *checked_calloc(size_t count, size_t size) {
    if (++attempts == fail_at) return NULL;
    void *result = calloc(count, size);
    if (result) allocations++;
    return result;
}
static char *checked_strdup(const char *value) {
    size_t size = strlen(value) + 1;
    char *result = checked_malloc(size);
    if (result) memcpy(result, value, size);
    return result;
}
static void *checked_realloc(void *old, size_t size) {
    if (++attempts == fail_at) return NULL;
    bool fresh = old == NULL;
    void *result = realloc(old, size);
    if (result && fresh) allocations++;
    return result;
}
static void checked_free(void *value) {
    if (value) { assert(allocations > 0); allocations--; }
    free(value);
}

bool is_resource_type(Environment *env, const char *name) {
    (void)env;
    return name && !strcmp(name, "Handle");
}
/* I isolate allocation behavior; classification has its own real-environment gate. */
bool is_resource_type_info(Environment *env, const TypeInfo *info) {
    return info && info->base_type == TYPE_STRUCT && is_resource_type(env, info->generic_name);
}
bool has_resource_collection_type_info(Environment *env, const TypeInfo *info) {
    (void)env; (void)info; return false;
}
bool env_effect_visible(Environment *env, const EffectDef *effect) { (void)env; (void)effect; return true; }
EffectDef *env_get_effect(Environment *env, const char *name) {
    for (int i = 0; name && i < env->effect_count; ++i)
        if (!strcmp(env->effects[i].name, name)) return &env->effects[i];
    return NULL;
}
EffectOp *effect_get_op(EffectDef *effect, const char *name) {
    for (int i = 0; effect && name && i < effect->op_count; ++i)
        if (!strcmp(effect->ops[i].name, name)) return &effect->ops[i];
    return NULL;
}
bool is_builtin_function(const char *name) { (void)name; return false; }
Function *env_get_function(Environment *env, const char *name) {
    for (int i = 0; name && i < env->function_count; ++i)
        if (!strcmp(env->functions[i].name, name)) return &env->functions[i];
    return NULL;
}
StructDef *env_get_struct(Environment *env, const char *name) {
    (void)env; (void)name; return NULL;
}
UnionDef *env_get_union(Environment *env, const char *name) {
    (void)env; (void)name; return NULL;
}
bool has_resource_collection_payload(Environment *env, const char *name) {
    (void)env; (void)name; return false;
}
TypeInfo *resolve_union_payload_type_info(const UnionDef *def, int arm, int field,
                                          const TypeInfo *arguments) {
    (void)def; (void)arm; (void)field; (void)arguments; return NULL;
}
void free_payload_type_info(TypeInfo *info) {
    assert(info == NULL);
}

#define malloc checked_malloc
#define calloc checked_calloc
#define strdup checked_strdup
#define realloc checked_realloc
#define free checked_free
#include "../src/resource_flow.c"
#undef malloc
#undef calloc
#undef strdup
#undef realloc
#undef free

static void test_effect_summary_allocations(void) {
    ASTNode perform = {.type = AST_EFFECT_OP}, handler = {.type = AST_HANDLE_EXPR};
    ASTNode call = {.type = AST_CALL}, result = {.type = AST_NUMBER};
    perform.as.effect_op.effect_name = "E";
    perform.as.effect_op.op_name = "tick";
    call.as.call.name = "f";
    char *names[] = {"tick"};
    int counts[] = {0};
    ASTNode *bodies[] = {&result};
    handler.as.handle_expr.body = &perform;
    handler.as.handle_expr.effect_name = "E";
    handler.as.handle_expr.handler_op_names = names;
    handler.as.handle_expr.handler_param_counts = counts;
    handler.as.handle_expr.handler_bodies = bodies;
    handler.as.handle_expr.handler_count = 1;
    EffectOp op = {.name = "tick", .return_type = TYPE_INT};
    EffectDef effect = {.name = "E", .ops = &op, .op_count = 1};
    Function function = {.name = "f", .body = &perform};
    Environment env = {.functions = &function, .function_count = 1, .effects = &effect, .effect_count = 1};
    bool error = false;
    OwnFlow flow = {.env = &env, .error = &error};
    attempts = 0; fail_at = 0;
    assert(own_call_effect_escape(&flow, &call));
    assert(!error && allocations == 0);
    function.body = &handler;
    assert(!own_call_effect_escape(&flow, &call));
    assert(!error && allocations == 0);
    attempts = 0; fail_at = 1;
    assert(own_call_effect_escape(&flow, &call));
    assert(error && allocations == 0);
    fail_at = 0;
}

int main(void) {
    enum { COUNT = 300 };
    char names[COUNT][24];
    ASTNode values[COUNT] = {0}, bindings[COUNT] = {0};
    ASTNode identifiers[COUNT] = {0}, calls[COUNT] = {0};
    ASTNode addresses[COUNT] = {0}, borrow_calls[COUNT] = {0};
    ASTNode *arguments[COUNT], *borrow_arguments[COUNT][2], *statements[COUNT * 3 + 1];
    for (int i = 0; i < COUNT; ++i) {
        snprintf(names[i], sizeof(names[i]), "owner_%d", i);
        values[i].type = AST_STRUCT_LITERAL;
        values[i].as.struct_literal.struct_name = "Handle";
        bindings[i].type = AST_LET;
        bindings[i].as.let.name = names[i];
        bindings[i].as.let.type_name = "Handle";
        bindings[i].as.let.value = &values[i];
        identifiers[i].type = AST_IDENTIFIER;
        identifiers[i].as.identifier = names[i];
        arguments[i] = &identifiers[i];
        calls[i].type = AST_CALL;
        calls[i].as.call.name = "consume";
        calls[i].as.call.args = &arguments[i];
        calls[i].as.call.arg_count = 1;
        addresses[i].type = AST_CALL;
        addresses[i].as.call.borrow_mode = 1;
        addresses[i].as.call.args = &arguments[i];
        addresses[i].as.call.arg_count = 1;
        borrow_arguments[i][0] = borrow_arguments[i][1] = &addresses[i];
        borrow_calls[i].type = AST_CALL;
        borrow_calls[i].as.call.name = "observe";
        borrow_calls[i].as.call.args = borrow_arguments[i];
        borrow_calls[i].as.call.arg_count = 2;
        statements[i * 3] = &bindings[i];
        statements[i * 3 + 1] = &borrow_calls[i];
        statements[i * 3 + 2] = &calls[i];
    }
    ASTNode condition = {.type = AST_BOOL}, empty = {.type = AST_BLOCK};
    ASTNode branch = {.type = AST_IF};
    condition.as.bool_val = true;
    branch.as.if_stmt.condition = &condition;
    branch.as.if_stmt.then_branch = &empty;
    branch.as.if_stmt.else_branch = &empty;
    statements[COUNT * 3] = &branch;
    ASTNode body = {.type = AST_BLOCK};
    body.as.block.statements = statements;
    body.as.block.count = COUNT * 3 + 1;
    ASTNode function = {.type = AST_FUNCTION};
    function.as.function.body = &body;
    StructDef record = {.name = "Handle", .is_resource = true};
    Environment env = {.structs = &record, .struct_count = 1};
    bool error = false;
    check_function_ownership(&env, &function, &error);
    assert(!error);
    assert(allocations == 0);
    size_t sites = attempts;
    assert(sites > 1);
    for (size_t failure = 1; failure <= sites; ++failure) {
        attempts = 0;
        fail_at = failure;
        error = false;
        check_function_ownership(&env, &function, &error);
        assert(error);
        assert(allocations == 0);
    }
    fail_at = 0;
    body.as.block.count = COUNT * 3 - 1;
    error = false;
    check_function_ownership(&env, &function, &error);
    assert(error);
    assert(allocations == 0);
    OwnFlow overflow = {.env = &env, .count = SIZE_MAX, .capacity = SIZE_MAX, .error = &error};
    error = false;
    assert(!own_add(&overflow, &function, "overflow", "Handle", NULL));
    assert(error);
    assert(allocations == 0);
    test_effect_summary_allocations();
    printf("I checked 300 owners and %zu allocation-failure positions.\n", sites);
    return 0;
}
