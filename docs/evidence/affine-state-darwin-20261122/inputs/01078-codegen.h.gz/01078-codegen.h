/*
 * codegen.h - NanoISA bytecode generation from nanolang AST
 *
 * Compiles a typechecked AST into an NvmModule containing bytecode.
 * Reuses the existing frontend (lexer/parser/typechecker) and targets
 * the NanoISA instruction set defined in nanoisa/isa.h.
 */
#ifndef NANOVIRT_CODEGEN_H
#define NANOVIRT_CODEGEN_H

#include "nanolang.h"
#include "nanoisa/isa.h"
#include "nanoisa/nvm_format.h"

#include <stdbool.h>
#include <stdint.h>

/* Result of compilation */
typedef struct {
    NvmModule *module;      /* NULL on error */
    bool ok;
    int error_line;
    char error_msg[256];
} CodegenResult;

/*
 * Compile a typechecked AST program into an NvmModule.
 *
 * @param program  AST root (must be AST_PROGRAM)
 * @param env      Post-typechecked environment
 * @param modules  Module list from process_imports (NULL = no modules)
 * @return         CodegenResult with module or error info
 */
CodegenResult codegen_compile(ASTNode *program, Environment *env,
                              ModuleList *modules, const char *input_file);

/* I compile root-file shadows into a separate module whose entry runs them.
 * I do not change the normal program entry or insert tests into production. */
CodegenResult codegen_compile_shadows(ASTNode *program, Environment *env,
                                      ModuleList *modules, const char *input_file);
/* I include dependency shadows when requested, before the root's shadows. */
CodegenResult codegen_compile_shadow_scope(ASTNode *program, Environment *env,
                                          ModuleList *modules, const char *input_file,
                                          bool include_imports);

/* I bind only a loaded extern declaration and an explicitly selected adapter.
 * On failure the caller discards the unpublished module. */
bool codegen_bind_callback_contract(NvmModule *module, uint32_t import_index,
                                   const ASTNode *declaration, Environment *env,
                                   const char *adapter_symbol, bool worker_thread);

#endif /* NANOVIRT_CODEGEN_H */
