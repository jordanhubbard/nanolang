/*
 * NanoISA Test Suite
 *
 * Tests: ISA encode/decode, NVM format serialize/deserialize,
 *        assembler, disassembler, and round-trip.
 */

#include "isa.h"
#include "nvm_format.h"
#include "assembler.h"
#include "disassembler.h"
#include "nanoisa.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

/* ========================================================================
 * Test Framework (minimal)
 * ======================================================================== */

static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

#define ASSERT(cond, msg) do { \
    tests_run++; \
    if (!(cond)) { \
        printf("  FAIL [%s:%d]: %s\n", __FILE__, __LINE__, msg); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define ASSERT_EQ_INT(a, b, msg) do { \
    tests_run++; \
    long long _a = (long long)(a), _b = (long long)(b); \
    if (_a != _b) { \
        printf("  FAIL [%s:%d]: %s (expected %lld, got %lld)\n", \
               __FILE__, __LINE__, msg, _b, _a); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define ASSERT_EQ_STR(a, b, msg) do { \
    tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        printf("  FAIL [%s:%d]: %s (expected \"%s\", got \"%s\")\n", \
               __FILE__, __LINE__, msg, (b), (a)); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define RUN_TEST(fn) do { \
    printf("  %s...\n", #fn); \
    fn(); \
} while(0)

/* ========================================================================
 * ISA Tests
 * ======================================================================== */

static void test_tag_names(void) {
    ASSERT_EQ_STR(isa_tag_name(TAG_VOID), "void", "TAG_VOID name");
    ASSERT_EQ_STR(isa_tag_name(TAG_INT), "int", "TAG_INT name");
    ASSERT_EQ_STR(isa_tag_name(TAG_FLOAT), "float", "TAG_FLOAT name");
    ASSERT_EQ_STR(isa_tag_name(TAG_BOOL), "bool", "TAG_BOOL name");
    ASSERT_EQ_STR(isa_tag_name(TAG_STRING), "string", "TAG_STRING name");
    ASSERT_EQ_STR(isa_tag_name(TAG_ARRAY), "array", "TAG_ARRAY name");
    ASSERT_EQ_STR(isa_tag_name(TAG_STRUCT), "struct", "TAG_STRUCT name");
    ASSERT_EQ_STR(isa_tag_name(TAG_ENUM), "enum", "TAG_ENUM name");
    ASSERT_EQ_STR(isa_tag_name(TAG_UNION), "union", "TAG_UNION name");
    ASSERT_EQ_STR(isa_tag_name(TAG_FUNCTION), "function", "TAG_FUNCTION name");
    ASSERT_EQ_STR(isa_tag_name(TAG_CLOSURE), "closure", "TAG_CLOSURE name");
    ASSERT_EQ_STR(isa_tag_name(TAG_TUPLE), "tuple", "TAG_TUPLE name");
    ASSERT_EQ_STR(isa_tag_name(TAG_HASHMAP), "hashmap", "TAG_HASHMAP name");
    ASSERT_EQ_STR(isa_tag_name(TAG_OPAQUE), "opaque", "TAG_OPAQUE name");
    ASSERT_EQ_STR(isa_tag_name(0xFF), "UNKNOWN", "Invalid tag name");
}

static void test_instruction_info(void) {
    const InstructionInfo *info;

    /* NOP - no operands */
    info = isa_get_info(OP_NOP);
    ASSERT(info != NULL, "NOP info exists");
    ASSERT_EQ_STR(info->name, "NOP", "NOP name");
    ASSERT_EQ_INT(info->operand_count, 0, "NOP operand count");

    /* PUSH_I64 - one i64 operand */
    info = isa_get_info(OP_PUSH_I64);
    ASSERT(info != NULL, "PUSH_I64 info exists");
    ASSERT_EQ_INT(info->operand_count, 1, "PUSH_I64 operand count");
    ASSERT_EQ_INT(info->operands[0], OPERAND_I64, "PUSH_I64 operand type");

    /* PUSH_F64 - one f64 operand */
    info = isa_get_info(OP_PUSH_F64);
    ASSERT(info != NULL, "PUSH_F64 info exists");
    ASSERT_EQ_INT(info->operands[0], OPERAND_F64, "PUSH_F64 operand type");

    /* LOAD_LOCAL - one u16 operand */
    info = isa_get_info(OP_LOAD_LOCAL);
    ASSERT(info != NULL, "LOAD_LOCAL info exists");
    ASSERT_EQ_INT(info->operand_count, 1, "LOAD_LOCAL operand count");
    ASSERT_EQ_INT(info->operands[0], OPERAND_U16, "LOAD_LOCAL operand type");

    /* LOAD_UPVALUE - two u16 operands */
    info = isa_get_info(OP_LOAD_UPVALUE);
    ASSERT(info != NULL, "LOAD_UPVALUE info exists");
    ASSERT_EQ_INT(info->operand_count, 2, "LOAD_UPVALUE operand count");
    ASSERT_EQ_INT(info->operands[0], OPERAND_U16, "LOAD_UPVALUE op0 type");
    ASSERT_EQ_INT(info->operands[1], OPERAND_U16, "LOAD_UPVALUE op1 type");

    /* CALL_MODULE - module index, function index, then the declared call
     * shape. The shape is encoded so a module's stack discipline is provable
     * before linking and so linking can confirm the real callee matches. */
    info = isa_get_info(OP_CALL_MODULE);
    ASSERT(info != NULL, "CALL_MODULE info exists");
    ASSERT_EQ_INT(info->operand_count, 4, "CALL_MODULE operand count");

    /* UNION_CONSTRUCT - three operands */
    info = isa_get_info(OP_UNION_CONSTRUCT);
    ASSERT(info != NULL, "UNION_CONSTRUCT info exists");
    ASSERT_EQ_INT(info->operand_count, 3, "UNION_CONSTRUCT operand count");

    /* Invalid opcode */
    info = isa_get_info(0xFF);
    ASSERT(info == NULL, "Invalid opcode returns NULL");
}

static void test_opcode_by_name(void) {
    ASSERT_EQ_INT(isa_opcode_by_name("NOP"), OP_NOP, "NOP by name");
    ASSERT_EQ_INT(isa_opcode_by_name("PUSH_I64"), OP_PUSH_I64, "PUSH_I64 by name");
    ASSERT_EQ_INT(isa_opcode_by_name("ADD"), OP_ADD, "ADD by name");
    ASSERT_EQ_INT(isa_opcode_by_name("JMP_FALSE"), OP_JMP_FALSE, "JMP_FALSE by name");
    ASSERT_EQ_INT(isa_opcode_by_name("HALT"), OP_HALT, "HALT by name");
    ASSERT_EQ_INT(isa_opcode_by_name("NONEXISTENT"), -1, "Unknown opcode");
}

static void test_extended_opcode_space(void) {
    /* 0xFF is the extension prefix: it is never a primary opcode, so
     * isa_get_info() must reject it and isa_is_extension_prefix() accept it. */
    ASSERT(isa_get_info(OP_EXTENSION_PREFIX) == NULL,
           "Extension prefix is not a primary opcode");
    ASSERT(isa_is_extension_prefix(OP_EXTENSION_PREFIX),
           "0xFF recognized as extension prefix");
    ASSERT(!isa_is_extension_prefix(OP_NOP),
           "0x00 is not the extension prefix");
    ASSERT(!isa_is_extension_prefix(OP_AGG_TAG),
           "Last primary opcode is not the extension prefix");

    /* The prefix must sit exactly at the exclusive plane bound, and that bound
     * is a range, not an opcode count. */
    ASSERT_EQ_INT(NANOISA_EXTENSION_PREFIX, NANOISA_PRIMARY_OPCODE_LIMIT,
                  "Prefix equals the primary plane limit");
    ASSERT(NANOISA_LEGACY_OPCODE_COUNT < NANOISA_PRIMARY_OPCODE_LIMIT,
           "Opcode count is distinct from the plane limit");

    /* No primary opcode may occupy the prefix byte. */
    ASSERT(isa_opcode_by_name("__none__") == -1, "Guard name is unmapped");
    for (int code = 0; code < 256; code++) {
        const InstructionInfo *info = isa_get_info((uint8_t)code);
        if (info != NULL) {
            ASSERT(code != NANOISA_EXTENSION_PREFIX,
                   "No primary opcode uses the extension prefix byte");
        }
    }

    /* The extended plane exists and is queryable; undefined extended opcodes
     * return NULL rather than aliasing a primary opcode. */
    ASSERT(isa_get_extended_info(0x00) == NULL,
           "Undefined extended opcode returns NULL");
    ASSERT_EQ_INT(NANOISA_EXTENDED_OPCODE_COUNT, 0,
                  "Extended plane starts empty");
}

static void test_encode_decode_no_operands(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_ADD;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 1, "ADD encodes to 1 byte");
    ASSERT_EQ_INT(buf[0], OP_ADD, "ADD opcode byte");

    DecodedInstruction decoded;
    uint32_t consumed = isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(consumed, 1, "ADD decodes from 1 byte");
    ASSERT_EQ_INT(decoded.opcode, OP_ADD, "ADD decoded opcode");
    ASSERT_EQ_INT(decoded.operand_count, 0, "ADD decoded operand count");
}

static void test_encode_decode_i64(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_PUSH_I64;
    instr.operands[0].i64 = -42;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 9, "PUSH_I64 encodes to 9 bytes");

    DecodedInstruction decoded;
    uint32_t consumed = isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(consumed, 9, "PUSH_I64 decodes from 9 bytes");
    ASSERT_EQ_INT(decoded.operands[0].i64, -42, "PUSH_I64 value preserved");
}

static void test_encode_decode_i64_large(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_PUSH_I64;
    instr.operands[0].i64 = 0x7FFFFFFFFFFFFFFFLL;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].i64, 0x7FFFFFFFFFFFFFFFLL, "PUSH_I64 max i64");

    instr.operands[0].i64 = (int64_t)0x8000000000000000LL; /* INT64_MIN */
    encoded = isa_encode(&instr, buf, sizeof(buf));
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].i64, (int64_t)0x8000000000000000LL, "PUSH_I64 min i64");
}

static void test_encode_decode_f64(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_PUSH_F64;
    instr.operands[0].f64 = 3.14159265358979;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 9, "PUSH_F64 encodes to 9 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT(fabs(decoded.operands[0].f64 - 3.14159265358979) < 1e-15,
           "PUSH_F64 value preserved");
}

static void test_encode_decode_u8(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_PUSH_BOOL;
    instr.operands[0].u8 = 1;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 2, "PUSH_BOOL encodes to 2 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].u8, 1, "PUSH_BOOL value preserved");
}

static void test_encode_decode_u16(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_LOAD_LOCAL;
    instr.operands[0].u16 = 0x1234;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 3, "LOAD_LOCAL encodes to 3 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].u16, 0x1234, "LOAD_LOCAL value preserved");
}

static void test_encode_decode_u32(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_PUSH_STR;
    instr.operands[0].u32 = 0xDEADBEEF;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 5, "PUSH_STR encodes to 5 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].u32, 0xDEADBEEF, "PUSH_STR value preserved");
}

static void test_encode_decode_i32(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};
    instr.opcode = OP_JMP;
    instr.operands[0].i32 = -100;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 5, "JMP encodes to 5 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].i32, -100, "JMP negative offset preserved");
}

static void test_encode_decode_multi_operand(void) {
    uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
    DecodedInstruction instr = {0};

    /* LOAD_UPVALUE: u16, u16 */
    instr.opcode = OP_LOAD_UPVALUE;
    instr.operands[0].u16 = 2;
    instr.operands[1].u16 = 5;

    uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 5, "LOAD_UPVALUE encodes to 5 bytes");

    DecodedInstruction decoded;
    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].u16, 2, "LOAD_UPVALUE depth");
    ASSERT_EQ_INT(decoded.operands[1].u16, 5, "LOAD_UPVALUE index");

    /* UNION_CONSTRUCT: u32, u16, u16 */
    memset(&instr, 0, sizeof(instr));
    instr.opcode = OP_UNION_CONSTRUCT;
    instr.operands[0].u32 = 10;
    instr.operands[1].u16 = 3;
    instr.operands[2].u16 = 2;

    encoded = isa_encode(&instr, buf, sizeof(buf));
    ASSERT_EQ_INT(encoded, 9, "UNION_CONSTRUCT encodes to 9 bytes");

    isa_decode(buf, encoded, &decoded);
    ASSERT_EQ_INT(decoded.operands[0].u32, 10, "UNION_CONSTRUCT def_idx");
    ASSERT_EQ_INT(decoded.operands[1].u16, 3, "UNION_CONSTRUCT variant");
    ASSERT_EQ_INT(decoded.operands[2].u16, 2, "UNION_CONSTRUCT fields");
}

static void test_decode_truncated(void) {
    uint8_t buf[1] = { OP_PUSH_I64 };
    DecodedInstruction decoded;
    uint32_t consumed = isa_decode(buf, 1, &decoded);
    ASSERT_EQ_INT(consumed, 0, "Truncated PUSH_I64 returns 0");
}

static void test_decode_invalid_opcode(void) {
    uint8_t buf[1] = { 0xFF };
    DecodedInstruction decoded;
    uint32_t consumed = isa_decode(buf, 1, &decoded);
    ASSERT_EQ_INT(consumed, 0, "Invalid opcode returns 0");
}

static void test_every_opcode_tooling_roundtrip(void) {
    ASSERT_EQ_INT(sizeof(nanoisa_schema_opcodes) / sizeof(nanoisa_schema_opcodes[0]),
                  NANOISA_LEGACY_OPCODE_COUNT, "Schema opcode count matches table");

    for (size_t i = 0; i < NANOISA_LEGACY_OPCODE_COUNT; i++) {
        const NanoisaSchemaOpcode *schema = &nanoisa_schema_opcodes[i];
        const InstructionInfo *info = isa_get_info(schema->opcode);
        ASSERT(info != NULL, "Schema opcode has active metadata");
        ASSERT_EQ_STR(info->name, schema->name, "Schema mnemonic matches metadata");
        ASSERT_EQ_INT(isa_opcode_by_name(schema->name), schema->opcode,
                      "Assembler lookup covers schema opcode");
        uint8_t buf[ISA_MAX_INSTRUCTION_SIZE];
        DecodedInstruction instr = {0};
        instr.opcode = schema->opcode;
        for (int operand = 0; operand < schema->operand_count; operand++) {
            instr.operands[operand].i64 = operand + 1;
        }

        uint32_t encoded = isa_encode(&instr, buf, sizeof(buf));
        ASSERT(encoded > 0, "Opcode encodes successfully");

        DecodedInstruction decoded;
        uint32_t consumed = isa_decode(buf, encoded, &decoded);
        ASSERT_EQ_INT(consumed, encoded, "Decoded same number of bytes");
        ASSERT_EQ_INT(decoded.opcode, schema->opcode, "Opcode round-trips");

        char source[256];
        int length = snprintf(source, sizeof(source),
                              ".function coverage 0 0 0 void 0\n  %s",
                              schema->name);
        for (int operand = 0; operand < schema->operand_count; operand++) {
            const char *value = schema->operands[operand] == OPERAND_F64 ? " 1.5" : " 1";
            length += snprintf(source + length, sizeof(source) - (size_t)length,
                               "%s", value);
        }
        snprintf(source + length, sizeof(source) - (size_t)length, "\n.end\n");

        /* Fragment, not a program: a lone DUP has an empty stack and a lone
         * LOAD_LOCAL names a slot the zero-local function does not have, so
         * these could never verify. This sweep checks encoding coverage, so it
         * assembles without the verification pass. */
        AsmResult result;
        NvmModule *mod = asm_assemble_unverified(source, &result);
        ASSERT(mod != NULL, "Every schema opcode assembles");
        ASSERT_EQ_INT(mod->code[mod->functions[0].code_offset], schema->opcode,
                      "Assembly emits schema opcode");

        char *listing = disasm_module(mod);
        if (schema->opcode >= OP_FILE_SERVICE && schema->opcode <= OP_FILE_CALL_INDIRECT_REFS) {
            ASSERT(listing == NULL, "File fragment module disassembly refuses");
            FILE *raw = tmpfile();
            ASSERT(raw != NULL, "Raw File listing stream opens");
            disasm_function_styled(mod->code, mod->code_size, NULL, raw,
                                   DISASM_STYLE_CANONICAL);
            ASSERT(fflush(raw) == 0, "Raw File listing flushes");
            rewind(raw);
            char fragment[256] = {0};
            size_t bytes = fread(fragment, 1, sizeof(fragment) - 1, raw);
            ASSERT(bytes > 0 && !ferror(raw), "Raw File listing reads");
            ASSERT(strstr(fragment, schema->name) != NULL,
                   "Raw File disassembly emits schema mnemonic");
            ASSERT(fclose(raw) == 0, "Raw File listing closes");
            nvm_module_free(mod);
            continue;
        }
        ASSERT(listing != NULL, "Every schema opcode disassembles");
        ASSERT(strstr(listing, schema->name) != NULL,
               "Disassembly emits schema mnemonic");
        free(listing);
        nvm_module_free(mod);
    }
}

/* ========================================================================
 * NVM Format Tests
 * ======================================================================== */

static void test_crc32(void) {
    const uint8_t data[] = "Hello, World!";
    uint32_t crc = nvm_crc32(data, 13);
    /* Known CRC32 value for "Hello, World!" */
    ASSERT_EQ_INT(crc, 0xEC4AC3D0, "CRC32 of 'Hello, World!'");
}

static void test_module_new_free(void) {
    NvmModule *mod = nvm_module_new();
    ASSERT(mod != NULL, "Module created");
    ASSERT_EQ_INT(mod->header.magic[0], 'N', "Magic byte 0");
    ASSERT_EQ_INT(mod->header.magic[1], 'V', "Magic byte 1");
    ASSERT_EQ_INT(mod->header.magic[2], 'M', "Magic byte 2");
    ASSERT_EQ_INT(mod->header.magic[3], 0x01, "Magic byte 3");
    ASSERT_EQ_INT(mod->string_count, 0, "No strings initially");
    ASSERT_EQ_INT(mod->function_count, 0, "No functions initially");
    nvm_module_free(mod);
}

static void test_string_pool(void) {
    NvmModule *mod = nvm_module_new();

    uint32_t idx0 = nvm_add_string(mod, "hello", 5);
    uint32_t idx1 = nvm_add_string(mod, "world", 5);
    uint32_t idx2 = nvm_add_string(mod, "hello", 5); /* duplicate */

    ASSERT_EQ_INT(idx0, 0, "First string at index 0");
    ASSERT_EQ_INT(idx1, 1, "Second string at index 1");
    ASSERT_EQ_INT(idx2, 0, "Duplicate returns existing index");
    ASSERT_EQ_INT(mod->string_count, 2, "Two unique strings");
    ASSERT_EQ_STR(nvm_get_string(mod, 0), "hello", "String 0 content");
    ASSERT_EQ_STR(nvm_get_string(mod, 1), "world", "String 1 content");
    ASSERT(nvm_get_string(mod, 99) == NULL, "Out of range returns NULL");

    nvm_module_free(mod);
}

static void test_function_table(void) {
    NvmModule *mod = nvm_module_new();

    NvmFunctionEntry fn1 = { .name_idx = 0, .arity = 2, .code_offset = 0,
                             .code_length = 10, .local_count = 3, .upvalue_count = 0,
                             .result_tag = TAG_INT, .result_count = 1 };
    NvmFunctionEntry fn2 = { .name_idx = 1, .arity = 0, .code_offset = 10,
                             .code_length = 20, .local_count = 5, .upvalue_count = 1,
                             .result_tag = TAG_VOID, .result_count = 0 };

    uint32_t i0 = nvm_add_function(mod, &fn1);
    uint32_t i1 = nvm_add_function(mod, &fn2);

    ASSERT_EQ_INT(i0, 0, "First function at index 0");
    ASSERT_EQ_INT(i1, 1, "Second function at index 1");
    ASSERT_EQ_INT(mod->function_count, 2, "Two functions");
    ASSERT_EQ_INT(mod->functions[0].arity, 2, "Function 0 arity");
    ASSERT_EQ_INT(mod->functions[1].local_count, 5, "Function 1 locals");
    ASSERT_EQ_INT(mod->functions[0].result_tag, TAG_INT, "Function 0 result tag");
    ASSERT_EQ_INT(mod->functions[0].result_count, 1, "Function 0 result count");

    nvm_module_free(mod);
}

static void test_code_append(void) {
    NvmModule *mod = nvm_module_new();

    uint8_t code1[] = { OP_PUSH_I64, 0x2A, 0, 0, 0, 0, 0, 0, 0 };
    uint8_t code2[] = { OP_PRINT, OP_HALT };

    uint8_t *original_code = mod->code;
    uint32_t original_capacity = mod->code_capacity;
    ASSERT_EQ_INT(nvm_append_code(mod, NULL, 0), 0, "I return the empty code offset");
    ASSERT(mod->code == original_code, "I preserve empty code storage");
    ASSERT_EQ_INT(mod->code_capacity, original_capacity, "I preserve empty code capacity");
    ASSERT_EQ_INT(mod->code_size, 0, "I keep empty code empty");

    uint32_t off1 = nvm_append_code(mod, code1, sizeof(code1));
    ASSERT_EQ_INT(nvm_append_code(mod, NULL, 0), sizeof(code1), "I return the populated code offset");
    ASSERT_EQ_INT(nvm_append_code(mod, code2, 0), sizeof(code1), "I ignore nonnull empty input");
    ASSERT(mod->code == original_code, "I preserve populated code storage");
    ASSERT_EQ_INT(mod->code_capacity, original_capacity, "I preserve populated code capacity");
    ASSERT(memcmp(mod->code, code1, sizeof(code1)) == 0, "I preserve existing code bytes");
    uint32_t off2 = nvm_append_code(mod, code2, sizeof(code2));

    ASSERT_EQ_INT(off1, 0, "First code at offset 0");
    ASSERT_EQ_INT(off2, 9, "Second code after first");
    ASSERT_EQ_INT(mod->code_size, 11, "Total code size");
    ASSERT_EQ_INT(mod->code[0], OP_PUSH_I64, "First opcode");
    ASSERT_EQ_INT(mod->code[9], OP_PRINT, "Second opcode");

    nvm_module_free(mod);
}

static void test_serialize_deserialize(void) {
    NvmModule *mod = nvm_module_new();
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = 0;

    nvm_add_string(mod, "main", 4);
    nvm_add_string(mod, "hello", 5);

    NvmFunctionEntry fn = { .name_idx = 0, .arity = 0, .code_offset = 0,
                            .code_length = 0, .local_count = 1, .upvalue_count = 0,
                            .result_tag = TAG_STRING, .result_count = 1 };
    nvm_add_function(mod, &fn);

    /* Some bytecode */
    uint8_t code[] = { OP_PUSH_STR, 1, 0, 0, 0, OP_PRINT, OP_HALT };
    uint32_t off = nvm_append_code(mod, code, sizeof(code));
    mod->functions[0].code_offset = off;
    mod->functions[0].code_length = sizeof(code);

    /* Debug info */
    nvm_add_debug_entry(mod, 0, 1, 5);
    nvm_add_debug_entry(mod, 5, 2, 0);

    /* Serialize */
    uint32_t out_size;
    uint8_t *data = nvm_serialize(mod, &out_size);
    ASSERT(data != NULL, "Serialization succeeded");
    ASSERT(out_size > NVM_HEADER_SIZE, "Output larger than header");

    /* Deserialize */
    NvmModule *mod2 = nvm_deserialize(data, out_size);
    ASSERT(mod2 != NULL, "Deserialization succeeded");

    /* Verify header */
    ASSERT_EQ_INT(mod2->header.format_version, NVM_FORMAT_VERSION, "Format version");
    ASSERT_EQ_INT(mod2->header.flags, NVM_FLAG_HAS_MAIN, "Flags");
    ASSERT_EQ_INT(mod2->header.entry_point, 0, "Entry point");

    /* Verify strings */
    ASSERT_EQ_INT(mod2->string_count, 2, "String count");
    ASSERT_EQ_STR(nvm_get_string(mod2, 0), "main", "String 0");
    ASSERT_EQ_STR(nvm_get_string(mod2, 1), "hello", "String 1");

    /* Verify functions */
    ASSERT_EQ_INT(mod2->function_count, 1, "Function count");
    ASSERT_EQ_INT(mod2->functions[0].arity, 0, "Function arity");
    ASSERT_EQ_INT(mod2->functions[0].local_count, 1, "Function locals");
    ASSERT_EQ_INT(mod2->functions[0].code_length, sizeof(code), "Function code length");
    ASSERT_EQ_INT(mod2->functions[0].result_tag, TAG_STRING, "Function result tag");
    ASSERT_EQ_INT(mod2->functions[0].result_count, 1, "Function result count");

    /* Verify code */
    ASSERT_EQ_INT(mod2->code_size, sizeof(code), "Code size");
    ASSERT_EQ_INT(mod2->code[0], OP_PUSH_STR, "Code byte 0");
    ASSERT_EQ_INT(mod2->code[5], OP_PRINT, "Code byte 5");
    ASSERT_EQ_INT(mod2->code[6], OP_HALT, "Code byte 6");

    /* Verify debug */
    ASSERT_EQ_INT(mod2->debug_count, 2, "Debug entry count");
    ASSERT_EQ_INT(mod2->debug_entries[0].bytecode_offset, 0, "Debug 0 offset");
    ASSERT_EQ_INT(mod2->debug_entries[0].source_line, 1, "Debug 0 line");
    ASSERT_EQ_INT(mod2->debug_entries[0].source_col, 5, "Debug 0 col");
    ASSERT_EQ_INT(mod2->debug_entries[1].bytecode_offset, 5, "Debug 1 offset");
    ASSERT_EQ_INT(mod2->debug_entries[1].source_line, 2, "Debug 1 line");
    ASSERT_EQ_INT(mod2->debug_entries[1].source_col, 0, "Debug 1 col");

    free(data);
    nvm_module_free(mod);
    nvm_module_free(mod2);
}

static void test_strip_debug_info(void) {
    NvmModule *mod = nvm_module_new();
    mod->header.flags = NVM_FLAG_HAS_MAIN | NVM_FLAG_DEBUG_INFO;
    mod->header.entry_point = 0;

    uint32_t src_idx = nvm_add_string(mod, "tests/sample.nano", 17);
    nvm_add_string(mod, "main", 4);
    mod->source_file_idx = src_idx;

    NvmFunctionEntry fn = {
        .name_idx = 1, .arity = 0, .code_offset = 0,
        .code_length = 0, .local_count = 1, .upvalue_count = 0
    };
    nvm_add_function(mod, &fn);

    uint8_t code[] = { OP_DEBUG_LINE, 42, 0, 0, 0, OP_PUSH_I64, 0, 0, 0, 0, 0, 0, 0, 0, OP_RET };
    uint32_t off = nvm_append_code(mod, code, sizeof(code));
    mod->functions[0].code_offset = off;
    mod->functions[0].code_length = sizeof(code);

    nvm_add_debug_entry(mod, 0, 42, 1);
    ASSERT_EQ_INT(mod->debug_count, 1, "Debug entry added");
    ASSERT((mod->header.flags & NVM_FLAG_DEBUG_INFO) != 0, "Debug flag set before strip");

    nvm_strip_debug_info(mod);

    ASSERT_EQ_INT(mod->debug_count, 0, "Debug entries stripped");
    ASSERT_EQ_INT(mod->source_file_idx, 0, "Source file index stripped");
    ASSERT((mod->header.flags & NVM_FLAG_DEBUG_INFO) == 0, "Debug flag cleared");

    uint32_t out_size = 0;
    uint8_t *data = nvm_serialize(mod, &out_size);
    ASSERT(data != NULL, "Serialization after strip succeeded");

    NvmModule *mod2 = nvm_deserialize(data, out_size);
    ASSERT(mod2 != NULL, "Deserialization after strip succeeded");
    ASSERT_EQ_INT(mod2->debug_count, 0, "No debug entries serialized");
    ASSERT((mod2->header.flags & NVM_FLAG_DEBUG_INFO) == 0, "No debug flag serialized");
    ASSERT_EQ_INT(mod2->source_file_idx, 0, "Source file index remains stripped");

    free(data);
    nvm_module_free(mod);
    nvm_module_free(mod2);
}

static void test_validate_header(void) {
    NvmHeader header;
    header.magic[0] = 'N';
    header.magic[1] = 'V';
    header.magic[2] = 'M';
    header.magic[3] = 0x01;
    header.format_version = NVM_FORMAT_VERSION;
    header.section_count = 3;

    ASSERT(nvm_validate_header(&header), "Valid header");

    header.magic[0] = 'X';
    ASSERT(!nvm_validate_header(&header), "Bad magic rejected");

    header.magic[0] = 'N';
    header.format_version = 999;
    ASSERT(!nvm_validate_header(&header), "Bad version rejected");

    header.format_version = NVM_FORMAT_VERSION;
    header.section_count = NVM_MAX_SECTIONS + 1;
    ASSERT(!nvm_validate_header(&header), "Too many sections rejected");
}

static void test_corrupt_checksum(void) {
    NvmModule *mod = nvm_module_new();
    nvm_add_string(mod, "test", 4);

    uint32_t out_size;
    uint8_t *data = nvm_serialize(mod, &out_size);
    ASSERT(data != NULL, "Serialization succeeded");

    /* Corrupt a data byte */
    if (out_size > NVM_HEADER_SIZE + 5) {
        data[NVM_HEADER_SIZE + 5] ^= 0xFF;
    }

    NvmModule *mod2 = nvm_deserialize(data, out_size);
    ASSERT(mod2 == NULL, "Corrupt data rejected");

    free(data);
    nvm_module_free(mod);
}


/* ========================================================================
 * Module Format Structural Validation Tests
 *
 * These exercise nvm_deserialize's rejection of malformed section directories:
 * duplicate singleton sections, overlapping sections, partial fixed-width
 * records, and trailing/uncovered data. Each test builds a raw buffer with a
 * valid header and CRC so the failure is attributable to the directory alone.
 * ======================================================================== */

/* Little-endian writers local to the test (mirror the format module). */
static void t_put_u32(uint8_t *b, uint32_t v) {
    b[0] = (uint8_t)(v & 0xFF);
    b[1] = (uint8_t)((v >> 8) & 0xFF);
    b[2] = (uint8_t)((v >> 16) & 0xFF);
    b[3] = (uint8_t)((v >> 24) & 0xFF);
}

/* Write a valid NVM header into buf for the given section count, then compute
 * and store the CRC32 over everything after the header. buf must be exactly
 * total_size bytes and already contain the directory + section data. */
static void t_finalize(uint8_t *buf, uint32_t total_size, uint32_t section_count) {
    buf[0] = 'N'; buf[1] = 'V'; buf[2] = 'M'; buf[3] = 0x01;
    t_put_u32(buf + 4,  NVM_FORMAT_VERSION);
    t_put_u32(buf + 8,  0);              /* flags */
    t_put_u32(buf + 12, 0);              /* entry_point */
    t_put_u32(buf + 16, section_count);
    t_put_u32(buf + 20, 0);              /* string_pool_offset */
    t_put_u32(buf + 24, 0);              /* string_pool_length */
    uint32_t crc = nvm_crc32(buf + NVM_HEADER_SIZE, total_size - NVM_HEADER_SIZE);
    t_put_u32(buf + 28, crc);
}

/* Baseline: a hand-built single-CODE-section module must deserialize. This
 * proves the raw-buffer builder produces something valid, so the negative
 * tests below isolate the malformation they inject. */
static void test_module_raw_valid_baseline(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE; /* one section */
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint8_t payload[3] = { OP_HALT, OP_HALT, OP_HALT };
    uint32_t total = data_start + sizeof(payload);
    uint8_t *buf = calloc(1, total);

    /* directory entry 0: CODE at data_start, size 3 */
    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, sizeof(payload));
    memcpy(buf + data_start, payload, sizeof(payload));

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod != NULL, "Hand-built valid module deserializes");
    ASSERT_EQ_INT(mod->code_size, 3, "Baseline code size");
    nvm_module_free(mod);
    free(buf);
}

/* Duplicate singleton section: two CODE sections must be rejected. */
static void test_module_reject_duplicate_singleton(void) {
    uint32_t dir = 2 * NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 4; /* 2 bytes each */
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0,  NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4,  data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8,  2);
    t_put_u32(buf + NVM_HEADER_SIZE + 12, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 16, data_start + 2);
    t_put_u32(buf + NVM_HEADER_SIZE + 20, 2);

    t_finalize(buf, total, 2);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Duplicate singleton section rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Overlapping sections: two sections whose byte ranges overlap are rejected. */
static void test_module_reject_overlap(void) {
    uint32_t dir = 2 * NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 8;
    uint8_t *buf = calloc(1, total);

    /* CODE covers [data_start, data_start+8); STRINGS overlaps it at +4. */
    t_put_u32(buf + NVM_HEADER_SIZE + 0,  NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4,  data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8,  8);
    t_put_u32(buf + NVM_HEADER_SIZE + 12, NVM_SECTION_STRINGS);
    t_put_u32(buf + NVM_HEADER_SIZE + 16, data_start + 4);
    t_put_u32(buf + NVM_HEADER_SIZE + 20, 4);

    t_finalize(buf, total, 2);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Overlapping sections rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Containment is overlap even when both section endpoints are otherwise in
 * range and the directory lists the inner section first. */
static void test_module_reject_contained_overlap(void) {
    uint32_t dir = 2 * NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 8;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0,  99);
    t_put_u32(buf + NVM_HEADER_SIZE + 4,  data_start + 2);
    t_put_u32(buf + NVM_HEADER_SIZE + 8,  2);
    t_put_u32(buf + NVM_HEADER_SIZE + 12, 100);
    t_put_u32(buf + NVM_HEADER_SIZE + 16, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 20, 8);

    t_finalize(buf, total, 2);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Contained section overlap rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Directory order does not define data order. Adjacent sections in reverse
 * directory order still form a valid partition. */
static void test_module_accept_reverse_order_adjacent_sections(void) {
    uint32_t dir = 2 * NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 4;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0,  99);
    t_put_u32(buf + NVM_HEADER_SIZE + 4,  data_start + 2);
    t_put_u32(buf + NVM_HEADER_SIZE + 8,  2);
    t_put_u32(buf + NVM_HEADER_SIZE + 12, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 16, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 20, 2);

    t_finalize(buf, total, 2);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod != NULL, "Reverse-order adjacent sections accepted");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Partial fixed-width record: a FUNCTIONS section whose size is not a whole
 * multiple of NVM_FUNCTION_ENTRY_SIZE is rejected. */
static void test_module_reject_partial_record(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t bad_size = NVM_FUNCTION_ENTRY_SIZE + 3; /* not a multiple */
    uint32_t total = data_start + bad_size;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_FUNCTIONS);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, bad_size);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Partial fixed-width record rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Trailing data: bytes after the last section, not covered by any section,
 * are rejected. */
static void test_module_reject_trailing_data(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t sec_size = 2;
    uint32_t total = data_start + sec_size + 4; /* 4 uncovered trailing bytes */
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, sec_size);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Trailing uncovered data rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Interior gap: a hole between two sections (uncovered bytes) is rejected. */
static void test_module_reject_interior_gap(void) {
    uint32_t dir = 2 * NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 10; /* [0,2) CODE, [2,6) GAP, [6,10) STRINGS */
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0,  NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4,  data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8,  2);
    t_put_u32(buf + NVM_HEADER_SIZE + 12, NVM_SECTION_STRINGS);
    t_put_u32(buf + NVM_HEADER_SIZE + 16, data_start + 6);
    t_put_u32(buf + NVM_HEADER_SIZE + 20, 4);

    t_finalize(buf, total, 2);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Interior gap between sections rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Section overlapping the directory: an offset pointing inside the header or
 * directory region is rejected. */
static void test_module_reject_section_into_directory(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 4;
    uint8_t *buf = calloc(1, total);

    /* Offset points at the header (0), overlapping header + directory. */
    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, 0);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, total);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Section overlapping the directory rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Out-of-range section: an offset beyond the end of the input is rejected. */
static void test_module_reject_section_out_of_range(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 1;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, total + 1);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, 1);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Section offset beyond input rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Wrapped section range: offset + size must be checked without uint32
 * arithmetic wrapping back into the input. */
static void test_module_reject_wrapped_section_range(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t total = data_start + 1;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_CODE);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, UINT32_MAX - 3);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, 8);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Wrapped section range rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* Partial fixed-width record: DEBUG entries use the same structural rule as
 * function entries and must not silently discard a short tail. */
static void test_module_reject_partial_debug_record(void) {
    uint32_t dir = NVM_SECTION_ENTRY_SIZE;
    uint32_t data_start = NVM_HEADER_SIZE + dir;
    uint32_t bad_size = NVM_DEBUG_ENTRY_SIZE - 1;
    uint32_t total = data_start + bad_size;
    uint8_t *buf = calloc(1, total);

    t_put_u32(buf + NVM_HEADER_SIZE + 0, NVM_SECTION_DEBUG);
    t_put_u32(buf + NVM_HEADER_SIZE + 4, data_start);
    t_put_u32(buf + NVM_HEADER_SIZE + 8, bad_size);

    t_finalize(buf, total, 1);

    NvmModule *mod = nvm_deserialize(buf, total);
    ASSERT(mod == NULL, "Partial debug record rejected");
    if (mod) nvm_module_free(mod);
    free(buf);
}

/* A well-formed multi-section module (contiguous, ordered, distinct types)
 * built via the serializer still round-trips after hardening. */
static void test_module_valid_multisection_roundtrip(void) {
    NvmModule *mod = nvm_module_new();
    nvm_add_string(mod, "main", 4);
    NvmFunctionEntry fn = { .name_idx = 0, .arity = 0, .code_offset = 0,
                            .code_length = 0, .local_count = 0, .upvalue_count = 0,
                            .result_tag = 0, .result_count = 0 };
    nvm_add_function(mod, &fn);
    uint8_t code[] = { OP_HALT };
    nvm_append_code(mod, code, sizeof(code));
    nvm_add_debug_entry(mod, 0, 1, 1);
    uint8_t ptypes[1] = { TAG_INT };
    uint32_t m = nvm_add_string(mod, "std", 3);
    uint32_t fnn = nvm_add_string(mod, "print", 5);
    nvm_add_import(mod, m, fnn, 1, TAG_INT, ptypes);

    uint32_t out_size = 0;
    uint8_t *data = nvm_serialize(mod, &out_size);
    ASSERT(data != NULL, "Multi-section serialize");
    NvmModule *mod2 = nvm_deserialize(data, out_size);
    ASSERT(mod2 != NULL, "Multi-section (strings+code+functions+debug+imports) round-trips");
    nvm_module_free(mod2);
    free(data);
    nvm_module_free(mod);
}

/* ========================================================================
 * Assembler Tests
 * ======================================================================== */

static void test_asm_simple_program(void) {
    const char *src =
        ".string \"hello\"\n"
        ".entry 0\n"
        ".function main 0 1 0 string 1\n"
        "  PUSH_STR 0\n"
        "  PRINT\n"
        "  HALT\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);

    ASSERT(mod != NULL, "Assembly succeeded");
    ASSERT_EQ_INT(result.error, ASM_OK, "No error");
    ASSERT_EQ_INT(mod->string_count, 2, "2 strings (hello + main)");
    ASSERT_EQ_STR(nvm_get_string(mod, 0), "hello", "String 0");
    ASSERT_EQ_STR(nvm_get_string(mod, 1), "main", "String 1 (function name)");
    ASSERT_EQ_INT(mod->function_count, 1, "1 function");
    ASSERT_EQ_INT(mod->functions[0].arity, 0, "main arity 0");
    ASSERT_EQ_INT(mod->functions[0].result_tag, TAG_STRING, "main result tag");
    ASSERT_EQ_INT(mod->functions[0].result_count, 1, "main result count");
    ASSERT_EQ_INT(mod->header.flags & NVM_FLAG_HAS_MAIN, NVM_FLAG_HAS_MAIN, "has_main flag");

    /* Check bytecode */
    ASSERT(mod->functions[0].code_length > 0, "Function has code");
    const uint8_t *code = mod->code + mod->functions[0].code_offset;
    ASSERT_EQ_INT(code[0], OP_PUSH_STR, "First instruction PUSH_STR");

    nvm_module_free(mod);
}

static void test_asm_labels_and_jumps(void) {
    const char *src =
        ".function test_loop 0 2 0 void 0\n"
        "  PUSH_I64 0\n"
        "  STORE_LOCAL 0\n"
        "loop_top:\n"
        "  LOAD_LOCAL 0\n"
        "  PUSH_I64 10\n"
        "  LT\n"
        "  JMP_FALSE loop_end\n"
        "  LOAD_LOCAL 0\n"
        "  PUSH_I64 1\n"
        "  ADD\n"
        "  STORE_LOCAL 0\n"
        "  JMP loop_top\n"
        "loop_end:\n"
        "  RET\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);

    ASSERT(mod != NULL, "Assembly with labels succeeded");
    ASSERT_EQ_INT(result.error, ASM_OK, "No error");
    ASSERT_EQ_INT(mod->function_count, 1, "1 function");
    ASSERT(mod->functions[0].code_length > 0, "Function has code");

    /* Verify jumps are resolved to offsets (not zero placeholders) */
    /* The JMP_FALSE should target loop_end, JMP should target loop_top */
    const uint8_t *code = mod->code + mod->functions[0].code_offset;
    uint32_t code_size = mod->functions[0].code_length;

    /* Decode instructions to find JMP_FALSE */
    uint32_t pos = 0;
    bool found_jmp_false = false;
    bool found_jmp = false;
    while (pos < code_size) {
        DecodedInstruction instr;
        uint32_t consumed = isa_decode(code + pos, code_size - pos, &instr);
        if (consumed == 0) break;

        if (instr.opcode == OP_JMP_FALSE) {
            found_jmp_false = true;
            ASSERT(instr.operands[0].i32 > 0, "JMP_FALSE offset is forward");
        }
        if (instr.opcode == OP_JMP) {
            found_jmp = true;
            ASSERT(instr.operands[0].i32 < 0, "JMP offset is backward (loop)");
        }

        pos += consumed;
    }
    ASSERT(found_jmp_false, "Found JMP_FALSE instruction");
    ASSERT(found_jmp, "Found JMP instruction");

    nvm_module_free(mod);
}

static void test_asm_all_operand_types(void) {
    const char *src =
        ".string \"test string\"\n"
        ".function test_ops 0 5 0 void 0\n"
        "  PUSH_I64 -9999\n"
        "  PUSH_F64 2.718281828\n"
        "  PUSH_BOOL 1\n"
        "  PUSH_STR 0\n"
        "  PUSH_U8 255\n"
        "  PUSH_VOID\n"
        "  LOAD_LOCAL 42\n"
        "  STORE_LOCAL 42\n"
        "  LOAD_GLOBAL 1000\n"
        "  STORE_GLOBAL 1000\n"
        "  LOAD_UPVALUE 1 3\n"
        "  STORE_UPVALUE 2 4\n"
        "  ARR_NEW 1\n"
        "  ARR_LITERAL 1 5\n"
        "  STRUCT_LITERAL 0 3\n"
        "  UNION_CONSTRUCT 0 1 2\n"
        "  MATCH_TAG 0 5\n"
        "  ENUM_VAL 0 3\n"
        "  TUPLE_NEW 4\n"
        "  HM_NEW 1 5\n"
        "  CLOSURE_NEW 0 3\n"
        "  TYPE_CHECK 4\n"
        "  DEBUG_LINE 100\n"
        "  CALL 0\n"
        "  TAIL_CALL 0\n"
        "  CALL_EXTERN 1\n"
        "  CALL_MODULE 0 1 0 1\n"
        "  HALT\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "All operand types were consumed before verification");
    ASSERT_EQ_INT(result.error, ASM_ERR_VERIFY,
                  "Semantically invalid operand fixture reaches verification");

    nvm_module_free(mod);
}

static void test_asm_error_unknown_opcode(void) {
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  NONEXISTENT_OP\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Unknown opcode returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_UNKNOWN_OPCODE, "Error type");
    ASSERT_EQ_INT(result.line, 2, "Error on line 2");
}

static void test_asm_error_undefined_label(void) {
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  JMP nonexistent\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Undefined label returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_UNDEFINED_LABEL, "Error type");
}

static void test_asm_error_missing_end(void) {
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  HALT\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Missing .end returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_SYNTAX, "Error type");
}

static void test_asm_error_instruction_outside_function(void) {
    const char *src =
        "PUSH_I64 42\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Instruction outside function returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_NO_FUNCTION, "Error type");
}

static void test_asm_error_bad_u8_operand(void) {
    /* PUSH_U8 expects a u8; provide a non-numeric → ASM_ERR_BAD_OPERAND */
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  PUSH_U8 notanumber\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Bad u8 operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_BAD_OPERAND, "Error type BAD_OPERAND");
}

static void test_asm_error_bad_u32_operand(void) {
    /* PUSH_STR expects a u32; provide garbage → ASM_ERR_BAD_OPERAND */
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  PUSH_STR @#$\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Bad u32 operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_BAD_OPERAND, "Error type BAD_OPERAND");
}

static void test_asm_error_bad_i64_operand(void) {
    /* PUSH_I64 expects an i64; provide garbage → ASM_ERR_BAD_OPERAND */
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  PUSH_I64 notanumber\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Bad i64 operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_BAD_OPERAND, "Error type BAD_OPERAND");
}

static void test_asm_error_bad_f64_operand(void) {
    /* PUSH_F64 expects an f64; provide garbage → ASM_ERR_BAD_OPERAND */
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  PUSH_F64 notanumber\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Bad f64 operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_BAD_OPERAND, "Error type BAD_OPERAND");
}

static void test_asm_error_bad_u16_operand(void) {
    /* ARR_LITERAL expects u8 then u16; provide bad u16 → ASM_ERR_BAD_OPERAND */
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  ARR_LITERAL 1 notanumber\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Bad u16 operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_BAD_OPERAND, "Error type BAD_OPERAND");
}

static void test_asm_error_trailing_instruction_operand(void) {
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  HALT unexpected\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Trailing instruction operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_SYNTAX, "Trailing operand is a syntax error");
    ASSERT_EQ_INT(result.line, 2, "Trailing operand reports its line");
}

static void test_asm_error_trailing_directive_operand(void) {
    const char *src = ".entry 0 unexpected\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Trailing directive operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_SYNTAX, "Trailing directive input is a syntax error");
    ASSERT_EQ_INT(result.line, 1, "Trailing directive input reports its line");
}

static void test_asm_rejects_unverified_module(void) {
    const char *src =
        ".function test 0 0 0 void 0\n"
        "  LOAD_LOCAL 0\n"
        "  HALT\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Unverified assembled module returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_VERIFY, "Verifier failure has a distinct error");
    ASSERT(strstr(result.message, "slot 0 >= local_count 0") != NULL,
           "Assembler preserves verifier diagnostic");
}

static void test_asm_comments_and_whitespace(void) {
    const char *src =
        "; This is a comment\n"
        "# This is also a comment\n"
        "\n"
        "  \n"
        ".function main 0 0 0 void 0\n"
        "  NOP ; inline comment\n"
        "  HALT\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod != NULL, "Comments and whitespace handled");
    ASSERT_EQ_INT(result.error, ASM_OK, "No error");
    nvm_module_free(mod);
}

/* A quoted string ending in a backslash is an unterminated escape. It must be
 * rejected, not walked past: the escape branch consumes the terminator and the
 * loop then steps outside the line buffer, which AddressSanitizer reports as a
 * heap-buffer-overflow read in parse_quoted_string. Found by the malformed-input
 * fuzz tests once they could run under sanitizers. */
static void test_asm_trailing_backslash_rejected(void) {
    AsmResult result;
    NvmModule *mod = asm_assemble(".string \"abc\\", &result);
    ASSERT(mod == NULL, "Unterminated escape must not assemble");
    ASSERT(result.error != ASM_OK, "Unterminated escape reports an error");
}

static void test_asm_string_escapes(void) {
    const char *src =
        ".string \"hello\\nworld\"\n"
        ".string \"tab\\there\"\n"
        ".string \"quote\\\"inside\"\n"
        ".string \"backslash\\\\\"\n"
        ".function main 0 0 0 void 0\n"
        "  HALT\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod != NULL, "String escapes assembly succeeded");

    /* .function adds "main" as string 4, but our explicit strings are first */
    ASSERT(mod->string_count >= 4, "At least 4 strings");
    ASSERT_EQ_STR(nvm_get_string(mod, 0), "hello\nworld", "Newline escape");
    ASSERT_EQ_STR(nvm_get_string(mod, 1), "tab\there", "Tab escape");
    ASSERT_EQ_STR(nvm_get_string(mod, 2), "quote\"inside", "Quote escape");
    ASSERT_EQ_STR(nvm_get_string(mod, 3), "backslash\\", "Backslash escape");

    nvm_module_free(mod);
}

static void test_asm_multiple_functions(void) {
    const char *src =
        ".function add 2 2 0 int 1\n"
        "  LOAD_LOCAL 0\n"
        "  LOAD_LOCAL 1\n"
        "  ADD\n"
        "  RET\n"
        ".end\n"
        ".function main 0 1 0 void 0\n"
        "  PUSH_I64 3\n"
        "  PUSH_I64 4\n"
        "  CALL 0\n"
        "  PRINT\n"
        "  HALT\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod != NULL, "Multiple functions assembly succeeded");
    ASSERT_EQ_INT(mod->function_count, 2, "2 functions");
    ASSERT_EQ_INT(mod->functions[0].arity, 2, "add arity");
    ASSERT_EQ_INT(mod->functions[1].arity, 0, "main arity");

    /* Functions should have distinct code regions */
    ASSERT(mod->functions[0].code_offset != mod->functions[1].code_offset,
           "Functions at different offsets");

    nvm_module_free(mod);
}

static void test_asm_symbolic_operands(void) {
    const char *src =
        ".string greeting \"hello\"\n"
        ".symbol import write 7\n"
        ".symbol type Point 3\n"
        ".symbol field x 1\n"
        ".function helper 0 0 0 void 0\n"
        "  CALL main\n"
        "  RET\n"
        ".end\n"
        ".function main 0 0 0 void 0\n"
        "again:\n"
        "  PUSH_STR greeting\n"
        "  CALL helper\n"
        "  CALL_EXTERN write\n"
        "  STRUCT_NEW Point\n"
        "  STRUCT_GET x\n"
        "  JMP again\n"
        "  RET\n"
        ".end\n"
        ".entry main\n";

    /* Fragment, not a program: the symbol indices here are arbitrary by design
     * (.symbol import write 7 with no imports declared), because what is under
     * test is that symbolic operands resolve to the indices named, not that the
     * result is runnable. Assemble without verification. */
    AsmResult result;
    NvmModule *mod = asm_assemble_unverified(src, &result);
    ASSERT(mod != NULL, "Symbolic operands assemble");
    ASSERT_EQ_INT(result.error, ASM_OK, "Symbolic operands have no error");
    ASSERT_EQ_INT(mod->header.entry_point, 1, "Symbolic entry resolves function");

    DecodedInstruction forward_call;
    ASSERT(isa_decode(mod->code + mod->functions[0].code_offset,
                      mod->functions[0].code_length, &forward_call) > 0,
           "Forward function call decodes");
    ASSERT_EQ_INT(forward_call.operands[0].u32, 1,
                  "Forward function symbol resolves function index");

    const uint8_t *code = mod->code + mod->functions[1].code_offset;
    uint32_t pos = 0;
    DecodedInstruction instr;
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT_EQ_INT(instr.operands[0].u32, 0, "Constant symbol resolves string index");
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT_EQ_INT(instr.operands[0].u32, 0, "Function symbol resolves function index");
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT_EQ_INT(instr.operands[0].u32, 7, "Import symbol resolves import index");
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT_EQ_INT(instr.operands[0].u32, 3, "Type symbol resolves layout index");
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT_EQ_INT(instr.operands[0].u16, 1, "Field symbol resolves field index");
    pos += isa_decode(code + pos, mod->functions[1].code_length - pos, &instr);
    ASSERT(instr.operands[0].i32 < 0, "Label symbol resolves relative branch");
    nvm_module_free(mod);
}

static void test_asm_error_undefined_symbol(void) {
    const char *src =
        ".function main 0 0 0 void 0\n"
        "  CALL missing\n"
        ".end\n";
    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod == NULL, "Undefined symbolic operand returns NULL");
    ASSERT_EQ_INT(result.error, ASM_ERR_UNDEFINED_SYMBOL, "Undefined symbol error type");
}

/* ========================================================================
 * Disassembler Tests
 * ======================================================================== */

static void test_disasm_basic(void) {
    NvmModule *mod = nvm_module_new();
    nvm_add_string(mod, "main", 4);
    nvm_add_string(mod, "hello", 5);

    NvmFunctionEntry fn = { .name_idx = 0, .arity = 0, .code_offset = 0,
                            .code_length = 0, .local_count = 1, .upvalue_count = 0 };
    nvm_add_function(mod, &fn);

    /* Build bytecode manually */
    uint8_t code[] = { OP_PUSH_STR, 1, 0, 0, 0, OP_PRINT, OP_HALT };
    uint32_t off = nvm_append_code(mod, code, sizeof(code));
    mod->functions[0].code_offset = off;
    mod->functions[0].code_length = sizeof(code);

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "Disassembly produced output");
    ASSERT(strstr(output, "PUSH_STR") != NULL, "Contains PUSH_STR");
    ASSERT(strstr(output, "PRINT") != NULL, "Contains PRINT");
    ASSERT(strstr(output, "HALT") != NULL, "Contains HALT");
    ASSERT(strstr(output, ".function main") != NULL, "Contains function header");
    ASSERT(strstr(output, ".end") != NULL, "Contains .end");
    ASSERT(strstr(output, "hello") != NULL, "Contains string comment");

    free(output);
    nvm_module_free(mod);
}

static void test_disasm_labels(void) {
    /* Assemble a program with jumps, then disassemble and check for labels */
    const char *src =
        ".function test 0 1 0 void 0\n"
        "  PUSH_I64 0\n"
        "  STORE_LOCAL 0\n"
        "loop:\n"
        "  LOAD_LOCAL 0\n"
        "  PUSH_I64 5\n"
        "  LT\n"
        "  JMP_FALSE done\n"
        "  LOAD_LOCAL 0\n"
        "  PUSH_I64 1\n"
        "  ADD\n"
        "  STORE_LOCAL 0\n"
        "  JMP loop\n"
        "done:\n"
        "  RET\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod != NULL, "Assembly for disasm test succeeded");

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "Disassembly produced output");

    /* Should contain reconstructed labels like L0, L1 */
    ASSERT(strstr(output, "L") != NULL, "Contains reconstructed labels");
    ASSERT(strstr(output, "JMP_FALSE") != NULL, "Contains JMP_FALSE");
    ASSERT(strstr(output, "JMP") != NULL, "Contains JMP");

    free(output);
    nvm_module_free(mod);
}

static void test_disasm_source_annotations_and_cfg(void) {
    const char *src =
        ".string \"tests/disasm_sample.nano\"\n"
        /* One declared result, and one value live at the RET both branches
         * reach. The fixture used to declare void and return a value; the
         * verifier now checks return shape, so that no longer assembles. */
        ".function main 0 1 0 int 1\n"
        "  DEBUG_LINE 42\n"
        "  PUSH_I64 1\n"
        "  JMP done\n"
        "  PUSH_I64 0\n"
        "done:\n"
        "  RET\n"
        ".end\n";

    AsmResult result;
    NvmModule *mod = asm_assemble(src, &result);
    ASSERT(mod != NULL, "Assembly with DEBUG_LINE succeeded");
    mod->source_file_idx = 0;

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "Disassembly produced output");
    ASSERT(strstr(output, "[0000|0000] DEBUG_LINE 42") != NULL, "Shows instruction offsets");
    ASSERT(strstr(output, "source tests/disasm_sample.nano:42") != NULL, "Shows source annotation");
    ASSERT(strstr(output, "; @ tests/disasm_sample.nano:42") != NULL, "Propagates line annotation");
    ASSERT(strstr(output, "; cfg:branch-if-false") == NULL, "No unrelated branch note");
    ASSERT(strstr(output, "; cfg:jump") != NULL, "Shows jump CFG annotation");
    ASSERT(strstr(output, "JMP L") != NULL, "Shows resolved jump target label reference");
    ASSERT(strstr(output, "<== jump target") != NULL, "Shows jump target marker");

    free(output);
    nvm_module_free(mod);
}

static char *disasm_raw_code(const uint8_t *code, uint32_t code_size) {
    char *output = NULL;
    size_t output_size = 0;
    FILE *stream = open_memstream(&output, &output_size);
    if (!stream) return NULL;
    disasm_function(code, code_size, NULL, stream);
    fclose(stream);
    return output;
}

static void test_disasm_malformed_bytecode(void) {
    uint8_t code[] = { OP_PUSH_I64, 0x01, OP_HALT };
    char *output = disasm_raw_code(code, sizeof(code));
    ASSERT(output != NULL, "Malformed disassembly produced output");
    ASSERT(strstr(output, "ERROR: invalid opcode") != NULL,
           "Malformed bytecode reports an error");
    ASSERT(strstr(output, "HALT") != NULL,
           "Disassembler recovers and decodes later valid bytes");
    free(output);
}

static void test_disasm_rejects_wrapped_function_range(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t name_idx = nvm_add_string(mod, "wrapped", 7);
    uint8_t code[] = { OP_HALT };
    nvm_append_code(mod, code, sizeof(code));
    NvmFunctionEntry fn = { .name_idx = name_idx,
                            .code_offset = UINT32_MAX,
                            .code_length = 2 };
    nvm_add_function(mod, &fn);

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "Wrapped-range disassembly produced output");
    ASSERT(strstr(output, ".function wrapped") != NULL,
           "Wrapped-range function declaration is preserved");
    ASSERT(strstr(output, "HALT") == NULL,
           "Wrapped-range function body is not read");

    free(output);
    nvm_module_free(mod);
}

static void test_disasm_label_deduplication(void) {
    DecodedInstruction jump = {0};
    uint8_t code[11] = {0};
    jump.opcode = OP_JMP;
    jump.operand_count = 1;
    jump.operand_types[0] = OPERAND_I32;
    jump.operands[0].i32 = 10;
    ASSERT_EQ_INT(isa_encode(&jump, code, sizeof(code)), 5, "First jump encoded");
    jump.operands[0].i32 = 5;
    ASSERT_EQ_INT(isa_encode(&jump, code + 5, sizeof(code) - 5), 5, "Second jump encoded");
    code[10] = OP_HALT;

    char *output = disasm_raw_code(code, sizeof(code));
    ASSERT(output != NULL, "Deduplication disassembly produced output");
    ASSERT(strstr(output, "JMP L0") != NULL, "Repeated target uses a label");
    ASSERT(strstr(output, "L1:") == NULL, "Repeated target is not assigned twice");
    free(output);
}

static void test_disasm_label_limit_degrades_gracefully(void) {
    const uint32_t jump_count = 513;
    const uint32_t jump_size = 5;
    const uint32_t code_size = jump_count * jump_size + jump_count + 1;
    uint8_t *code = calloc(code_size, 1);
    ASSERT(code != NULL, "Label-limit bytecode allocation succeeded");

    DecodedInstruction jump = {0};
    jump.opcode = OP_JMP;
    jump.operand_count = 1;
    jump.operand_types[0] = OPERAND_I32;
    for (uint32_t i = 0; i < jump_count; i++) {
        uint32_t pos = i * jump_size;
        uint32_t target = jump_count * jump_size + i;
        jump.operands[0].i32 = (int32_t)(target - pos);
        ASSERT_EQ_INT(isa_encode(&jump, code + pos, code_size - pos), jump_size,
                      "Label-limit jump encoded");
    }
    memset(code + jump_count * jump_size, OP_NOP, jump_count);
    code[code_size - 1] = OP_HALT;

    char *output = disasm_raw_code(code, code_size);
    ASSERT(output != NULL, "Label-limit disassembly produced output");
    ASSERT(strstr(output, "L511:") != NULL, "The 512th label is emitted");
    ASSERT(strstr(output, "L512:") == NULL, "No label is emitted beyond the limit");
    ASSERT(strstr(output, "JMP 517") != NULL,
           "Targets beyond the limit remain numeric");
    ASSERT(strstr(output, "HALT") != NULL, "Disassembly completes after label overflow");

    free(output);
    free(code);
}


static void test_disasm_call_extern_import_annotation(void) {
    /* CALL_EXTERN's operand is an import table index, not a function index.
     * The disassembler must annotate it with the imported module/function. */
    NvmModule *mod = nvm_module_new();
    nvm_add_string(mod, "main", 4);
    uint32_t modn = nvm_add_string(mod, "std", 3);
    uint32_t fnn = nvm_add_string(mod, "println", 7);
    uint8_t ptypes[1] = { TAG_STRING };
    nvm_add_import(mod, modn, fnn, 1, TAG_INT, ptypes);

    NvmFunctionEntry fn = { .name_idx = 0, .arity = 0, .code_offset = 0,
                            .code_length = 0, .local_count = 0, .upvalue_count = 0,
                            .result_tag = 0, .result_count = 0 };
    nvm_add_function(mod, &fn);
    uint8_t code[] = { OP_CALL_EXTERN, 0, 0, 0, 0, OP_HALT };
    uint32_t off = nvm_append_code(mod, code, sizeof(code));
    mod->functions[0].code_offset = off;
    mod->functions[0].code_length = sizeof(code);

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "CALL_EXTERN disassembly produced output");
    ASSERT(strstr(output, "CALL_EXTERN 0") != NULL, "Shows import index");
    ASSERT(strstr(output, "; import std.println") != NULL,
           "Annotates CALL_EXTERN with imported module.function");
    /* Regression: it must not mislabel the operand as a function-table name. */
    ASSERT(strstr(output, "; main") == NULL,
           "CALL_EXTERN is not annotated as a local function");
    free(output);
    nvm_module_free(mod);
}

static void test_disasm_non_branch_i32_is_numeric(void) {
    /* MATCH_TAG has a u16 variant operand and an i32 branch operand. Only the
     * i32 branch resolves to a label; the u16 is a plain immediate. The old
     * disassembler treated every i32 as a branch target — verify the branch
     * role is honored and non-branch operands stay numeric. */
    const char *src =
        ".function test 0 1 0 void 0\n"
        "  PUSH_I64 0\n"
        "  MATCH_TAG 3 5\n"
        "  PUSH_I64 1\n"
        "target:\n"
        "  RET\n"
        ".end\n";
    /* Fragment: the branch displacement here is arbitrary and lands
     * mid-instruction, which the verifier correctly rejects. What is under test
     * is how the disassembler renders the u16 variant vs the i32 branch
     * operand, so assemble without verification. */
    AsmResult result;
    NvmModule *mod = asm_assemble_unverified(src, &result);
    ASSERT(mod != NULL, "Assembly with MATCH_TAG succeeded");

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "MATCH_TAG disassembly produced output");
    /* The u16 variant selector 3 must remain a plain number, not a label. */
    ASSERT(strstr(output, "MATCH_TAG 3 ") != NULL,
           "Variant selector stays numeric");
    /* The branch operand resolves to a reconstructed label. */
    ASSERT(strstr(output, "MATCH_TAG 3 L0") != NULL,
           "Branch operand resolves to a label");
    ASSERT(strstr(output, "cfg:match-tag-branch") != NULL,
           "MATCH_TAG gets a control-flow annotation");
    free(output);
    nvm_module_free(mod);
}

static void test_disasm_binary_string_lossless(void) {
    /* A string with embedded NUL and non-printable bytes must disassemble to
     * escapes that round-trip through the assembler without truncation. */
    NvmModule *mod = nvm_module_new();
    const char data[] = { 'a', '\0', 'b', '\r', '\n', (char)0xFF, '\t', 'z' };
    nvm_add_string(mod, data, (uint32_t)sizeof(data));

    char *output = disasm_module(mod);
    ASSERT(output != NULL, "Binary-string disassembly produced output");
    /* Bytes after the embedded NUL must not be dropped. */
    ASSERT(strstr(output, "a\\x00b\\r\\n\\xff\\tz") != NULL,
           "Binary string escaped losslessly including bytes after NUL");

    /* Round-trip: reassembling the emitted .string reproduces the bytes. */
    AsmResult result;
    NvmModule *mod2 = asm_assemble(output, &result);
    ASSERT(mod2 != NULL, "Reassembly of binary string succeeded");
    if (mod2) {
        ASSERT_EQ_INT(nvm_get_string_len(mod2, 0), (uint32_t)sizeof(data),
                      "Reassembled string preserves full byte length");
        const char *s2 = nvm_get_string(mod2, 0);
        ASSERT(s2 != NULL && memcmp(s2, data, sizeof(data)) == 0,
               "Reassembled bytes match the original");
        nvm_module_free(mod2);
    }
    free(output);
    nvm_module_free(mod);
}

/* ========================================================================
 * Round-Trip Test
 * ======================================================================== */

static void test_roundtrip_assemble_serialize_deserialize_disassemble(void) {
    const char *src =
        ".string \"Hello, NanoISA!\"\n"
        ".entry 0\n"
        ".function main 0 2 0 void 0\n"
        "  PUSH_I64 42\n"
        "  STORE_LOCAL 0\n"
        "  PUSH_STR 0\n"
        "  PRINT\n"
        "  LOAD_LOCAL 0\n"
        "  PRINT\n"
        "  HALT\n"
        ".end\n";

    /* Step 1: Assemble */
    AsmResult result;
    NvmModule *mod1 = asm_assemble(src, &result);
    ASSERT(mod1 != NULL, "Round-trip: assembly succeeded");
    ASSERT_EQ_INT(result.error, ASM_OK, "No assembly error");

    /* Step 2: Serialize to binary */
    uint32_t bin_size;
    uint8_t *bin = nvm_serialize(mod1, &bin_size);
    ASSERT(bin != NULL, "Round-trip: serialization succeeded");

    /* Step 3: Deserialize from binary */
    NvmModule *mod2 = nvm_deserialize(bin, bin_size);
    ASSERT(mod2 != NULL, "Round-trip: deserialization succeeded");

    /* Step 4: Verify structural equality */
    ASSERT_EQ_INT(mod2->string_count, mod1->string_count, "String count matches");
    ASSERT_EQ_INT(mod2->function_count, mod1->function_count, "Function count matches");
    ASSERT_EQ_INT(mod2->code_size, mod1->code_size, "Code size matches");

    for (uint32_t i = 0; i < mod1->string_count; i++) {
        ASSERT_EQ_STR(nvm_get_string(mod2, i), nvm_get_string(mod1, i),
                       "String content matches");
    }

    ASSERT(memcmp(mod2->code, mod1->code, mod1->code_size) == 0,
           "Bytecode content matches");

    /* Step 5: Disassemble */
    char *disasm = disasm_module(mod2);
    ASSERT(disasm != NULL, "Round-trip: disassembly succeeded");
    ASSERT(strstr(disasm, "PUSH_I64") != NULL, "Disasm contains PUSH_I64");
    ASSERT(strstr(disasm, "PRINT") != NULL, "Disasm contains PRINT");
    ASSERT(strstr(disasm, "HALT") != NULL, "Disasm contains HALT");
    ASSERT(strstr(disasm, "Hello, NanoISA!") != NULL, "Disasm contains string");

    free(disasm);
    free(bin);
    nvm_module_free(mod1);
    nvm_module_free(mod2);
}

/* ========================================================================
 * Public NanoISA Facade Tests
 * ======================================================================== */

static void test_nanoisa_facade_roundtrip(void) {
    const char *src =
        ".entry 0\n"
        ".function main 0 1 0 void 0\n"
        "  PUSH_I64 42\n"
        "  PRINT\n"
        "  HALT\n"
        ".end\n";
    NanoisaErr err;
    NvmModule *assembled = nanoisa_assemble_text(src, &err);
    ASSERT(assembled != NULL, "Facade assembles text");
    ASSERT_EQ_INT(err.code, NANOISA_OK, "Facade clears assembly error");

    char *assembled_pretty = nanoisa_pretty_print(assembled);
    ASSERT(assembled_pretty != NULL, "Facade pretty-prints unsaved module");
    ASSERT(strstr(assembled_pretty, "[logical] code") != NULL,
           "Unsaved pretty print includes logical sections");
    free(assembled_pretty);

    uint32_t blob_size = 0;
    uint8_t *blob = nanoisa_save_bytes(assembled, &blob_size, &err);
    ASSERT(blob != NULL, "Facade saves bytes");
    ASSERT(blob_size > NVM_HEADER_SIZE, "Facade emits complete NVM bytes");

    NvmModule *loaded = nanoisa_load_bytes(blob, blob_size, &err);
    ASSERT(loaded != NULL, "Facade loads bytes");

    char *printed = nanoisa_print(loaded);
    ASSERT(printed != NULL, "Facade prints canonical assembly");
    ASSERT(strstr(printed, "PUSH_I64 42") != NULL,
           "Canonical print contains instruction");

    char *pretty = nanoisa_pretty_print(loaded);
    ASSERT(pretty != NULL, "Facade pretty-prints module");
    ASSERT(strstr(pretty, "NVM module") != NULL,
           "Pretty print contains module heading");
    ASSERT(strstr(pretty, "magic: NVM\\x01") != NULL,
           "Pretty print contains module magic");
    ASSERT(strstr(pretty, "Sections") != NULL,
           "Pretty print contains section table");
    ASSERT(strstr(pretty, "Functions") != NULL,
           "Pretty print contains function table");
    ASSERT(strstr(pretty, "[0000|0000] PUSH_I64 42") != NULL,
           "Pretty print contains instruction offsets");

    free(pretty);
    free(printed);
    nvm_module_free(loaded);
    free(blob);
    nvm_module_free(assembled);
}

static void test_nanoisa_print_is_assemblable(void) {
    const char *src =
        ".flag needs_extern\n"
        ".flag debug_info\n"
        ".entry 0\n"
        ".function main 0 1 0 void 0\n"
        "  PUSH_I64 1\n"
        "  JMP done\n"
        "  PUSH_I64 0\n"
        "done:\n"
        "  HALT\n"
        ".end\n";
    NanoisaErr err;
    NvmModule *mod = nanoisa_assemble_text(src, &err);
    ASSERT(mod != NULL, "flagged fixture assembles");

    char *printed = nanoisa_print(mod);
    ASSERT(printed != NULL, "canonical print produced text");
    ASSERT(strstr(printed, "[0000|") == NULL,
           "canonical print has no offset prefixes");
    ASSERT(strstr(printed, "; cfg:") == NULL,
           "canonical print has no cfg notes");
    ASSERT(strstr(printed, ".flag needs_extern") != NULL,
           "canonical print emits needs_extern");
    ASSERT(strstr(printed, ".flag debug_info") != NULL,
           "canonical print emits debug_info");

    NvmModule *reassembled = nanoisa_assemble_text(printed, &err);
    ASSERT(reassembled != NULL, "canonical print reassembles");
    ASSERT_EQ_INT(err.code, NANOISA_OK, "reassembly clears error");

    char *printed_again = nanoisa_print(reassembled);
    ASSERT(printed_again != NULL, "second canonical print produced text");
    ASSERT_EQ_STR(printed, printed_again, "canonical print is a text fixed point");

    free(printed_again);
    nvm_module_free(reassembled);
    free(printed);
    nvm_module_free(mod);
}

static void test_nanoisa_facade_file_roundtrip(void) {
    const char *path = "/tmp/nanolang_nanoisa_facade_test.nvm";
    const char *src =
        ".function helper 0 0 0 void 0\n"
        "  RET\n"
        ".end\n";
    NanoisaErr err;
    NvmModule *assembled = nanoisa_assemble_text(src, &err);
    ASSERT(assembled != NULL, "Facade file test assembles");
    ASSERT_EQ_INT(nanoisa_save_file(assembled, path, &err), NANOISA_OK,
                  "Facade saves NVM file");

    NvmModule *loaded = nanoisa_load_file(path, &err);
    ASSERT(loaded != NULL, "Facade loads NVM file");
    ASSERT_EQ_INT(loaded->function_count, 1, "Loaded file has function");
    ASSERT_EQ_STR(nvm_get_string(loaded, loaded->functions[0].name_idx),
                  "helper", "Loaded function name matches");

    remove(path);
    nvm_module_free(loaded);
    nvm_module_free(assembled);
}

static void test_nanoisa_facade_reports_invalid_bytes(void) {
    const uint8_t invalid[] = { 'N', 'V', 'M' };
    NanoisaErr err;
    NvmModule *mod = nanoisa_load_bytes(invalid, sizeof(invalid), &err);
    ASSERT(mod == NULL, "Facade rejects truncated NVM bytes");
    ASSERT(err.code != NANOISA_OK, "Facade reports an error code");
    ASSERT(err.message[0] != '\0', "Facade reports an error message");

    uint8_t bad_magic[NVM_HEADER_SIZE] = {0};
    mod = nanoisa_load_bytes(bad_magic, sizeof(bad_magic), &err);
    ASSERT(mod == NULL, "Facade rejects invalid NVM magic");
    ASSERT(strstr(err.message, "magic") != NULL,
           "Facade identifies invalid magic");

    const char *src =
        ".function checksum 0 0 0 void 0\n"
        "  RET\n"
        ".end\n";
    NvmModule *assembled = nanoisa_assemble_text(src, &err);
    ASSERT(assembled != NULL, "Checksum test assembles");
    uint32_t size = 0;
    uint8_t *blob = nanoisa_save_bytes(assembled, &size, &err);
    ASSERT(blob != NULL, "Checksum test serializes");
    blob[size - 1] ^= 0xff;

    mod = nanoisa_load_bytes(blob, size, &err);
    ASSERT(mod == NULL, "Facade rejects invalid NVM checksum");
    ASSERT(strstr(err.message, "checksum") != NULL,
           "Facade identifies invalid checksum");

    free(blob);
    nvm_module_free(assembled);
}

/* ========================================================================
 * Main
 * ======================================================================== */

static void test_nanoisa_atomic_text_publication(void) {
    char directory[] = "/tmp/nanoisa-atomic-XXXXXX";
    ASSERT(mkdtemp(directory) != NULL, "I create isolated publication storage");
    char path[256];
    snprintf(path, sizeof(path), "%s/output.nvm", directory);
    FILE *file = fopen(path, "wb");
    ASSERT(file != NULL, "I create the previous output");
    ASSERT(fwrite("previous", 1, 8, file) == 8, "I seed the previous bytes");
    ASSERT(fclose(file) == 0, "I close the previous output");
    ASSERT(nl_nanoisa_assemble_text_save("not assembly", path) != NANOISA_OK,
           "I reject malformed assembly");
    ASSERT(nl_nanoisa_assemble_text_save(
        ".entry main\n.function main 0 0 0 int 1\nPOP\nRET\n.end\n", path) != NANOISA_OK,
        "I reject unverified stack use");
    file = fopen(path, "rb");
    ASSERT(file != NULL, "I retain the previous output");
    char prior[9] = {0};
    ASSERT(fread(prior, 1, 8, file) == 8, "I retain the previous length");
    fclose(file);
    ASSERT_EQ_STR(prior, "previous", "I preserve previous bytes on rejection");
    const char *source = ".entry main\n.function main 0 0 0 int 1\nPUSH_I64 0\nRET\n.end\n";
    ASSERT_EQ_INT(nl_nanoisa_assemble_text_save(source, path), NANOISA_OK,
                  "I publish a verified module");
    NanoisaErr err;
    NvmModule *module = nanoisa_load_file(path, &err);
    ASSERT(module != NULL, "I reload the published v2 module");
    nvm_module_free(module);
    char blocked[256];
    snprintf(blocked, sizeof(blocked), "%s/blocked", directory);
    ASSERT(mkdir(blocked, 0700) == 0, "I create a blocked output directory");
    ASSERT_EQ_INT(nl_nanoisa_assemble_text_save(source, blocked), NANOISA_ERR_IO,
                  "I report failed publication over a directory");
    DIR *dir = opendir(directory);
    ASSERT(dir != NULL, "I inspect staging cleanup");
    struct dirent *entry;
    int staged = 0;
    while ((entry = readdir(dir)) != NULL) {
        if (strstr(entry->d_name, ".tmp.")) ++staged;
    }
    closedir(dir);
    ASSERT_EQ_INT(staged, 0, "I remove every failed staging file");
    unlink(path);
    rmdir(blocked);
    rmdir(directory);
}

int main(void) {
    printf("=== NanoISA Test Suite ===\n\n");

    printf("[ISA]\n");
    RUN_TEST(test_tag_names);
    RUN_TEST(test_instruction_info);
    RUN_TEST(test_opcode_by_name);
    RUN_TEST(test_extended_opcode_space);
    RUN_TEST(test_encode_decode_no_operands);
    RUN_TEST(test_encode_decode_i64);
    RUN_TEST(test_encode_decode_i64_large);
    RUN_TEST(test_encode_decode_f64);
    RUN_TEST(test_encode_decode_u8);
    RUN_TEST(test_encode_decode_u16);
    RUN_TEST(test_encode_decode_u32);
    RUN_TEST(test_encode_decode_i32);
    RUN_TEST(test_encode_decode_multi_operand);
    RUN_TEST(test_decode_truncated);
    RUN_TEST(test_decode_invalid_opcode);
    RUN_TEST(test_every_opcode_tooling_roundtrip);

    printf("\n[NVM Format]\n");
    RUN_TEST(test_crc32);
    RUN_TEST(test_module_new_free);
    RUN_TEST(test_string_pool);
    RUN_TEST(test_function_table);
    RUN_TEST(test_code_append);
    RUN_TEST(test_serialize_deserialize);
    RUN_TEST(test_strip_debug_info);
    RUN_TEST(test_validate_header);
    RUN_TEST(test_corrupt_checksum);
    RUN_TEST(test_module_raw_valid_baseline);
    RUN_TEST(test_module_reject_duplicate_singleton);
    RUN_TEST(test_module_reject_overlap);
    RUN_TEST(test_module_reject_contained_overlap);
    RUN_TEST(test_module_accept_reverse_order_adjacent_sections);
    RUN_TEST(test_module_reject_partial_record);
    RUN_TEST(test_module_reject_trailing_data);
    RUN_TEST(test_module_reject_interior_gap);
    RUN_TEST(test_module_reject_section_into_directory);
    RUN_TEST(test_module_reject_section_out_of_range);
    RUN_TEST(test_module_reject_wrapped_section_range);
    RUN_TEST(test_module_reject_partial_debug_record);
    RUN_TEST(test_module_valid_multisection_roundtrip);

    printf("\n[Assembler]\n");
    RUN_TEST(test_asm_simple_program);
    RUN_TEST(test_asm_labels_and_jumps);
    RUN_TEST(test_asm_all_operand_types);
    RUN_TEST(test_asm_error_unknown_opcode);
    RUN_TEST(test_asm_error_undefined_label);
    RUN_TEST(test_asm_error_missing_end);
    RUN_TEST(test_asm_error_instruction_outside_function);
    RUN_TEST(test_asm_error_bad_u8_operand);
    RUN_TEST(test_asm_error_bad_u32_operand);
    RUN_TEST(test_asm_error_bad_i64_operand);
    RUN_TEST(test_asm_error_bad_f64_operand);
    RUN_TEST(test_asm_error_bad_u16_operand);
    RUN_TEST(test_asm_error_trailing_instruction_operand);
    RUN_TEST(test_asm_error_trailing_directive_operand);
    RUN_TEST(test_asm_rejects_unverified_module);
    RUN_TEST(test_asm_comments_and_whitespace);
    RUN_TEST(test_asm_trailing_backslash_rejected);
    RUN_TEST(test_asm_string_escapes);
    RUN_TEST(test_asm_multiple_functions);
    RUN_TEST(test_asm_symbolic_operands);
    RUN_TEST(test_asm_error_undefined_symbol);

    printf("\n[Disassembler]\n");
    RUN_TEST(test_disasm_basic);
    RUN_TEST(test_disasm_labels);
    RUN_TEST(test_disasm_source_annotations_and_cfg);
    RUN_TEST(test_disasm_malformed_bytecode);
    RUN_TEST(test_disasm_rejects_wrapped_function_range);
    RUN_TEST(test_disasm_label_deduplication);
    RUN_TEST(test_disasm_label_limit_degrades_gracefully);
    RUN_TEST(test_disasm_call_extern_import_annotation);
    RUN_TEST(test_disasm_non_branch_i32_is_numeric);
    RUN_TEST(test_disasm_binary_string_lossless);

    printf("\n[Round-Trip]\n");
    RUN_TEST(test_roundtrip_assemble_serialize_deserialize_disassemble);

    printf("\n[Public Facade]\n");
    RUN_TEST(test_nanoisa_atomic_text_publication);
    RUN_TEST(test_nanoisa_facade_roundtrip);
    RUN_TEST(test_nanoisa_print_is_assemblable);
    RUN_TEST(test_nanoisa_facade_file_roundtrip);
    RUN_TEST(test_nanoisa_facade_reports_invalid_bytes);

    printf("\n=== Results: %d passed, %d failed, %d total ===\n",
           tests_passed, tests_failed, tests_run);

    return tests_failed > 0 ? 1 : 0;
}
