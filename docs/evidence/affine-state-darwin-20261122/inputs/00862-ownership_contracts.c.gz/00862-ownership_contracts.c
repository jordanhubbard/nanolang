#include "ownership_contracts.h"
#include "retained_layouts.h"
#include "reference_places.h"
#include "isa.h"
#include "ownership_map_declarations.h"
#include "record_map_structure_private.h"
#include "record_map_cost_private.h"
#include <stdlib.h>
#include <string.h>

static bool scalar(uint8_t tag) {
    return tag == TAG_INT || tag == TAG_U8 || tag == TAG_FLOAT || tag == TAG_BOOL;
}

static bool ownership_version(uint32_t version) {
    return version == NVM_OWNERSHIP_VERSION ||
           version == NVM_OWNERSHIP_PATH_VERSION ||
           version == NVM_OWNERSHIP_EXTENSION_VERSION;
}

static NvmV2Result check_layouts(const NvmV2Layouts *layouts, const uint8_t *flags,
                                bool *needs, bool array_fields, bool union_fields, bool map_fields) {
    bool resource_table = false;
    for (uint32_t i = 0; i < layouts->count; i++)
        if (flags[i] & NVM_LAYOUT_RESOURCE) resource_table = true;
    /* I preserve the old codec precondition for every resource-bearing table,
     * including edges in disconnected UNKNOWN declarations. */
    if (resource_table) for (uint32_t i = 0; i < layouts->count; i++)
        for (uint16_t j = 0; j < layouts->items[i].field_count; j++) {
            uint32_t child = layouts->items[i].fields[j].nested_idx;
            if (child != NVM_V2_NO_INDEX && child >= i) return NVM_V2_ERR_SECTION_TYPE;
        }
    for (uint32_t i = 0; i < layouts->count; i++) {
        unsigned flag = flags[i];
        if (flag & ~(NVM_LAYOUT_COMPLETE | NVM_LAYOUT_RESOURCE))
            return NVM_V2_ERR_RESERVED_FLAGS;
        if ((flag & NVM_LAYOUT_RESOURCE) && !(flag & NVM_LAYOUT_COMPLETE))
            return NVM_V2_ERR_SECTION_TYPE;
        if (!(flag & NVM_LAYOUT_COMPLETE)) continue;
        const NvmV2Layout *layout = &layouts->items[i];
        if (layout->kind != NVM_V2_LAYOUT_STRUCT &&
            !(union_fields && layout->kind == NVM_V2_LAYOUT_UNION))
            return NVM_V2_ERR_SECTION_TYPE;
        for (uint16_t j = 0; j < layout->field_count; j++) {
            const NvmV2LayoutField *field = &layout->fields[j];
            if (scalar(field->type_tag) || field->type_tag == TAG_STRING) {
                if (field->nested_idx != NVM_V2_NO_INDEX) return NVM_V2_ERR_SECTION_TYPE;
            } else if (array_fields && field->type_tag == TAG_ARRAY && !(flag & NVM_LAYOUT_RESOURCE)) {
                if (field->nested_idx != NVM_V2_NO_INDEX) return NVM_V2_ERR_SECTION_TYPE;
            } else if (map_fields && field->type_tag == TAG_HASHMAP &&
                       layout->kind == NVM_V2_LAYOUT_STRUCT && flag == NVM_LAYOUT_COMPLETE) {
                if (field->nested_idx != NVM_V2_NO_INDEX) return NVM_V2_ERR_SECTION_TYPE;
            } else if ((field->type_tag == TAG_STRUCT ||
                        (union_fields && field->type_tag == TAG_UNION)) &&
                       field->nested_idx < layouts->count &&
                       (!resource_table || field->nested_idx < i)) {
                uint16_t kind = field->type_tag == TAG_STRUCT ?
                    NVM_V2_LAYOUT_STRUCT : NVM_V2_LAYOUT_UNION;
                if (layouts->items[field->nested_idx].kind != kind)
                    return NVM_V2_ERR_SECTION_TYPE;
                unsigned nested = flags[field->nested_idx];
                if (!(nested & NVM_LAYOUT_COMPLETE)) return NVM_V2_ERR_SECTION_TYPE;
                if ((nested & NVM_LAYOUT_RESOURCE) && !(flag & NVM_LAYOUT_RESOURCE))
                    return NVM_V2_ERR_SECTION_TYPE;
            } else return NVM_V2_ERR_SECTION_TYPE;
        }
        /* STRING leaves retain value roots; executable and borrowed profiles
         * independently constrain these complete resource declarations. */
        if (flag & NVM_LAYOUT_RESOURCE) *needs = true;
    }
    return NVM_V2_OK;
}

/* I defer element references until the complete suffix has been checked. */
typedef struct { uint32_t required; bool untyped; } EffectArrayReferences;
static NvmV2Result descriptor(NvmV2Cursor *cursor, const NvmV2Layouts *layouts,
                               const uint8_t *flags, uint32_t version, bool parameter,
                               int signature_tag, bool *needs, bool *ambiguous,
                               EffectArrayReferences *arrays) {
    uint8_t tag, mode;
    uint16_t reserved;
    uint32_t layout;
    NvmV2Result result;
    if ((result = nvm_v2_u8(cursor, &tag)) != NVM_V2_OK ||
        (result = nvm_v2_u8(cursor, &mode)) != NVM_V2_OK ||
        (result = nvm_v2_u16(cursor, &reserved)) != NVM_V2_OK ||
        (result = nvm_v2_u32(cursor, &layout)) != NVM_V2_OK) return result;
    if (reserved) return NVM_V2_ERR_RESERVED_FLAGS;
    if (tag >= TAG_COUNT || mode > NVM_REFERENCE_EXCLUSIVE ||
        (!parameter && mode) || (signature_tag >= 0 && tag != signature_tag))
        return NVM_V2_ERR_SECTION_TYPE;
    if (tag==TAG_ARRAY && arrays) {
        if (layout==NVM_V2_NO_INDEX) arrays->untyped=true;
        else {
            if (version!=NVM_OWNERSHIP_EXTENSION_VERSION || mode)
                return NVM_V2_ERR_SECTION_TYPE;
            /* NO_INDEX was excluded, so this increment cannot wrap. */
            if (arrays->required<layout+1) arrays->required=layout+1;
            *needs=true;return NVM_V2_OK;
        }
    }
    if (layout != NVM_V2_NO_INDEX) {
        if (layout >= layouts->count) return NVM_V2_ERR_INDEX_RANGE;
        bool record=tag==TAG_STRUCT && (flags[layout]&NVM_LAYOUT_COMPLETE) &&
                    layouts->items[layout].kind==NVM_V2_LAYOUT_STRUCT;
        bool union_value=version==NVM_OWNERSHIP_EXTENSION_VERSION && tag==TAG_UNION &&
                         (!flags[layout] || (flags[layout]&NVM_LAYOUT_COMPLETE)) &&
                         layouts->items[layout].kind==NVM_V2_LAYOUT_UNION;
        if (!record && !union_value)
            return NVM_V2_ERR_SECTION_TYPE;
        if (union_value) *needs=true;
    }
    if (mode) {
        if (layout == NVM_V2_NO_INDEX || !(flags[layout] & NVM_LAYOUT_RESOURCE))
            return NVM_V2_ERR_SECTION_TYPE;
        NvmReferencePlace place = {1, 0, layout, NULL, 0, layout, (NvmReferenceMode)mode};
        if (!nvm_reference_place_valid(layouts, layout, &place)) {
            if (ambiguous) *ambiguous=true;
            return NVM_V2_ERR_SECTION_TYPE;
        }
        *needs = true;
    }
    return NVM_V2_OK;
}

/* I share exact path-table transport validation with runtime lookup. */
static NvmV2Result paths_read(NvmV2Cursor *cursor,uint32_t wanted,
                               uint16_t *fields,uint16_t capacity,uint16_t *length,
                               bool terminal) {
    uint32_t count;NvmV2Result result;
    uint16_t selected[NVM_OWNERSHIP_MAX_PATH_DEPTH],selected_count=0;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (count>NVM_OWNERSHIP_MAX_PATHS) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint16_t n,reserved;
        if ((result=nvm_v2_u16(cursor,&n))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&reserved))!=NVM_V2_OK) return result;
        if (reserved) return NVM_V2_ERR_RESERVED_FLAGS;
        if (!n || n>NVM_OWNERSHIP_MAX_PATH_DEPTH) return NVM_V2_ERR_INDEX_RANGE;
        for (uint16_t j=0;j<n;j++) {
            uint16_t field;
            if ((result=nvm_v2_u16(cursor,&field))!=NVM_V2_OK) return result;
            if (i==wanted) selected[j]=field;
        }
        if (i==wanted) selected_count=n;
        if ((result=nvm_v2_align4(cursor))!=NVM_V2_OK) return result;
    }
    if (terminal && cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (wanted!=NVM_V2_NO_INDEX) {
        if (!selected_count || selected_count>capacity || !fields || !length)
            return NVM_V2_ERR_INDEX_RANGE;
        for (uint16_t i=0;i<selected_count;i++) fields[i]=selected[i];
        *length=selected_count;
    }
    return NVM_V2_OK;
}

typedef struct {
    const uint8_t *data;
    uint32_t size;
    uint16_t revision;
} NvmOwnershipExtensionView;

typedef struct {
    NvmOwnershipExtensionView union_variants;
    NvmOwnershipExtensionView array_fields;
    NvmOwnershipExtensionView globals;
    NvmOwnershipExtensionView effects;
} NvmOwnershipExtensions;

/* I frame all version-3 extensions before a feature query may inspect one.
 * Kinds are mandatory-understanding, ordered and unique. */
static NvmV2Result extensions_read_map(NvmV2Cursor *cursor,NvmOwnershipExtensions *out,
                                         NvmOwnershipExtensionView *map) {
    uint32_t count;NvmV2Result result;
    NvmOwnershipExtensions found={0};uint16_t prior=0;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (!count || count>NVM_OWNERSHIP_MAX_EXTENSIONS) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint16_t kind,revision;uint32_t bytes;const uint8_t *payload;
        if ((result=nvm_v2_u16(cursor,&kind))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&revision))!=NVM_V2_OK ||
            (result=nvm_v2_u32(cursor,&bytes))!=NVM_V2_OK ||
            (result=nvm_v2_take(cursor,bytes,&payload))!=NVM_V2_OK ||
            (result=nvm_v2_align4(cursor))!=NVM_V2_OK) return result;
        if (!kind || kind<=prior) return NVM_V2_ERR_SECTION_TYPE;
        if (revision!=NVM_OWNERSHIP_EXTENSION_REVISION_1 &&
            !(kind==NVM_OWNERSHIP_EXTENSION_EFFECTS && (revision==NVM_OWNERSHIP_EFFECT_ARRAY_REVISION ||
              revision==NVM_OWNERSHIP_EFFECT_CONSTRUCTOR_REVISION)))
            return NVM_V2_ERR_FORMAT_VERSION;
        NvmOwnershipExtensionView view={payload,bytes,revision};
        if (kind==NVM_OWNERSHIP_EXTENSION_UNION_VARIANTS)
            found.union_variants=view;
        else if (kind==NVM_OWNERSHIP_EXTENSION_ARRAY_FIELDS)
            found.array_fields=view;
        else if (kind==NVM_OWNERSHIP_EXTENSION_GLOBALS)
            found.globals=view;
        else if (kind==NVM_OWNERSHIP_EXTENSION_EFFECTS)
            found.effects=view;
        else if (kind==NVM_OWNERSHIP_EXTENSION_MAP_FIELDS && map)
            *map=view;
        else return NVM_V2_ERR_FORMAT_VERSION;
        prior=kind;
    }
    if (cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (out) *out=found;
    return NVM_V2_OK;
}

/* Version 3 bounds the byte-identical version-2 path suffix before its shared
 * extension records. The path subcursor, not the outer payload, is terminal. */
static NvmV2Result extension_suffix_read_map(NvmV2Cursor *cursor,uint32_t wanted,
                                         uint16_t *fields,uint16_t capacity,
                                         uint16_t *length,NvmOwnershipExtensions *extensions,
                                         NvmOwnershipExtensionView *map) {
    uint32_t bytes;const uint8_t *data;NvmV2Result result;
    if ((result=nvm_v2_u32(cursor,&bytes))!=NVM_V2_OK) return result;
    if (bytes<4 || bytes%4) return NVM_V2_ERR_SECTION_RANGE;
    if ((result=nvm_v2_take(cursor,bytes,&data))!=NVM_V2_OK) return result;
    NvmV2Cursor paths;nvm_v2_cursor_init(&paths,data,bytes);
    if ((result=paths_read(&paths,wanted,fields,capacity,length,true))!=NVM_V2_OK)
        return result;
    return extensions_read_map(cursor,extensions,map);
}

static NvmV2Result extension_suffix_read(NvmV2Cursor *cursor,uint32_t wanted,
        uint16_t *fields,uint16_t capacity,uint16_t *length,NvmOwnershipExtensions *extensions) {
    return extension_suffix_read_map(cursor,wanted,fields,capacity,length,extensions,NULL);
}

NvmV2Result nvm_ownership_path(const NvmModule *module,uint32_t index,
                               uint16_t *fields,uint16_t capacity,uint16_t *count) {
    if (!module || !module->ownership_data || index==NVM_V2_NO_INDEX)
        return NVM_V2_ERR_INDEX_RANGE;
    bool needs=false;NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,layouts,functions;const uint8_t *ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=NVM_OWNERSHIP_PATH_VERSION && version!=NVM_OWNERSHIP_EXTENSION_VERSION)
        return NVM_V2_ERR_FORMAT_VERSION;
    if ((result=nvm_v2_u32(&cursor,&layouts))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,layouts,&ignored))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&functions))!=NVM_V2_OK) return result;
    if (functions!=module->function_count) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<functions;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK) return result;
        if (params>locals) return NVM_V2_ERR_INDEX_RANGE;
        if ((result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK) return result;
    }
    uint16_t selected[NVM_OWNERSHIP_MAX_PATH_DEPTH],selected_count=0;
    if (version==NVM_OWNERSHIP_PATH_VERSION)
        result=paths_read(&cursor,index,selected,NVM_OWNERSHIP_MAX_PATH_DEPTH,
                          &selected_count,true);
    else
        result=extension_suffix_read(&cursor,index,selected,NVM_OWNERSHIP_MAX_PATH_DEPTH,
                                     &selected_count,NULL);
    if (result!=NVM_V2_OK) return result;
    if (!fields || !count || selected_count>capacity) return NVM_V2_ERR_INDEX_RANGE;
    for (uint16_t i=0;i<selected_count;i++) fields[i]=selected[i];
    *count=selected_count;
    return NVM_V2_OK;
}

/* I collect only checked numeric facts during one complete declaration read. */
typedef struct {
    NvmOwnershipExtensionView view;
    NvmUnionVariantFact *rows;
    uint32_t capacity, count;
    uint32_t *starts;
    uint16_t *variants;
    bool ambiguous;
} OwnershipProjection;
static NvmV2Result union_facts_read(NvmV2Cursor *cursor,const NvmModule *module,
                                    const NvmV2Layouts *layouts,const uint8_t *flags,
                                    uint32_t wanted_union,uint16_t wanted_variant,
                                    NvmUnionVariantFact *selected, OwnershipProjection *projection) {
    uint32_t count;NvmV2Result result;
    NvmUnionVariantFact found={0};bool have=false;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (count!=module->union_count || count>NVM_OWNERSHIP_MAX_UNIONS)
        return NVM_V2_ERR_INDEX_RANGE;
    uint32_t ordinal=0, copied=0;
    for (uint32_t i=0;i<count;i++) {
        uint32_t layout;uint16_t variants,reserved;
        if ((result=nvm_v2_u32(cursor,&layout))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&variants))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&reserved))!=NVM_V2_OK) return result;
        while (ordinal<layouts->count && layouts->items[ordinal].kind!=NVM_V2_LAYOUT_UNION)
            ordinal++;
        if (reserved || !variants || variants>NVM_OWNERSHIP_MAX_VARIANTS ||
            ordinal>=layouts->count || layout!=ordinal ||
            layouts->items[layout].kind!=NVM_V2_LAYOUT_UNION ||
            layouts->items[layout].name_idx==NVM_V2_NO_INDEX)
            return NVM_V2_ERR_SECTION_TYPE;
        const NvmV2Layout *shape=&layouts->items[layout];
        if (projection && projection->rows) {
            if (copied>projection->capacity || variants>projection->capacity-copied)
                return NVM_V2_ERR_INDEX_RANGE;
            projection->starts[i]=copied;
            projection->variants[i]=variants;
        }
        size_t variants_at=cursor->pos;
        uint32_t next=0;
        for (uint16_t v=0;v<variants;v++) {
            uint32_t name;uint16_t offset,fields;
            if ((result=nvm_v2_u32(cursor,&name))!=NVM_V2_OK ||
                (result=nvm_v2_u16(cursor,&offset))!=NVM_V2_OK ||
                (result=nvm_v2_u16(cursor,&fields))!=NVM_V2_OK) return result;
            if (name>=module->string_count || offset!=next ||
                fields>shape->field_count-offset)
                return NVM_V2_ERR_INDEX_RANGE;
            for (uint16_t prior=0;prior<v;prior++) {
                size_t prior_at=variants_at+(size_t)prior*8;
                if (prior_at>cursor->size || cursor->size-prior_at<4)
                    return NVM_V2_ERR_SECTION_RANGE;
                uint32_t prior_name=(uint32_t)cursor->base[prior_at] |
                    ((uint32_t)cursor->base[prior_at+1]<<8) |
                    ((uint32_t)cursor->base[prior_at+2]<<16) |
                    ((uint32_t)cursor->base[prior_at+3]<<24);
                if (prior_name==name) return NVM_V2_ERR_SECTION_TYPE;
            }
            for (uint16_t f=0;f<fields;f++) {
                const NvmV2LayoutField *field=&shape->fields[offset+f];
                bool leaf=(scalar(field->type_tag) || field->type_tag==TAG_STRING) &&
                          field->nested_idx==NVM_V2_NO_INDEX;
                bool nested=(flags[layout]&NVM_LAYOUT_COMPLETE) &&
                            field->nested_idx<layout &&
                            (flags[field->nested_idx]&NVM_LAYOUT_COMPLETE) &&
                            ((field->type_tag==TAG_STRUCT &&
                              layouts->items[field->nested_idx].kind==NVM_V2_LAYOUT_STRUCT) ||
                             (field->type_tag==TAG_UNION &&
                              layouts->items[field->nested_idx].kind==NVM_V2_LAYOUT_UNION));
                if ((!leaf && !nested) || field->name_idx==NVM_V2_NO_INDEX)
                    return NVM_V2_ERR_SECTION_TYPE;
            }
            if (projection && projection->rows)
                projection->rows[copied]=(NvmUnionVariantFact){layout,name,offset,fields};
            copied++;
            if (i==wanted_union && v==wanted_variant) {
                found=(NvmUnionVariantFact){layout,name,offset,fields};have=true;
            }
            next=(uint32_t)offset+fields;
        }
        if (next!=shape->field_count) return NVM_V2_ERR_INDEX_RANGE;
        ordinal++;
    }
    while (ordinal<layouts->count) {
        if (layouts->items[ordinal].kind==NVM_V2_LAYOUT_UNION)
            return NVM_V2_ERR_INDEX_RANGE;
        ordinal++;
    }
    if (cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (wanted_union!=NVM_V2_NO_INDEX && !have) return NVM_V2_ERR_INDEX_RANGE;
    if (have && selected) *selected=found;
    if (projection) projection->count=copied;
    return NVM_V2_OK;
}

/* GLOBALS revision 1: u32 count followed by dense eight-byte slots:
 * u8 tag, u8 mutable (0/1), u16 reserved (0), u32 exact layout or NO_INDEX.
 * These declarations deliberately carry no assumed initial value. */
static NvmV2Result globals_read(NvmOwnershipExtensionView view,
        const NvmV2Layouts *layouts,const uint8_t *flags) {
    NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,view.data,view.size);
    uint32_t count;NvmV2Result result;
    if ((result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) return result;
    if (!count || count>NVM_OWNERSHIP_MAX_GLOBALS) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint8_t tag,mutable;uint16_t reserved;uint32_t layout;
        if ((result=nvm_v2_u8(&cursor,&tag))!=NVM_V2_OK ||
            (result=nvm_v2_u8(&cursor,&mutable))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&reserved))!=NVM_V2_OK ||
            (result=nvm_v2_u32(&cursor,&layout))!=NVM_V2_OK) return result;
        if (reserved || mutable>1) return NVM_V2_ERR_RESERVED_FLAGS;
        if (scalar(tag) || tag==TAG_STRING) {
            if (layout!=NVM_V2_NO_INDEX) return NVM_V2_ERR_SECTION_TYPE;
        } else if (tag==TAG_STRUCT || tag==TAG_UNION) {
            if (layout>=layouts->count) return NVM_V2_ERR_INDEX_RANGE;
            uint16_t kind=tag==TAG_STRUCT?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION;
            if (layouts->items[layout].kind!=kind || !(flags[layout]&NVM_LAYOUT_COMPLETE))
                return NVM_V2_ERR_SECTION_TYPE;
        } else return NVM_V2_ERR_SECTION_TYPE;
    }
    return cursor.pos==cursor.size?NVM_V2_OK:NVM_V2_ERR_SECTION_RANGE;
}

#include "ownership_effects.inc"
#include "ownership_array_fields.inc"
#include "ownership_map_fields.inc"
static NvmV2Result ownership_validate_owned(const NvmModule *module,
        const NvmV2Layouts *layouts,bool *requires_verifier,
        NvmOrdinaryArrayAuthority *private_plan, OwnershipProjection *projection,
        NvmMapDeclarationPlan *map) {
    NvmV2Result result;
    bool ambiguous=false;
    EffectArrayReferences arrays={0};uint32_t effect_type_count=0;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
    uint32_t version, count;
    const uint8_t *flags;
    bool needs = false;
    if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
        (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK) goto done;
    if (!ownership_version(version)) { result = NVM_V2_ERR_FORMAT_VERSION; goto done; }
    if (count != layouts->count) { result = NVM_V2_ERR_INDEX_RANGE; goto done; }
    if ((result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK ||
        (result = nvm_v2_align4(&cursor)) != NVM_V2_OK ||
        (result = check_layouts(layouts, flags, &needs, private_plan!=NULL,
                                version==NVM_OWNERSHIP_EXTENSION_VERSION && !private_plan,map!=NULL)) != NVM_V2_OK ||
        (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK) goto done;
    if (private_plan) for (uint32_t i=0;i<layouts->count;i++) private_plan->flags[i]=flags[i];
    if (count != module->function_count || (count && !module->functions)) {
        result = NVM_V2_ERR_INDEX_RANGE; goto done;
    }
    for (uint32_t i = 0; i < count; i++) {
        uint16_t locals, params;
        const NvmFunctionEntry *function = &module->functions[i];
        if ((result = nvm_v2_u16(&cursor, &locals)) != NVM_V2_OK ||
            (result = nvm_v2_u16(&cursor, &params)) != NVM_V2_OK) goto done;
        if (locals != function->local_count || params != function->arity || params > locals ||
            function->result_count > 1) { result = NVM_V2_ERR_INDEX_RANGE; goto done; }
        int return_tag = function->result_count ? function->result_tag : TAG_VOID;
        if(map && return_tag==TAG_HASHMAP) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
        ambiguous=false;
        result=descriptor(&cursor,layouts,flags,version,false,return_tag,&needs,private_plan?&ambiguous:NULL,private_plan?NULL:&arrays);
        if (result!=NVM_V2_OK) {
            if (!projection || !ambiguous) goto done;
            projection->ambiguous=true;result=NVM_V2_OK;
        }
        for (uint16_t local = 0; local < locals; local++) {
            int tag = -1;
            if (local < params) tag = module->function_param_types &&
                module->function_param_types[i] ? module->function_param_types[i][local] : TAG_VOID;
            if(map && local<params && tag==TAG_HASHMAP) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
            ambiguous=false;
            result=descriptor(&cursor,layouts,flags,version,local<params,tag,&needs,private_plan?&ambiguous:NULL,private_plan?NULL:&arrays);
            if (result!=NVM_V2_OK) {
                if (!projection || !ambiguous) goto done;
                projection->ambiguous=true;result=NVM_V2_OK;
            }
        }
    }
    NvmOwnershipExtensions extensions={0};NvmOwnershipExtensionView map_view={0};
    if (version==NVM_OWNERSHIP_PATH_VERSION) {
        if ((result=paths_read(&cursor,NVM_V2_NO_INDEX,NULL,0,NULL,true))!=NVM_V2_OK)
            goto done;
    } else if (version==NVM_OWNERSHIP_EXTENSION_VERSION) {
        if ((result=extension_suffix_read_map(&cursor,NVM_V2_NO_INDEX,NULL,0,NULL,
                                          &extensions,map?&map_view:NULL))!=NVM_V2_OK) goto done;
        if (!!extensions.union_variants.data != !!module->union_count) {
            result=NVM_V2_ERR_SECTION_TYPE;goto done;
        }
        if (extensions.union_variants.data) {
            NvmV2Cursor unions;nvm_v2_cursor_init(&unions,extensions.union_variants.data,
                                                  extensions.union_variants.size);
            if ((result=union_facts_read(&unions,module,layouts,flags,NVM_V2_NO_INDEX,0,NULL,projection))
                !=NVM_V2_OK) goto done;
            if (projection) projection->view=extensions.union_variants;
            needs=true;
        }
        if (extensions.globals.data) {
            /* Private array/mixed projections have no global declaration
             * contract. An unrelated extension must not confer authority. */
            if (private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            if ((result=globals_read(extensions.globals,layouts,flags))!=NVM_V2_OK) goto done;
            needs=true;
        }
        if (extensions.effects.data) {
            if (private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            NvmOwnershipEffectTypes types;
            if ((result=effects_read(extensions.effects,module,layouts,flags,
                                     NVM_V2_NO_INDEX,NULL,&types,NULL))!=NVM_V2_OK) goto done;
            effect_type_count=types.count;
            needs=true;
        }
        if (extensions.array_fields.data) {
            if (!private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            if ((result=oaa_array_fields(extensions.array_fields,private_plan))!=NVM_V2_OK) goto done;
        }
    }
    if (map && (!map_view.data || !map_payload(map,map_view,layouts,flags))) {
        result=NVM_V2_ERR_SECTION_TYPE;goto done;
    }
    if (arrays.required>effect_type_count) { result=NVM_V2_ERR_INDEX_RANGE;goto done; }
    if (effect_type_count && arrays.untyped) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
    if (cursor.pos != cursor.size) { result = NVM_V2_ERR_SECTION_RANGE; goto done; }
    *requires_verifier = needs;
done:
    if (private_plan && ambiguous && !projection) private_plan->failure=NVM_OAA_UNKNOWN;
    return result;
}

NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            bool *requires_verifier) {
    if (!module || !requires_verifier) return NVM_V2_ERR_INDEX_RANGE;
    *requires_verifier = false;
    if (!module->ownership_size)
        return module->ownership_data ? NVM_V2_ERR_SECTION_RANGE : NVM_V2_OK;
    if (!module->ownership_data || !module->layout_size ||
        !nvm_retained_layouts_valid(module)) return NVM_V2_ERR_SECTION_TYPE;
    NvmV2Layouts layouts = {0};
    NvmV2Result result = nvm_v2_layouts_decode(module->layout_data,
                                             module->layout_size, &layouts);
    if (result != NVM_V2_OK) return result;
    result=ownership_validate_owned(module,&layouts,requires_verifier,NULL,NULL,NULL);
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_globals(const NvmModule *module,NvmOwnershipGlobal *out,
                                  uint32_t capacity,uint32_t *count) {
    if (!module || !count || (!out && capacity)) return NVM_V2_ERR_INDEX_RANGE;
    bool needs=false;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    if (!module->ownership_size) { *count=0;return NVM_V2_OK; }
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,n;const uint8_t *ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=NVM_OWNERSHIP_EXTENSION_VERSION) { *count=0;return NVM_V2_OK; }
    if ((result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,n,&ignored))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK) return result;
    for (uint32_t i=0;i<n;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            return result;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,NVM_V2_NO_INDEX,NULL,0,NULL,&extensions))
        !=NVM_V2_OK) return result;
    if (!extensions.globals.data) { *count=0;return NVM_V2_OK; }
    nvm_v2_cursor_init(&cursor,extensions.globals.data,extensions.globals.size);
    if ((result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK) return result;
    if (out && capacity<n) return NVM_V2_ERR_INDEX_RANGE;
    NvmOwnershipGlobal rows[NVM_OWNERSHIP_MAX_GLOBALS];
    for (uint32_t i=0;i<n;i++) {
        uint8_t mutable;uint16_t reserved;
        if ((result=nvm_v2_u8(&cursor,&rows[i].tag))!=NVM_V2_OK ||
            (result=nvm_v2_u8(&cursor,&mutable))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&reserved))!=NVM_V2_OK ||
            (result=nvm_v2_u32(&cursor,&rows[i].layout))!=NVM_V2_OK) return result;
        rows[i].mutable=mutable!=0;
    }
    if (out) for (uint32_t i=0;i<n;i++) out[i]=rows[i];
    *count=n;return NVM_V2_OK;
}

static NvmV2Result ownership_effect_query(const NvmModule *module,uint32_t key_idx,
                                 NvmOwnershipEffect *out,NvmOwnershipEffectTypes *types,
                                 EffectConstructorQuery *constructor) {
    if (!module || (!out && !types && !constructor) || (out && key_idx>=module->string_count)) return NVM_V2_ERR_INDEX_RANGE;
    bool needs=false;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    if (!module->ownership_size) return NVM_V2_ERR_INDEX_RANGE;
    NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,count;const uint8_t *flags,*ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=NVM_OWNERSHIP_EXTENSION_VERSION) return NVM_V2_ERR_INDEX_RANGE;
    if ((result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,count,&flags))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) return result;
    for (uint32_t i=0;i<count;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            return result;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,NVM_V2_NO_INDEX,NULL,0,NULL,&extensions))!=NVM_V2_OK)
        return result;
    if (!extensions.effects.data) return NVM_V2_ERR_INDEX_RANGE;
    NvmV2Layouts layouts={0};
    result=nvm_v2_layouts_decode(module->layout_data,module->layout_size,&layouts);
    if (result!=NVM_V2_OK) return result;
    result=effects_read(extensions.effects,module,&layouts,flags,key_idx,out,types,constructor);
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_effect(const NvmModule *module,uint32_t key_idx,
                                 NvmOwnershipEffect *out) {
    return ownership_effect_query(module,key_idx,out,NULL,NULL);
}
NvmV2Result nvm_ownership_effect_types(const NvmModule *module,NvmOwnershipEffectTypes *out) {
    return ownership_effect_query(module,NVM_V2_NO_INDEX,NULL,out,NULL);
}

NvmV2Result nvm_ownership_array_constructor(const NvmModule *module,uint32_t function,
                                            uint32_t byte_offset,uint32_t *out) {
    if (!module || !out || !module->functions || function>=module->function_count ||
        byte_offset>=module->functions[function].code_length) return NVM_V2_ERR_INDEX_RANGE;
    EffectConstructorQuery query={function,byte_offset,NVM_V2_NO_INDEX};
    NvmV2Result result=ownership_effect_query(module,NVM_V2_NO_INDEX,NULL,NULL,&query);
    if (result==NVM_V2_OK) *out=query.element;
    return result;
}

NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out) {
    if (!module || !out || !module->ownership_data || !module->layout_data)
        return NVM_V2_ERR_INDEX_RANGE;
    bool needs=false;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    NvmV2Layouts layouts={0};
    result=nvm_v2_layouts_decode(module->layout_data,module->layout_size,&layouts);
    if (result!=NVM_V2_OK) return result;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,count;const uint8_t *ignored,*flags;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK ||
        version!=NVM_OWNERSHIP_EXTENSION_VERSION ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,count,&flags))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) {
        if (result==NVM_V2_OK) result=NVM_V2_ERR_FORMAT_VERSION;
        goto done_query;
    }
    for (uint32_t i=0;i<count;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            goto done_query;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,NVM_V2_NO_INDEX,NULL,0,NULL,&extensions))
        !=NVM_V2_OK) goto done_query;
    if (!extensions.union_variants.data) { result=NVM_V2_ERR_FORMAT_VERSION;goto done_query; }
    NvmV2Cursor unions;nvm_v2_cursor_init(&unions,extensions.union_variants.data,
                                          extensions.union_variants.size);
    NvmUnionVariantFact selected;
    result=union_facts_read(&unions,module,&layouts,flags,union_ordinal,variant,&selected,NULL);
    if (result==NVM_V2_OK) *out=selected;
done_query:
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_layout_authority(const NvmModule *module, uint32_t layout,
                                          NvmLayoutAuthority *out) {
    if (!module || !out || layout == NVM_V2_NO_INDEX) return NVM_V2_ERR_INDEX_RANGE;
    bool needs;
    NvmV2Result result = nvm_ownership_contracts_validate(module, &needs);
    if (result != NVM_V2_OK) return result;
    NvmLayoutAuthority authority = NVM_LAYOUT_AUTHORITY_UNKNOWN;
    if (module->ownership_size) {
        NvmV2Cursor cursor;
        uint32_t version, count;
        const uint8_t *flags;
        nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
        if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
            (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK ||
            (result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK) return result;
        if (layout >= count) return NVM_V2_ERR_INDEX_RANGE;
        if (flags[layout] & NVM_LAYOUT_COMPLETE)
            authority = flags[layout] & NVM_LAYOUT_RESOURCE ?
                NVM_LAYOUT_AUTHORITY_RESOURCE : NVM_LAYOUT_AUTHORITY_ORDINARY;
    }
    *out = authority;
    return NVM_V2_OK;
}

NvmV2Result nvm_ownership_layout_authorities(const NvmModule *module, uint32_t count,
                                            NvmLayoutAuthority *out) {
    if (!module || (count && !out)) return NVM_V2_ERR_INDEX_RANGE;
    bool needs;
    NvmV2Result result = nvm_ownership_contracts_validate(module, &needs);
    if (result != NVM_V2_OK) return result;
    const uint8_t *flags = NULL;
    if (module->ownership_size) {
        NvmV2Cursor cursor;
        uint32_t version, declared_count;
        nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
        if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
            (result = nvm_v2_u32(&cursor, &declared_count)) != NVM_V2_OK) return result;
        if (declared_count != count) return NVM_V2_ERR_INDEX_RANGE;
        if ((result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK) return result;
    }
    for (uint32_t i = 0; i < count; i++)
        out[i] = flags && (flags[i] & NVM_LAYOUT_COMPLETE) ?
            (flags[i] & NVM_LAYOUT_RESOURCE ? NVM_LAYOUT_AUTHORITY_RESOURCE :
             NVM_LAYOUT_AUTHORITY_ORDINARY) : NVM_LAYOUT_AUTHORITY_UNKNOWN;
    return NVM_V2_OK;
}

#include "ordinary_array_authority.inc"

#include "ownership_declaration_projection.inc"

#include "ownership_map_declarations.inc"
#include "record_map_route.inc"

#include "ownership_union_fields_private.inc"
