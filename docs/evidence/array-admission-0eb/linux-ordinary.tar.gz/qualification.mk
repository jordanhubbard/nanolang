.PHONY: qualification-array-refusals
qualification-array-refusals: $(NANOVIRT_OBJECTS) $(NANOVM_OBJECTS) $(NANOISA_OBJECTS) $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	$(CC) $(CFLAGS) -o tests/nanovirt/test_codegen tests/nanovirt/test_codegen.c $(NANOVIRT_OBJECTS) $(NANOVM_OBJECTS) $(NANOISA_OBJECTS) $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS)
	./tests/nanovirt/test_codegen --array-arithmetic-refusals
	rm -f tests/nanovirt/test_codegen
