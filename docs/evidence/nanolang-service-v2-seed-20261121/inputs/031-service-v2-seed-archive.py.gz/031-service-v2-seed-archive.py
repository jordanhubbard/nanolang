from pathlib import Path
import gzip,hashlib,json,subprocess
B=Path('.test_output');D=Path('docs/evidence/nanolang-service-v2-seed-20261121');(D/'inputs').mkdir(parents=True,exist_ok=True)
paths=set()
for pattern in ['service-v2-seed-*','service-v2-bootstrap*','service-build-budget*','service-link-order*','service-v2-native-option-linux.log','service-v2-raw-seed-constructor-linux.log']:
 for p in B.glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(f for f in p.rglob('*') if f.is_file())
paths.update(p for p in Path('obj/bootstrap-nanoisa/run-51lant1s').rglob('*') if p.is_file())
for p in ['Makefile.gnu','tests/native_process.py','tests/nanolang_translator_routes.py','tests/test_nanolang_translator_service_v2.py','tests/nvm2c_service_v2_reference.c','tests/nvm2c_service_v2_driver.nano','scripts/bootstrap_nanoisa.py']:paths.add(Path(p))
# I retain the original diagnostic's actual C, bytecode and driver closure.
root=Path('/tmp/nano-service-module-6bn32ge1')
for name in ['5.c','5-driver.c','5.nvm']:
 p=root/name
 if p.is_file():paths.add(p)
files=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);target=D/'inputs'/f'{i:03d}-{p.name}.gz';target.write_bytes(packed)
 files.append(dict(path=str(p),artifact=str(target.relative_to(D)),sha256=sha(raw),bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(D/'manifest.json').write_text(json.dumps(dict(code_commit='02f3f05c9',files=files),indent=2)+'\n')
for r in files:
 p=D/r['artifact'];assert sha(p.read_bytes())==r['compressed_sha256'] and sha(gzip.decompress(p.read_bytes()))==r['sha256']
print('I retained and audited',len(files),'files,',sum(r['bytes'] for r in files),'raw bytes and',sum(r['compressed_bytes'] for r in files),'compressed bytes.')
