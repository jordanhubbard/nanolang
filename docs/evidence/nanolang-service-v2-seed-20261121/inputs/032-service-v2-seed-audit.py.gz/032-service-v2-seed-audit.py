from pathlib import Path
import gzip,hashlib,json,subprocess
B=Path('.test_output');hosts=('linux','darwin')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(h,s):return json.loads(gzip.decompress((B/f'service-v2-seed-{h}-{s}.json.gz').read_bytes()))
a,b=(read(h,'corpus') for h in hosts);assert a==b
for r in a:assert sha(bytes.fromhex(r['bytes_hex']))==r['sha256']
man={h:json.loads((B/f'service-v2-seed-{h}-manifest.json').read_text()) for h in hosts}
assert man['linux']['source_sha256']==man['darwin']['source_sha256']
for p,h in man['linux']['source_sha256'].items():assert sha(subprocess.check_output(['git','show','02f3f05c9:'+p]))==h,p
for h,m in man.items():
 for r in [m['retained_seed'],*m['host_libraries'].values()]:
  p=Path(r['path']);assert sha(p.read_bytes())==r['compressed_sha256'];assert sha(gzip.decompress(p.read_bytes()))==r['sha256']
 boot=m['bootstrap_seed_manifest'];assert boot['artifacts']['nanoc_seed.nvm']==m['retained_seed']['sha256']
 assert boot['shadow_timeout_seconds']==30 and boot['stage_timeout_seconds']==1800
 assert all(next(s for s in boot['steps'] if s['label']==k)['exit_code']==0 for k in ('seed','seed-verify'))
products={h:read(h,'products') for h in hosts}
for h,data in products.items():
 assert len(data['records'])==8
 for p,r in data['files'].items():assert sha(bytes.fromhex(r['bytes_hex']))==r['sha256'],(h,p)
 for r in data['records']:
  assert len(r['routes'])==5 and all(v==r['actual_c_report'] for v in r['routes'].values())
  for k in ('module','carrier'):assert data['files'][r[k]]['sha256']==r[k+'_sha256']
  for p,d in r['sources'].items():assert data['files'][p]['sha256']==d
for l,r in zip(*(products[h]['records'] for h in hosts)):
 assert l['module']==r['module'] and l['sources']==r['sources'] and l['actual_c_report']==r['actual_c_report']
for h in hosts:
 log=(B/f'service-v2-seed-qualified-{h}.log').read_text();assert 'Ran 22 tests' in log and '\nOK\n' in log
 log=(B/f'service-build-budget-{h}.log').read_text();assert log.count('\nOK\n')==6,(h,log.count('\nOK\n'))
result=dict(code_commit='02f3f05c9',synthetic_records=len(a),explicit_statuses=sum(r['explicit_status'] is not None for r in a),source_hashes_against_git=len(man['linux']['source_sha256']),independent_corpora_and_c_reports_equal=True,actual_products_per_host=8,actual_routes_per_product=5,producer_sources_equal=True,retained_seed_and_six_host_libraries_per_host=True,component_methods_per_host=22,original_service_make_methods_per_host=[3,2,2,2,5,8],limits=['I qualify components through actual verified raw seeds, not Stage1 native compilers or raw fixed points.','I preserve ordinary source-creation failures and independent whole-module tuple/enum defect #1160.'])
(B/'service-v2-seed-paired-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
