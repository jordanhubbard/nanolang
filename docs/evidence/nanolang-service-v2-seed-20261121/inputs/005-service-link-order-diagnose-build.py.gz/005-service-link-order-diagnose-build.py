from pathlib import Path
import hashlib,json,os,resource,shlex,subprocess,time
from tests.native_process import run_captured
base=Path('.test_output');origin=Path('/tmp/nano-service-module-6bn32ge1');argv=shlex.split((origin/'0-5-native-build-command.txt').read_text());assert argv[-2]=='-o';argv[-1]=str(Path.cwd()/base/'service-link-order-graph5-diagnostic')
paths=[origin/'0-5.c',origin/'0-5-driver.c'];digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):digest(p) for p in paths}
record=dict(argv=argv,scope='I diagnose one native build under a separately declared 600-second bound. I do not qualify the original 90-second driver budget.',source_sha256=before)
(base/'service-link-order-slow-build.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
try:
 result=run_captured(argv,timeout=600,cwd=Path.cwd());record['returncode']=result.returncode
 (base/'service-link-order-slow-build.stdout').write_bytes(result.stdout);(base/'service-link-order-slow-build.stderr').write_bytes(result.stderr)
except BaseException as error:
 record['error']=repr(error);raise
finally:
 after=resource.getrusage(resource.RUSAGE_CHILDREN);record.update(wall_seconds=time.monotonic()-start,child_user_seconds=after.ru_utime-usage.ru_utime,child_system_seconds=after.ru_stime-usage.ru_stime,source_hashes_stable=before=={str(p):digest(p) for p in paths});(base/'service-link-order-slow-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
