import ast,hashlib,json,os,pathlib,shutil,subprocess,sys,time,signal,re,tarfile
from pathlib import Path
base=Path('/home/jkh/nanolang-qualification/pr945-make-flags-585a');base.mkdir(exist_ok=False)
repo=Path('/home/jkh/Src/nanolang-pr945-hosted-findings');pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
files=subprocess.check_output(['git','ls-files','-z'],cwd=repo,text=True).split('\0');files=[x for x in files if x and not x.startswith(('docs/evidence/','.tickets/'))]
archive=base/'source.tar';archive.write_bytes(subprocess.check_output(['git','archive',pin,*files],cwd=repo));
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
(base/'source-pin.json').write_text(json.dumps({'commit':pin,'archive_sha256':sha(archive),'files':len(files)},indent=2))
original=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(original.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run');run_source=ast.get_source_segment(original.read_text(),node);exec(run_source)
phases=set();results=[];darwin=False
for key in ('CC','CFLAGS','LDFLAGS','NANO_NATIVE_TEST_CC','MAKEFLAGS','MFLAGS','LSAN_OPTIONS'):os.environ.pop(key,None)
os.environ.update(PATH='/usr/bin:/bin:/usr/local/bin',PYTHONDONTWRITEBYTECODE='1',ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',NANO_SHADOW_TIMEOUT_SECONDS='60')
compiler='/usr/bin/cc'
paths={'python':sys.executable,'cc':compiler,'make':shutil.which('make'),'ar':shutil.which('ar'),'ld':shutil.which('ld'),'python_recipe':'/usr/bin/python3','driver':__file__,'supervisor':str(original),'ps':shutil.which('ps')}
for n in ('cc1','collect2','libgcc.a','libgcov.a','libasan.so','libubsan.so'):
 s=subprocess.check_output([compiler,('-print-prog-name=' if n in ('cc1','collect2') else '-print-file-name=')+n],text=True).strip()
 if Path(s).is_file():paths[n]=s
for name,flags in [('ordinary','-O3 -ftree-vectorize -fPIC'),('coverage','-fprofile-arcs -ftest-coverage'),('sanitizers','-fsanitize=address,undefined -fno-omit-frame-pointer')]:
 root=base/name;root.mkdir();report=base/(name+'-reports');report.mkdir();artifacts=report/'artifacts';artifacts.mkdir()
 with tarfile.open(archive) as t:t.extractall(root,filter='data')
 os.chdir(root)
 def write(n,v):(report/n).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
 def source():return {x:sha(root/x) for x in files if (root/x).is_file()}
 def tools():return {k:{'path':str(Path(v).resolve()),'sha256':sha(v)} for k,v in paths.items()}
 def inventory(extra=()):
  out={}
  for directory in [root/'bin',root/'obj',root/'lib',*map(Path,extra)]:
   if not directory.exists():continue
   for p in directory.rglob('*'):
    if not p.is_file():continue
    d=sha(p);dst=artifacts/d
    if not dst.exists():shutil.copyfile(p,dst)
    out[str(p)]={'sha256':d,'bytes':p.stat().st_size,'mode':p.stat().st_mode&511,'artifact':str(dst)}
  return out
 write('source-git-correspondence.json',{x:subprocess.check_output(['git','rev-parse',pin+':'+x],cwd=repo,text=True).strip() for x in files})
 write('environment.json',{k:os.environ.get(k) for k in ('PATH','CC','CFLAGS','LDFLAGS','NANO_NATIVE_TEST_CC','ASAN_OPTIONS','UBSAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS')})
 cflags='-Wall -Wextra -Werror -std=c99 -g -Isrc -D_GNU_SOURCE '+flags
 ldflags='-lm -lcrypto '+('' if name=='ordinary' else flags)
 run(name+'-actual-make',['make','-j2','test-nanoisa-src-nano','CC='+compiler,'CFLAGS='+cflags,'LDFLAGS='+ldflags])
(base/'complete.json').write_text(json.dumps({'pin':pin,'results':results},indent=2))
