import hashlib,itertools,json,os,pathlib,subprocess,tempfile
_trace=pathlib.Path(os.environ['QUAL_CHILD_REPORT']);_trace.mkdir(parents=True,exist_ok=True)
_counter=itertools.count();_run=subprocess.run

def _observed_run(*args,**kwargs):
 ident=str(os.getpid())+'-'+str(next(_counter)); argv=args[0] if args else kwargs.get('args');env=kwargs.get('env') or os.environ
 record={'argv':[os.fspath(x) for x in argv] if isinstance(argv,(list,tuple)) else str(argv),'cwd':os.fspath(kwargs.get('cwd') or os.getcwd()),'env':{k:env.get(k) for k in ('CC','LDFLAGS','NANO_NATIVE_TEST_CC','ASAN_OPTIONS','UBSAN_OPTIONS')}}
 (_trace/(ident+'-command.json')).write_text(json.dumps(record,indent=2))
 result=_run(*args,**kwargs)
 for name in ('stdout','stderr'):
  data=getattr(result,name,None)
  if data is not None:(_trace/(ident+'.'+name)).write_bytes(data.encode() if isinstance(data,str) else data)
 (_trace/(ident+'-terminal.json')).write_text(json.dumps({'returncode':result.returncode}))
 return result
subprocess.run=_observed_run
_OriginalTemporaryDirectory=tempfile.TemporaryDirectory
class _RetainedTemporaryDirectory(_OriginalTemporaryDirectory):
 def cleanup(self):self._finalizer.detach()
tempfile.TemporaryDirectory=_RetainedTemporaryDirectory
(_trace/(str(os.getpid())+'-environment.json')).write_text(json.dumps({'CC':os.environ.get('CC'),'LDFLAGS':os.environ.get('LDFLAGS'),'argv':__import__('sys').argv}))
