from pathlib import Path
import json,hashlib,os,tarfile,subprocess,shlex,shutil
base=Path('/home/jkh/nanolang-qualification');first=base/'pr945-make-flags-585a';mixed=base/'pr945-make-flags-mixed-585a';seal=base/'pr945-make-flags-seal';seal.mkdir(exist_ok=False);objects=seal/'objects';objects.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reports={};cas={};pairs=[];terminals=[];references=0
for label,report in [('ordinary',first/'ordinary-reports'),('coverage',first/'coverage-reports'),('full-sanitizer-first',first/'sanitizers-reports'),('mixed-sanitizer',mixed/'reports')]:
 for p in sorted(report.rglob('*')):
  if not p.is_file() or 'artifacts' in p.relative_to(report).parts or 'controls' in p.relative_to(report).parts:continue
  rel=label+'/'+str(p.relative_to(report));reports[rel]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 for p in report.glob('*-source-before.json'):
  for kind in ['source','tools']:
   before=Path(str(p).replace('-source-before.json','-'+kind+'-before.json'));after=Path(str(p).replace('-source-before.json','-'+kind+'-after.json'));assert json.loads(before.read_text())==json.loads(after.read_text());pairs.append([label,before.name,after.name])
 for p in report.glob('*-terminal.json'):
  d=json.loads(p.read_text());assert d['leader_reaped'] and d['group_disappeared'] and not d['timeout'] and not d['errors'];terminals.append({'label':label,'file':p.name,**d})
 for p in report.glob('*-artifacts.json'):
  for entry in json.loads(p.read_text()).values():references+=1;assert sha(Path(entry['artifact']))==entry['sha256']
 for p in (report/'artifacts').iterdir():
  assert sha(p)==p.name
  if p.name not in cas:os.link(p,objects/p.name);cas[p.name]=p.stat().st_size
assert len(terminals)==6 and sum(x['returncode']==0 for x in terminals)==5
for label,report in [('ordinary',first/'ordinary-reports'),('coverage',first/'coverage-reports'),('mixed-sanitizer',mixed/'reports')]:
 log=next(report.glob('*actual-make.log')).read_text();assert 'Ran 90 tests' in log and log.rstrip().endswith('OK')
links=[]
children=mixed/'reports/children';runtime=mixed/'source/bin/nano_aot_runtime.o'
for p in children.glob('*-command.json'):
 d=json.loads(p.read_text());a=d['argv']
 if not isinstance(a,list) or str(runtime) not in a:continue
 assert a[0]=='/usr/bin/cc' and a[-len(shlex.split(d['env']['LDFLAGS'])):]==shlex.split(d['env']['LDFLAGS'])
 assert '-fsanitize=address,undefined' in a and json.loads(Path(str(p).replace('-command.json','-terminal.json')).read_text())['returncode']==0
 out=Path(a[a.index('-o')+1]);assert out.is_file()
 executed=[]
 for q in children.glob('*-command.json'):
  v=json.loads(q.read_text())
  if v['argv']==[str(out)]:assert json.loads(Path(str(q).replace('-command.json','-terminal.json')).read_text())['returncode']==0;executed.append(q.name)
 assert executed
 links.append({'command':p.name,'binary_sha256':sha(out),'runtime_sha256':sha(runtime),'executions':executed})
assert len(links)==3
for n in ['qualify-pr945-make-flags.py','qualify-pr945-make-flags-mixed.py','pr945-flags-sitecustomize.py','seal-pr945-make-flags.py']:
 p=Path('/tmp')/n;reports['drivers/'+n]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
for label,b in [('original',first),('mixed',mixed)]:
 p=b/'source-pin.json';reports[label+'/source-pin.json']={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
summary={'source':subprocess.check_output(['git','rev-parse','585a6bc12'],cwd='/home/jkh/Src/nanolang-pr945-hosted-findings',text=True).strip(),'reports':len(reports),'report_bytes':sum(x['bytes'] for x in reports.values()),'cas':len(cas),'cas_bytes':sum(cas.values()),'references':references,'pairs':pairs,'terminals':terminals,'verified_native_links':links,'limits':['Original ordinary and coverage fixture temporary products were cleaned by unchanged tests; retained provider objects and raw90-method results remain.','Mixed run observer retains actual fixture TemporaryDirectories and subprocess commands/results; it does not reconstruct compiler-owned deleted transient files.','All-provider sanitizer compiler shadow timed out at existing60s; mixed sanitizer result is ordinary compiler/providers with instrumented AOT runtime.','ASAN detect_leaks=0 follows hosted flags; no LSan acceptance claim.']}
(seal/'reports.json').write_text(json.dumps(reports,indent=2));(seal/'objects.json').write_text(json.dumps(cas,indent=2));(seal/'summary.json').write_text(json.dumps(summary,indent=2))
with tarfile.open(seal/'reports.tar.gz','w:gz') as t:
 for rel,r in reports.items():t.add(r['path'],arcname=rel,recursive=False)
with tarfile.open(seal/'reports.tar.gz') as t:
 assert set(t.getnames())==set(reports)
 for member in t:
  data=t.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==reports[member.name]['sha256']
(seal/'archive.json').write_text(json.dumps({'sha256':sha(seal/'reports.tar.gz'),'bytes':(seal/'reports.tar.gz').stat().st_size,'members':len(reports)},indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ['pairs','terminals','verified_native_links']},indent=2))
