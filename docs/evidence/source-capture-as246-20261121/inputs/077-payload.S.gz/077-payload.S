#define INSTRUCTION nop
.include "debug macro.s"
.text
step INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
read_payload "debug payload.bin"
