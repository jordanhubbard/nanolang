#define INSTRUCTION nop
.include "/tmp/nano-nop-assembler-debug-9vyi6fbg/debug macro.s"
.text
step INSTRUCTION
.data
.globl snapshot_payload
snapshot_payload:
read_payload "/tmp/nano-nop-assembler-debug-9vyi6fbg/debug payload.bin"
