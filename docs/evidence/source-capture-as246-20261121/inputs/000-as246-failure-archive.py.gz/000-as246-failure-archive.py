from pathlib import Path
import gzip,hashlib,json,subprocess
D=Path('docs/evidence/source-capture-as246-20261121');(D/'inputs').mkdir(parents=True,exist_ok=True);B=Path('.test_output');roots=[B/'as246-candidate-44930824853',B/'native-debug-44935014281']
paths=set()
for root in roots:paths.update(p for p in root.rglob('*') if p.is_file())
paths.update([B/'as246-candidate-44930824853-failed.log',B/'native-debug-44935014281-failed.log',B/'native-debug-ci-workflow.log',B/'native-debug-ci-workflow-system-python.log',Path('scripts/ci_qualify_as246.py'),Path('tests/characterize_assembler_debug.py'),Path('.github/workflows/source-capture-toolchain-diagnostic.yml'),Path(__file__)])
sha=lambda b:hashlib.sha256(b).hexdigest();audits=[]
for root in (B/'native-debug-44935014281').rglob('native-*'):
 if not root.is_dir() or not (root/'observation.json').is_file():continue
 model=json.loads((root/'observation.json').read_text());assert model['source_stem']=='payload' and model['suffix']=='S'
 for name,key in [('native.o','native_sha256'),('physical-native.o','physical_sha256')]:
  obj=root/'fixture'/name;assert sha(obj.read_bytes())==model[key]
  dump=subprocess.check_output(['readelf','--debug-dump=info','--debug-dump=decodedline',str(obj)])
  assert b'DW_TAG_compile_unit' in dump and b'/tmp/cc' in dump and b'payload.S' not in dump
  target=root/(name+'.local-readelf.txt');target.write_bytes(dump);paths.add(target)
 audits.append(dict(path=str(root),native_object_hash_matches=True,independent_local_object_dump_confirms_temporary_name=True))
audit=B/'as246-native-object-audit.json';audit.write_text(json.dumps(dict(objects=audits,product_admission_changed=False),indent=2)+'\n');paths.add(audit)
files=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=D/'inputs'/f'{i:03d}-{p.name}.gz';dest.write_bytes(packed);files.append(dict(path=str(p),artifact=str(dest.relative_to(D)),sha256=sha(raw),bytes=len(raw),compressed_sha256=sha(packed)))
(D/'manifest.json').write_text(json.dumps(dict(candidate_commit='4f74234b6',native_debug_commit='0885f2d50',files=files),indent=2)+'\n');print(len(files),'files',sum(r['bytes'] for r in files),'raw bytes')
