extern unsigned char snapshot_payload[];
long long nano_build_answer(void) { return snapshot_payload[0]; }
