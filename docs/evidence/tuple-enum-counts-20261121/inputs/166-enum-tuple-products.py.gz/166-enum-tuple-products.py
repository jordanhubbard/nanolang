from pathlib import Path
import hashlib,json,sys
from tests.test_nanolang_translator_declarations import producer_cases
from tests.nanolang_translator_routes import build_routes,checked
R=Path.cwd();host='darwin' if sys.platform=='darwin' else 'linux';D=R/'.test_output'/('enum-tuple-products-'+host);D.mkdir(exist_ok=True)
cases=producer_cases(D,root=D/'products');assert len(cases)==14,len(cases)
paths=[]
for i,(name,data,_) in enumerate(cases):
 p=D/(str(i)+'.bin');p.write_bytes(data);paths.append(p)
routes=build_routes(R/'tests/nvm2c_declaration_driver.nano',D);assert len(routes)==5
reports={}
for profile in (1,2,3):
 reference=checked(['obj/nvm2c_declaration_reference',str(profile),*paths],timeout=600)
 for label,cmd in routes:assert checked([*cmd,str(profile),*paths],timeout=600)==reference,(profile,label)
 reports[profile]=reference
files={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in D.rglob('*') if p.is_file()}
(D/'qualification.json').write_text(json.dumps(dict(products=len(cases),routes=len(routes),profiles=3,reports=reports,files=files),indent=2)+'\n');print('I matched14 actual C/NanoLang products through three profiles and five routes.',flush=True)
