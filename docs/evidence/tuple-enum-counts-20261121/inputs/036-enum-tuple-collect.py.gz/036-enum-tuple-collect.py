from pathlib import Path
import hashlib,json,subprocess,sys
from tests.test_nanolang_translator_ownership import corpus
from tests.nanolang_translator_routes import checked
R=Path.cwd();B=R/'.test_output';host='darwin' if sys.platform=='darwin' else 'linux';D=B/('enum-tuple-retained-'+host);D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
for name,data,expected in corpus():
 if name.startswith('wire-kind-'):
  p=D/(name+'.bin');p.write_bytes(data);actual=checked(['obj/nvm2c_ownership_reference',p]).strip();assert actual==expected
  records.append(dict(name=name,sha256=sha(data),expected=expected,actual_c_report=actual))
sources=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','Makefile.gnu','scripts/bootstrap_nanoisa.py','tests/test_nanolang_translator_ownership.py','tests/test_nanolang_translator_declarations.py','tests/test_nanolang_translator_module.py','tests/test_nanolang_translator_ownership_module.py','tests/nanolang_translator_routes.py'],text=True).splitlines()
sources=[p for p in sources if Path(p).suffix in ('.nano','.c','.h','.inc','.json','.py') or p=='Makefile.gnu']
tools=['bin/nanoc_seed.nvm','bin/nano_vm','bin/nanoc_c','bin/nano_virt','bin/nvm2c','bin/nanoisa','obj/nvm2c_ownership_reference','obj/nvm2c_declaration_reference','obj/nvm2c_declaration_reference_asan','obj/nvm2c_module_reference']
old=json.loads((B/f'service-v2-seed-{host}-manifest.json').read_text());assert sha((R/'bin/nanoc_seed.nvm').read_bytes())==old['retained_seed']['sha256']
model=dict(host=host,source_sha256={p:sha((R/p).read_bytes()) for p in sources},post_run_tool_sha256={p:sha((R/p).read_bytes()) for p in tools},explicit_count_controls=records,seed_provenance='docs/evidence/nanolang-service-v2-seed-20261121/README.md',limits=['I use the earlier verified raw seed to compile the corrected library source. I do not claim a new compiler bootstrap or native Stage1.','My initial six-method gate has seven C declaration products; a separate14-product gate includes all seven additional NanoLang products. Linux full ownership-module gate includes14; Darwin first full gate includes7, followed by14-product full-module comparison.','Private profiles remain explicitly pending, never successful admission.'])
(D/'manifest.json').write_text(json.dumps(model,indent=2)+'\n');print(host,len(sources),'equal-source candidates and18 independently expected reports.')
