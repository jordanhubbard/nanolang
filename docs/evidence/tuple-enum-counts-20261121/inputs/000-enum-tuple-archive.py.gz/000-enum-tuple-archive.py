from pathlib import Path
import gzip,hashlib,json,subprocess
B=Path('.test_output');D=Path('docs/evidence/tuple-enum-counts-20261121');(D/'inputs').mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
models={h:json.loads((B/f'enum-tuple-retained-{h}/manifest.json').read_text()) for h in ('linux','darwin')};assert models['linux']['source_sha256']==models['darwin']['source_sha256']
assert models['linux']['explicit_count_controls']==models['darwin']['explicit_count_controls']
for p,d in models['linux']['source_sha256'].items():assert sha(Path(p).read_bytes())==d,p
for host in models:
 log=(B/f'enum-tuple-qualified-{host}.log').read_text();assert 'Ran 6 tests' in log and '\nOK\n' in log
 log=(B/f'enum-tuple-module-qualified-{host}.log').read_text();assert 'Ran 1 test' in log and '\nOK\n' in log
 p=B/f'enum-tuple-products-{host}';q=json.loads((p/'qualification.json').read_text());assert(q['products'],q['routes'],q['profiles'])==(14,5,3)
 for path,digest in q['files'].items():assert sha((p/path).read_bytes())==digest,(host,path)
 if host=='darwin':
  q=json.loads((p/'module-qualification.json').read_text());assert(q['products'],q['routes'])==(14,5)
product_rows={h:json.loads((B/f'enum-tuple-products-{h}/products/records.json').read_text()) for h in models}
for l,r in zip(*(product_rows[h] for h in models)):
 assert l['name']==r['name'] and l['source_sha256']==r['source_sha256']
audit=B/'enum-tuple-paired-audit.json';audit.write_text(json.dumps(dict(equal_source_hashes=1334,explicit_controls=18,original_methods_per_host=7,extra_products_per_host=14,extra_profiles=3,extra_routes=5,linux_ownership_modules=2563,darwin_ownership_modules=2556,linux_pending=8,darwin_pending=7,darwin_additional_full_modules=14,limits=models['linux']['limits']),indent=2)+'\n')
paths=set()
for pattern in ['enum-tuple-*']:
 for p in B.glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(f for f in p.rglob('*') if f.is_file())
# I retain the original actual disagreement and its driver too.
paths.update(p for p in (B/'enum-tuple-boundary').rglob('*') if p.is_file())
source_paths=['src_nano/nvm2c/'+name for name in ('ownership.nano','declarations.nano','module.nano')]+['tests/test_nanolang_translator_'+name+'.py' for name in ('ownership','declarations','module','ownership_module')]
paths.update(Path(p) for p in source_paths)
files=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=D/'inputs'/f'{i:03d}-{p.name}.gz';dest.write_bytes(packed);files.append(dict(path=str(p),artifact=str(dest.relative_to(D)),sha256=sha(raw),bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(D/'manifest.json').write_text(json.dumps(dict(base_commit='3bf3e8538',original_candidate_patch_sha256=sha((B/'enum-tuple-candidate.patch').read_bytes()),files=files),indent=2)+'\n')
for row in files:
 data=(D/row['artifact']).read_bytes();assert sha(data)==row['compressed_sha256'] and sha(gzip.decompress(data))==row['sha256']
print(len(files),'files',sum(r['bytes'] for r in files),'raw',sum(r['compressed_bytes'] for r in files),'compressed')
