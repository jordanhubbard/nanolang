from pathlib import Path
import json,sys
from tests.nanolang_translator_routes import build_routes,checked
from tests.test_nanolang_translator_ownership_module import wrapped
R=Path.cwd();host='darwin' if sys.platform=='darwin' else 'linux';D=R/'.test_output'/('enum-tuple-products-'+host);rows=json.loads((D/'products/records.json').read_text());assert len(rows)==14
paths=[D/'products'/r['module'] for r in rows];private=[wrapped((D/'products'/r['model']).read_bytes()[16:])[1] for r in rows]
reference=checked(['obj/nvm2c_module_reference','--claims',*paths],timeout=600).splitlines();assert len(reference)==14
work=D/'module-drivers';work.mkdir(exist_ok=True);routes=build_routes(R/'tests/nvm2c_module_driver.nano',work);assert len(routes)==5
reports={}
for label,cmd in routes:
 actual=checked([*cmd,'--claims',*paths],timeout=600).splitlines();assert len(actual)==14
 for i,(expected,value) in enumerate(zip(reference,actual)):
  if value.startswith('-1:'):assert private[i] and value=='-1:0::0:',(i,value)
  else:assert value==expected,(i,label,expected,value)
 reports[label]=actual
(D/'module-qualification.json').write_text(json.dumps(dict(products=14,routes=5,private_inputs=private,reference=reference,reports=reports),indent=2)+'\n');print('I compared14 actual C/NanoLang modules and exact claims across five routes; private profiles remain pending.')
