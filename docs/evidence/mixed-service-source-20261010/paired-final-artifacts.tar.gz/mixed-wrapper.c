
#include "nanoisa/services_indirect_public.h"
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>
extern NvmServicesIndirectExecutionReport nvm_services_indirect_program_source(NvmServicesHostGrant *,const NvmServicesIndirectOptions *,NvmServicesScalar *);
int main(void) {
    NvmServicesHostGrant *grant=NULL;
    NvmServicesHostPolicy policies[]={{NVM_SERVICES_HOST_FILE,true},{NVM_SERVICES_HOST_TCP,true},{NVM_SERVICES_HOST_FILE,true}}; assert(nvm_services_host_grant_create(policies,3,&grant)==NVM_SERVICES_HOST_OK);
    NvmServicesIndirectOptions options={1,100000};NvmServicesScalar scalar={0};
    unsigned before=0,after=0;
    for(int i=0;i<1024;i++)before+=fcntl(i,F_GETFD)!=-1;
    NvmServicesIndirectExecutionReport denied=nvm_services_indirect_program_source(NULL,&options,&scalar);
    assert(denied.runtime.status==NVM_SERVICES_RUNTIME_INVALID && !denied.runtime.acquired);
    NvmServicesIndirectExecutionReport report=nvm_services_indirect_program_source(grant,&options,&scalar);
    for(int i=0;i<1024;i++)after+=fcntl(i,F_GETFD)!=-1;
    assert(before==after);
    printf("EXEC %u VALUE %lld\n",report.runtime.status,(long long)scalar.value);
    assert(!report.runtime.cleanup.cleanup_failures);
    assert(nvm_services_host_grant_destroy(&grant)==NVM_SERVICES_HOST_OK);
    return 0;
}
