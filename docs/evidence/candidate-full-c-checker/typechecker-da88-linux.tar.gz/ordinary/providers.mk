include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	@printf '%s\n' '$(COMMON_OBJECTS) $(RUNTIME_OBJECTS)' > /home/jkh/nanolang-qualification/typechecker-da88-linux/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/typechecker-da88-linux/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/typechecker-da88-linux/ordinary/ldflags.txt
