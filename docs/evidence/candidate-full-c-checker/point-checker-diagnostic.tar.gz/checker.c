#include "nanolang.h"
#include "reflection.h"
int g_argc; char **g_argv; char g_project_root[4096]="."; const char *get_project_root(void){return g_project_root;}
int main(int argc,char **argv){
const char *source="struct Point { value:int } union Box<T> { Value { value:T } } enum Choice { One, Two } fn fold(a:Point,b:Point)->Point{return a} fn apply(xs:array<Point>,initial:Point)->Point{return (reduce xs initial fold)}";
int count;Token *tokens=tokenize(source,&count);if(!tokens)return 3;ASTNode *program=parse_program(tokens,count);if(!program)return 4;clear_module_cache();Environment *env=create_environment();if(!env)return 5;typecheck_set_current_file("<module>");bool ok=type_check_module(program,env);if(ok&&argc==2)ok=emit_module_reflection(argv[1],program,env,"probe");free_environment(env);free_ast(program);free_tokens(tokens,count);return ok?0:1;}
