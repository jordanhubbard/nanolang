from pathlib import Path
import gzip,hashlib,json,os,platform,subprocess,sys,tempfile
from tests.nanolang_translator_routes import checked
from tests.test_nanolang_translator_services import corpus
from tests.test_native_byte_array_results import source
from tests.native_process import native_link_flags,run_captured

def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,data):Path(path).write_bytes(gzip.compress((json.dumps(data,separators=(',',':'))+'\n').encode(),mtime=0))
def observe(*args):
 p=subprocess.run(args,capture_output=True,text=True);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

if sys.argv[1]=='--corpus':
 cases=corpus();reports={}
 with tempfile.TemporaryDirectory(prefix='service-wire-corpus-') as directory:
  groups={}
  for i,(profile,mode,_,data,_) in enumerate(cases):
   path=Path(directory)/str(i);path.write_bytes(data);groups.setdefault((profile,mode),[]).append((i,path))
  for (profile,mode),items in groups.items():
   for offset in range(0,len(items),32):
    batch=items[offset:offset+32];values=checked(['obj/nvm2c_service_reference',str(profile),mode,*[p for _,p in batch]],timeout=600).splitlines();assert len(values)==len(batch)
    reports.update({i:value for (i,_),value in zip(batch,values)})
 records=[]
 for i,(profile,mode,name,data,expected) in enumerate(cases):
  report=reports[i]
  if expected is not None:assert int(report.split('|')[0])==expected,(profile,mode,name,expected,report[:100])
  records.append(dict(profile=profile,mode=mode,name=name,bytes_hex=data.hex(),sha256=digest(data),explicit_status=expected,actual_c_report=report))
 save('.test_output/service-wire-corpus.json.gz',records)
 print('I retained',len(records),'raw wire/value inputs and complete C reports;',sum(r['explicit_status'] is not None for r in records),'explicit statuses.')
elif sys.argv[1]=='--products':
 root=Path(tempfile.mkdtemp(prefix='service-wire-products-',dir=Path('.test_output').resolve()));print('I retain product artifacts at',root,flush=True)
 fixtures=[]
 for reverse in (False,True):
  for direct in (False,True):
   path=root/f'bytes-{reverse}-{direct}.nano';path.write_text(source(reverse,direct));fixtures.append((path,'255\n255\n'))
 fixtures += [(Path(p).resolve(),'') for p in ('tests/nanoisa/fixtures/generic_scalar_array.nano','tests/test_u8_basic.nano','tests/test_bytes_conversion.nano')]
 producers=[('c',Path('bin/nano_virt').resolve())]
 if os.environ.get('NANOLANG_TRANSLATOR_SOURCE_COMPILER'):producers.append(('nanolang',Path(os.environ['NANOLANG_TRANSLATOR_SOURCE_COMPILER'])))
 records=[]
 for fixture,expected in fixtures:
  before=fixture.read_bytes()
  for label,compiler in producers:
   stem=label+'-'+fixture.stem;module=root/(stem+'.nvm');c=root/(stem+'.c');native=root/(stem+'.native')
   checked([compiler,fixture,'--emit-nvm','-o',module],build=True,timeout=180)
   checked(['bin/nano_vm','--verify-only',module],timeout=120)
   vm=run_captured([Path('bin/nano_vm').resolve(),module],cwd=Path.cwd(),timeout=120)
   assert vm.returncode==0 and vm.stdout.decode()==expected,(stem,vm.returncode,vm.stderr)
   checked(['bin/nvm2c',module,'-o',c],build=True,timeout=120)
   command=['cc','-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all',c,Path('bin/nano_aot_runtime.o').resolve(),'-lm',*(['-ldl','-Wl,--export-dynamic'] if sys.platform.startswith('linux') else []),*native_link_flags(),'-o',native]
   checked(command,build=True,timeout=120)
   result=run_captured([native],cwd=Path.cwd(),timeout=120);assert result.returncode==0 and result.stdout.decode()==expected,(stem,result.returncode,result.stderr)
   assert fixture.read_bytes()==before
   records.append(dict(name=stem,source=str(fixture),source_bytes_hex=before.hex(),source_sha256=digest(before),module_bytes_hex=module.read_bytes().hex(),module_sha256=digest(module.read_bytes()),generated_c_sha256=digest(c.read_bytes()),native_sha256=digest(native.read_bytes()),producer=str(compiler),vm_exit=vm.returncode,vm_stdout=vm.stdout.decode(),vm_stderr=vm.stderr.decode(errors='replace'),native_exit=result.returncode,native_stdout=result.stdout.decode(),native_stderr=result.stderr.decode(errors='replace')))
   save(sys.argv[2],records)
 print('I retained',len(records),'real producer modules and paired VM/sanitized-native results; sources are unchanged.')
else:
 host='darwin' if sys.platform=='darwin' else 'linux'
 sources=['Makefile.gnu','src/eval.c','src/typechecker.c','src/nanovm/vm_builtins.c','src/nanovm/vm_ffi_arrays.c','src/nanovm/vm_ffi.c','src/module_builder.c','src/runtime/assembler_capture.c','tests/nanovm/test_vm_builtins.c','tests/test_eval.c','tests/test_typechecker.c']
 sources += [str(p) for p in Path('src_nano/nvm2c').glob('*.nano')]+[str(p) for p in Path('src/nanoisa').iterdir() if p.suffix in ('.c','.h','.inc')]
 sources += ['tests/'+s for s in ['nvm2c_service_driver.nano','nvm2c_service_reference.c','test_nanolang_translator_services.py','test_native_byte_array_results.py','nanolang_translator_routes.py','native_process.py','test_native_byte_arrays.py','test_native_nested_arrays.py','test_native_record_array_scalar_tags.py','test_native_generic_scalar_array.py','test_byte_array_literals.py','test_byte_conversion_contracts.py','test_byte_alias_contracts.py','test_u8_argument_contracts.py','test_numeric_builtin_selection.py','test_module_builder_self_capture.py','test_assembler_capture_records.py','test_bytes_conversion.nano','test_u8_basic.nano','nanoisa/fixtures/generic_scalar_array.nano']]
 sources += ['tests/'+s for s in ['nanoisa/test_service_bindings.c','nanoisa/test_file_nominal.c','nanoisa/test_socket_nominal.c','nanoisa/test_websocket_nominal.c','nanoisa/test_multi_nominal.c','nanoisa/test_nvm2c.c','nanoisa/test_nvm2c_shape.c','nanoisa/test_nvm2c_callables.c','test_service_bindings.py','test_service_bindings_module.py','test_socket_nominal.py','test_multi_nominal.py','test_type_infer.c']]
 tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_service_reference','obj/nvm2c_service_reference_asan','.test_output/ownership-source-final']
 if host=='linux':tools+=['bin/nano_as_capture.so','obj/test_module_generation_probe']
 hashes={s:digest(Path(s).read_bytes()) for s in tools}
 previous=json.loads(gzip.decompress(Path('docs/evidence/nanolang-ownership-20261120/inputs/ownership-'+host+'-manifest.json.gz').read_bytes()))
 assert previous['post_run_tool_sha256']['.test_output/ownership-source-final']==hashes['.test_output/ownership-source-final']
 result=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,environment={k:os.environ.get(k) for k in ('CC','NANO_NUMERIC_PROVIDERS','NANO_AS_CAPTURE_HELPER','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS')},source_sha256={s:digest(Path(s).read_bytes()) for s in sorted(set(sources))},post_run_tool_sha256=hashes,reused_compiler_matches_previous_receipt=True,limits=['I reuse the real C-seed-built development NanoLang compiler image from7cd173b30; it matches the previous paired ownership receipt.','I explicitly configure the real Linux GNU-as capture helper for the development image outside bin; no capture/shadow guards are disabled.','All five C codec providers are ASan/UBSan instrumented in the raw differential oracle. Generated C fixtures/products are instrumented and link an ordinary AOT runtime.','The full C evaluator/checker/VM/provider regression has its stated ordinary or focused sanitizer scope; this is no complete evaluator leak qualification or Darwin LSan claim.','I model immutable normal narrow value carriers, not arbitrary C pointer/overlap graphs; original C raw units retain null/overlap/short-buffer/failure-atomic controls.','The installed Stage1/Stage2 generic-source gate remains open; the original fixture is independently executed with actual available C/NanoLang development producers.','Raw service bytes grant no module, flow, execution or host authority; complete profiles, pure NanoLang C emission and release acceptance remain open.'])
 if host=='darwin':result.update(sdk=observe('xcrun','--sdk','macosx','--show-sdk-version'),sdk_path=observe('xcrun','--sdk','macosx','--show-sdk-path'),os=observe('sw_vers'))
 Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
