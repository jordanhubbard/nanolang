.test_output/byte-before-typechecker.o: .test_output/typechecker-before-byte-mutation-fix.c
	$(CC) $(CFLAGS) -c $< -o $@
.test_output/byte-before-eval.o: .test_output/eval-before-byte-mutation-fix.c
	$(CC) $(CFLAGS) -c $< -o $@
.test_output/byte-before-nanoc: .test_output/byte-before-typechecker.o .test_output/byte-before-eval.o
	$(CC) $(CFLAGS) -o $@ $(filter-out $(OBJ_DIR)/typechecker.o $(OBJ_DIR)/eval.o,$(COMPILER_OBJECTS)) $^ $(LDFLAGS)
.test_output/byte-before-virt: .test_output/byte-before-typechecker.o .test_output/byte-before-eval.o
	$(CC) $(CFLAGS) -rdynamic -o $@ $(NANOVIRT_OBJECTS) $(NANOVM_OBJECTS) $(NANOISA_OBJECTS) $(filter-out $(OBJ_DIR)/typechecker.o $(OBJ_DIR)/eval.o,$(COMMON_OBJECTS)) $(RUNTIME_OBJECTS) $(OBJ_DIR)/nanovirt/main.o $(SERVICE_DRIVER_OBJECTS) $(FILE_PUBLIC_LIBRARY) lib/libnano_socket_runtime.a lib/libnano_services_runtime.a lib/libnano_websocket_runtime.a $^ $(LDFLAGS)
