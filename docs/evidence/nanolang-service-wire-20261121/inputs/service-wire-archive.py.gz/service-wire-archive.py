from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('.test_output');dest=Path('docs/evidence/nanolang-service-wire-20261121');inputs=dest/'inputs'
def digest(data):return hashlib.sha256(data).hexdigest()
results=dict(implementation_commits=['f75aa6189','ff6aa99bd'],terminal_commands=[
 dict(command='Initial unsupported --emit-c build',exit_code=1,log='service-wire-first-build.log'),
 dict(command='First executable fixture build with nonexistent cast_u8',exit_code=1,log='service-wire-driver-first-build.log'),
 dict(session=63138,command='Corrected C-seed fixture build',exit_code=0,log='service-wire-driver-corrected-build.log'),
 dict(session=88483,command='Build raw reference providers, then first service unittest gate',exit_code=1,logs=['service-wire-oracles-build.log','service-wire-linux-first.log'],outcome='Actual codec-provider sanitizer method passes; native fixture translation refuses premature byte/integer return storage.'),
 dict(session=31910,command='Rebuild translator and translate original minimal and service modules after inference fix',exit_code=0,logs=['byte-array-return-rebuild.log','byte-array-return-corrected-native.log','service-wire-corrected-translator.log']),
 dict(session=48783,command='First byte-write and service combined gate',exit_code=1,log='service-wire-linux-corrected.log',outcome='C wide-write shadows and four source-publication assertions fail; both service methods pass.'),
 dict(session=74112,command='Byte mutation and service gate after shared C repairs',exit_code=1,log='service-wire-linux-final.log',outcome='Eight dynamic VM route assertions fail; source refusals and service methods pass.'),
 dict(session=29124,command='Build VM builtin repair and run combined source/service gate',exit_code=1,logs=['byte-vm-builtin-linux-build-unit.log','service-wire-linux-qualified.log'],outcome='All23 builtin tests pass; original NanoLang dependency shadows expose missing development assembler companion.'),
 dict(session=41392,command='Record #1110 update and retain actual NanoLang-produced failing dynamic module',exit_code=1,logs=['byte-array-results-dynamic-source-producer.log','byte-array-results-dynamic-source-vm.log']),
 dict(command='Verbose and trace std capture diagnoses',exit_code=1,logs=['byte-conversion-source-module-diagnostic.log','byte-conversion-source-module-trace.log']),
 dict(session=61700,command='Record #1152 and trace exact child execution of original failing source',exit_code=1,logs=['byte-conversion-source-strace.log','byte-conversion-module-process.trace']),
 dict(command='Original complete source with actual NANO_AS_CAPTURE_HELPER',exit_code=0,log='byte-conversion-source-helper-corrected.log'),
 dict(session=96083,command='Linux final six-method source/service gate with genuine development compiler and explicit actual assembler companion',exit_code=0,log='service-wire-linux-qualified-final.log'),
 dict(session=33830,command='Linux eleven array methods, then embedded identifier gate',exit_code=0,logs=['byte-return-linux-array-qualified.log','service-wire-linux-identifiers.log'],note='Both logs retain their own complete passing method counts; this is the combined shell status.'),
 dict(session=33397,command='Linux eleven array methods, then original checker/inference/evaluator/metadata targets',exit_code=0,logs=['byte-return-linux-array-final.log','byte-mutation-linux-units-final.log'],note='Combined shell status; both independent logs record complete passing gates.'),
 dict(session=44811,command='Linux eighteen original conversion/alias/argument methods, then full native translator/VM-FFI/byte-literal targets',exit_code=0,logs=['byte-conversion-linux-original.log','byte-return-linux-native-final.log'],note='Combined shell status; first Python group is additionally supported by its full eighteen-method OK log, not an invented independent exit status.'),
 dict(session=34818,command='Linux final original five raw/nominal C targets',exit_code=0,log='service-wire-linux-codec-original-final.log'),
 dict(session=60087,command='Build actual module probe and run twelve GNU-as capture/replay/self-capture/refusal methods',exit_code=0,logs=['service-module-probe-build.log','service-module-capture-linux-controls.log']),
 dict(session=89939,command='Darwin fetch ff6aa99bd, build actual tools/providers, run35 methods and all original targets with && dependencies',exit_code=0,logs=['service-wire-darwin-build.log','service-wire-darwin-final.log','service-wire-darwin-original.log']),
 dict(session=6851,command='Retain Linux fourteen real modules and paired verified VM/sanitized-native outcomes',exit_code=0,log='service-wire-linux-products.log'),
 dict(session=73145,command='Collect Linux manifest, Darwin fourteen products and Darwin manifest',exit_code=0,log='service-wire-darwin-products.log'),
 dict(session=65002,command='Build isolated reconstructed old-checker/evaluator compiler controls',exit_code=0,log='byte-before-tools-build.log'),
 dict(session=4859,command='Run six reconstructed old-checker publication controls with the exact .nvm output suffix and verify retained inputs',exit_code=0,log='byte-before-publications.log')],setup_failures=dict(array_regression='I retain the first default-Clang Werror and missing installed Stage1/Stage2 path failures. Explicit cc and actual available images qualify the unchanged fixtures; installed stages remain a separate open gate.'),limits=['Only observed complete command outcomes are assigned exit codes; compound commands are identified as compound.','Expected invariant diagnostics inside passing original refusal tests are not hidden product failures.','The reconstructed old tools use exact afca0a6a0 checker/evaluator source with the current unchanged-interface provider closure; they are not the original first-failure executable images.'])
(root/'service-wire-terminal-results.json').write_text(json.dumps(results,indent=2)+'\n')
files='''service-wire-collect.py service-wire-archive.py service-wire-terminal-results.json service-wire-corpus.json.gz service-wire-darwin-corpus.json.gz service-wire-corpus.log service-wire-linux-products.json.gz service-wire-darwin-products.json.gz service-wire-linux-products.log service-wire-darwin-products.log service-wire-linux-manifest.json service-wire-darwin-manifest.json
service-wire-first-source.nano service-wire-pre-cast-fix.nano service-wire-shape-refusal.nano service-driver-shape-refusal.nano service-wire-first-build.log service-wire-driver-first-build.log service-wire-driver-corrected-build.log service-wire-reference-first-build.log service-wire-oracles-build.log service-wire-linux-first.log service-wire-refused.nvm service-wire-reproduce-producer.log service-wire-reproduce-translator.log
byte-array-return.nano byte-array-return.nvm byte-array-return-native.log byte-array-return-producer.log byte-array-return-vm.log byte-array-return-record.nano byte-array-return-record.nvm byte-array-return-record-native.log byte-array-return-record-producer.log byte-array-return-record-vm.log byte-array-return-computed.nano byte-array-return-computed.nvm byte-array-return-computed-native.log byte-array-return-computed-producer.log byte-array-return-computed-vm.log byte-array-return-corrected-native.log byte-array-return-rebuild.log service-wire-corrected-translator.log
byte-array-results-first-positive.nano byte-array-results-first-positive.log byte-array-results-first-test.py byte-array-refusal-bool.nano byte-array-refusal-string.nano byte-array-refusal-nested.nano service-wire-linux-corrected.log byte-array-results-dynamic.nano byte-array-results-dynamic.nvm byte-array-results-dynamic-producer.log byte-array-results-dynamic-vm.log byte-array-results-dynamic-source.nvm byte-array-results-dynamic-source-producer.log byte-array-results-dynamic-source-vm.log service-wire-linux-final.log service-wire-linux-qualified.log
byte-conversion-source-module-diagnostic.log byte-conversion-source-module-trace.log byte-conversion-source-strace.log byte-conversion-module-process.trace byte-conversion-source-helper-corrected.log byte-conversion-original-complete.nvm std-fs-capture-diagnostic.s std-process-capture-diagnostic.s
nvm2c-before-byte-return-fix.c eval-before-byte-mutation-fix.c typechecker-before-byte-mutation-fix.c vm-builtins-before-byte-result-fix.c test-vm-builtins-before-byte-result-fix.c byte-before.mk byte-before-publications.py byte-before-tools-build.log byte-before-publications.log byte-before-publications.json.gz
byte-mutation-objects-build.log byte-mutation-frontends-build.log byte-mutation-linux-units.log byte-mutation-linux-units-final.log byte-return-linux-array-regression.log byte-return-linux-array-final.log byte-return-linux-array-qualified.log byte-vm-builtin-linux-build-unit.log service-wire-linux-qualified-final.log byte-conversion-linux-original.log byte-return-linux-native-final.log service-wire-linux-original.log service-wire-linux-codec-original-final.log service-wire-linux-identifiers.log service-module-probe-build.log service-module-capture-linux-controls.log service-wire-darwin-build.log service-wire-darwin-final.log service-wire-darwin-original.log'''.split()
records=[]
def retain(name,raw,compressed=None):
 if compressed is None:compressed=gzip.compress(raw,mtime=0)
 (inputs/name).write_bytes(compressed)
 records.append(dict(path='inputs/'+name,raw_bytes=len(raw),raw_sha256=digest(raw),compressed_bytes=len(compressed),compressed_sha256=digest(compressed)))
for name in files:
 data=(root/name).read_bytes();raw=gzip.decompress(data) if name.endswith('.gz') else data
 retain(name if name.endswith('.gz') else name+'.gz',raw,data if name.endswith('.gz') else None)
qualified=['Makefile.gnu','src/eval.c','src/typechecker.c','src/nanovm/vm_builtins.c','src/nanoisa/nvm2c.c','tests/nanovm/test_vm_builtins.c','src_nano/nvm2c/service_wire.nano','tests/nvm2c_service_driver.nano','tests/nvm2c_service_reference.c','tests/test_nanolang_translator_services.py','tests/test_native_byte_array_results.py']
for path in qualified:
 raw=subprocess.check_output(['git','show','ff6aa99bd:'+path]);assert raw==Path(path).read_bytes(),path
 retain('qualified-'+path.replace('/','_')+'.gz',raw)
for record in records:
 data=(dest/record['path']).read_bytes();raw=gzip.decompress(data)
 assert digest(data)==record['compressed_sha256'] and len(data)==record['compressed_bytes']
 assert digest(raw)==record['raw_sha256'] and len(raw)==record['raw_bytes']
a=json.loads((root/'service-wire-linux-manifest.json').read_text());b=json.loads((root/'service-wire-darwin-manifest.json').read_text());assert a['source_sha256']==b['source_sha256']
for path,value in a['post_run_tool_sha256'].items():assert digest(Path(path).read_bytes())==value,path
for path,value in a['source_sha256'].items():assert digest(Path(path).read_bytes())==value,path
assert gzip.decompress((root/'service-wire-corpus.json.gz').read_bytes())==gzip.decompress((root/'service-wire-darwin-corpus.json.gz').read_bytes())
(dest/'retained-inputs.json').write_text(json.dumps(dict(implementation_commits=['f75aa6189','ff6aa99bd'],matching_source_hashes=len(a['source_sha256']),inputs=records),indent=2)+'\n')
print('I verified',len(records),'retained inputs and live qualified source/tool hashes;',sum(r['compressed_bytes'] for r in records),'compressed bytes.')
