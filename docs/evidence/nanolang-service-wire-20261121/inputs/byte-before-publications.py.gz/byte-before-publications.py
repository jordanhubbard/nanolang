from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('.test_output');records=[]
def digest(b):return hashlib.sha256(b).hexdigest()
for producer in ('nanoc','virt'):
 image=root/('byte-before-'+producer)
 for label,expression in [('bool','true'),('string','"wrong"'),('nested','[1]')]:
  source=root/('byte-before-source-'+label+'.nano')
  source.write_text('fn main()->int { let bytes:array<u8> = [] let result:array<u8> = (array_push bytes '+expression+') return 0 }\n')
  output=root/f'byte-before-{producer}-{label}.nvm';prior=b'I preserve this prior product.';output.write_bytes(prior)
  result=subprocess.run([str(image.resolve()),str(source.resolve()),'-o',str(output.resolve())],capture_output=True)
  data=output.read_bytes() if output.is_file() else b''
  published=result.returncode==0 and data!=prior and bool(data)
  records.append(dict(producer=producer,compiler_sha256=digest(image.read_bytes()),source_bytes_hex=source.read_bytes().hex(),source_sha256=digest(source.read_bytes()),exit_code=result.returncode,stdout=result.stdout.decode(errors='replace'),stderr=result.stderr.decode(errors='replace'),prior_preserved=data==prior,published=published,publication_kind=('nanoisa' if data[:3]==b'NVM' else 'native'),output_bytes_hex=data.hex() if published else None,output_sha256=digest(data)))
assert {(r['producer'],r['source_sha256']) for r in records if r['published']}
assert sum(r['published'] for r in records)==4
value=dict(scope='I reconstruct the pre-fix checker/evaluator from hash-exact afca0a6a0 sources and link them privately with the current unchanged-interface provider closure. These are controlled reconstructed tools, not the original first-failure executable images. I do not replace production tools.',records=records)
(root/'byte-before-publications.json.gz').write_bytes(gzip.compress((json.dumps(value,separators=(',',':'))+'\n').encode(),mtime=0))
print('I retained four successful invalid-source publications from six reconstructed old-checker controls, with prior markers and actual product bytes.')
