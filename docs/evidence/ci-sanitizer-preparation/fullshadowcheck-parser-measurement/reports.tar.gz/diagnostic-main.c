#include "runtime/module_build_dir.h"
#include "runtime/dyn_array.h"
#include "runtime/shadow_timeout.h"
#include "runtime/shadow_completion.h"
#include "runtime/shadow_timing.h"
#include "nanovirt/shadow_runner.h"
#include "nanolang.h"
#include "file_source_resolution.h"
#include "colors.h"
#include "version.h"
#include "module_builder.h"
#include "shell_path.h"
#include "interpreter_ffi.h"
#include "reflection.h"
#include "emit_typed_ast.h"
#include "docgen_md.h"
#include "runtime/list_CompilerDiagnostic.h"
#include "toon_output.h"
#include "nanocore_subset.h"
#include "nanocore_export.h"
#include "locale.h"
#include "utf8.h"
#include "diag_id.h"
#include "catalog.h"
#include "ptx_backend.h"
#include "opencl_backend.h"
#include "c_backend.h"
#include "riscv_backend.h"
#include "bench.h"
#include "tco_pass.h"
#include "cps_pass.h"
#include "pgo_pass.h"
#include "stdlib_runtime.h"  /* profile_runtime_backend_* support policy */
#include <unistd.h>  /* For getpid(), execv() on all POSIX systems */
#include <limits.h>  /* For PATH_MAX */
#include <errno.h>   /* For errno/strerror in execv error reporting */
#include <signal.h>
#include <sys/wait.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>

#ifdef __APPLE__
#include <mach-o/loader.h>
#include <fcntl.h>
#endif

/* Global argc/argv for runtime access by transpiled programs */
int g_argc = 0;
char **g_argv = NULL;

static NlResolvedLocale g_process_locale;

static int collect_locale_cli(int argc, char **argv, const char **cli_tag,
                              int *print_locale) {
    int i;
    *cli_tag = NULL;
    *print_locale = 0;
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--print-locale") == 0) {
            *print_locale = 1;
        } else if (strcmp(argv[i], "--locale") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "nanoc: --locale requires a BCP 47 tag\n");
                return -1;
            }
            i++;
            *cli_tag = argv[i];
        }
    }
    return 0;
}

/* Structured JSON diagnostics (implemented in json_diagnostics.c).  Declared
 * here rather than including json_diagnostics.h because that header defines a
 * DiagnosticSeverity enum that conflicts with the one pulled in via
 * nanolang.h.  These entry points take no severity argument, so local extern
 * declarations are safe and match the pattern used in lsp_server.c. */
extern void json_diagnostics_init(void);
extern void json_diagnostics_enable(void);
extern void json_diagnostics_output(void);
extern void json_diagnostics_cleanup(void);

/* Compilation options */
typedef struct {
    bool verbose;
    bool keep_c;
    bool allow_temporary_files; /* Descriptive preparation only until source admission. */
    bool show_intermediate_code;
    bool test_imports;
    bool save_asm;            /* -S flag: save generated C to .genC file */
    bool json_errors;         /* Output errors in JSON format for tooling */
    bool profile_gprof;       /* -pg flag: enable gprof profiling support */
    bool profile;             /* --profile: inject timing hooks into generated C */
    bool trace;               /* --trace: inject generated-C function-call tracing hooks */
    bool coverage;            /* --coverage: instrument compiled output for gcov/lcov line+branch coverage */
    bool profile_runtime;     /* --profile-runtime: also emit flamegraph collapsed-stack .nano.prof */

    const char *profile_output_path;     /* --profile-output <path>: write structured profile JSON to file */
    const char *profile_flamegraph_path; /* --profile-runtime [<path>]: flamegraph .nano.prof output path */
    const char *llm_diags_json_path; /* --llm-diags-json <path> (agent-only): write diagnostics as JSON */
    const char *llm_diags_toon_path; /* --llm-diags-toon <path> (agent-only): write diagnostics as TOON (~40% fewer tokens) */
    const char *llm_shadow_json_path; /* --llm-shadow-json <path> (agent-only): write shadow failure summary as JSON */
    const char *reflect_output_path;  /* --reflect <path>: emit module API as JSON */
    bool emit_typed_ast;              /* --emit-typed-ast-json: emit typed AST as JSON to stdout */
    char **include_paths;      /* -I flags */
    int include_count;
    char **library_paths;     /* -L flags */
    int library_path_count;
    char **libraries;         /* -l flags */
    int library_count;
    /* Phase 3: Module safety warnings */
    bool warn_unsafe_imports;  /* Warn when importing unsafe modules */
    bool warn_unsafe_calls;    /* Warn when calling functions from unsafe modules */
    bool warn_ffi;             /* Warn on any FFI call */
    bool forbid_unsafe;        /* Error (not warn) on unsafe modules */
    bool trust_report;         /* --trust-report: print formal verification trust levels */
    bool reference_eval;       /* --reference-eval: cross-check with Coq-extracted interpreter */
    const char *target;        /* --target <name>: compile target */
    bool tco;                  /* --tco: enable tail-call optimization pass */
    const char *pgo_profile;   /* --pgo <path>: apply profile-guided inlining from .nano.prof */
    bool debug;                /* --debug / -g: emit debug information where supported */
    bool bench;                /* --bench: run @bench-annotated functions */
    uint64_t bench_n;          /* --bench-n <N>: fixed iteration count (0 = auto) */
    const char *bench_json;    /* --bench-json <path>: write JSON results to file */
    bool doc_md;               /* --doc-md / -dm: emit GFM Markdown API docs */
} CompilerOptions;

/* Return TMPDIR if set, otherwise "/tmp" (matches pattern in eval_io.c:177) */
static const char *get_tmp_dir(void) {
    const char *tmp = getenv("TMPDIR");
    if (!tmp || tmp[0] == '\0') tmp = "/tmp";
    return tmp;
}

/* Resolve the nanolang project root from the compiler binary path.
 * The binary lives at <root>/bin/nanoc_c, so we go up two levels.
 * Falls back to CWD if resolution fails. */
char g_project_root[PATH_MAX] = "";

const char *get_project_root(void) {
    return g_project_root[0] ? g_project_root : ".";
}

static bool resolve_project_root(void) {
    bool installed;
    return nano_native_sdk_root(g_project_root, sizeof(g_project_root), &installed) == NANO_SDK_OK &&
           nano_native_sdk_prepare() == NANO_SDK_OK;
}

static void json_escape(FILE *out, const char *s) {
    if (!s) return;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        unsigned char c = *p;
        switch (c) {
            case '\\': fputs("\\\\", out); break;
            case '"': fputs("\\\"", out); break;
            case '\n': fputs("\\n", out); break;
            case '\r': fputs("\\r", out); break;
            case '\t': fputs("\\t", out); break;
            default:
                if (c < 0x20) fprintf(out, "\\u%04x", (unsigned int)c);
                else fputc((int)c, out);
        }
    }
}

static const char *phase_name(int phase) {
    switch (phase) {
        case CompilerPhase_PHASE_LEXER: return "lexer";
        case CompilerPhase_PHASE_PARSER: return "parser";
        case CompilerPhase_PHASE_TYPECHECK: return "typecheck";
        case CompilerPhase_PHASE_LOWERING: return "lowering";
        case CompilerPhase_PHASE_RUNTIME: return "runtime";
        default: return "unknown";
    }
}

static const char *severity_name(int severity) {
    switch (severity) {
        case DiagnosticSeverity_DIAG_INFO: return "info";
        case DiagnosticSeverity_DIAG_WARNING: return "warning";
        case DiagnosticSeverity_DIAG_ERROR: return "error";
        default: return "unknown";
    }
}

static void llm_emit_diags_json(
    const char *path,
    const char *input_file,
    const char *output_file,
    int exit_code,
    List_CompilerDiagnostic *diags
) {
    if (!path || path[0] == '\0') return;

    FILE *f = fopen(path, "w");
    if (!f) return; /* best-effort */

    fprintf(f, "{");
    fprintf(f, "\"tool\":\"nanoc_c\",");
    fprintf(f, "\"success\":%s,", exit_code == 0 ? "true" : "false");
    fprintf(f, "\"exit_code\":%d,", exit_code);
    fprintf(f, "\"input_file\":\""); json_escape(f, input_file); fprintf(f, "\",");
    fprintf(f, "\"output_file\":\""); json_escape(f, output_file); fprintf(f, "\",");
    fprintf(f, "\"diagnostics\":[");

    int n = diags ? nl_list_CompilerDiagnostic_length(diags) : 0;
    for (int i = 0; i < n; i++) {
        CompilerDiagnostic d = nl_list_CompilerDiagnostic_get(diags, i);
        if (i > 0) fprintf(f, ",");
        fprintf(f, "{");
        fprintf(f, "\"code\":\""); json_escape(f, d.code); fprintf(f, "\",");
        fprintf(f, "\"message\":\""); json_escape(f, d.message); fprintf(f, "\",");
        fprintf(f, "\"phase\":%d,", d.phase);
        fprintf(f, "\"phase_name\":\"%s\",", phase_name(d.phase));
        fprintf(f, "\"severity\":%d,", d.severity);
        fprintf(f, "\"severity_name\":\"%s\",", severity_name(d.severity));
        fprintf(f, "\"location\":{");
        fprintf(f, "\"file\":\""); json_escape(f, d.location.file); fprintf(f, "\",");
        fprintf(f, "\"line\":%d,", d.location.line);
        fprintf(f, "\"column\":%d", d.location.column);
        fprintf(f, "}");
        fprintf(f, "}");
    }

    fprintf(f, "]}");
    fclose(f);
}

static void llm_emit_diags_toon(
    const char *path,
    const char *input_file,
    const char *output_file,
    int exit_code,
    List_CompilerDiagnostic *diags
) {
    if (!path || path[0] == '\0') return;
    if (!toon_diagnostics_enabled()) return;

    /* Populate TOON diagnostics from compiler diagnostics list */
    int n = diags ? nl_list_CompilerDiagnostic_length(diags) : 0;
    for (int i = 0; i < n; i++) {
        CompilerDiagnostic d = nl_list_CompilerDiagnostic_get(diags, i);
        toon_diagnostics_add(
            severity_name(d.severity),
            d.code,
            d.message,
            d.location.file,
            d.location.line,
            d.location.column
        );
    }

    /* Output to file */
    if (!toon_diagnostics_output_to_file(path, input_file, output_file, exit_code)) {
        /* best-effort, ignore failure */
    }

    toon_diagnostics_cleanup();
}

static void diags_push_simple(List_CompilerDiagnostic *diags, int phase, int severity, const char *code, const char *message) {
    if (!diags) return;
    CompilerDiagnostic d;
    d.phase = phase;
    d.severity = severity;
    d.code = (char*)nl_utf8_cstr_or_marker(code ? code : "C0000");
    d.message = (char*)nl_utf8_cstr_or_marker(message);
    d.location.file = (char*)"";
    d.location.line = 0;
    d.location.column = 0;
    nl_list_CompilerDiagnostic_push(diags, d);
}

static void diags_push_id(List_CompilerDiagnostic *diags, int phase, int severity, const char *id) {
    const char *en = nl_diag_en(id);
    /* JSON/TOON stay English. Human stderr uses nl_catalog_text. */
    diags_push_simple(diags, phase, severity, id, en ? en : id);
}

static void human_diag(const char *id) {
    fprintf(stderr, "%s\n", nl_catalog_text(id));
}

static void load_process_catalogs(const char *argv0) {
    const char *env = getenv("NANO_CATALOG_DIR");
    char path[4096];
    const char *slash;

    if (env && env[0] && nl_catalog_load_locale(&g_process_locale, env)) return;
    if (nl_catalog_load_locale(&g_process_locale, "catalogs/messages")) return;
    if (!argv0) return;
    slash = strrchr(argv0, '/');
    if (slash) {
        size_t n = (size_t)(slash - argv0);
        if (n + 32 < sizeof path) {
            memcpy(path, argv0, n);
            snprintf(path + n, sizeof path - n, "/../catalogs/messages");
            nl_catalog_load_locale(&g_process_locale, path);
        }
    }
}

static bool deterministic_outputs_enabled(void) {
    const char *v = getenv("NANO_DETERMINISTIC");
    return v && (strcmp(v, "1") == 0 || strcmp(v, "true") == 0 || strcmp(v, "yes") == 0);
}

/* I ask the filesystem whether stable output names identify one destination.
 * This preflight is not protection against concurrent path replacement. */
static int output_paths_alias(const char *artifact, const char *diagnostic,
                              bool *alias) {
    struct stat artifact_stat;
    struct stat diagnostic_stat;
    bool probe = false;
    int saved_errno;

    *alias = false;
    if (!artifact || !diagnostic || diagnostic[0] == '\0') return 0;

    if (stat(artifact, &artifact_stat) != 0) {
        if (errno != ENOENT) return -1;
        if (mkdir(artifact, 0700) != 0) return -1;
        probe = true;
        if (stat(artifact, &artifact_stat) != 0) {
            saved_errno = errno;
            if (rmdir(artifact) != 0) saved_errno = errno;
            errno = saved_errno;
            return -1;
        }
    }

    if (stat(diagnostic, &diagnostic_stat) == 0) {
        *alias = artifact_stat.st_dev == diagnostic_stat.st_dev &&
                 artifact_stat.st_ino == diagnostic_stat.st_ino;
    } else {
        saved_errno = errno;
        if (saved_errno == ENOENT) {
            /* I distinguish a missing entry from a dangling symlink. */
            if (lstat(diagnostic, &diagnostic_stat) == 0) saved_errno = EINVAL;
            else saved_errno = errno == ENOENT ? 0 : errno;
        }
        if (saved_errno != 0) {
            if (probe && rmdir(artifact) != 0) saved_errno = errno;
            errno = saved_errno;
            return -1;
        }
    }

    if (probe && rmdir(artifact) != 0) return -1;
    return 0;
}

static int reject_artifact_diagnostic_aliases(const char *artifact,
                                               const CompilerOptions *opts) {
    const char *diagnostics[] = {
        opts->profile_output_path,
        opts->profile_flamegraph_path,
        opts->llm_diags_json_path,
        opts->llm_diags_toon_path,
        opts->llm_shadow_json_path,
        opts->reflect_output_path,
        opts->bench_json
    };

    for (size_t i = 0; i < sizeof(diagnostics) / sizeof(diagnostics[0]); i++) {
        bool alias;
        if (output_paths_alias(artifact, diagnostics[i], &alias) != 0) {
            fprintf(stderr,
                    "nanoc: I cannot verify that artifact '%s' and diagnostic '%s' are distinct: %s\n",
                    artifact, diagnostics[i] ? diagnostics[i] : "", strerror(errno));
            return -1;
        }
        if (alias) {
            fprintf(stderr,
                    "nanoc: I require separate outputs; artifact '%s' and diagnostic '%s' identify the same destination\n",
                    artifact, diagnostics[i]);
            return -1;
        }
    }
    return 0;
}

#ifdef __APPLE__
static int determinize_macho_uuid_and_signature(const char *path) {
    /* On modern macOS, Mach-O binaries are ad-hoc signed and include a randomized LC_UUID.
     * For deterministic bootstrap verification we:
     *  1) overwrite the LC_UUID bytes with a fixed value
     *  2) re-sign with a fixed identifier so the LC_CODE_SIGNATURE blob is deterministic
     */
    int fd = open(path, O_RDWR);
    if (fd < 0) return -1;

    struct mach_header_64 hdr;
    ssize_t n = pread(fd, &hdr, sizeof(hdr), 0);
    if (n != (ssize_t)sizeof(hdr) || hdr.magic != MH_MAGIC_64) {
        close(fd);
        return -1;
    }

    off_t off = (off_t)sizeof(hdr);
    for (uint32_t i = 0; i < hdr.ncmds; i++) {
        struct load_command lc;
        if (pread(fd, &lc, sizeof(lc), off) != (ssize_t)sizeof(lc) || lc.cmdsize < sizeof(lc)) {
            close(fd);
            return -1;
        }

        if (lc.cmd == LC_UUID) {
            struct uuid_command uc;
            if (lc.cmdsize < sizeof(uc) || pread(fd, &uc, sizeof(uc), off) != (ssize_t)sizeof(uc)) {
                close(fd);
                return -1;
            }

            static const uint8_t fixed_uuid[16] = {
                0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF,
                0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10
            };
            memcpy(uc.uuid, fixed_uuid, sizeof(fixed_uuid));

            if (pwrite(fd, &uc, sizeof(uc), off) != (ssize_t)sizeof(uc)) {
                close(fd);
                return -1;
            }
            break;
        }

        off += (off_t)lc.cmdsize;
    }

    close(fd);

    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "codesign -s - --force -i nanolang.deterministic '%s' >/dev/null 2>&1", path);
    return system(cmd);
}
#endif

static bool check_interpreted_shadows(ASTNode *program, Environment *env,
                                      ModuleList *modules, const char *input,
                                      CompilerOptions *opts) {
    if (opts->llm_shadow_json_path) {
        FILE *report = fopen(opts->llm_shadow_json_path, "w");
        if (!report) {
            fprintf(stderr, "I cannot initialize the shadow report: %s\n", strerror(errno));
            return false;
        }
        fputs("{\"tool\":\"nanoc_c\",\"success\":false,\"completed\":false,"
              "\"test_count\":null,\"failures\":[]}\n", report);
        bool report_ok = !ferror(report);
        if (fclose(report) != 0) report_ok = false;
        if (!report_ok) {
            fprintf(stderr, "I cannot write the shadow report.\n");
            return false;
        }
    }
    int shadow_seconds = nl_shadow_timeout_seconds(10);
    if (shadow_seconds < 0) return false;
    int completion[2];
    if (pipe(completion) != 0) {
        fprintf(stderr, "I cannot create the shadow completion channel.\n");
        return false;
    }
    if (fcntl(completion[0], F_SETFL, O_NONBLOCK) < 0 ||
        fcntl(completion[0], F_SETFD, FD_CLOEXEC) < 0 ||
        fcntl(completion[1], F_SETFD, FD_CLOEXEC) < 0) {
        close(completion[0]);
        close(completion[1]);
        fprintf(stderr, "I cannot configure the shadow completion channel.\n");
        return false;
    }
    nl_shadow_timing("parent_before_fork", -1, -1, 0, 1, 0);
    fflush(NULL);
    /* I share the exact start with the child; fork time consumes the budget. */
    struct timespec start, now, pause = {0, 10000000};
    if (clock_gettime(CLOCK_MONOTONIC, &start) != 0) {
        close(completion[0]);
        close(completion[1]);
        fprintf(stderr, "I cannot measure the shadow execution deadline.\n");
        return false;
    }
    pid_t child = fork();
    if (child == 0) {
        close(completion[0]);
        /* I isolate compiler state, not host authority. */
        signal(SIGALRM, SIG_DFL);
        alarm((unsigned)shadow_seconds);
        if (dup2(STDERR_FILENO, STDOUT_FILENO) < 0) _exit(1);
        nl_shadow_timing("callback_start", -1, -1, 0, 0, 0);
        int callback_status = check_callback_shadows(program, env, modules, input,
                                                     opts->test_imports);
        nl_shadow_timing("callback_end", -1, -1, 0, 0, callback_status);
        bool passed = callback_status != 0 ? callback_status > 0 :
            run_shadow_tests_scope(program, env, modules, input,
                                   opts->test_imports, opts->verbose);
        nl_shadow_timing("selection_end", -1, -1, 0, 0, passed ? 0 : 1);
        if (callback_status != 0 && opts->llm_shadow_json_path) {
            FILE *report = fopen(opts->llm_shadow_json_path, "w");
            if (!report) passed = false;
            else {
                bool written = fprintf(report,
                    "{\"tool\":\"nanoc_c\",\"backend\":\"nano_vm\","
                    "\"success\":%s,\"completed\":true}\n",
                    passed ? "true" : "false") >= 0;
                if (fclose(report) != 0 || !written) passed = false;
            }
        }
        if (fflush(NULL) != 0) passed = false;
        NlShadowCompletion done = {0};
        done.tag = NL_SHADOW_COMPLETION_TAG;
        if (passed && clock_gettime(CLOCK_MONOTONIC, &done.finished) != 0)
            passed = false;
        if (passed && write(completion[1], &done, sizeof(done)) != (ssize_t)sizeof(done))
            passed = false;
        /* I perform no program, callback, flush or observer work after publication. */
        close(completion[1]);
        _exit(passed ? 0 : 1);
    }
    int fork_error = errno;
    close(completion[1]);
    if (child < 0) {
        close(completion[0]);
        fprintf(stderr, "I cannot start shadow execution: %s\n", strerror(fork_error));
        return false;
    }
    bool timed_out = false, clock_failed = false;
    int status = 0;
    pid_t waited;
    for (;;) {
        waited = waitpid(child, &status, WNOHANG);
        if (waited == child || (waited < 0 && errno != EINTR)) break;
        clock_failed = clock_gettime(CLOCK_MONOTONIC, &now) != 0;
        timed_out = !clock_failed && (now.tv_sec - start.tv_sec > shadow_seconds ||
            (now.tv_sec - start.tv_sec == shadow_seconds && now.tv_nsec >= start.tv_nsec));
        if (clock_failed || timed_out) {
            kill(child, SIGKILL);
            do { waited = waitpid(child, &status, 0); } while (waited < 0 && errno == EINTR);
            break;
        }
        nanosleep(&pause, NULL);
    }
    int wait_error = errno;
    nl_shadow_timing("parent_after_wait", -1, -1, 0, 1, waited < 0 ? -1 : status);
    NlShadowCompletion done = {0};
    ssize_t received = read(completion[0], &done, sizeof(done));
    close(completion[0]);
    size_t record_bytes = received < 0 ? 0 : (size_t)received;
    bool completed = nl_shadow_completion_ontime(&done, record_bytes, &start,
                                                  shadow_seconds);
    if (waited < 0) {
        fprintf(stderr, "I cannot supervise shadow execution: %s\n", strerror(wait_error));
        return false;
    }
    if (!nl_shadow_completion_accept(&done, record_bytes, &start, shadow_seconds,
                                     clock_failed, waited < 0, status)) {
        if (clock_failed)
            fprintf(stderr, "I cannot measure the shadow execution deadline.\n");
        else if (timed_out || (!completed && nl_shadow_completion_valid(
                              &done, record_bytes, &start, shadow_seconds)) ||
                 (WIFSIGNALED(status) && WTERMSIG(status) == SIGALRM))
            fprintf(stderr, "I stopped shadow execution after %d seconds.\n", shadow_seconds);
        else
            fprintf(stderr, "I will not publish output after failed shadow execution.\n");
        return false;
    }
    return true;
}

/* Compile nanolang source to executable */
static int compile_file(const char *input_file, const char *output_file, CompilerOptions *opts) {
    List_CompilerDiagnostic *diags = nl_list_CompilerDiagnostic_new();

    if (opts->allow_temporary_files) {
        NlFileResolution *prepared = NULL;
        NlFileResolutionReport report = nl_file_source_resolve(input_file, &prepared);
        if (report.status != NL_FILE_RESOLUTION_NONE) {
            if (report.status == NL_FILE_RESOLUTION_PREPARED)
                fprintf(stderr, "I prepared File source declarations; source lowering is not admitted.\n");
            else fprintf(stderr, "I cannot prepare complete File source declarations: %d\n", (int)report.status);
            nl_file_source_resolution_free(prepared);
            nl_list_CompilerDiagnostic_free(diags);
            return 1;
        }
    }
    /* Read source file */
    FILE *file = fopen(input_file, "rb");
    if (!file) {
        fprintf(stderr, "%s: %s\n", nl_catalog_text(NL_DIAG_IO_OPEN),
                nl_utf8_cstr_or_marker(input_file));
        diags_push_id(diags, CompilerPhase_PHASE_LEXER, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_IO_OPEN);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    fseek(file, 0, SEEK_SET);
    if (size < 0) {
        fprintf(stderr, "%s: %s\n", nl_catalog_text(NL_DIAG_IO_OPEN),
                nl_utf8_cstr_or_marker(input_file));
        fclose(file);
        diags_push_id(diags, CompilerPhase_PHASE_LEXER, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_IO_OPEN);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }

    char *source = malloc(size + 1);
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-result"
    fread(source, 1, size, file);
#pragma GCC diagnostic pop
    source[size] = '\0';
    fclose(file);

    {
        size_t utf8_off = 0;
        if (!nl_utf8_validate(source, (size_t)size, &utf8_off)) {
            fprintf(stderr, "%s: %s (byte offset %zu)\n",
                    nl_catalog_text(NL_DIAG_SRC_UTF8),
                    nl_utf8_cstr_or_marker(input_file), utf8_off);
            diags_push_id(diags, CompilerPhase_PHASE_LEXER,
                          DiagnosticSeverity_DIAG_ERROR, NL_DIAG_SRC_UTF8);
            free(source);
            llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
            llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
            nl_list_CompilerDiagnostic_free(diags);
            return 1;
        }
    }

    if (opts->verbose) printf("Compiling %s...\n", input_file);

    /* Phase 1: Lexing */
    int token_count = 0;
    Token *tokens = tokenize(source, &token_count);
    if (!tokens) {
        human_diag(lexer_last_error_id());
        diags_push_id(diags, CompilerPhase_PHASE_LEXER, DiagnosticSeverity_DIAG_ERROR, lexer_last_error_id());
        free(source);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }
    if (opts->verbose) printf("✓ Lexing complete (%d tokens)\n", token_count);

    /* Phase 2: Parsing */
    ASTNode *program = parse_program(tokens, token_count);
    if (!program) {
        human_diag(parser_last_error_id());
        diags_push_id(diags, CompilerPhase_PHASE_PARSER, DiagnosticSeverity_DIAG_ERROR, parser_last_error_id());
        free_tokens(tokens, token_count);
        free(source);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }
    if (opts->verbose) printf("✓ Parsing complete\n");

    /* Phase 3: Create environment and process imports */
    clear_module_cache();  /* Clear cache from any previous compilation */
    Environment *env = create_environment();
    
    /* Set warning flags from compiler options */
    env->warn_unsafe_imports = opts->warn_unsafe_imports;
    env->warn_unsafe_calls = opts->warn_unsafe_calls;
    env->warn_ffi = opts->warn_ffi;
    env->forbid_unsafe = opts->forbid_unsafe;
    env->profile_gprof = opts->profile_gprof;
    env->profile = opts->profile;
    env->trace = opts->trace;
    env->profile_runtime = opts->profile_runtime;
    env->profile_flamegraph_path = opts->profile_flamegraph_path;
    env->gpu_target = (opts->target &&
        (strcmp(opts->target, "ptx") == 0 || strcmp(opts->target, "opencl") == 0));


    env->profile_output_path = opts->profile_output_path;
    
    ModuleList *modules = create_module_list();
    if (!process_imports(program, env, modules, input_file)) {
        human_diag(NL_DIAG_IMPORT_FAILED);
        diags_push_id(diags, CompilerPhase_PHASE_PARSER, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_IMPORT_FAILED);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }
    if (opts->verbose && modules->count > 0) {
        printf("✓ Loaded %d module(s)\n", modules->count);
    }

    /* Compile modules early so extern C functions are available for shadow tests (via FFI). */
    char *module_objs = NULL;
    char module_compile_flags[2048] = "";

    /* Enable structured JSON diagnostics when the caller requested them via
     * --json-errors.  Only the typechecker feeds json_error()/json_warning(),
     * so we enable right before it and flush/free immediately after, keeping
     * the earlier failure paths allocation-free. */
    if (opts->json_errors) {
        json_diagnostics_enable();
        json_diagnostics_init();
    }

    /* Phase 4: Type Checking */
    typecheck_set_current_file(input_file);
    env_set_current_file(env, input_file);
    /* Use type_check_module if reflection or doc-md is requested (no main needed) */
    bool typecheck_success = (opts->reflect_output_path || opts->doc_md) ?
        type_check_module(program, env) :
        type_check(program, env);
    if (typecheck_success) {
        int production_symbols = env->symbol_count;
        fprintf(stderr,
            "NANO_DIAGNOSTIC_SCOPE_BEFORE functions=%d symbols=%d structs=%d enums=%d unions=%d tuple_bindings=%zu\n",
            env->function_count, env->symbol_count, env->struct_count,
            env->enum_count, env->union_count, env->tuple_literal_binding_count);
        typecheck_success = type_check_shadow_scope(program, env, modules, input_file, true);
        if (typecheck_success) {
            int diagnostic_imported_shadows = 0;
            for (int diagnostic_i = 0; diagnostic_i < modules->count; ++diagnostic_i) {
                ASTNode *diagnostic_module = get_cached_module_ast(modules->module_paths[diagnostic_i]);
                if (!diagnostic_module || diagnostic_module->type != AST_PROGRAM) continue;
                for (int diagnostic_j = 0; diagnostic_j < diagnostic_module->as.program.count; ++diagnostic_j)
                    if (diagnostic_module->as.program.items[diagnostic_j]->type == AST_SHADOW)
                        ++diagnostic_imported_shadows;
            }
            fprintf(stderr,
                "NANO_DIAGNOSTIC_FULL_SHADOW_CHECK modules=%d imported_shadows=%d functions=%d symbols=%d structs=%d enums=%d unions=%d tuple_bindings=%zu\n",
                modules->count, diagnostic_imported_shadows, env->function_count,
                env->symbol_count, env->struct_count, env->enum_count,
                env->union_count, env->tuple_literal_binding_count);
        }
        /* I do not lower shadow bodies in this backend. Their checked local
         * declarations must not replace production metadata by short name. */
        for (int i = production_symbols; i < env->symbol_count; i++) {
            free(env->symbols[i].name);
            free(env->symbols[i].struct_type_name);
        }
        env->symbol_count = production_symbols;
    }
    
    if (!typecheck_success) {
        human_diag(NL_DIAG_TYPE_FAILED);
        diags_push_id(diags, CompilerPhase_PHASE_TYPECHECK, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_TYPE_FAILED);
        if (opts->json_errors) {
            json_diagnostics_output();
            json_diagnostics_cleanup();
        }
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }
    if (opts->json_errors) {
        /* Typechecking succeeded: flush any warnings collected and release
         * the diagnostics buffer so the JSON subsystem is left clean. */
        json_diagnostics_output();
        json_diagnostics_cleanup();
    }
    if (opts->verbose) printf("✓ Type checking complete\n");

    /* ── Profile-Guided Optimization (inlining) ───────────────────────── */
    if (opts->pgo_profile) {
        PGOProfile *pgo = pgo_load_profile(opts->pgo_profile);
        if (pgo) {
            int sites = pgo_apply(program, pgo);
            if (opts->verbose || sites > 0)
                printf("✓ PGO pass: %d call site(s) inlined from %s\n",
                       sites, opts->pgo_profile);
            if (opts->verbose) pgo_print_report(pgo);
            pgo_profile_free(pgo);
        } else {
            fprintf(stderr, "warning: --pgo: could not load profile %s\n",
                    opts->pgo_profile);
        }
    }

    /* ── Auto-TCO for pure fn (always on — pure fns cannot use loops) ── */
    {
        int pure_tco = tco_pass_pure(program);
        if (opts->verbose && pure_tco > 0)
            printf("✓ Auto-TCO: %d pure fn(s) transformed\n", pure_tco);
    }

    /* ── Tail-Call Optimization pass ─────────────────────────────────── */
    if (opts->tco) {
        tco_pass(program);
        if (opts->verbose) printf("✓ TCO pass complete\n");
    }

    /* ── CPS transform pass (async/await) — always runs ──────────────── */
    {
        int async_count = cps_pass(program);
        if (opts->verbose && async_count > 0)
            printf("✓ CPS pass: %d async function(s) transformed\n", async_count);
    }

    /* ── PTX target: emit .ptx text and exit ────────────────────────── */
    if (opts->target && strcmp(opts->target, "ptx") == 0) {
        const char *ptx_out = output_file;
        char ptx_out_buf[PATH_MAX];
        if (!ptx_out) {
            strncpy(ptx_out_buf, input_file, PATH_MAX - 5);
            ptx_out_buf[PATH_MAX - 5] = '\0';
            char *dot = strrchr(ptx_out_buf, '.');
            if (dot) *dot = '\0';
            strcat(ptx_out_buf, ".ptx");
            ptx_out = ptx_out_buf;
        }
        if (opts->verbose) printf("Emitting PTX → %s\n", ptx_out);
        int ptx_rc = ptx_backend_emit(program, ptx_out, input_file, opts->verbose);
        if (ptx_rc == 0) {
            printf("✓ PTX assembly emitted to %s\n", ptx_out);
            printf("  Load with: cuModuleLoad(&mod, \"%s\");\n", ptx_out);
            printf("  Or compile: nvcc -ptx %s -o %s.cubin\n", ptx_out, ptx_out);
        }
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return ptx_rc;
    }

    /* ── OpenCL target: emit .cl kernel source and exit ─────────────── */
    if (opts->target && strcmp(opts->target, "opencl") == 0) {
        const char *cl_out = output_file;
        char cl_out_buf[PATH_MAX];
        if (!cl_out) {
            strncpy(cl_out_buf, input_file, PATH_MAX - 4);
            cl_out_buf[PATH_MAX - 4] = '\0';
            char *dot = strrchr(cl_out_buf, '.');
            if (dot) *dot = '\0';
            strcat(cl_out_buf, ".cl");
            cl_out = cl_out_buf;
        }
        if (opts->verbose) printf("Emitting OpenCL C → %s\n", cl_out);
        int cl_rc = ocl_backend_emit(program, cl_out, input_file, opts->verbose);
        if (cl_rc == 0) {
            printf("✓ OpenCL C kernel emitted to %s\n", cl_out);
            printf("  Load with: clCreateProgramWithSource + clBuildProgram\n");
            printf("  CPU fallback: set POCL_DEVICES=cpu (POCL required)\n");
        }
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return cl_rc;
    }

    /* ── C target: emit .c source file and exit ─────────────────────── */
    if (opts->target && strcmp(opts->target, "c") == 0) {
        const char *c_out = output_file;
        char c_out_buf[PATH_MAX];
        if (!c_out) {
            strncpy(c_out_buf, input_file, PATH_MAX - 3);
            c_out_buf[PATH_MAX - 3] = '\0';
            char *dot = strrchr(c_out_buf, '.');
            if (dot) *dot = '\0';
            strcat(c_out_buf, ".c");
            c_out = c_out_buf;
        }
        if (opts->verbose) printf("Emitting C → %s\n", c_out);
        CBOptions cb_opts = {0}; cb_opts.verbose = opts->verbose;
        int c_rc = c_backend_emit(program, c_out, input_file, &cb_opts);
        if (c_rc == 0 && opts->verbose) {
            printf("✓ C source emitted to %s\n", c_out);
            printf("  Compile with: gcc -std=c11 %s -o prog\n", c_out);
        }
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return c_rc;
    }

    /* ── RISC-V target: emit .s assembly and exit ─────────────────────── */
    if (opts->target && strcmp(opts->target, "riscv") == 0) {
        const char *rv_out = output_file;
        char rv_out_buf[PATH_MAX];
        if (!rv_out) {
            strncpy(rv_out_buf, input_file, PATH_MAX - 3);
            rv_out_buf[PATH_MAX - 3] = '\0';
            char *dot = strrchr(rv_out_buf, '.');
            if (dot) *dot = '\0';
            strcat(rv_out_buf, ".s");
            rv_out = rv_out_buf;
        }
        if (opts->verbose) printf("Emitting RISC-V asm → %s\n", rv_out);
        int rv_rc = riscv_backend_emit(program, rv_out, input_file,
                                       opts->verbose, opts->debug);
        if (rv_rc == 0) {
            printf("✓ RISC-V assembly emitted to %s\n", rv_out);
            printf("  Assemble: riscv64-unknown-elf-gcc -nostdlib %s -o %s.elf\n",
                   rv_out, rv_out_buf);
        } else {
            fprintf(stderr, "RISC-V backend failed\n");
        }
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return rv_rc;
    }

    /* ── Bench mode: run @bench-annotated functions ──────────────────── */
    if (opts->bench) {
        BenchOptions bopts = {
            .n_iters       = opts->bench_n,
            .output_format = opts->bench_json ? BENCH_FMT_JSON : BENCH_FMT_HUMAN,
            .json_out_path = opts->bench_json,
            .backend       = opts->target ? opts->target : "native",
            .verbose       = opts->verbose,
        };
        FILE *json_out = NULL;
        if (opts->bench_json) {
            json_out = fopen(opts->bench_json, "w");
            if (!json_out)
                fprintf(stderr, "[bench] Cannot open %s for writing\n",
                        opts->bench_json);
        }
        int bench_rc = bench_run_program(program, env, &bopts, input_file, json_out);
        if (json_out) fclose(json_out);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return bench_rc;
    }

    /* Phase 4.1: Trust Report (if requested) */
    if (opts->trust_report) {
        TrustReport *report = nanocore_trust_report(program, env);
        if (report) {
            nanocore_print_trust_report(report, input_file);
            nanocore_free_trust_report(report);
        }
        /* Clean up and exit - trust report is an analysis-only mode */
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return 0;
    }

    /* Phase 4.2: Reference Eval — cross-check with Coq-extracted interpreter */
    if (opts->reference_eval) {
        printf("NanoCore Reference Evaluation: %s\n", input_file);
        printf("Cross-checking verified functions against Coq-extracted interpreter\n\n");

        /* Walk all functions and export verified ones */
        int checked = 0, matched = 0, failed = 0, skipped = 0;
        for (int i = 0; i < program->as.program.count; i++) {
            ASTNode *item = program->as.program.items[i];
            if (!item || item->type != AST_FUNCTION) continue;
            if (item->as.function.is_extern) continue;

            const char *fname = item->as.function.name;
            TrustLevel level = nanocore_function_trust(item, env);

            if (level != TRUST_VERIFIED) {
                skipped++;
                continue;
            }

            /* Export entire function (wrapped in lambdas) to S-expression */
            char *sexpr = nanocore_export_sexpr(item, env);
            if (!sexpr) {
                printf("  %-30s [skip] could not export to S-expression\n", fname);
                skipped++;
                continue;
            }

            /* Call reference interpreter */
            char *ref_result = nanocore_reference_eval(sexpr, g_argv[0]);
            if (ref_result) {
                printf("  %-30s [ok]   ref=%s\n", fname, ref_result);
                matched++;
                free(ref_result);
            } else {
                printf("  %-30s [warn] reference interpreter unavailable\n", fname);
                failed++;
            }

            free(sexpr);
            checked++;
        }

        printf("\nSummary: %d checked, %d matched, %d warnings, %d skipped (not verified)\n",
               checked, matched, failed, skipped);

        env_require_destroyable(env);

        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return 0;
    }

    /* Phase 4.4: Module Reflection (if requested) */
    if (opts->reflect_output_path) {
        /* Extract module name from input file */
        const char *module_name = strrchr(input_file, '/');
        module_name = module_name ? module_name + 1 : input_file;
        /* Remove .nano extension if present */
        char *name_copy = strdup(module_name);
        char *dot = strrchr(name_copy, '.');
        if (dot && strcmp(dot, ".nano") == 0) {
            *dot = '\0';
        }
        
        if (opts->verbose) printf("→ Emitting module reflection to %s\n", opts->reflect_output_path);
        
        if (!emit_module_reflection(opts->reflect_output_path, program, env, name_copy)) {
            fprintf(stderr, "Error: Failed to emit module reflection\n");
            free(name_copy);
            env_require_destroyable(env);
            free_ast(program);
            free_tokens(tokens, token_count);
            free_environment(env);
            free_module_list(modules);
            free(source);
            llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
            nl_list_CompilerDiagnostic_free(diags);
            return 1;
        }
        
        if (opts->verbose) printf("✓ Module reflection complete\n");
        free(name_copy);
        
        /* Clean up and exit - no need to compile when reflecting */
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return 0;
    }

    /* Phase 4.42: Emit GFM Markdown docs (--doc-md) */
    if (opts->doc_md) {
        /* Extract module name from input file */
        const char *module_name = strrchr(input_file, '/');
        module_name = module_name ? module_name + 1 : input_file;
        char *name_copy = strdup(module_name);
        char *dot = strrchr(name_copy, '.');
        if (dot && strcmp(dot, ".nano") == 0) *dot = '\0';

        /* Determine output path: use -o if provided, else <module>.md */
        char md_out_buf[512];
        const char *md_out = output_file;
        /* output_file defaults to TMPDIR/nanoc_a.out; treat that as "not set" */
        {
            char default_prefix[64];
            snprintf(default_prefix, sizeof(default_prefix), "%s/nanoc_a.out",
                     get_tmp_dir());
            if (strcmp(md_out, default_prefix) == 0) {
                snprintf(md_out_buf, sizeof(md_out_buf), "%s.md", name_copy);
                md_out = md_out_buf;
            }
        }

        if (opts->verbose) printf("→ Emitting Markdown docs to %s\n", md_out);

        if (!emit_doc_md(md_out, program, source, name_copy)) {
            fprintf(stderr, "Error: Failed to emit Markdown docs\n");
            free(name_copy);
            env_require_destroyable(env);
            free_ast(program);
            free_tokens(tokens, token_count);
            free_environment(env);
            free_module_list(modules);
            free(source);
            nl_list_CompilerDiagnostic_free(diags);
            return 1;
        }

        if (opts->verbose) printf("✓ Markdown docs written to %s\n", md_out);
        free(name_copy);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return 0;
    }

    /* Phase 4.45: Emit typed AST as JSON (if requested) */
    if (opts->emit_typed_ast) {
        emit_typed_ast_json(input_file, program, env);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        free(source);
        nl_list_CompilerDiagnostic_free(diags);
        return 0;
    }

    /* Phase 4.5: Build imported modules (object + shared libs) */
    if (modules->count > 0) {
        if (opts->keep_c) nano_native_retain_private_work();
        if (!compile_modules(modules, env, &module_objs,
                             module_compile_flags, sizeof(module_compile_flags),
                             opts->verbose)) {
            fprintf(stderr, "Error: Failed to compile modules\n");
            diags_push_id(diags, CompilerPhase_PHASE_PARSER, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_MOD_COMPILE);
            env_require_destroyable(env);
            free_ast(program);
            free_tokens(tokens, token_count);
            free_environment(env);
            free_module_list(modules);
            clear_module_cache();
            free(source);
            llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
            llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
            nl_list_CompilerDiagnostic_free(diags);
            free(module_objs);
            return 1;
        }
    }

    /* Phase 4.6: Initialize FFI and load module shared libraries for shadow tests */
    (void)ffi_init(opts->verbose);
    for (int i = 0; i < modules->count; i++) {
        const char *module_path = modules->module_paths[i];

        char *module_dir = strdup(module_path);
        char *last_slash = strrchr(module_dir, '/');
        if (last_slash) {
            *last_slash = '\0';
        } else {
            free(module_dir);
            module_dir = strdup(".");
        }

        ModuleBuildMetadata *meta = module_load_metadata(module_dir);

        char mod_name[256];
        if (meta && meta->name) {
            snprintf(mod_name, sizeof(mod_name), "%s", meta->name);
        } else {
            const char *base_name = last_slash ? last_slash + 1 : module_path;
            snprintf(mod_name, sizeof(mod_name), "%s", base_name);
            char *dot = strrchr(mod_name, '.');
            if (dot) *dot = '\0';
        }

        (void)ffi_load_module(mod_name, module_path, env, opts->verbose);

        if (meta) module_metadata_free(meta);
        free(module_dir);
    }

    /* Phase 5: Shadow-Test Execution (Compile-Time Function Execution) */
    if (opts->llm_shadow_json_path && opts->llm_shadow_json_path[0] != '\0') {
        setenv("NANO_LLM_SHADOW_JSON", opts->llm_shadow_json_path, 1);
    } else {
        unsetenv("NANO_LLM_SHADOW_JSON");
    }
    if (!check_interpreted_shadows(program, env, modules, input_file, opts)) {
        human_diag(NL_DIAG_SHADOW_FAILED);
        diags_push_id(diags, CompilerPhase_PHASE_RUNTIME, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_SHADOW_FAILED);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        ffi_cleanup();
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        unsetenv("NANO_LLM_SHADOW_JSON");
        free(module_objs);
        return 1;
    }
    if (opts->verbose) printf("✓ Shadow tests passed\n");
    unsetenv("NANO_LLM_SHADOW_JSON");

    /* Phase 5.5: Ensure module ASTs are in cache for declaration generation */
    /* Module compilation uses isolated caches that get cleared, so we need to
     * re-load modules into the main cache before transpilation so that
     * generate_module_function_declarations() can find them. */
    if (modules->count > 0) {
        if (opts->verbose) printf("Ensuring module ASTs are cached for declaration generation...\n");
        for (int i = 0; i < modules->count; i++) {
            const char *module_path = modules->module_paths[i];
            if (module_path) {
                /* Load module into cache (won't re-parse if already loaded) */
                ASTNode *module_ast = load_module(module_path, env);
                if (!module_ast) {
                    fprintf(stderr, "Warning: Failed to load module '%s' for declaration generation\n", module_path);
                }
            }
        }
        if (opts->verbose) printf("✓ Module ASTs cached\n");
    }

    /* Phase 6: C Transpilation */
    if (opts->verbose) printf("Transpiling to C...\n");
    char *c_code = transpile_to_c(program, env, input_file);
    if (!c_code) {
        human_diag(NL_DIAG_TRANS_FAILED);
        diags_push_id(diags, CompilerPhase_PHASE_LOWERING, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_TRANS_FAILED);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        ffi_cleanup();
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        free(module_objs);
        return 1;
    }
    
    /* Calculate C code size */
    size_t c_code_size = strlen(c_code);
    int c_code_lines = 1;
    for (size_t i = 0; i < c_code_size; i++) {
        if (c_code[i] == '\n') c_code_lines++;
    }
    
    if (opts->verbose) {
        printf("✓ Transpilation complete (%d lines of C, %zu bytes)\n", c_code_lines, c_code_size);
    }

    if (opts->show_intermediate_code) {
        fwrite(c_code, 1, c_code_size, stdout);
        fflush(stdout);
    }
    
    /* Save generated C to .genC file if -S flag is set */
    if (opts->save_asm) {
        char gen_c_file[512];
        snprintf(gen_c_file, sizeof(gen_c_file), "%s.genC", input_file);
        FILE *gen_c = fopen(gen_c_file, "w");
        if (gen_c) {
            fprintf(gen_c, "%s", c_code);
            fclose(gen_c);
            if (opts->verbose) {
                printf("✓ Saved generated C to: %s\n", gen_c_file);
            }
        } else {
            fprintf(stderr, "Warning: Could not save generated C to %s\n", gen_c_file);
        }
    }

    /* Write C code to temporary file in /tmp (or keep in output dir if --keep-c) */
    char temp_c_file[512];
    if (opts->keep_c) {
        /* Keep in output directory if --keep-c is set */
        snprintf(temp_c_file, sizeof(temp_c_file), "%s.c", output_file);
    } else {
        /* Use TMPDIR (or /tmp) for temporary files */
        snprintf(temp_c_file, sizeof(temp_c_file), "%s/nanoc_%d_%s.c",
                 get_tmp_dir(), (int)getpid(), strrchr(output_file, '/') ? strrchr(output_file, '/') + 1 : output_file);
    }

    FILE *c_file = fopen(temp_c_file, "w");
    if (!c_file) {
        fprintf(stderr, "%s: %s\n", nl_catalog_text(NL_DIAG_C_TEMP),
                nl_utf8_cstr_or_marker(temp_c_file));
        diags_push_id(diags, CompilerPhase_PHASE_LOWERING, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_C_TEMP);
        free(c_code);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        free(module_objs);
        return 1;
    }

    fprintf(c_file, "%s", c_code);
    fclose(c_file);
    if (opts->verbose) printf("✓ Generated C code: %s\n", temp_c_file);

    enum { NATIVE_FINAL_COMMAND_BYTES = 65536 }; /* Inclusive of the trailing NUL. */
    char *compile_cmd = NULL;
    
    /* Build include flags */
    char include_flags[8192] = "";
    char root_include[4096];
    int root_length = snprintf(root_include, sizeof(root_include), "%s/src", get_project_root());
    bool include_paths_valid = root_length >= 0 && (size_t)root_length < sizeof(root_include);
    include_paths_valid = module_append_include(include_flags, sizeof(include_flags), root_include) && include_paths_valid;
    for (int i = 0; i < opts->include_count; i++) {
        include_paths_valid = module_append_include(include_flags, sizeof(include_flags), opts->include_paths[i]) && include_paths_valid;
    }
    
    /* Add module directories to include path (for FFI headers) */
    /* This enables standalone tools to import modules like "modules/std/fs.nano" */
    /* and have the C compiler find the corresponding "fs.h" header */
    if (modules && modules->count > 0) {
        /* Track unique directories to avoid duplicates */
        char **unique_dirs = malloc(sizeof(char*) * modules->count);
        int unique_count = 0;
        
        for (int i = 0; i < modules->count; i++) {
            const char *module_path = modules->module_paths[i];
            if (!module_path) continue;
            
            /* Extract directory from module path */
            char dir_path[512];
            if (strlen(module_path) >= sizeof(dir_path)) {
                include_paths_valid = false;
                continue;
            }
            strncpy(dir_path, module_path, sizeof(dir_path) - 1);
            dir_path[sizeof(dir_path) - 1] = '\0';
            
            /* Find last slash to get directory */
            char *last_slash = strrchr(dir_path, '/');
            if (last_slash) {
                *last_slash = '\0';  /* Trim filename to get directory */
                
                /* Check if this directory is already in the list */
                bool already_added = false;
                for (int j = 0; j < unique_count; j++) {
                    if (strcmp(unique_dirs[j], dir_path) == 0) {
                        already_added = true;
                        break;
                    }
                }
                
                if (!already_added) {
                    unique_dirs[unique_count] = strdup(dir_path);
                    unique_count++;
                    
                    /* Add -I flag for this directory */
                    include_paths_valid = module_append_include(include_flags, sizeof(include_flags), dir_path) && include_paths_valid;
                    
                    if (opts->verbose) {
                        printf("Adding module include path: %s\n", dir_path);
                    }
                }
            }
        }
        
        /* Free unique_dirs */
        for (int i = 0; i < unique_count; i++) {
            free(unique_dirs[i]);
        }
        free(unique_dirs);
    }
    
    /* Add module compile flags (include paths from pkg-config) */
    if (module_compile_flags[0] != '\0') {
        size_t used = strlen(include_flags);
        int written = snprintf(include_flags + used, sizeof(include_flags) - used,
                               " %s", module_compile_flags);
        include_paths_valid = written >= 0 && (size_t)written < sizeof(include_flags) - used && include_paths_valid;
    }
    
    /* Build library path flags */
    char lib_path_flags[2048] = "";
    for (int i = 0; i < opts->library_path_count; i++) {
        include_paths_valid = module_append_path_flag(lib_path_flags, sizeof(lib_path_flags), "-L", opts->library_paths[i]) && include_paths_valid;
    }
    
    /* Build library flags */
    char lib_flags[2048] = "-lm";
#ifdef __linux__
    strcat(lib_flags, " -ldl"); /* I resolve native array ABI declarations. */
#endif
    for (int i = 0; i < opts->library_count; i++) {
        include_paths_valid = module_append_path_flag(lib_flags, sizeof(lib_flags), "-l", opts->libraries[i]) && include_paths_valid;
    }
    
    /* Detect and generate generic list types from the C code AND compiler_schema.h */
    char generated_lists[1024] = "";
    char generated_directory[4096];
    int generated_length = snprintf(generated_directory, sizeof(generated_directory),
                                    "%s/nanolang-lists-XXXXXX", get_tmp_dir());
    bool generated_ready = generated_length >= 0 && (size_t)generated_length < sizeof(generated_directory) &&
                           mkdtemp(generated_directory) != NULL;
    if (!generated_ready) generated_directory[0] = 0;
    include_paths_valid = include_paths_valid && generated_ready;
    char detected_types[64][64]; /* Increased to handle more types */
    int detected_count = 0;
    
    /* First, scan compiler_schema.h if it exists */
    FILE *schema_h = fopen("src/generated/compiler_schema.h", "r");
    if (schema_h) {
        fseek(schema_h, 0, SEEK_END);
        long size = ftell(schema_h);
        fseek(schema_h, 0, SEEK_SET);
        char *schema_content = malloc(size + 1);
        if (schema_content) {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-result"
            fread(schema_content, 1, size, schema_h);
#pragma GCC diagnostic pop
            schema_content[size] = '\0';
            
            const char *ptr = schema_content;
            while ((ptr = strstr(ptr, "List_")) != NULL) {
                ptr += 5;
                const char *end = ptr;
                while ((*end >= 'A' && *end <= 'Z') || (*end >= 'a' && *end <= 'z') || (*end >= '0' && *end <= '9') || *end == '_') {
                    end++;
                }
                if (*end == '*' || *end == ' ' || *end == '\n' || *end == ';') {
                    size_t len = (size_t)(end - ptr);
                    char type_name[64];
                    if (!len || len >= sizeof(type_name)) {
                        include_paths_valid = false;
                        fprintf(stderr, "I cannot represent this schema list wrapper name.\n");
                        continue;
                    }
                    memcpy(type_name, ptr, len);
                    type_name[len] = '\0';
                    
                    if (strcmp(type_name, "int") != 0 && strcmp(type_name, "string") != 0 && strcmp(type_name, "token") != 0 && strcmp(type_name, "Generic") != 0) {
                        bool found = false;
                        for (int i = 0; i < detected_count; i++) {
                            if (strcmp(detected_types[i], type_name) == 0) {
                                found = true;
                                break;
                            }
                        }
                        if (!found && detected_count < 64) {
                            strcpy(detected_types[detected_count++], type_name);
                        }
                    }
                }
            }
            free(schema_content);
        }
        fclose(schema_h);
    }

    const char *scan_ptr = c_code;
    /* Scan for List_TypeName* patterns in generated code too */
    while ((scan_ptr = strstr(scan_ptr, "List_")) != NULL) {
        scan_ptr += 5; /* Skip "List_" */
        const char *end_ptr = scan_ptr;
        
        /* Extract type name (alphanumeric + underscore) */
        while ((*end_ptr >= 'A' && *end_ptr <= 'Z') || 
               (*end_ptr >= 'a' && *end_ptr <= 'z') || 
               (*end_ptr >= '0' && *end_ptr <= '9') || 
               *end_ptr == '_') {
            end_ptr++;
        }
        
        /* Check if followed by * or space (valid list type) */
        if (*end_ptr == '*' || *end_ptr == ' ' || *end_ptr == '\n') {
            size_t len = (size_t)(end_ptr - scan_ptr);
            char provider_type_name[256];
            if (!len || len >= sizeof(provider_type_name)) {
                include_paths_valid = false;
                fprintf(stderr, "I cannot represent this native list specialization name.\n");
                continue;
            }
            memcpy(provider_type_name, scan_ptr, len);
            provider_type_name[len] = '\0';
            /* I emitted the complete provider in the translation unit itself. */
            char provider_marker[300];
            snprintf(provider_marker, sizeof(provider_marker), "NL_DEFINE_RECORD_LIST(%s,", provider_type_name);
            if (strstr(c_code, provider_marker)) continue;
            if (len >= sizeof(detected_types[0])) {
                include_paths_valid = false;
                fprintf(stderr, "I cannot represent this legacy external list wrapper name.\n");
                continue;
            }
            
            char type_name[sizeof(detected_types[0])];
            memcpy(type_name, provider_type_name, len + 1);

            /* Skip built-in types */
            if (strcmp(type_name, "int") == 0 || 
                strcmp(type_name, "string") == 0 || 
                strcmp(type_name, "token") == 0) {
                continue;
            }
            
            /* Check if already detected */
            bool already_detected = false;
            for (int i = 0; i < detected_count; i++) {
                if (strcmp(detected_types[i], type_name) == 0) {
                    already_detected = true;
                    break;
                }
            }
            
            if (!already_detected && detected_count < 32) {
                snprintf(detected_types[detected_count], 64, "%s", type_name);
                detected_count++;
                
                /* Check if this type already has a runtime list implementation.
                 * If so, skip wrapper generation to avoid duplicate symbols —
                 * the runtime file is already linked via runtime_basenames[]. */
                char runtime_list_path[8192];
                snprintf(runtime_list_path, sizeof(runtime_list_path),
                         "%s/src/runtime/list_%s.c", get_project_root(), type_name);
                if (access(runtime_list_path, F_OK) == 0) {
                    if (opts->verbose) {
                        printf("Skipping List<%s> wrapper — runtime implementation exists at %s\n",
                               type_name, runtime_list_path);
                    }
                    continue;
                }
                
                /* Check if the transpiler already generated inline list code */
                char inline_check[128];
                snprintf(inline_check, sizeof(inline_check), "nl_list_%s_new", type_name);
                if (strstr(c_code, inline_check) != NULL) {
                    if (opts->verbose) {
                        printf("Skipping List<%s> wrapper — inline implementation in transpiled code\n",
                               type_name);
                    }
                    continue;
                }
                
                /* Generate list runtime files */
                const char *c_type = type_name;
                char nl_prefixed_type[128];
                if (strcmp(type_name, "LexerToken") == 0) c_type = "Token";
                else if (strcmp(type_name, "NSType") == 0) c_type = "NSType";
                else if (strncmp(type_name, "AST", 3) == 0 || strncmp(type_name, "Compiler", 8) == 0) {
                    c_type = type_name;
                } else {
                    snprintf(nl_prefixed_type, sizeof(nl_prefixed_type), "nl_%s", type_name);
                    c_type = nl_prefixed_type;
                }
                
                if (!generated_ready || !nano_native_generate_list(get_project_root(), generated_directory, type_name, c_type)) {
                    fprintf(stderr, "I could not generate the required List<%s> runtime\n", type_name);
                    include_paths_valid = false;
                    break;
                }

                /* Create wrapper that includes struct definition */
                char wrapper_file[8192];
                snprintf(wrapper_file, sizeof(wrapper_file), "%s/list_%s_wrapper.c", generated_directory, type_name);
                FILE *wrapper = fopen(wrapper_file, "w");
                if (wrapper) {
                    /* Extract struct definition from generated C code */
                    const char *struct_search = c_code;
                    char struct_pattern[128];
                    snprintf(struct_pattern, sizeof(struct_pattern), "typedef struct nl_%s {", type_name);
                    const char *struct_start = strstr(struct_search, struct_pattern);
                    const char *struct_start_original = struct_start;
                    
                    /* Try to find guards if they exist */
                    char guard_pattern[128];
                    snprintf(guard_pattern, sizeof(guard_pattern), "#ifndef DEFINED_nl_%s", type_name);
                    const char *guard_start = strstr(struct_search, guard_pattern);
                    if (guard_start && guard_start < struct_start) {
                        struct_start = guard_start;
                    }
                    
                    if (struct_start) {
                        /* Find the end of the struct (closing brace + semicolon) */
                        const char *struct_end = struct_start;
                        int brace_count = 0;
                        bool found_open_brace = false;
                        while (*struct_end) {
                            if (*struct_end == '{') {
                                found_open_brace = true;
                                brace_count++;
                            } else if (*struct_end == '}' && found_open_brace) {
                                brace_count--;
                                if (brace_count == 0) {
                                    /* Found the closing brace, look for semicolon */
                                    struct_end++;
                                    while (*struct_end && *struct_end != ';') struct_end++;
                                    if (*struct_end == ';') struct_end++;
                                    
                                    /* Look for #endif if we started with a guard */
                                    if (guard_start && guard_start < struct_start_original) {
                                        const char *endif_search = strstr(struct_end, "#endif");
                                        if (endif_search) {
                                            struct_end = endif_search + 6;
                                        }
                                    }
                                    break;
                                }
                            }
                            struct_end++;
                        }
                        
                        /* Write the wrapper */
                        fprintf(wrapper, "#include <stdint.h>\n");
                        fprintf(wrapper, "#include <stdbool.h>\n");
                        fprintf(wrapper, "#include <stdlib.h>\n");
                        fprintf(wrapper, "#include <stdio.h>\n");
                        fprintf(wrapper, "#include <string.h>\n\n");
                        /* Needed for DynArray/nl_string_t/Token used by extracted structs */
                        fprintf(wrapper, "#include \"nanolang.h\"\n");
                        fprintf(wrapper, "#include \"generated/compiler_schema.h\"\n\n");
                        fprintf(wrapper, "/* Struct definition extracted from main file */\n");
                        fprintf(wrapper, "%.*s\n", (int)(struct_end - struct_start), struct_start);
                        /* Set guard macro to prevent typedef redefinition in list header */
                        char type_upper[128];
                        strncpy(type_upper, type_name, sizeof(type_upper) - 1);
                        type_upper[sizeof(type_upper) - 1] = '\0';
                        for (char *p = type_upper; *p; p++) {
                            *p = (char)nl_ascii_toupper((unsigned char)*p);
                        }
                        fprintf(wrapper, "\n/* Guard macro set - typedef already defined above */\n");
                        fprintf(wrapper, "#define NL_%s_DEFINED\n\n", type_upper);
                        fprintf(wrapper, "/* Include list implementation */\n");
                        fprintf(wrapper, "#include \"list_%s.c\"\n", type_name);
                    } else {
                        /* Fallback: just include the list file.
                         * We include schema headers in case it's a schema type. */
                        fprintf(wrapper, "#include <stdint.h>\n");
                        fprintf(wrapper, "#include <stdbool.h>\n");
                        fprintf(wrapper, "#include <stdlib.h>\n");
                        fprintf(wrapper, "#include <stdio.h>\n");
                        fprintf(wrapper, "#include <string.h>\n\n");
                        fprintf(wrapper, "#include \"nanolang.h\"\n");
                        fprintf(wrapper, "#include \"generated/compiler_schema.h\"\n\n");
                        fprintf(wrapper, "#include \"list_%s.c\"\n", type_name);
                    }
                    if (ferror(wrapper)) include_paths_valid = false;
                    if (fclose(wrapper)) include_paths_valid = false;
                } else {
                    include_paths_valid = false;
                }
                
                /* Add wrapper to compile list */
                char list_file[256];
                int list_length = snprintf(list_file, sizeof(list_file), "%s/list_%s_wrapper.c", generated_directory, type_name);
                if (list_length < 0 || (size_t)list_length >= sizeof(list_file)) include_paths_valid = false;
                include_paths_valid = module_append_path_flag(generated_lists, sizeof(generated_lists), "", list_file) && include_paths_valid;
            }
        }
    }
    
    if (opts->verbose && detected_count > 0) {
        printf("Detected %d generic list type(s): ", detected_count);
        for (int i = 0; i < detected_count; i++) {
            printf("%s%s", detected_types[i], i < detected_count - 1 ? ", " : "");
        }
        printf("\n");
    }
    
    /* Build runtime files string (paths relative to project root) */
    /* Note: sdl_helpers.c is NOT included here - it's provided by the sdl_helpers module */
    static const char *runtime_basenames[] = {
        "runtime/list_int.c", "runtime/list_string.c", "runtime/list_LexerToken.c",
        "runtime/list_token.c", "runtime/list_CompilerDiagnostic.c",
        "runtime/list_CompilerSourceLocation.c", "runtime/list_ASTNumber.c",
        "runtime/list_ASTFloat.c", "runtime/list_ASTString.c", "runtime/list_ASTBool.c",
        "runtime/list_ASTIdentifier.c", "runtime/list_ASTBinaryOp.c",
        "runtime/list_ASTCall.c", "runtime/list_ASTModuleQualifiedCall.c",
        "runtime/list_ASTArrayLiteral.c", "runtime/list_ASTLet.c", "runtime/list_ASTSet.c",
        "runtime/list_ASTStmtRef.c", "runtime/list_ASTIf.c", "runtime/list_ASTWhile.c",
        "runtime/list_ASTFor.c", "runtime/list_ASTReturn.c", "runtime/list_ASTBlock.c",
        "runtime/list_ASTUnsafeBlock.c", "runtime/list_ASTPrint.c",
        "runtime/list_ASTAssert.c", "runtime/list_ASTFunction.c",
        "runtime/list_ASTShadow.c", "runtime/list_ASTStruct.c",
        "runtime/list_ASTStructLiteral.c", "runtime/list_ASTFieldAccess.c",
        "runtime/list_ASTEnum.c", "runtime/list_ASTUnion.c",
        "runtime/list_ASTUnionConstruct.c", "runtime/list_ASTMatch.c",
        "runtime/list_ASTImport.c", "runtime/list_ASTOpaqueType.c", "runtime/list_ASTServiceDecl.c",
        "runtime/list_ASTTupleLiteral.c", "runtime/list_ASTTupleIndex.c",
        "runtime/token_helpers.c", "runtime/gc.c", "runtime/effect_runtime.c", "runtime/dyn_array.c",
        "runtime/gc_struct.c", "runtime/nl_string.c", "runtime/cli.c", "runtime/regex.c",
        "utf8.c",
        "coroutine.c",
        NULL
    };
    char runtime_files[65536];
    runtime_files[0] = '\0';
    for (int i = 0; runtime_basenames[i]; i++) {
        char entry[8192];
        int entry_length = snprintf(entry, sizeof(entry), "%s/src/%s",
                                    get_project_root(), runtime_basenames[i]);
        if (entry_length < 0 || (size_t)entry_length >= sizeof(entry)) include_paths_valid = false;
        include_paths_valid = module_append_path_flag(runtime_files, sizeof(runtime_files), "", entry) && include_paths_valid;
    }
    if (strlen(generated_lists) >= sizeof(runtime_files) - strlen(runtime_files)) include_paths_valid = false;
    else strcat(runtime_files, generated_lists);

    /* Add TMPDIR to include path for generated list headers */
    char include_flags_with_tmp[12288];
    snprintf(include_flags_with_tmp, sizeof(include_flags_with_tmp), "%s", include_flags);
    include_paths_valid = module_append_include(include_flags_with_tmp, sizeof(include_flags_with_tmp), generated_directory) && include_paths_valid;
    
    const char *cc = getenv("NANO_CC");
    if (!cc) cc = getenv("CC");
    if (!cc) cc = "cc";

    const char *export_dynamic_flag = "";
#ifdef __linux__
    export_dynamic_flag = "-rdynamic";
#elif defined(__FreeBSD__)
    export_dynamic_flag = "-Wl,-E";
#endif

    /* Profiling flags for gprof support (-pg option) */
    const char *profile_flags = "";
    if (opts->profile_gprof) {
        profile_flags = "-pg -g -fno-omit-frame-pointer -fno-optimize-sibling-calls";
        if (opts->verbose) {
            printf("Profiling enabled: adding %s\n", profile_flags);
        }
    }

    /* Coverage flags for gcov/lcov line+branch coverage (--coverage option) */
    const char *coverage_flags = "";
    if (opts->coverage) {
        coverage_flags = "-fprofile-arcs -ftest-coverage -fno-inline";
        if (opts->verbose) {
            printf("Coverage instrumentation enabled: adding %s\n", coverage_flags);
        }
    }

    /* Extra C flags from environment — set NANO_CFLAGS to inject flags into every compilation.
     * Example: NANO_CFLAGS="-pg" make launcher  — instruments the launcher and every example it builds. */
    const char *nano_cflags = getenv("NANO_CFLAGS");
    if (!nano_cflags) nano_cflags = "";

    char *quoted_output = module_quote_path(output_file);
    char *quoted_temp_source = module_quote_path(temp_c_file);
    const char *compile_format = "%s -std=c99 -Wall -Wextra -Werror -Wno-error=unused-function -Wno-error=unused-parameter -Wno-error=unused-variable -Wno-error=unused-but-set-variable -Wno-error=logical-not-parentheses -Wno-error=duplicate-decl-specifier %s %s %s %s %s -o %s %s %s %s %s %s";
    int cmd_len = quoted_output && quoted_temp_source ? snprintf(NULL, 0,
            compile_format, cc, profile_flags, coverage_flags, nano_cflags, include_flags_with_tmp, export_dynamic_flag, quoted_output, quoted_temp_source, module_objs ? module_objs : "", runtime_files, lib_path_flags, lib_flags) : -1;
    int formatted = -1;
    if (include_paths_valid && cmd_len >= 0 && (size_t)cmd_len < NATIVE_FINAL_COMMAND_BYTES) {
        /* This bound proves the NUL addition fits before I allocate. */
        size_t command_bytes = (size_t)cmd_len + 1;
        compile_cmd = malloc(command_bytes);
        if (compile_cmd) formatted = snprintf(compile_cmd, command_bytes,
            compile_format, cc, profile_flags, coverage_flags, nano_cflags, include_flags_with_tmp, export_dynamic_flag, quoted_output, quoted_temp_source, module_objs ? module_objs : "", runtime_files, lib_path_flags, lib_flags);
    }
    free(quoted_output);
    free(quoted_temp_source);
    free(module_objs);
    
    if (!include_paths_valid || !compile_cmd || formatted != cmd_len) {
        free(compile_cmd);
        human_diag(NL_DIAG_CC_CMD);
        fprintf(stderr, "I could not represent all compiler arguments (%d command bytes, limit %zu).\n", cmd_len, (size_t)NATIVE_FINAL_COMMAND_BYTES);
        fprintf(stderr, "Try reducing the number of modules or shortening paths.\n");
        diags_push_id(diags, CompilerPhase_PHASE_LOWERING, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_CC_CMD);
        if (!opts->keep_c) nano_native_remove_private_tree(generated_directory);
        free(c_code);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        if (!opts->keep_c) {
            remove(temp_c_file);
        }
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;
    }

    if (opts->verbose) printf("Compiling C code: %s\n", compile_cmd);
    int result = system(compile_cmd);
    free(compile_cmd);

    if (result == 0) {
        if (deterministic_outputs_enabled()) {
#ifdef __APPLE__
            (void)determinize_macho_uuid_and_signature(output_file);
#endif
        }
        if (opts->verbose) printf("✓ Compilation successful: %s\n", output_file);
    } else {
        human_diag(NL_DIAG_CC_FAILED);
        diags_push_id(diags, CompilerPhase_PHASE_LOWERING, DiagnosticSeverity_DIAG_ERROR, NL_DIAG_CC_FAILED);
        /* Cleanup */
        if (!opts->keep_c) nano_native_remove_private_tree(generated_directory);
        free(c_code);
        env_require_destroyable(env);
        free_ast(program);
        free_tokens(tokens, token_count);
        free_environment(env);
        free_module_list(modules);
        clear_module_cache();
        free(source);
        /* Remove temporary C file unless --keep-c */
        if (!opts->keep_c) {
            remove(temp_c_file);
        }
        llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 1, diags);
        llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 1, diags);
        nl_list_CompilerDiagnostic_free(diags);
        return 1;  /* Return error if C compilation failed */
    }

    /* Remove temporary C file unless --keep-c (cleanup on both success and failure) */
    if (!opts->keep_c) {
        remove(temp_c_file);
    }

    llm_emit_diags_json(opts->llm_diags_json_path, input_file, output_file, 0, diags);
    llm_emit_diags_toon(opts->llm_diags_toon_path, input_file, output_file, 0, diags);
    nl_list_CompilerDiagnostic_free(diags);

    /* Cleanup */
    if (!opts->keep_c) nano_native_remove_private_tree(generated_directory);
    free(c_code);
    env_require_destroyable(env);
    free_ast(program);
    free_tokens(tokens, token_count);
    free_environment(env);
    free_module_list(modules);
    clear_module_cache();  /* Free all cached module ASTs */
    free(source);
    ffi_cleanup();

    return 0;  /* Success */
}

/* Main entry point */
int main(int argc, char *argv[]) {
    /* Store argc/argv for runtime access */
    g_argc = argc;
    g_argv = argv;

    /* Resolve project root from binary location (enables compilation from any CWD) */
    if (argc == 2 && strcmp(argv[1], "--native-array-abi") == 0) {
        printf("%u\n", NANO_DYN_ARRAY_ABI_VERSION);
        return 0;
    }
    if (!resolve_project_root()) {
        fprintf(stderr, "I require a complete compatible native SDK or source root\n");
        return 1;
    }
    
    /* Handle --version */
    if (argc >= 2 && (strcmp(argv[1], "--version") == 0 || strcmp(argv[1], "-v") == 0)) {
        printf("nanoc %s\n", NANOLANG_VERSION);
        printf("nanolang compiler\n");
        printf("Built: %s %s\n", NANOLANG_BUILD_DATE, NANOLANG_BUILD_TIME);
        return 0;
    }

    /* Handle --help */
    if (argc >= 2 && (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0)) {
        printf("nanoc - Compiler for the nanolang programming language\n\n");
        printf("Usage: %s [OPTIONS] <input.nano>\n", argv[0]);
        printf("       %s --print-locale [--locale <tag>]\n\n", argv[0]);
        printf("Options:\n");
        printf("  -o <file>      Specify output file (default: $TMPDIR/nanoc_a.out)\n");
        printf("  --verbose      Show detailed compilation steps and commands\n");
        printf("                 (also enabled by NANO_VERBOSE_BUILD=1 env var)\n");
        printf("  --allow-temporary-files  Prepare File source facts only; source execution remains held\n");
        printf("  --keep-c       Keep generated C file (saves to output dir instead of /tmp)\n");
        printf("  -fshow-intermediate-code  Print generated C to stdout\n");
        printf("  -S             Save generated C to <input>.genC (for inspection)\n");
        printf("  --json-errors  Output errors in JSON format for tool integration\n");
        printf("  --reflect <path>  Emit module API as JSON (for documentation generation)\n");
        printf("  -I <path>      Add include path for C compilation\n");
        printf("  -L <path>      Add library path for C linking\n");
        printf("  -l <lib>       Link against library (e.g., -lSDL2)\n");
        printf("  -pg            Enable gprof profiling (adds -g -fno-omit-frame-pointer)\n");
        printf("  --profile      Inject timing hooks; print hotspot report (sorted by total time)\n");
        printf("  --trace        Inject generated-C function-call tracing hooks (stderr).\n");
        printf("                 Shares one startup hook with --profile; NANO_TRACE=0 disables\n");
        printf("                 collection at runtime without recompiling.\n");
        printf("  --profile-output <p>  Write structured profiling JSON to file <p> (use with -pg)\n");
        printf("  --coverage     Instrument compiled output for gcov/lcov line+branch coverage\n");
        printf("                 Run: gcov <source.c>, or use 'make coverage-report' for HTML\n");
        printf("  --profile-runtime     Implies --profile; also write flamegraph collapsed-stack\n");
        printf("                 .nano.prof (default: <output_binary>.nano.prof). Compatible with\n");
        printf("                 flamegraph.pl: flamegraph.pl <bin>.nano.prof > flame.svg\n");
        printf("                 Native target only — errors out under --target, which\n");
        printf("                 emit artifacts nanoc never runs and so cannot profile.\n");
        printf("  --profile-runtime-output <p>  Set explicit path for flamegraph .nano.prof output\n");
        printf("  --target <t>   Compile target: native (default), ptx, opencl, c, riscv\n");
        printf("                 ptx:    emit NVIDIA PTX assembly for `gpu fn` functions\n");
        printf("                 opencl: emit OpenCL C kernel source (.cl) for `gpu fn` functions\n");
        printf("                         CPU fallback via POCL when no GPU present\n");
        printf("  --tco          Enable tail-call optimization (rewrite tail recursion to loops)\n");
        printf("  --debug / -g   Emit debug info where the selected target supports it\n");
        printf("  --bench        Run @bench-annotated functions (micro-benchmark mode)\n");
        printf("  --bench-n <N>  Fixed iteration count (default: auto-calibrate to ~1s)\n");
        printf("  --bench-json <f> Write JSON benchmark results to file\n");
        printf("                          clang -O2 prog.ll -o prog\n");
        printf("  --pgo <file>   Profile-guided inlining: read .nano.prof from a native\n");
        printf("                 --profile-runtime build, identify hot call sites and inline\n");
        printf("                 them. Combines with --tco.\n");
        printf("                 Example: nanoc --profile-runtime prog.nano -o prog\n");
        printf("                          ./prog                    # generates prog.nano.prof\n");
        printf("                          nanoc --pgo prog.nano.prof prog.nano -o prog_opt\n");
        printf("  install [pkg@range ...]\n");
        printf("                 Install nano packages from the registry (nanoc-install.sh)\n");
        printf("                 Reads nano.packages.json + writes nano.lock\n");
        printf("                 Example: nanoc install gpu-math@^1.0.0 nano-core@latest\n");
        printf("  add [pkg@range ...]\n");
        printf("                 Add package(s) to nano.packages.json and install them\n");
        printf("                 Example: nanoc add gpu-math@^1.0.0\n");
        printf("  --version, -v  Show version information\n");
        printf("  --help, -h     Show this help message\n");
        printf("  --locale <tag> BCP 47 language tag (overrides NANO_LOCALE, LC_ALL, LANG)\n");
        printf("  --print-locale Print resolved locale axes and exit (no compile)\n");
        printf("\nVerification Options:\n");
        printf("  --trust-report         Show formal verification trust levels for all functions\n");
        printf("  --reference-eval       Cross-check verified functions with Coq-extracted interpreter\n");
        printf("\nSafety Options:\n");
        printf("  --warn-unsafe-imports  Warn when importing unsafe modules\n");
        printf("  --warn-unsafe-calls    Warn when calling functions from unsafe modules\n");
        printf("  --warn-ffi             Warn on any FFI (extern function) call\n");
        printf("  --forbid-unsafe        Error (not warn) on unsafe module imports\n");
        printf("\nAgent Options:\n");
        printf("  --llm-diags-json <p>   Write machine-readable diagnostics JSON (agent-only)\n");
        printf("  --llm-diags-toon <p>   Write diagnostics in TOON format (~40%% fewer tokens)\n");
        printf("  --llm-shadow-json <p>  Write machine-readable shadow failure summary JSON (agent-only)\n");
        printf("  --test-imports        I run dependency shadows before root shadows (default)\n");
        printf("  --root-shadows-only   I run only root-file shadows\n");
        printf("\nExamples:\n");
        printf("  %s hello.nano -o hello\n", argv[0]);
        printf("  %s program.nano --verbose -S          # Show steps and save C code\n", argv[0]);
        printf("  %s example.nano -o example --verbose\n", argv[0]);
        printf("  %s sdl_app.nano -o app -I/opt/homebrew/include/SDL2 -L/opt/homebrew/lib -lSDL2\n\n", argv[0]);
        return 0;
    }

    /* Handle 'install' and 'add' subcommands — delegates to scripts/nanoc-install.sh */
    if (argc >= 2 && (strcmp(argv[1], "install") == 0 || strcmp(argv[1], "add") == 0)) {
        bool add_mode = (strcmp(argv[1], "add") == 0);
        const char *install_suffix = "/scripts/nanoc-install.sh";
        char *install_script = NULL;
        const char *nano_root = getenv("NANOLANG_ROOT");
        if (nano_root) {
            size_t len = strlen(nano_root) + strlen(install_suffix) + 1;
            install_script = malloc(len);
            if (install_script) { strcpy(install_script, nano_root); strcat(install_script, install_suffix); }
        }
        if (!install_script || 0) {
            /* Fall back: look relative to argv[0] */
            free(install_script);
            char *argv0_copy = strdup(argv[0]);
            char *last_slash = strrchr(argv0_copy, '/');
            if (last_slash) { *last_slash = '\0';
                size_t len = strlen(argv0_copy) + strlen(install_suffix) + 1;
                install_script = malloc(len);
                if (install_script) { strcpy(install_script, argv0_copy); strcat(install_script, install_suffix); }
            }
            free(argv0_copy);
            if (!install_script) install_script = strdup("./scripts/nanoc-install.sh");
        }
        /* Build argv for install script */
        size_t script_argc = (size_t)argc + (add_mode ? 1 : 0);
        const char **script_argv = malloc((script_argc + 1) * sizeof(char *));
        if (!script_argv) { perror("malloc"); free(install_script); return 1; }
        script_argv[0] = install_script;
        size_t out_idx = 1;
        if (add_mode) {
            script_argv[out_idx++] = "--save";
        }
        for (int i = 2; i < argc; i++) {
            script_argv[out_idx++] = argv[i];
        }
        script_argv[out_idx] = NULL;
        execv(install_script, (char *const *)script_argv);
        fprintf(stderr, "nanoc %s: could not exec %s: %s\n", add_mode ? "add" : "install", install_script, strerror(errno));
        fprintf(stderr, "Ensure nanoc-install.sh is in scripts/ relative to NANOLANG_ROOT.\n");
        free(script_argv);
        free(install_script);
        return 1;
    }

    {
        const char *cli_tag = NULL;
        int print_locale = 0;
        char locale_buf[1024];
        if (collect_locale_cli(argc, argv, &cli_tag, &print_locale) != 0)
            return 1;
        if (!nl_locale_resolve(cli_tag, &g_process_locale)) {
            fprintf(stderr, "nanoc: invalid locale tag\n");
            return 1;
        }
        if (print_locale) {
            nl_locale_format(&g_process_locale, locale_buf, sizeof locale_buf);
            fputs(locale_buf, stdout);
            return 0;
        }
        load_process_catalogs(argv[0]);
    }

    if (argc < 2) {
        fprintf(stderr, "Usage: %s [OPTIONS] <input.nano>\n", argv[0]);
        fprintf(stderr, "Try '%s --help' for more information.\n", argv[0]);
        return 1;
    }

    const char *input_file = NULL;
    /* Default output to TMPDIR (or /tmp) to avoid polluting project dir */
    char default_output[512];
    snprintf(default_output, sizeof(default_output), "%s/nanoc_a.out", get_tmp_dir());
    const char *output_file = default_output;
    CompilerOptions opts = {
        .verbose = false,
        .keep_c = false,
        .show_intermediate_code = false,
        .test_imports = true,
        .save_asm = false,
        .json_errors = false,
        .profile_gprof = false,
        .profile = false,
        .trace = false,
        .coverage = false,
        .profile_runtime = false,

        .profile_output_path = NULL,
        .profile_flamegraph_path = NULL,
        .llm_diags_json_path = NULL,
        .llm_diags_toon_path = NULL,
        .llm_shadow_json_path = NULL,
        .reflect_output_path = NULL,
        .include_paths = NULL,
        .include_count = 0,
        .library_paths = NULL,
        .library_path_count = 0,
        .libraries = NULL,
        .library_count = 0,
        .warn_unsafe_imports = false,
        .warn_unsafe_calls = false,
        .warn_ffi = false,
        .forbid_unsafe = false,
        .trust_report = false,
        .reference_eval = false,
        .target = NULL,
        .pgo_profile = NULL,
        .debug = false,
        .doc_md = false
    };
    
    /* Allocate arrays for flags */
    char **include_paths = malloc(sizeof(char*) * 32);
    char **library_paths = malloc(sizeof(char*) * 32);
    char **libraries = malloc(sizeof(char*) * 32);
    int include_count = 0;
    int library_path_count = 0;
    int library_count = 0;

    /* Parse command-line options. Flags may precede the input file. */
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] != '-') {
            if (input_file) {
                fprintf(stderr, "Unknown option: %s\n", argv[i]);
                fprintf(stderr, "Try '%s --help' for more information.\n", argv[0]);
                free(include_paths);
                free(library_paths);
                free(libraries);
                return 1;
            }
            input_file = argv[i];
            continue;
        }
        if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
            output_file = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--verbose") == 0) {
            opts.verbose = true;
        } else if (strcmp(argv[i], "--allow-temporary-files") == 0) {
            opts.allow_temporary_files = true;
        } else if (strcmp(argv[i], "--keep-c") == 0) {
            opts.keep_c = true;
        } else if (strcmp(argv[i], "-fshow-intermediate-code") == 0) {
            opts.show_intermediate_code = true;
        } else if (strcmp(argv[i], "-S") == 0) {
            opts.save_asm = true;
        } else if (strcmp(argv[i], "--json-errors") == 0) {
            opts.json_errors = true;
        } else if (strcmp(argv[i], "-pg") == 0) {
            opts.profile_gprof = true;
        } else if (strcmp(argv[i], "--profile") == 0) {
            opts.profile = true;

        } else if (strcmp(argv[i], "--trace") == 0) {
            opts.trace = true;

        } else if (strcmp(argv[i], "--coverage") == 0) {
            opts.coverage = true;

        } else if (strcmp(argv[i], "--profile-runtime") == 0) {
            opts.profile = true;        /* --profile-runtime implies --profile */
            opts.profile_runtime = true;
            /* path via --profile-runtime-output; leave flamegraph_path NULL for auto-derive */

        } else if (strcmp(argv[i], "--profile-runtime-output") == 0 && i + 1 < argc) {
            opts.profile_flamegraph_path = argv[i + 1];
            i++;

        } else if (strcmp(argv[i], "--profile-output") == 0 && i + 1 < argc) {
            opts.profile_output_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "-I") == 0 && i + 1 < argc) {
            if (include_count < 32) {
                include_paths[include_count++] = argv[i + 1];
            }
            i++;
        } else if (strncmp(argv[i], "-I", 2) == 0) {
            /* Handle -I/path form */
            if (include_count < 32) {
                include_paths[include_count++] = argv[i] + 2;
            }
        } else if (strcmp(argv[i], "-L") == 0 && i + 1 < argc) {
            if (library_path_count < 32) {
                library_paths[library_path_count++] = argv[i + 1];
            }
            i++;
        } else if (strncmp(argv[i], "-L", 2) == 0) {
            /* Handle -L/path form */
            if (library_path_count < 32) {
                library_paths[library_path_count++] = argv[i] + 2;
            }
        } else if (strcmp(argv[i], "-l") == 0 && i + 1 < argc) {
            if (library_count < 32) {
                libraries[library_count++] = argv[i + 1];
            }
            i++;
        } else if (strncmp(argv[i], "-l", 2) == 0) {
            /* Handle -llibname form */
            if (library_count < 32) {
                libraries[library_count++] = argv[i] + 2;
            }
        } else if (strcmp(argv[i], "--warn-unsafe-imports") == 0) {
            opts.warn_unsafe_imports = true;
        } else if (strcmp(argv[i], "--warn-unsafe-calls") == 0) {
            opts.warn_unsafe_calls = true;
        } else if (strcmp(argv[i], "--warn-ffi") == 0) {
            opts.warn_ffi = true;
        } else if (strcmp(argv[i], "--forbid-unsafe") == 0) {
            opts.forbid_unsafe = true;
        } else if (strcmp(argv[i], "--trust-report") == 0) {
            opts.trust_report = true;
        } else if (strcmp(argv[i], "--reference-eval") == 0) {
            opts.reference_eval = true;
        } else if (strcmp(argv[i], "--llm-diags-json") == 0 && i + 1 < argc) {
            opts.llm_diags_json_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--llm-diags-toon") == 0 && i + 1 < argc) {
            opts.llm_diags_toon_path = argv[i + 1];
            toon_diagnostics_enable();
            i++;
        } else if (strcmp(argv[i], "--test-imports") == 0) {
            opts.test_imports = true;
        } else if (strcmp(argv[i], "--root-shadows-only") == 0) {
            opts.test_imports = false;
        } else if (strcmp(argv[i], "--llm-shadow-json") == 0 && i + 1 < argc) {
            opts.llm_shadow_json_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--reflect") == 0 && i + 1 < argc) {
            opts.reflect_output_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--emit-typed-ast-json") == 0) {
            opts.emit_typed_ast = true;
        } else if (strcmp(argv[i], "--target") == 0 && i + 1 < argc) {
            opts.target = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--tco") == 0) {
            opts.tco = true;
        } else if (strcmp(argv[i], "--pgo") == 0 && i + 1 < argc) {
            opts.pgo_profile = argv[++i];
        } else if (strcmp(argv[i], "--debug") == 0 || strcmp(argv[i], "-g") == 0) {
            opts.debug = true;
        } else if (strcmp(argv[i], "--bench") == 0) {
            opts.bench = true;
        } else if (strcmp(argv[i], "--bench-n") == 0 && i + 1 < argc) {
            opts.bench_n = (uint64_t)strtoull(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "--bench-json") == 0 && i + 1 < argc) {
            opts.bench_json = argv[++i];
        } else if (strcmp(argv[i], "--doc-md") == 0 ||
                   strcmp(argv[i], "-dm") == 0) {
            opts.doc_md = true;
        } else if (strcmp(argv[i], "--locale") == 0 && i + 1 < argc) {
            i++;
        } else if (strcmp(argv[i], "--print-locale") == 0) {
            /* handled before compile */
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            fprintf(stderr, "Try '%s --help' for more information.\n", argv[0]);
            free(include_paths);
            free(library_paths);
            free(libraries);
            return 1;
        }
    }

    if (!input_file) {
        fprintf(stderr, "Usage: %s [OPTIONS] <input.nano>\n", argv[0]);
        fprintf(stderr, "Try '%s --help' for more information.\n", argv[0]);
        free(include_paths);
        free(library_paths);
        free(libraries);
        return 1;
    }
    
    /* Set parsed flags in options */
    opts.include_paths = include_paths;
    opts.include_count = include_count;
    opts.library_paths = library_paths;
    opts.library_path_count = library_path_count;
    opts.libraries = libraries;
    opts.library_count = library_count;
    
    /* Check for NANO_VERBOSE_BUILD environment variable */
    if (getenv("NANO_VERBOSE_BUILD")) {
        opts.verbose = true;
    }

    /* --profile-runtime instruments the C the transpiler emits, so it only has
     * meaning on the native path. Fail loudly instead of accepting the flag and
     * emitting an artifact with no profiling in it. */
    if (opts.profile_runtime) {
        const char *backend = profile_runtime_backend_name(opts.target, false);
        if (!profile_runtime_backend_supported(backend)) {
            fprintf(stderr,
                    "error: --profile-runtime is not supported for the '%s' backend\n",
                    backend);
            fprintf(stderr,
                    "  Runtime flamegraph profiling instruments the C emitted by the native\n"
                    "  backend and writes <output>.nano.prof when the compiled program exits.\n"
                    "  The '%s' backend emits an artifact that nanoc never runs, so no\n"
                    "  profile can be collected.\n", backend);
            fprintf(stderr,
                    "  Drop --target to profile natively, then feed the resulting\n"
                    "  .nano.prof back in with --pgo.\n");
            free(include_paths);
            free(library_paths);
            free(libraries);
            return 1;
        }
    }

    if (reject_artifact_diagnostic_aliases(output_file, &opts) != 0) {
        free(include_paths);
        free(library_paths);
        free(libraries);
        return 1;
    }

    int result = compile_file(input_file, output_file, &opts);
    
    /* Cleanup */
    free(include_paths);
    free(library_paths);
    free(libraries);
    
    return result;
}
