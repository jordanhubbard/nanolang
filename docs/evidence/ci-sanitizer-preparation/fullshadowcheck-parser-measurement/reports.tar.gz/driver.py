import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker='full-shadow-check-parser-diagnostic'
# This bounded gate proves preparation only; it cannot produce a passing worker result.
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("180",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
files=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p and not p.startswith('docs/evidence/')]
files += ['src_nano/diagnostic_parse_block_recursive.nano','src_nano/diagnostic_parse_unsafe_block_recursive.nano']
assert len(files)>3000 and all((root/p).is_file() for p in files)
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)

os.environ['NANO_SHADOW_TIMING']='1'
os.environ['NANO_CFLAGS']='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
os.environ['NANO_VERBOSE_BUILD']='1'
selection=Path('/tmp/ci53cc-fullenv-parser-selection.json')
closure_path=Path('/tmp/ci53cc-fullcheck-build-closure.json')
closure=json.loads(closure_path.read_text())
overlay=Path('/tmp/ci53cc-fullcheck-overlay.c')
proof=json.loads(selection.read_text())
paths.update(compiler=str(root/'bin/nanoc_c'),assembler_capture=str(root/'bin/nano_as_capture.so'),selection_proof=str(selection),staging_driver='/tmp/stage-ci53cc-fullenv-parser.py',build_closure=str(closure_path),diagnostic_overlay=str(overlay))
paths.update({'retained_object:'+p:p for p in closure['object_maps']})
prior_root=Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-source')
prior=json.loads(Path('/home/jkh/nanolang-qualification/ci-native-preparation-53cc-reports/sanitize-artifacts.json').read_text())
for name in ['nanoc_c','nano_as_capture.so']:
 assert sha(root/'bin'/name)==prior[str(prior_root/'bin'/name)]['sha256']
parser=(root/'src_nano/parser.nano').read_text()
for label,item in proof.items():
 body=re.search(r'^shadow '+label+r' \{\n(.*?)^\}',parser,re.M|re.S).group(1)
 assert hashlib.sha256(body.encode()).hexdigest()==item['body_sha256']
 assert sha(root/item['sample'])==item['sample_sha256']
 assert (root/item['sample']).read_text().split('shadow main {\n',1)[1]==body+'}\n'
write('attribution.json',{'scope':'measurement only; diagnostic main checks full dependency shadows then selects one exact root body; new diagnostic compiler, no original suite acceptance','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_sha256':sha(root/'bin/nanoc_c'),'shadow_bound':60,'outer_bound_per_invocation':180,'selection':proof,'environment':{k:os.environ.get(k) for k in ('ASAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','NANO_SHADOW_TIMING','NANO_CFLAGS','NANO_VERBOSE_BUILD')}})
shutil.copy2(selection,report/'selection-proof.json')
assert sha(overlay)==closure['overlay_sha256']
assert sha(root/'src/main.c')==closure['original_main_sha256']
for path,identity in closure['object_maps'].items():assert sha(path)==identity['sha256']
shutil.copy2(overlay,report/'diagnostic-main.c')
shutil.copy2(closure_path,report/'build-closure.json')
main_object=report/'diagnostic-main.o'
diagnostic=root/'bin/nanoc_c_fullcheck'
compile_command=closure['cc']+closure['cflags']+closure['sanitize_flags']+['-MMD','-MP','-c',str(overlay),'-o',str(main_object)]
objects=[str(main_object) if p=='obj/main.o' else str(prior_root/p) for p in closure['objects']]
link_command=closure['cc']+closure['cflags']+closure['sanitize_flags']+closure['sanitize_flags']+['-o',str(diagnostic)]+objects+closure['ldflags']+closure['sanitize_flags']+closure['sanitize_flags']
write('diagnostic-build-commands.json',{'compile':compile_command,'link':link_command,'source_override':'only main translation unit; complete original160 provider list retained with exactly main.o replaced','original_main':closure['original_main_sha256'],'overlay':closure['overlay_sha256']})
run('diagnostic-main-compile',compile_command)
run('diagnostic-link',link_command)
paths['diagnostic_compiler']=str(diagnostic)
run('diagnostic-symbols',[paths['nm'],'-u',str(diagnostic)])
symbols=(report/'diagnostic-symbols.log').read_text()
assert '__asan_' in symbols and '__ubsan_' in symbols
write('diagnostic-instrumentation.json',{'sha256':sha(diagnostic),'asan':True,'ubsan':True})
for label,item in proof.items():
 sample=root/item['sample']
 shutil.copy2(sample,report/sample.name)
 run(label,[str(diagnostic),str(sample),'--verbose','--root-shadows-only','-S','-o',str(report/(label+'-sample'))])
 log=(report/(label+'.log')).read_text(errors='replace')
 records=[json.loads(line.split('NANO_SHADOW_TIMING ',1)[1]) for line in log.splitlines() if line.startswith('NANO_SHADOW_TIMING ')]
 starts=[r for r in records if r['phase']=='shadow_start'];ends=[r for r in records if r['phase']=='shadow_end']
 assert re.findall(r'Loaded (\d+) module',log)==['19']
 marker=re.findall(r'^NANO_DIAGNOSTIC_FULL_SHADOW_CHECK (.*)$',log,re.M)
 assert len(marker)==1
 counts={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',marker[0])}
 assert counts['modules']==19 and counts['imported_shadows']>335
 before_markers=re.findall(r'^NANO_DIAGNOSTIC_SCOPE_BEFORE (.*)$',log,re.M)
 assert len(before_markers)==1
 before_counts={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',before_markers[0])}
 assert len(starts)==len(ends)==1 and starts[0]['source']==ends[0]['source']==0 and ends[0]['status']==0
 assert len([r for r in records if r['phase']=='module_init_start'])==1
 assert re.findall(r'^Testing (.*?)\.\.\.',log,re.M)==['main']
 elapsed=ends[0]['wall_sec']-starts[0]['wall_sec']+(ends[0]['wall_nsec']-starts[0]['wall_nsec'])/1e9
 write(label+'-selection-validation.json',{'pass':True,'loaded_modules':19,'selected_shadows':1,'shadow_seconds':elapsed,'checked_scope_before':before_counts,'checked_scope_after':counts,'records':records})
write('retained-sample-products.json',inventory([report]))
