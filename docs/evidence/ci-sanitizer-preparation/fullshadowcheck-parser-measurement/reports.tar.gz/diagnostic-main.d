/home/jkh/nanolang-qualification/ci53cc-fullshadowcheck-parser-measurement/diagnostic-main.o: \
 /tmp/ci53cc-fullcheck-overlay.c src/runtime/module_build_dir.h \
 src/runtime/dyn_array.h src/runtime/gc.h src/runtime/shadow_timeout.h \
 src/runtime/shadow_completion.h src/runtime/shadow_timing.h \
 src/nanovirt/shadow_runner.h src/nanolang.h \
 src/generated/compiler_schema.h src/runtime/dyn_array.h \
 src/runtime/gc_struct.h src/module_builder.h src/nanolang.h \
 src/nanoisa/nvm_format.h src/file_source_resolution.h \
 src/file_companion_snapshot.h src/nanoisa/file_source_plan.h \
 src/colors.h src/version.h src/shell_path.h src/interpreter_ffi.h \
 src/reflection.h src/emit_typed_ast.h src/docgen_md.h \
 src/runtime/list_CompilerDiagnostic.h src/toon_output.h \
 src/nanocore_subset.h src/nanocore_export.h src/locale.h src/bcp47.h \
 src/utf8.h src/diag_id.h src/catalog.h src/locale.h src/ptx_backend.h \
 src/opencl_backend.h src/c_backend.h src/riscv_backend.h src/bench.h \
 src/tco_pass.h src/cps_pass.h src/pgo_pass.h src/stdlib_runtime.h
src/runtime/module_build_dir.h:
src/runtime/dyn_array.h:
src/runtime/gc.h:
src/runtime/shadow_timeout.h:
src/runtime/shadow_completion.h:
src/runtime/shadow_timing.h:
src/nanovirt/shadow_runner.h:
src/nanolang.h:
src/generated/compiler_schema.h:
src/runtime/dyn_array.h:
src/runtime/gc_struct.h:
src/module_builder.h:
src/nanolang.h:
src/nanoisa/nvm_format.h:
src/file_source_resolution.h:
src/file_companion_snapshot.h:
src/nanoisa/file_source_plan.h:
src/colors.h:
src/version.h:
src/shell_path.h:
src/interpreter_ffi.h:
src/reflection.h:
src/emit_typed_ast.h:
src/docgen_md.h:
src/runtime/list_CompilerDiagnostic.h:
src/toon_output.h:
src/nanocore_subset.h:
src/nanocore_export.h:
src/locale.h:
src/bcp47.h:
src/utf8.h:
src/diag_id.h:
src/catalog.h:
src/locale.h:
src/ptx_backend.h:
src/opencl_backend.h:
src/c_backend.h:
src/riscv_backend.h:
src/bench.h:
src/tco_pass.h:
src/cps_pass.h:
src/pgo_pass.h:
src/stdlib_runtime.h:
