from pathlib import Path
import gzip,hashlib,json
base=Path('.test_output'); dest=Path('docs/evidence/translator-components-linux-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
report=json.loads((base/'nanolang-functions-results.json').read_text());assert len(report['cases'])==1325 and report['explicit']==1197 and len(report['routes'])==5
paths={Path(__file__)}
for name in ['service-module-native-products-linux','service-module-explicit','service-module-explicit-corrected','service-module-qualified-products-linux','service-module-source-products-linux',str(Path(report['products']).relative_to(base.resolve()))]:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['service-module-before-valid-spans.py','service-module-smoke2.log','service-module-factory-observation.txt','service-module-observed.log','service-module-observed.nvm','service-module-native-regressions-linux.log','service-module-native-provider-linux.json','service-module-five-routes-linux.log','nanolang-functions-results.json','functions-five-routes-linux.log','functions-retained-five-routes-linux.log']:
 p=base/name
 if p.exists():paths.add(p)
for name in ['src_nano/nvm2c/module.nano','src_nano/nvm2c/functions.nano','tests/test_nanolang_translator_functions.py','tests/test_nanolang_translator_service_modules.py','tests/nvm2c_functions_reference.c','tests/nvm2c_functions_driver.nano']:
 paths.add(Path(name))
sha=lambda b:hashlib.sha256(b).hexdigest(); entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,limits=['I retain Linux component observations; Darwin, executable authority and full source-factory acceptance remain pending.']),indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
