from pathlib import Path
import subprocess,json,hashlib,re
base=Path.cwd();root=(base/'.test_output/as246-same-host-witness');root.mkdir(exist_ok=False)
source=base/'.test_output/native-replay-44950231043/source-capture-tools-linux/0/native-nop-include-step/preprocessed.s';raw=source.read_text();normalized=re.sub(r'^\.include .*$', '.include "debug macro.s"',raw,flags=re.M);(root/'debug macro.s').write_bytes((source.parent/'debug macro.s').read_bytes());lines=normalized.splitlines(keepends=True)
variants={'actual-markers':normalized,'without-directory':''.join(x for x in lines if not(x.startswith('# ') and '//"' in x)),'without-predef':''.join(x for x in lines if not(x.startswith('# ') and 'stdc-predef.h' in x)),'source-marker-only':'# 1 "payload.S"\n'+''.join(x for x in lines if not x.startswith('# '))}
record=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),limits=['I change only the assembler include pathname to an identical local macro file before comparing identical bytes on one host. I compare direct assemblers under --gdwarf-5, without a compiler driver. The private upstream tool does not replace any product tool.'],tools=[],steps=[])
for number,tool in enumerate([Path('/usr/bin/as'),base/'.test_output/binutils-marker-source/build-2_46/gas/as-new']):
 record['tools'].append(dict(path=str(tool),sha256=hashlib.sha256(tool.read_bytes()).hexdigest(),version=subprocess.check_output([tool,'--version'],text=True)))
 for name,contents in variants.items():
  path=root/(name+'.s');path.write_text(contents);obj=root/(str(number)+'-'+name+'.o');argv=list(map(str,[tool,'--gdwarf-5','-o',obj,path]));r=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=30);item=dict(argv=argv,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr);record['steps'].append(item);r.check_returncode()
  d=subprocess.run(['/usr/bin/readelf','--debug-dump=info',obj],capture_output=True,text=True,timeout=30);item['debug_info']=d.stdout;item['debug_stderr']=d.stderr;item['debug_returncode']=d.returncode;d.check_returncode();print(number,name,re.findall(r'DW_AT_name[^\n]*',d.stdout)[:1])
(root/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
