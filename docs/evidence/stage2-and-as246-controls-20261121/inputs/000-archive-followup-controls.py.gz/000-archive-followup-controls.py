from pathlib import Path
import gzip,hashlib,json
base=Path('.test_output');dest=Path('docs/evidence/stage2-and-as246-controls-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__)}
for name in ['stage2-vm-cpu-packed-leaf-profile','as246-same-host-witness','as246-same-host-candidate']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['profile-vm-cpu-packed-leaf.py','analyze-vm-cpu-packed-leaf.py','profile-vm-cpu-packed-leaf.log','analyze-vm-cpu-packed-leaf.log','build-diagnostic-as246.py','patch-diagnostic-as246.py','compare-as246-same-host.py','compare-as246-same-host.log','compare-as246-candidate.py','compare-as246-candidate.log']:
 paths.add(base/name)
r=base/'binutils-marker-source'
paths.update(p for p in r.iterdir() if p.is_file())
paths.add(r/'build-2_46/gas/as-new')
paths.update(p for p in (r/'build-2_46').rglob('config.log') if p.is_file())
x=json.loads((base/'stage2-vm-cpu-packed-leaf-profile/analysis.json').read_text());assert x['samples']==2998 and x['intentional_completed_window_stop']
sha=lambda b:hashlib.sha256(b).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,limits=['I retain a remaining-hotspot CPU observation and same-host upstream assembler diagnostic, not full bootstrap or assembler admission.']),indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
