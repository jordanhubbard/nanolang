from pathlib import Path
import urllib.request,hashlib,json,tarfile,subprocess,time,os
root=Path('.test_output/binutils-marker-source').resolve();p=root/'binutils-2.46.0.tar.xz';url='https://sourceware.org/pub/binutils/releases/binutils-2.46.0.tar.xz';record=dict(url=url,earlier_setup_refusal='I first queried the nonexistent binutils-2.46.tar.xz path (HTTP404); I use the published2.46.0 archive name.',steps=[])
with urllib.request.urlopen(url,timeout=60) as response,p.open('wb') as f:
 while chunk:=response.read(1024*1024):f.write(chunk)
record.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
with tarfile.open(p) as t:t.extractall(root,filter='data')
build=root/'build-2_46';build.mkdir(exist_ok=False);sources=list(root.glob('binutils-2.46*/configure'));assert len(sources)==1
for label,argv in [('configure',[str(sources[0]),'--disable-nls','--disable-werror','--disable-gdb','--disable-gdbserver','--disable-gprofng','--disable-gprof','--disable-binutils','--disable-ld','--disable-gold']),('build',['make','-j4','all-gas'])]:
 start=time.monotonic()
 with (root/(label+'.stdout')).open('wb') as out,(root/(label+'.stderr')).open('wb') as err:r=subprocess.run(argv,cwd=build,stdout=out,stderr=err,timeout=600)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));(root/'build-manifest.json').write_text(json.dumps(record,indent=2)+'\n');r.check_returncode()
binary=build/'gas/as-new';record['assembler_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();record['assembler_version']=subprocess.check_output([binary,'--version'],text=True);(root/'build-manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(record['assembler_version'])
