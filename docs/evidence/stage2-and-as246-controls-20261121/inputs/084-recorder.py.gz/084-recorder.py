#!/usr/bin/python3
import fcntl,json,os,subprocess,sys,time
from pathlib import Path
phase=sys.argv[1];now=time.monotonic_ns();root=Path(os.environ['NANO_CPU_EXPERIMENT']);pid=int((root/'target.pid').read_text());assert Path('/proc/'+str(pid)+'/exe').resolve()==Path(os.environ['NANO_CPU_PROFILE_TARGET'])
with (root/'phases.jsonl').open('a') as f:
 fcntl.flock(f,fcntl.LOCK_EX);f.write(json.dumps(dict(phase=phase,mono_ns=now,pid=os.getpid(),target_pid=pid))+'\n')
if phase=='typecheck-start':
 (root/'typecheck-start.maps').write_text(Path('/proc/'+str(pid)+'/maps').read_text())
 subprocess.Popen([sys.executable,str(root/'complete-window.py'),str(now),str(pid),str(root/'window-complete.json')],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
