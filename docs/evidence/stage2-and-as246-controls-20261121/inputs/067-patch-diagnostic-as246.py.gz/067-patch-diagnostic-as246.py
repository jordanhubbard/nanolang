from pathlib import Path
import shutil,subprocess,time,json,hashlib
root=Path('.test_output/binutils-marker-source').resolve();source=root/'binutils-2.46.0/gas/input-scrub.c';before=source.read_text();needle='if (logical_input_file == 0 && logical_input_line == -1u\n\t  && saved->logical_input_line != -1u)';assert before.count(needle)==1
shutil.copy2(root/'build-2_46/gas/as-new',root/'as-unmodified');(root/'input-scrub-before.c').write_text(before);after=before.replace(needle,'if (from_sb_expansion != expanding_none\n\t  && logical_input_file == 0 && logical_input_line == -1u\n\t  && saved->logical_input_line != -1u)');source.write_text(after);(root/'input-scrub-candidate.c').write_text(after)
argv=['make','-j4','all-gas'];start=time.monotonic()
with (root/'candidate-build.stdout').open('wb') as out,(root/'candidate-build.stderr').open('wb') as err:r=subprocess.run(argv,cwd=root/'build-2_46',stdout=out,stderr=err,timeout=600)
(root/'candidate-build.json').write_text(json.dumps(dict(argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-start,before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(after.encode()).hexdigest()),indent=2)+'\n');r.check_returncode()
