from pathlib import Path
import subprocess,os,json,hashlib,time,signal
root=Path('/home/jkh/Src/nanolang-riscv-argument-registers');base=Path(__file__).resolve().parent
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');paths=[p for p in paths if p and (root/p).is_file() and not p.startswith('docs/evidence/')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():return {p:sha(root/p) for p in paths}
def dump(name,value):(base/name).write_text(json.dumps(value,indent=2)+'\n')
before=inputs();dump('inputs-before.json',before)
tools={str(Path(p).resolve()):sha(Path(p).resolve()) for p in ['/usr/bin/gcc','/usr/local/bin/clang','/usr/bin/make','/usr/bin/bash']};dump('tools-before.json',tools)
commands=[['/usr/bin/gcc','-Wall','-Wextra','-Werror','-std=c99','-O1','-g','-fPIC','-Isrc','-D_GNU_SOURCE','-fsanitize=address,undefined','-fno-omit-frame-pointer','-c','src/riscv_backend.c','-o',str(base/'riscv-gcc-sanitized.o')],['/usr/local/bin/clang','--gcc-install-dir=/usr/lib/gcc/aarch64-linux-gnu/13','-Wall','-Wextra','-Werror','-std=c99','-O1','-g','-fPIC','-Isrc','-D_GNU_SOURCE','-fsanitize=address,undefined','-fno-omit-frame-pointer','-c','src/riscv_backend.c','-o',str(base/'riscv-clang-sanitized.o')],['/usr/bin/make','-f','Makefile.gnu','-j2','bin/nanoc_c'],['/usr/bin/python3','tests/test_cross_backend_runner.py'],['/usr/bin/bash','tests/cross-backend/run-all.sh',str(root/'bin/nanoc_c')]]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();dump(f'{i}-command.json',cmd)
 with (base/f'{i}-stdout.log').open('wb') as out,(base/f'{i}-stderr.log').open('wb') as err:
  p=subprocess.Popen(cmd,cwd=root,stdout=out,stderr=err,start_new_session=True)
  try:rc=p.wait(timeout=1800);timeout=False
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 try:os.killpg(p.pid,0);gone=False
 except ProcessLookupError:gone=True
 result={'returncode':rc,'seconds':time.monotonic()-start,'timeout':timeout,'group_gone':gone};results.append(result);dump(f'{i}-terminal.json',result);print(i,result,flush=True)
 if rc or timeout or not gone:break
after=inputs();dump('inputs-after.json',after);finaltools={p:sha(Path(p)) for p in tools};dump('tools-after.json',finaltools)
dump('summary.json',{'source_pin':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'results':results,'source_unchanged':before==after,'tools_unchanged':tools==finaltools,'scope':'Fresh isolated-main strict sanitized changed translation unit compilation plus ordinary C seed and original cross-backend gate; RISC-V structural validation is not target execution.'})
raise SystemExit(any(r['returncode'] or r['timeout'] or not r['group_gone'] for r in results) or len(results)!=len(commands) or before!=after or tools!=finaltools)
