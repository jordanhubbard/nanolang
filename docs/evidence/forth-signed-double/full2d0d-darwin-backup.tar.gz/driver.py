from pathlib import Path
import hashlib,json,subprocess,os,signal,time,sys,shutil,tarfile
base=Path(__file__).resolve().parent;root=base/'qualified-full2d0d';root.mkdir(exist_ok=False);report=base/'reports-full2d0d';report.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,obj):(report/name).write_text(json.dumps(obj,indent=2)+'\n')
m=json.loads((base/'source.json').read_text());archive=base/'source.tar.gz';assert sha(archive)==m['archive_sha256']
with tarfile.open(archive) as t:t.extractall(root,filter='data')
def inputs():return {n:{'sha256':sha(root/n),'bytes':(root/n).stat().st_size,'mode':(root/n).stat().st_mode&0o777} for n in m['inputs']}
before=inputs();assert before==m['inputs'];dump('inputs-before.json',before);dump('source.json',m);shutil.copyfile(__file__,report/'driver.py')
sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip();assert Path(sdk).is_dir();dump('sdk.json',{'path':sdk,'version':subprocess.check_output(['/usr/bin/xcrun','--show-sdk-version'],text=True)})
paths=['/usr/bin/clang','/opt/homebrew/opt/llvm/bin/clang','/usr/bin/make','/usr/bin/xcrun',sys.executable,'/opt/homebrew/opt/openssl@3/include/openssl/sha.h','/opt/homebrew/opt/openssl@3/lib/libcrypto.dylib','/opt/homebrew/opt/libffi/lib/libffi.dylib']
def tools():return {p:{'path':str(Path(p).resolve()),'sha256':sha(Path(p).resolve())} for p in paths}
before_tools=tools();dump('tools-before.json',before_tools)
env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',PYTHONDONTWRITEBYTECODE='1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',LSAN_OPTIONS='');rows=[]
try:
 for label,cc,sanitizer in [('apple','/usr/bin/clang',False),('brew-ubsan','/opt/homebrew/opt/llvm/bin/clang',True)]:
  assert shutil.disk_usage(root).free>3*1024**3
  compiler=cc+' -isysroot '+sdk
  if sanitizer:compiler+=' -fsanitize=undefined -fno-sanitize-recover=all -fno-omit-frame-pointer'
  argv=['/usr/bin/make','-j2','test-forth-session','test-forth-double','OBJ_DIR=obj-forth-'+label,'CC='+compiler,'PYTHON_WITH_YAML=/usr/bin/python3','OPENSSL_PREFIX=/opt/homebrew/opt/openssl@3']
  dump(label+'-command.json',{'argv':argv,'cwd':str(root),'environment':{k:env[k] for k in ['UBSAN_OPTIONS','LSAN_OPTIONS','PYTHONDONTWRITEBYTECODE']}});start=time.monotonic();timeout=False
  with (report/(label+'.stdout')).open('wb') as out,(report/(label+'.stderr')).open('wb') as err:
   p=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
   try:p.wait(timeout=900)
   except subprocess.TimeoutExpired:timeout=True
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    try:os.killpg(p.pid,0)
    except ProcessLookupError:break
    os.killpg(p.pid,sig);deadline=time.monotonic()+3
    while time.monotonic()<deadline:
     p.poll()
     try:os.killpg(p.pid,0)
     except ProcessLookupError:break
     time.sleep(.05)
   p.wait(timeout=3)
   try:os.killpg(p.pid,0);gone=False
   except ProcessLookupError:gone=True
  row={'configuration':label,'returncode':p.returncode,'timeout':timeout,'group_gone':gone,'leader_reaped':p.poll() is not None,'seconds':time.monotonic()-start};rows.append(row);dump(label+'-terminal.json',row);dump('results.json',rows);print(row,flush=True)
  dump(label+'-products.json',{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in (root/('obj-forth-'+label)).rglob('*') if p.is_file()})
  assert p.returncode==0 and gone and not timeout
finally:
 after=inputs();dump('inputs-after.json',after);dump('tools-after.json',tools());dump('identity.json',{'unchanged':before==after,'tools_unchanged':before_tools==tools(),'inputs':len(before)})
