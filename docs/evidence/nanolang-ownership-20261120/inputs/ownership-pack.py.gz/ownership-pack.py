from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('docs/evidence/nanolang-ownership-20261120')
inputs=root/'inputs'; inputs.mkdir(exist_ok=True)
records=[]
def retain(name,data):
    packed=gzip.compress(data,mtime=0)
    (inputs/(name+'.gz')).write_bytes(packed)
    records.append(dict(path='inputs/'+name+'.gz',uncompressed_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),compressed_sha256=hashlib.sha256(packed).hexdigest()))
for p in sorted(Path('.test_output').glob('ownership*.log')):
    retain('linux-'+p.name,p.read_bytes())
for p in sorted(Path('.test_output/ownership-darwin').glob('*.log')):
    retain('darwin-'+p.name,p.read_bytes())
for name in ['ownership-linux-manifest.json','ownership-corpus.json','ownership-collect.py','ownership-pack.py','ownership-slice-artifacts.py','ownership-typecheck-first-candidate.nano','ownership-slice-shadow-unspaced.nano','ownership-launch-results.json','ownership-linux-slice-artifacts.json']:
    retain(name,Path('.test_output',name).read_bytes())
for name in ['ownership-darwin-manifest.json','ownership-darwin-slice-artifacts.json']:
    retain(name,Path('.test_output/ownership-darwin',name).read_bytes())
manifest=json.loads(Path('.test_output/ownership-linux-manifest.json').read_text())
for name,sha in manifest['source_sha256'].items():
    data=subprocess.check_output(['git','show','7cd173b30:'+name])
    assert hashlib.sha256(data).hexdigest()==sha,name
    retain('source-'+name.replace('/','_'),data)
assert Path('.test_output/ownership-corpus.json').read_bytes()==Path('.test_output/ownership-darwin/ownership-corpus.json').read_bytes()
(root/'retained-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
    compressed=(root/r['path']).read_bytes(); data=gzip.decompress(compressed)
    assert hashlib.sha256(compressed).hexdigest()==r['compressed_sha256']
    assert hashlib.sha256(data).hexdigest()==r['sha256'] and len(data)==r['uncompressed_bytes']
print('I retained and verified',len(records),'inputs.')
