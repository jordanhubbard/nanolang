from pathlib import Path
import hashlib,json,re,sys
log=Path('.test_output/ownership-original-slice-final.log').read_text()
assert '\nOK\n' in log
match=re.search(r'I retain source, logs and generated artifacts at (.+)',log)
root=Path(match[1]); records={}; hashes={}
for p in sorted(root.iterdir()):
    if p.is_file():
        data=p.read_bytes()
        hashes[p.name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        if p.suffix in {'.log','.nano'}:
            records[p.name]=dict(sha256=hashlib.sha256(data).hexdigest(),text=data.decode())
        elif p.suffix=='.nvm':
            records[p.name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes_hex=data.hex())
Path(sys.argv[1]).write_text(json.dumps(dict(original_suite_log=log,artifacts=records,all_file_hashes=hashes),indent=2)+'\n')
print('I retained',len(records),'original suite source/module/command records.')
