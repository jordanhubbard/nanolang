from pathlib import Path
import hashlib, json, platform, subprocess, sys
from tests.test_nanolang_translator_ownership import corpus
from tests.nanolang_translator_routes import checked

def observe(*args):
    p = subprocess.run(args, capture_output=True, text=True)
    return dict(returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)

if sys.argv[1] == '--corpus':
    cases = corpus()
    root = Path('.test_output/ownership-corpus')
    root.mkdir(exist_ok=True)
    paths = []
    for i, (_, data, _) in enumerate(cases):
        p = root / f'case-{i}.bin'
        p.write_bytes(data)
        paths.append(p)
    values = []
    for i in range(0, len(paths), 64):
        values += checked(['obj/nvm2c_ownership_reference', *paths[i:i+64]], timeout=600).splitlines()
    assert len(values) == len(cases)
    records = []
    for (name, data, expected), value in zip(cases, values):
        if expected is not None:
            assert value == expected, (name, expected, value)
        records.append(dict(name=name, bytes_hex=data.hex(), sha256=hashlib.sha256(data).hexdigest(), explicit_report=expected, actual_c_report=value))
    Path('.test_output/ownership-corpus.json').write_text(json.dumps(records, separators=(',', ':')) + '\n')
    print('I retained', len(records), 'shared-declaration decisions;', sum(x['explicit_report'] is not None for x in records), 'explicit controls.')
else:
    sources = ['src/typechecker.c','src_nano/typecheck.nano','src_nano/nanoc_v06.nano', 'src_nano/nvm2c/ownership.nano', 'src_nano/nvm2c/ownership_wire.nano', 'src_nano/nvm2c/payloads.nano', 'src_nano/nvm2c/instructions.nano', 'src_nano/nvm2c/passive_calls.nano', 'src/nanoisa/ownership_contracts.c', 'src/nanoisa/ownership_contracts.h', 'tests/nvm2c_ownership_driver.nano', 'tests/nvm2c_ownership_reference.c', 'tests/test_nanolang_translator_ownership.py', 'tests/array_slice_nested.nano', 'tests/test_selfhost_native_array_slice.py', 'tests/nanolang_translator_routes.py', 'tests/native_process.py', 'Makefile.gnu']
    tools = ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_ownership_reference','.test_output/ownership-source-final']
    record = dict(commit=observe('git','rev-parse','HEAD'), status=observe('git','status','--short'), uname=observe('uname','-a'), cc=observe('cc','--version'), clang=observe('clang','--version'), gcc=observe('gcc','--version'), python=sys.version, source_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources}, post_run_tool_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in tools}, limits=['I built my development source compiler with the C seed at 7cd173b30, not through a raw fixed point.', 'My ordinary C oracle calls the shared validator, without private declaration projections.', 'My generated C is ASan/UBSan instrumented and links an ordinary AOT runtime.', 'My decoder unittest products and native binaries are not archived; original slicing modules are retained separately.', 'I record post-run tool observations, not a complete SDK closure.', 'Declarations alone grant no instruction or host execution authority.'])
    if sys.platform == 'darwin':
        record['sdk'] = observe('xcrun','--sdk','macosx','--show-sdk-version')
        record['sdk_path'] = observe('xcrun','--sdk','macosx','--show-sdk-path')
        record['os'] = observe('sw_vers')
    Path(sys.argv[1]).write_text(json.dumps(record, indent=2)+'\n')
