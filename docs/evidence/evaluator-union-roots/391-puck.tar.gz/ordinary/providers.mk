include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(COMMON_OBJECTS) $(RUNTIME_OBJECTS)
	@printf '%s\n' '$(COMMON_OBJECTS) $(RUNTIME_OBJECTS)' > /Users/jkh/nanolang-qualification/union-root-391-puck/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /Users/jkh/nanolang-qualification/union-root-391-puck/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /Users/jkh/nanolang-qualification/union-root-391-puck/ordinary/ldflags.txt
