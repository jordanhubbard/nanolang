from pathlib import Path
import subprocess,os,time,signal,json,hashlib
ROOT=Path('/tmp/nanolang-artifact-native-link-flags')
OUT=Path(__file__).resolve().parent
inputs={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0') if n and (ROOT/n).is_file()}
(OUT/'inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
def run(name,args,timeout=600,extra=None):
 env=dict(os.environ);env.update(extra or {})
 start=time.monotonic();timed_out=False
 with (OUT/(name+'.stdout')).open('wb') as out,(OUT/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
  try: status=child.wait(timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try: child.wait(3)
   except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);child.wait(3)
   status=child.returncode
 record={'argv':args,'extra_env':extra,'returncode':status,'timed_out':timed_out,'elapsed':time.monotonic()-start}
 (OUT/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,status,record['elapsed'],flush=True)
 assert status==0 and not timed_out
run('providers',['make','-j2','-f',str(OUT/'qualification.mk'),'bin/nanoc_c','nano_vm','nano_virt','nvm2c','nvm2c-runtime','nanoisa_dump','artifact-compare'])
