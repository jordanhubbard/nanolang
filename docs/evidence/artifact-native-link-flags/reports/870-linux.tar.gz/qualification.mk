include Makefile.gnu
.PHONY: artifact-compare
artifact-compare: $(NANOISA_OBJECTS) $(NANOISA_UTF8)
	$(CC) $(CFLAGS) -I$(NANOISA_DIR) -I$(NANOISA_MODULE_DIR) -o tests/nanoisa/test_nanoisa_src_nano tests/nanoisa/test_nanoisa_src_nano.c $(NANOISA_OBJECTS) $(NANOISA_UTF8) $(LDFLAGS)
