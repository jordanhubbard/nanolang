from pathlib import Path
import hashlib,json,os,platform,shlex,signal,subprocess,time
HERE=Path(__file__).resolve().parent;ROOT=Path(os.environ.get('QUAL_ROOT','/tmp/nanolang-artifact-native-link-flags'))
def run(name,args,extra=None):
 env=dict(os.environ);env.update(extra or {});start=time.monotonic()
 with (HERE/(name+'.stdout')).open('wb') as out,(HERE/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
  try: code=child.wait(600)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(3)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(3)
   raise
 record={'argv':args,'extra_env':extra,'returncode':code,'elapsed':time.monotonic()-start}
 (HERE/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,code,round(record['elapsed'],3),flush=True)
 assert code==0
ordinary='/usr/bin/cc';clang='/usr/local/bin/clang --gcc-install-dir=/usr/lib/gcc/aarch64-linux-gnu/13'
if platform.system()=='Darwin':
 sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
 ordinary='/usr/bin/clang -isysroot '+shlex.quote(sdk)
 clang='/opt/homebrew/opt/llvm/bin/clang -isysroot '+shlex.quote(sdk)
configs=[('ordinary',ordinary,''),('coverage',ordinary,'-fprofile-arcs -ftest-coverage'),('gcc-sanitizer' if platform.system()=='Linux' else 'apple-sanitizer',ordinary,'-fsanitize=address,undefined -fno-omit-frame-pointer'),('clang-sanitizer',clang,'-fsanitize=address,undefined -fno-omit-frame-pointer')]
if platform.system()=='Darwin': configs=[c for c in configs if c[0]!='apple-sanitizer']
for name,compiler,flags in configs:
 if name!='ordinary':
  cflags='-Wall -Wextra -Werror -std=c99 -g -O3 -fPIC -Isrc -D_GNU_SOURCE '+flags
  run(name+'-runtime',['make','-j2','nvm2c-runtime','OBJ_DIR=obj-'+name,'CC='+compiler,'CFLAGS='+cflags,'LDFLAGS=-lm '+flags])
 obj=ROOT/'bin/nano_aot_runtime.o';data=obj.read_bytes();(HERE/(name+'-runtime.o')).write_bytes(data)
 (HERE/(name+'-runtime-sha256.txt')).write_text(hashlib.sha256(data).hexdigest()+'\n')
 extra={'NANO_CC':'/usr/bin/cc','QUAL_ROOT':str(ROOT),'QUAL_REPORT':str(HERE/(name+'-commands')),'CC':compiler,'LDFLAGS':flags,'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
 extra['NANO_NATIVE_TEST_CC']=compiler
 if platform.system()=='Darwin':extra['SDKROOT']=sdk
 run(name+'-suite',['/usr/bin/python3',str(HERE/'fixture.py')],extra)
(HERE/'complete.json').write_text(json.dumps({'status':'pass','platform':platform.platform()})+'\n')
