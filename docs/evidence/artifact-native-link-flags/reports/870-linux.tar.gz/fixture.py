from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile,unittest
ROOT=Path(os.environ['QUAL_ROOT']);OUT=Path(os.environ['QUAL_REPORT']);OUT.mkdir()
sys.path.insert(0,str(ROOT));real_run=subprocess.run;count=0

def run(*args,**kwargs):
 global count
 count+=1;n=count
 try: result=real_run(*args,**kwargs)
 except BaseException as e:
  (OUT/f'{n:03}-exception.txt').write_text(repr(e));raise
 record={'argv':[str(x) for x in args[0]],'returncode':result.returncode}
 for stream in ['stdout','stderr']:
  value=getattr(result,stream)
  if value is not None: (OUT/f'{n:03}-{stream}.txt').write_bytes(value.encode() if isinstance(value,str) else value)
 (OUT/f'{n:03}.json').write_text(json.dumps(record,indent=2)+'\n')
 return result
subprocess.run=run
Original=tempfile.TemporaryDirectory
class Retained(Original):
 def cleanup(self):
  source=Path(self.name)
  if source.exists():
   target=OUT/'products'/source.name
   target.parent.mkdir(exist_ok=True)
   if not target.exists(): shutil.copytree(source,target)
  return super().cleanup()
tempfile.TemporaryDirectory=Retained
suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_nanoisa_artifact_imports')
result=unittest.TextTestRunner(verbosity=2).run(suite)
products={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (OUT/'products').rglob('*') if p.is_file()}
(OUT/'products.json').write_text(json.dumps(products,indent=2)+'\n')
sys.exit(not result.wasSuccessful())
