from pathlib import Path
import runpy,platform,subprocess,shlex,json,hashlib
HERE=Path(__file__).resolve().parent
scope=runpy.run_path(str(HERE/'matrix.py'),run_name='__main__')
args=['make','-j2','test-nvm2c']
if platform.system()=='Darwin':
 sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
 args+=['CC=/opt/homebrew/opt/llvm/bin/clang -isysroot '+shlex.quote(sdk)]
scope['run']('nvm2c-adjacency',args)
root=scope['ROOT'];m=json.loads((HERE/'inputs-before.json').read_text());after={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in m};(HERE/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert m==after
(HERE/'all-complete.json').write_text(json.dumps({'status':'pass','platform':platform.platform(),'inputs':len(m)})+'\n')
