from pathlib import Path
import runpy,os,json,hashlib,platform,subprocess
here=Path(__file__).resolve().parent
scope=runpy.run_path(str(here/'providers.py'),run_name='__main__')
root=scope['ROOT'];extra={'QUAL_ROOT':str(root),'QUAL_REPORT':str(here/'ordinary-commands'),'NANO_CC':'/usr/bin/cc','CC':'/usr/bin/cc','LDFLAGS':''}
if platform.system()=='Darwin':extra['SDKROOT']=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
scope['run']('ordinary-suite',['/usr/bin/python3',str(here/'fixture.py')],extra=extra)
m=json.loads((here/'inputs-before.json').read_text());after={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in m};(here/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert m==after
(here/'complete.json').write_text(json.dumps({'status':'pass','platform':platform.platform(),'inputs':len(m)})+'\n')
