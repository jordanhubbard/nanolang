from pathlib import Path
import sys,os,json,gzip,hashlib,stat,subprocess,shutil
root=Path('/Users/jkh/.worktrees/nanolang/linked-module-verifier-20261122');active=root.with_name(root.name+'-guarded');out=root.with_name(root.name+'-archive');state=json.loads((active/'manifest.json').read_text());assert state['status']=='passed' and state['primary_preserved'] and state['provider_guards_unchanged'] and state['final_status']==''
linked=json.loads((active/'linked-products/manifest.json').read_text());ordinary=json.loads((active/'unlinked-products/manifest.json').read_text());sans={name:json.loads((active/name/'manifest.json').read_text()) for name in ['linked-reference-sanitizers','unlinked-reference-sanitizers']};assert all(r['status']=='passed' for r in sans.values())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
primary=Path('/Users/jkh/Src/nanolang')
def primary_guard():
 def git(*args):return subprocess.check_output(['git',*args],cwd=primary)
 files={}
 for raw in git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0'):
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','--full-index','HEAD')),cached=sha(git('diff','--cached','--binary','--full-index','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)
assert primary_guard()==state['primary_before']==state['primary_after']
expected=state['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in expected.items());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==state['pin']
examples=json.loads((active/'original-example-inputs.json').read_text())['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in examples.items())
sys.path.insert(0,'/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');from scripts.bootstrap_nanoisa import Bootstrap
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
assert all(sha((root/name).read_bytes())==value for name,value in state['tools'].items())
(out/'inputs').mkdir(parents=True,exist_ok=False)
paths={root/name for name in [*expected,*examples,*state['tools'],'obj/fixture_identifier_lexer'] if (root/name).is_file()};symlinks={}
for suffix in ['-control','-resume','-gates','-python','-guarded']:
 control=root.with_name(root.name+suffix)
 if control.is_dir():
  for path in control.rglob('*'):
   if path.is_symlink():symlinks[str(path)]=os.readlink(path)
   if path.is_file():paths.add(path)
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
for name in ['/tmp/nanolang-linked-darwin-20261122.log','/tmp/nanolang-linked-darwin-resume-20261122.log','/tmp/nanolang-linked-darwin-gates-20261122.log','/tmp/nanolang-linked-darwin-guarded-20261122.log',__file__]:
 p=Path(name)
 if p.is_file():paths.add(p)
record=dict(implementation=state['pin'],issue=1142,source_hashes=expected,example_source_hashes=examples,verification=dict(linked=linked,ordinary_regression=ordinary),provider=state['provider'],tools=state['tools'],primary_before=state['primary_before'],primary_after=state['primary_after'],symlinks=symlinks,limits=['I qualify ordinary linked/root and every present-node flat-graph checks plus the original full/declared unlinked regression, through actual C public APIs and five routes with original fresh producer targets. Private/affine/owned admission and executable pure C emission remain open. I retain the initial primary partial-clone promised-object failure, standalone checkout/tools completion followed by shell-selected Python3.14 missing-PyYAML import failure, and a pre-gate preservation refusal caused only by9-to10-digit Git diff index-hash abbreviation. No product method executes in those refused setups. Both historical diff hashes reconstruct from the identical full-index patch and every other primary/audit/stash field matches. The final observer uses full-index preservation and existing Python3.13/PyYAML6.0.3 after host Bash startup modifies PATH. I reuse only completed guarded tool/source setup; no passed product gate is repeated. C compiler and all native/guest/shadow limits remain unchanged. Mac emitted/native and targeted C ASan/UBSan do not instrument all providers or establish LeakSanitizer support. I preserve the actual frozen bdffa4ccc native Stage1 as a development producer, not a new raw bootstrap. The3original example inputs are separately checked with source Git and Linux; they are additional to the3567 core/test/specification/Make guards. Build caches are omitted; all generated retained fixture products/DSYM data, native images, command streams, source/provider receipts and observer failures remain included. Final-source release/bootstrap, private profiles and full #976 scope remain open.'])
files=[];seen={}
for i,path in enumerate(sorted(paths)):
 raw=path.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{path.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(path),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(path.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and sha(raw)==e['sha256'] and len(raw)==e['bytes']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/name).read_bytes())==value for name,value in expected.items());assert all(sha((root/name).read_bytes())==value for name,value in state['tools'].items());assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
assert primary_guard()==state['primary_before']
print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/name).stat().st_size for name in seen.values()),source_files=len(expected),original_example_inputs=len(examples))))
