from pathlib import Path
import sys,os,subprocess,json,hashlib,time,signal,traceback,shutil,platform,re
pin=sys.argv[1];expected_path=Path(sys.argv[2]);primary=Path('/Users/jkh/Src/nanolang')
root=Path('/Users/jkh/.worktrees/nanolang/linked-module-verifier-20261122')
out=root.with_name(root.name+'-gates');assert root.is_dir() and not out.exists()
out.mkdir(parents=True);shutil.copy2(__file__,out/'observer.py');shutil.copy2(expected_path,out/'expected-sources.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
record=dict(pin=pin,root=str(root),controller_pid=os.getpid(),python=sys.version,platform=platform.platform(),steps=[],status='running',limits=['I qualify ordinary linked/root and complete present-node graph verification and the full/declared unlinked regression in a separate exact-source sparse clone. Successful conversion grants no executable, affine, private-profile or pure-emitter authority. I use the actual frozen bdffa4ccc qualified Stage1 only as a development source producer. Ordinary shadows retain10 seconds. I preserve every frozen root, primary dirty audit and stash. No new raw bootstrap is claimed. Puck explicitly released its heavy reservation; three1.05CPU-second health samples pass75percent scheduling admission.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def git(*args,cwd=primary):return subprocess.check_output(['git',*args],cwd=cwd)
def primary_guard():
 paths=git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0');files={}
 for raw in paths:
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','HEAD')),cached=sha(git('diff','--cached','--binary','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)
original=primary_guard();record['primary_before']=original
prior_path=root.with_name(root.name+'-control')/'manifest.json';prior=json.loads(prior_path.read_text());assert prior['primary_preserved'] and prior['primary_before']==original
record['initial_setup_failure']=dict(manifest=str(prior_path),sha256=sha(prior_path.read_bytes()),limits='I preserve the primary partial-clone promised-object failure. No source checkout or product gate completed. I fetch into a new standalone private Git database without repairing or modifying the primary.')
setup_path=root.with_name(root.name+'-resume')/'manifest.json';setup=json.loads(setup_path.read_text());assert setup['primary_preserved'] and setup['provider_guards_unchanged'] and setup['final_status']==''
record['completed_setup_reuse']=dict(manifest=str(setup_path),sha256=sha(setup_path.read_bytes()),limits='I retain the shell-selected Python3.14 missing-PyYAML import refusal; no corpus method executed. I reuse only its completed exact-source checkout and source/tool/provider/primary guards, and resume missing gates through the verified installed Python3.13 shell selector.')
save()
base_env=dict(os.environ,PATH='/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',MAKEFLAGS='-j1')
def step(name,args,cwd,env=base_env,timeout=3600):
 item=dict(name=name,argv=list(map(str,args)),cwd=str(cwd));record['steps'].append(item);save();started=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=a,stderr=b,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['elapsed_seconds']=time.monotonic()-started;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError(f'{name} failed with {item["returncode"]}')
 return item
expected=json.loads(expected_path.read_text())
def sources():
 actual={name:sha((root/name).read_bytes()) for name in expected};assert actual==expected,[name for name in expected if actual[name]!=expected[name]]
 return actual
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=None;tools={}
def guards():
 assert sources()==expected
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 if tools:assert {name:sha((root/name).read_bytes()) for name in tools}==tools
 assert primary_guard()==original
try:
 assert git('rev-parse','HEAD',cwd=root).decode().strip()==pin
 record['source_hashes']=sources();record['source_map_sha256']=sha(expected_path.read_bytes());save()
 sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
 b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 compiler=frozen/'bin/nanoc_stage1';record['provider']=dict(pin=git('rev-parse','HEAD',cwd=frozen).decode().strip(),compiler=str(compiler),compiler_sha256=sha(compiler.read_bytes()),receipt=str(frozen/'bin/nanoc_bootstrap.json'),receipt_sha256=sha((frozen/'bin/nanoc_bootstrap.json').read_bytes()),hosts=b.manifest['hosts'])
 env=dict(base_env,PYTHONPATH=str(root),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(root/'.test_output/linked-module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(compiler))
 for name in ['NANOLANG_TRANSLATOR_SOURCE_MODULE','NANO_CC','NANOLANG_BOOTSTRAP_NO_CC','NANO_AS_CAPTURE_HELPER']:env.pop(name,None)
 record['gate_environment']={name:env.get(name) for name in ['PATH','CC','MAKEFLAGS','NANOLANG_ROOT','NANO_MODULE_PATH','NANO_BUILD_CACHE','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']};save();guards()
 shutil.copy2(Path(sys.argv[3]),out/'run-linked-sanitizers.py')
 shutil.copy2(Path(sys.argv[4]),out/'run-unlinked-sanitizers.py')
 shutil.copy2(Path(sys.argv[5]),out/'health.json')
 (root/'.test_output').mkdir(exist_ok=True)
 tools=setup['tools'];record['tools']=tools;save();guards()
 selector=root.with_name(root.name+'-python')/'make-shell';assert sha(selector.read_bytes())=='b7a7e23f7b05bdd3008f086b7df3724405d32d8de51ce95adb125433799ff6ea'
 shutil.copy2(selector,out/'make-shell');shutil.copy2(selector.parent/'preflight.stdout',out/'python-preflight.stdout');shutil.copy2(selector.parent/'preflight.stderr',out/'python-preflight.stderr')
 record['python_shell_selection']=dict(shell=str(selector),sha256=sha(selector.read_bytes()),limits='I prefix the existing installed Python3.13 after host Bash startup changes PATH; Make recipes, C compiler, assertions, guest budgets and ordinary shadows are unchanged. I install nothing.')
 save()
 env['NANOLANG_LINKED_VERIFIER_PRODUCTS']=str(out/'linked-products')
 step('linked',['make','CC=/usr/bin/cc','SHELL='+str(selector),'test-nanolang-translator-linked-module-verifier'],root,env,timeout=7200);guards()
 env['NANOLANG_MODULE_VERIFIER_PRODUCTS']=str(out/'unlinked-products')
 step('unlinked',['make','CC=/usr/bin/cc','SHELL='+str(selector),'test-nanolang-translator-module-verifier'],root,env,timeout=7200);guards()
 step('linked-reference-sanitizers',['python3',out/'run-linked-sanitizers.py',out/'linked-products',out/'linked-reference-sanitizers'],root,env);guards()
 step('unlinked-reference-sanitizers',['python3',out/'run-unlinked-sanitizers.py',out/'unlinked-products',out/'unlinked-reference-sanitizers'],root,env);guards()
 step('identifiers',['make','CC=/usr/bin/cc','SHELL='+str(selector),'test-embedded-nano-identifiers'],root,env);guards()
 record['status']='passed';record['primary_after']=primary_guard();assert record['primary_after']==original
except BaseException as error:
 record['status']='failed';record['error']=repr(error);(out/'exception').write_text(traceback.format_exc())
finally:
 try:
  assert primary_guard()==original;record['primary_preserved']=True
  if b is not None:b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
  if root.exists():record['final_status']=git('status','--porcelain=v1','--untracked-files=all',cwd=root).decode();assert record['final_status']==''
 except BaseException as error:
  record['status']='failed';record['guard_error']=repr(error)
 save()
print(json.dumps({'status':record['status'],'root':str(root),'manifest':str(out/'manifest.json')}),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
