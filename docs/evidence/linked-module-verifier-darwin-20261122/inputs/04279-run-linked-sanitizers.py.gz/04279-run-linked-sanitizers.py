from pathlib import Path
import os,sys,subprocess,json,hashlib,shlex,time
root=Path.cwd();products=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
record=dict(status='running',sanitizer_environment={key:os.environ.get(key) for key in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},limits=['I instrument the actual public verifier/type/decoder/ISA and v2 module/reverse-converter providers plus the test oracle. Other linked providers retain ordinary instrumentation. I compare all raw-C normalized reports in both linked/graph public modes and all original linked source products; private C outcomes remain distinct from explicit pure deferral. This does not qualify complete private profiles or all linked providers.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
text=subprocess.check_output(['make','-Bn','CC=/usr/bin/cc','obj/nvm2c_linked_module_verifier_reference'],cwd=root,text=True);(out/'make-dry-run').write_text(text)
commands=[shlex.split(line) for line in text.replace('\\\n',' ').splitlines() if line.startswith('/usr/bin/cc ') and 'tests/nvm2c_linked_module_verifier_reference.c' in shlex.split(line)];assert len(commands)==1
providers={'obj/nanoisa/verifier.o':'src/nanoisa/verifier.c','obj/nanoisa/verifier_types.o':'src/nanoisa/verifier_types.c','obj/nanovm/vm_decode.o':'src/nanovm/vm_decode.c','obj/nanoisa/isa.o':'src/nanoisa/isa.c','obj/nanoisa/nvm_v2_convert.o':'src/nanoisa/nvm_v2_convert.c','obj/nanoisa/nvm_v2_module.o':'src/nanoisa/nvm_v2_module.c'}
args=[arg for arg in commands[0] if arg not in providers];exe=out/'reference-sanitized';args[args.index('-o')+1]=str(exe);args += [*providers.values(),'-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'];record['build_argv']=args;save();start=time.monotonic();p=subprocess.run(args,cwd=root,capture_output=True,timeout=600);(out/'build.stdout').write_bytes(p.stdout);(out/'build.stderr').write_bytes(p.stderr);record.update(build_returncode=p.returncode,build_seconds=time.monotonic()-start);save();assert p.returncode==0
paths=sorted((products/'inputs').glob('*.bin'),key=lambda p:int(p.stem));record['modes']={}
for declared,mode in [(False,'linked'),(True,'graph')]:
 start=time.monotonic();rows=[]
 for offset in range(0,len(paths),32):
  p=subprocess.run([exe,*(['--graph'] if declared else []),*paths[offset:offset+32]],cwd=root,capture_output=True,timeout=600);(out/f'{mode}-{offset:05d}.stdout').write_bytes(p.stdout);(out/f'{mode}-{offset:05d}.stderr').write_bytes(p.stderr);assert p.returncode==0,(mode,offset,p.returncode,p.stderr[-1000:]);rows+=p.stdout.decode().splitlines()
 assert rows==(products/f'{mode}-reference.txt').read_text().splitlines();record['modes'][mode]=dict(cases=len(rows),seconds=time.monotonic()-start);save()
 originals=sorted(products.glob('original-*.bin'));p=subprocess.run([exe,*(['--graph'] if declared else []),*originals],cwd=root,capture_output=True,timeout=600);(out/f'{mode}-originals.stdout').write_bytes(p.stdout);(out/f'{mode}-originals.stderr').write_bytes(p.stderr);assert p.returncode==0
 assert sorted(p.stdout.decode().splitlines())==sorted((products/f'original-{mode}-reference.txt').read_text().splitlines())
record['status']='passed';record['original_products']=len(originals);save();print(json.dumps({k:v for k,v in record.items() if k!='build_argv'}))
