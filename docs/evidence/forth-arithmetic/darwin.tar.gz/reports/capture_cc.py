from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys
args=sys.argv[1:];command=shlex.split(os.environ['FORTH_REAL_CC'])+args
rc=subprocess.call(command)
if rc==0 and '-o' in args:
 p=Path(args[args.index('-o')+1])
 if p.name in ('test_forth_session','test_forth_core_load') and p.parent==Path('tests/forth'):
  data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();dest=Path(os.environ['FORTH_CAPTURE'])
  dest.mkdir(exist_ok=True,parents=True);target=dest/p.name
  with target.open('xb') as f:f.write(data)
  target.chmod(p.stat().st_mode&0o777)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
  (dest/(p.name+'.json')).write_text(json.dumps({'source':str(p.resolve()),'copy':str(target),'sha256':digest,'bytes':len(data),'mode':p.stat().st_mode&0o777,'compiler_argv':command},indent=2)+'\n')
sys.exit(rc)
