from pathlib import Path
import subprocess,json,sys,time
base=Path(__file__).resolve().parent;r={'started':time.time(),'returncode':None,'error':None}
try:
 with (base/'outer.log').open('wb') as f:r['returncode']=subprocess.run([sys.executable,str(base/'driver.py')],stdout=f,stderr=subprocess.STDOUT).returncode
except Exception as e:r['error']=repr(e)
finally:r['finished']=time.time();(base/'outer.json').write_text(json.dumps(r,indent=2)+'\n')
