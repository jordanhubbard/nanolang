from pathlib import Path
import json,gzip,hashlib,struct
base=Path('.test_output');p=base/'stage2-vm-cpu-work-profile';m=json.loads((p/'manifest.json').read_text());window=m['steps'][-1]['window'];assert m['steps'][-1]['intentional_completed_window_stop'] and m['unchanged_authoritative_inputs'];rows=[json.loads(x) for x in (p/'collections.jsonl').read_text().splitlines()];assert len(rows)==27 and len({x['heap'] for x in rows})==1 and all(window['start_ns']<=x['mono_ns']<=window['end_ns'] for x in rows);delta={k:rows[-1][k]-rows[0][k] for k in ['mono_ns','passes','roots','visits','slots','allocated','freed','objects','allocations']};assert delta['passes']==81 and delta['roots']==81*4096 and delta['slots']==724507731
analysis=dict(records=len(rows),window=window,delta=delta,initial_retained=rows[0]['allocated']-rows[0]['freed'],final_retained=rows[-1]['allocated']-rows[-1]['freed'],limits=['I count actual object/child-slot inspections in completed collections of one observed heap. My private instrumentation changes timing; these are workload counts, not uninstrumented performance qualification.'])
(p/'collection-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
dest=Path('docs/evidence/gc-collection-work-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__)}
for name in ['stage2-vm-cpu-work-profile','cycle-work-observer','cycle-work-generation']:
 paths.update(x for x in (base/name).rglob('*') if x.is_file())
for name in ['prepare-gc-work-observer.py','run-cycle-work-regression.py','run-cycle-work-regression.log','link-cycle-work-vm.py','profile-vm-cpu-work.py','profile-vm-cpu-work.log']:
 paths.add(base/name)
sha=lambda x:hashlib.sha256(x).hexdigest();entries=[];seen={}
for i,x in enumerate(sorted(paths)):
 raw=x.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{x.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(x),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,analysis=analysis),indent=2)+'\n')
for x in entries:
 raw=(dest/x['artifact']).read_bytes();assert sha(raw)==x['compressed_sha256'] and sha(gzip.decompress(raw))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(x.stat().st_size for x in seen.values()))
