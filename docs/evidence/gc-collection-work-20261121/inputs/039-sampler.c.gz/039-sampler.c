#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>
static int sample_fd=-1;
static uint64_t owner_pid,owner_tid;
static void sample_cpu(int number,siginfo_t *info,void *context) {
    (void)number;(void)info;
    ucontext_t *u=context;
    uint64_t pc=0;
#if defined(__aarch64__)
    pc=u->uc_mcontext.pc;
#elif defined(__x86_64__)
    pc=(uint64_t)u->uc_mcontext.gregs[REG_RIP];
#endif
    struct timespec now;
    if(sample_fd>=0 && !clock_gettime(CLOCK_MONOTONIC,&now)) {
        uint64_t record[4]={(uint64_t)now.tv_sec*UINT64_C(1000000000)+(uint64_t)now.tv_nsec,pc,owner_pid,owner_tid};
        ssize_t written=write(sample_fd,record,sizeof(record));
        (void)written;
    }
}
__attribute__((constructor)) static void begin_cpu_samples(void) {
    const char *target=getenv("NANO_CPU_PROFILE_TARGET"),*path=getenv("NANO_CPU_PROFILE_OUTPUT");
    char actual[4096];ssize_t size=readlink("/proc/self/exe",actual,sizeof(actual)-1);
    if(!target || !path || size<0)return;
    actual[size]=0;
    if(strcmp(actual,target))return;
    owner_pid=(uint64_t)getpid();owner_tid=(uint64_t)syscall(SYS_gettid);
    int ok=1,err=0;timer_t timer;
    sample_fd=open(path,O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
    if(sample_fd<0){ok=0;err=errno;}
    int sig=SIGRTMIN+6;
    struct sigaction action={0};action.sa_sigaction=sample_cpu;action.sa_flags=SA_SIGINFO|SA_RESTART;sigemptyset(&action.sa_mask);
    if(ok && sigaction(sig,&action,NULL)){ok=0;err=errno;}
    sigset_t mask;sigemptyset(&mask);sigaddset(&mask,sig);
    if(ok && sigprocmask(SIG_UNBLOCK,&mask,NULL)){ok=0;err=errno;}
    struct sigevent event={0};event.sigev_notify=SIGEV_THREAD_ID;event.sigev_signo=sig;event._sigev_un._tid=(pid_t)owner_tid;
    if(ok && timer_create(CLOCK_THREAD_CPUTIME_ID,&event,&timer)){ok=0;err=errno;}
    struct itimerspec interval={.it_interval={.tv_nsec=10000000},.it_value={.tv_nsec=10000000}};
    if(ok && timer_settime(timer,0,&interval,NULL)){ok=0;err=errno;}
    const char *status=getenv("NANO_CPU_PROFILE_STATUS");
    if(status){FILE *f=fopen(status,"w");if(f){fprintf(f,"{\"enabled\":%s,\"errno\":%d,\"pid\":%llu,\"tid\":%llu,\"interval_ns\":10000000}\n",ok?"true":"false",err,(unsigned long long)owner_pid,(unsigned long long)owner_tid);fclose(f);}}
}
