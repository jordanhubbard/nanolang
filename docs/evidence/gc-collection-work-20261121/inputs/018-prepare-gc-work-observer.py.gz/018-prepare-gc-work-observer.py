from pathlib import Path
base=Path.cwd();s=(base/'src/nanovm/heap_cycles.c').read_text();needle='#include <string.h>\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''#include <stdio.h>
#include <time.h>
#include <unistd.h>
static uint64_t observed_visits, observed_slots, observed_passes, observed_roots;
static void record_gc_work(VmHeap *heap);
''') if False else s
# I put declarations after the actual heap types are available.
needle='#include "../nanoisa/isa.h"\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''#include <stdio.h>
#include <time.h>
#include <unistd.h>
static uint64_t observed_visits, observed_slots, observed_passes, observed_roots;
static void record_gc_work(VmHeap *heap) {
    static unsigned records;
    static uint64_t last;
    const char *arm = getenv("NANO_GC_WORK_ARM");
    const char *path = getenv("NANO_GC_WORK_LOG");
    if (!arm || !path || records >= 64 || access(arm, F_OK)) return;
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now)) return;
    uint64_t ns = (uint64_t)now.tv_sec * 1000000000u + now.tv_nsec;
    if (last && ns - last < 1000000000u) return;
    FILE *out = fopen(path, "a");
    if (!out) return;
    fprintf(out, "{\\"mono_ns\\":%llu,\\"heap\\":\\"%p\\",\\"passes\\":%llu,\\"roots\\":%llu,\\"visits\\":%llu,\\"slots\\":%llu,\\"allocated\\":%llu,\\"freed\\":%llu,\\"objects\\":%llu,\\"allocations\\":%llu,\\"pending_roots\\":%u}\\n",
        (unsigned long long)ns, (void *)heap,
        (unsigned long long)observed_passes, (unsigned long long)observed_roots,
        (unsigned long long)observed_visits, (unsigned long long)observed_slots,
        (unsigned long long)heap->stats.allocated, (unsigned long long)heap->stats.freed,
        (unsigned long long)heap->stats.num_objects,
        (unsigned long long)heap->stats.allocation_calls, heap->cycle_count);
    fclose(out);
    last = ns;
    records++;
}
''')
needle='static void for_each_child(VmHeap *heap, NanoValue v, ChildFn fn, void *ctx) {\n';assert s.count(needle)==1;s=s.replace(needle,needle+'    observed_visits++;\n')
for needle,insert in [('        for (uint32_t i = 0; i < a->length; i++) fn(heap, a->elements[i], ctx);','        observed_slots += a->length;\n'),('        for (uint32_t i = 0; i < s->field_count; i++) fn(heap, s->fields[i], ctx);','        observed_slots += s->field_count;\n        if (s->field_names) observed_slots += s->field_count;\n'),('        for (uint32_t i = 0; i < u->field_count; i++) fn(heap, u->fields[i], ctx);','        observed_slots += u->field_count;\n'),('        for (uint32_t i = 0; i < t->count; i++) fn(heap, t->elements[i], ctx);','        observed_slots += t->count;\n'),('            fn(heap, m->entries[i].key, ctx);','            observed_slots += 2;\n'),('        for (uint16_t i = 0; i < c->capture_count; i++) fn(heap, c->captures[i], ctx);','        observed_slots += c->capture_count;\n')]:
 assert s.count(needle)==1,needle;s=s.replace(needle,insert+needle)
needle='    uint32_t count = heap->cycle_count;\n';assert s.count(needle)==1;s=s.replace(needle,needle+'    observed_passes++;\n    observed_roots += count;\n')
needle='    heap->gc_running = false;\n    return freed;';assert s.count(needle)==1;s=s.replace(needle,'    heap->gc_running = false;\n    record_gc_work(heap);\n    return freed;')
out=base/'.test_output/cycle-work-observer';out.mkdir(exist_ok=False);(out/'heap_cycles.c').write_text(s)
s=(base/'.test_output/run-cycle-inline-regression.py').read_text().replace('cycle-inline-candidate','cycle-work-observer').replace('private inlined collector candidate','private work-observer collector');(base/'.test_output/run-cycle-work-regression.py').write_text(s)
