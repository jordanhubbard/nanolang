from pathlib import Path
import json,os,shlex,signal,subprocess,sys,time
old=Path('/home/jkh/Src/nanolang-callable-ownership');base=Path.cwd();out=base/'.test_output/cycle-work-generation';out.mkdir(exist_ok=False);sys.path.insert(0,str(old));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1.nvm']);opts={l.partition('=')[0]:l.partition('=')[2] for l in (base/'.test_output/vm-profile-inputs.log').read_text().splitlines() if l.startswith('PROFILE_')};collector=base/'.test_output/cycle-work-observer/heap_cycles.o';proof=json.loads((base/'.test_output/cycle-work-observer/manifest.json').read_text());assert proof['source_sha256']==digest(base/'.test_output/cycle-work-observer/heap_cycles.c');objects=shlex.split(opts['PROFILE_OBJECTS']);assert objects.count('obj/nanovm/heap_cycles.o')==1;objects=[str(collector) if x=='obj/nanovm/heap_cycles.o' else x for x in objects];binary=out/'nano_vm';record=dict(original_pin='74644c29f',base_checkout_pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),collector_source_sha256=proof['source_sha256'],compiler_module_sha256=digest(old/'bin/nanoc_stage1.nvm'),steps=[],limits=['I test a genuine candidate VM with only the packed-leaf exclusion and private traversal counters replaced among original linked providers. I do not overwrite the authoritative VM/receipt or alias any stage. Fresh exact-source bootstrap and Darwin acceptance remain separate.'])
def run(argv,label,env=None):
 argv=list(map(str,argv));r=dict(label=label,argv=argv);record['steps'].append(r);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(argv,cwd=old,env=env,stdout=a,stderr=c,start_new_session=True);r['pid']=p.pid
  try:r['returncode']=p.wait(timeout=1800)
  except BaseException as error:os.killpg(p.pid,signal.SIGKILL);p.wait();r['error']=repr(error);raise
  finally:r['elapsed_seconds']=time.monotonic()-t;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 if r['returncode']:raise RuntimeError(r)
run([*shlex.split(opts['PROFILE_CC']),*shlex.split(opts['PROFILE_CFLAGS']),'-o',binary,*objects,*shlex.split(opts['PROFILE_LDFLAGS'])],'link-candidate-vm');record['candidate_vm_sha256']=digest(binary);(out/'candidate-collector.c').write_bytes((base/'.test_output/cycle-work-observer/heap_cycles.c').read_bytes())

record['link_only']=True;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
