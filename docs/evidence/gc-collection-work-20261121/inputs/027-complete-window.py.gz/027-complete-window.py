import json,sys,time
from pathlib import Path
start=int(sys.argv[1]);pid=int(sys.argv[2]);target=Path(sys.argv[3]);time.sleep(max(0,(start+30000000000-time.monotonic_ns())/1e9));temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(dict(start_ns=start,end_ns=time.monotonic_ns(),pid=pid))+'\n');temporary.replace(target)
