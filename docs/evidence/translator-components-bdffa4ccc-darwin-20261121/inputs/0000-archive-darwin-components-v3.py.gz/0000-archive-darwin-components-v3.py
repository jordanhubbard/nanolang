from pathlib import Path
import json,re,gzip,hashlib,sys
root=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(root,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
c=root/'.test_output/current-darwin-components';state=json.loads((c/'manifest.json').read_text());assert state['status']=='passed'
out=root/'.test_output/preserved-darwin-components-bdffa4ccc-20261121-v3';(out/'inputs').mkdir(parents=True,exist_ok=False)
missing=[]
paths={Path(__file__).resolve(),root/'.test_output/run-current-darwin-components.py',root/'bin/nanoc_stage1',root/'bin/nanoc_bootstrap.json'};paths.update(p for p in c.rglob('*') if p.is_file());reports=[]
for p in c.glob('*.stdout'):
 for line in p.read_text().splitlines():
  if line.startswith('I '):reports.append(line)
  if line.startswith('I retain ') and ' at /' in line:
   directory=Path(line.split(' at ',1)[1]);assert directory.is_relative_to(root/'.test_output') or str(directory)=='/var/folders/v0/pxyl2_m512v5j9nhv674pt400000gn/T/shared-service-modules-uhqmxdps/products';missing.extend([str(directory)] if not directory.is_dir() else []);paths.update(q for q in directory.rglob('*') if q.is_file())
paths.update(p for p in (root/'obj').glob('*reference*') if p.is_file())
for directory in (root/'.test_output').glob('nanolang-functions-products-*'):paths.update(p for p in directory.rglob('*') if p.is_file())
for folder in ['src_nano/nvm2c','tests']:
 for p in (root/folder).iterdir():
  if p.is_file() and (folder!='tests' or p.name.startswith(('nvm2c_','test_nanolang_translator','nanolang_translator'))):paths.add(p)
seen={};files=[];sha=lambda x:hashlib.sha256(x).hexdigest()
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw)
 if h not in seen:
  artifact=f'inputs/{i:04d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 artifact=seen[h];packed=(out/artifact).read_bytes();files.append(dict(path=str(p),artifact=artifact,bytes=len(raw),sha256=h,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
(out/'manifest.json').write_text(json.dumps(dict(state=state,reports=reports,missing_temporary_products=missing,files=files),indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(files),compressed_bytes=sum((out/x).stat().st_size for x in seen.values()),state=state,reports=reports)))
