from pathlib import Path
import os,sys,subprocess,time,signal,json,traceback,hashlib
root=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(root,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));out=root/'.test_output/current-darwin-components';out.mkdir(exist_ok=False);env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(root/'bin/nanoc_stage1'))
for key in ['NANOLANG_TRANSLATOR_SOURCE_MODULE','NANO_SHADOW_TIMEOUT_SECONDS','NANO_CC','NANO_CFLAGS','NANO_LDFLAGS','NANO_AS_CAPTURE_HELPER']:env.pop(key,None)
record=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_compiler_sha256=digest(root/'bin/nanoc_stage1'),steps=[],limits=['I run additional component gates only after both coordinated Darwin bootstrap handles terminate and my complete bdffa4ccc result is preserved. I use that actual qualified native Stage1 without aliases, keep ordinary shadow deadlines, preserve all original cases and recheck original bootstrap guards. This does not qualify later parser/checker/workflow changes, full profile analysis or pure translator cutover.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,targets):
 args=['make','CC=/usr/bin/cc',*targets];t=time.monotonic();s=dict(label=label,argv=args);record['steps'].append(s);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=c,start_new_session=True);s['pid']=p.pid;save()
  try:s['returncode']=p.wait(timeout=7200)
  except subprocess.TimeoutExpired:s['driver_timeout']=True;os.killpg(p.pid,signal.SIGKILL);s['returncode']=p.wait()
 s['elapsed_seconds']=time.monotonic()-t;save();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));s['bootstrap_guards_unchanged']=True;save();assert s['returncode']==0,s
try:
 run('original-module-regressions',['test-nanolang-translator-service-modules','test-nanolang-translator-module','test-nanolang-translator-service-nominal','test-nanolang-translator-ownership-module','test-nanolang-translator-passive-module'])
 run('original-functions',['test-nanolang-translator-functions'])
 run('original-recipes',['test-nanolang-translator-record-instructions'])
 run('original-heights',['test-nanolang-translator-record-stack'])
 record['status']='passed';save()
except BaseException as error:
 record.update(status='failed',error=repr(error));save();traceback.print_exc();sys.exit(1)
