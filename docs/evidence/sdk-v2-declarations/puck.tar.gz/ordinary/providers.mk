include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(NANOISA_OBJECTS) $(NANOISA_UTF8)
	@printf '%s\n' '$(NANOISA_OBJECTS) $(NANOISA_UTF8)' > /Users/jkh/nanolang-qualification/declaration-v2-8bf-puck/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /Users/jkh/nanolang-qualification/declaration-v2-8bf-puck/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /Users/jkh/nanolang-qualification/declaration-v2-8bf-puck/ordinary/ldflags.txt
