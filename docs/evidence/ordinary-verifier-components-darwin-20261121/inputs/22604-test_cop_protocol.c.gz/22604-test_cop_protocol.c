/*
 * test_cop_protocol.c — unit tests for src/nanovm/cop_protocol.c
 *
 * Exercises: cop_serialize_value, cop_deserialize_value (round-trips),
 * cop_send/cop_recv_header/cop_recv_payload/cop_send_simple (via pipes).
 */

#include <stddef.h>  /* NULL */

/* Required by runtime/cli.c */
int g_argc = 0;
char **g_argv = NULL;
char g_project_root[4096] = ".";
const char *get_project_root(void) { return g_project_root; }

#include "../../src/nanovm/cop_protocol.h"
#include "../../src/nanovm/vm_ffi.h"
#include "../../src/nanoisa/nvm_format.h"
#include "../../src/nanovm/heap.h"
#include "../../src/nanovm/value.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

static int g_pass = 0, g_fail = 0;
#define TEST(name) static void test_##name(void)
#define RUN(name)  do { test_##name(); \
    printf("  %-55s PASS\n", #name "..."); g_pass++; } while(0)
#define ASSERT(cond) do { if (!(cond)) { \
    printf("  FAIL: %s  (%s:%d)\n", #cond, __FILE__, __LINE__); \
    g_fail++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if ((a) != (b)) { \
    printf("  FAIL: %s == %s  (%s:%d)\n", #a, #b, __FILE__, __LINE__); \
    g_fail++; return; } } while(0)

/* ── Serialize/Deserialize round-trip helpers ──────────────────────────── */

TEST(serialize_int) {
    uint8_t buf[32];
    NanoValue v = val_int(42);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);  /* 1 tag + 8 bytes */
    ASSERT(buf[0] == TAG_INT);

    VmHeap heap = {0};
    NanoValue out;
    uint32_t consumed = cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(consumed == n);
    ASSERT(out.tag == TAG_INT);
    ASSERT(out.as.i64 == 42);
}

TEST(serialize_negative_int) {
    uint8_t buf[32];
    NanoValue v = val_int(-1000);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);

    VmHeap heap = {0};
    NanoValue out;
    cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(out.tag == TAG_INT);
    ASSERT(out.as.i64 == -1000);
}

TEST(serialize_int_little_endian) {
    uint8_t buf[32];
    NanoValue v = val_int((int64_t)0x0102030405060708LL);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);
    ASSERT(buf[1] == 0x08 && buf[2] == 0x07 && buf[3] == 0x06);
    ASSERT(buf[4] == 0x05 && buf[5] == 0x04 && buf[6] == 0x03);
    ASSERT(buf[7] == 0x02 && buf[8] == 0x01);
}

TEST(deserialize_int_little_endian) {
    const uint8_t wire[] = {TAG_INT, 0x08, 0x07, 0x06, 0x05,
                            0x04, 0x03, 0x02, 0x01};
    VmHeap heap = {0};
    NanoValue out;
    ASSERT(cop_deserialize_value(wire, sizeof(wire), &out, &heap) == sizeof(wire));
    ASSERT(out.as.i64 == (int64_t)0x0102030405060708LL);
}

TEST(serialize_float) {
    uint8_t buf[32];
    NanoValue v = val_float(3.14);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);  /* 1 tag + 8 bytes */

    VmHeap heap = {0};
    NanoValue out;
    cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(out.tag == TAG_FLOAT);
    ASSERT(out.as.f64 > 3.13 && out.as.f64 < 3.15);
}

TEST(serialize_float_little_endian) {
    uint8_t buf[32];
    NanoValue v = val_float(1.0);
    ASSERT(cop_serialize_value(&v, buf, sizeof(buf)) == 9);
    ASSERT(buf[1] == 0x00 && buf[2] == 0x00 && buf[3] == 0x00);
    ASSERT(buf[4] == 0x00 && buf[5] == 0x00 && buf[6] == 0x00);
    ASSERT(buf[7] == 0xf0 && buf[8] == 0x3f);
}

TEST(serialize_bool_true) {
    uint8_t buf[8];
    NanoValue v = val_bool(true);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 2);  /* 1 tag + 1 byte */

    VmHeap heap = {0};
    NanoValue out;
    cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(out.tag == TAG_BOOL);
    ASSERT(out.as.boolean == true);
}

TEST(serialize_bool_false) {
    uint8_t buf[8];
    NanoValue v = val_bool(false);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 2);

    VmHeap heap = {0};
    NanoValue out;
    cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(out.tag == TAG_BOOL);
    ASSERT(out.as.boolean == false);
}

TEST(serialize_void) {
    uint8_t buf[8];
    NanoValue v = val_void();
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 1);  /* tag only */

    VmHeap heap = {0};
    NanoValue out;
    uint32_t consumed = cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(consumed == 1);
    ASSERT(out.tag == TAG_VOID);
}

TEST(serialize_buffer_too_small) {
    uint8_t buf[4];  /* too small for int (needs 9) */
    NanoValue v = val_int(99);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 0);  /* fails gracefully */
}

TEST(deserialize_truncated) {
    uint8_t buf[32];
    NanoValue v = val_int(123);
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);

    VmHeap heap = {0};
    NanoValue out;
    /* Truncate buffer to 3 bytes (too short for int payload) */
    uint32_t consumed = cop_deserialize_value(buf, 3, &out, &heap);
    ASSERT(consumed == 0);
}

TEST(serialize_opaque) {
    uint8_t buf[32];
    NanoValue v;
    v.tag = TAG_OPAQUE;
    v.as.i64 = 12345;
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    ASSERT(n == 9);

    VmHeap heap = {0};
    NanoValue out;
    cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(out.tag == TAG_OPAQUE);
    ASSERT(out.as.i64 == 12345);
}

/* ── Pipe-based send/recv tests ────────────────────────────────────────── */

TEST(send_recv_simple) {
    int fds[2];
    ASSERT(pipe(fds) == 0);

    bool sent = cop_send_simple(fds[1], COP_MSG_READY);
    ASSERT(sent);

    CopMsgHeader hdr;
    bool ok = cop_recv_header(fds[0], &hdr);
    ASSERT(ok);
    ASSERT(hdr.msg_type == COP_MSG_READY);
    ASSERT(hdr.payload_len == 0);
    ASSERT(hdr.version == COP_PROTO_VERSION);

    close(fds[0]);
    close(fds[1]);
}

TEST(send_recv_with_payload) {
    int fds[2];
    ASSERT(pipe(fds) == 0);

    const char *payload = "hello world";
    uint32_t len = (uint32_t)strlen(payload);
    bool sent = cop_send(fds[1], COP_MSG_FFI_RESULT, payload, len);
    ASSERT(sent);

    CopMsgHeader hdr;
    bool ok = cop_recv_header(fds[0], &hdr);
    ASSERT(ok);
    ASSERT(hdr.msg_type == COP_MSG_FFI_RESULT);
    ASSERT_EQ(hdr.payload_len, len);

    char buf[64] = {0};
    ok = cop_recv_payload(fds[0], buf, len);
    ASSERT(ok);
    ASSERT(strcmp(buf, "hello world") == 0);

    close(fds[0]);
    close(fds[1]);
}

TEST(recv_header_fixed_little_endian) {
    int fds[2];
    ASSERT(pipe(fds) == 0);
    const uint8_t wire[] = {COP_PROTO_VERSION, COP_MSG_FFI_REQ, 0, 0,
                            0x04, 0x00, 0x00, 0x00};
    ASSERT(write(fds[1], wire, sizeof(wire)) == (ssize_t)sizeof(wire));
    CopMsgHeader hdr;
    ASSERT(cop_recv_header(fds[0], &hdr));
    ASSERT(hdr.payload_len == 4);
    close(fds[0]);
    close(fds[1]);
}

TEST(recv_header_rejects_reserved_bits) {
    int fds[2];
    ASSERT(pipe(fds) == 0);
    const uint8_t wire[] = {COP_PROTO_VERSION, COP_MSG_READY, 1, 0, 0, 0, 0, 0};
    ASSERT(write(fds[1], wire, sizeof(wire)) == (ssize_t)sizeof(wire));
    CopMsgHeader hdr;
    ASSERT(!cop_recv_header(fds[0], &hdr));
    close(fds[0]);
    close(fds[1]);
}

TEST(recv_header_rejects_oversized_payload) {
    int fds[2];
    ASSERT(pipe(fds) == 0);
    const uint8_t wire[] = {COP_PROTO_VERSION, COP_MSG_FFI_REQ, 0, 0,
                            0x01, 0x00, 0x00, 0x01};
    ASSERT(write(fds[1], wire, sizeof(wire)) == (ssize_t)sizeof(wire));
    CopMsgHeader hdr;
    ASSERT(!cop_recv_header(fds[0], &hdr));
    close(fds[0]);
    close(fds[1]);
}

TEST(recv_header_closed_pipe) {
    int fds[2];
    ASSERT(pipe(fds) == 0);
    close(fds[1]);  /* Close write end — recv should fail */

    CopMsgHeader hdr;
    bool ok = cop_recv_header(fds[0], &hdr);
    ASSERT(!ok);

    close(fds[0]);
}

TEST(send_recv_shutdown_msg) {
    int fds[2];
    ASSERT(pipe(fds) == 0);

    cop_send_simple(fds[1], COP_MSG_SHUTDOWN);

    CopMsgHeader hdr;
    cop_recv_header(fds[0], &hdr);
    ASSERT(hdr.msg_type == COP_MSG_SHUTDOWN);

    close(fds[0]);
    close(fds[1]);
}

/* ── String and Array serialization (covers lines 43-79, 120-157) ───────── */

TEST(serialize_string_roundtrip) {
    VmHeap heap = {0};
    vm_heap_init(&heap);

    VmString *s = vm_string_new(&heap, "hello", 5);
    ASSERT(s != NULL);
    NanoValue v = val_string(s);

    uint8_t buf[64];
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    /* TAG_STRING: 1 tag + 4 len + 5 data = 10 bytes */
    ASSERT(n == 10);
    ASSERT(buf[0] == TAG_STRING);

    VmHeap heap2 = {0};
    vm_heap_init(&heap2);
    NanoValue out;
    uint32_t consumed = cop_deserialize_value(buf, n, &out, &heap2);
    ASSERT(consumed == n);
    ASSERT(out.tag == TAG_STRING);
    ASSERT(out.as.string != NULL);
    ASSERT(memcmp(out.as.string->data, "hello", 5) == 0);

    vm_heap_destroy(&heap);
    vm_heap_destroy(&heap2);
}

TEST(serialize_string_null) {
    /* TAG_STRING with NULL VmString: serializes as empty string */
    NanoValue v;
    memset(&v, 0, sizeof(v));
    v.tag = TAG_STRING;
    v.as.string = NULL;

    uint8_t buf[64];
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    /* 1 tag + 4 len(=0) = 5 bytes */
    ASSERT(n == 5);
    ASSERT(buf[0] == TAG_STRING);

    VmHeap heap = {0};
    vm_heap_init(&heap);
    NanoValue out;
    uint32_t consumed = cop_deserialize_value(buf, n, &out, &heap);
    ASSERT(consumed == n);
    ASSERT(out.tag == TAG_STRING);
    vm_heap_destroy(&heap);
}

TEST(serialize_string_length_little_endian) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmString *s = vm_string_new(&heap, "x", 1);
    NanoValue v = val_string(s);
    uint8_t buf[32];
    ASSERT(cop_serialize_value(&v, buf, sizeof(buf)) == 6);
    ASSERT(buf[1] == 0x01 && buf[2] == 0x00 && buf[3] == 0x00 && buf[4] == 0x00);
    vm_heap_destroy(&heap);
}

TEST(deserialize_hostile_lengths) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    NanoValue out;
    const uint8_t huge_string[] = {TAG_STRING, 0xff, 0xff, 0xff, 0xff};
    const uint8_t huge_array[] = {TAG_ARRAY, TAG_INT, 0xff, 0xff, 0xff, 0xff};
    ASSERT(cop_deserialize_value(huge_string, sizeof(huge_string), &out, &heap) == 0);
    ASSERT(cop_deserialize_value(huge_array, sizeof(huge_array), &out, &heap) == 0);
    vm_heap_destroy(&heap);
}

TEST(decode_nested_array_ownership) {
    const uint8_t wire[] = {
        TAG_ARRAY, TAG_ARRAY, 1, 0, 0, 0,
        TAG_ARRAY, TAG_STRING, 2, 0, 0, 0,
        TAG_STRING, 1, 0, 0, 0, 'a',
        TAG_STRING, 1, 0, 0, 0, 'b'
    };
    VmHeap heap;
    vm_heap_init(&heap);
    for (size_t length = 0; length < sizeof(wire); length++) {
        NanoValue out = val_void();
        ASSERT(cop_deserialize_value(wire, (uint32_t)length, &out, &heap) == 0);
        ASSERT(heap.stats.num_objects == 0);
    }
    NanoValue out = val_void();
    ASSERT(cop_deserialize_value(wire, sizeof(wire), &out, &heap) == sizeof(wire));
    ASSERT(out.tag == TAG_ARRAY && out.as.array->length == 1);
    NanoValue inner = vm_array_get(out.as.array, 0);
    ASSERT(inner.tag == TAG_ARRAY && inner.as.array->header.ref_count == 1);
    ASSERT(inner.as.array->length == 2);
    for (unsigned i = 0; i < 2; i++) {
        NanoValue string = vm_array_get(inner.as.array, i);
        ASSERT(string.tag == TAG_STRING && string.as.string->header.ref_count == 1);
    }
    vm_release(&heap, out);
    vm_gc_collect_cycles(&heap);
    ASSERT(heap.stats.num_objects == 0);
    vm_heap_destroy(&heap);
}

TEST(serialize_array_roundtrip) {
    VmHeap heap = {0};
    vm_heap_init(&heap);

    /* Build an int array [1, 2, 3] */
    VmArray *arr = vm_array_new(&heap, TAG_INT, 4);
    ASSERT(arr != NULL);
    vm_array_push(&heap, arr, val_int(1));
    vm_array_push(&heap, arr, val_int(2));
    vm_array_push(&heap, arr, val_int(3));

    NanoValue v = val_array(arr);
    uint8_t buf[256];
    uint32_t n = cop_serialize_value(&v, buf, sizeof(buf));
    /* 1 tag + 1 etype + 4 count + 3*(1 tag + 8 val) = 6 + 27 = 33 */
    ASSERT(n > 0);
    ASSERT(buf[0] == TAG_ARRAY);

    VmHeap heap2 = {0};
    vm_heap_init(&heap2);
    NanoValue out;
    uint32_t consumed = cop_deserialize_value(buf, n, &out, &heap2);
    ASSERT(consumed == n);
    ASSERT(out.tag == TAG_ARRAY);
    ASSERT(out.as.array != NULL);
    ASSERT(out.as.array->length == 3);

    vm_heap_destroy(&heap);
    vm_heap_destroy(&heap2);
}


/* ── Batched co-process dispatch (end-to-end fork) ─────────────────────── */

/* Build a throwaway module exposing libc `abs` as import 0 (int -> int). */
static NvmModule *make_abs_module(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t mod_idx = nvm_add_string(mod, "", 0);          /* bare extern */
    uint32_t fn_idx  = nvm_add_string(mod, "abs", 3);
    uint8_t param_types[1] = { TAG_INT };
    nvm_add_import(mod, mod_idx, fn_idx, 1, TAG_INT, param_types);
    return mod;
}

static void cop_vm_init(VmState *vm) {
    memset(vm, 0, sizeof(*vm));
    vm->cop_pid = -1;
    vm->cop_in_fd = -1;
    vm->cop_out_fd = -1;
    vm->cop_sig_send_fd = -1;
    vm->cop_sig_recv_fd = -1;
    vm->cop_timeout_ms = 5000;
    vm->isolate_ffi = true;
}

TEST(batch_roundtrip_many_calls) {
    NvmModule *mod = make_abs_module();
    VmState vm; cop_vm_init(&vm);
    VmHeap heap; vm_heap_init(&heap);

    enum { N = 64 };
    CopBatchCall calls[N];
    NanoValue argbuf[N];
    NanoValue results[N];
    for (int i = 0; i < N; i++) {
        argbuf[i] = val_int(-(i + 1));
        calls[i].import_idx = 0;
        calls[i].args = &argbuf[i];
        calls[i].arg_count = 1;
    }

    char err[256] = {0};
    bool ok = vm_ffi_call_cop_batch(&vm, mod, calls, N, results, &heap,
                                    err, sizeof(err));
    ASSERT(ok);
    for (int i = 0; i < N; i++) {
        ASSERT(results[i].tag == TAG_INT);
        ASSERT_EQ(results[i].as.i64, (int64_t)(i + 1));  /* abs(-(i+1)) */
        vm_release(&heap, results[i]);
    }
    NanoValue single_arg = val_int(-123), single_result;
    ASSERT(vm_ffi_call_cop(&vm, mod, 0, &single_arg, 1, &single_result, &heap,
                          err, sizeof err));
    ASSERT(single_result.tag == TAG_INT && single_result.as.i64 == 123);
    vm_release(&heap, single_result);

    vm_ffi_cop_stop(&vm);
    vm_heap_destroy(&heap);
    nvm_module_free(mod);
}

TEST(batch_empty_is_noop) {
    NvmModule *mod = make_abs_module();
    VmState vm; cop_vm_init(&vm);
    VmHeap heap; vm_heap_init(&heap);

    NanoValue results[1];
    char err[256] = {0};
    bool ok = vm_ffi_call_cop_batch(&vm, mod, NULL, 0, results, &heap,
                                    err, sizeof(err));
    ASSERT(ok);
    /* No co-process should have been launched for an empty batch. */
    ASSERT(vm.cop_pid <= 0);

    vm_ffi_cop_stop(&vm);
    vm_heap_destroy(&heap);
    nvm_module_free(mod);
}

TEST(batch_bad_import_reports_error) {
    NvmModule *mod = make_abs_module();
    VmState vm; cop_vm_init(&vm);
    VmHeap heap; vm_heap_init(&heap);

    NanoValue a0 = val_int(-7);
    NanoValue a1 = val_int(-9);
    CopBatchCall calls[2] = {
        { .import_idx = 0,   .args = &a0, .arg_count = 1 },  /* valid */
        { .import_idx = 999, .args = &a1, .arg_count = 1 },  /* out of range */
    };
    NanoValue results[2];
    char err[256] = {0};
    bool ok = vm_ffi_call_cop_batch(&vm, mod, calls, 2, results, &heap,
                                    err, sizeof(err));
    ASSERT(!ok);
    ASSERT(err[0] != '\0');
    /* The first (valid) call completed before the failure. */
    ASSERT(results[0].tag == TAG_INT);
    ASSERT_EQ(results[0].as.i64, 7);
    vm_release(&heap, results[0]);

    vm_ffi_cop_stop(&vm);
    vm_heap_destroy(&heap);
    nvm_module_free(mod);
}

/* ── main ──────────────────────────────────────────────────────────────── */

/* ── Large payloads ──────────────────────────────────────────────────────
 *
 * The mailbox fast path has 4 KB slots, so anything bigger travels the pipe
 * path, which COP_MAX_PAYLOAD sizes at 16 MB. Nothing exercised a payload
 * above 256 bytes: the fuzzer only checks that a length ABOVE the cap is
 * rejected, which says nothing about whether a legal large one arrives
 * intact. A pipe has a capacity of a few dozen KB, so a megabyte cannot be
 * written and then read by one process -- it needs a reader draining
 * concurrently, which is why this forks.
 */

#define LARGE_PAYLOAD_BYTES (1u * 1024u * 1024u)

TEST(large_payload_survives_the_pipe) {
    uint8_t *sent = malloc(LARGE_PAYLOAD_BYTES);
    ASSERT(sent != NULL);
    /* A pattern that catches truncation, duplication and byte swaps rather
     * than a constant fill, which would survive all three. */
    for (uint32_t i = 0; i < LARGE_PAYLOAD_BYTES; i++)
        sent[i] = (uint8_t)((i * 31u + (i >> 8)) & 0xFF);

    int fds[2];
    if (pipe(fds) != 0) { free(sent); ASSERT(0); }

    pid_t pid = fork();
    if (pid < 0) { close(fds[0]); close(fds[1]); free(sent); ASSERT(0); }
    if (pid == 0) {
        close(fds[0]);
        bool ok = cop_send(fds[1], COP_MSG_FFI_RESULT, sent, LARGE_PAYLOAD_BYTES);
        close(fds[1]);
        free(sent);
        _exit(ok ? 0 : 1);
    }
    close(fds[1]);

    CopMsgHeader hdr;
    bool got_header = cop_recv_header(fds[0], &hdr);
    uint8_t *received = malloc(LARGE_PAYLOAD_BYTES);
    bool got_payload = false;
    if (got_header && received && hdr.payload_len == LARGE_PAYLOAD_BYTES)
        got_payload = cop_recv_payload(fds[0], received, hdr.payload_len);
    close(fds[0]);
    int status = 0;
    waitpid(pid, &status, 0);

    ASSERT(got_header);
    ASSERT_EQ(hdr.payload_len, LARGE_PAYLOAD_BYTES);
    ASSERT_EQ(hdr.msg_type, COP_MSG_FFI_RESULT);
    ASSERT(got_payload);
    ASSERT(received != NULL);
    ASSERT_EQ(memcmp(sent, received, LARGE_PAYLOAD_BYTES), 0);
    free(sent);
    free(received);
}

TEST(large_string_value_survives_the_pipe) {
    /* The same path carrying a serialized NanoValue rather than raw bytes:
     * a string long enough that its length field matters. */
    const uint32_t len = 512u * 1024u;
    char *text = malloc(len);
    ASSERT(text != NULL);
    for (uint32_t i = 0; i < len; i++) text[i] = (char)('a' + (i % 26));
    /* One embedded zero, because the length field is the only thing that
     * makes it survive. */
    text[len / 2] = '\0';

    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmString *str = vm_string_new(&heap, text, len);
    ASSERT(str != NULL);
    NanoValue v = val_string(str);
    uint32_t bufsize = len + 64;
    uint8_t *buf = malloc(bufsize);
    ASSERT(buf != NULL);
    uint32_t written = cop_serialize_value(&v, buf, bufsize);
    ASSERT(written == 1 + 4 + len);

    NanoValue back;
    uint32_t consumed = cop_deserialize_value(buf, written, &back, &heap);
    ASSERT_EQ(consumed, written);
    ASSERT_EQ(back.tag, TAG_STRING);
    ASSERT(back.as.string != NULL);
    ASSERT_EQ(back.as.string->length, len);
    ASSERT_EQ(memcmp(back.as.string->data, text, len), 0);

    vm_heap_destroy(&heap);
    free(buf);
    free(text);
}

TEST(wire_header_byte_layout_is_fixed) {
    /* The wire header is little-endian by construction rather than by
     * host accident: version, type, two reserved zero bytes, then the
     * payload length low byte first. Pinning the exact bytes is what makes
     * that a guarantee instead of a comment -- a host-order struct write
     * would pass every same-machine test and fail across architectures. */
    int fds[2];
    if (pipe(fds) != 0) { ASSERT(0); }
    ASSERT(cop_send(fds[1], COP_MSG_FFI_RESULT, "abcd", 4));
    uint8_t wire[COP_HEADER_SIZE + 4];
    ASSERT_EQ(read(fds[0], wire, sizeof(wire)), (ssize_t)sizeof(wire));
    close(fds[0]); close(fds[1]);

    ASSERT_EQ(wire[0], COP_PROTO_VERSION);
    ASSERT_EQ(wire[1], (uint8_t)COP_MSG_FFI_RESULT);
    ASSERT_EQ(wire[2], 0);
    ASSERT_EQ(wire[3], 0);
    ASSERT_EQ(wire[4], 4);   /* length low byte first */
    ASSERT_EQ(wire[5], 0);
    ASSERT_EQ(wire[6], 0);
    ASSERT_EQ(wire[7], 0);
    ASSERT_EQ(memcmp(wire + COP_HEADER_SIZE, "abcd", 4), 0);
}

TEST(a_payload_over_the_cap_is_refused_by_the_sender) {
    /* The receiver already rejects an oversized declared length. The sender
     * must refuse too, or it writes a header the peer will hang up on. */
    int fds[2];
    if (pipe(fds) != 0) { ASSERT(0); }
    static const uint8_t one = 0;
    ASSERT(!cop_send(fds[1], COP_MSG_FFI_RESULT, &one, COP_MAX_PAYLOAD + 1));
    close(fds[0]); close(fds[1]);
}

TEST(call_envelope_aliases_and_atomic_reply) {
    VmHeap heap;
    vm_heap_init(&heap);
    VmArray *a = vm_array_new(&heap, TAG_U8, 4);
    ASSERT(a && vm_array_push(&heap, a, val_u8(7)));
    NanoValue args[] = {val_array(a), val_array(a)};
    uint8_t wire[256];
    uint32_t n = cop_encode_call_values(args, 2, wire, sizeof wire);
    ASSERT(n > 0);
    NanoValue child[3];
    ASSERT(cop_decode_call_values(wire, n, child, 2, &heap));
    ASSERT(child[0].as.array == child[1].as.array && child[0].as.array != a);
    vm_array_set(child[0].as.array, 0, val_u8(99));
    child[2] = child[0]; /* encoding borrows; I own only the first two refs */
    n = cop_encode_call_values(child, 3, wire, sizeof wire);
    ASSERT(n > 0);
    NanoValue result = val_void();
    for (uint32_t truncated = 0; truncated < n; ++truncated) {
        ASSERT(!cop_apply_call_reply(wire, truncated, args, 2, &result, &heap));
        ASSERT_EQ(vm_array_get(a, 0).as.u8, 7);
    }
    wire[n] = 0;
    ASSERT(!cop_apply_call_reply(wire, n + 1, args, 2, &result, &heap));
    ASSERT(cop_apply_call_reply(wire, n, args, 2, &result, &heap));
    ASSERT(result.as.array == a && vm_array_get(a, 0).as.u8 == 99);
    vm_release(&heap, result);
    vm_release(&heap, child[0]);
    vm_release(&heap, child[1]);
    vm_release(&heap, val_array(a));
    vm_gc_collect_cycles(&heap);
    ASSERT_EQ(heap.stats.num_objects, 0);
    vm_heap_destroy(&heap);
}

TEST(call_envelope_rejects_bad_references_and_topology) {
    VmHeap heap;
    vm_heap_init(&heap);
    uint8_t invalid[] = {'C', 'A', 1, 1, 0xff, 0};
    NanoValue out[3];
    ASSERT(!cop_decode_call_values(invalid, sizeof invalid, out, 1, &heap));
    ASSERT_EQ(out[0].tag, TAG_VOID);
    invalid[2] = 2;
    ASSERT(!cop_decode_call_values(invalid, sizeof invalid, out, 1, &heap));
    uint8_t scalar_ref[] = {'C', 'A', 1, 2, TAG_VOID, 0xff, 0};
    ASSERT(!cop_decode_call_values(scalar_ref, sizeof scalar_ref, out, 2, &heap));
    VmArray *a = vm_array_new(&heap, TAG_INT, 1);
    VmArray *b = vm_array_new(&heap, TAG_INT, 1);
    ASSERT(vm_array_push(&heap, a, val_int(1)) && vm_array_push(&heap, b, val_int(2)));
    NanoValue original[] = {val_array(a), val_array(b)};
    NanoValue changed[] = {val_array(b), val_array(b), val_void()};
    uint8_t wire[256];
    uint32_t n = cop_encode_call_values(changed, 3, wire, sizeof wire);
    NanoValue result = val_void();
    ASSERT(n && !cop_apply_call_reply(wire, n, original, 2, &result, &heap));
    ASSERT_EQ(vm_array_get(a, 0).as.i64, 1);
    original[1] = original[0];
    changed[0] = val_array(a);
    n = cop_encode_call_values(changed, 3, wire, sizeof wire);
    ASSERT(n && !cop_apply_call_reply(wire, n, original, 2, &result, &heap));
    vm_release(&heap, val_array(a)); vm_release(&heap, val_array(b));
    vm_gc_collect_cycles(&heap);
    ASSERT_EQ(heap.stats.num_objects, 0);
    vm_heap_destroy(&heap);
}

TEST(pipe_exchange_deadlines_and_broken_peer) {
    for (int mode = 0; mode < 4; ++mode) {
        int send_pipe[2], recv_pipe[2];
        ASSERT(pipe(send_pipe) == 0 && pipe(recv_pipe) == 0);
        pid_t child = fork();
        ASSERT(child >= 0);
        if (!child) {
            close(send_pipe[1]); close(recv_pipe[0]);
            if (mode == 1) {
                CopMsgHeader header;
                uint8_t request;
                if (!cop_recv_header(send_pipe[0], &header) ||
                    !cop_recv_payload(send_pipe[0], &request, 1)) _exit(2);
                uint8_t partial[8] = {COP_PROTO_VERSION, COP_MSG_FFI_RESULT, 0, 0, 10, 0, 0, 0};
                if (write(recv_pipe[1], partial, sizeof partial) != sizeof partial) _exit(3);
            }
            if (mode == 2) _exit(0);
            for (;;) pause();
        }
        close(send_pipe[0]); close(recv_pipe[1]);
        if (mode == 2) ASSERT(waitpid(child, NULL, 0) == child);
        size_t size = mode == 0 ? COP_MAX_PAYLOAD : 1;
        uint8_t *request = calloc(size, 1);
        ASSERT(request);
        int flags = fcntl(send_pipe[1], F_GETFL);
        struct timespec start, finish;
        ASSERT(clock_gettime(CLOCK_MONOTONIC, &start) == 0);
        CopMsgType type;
        uint8_t *reply;
        uint32_t reply_size;
        ASSERT(!cop_exchange(mode == 3 ? -1 : send_pipe[1], recv_pipe[0], request, (uint32_t)size,
                             50, &type, &reply, &reply_size));
        ASSERT(clock_gettime(CLOCK_MONOTONIC, &finish) == 0);
        double elapsed = finish.tv_sec - start.tv_sec + (finish.tv_nsec - start.tv_nsec) / 1e9;
        ASSERT(elapsed < 2.0);
        ASSERT(reply == NULL && reply_size == 0);
        int restored = fcntl(send_pipe[1], F_GETFL);
        ASSERT(restored >= 0);
        /* Darwin can expose additional internal pipe status bits after I/O;
         * I check the caller-visible modes this helper must preserve. */
        int modes = O_NONBLOCK | O_APPEND | O_ACCMODE;
        ASSERT_EQ(restored & modes, flags & modes);
        free(request);
        close(send_pipe[1]); close(recv_pipe[0]);
        if (mode != 2) { kill(child, SIGKILL); ASSERT(waitpid(child, NULL, 0) == child); }
    }
}

int main(void) {
    printf("\n[cop_protocol] Co-process protocol tests...\n\n");
    RUN(serialize_int);
    RUN(pipe_exchange_deadlines_and_broken_peer);
    RUN(call_envelope_aliases_and_atomic_reply);
    RUN(call_envelope_rejects_bad_references_and_topology);
    RUN(serialize_negative_int);
    RUN(serialize_int_little_endian);
    RUN(deserialize_int_little_endian);
    RUN(serialize_float);
    RUN(serialize_float_little_endian);
    RUN(serialize_bool_true);
    RUN(serialize_bool_false);
    RUN(serialize_void);
    RUN(serialize_buffer_too_small);
    RUN(deserialize_truncated);
    RUN(serialize_opaque);
    RUN(send_recv_simple);
    RUN(send_recv_with_payload);
    RUN(recv_header_fixed_little_endian);
    RUN(recv_header_rejects_reserved_bits);
    RUN(recv_header_rejects_oversized_payload);
    RUN(recv_header_closed_pipe);
    RUN(send_recv_shutdown_msg);
    RUN(serialize_string_roundtrip);
    RUN(serialize_string_null);
    RUN(serialize_string_length_little_endian);
    RUN(deserialize_hostile_lengths);
    RUN(serialize_array_roundtrip);
    RUN(decode_nested_array_ownership);
    RUN(batch_roundtrip_many_calls);
    RUN(batch_empty_is_noop);
    RUN(batch_bad_import_reports_error);
    RUN(wire_header_byte_layout_is_fixed);
    RUN(a_payload_over_the_cap_is_refused_by_the_sender);
    RUN(large_payload_survives_the_pipe);
    RUN(large_string_value_survives_the_pipe);

    printf("\n");
    if (g_fail == 0) {
        printf("All %d cop_protocol tests passed.\n", g_pass);
        return 0;
    }
    printf("%d/%d cop_protocol tests FAILED.\n", g_fail, g_pass + g_fail);
    return 1;
}
