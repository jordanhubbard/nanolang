from pathlib import Path
import ast,sys,os,json,hashlib,subprocess,shlex,re,time,signal,shutil,gzip
root=Path('/Users/jkh/.worktrees/nanolang/ordinary-verifier-components-20261121')
control=root.with_name(root.name+'-control-v2');initial=root.with_name(root.name+'-control');prior=json.loads((control/'manifest.json').read_text());assert prior['status']=='passed'
linux_path=Path(sys.argv[1]);linux=json.loads(linux_path.read_text());out=root.with_name(root.name+'-sanitizers');out.mkdir(exist_ok=False);shutil.copy2(__file__,out/'observer.py');shutil.copy2(linux_path,out/'linux-corpora.json')
sha=lambda b:hashlib.sha256(b).hexdigest();expected=prior['source_hashes'];tools=prior['tools'];primary=Path('/Users/jkh/Src/nanolang')
# I reuse only my two retained read-only primary guard functions, not the
# setup observer's top-level clone/build/test actions.
nodes=[n for n in ast.parse((control/'observer.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['git','primary_guard']]
assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(control/'observer.py'),'exec'))
frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load()
def guards():
 assert {name:sha((root/name).read_bytes()) for name in expected}==expected
 assert {name:sha((root/name).read_bytes()) for name in tools}==tools
 assert primary_guard()==prior['primary_before']
 b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
guards();env=dict(os.environ,PATH=prior['gate_environment']['PATH'],CC='/usr/bin/cc');record=dict(status='running',pid=os.getpid(),steps=[],paired={},sanitizer_environment={k:env.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},limits=['I instrument actual C verifier/type/decoder/ISA providers, together with the original fixture carriers. Other linked providers retain ordinary instrumentation; affine analysis remains deferred. Darwin does not establish LeakSanitizer coverage. I preserve the original exact corpus and flags/limits; I change no source or ordinary reference executable.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,args,timeout=600):
 item=dict(name=name,argv=list(map(str,args)));record['steps'].append(item);save();started=time.monotonic()
 p=subprocess.Popen(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);item['pid']=p.pid;save()
 try:a,c=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);a,c=p.communicate();item['timed_out']=True
 item.update(returncode=p.returncode,elapsed_seconds=time.monotonic()-started);save();return item,a,c
works={};commands=[shlex.split(line) for line in (control/'build-tools.stdout').read_text().replace('\\\n',' ').splitlines() if line.startswith('/usr/bin/cc ')]
for key,pattern,stem in [('stack-types','shallow type-walk','stack_types'),('stack-heights','ordinary height-walk','stack_heights'),('function-body','ordinary function-body','function_body')]:
 matches=re.findall(r'I retain '+pattern+r' products at (\S+)',(control/(key+'.stdout')).read_text());assert len(matches)==1;work=Path(matches[0]);works[key]=work;m=json.loads((work/'manifest.json').read_text());assert len(m['routes'])==5 and m['cases']==linux[key]['cases']
 expected_reports=(work/'actual-c.reports').read_text().splitlines();assert sha((work/'actual-c.reports').read_bytes())==linux[key]['reports_sha256']
 paths=[work/f'case-{i}.bin' for i in range(len(m['cases']))]
 for case,path in zip(m['cases'],paths):assert sha(path.read_bytes())==case['sha256']
 record['paired'][key]=dict(cases=len(paths),routes=len(m['routes']),linux_cases_and_reports_identical=True,work=str(work));save()
 selected=[cmd for cmd in commands if 'tests/nvm2c_'+stem+'_reference.c' in cmd];assert len(selected)==1
 args=[arg for arg in selected[0] if arg not in ['obj/nanovm/vm_decode.o','obj/nanoisa/isa.o','obj/nanoisa/verifier_types.o']]
 executable=out/(key+'-reference');args[args.index('-o')+1]=str(executable)
 args+=['src/nanovm/vm_decode.c','src/nanoisa/isa.c']
 if key!='stack-types':args+=['src/nanoisa/verifier_types.c']
 args+=['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
 item,a,c=run(key+'-build',args);(out/(key+'-build.stdout')).write_bytes(a);(out/(key+'-build.stderr')).write_bytes(c);assert item['returncode']==0,(key,c[-2000:])
 reports=[]
 with (out/(key+'.stderr')).open('wb') as errors:
  for i in range(0,len(paths),64):
   item,a,c=run(key+f'-cases-{i}',[executable,*(['--trace'] if key=='stack-types' else []),*paths[i:i+64]])
   reports+=a.decode().splitlines();errors.write(c);errors.flush();(out/(key+'.reports')).write_text('\n'.join(reports)+'\n');assert item['returncode']==0,(key,i,c[-2000:]);assert reports==expected_reports[:len(reports)]
 record['paired'][key]['sanitized_actual_c_reports']=len(reports);guards();save();print(json.dumps(record['paired'][key]),flush=True)
record.update(status='passed',all_guards_unchanged=True);guards();save()
archive=root.with_name(root.name+'-archive');(archive/'inputs').mkdir(parents=True,exist_ok=False);paths={Path(__file__).resolve()}
for folder in [initial,control,out,*works.values()]:paths.update(p for p in folder.rglob('*') if p.is_file())
paths.update(root/name for name in expected);paths.update(root/name for name in tools)
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
module_index=root/'modules/index.json'
if module_index.is_file():paths.add(module_index)
entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(archive/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(archive/seen[digest]).read_bytes();entries.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
receipt=dict(pin=prior['pin'],root=str(root),source_hashes=expected,provider=prior['provider'],tools=tools,component_steps=[x for x in prior['steps'] if x['name']!='build-tools'],setup_step=prior['steps'][0],paired=record['paired'],original_setup_manifest_sha256=sha((initial/'manifest.json').read_bytes()),successful_manifest_sha256=sha((control/'manifest.json').read_bytes()),sanitizer_manifest_sha256=sha((out/'manifest.json').read_bytes()),files=entries,limits=prior['limits']+record['limits']);(archive/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
for entry in entries:
 packed=(archive/entry['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==entry['compressed_sha256'] and sha(raw)==entry['sha256']
guards();summary=dict(status='passed',archive=str(archive),files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum((archive/p).stat().st_size for p in seen.values()),source_files=len(expected),component_steps=receipt['component_steps']);(archive/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
subprocess.run(['tar','-cf',str(archive)+'.tar','-C',str(archive.parent),archive.name],check=True,timeout=600)
