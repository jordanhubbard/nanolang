include Makefile.gnu
.PHONY: focused-providers
focused-providers: $(MODULE_GENERATION_PROBE_OBJECTS) $(OBJ_DIR)/test_module_generation_probe
	@printf '%s\n' '$(MODULE_GENERATION_PROBE_OBJECTS) $(OBJ_DIR)/test_module_generation_probe' > /home/jkh/nanolang-qualification/sdk-metadata-819-linux/ordinary/providers.txt
	@printf '%s\n' '$(CFLAGS)' > /home/jkh/nanolang-qualification/sdk-metadata-819-linux/ordinary/cflags.txt
	@printf '%s\n' '$(LDFLAGS)' > /home/jkh/nanolang-qualification/sdk-metadata-819-linux/ordinary/ldflags.txt
