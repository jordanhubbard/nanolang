from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys

from tests.test_nanolang_translator_passive_module import corpus
from tests.nanolang_translator_routes import checked


def observe(*args):
    p = subprocess.run(args, capture_output=True, text=True)
    return dict(returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)


if sys.argv[1] == "--corpus":
    oracle = "obj/nvm2c_module_reference"
    widths = list(map(int, checked([oracle, "--widths"]).splitlines()))
    cases = corpus(widths)
    root = Path(".test_output/passive-module-corpus")
    root.mkdir(exist_ok=True)
    paths = []
    for i, (_, data, _) in enumerate(cases):
        p = root / f"case-{i}.nvm"
        p.write_bytes(data)
        paths.append(p)
    values = []
    for i in range(0, len(paths), 64):
        values += checked([oracle, "--passive", *paths[i:i + 64]], timeout=60).splitlines()
    assert len(values) == len(cases)
    records = []
    for (name, data, expected), value in zip(cases, values):
        if expected is not None:
            assert int(value.split(":")[0]) == expected, (name, expected, value)
        records.append(dict(name=name, bytes_hex=data.hex(), sha256=hashlib.sha256(data).hexdigest(),
                            explicit_status=expected, actual_c_report=value))
    Path(".test_output/passive-module-corpus.json").write_text(json.dumps(records, separators=(",", ":")) + "\n")
    print("I retained", len(records), "actual whole-module C decisions and byte reports; explicit controls:",
          sum(x["explicit_status"] is not None for x in records))
else:
    sources = ["src_nano/nvm2c/module.nano", "src_nano/nvm2c/passive.nano",
               "src_nano/nvm2c/passive_calls.nano", "src_nano/nvm2c/instructions.nano",
               "src_nano/nvm2c/payloads.nano", "src_nano/nvm2c/container.nano", "src_nano/nvm2c/isa_metadata.nano",
               "tests/nvm2c_module_driver.nano", "tests/nvm2c_module_reference.c",
               "tests/test_nanolang_translator_module.py", "tests/test_nanolang_translator_passive_module.py",
               "tests/test_nanolang_translator_passive.py", "tests/test_nanolang_translator_passive_calls.py",
               "tests/nanoisa/fixtures/passive_par.nano", "tests/nanoisa/fixtures/passive_flow.nano",
               "tests/nanolang_translator_routes.py", "tests/native_process.py", "Makefile.gnu",
               "src/nanoisa/nvm_v2_module.c", "src/nanoisa/nvm_v2_convert.c", "src/nanoisa/nvm_format.c",
               "src/nanoisa/retained_layouts.c", "src/nanoisa/ownership_contracts.c"]
    tools = ["bin/nanoc_c", "bin/nano_virt", "bin/nano_vm", "bin/nvm2c", "bin/nano_aot_runtime.o",
             "obj/nvm2c_module_reference", ".test_output/legacy-globals-source-final"]
    record = dict(commit=observe("git", "rev-parse", "HEAD"), status=observe("git", "status", "--short"),
                  uname=observe("uname", "-a"), platform=platform.platform(), cc=observe("cc", "--version"),
                  python=sys.version,
                  source_sha256={s: hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},
                  post_run_tool_sha256={s: hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in tools},
                  limits=["I record post-run observations, not a full SDK closure.",
                          "My development NanoLang driver was C-seed-built at602dc495e; compiler frontends are unchanged.",
                          "My generated-C routes instrument generated code with an ordinary AOT runtime.",
                          "My whole-module C oracle is ordinary, not a full-provider sanitizer build.",
                          "My unittest products, including producer modules, are temporary and not archived.",
                          "I regenerate synthetic corpus receipts independently from the final deterministic test.",
                          "Module success grants no instruction/host execution authority; other profiles remain pending."])
    if sys.platform == "darwin":
        record["sdk"] = observe("xcrun", "--sdk", "macosx", "--show-sdk-version")
        record["sdk_path"] = observe("xcrun", "--sdk", "macosx", "--show-sdk-path")
        record["os"] = observe("sw_vers")
    Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + "\n")
