.PHONY: token-preserved-ffi
token-preserved-ffi:
	$(CC) $(CFLAGS) -fPIC $(if $(filter Darwin,$(UNAME_S)),-dynamiclib,-shared) -pthread tests/nanovm/ffi_callback_fixture.c -o obj/ffi_callback_fixture.so $(LDFLAGS)
	$(CC) $(CFLAGS) -pthread tests/nanovm/test_retained_image_failure.c $(OBJ_DIR)/runtime/module_build_dir.o -o obj/test_retained_image_failure $(LDFLAGS)
	@obj/test_retained_image_failure
	$(CC) $(CFLAGS) -fPIC $(if $(filter Darwin,$(UNAME_S)),-dynamiclib,-shared) -DARTIFACT_ANSWER=42 tests/nanovm/ffi_artifact_fixture.c -o obj/ffi_artifact_first.so $(LDFLAGS)
	$(CC) $(CFLAGS) -fPIC $(if $(filter Darwin,$(UNAME_S)),-dynamiclib,-shared) -DARTIFACT_ANSWER=43 tests/nanovm/ffi_artifact_identity_fixture.c -o obj/ffi_artifact_second.so $(LDFLAGS)
	$(CC) $(CFLAGS) tests/nanovm/test_artifact_load.c -o obj/test_artifact_load $(LDFLAGS) $(if $(filter Linux,$(UNAME_S)),-ldl,)
	@obj/test_artifact_load obj/ffi_artifact_first.so obj/ffi_artifact_second.so
	@echo "Running vm_ffi unit tests..."
	$(CC) $(CFLAGS) -I$(NANOVM_DIR) -I$(NANOISA_DIR) -o tests/nanovm/test_vm_ffi \
		tests/nanovm/test_vm_ffi.c $(NANOVM_OBJECTS) $(NANOISA_OBJECTS) \
		$(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(LDFLAGS)
	@./tests/nanovm/test_vm_ffi
	@rm -f tests/nanovm/test_vm_ffi
