from pathlib import Path
import os,sys,subprocess,json,time,hashlib,tempfile,unittest
root=Path.cwd();out=root/'.test_output/conversion-projection-20261121/regressions-corrected';out.mkdir(exist_ok=False)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
source_record=json.loads((out.parent/'linux/manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(frozen/'bin/nanoc_stage1'))
os.environ.pop('NANOLANG_TRANSLATOR_SOURCE_MODULE',None)
record=dict(base=source_record['base'],source_hashes=source_record['source_hashes'],provider=source_record['source_compiler'],status='running')
args=['/usr/bin/python3',str(out.parent/'retained-regressions.py'),str(out/'suite')];record['argv']=args
with (out/'stdout').open('wb') as a,(out/'stderr').open('wb') as c:
 start=time.monotonic();p=subprocess.Popen(args,cwd=root,env=dict(os.environ,PYTHONPATH=str(root)),stdout=a,stderr=c,start_new_session=True);record['pid']=p.pid;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');record['returncode']=p.wait(timeout=7200);record['seconds']=time.monotonic()-start
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
assert all(sha(root/p)==value for p,value in record['source_hashes'].items());record['source_guards_unchanged']=True
record['status']='passed' if record['returncode']==0 else 'failed';(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}));sys.exit(record['returncode'])
