from pathlib import Path
import os,sys,subprocess,json,time,hashlib,signal
root=Path.cwd();out=root/'.test_output/conversion-projection-20261121/linux-final';out.mkdir(exist_ok=False)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_compiler=str(frozen/'bin/nanoc_stage1'),source_compiler_sha256=sha(frozen/'bin/nanoc_stage1'),receipt_sha256=sha(frozen/'bin/nanoc_bootstrap.json'),source_hashes={p:sha(root/p) for p in subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],text=True).splitlines() if (root/p).is_file()})
record['source_hashes']['tests/test_nanolang_translator_conversion.py']=sha(root/'tests/test_nanolang_translator_conversion.py')
env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=record['source_compiler'],NANOLANG_TRANSLATOR_CONVERSION_PRODUCTS=str(out/'products'));env.pop('NANOLANG_TRANSLATOR_SOURCE_MODULE',None)
args=['make','CC=/usr/bin/cc','test-nanolang-translator-conversion'];record.update(argv=args,environment={k:env[k] for k in ['PATH','CC','NANOLANG_ROOT','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER']})
with (out/'stdout').open('wb') as a,(out/'stderr').open('wb') as c:
 start=time.monotonic();p=subprocess.Popen(args,env=env,cwd=root,stdout=a,stderr=c,start_new_session=True);record['pid']=p.pid;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 try:record['returncode']=p.wait(timeout=3600)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);record.update(returncode=p.wait(),timeout=True)
 record['seconds']=time.monotonic()-start
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
assert all(sha(root/p)==value for p,value in record['source_hashes'].items());record['source_guards_unchanged']=True
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}));sys.exit(record['returncode'])
