from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,re,stat
root=Path.cwd();work=root/'.test_output/conversion-projection-20261121';out=root/'docs/evidence/conversion-projection-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest();state=json.loads((work/'linux-final/manifest.json').read_text());reg=json.loads((work/'regressions-final/manifest.json').read_text());suite=json.loads((work/'regressions-final/suite/manifest.json').read_text());san=json.loads((work/'reference-sanitizers/manifest.json').read_text());products=json.loads((work/'linux-final/products/manifest.json').read_text())
assert state['returncode']==reg['returncode']==0 and suite['status']==san['status']=='passed' and suite['tests']==5
for record in [state,reg]:assert record['provider_guards_unchanged'] and record['source_guards_unchanged']
expected=state['source_hashes'];assert all(sha((root/name).read_bytes())==value for name,value in expected.items())
paths=set();extra=[]
for path in work.rglob('*'):
 if path.is_file() and not any(part in ['module-cache','darwin-download'] for part in path.relative_to(work).parts) and not path.name.endswith('.tar') and path.name not in ['darwin-launch.log','darwin-resume.log']:paths.add(path)
for path in list(paths):
 if path.suffix not in ['.stdout','.log']:continue
 try:text=path.read_text()
 except UnicodeDecodeError:continue
 for name in re.findall(r'I retain actual producer modules/models at (\S+)',text):
  directory=Path(name);assert directory.is_relative_to(root/'.test_output');extra.append(str(directory));paths.update(p for p in directory.rglob('*') if p.is_file())
paths.update(root/name for name in expected)
for name in ['docs/ROADMAP.md','docs/NANOLANG_NANOISA_C_TRANSLATOR.md','bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so','obj/nvm2c_module_reference','obj/nvm2c_declaration_reference','obj/fixture_identifier_lexer']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(name) for name in b.manifest['hosts'])
record=dict(implementation='ad2f8fbeb29636983463c559d7d1bbce5d6dbaab',issue=1142,source_hashes=expected,conversion=products,regressions=suite,qualified_provider={k:state[k] for k in ['source_compiler','source_compiler_sha256','receipt_sha256']},extra_product_roots=sorted(set(extra)),limits=['I compare complete converted code/string/layout/function/signature projections with actual C. Successful conversion is descriptive only; full module/affine/private-profile verification, pure C emission and final-source bootstrap remain open. I retain the initial missing-private-route native mismatch and both stopped attempts, plus the in-process observer import-root refusal. Corrected gates run against one fixed3560-input snapshot. Original complete module regression products are retained. Build caches are omitted; generated test inputs, products, reports, tools, source and guard receipts are retained. Targeted actual projection/reverse-converter ASan/UBSan/leak behavior and emitted product sanitizers do not instrument every linked provider.'])
files=[];seen={}
for i,path in enumerate(sorted(paths)):
 raw=path.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{path.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(path),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(path.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for e in files:
 packed=(out/e['artifact']).read_bytes();raw=gzip.decompress(packed);assert sha(packed)==e['compressed_sha256'] and len(raw)==e['bytes'] and sha(raw)==e['sha256']
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/name).read_bytes())==value for name,value in expected.items())
print(json.dumps(dict(files=len(files),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/name).stat().st_size for name in seen.values()),unique_artifacts=len(seen),source_files=len(expected))))
