from pathlib import Path
import os,sys,subprocess,json,time,hashlib,tempfile,unittest
root=Path.cwd();out=root/'.test_output/conversion-projection-20261121/regressions';out.mkdir(exist_ok=False)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
source_record=json.loads((out.parent/'linux/manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
os.environ.update(PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(frozen/'bin/nanoc_stage1'))
os.environ.pop('NANOLANG_TRANSLATOR_SOURCE_MODULE',None)
sys.path.insert(0,str(root));products=out/'products';products.mkdir()
class Retained(tempfile.TemporaryDirectory):
 def __init__(self,*args,**kwargs):
  kwargs['dir']=products
  super().__init__(*args,**kwargs)
 def cleanup(self):self._finalizer.detach()
tempfile.TemporaryDirectory=Retained
names=['tests.test_nanolang_translator_module','tests.test_nanolang_translator_ownership_module','tests.test_nanolang_translator_passive_module','tests.test_nanolang_translator_service_modules']
record=dict(base=source_record['base'],source_hashes=source_record['source_hashes'],test_modules=names,provider=source_record['source_compiler'],pid=os.getpid(),status='running',products=str(products));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromNames(names);result=unittest.TextTestRunner(verbosity=2).run(suite)
record.update(status='passed' if result.wasSuccessful() else 'failed',tests=result.testsRun,seconds=time.monotonic()-start,failures=len(result.failures),errors=len(result.errors))
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
assert all(sha(root/p)==value for p,value in record['source_hashes'].items());record['source_guards_unchanged']=True
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(0 if result.wasSuccessful() else 1)
