from pathlib import Path
import os,sys,json,subprocess,time,hashlib,signal,traceback,shutil
primary=Path('/Users/jkh/Src/nanolang');root=Path('/Users/jkh/.worktrees/nanolang/conversion-projection-20261121');control=root.with_name(root.name+'-control');out=root.with_name(root.name+'-resume');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest();prior_bytes=(control/'manifest.json').read_bytes();prior=json.loads(prior_bytes);assert prior['status']=='failed' and prior['primary_preserved'] and prior['provider_guards_unchanged'];assert prior['steps'][-1]['name']=='module-regressions' and prior['steps'][-1]['returncode']==1
record=dict(pin=prior['pin'],root=str(root),prior_manifest=str(control/'manifest.json'),prior_manifest_sha256=sha(prior_bytes),status='running',steps=[],source_hashes=prior['source_hashes'],limits=['I preserve the original failed observer/manifest and complete conversion plus three passing original methods. The two errors are absent generated .test_output and an omitted declared service-nominal C oracle. I supply only these prerequisites, then resume the two missing original methods and pending targeted C sanitizer/identifier checks. I do not repeat any completed passing product gate or change source, tools, limits or frozen roots.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def git(*args,cwd=primary):return subprocess.check_output(['git',*args],cwd=cwd)
def primary_guard():
 paths=git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0');files={}
 for raw in paths:
  if not raw:continue
  name=os.fsdecode(raw);p=primary/name
  if p.is_symlink():files[name]={'symlink':os.readlink(p)}
  elif p.is_file():files[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode}
  else:files[name]={'absent':True}
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('rev-parse','--abbrev-ref','HEAD').decode().strip(),status=sha(git('status','--porcelain=v1','-z','--untracked-files=all')),diff=sha(git('diff','--binary','HEAD')),cached=sha(git('diff','--cached','--binary','HEAD')),stashes=git('stash','list','--format=%H').decode().splitlines(),files=files)

original=primary_guard();assert original==prior['primary_before'];record['primary_before']=original;save()
base_env=dict(os.environ,PATH='/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',MAKEFLAGS='-j1')
def step(name,args,cwd,env=base_env,timeout=3600):
 item=dict(name=name,argv=list(map(str,args)),cwd=str(cwd));record['steps'].append(item);save();started=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as a,(out/(name+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=a,stderr=b,start_new_session=True);item['pid']=p.pid;save()
  try:item['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);item.update(returncode=p.wait(),timed_out=True)
 item['elapsed_seconds']=time.monotonic()-started;save();print(json.dumps(item),flush=True)
 if item['returncode']:raise RuntimeError(f'{name} failed with {item["returncode"]}')
 return item
expected=prior['source_hashes'];frozen=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');b=None
try:
 assert git('rev-parse','HEAD',cwd=root).decode().strip()==prior['pin']
 assert git('status','--porcelain=v1','--untracked-files=all',cwd=root)==b''
 sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
 b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
 def guards():
  assert {name:sha((root/name).read_bytes()) for name in expected}==expected
  assert {name:sha((root/name).read_bytes()) for name in prior['tools']}==prior['tools']
  b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
  assert primary_guard()==original and (control/'manifest.json').read_bytes()==prior_bytes
 guards();shutil.copy2(__file__,out/'observer.py');shutil.copy2(Path(sys.argv[1]),out/'retained-missing.py')
 env=dict(base_env,PYTHONPATH=str(root),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(root/'.test_output/conversion-module-cache'),NANO_SHADOW_TIMEOUT_SECONDS='10',NANOLANG_TRANSLATOR_SOURCE_COMPILER=str(frozen/'bin/nanoc_stage1'))
 for name in ['NANOLANG_TRANSLATOR_SOURCE_MODULE','NANO_CC','NANOLANG_BOOTSTRAP_NO_CC','NANO_AS_CAPTURE_HELPER']:env.pop(name,None)
 record['generated_output_existed_before']=(root/'.test_output').exists();(root/'.test_output').mkdir(exist_ok=True)
 step('missing-oracles',['make','CC=/usr/bin/cc','obj/nvm2c_module_reference','obj/nvm2c_declaration_reference','obj/nvm2c_service_nominal_reference'],root,env);guards()
 step('missing-regressions',['python3',out/'retained-missing.py',out/'regressions'],root,env,timeout=7200);guards()
 step('reference-sanitizers',['python3',control/'run-reference-sanitizers.py',root,control/'conversion-products',out/'reference-sanitizers'],root,env);guards()
 step('identifiers',['make','CC=/usr/bin/cc','test-embedded-nano-identifiers'],root,env);guards()
 record['status']='passed';record['completed_original_methods']=dict(prior_successful=3,resumed=2,total=5);record['primary_after']=primary_guard()
except BaseException as error:
 record['status']='failed';record['error']=repr(error);(out/'exception').write_text(traceback.format_exc())
finally:
 try:
  assert primary_guard()==original;record['primary_preserved']=True
  if b is not None:b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));record['provider_guards_unchanged']=True
  assert (control/'manifest.json').read_bytes()==prior_bytes;record['failed_manifest_bytes_preserved']=True
  record['final_status']=git('status','--porcelain=v1','--untracked-files=all',cwd=root).decode();assert record['final_status']==''
 except BaseException as error:
  record['status']='failed';record['guard_error']=repr(error)
 save()
print(json.dumps({'status':record['status'],'manifest':str(out/'manifest.json')}),flush=True);sys.exit(0 if record['status']=='passed' else 1)
