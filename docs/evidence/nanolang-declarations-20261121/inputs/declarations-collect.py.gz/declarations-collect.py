from pathlib import Path
import gzip,hashlib,json,os,platform,re,subprocess,sys,tempfile
from tests.test_nanolang_translator_declarations import corpus
from tests.nanolang_translator_routes import checked

def observe(*args):
    p=subprocess.run(args,capture_output=True,text=True)
    return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

if sys.argv[1]=='--corpus':
    cases=corpus();reports={}
    with tempfile.TemporaryDirectory(prefix='declaration-corpus-') as d:
        paths=[]
        for i,(_,data,_) in enumerate(cases):
            p=Path(d)/str(i);p.write_bytes(data);paths.append(p)
        for profile in (1,2,3):
            values=[]
            for i in range(0,len(paths),32):values+=checked(['obj/nvm2c_declaration_reference',str(profile),*paths[i:i+32]],timeout=600).splitlines()
            assert len(values)==len(cases)
            for (name,_,expected),value in zip(cases,values):
                if expected is not None:assert int(value.split('|')[0])==expected[profile],(name,profile,value[:30],expected[profile])
            reports[profile]=values
    records=[dict(name=name,bytes_hex=data.hex(),sha256=hashlib.sha256(data).hexdigest(),explicit_status=expected,actual_c_reports={profile:reports[profile][i] for profile in (1,2,3)}) for i,(name,data,expected) in enumerate(cases)]
    Path('.test_output/declarations-corpus.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
    print('I retained',len(records),'synthetic models and complete three-profile reports;',sum(e is not None for _,_,e in cases)*3,'explicit statuses.')
elif sys.argv[1]=='--products':
    log=Path(sys.argv[2]).read_text()
    match=re.search(r'I retain actual producer modules/models at (.+)',log);assert match
    root=Path(match[1]);records=json.loads((root/'records.json').read_text());assert len(records)==14
    result=[]
    for record in records:
        module=(root/record['module']).read_bytes();model=(root/record['model']).read_bytes()
        assert hashlib.sha256(module).hexdigest()==record['module_sha256']
        assert hashlib.sha256(model).hexdigest()==record['model_sha256']
        assert hashlib.sha256(Path(record['source']).read_bytes()).hexdigest()==record['source_sha256']
        reports={p:checked(['obj/nvm2c_declaration_reference',str(p),root/record['model']],timeout=120).strip() for p in (1,2,3)}
        result.append(dict(**record,module_bytes_hex=module.hex(),model_bytes_hex=model.hex(),actual_c_reports=reports))
    Path('.test_output/declarations-products.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print('I retained',len(result),'actual producer modules/models and original VM results.')
else:
    sources=['Makefile.gnu']
    sources+=['src_nano/nvm2c/'+s+'.nano' for s in ['declarations','array_declarations','map_declarations','ownership','ownership_wire','private_layouts','payloads','container','instructions','passive_calls','isa_metadata']]
    sources+=['tests/'+s for s in ['nvm2c_declaration_driver.nano','nvm2c_declaration_reference.c','test_nanolang_translator_declarations.py','test_nanolang_translator_ownership.py','test_nanolang_translator_payloads.py','nanolang_translator_routes.py','native_process.py']]
    sources+=['src/nanoisa/'+s for s in ['ownership_contracts.c','ownership_contracts.h','ordinary_array_authority.inc','ordinary_array_authority.h','ownership_array_fields.inc','ownership_map_fields.inc','ownership_map_declarations.inc','ownership_map_declarations.h','ownership_declaration_projection.inc','ownership_declaration_projection.h','ownership_layouts_private.h','record_map_cost_private.h','nvm_v2_layouts.c','nvm_v2_cursor.c','nvm_v2_sections.h','retained_layouts.c','reference_places.c','isa.c','isa.h']]
    sources+=['tests/nanoisa/fixtures/'+s for s in ['array_record_fields.nano','empty_array_append.nano','affine_scalar_union_instances.nano','string_int_maps.nano','string_string_maps.nano','map_nested_u8_borrowed.nano','owned_mixed/basic.nano']]
    tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_declaration_reference','obj/nvm2c_declaration_reference_asan','.test_output/ownership-source-final']
    tool_hashes={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in tools}
    host='darwin' if sys.platform=='darwin' else 'linux'
    previous=json.loads(gzip.decompress(Path('docs/evidence/nanolang-ownership-20261120/inputs/ownership-'+host+'-manifest.json.gz').read_bytes()))
    assert previous['post_run_tool_sha256']['.test_output/ownership-source-final']==tool_hashes['.test_output/ownership-source-final']
    record=dict(sanitizer_environment={key:os.environ.get(key) for key in ('ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS')},commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,source_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},post_run_tool_sha256=tool_hashes,reused_compiler_matches_previous_receipt=True,limits=['I reuse the C-seed-built development NanoLang compiler at7cd173b30; its image matches the prior paired ownership receipt.', 'My projection model supplies normal narrow carriers and immutable input views, not arbitrary C pointers or allocator-layout emulation.', 'Generated C fixtures are instrumented and link an ordinary AOT runtime.', 'The declaration/layout/retained/reference/cursor/ISA provider oracle is instrumented; unrelated linked providers and producer-model extraction are ordinary.', 'No allocation denial is injected into NanoLang; original C units retain their separate allocator-denial controls.', 'I retain original producer modules/models and results; temporary decoder-driver images are not archived.', 'Declarations grant no executable admission; this is no raw fixed point, installed cutover, full SDK closure or complete leak-freedom claim.'])
    if sys.platform=='darwin':record.update(sdk=observe('xcrun','--sdk','macosx','--show-sdk-version'),sdk_path=observe('xcrun','--sdk','macosx','--show-sdk-path'),os=observe('sw_vers'))
    Path(sys.argv[1]).write_text(json.dumps(record,indent=2)+'\n')
