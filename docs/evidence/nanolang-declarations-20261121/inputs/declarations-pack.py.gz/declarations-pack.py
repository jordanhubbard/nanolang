from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('docs/evidence/nanolang-declarations-20261121');inputs=root/'inputs';inputs.mkdir(exist_ok=True)
records=[]
def retain(name,data):
    packed=gzip.compress(data,mtime=0);(inputs/(name+'.gz')).write_bytes(packed)
    records.append(dict(path='inputs/'+name+'.gz',uncompressed_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),compressed_sha256=hashlib.sha256(packed).hexdigest()))
for p in sorted(Path('.test_output').glob('declarations-*.log')):retain('linux-'+p.name,p.read_bytes())
for p in sorted(Path('.test_output/declarations-darwin').glob('*.log')):retain('darwin-'+p.name,p.read_bytes())
for name in ['declarations-corpus.json','declarations-products.json','declarations-linux-manifest.json','declarations-collect.py','declarations-pack.py','declarations-reference-first.c','declarations-first-tests.py','declarations-producer-first-tests.py','declarations-launch-results.json']:
    retain(name,Path('.test_output',name).read_bytes())
for name in ['declarations-darwin-manifest.json','declarations-products.json']:
    p=Path('.test_output/declarations-darwin',name)
    data=gzip.decompress(p.with_suffix('.json.gz').read_bytes()) if not p.exists() else p.read_bytes()
    retain('darwin-'+name,data)
manifest=json.loads(Path('.test_output/declarations-linux-manifest.json').read_text())
other=json.loads(Path('.test_output/declarations-darwin/declarations-darwin-manifest.json').read_text())
assert manifest['source_sha256']==other['source_sha256']
for name,sha in manifest['source_sha256'].items():
    data=subprocess.check_output(['git','show','b50039864:'+name]);assert hashlib.sha256(data).hexdigest()==sha,name
    retain('source-'+name.replace('/','_'),data)
assert Path('.test_output/declarations-corpus.json').read_bytes()==gzip.decompress(Path('.test_output/declarations-darwin/declarations-corpus.json.gz').read_bytes())
(root/'retained-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
    packed=(root/r['path']).read_bytes();data=gzip.decompress(packed)
    assert len(data)==r['uncompressed_bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
    assert hashlib.sha256(packed).hexdigest()==r['compressed_sha256']
print('I retained and verified',len(records),'inputs; paired synthetic corpus reports and tested source hashes match.')
