from pathlib import Path
import sys,os,json,subprocess,hashlib,gzip,re
root=Path.cwd();work=root/'.test_output/empty-function-boundary-20261121';out=root/'docs/evidence/empty-function-results-linux-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);sha=lambda data:hashlib.sha256(data).hexdigest();paths={Path(__file__).resolve()}
state=json.loads((work/'source-products/manifest.json').read_text());assert state['returncode']==0 and state['original_bootstrap_guards_unchanged'];assert 'All 101 tests passed.' in (work/'corrected.log').read_text();assert '569591 passed, 0 failed' in (work/'original-vm-identifiers.log').read_text();assert 'All 101 tests passed.' in (work/'sanitizers/stdout').read_text()
paths.update(p for p in work.rglob('*') if p.is_file())
products=[]
for p in (root/'.test_output').glob('empty-result-products-*'):
 if p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file());products.append(str(p))
for folder in ['src','src_nano','modules','std','stdlib','include','scripts','tests','spec']:
 for name in subprocess.check_output(['git','ls-files',folder],text=True).splitlines():
  p=root/name
  if p.is_file():paths.add(p)
for name in ['tests/test_empty_function_results.py','Makefile.gnu','GNUmakefile','docs/ROADMAP.md','docs/NANOLANG_NANOISA_C_TRANSLATOR.md','bin/nano_vm','bin/nvm2c','bin/nanoc_c','bin/nano_virt','bin/nanoisa','bin/nano_aot_runtime.o','bin/nano_as_capture.so','obj/fixture_identifier_lexer']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(p) for p in b.manifest['hosts'])
source_map={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths if p.is_relative_to(root) and str(p.relative_to(root)).startswith(('src/','src_nano/','modules/','std/','stdlib/','include/','scripts/','tests/','spec/'))};source_map.update({name:sha((root/name).read_bytes()) for name in ['Makefile.gnu','GNUmakefile']})
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),issue=1174,source_hashes=source_map,qualified_source_provider=state,product_roots=products,limits=['I retain the baseline accepted/execution-failed v2 bytes and original tools, red direct/CLI gates, corrected source and original VM/verifier regressions. My first CLI expectations wrongly treated legacy NVM01 as executable; I preserve the existing blanket refusal. The C translator already refused the required invalid body and preserved prior output. The shared helper empty-height behavior and zero declared-depth absence remain unchanged. I do not claim full-provider sanitizer or newer raw bootstrap acceptance.'])
files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  name=f'inputs/{i:05d}-{p.name}.gz';(out/name).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=name
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record['files']=files;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for e in files:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(files),raw_bytes=sum(x['bytes'] for x in files),compressed_bytes=sum((out/p).stat().st_size for p in seen.values()),source_files=len(source_map))))
