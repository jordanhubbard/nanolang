nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano=native-timing-wdq2xf18/foreign/payload.S
