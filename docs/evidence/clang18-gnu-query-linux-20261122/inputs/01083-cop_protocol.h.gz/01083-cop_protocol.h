/*
 * cop_protocol.h - Co-Process FFI Protocol
 *
 * Wire format for FFI isolation: the VM core runs in the main process,
 * FFI calls are dispatched to a separate co-process (nano_cop) via pipes.
 *
 * Reuses VmdMsgHeader (8-byte header + payload) wire format.
 */

#ifndef NANOVM_COP_PROTOCOL_H
#define NANOVM_COP_PROTOCOL_H

#include "value.h"
#include "heap.h"
#include "../nanoisa/nvm_format.h"
#include <stdint.h>
#include <stdbool.h>

/* ========================================================================
 * Message Types (co-process ↔ VM)
 * ======================================================================== */

typedef enum {
    /* VM → Co-process */
    COP_MSG_INIT       = 0x01,  /* Payload: serialized import table */
    COP_MSG_FFI_REQ    = 0x02,  /* Payload: import_idx + serialized args */
    COP_MSG_SHUTDOWN   = 0x03,  /* No payload */
    COP_MSG_FFI_BATCH  = 0x04,  /* Payload: count + [import_idx+argc+args]... */

    /* Co-process → VM */
    COP_MSG_FFI_RESULT = 0x10,  /* Payload: serialized NanoValue result */
    COP_MSG_FFI_ERROR  = 0x11,  /* Payload: error string */
    COP_MSG_READY      = 0x12,  /* No payload (init complete) */
    COP_MSG_FFI_BATCH_RESULT = 0x13  /* Payload: count + [serialized result]... */
} CopMsgType;

/* Wire Header (same 8-byte format as VmdMsgHeader) */
typedef struct {
    uint8_t  version;       /* COP_PROTO_VERSION */
    uint8_t  msg_type;      /* CopMsgType */
    uint16_t reserved;      /* Must be 0 */
    uint32_t payload_len;   /* Bytes following this header */
} __attribute__((packed)) CopMsgHeader;

#define COP_HEADER_SIZE 8
#define COP_PROTO_VERSION 2
#define COP_MAX_PAYLOAD (16 * 1024 * 1024)  /* 16 MB max for FFI payloads */

/* ========================================================================
 * NanoValue Serialization
 *
 * Format: tag(u8) + payload
 *   TAG_INT:    i64 (8 bytes, little-endian)
 *   TAG_FLOAT:  f64 (8 bytes, IEEE 754)
 *   TAG_BOOL:   u8 (0 or 1)
 *   TAG_STRING: len(u32) + data (UTF-8 bytes)
 *   TAG_OPAQUE: i64 (proxy ID)
 *   TAG_ARRAY:  elem_type(u8) + count(u32) + [serialized elements...]
 *   TAG_VOID:   nothing (0 extra bytes)
 * ======================================================================== */

/* Serialize a NanoValue into a buffer. Returns bytes written.
 * Buffer must be at least 13 bytes (1 tag + max 8 payload + 4 len). */
uint32_t cop_serialize_value(const NanoValue *val, uint8_t *buf, uint32_t buf_size);

/* Deserialize a NanoValue from a buffer. Returns bytes consumed, 0 on error.
 * heap is needed for allocating strings. */
uint32_t cop_deserialize_value(const uint8_t *buf, uint32_t buf_size,
                               NanoValue *out, VmHeap *heap);

/* Versioned call envelope: arguments, optionally followed by the result.
 * Top-level array aliases use bounded backward references. Supported arrays
 * contain scalar/string elements, matching the in-process foreign boundary.
 * Decode owns each output reference; failure clears/releases every output.
 * Single-call mailbox and version-2 pipe transports use this envelope. */
uint32_t cop_encode_call_values(const NanoValue *values, uint8_t count,
                                uint8_t *buf, uint32_t size);
bool cop_decode_call_values(const uint8_t *buf, uint32_t size, NanoValue *values,
                            uint8_t count, VmHeap *heap);
/* Reply contains argc argument snapshots followed by one result. I validate
 * all snapshots and alias relationships before swapping any original storage.
 * Native side effects cannot be rolled back if a reply fails validation. */
bool cop_apply_call_reply(const uint8_t *buf, uint32_t size, NanoValue *args,
                          uint8_t argc, NanoValue *result, VmHeap *heap);
/* Execute a version-2 pipe request: little-endian import(u32), argc(u16),
 * call envelope. On success the caller owns *reply and must free it. */
bool cop_execute_request(const uint8_t *request, uint32_t size,
                          const NvmModule *module, VmHeap *heap,
                          uint8_t **reply, uint32_t *reply_size,
                          char *error, size_t error_size);

/* ========================================================================
 * Shared-Memory Mailbox (fast path)
 *
 * For high-frequency FFI (e.g. pixel rendering), the pipe protocol pays
 * 4+ syscalls per call and copies payload bytes through kernel buffers.
 * The mailbox eliminates the payload copies: only a 1-byte signal travels
 * through each pipe, and all argument/result data lives in a shared mmap
 * region inherited across fork().
 *
 * Per-call cost: 2 pipe syscalls (signal + ack) instead of 4+ pipe I/O
 * syscalls, and zero kernel copies of the payload.
 *
 * The parent uses poll() with cop_timeout_ms for the per-call timeout.
 * ======================================================================== */

#define COP_MAILBOX_SLOT_SIZE 4096   /* fits any scalar/pixel FFI call */

/* Maximum number of calls that may be coalesced into one boundary crossing.
 * A batch still shares the single request/response slots, so the effective
 * limit is whatever fits in COP_MAILBOX_SLOT_SIZE; this cap bounds the
 * per-batch bookkeeping arrays and rejects hostile counts up front. */
#define COP_MAX_BATCH 1024

typedef struct CopMailbox {
    /* Request slot — written by parent, read by child */
    uint8_t  req_import_idx[4];
    uint8_t  req_argc[2];
    uint8_t  req_data_size[2];
    /* Batch mode: 0 = single call (fields above describe it), >0 = req_data
     * holds this many packed sub-requests, each encoded as
     *   import_idx(u32) + argc(u16) + arg_data_size(u16) + serialized args. */
    uint8_t  req_batch_count[4];
    uint8_t  req_data[COP_MAILBOX_SLOT_SIZE];

    /* Response slot — written by child, read by parent */
    uint8_t  resp_is_error;          /* 0=result, 1=error string, 2=pipe spill */
    uint8_t  _pad[3];
    uint8_t  resp_data_size[4];
    /* Batch mode response: number of serialized results packed in resp_data.
     * Only meaningful when the matching request set req_batch_count > 0. */
    uint8_t  resp_batch_count[4];
    uint8_t  resp_data[COP_MAILBOX_SLOT_SIZE];
    char     resp_error[256];
} CopMailbox;

/* Wire integers are always little-endian, independent of the host ABI. */
static inline void cop_put_u16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8);
}
static inline uint16_t cop_get_u16(const uint8_t *p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}
static inline void cop_put_u32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static inline uint32_t cop_get_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static inline void cop_put_u64(uint8_t *p, uint64_t v) {
    for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (i * 8));
}
static inline uint64_t cop_get_u64(const uint8_t *p) {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= (uint64_t)p[i] << (i * 8);
    return v;
}

/* Run the cop logic in a forked child (no exec).  Never returns.
 * mailbox, sig_in_fd, sig_out_fd are inherited from the parent's
 * address space.  module is the NvmModule whose imports are served. */
void cop_child_main(CopMailbox *mailbox, size_t mailbox_size,
                    int sig_in_fd, int sig_out_fd,
                    int data_in_fd, int data_out_fd,
                    const NvmModule *module);

/* Batch request descriptor: one host call in a coalesced batch.
 * All calls in a batch share a single boundary crossing (one signal + one
 * ack) instead of paying the per-element round-trip cost. */
typedef struct CopBatchCall {
    uint32_t         import_idx;  /* index into the module import table */
    const NanoValue *args;        /* argument array for this call */
    int              arg_count;   /* number of arguments */
} CopBatchCall;

/* ========================================================================
 * Send / Receive Helpers (pipe-based I/O)
 * ======================================================================== */

/* Send a header + payload over a file descriptor. */
bool cop_send(int fd, CopMsgType type, const void *payload, uint32_t payload_len);

/* Receive a header. Returns true on success. */
bool cop_recv_header(int fd, CopMsgHeader *hdr);

/* Receive exactly len bytes. */
bool cop_recv_payload(int fd, void *buf, uint32_t len);

/* Send a simple message (no payload). */
bool cop_send_simple(int fd, CopMsgType type);

/* I bound the entire parent exchange by one monotonic deadline. These owned
 * pipe endpoints must not be used concurrently. On success the caller owns
 * *reply; on failure it must close/reset the channel (a frame may be partial). */
bool cop_exchange(int send_fd, int recv_fd, const uint8_t *request, uint32_t size,
                   int timeout_ms, CopMsgType *type, uint8_t **reply, uint32_t *reply_size);
/* send_fd == -1 receives an already-computed spill reply without sending. */
int64_t cop_now_ms(void);

#endif /* NANOVM_COP_PROTOCOL_H */
