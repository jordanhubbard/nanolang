# 1 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano=native-timing-a73u9xnx/foreign/answer.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 397 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano=native-timing-a73u9xnx/foreign/answer.c" 2
extern unsigned char snapshot_payload[];
long long nano_build_answer(void) { return snapshot_payload[0]; }
