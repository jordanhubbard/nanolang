# 1 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/answer.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 396 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/answer.c" 2
# 1 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/C headers/selection.h" 1
# 2 "/home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/answer.c" 2
extern const unsigned char snapshot_payload[];
long long nano_build_answer(void) { return 0 + (snapshot_payload[0]-48)*10 + snapshot_payload[1]-48; }
