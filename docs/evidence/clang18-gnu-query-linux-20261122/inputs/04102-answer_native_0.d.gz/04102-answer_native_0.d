nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano=native-timing-tr72dp_i/foreign/answer.c
