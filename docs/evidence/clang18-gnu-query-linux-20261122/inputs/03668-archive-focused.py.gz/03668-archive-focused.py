from pathlib import Path
import os,json,gzip,hashlib,stat,subprocess
control=Path(__file__).resolve().parent
axis=control.with_name('clang18-capture-provider-axis-20261122-control')
repo=Path('/home/jkh/.worktrees/nanolang/service-module-integration');out=repo/'docs/evidence/clang18-gnu-query-linux-20261122'
assert not (out/'manifest.json').exists() and not list((out/'inputs').iterdir())
(out/'inputs').mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
sets={name:json.loads((folder/'manifest.json').read_text()) for name,folder in [('provider_axis',axis),('red',control/'red'),('green',control/'green')]}
assert sets['provider_axis']['status']=='terminal-failure' and len(sets['provider_axis']['tests']['failures'])==8
assert sets['red']['status']=='expected-red' and len(sets['red']['queries']['failures'])==2
assert sets['green']['status']=='passed' and sets['green']['queries']['successful'] and sets['green']['external_and_slow']['successful']
paths=set();sources={};symlinks={}
for name,m in sets.items():
 assert m['source_and_tool_guards_unchanged']
 root=Path(m['root']);expected=m['source_hashes'];pins=m.get('source_pins',{})
 assert all(sha((root/n).read_bytes())==v for n,v in expected.items())
 assert all(sha(Path(n).read_bytes())==v for n,v in m['tools'].items())
 actual=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
 assert actual==m.get('initial_status',''),(name,actual)
 sources[name]=dict(root=str(root),implementation=m['pin'],source_hashes=expected,source_pins=pins,tools=m['tools'],git_status=actual)
 paths.update(root/n for n in expected);paths.update(Path(n) for n in m['tools'])
for parent in [axis,control]:
 for p in parent.rglob('*'):
  if p.is_symlink():symlinks[str(p)]=os.readlink(p)
  if p.is_file():paths.add(p)
files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(issue=1159,implementation=sets['green']['pin'],source_sets=sources,verification={n:{k:v for k,v in m.items() if k not in ['source_hashes','tools']} for n,m in sets.items()},files=files,symlinks=symlinks,limits=['I qualify focused native AArch64 Clang18/GNU2.42 controls only. Original0419 external-only helper absence reproduces8 first-build capture refusals without editing or repeating the old roots. Red retains5bb harness/tests and the exact8ccb builder as its sole declared source override. Both expected raw query failures remain failures; green passes3 query tests plus8 external combinations and original slow recovery. Ambient helper remains unset for the candidate fixture to supply. All original deadlines/assertions/output boundaries and source/tool guards remain intact. I grant no full hosted-suite, Clang21, generic tool admission or release acceptance; capture implementation and promotion remain with Puck.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_sets={k:len(v['source_hashes']) for k,v in sources.items()},symlinks=len(symlinks))))
