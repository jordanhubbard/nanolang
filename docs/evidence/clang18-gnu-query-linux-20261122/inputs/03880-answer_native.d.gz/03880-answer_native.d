nano_module_dependencies: \
  /home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/answer.c \
  /home/jkh/.worktrees/nanolang/clang18-gnu-query-20261122-control/green/source-products/fixtures/nano-as-search-w_w5pu2a/foreign/C\ headers/selection.h
