from pathlib import Path
import os,sys,json,time,hashlib,subprocess,tempfile,traceback
from unittest.mock import patch
import unittest
root=Path('/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122');out=Path(__file__).resolve().parent
assert Path.cwd()==root
sys.dont_write_bytecode=True
sys.path.insert(0,str(root))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),status='preparing',methods=['test_equals_path_post_capture_reads'],limits=['I execute only the eight original external equals-path subcases with unchanged source, assertions and per-command deadlines. I retain TemporaryDirectory fixtures through an external cleanup-only observer; actual fixture prefixes and native operations remain unchanged. cc/clang select the installed supported Clang18; the queried native GNU assembler remains2.42. I edit no production capture/test source or admission. This observation grants no Clang21 or general admission.'])
assert record['pin']=='0419b4d237f0dc16b5b67555aa51883f32d9b68e'
names=subprocess.check_output(['git','ls-files','src','src_nano','modules','std','stdlib','include','scripts','tests','spec','Makefile.gnu','GNUmakefile'],text=True).splitlines();record['source_hashes']={n:sha(root/n) for n in names if (root/n).is_file()}
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def guards():
 assert {n:sha(root/n) for n in record['source_hashes']}==record['source_hashes']
 if record.get('tools'):assert {n:sha(n) for n in record['tools']}==record['tools']
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==record['pin']
tools=Path('/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/tools')
initial=json.loads(Path('/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/manifest.json').read_text())
assert initial['source_hashes']==record['source_hashes'] and initial['source_and_tool_guards_unchanged']
record['tools']=initial['tools'];record['preparation_reuse']=dict(manifest='/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/manifest.json',sha256=sha(Path('/home/jkh/.worktrees/nanolang/clang18-capture-localization-20261122-control/manifest.json')),limits='I retain the first import-root setup refusal and reuse only its already completed source/tool/build setup. Neither original test method executed there.')
env=dict(os.environ,PATH=str(tools)+':/usr/bin:/bin',CC=str(tools/'cc'),NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_SHADOW_TIMEOUT_SECONDS='10')
for name in ['NANO_AS_CAPTURE_HELPER','NANO_CC','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_TEST_SLOW_RECOVERY','COMPILER_PATH','NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANOLANG_TRANSLATOR_SOURCE_MODULE']:env.pop(name,None)
for name in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']:
 if name in env:raise RuntimeError('I require the unchanged ordinary sanitizer environment.')
os.environ.clear();os.environ.update(env)
record['environment']={n:env.get(n) for n in ['PATH','CC','NANOLANG_ROOT','NANO_AS_CAPTURE_HELPER','NANO_SHADOW_TIMEOUT_SECONDS','NANO_CAPTURE_TIMEOUT_MS','COMPILER_PATH']}
try:
 save();guards()
 record['identities']=initial['identities'];record['assembler']=initial['assembler'];record['assembler_version']=initial['assembler_version'];record['build_reused']=initial['build'];guards();save()
 fixtures=out/'fixtures';fixtures.mkdir();tempfile.tempdir=str(fixtures)
 original_temporary=tempfile.TemporaryDirectory
 class RetainedDirectory(original_temporary):
  def cleanup(self):self._finalizer.detach()
 command_dir=out/'commands';command_dir.mkdir();commands=[];original_run=subprocess.run
 def recorded_run(*args,**kwargs):
  number=len(commands);item=dict(argv=list(map(str,args[0] if args else kwargs['args'])),cwd=str(kwargs.get('cwd',root)),timeout=kwargs.get('timeout'),environment={n:(kwargs.get('env') or os.environ).get(n) for n in ['PATH','CC','NANO_CC','NANO_BUILD_CACHE','NANO_AS_CAPTURE_HELPER','NANO_TEST_SLOW_RECOVERY','NANO_CAPTURE_TIMEOUT_MS','NANO_TRACE_BUILD','NANO_SHADOW_TIMEOUT_SECONDS','COMPILER_PATH']});commands.append(item)
  (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');start=time.monotonic()
  try:
   done=original_run(*args,**kwargs);item['returncode']=done.returncode
   for label in ['stdout','stderr']:
    data=getattr(done,label);item[label+'_present']=data is not None
    if data is not None:(command_dir/f'{number:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   return done
  except BaseException as error:
   item['error']=repr(error)
   if isinstance(error,subprocess.TimeoutExpired):
    for label,data in [('stdout',error.output),('stderr',error.stderr)]:
     if data is not None:(command_dir/f'{number:05d}.{label}').write_bytes(data.encode() if isinstance(data,str) else data)
   raise
  finally:
   item['seconds']=time.monotonic()-start;(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 record['provider_axis']=dict(ambient_helper=None,default_helper=str(root/'obj/nano_as_capture.so'),default_helper_absent=not (root/'obj/nano_as_capture.so').exists(),built_helper=str(root/'bin/nano_as_capture.so'),limits='I change only the ambient helper provider setting from the original supported control. The eight original external subcases execute; integrated and slow controls are not repeated. I preserve all old source/control roots and disable observer bytecode writes.')
 assert record['provider_axis']['default_helper_absent'] and os.environ.get('NANO_AS_CAPTURE_HELPER') is None
 assert sha(root/'src/module_builder.c')=='5114f15ae779896d300de0987d720eb3fcd11da9d79adb257ad51ecd6a941a35'
 record['status']='running-original-methods';save()
 start=time.monotonic()
 with patch.object(tempfile,'TemporaryDirectory',RetainedDirectory),patch.object(subprocess,'run',recorded_run):
  import tests.test_source_snapshots as selected_tests
  assert Path(selected_tests.__file__).resolve()==root/'tests/test_source_snapshots.py'
  record['imported_test_source']=str(Path(selected_tests.__file__).resolve());save()
  class ExternalOnly(selected_tests.SourceSnapshots):
   def test_equals_path_post_capture_reads(self):self.native_unit_post_capture_reads(integrated=False,equals_paths=True)
  suite=unittest.TestSuite([ExternalOnly('test_equals_path_post_capture_reads')]);assert suite.countTestCases()==1
  def leaves(group):
   for test in group:
    if isinstance(test,unittest.TestSuite):yield from leaves(test)
    else:yield test
  assert [case._testMethodName for case in leaves(suite)]==record['methods']
  with (out/'original-methods.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 record['tests']=dict(discovered=1,ran=result.testsRun,failures=[dict(case=case.id(),traceback=tb) for case,tb in result.failures],errors=[dict(case=case.id(),traceback=tb) for case,tb in result.errors],skipped=[(case.id(),reason) for case,reason in result.skipped],seconds=time.monotonic()-start,successful=result.wasSuccessful())
 record['status']='terminal-pass' if result.wasSuccessful() else 'terminal-failure';guards();record['source_and_tool_guards_unchanged']=True
except BaseException as error:
 record.update(status='observer-failure',error=repr(error));(out/'exception').write_text(traceback.format_exc());raise
finally:save()
print(json.dumps({k:v for k,v in record.items() if k not in ['source_hashes','tests','tools','identities']}));sys.exit(0 if record['status']=='terminal-pass' else 1)
