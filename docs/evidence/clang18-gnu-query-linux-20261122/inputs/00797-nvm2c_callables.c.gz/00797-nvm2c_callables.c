#include "nvm2c_callables.h"
#include "../nanovm/vm_decode.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "nvm2c_effect_flow.h"

typedef struct {
    NvmShapeId callee, result;
    NvmShapeId *arguments;
    uint32_t *linked;
    size_t linked_count;
    uint16_t arity, results;
} IndirectCall;

typedef struct {
    const NvmModule *module;
    NvmCallableAnalysis *out;
    /* I conservatively merge capture provenance across instances of one body.
     * These analysis slots do not imply shared runtime environments. */
    NvmShapeId **locals, **upvalues, *results, *globals;
    size_t global_count;
    uint32_t field_count;
    uint16_t *variants;
    size_t variant_count;
    IndirectCall *calls;
    size_t call_count;
    Nvm2cHandler *handlers;
    size_t handler_count;
    NvmShapeId *effect_results;
} Analysis;

typedef struct { NvmShapeId *stack; size_t count; int set; } Frame;

/* I keep selected-arm provenance separate from ordinary positional fields. */
#define CALLABLE_VARIANT_BASE UINT32_C(65536)

static int fail(Analysis *a, const char *message) {
    if (!a->out->error[0]) snprintf(a->out->error, sizeof a->out->error, "%s", message);
    return 0;
}
static NvmShapeId fresh(Analysis *a) {
    return nvm_shape_new(&a->out->shapes, NVM_SHAPE_UNKNOWN);
}
static int flow(Analysis *a, NvmShapeId source, NvmShapeId destination) {
    return nvm_shape_convert(&a->out->shapes, source, destination);
}
static NvmShapeId field(Analysis *a, NvmShapeId value, uint32_t index) {
    return nvm_shape_child(&a->out->shapes, value, index);
}
static int connect_call(Analysis *a, uint32_t target, const NvmShapeId *arguments,
                        uint16_t arity, uint16_t results, NvmShapeId result) {
    if (target >= a->module->function_count)
        return fail(a, "I require a module-local callable target");
    const NvmFunctionEntry *fn = &a->module->functions[target];
    if (fn->arity != arity || fn->result_count != results || results > 1)
        return fail(a, "I require matching callable argument and result counts");
    for (uint16_t i = 0; i < arity; ++i)
        if (!flow(a, arguments[i], a->locals[target][i])) return 0;
    return !results || flow(a, a->results[target], result);
}
static int edge(Analysis *a, Frame *frames, uint32_t destination,
                const NvmShapeId *stack, size_t count, uint32_t *work, size_t *tail) {
    Frame *frame = &frames[destination];
    if (!frame->set) {
        frame->stack = calloc(count ? count : 1, sizeof *frame->stack);
        if (!frame->stack) return fail(a, "I cannot allocate callable control-flow storage");
        frame->count = count;
        frame->set = 1;
        for (size_t i = 0; i < count; ++i) frame->stack[i] = fresh(a);
        work[(*tail)++] = destination;
    }
    if (frame->count != count) return fail(a, "I require equal callable stack heights at joins");
    for (size_t i = 0; i < count; ++i)
        if (!flow(a, stack[i], frame->stack[i])) return 0;
    return 1;
}

static int collect_function(Analysis *a, uint32_t function) {
    VmDecodedFunction decoded = {0};
    const NvmFunctionEntry *fn = &a->module->functions[function];
    char error[VM_DECODE_ERROR_SIZE];
    if (!vm_decode_function(a->module, function, &decoded, error)) return fail(a, error);
    size_t count = decoded.instruction_count;
    Frame *frames = calloc(count + 1, sizeof *frames);
    uint32_t *work = calloc(count + 1, sizeof *work);
    NvmShapeId *stack = NULL;
    unsigned char *branch_targets = calloc(count + 1, 1);
    int ok = 0;
    if (!branch_targets) { fail(a, "I cannot retain callable branch boundaries"); goto done; }
    for (size_t i = 0; i < count; ++i) {
        const VmDecodedInstruction *instruction = &decoded.instructions[i];
        uint8_t opcode = instruction->instruction.opcode;
        if (opcode != OP_JMP && opcode != OP_JMP_TRUE && opcode != OP_JMP_FALSE && opcode != OP_HANDLER_PUSH) continue;
        int64_t offset = (int64_t)instruction->byte_offset + instruction->instruction.operands[opcode == OP_HANDLER_PUSH ? 1 : 0].i32;
        if (offset < 0 || (uint64_t)offset > decoded.code_size ||
            !vm_decoded_function_has_boundary(&decoded, (uint32_t)offset)) {
            fail(a, "I require valid callable branch boundaries"); goto done;
        }
        size_t target = offset == decoded.code_size ? count :
            (size_t)(vm_decoded_function_at(&decoded, (uint32_t)offset) - decoded.instructions);
        branch_targets[target] = 1;
    }
    if (!frames || !work) { fail(a, "I cannot allocate callable analysis frames"); goto done; }
    size_t head = 0, tail = 0;
    if (!edge(a, frames, 0, NULL, 0, work, &tail)) goto done;
    while (head < tail) {
        uint32_t at = work[head++];
        if (at == count) continue;
        const VmDecodedInstruction *decoded_instruction = &decoded.instructions[at];
        const DecodedInstruction *in = &decoded_instruction->instruction;
        const InstructionInfo *info = isa_get_info(in->opcode);
        if (!info) { fail(a, "I require known callable-analysis instructions"); goto done; }
        int pop = info->pop_count, push = info->push_count;
        uint32_t target = in->operands[0].u32;
        switch (in->opcode) {
        case OP_CALL: case OP_TAIL_CALL:
            if (target >= a->module->function_count) { fail(a, "I require a valid direct call target"); goto done; }
            pop = a->module->functions[target].arity;
            push = a->module->functions[target].result_count; break;
        case OP_CALL_EXTERN:
            if (target >= a->module->import_count) { fail(a, "I require a valid callable-analysis import"); goto done; }
            pop = a->module->imports[target].param_count;
            push = a->module->imports[target].return_type != TAG_VOID; break;
        case OP_CALL_INDIRECT: pop = in->operands[0].u16 + 1; push = in->operands[1].u16; break;
        case OP_CLOSURE_NEW: pop = in->operands[1].u16; push = 1; break;
        case OP_AGG_PACK: pop = in->operands[3].u16; push = 1; break;
        case OP_ARR_LITERAL: pop = in->operands[1].u16; push = 1; break;
        case OP_PERFORM: pop = in->operands[1].u16; push = 1; break;
        case OP_PICK: pop = 0; push = 1; break;
        case OP_RET: pop = fn->result_count; push = 0; break;
        default: break;
        }
        if (pop < 0 || push < 0 || push > 3) {
            fail(a, "I require an explicit stack contract for callable analysis"); goto done;
        }
        size_t before = frames[at].count;
        if (in->opcode == OP_PICK && in->operands[0].u16 >= before) {
            fail(a, "I require an existing stack slot for callable PICK"); goto done;
        }
        if ((size_t)pop > before) {
            snprintf(error, sizeof error, "I found callable-analysis stack underflow in function %u at %u (%s: %zu available, %d required)",
                     function, decoded_instruction->byte_offset, info->name, before, pop);
            fail(a, error); goto done;
        }
        size_t base = before - (size_t)pop, after = base + (size_t)push;
        size_t capacity = before > after ? before : after;
        free(stack);
        stack = calloc(capacity ? capacity : 1, sizeof *stack);
        if (!stack) { fail(a, "I cannot allocate a callable-analysis stack"); goto done; }
        if (before) memcpy(stack, frames[at].stack, before * sizeof *stack);
        NvmShapeId output[3] = {0};
        for (int i = 0; i < push; ++i) output[i] = fresh(a);
        switch (in->opcode) {
        case OP_PERFORM: {
            if (target >= a->module->string_count) { fail(a, "I require a valid effect operation"); goto done; }
            uint32_t operation = effect_operation(a->module, target);
            output[0] = a->effect_results[operation];
            for (size_t h = 0; h < a->handler_count; ++h) {
                Nvm2cHandler *handler = &a->handlers[h];
                if (handler->operation != operation || handler->count != pop) continue;
                for (int p = 0; p < pop; ++p)
                    if (!flow(a, stack[base + (size_t)p], a->locals[handler->function][handler->start + p])) goto done;
            }
            break;
        }
        case OP_EFFECT_RESUME:
            for (size_t h = 0; h < a->handler_count; ++h) {
                Nvm2cHandler *handler = &a->handlers[h];
                if (handler->function == function && handler->flow[decoded_instruction->byte_offset] &&
                    !flow(a, stack[base], a->effect_results[handler->operation])) goto done;
            }
            break;
        case OP_FUNCREF:
            if (target >= a->module->function_count) { fail(a, "I require a valid function reference"); goto done; }
            if (!nvm_shape_function_add(&a->out->shapes, output[0], target)) goto done;
            break;
        case OP_CLOSURE_NEW:
            if (target >= a->module->function_count ||
                a->module->functions[target].upvalue_count != (uint16_t)pop) {
                fail(a, "I require matching closure target and capture counts"); goto done;
            }
            if (!nvm_shape_function_add(&a->out->shapes, output[0], target)) goto done;
            for (int i = 0; i < pop; ++i)
                if (!flow(a, stack[base + (size_t)i], a->upvalues[target][i])) goto done;
            break;
        case OP_LOAD_UPVALUE: case OP_STORE_UPVALUE: {
            uint16_t slot = in->operands[1].u16;
            if (in->operands[0].u16 != 0 || slot >= fn->upvalue_count) {
                fail(a, "I require a valid flattened callable capture"); goto done;
            }
            if (in->opcode == OP_LOAD_UPVALUE) output[0] = a->upvalues[function][slot];
            else if (!flow(a, stack[base], a->upvalues[function][slot])) goto done;
            break;
        }
        case OP_LOAD_LOCAL: case OP_STORE_LOCAL: {
            uint16_t slot = in->operands[0].u16;
            if (slot >= fn->local_count) { fail(a, "I require a valid callable local"); goto done; }
            if (in->opcode == OP_LOAD_LOCAL) output[0] = a->locals[function][slot];
            else if (!flow(a, stack[base], a->locals[function][slot])) goto done;
            break;
        }
        case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL:
            if (target >= a->global_count) { fail(a, "I require a valid callable global"); goto done; }
            if (in->opcode == OP_LOAD_GLOBAL) output[0] = a->globals[target];
            else if (!flow(a, stack[base], a->globals[target])) goto done;
            break;
        case OP_DUP: output[0] = output[1] = stack[base]; break;
        case OP_PICK: output[0] = stack[before - 1 - in->operands[0].u16]; break;
        case OP_SWAP: output[0] = stack[base + 1]; output[1] = stack[base]; break;
        case OP_ROT3: output[0] = stack[base + 2]; output[1] = stack[base]; output[2] = stack[base + 1]; break;
        case OP_AGG_PACK:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_RECORD))) goto done;
            for (int i = 0; i < pop; ++i) {
                if (!flow(a, stack[base + (size_t)i], field(a, output[0], (uint32_t)i))) goto done;
                if (in->operands[0].u8 == 1) {
                    NvmShapeId selected = field(a, output[0], CALLABLE_VARIANT_BASE + in->operands[2].u16);
                    if (!nvm_shape_unify(&a->out->shapes, selected, nvm_shape_new(&a->out->shapes, NVM_SHAPE_RECORD))) goto done;
                    if (!flow(a, stack[base + (size_t)i], field(a, selected, (uint32_t)i))) goto done;
                }
            }
            break;
        case OP_AGG_GET:
            output[0] = field(a, stack[base], in->operands[0].u16);
            a->out->projections[function][decoded_instruction->byte_offset] = output[0];
            break;
        case OP_ARR_NEW:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY))) goto done;
            break;
        case OP_CALL_EXTERN: {
            const NvmImportEntry *import = &a->module->imports[target];
            const char *library = nvm_get_string(a->module, import->module_name_idx);
            const char *symbol = nvm_get_string(a->module, import->function_name_idx);
            if (library && !*library && symbol && !strcmp(symbol, "vm_array_sort") &&
                pop == 1 && push == 1 && import->return_type == TAG_ARRAY &&
                a->module->import_param_types && a->module->import_param_types[target] &&
                a->module->import_param_types[target][0] == TAG_ARRAY) {
                if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY)) ||
                    !flow(a, field(a, stack[base], 0), field(a, output[0], 0)) ||
                    !nvm_shape_tags_add(&a->out->shapes, output[0], 1u << TAG_ARRAY)) goto done;
            } else if (library && !*library && symbol &&
                !strcmp(symbol, "vm_bytes_from_string") && pop == 1 && push == 1 &&
                import->return_type == TAG_ARRAY && a->module->import_param_types &&
                a->module->import_param_types[target] && a->module->import_param_types[target][0] == TAG_STRING) {
                if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY)) ||
                    !nvm_shape_tags_add(&a->out->shapes, output[0], 1u << TAG_ARRAY) ||
                    !nvm_shape_tags_add(&a->out->shapes, field(a, output[0], 0), 1u << TAG_U8)) goto done;
            } else if (library && !*library && symbol &&
                !strcmp(symbol, "vm_string_from_bytes") && pop == 1 && push == 1 &&
                import->return_type == TAG_STRING && a->module->import_param_types &&
                a->module->import_param_types[target] && a->module->import_param_types[target][0] == TAG_ARRAY) {
                if (!nvm_shape_tags_add(&a->out->shapes, output[0], 1u << TAG_STRING)) goto done;
            } else {
                for (int i = 0; i < push; ++i)
                    if (!nvm_shape_tags_add(&a->out->shapes, output[i], NVM_CALLABLE_TAG_UNKNOWN)) goto done;
            }
            break;
        }
        case OP_STR_SPLIT:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY)) ||
                !nvm_shape_tags_add(&a->out->shapes, field(a, output[0], 0), 1u << TAG_STRING)) goto done;
            break;
        case OP_ARR_LITERAL:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY))) goto done;
            for (int i = 0; i < pop; ++i)
                if (!flow(a, stack[base + (size_t)i], field(a, output[0], 0))) goto done;
            break;
        case OP_ARR_REMOVE: output[0] = stack[base]; break;
        case OP_ARR_SLICE:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_ARRAY)) ||
                !flow(a, field(a, stack[base], 0), field(a, output[0], 0))) goto done;
            break;
        case OP_ARR_POP:
        case OP_ARR_GET: output[0] = field(a, stack[base], 0); break;
        case OP_ARR_SET: case OP_ARR_PUSH:
            output[0] = stack[base];
            if (!flow(a, stack[before - 1], field(a, output[0], 0))) goto done;
            break;
        case OP_HM_NEW:
            if (!nvm_shape_unify(&a->out->shapes, output[0], nvm_shape_new(&a->out->shapes, NVM_SHAPE_MAP))) goto done;
            break;
        case OP_HM_GET: output[0] = field(a, stack[base], 1); break;
        case OP_HM_SET:
            output[0] = stack[base];
            if (!flow(a, stack[base + 1], field(a, output[0], 0)) ||
                !flow(a, stack[base + 2], field(a, output[0], 1))) goto done;
            break;
        case OP_HM_DELETE: output[0] = stack[base]; break;
        case OP_CALL: case OP_TAIL_CALL:
            if (!connect_call(a, target, stack + base, (uint16_t)pop, (uint16_t)push, output[0])) goto done;
            if (in->opcode == OP_TAIL_CALL && push && !flow(a, output[0], a->results[function])) goto done;
            break;
        case OP_CALL_INDIRECT: {
            if (push > 1) { fail(a, "I require at most one native callable result"); goto done; }
            if (a->call_count >= SIZE_MAX / sizeof *a->calls) {
                fail(a, "I cannot represent indirect-call constraints"); goto done;
            }
            IndirectCall *next = realloc(a->calls, (a->call_count + 1) * sizeof *next);
            if (!next) { fail(a, "I cannot allocate indirect-call constraints"); goto done; }
            a->calls = next;
            IndirectCall *call = &a->calls[a->call_count++];
            *call = (IndirectCall){.callee = stack[before - 1], .result = output[0],
                                   .arity = (uint16_t)(pop - 1), .results = (uint16_t)push};
            call->arguments = calloc(call->arity ? call->arity : 1, sizeof *call->arguments);
            if (!call->arguments) { fail(a, "I cannot retain callable arguments"); goto done; }
            memcpy(call->arguments, stack + base, call->arity * sizeof *call->arguments);
            a->out->callees[function][decoded_instruction->byte_offset] = call->callee;
            break;
        }
        case OP_RET:
            if (pop > 1 || (pop && !flow(a, stack[base], a->results[function]))) goto done;
            break;
        default:
            for (int i = 0; i < push; ++i) {
                uint16_t tags = NVM_CALLABLE_TAG_UNKNOWN;
                switch (in->opcode) {
                case OP_STR_LEN: case OP_STR_CHAR_AT: case OP_ARR_LEN: case OP_HM_LEN:
                case OP_AGG_TAG: case OP_ENUM_VAL: case OP_CAST_INT: case OP_F64_TO_BITS:
                case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
                case OP_I64_REM_S: case OP_I64_NEG: case OP_I64_DIV_U: case OP_I64_REM_U:
                case OP_I64_AND: case OP_I64_OR: case OP_I64_XOR: case OP_I64_INVERT:
                case OP_I64_SHL: case OP_I64_SHR_S: case OP_I64_SHR_U:
                case OP_PUSH_I64: tags = 1u << TAG_INT; break;
                case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV:
                case OP_F64_NEG: case OP_CAST_FLOAT: case OP_F64_FROM_BITS:
                case OP_PUSH_F64: tags = 1u << TAG_FLOAT; break;
                case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
                case OP_AND: case OP_OR: case OP_NOT: case OP_BOOL_AND: case OP_BOOL_OR: case OP_BOOL_NOT:
                case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
                case OP_I64_GT_S: case OP_I64_GE_S: case OP_I64_LT_U: case OP_I64_LE_U:
                case OP_I64_GT_U: case OP_I64_GE_U: case OP_F64_EQ: case OP_F64_NE:
                case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
                case OP_STR_CONTAINS: case OP_STR_EQ: case OP_STR_STARTS_WITH: case OP_STR_ENDS_WITH:
                case OP_HM_HAS: case OP_CAST_BOOL: case OP_TYPE_CHECK: case OP_OPAQUE_VALID:
                case OP_PUSH_BOOL: tags = 1u << TAG_BOOL; break;
                case OP_STR_CONCAT: case OP_STR_SUBSTR: case OP_STR_FROM_INT: case OP_STR_FROM_FLOAT:
                case OP_STR_TRIM: case OP_STR_TO_LOWER: case OP_STR_TO_UPPER: case OP_STR_REPLACE:
                case OP_CAST_STRING: case OP_PUSH_STR: tags = 1u << TAG_STRING; break;
                case OP_PUSH_VOID: tags = 1u << TAG_VOID; break;
                case OP_CAST_U8: case OP_PUSH_U8: tags = 1u << TAG_U8; break;
                default: break;
                }
                if (!nvm_shape_tags_add(&a->out->shapes, output[i], tags)) goto done;
            }
            break;
        }
        if (push && (in->opcode == OP_ARR_NEW || in->opcode == OP_ARR_LITERAL || in->opcode == OP_ARR_SLICE || in->opcode == OP_STR_SPLIT))
            if (!nvm_shape_tags_add(&a->out->shapes, output[0], 1u << TAG_ARRAY)) goto done;
        if (push && (in->opcode == OP_FUNCREF || in->opcode == OP_CLOSURE_NEW))
            if (!nvm_shape_tags_add(&a->out->shapes, output[0], 1u << TAG_FUNCTION)) goto done;
        for (int i = 0; i < push; ++i) stack[base + (size_t)i] = output[i];
        if (a->out->shapes.error) goto done;
        if (in->opcode == OP_RET || in->opcode == OP_HALT || in->opcode == OP_TAIL_CALL || in->opcode == OP_EFFECT_RESUME) continue;
        if (in->opcode == OP_HANDLER_PUSH) {
            uint32_t offset = (uint32_t)((int64_t)decoded_instruction->byte_offset + in->operands[1].i32);
            uint32_t destination = (uint32_t)(vm_decoded_function_at(&decoded, offset) - decoded.instructions);
            if (!edge(a, frames, destination, NULL, 0, work, &tail)) goto done;
        }
        if (in->opcode == OP_JMP || in->opcode == OP_JMP_TRUE || in->opcode == OP_JMP_FALSE) {
            int64_t offset = (int64_t)decoded_instruction->byte_offset + in->operands[0].i32;
            if (offset < 0 || (uint64_t)offset > decoded.code_size ||
                !vm_decoded_function_has_boundary(&decoded, (uint32_t)offset)) {
                fail(a, "I require a valid callable branch target"); goto done;
            }
            uint32_t destination = offset == decoded.code_size ? (uint32_t)count : (uint32_t)(vm_decoded_function_at(&decoded, (uint32_t)offset) - decoded.instructions);
            if (!edge(a, frames, destination, stack, after, work, &tail)) goto done;
            if (in->opcode == OP_JMP) continue;
            /* I refine only the fallthrough of an uninterrupted exact tag
             * equality. Entry into its middle would invalidate the DUP proof. */
            if (in->opcode == OP_JMP_FALSE && at >= 4 && after &&
                decoded.instructions[at-4].instruction.opcode == OP_DUP &&
                decoded.instructions[at-3].instruction.opcode == OP_AGG_TAG &&
                decoded.instructions[at-2].instruction.opcode == OP_PUSH_I64 &&
                (decoded.instructions[at-1].instruction.opcode == OP_EQ ||
                 decoded.instructions[at-1].instruction.opcode == OP_I64_EQ) &&
                !branch_targets[at-3] && !branch_targets[at-2] &&
                !branch_targets[at-1] && !branch_targets[at]) {
                int64_t variant = decoded.instructions[at-2].instruction.operands[0].i64;
                if (variant >= 0 && variant <= UINT16_MAX) {
                    NvmShapeId original = stack[after-1];
                    NvmShapeId view = nvm_shape_new(&a->out->shapes, NVM_SHAPE_RECORD);
                    NvmShapeId selected = field(a, original, CALLABLE_VARIANT_BASE + (uint32_t)variant);
                    for (uint32_t i = 0; i < a->field_count; ++i)
                        if (!flow(a, field(a, selected, i), field(a, view, i))) goto done;
                    /* A later match still sees each constructor's tag map. */
                    for (size_t i = 0; i < a->variant_count; ++i) {
                        uint32_t key = CALLABLE_VARIANT_BASE + a->variants[i];
                        if (!flow(a, field(a, original, key), field(a, view, key))) goto done;
                    }
                    stack[after-1] = view;
                }
            }
        }
        if (!edge(a, frames, at + 1, stack, after, work, &tail)) goto done;
    }
    ok = 1;
done:
    if (frames) for (size_t i = 0; i <= count; ++i) free(frames[i].stack);
    free(frames); free(work); free(stack); free(branch_targets);
    vm_decoded_function_free(&decoded);
    return ok;
}

/* I preserve mutable element identity through copied array/map handles, including arrays
 * nested in copied records. A later write through either alias reaches reads
 * through the other; scalar function assignments still flow only forward. */
static int connect_array_aliases(Analysis *a, int *changed) {
    NvmShapeGraph *g = &a->out->shapes;
    typedef struct { NvmShapeId source, target; } Pair;
    for (size_t c = 0; c < g->conversion_count; ++c) {
        size_t count = 1, cursor = 0;
        Pair *pairs = malloc(sizeof *pairs);
        if (!pairs) return fail(a, "I cannot allocate callable alias constraints");
        pairs[0] = (Pair){g->conversions[c].source, g->conversions[c].target};
        while (cursor < count && !g->error) {
            Pair pair = pairs[cursor++];
            pair.source = nvm_shape_root(g, pair.source);
            pair.target = nvm_shape_root(g, pair.target);
            if (pair.source == pair.target) continue;
            NvmShapeKind kind = nvm_shape_kind(g, pair.source);
            if (kind != nvm_shape_kind(g, pair.target)) continue;
            if (kind == NVM_SHAPE_ARRAY || kind == NVM_SHAPE_MAP) {
                uint32_t fields = kind == NVM_SHAPE_MAP ? 2 : 1;
                for (uint32_t f = 0; f < fields && !g->error; ++f) {
                    NvmShapeId from = nvm_shape_child(g, pair.source, f);
                    NvmShapeId to = nvm_shape_child(g, pair.target, f);
                    if (nvm_shape_root(g, from) != nvm_shape_root(g, to)) {
                        if (!nvm_shape_unify(g, from, to)) break;
                        *changed = 1;
                    }
                }
            } else if (kind == NVM_SHAPE_RECORD) {
                for (size_t f = 0; f < (size_t)a->field_count + a->variant_count; ++f) {
                    uint32_t field_index = f < a->field_count ? (uint32_t)f :
                        CALLABLE_VARIANT_BASE + a->variants[f - a->field_count];
                    NvmShapeId from = nvm_shape_lookup(g, pair.source, field_index);
                    NvmShapeId to = nvm_shape_lookup(g, pair.target, field_index);
                    if (!from || !to || from == to) continue;
                    size_t seen = 0;
                    while (seen < count &&
                           (nvm_shape_root(g, pairs[seen].source) != from ||
                            nvm_shape_root(g, pairs[seen].target) != to)) ++seen;
                    if (seen < count) continue;
                    if (count >= SIZE_MAX / sizeof *pairs) {
                        fail(a, "I cannot represent callable alias constraints"); free(pairs); return 0;
                    }
                    Pair *next = realloc(pairs, (count + 1) * sizeof *pairs);
                    if (!next) { free(pairs); return fail(a, "I cannot grow callable alias constraints"); }
                    pairs = next; pairs[count++] = (Pair){from, to};
                }
            }
        }
        free(pairs);
        if (g->error) return 0;
    }
    return 1;
}

void nvm_callable_destroy(NvmCallableAnalysis *out) {
    if (out->callees) for (uint32_t i = 0; i < out->function_count; ++i) free(out->callees[i]);
    if (out->projections) for (uint32_t i = 0; i < out->function_count; ++i) free(out->projections[i]);
    free(out->projections); free(out->callees); free(out->code_lengths);
    nvm_shape_destroy(&out->shapes);
    memset(out, 0, sizeof *out);
}

NvmShapeId nvm_callable_at(NvmCallableAnalysis *out, uint32_t function, uint32_t offset) {
    if (out->error[0] || function >= out->function_count || offset >= out->code_lengths[function]) return 0;
    NvmShapeId shape = out->callees[function][offset];
    if (!shape || nvm_shape_kind(&out->shapes, shape) != NVM_SHAPE_FUNCTION) return 0;
    return shape;
}

uint16_t nvm_callable_projection_tags(NvmCallableAnalysis *out, uint32_t function, uint32_t offset) {
    if (out->error[0] || function >= out->function_count || offset >= out->code_lengths[function])
        return NVM_CALLABLE_TAG_UNKNOWN;
    NvmShapeId shape = out->projections[function][offset];
    return shape ? nvm_shape_tags(&out->shapes, shape) : NVM_CALLABLE_TAG_UNKNOWN;
}

int nvm_callable_analyze(const NvmModule *module, NvmCallableAnalysis *out) {
    memset(out, 0, sizeof *out);
    Analysis a = {.module = module, .out = out};
    int ok = 0;
    if (!module || !module->functions || !module->function_count) return fail(&a, "I require callable module functions");
    out->function_count = module->function_count;
    out->callees = calloc(module->function_count, sizeof *out->callees);
    out->projections = calloc(module->function_count, sizeof *out->projections);
    out->code_lengths = calloc(module->function_count, sizeof *out->code_lengths);
    a.locals = calloc(module->function_count, sizeof *a.locals);
    a.upvalues = calloc(module->function_count, sizeof *a.upvalues);
    a.results = calloc(module->function_count, sizeof *a.results);
    if (!out->projections || !out->callees || !out->code_lengths || !a.locals || !a.upvalues || !a.results) goto done;
    /* I retain every global referenced by the module, including late stores. */
    for (uint32_t f = 0; f < module->function_count; ++f) {
        const NvmFunctionEntry *fn = &module->functions[f];
        if (fn->arity > fn->local_count || fn->code_offset > module->code_size ||
            fn->code_length > module->code_size - fn->code_offset) goto done;
        out->code_lengths[f] = fn->code_length;
        out->callees[f] = calloc(fn->code_length ? fn->code_length : 1, sizeof **out->callees);
        out->projections[f] = calloc(fn->code_length ? fn->code_length : 1, sizeof **out->projections);
        a.locals[f] = calloc(fn->local_count ? fn->local_count : 1, sizeof **a.locals);
        a.upvalues[f] = calloc(fn->upvalue_count ? fn->upvalue_count : 1, sizeof **a.upvalues);
        if (!out->projections[f] || !out->callees[f] || !a.locals[f] || !a.upvalues[f]) goto done;
        a.results[f] = fresh(&a);
        for (uint16_t l = 0; l < fn->local_count; ++l) a.locals[f][l] = fresh(&a);
        for (uint16_t u = 0; u < fn->upvalue_count; ++u) a.upvalues[f][u] = fresh(&a);
        for (uint32_t pc = 0; pc < fn->code_length;) {
            DecodedInstruction in;
            uint32_t size = isa_decode(module->code + fn->code_offset + pc, fn->code_length - pc, &in);
            if (!size) goto done;
            uint32_t fields = in.opcode == OP_AGG_PACK ? in.operands[3].u16 :
                in.opcode == OP_AGG_GET ? (uint32_t)in.operands[0].u16 + 1 : 0;
            if (fields > a.field_count) a.field_count = fields;
            if (in.opcode == OP_AGG_PACK && in.operands[0].u8 == 1) {
                uint16_t variant = in.operands[2].u16;
                size_t i = 0;
                while (i < a.variant_count && a.variants[i] != variant) ++i;
                if (i == a.variant_count) {
                    uint16_t *next = realloc(a.variants, (i + 1) * sizeof *next);
                    if (!next) goto done;
                    a.variants = next; a.variants[a.variant_count++] = variant;
                }
            }
            if (in.opcode == OP_LOAD_GLOBAL || in.opcode == OP_STORE_GLOBAL) {
                if (in.operands[0].u32 >= NVM_MAX_GLOBALS) goto done;
                size_t required = (size_t)in.operands[0].u32 + 1;
                if (required > a.global_count) a.global_count = required;
            }
            pc += size;
        }
    }
    a.globals = calloc(a.global_count ? a.global_count : 1, sizeof *a.globals);
    if (!a.globals) goto done;
    for (size_t i = 0; i < a.global_count; ++i) a.globals[i] = fresh(&a);
    if (!effect_collect_entries(module, &a.handlers, &a.handler_count)) goto done;
    a.effect_results = calloc(module->string_count ? module->string_count : 1, sizeof *a.effect_results);
    if (!a.effect_results) goto done;
    for (uint32_t i = 0; i < module->string_count; ++i) a.effect_results[i] = fresh(&a);
    for (uint32_t f = 0; f < module->function_count; ++f)
        if (!collect_function(&a, f)) goto done;
    for (;;) {
        if (!nvm_shape_solve_conversions(&out->shapes)) goto done;
        int changed = 0;
        if (!connect_array_aliases(&a, &changed)) goto done;
        for (size_t c = 0; c < a.call_count; ++c) {
            IndirectCall *call = &a.calls[c];
            if (nvm_shape_kind(&out->shapes, call->callee) != NVM_SHAPE_FUNCTION) continue;
            size_t count = nvm_shape_function_count(&out->shapes, call->callee);
            for (size_t i = 0; i < count; ++i) {
                uint32_t target;
                if (!nvm_shape_function_target(&out->shapes, call->callee, i, &target)) goto done;
                size_t seen = 0;
                while (seen < call->linked_count && call->linked[seen] != target) ++seen;
                if (seen < call->linked_count) continue;
                if (!connect_call(&a, target, call->arguments, call->arity, call->results, call->result)) goto done;
                if (call->linked_count >= SIZE_MAX / sizeof *call->linked) goto done;
                uint32_t *next = realloc(call->linked, (call->linked_count + 1) * sizeof *next);
                if (!next) goto done;
                call->linked = next; call->linked[call->linked_count++] = target;
                changed = 1;
            }
        }
        if (!changed) break;
    }
    ok = 1;
done:
    if (!ok && !out->error[0]) fail(&a, out->shapes.error ? out->shapes.error : "I cannot construct callable constraints");
    if (a.locals) for (uint32_t f = 0; f < module->function_count; ++f) free(a.locals[f]);
    if (a.upvalues) for (uint32_t f = 0; f < module->function_count; ++f) free(a.upvalues[f]);
    for (size_t i = 0; i < a.call_count; ++i) { free(a.calls[i].arguments); free(a.calls[i].linked); }
    for (size_t h = 0; h < a.handler_count; ++h) free(a.handlers[h].flow);
    free(a.handlers); free(a.effect_results);
    free(a.variants); free(a.calls); free(a.upvalues); free(a.locals); free(a.results); free(a.globals);
    return ok;
}
