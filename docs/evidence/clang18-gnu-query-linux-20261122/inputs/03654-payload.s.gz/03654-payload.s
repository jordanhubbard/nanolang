.include "/home/jkh/.worktrees/nanolang/clang18-capture-provider-axis-20261122-control/fixtures/nano=native-timing-wfvtlkn4/foreign/macro.s"
.data
.globl snapshot_payload
snapshot_payload:
emit "/home/jkh/.worktrees/nanolang/clang18-capture-provider-axis-20261122-control/fixtures/nano=native-timing-wfvtlkn4/foreign/payload.bin"
