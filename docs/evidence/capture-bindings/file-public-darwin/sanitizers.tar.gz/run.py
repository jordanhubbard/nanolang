from pathlib import Path
import subprocess,hashlib,json,tarfile,os,signal,time,shutil
base=Path(__file__).resolve().parent;root=base/'source';reports=base/'reports'
assert shutil.disk_usage(base).free>=2*1024**3
root.mkdir();reports.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def dump(n,x):(reports/n).write_text(json.dumps(x,indent=2)+'\n')
with tarfile.open(base/'source.tar.gz') as t:t.extractall(root,filter='data')
paths=json.loads((base/'paths.json').read_text())
subprocess.run(['/usr/bin/git','init','-q'],cwd=root,check=True)
with (base/'reference.pack').open('rb') as f:subprocess.run(['/usr/bin/git','index-pack','--stdin'],cwd=root,stdin=f,stdout=subprocess.DEVNULL,check=True)
reference='/usr/bin/git'
refspec='f1606e2c84e67491e9652a5bf71944d235216d95:src/nanoisa/nvm2c_file_private.c'
reference_bytes=subprocess.check_output([reference,'show',refspec],cwd=root)
dump('reference.json',{'spec':refspec,'sha256':hashlib.sha256(reference_bytes).hexdigest(),'pack_sha256':sha(base/'reference.pack'),'scope':'Exact required historical commit/tree/blob objects only; no full historical checkout.'})
subprocess.run(['/usr/bin/git','add','-f','.'],cwd=root,check=True)
subprocess.run(['/usr/bin/git','-c','user.name=Qualification','-c','user.email=qualification@localhost','commit','-qm','Frozen qualification source'],cwd=root,check=True)

def inputs():return {p:{'sha256':sha(root/p),'bytes':(root/p).stat().st_size} for p in paths}
clang='/opt/homebrew/opt/llvm/bin/clang'
ld=subprocess.check_output(['/usr/bin/xcrun','--find','ld'],text=True).strip()
sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
tools=[clang,ld,'/usr/bin/make','/usr/bin/git','/usr/bin/python3','/opt/homebrew/bin/python3.14','/opt/homebrew/opt/llvm/bin/clang','/opt/homebrew/opt/llvm/bin/opt']
runtime=Path(subprocess.check_output([clang,'--print-runtime-dir'],text=True).strip())
tools.extend(str(p) for p in runtime.glob('*asan*dynamic.dylib'))
def toolmap():return {p:{'realpath':str(Path(p).resolve()),'sha256':sha(Path(p).resolve())} for p in tools}
before=inputs();selected=toolmap();dump('inputs-before.json',before);dump('tools-before.json',selected)
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['SDKROOT']=sdk;env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1';env['LSAN_OPTIONS']='';env['TMPDIR']=str(base/'artifacts');Path(env['TMPDIR']).mkdir()
cmd=['/usr/bin/make','-f','Makefile.gnu','-j2','CC='+clang,'CFLAGS=-Wall -Wextra -Werror -std=c99 -g -O1 -fPIC -Isrc -D_GNU_SOURCE -fno-omit-frame-pointer -fsanitize=address,undefined -isysroot '+sdk,'LDFLAGS=-lm -fsanitize=address,undefined -isysroot '+sdk,'NMS_RUNTIME_CLANG=/opt/homebrew/opt/llvm/bin/clang -isysroot '+sdk,'NMS_RUNTIME_OPT=/opt/homebrew/opt/llvm/bin/opt','test-file-public-sanitizers']
dump('source.json',{'revision':'d1f035314','archive_sha256':sha(base/'source.tar.gz'),'files':len(paths)})
dump('command.json',{'argv':cmd,'cwd':str(root),'SDKROOT':sdk,'PATH':env['PATH'],'sanitizers':{k:env[k] for k in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']},'timeout_seconds':1800})
def process_table():
 rows={}
 raw=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,lstart='],text=True)
 for line in raw.splitlines():
  parts=line.split()
  if len(parts)==8:rows[int(parts[0])]={'parent':int(parts[1]),'group':int(parts[2]),'started':' '.join(parts[3:])}
 return rows
owned={}
def observe(pid):
 table=process_table();selected={pid};changed=True
 while changed:
  changed=False
  for child,row in table.items():
   if row['parent'] in selected and child not in selected:selected.add(child);changed=True
 for child in selected:
  if child in table:owned[child]=table[child]
 return table
def live_owned():
 table=process_table()
 return {pid:row for pid,row in owned.items() if pid in table and table[pid]['started']==row['started']}
def terminate_owned():
 for sig in (signal.SIGTERM,signal.SIGKILL):
  for group in {row['group'] for row in live_owned().values()}:
   if group==os.getpgrp():raise RuntimeError('I refuse to terminate my own supervisor group')
   try:os.killpg(group,sig)
   except ProcessLookupError:pass
  time.sleep(0.5)
start=time.monotonic();status={'timeout':False,'capacity_refusal':False,'cleanup_errors':[]}
with (reports/'stdout.log').open('wb') as out,(reports/'stderr.log').open('wb') as err:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 while p.poll() is None:
  observe(p.pid)
  if time.monotonic()-start>1800 or shutil.disk_usage(base).free<1536*1024**2:
   status['timeout']=time.monotonic()-start>1800
   status['capacity_refusal']=not status['timeout']
   terminate_owned();break
  time.sleep(0.5)
 rc=p.wait(timeout=10)
remaining=live_owned()
if remaining:
 status['cleanup_errors'].append('I found tracked descendants after the leader exited')
 terminate_owned()
status.update(returncode=rc,seconds=time.monotonic()-start,leader_reaped=p.poll() is not None,tracked_remaining=live_owned())
try:os.killpg(p.pid,0);status['group_gone']=False
except ProcessLookupError:status['group_gone']=True
dump('owned-processes.json',owned)
assert subprocess.check_output([reference,'show',refspec],cwd=root)==reference_bytes
after=inputs();finaltools=toolmap();dump('terminal.json',status);dump('inputs-after.json',after);dump('tools-after.json',finaltools)
products={str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777} for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts and str(p.relative_to(root)) not in paths}
products.update({str(p.relative_to(base)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777} for p in (base/'artifacts').rglob('*') if p.is_file()})
dump('products.json',products);dump('checks.json',{'terminal':status,'source_unchanged':before==after,'tools_unchanged':selected==finaltools,'products':len(products)})
print(json.dumps(status),flush=True)
raise SystemExit(rc or (before!=after) or (selected!=finaltools) or bool(status['cleanup_errors']) or bool(status['tracked_remaining']))
