import hashlib,json,os,shlex,shutil,signal,subprocess,time
from pathlib import Path
root=Path('/run/user/1000/nanolang-capture-file-d1f-linux-r2/source')
old=root.parent/'reports'
report=Path('/run/user/1000/capture-private-f83-linux');report.mkdir(exist_ok=False)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(n,d):(report/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
shutil.copy2(__file__,report/'driver.py')
source=report/'test_capture_transport.c'
source.write_bytes(subprocess.check_output(['git','show','f83ad7941:tests/nanoisa/test_capture_transport.c'],cwd='/tmp/nanolang-record-literal-source-order'))
source_paths=json.loads((old/'inputs-after.json').read_text())
tool_paths=json.loads((old/'tools-after.json').read_text())
products=json.loads((old/'products.json').read_text())
def verify_inputs():
 for rel,entry in source_paths.items():
  expected=entry['sha256'] if isinstance(entry,dict) else entry
  assert digest(root/rel)==expected,rel
 for path,entry in tool_paths.items():assert digest(path)==entry['sha256'],path
 return {'source_files':len(source_paths),'tools':len(tool_paths),'status':'PASS'}
write('input-verification-before.json',verify_inputs())
argv=json.loads(Path('/tmp/capture-private-command.json').read_text());original=list(argv)
providers=[p for p in argv if p.endswith('.o')]
for p in providers:assert digest(root/p)==products[p]['sha256'],p
write('providers.json',{p:products[p] for p in providers})
argv[argv.index('-o')+1]=str(report/'consumer')
argv[argv.index('tests/nanoisa/test_capture_transport.c')]=str(source)
write('attribution.json',{'revision':'f83ad7941','production':'d1f035314','original_command':original,'source_sha256':digest(source),'provider_count':len(providers),'provider_archive_sha256':'da4ea96e9ab1b036499940391339e736a61c7d7e4cbe17459f153e39c9e883f9','scope':'one new fixture linked to rehashed retained ordinary GCC providers; not a fresh provider build'})
assert shutil.disk_usage(report).free>=2147483648
def run(name,cmd,bound):
 write(name+'-command.json',cmd);start=time.monotonic();timeout=False;capacity=False
 with (report/(name+'.log')).open('wb') as out:
  p=subprocess.Popen(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,TMPDIR=str(report)))
  while p.poll() is None:
   if time.monotonic()-start>bound:timeout=True;break
   if shutil.disk_usage(report).free<1610612736:capacity=True;break
   try:p.wait(timeout=.25)
   except subprocess.TimeoutExpired:pass
  for sig in (signal.SIGTERM,signal.SIGKILL):
   try:os.killpg(p.pid,sig)
   except ProcessLookupError:break
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:continue
  code=p.wait(timeout=5)
  try:os.killpg(p.pid,0);gone=False
  except ProcessLookupError:gone=True
 result=dict(code=code,timeout=timeout,capacity=capacity,leader_reaped=True,group_gone=gone,seconds=time.monotonic()-start)
 write(name+'-terminal.json',result);print(name,json.dumps(result),flush=True)
 assert code==0 and not timeout and not capacity and gone
try:
 run('compile',argv,120)
 run('run',[str(report/'consumer')],60)
finally:
 write('input-verification-after.json',verify_inputs())
 for p in providers:assert digest(root/p)==products[p]['sha256'],p
 write('products.json',{p.name:{'sha256':digest(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777} for p in report.iterdir() if p.is_file()})
