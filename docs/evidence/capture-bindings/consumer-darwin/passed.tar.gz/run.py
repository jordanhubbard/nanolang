from pathlib import Path
import subprocess,hashlib,json,tarfile,os,signal,time,shutil
base=Path(__file__).resolve().parent;root=base/'source';reports=base/'reports'
assert shutil.disk_usage(base).free>=2*1024**3
root.mkdir();reports.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def dump(n,x):(reports/n).write_text(json.dumps(x,indent=2)+'\n')
with tarfile.open(base/'source.tar.gz') as t:t.extractall(root,filter='data')
paths=json.loads((base/'paths.json').read_text())
def inputs():return {p:{'sha256':sha(root/p),'bytes':(root/p).stat().st_size} for p in paths}
clang=subprocess.check_output(['/usr/bin/xcrun','--find','clang'],text=True).strip()
ld=subprocess.check_output(['/usr/bin/xcrun','--find','ld'],text=True).strip()
sdk=subprocess.check_output(['/usr/bin/xcrun','--show-sdk-path'],text=True).strip()
tools=[clang,ld,'/usr/bin/make','/usr/bin/python3','/opt/homebrew/bin/python3.14','/opt/homebrew/opt/llvm/bin/clang','/opt/homebrew/opt/llvm/bin/opt']
def toolmap():return {p:{'realpath':str(Path(p).resolve()),'sha256':sha(Path(p).resolve())} for p in tools}
before=inputs();selected=toolmap();dump('inputs-before.json',before);dump('tools-before.json',selected)
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['SDKROOT']=sdk
cmd=['/usr/bin/make','-f','Makefile.gnu','-j2','CC='+clang,'NMS_RUNTIME_CLANG=/opt/homebrew/opt/llvm/bin/clang -isysroot '+sdk,'NMS_RUNTIME_OPT=/opt/homebrew/opt/llvm/bin/opt','test-capture-transport-consumers']
dump('source.json',{'revision':'5d8ca9be9','archive_sha256':sha(base/'source.tar.gz'),'files':len(paths)})
dump('command.json',{'argv':cmd,'cwd':str(root),'SDKROOT':sdk,'PATH':env['PATH'],'timeout_seconds':600})
start=time.monotonic();status={'timeout':False,'cleanup_errors':[]}
with (reports/'stdout.log').open('wb') as out,(reports/'stderr.log').open('wb') as err:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
 try:rc=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  status['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait(timeout=10)
status.update(returncode=rc,seconds=time.monotonic()-start,leader_reaped=p.poll() is not None)
try:os.killpg(p.pid,0);status['group_gone']=False
except ProcessLookupError:status['group_gone']=True
if not status['group_gone']:os.killpg(p.pid,signal.SIGKILL);status['cleanup_errors'].append('Residual group required termination')
after=inputs();finaltools=toolmap();dump('terminal.json',status);dump('inputs-after.json',after);dump('tools-after.json',finaltools)
products={str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777} for p in root.glob('obj/**/*') if p.is_file()}
dump('products.json',products);dump('checks.json',{'terminal':status,'source_unchanged':before==after,'tools_unchanged':selected==finaltools,'products':len(products)})
print(json.dumps(status),flush=True)
raise SystemExit(rc or (before!=after) or (selected!=finaltools))
