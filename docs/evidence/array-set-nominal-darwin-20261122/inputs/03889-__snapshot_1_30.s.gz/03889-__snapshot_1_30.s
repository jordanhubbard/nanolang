	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_verify_function_types ; -- Begin function nvm_verify_function_types
	.globl	_nvm_verify_function_types
	.p2align	2
_nvm_verify_function_types:             ; @nvm_verify_function_types
	.cfi_startproc
; %bb.0:
	mov	x6, #0                          ; =0x0
	b	_verify_types_checked
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_types_checked
_verify_types_checked:                  ; @verify_types_checked
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x11, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	sub	w8, w3, #257
	ubfx	w8, w8, #8, #8
	cmp	w8, #255
	b.lo	LBB1_15
; %bb.1:
	mov	x28, x2
	ldr	w12, [x2, #8]
	cbz	w12, LBB1_15
; %bb.2:
	mov	x23, x1
	add	w20, w12, #1
	mov	w13, w3
	add	x8, x13, #8
	umull	x27, w8, w20
	cbz	x6, LBB1_12
; %bb.3:
	ldrb	w8, [x6, #24]
	tbnz	w8, #0, LBB1_137
; %bb.4:
	ldrb	w8, [x6, #25]
	tbnz	w8, #0, LBB1_137
; %bb.5:
	ldr	x8, [x6]
	mov	w9, #67108864                   ; =0x4000000
	cmp	x8, x9
	b.hi	LBB1_136
; %bb.6:
	sub	x9, x9, x8
	cmp	x27, x9
	b.hi	LBB1_136
; %bb.7:
	ldr	x9, [x6, #8]
	add	x8, x8, x27
	cmp	x9, x8
	str	x8, [x6]
	b.hs	LBB1_9
; %bb.8:
	str	x8, [x6, #8]
LBB1_9:
	ldr	x8, [x6, #16]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB1_136
; %bb.10:
	add	w10, w3, #4
	and	x10, x10, #0xffff
	umull	x10, w20, w10
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB1_136
; %bb.11:
	add	x8, x8, x10
	str	x8, [x6, #16]
LBB1_12:
	str	x6, [sp, #216]                  ; 8-byte Folded Spill
	str	w12, [sp, #188]                 ; 4-byte Folded Spill
	str	x11, [sp, #160]                 ; 8-byte Folded Spill
	str	x0, [sp, #136]                  ; 8-byte Folded Spill
	str	w3, [sp, #156]                  ; 4-byte Folded Spill
	stp	x5, x4, [sp, #88]               ; 16-byte Folded Spill
	umull	x25, w20, w13
	mov	x0, x25
	str	x13, [sp, #232]                 ; 8-byte Folded Spill
	bl	_malloc
	mov	x22, x0
	lsl	x21, x20, #1
	mov	x0, x21
	bl	_malloc
	mov	x26, x0
	mov	x0, x20
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x24, x0
	mov	x0, x20
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x19, x0
	str	x20, [sp, #200]                 ; 8-byte Folded Spill
	lsl	x0, x20, #2
	bl	_malloc
	mov	x8, x22
	mov	x22, x0
	cmp	x8, #0
	ccmp	x26, #0, #4, ne
	ccmp	x24, #0, #4, ne
	ccmp	x19, #0, #4, ne
	ccmp	x0, #0, #4, ne
	b.ne	LBB1_16
; %bb.13:
	mov	x0, x8
	bl	_free
	mov	x0, x26
	bl	_free
	mov	x0, x24
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x0, x22
	bl	_free
	mov	w8, #1                          ; =0x1
	ldr	x10, [sp, #216]                 ; 8-byte Folded Reload
	cbz	x10, LBB1_138
; %bb.14:
	ldr	x9, [x10]
	sub	x9, x9, x27
	str	x9, [x10]
	strb	w8, [x10, #25]
Lloh3:
	adrp	x8, l_.str.1@PAGE+1
Lloh4:
	add	x8, x8, l_.str.1@PAGEOFF+1
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #256]
	ldur	q0, [x8, #30]
	add	x8, sp, #31
	stur	q0, [x8, #255]
	mov	w9, #73                         ; =0x49
	mov	w8, #0                          ; =0x0
	b	LBB1_139
LBB1_15:
	mov	w8, #1                          ; =0x1
	strh	w8, [x11]
	b	LBB1_152
LBB1_16:
	str	x27, [sp, #56]                  ; 8-byte Folded Spill
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	mov	x0, x8
	mov	w1, #255                        ; =0xff
	mov	x2, x25
	bl	_memset
	mov	x0, x26
	mov	x1, x21
	bl	_bzero
	mov	w10, #0                         ; =0x0
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	mov	w11, #1                         ; =0x1
	strh	w11, [x8], #1
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	lsl	x8, x2, #2
	stp	x22, x24, [sp, #120]            ; 16-byte Folded Spill
	strb	w11, [x24]
	add	x9, x8, #32
	str	x9, [sp, #168]                  ; 8-byte Folded Spill
	mov	w9, #16777184                   ; =0xffffe0
	strb	w11, [x19]
	sub	x8, x9, x8
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	str	wzr, [x22]
	str	x23, [sp, #48]                  ; 8-byte Folded Spill
	mov	w8, w23
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w27, #1                         ; =0x1
	mov	x25, x26
	mov	x21, x19
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	stp	x28, x25, [sp, #104]            ; 16-byte Folded Spill
	str	x21, [sp, #144]                 ; 8-byte Folded Spill
	b	LBB1_21
LBB1_17:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
LBB1_18:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
LBB1_19:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	w10, [sp, #212]                 ; 4-byte Folded Reload
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
LBB1_20:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x27, x11
	cbz	w11, LBB1_146
LBB1_21:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_52 Depth 2
                                        ;     Child Loop BB1_80 Depth 2
                                        ;     Child Loop BB1_83 Depth 2
                                        ;     Child Loop BB1_108 Depth 2
                                        ;     Child Loop BB1_113 Depth 2
                                        ;     Child Loop BB1_122 Depth 2
                                        ;     Child Loop BB1_128 Depth 2
	cbz	x26, LBB1_26
; %bb.22:                               ;   in Loop: Header=BB1_21 Depth=1
	ldrb	w8, [x26, #24]
	tbnz	w8, #0, LBB1_143
; %bb.23:                               ;   in Loop: Header=BB1_21 Depth=1
	ldrb	w8, [x26, #25]
	tbnz	w8, #0, LBB1_143
; %bb.24:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	x8, [x26, #16]
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	cmp	x8, x9
	b.hi	LBB1_142
; %bb.25:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	add	x8, x8, x9
	str	x8, [x26, #16]
LBB1_26:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	w24, [x22, w10, uxtw #2]
	add	w8, w10, #1
	udiv	w9, w8, w20
	msub	w10, w9, w20, w8
	sub	w11, w27, #1
	strb	wzr, [x21, x24]
	cmp	w24, w19
	b.hs	LBB1_20
; %bb.27:                               ;   in Loop: Header=BB1_21 Depth=1
	str	w11, [sp, #228]                 ; 4-byte Folded Spill
	str	w10, [sp, #212]                 ; 4-byte Folded Spill
	ldr	x8, [x28]
	mov	w9, #104                        ; =0x68
	umaddl	x23, w24, w9, x8
	ldrb	w0, [x23, #40]
	bl	_isa_get_info
	cbz	x0, LBB1_19
; %bb.28:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	x14, x0
	mov	w22, #0                         ; =0x0
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	umaddl	x1, w24, w2, x8
	ldrh	w25, [x25, x24, lsl #1]
	ldrb	w9, [x23, #40]
	str	wzr, [sp, #240]
	mov	w19, #255                       ; =0xff
	strh	w19, [sp, #244]
	sub	w10, w9, #1
	cmp	w10, #253
	b.hi	LBB1_135
; %bb.29:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
Lloh5:
	adrp	x13, lJTI1_0@PAGE
Lloh6:
	add	x13, x13, lJTI1_0@PAGEOFF
	adr	x11, LBB1_30
	ldrh	w12, [x13, x10, lsl #1]
	add	x11, x11, x12, lsl #2
	mov	x26, x22
	mov	x28, x22
	br	x11
LBB1_30:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #257                        ; =0x101
	strh	w8, [sp, #240]
	mov	w8, #258                        ; =0x102
	sturh	w8, [sp, #243]
	mov	w22, #1                         ; =0x1
	strb	w22, [sp, #245]
	mov	w8, #2                          ; =0x2
	b	LBB1_38
LBB1_31:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB1_69
LBB1_32:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #257                        ; =0x101
	b	LBB1_48
LBB1_33:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB1_69
LBB1_34:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #771                        ; =0x303
	b	LBB1_48
LBB1_35:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB1_69
LBB1_36:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #240]
	mov	w9, #257                        ; =0x101
	sturh	w9, [sp, #243]
LBB1_37:                                ;   in Loop: Header=BB1_21 Depth=1
	strb	w8, [sp, #245]
	mov	w22, #1                         ; =0x1
LBB1_38:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w19, #1                         ; =0x1
	b	LBB1_50
LBB1_39:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w22, #0                         ; =0x0
	mov	w8, #257                        ; =0x101
	strh	w8, [sp, #240]
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #243]
	b	LBB1_50
LBB1_40:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x10, #0                         ; =0x0
	and	w8, w9, #0xfe
	cmp	w8, #240
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, eq
	strb	w8, [sp, #243]
LBB1_41:                                ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, sp, #240
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, x10]
	add	x10, x10, #1
	ldrb	w8, [sp, #243]
	cmp	x10, x8
	b.lo	LBB1_41
; %bb.42:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w9, #513                        ; =0x201
	strh	w9, [sp, #244]
	mov	w19, #1                         ; =0x1
	mov	w22, #2                         ; =0x2
	cbnz	w8, LBB1_50
; %bb.43:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w26, #0                         ; =0x0
	b	LBB1_70
LBB1_44:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #771                        ; =0x303
	strh	w8, [sp, #240]
	mov	w8, #770                        ; =0x302
	sturh	w8, [sp, #243]
	mov	w22, #1                         ; =0x1
	strb	w22, [sp, #245]
	mov	w19, #3                         ; =0x3
	b	LBB1_49
LBB1_45:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #3                          ; =0x3
	b	LBB1_69
LBB1_46:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB1_69
LBB1_47:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1028                       ; =0x404
LBB1_48:                                ;   in Loop: Header=BB1_21 Depth=1
	strh	w8, [sp, #240]
	mov	w8, #1026                       ; =0x402
	sturh	w8, [sp, #243]
	mov	w22, #1                         ; =0x1
	strb	w22, [sp, #245]
	mov	w19, #4                         ; =0x4
LBB1_49:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #2                          ; =0x2
LBB1_50:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x9, #0                          ; =0x0
	sub	w10, w25, w8
	sub	w11, w8, #1
	mov	w26, w8
	b	LBB1_52
LBB1_51:                                ;   in Loop: Header=BB1_52 Depth=2
	add	x9, x9, #1
	sub	w11, w11, #1
	add	w10, w10, #1
	cmp	x26, x9
	b.eq	LBB1_70
LBB1_52:                                ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w11, w25
	b.hs	LBB1_70
; %bb.53:                               ;   in Loop: Header=BB1_52 Depth=2
	ldrb	w21, [x1, w10, uxtw]
	cmp	w21, #255
	b.eq	LBB1_51
; %bb.54:                               ;   in Loop: Header=BB1_52 Depth=2
	add	x8, sp, #240
	ldrb	w0, [x8, x9]
	cmp	w0, #255
	b.eq	LBB1_51
; %bb.55:                               ;   in Loop: Header=BB1_52 Depth=2
	ldrb	w8, [x23, #40]
	cmp	w21, #2
	mov	w12, #143                       ; =0x8f
	ccmp	w8, w12, #0, eq
	cset	w12, eq
	cmp	w21, w0
	b.eq	LBB1_51
; %bb.56:                               ;   in Loop: Header=BB1_52 Depth=2
	tbnz	w12, #0, LBB1_51
	b	LBB1_140
LBB1_57:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #10                         ; =0xa
	b	LBB1_69
LBB1_58:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB1_69
LBB1_59:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #3                          ; =0x3
	strb	w8, [sp, #240]
	mov	w8, #257                        ; =0x101
	sturh	w8, [sp, #243]
	mov	w8, #1                          ; =0x1
	b	LBB1_37
LBB1_60:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #12                         ; =0xc
	b	LBB1_69
LBB1_61:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #0                          ; =0x0
	b	LBB1_69
LBB1_62:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #13                         ; =0xd
	b	LBB1_69
LBB1_63:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #240]
	mov	w9, #513                        ; =0x201
	sturh	w9, [sp, #243]
	strb	w8, [sp, #245]
	mov	w19, #2                         ; =0x2
	mov	w22, #1                         ; =0x1
	b	LBB1_50
LBB1_64:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #15                         ; =0xf
	b	LBB1_69
LBB1_65:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #11                         ; =0xb
	b	LBB1_69
LBB1_66:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w19, #3                         ; =0x3
	strb	w19, [sp, #240]
	mov	w8, #769                        ; =0x301
	b	LBB1_134
LBB1_67:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #240]
	mov	w9, #769                        ; =0x301
	sturh	w9, [sp, #243]
	strb	w8, [sp, #245]
	mov	w19, #3                         ; =0x3
	mov	w22, #1                         ; =0x1
	b	LBB1_50
LBB1_68:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #14                         ; =0xe
LBB1_69:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w26, #0                         ; =0x0
	strb	w8, [sp, #244]
	mov	w22, #1                         ; =0x1
	strb	w22, [sp, #245]
	mov	x19, x8
LBB1_70:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	w28, #1                         ; =0x1
LBB1_71:                                ;   in Loop: Header=BB1_21 Depth=1
	add	x0, sp, #256
	mov	w3, #256                        ; =0x100
	mov	x20, x14
	bl	___memcpy_chk
	ldrb	w8, [x20, #28]
	sxtb	w8, w8
	cmp	w26, #0
	csel	w9, wzr, w28, eq
	cmp	w8, #0
	cset	w10, lt
	tst	w9, w10
	csel	w8, w26, w8, ne
	tbnz	w8, #31, LBB1_77
; %bb.72:                               ;   in Loop: Header=BB1_21 Depth=1
	ldrsb	w21, [x20, #29]
	tbnz	w21, #31, LBB1_77
; %bb.73:                               ;   in Loop: Header=BB1_21 Depth=1
	sub	w9, w25, w8
	cmp	w8, w25
	csel	w17, wzr, w9, hi
	ldr	w16, [sp, #156]                 ; 4-byte Folded Reload
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	cbz	w21, LBB1_78
; %bb.74:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	w16, w17, uxth
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	b.ls	LBB1_86
; %bb.75:                               ;   in Loop: Header=BB1_21 Depth=1
	and	w8, w22, #0xff
	cmp	w8, w21, uxtb
	cset	w8, eq
	tst	w28, w8
	csinv	w1, w19, wzr, ne
	and	x25, x17, #0xffff
	mvn	w8, w17
	mov	x26, x16
	add	w8, w16, w8
	and	x8, x8, #0xffff
	sub	w22, w21, #1
	cmp	x8, x22
	csel	x8, x8, x22, lo
	add	x9, sp, #256
	add	x0, x9, x25
	add	x2, x8, #1
	bl	_memset
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	mvn	x8, x25
	add	x8, x8, x2
	cmp	x8, x22
	csel	x8, x8, x22, lo
	cmp	x8, #3
	b.hs	LBB1_79
; %bb.76:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #0                          ; =0x0
	mov	x16, x26
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	b	LBB1_82
LBB1_77:                                ;   in Loop: Header=BB1_21 Depth=1
	add	x0, sp, #256
	mov	w1, #255                        ; =0xff
	ldr	x20, [sp, #232]                 ; 8-byte Folded Reload
	mov	x2, x20
	mov	w3, #256                        ; =0x100
	bl	___memset_chk
	mov	x2, x20
	mov	w17, #0                         ; =0x0
	ldr	w16, [sp, #156]                 ; 4-byte Folded Reload
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	b	LBB1_86
LBB1_78:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	b	LBB1_86
LBB1_79:                                ;   in Loop: Header=BB1_21 Depth=1
	add	x9, x8, #1
	and	x8, x9, #0x1fffffffc
	add	x25, x8, x25
	mov	x10, x8
LBB1_80:                                ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	subs	x10, x10, #4
	b.ne	LBB1_80
; %bb.81:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	x9, x8
	mov	x16, x26
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	b.eq	LBB1_85
LBB1_82:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x9, x25
	add	w10, w8, #1
	add	x11, x25, #1
	cmp	x11, x2
	csinc	x12, x2, x25, ls
	mvn	x13, x25
	add	x12, x13, x12
	cmp	w10, w21
	csinc	w13, w21, w8, le
	mvn	w8, w8
	add	w8, w8, w13
	cmp	x12, x8
	csel	x8, x12, x8, lo
	add	x25, x11, x8
LBB1_83:                                ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w10, w21
	b.ge	LBB1_85
; %bb.84:                               ;   in Loop: Header=BB1_83 Depth=2
	add	x9, x9, #1
	add	w10, w10, #1
	cmp	x9, x2
	b.lo	LBB1_83
LBB1_85:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x17, x25
LBB1_86:                                ;   in Loop: Header=BB1_21 Depth=1
	ldrb	w25, [x23, #40]
	sub	w8, w25, #56
	cmp	w8, #3
	b.lo	LBB1_89
; %bb.87:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	w25, #165
	b.eq	LBB1_89
; %bb.88:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	w25, #107
	b.ne	LBB1_94
LBB1_89:                                ;   in Loop: Header=BB1_21 Depth=1
	ldp	x8, x21, [sp, #136]             ; 16-byte Folded Reload
	ldr	x8, [x8, #256]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldr	w8, [x8, #8]
	ldr	w9, [x23, #8]
	subs	w1, w9, w8
	ldr	x28, [sp, #104]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #120]                 ; 8-byte Folded Reload
	b.lo	LBB1_91
; %bb.90:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	w8, [x28, #12]
	cmp	w1, w8
	b.ne	LBB1_92
LBB1_91:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w23, #1                         ; =0x1
	b	LBB1_97
LBB1_92:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x19, x17
	mov	x0, x28
	bl	_vm_decoded_function_at
	cbz	x0, LBB1_95
; %bb.93:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w23, #0                         ; =0x0
	ldr	x8, [x28]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w8, w8, w9
	str	w8, [sp, #248]
	mov	w8, #1                          ; =0x1
	b	LBB1_96
LBB1_94:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w23, #1                         ; =0x1
	ldr	x28, [sp, #104]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #120]                 ; 8-byte Folded Reload
	ldr	x21, [sp, #144]                 ; 8-byte Folded Reload
	b	LBB1_97
LBB1_95:                                ;   in Loop: Header=BB1_21 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w23, #1                         ; =0x1
LBB1_96:                                ;   in Loop: Header=BB1_21 Depth=1
	ldr	w16, [sp, #156]                 ; 4-byte Folded Reload
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	mov	w3, #255                        ; =0xff
	mov	x17, x19
LBB1_97:                                ;   in Loop: Header=BB1_21 Depth=1
	cmp	w25, #61
	b.hi	LBB1_99
; %bb.98:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w9, #1                          ; =0x1
	lsl	x9, x9, x25
	mov	x10, #2380152403065307136       ; =0x2108000000000000
	tst	x9, x10
	b.ne	LBB1_103
LBB1_99:                                ;   in Loop: Header=BB1_21 Depth=1
	cmp	w25, #163
	b.eq	LBB1_103
; %bb.100:                              ;   in Loop: Header=BB1_21 Depth=1
	cmp	w25, #168
	b.eq	LBB1_103
; %bb.101:                              ;   in Loop: Header=BB1_21 Depth=1
	add	w9, w24, #1
	ldr	w10, [sp, #188]                 ; 4-byte Folded Reload
	cmp	w9, w10
	b.hs	LBB1_103
; %bb.102:                              ;   in Loop: Header=BB1_21 Depth=1
	add	x10, sp, #248
	str	w9, [x10, x8, lsl #2]
	b	LBB1_105
LBB1_103:                               ;   in Loop: Header=BB1_21 Depth=1
	cbnz	w23, LBB1_17
; %bb.104:                              ;   in Loop: Header=BB1_21 Depth=1
	mov	w23, #1                         ; =0x1
LBB1_105:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	ldr	w24, [sp, #248]
	cmp	w25, #165
	csel	w21, wzr, w17, eq
	umaddl	x0, w2, w24, x8
	ldr	x26, [sp, #128]                 ; 8-byte Folded Reload
	ldrb	w8, [x26, w24, uxtw]
	str	x17, [sp, #64]                  ; 8-byte Folded Spill
	tbz	w8, #0, LBB1_109
; %bb.106:                              ;   in Loop: Header=BB1_21 Depth=1
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
	ldrh	w10, [x25, w24, uxtw #1]
	and	w8, w21, #0xffff
	cmp	w10, w8
	csel	w9, w10, w8, lo
	cbz	w9, LBB1_110
; %bb.107:                              ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #0                          ; =0x0
	add	x11, sp, #256
	mov	x12, x9
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
LBB1_108:                               ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w13, [x0]
	cmp	w13, #255
	cset	w14, ne
	ldrb	w15, [x11], #1
	cmp	w13, w15
	csel	w14, wzr, w14, eq
	csel	w13, w3, w13, ne
	strb	w13, [x0], #1
	orr	w8, w14, w8
	subs	x12, x12, #1
	b.ne	LBB1_108
	b	LBB1_111
LBB1_109:                               ;   in Loop: Header=BB1_21 Depth=1
	add	x1, sp, #256
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	bl	_memcpy
	mov	w3, #255                        ; =0xff
	ldr	x2, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
	strh	w21, [x25, w24, uxtw #1]
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, w24, uxtw]
	ldr	x21, [sp, #144]                 ; 8-byte Folded Reload
	ldrb	w8, [x21, w24, uxtw]
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	tbz	w8, #0, LBB1_117
	b	LBB1_118
LBB1_110:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	x20, [sp, #200]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
LBB1_111:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	w10, w16
	csel	w10, w10, w16, lo
	cmp	w10, w21, uxth
	b.ls	LBB1_114
; %bb.112:                              ;   in Loop: Header=BB1_21 Depth=1
	umull	x11, w2, w24
	and	x12, x21, #0xffff
	add	w10, w10, w21
	sub	w10, w10, w9
	ldr	x9, [sp, #192]                  ; 8-byte Folded Reload
	add	x9, x9, x11
	add	x9, x9, x12
	add	x11, x12, #1
	and	w10, w10, #0xffff
	ldr	x21, [sp, #144]                 ; 8-byte Folded Reload
LBB1_113:                               ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w12, [x9]
	cmp	w12, #255
	cset	w12, ne
	strb	w3, [x9], #1
	orr	w8, w12, w8
	cmp	w10, w11, uxth
	add	x11, x11, #1
	b.ne	LBB1_113
	b	LBB1_115
LBB1_114:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	x21, [sp, #144]                 ; 8-byte Folded Reload
LBB1_115:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB1_118
; %bb.116:                              ;   in Loop: Header=BB1_21 Depth=1
	ldrb	w8, [x21, w24, uxtw]
	tbnz	w8, #0, LBB1_118
LBB1_117:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, w24, uxtw]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #228]                  ; 4-byte Folded Reload
	add	w8, w9, w8
	udiv	w9, w8, w20
	msub	w8, w9, w20, w8
	str	w24, [x22, w8, uxtw #2]
	str	w27, [sp, #228]                 ; 4-byte Folded Spill
LBB1_118:                               ;   in Loop: Header=BB1_21 Depth=1
	tbnz	w23, #0, LBB1_19
; %bb.119:                              ;   in Loop: Header=BB1_21 Depth=1
	ldr	w23, [sp, #252]
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	umaddl	x0, w2, w23, x8
	ldr	x19, [sp, #128]                 ; 8-byte Folded Reload
	ldrb	w8, [x19, w23, uxtw]
	tbz	w8, #0, LBB1_123
; %bb.120:                              ;   in Loop: Header=BB1_21 Depth=1
	ldrh	w10, [x25, w23, uxtw #1]
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	and	w8, w1, #0xffff
	cmp	w10, w8
	csel	w9, w10, w8, lo
	ldr	w17, [sp, #156]                 ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	cbz	w9, LBB1_125
; %bb.121:                              ;   in Loop: Header=BB1_21 Depth=1
	add	x11, sp, #256
	mov	x12, x0
	mov	x13, x9
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
LBB1_122:                               ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w14, [x12]
	cmp	w14, #255
	cset	w15, ne
	ldrb	w16, [x11], #1
	cmp	w14, w16
	csel	w15, wzr, w15, eq
	csel	w14, w3, w14, ne
	strb	w14, [x12], #1
	orr	w8, w15, w8
	subs	x13, x13, #1
	b.ne	LBB1_122
	b	LBB1_126
LBB1_123:                               ;   in Loop: Header=BB1_21 Depth=1
	add	x1, sp, #256
	bl	_memcpy
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	strh	w8, [x25, w23, uxtw #1]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, w23, uxtw]
	ldrb	w8, [x21, w23, uxtw]
	tbnz	w8, #0, LBB1_18
; %bb.124:                              ;   in Loop: Header=BB1_21 Depth=1
	strb	w9, [x21, w23, uxtw]
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
	ldr	w10, [sp, #212]                 ; 4-byte Folded Reload
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	b	LBB1_132
LBB1_125:                               ;   in Loop: Header=BB1_21 Depth=1
	ldr	w19, [sp, #188]                 ; 4-byte Folded Reload
LBB1_126:                               ;   in Loop: Header=BB1_21 Depth=1
	cmp	w10, w17
	csel	w11, w10, w17, lo
	cmp	w11, w1, uxth
	b.ls	LBB1_129
; %bb.127:                              ;   in Loop: Header=BB1_21 Depth=1
	mov	x10, x1
	and	x10, x10, #0xffff
	add	w11, w11, w1
	sub	w9, w11, w9
	and	w9, w9, #0xffff
LBB1_128:                               ;   Parent Loop BB1_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x0, x10]
	cmp	w11, #255
	cset	w11, ne
	strb	w3, [x0, x10]
	orr	w8, w11, w8
	add	x10, x10, #1
	cmp	w9, w10, uxth
	b.ne	LBB1_128
LBB1_129:                               ;   in Loop: Header=BB1_21 Depth=1
	tbz	w8, #0, LBB1_19
; %bb.130:                              ;   in Loop: Header=BB1_21 Depth=1
	ldrb	w8, [x21, w23, uxtw]
	ldr	w10, [sp, #212]                 ; 4-byte Folded Reload
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB1_20
; %bb.131:                              ;   in Loop: Header=BB1_21 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, w23, uxtw]
LBB1_132:                               ;   in Loop: Header=BB1_21 Depth=1
	add	w8, w11, w10
	udiv	w9, w8, w20
	msub	w8, w9, w20, w8
	str	w23, [x22, w8, uxtw #2]
	add	w11, w11, #1
	b	LBB1_20
LBB1_133:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	w19, #4                         ; =0x4
	strb	w19, [sp, #240]
	mov	w8, #1025                       ; =0x401
LBB1_134:                               ;   in Loop: Header=BB1_21 Depth=1
	sturh	w8, [sp, #243]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #245]
	mov	w22, #1                         ; =0x1
	b	LBB1_50
LBB1_135:                               ;   in Loop: Header=BB1_21 Depth=1
	mov	x26, x22
	mov	x28, x22
	b	LBB1_71
LBB1_136:
	mov	w8, #1                          ; =0x1
	strb	w8, [x6, #24]
LBB1_137:
	mov	w8, #18688                      ; =0x4900
	strh	w8, [x11]
Lloh7:
	adrp	x8, l_.str@PAGE+1
Lloh8:
	add	x8, x8, l_.str@PAGEOFF+1
	ldp	q0, q1, [x8]
	stur	q0, [x11, #2]
	stur	q1, [x11, #18]
	ldur	x8, [x8, #31]
	stur	x8, [x11, #33]
	b	LBB1_152
LBB1_138:
	mov	w9, #0                          ; =0x0
LBB1_139:
	ldr	x10, [sp, #160]                 ; 8-byte Folded Reload
	ldp	q0, q1, [sp, #448]
	stur	q0, [x10, #194]
	stur	q1, [x10, #210]
	ldr	q0, [sp, #480]
	stur	q0, [x10, #226]
	add	x11, sp, #240
	ldur	q0, [x11, #255]
	stur	q0, [x10, #241]
	ldp	q0, q1, [sp, #384]
	stur	q0, [x10, #130]
	stur	q1, [x10, #146]
	ldp	q0, q1, [sp, #416]
	stur	q0, [x10, #162]
	stur	q1, [x10, #178]
	ldp	q0, q1, [sp, #320]
	stur	q0, [x10, #66]
	stur	q1, [x10, #82]
	ldp	q0, q1, [sp, #352]
	stur	q0, [x10, #98]
	stur	q1, [x10, #114]
	ldp	q0, q1, [sp, #256]
	stur	q0, [x10, #2]
	stur	q1, [x10, #18]
	ldp	q0, q1, [sp, #288]
	stur	q0, [x10, #34]
	strb	w8, [x10]
	strb	w9, [x10, #1]
	stur	q1, [x10, #50]
	b	LBB1_152
LBB1_140:
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	strb	wzr, [x9]
	ldr	x24, [x14]
	ldr	w23, [x23]
	cmp	w8, #143
	b.ne	LBB1_144
; %bb.141:
Lloh9:
	adrp	x22, l_.str.4@PAGE
Lloh10:
	add	x22, x22, l_.str.4@PAGEOFF
	b	LBB1_145
LBB1_142:
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, #24]
LBB1_143:
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	strb	wzr, [x8]
Lloh11:
	adrp	x8, l_.str.2@PAGE
Lloh12:
	add	x8, x8, l_.str.2@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	q0, q1, [x9]
	ldur	q0, [x8, #28]
	stur	q0, [x9, #28]
	b	LBB1_147
LBB1_144:
	bl	_isa_tag_name
	mov	x22, x0
LBB1_145:
	ldr	x25, [sp, #48]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
	mov	x0, x21
	bl	_isa_tag_name
	stp	x22, x0, [sp, #24]
	stp	x24, x23, [sp, #8]
	str	x25, [sp]
Lloh13:
	adrp	x2, l_.str.3@PAGE
Lloh14:
	add	x2, x2, l_.str.3@PAGEOFF
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	mov	w1, #256                        ; =0x100
	bl	_snprintf
	ldp	x25, x22, [sp, #112]            ; 16-byte Folded Reload
	ldr	x21, [sp, #144]                 ; 8-byte Folded Reload
LBB1_146:
	cbz	x26, LBB1_148
LBB1_147:
	ldr	x8, [x26]
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	sub	x8, x8, x9
	str	x8, [x26]
LBB1_148:
	ldr	x0, [sp, #192]                  ; 8-byte Folded Reload
	bl	_free
	mov	x0, x25
	bl	_free
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	bl	_free
	mov	x0, x21
	bl	_free
	mov	x0, x22
	bl	_free
	ldp	x1, x0, [sp, #88]               ; 16-byte Folded Reload
	cbz	x1, LBB1_152
; %bb.149:
	cbz	x0, LBB1_152
; %bb.150:
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB1_152
; %bb.151:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp]
Lloh15:
	adrp	x2, l_.str.5@PAGE
Lloh16:
	add	x2, x2, l_.str.5@PAGEOFF
	bl	_snprintf
LBB1_152:
	ldur	x8, [x29, #-96]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_154
; %bb.153:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_154:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh3, Lloh4
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpAdd	Lloh7, Lloh8
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpAdd	Lloh11, Lloh12
	.loh AdrpAdd	Lloh13, Lloh14
	.loh AdrpAdd	Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI1_0:
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_45-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_61-LBB1_30)>>2
	.short	(LBB1_58-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_46-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_46-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_57-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_60-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_62-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_35-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
	.short	(LBB1_45-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_31-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_67-LBB1_30)>>2
	.short	(LBB1_59-LBB1_30)>>2
	.short	(LBB1_63-LBB1_30)>>2
	.short	(LBB1_64-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_68-LBB1_30)>>2
	.short	(LBB1_33-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_39-LBB1_30)>>2
	.short	(LBB1_39-LBB1_30)>>2
	.short	(LBB1_39-LBB1_30)>>2
	.short	(LBB1_39-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_44-LBB1_30)>>2
	.short	(LBB1_44-LBB1_30)>>2
	.short	(LBB1_44-LBB1_30)>>2
	.short	(LBB1_44-LBB1_30)>>2
	.short	(LBB1_66-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_34-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_47-LBB1_30)>>2
	.short	(LBB1_47-LBB1_30)>>2
	.short	(LBB1_133-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_32-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_36-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_30-LBB1_30)>>2
	.short	(LBB1_40-LBB1_30)>>2
	.short	(LBB1_40-LBB1_30)>>2
	.short	(LBB1_40-LBB1_30)>>2
	.short	(LBB1_40-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_65-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_71-LBB1_30)>>2
	.short	(LBB1_69-LBB1_30)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_verify_function_types_record_array ; -- Begin function nvm_verify_function_types_record_array
	.globl	_nvm_verify_function_types_record_array
	.p2align	2
_nvm_verify_function_types_record_array: ; @nvm_verify_function_types_record_array
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	b	_verify_types_checked
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I reached my private type-check budget."

l_.str.1:                               ; @.str.1
	.asciz	"I could not allocate private type-check state."

l_.str.2:                               ; @.str.2
	.asciz	"I reached my private type-check work bound."

l_.str.3:                               ; @.str.3
	.asciz	"function[%u] %s at offset %u expects %s but the operand is %s"

l_.str.4:                               ; @.str.4
	.asciz	"int or u8"

l_.str.5:                               ; @.str.5
	.asciz	"%s"

.subsections_via_symbols
