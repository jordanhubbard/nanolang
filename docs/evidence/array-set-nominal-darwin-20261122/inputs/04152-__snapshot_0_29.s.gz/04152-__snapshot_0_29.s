	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_module_free             ; -- Begin function nvm_v2_module_free
	.p2align	2
_nvm_v2_module_free:                    ; @nvm_v2_module_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	b	LBB0_3
LBB0_2:
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	bl	_nvm_v2_metadata_free
	ldr	x8, [sp, #8]
	add	x0, x8, #24
	bl	_nvm_v2_constants_free
	ldr	x8, [sp, #8]
	add	x0, x8, #40
	bl	_nvm_v2_signatures_free
	ldr	x8, [sp, #8]
	add	x0, x8, #56
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	add	x0, x8, #72
	bl	_nvm_v2_functions_free
	ldr	x8, [sp, #8]
	add	x0, x8, #88
	bl	_nvm_v2_globals_free
	ldr	x8, [sp, #8]
	add	x0, x8, #104
	bl	_nvm_v2_imports_free
	ldr	x8, [sp, #8]
	add	x0, x8, #120
	bl	_nvm_v2_callbacks_free
	ldr	x8, [sp, #8]
	add	x0, x8, #136
	bl	_nvm_v2_links_free
	ldr	x8, [sp, #8]
	add	x0, x8, #152
	bl	_nvm_v2_debug_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #232]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #232]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #168]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #176]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #216]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #224]
	ldr	x8, [sp, #8]
	str	xzr, [x8, #200]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #208]
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #228]
	b	LBB0_3
LBB0_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_private_serialize          ; -- Begin function nvm_private_serialize
	.p2align	2
_nvm_private_serialize:                 ; @nvm_private_serialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	str	x3, [sp, #40]
	str	x4, [sp, #32]
	ldur	x0, [x29, #-16]
	bl	_nvm_record_map_wire_selected
	tbz	w0, #0, LBB1_19
	b	LBB1_1
LBB1_1:
	add	x3, sp, #24
	mov	x2, #0                          ; =0x0
	str	xzr, [sp, #24]
	ldur	x0, [x29, #-16]
	ldr	x4, [sp, #32]
	mov	x1, #0                          ; =0x0
	bl	_nvm_serialize_core
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB1_3
	b	LBB1_2
LBB1_2:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB1_20
LBB1_3:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB1_7
	b	LBB1_4
LBB1_4:
	ldr	x8, [sp, #40]
	cbz	x8, LBB1_6
	b	LBB1_5
LBB1_5:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	b	LBB1_6
LBB1_6:
	stur	wzr, [x29, #-4]
	b	LBB1_20
LBB1_7:
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB1_9
	b	LBB1_8
LBB1_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_20
LBB1_9:
	ldr	x8, [sp, #24]
	cbz	x8, LBB1_11
	b	LBB1_10
LBB1_10:
	ldr	x8, [sp, #24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB1_12
LBB1_11:
	mov	x8, #1                          ; =0x1
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB1_12
LBB1_12:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_malloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_14
	b	LBB1_13
LBB1_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_20
LBB1_14:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #24]
	ldr	x4, [sp, #32]
	mov	x3, #0                          ; =0x0
	bl	_nvm_serialize_core
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB1_18
	b	LBB1_15
LBB1_15:
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #24]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #40]
	cbz	x8, LBB1_17
	b	LBB1_16
LBB1_16:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	b	LBB1_17
LBB1_17:
	b	LBB1_18
LBB1_18:
	ldr	x0, [sp, #8]
	bl	_free
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB1_20
LBB1_19:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-32]
	ldr	x3, [sp, #40]
	ldr	x4, [sp, #32]
	bl	_nvm_serialize_core
	stur	w0, [x29, #-4]
	b	LBB1_20
LBB1_20:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_serialize_core
_nvm_serialize_core:                    ; @nvm_serialize_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #736
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #264]
	str	x1, [sp, #256]
	str	x2, [sp, #248]
	str	x3, [sp, #240]
	str	x4, [sp, #232]
	ldr	x8, [sp, #264]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_2:
	ldr	x0, [sp, #264]
	ldr	x1, [sp, #232]
	bl	_nvm_private_service_wire
	str	w0, [sp, #228]
	ldr	w8, [sp, #228]
	cbz	w8, LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	w8, [sp, #228]
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_4:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #208]
	cbz	w8, LBB2_6
	b	LBB2_5
LBB2_5:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #200]
	cbz	x8, LBB2_8
	b	LBB2_6
LBB2_6:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #208]
	cbnz	w8, LBB2_9
	b	LBB2_7
LBB2_7:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #240]
	tbz	w8, #6, LBB2_9
	b	LBB2_8
LBB2_8:
	mov	w8, #14                         ; =0xe
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_9:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #192]
	cbz	w8, LBB2_11
	b	LBB2_10
LBB2_10:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #184]
	cbz	x8, LBB2_13
	b	LBB2_11
LBB2_11:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #192]
	cbnz	w8, LBB2_14
	b	LBB2_12
LBB2_12:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #240]
	tbz	w8, #8, LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #14                         ; =0xe
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_14:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #208]
	cbnz	w8, LBB2_17
	b	LBB2_15
LBB2_15:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #192]
	cbnz	w8, LBB2_17
	b	LBB2_16
LBB2_16:
	ldr	x0, [sp, #264]
	bl	_nvm_v2_service_bindings_present
	tbz	w0, #0, LBB2_22
	b	LBB2_17
LBB2_17:
	ldr	x8, [sp, #264]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #264]
	bl	_required_features
	mov	x8, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #240]
	orr	w1, w8, w9
	ldr	x2, [sp, #232]
	bl	_validate_cross_section
	str	w0, [sp, #224]
	ldr	w8, [sp, #224]
	cbz	w8, LBB2_19
	b	LBB2_18
LBB2_18:
	ldr	w8, [sp, #224]
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_19:
	add	x1, sp, #216
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #216]
	ldr	x0, [sp, #264]
	ldr	x2, [sp, #232]
	bl	_nvm_private_to_module
	str	w0, [sp, #224]
	ldr	x0, [sp, #216]
	bl	_nvm_module_free
	ldr	w8, [sp, #224]
	cbz	w8, LBB2_21
	b	LBB2_20
LBB2_20:
	ldr	w8, [sp, #224]
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_21:
	b	LBB2_22
LBB2_22:
	ldr	x0, [sp, #264]
	add	x1, sp, #280
	bl	_build_plan
	str	x0, [sp, #208]
	str	wzr, [sp, #204]
	str	xzr, [sp, #192]
	b	LBB2_23
LBB2_23:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #192]
	ldr	x9, [sp, #208]
	subs	x8, x8, x9
	b.hs	LBB2_28
	b	LBB2_24
LBB2_24:                                ;   in Loop: Header=BB2_23 Depth=1
	ldr	x9, [sp, #192]
	add	x8, sp, #280
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB2_26
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_23 Depth=1
	ldr	w8, [sp, #204]
	add	w8, w8, #1
	str	w8, [sp, #204]
	b	LBB2_26
LBB2_26:                                ;   in Loop: Header=BB2_23 Depth=1
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_23 Depth=1
	ldr	x8, [sp, #192]
	add	x8, x8, #1
	str	x8, [sp, #192]
	b	LBB2_23
LBB2_28:
	ldr	w8, [sp, #204]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	str	x8, [sp, #184]
	ldr	x8, [sp, #184]
	add	x8, x8, #40
	str	x8, [sp, #176]
	str	xzr, [sp, #168]
	b	LBB2_29
LBB2_29:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #168]
	ldr	x9, [sp, #208]
	subs	x8, x8, x9
	b.hs	LBB2_34
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_29 Depth=1
	ldr	x9, [sp, #168]
	add	x8, sp, #280
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB2_32
	b	LBB2_31
LBB2_31:                                ;   in Loop: Header=BB2_29 Depth=1
	b	LBB2_33
LBB2_32:                                ;   in Loop: Header=BB2_29 Depth=1
	ldr	x0, [sp, #176]
	bl	_align4
	str	x0, [sp, #176]
	ldr	x9, [sp, #176]
	ldr	x11, [sp, #168]
	add	x8, sp, #280
	mov	x10, x8
	add	x10, x10, x11, lsl #5
	str	x9, [x10, #16]
	ldr	x9, [sp, #168]
	add	x8, x8, x9, lsl #5
	ldr	x9, [x8, #8]
	ldr	x8, [sp, #176]
	add	x8, x8, x9
	str	x8, [sp, #176]
	b	LBB2_33
LBB2_33:                                ;   in Loop: Header=BB2_29 Depth=1
	ldr	x8, [sp, #168]
	add	x8, x8, #1
	str	x8, [sp, #168]
	b	LBB2_29
LBB2_34:
	ldr	x8, [sp, #176]
	str	x8, [sp, #160]
	ldr	x8, [sp, #240]
	cbz	x8, LBB2_36
	b	LBB2_35
LBB2_35:
	ldr	x8, [sp, #160]
	ldr	x9, [sp, #240]
	str	x8, [x9]
	b	LBB2_36
LBB2_36:
	ldr	x8, [sp, #256]
	cbnz	x8, LBB2_38
	b	LBB2_37
LBB2_37:
	str	wzr, [sp, #276]
	b	LBB2_76
LBB2_38:
	ldr	x8, [sp, #248]
	ldr	x9, [sp, #160]
	subs	x8, x8, x9
	b.hs	LBB2_40
	b	LBB2_39
LBB2_39:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #276]
	b	LBB2_76
LBB2_40:
	ldr	x0, [sp, #256]
	ldr	x2, [sp, #160]
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	add	x0, sp, #112
	mov	x2, #48                         ; =0x30
	bl	_memset
	mov	w8, #78                         ; =0x4e
	strb	w8, [sp, #112]
	mov	w8, #86                         ; =0x56
	strb	w8, [sp, #113]
	mov	w8, #77                         ; =0x4d
	strb	w8, [sp, #114]
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #115]
	mov	w8, #1                          ; =0x1
	strh	w8, [sp, #116]
	ldr	x8, [sp, #264]
	ldrh	w8, [x8]
	cbz	w8, LBB2_42
	b	LBB2_41
LBB2_41:
	ldr	x8, [sp, #264]
	ldrh	w8, [x8]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB2_43
LBB2_42:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB2_43
LBB2_43:
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	add	x9, sp, #112
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	strh	w8, [sp, #118]
	ldr	x0, [sp, #264]
	bl	_required_features
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #240]
	orr	w8, w0, w8
	str	w8, [sp, #120]
	ldr	x8, [sp, #160]
	str	x8, [sp, #128]
	mov	w8, #40                         ; =0x28
	str	w8, [sp, #136]
	ldr	w8, [sp, #204]
	str	w8, [sp, #140]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #4]
	str	w8, [sp, #144]
	str	wzr, [sp, #148]
	str	wzr, [sp, #152]
	ldr	x0, [sp, #256]
	bl	_nvm_v2_write_header
	mov	x8, #40                         ; =0x28
	str	x8, [sp, #104]
	str	xzr, [sp, #96]
	b	LBB2_44
LBB2_44:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #208]
	subs	x8, x8, x9
	b.hs	LBB2_49
	b	LBB2_45
LBB2_45:                                ;   in Loop: Header=BB2_44 Depth=1
	ldr	x9, [sp, #96]
	add	x8, sp, #280
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB2_47
	b	LBB2_46
LBB2_46:                                ;   in Loop: Header=BB2_44 Depth=1
	b	LBB2_48
LBB2_47:                                ;   in Loop: Header=BB2_44 Depth=1
	ldr	x8, [sp, #96]
	lsl	x9, x8, #5
	add	x8, sp, #280
	ldr	w9, [x8, x9]
	add	x1, sp, #72
	str	w9, [sp, #72]
	str	wzr, [sp, #76]
	ldr	x10, [sp, #96]
	mov	x9, x8
	add	x9, x9, x10, lsl #5
	ldr	x9, [x9, #16]
	str	x9, [sp, #80]
	ldr	x9, [sp, #96]
	add	x8, x8, x9, lsl #5
	ldr	x8, [x8, #8]
	str	x8, [sp, #88]
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #104]
	add	x0, x8, x9
	bl	_nvm_v2_write_section
	ldr	x8, [sp, #104]
	add	x8, x8, #24
	str	x8, [sp, #104]
	b	LBB2_48
LBB2_48:                                ;   in Loop: Header=BB2_44 Depth=1
	ldr	x8, [sp, #96]
	add	x8, x8, #1
	str	x8, [sp, #96]
	b	LBB2_44
LBB2_49:
	str	xzr, [sp, #64]
	b	LBB2_50
LBB2_50:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #208]
	subs	x8, x8, x9
	b.hs	LBB2_75
	b	LBB2_51
LBB2_51:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x9, [sp, #64]
	add	x8, sp, #280
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB2_53
	b	LBB2_52
LBB2_52:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x9, [sp, #64]
	add	x8, sp, #280
	add	x8, x8, x9, lsl #5
	ldr	x8, [x8, #8]
	cbnz	x8, LBB2_54
	b	LBB2_53
LBB2_53:                                ;   in Loop: Header=BB2_50 Depth=1
	b	LBB2_74
LBB2_54:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x9, [sp, #256]
	ldr	x11, [sp, #64]
	add	x8, sp, #280
	mov	x10, x8
	add	x10, x10, x11, lsl #5
	ldr	x10, [x10, #16]
	add	x9, x9, x10
	str	x9, [sp, #56]
	ldr	x10, [sp, #64]
	mov	x9, x8
	add	x9, x9, x10, lsl #5
	ldr	x9, [x9, #8]
	str	x9, [sp, #48]
	ldr	x9, [sp, #64]
	lsl	x9, x9, #5
	ldr	w8, [x8, x9]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	subs	x8, x8, #13
	b.hi	LBB2_72
; %bb.55:                               ;   in Loop: Header=BB2_50 Depth=1
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	adrp	x10, lJTI2_0@PAGE
	add	x10, x10, lJTI2_0@PAGEOFF
Ltmp0:
	adr	x8, Ltmp0
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB2_56:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #8
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_metadata_encode
	b	LBB2_73
LBB2_57:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #24
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_constants_encode
	b	LBB2_73
LBB2_58:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #40
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_signatures_encode
	b	LBB2_73
LBB2_59:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #56
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_layouts_encode
	b	LBB2_73
LBB2_60:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #72
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_functions_encode
	b	LBB2_73
LBB2_61:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #168]
	cbz	x8, LBB2_63
	b	LBB2_62
LBB2_62:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x0, [sp, #56]
	ldr	x8, [sp, #264]
	ldr	x1, [x8, #168]
	ldr	x2, [sp, #48]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_63
LBB2_63:                                ;   in Loop: Header=BB2_50 Depth=1
	b	LBB2_73
LBB2_64:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #88
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_globals_encode
	b	LBB2_73
LBB2_65:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #104
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_imports_encode
	b	LBB2_73
LBB2_66:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #136
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_links_encode
	b	LBB2_73
LBB2_67:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #152
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_debug_encode
	b	LBB2_73
LBB2_68:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #264]
	add	x0, x8, #120
	ldr	x1, [sp, #56]
	ldr	x2, [sp, #48]
	bl	_nvm_v2_callbacks_encode
	b	LBB2_73
LBB2_69:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x0, [sp, #56]
	ldr	x8, [sp, #264]
	ldr	x1, [x8, #200]
	ldr	x2, [sp, #48]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_73
LBB2_70:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x0, [sp, #56]
	ldr	x8, [sp, #264]
	ldr	x1, [x8, #184]
	ldr	x2, [sp, #48]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_73
LBB2_71:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x0, [sp, #56]
	ldr	x8, [sp, #264]
	ldr	x1, [x8, #216]
	ldr	x2, [sp, #48]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_73
LBB2_72:                                ;   in Loop: Header=BB2_50 Depth=1
	b	LBB2_73
LBB2_73:                                ;   in Loop: Header=BB2_50 Depth=1
	b	LBB2_74
LBB2_74:                                ;   in Loop: Header=BB2_50 Depth=1
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB2_50
LBB2_75:
	ldr	x8, [sp, #256]
	add	x0, x8, #40
	ldr	x8, [sp, #160]
	subs	x8, x8, #40
	mov	x1, x8
	bl	_nvm_crc32
	add	x1, sp, #112
	str	w0, [sp, #152]
	ldr	x0, [sp, #256]
	bl	_nvm_v2_write_header
	str	wzr, [sp, #276]
	b	LBB2_76
LBB2_76:
	ldr	w8, [sp, #276]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB2_78
	b	LBB2_77
LBB2_77:
	bl	___stack_chk_fail
LBB2_78:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #736
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI2_0:
	.long	LBB2_56-Ltmp0
	.long	LBB2_57-Ltmp0
	.long	LBB2_58-Ltmp0
	.long	LBB2_59-Ltmp0
	.long	LBB2_60-Ltmp0
	.long	LBB2_61-Ltmp0
	.long	LBB2_64-Ltmp0
	.long	LBB2_65-Ltmp0
	.long	LBB2_66-Ltmp0
	.long	LBB2_67-Ltmp0
	.long	LBB2_68-Ltmp0
	.long	LBB2_69-Ltmp0
	.long	LBB2_70-Ltmp0
	.long	LBB2_71-Ltmp0
                                        ; -- End function
	.globl	_nvm_private_deserialize        ; -- Begin function nvm_private_deserialize
	.p2align	2
_nvm_private_deserialize:               ; @nvm_private_deserialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #56
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	x0, [x8, #24]
	str	x1, [x8, #16]
	str	x2, [x8, #8]
	str	x3, [x8]
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #16]
	bl	_map_bytes_selected
	tbz	w0, #0, LBB3_7
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbnz	x8, LBB3_3
	b	LBB3_2
LBB3_2:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB3_8
LBB3_3:
	add	x0, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #248                        ; =0xf8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #16]
	ldr	x3, [x8]
	bl	_nvm_deserialize_core
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbnz	w8, LBB3_5
	b	LBB3_4
LBB3_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	add	x1, sp, #32
	mov	x2, #248                        ; =0xf8
	bl	_memcpy
	b	LBB3_6
LBB3_5:
	add	x0, sp, #32
	bl	_nvm_v2_module_free
	b	LBB3_6
LBB3_6:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-20]
	b	LBB3_8
LBB3_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #16]
	ldr	x2, [x8, #8]
	ldr	x3, [x8]
	bl	_nvm_deserialize_core
	stur	w0, [x29, #-20]
	b	LBB3_8
LBB3_8:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_bytes_selected
_map_bytes_selected:                    ; @map_bytes_selected
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #592
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	sub	x2, x29, #88
	bl	_nvm_v2_read_header
	cbz	w0, LBB4_2
	b	LBB4_1
LBB4_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB4_20
LBB4_2:
	stur	wzr, [x29, #-92]
	b	LBB4_3
LBB4_3:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-92]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB4_19
	b	LBB4_4
LBB4_4:                                 ;   in Loop: Header=BB4_3 Depth=1
	add	x0, sp, #8
	mov	x1, #480                        ; =0x1e0
	bl	_bzero
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	w3, [x29, #-92]
	sub	x2, x29, #88
	sub	x4, x29, #120
	bl	_nvm_v2_read_section
	cbz	w0, LBB4_6
	b	LBB4_5
LBB4_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB4_20
LBB4_6:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-112]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.hi	LBB4_8
	b	LBB4_7
LBB4_7:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-104]
	ldur	x9, [x29, #-40]
	ldur	x10, [x29, #-112]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_9
	b	LBB4_8
LBB4_8:                                 ;   in Loop: Header=BB4_3 Depth=1
	b	LBB4_18
LBB4_9:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-104]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB4_11
	b	LBB4_10
LBB4_10:                                ;   in Loop: Header=BB4_3 Depth=1
	b	LBB4_18
LBB4_11:                                ;   in Loop: Header=BB4_3 Depth=1
	ldur	w8, [x29, #-120]
	subs	w8, w8, #4
	b.ne	LBB4_13
	b	LBB4_12
LBB4_12:                                ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-112]
	add	x8, x8, x9
	str	x8, [sp, #320]
	ldur	x8, [x29, #-104]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #328]
	b	LBB4_13
LBB4_13:                                ;   in Loop: Header=BB4_3 Depth=1
	ldur	w8, [x29, #-120]
	subs	w8, w8, #13
	b.ne	LBB4_15
	b	LBB4_14
LBB4_14:                                ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-112]
	add	x8, x8, x9
	str	x8, [sp, #304]
	ldur	x8, [x29, #-104]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #312]
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_3 Depth=1
	add	x0, sp, #8
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB4_17
	b	LBB4_16
LBB4_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB4_20
LBB4_17:                                ;   in Loop: Header=BB4_3 Depth=1
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_3 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB4_3
LBB4_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB4_20
LBB4_20:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	add	sp, sp, #592
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_deserialize_core
_nvm_deserialize_core:                  ; @nvm_deserialize_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	ldur	x0, [x29, #-48]
	mov	w1, #0                          ; =0x0
	mov	x2, #248                        ; =0xf8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	bl	_nvm_v2_validate
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-20]
	b	LBB5_86
LBB5_2:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	sub	x2, x29, #112
	bl	_nvm_v2_read_header
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_4
	b	LBB5_3
LBB5_3:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-20]
	b	LBB5_86
LBB5_4:
	ldurh	w8, [x29, #-106]
	ldur	x9, [x29, #-48]
	strh	w8, [x9]
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #4]
	ldur	w8, [x29, #-104]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #240]
	add	x0, sp, #128
	mov	x1, #480                        ; =0x1e0
	bl	_bzero
	str	wzr, [sp, #124]
	b	LBB5_5
LBB5_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #124]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB5_18
	b	LBB5_6
LBB5_6:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldr	w3, [sp, #124]
	sub	x2, x29, #112
	add	x4, sp, #96
	bl	_nvm_v2_read_section
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_8
	b	LBB5_7
LBB5_7:
	b	LBB5_85
LBB5_8:                                 ;   in Loop: Header=BB5_5 Depth=1
	ldr	x8, [sp, #112]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB5_10
	b	LBB5_9
LBB5_9:                                 ;   in Loop: Header=BB5_5 Depth=1
	b	LBB5_17
LBB5_10:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w8, [sp, #96]
	subs	w8, w8, #4
	b.ne	LBB5_12
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #104]
	add	x8, x8, x9
	str	x8, [sp, #440]
	ldr	x8, [sp, #112]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #448]
	b	LBB5_12
LBB5_12:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w8, [sp, #96]
	subs	w8, w8, #13
	b.ne	LBB5_14
	b	LBB5_13
LBB5_13:                                ;   in Loop: Header=BB5_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #104]
	add	x8, x8, x9
	str	x8, [sp, #424]
	ldr	x8, [sp, #112]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #432]
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w8, [sp, #96]
	subs	w8, w8, #14
	b.ne	LBB5_16
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #104]
	add	x8, x8, x9
	str	x8, [sp, #456]
	ldr	x8, [sp, #112]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #464]
	b	LBB5_16
LBB5_16:                                ;   in Loop: Header=BB5_5 Depth=1
	b	LBB5_17
LBB5_17:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w8, [sp, #124]
	add	w8, w8, #1
	str	w8, [sp, #124]
	b	LBB5_5
LBB5_18:
	add	x0, sp, #128
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_record_array_candidate
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	strb	w8, [sp, #95]
	strb	wzr, [sp, #94]
	bl	_nvm_record_map_route
	str	w0, [sp, #88]
	ldr	w8, [sp, #88]
	subs	w8, w8, #2
	b.eq	LBB5_20
	b	LBB5_19
LBB5_19:
	ldr	w8, [sp, #88]
	subs	w8, w8, #3
	b.ne	LBB5_21
	b	LBB5_20
LBB5_20:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-60]
	b	LBB5_85
LBB5_21:
	ldr	w8, [sp, #88]
	subs	w8, w8, #1
	cset	w8, eq
	strb	w8, [sp, #94]
	str	wzr, [sp, #84]
	b	LBB5_22
LBB5_22:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB5_72
	b	LBB5_23
LBB5_23:                                ;   in Loop: Header=BB5_22 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldr	w3, [sp, #84]
	sub	x2, x29, #112
	add	x4, sp, #56
	bl	_nvm_v2_read_section
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_25
	b	LBB5_24
LBB5_24:
	b	LBB5_85
LBB5_25:                                ;   in Loop: Header=BB5_22 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #64]
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #72]
	str	x8, [sp, #40]
	ldr	w8, [sp, #56]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	subs	x8, x8, #13
	b.hi	LBB5_67
; %bb.26:                               ;   in Loop: Header=BB5_22 Depth=1
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	adrp	x10, lJTI5_0@PAGE
	add	x10, x10, lJTI5_0@PAGEOFF
Ltmp1:
	adr	x8, Ltmp1
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB5_27:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #8
	bl	_nvm_v2_metadata_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_28:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #24
	bl	_nvm_v2_constants_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_29:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #40
	bl	_nvm_v2_signatures_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_30:                                ;   in Loop: Header=BB5_22 Depth=1
	ldrb	w8, [sp, #94]
	tbz	w8, #0, LBB5_32
	b	LBB5_31
LBB5_31:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #56
	mov	x3, #0                          ; =0x0
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB5_36
LBB5_32:                                ;   in Loop: Header=BB5_22 Depth=1
	ldrb	w8, [sp, #95]
	tbz	w8, #0, LBB5_34
	b	LBB5_33
LBB5_33:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #56
	bl	_nvm_ownership_layouts_private_decode
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB5_35
LBB5_34:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #56
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB5_35
LBB5_35:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB5_36
LBB5_36:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-60]
	b	LBB5_68
LBB5_37:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #72
	bl	_nvm_v2_functions_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_38:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	cbz	x8, LBB5_40
	b	LBB5_39
LBB5_39:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_41
LBB5_40:                                ;   in Loop: Header=BB5_22 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_41
LBB5_41:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x9, [x29, #-48]
	str	x8, [x9, #168]
	ldr	x8, [sp, #72]
	ldur	x9, [x29, #-48]
	str	x8, [x9, #176]
	b	LBB5_68
LBB5_42:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #88
	bl	_nvm_v2_globals_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_43:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #104
	bl	_nvm_v2_imports_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_44:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #136
	bl	_nvm_v2_links_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_45:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #120
	bl	_nvm_v2_callbacks_decode
	stur	w0, [x29, #-60]
	b	LBB5_68
LBB5_46:                                ;   in Loop: Header=BB5_22 Depth=1
	ldur	x8, [x29, #-56]
	cbz	x8, LBB5_49
	b	LBB5_47
LBB5_47:                                ;   in Loop: Header=BB5_22 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #16]
	cbz	w8, LBB5_56
	b	LBB5_48
LBB5_48:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB5_56
	b	LBB5_57
LBB5_49:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	subs	x8, x8, #56
	b.eq	LBB5_57
	b	LBB5_50
LBB5_50:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	subs	x8, x8, #120
	b.eq	LBB5_57
	b	LBB5_51
LBB5_51:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	subs	x8, x8, #128
	b.eq	LBB5_57
	b	LBB5_52
LBB5_52:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	subs	x8, x8, #80
	b.lo	LBB5_56
	b	LBB5_53
LBB5_53:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, #4112                       ; =0x1010
	subs	x8, x8, x9
	b.hi	LBB5_56
	b	LBB5_54
LBB5_54:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #3
	b.ne	LBB5_56
	b	LBB5_55
LBB5_55:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #1]
	cbz	w8, LBB5_57
	b	LBB5_56
LBB5_56:                                ;   in Loop: Header=BB5_22 Depth=1
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-60]
	b	LBB5_68
LBB5_57:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-48]
	str	x8, [x9, #216]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-48]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #224]
	b	LBB5_68
LBB5_58:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	cbz	x8, LBB5_60
	b	LBB5_59
LBB5_59:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB5_61
	b	LBB5_60
LBB5_60:                                ;   in Loop: Header=BB5_22 Depth=1
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-60]
	b	LBB5_68
LBB5_61:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-48]
	str	x8, [x9, #184]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-48]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #192]
	b	LBB5_68
LBB5_62:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	cbz	x8, LBB5_64
	b	LBB5_63
LBB5_63:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB5_65
	b	LBB5_64
LBB5_64:                                ;   in Loop: Header=BB5_22 Depth=1
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-60]
	b	LBB5_68
LBB5_65:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-48]
	str	x8, [x9, #200]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-48]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #208]
	b	LBB5_68
LBB5_66:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	ldur	x8, [x29, #-48]
	add	x2, x8, #152
	bl	_nvm_v2_debug_decode
	stur	w0, [x29, #-60]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #228]
	b	LBB5_68
LBB5_67:                                ;   in Loop: Header=BB5_22 Depth=1
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-60]
	b	LBB5_68
LBB5_68:                                ;   in Loop: Header=BB5_22 Depth=1
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_70
	b	LBB5_69
LBB5_69:
	b	LBB5_85
LBB5_70:                                ;   in Loop: Header=BB5_22 Depth=1
	b	LBB5_71
LBB5_71:                                ;   in Loop: Header=BB5_22 Depth=1
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB5_22
LBB5_72:
	ldur	x0, [x29, #-48]
	ldur	w1, [x29, #-104]
	ldur	x2, [x29, #-56]
	bl	_validate_cross_section
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_74
	b	LBB5_73
LBB5_73:
	b	LBB5_85
LBB5_74:
	ldur	w8, [x29, #-104]
	ands	w8, w8, #0x40
	cset	w8, ne
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #208]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB5_76
	b	LBB5_75
LBB5_75:
	mov	w8, #14                         ; =0xe
	stur	w8, [x29, #-60]
	b	LBB5_85
LBB5_76:
	ldur	w8, [x29, #-104]
	ands	w8, w8, #0x100
	cset	w8, ne
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #192]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB5_78
	b	LBB5_77
LBB5_77:
	mov	w8, #14                         ; =0xe
	stur	w8, [x29, #-60]
	b	LBB5_85
LBB5_78:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #208]
	cbnz	w8, LBB5_81
	b	LBB5_79
LBB5_79:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #192]
	cbnz	w8, LBB5_81
	b	LBB5_80
LBB5_80:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #224]
	cbz	w8, LBB5_84
	b	LBB5_81
LBB5_81:
	add	x1, sp, #32
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	ldur	x0, [x29, #-48]
	ldur	x2, [x29, #-56]
	bl	_nvm_private_to_module
	stur	w0, [x29, #-60]
	ldr	x0, [sp, #32]
	bl	_nvm_module_free
	ldur	w8, [x29, #-60]
	cbz	w8, LBB5_83
	b	LBB5_82
LBB5_82:
	b	LBB5_85
LBB5_83:
	b	LBB5_84
LBB5_84:
	stur	wzr, [x29, #-20]
	b	LBB5_86
LBB5_85:
	ldur	x0, [x29, #-48]
	bl	_nvm_v2_module_free
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-20]
	b	LBB5_86
LBB5_86:
	ldur	w0, [x29, #-20]
	add	sp, sp, #704
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI5_0:
	.long	LBB5_27-Ltmp1
	.long	LBB5_28-Ltmp1
	.long	LBB5_29-Ltmp1
	.long	LBB5_30-Ltmp1
	.long	LBB5_37-Ltmp1
	.long	LBB5_38-Ltmp1
	.long	LBB5_42-Ltmp1
	.long	LBB5_43-Ltmp1
	.long	LBB5_44-Ltmp1
	.long	LBB5_66-Ltmp1
	.long	LBB5_45-Ltmp1
	.long	LBB5_62-Ltmp1
	.long	LBB5_58-Ltmp1
	.long	LBB5_46-Ltmp1
                                        ; -- End function
	.globl	_nvm_v2_module_serialize        ; -- Begin function nvm_v2_module_serialize
	.p2align	2
_nvm_v2_module_serialize:               ; @nvm_v2_module_serialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	ldr	x3, [sp]
	mov	x4, #0                          ; =0x0
	bl	_nvm_private_serialize
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_module_deserialize      ; -- Begin function nvm_v2_module_deserialize
	.p2align	2
_nvm_v2_module_deserialize:             ; @nvm_v2_module_deserialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	x3, #0                          ; =0x0
	bl	_nvm_private_deserialize
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_private_service_wire
_nvm_private_service_wire:              ; @nvm_private_service_wire
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB8_7
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	cbz	x8, LBB8_5
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	cbz	x8, LBB8_5
	b	LBB8_3
LBB8_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
	cbz	w8, LBB8_5
	b	LBB8_4
LBB8_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldur	x0, [x29, #-8]
	blr	x8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB8_6
LBB8_5:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB8_6
LBB8_6:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB8_8
LBB8_7:
	ldur	x0, [x29, #-8]
	bl	_nvm_v2_service_bindings_validate
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB8_8
LBB8_8:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validate_cross_section
_validate_cross_section:                ; @validate_cross_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp]                        ; 8-byte Folded Spill
	str	x0, [x8]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldr	x0, [x8]
	ldur	x1, [x29, #-32]
	bl	_nvm_private_service_wire
	stur	w0, [x29, #-36]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_2:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldur	w8, [x29, #-20]
	ands	w8, w8, #0x200
	cset	w8, ne
	ldr	x9, [x9]
	ldr	w9, [x9, #224]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB9_4
	b	LBB9_3
LBB9_3:
	mov	w8, #14                         ; =0xe
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_4:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	w9, [x9, #32]
	stur	w9, [x29, #-40]
	ldr	x9, [x8]
	ldr	w9, [x9, #48]
	stur	w9, [x29, #-44]
	ldr	x8, [x8]
	ldr	w8, [x8, #64]
	stur	w8, [x29, #-48]
	stur	wzr, [x29, #-52]
	b	LBB9_5
LBB9_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldur	w8, [x29, #-52]
	ldr	x9, [x9]
	ldr	w9, [x9, #80]
	subs	w8, w8, w9
	b.hs	LBB9_16
	b	LBB9_6
LBB9_6:                                 ;   in Loop: Header=BB9_5 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #72]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldr	w0, [x8]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_8
	b	LBB9_7
LBB9_7:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_8:                                 ;   in Loop: Header=BB9_5 Depth=1
	ldur	x8, [x29, #-64]
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-44]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_10
	b	LBB9_9
LBB9_9:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_10:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #8]
	ldr	x9, [x9]
	ldr	x9, [x9, #176]
	subs	x8, x8, x9
	b.ls	LBB9_12
	b	LBB9_11
LBB9_11:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_12:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldr	x9, [x9]
	ldr	x9, [x9, #176]
	ldur	x10, [x29, #-64]
	ldr	x10, [x10, #8]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB9_14
	b	LBB9_13
LBB9_13:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_14:                                ;   in Loop: Header=BB9_5 Depth=1
	b	LBB9_15
LBB9_15:                                ;   in Loop: Header=BB9_5 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB9_5
LBB9_16:
	stur	wzr, [x29, #-68]
	b	LBB9_17
LBB9_17:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldur	w8, [x29, #-68]
	ldr	x9, [x9]
	ldr	w9, [x9, #96]
	subs	w8, w8, w9
	b.hs	LBB9_24
	b	LBB9_18
LBB9_18:                                ;   in Loop: Header=BB9_17 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x10, [x8, #88]
	ldur	w8, [x29, #-68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	w0, [x8]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_20
	b	LBB9_19
LBB9_19:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_20:                                ;   in Loop: Header=BB9_17 Depth=1
	ldr	x8, [sp, #80]
	ldr	w0, [x8, #8]
	ldur	w1, [x29, #-40]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_22
	b	LBB9_21
LBB9_21:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_22:                                ;   in Loop: Header=BB9_17 Depth=1
	b	LBB9_23
LBB9_23:                                ;   in Loop: Header=BB9_17 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB9_17
LBB9_24:
	str	wzr, [sp, #76]
	b	LBB9_25
LBB9_25:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #76]
	ldr	x9, [x9]
	ldr	w9, [x9, #112]
	subs	w8, w8, w9
	b.hs	LBB9_44
	b	LBB9_26
LBB9_26:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #104]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #12]
	subs	w8, w8, #3
	b.le	LBB9_28
	b	LBB9_27
LBB9_27:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_28:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #64]
	ldr	w0, [x8]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_30
	b	LBB9_29
LBB9_29:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_30:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #64]
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_32
	b	LBB9_31
LBB9_31:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_32:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #64]
	ldr	w0, [x8, #8]
	ldur	w1, [x29, #-44]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_34
	b	LBB9_33
LBB9_33:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_34:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #12]
	subs	w8, w8, #2
	b.ne	LBB9_42
	b	LBB9_35
LBB9_35:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #64]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB9_40
	b	LBB9_36
LBB9_36:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	cbz	w8, LBB9_40
	b	LBB9_37
LBB9_37:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	cbz	x8, LBB9_40
	b	LBB9_38
LBB9_38:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB9_40
	b	LBB9_39
LBB9_39:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB9_41
	b	LBB9_40
LBB9_40:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_41:                                ;   in Loop: Header=BB9_25 Depth=1
	b	LBB9_42
LBB9_42:                                ;   in Loop: Header=BB9_25 Depth=1
	b	LBB9_43
LBB9_43:                                ;   in Loop: Header=BB9_25 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB9_25
LBB9_44:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_validate_callbacks
	str	w0, [sp, #52]
	ldr	w8, [sp, #52]
	cbz	w8, LBB9_46
	b	LBB9_45
LBB9_45:
	ldr	w8, [sp, #52]
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_46:
	str	wzr, [sp, #48]
	b	LBB9_47
LBB9_47:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #48]
	ldr	x9, [x9]
	ldr	w9, [x9, #144]
	subs	w8, w8, w9
	b.hs	LBB9_56
	b	LBB9_48
LBB9_48:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #136]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldr	w0, [x8]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_50
	b	LBB9_49
LBB9_49:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_50:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	x8, [sp, #40]
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-40]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_52
	b	LBB9_51
LBB9_51:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_52:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	x8, [sp, #40]
	ldr	w0, [x8, #8]
	ldur	w1, [x29, #-44]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_54
	b	LBB9_53
LBB9_53:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_54:                                ;   in Loop: Header=BB9_47 Depth=1
	b	LBB9_55
LBB9_55:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB9_47
LBB9_56:
	str	wzr, [sp, #36]
	b	LBB9_57
LBB9_57:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB9_61 Depth 2
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #36]
	ldr	x9, [x9]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB9_70
	b	LBB9_58
LBB9_58:                                ;   in Loop: Header=BB9_57 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #56]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-40]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_60
	b	LBB9_59
LBB9_59:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_60:                                ;   in Loop: Header=BB9_57 Depth=1
	strh	wzr, [sp, #22]
	b	LBB9_61
LBB9_61:                                ;   Parent Loop BB9_57 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB9_68
	b	LBB9_62
LBB9_62:                                ;   in Loop: Header=BB9_61 Depth=2
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w0, [x8, #8]
	ldur	w1, [x29, #-40]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_64
	b	LBB9_63
LBB9_63:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_64:                                ;   in Loop: Header=BB9_61 Depth=2
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-48]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_66
	b	LBB9_65
LBB9_65:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_66:                                ;   in Loop: Header=BB9_61 Depth=2
	b	LBB9_67
LBB9_67:                                ;   in Loop: Header=BB9_61 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB9_61
LBB9_68:                                ;   in Loop: Header=BB9_57 Depth=1
	b	LBB9_69
LBB9_69:                                ;   in Loop: Header=BB9_57 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB9_57
LBB9_70:
	str	wzr, [sp, #16]
	b	LBB9_71
LBB9_71:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB9_78
	b	LBB9_72
LBB9_72:                                ;   in Loop: Header=BB9_71 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	w0, [x8, x9]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_74
	b	LBB9_73
LBB9_73:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_74:                                ;   in Loop: Header=BB9_71 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w0, [x8, #4]
	ldur	w1, [x29, #-40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_76
	b	LBB9_75
LBB9_75:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_76:                                ;   in Loop: Header=BB9_71 Depth=1
	b	LBB9_77
LBB9_77:                                ;   in Loop: Header=BB9_71 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB9_71
LBB9_78:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	w0, [x9, #4]
	ldr	x8, [x8]
	ldr	w1, [x8, #80]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_index_ok
	tbnz	w0, #0, LBB9_81
	b	LBB9_79
LBB9_79:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB9_81
	b	LBB9_80
LBB9_80:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_81:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_required_features
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	str	w0, [sp, #12]
	ldur	w8, [x29, #-20]
	ands	w8, w8, #0x20
	cset	w8, ne
	ldr	x9, [x9]
	ldr	w9, [x9, #128]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB9_83
	b	LBB9_82
LBB9_82:
	mov	w8, #14                         ; =0xe
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_83:
	ldur	w8, [x29, #-20]
	ldr	w9, [sp, #12]
	and	w8, w8, w9
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.eq	LBB9_85
	b	LBB9_84
LBB9_84:
	mov	w8, #14                         ; =0xe
	stur	w8, [x29, #-4]
	b	LBB9_86
LBB9_85:
	stur	wzr, [x29, #-4]
	b	LBB9_86
LBB9_86:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function required_features
_required_features:                     ; @required_features
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	wzr, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #144]
	cbz	w8, LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x1
	str	w8, [sp, #4]
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #112]
	cbz	w8, LBB10_4
	b	LBB10_3
LBB10_3:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x2
	str	w8, [sp, #4]
	b	LBB10_4
LBB10_4:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #128]
	cbz	w8, LBB10_6
	b	LBB10_5
LBB10_5:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x20
	str	w8, [sp, #4]
	b	LBB10_6
LBB10_6:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #208]
	cbz	w8, LBB10_8
	b	LBB10_7
LBB10_7:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x40
	str	w8, [sp, #4]
	b	LBB10_8
LBB10_8:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #192]
	cbz	w8, LBB10_10
	b	LBB10_9
LBB10_9:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x100
	str	w8, [sp, #4]
	b	LBB10_10
LBB10_10:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #224]
	cbz	w8, LBB10_12
	b	LBB10_11
LBB10_11:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x200
	str	w8, [sp, #4]
	b	LBB10_12
LBB10_12:
	ldr	x8, [sp, #8]
	add	x0, x8, #56
	bl	_nvm_layouts_have_facts
	tbz	w0, #0, LBB10_14
	b	LBB10_13
LBB10_13:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x80
	str	w8, [sp, #4]
	b	LBB10_14
LBB10_14:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #228]
	tbz	w8, #0, LBB10_16
	b	LBB10_15
LBB10_15:
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x8
	str	w8, [sp, #4]
	b	LBB10_16
LBB10_16:
	str	wzr, [sp]
	b	LBB10_17
LBB10_17:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #112]
	subs	w8, w8, w9
	b.hs	LBB10_22
	b	LBB10_18
LBB10_18:                               ;   in Loop: Header=BB10_17 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #104]
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #12]
	subs	w8, w8, #1
	b.ne	LBB10_20
	b	LBB10_19
LBB10_19:                               ;   in Loop: Header=BB10_17 Depth=1
	ldr	w8, [sp, #4]
	orr	w8, w8, #0x4
	str	w8, [sp, #4]
	b	LBB10_20
LBB10_20:                               ;   in Loop: Header=BB10_17 Depth=1
	b	LBB10_21
LBB10_21:                               ;   in Loop: Header=BB10_17 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB10_17
LBB10_22:
	ldr	w0, [sp, #4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function build_plan
_build_plan:                            ; @build_plan
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #736
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	stur	xzr, [x29, #-40]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	sub	x8, x29, #72
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #212]                  ; 4-byte Folded Spill
	stur	w8, [x29, #-72]
	stur	wzr, [x29, #-68]
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	bl	_nvm_v2_metadata_encoded_size
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-64]
	stur	xzr, [x29, #-56]
	mov	w11, #1                         ; =0x1
	str	w11, [sp, #180]                 ; 4-byte Folded Spill
	sturb	w11, [x29, #-48]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-44]
	ldur	q0, [x29, #-72]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-56]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	sub	x8, x29, #104
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-104]
	stur	wzr, [x29, #-100]
	ldur	x8, [x29, #-24]
	add	x0, x8, #24
	bl	_nvm_v2_constants_encoded_size
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	stur	x0, [x29, #-96]
	stur	xzr, [x29, #-88]
	sturb	w11, [x29, #-80]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-76]
	ldur	q0, [x29, #-104]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-88]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	sub	x8, x29, #136
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-136]
	stur	wzr, [x29, #-132]
	ldur	x8, [x29, #-24]
	add	x0, x8, #40
	bl	_nvm_v2_signatures_encoded_size
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	stur	x0, [x29, #-128]
	stur	xzr, [x29, #-120]
	sturb	w11, [x29, #-112]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-108]
	ldur	q0, [x29, #-136]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-120]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	sub	x8, x29, #168
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-168]
	stur	wzr, [x29, #-164]
	ldur	x8, [x29, #-24]
	add	x0, x8, #56
	bl	_nvm_v2_layouts_encoded_size
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	stur	x0, [x29, #-160]
	stur	xzr, [x29, #-152]
	sturb	w11, [x29, #-144]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-140]
	ldur	q0, [x29, #-168]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-152]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	sub	x8, x29, #200
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-200]
	stur	wzr, [x29, #-196]
	ldur	x8, [x29, #-24]
	add	x0, x8, #72
	bl	_nvm_v2_functions_encoded_size
	ldr	x10, [sp, #104]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	stur	x0, [x29, #-192]
	stur	xzr, [x29, #-184]
	sturb	w11, [x29, #-176]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-172]
	ldur	q0, [x29, #-200]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-184]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	add	x10, x9, #1
	stur	x10, [x29, #-40]
	sub	x10, x29, #232
	mov	w12, #6                         ; =0x6
	stur	w12, [x29, #-232]
	stur	wzr, [x29, #-228]
	ldur	x12, [x29, #-24]
	ldr	x12, [x12, #176]
	stur	x12, [x29, #-224]
	stur	xzr, [x29, #-216]
	sturb	w11, [x29, #-208]
	stur	wzr, [x10, #25]
	stur	wzr, [x29, #-204]
	ldur	q0, [x29, #-232]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	ldur	q0, [x29, #-216]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	add	x8, sp, #488
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #488]
	str	wzr, [sp, #492]
	ldur	x8, [x29, #-24]
	add	x0, x8, #88
	bl	_nvm_v2_globals_encoded_size
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	str	x0, [sp, #496]
	str	xzr, [sp, #504]
	strb	w11, [sp, #512]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #516]
	add	x10, sp, #233
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #249
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	add	x8, sp, #456
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #456]
	str	wzr, [sp, #460]
	ldur	x8, [x29, #-24]
	add	x0, x8, #104
	bl	_nvm_v2_imports_encoded_size
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	str	x0, [sp, #464]
	str	xzr, [sp, #472]
	strb	w11, [sp, #480]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #484]
	add	x10, sp, #201
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #217
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	add	x8, sp, #424
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	mov	w8, #9                          ; =0x9
	str	w8, [sp, #424]
	str	wzr, [sp, #428]
	ldur	x8, [x29, #-24]
	add	x0, x8, #136
	bl	_nvm_v2_links_encoded_size
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	ldr	x10, [sp, #184]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #192]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	str	x0, [sp, #432]
	str	xzr, [sp, #440]
	strb	w11, [sp, #448]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #452]
	add	x10, sp, #169
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #185
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	add	x8, sp, #392
	str	x8, [sp, #216]                  ; 8-byte Folded Spill
	mov	w8, #10                         ; =0xa
	str	w8, [sp, #392]
	str	wzr, [sp, #396]
	ldur	x8, [x29, #-24]
	add	x0, x8, #152
	bl	_nvm_v2_debug_encoded_size
	ldr	w12, [sp, #212]                 ; 4-byte Folded Reload
	ldr	x10, [sp, #216]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #224]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	str	x0, [sp, #400]
	str	xzr, [sp, #408]
	ldur	x11, [x29, #-24]
	ldrb	w11, [x11, #228]
	and	w11, w11, w12
	strb	w11, [sp, #416]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #420]
	add	x10, sp, #137
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #153
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	str	x8, [sp, #248]                  ; 8-byte Folded Spill
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	add	x8, sp, #360
	str	x8, [sp, #240]                  ; 8-byte Folded Spill
	mov	w8, #11                         ; =0xb
	str	w8, [sp, #360]
	str	wzr, [sp, #364]
	ldur	x8, [x29, #-24]
	add	x0, x8, #120
	bl	_nvm_v2_callbacks_encoded_size
	ldr	x10, [sp, #240]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #248]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x0, [sp, #368]
	str	xzr, [sp, #376]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #128]
	subs	w11, w11, #0
	cset	w11, ne
	strb	w11, [sp, #384]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #388]
	add	x10, sp, #105
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #121
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	add	x10, x9, #1
	stur	x10, [x29, #-40]
	add	x10, sp, #328
	mov	w11, #12                        ; =0xc
	str	w11, [sp, #328]
	str	wzr, [sp, #332]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #208]
                                        ; kill: def $x11 killed $w11
	str	x11, [sp, #336]
	str	xzr, [sp, #344]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #208]
	subs	w11, w11, #0
	cset	w11, ne
	strb	w11, [sp, #352]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #356]
	add	x10, sp, #73
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #89
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	add	x10, x9, #1
	stur	x10, [x29, #-40]
	add	x10, sp, #296
	mov	w11, #13                        ; =0xd
	str	w11, [sp, #296]
	str	wzr, [sp, #300]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #192]
                                        ; kill: def $x11 killed $w11
	str	x11, [sp, #304]
	str	xzr, [sp, #312]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #192]
	subs	w11, w11, #0
	cset	w11, ne
	strb	w11, [sp, #320]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #324]
	add	x10, sp, #41
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #57
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	add	x10, x9, #1
	stur	x10, [x29, #-40]
	add	x10, sp, #264
	mov	w11, #14                        ; =0xe
	str	w11, [sp, #264]
	str	wzr, [sp, #268]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #224]
                                        ; kill: def $x11 killed $w11
	str	x11, [sp, #272]
	str	xzr, [sp, #280]
	ldur	x11, [x29, #-24]
	ldr	w11, [x11, #224]
	subs	w11, w11, #0
	cset	w11, ne
	strb	w11, [sp, #288]
	stur	wzr, [x10, #25]
	str	wzr, [sp, #292]
	add	x10, sp, #9
	ldur	q0, [x10, #255]
	add	x8, x8, x9, lsl #5
	str	q0, [x8]
	add	x9, sp, #25
	ldur	q0, [x9, #255]
	str	q0, [x8, #16]
	ldur	x0, [x29, #-40]
	add	sp, sp, #736
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function align4
_align4:                                ; @align4
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x8, x8, #3
	and	x0, x8, #0xfffffffffffffffc
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function index_ok
_index_ok:                              ; @index_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	str	w1, [sp, #4]
	strb	w2, [sp, #3]
	ldrb	w8, [sp, #3]
	tbz	w8, #0, LBB13_3
	b	LBB13_1
LBB13_1:
	ldr	w8, [sp, #8]
	adds	w8, w8, #1
	b.ne	LBB13_3
	b	LBB13_2
LBB13_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB13_4
LBB13_3:
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #4]
	subs	w8, w8, w9
	cset	w8, lo
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB13_4
LBB13_4:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validate_callbacks
_validate_callbacks:                    ; @validate_callbacks
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	wzr, [x29, #-20]
	b	LBB14_1
LBB14_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_7 Depth 2
                                        ;     Child Loop BB14_14 Depth 2
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #128]
	subs	w8, w8, w9
	b.hs	LBB14_49
	b	LBB14_2
LBB14_2:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #120]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #112]
	subs	w8, w8, w9
	b.lo	LBB14_4
	b	LBB14_3
LBB14_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_4:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #104]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8]
	subs	w8, w8, #16
	b.le	LBB14_6
	b	LBB14_5
LBB14_5:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_6:                                ;   in Loop: Header=BB14_1 Depth=1
	stur	wzr, [x29, #-44]
	stur	wzr, [x29, #-48]
	sturh	wzr, [x29, #-50]
	b	LBB14_7
LBB14_7:                                ;   Parent Loop BB14_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-50]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB14_13
	b	LBB14_8
LBB14_8:                                ;   in Loop: Header=BB14_7 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-50]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #11
	b.eq	LBB14_10
	b	LBB14_9
LBB14_9:                                ;   in Loop: Header=BB14_7 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-50]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #15
	b.ne	LBB14_11
	b	LBB14_10
LBB14_10:                               ;   in Loop: Header=BB14_7 Depth=2
	ldurh	w9, [x29, #-50]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w9
	ldur	w8, [x29, #-44]
	orr	w8, w8, w9
	stur	w8, [x29, #-44]
	b	LBB14_11
LBB14_11:                               ;   in Loop: Header=BB14_7 Depth=2
	b	LBB14_12
LBB14_12:                               ;   in Loop: Header=BB14_7 Depth=2
	ldurh	w8, [x29, #-50]
	add	w8, w8, #1
	sturh	w8, [x29, #-50]
	b	LBB14_7
LBB14_13:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	w8, [x29, #-20]
	str	w8, [sp, #56]
	b	LBB14_14
LBB14_14:                               ;   Parent Loop BB14_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w9, [sp, #56]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #128]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b.hs	LBB14_16
	b	LBB14_15
LBB14_15:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #120]
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB14_16
LBB14_16:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_46
	b	LBB14_17
LBB14_17:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #120]
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.lo	LBB14_19
	b	LBB14_18
LBB14_18:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_19:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB14_25
	b	LBB14_20
LBB14_20:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #4]
	cbz	w8, LBB14_25
	b	LBB14_21
LBB14_21:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #8]
	cbz	x8, LBB14_25
	b	LBB14_22
LBB14_22:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #4]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB14_25
	b	LBB14_23
LBB14_23:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #7]
	ldur	x9, [x29, #-32]
	ldrb	w9, [x9, #7]
	subs	w8, w8, w9
	b.ne	LBB14_25
	b	LBB14_24
LBB14_24:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.eq	LBB14_26
	b	LBB14_25
LBB14_25:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_26:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldrh	w8, [x8, #4]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB14_32
	b	LBB14_27
LBB14_27:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	w8, [x29, #-44]
	cbnz	w8, LBB14_30
	b	LBB14_28
LBB14_28:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	w8, [sp, #56]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB14_30
	b	LBB14_29
LBB14_29:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB14_31
	b	LBB14_30
LBB14_30:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_31:                               ;   in Loop: Header=BB14_14 Depth=2
	b	LBB14_45
LBB14_32:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB14_35
	b	LBB14_33
LBB14_33:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	w8, [x29, #-44]
	ldr	x9, [sp, #48]
	ldrh	w10, [x9, #4]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB14_35
	b	LBB14_34
LBB14_34:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.lo	LBB14_36
	b	LBB14_35
LBB14_35:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_36:                               ;   in Loop: Header=BB14_14 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #40]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #1
	b.gt	LBB14_43
	b	LBB14_37
LBB14_37:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB14_39
	b	LBB14_38
LBB14_38:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	cbz	w8, LBB14_43
	b	LBB14_39
LBB14_39:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #32]
	ldrh	w8, [x8]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB14_41
	b	LBB14_40
LBB14_40:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB14_42
LBB14_41:                               ;   in Loop: Header=BB14_14 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB14_42
LBB14_42:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	w1, [sp, #24]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #12]                   ; 4-byte Folded Reload
	bl	_nvm_callback_shape_valid
	tbnz	w0, #0, LBB14_44
	b	LBB14_43
LBB14_43:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_44:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	x8, [sp, #48]
	ldrh	w9, [x8, #4]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w9
	ldur	w8, [x29, #-48]
	orr	w8, w8, w9
	stur	w8, [x29, #-48]
	b	LBB14_45
LBB14_45:                               ;   in Loop: Header=BB14_14 Depth=2
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB14_14
LBB14_46:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	w8, [x29, #-44]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.eq	LBB14_48
	b	LBB14_47
LBB14_47:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB14_50
LBB14_48:                               ;   in Loop: Header=BB14_1 Depth=1
	ldr	w8, [sp, #56]
	stur	w8, [x29, #-20]
	b	LBB14_1
LBB14_49:
	stur	wzr, [x29, #-4]
	b	LBB14_50
LBB14_50:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_map_selected
_nvm_record_map_selected:               ; @nvm_record_map_selected
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_3
	b	LBB15_1
LBB15_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_3
	b	LBB15_2
LBB15_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB15_3
LBB15_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
