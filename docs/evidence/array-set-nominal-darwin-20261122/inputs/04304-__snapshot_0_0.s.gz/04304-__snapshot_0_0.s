	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_service_source_catalog_id   ; -- Begin function nl_service_source_catalog_id
	.p2align	2
_nl_service_source_catalog_id:          ; @nl_service_source_catalog_id
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	stur	xzr, [x29, #-8]
	b	LBB0_9
LBB0_2:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nl_source_catalog_private_file_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_strcmp
	cbnz	w0, LBB0_4
	b	LBB0_3
LBB0_3:
	mov	x8, #1                          ; =0x1
	stur	x8, [x29, #-8]
	b	LBB0_9
LBB0_4:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nl_source_catalog_private_socket_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_strcmp
	cbnz	w0, LBB0_6
	b	LBB0_5
LBB0_5:
	mov	x8, #2                          ; =0x2
	stur	x8, [x29, #-8]
	b	LBB0_9
LBB0_6:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nl_source_catalog_private_websocket_catalog_interface
	mov	x1, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_strcmp
	cbnz	w0, LBB0_8
	b	LBB0_7
LBB0_7:
	mov	x8, #3                          ; =0x3
	stur	x8, [x29, #-8]
	b	LBB0_9
LBB0_8:
	stur	xzr, [x29, #-8]
	b	LBB0_9
LBB0_9:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_catalog_count ; -- Begin function nl_service_source_catalog_count
	.p2align	2
_nl_service_source_catalog_count:       ; @nl_service_source_catalog_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	subs	x8, x8, #1
	b.ne	LBB1_5
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #24]
	subs	x8, x8, #1
	b.ne	LBB1_3
	b	LBB1_2
LBB1_2:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_3:
	ldr	x9, [sp, #24]
	mov	w8, #5                          ; =0x5
	subs	x9, x9, #2
	csinv	w8, w8, wzr, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_4:
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #40]
	b	LBB1_16
LBB1_5:
	ldr	x8, [sp, #32]
	subs	x8, x8, #2
	b.ne	LBB1_10
	b	LBB1_6
LBB1_6:
	ldr	x8, [sp, #24]
	subs	x8, x8, #1
	b.ne	LBB1_8
	b	LBB1_7
LBB1_7:
	mov	x8, #9                          ; =0x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_9
LBB1_8:
	ldr	x9, [sp, #24]
	mov	x8, #5                          ; =0x5
	subs	x9, x9, #2
	csinv	x8, x8, xzr, eq
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_9
LBB1_9:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #40]
	b	LBB1_16
LBB1_10:
	ldr	x8, [sp, #32]
	subs	x8, x8, #3
	b.ne	LBB1_15
	b	LBB1_11
LBB1_11:
	ldr	x8, [sp, #24]
	subs	x8, x8, #1
	b.ne	LBB1_13
	b	LBB1_12
LBB1_12:
	mov	x8, #7                          ; =0x7
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB1_14
LBB1_13:
	ldr	x9, [sp, #24]
	mov	x8, #4                          ; =0x4
	subs	x9, x9, #2
	csinv	x8, x8, xzr, eq
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB1_14
LBB1_14:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #40]
	b	LBB1_16
LBB1_15:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #40]
	b	LBB1_16
LBB1_16:
	ldr	x0, [sp, #40]
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_catalog_string ; -- Begin function nl_service_source_catalog_string
	.p2align	2
_nl_service_source_catalog_string:      ; @nl_service_source_catalog_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-32]
	stur	x4, [x29, #-40]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-48]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB2_5
	b	LBB2_1
LBB2_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB2_5
	b	LBB2_2
LBB2_2:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB2_5
	b	LBB2_3
LBB2_3:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_5
	b	LBB2_4
LBB2_4:
	ldur	x0, [x29, #-8]
	bl	_source_interface
	stur	x0, [x29, #-48]
	b	LBB2_5
LBB2_5:
	ldur	x8, [x29, #-16]
	subs	x8, x8, #1
	b.ne	LBB2_28
	b	LBB2_6
LBB2_6:
	ldur	x8, [x29, #-24]
	tbnz	x8, #63, LBB2_28
	b	LBB2_7
LBB2_7:
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-8]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB2_28
	b	LBB2_8
LBB2_8:
	ldur	x8, [x29, #-40]
	tbnz	x8, #63, LBB2_28
	b	LBB2_9
LBB2_9:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-24]
	bl	_source_type
	str	x0, [sp, #56]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB2_12
	b	LBB2_10
LBB2_10:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_12
	b	LBB2_11
LBB2_11:
	ldr	x8, [sp, #56]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	b	LBB2_27
LBB2_12:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #1
	b.ne	LBB2_15
	b	LBB2_13
LBB2_13:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_15
	b	LBB2_14
LBB2_14:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	b	LBB2_26
LBB2_15:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #56]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB2_25
	b	LBB2_16
LBB2_16:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-40]
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #48]
	ldur	x8, [x29, #-32]
	subs	x8, x8, #2
	b.ne	LBB2_18
	b	LBB2_17
LBB2_17:
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	b	LBB2_24
LBB2_18:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #3
	b.ne	LBB2_20
	b	LBB2_19
LBB2_19:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	b	LBB2_23
LBB2_20:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #4
	b.ne	LBB2_22
	b	LBB2_21
LBB2_21:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-48]
	b	LBB2_22
LBB2_22:
	b	LBB2_23
LBB2_23:
	b	LBB2_24
LBB2_24:
	b	LBB2_25
LBB2_25:
	b	LBB2_26
LBB2_26:
	b	LBB2_27
LBB2_27:
	b	LBB2_28
LBB2_28:
	ldur	x8, [x29, #-16]
	subs	x8, x8, #2
	b.ne	LBB2_63
	b	LBB2_29
LBB2_29:
	ldur	x8, [x29, #-24]
	tbnz	x8, #63, LBB2_63
	b	LBB2_30
LBB2_30:
	ldur	x8, [x29, #-24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-8]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB2_63
	b	LBB2_31
LBB2_31:
	ldur	x8, [x29, #-40]
	tbnz	x8, #63, LBB2_63
	b	LBB2_32
LBB2_32:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-24]
	bl	_source_method
	str	x0, [sp, #40]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB2_35
	b	LBB2_33
LBB2_33:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_35
	b	LBB2_34
LBB2_34:
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	b	LBB2_62
LBB2_35:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #1
	b.ne	LBB2_38
	b	LBB2_36
LBB2_36:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_38
	b	LBB2_37
LBB2_37:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	b	LBB2_61
LBB2_38:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #2
	b.ne	LBB2_41
	b	LBB2_39
LBB2_39:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_41
	b	LBB2_40
LBB2_40:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-48]
	b	LBB2_60
LBB2_41:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #3
	b.ne	LBB2_44
	b	LBB2_42
LBB2_42:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB2_44
	b	LBB2_43
LBB2_43:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #24]
	stur	x8, [x29, #-48]
	b	LBB2_59
LBB2_44:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #7
	b.ne	LBB2_47
	b	LBB2_45
LBB2_45:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ge	LBB2_47
	b	LBB2_46
LBB2_46:
	ldr	x8, [sp, #40]
	add	x8, x8, #64
	ldur	x9, [x29, #-40]
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	b	LBB2_58
LBB2_47:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB2_57
	b	LBB2_48
LBB2_48:
	ldr	x8, [sp, #40]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldur	x8, [x29, #-32]
	subs	x8, x8, #4
	b.ne	LBB2_50
	b	LBB2_49
LBB2_49:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	b	LBB2_56
LBB2_50:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #5
	b.ne	LBB2_52
	b	LBB2_51
LBB2_51:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	b	LBB2_55
LBB2_52:
	ldur	x8, [x29, #-32]
	subs	x8, x8, #6
	b.ne	LBB2_54
	b	LBB2_53
LBB2_53:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-48]
	b	LBB2_54
LBB2_54:
	b	LBB2_55
LBB2_55:
	b	LBB2_56
LBB2_56:
	b	LBB2_57
LBB2_57:
	b	LBB2_58
LBB2_58:
	b	LBB2_59
LBB2_59:
	b	LBB2_60
LBB2_60:
	b	LBB2_61
LBB2_61:
	b	LBB2_62
LBB2_62:
	b	LBB2_63
LBB2_63:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB2_65
	b	LBB2_64
LBB2_64:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB2_66
LBB2_65:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB2_66
LBB2_66:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function source_interface
_source_interface:                      ; @source_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	subs	x8, x8, #1
	b.ne	LBB3_2
	b	LBB3_1
LBB3_1:
	bl	_nl_source_catalog_private_file_catalog_interface
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_9
LBB3_2:
	ldur	x8, [x29, #-8]
	subs	x8, x8, #2
	b.ne	LBB3_4
	b	LBB3_3
LBB3_3:
	bl	_nl_source_catalog_private_socket_catalog_interface
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_8
LBB3_4:
	ldur	x8, [x29, #-8]
	subs	x8, x8, #3
	b.ne	LBB3_6
	b	LBB3_5
LBB3_5:
	bl	_nl_source_catalog_private_websocket_catalog_interface
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB3_7
LBB3_6:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB3_7
LBB3_7:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_8
LBB3_8:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_9
LBB3_9:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function source_type
_source_type:                           ; @source_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	subs	x8, x8, #1
	b.ne	LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_file_catalog_type
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_6
LBB4_2:
	ldur	x8, [x29, #-8]
	subs	x8, x8, #2
	b.ne	LBB4_4
	b	LBB4_3
LBB4_3:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_socket_catalog_type
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB4_5
LBB4_4:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_websocket_catalog_type
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB4_5
LBB4_5:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_6
LBB4_6:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function source_method
_source_method:                         ; @source_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	subs	x8, x8, #1
	b.ne	LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_file_catalog_method
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_6
LBB5_2:
	ldur	x8, [x29, #-8]
	subs	x8, x8, #2
	b.ne	LBB5_4
	b	LBB5_3
LBB5_3:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_socket_catalog_method
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB5_5
LBB5_4:
	ldr	x0, [sp, #16]
	bl	_nl_source_catalog_private_websocket_catalog_method
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB5_5
LBB5_5:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_6
LBB5_6:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_catalog_number ; -- Begin function nl_service_source_catalog_number
	.p2align	2
_nl_service_source_catalog_number:      ; @nl_service_source_catalog_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	str	x4, [sp, #48]
	ldur	x8, [x29, #-24]
	subs	x8, x8, #1
	b.ne	LBB6_14
	b	LBB6_1
LBB6_1:
	ldur	x8, [x29, #-32]
	tbnz	x8, #63, LBB6_14
	b	LBB6_2
LBB6_2:
	ldur	x8, [x29, #-32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB6_14
	b	LBB6_3
LBB6_3:
	ldr	x8, [sp, #48]
	tbnz	x8, #63, LBB6_14
	b	LBB6_4
LBB6_4:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	bl	_source_type
	str	x0, [sp, #40]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB6_7
	b	LBB6_5
LBB6_5:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_7
	b	LBB6_6
LBB6_6:
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_7:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.ne	LBB6_10
	b	LBB6_8
LBB6_8:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_10
	b	LBB6_9
LBB6_9:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #32]
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_10:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ne	LBB6_13
	b	LBB6_11
LBB6_11:
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB6_13
	b	LBB6_12
LBB6_12:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #48]
	add	x8, x8, x9, lsl #5
	ldr	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_13:
	b	LBB6_14
LBB6_14:
	ldur	x8, [x29, #-24]
	subs	x8, x8, #2
	b.ne	LBB6_49
	b	LBB6_15
LBB6_15:
	ldur	x8, [x29, #-32]
	tbnz	x8, #63, LBB6_49
	b	LBB6_16
LBB6_16:
	ldur	x8, [x29, #-32]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB6_49
	b	LBB6_17
LBB6_17:
	ldr	x8, [sp, #48]
	tbnz	x8, #63, LBB6_49
	b	LBB6_18
LBB6_18:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	bl	_source_method
	str	x0, [sp, #32]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB6_21
	b	LBB6_19
LBB6_19:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_21
	b	LBB6_20
LBB6_20:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #32]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_21:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.ne	LBB6_24
	b	LBB6_22
LBB6_22:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_24
	b	LBB6_23
LBB6_23:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #36]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_24:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ne	LBB6_27
	b	LBB6_25
LBB6_25:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_27
	b	LBB6_26
LBB6_26:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_27:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #3
	b.ne	LBB6_30
	b	LBB6_28
LBB6_28:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_30
	b	LBB6_29
LBB6_29:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #44]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_30:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #4
	b.ne	LBB6_33
	b	LBB6_31
LBB6_31:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB6_33
	b	LBB6_32
LBB6_32:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #56]
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_33:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #10
	b.ne	LBB6_36
	b	LBB6_34
LBB6_34:
	ldr	x8, [sp, #48]
	subs	x8, x8, #2
	b.ge	LBB6_36
	b	LBB6_35
LBB6_35:
	ldr	x8, [sp, #32]
	add	x8, x8, #64
	ldr	x9, [sp, #48]
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_36:
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #32]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB6_48
	b	LBB6_37
LBB6_37:
	ldr	x8, [sp, #32]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #48]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldur	x8, [x29, #-40]
	subs	x8, x8, #5
	b.ne	LBB6_39
	b	LBB6_38
LBB6_38:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_39:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #6
	b.ne	LBB6_41
	b	LBB6_40
LBB6_40:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #28]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_41:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #7
	b.ne	LBB6_43
	b	LBB6_42
LBB6_42:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #32]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_43:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #8
	b.ne	LBB6_45
	b	LBB6_44
LBB6_44:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #36]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_45:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #9
	b.ne	LBB6_47
	b	LBB6_46
LBB6_46:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_47:
	b	LBB6_48
LBB6_48:
	b	LBB6_49
LBB6_49:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-8]
	b	LBB6_50
LBB6_50:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_catalog_view ; -- Begin function nl_service_source_catalog_view
	.p2align	2
_nl_service_source_catalog_view:        ; @nl_service_source_catalog_view
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #33008                      ; =0x80f0
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #240
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #200]
	str	x1, [sp, #192]
	str	x2, [sp, #184]
	str	x3, [sp, #176]
	ldr	x8, [sp, #176]
	cbz	x8, LBB7_4
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #192]
	cbnz	x8, LBB7_3
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp, #184]
	cbnz	x8, LBB7_4
	b	LBB7_3
LBB7_3:
	ldr	x0, [sp, #200]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_count
	tbz	x0, #63, LBB7_5
	b	LBB7_4
LBB7_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #215]
	b	LBB7_63
LBB7_5:
	add	x0, sp, #216
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x1, #32784                      ; =0x8010
	bl	_bzero
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	mov	x9, #32776                      ; =0x8008
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x8, [sp, #200]
	subs	x8, x8, #1
	b.ne	LBB7_7
	b	LBB7_6
LBB7_6:
	adrp	x8, l_.str.1@PAGE
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB7_8
LBB7_7:
	ldr	x10, [sp, #200]
	adrp	x9, l_.str.3@PAGE
	add	x9, x9, l_.str.3@PAGEOFF
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	subs	x10, x10, #2
	csel	x8, x8, x9, eq
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB7_8
LBB7_8:
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	add	x0, sp, #216
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_catalog_text
	ldr	x0, [sp, #200]
	bl	_source_interface
	mov	x1, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_catalog_string
	ldr	x0, [sp, #200]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_catalog_number
	ldr	x0, [sp, #200]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_count
	mov	x1, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_catalog_number
	str	xzr, [sp, #168]
	b	LBB7_9
LBB7_9:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_11 Depth 2
                                        ;     Child Loop BB7_15 Depth 2
                                        ;     Child Loop BB7_19 Depth 2
                                        ;       Child Loop BB7_21 Depth 3
	ldr	x8, [sp, #168]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #200]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB7_28
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_9 Depth=1
	str	xzr, [sp, #160]
	b	LBB7_11
LBB7_11:                                ;   Parent Loop BB7_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #160]
	subs	x8, x8, #2
	b.ge	LBB7_14
	b	LBB7_12
LBB7_12:                                ;   in Loop: Header=BB7_11 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #168]
	ldr	x3, [sp, #160]
	mov	x1, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_string
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_11 Depth=2
	ldr	x8, [sp, #160]
	add	x8, x8, #1
	str	x8, [sp, #160]
	b	LBB7_11
LBB7_14:                                ;   in Loop: Header=BB7_9 Depth=1
	str	xzr, [sp, #152]
	b	LBB7_15
LBB7_15:                                ;   Parent Loop BB7_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #152]
	subs	x8, x8, #2
	b.ge	LBB7_18
	b	LBB7_16
LBB7_16:                                ;   in Loop: Header=BB7_15 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #168]
	ldr	x3, [sp, #152]
	mov	x1, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_number
	b	LBB7_17
LBB7_17:                                ;   in Loop: Header=BB7_15 Depth=2
	ldr	x8, [sp, #152]
	add	x8, x8, #1
	str	x8, [sp, #152]
	b	LBB7_15
LBB7_18:                                ;   in Loop: Header=BB7_9 Depth=1
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #168]
	mov	x3, #1                          ; =0x1
	mov	x1, x3
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_number
	str	x0, [sp, #144]
	str	xzr, [sp, #136]
	b	LBB7_19
LBB7_19:                                ;   Parent Loop BB7_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB7_21 Depth 3
	ldr	x8, [sp, #136]
	ldr	x9, [sp, #144]
	subs	x8, x8, x9
	b.ge	LBB7_26
	b	LBB7_20
LBB7_20:                                ;   in Loop: Header=BB7_19 Depth=2
	mov	x8, #2                          ; =0x2
	str	x8, [sp, #128]
	b	LBB7_21
LBB7_21:                                ;   Parent Loop BB7_9 Depth=1
                                        ;     Parent Loop BB7_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x8, [sp, #128]
	subs	x8, x8, #5
	b.ge	LBB7_24
	b	LBB7_22
LBB7_22:                                ;   in Loop: Header=BB7_21 Depth=3
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #168]
	ldr	x3, [sp, #128]
	ldr	x4, [sp, #136]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_string
	b	LBB7_23
LBB7_23:                                ;   in Loop: Header=BB7_21 Depth=3
	ldr	x8, [sp, #128]
	add	x8, x8, #1
	str	x8, [sp, #128]
	b	LBB7_21
LBB7_24:                                ;   in Loop: Header=BB7_19 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #168]
	ldr	x4, [sp, #136]
	mov	x1, #1                          ; =0x1
	mov	x3, #2                          ; =0x2
	bl	_nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_number
	b	LBB7_25
LBB7_25:                                ;   in Loop: Header=BB7_19 Depth=2
	ldr	x8, [sp, #136]
	add	x8, x8, #1
	str	x8, [sp, #136]
	b	LBB7_19
LBB7_26:                                ;   in Loop: Header=BB7_9 Depth=1
	b	LBB7_27
LBB7_27:                                ;   in Loop: Header=BB7_9 Depth=1
	ldr	x8, [sp, #168]
	add	x8, x8, #1
	str	x8, [sp, #168]
	b	LBB7_9
LBB7_28:
	str	xzr, [sp, #120]
	b	LBB7_29
LBB7_29:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_31 Depth 2
                                        ;     Child Loop BB7_35 Depth 2
                                        ;     Child Loop BB7_39 Depth 2
                                        ;       Child Loop BB7_41 Depth 3
                                        ;       Child Loop BB7_45 Depth 3
                                        ;     Child Loop BB7_51 Depth 2
	ldr	x8, [sp, #120]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #200]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_count
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.ge	LBB7_56
	b	LBB7_30
LBB7_30:                                ;   in Loop: Header=BB7_29 Depth=1
	str	xzr, [sp, #112]
	b	LBB7_31
LBB7_31:                                ;   Parent Loop BB7_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #112]
	subs	x8, x8, #4
	b.ge	LBB7_34
	b	LBB7_32
LBB7_32:                                ;   in Loop: Header=BB7_31 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x3, [sp, #112]
	mov	x1, #2                          ; =0x2
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_string
	b	LBB7_33
LBB7_33:                                ;   in Loop: Header=BB7_31 Depth=2
	ldr	x8, [sp, #112]
	add	x8, x8, #1
	str	x8, [sp, #112]
	b	LBB7_31
LBB7_34:                                ;   in Loop: Header=BB7_29 Depth=1
	str	xzr, [sp, #104]
	b	LBB7_35
LBB7_35:                                ;   Parent Loop BB7_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #104]
	subs	x8, x8, #5
	b.ge	LBB7_38
	b	LBB7_36
LBB7_36:                                ;   in Loop: Header=BB7_35 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x3, [sp, #104]
	mov	x1, #2                          ; =0x2
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_number
	b	LBB7_37
LBB7_37:                                ;   in Loop: Header=BB7_35 Depth=2
	ldr	x8, [sp, #104]
	add	x8, x8, #1
	str	x8, [sp, #104]
	b	LBB7_35
LBB7_38:                                ;   in Loop: Header=BB7_29 Depth=1
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	mov	x1, #2                          ; =0x2
	mov	x3, #4                          ; =0x4
	mov	x4, #0                          ; =0x0
	bl	_nl_service_source_catalog_number
	str	x0, [sp, #96]
	str	xzr, [sp, #88]
	b	LBB7_39
LBB7_39:                                ;   Parent Loop BB7_29 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB7_41 Depth 3
                                        ;       Child Loop BB7_45 Depth 3
	ldr	x8, [sp, #88]
	ldr	x9, [sp, #96]
	subs	x8, x8, x9
	b.ge	LBB7_50
	b	LBB7_40
LBB7_40:                                ;   in Loop: Header=BB7_39 Depth=2
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #80]
	b	LBB7_41
LBB7_41:                                ;   Parent Loop BB7_29 Depth=1
                                        ;     Parent Loop BB7_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x8, [sp, #80]
	subs	x8, x8, #7
	b.ge	LBB7_44
	b	LBB7_42
LBB7_42:                                ;   in Loop: Header=BB7_41 Depth=3
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x3, [sp, #80]
	ldr	x4, [sp, #88]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_string
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_string
	b	LBB7_43
LBB7_43:                                ;   in Loop: Header=BB7_41 Depth=3
	ldr	x8, [sp, #80]
	add	x8, x8, #1
	str	x8, [sp, #80]
	b	LBB7_41
LBB7_44:                                ;   in Loop: Header=BB7_39 Depth=2
	mov	x8, #5                          ; =0x5
	str	x8, [sp, #72]
	b	LBB7_45
LBB7_45:                                ;   Parent Loop BB7_29 Depth=1
                                        ;     Parent Loop BB7_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x8, [sp, #72]
	subs	x8, x8, #10
	b.ge	LBB7_48
	b	LBB7_46
LBB7_46:                                ;   in Loop: Header=BB7_45 Depth=3
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x3, [sp, #72]
	ldr	x4, [sp, #88]
	mov	x1, #2                          ; =0x2
	bl	_nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, #216
	bl	_catalog_number
	b	LBB7_47
LBB7_47:                                ;   in Loop: Header=BB7_45 Depth=3
	ldr	x8, [sp, #72]
	add	x8, x8, #1
	str	x8, [sp, #72]
	b	LBB7_45
LBB7_48:                                ;   in Loop: Header=BB7_39 Depth=2
	b	LBB7_49
LBB7_49:                                ;   in Loop: Header=BB7_39 Depth=2
	ldr	x8, [sp, #88]
	add	x8, x8, #1
	str	x8, [sp, #88]
	b	LBB7_39
LBB7_50:                                ;   in Loop: Header=BB7_29 Depth=1
	str	xzr, [sp, #64]
	b	LBB7_51
LBB7_51:                                ;   Parent Loop BB7_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #64]
	subs	x8, x8, #2
	b.ge	LBB7_54
	b	LBB7_52
LBB7_52:                                ;   in Loop: Header=BB7_51 Depth=2
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x4, [sp, #64]
	mov	x1, #2                          ; =0x2
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x3, #10                         ; =0xa
	bl	_nl_service_source_catalog_number
	mov	x1, x0
	add	x0, sp, #216
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_catalog_number
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp, #200]
	ldr	x2, [sp, #120]
	ldr	x4, [sp, #64]
	mov	x3, #7                          ; =0x7
	bl	_nl_service_source_catalog_string
	mov	x1, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_catalog_string
	b	LBB7_53
LBB7_53:                                ;   in Loop: Header=BB7_51 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB7_51
LBB7_54:                                ;   in Loop: Header=BB7_29 Depth=1
	b	LBB7_55
LBB7_55:                                ;   in Loop: Header=BB7_29 Depth=1
	ldr	x8, [sp, #120]
	add	x8, x8, #1
	str	x8, [sp, #120]
	b	LBB7_29
LBB7_56:
	mov	x9, #32776                      ; =0x8008
	add	x8, sp, #216
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB7_59
	b	LBB7_57
LBB7_57:
	ldr	x8, [sp, #192]
	cbz	x8, LBB7_60
	b	LBB7_58
LBB7_58:
	ldr	x8, [sp, #184]
	mov	x10, #32768                     ; =0x8000
	add	x9, sp, #216
	ldr	x9, [x9, x10]
	subs	x8, x8, x9
	b.hi	LBB7_60
	b	LBB7_59
LBB7_59:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #215]
	b	LBB7_63
LBB7_60:
	ldr	x8, [sp, #192]
	cbz	x8, LBB7_62
	b	LBB7_61
LBB7_61:
	ldr	x0, [sp, #192]
	mov	x8, #32768                      ; =0x8000
	add	x1, sp, #216
	ldr	x8, [x1, x8]
	add	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB7_62
LBB7_62:
	mov	x9, #32768                      ; =0x8000
	add	x8, sp, #216
	ldr	x8, [x8, x9]
	add	x8, x8, #1
	ldr	x9, [sp, #176]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #215]
	b	LBB7_63
LBB7_63:
	ldrb	w8, [sp, #215]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB7_65
	b	LBB7_64
LBB7_64:
	bl	___stack_chk_fail
LBB7_65:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #240
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_text
_catalog_text:                          ; @catalog_text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	x9, #32776                      ; =0x8008
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	mov	x10, #32768                     ; =0x8000
	ldr	x10, [x9, x10]
	mov	x9, #32768                      ; =0x8000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.lo	LBB8_3
	b	LBB8_2
LBB8_2:
	ldur	x8, [x29, #-8]
	mov	x9, #32776                      ; =0x8008
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB8_4
LBB8_3:
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-8]
	mov	x10, #32768                     ; =0x8000
	str	x10, [sp]                       ; 8-byte Folded Spill
	ldr	x9, [x9, x10]
	add	x0, x8, x9
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldr	x11, [sp, #8]
	ldur	x8, [x29, #-8]
	add	x9, x8, #8, lsl #12             ; =32768
	ldr	x8, [x9]
	add	x8, x8, x11
	str	x8, [x9]
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, x10]
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB8_4
LBB8_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_string
_catalog_string:                        ; @catalog_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x0, [sp, #24]
	bl	_strlen
	mov	x8, sp
	str	x0, [x8]
	add	x0, sp, #40
	mov	x3, #32                         ; =0x20
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.4@PAGE
	add	x4, x4, l_.str.4@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	tbnz	w8, #31, LBB9_2
	b	LBB9_1
LBB9_1:
	ldrsw	x8, [sp, #20]
	subs	x8, x8, #32
	b.lo	LBB9_3
	b	LBB9_2
LBB9_2:
	ldr	x8, [sp, #32]
	mov	x9, #32776                      ; =0x8008
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB9_4
LBB9_3:
	ldr	x0, [sp, #32]
	add	x1, sp, #40
	bl	_catalog_text
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #24]
	bl	_catalog_text
	ldr	x0, [sp, #32]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_catalog_text
	b	LBB9_4
LBB9_4:
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB9_6
	b	LBB9_5
LBB9_5:
	bl	___stack_chk_fail
LBB9_6:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_number
_catalog_number:                        ; @catalog_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #24]
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #40
	mov	x3, #32                         ; =0x20
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.6@PAGE
	add	x4, x4, l_.str.6@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	tbnz	w8, #31, LBB10_2
	b	LBB10_1
LBB10_1:
	ldrsw	x8, [sp, #20]
	subs	x8, x8, #32
	b.lo	LBB10_3
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #32]
	mov	x9, #32776                      ; =0x8008
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB10_4
LBB10_3:
	ldr	x0, [sp, #32]
	add	x1, sp, #40
	bl	_catalog_text
	b	LBB10_4
LBB10_4:
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB10_6
	b	LBB10_5
LBB10_5:
	bl	___stack_chk_fail
LBB10_6:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_catalog_string  ; -- Begin function nl_file_source_catalog_string
	.p2align	2
_nl_file_source_catalog_string:         ; @nl_file_source_catalog_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x1, [x29, #-8]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #8]
	ldr	x4, [sp]
	mov	x0, #1                          ; =0x1
	bl	_nl_service_source_catalog_string
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_catalog_number  ; -- Begin function nl_file_source_catalog_number
	.p2align	2
_nl_file_source_catalog_number:         ; @nl_file_source_catalog_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x1, [x29, #-8]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #8]
	ldr	x4, [sp]
	mov	x0, #1                          ; =0x1
	bl	_nl_service_source_catalog_number
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_catalog_view    ; -- Begin function nl_file_source_catalog_view
	.p2align	2
_nl_file_source_catalog_view:           ; @nl_file_source_catalog_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x1, [x29, #-8]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #8]
	mov	x0, #1                          ; =0x1
	bl	_nl_service_source_catalog_view
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

l_.str.1:                               ; @.str.1
	.asciz	"file-source-catalog1;"

l_.str.2:                               ; @.str.2
	.asciz	"socket-source-catalog1;"

l_.str.3:                               ; @.str.3
	.asciz	"websocket-source-catalog1;"

l_.str.4:                               ; @.str.4
	.asciz	"%zu:"

l_.str.5:                               ; @.str.5
	.asciz	";"

l_.str.6:                               ; @.str.6
	.asciz	"#%lld;"

.subsections_via_symbols
