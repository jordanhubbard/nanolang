	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_source_catalog_private_file_plan_build ; -- Begin function nl_source_catalog_private_file_plan_build
	.p2align	2
_nl_source_catalog_private_file_plan_build: ; @nl_source_catalog_private_file_plan_build
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x0, [sp, #16]
	bl	_document_equal
	tbnz	w0, #0, LBB0_3
	b	LBB0_2
LBB0_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_3:
	mov	x0, #16                         ; =0x10
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB0_5
	b	LBB0_4
LBB0_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_5:
	ldr	x9, [sp]
	adrp	x8, _methods@PAGE
	add	x8, x8, _methods@PAGEOFF
	str	x8, [x9]
	ldr	x9, [sp]
	adrp	x8, _types@PAGE
	add	x8, x8, _types@PAGEOFF
	str	x8, [x9, #8]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB0_6
LBB0_6:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function document_equal
_document_equal:                        ; @document_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	adrp	x1, _catalog@PAGE
	add	x1, x1, _catalog@PAGEOFF
	bl	_nl_service_catalog_document_equal
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_free ; -- Begin function nl_source_catalog_private_file_plan_free
	.p2align	2
_nl_source_catalog_private_file_plan_free: ; @nl_source_catalog_private_file_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_storage_size ; -- Begin function nl_source_catalog_private_file_plan_storage_size
	.p2align	2
_nl_source_catalog_private_file_plan_storage_size: ; @nl_source_catalog_private_file_plan_storage_size
	.cfi_startproc
; %bb.0:
	mov	x0, #16                         ; =0x10
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_interface ; -- Begin function nl_source_catalog_private_file_plan_interface
	.p2align	2
_nl_source_catalog_private_file_plan_interface: ; @nl_source_catalog_private_file_plan_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x10, [sp, #8]
	mov	x9, #0                          ; =0x0
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	subs	x10, x10, #0
	csel	x0, x8, x9, ne
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_method_count ; -- Begin function nl_source_catalog_private_file_plan_method_count
	.p2align	2
_nl_source_catalog_private_file_plan_method_count: ; @nl_source_catalog_private_file_plan_method_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x10, [sp, #8]
	mov	x9, #0                          ; =0x0
	mov	x8, #5                          ; =0x5
	subs	x10, x10, #0
	csel	x0, x8, x9, ne
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_type_count ; -- Begin function nl_source_catalog_private_file_plan_type_count
	.p2align	2
_nl_source_catalog_private_file_plan_type_count: ; @nl_source_catalog_private_file_plan_type_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x10, [sp, #8]
	mov	x9, #0                          ; =0x0
	mov	x8, #8                          ; =0x8
	subs	x10, x10, #0
	csel	x0, x8, x9, ne
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_method ; -- Begin function nl_source_catalog_private_file_plan_method
	.p2align	2
_nl_source_catalog_private_file_plan_method: ; @nl_source_catalog_private_file_plan_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB7_3
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #16]
	subs	x8, x8, #5
	b.hs	LBB7_3
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB7_4
LBB7_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB7_4
LBB7_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_plan_type ; -- Begin function nl_source_catalog_private_file_plan_type
	.p2align	2
_nl_source_catalog_private_file_plan_type: ; @nl_source_catalog_private_file_plan_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #16]
	subs	x8, x8, #8
	b.hs	LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_catalog_interface ; -- Begin function nl_source_catalog_private_file_catalog_interface
	.p2align	2
_nl_source_catalog_private_file_catalog_interface: ; @nl_source_catalog_private_file_catalog_interface
	.cfi_startproc
; %bb.0:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_catalog_method ; -- Begin function nl_source_catalog_private_file_catalog_method
	.p2align	2
_nl_source_catalog_private_file_catalog_method: ; @nl_source_catalog_private_file_catalog_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #5
	b.hs	LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #8]
	mov	x9, #96                         ; =0x60
	mul	x9, x8, x9
	adrp	x8, _methods@PAGE
	add	x8, x8, _methods@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_source_catalog_private_file_catalog_type ; -- Begin function nl_source_catalog_private_file_catalog_type
	.p2align	2
_nl_source_catalog_private_file_catalog_type: ; @nl_source_catalog_private_file_catalog_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #8
	b.hs	LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #8]
	mov	x9, #40                         ; =0x28
	mul	x9, x8, x9
	adrp	x8, _types@PAGE
	add	x8, x8, _types@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_document_equal
_nl_service_catalog_document_equal:     ; @nl_service_catalog_document_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB12_12
	b	LBB12_1
LBB12_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	cbnz	w8, LBB12_12
	b	LBB12_2
LBB12_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_12
	b	LBB12_3
LBB12_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_12
	b	LBB12_4
LBB12_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ne	LBB12_12
	b	LBB12_5
LBB12_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.ne	LBB12_12
	b	LBB12_6
LBB12_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #64]
	subs	x8, x8, #1
	b.ne	LBB12_12
	b	LBB12_7
LBB12_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #80]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.ne	LBB12_12
	b	LBB12_8
LBB12_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	cbz	x8, LBB12_12
	b	LBB12_9
LBB12_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	cbz	x8, LBB12_12
	b	LBB12_10
LBB12_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB12_12
	b	LBB12_11
LBB12_11:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	cbnz	x8, LBB12_13
	b	LBB12_12
LBB12_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_13:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_16
	b	LBB12_14
LBB12_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_16
	b	LBB12_15
LBB12_15:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB12_17
	b	LBB12_16
LBB12_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_17:
	stur	xzr, [x29, #-32]
	b	LBB12_18
LBB12_18:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB12_24
	b	LBB12_19
LBB12_19:                               ;   in Loop: Header=BB12_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x1, [x8, x9]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_21
	b	LBB12_20
LBB12_20:                               ;   in Loop: Header=BB12_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB12_22
	b	LBB12_21
LBB12_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_22:                               ;   in Loop: Header=BB12_18 Depth=1
	b	LBB12_23
LBB12_23:                               ;   in Loop: Header=BB12_18 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB12_18
LBB12_24:
	stur	xzr, [x29, #-40]
	b	LBB12_25
LBB12_25:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_33 Depth 2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB12_48
	b	LBB12_26
LBB12_26:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-40]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-40]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-48]
	ldr	x0, [x8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_31
	b	LBB12_27
LBB12_27:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_31
	b	LBB12_28
LBB12_28:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	cbnz	w8, LBB12_31
	b	LBB12_29
LBB12_29:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB12_31
	b	LBB12_30
LBB12_30:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB12_32
	b	LBB12_31
LBB12_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_32:                               ;   in Loop: Header=BB12_25 Depth=1
	str	xzr, [sp, #64]
	b	LBB12_33
LBB12_33:                               ;   Parent Loop BB12_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB12_46
	b	LBB12_34
LBB12_34:                               ;   in Loop: Header=BB12_33 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #64]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #56]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #64]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	x0, [x8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_43
	b	LBB12_35
LBB12_35:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_43
	b	LBB12_36
LBB12_36:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_43
	b	LBB12_37
LBB12_37:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB12_43
	b	LBB12_38
LBB12_38:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #28]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.ne	LBB12_43
	b	LBB12_39
LBB12_39:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #32]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB12_43
	b	LBB12_40
LBB12_40:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #36]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.ne	LBB12_43
	b	LBB12_41
LBB12_41:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #40]
	cbnz	w8, LBB12_43
	b	LBB12_42
LBB12_42:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #44]
	cbz	w8, LBB12_44
	b	LBB12_43
LBB12_43:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_44:                               ;   in Loop: Header=BB12_33 Depth=2
	b	LBB12_45
LBB12_45:                               ;   in Loop: Header=BB12_33 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB12_33
LBB12_46:                               ;   in Loop: Header=BB12_25 Depth=1
	b	LBB12_47
LBB12_47:                               ;   in Loop: Header=BB12_25 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB12_25
LBB12_48:
	str	xzr, [sp, #40]
	b	LBB12_49
LBB12_49:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_63 Depth 2
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB12_72
	b	LBB12_50
LBB12_50:                               ;   in Loop: Header=BB12_49 Depth=1
	ldur	x8, [x29, #-16]
	mov	x10, #40                        ; =0x28
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #40]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_61
	b	LBB12_51
LBB12_51:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_61
	b	LBB12_52
LBB12_52:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB12_61
	b	LBB12_53
LBB12_53:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB12_61
	b	LBB12_54
LBB12_54:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #40]
	cbnz	x8, LBB12_61
	b	LBB12_55
LBB12_55:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB12_61
	b	LBB12_56
LBB12_56:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB12_61
	b	LBB12_57
LBB12_57:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB12_59
	b	LBB12_58
LBB12_58:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB12_61
	b	LBB12_59
LBB12_59:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB12_62
	b	LBB12_60
LBB12_60:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB12_62
	b	LBB12_61
LBB12_61:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_62:                               ;   in Loop: Header=BB12_49 Depth=1
	str	xzr, [sp, #16]
	b	LBB12_63
LBB12_63:                               ;   Parent Loop BB12_49 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB12_70
	b	LBB12_64
LBB12_64:                               ;   in Loop: Header=BB12_63 Depth=2
	ldr	x8, [sp, #32]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	add	x8, x8, x9, lsl #5
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	ldr	x8, [sp]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_67
	b	LBB12_65
LBB12_65:                               ;   in Loop: Header=BB12_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB12_67
	b	LBB12_66
LBB12_66:                               ;   in Loop: Header=BB12_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	ldr	x8, [sp]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB12_68
	b	LBB12_67
LBB12_67:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_68:                               ;   in Loop: Header=BB12_63 Depth=2
	b	LBB12_69
LBB12_69:                               ;   in Loop: Header=BB12_63 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB12_63
LBB12_70:                               ;   in Loop: Header=BB12_49 Depth=1
	b	LBB12_71
LBB12_71:                               ;   in Loop: Header=BB12_49 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #1
	str	x8, [sp, #40]
	b	LBB12_49
LBB12_72:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_73
LBB12_73:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_text_equal
_nl_service_catalog_text_equal:         ; @nl_service_catalog_text_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB13_3
	b	LBB13_2
LBB13_2:
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_4
LBB13_3:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_4
LBB13_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w0, ne
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/filesystem"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @catalog
_catalog:
	.quad	l_.str
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	_capabilities
	.quad	1                               ; 0x1
	.quad	_methods
	.quad	5                               ; 0x5
	.quad	_types
	.quad	8                               ; 0x8

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"filesystem"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/filesystem#io"

l_.str.3:                               ; @.str.3
	.asciz	"io"

l_.str.4:                               ; @.str.4
	.asciz	"1"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @capabilities
_capabilities:
	.quad	l_.str.5
	.quad	l_.str.6

	.section	__TEXT,__cstring,cstring_literals
l_.str.5:                               ; @.str.5
	.asciz	"cap:nanolang/filesystem.temp"

l_.str.6:                               ; @.str.6
	.asciz	"temp"

l_.str.7:                               ; @.str.7
	.asciz	"nsi:nanolang/filesystem#temp"

l_.str.8:                               ; @.str.8
	.asciz	"nsi_nanolang_filesystem_temp"

l_.str.9:                               ; @.str.9
	.asciz	"nsi.local-file.v1.temp"

l_.str.10:                              ; @.str.10
	.asciz	"nsi:nanolang/filesystem#File"

l_.str.11:                              ; @.str.11
	.asciz	"nsi:nanolang/filesystem#write_byte"

l_.str.12:                              ; @.str.12
	.asciz	"write_byte"

l_.str.13:                              ; @.str.13
	.asciz	"nsi_nanolang_filesystem_write_byte"

l_.str.14:                              ; @.str.14
	.asciz	"nsi.local-file.v1.write_byte"

l_.str.15:                              ; @.str.15
	.asciz	"nsi:nanolang/filesystem#rewind"

l_.str.16:                              ; @.str.16
	.asciz	"rewind"

l_.str.17:                              ; @.str.17
	.asciz	"nsi_nanolang_filesystem_rewind"

l_.str.18:                              ; @.str.18
	.asciz	"nsi.local-file.v1.rewind"

l_.str.19:                              ; @.str.19
	.asciz	"nsi:nanolang/filesystem#read_byte"

l_.str.20:                              ; @.str.20
	.asciz	"read_byte"

l_.str.21:                              ; @.str.21
	.asciz	"nsi_nanolang_filesystem_read_byte"

l_.str.22:                              ; @.str.22
	.asciz	"nsi.local-file.v1.read_byte"

l_.str.23:                              ; @.str.23
	.asciz	"nsi:nanolang/filesystem#close"

l_.str.24:                              ; @.str.24
	.asciz	"close"

l_.str.25:                              ; @.str.25
	.asciz	"nsi_nanolang_filesystem_close"

l_.str.26:                              ; @.str.26
	.asciz	"nsi.local-file.v1.close"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @methods
_methods:
	.quad	l_.str.7
	.quad	l_.str.6
	.quad	l_.str.8
	.quad	l_.str.9
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	19                              ; 0x13
	.long	0                               ; 0x0
	.quad	_temp_params
	.quad	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.10
	.space	16
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_write_params
	.quad	3                               ; 0x3
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.15
	.quad	l_.str.16
	.quad	l_.str.17
	.quad	l_.str.18
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_rewind_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.19
	.quad	l_.str.20
	.quad	l_.str.21
	.quad	l_.str.22
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_read_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.23
	.quad	l_.str.24
	.quad	l_.str.25
	.quad	l_.str.26
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.quad	_close_params
	.quad	2                               ; 0x2
	.long	2                               ; 0x2
	.space	4
	.quad	0
	.long	2                               ; 0x2
	.space	4
	.quad	0

	.section	__TEXT,__cstring,cstring_literals
l_.str.28:                              ; @.str.28
	.asciz	"nsi:nanolang/filesystem#temp.result"

l_.str.29:                              ; @.str.29
	.asciz	"result"

l_.str.30:                              ; @.str.30
	.asciz	"nsi:nanolang/filesystem#OpenResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @temp_params
_temp_params:
	.quad	l_.str.28
	.quad	l_.str.29
	.quad	l_.str.30
	.long	3                               ; 0x3
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.32:                              ; @.str.32
	.asciz	"nsi:nanolang/filesystem#write_byte.file"

l_.str.33:                              ; @.str.33
	.asciz	"file"

l_.str.34:                              ; @.str.34
	.asciz	"nsi:nanolang/filesystem#write_byte.value"

l_.str.35:                              ; @.str.35
	.asciz	"value"

l_.str.36:                              ; @.str.36
	.asciz	"nsi:core/int"

l_.str.37:                              ; @.str.37
	.asciz	"nsi:nanolang/filesystem#write_byte.result"

l_.str.38:                              ; @.str.38
	.asciz	"nsi:nanolang/filesystem#WriteResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @write_params
_write_params:
	.quad	l_.str.32
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.34
	.quad	l_.str.35
	.quad	l_.str.36
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.37
	.quad	l_.str.29
	.quad	l_.str.38
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.40:                              ; @.str.40
	.asciz	"nsi:nanolang/filesystem#rewind.file"

l_.str.41:                              ; @.str.41
	.asciz	"nsi:nanolang/filesystem#rewind.result"

l_.str.42:                              ; @.str.42
	.asciz	"nsi:nanolang/filesystem#PositionResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @rewind_params
_rewind_params:
	.quad	l_.str.40
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.41
	.quad	l_.str.29
	.quad	l_.str.42
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.44:                              ; @.str.44
	.asciz	"nsi:nanolang/filesystem#read_byte.file"

l_.str.45:                              ; @.str.45
	.asciz	"nsi:nanolang/filesystem#read_byte.result"

l_.str.46:                              ; @.str.46
	.asciz	"nsi:nanolang/filesystem#ReadResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @read_params
_read_params:
	.quad	l_.str.44
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.45
	.quad	l_.str.29
	.quad	l_.str.46
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.48:                              ; @.str.48
	.asciz	"nsi:nanolang/filesystem#close.file"

l_.str.49:                              ; @.str.49
	.asciz	"nsi:nanolang/filesystem#close.result"

l_.str.50:                              ; @.str.50
	.asciz	"nsi:nanolang/filesystem#CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @close_params
_close_params:
	.quad	l_.str.48
	.quad	l_.str.33
	.quad	l_.str.10
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.49
	.quad	l_.str.29
	.quad	l_.str.50
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.52:                              ; @.str.52
	.asciz	"File"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:nanolang/filesystem#FileError"

l_.str.54:                              ; @.str.54
	.asciz	"FileError"

l_.str.55:                              ; @.str.55
	.asciz	"nsi:nanolang/filesystem#ReadByte"

l_.str.56:                              ; @.str.56
	.asciz	"ReadByte"

l_.str.57:                              ; @.str.57
	.asciz	"OpenResult"

l_.str.58:                              ; @.str.58
	.asciz	"WriteResult"

l_.str.59:                              ; @.str.59
	.asciz	"PositionResult"

l_.str.60:                              ; @.str.60
	.asciz	"ReadResult"

l_.str.61:                              ; @.str.61
	.asciz	"CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @types
_types:
	.quad	l_.str.10
	.quad	l_.str.52
	.long	6                               ; 0x6
	.space	4
	.quad	0
	.quad	0                               ; 0x0
	.quad	l_.str.53
	.quad	l_.str.54
	.long	1                               ; 0x1
	.space	4
	.quad	_error_fields
	.quad	7                               ; 0x7
	.quad	l_.str.55
	.quad	l_.str.56
	.long	1                               ; 0x1
	.space	4
	.quad	_byte_fields
	.quad	2                               ; 0x2
	.quad	l_.str.30
	.quad	l_.str.57
	.long	2                               ; 0x2
	.space	4
	.quad	_OpenResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.38
	.quad	l_.str.58
	.long	2                               ; 0x2
	.space	4
	.quad	_WriteResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.42
	.quad	l_.str.59
	.long	2                               ; 0x2
	.space	4
	.quad	_PositionResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.46
	.quad	l_.str.60
	.long	2                               ; 0x2
	.space	4
	.quad	_ReadResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.50
	.quad	l_.str.61
	.long	2                               ; 0x2
	.space	4
	.quad	_CloseResult_cases
	.quad	2                               ; 0x2

	.section	__TEXT,__cstring,cstring_literals
l_.str.63:                              ; @.str.63
	.asciz	"nsi:nanolang/filesystem#FileError.status"

l_.str.64:                              ; @.str.64
	.asciz	"status"

l_.str.65:                              ; @.str.65
	.asciz	"nsi:nanolang/filesystem#FileError.host_errno"

l_.str.66:                              ; @.str.66
	.asciz	"host_errno"

l_.str.67:                              ; @.str.67
	.asciz	"nsi:nanolang/filesystem#FileError.cleanup_errno"

l_.str.68:                              ; @.str.68
	.asciz	"cleanup_errno"

l_.str.69:                              ; @.str.69
	.asciz	"nsi:nanolang/filesystem#FileError.bytes"

l_.str.70:                              ; @.str.70
	.asciz	"bytes"

l_.str.71:                              ; @.str.71
	.asciz	"nsi:nanolang/filesystem#FileError.eof"

l_.str.72:                              ; @.str.72
	.asciz	"eof"

l_.str.73:                              ; @.str.73
	.asciz	"nsi:core/bool"

l_.str.74:                              ; @.str.74
	.asciz	"nsi:nanolang/filesystem#FileError.consumed"

l_.str.75:                              ; @.str.75
	.asciz	"consumed"

l_.str.76:                              ; @.str.76
	.asciz	"nsi:nanolang/filesystem#FileError.cleanup_failed"

l_.str.77:                              ; @.str.77
	.asciz	"cleanup_failed"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @error_fields
_error_fields:
	.quad	l_.str.63
	.quad	l_.str.64
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.65
	.quad	l_.str.66
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.67
	.quad	l_.str.68
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.69
	.quad	l_.str.70
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.71
	.quad	l_.str.72
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.74
	.quad	l_.str.75
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.76
	.quad	l_.str.77
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.79:                              ; @.str.79
	.asciz	"nsi:nanolang/filesystem#ReadByte.value"

l_.str.80:                              ; @.str.80
	.asciz	"nsi:nanolang/filesystem#ReadByte.eof"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @byte_fields
_byte_fields:
	.quad	l_.str.79
	.quad	l_.str.35
	.quad	l_.str.36
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.80
	.quad	l_.str.72
	.quad	l_.str.73
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.82:                              ; @.str.82
	.asciz	"nsi:nanolang/filesystem#OpenResult.Ok"

l_.str.83:                              ; @.str.83
	.asciz	"Ok"

l_.str.84:                              ; @.str.84
	.asciz	"nsi:nanolang/filesystem#OpenResult.Error"

l_.str.85:                              ; @.str.85
	.asciz	"Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @OpenResult_cases
_OpenResult_cases:
	.quad	l_.str.82
	.quad	l_.str.83
	.quad	l_.str.10
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.84
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.87:                              ; @.str.87
	.asciz	"nsi:nanolang/filesystem#WriteResult.Ok"

l_.str.88:                              ; @.str.88
	.asciz	"nsi:nanolang/filesystem#WriteResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @WriteResult_cases
_WriteResult_cases:
	.quad	l_.str.87
	.quad	l_.str.83
	.quad	l_.str.36
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.88
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.90:                              ; @.str.90
	.asciz	"nsi:nanolang/filesystem#PositionResult.Ok"

l_.str.91:                              ; @.str.91
	.asciz	"nsi:nanolang/filesystem#PositionResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @PositionResult_cases
_PositionResult_cases:
	.quad	l_.str.90
	.quad	l_.str.83
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.91
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.93:                              ; @.str.93
	.asciz	"nsi:nanolang/filesystem#ReadResult.Ok"

l_.str.94:                              ; @.str.94
	.asciz	"nsi:nanolang/filesystem#ReadResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ReadResult_cases
_ReadResult_cases:
	.quad	l_.str.93
	.quad	l_.str.83
	.quad	l_.str.55
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.94
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.96:                              ; @.str.96
	.asciz	"nsi:nanolang/filesystem#CloseResult.Ok"

l_.str.97:                              ; @.str.97
	.asciz	"nsi:nanolang/filesystem#CloseResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @CloseResult_cases
_CloseResult_cases:
	.quad	l_.str.96
	.quad	l_.str.83
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.97
	.quad	l_.str.85
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

.subsections_via_symbols
