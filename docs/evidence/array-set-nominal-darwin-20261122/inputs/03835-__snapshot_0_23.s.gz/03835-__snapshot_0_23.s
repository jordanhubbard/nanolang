	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_values_storage_bound ; -- Begin function nl_socket_values_storage_bound
	.p2align	2
_nl_socket_values_storage_bound:        ; @nl_socket_values_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, sp, #8
	bl	_nl_socket_service_storage_bound
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB0_4
; %bb.2:
	ldr	x8, [sp, #8]
	mov	x9, #-5753                      ; =0xffffffffffffe987
	cmp	x8, x9
	b.hi	LBB0_4
; %bb.3:
	mov	w9, #5752                       ; =0x1678
	add	x8, x8, x9
	str	x8, [x19]
	mov	w0, #1                          ; =0x1
LBB0_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB0_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_create        ; -- Begin function nl_socket_values_create
	.p2align	2
_nl_socket_values_create:               ; @nl_socket_values_create
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB1_3
LBB1_2:
	mov	w0, #1                          ; =0x1
	ret
LBB1_3:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	adrp	x20, _sv_identity@PAGE
	ldr	x8, [x20, _sv_identity@PAGEOFF]
	cmn	x8, #1
	b.eq	LBB1_7
; %bb.4:
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #5752                       ; =0x1678
	bl	_calloc
	cbz	x0, LBB1_8
; %bb.5:
	mov	x19, x0
	add	x8, sp, #8
	add	x0, x0, #8
	bl	_nl_socket_service_create
	ldr	w22, [sp, #8]
	cbz	w22, LBB1_9
; %bb.6:
	mov	x0, x19
	bl	_free
	mov	w8, #8                          ; =0x8
	mov	w9, #6                          ; =0x6
	cmp	w22, #10
	csel	w8, w9, w8, eq
	mov	w9, #5                          ; =0x5
	cmp	w22, #9
	csel	w0, w9, w8, eq
	b	LBB1_10
LBB1_7:
	mov	w0, #5                          ; =0x5
	b	LBB1_10
LBB1_8:
	mov	w0, #6                          ; =0x6
	b	LBB1_10
LBB1_9:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20, _sv_identity@PAGEOFF]
	add	x8, x8, #1
	str	x8, [x20, _sv_identity@PAGEOFF]
	str	x8, [x19]
	str	x19, [x21]
LBB1_10:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_connect       ; -- Begin function nl_socket_values_connect
	.p2align	2
_nl_socket_values_connect:              ; @nl_socket_values_connect
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_21
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB2_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB2_3:
	mov	w8, #1                          ; =0x1
	cbz	x1, LBB2_22
; %bb.4:
	cbz	x2, LBB2_22
; %bb.5:
	sub	x8, x2, x1
	cmp	x8, #27
	cset	w8, hi
	subs	x9, x1, x2
	cmp	x9, #23
	cset	w9, hi
	cmp	x1, x2
	csel	w8, w9, w8, hi
	cmp	w8, #1
	b.ne	LBB2_21
; %bb.6:
	ldr	x9, [x2]
	cbnz	x9, LBB2_22
; %bb.7:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB2_22
; %bb.8:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB2_22
; %bb.9:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB2_11
LBB2_10:                                ;   in Loop: Header=BB2_11 Depth=1
	add	x19, x19, #1
	add	x21, x21, #88
	cmp	x19, #64
	b.eq	LBB2_23
LBB2_11:                                ; =>This Inner Loop Header: Depth=1
	add	x8, x0, x21
	ldr	w9, [x8, #136]
	cbnz	w9, LBB2_10
; %bb.12:                               ;   in Loop: Header=BB2_11 Depth=1
	ldr	x8, [x8, #120]
	cmn	x8, #1
	b.eq	LBB2_10
; %bb.13:                               ;   in Loop: Header=BB2_11 Depth=1
	add	x20, x0, x21
	ldr	x8, [x20, #128]
	cmn	x8, #1
	b.eq	LBB2_10
; %bb.14:
	mov	x22, x2
	stp	xzr, xzr, [sp, #40]
	str	xzr, [sp, #56]
	mov	x23, x0
	ldr	x0, [x0, #8]
	mov	x8, sp
	add	x3, sp, #40
	mov	w2, #19                         ; =0x13
	bl	_nl_socket_acquire_tcp
	ldr	x8, [x20, #120]
	add	x10, x8, #1
	str	x10, [x20, #120]
	ldr	w8, [sp]
	cbz	w8, LBB2_25
; %bb.15:
	mov	w9, #3                          ; =0x3
	str	w9, [x20, #136]
	mov	x9, x23
	add	x11, x23, x21
	ldp	q0, q1, [sp]
	stur	q0, [x11, #168]
	stur	q1, [x11, #184]
	ldr	x12, [sp, #32]
	str	x12, [x11, #200]
	ldrb	w12, [sp, #34]
	ldrb	w13, [sp, #35]
	mov	x11, x22
	tbnz	w12, #0, LBB2_17
; %bb.16:
	tbz	w13, #0, LBB2_29
LBB2_17:
	ldr	x14, [x9, #32]
	cmn	x14, #1
	b.eq	LBB2_29
; %bb.18:
	ldr	w15, [sp, #36]
	cbz	x14, LBB2_26
; %bb.19:
	cmp	x14, #1
	b.ne	LBB2_28
; %bb.20:
	mov	w10, #80                        ; =0x50
	b	LBB2_27
LBB2_21:
	mov	w8, #1                          ; =0x1
LBB2_22:
	mov	x0, x8
	ret
LBB2_23:
	mov	w8, #5                          ; =0x5
LBB2_24:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	mov	x0, x8
	ret
LBB2_25:
	mov	w8, #2                          ; =0x2
	str	w8, [x20, #136]
	mov	x9, x23
	add	x8, x23, x21
	ldur	q0, [sp, #40]
	str	q0, [x8, #144]
	ldr	x11, [sp, #56]
	str	x11, [x8, #160]
	ldrb	w11, [sp, #36]
	strb	w11, [x8, #141]
	mov	x11, x22
	b	LBB2_29
LBB2_26:
	mov	w10, #40                        ; =0x28
LBB2_27:
	mov	x16, sp
	orr	x16, x16, #0x4
	add	x10, x9, x10
	str	w8, [x10]
	ldr	q0, [x16]
	stur	q0, [x10, #4]
	ldur	q0, [x16, #14]
	stur	q0, [x10, #18]
	strb	w12, [x10, #34]
	strb	w13, [x10, #35]
	str	w15, [x10, #36]
	ldr	x10, [x20, #120]
LBB2_28:
	add	x8, x14, #1
	str	x8, [x9, #32]
LBB2_29:
	mov	w8, #0                          ; =0x0
	ldr	x9, [x9]
	stp	x9, x10, [x11]
	stp	w19, wzr, [x11, #16]
	b	LBB2_24
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_endpoint_decode      ; -- Begin function nl_socket_endpoint_decode
	.p2align	2
_nl_socket_endpoint_decode:             ; @nl_socket_endpoint_decode
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB3_13
; %bb.1:
	cbz	x1, LBB3_13
; %bb.2:
	sub	x8, x1, x0
	cmp	x8, #55
	cset	w8, hi
	subs	x9, x0, x1
	cmp	x9, #27
	cset	w9, hi
	cmp	x0, x1
	csel	w8, w9, w8, hi
	cmp	w8, #1
	b.ne	LBB3_7
; %bb.3:
	ldr	x13, [x0]
	orr	x8, x13, #0x2
	cmp	x8, #6
	b.ne	LBB3_7
; %bb.4:
	ldr	x10, [x0, #40]
	sub	x8, x10, #16, lsl #12           ; =65536
	cmn	x8, #16, lsl #12                ; =65536
	b.ls	LBB3_7
; %bb.5:
	ldr	x9, [x0, #48]
	lsr	x8, x9, #32
	cbnz	x8, LBB3_7
; %bb.6:
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #8]
	movi.2d	v2, #0x000000ffffffff
	cmhi.2d	v0, v0, v2
	cmhi.2d	v1, v1, v2
	uzp1.4s	v0, v1, v0
	umaxv.4s	s0, v0
	fmov	w8, s0
	tbz	w8, #0, LBB3_8
LBB3_7:
	mov	w0, #0                          ; =0x0
	ret
LBB3_8:
	ldp	x12, x11, [x0, #24]
	ldp	x15, x14, [x0, #8]
	cmp	x13, #4
	b.ne	LBB3_12
; %bb.9:
	mov	w8, #0                          ; =0x0
	cbnz	x14, LBB3_13
; %bb.10:
	cbnz	x12, LBB3_13
; %bb.11:
	orr	x16, x11, x9
	cbnz	x16, LBB3_13
LBB3_12:
	str	w13, [x1]
	lsr	x8, x15, #24
	strb	w8, [x1, #4]
	lsr	x8, x15, #16
	strb	w8, [x1, #5]
	lsr	x8, x15, #8
	strb	w8, [x1, #6]
	lsr	x8, x14, #24
	strb	w15, [x1, #7]
	lsr	x13, x14, #16
	strb	w8, [x1, #8]
	lsr	x8, x14, #8
	strb	w13, [x1, #9]
	lsr	x13, x12, #24
	strb	w8, [x1, #10]
	lsr	x8, x12, #16
	strb	w14, [x1, #11]
	lsr	x14, x12, #8
	strb	w13, [x1, #12]
	lsr	x13, x11, #24
	strb	w8, [x1, #13]
	lsr	x8, x11, #16
	strb	w14, [x1, #14]
	lsr	x14, x11, #8
	strb	w12, [x1, #15]
	strb	w13, [x1, #16]
	strb	w8, [x1, #17]
	strb	w14, [x1, #18]
	strb	w11, [x1, #19]
	strh	w10, [x1, #20]
	strh	wzr, [x1, #22]
	mov	w8, #1                          ; =0x1
	str	w9, [x1, #24]
LBB3_13:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_begin_connect ; -- Begin function nl_socket_values_begin_connect
	.p2align	2
_nl_socket_values_begin_connect:        ; @nl_socket_values_begin_connect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	mov	w8, #1                          ; =0x1
	cbz	x1, LBB4_5
; %bb.1:
	cbz	x2, LBB4_5
; %bb.2:
	sub	x8, x2, x1
	cmp	x8, #55
	cset	w8, hi
	subs	x9, x1, x2
	cmp	x9, #23
	cset	w9, hi
	cmp	x1, x2
	csel	w8, w9, w8, hi
	cmp	w8, #1
	b.ne	LBB4_4
; %bb.3:
	stp	xzr, xzr, [sp, #8]
	str	wzr, [sp, #32]
	str	xzr, [sp, #24]
	mov	x8, x1
	add	x1, sp, #8
	mov	x19, x0
	mov	x0, x8
	mov	x20, x2
	bl	_nl_socket_endpoint_decode
	add	x1, sp, #8
	mov	x0, x19
	mov	x2, x20
	bl	_nl_socket_values_connect
	mov	x8, x0
	b	LBB4_5
LBB4_4:
	mov	w8, #1                          ; =0x1
LBB4_5:
	ldur	x9, [x29, #-24]
Lloh3:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB4_7
; %bb.6:
	mov	x0, x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB4_7:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_move           ; -- Begin function nl_socket_value_move
	.p2align	2
_nl_socket_value_move:                  ; @nl_socket_value_move
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB5_19
; %bb.1:
	cbz	x2, LBB5_19
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB5_19
; %bb.3:
	cbz	x8, LBB5_19
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB5_19
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB5_19
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB5_19
; %bb.7:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB5_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB5_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB5_16
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB5_16
; %bb.11:
	ldr	x10, [x1, #8]
	cbz	x10, LBB5_16
; %bb.12:
	mov	w11, #88                        ; =0x58
	umaddl	x11, w9, w11, x8
	ldr	w12, [x11, #136]
	cbz	w12, LBB5_16
; %bb.13:
	ldur	x12, [x11, #120]
	cmp	x12, x10
	b.ne	LBB5_16
; %bb.14:
	ldurb	w12, [x11, #140]
	tbz	w12, #0, LBB5_17
; %bb.15:
	mov	w0, #4                          ; =0x4
	ret
LBB5_16:
	mov	w0, #2                          ; =0x2
	ret
LBB5_17:
	cmn	x10, #1
	b.eq	LBB5_20
; %bb.18:
	mov	w0, #0                          ; =0x0
	add	x10, x10, #1
	stur	x10, [x11, #120]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldur	x10, [x11, #120]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB5_19:
	ret
LBB5_20:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_connect_take_ok      ; -- Begin function nl_socket_connect_take_ok
	.p2align	2
_nl_socket_connect_take_ok:             ; @nl_socket_connect_take_ok
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB6_21
; %bb.1:
	cbz	x2, LBB6_21
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB6_21
; %bb.3:
	cbz	x8, LBB6_21
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB6_21
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB6_21
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB6_21
; %bb.7:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB6_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB6_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB6_17
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB6_17
; %bb.11:
	ldr	x11, [x1, #8]
	cbz	x11, LBB6_17
; %bb.12:
	mov	w10, #88                        ; =0x58
	umaddl	x10, w9, w10, x8
	ldr	w12, [x10, #136]
	cbz	w12, LBB6_17
; %bb.13:
	ldur	x13, [x10, #120]
	cmp	x13, x11
	b.ne	LBB6_17
; %bb.14:
	cmp	w12, #2
	b.ne	LBB6_18
; %bb.15:
	ldurb	w12, [x10, #140]
	tbz	w12, #0, LBB6_19
; %bb.16:
	mov	w0, #4                          ; =0x4
	ret
LBB6_17:
	mov	w0, #2                          ; =0x2
	ret
LBB6_18:
	mov	w0, #3                          ; =0x3
	ret
LBB6_19:
	cmn	x11, #1
	b.eq	LBB6_22
; %bb.20:
	mov	w0, #0                          ; =0x0
	add	x11, x11, #1
	stur	x11, [x10, #120]
	mov	w11, #1                         ; =0x1
	stur	w11, [x10, #136]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldur	x10, [x10, #120]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB6_21:
	ret
LBB6_22:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_connect_view         ; -- Begin function nl_socket_connect_view
	.p2align	2
_nl_socket_connect_view:                ; @nl_socket_connect_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh6:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x9, [x9]
	stur	x9, [x29, #-8]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB7_15
; %bb.1:
	cbz	x2, LBB7_15
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #24
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #48
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB7_15
; %bb.3:
	tbnz	w9, #0, LBB7_15
; %bb.4:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB7_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB7_15
LBB7_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB7_14
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB7_14
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB7_14
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #136]
	cbz	w9, LBB7_14
; %bb.10:
	ldur	x11, [x8, #120]
	cmp	x11, x10
	b.ne	LBB7_14
; %bb.11:
	and	w10, w9, #0xfffffffe
	cmp	w10, #2
	b.ne	LBB7_17
; %bb.12:
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #30]
	stp	q0, q0, [sp]
	cmp	w9, #2
	cset	w9, eq
	b.ne	LBB7_18
; %bb.13:
	ldurb	w10, [x8, #141]
	b	LBB7_19
LBB7_14:
	mov	w0, #2                          ; =0x2
LBB7_15:
	ldur	x8, [x29, #-8]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_20
; %bb.16:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB7_17:
	mov	w0, #3                          ; =0x3
	b	LBB7_15
LBB7_18:
	mov	w10, #0                         ; =0x0
	ldur	q0, [x8, #168]
	stur	q0, [sp, #6]
	ldur	q0, [x8, #184]
	stur	q0, [sp, #22]
	ldur	x8, [x8, #200]
	stur	x8, [sp, #38]
LBB7_19:
	mov	w0, #0                          ; =0x0
	strb	w9, [x2]
	strb	w10, [x2, #1]
	ldp	q0, q1, [sp]
	stur	q0, [x2, #2]
	stur	q1, [x2, #18]
	ldur	q0, [sp, #30]
	str	q0, [x2, #32]
	b	LBB7_15
LBB7_20:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_connect_take_error   ; -- Begin function nl_socket_connect_take_error
	.p2align	2
_nl_socket_connect_take_error:          ; @nl_socket_connect_take_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB8_13
; %bb.1:
	cbz	x2, LBB8_13
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #24
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #40
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB8_13
; %bb.3:
	tbnz	w9, #0, LBB8_13
; %bb.4:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB8_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	add	sp, sp, #48
	ret
LBB8_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB8_14
; %bb.7:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB8_14
; %bb.8:
	ldr	x9, [x1, #8]
	cbz	x9, LBB8_14
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #136]
	cbz	w10, LBB8_14
; %bb.10:
	ldur	x11, [x8, #120]
	cmp	x11, x9
	b.ne	LBB8_14
; %bb.11:
	cmp	w10, #3
	b.ne	LBB8_15
; %bb.12:
	mov	w0, #0                          ; =0x0
	ldur	q0, [x8, #168]
	ldur	q1, [x8, #184]
	ldur	x10, [x8, #200]
	ldur	x11, [x8, #128]
	movi.2d	v2, #0000000000000000
	stur	q2, [x8, #120]
	stur	q2, [x8, #136]
	stur	q2, [x8, #152]
	stur	q2, [x8, #168]
	stur	q2, [x8, #184]
	stur	xzr, [x8, #200]
	stp	x9, x11, [x8, #120]
	stp	xzr, xzr, [x1, #8]
	str	xzr, [x1]
	str	x10, [x2, #32]
	stp	q0, q1, [x2]
LBB8_13:
	add	sp, sp, #48
	ret
LBB8_14:
	mov	w0, #2                          ; =0x2
	add	sp, sp, #48
	ret
LBB8_15:
	mov	w0, #3                          ; =0x3
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_borrow         ; -- Begin function nl_socket_value_borrow
	.p2align	2
_nl_socket_value_borrow:                ; @nl_socket_value_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB9_22
; %bb.1:
	cbz	x2, LBB9_22
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #23
	cset	w9, hi
	subs	x10, x1, x2
	cmp	x10, #31
	cset	w10, hi
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB9_22
; %bb.3:
	ldr	x9, [x2]
	cbnz	x9, LBB9_22
; %bb.4:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB9_22
; %bb.5:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB9_22
; %bb.6:
	cbz	x8, LBB9_22
; %bb.7:
	ldr	x9, [x2, #24]
	cbnz	x9, LBB9_22
; %bb.8:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB9_10
; %bb.9:
	mov	w0, #7                          ; =0x7
	ret
LBB9_10:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB9_18
; %bb.11:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB9_18
; %bb.12:
	ldr	x10, [x1, #8]
	cbz	x10, LBB9_18
; %bb.13:
	mov	w11, #88                        ; =0x58
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #136]
	cbz	w9, LBB9_18
; %bb.14:
	ldur	x11, [x8, #120]
	cmp	x11, x10
	b.ne	LBB9_18
; %bb.15:
	cmp	w9, #1
	b.ne	LBB9_19
; %bb.16:
	ldurb	w9, [x8, #140]
	tbz	w9, #0, LBB9_20
; %bb.17:
	mov	w0, #4                          ; =0x4
	ret
LBB9_18:
	mov	w0, #2                          ; =0x2
	ret
LBB9_19:
	mov	w0, #3                          ; =0x3
	ret
LBB9_20:
	ldur	x9, [x8, #128]
	cmn	x9, #1
	b.eq	LBB9_23
; %bb.21:
	mov	w0, #0                          ; =0x0
	add	x9, x9, #1
	stur	x9, [x8, #128]
	mov	w10, #1                         ; =0x1
	sturb	w10, [x8, #140]
	ldr	q0, [x1]
	ldr	x8, [x1, #16]
	str	q0, [x2]
	stp	x8, x9, [x2, #16]
LBB9_22:
	ret
LBB9_23:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_end_borrow     ; -- Begin function nl_socket_value_end_borrow
	.p2align	2
_nl_socket_value_end_borrow:            ; @nl_socket_value_end_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB10_13
; %bb.1:
	cbz	x1, LBB10_13
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB10_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB10_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB10_14
; %bb.5:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB10_14
; %bb.6:
	ldr	x10, [x1, #8]
	cbz	x10, LBB10_14
; %bb.7:
	mov	w11, #88                        ; =0x58
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #136]
	cbz	w9, LBB10_14
; %bb.8:
	ldur	x11, [x8, #120]
	cmp	w9, #1
	ccmp	x11, x10, #0, eq
	b.ne	LBB10_14
; %bb.9:
	ldurb	w9, [x8, #140]
	cmp	w9, #1
	b.ne	LBB10_14
; %bb.10:
	ldr	x9, [x1, #24]
	cbz	x9, LBB10_14
; %bb.11:
	ldur	x10, [x8, #128]
	cmp	x9, x10
	b.ne	LBB10_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	sturb	wzr, [x8, #140]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x1]
LBB10_13:
	ret
LBB10_14:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_finish_connect ; -- Begin function nl_socket_value_finish_connect
	.p2align	2
_nl_socket_value_finish_connect:        ; @nl_socket_value_finish_connect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh12:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB11_16
; %bb.1:
	cbz	x2, LBB11_16
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #32
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #64
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB11_16
; %bb.3:
	tbnz	w9, #0, LBB11_16
; %bb.4:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB11_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB11_16
LBB11_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB11_15
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB11_15
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB11_15
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #136]
	cbz	w11, LBB11_15
; %bb.10:
	ldr	x12, [x9, #120]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB11_15
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB11_15
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB11_15
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB11_15
; %bb.14:
	ldr	x0, [x8, #8]
	mov	x8, sp
	add	x1, x9, #24
	mov	x19, x2
	bl	_nl_socket_finish_connect
	mov	w0, #0                          ; =0x0
	strb	wzr, [sp, #46]
	strh	wzr, [sp, #44]
	ldp	q1, q0, [sp]
	stur	q0, [sp, #63]
	stur	q1, [sp, #47]
	ldur	q0, [sp, #44]
	ldur	q1, [sp, #60]
	stur	q0, [x19, #5]
	ldr	w8, [sp]
	cmp	w8, #0
	ldr	x8, [sp, #32]
	stur	x8, [sp, #79]
	cset	w8, eq
	str	wzr, [x19]
	strb	w8, [x19, #4]
	stur	q1, [x19, #21]
	ldur	q0, [sp, #71]
	str	q0, [x19, #32]
	stp	xzr, xzr, [x19, #48]
	b	LBB11_16
LBB11_15:
	mov	w0, #2                          ; =0x2
LBB11_16:
	ldur	x8, [x29, #-24]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB11_18
; %bb.17:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB11_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_send_byte      ; -- Begin function nl_socket_value_send_byte
	.p2align	2
_nl_socket_value_send_byte:             ; @nl_socket_value_send_byte
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh18:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh19:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh20:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB12_17
; %bb.1:
	cbz	x3, LBB12_17
; %bb.2:
	sub	x9, x3, x1
	cmp	x9, #32
	cset	w9, lo
	subs	x10, x1, x3
	cmp	x10, #64
	cset	w10, lo
	cmp	x1, x3
	csel	w9, w10, w9, hi
	cbz	x8, LBB12_17
; %bb.3:
	tbnz	w9, #0, LBB12_17
; %bb.4:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB12_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB12_17
LBB12_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB12_16
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB12_16
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB12_16
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #136]
	cbz	w11, LBB12_16
; %bb.10:
	ldr	x12, [x9, #120]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB12_16
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB12_16
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB12_16
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB12_16
; %bb.14:
	stur	wzr, [x29, #-32]
	stur	xzr, [x29, #-40]
	stp	xzr, xzr, [sp, #48]
	cmp	x2, #255
	b.hi	LBB12_19
; %bb.15:
	ldr	x0, [x8, #8]
	add	x8, sp, #8
	add	x1, x9, #24
                                        ; kill: def $w2 killed $w2 killed $x2
	mov	x19, x3
	bl	_nl_socket_send_byte
	mov	x3, x19
	ldr	w9, [sp, #8]
	ldur	x8, [sp, #12]
	stur	x8, [x29, #-40]
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-32]
	ldr	x8, [sp, #24]
	ldur	q0, [sp, #32]
	str	q0, [sp, #48]
	b	LBB12_20
LBB12_16:
	mov	w0, #2                          ; =0x2
LBB12_17:
	ldur	x8, [x29, #-24]
Lloh21:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh22:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh23:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB12_21
; %bb.18:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB12_19:
	mov	x8, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
LBB12_20:
	mov	w0, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	str	w10, [x3]
	cmp	w9, #0
	cset	w10, eq
	strb	w10, [x3, #4]
	csel	x10, x8, xzr, eq
	sturh	wzr, [x3, #5]
	strb	wzr, [x3, #7]
	str	w9, [x3, #8]
	ldur	x9, [x29, #-40]
	stur	x9, [x3, #12]
	ldur	w9, [x29, #-32]
	str	w9, [x3, #20]
	str	x8, [x3, #24]
	ldr	q0, [sp, #48]
	str	q0, [x3, #32]
	stp	x10, xzr, [x3, #48]
	b	LBB12_17
LBB12_21:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh18, Lloh19, Lloh20
	.loh AdrpLdrGotLdr	Lloh21, Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_receive_byte   ; -- Begin function nl_socket_value_receive_byte
	.p2align	2
_nl_socket_value_receive_byte:          ; @nl_socket_value_receive_byte
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh24:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh25:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh26:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB13_18
; %bb.1:
	cbz	x2, LBB13_18
; %bb.2:
	sub	x9, x2, x1
	cmp	x9, #32
	cset	w9, lo
	subs	x10, x1, x2
	cmp	x10, #64
	cset	w10, lo
	cmp	x1, x2
	csel	w9, w10, w9, hi
	cbz	x8, LBB13_18
; %bb.3:
	tbnz	w9, #0, LBB13_18
; %bb.4:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB13_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB13_18
LBB13_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB13_17
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB13_17
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB13_17
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #136]
	cbz	w11, LBB13_17
; %bb.10:
	ldr	x12, [x9, #120]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB13_17
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB13_17
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB13_17
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB13_17
; %bb.14:
	mov	x19, x2
	strb	wzr, [sp, #47]
	ldr	x0, [x8, #8]
	mov	x20, sp
	mov	x8, sp
	add	x1, x9, #24
	add	x2, sp, #47
	bl	_nl_socket_receive_byte
	ldr	w8, [sp]
	orr	x9, x20, #0x4
	cbz	w8, LBB13_20
; %bb.15:
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #48]
	ldr	w9, [x9, #32]
	str	w9, [sp, #80]
	cmp	w8, #1
	mov	x9, x19
	b.eq	LBB13_21
; %bb.16:
	mov	w12, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	b	LBB13_22
LBB13_17:
	mov	w0, #2                          ; =0x2
LBB13_18:
	ldur	x8, [x29, #-24]
Lloh27:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh28:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh29:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB13_23
; %bb.19:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB13_20:
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #48]
	ldr	w9, [x9, #32]
	str	w9, [sp, #80]
	mov	x9, x19
LBB13_21:
	ldrb	w10, [sp, #47]
	mov	w12, #1                         ; =0x1
	ldrb	w11, [sp, #32]
LBB13_22:
	mov	w0, #0                          ; =0x0
	ldp	q0, q1, [sp, #48]
	stur	q0, [x9, #12]
	mov	w13, #2                         ; =0x2
	str	w13, [x9]
	strb	w12, [x9, #4]
	sturh	wzr, [x9, #5]
	strb	wzr, [x9, #7]
	str	w8, [x9, #8]
	stur	q1, [x9, #28]
	ldr	w8, [sp, #80]
	str	w8, [x9, #44]
	str	x10, [x9, #48]
	strb	w11, [x9, #56]
	stur	wzr, [x9, #57]
	str	wzr, [x9, #60]
	b	LBB13_18
LBB13_23:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh24, Lloh25, Lloh26
	.loh AdrpLdrGotLdr	Lloh27, Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_close          ; -- Begin function nl_socket_value_close
	.p2align	2
_nl_socket_value_close:                 ; @nl_socket_value_close
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x9, x0
Lloh30:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh31:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh32:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB14_15
; %bb.1:
	cbz	x2, LBB14_15
; %bb.2:
	sub	x8, x2, x1
	cmp	x8, #24
	cset	w8, lo
	subs	x10, x1, x2
	cmp	x10, #64
	cset	w10, lo
	cmp	x1, x2
	csel	w8, w10, w8, hi
	cbz	x9, LBB14_15
; %bb.3:
	tbnz	w8, #0, LBB14_15
; %bb.4:
	ldrb	w8, [x9, #16]
	tbz	w8, #0, LBB14_6
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB14_15
LBB14_6:
	ldr	x8, [x1]
	ldr	x10, [x9]
	cmp	x8, x10
	b.ne	LBB14_14
; %bb.7:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB14_14
; %bb.8:
	ldr	x8, [x1, #8]
	cbz	x8, LBB14_14
; %bb.9:
	mov	w11, #88                        ; =0x58
	umaddl	x11, w10, w11, x9
	ldr	w10, [x11, #136]
	cbz	w10, LBB14_14
; %bb.10:
	add	x19, x11, #120
	ldr	x11, [x19]
	cmp	x11, x8
	b.ne	LBB14_14
; %bb.11:
	cmp	w10, #1
	b.ne	LBB14_17
; %bb.12:
	ldrb	w8, [x19, #20]
	tbz	w8, #0, LBB14_18
; %bb.13:
	mov	w0, #4                          ; =0x4
	b	LBB14_15
LBB14_14:
	mov	w0, #2                          ; =0x2
LBB14_15:
	ldur	x8, [x29, #-56]
Lloh33:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh34:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh35:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB14_31
; %bb.16:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB14_17:
	mov	w0, #3                          ; =0x3
	b	LBB14_15
LBB14_18:
	ldr	x0, [x9, #8]
	add	x23, sp, #8
	add	x8, sp, #8
	mov	x20, x1
	add	x1, x19, #24
	mov	x21, x9
	mov	x22, x2
	bl	_nl_socket_consume_close
	mov	x12, x21
	mov	x10, x20
	mov	x8, x22
	ldr	w9, [sp, #8]
	orr	x11, x23, #0x4
	ldrb	w13, [sp, #42]
	ldrb	w14, [sp, #43]
	ldr	w15, [sp, #44]
	cbnz	w9, LBB14_21
; %bb.19:
	tbnz	w13, #0, LBB14_21
; %bb.20:
	tbz	w14, #0, LBB14_28
LBB14_21:
	ldr	x16, [x12, #32]
	cmn	x16, #1
	b.eq	LBB14_28
; %bb.22:
	cbz	x16, LBB14_25
; %bb.23:
	cmp	x16, #1
	b.ne	LBB14_27
; %bb.24:
	mov	w17, #80                        ; =0x50
	b	LBB14_26
LBB14_25:
	mov	w17, #40                        ; =0x28
LBB14_26:
	add	x17, x12, x17
	str	w9, [x17]
	ldr	q0, [x11]
	stur	q0, [x17, #4]
	ldur	q0, [x11, #14]
	stur	q0, [x17, #18]
	strb	w13, [x17, #34]
	strb	w14, [x17, #35]
	str	w15, [x17, #36]
LBB14_27:
	add	x13, x16, #1
	str	x13, [x12, #32]
LBB14_28:
	ldrb	w12, [sp, #41]
	tbz	w12, #0, LBB14_30
; %bb.29:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #16]
	stp	q0, q0, [x19, #48]
	str	xzr, [x19, #80]
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp, #48]
	ldr	w11, [x11, #32]
	str	w11, [sp, #80]
	stp	xzr, xzr, [x10]
	str	xzr, [x10, #16]
	cmp	w9, #0
	mov	w10, #3                         ; =0x3
	str	w10, [x8]
	cset	w10, eq
	strb	w10, [x8, #4]
	sturh	wzr, [x8, #5]
	strb	wzr, [x8, #7]
	str	w9, [x8, #8]
	stur	q0, [x8, #12]
	stur	q1, [x8, #28]
	str	w11, [x8, #44]
	stp	xzr, xzr, [x8, #48]
	b	LBB14_15
LBB14_30:
	mov	w0, #8                          ; =0x8
	b	LBB14_15
LBB14_31:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh30, Lloh31, Lloh32
	.loh AdrpLdrGotLdr	Lloh33, Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function sv_close_slot
_sv_close_slot:                         ; @sv_close_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	ldr	x0, [x0, #8]
	add	x22, sp, #8
	add	x8, sp, #8
	add	x1, x1, #24
	bl	_nl_socket_consume_close
	ldr	w11, [sp, #8]
	ldrb	w8, [sp, #42]
	ldrb	w9, [sp, #43]
	ldr	w10, [sp, #44]
	cbnz	w11, LBB15_3
; %bb.1:
	tbnz	w8, #0, LBB15_3
; %bb.2:
	tbz	w9, #0, LBB15_10
LBB15_3:
	ldr	x12, [x21, #32]
	cmn	x12, #1
	b.eq	LBB15_10
; %bb.4:
	cbz	x12, LBB15_7
; %bb.5:
	cmp	x12, #1
	b.ne	LBB15_9
; %bb.6:
	mov	w13, #80                        ; =0x50
	b	LBB15_8
LBB15_7:
	mov	w13, #40                        ; =0x28
LBB15_8:
	orr	x14, x22, #0x4
	add	x13, x21, x13
	str	w11, [x13]
	ldr	q0, [x14]
	stur	q0, [x13, #4]
	ldur	q0, [x14, #14]
	stur	q0, [x13, #18]
	strb	w8, [x13, #34]
	strb	w9, [x13, #35]
	str	w10, [x13, #36]
LBB15_9:
	add	x8, x12, #1
	str	x8, [x21, #32]
LBB15_10:
	ldrb	w8, [sp, #41]
	cmp	w8, #1
	b.ne	LBB15_12
; %bb.11:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20, #16]
	stp	q0, q0, [x20, #48]
	str	xzr, [x20, #80]
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldr	x8, [sp, #40]
	str	x8, [x19, #32]
	b	LBB15_13
LBB15_12:
	mov	w0, #8                          ; =0x8
LBB15_13:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_drop           ; -- Begin function nl_socket_value_drop
	.p2align	2
_nl_socket_value_drop:                  ; @nl_socket_value_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_8
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB16_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB16_3:
	cbz	x1, LBB16_8
; %bb.4:
	ldp	x11, x9, [x1]
	ldr	w10, [x1, #16]
	cbnz	x11, LBB16_9
; %bb.5:
	cbnz	x9, LBB16_9
; %bb.6:
	cbnz	w10, LBB16_9
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB16_8:
	mov	w0, #1                          ; =0x1
	ret
LBB16_9:
	ldr	x12, [x0]
	mov	w8, #2                          ; =0x2
	cmp	x11, x12
	b.ne	LBB16_20
; %bb.10:
	cmp	w10, #63
	ccmp	x9, #0, #4, ls
	b.eq	LBB16_20
; %bb.11:
	mov	w8, #88                         ; =0x58
	umaddl	x8, w10, w8, x0
	ldr	w10, [x8, #136]
	cbz	w10, LBB16_15
; %bb.12:
	ldur	x11, [x8, #120]
	cmp	x11, x9
	b.ne	LBB16_15
; %bb.13:
	ldurb	w11, [x8, #140]
	tbz	w11, #0, LBB16_16
; %bb.14:
	mov	w0, #4                          ; =0x4
	ret
LBB16_15:
	mov	w0, #2                          ; =0x2
	ret
LBB16_16:
	cmp	w10, #3
	b.ne	LBB16_18
; %bb.17:
	ldur	x10, [x8, #128]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #120]
	stur	q0, [x8, #136]
	stur	q0, [x8, #152]
	stur	q0, [x8, #168]
	stur	q0, [x8, #184]
	stur	xzr, [x8, #200]
	stp	x9, x10, [x8, #120]
	b	LBB16_19
LBB16_18:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	add	x1, x8, #120
	add	x2, sp, #8
	bl	_sv_close_slot
	mov	x1, x19
	mov	x8, x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	cbnz	w0, LBB16_20
LBB16_19:
	mov	w8, #0                          ; =0x0
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
LBB16_20:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_validate       ; -- Begin function nl_socket_value_validate
	.p2align	2
_nl_socket_value_validate:              ; @nl_socket_value_validate
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_10
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB17_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB17_3:
	cbz	x1, LBB17_10
; %bb.4:
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB17_11
; %bb.5:
	ldr	w8, [x1, #16]
	cmp	w8, #63
	b.hi	LBB17_11
; %bb.6:
	ldr	x9, [x1, #8]
	cbz	x9, LBB17_11
; %bb.7:
	mov	w10, #88                        ; =0x58
	umaddl	x10, w8, w10, x0
	ldr	w8, [x10, #136]
	cbz	w8, LBB17_11
; %bb.8:
	ldur	x10, [x10, #120]
	cmp	x10, x9
	b.ne	LBB17_11
; %bb.9:
	sub	w9, w8, #4
	cmn	w9, #2
	cset	w9, lo
	cmp	w8, #1
	cset	w8, ne
	cmp	w2, #0
	csel	w8, w9, w8, ne
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w0, w9, wzr, ne
	ret
LBB17_10:
	mov	w0, #1                          ; =0x1
	ret
LBB17_11:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_value_borrow_validate ; -- Begin function nl_socket_value_borrow_validate
	.p2align	2
_nl_socket_value_borrow_validate:       ; @nl_socket_value_borrow_validate
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB18_12
; %bb.1:
	cbz	x1, LBB18_12
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB18_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB18_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB18_13
; %bb.5:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB18_13
; %bb.6:
	ldr	x10, [x1, #8]
	cbz	x10, LBB18_13
; %bb.7:
	mov	w11, #88                        ; =0x58
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #136]
	cbz	w9, LBB18_13
; %bb.8:
	ldur	x11, [x8, #120]
	cmp	w9, #1
	ccmp	x11, x10, #0, eq
	b.ne	LBB18_13
; %bb.9:
	ldurb	w9, [x8, #140]
	cmp	w9, #1
	b.ne	LBB18_13
; %bb.10:
	ldr	x9, [x1, #24]
	mov	w0, #2                          ; =0x2
	cbz	x9, LBB18_12
; %bb.11:
	ldur	x8, [x8, #128]
	cmp	x9, x8
	csel	w0, wzr, w0, eq
LBB18_12:
	ret
LBB18_13:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_live_slots    ; -- Begin function nl_socket_values_live_slots
	.p2align	2
_nl_socket_values_live_slots:           ; @nl_socket_values_live_slots
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB19_3
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB19_4
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB19_3:
	mov	w0, #1                          ; =0x1
	ret
LBB19_4:
	mov	x17, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB19_10
; %bb.5:
	cbz	x2, LBB19_10
; %bb.6:
	sub	x8, x2, x1
	subs	x9, x1, x2
	csel	x8, x9, x8, hi
	cmp	x8, #8
	b.lo	LBB19_10
; %bb.7:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	mov	x12, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	add	x17, x17, #224
	mov	w0, #1                          ; =0x1
	mov	w3, #2                          ; =0x2
	mov	w4, #4                          ; =0x4
	mov	w5, #8                          ; =0x8
LBB19_8:                                ; =>This Inner Loop Header: Depth=1
	ldur	w6, [x17, #-88]
	ldr	w7, [x17]
	ldr	w19, [x17, #88]
	ldr	w20, [x17, #176]
	lsl	x21, x0, x12
	lsl	x22, x3, x12
	lsl	x23, x4, x12
	lsl	x24, x5, x12
	cmp	w6, #0
	csel	x6, xzr, x21, eq
	cmp	w7, #0
	csel	x7, xzr, x22, eq
	cmp	w19, #0
	csel	x19, xzr, x23, eq
	cmp	w20, #0
	csel	x20, xzr, x24, eq
	orr	x11, x6, x11
	orr	x14, x7, x14
	orr	x15, x19, x15
	orr	x16, x20, x16
	ldurb	w6, [x17, #-84]
	ldrb	w7, [x17, #4]
	ldrb	w19, [x17, #92]
	ldrb	w20, [x17, #180]
	cmp	w6, #0
	csel	x6, x21, xzr, ne
	cmp	w7, #0
	csel	x7, x22, xzr, ne
	cmp	w19, #0
	csel	x19, x23, xzr, ne
	cmp	w20, #0
	csel	x20, x24, xzr, ne
	orr	x8, x6, x8
	orr	x9, x7, x9
	orr	x10, x19, x10
	orr	x13, x20, x13
	add	x12, x12, #4
	add	x17, x17, #352
	cmp	x12, #64
	b.ne	LBB19_8
; %bb.9:
	mov	w0, #0                          ; =0x0
	orr	x8, x9, x8
	orr	x9, x13, x10
	orr	x8, x9, x8
	orr	x9, x14, x11
	orr	x10, x16, x15
	orr	x9, x10, x9
	str	x9, [x1]
	str	x8, [x2]
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
LBB19_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_report        ; -- Begin function nl_socket_values_report
	.p2align	2
_nl_socket_values_report:               ; @nl_socket_values_report
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB20_2
; %bb.1:
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	stp	q0, q1, [x1]
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	ldur	q3, [x8, #104]
	stp	q2, q3, [x1, #64]
	stp	q0, q1, [x1, #32]
LBB20_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_finish        ; -- Begin function nl_socket_values_finish
	.p2align	2
_nl_socket_values_finish:               ; @nl_socket_values_finish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB21_4
; %bb.1:
	mov	x19, x0
	ldrb	w9, [x0, #16]
	cmp	w9, #1
	b.ne	LBB21_3
; %bb.2:
	ldur	q0, [x19, #56]
	ldur	q1, [x19, #72]
	stp	q0, q1, [x8, #32]
	ldur	q0, [x19, #88]
	ldur	q1, [x19, #104]
	stp	q0, q1, [x8, #64]
	ldur	q0, [x19, #24]
	ldur	q1, [x19, #40]
	stp	q0, q1, [x8]
	b	LBB21_33
LBB21_3:
	cmp	w1, #9
	b.lo	LBB21_5
LBB21_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	b	LBB21_33
LBB21_5:
	mov	x22, x8
	mov	x21, x19
	str	w1, [x21, #24]!
	add	x8, sp, #8
	orr	x23, x8, #0x4
	add	x20, x21, #120
	mov	w24, #64                        ; =0x40
	movi.2d	v1, #0000000000000000
	mov	w25, #8                         ; =0x8
	b	LBB21_8
LBB21_6:                                ;   in Loop: Header=BB21_8 Depth=1
	stp	q1, q1, [x26, #16]
	stp	q1, q1, [x26, #48]
	str	xzr, [x26, #80]
LBB21_7:                                ;   in Loop: Header=BB21_8 Depth=1
	ldur	q0, [x20, #-24]
	str	xzr, [x26, #80]
	stp	q1, q1, [x26, #48]
	stp	q1, q1, [x26, #16]
	str	q1, [x26]
	stur	q0, [x20, #-24]
	add	x20, x20, #88
	subs	x24, x24, #1
	b.eq	LBB21_22
LBB21_8:                                ; =>This Inner Loop Header: Depth=1
	sub	x26, x20, #24
	ldur	w8, [x20, #-8]
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB21_7
; %bb.9:                                ;   in Loop: Header=BB21_8 Depth=1
	ldr	x0, [x19, #8]
	add	x8, sp, #8
	mov	x1, x20
	bl	_nl_socket_consume_close
	ldr	w11, [sp, #8]
	ldrb	w8, [sp, #42]
	ldrb	w9, [sp, #43]
	ldr	w10, [sp, #44]
	cbnz	w11, LBB21_12
; %bb.10:                               ;   in Loop: Header=BB21_8 Depth=1
	tbnz	w8, #0, LBB21_12
; %bb.11:                               ;   in Loop: Header=BB21_8 Depth=1
	tbz	w9, #0, LBB21_19
LBB21_12:                               ;   in Loop: Header=BB21_8 Depth=1
	ldr	x12, [x19, #32]
	cmn	x12, #1
	b.eq	LBB21_19
; %bb.13:                               ;   in Loop: Header=BB21_8 Depth=1
	cbz	x12, LBB21_16
; %bb.14:                               ;   in Loop: Header=BB21_8 Depth=1
	cmp	x12, #1
	b.ne	LBB21_18
; %bb.15:                               ;   in Loop: Header=BB21_8 Depth=1
	mov	w13, #80                        ; =0x50
	b	LBB21_17
LBB21_16:                               ;   in Loop: Header=BB21_8 Depth=1
	mov	w13, #40                        ; =0x28
LBB21_17:                               ;   in Loop: Header=BB21_8 Depth=1
	add	x13, x19, x13
	str	w11, [x13]
	ldr	q0, [x23]
	stur	q0, [x13, #4]
	ldur	q0, [x23, #14]
	stur	q0, [x13, #18]
	strb	w8, [x13, #34]
	strb	w9, [x13, #35]
	str	w10, [x13, #36]
LBB21_18:                               ;   in Loop: Header=BB21_8 Depth=1
	add	x8, x12, #1
	str	x8, [x19, #32]
LBB21_19:                               ;   in Loop: Header=BB21_8 Depth=1
	ldrb	w8, [sp, #41]
	cmp	w8, #1
	movi.2d	v1, #0000000000000000
	b.eq	LBB21_6
; %bb.20:                               ;   in Loop: Header=BB21_8 Depth=1
	ldr	w8, [x21]
	cbnz	w8, LBB21_7
; %bb.21:                               ;   in Loop: Header=BB21_8 Depth=1
	str	w25, [x21]
	b	LBB21_7
LBB21_22:
	ldr	x0, [x19, #8]
	add	x8, sp, #8
	bl	_nl_socket_service_destroy
	ldr	w8, [sp, #8]
	cbnz	w8, LBB21_25
; %bb.23:
	ldrb	w8, [sp, #42]
	tbnz	w8, #0, LBB21_25
; %bb.24:
	ldrb	w8, [sp, #43]
	tbz	w8, #0, LBB21_32
LBB21_25:
	ldr	x8, [x19, #32]
	cmn	x8, #1
	b.eq	LBB21_32
; %bb.26:
	cbz	x8, LBB21_29
; %bb.27:
	cmp	x8, #1
	b.ne	LBB21_31
; %bb.28:
	mov	w9, #80                         ; =0x50
	b	LBB21_30
LBB21_29:
	mov	w9, #40                         ; =0x28
LBB21_30:
	add	x9, x19, x9
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x9]
	ldr	x10, [sp, #40]
	str	x10, [x9, #32]
LBB21_31:
	add	x8, x8, #1
	str	x8, [x19, #32]
LBB21_32:
	str	xzr, [x19, #8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #16]
	ldp	q0, q1, [x21, #32]
	stp	q0, q1, [x22, #32]
	ldp	q0, q1, [x21, #64]
	stp	q0, q1, [x22, #64]
	ldp	q0, q1, [x21]
	stp	q0, q1, [x22]
LBB21_33:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_values_destroy       ; -- Begin function nl_socket_values_destroy
	.p2align	2
_nl_socket_values_destroy:              ; @nl_socket_values_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nl_socket_values_finish
	cbz	x19, LBB22_3
; %bb.1:
	ldrb	w8, [x19, #16]
	cmp	w8, #1
	b.ne	LBB22_3
; %bb.2:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB22_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_sv_identity,8,3 ; @sv_identity
.subsections_via_symbols
