	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_host_enter_query  ; -- Begin function nvm_services_host_enter_query
	.p2align	2
_nvm_services_host_enter_query:         ; @nvm_services_host_enter_query
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_nvm_file_host_enter_query
	mov	w8, #5                          ; =0x5
	cmp	w0, #0
	csel	w0, wzr, w8, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_leave        ; -- Begin function nvm_services_host_leave
	.p2align	2
_nvm_services_host_leave:               ; @nvm_services_host_leave
	.cfi_startproc
; %bb.0:
	b	_nvm_file_host_leave
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_enter        ; -- Begin function nvm_services_host_enter
	.p2align	2
_nvm_services_host_enter:               ; @nvm_services_host_enter
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB2_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB2_7
LBB2_2:
	cbz	x19, LBB2_5
; %bb.3:
	ldr	x8, [x19]
Lloh0:
	adrp	x9, _services_host_identity@PAGE
Lloh1:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.eq	LBB2_8
LBB2_4:
	mov	w8, #4                          ; =0x4
	b	LBB2_6
LBB2_5:
	mov	w8, #1                          ; =0x1
LBB2_6:
	mov	x19, x8
	bl	_nvm_file_host_leave
	mov	x0, x19
LBB2_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB2_8:
	mov	w8, #4                          ; =0x4
	cmp	w21, #1
	b.ne	LBB2_6
; %bb.9:
	cmp	w20, #3
	b.ne	LBB2_6
; %bb.10:
	ldr	w8, [x19, #8]
	cmp	w8, #1
	b.ne	LBB2_4
; %bb.11:
	ldr	w8, [x19, #12]
	cmp	w8, #3
	b.ne	LBB2_4
; %bb.12:
	ldr	x8, [x19, #24]
	sub	x8, x8, #65
	cmn	x8, #64
	b.lo	LBB2_4
; %bb.13:
	ldrb	w8, [x19, #16]
	tbz	w8, #0, LBB2_15
; %bb.14:
	mov	w0, #0                          ; =0x0
	b	LBB2_7
LBB2_15:
	mov	w8, #3                          ; =0x3
	b	LBB2_6
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_grant_create_config ; -- Begin function nvm_services_host_grant_create_config
	.p2align	2
_nvm_services_host_grant_create_config: ; @nvm_services_host_grant_create_config
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB3_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB3_3
LBB3_2:
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	bl	_services_host_create_config
	mov	x19, x0
	bl	_nvm_file_host_leave
	mov	x0, x19
LBB3_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function services_host_create_config
lCPI4_0:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_services_host_create_config:           ; @services_host_create_config
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w8, #1                          ; =0x1
	cbz	x2, LBB4_5
; %bb.1:
	cbz	x0, LBB4_5
; %bb.2:
	sub	x19, x1, #1
	cmp	x19, #63
	b.hi	LBB4_5
; %bb.3:
	ldr	x8, [x2]
	cbz	x8, LBB4_7
LBB4_4:
	mov	w8, #1                          ; =0x1
LBB4_5:
	ldur	x9, [x29, #-96]
Lloh5:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB4_54
; %bb.6:
	mov	x0, x8
	add	sp, sp, #560
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB4_7:
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #512]
	stp	q0, q0, [sp, #480]
	stp	q0, q0, [sp, #448]
	stp	q0, q0, [sp, #416]
	stp	q0, q0, [sp, #384]
	stp	q0, q0, [sp, #352]
	stp	q0, q0, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	mov	w10, #24                        ; =0x18
	mov	w11, #60000                     ; =0xea60
	mov	x12, #-4097                     ; =0xffffffffffffefff
	movk	x12, #32767, lsl #48
	add	x13, sp, #32
	stp	q0, q0, [sp, #32]
LBB4_8:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_20 Depth 2
	madd	x14, x9, x10, x0
	ldr	w15, [x14]
	cmp	w15, #1
	b.ne	LBB4_4
; %bb.9:                                ;   in Loop: Header=BB4_8 Depth=1
	ldr	w15, [x14, #4]
	sub	w16, w15, #1
	cmp	w16, #2
	b.hs	LBB4_14
; %bb.10:                               ;   in Loop: Header=BB4_8 Depth=1
	ldrb	w15, [x14, #9]
	tbnz	w15, #0, LBB4_4
; %bb.11:                               ;   in Loop: Header=BB4_8 Depth=1
	ldr	w15, [x14, #12]
	cbnz	w15, LBB4_4
; %bb.12:                               ;   in Loop: Header=BB4_8 Depth=1
	ldr	x14, [x14, #16]
	cbnz	x14, LBB4_4
LBB4_13:                                ;   in Loop: Header=BB4_8 Depth=1
	add	x9, x9, #1
	cmp	x9, x1
	b.ne	LBB4_8
	b	LBB4_25
LBB4_14:                                ;   in Loop: Header=BB4_8 Depth=1
	cmp	w15, #3
	b.ne	LBB4_4
; %bb.15:                               ;   in Loop: Header=BB4_8 Depth=1
	ldr	w15, [x14, #12]
	cmp	w15, w11
	b.hi	LBB4_4
; %bb.16:                               ;   in Loop: Header=BB4_8 Depth=1
	ldrb	w15, [x14, #9]
	ldr	x14, [x14, #16]
	cmp	w15, #1
	b.ne	LBB4_18
; %bb.17:                               ;   in Loop: Header=BB4_8 Depth=1
	cbnz	x14, LBB4_19
	b	LBB4_4
LBB4_18:                                ;   in Loop: Header=BB4_8 Depth=1
	cbz	x14, LBB4_13
LBB4_19:                                ;   in Loop: Header=BB4_8 Depth=1
	mov	x15, #0                         ; =0x0
LBB4_20:                                ;   Parent Loop BB4_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x14, x15]
	cbz	w16, LBB4_22
; %bb.21:                               ;   in Loop: Header=BB4_20 Depth=2
	add	x15, x15, #1
	cmp	x15, #1, lsl #12                ; =4096
	b.ne	LBB4_20
	b	LBB4_4
LBB4_22:                                ;   in Loop: Header=BB4_8 Depth=1
	tst	x15, x12
	b.eq	LBB4_4
; %bb.23:                               ;   in Loop: Header=BB4_8 Depth=1
	ldrb	w14, [x14]
	cmp	w14, #47
	b.ne	LBB4_4
; %bb.24:                               ;   in Loop: Header=BB4_8 Depth=1
	add	x14, x15, #1
	str	x14, [x13, x9, lsl #3]
	add	x8, x14, x8
	b	LBB4_13
LBB4_25:
	mov	x20, x1
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x22, x2
	mov	w21, #1                         ; =0x1
	add	x1, x8, #1568
	mov	w0, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB4_28
; %bb.26:
	mov	x28, x0
Lloh8:
	adrp	x8, _services_host_identity@PAGE
Lloh9:
	add	x8, x8, _services_host_identity@PAGEOFF
	str	x8, [x0]
Lloh10:
	adrp	x8, lCPI4_0@PAGE
Lloh11:
	ldr	d0, [x8, lCPI4_0@PAGEOFF]
	str	d0, [x0, #8]
	strb	w21, [x0, #16]
	str	x20, [x0, #24]
	add	x23, x0, #1568
	and	x24, x20, #0x7
	cmp	x19, #7
	b.hs	LBB4_29
; %bb.27:
	mov	x10, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	mov	x9, x22
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB4_48
LBB4_28:
	mov	w8, #2                          ; =0x2
	b	LBB4_5
LBB4_29:
	mov	x27, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	and	x8, x20, #0x78
	neg	x8, x8
	stp	x28, x8, [sp, #8]               ; 16-byte Folded Spill
	add	x19, x28, #120
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x28, x8, #96
	add	x8, sp, #32
	add	x26, x8, #32
	b	LBB4_31
LBB4_30:                                ;   in Loop: Header=BB4_31 Depth=1
	mov	x9, x22
	ldp	x10, x8, [sp, #16]              ; 16-byte Folded Reload
	sub	x27, x27, #8
	add	x19, x19, #192
	add	x28, x28, #192
	add	x26, x26, #64
	cmp	x10, x27
	b.eq	LBB4_47
LBB4_31:                                ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x28, #-96]
	stur	q0, [x19, #-88]
	ldur	x8, [x28, #-80]
	stur	x8, [x19, #-72]
	ldur	x20, [x26, #-32]
	cbz	x20, LBB4_33
; %bb.32:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldur	x1, [x28, #-80]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	stur	x21, [x19, #-72]
	add	x25, x20, x25
LBB4_33:                                ;   in Loop: Header=BB4_31 Depth=1
	ldur	q0, [x28, #-72]
	stur	q0, [x19, #-64]
	ldur	x8, [x28, #-56]
	stur	x8, [x19, #-48]
	ldur	x20, [x26, #-24]
	cbz	x20, LBB4_35
; %bb.34:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldur	x1, [x28, #-56]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	stur	x21, [x19, #-48]
	add	x25, x20, x25
LBB4_35:                                ;   in Loop: Header=BB4_31 Depth=1
	ldur	q0, [x28, #-48]
	stur	q0, [x19, #-40]
	ldur	x8, [x28, #-32]
	stur	x8, [x19, #-24]
	ldur	x20, [x26, #-16]
	cbz	x20, LBB4_37
; %bb.36:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldur	x1, [x28, #-32]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	stur	x21, [x19, #-24]
	add	x25, x20, x25
LBB4_37:                                ;   in Loop: Header=BB4_31 Depth=1
	ldur	q0, [x28, #-24]
	stur	q0, [x19, #-16]
	ldur	x8, [x28, #-8]
	str	x8, [x19]
	ldur	x20, [x26, #-8]
	cbz	x20, LBB4_39
; %bb.38:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldur	x1, [x28, #-8]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	str	x21, [x19]
	add	x25, x20, x25
LBB4_39:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	q0, [x28]
	stur	q0, [x19, #8]
	ldr	x8, [x28, #16]
	str	x8, [x19, #24]
	ldr	x20, [x26]
	cbz	x20, LBB4_41
; %bb.40:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldr	x1, [x28, #16]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	str	x21, [x19, #24]
	add	x25, x20, x25
LBB4_41:                                ;   in Loop: Header=BB4_31 Depth=1
	ldur	q0, [x28, #24]
	str	q0, [x19, #32]
	ldr	x8, [x28, #40]
	str	x8, [x19, #48]
	ldr	x20, [x26, #8]
	cbz	x20, LBB4_43
; %bb.42:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldr	x1, [x28, #40]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	str	x21, [x19, #48]
	add	x25, x20, x25
LBB4_43:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	q0, [x28, #48]
	stur	q0, [x19, #56]
	ldr	x8, [x28, #64]
	str	x8, [x19, #72]
	ldr	x20, [x26, #16]
	cbz	x20, LBB4_45
; %bb.44:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldr	x1, [x28, #64]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	str	x21, [x19, #72]
	add	x25, x20, x25
LBB4_45:                                ;   in Loop: Header=BB4_31 Depth=1
	ldur	q0, [x28, #72]
	str	q0, [x19, #80]
	ldr	x8, [x28, #88]
	str	x8, [x19, #96]
	ldr	x20, [x26, #24]
	cbz	x20, LBB4_30
; %bb.46:                               ;   in Loop: Header=BB4_31 Depth=1
	add	x21, x23, x25
	ldr	x1, [x28, #88]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	str	x21, [x19, #96]
	add	x25, x20, x25
	b	LBB4_30
LBB4_47:
	neg	x10, x27
	ldr	x28, [sp, #8]                   ; 8-byte Folded Reload
LBB4_48:
	cbz	x24, LBB4_53
; %bb.49:
	add	x11, sp, #32
	add	x19, x11, x10, lsl #3
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #3
	add	x8, x10, x8
	add	x26, x8, #16
	add	x8, x10, x28
	add	x27, x8, #48
	b	LBB4_51
LBB4_50:                                ;   in Loop: Header=BB4_51 Depth=1
	add	x26, x26, #24
	add	x27, x27, #24
	subs	x24, x24, #1
	b.eq	LBB4_53
LBB4_51:                                ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x26, #-16]
	stur	q0, [x27, #-16]
	ldr	x8, [x26]
	str	x8, [x27]
	ldr	x20, [x19], #8
	cbz	x20, LBB4_50
; %bb.52:                               ;   in Loop: Header=BB4_51 Depth=1
	add	x21, x23, x25
	ldr	x1, [x26]
	mov	x0, x21
	mov	x2, x20
	bl	_memcpy
	mov	x9, x22
	str	x21, [x27]
	add	x25, x20, x25
	b	LBB4_50
LBB4_53:
	mov	w8, #0                          ; =0x0
	str	x28, [x9]
	b	LBB4_5
LBB4_54:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_grant_create ; -- Begin function nvm_services_host_grant_create
	.p2align	2
_nvm_services_host_grant_create:        ; @nvm_services_host_grant_create
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #1552
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
Lloh12:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB5_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB5_12
LBB5_2:
	mov	w19, #1                         ; =0x1
	cbz	x20, LBB5_11
; %bb.3:
	cbz	x22, LBB5_11
; %bb.4:
	sub	x8, x21, #1
	cmp	x8, #63
	b.hi	LBB5_11
; %bb.5:
	ldr	x8, [x20]
	cbnz	x8, LBB5_11
; %bb.6:
	add	x23, sp, #8
	add	x0, sp, #8
	mov	w1, #1536                       ; =0x600
	bl	_bzero
	add	x8, x23, #9
	add	x9, x22, #4
	mov	x10, x21
LBB5_7:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x9, #-4]
	sub	w12, w11, #1
	cmp	w12, #1
	b.hi	LBB5_10
; %bb.8:                                ;   in Loop: Header=BB5_7 Depth=1
	ldrb	w12, [x9], #8
	stur	w19, [x8, #-9]
	stur	w11, [x8, #-5]
	sturb	w12, [x8, #-1]
	str	xzr, [x8]
	stur	xzr, [x8, #7]
	add	x8, x8, #24
	subs	x10, x10, #1
	b.ne	LBB5_7
; %bb.9:
	add	x0, sp, #8
	mov	x1, x21
	mov	x2, x20
	bl	_services_host_create_config
	mov	x19, x0
	b	LBB5_11
LBB5_10:
	mov	w19, #1                         ; =0x1
LBB5_11:
	bl	_nvm_file_host_leave
LBB5_12:
	ldur	x8, [x29, #-56]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_14
; %bb.13:
	mov	x0, x19
	add	sp, sp, #1552
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB5_14:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_websocket_policy ; -- Begin function nvm_services_host_websocket_policy
	.p2align	2
_nvm_services_host_websocket_policy:    ; @nvm_services_host_websocket_policy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_6
; %bb.1:
	ldr	x8, [x0]
Lloh18:
	adrp	x9, _services_host_identity@PAGE
Lloh19:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB6_5
; %bb.2:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB6_5
; %bb.3:
	ldr	w8, [x0, #12]
	cmp	w8, #3
	b.ne	LBB6_5
; %bb.4:
	ldr	x8, [x0, #24]
	sub	x9, x8, #65
	cmn	x9, #64
	b.hs	LBB6_7
LBB6_5:
	mov	w0, #4                          ; =0x4
	ret
LBB6_6:
	mov	w0, #1                          ; =0x1
	ret
LBB6_7:
	ldrb	w9, [x0, #16]
	cmp	w9, #1
	b.ne	LBB6_13
; %bb.8:
	mov	x9, x0
	mov	w0, #1                          ; =0x1
	cbz	x2, LBB6_12
; %bb.9:
	cmp	x1, x8
	b.hs	LBB6_12
; %bb.10:
	mov	w8, #24                         ; =0x18
	madd	x8, x1, x8, x9
	ldr	w9, [x8, #36]
	cmp	w9, #3
	b.ne	LBB6_5
; %bb.11:
	mov	w0, #0                          ; =0x0
	ldurh	w9, [x8, #40]
	ldur	x10, [x8, #48]
	ldur	w8, [x8, #44]
	strh	w9, [x2]
	stur	wzr, [x2, #2]
	strh	wzr, [x2, #6]
	str	x10, [x2, #8]
	stp	w8, wzr, [x2, #16]
LBB6_12:
	ret
LBB6_13:
	mov	w0, #3                          ; =0x3
	ret
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_grant_revoke_instance ; -- Begin function nvm_services_host_grant_revoke_instance
	.p2align	2
_nvm_services_host_grant_revoke_instance: ; @nvm_services_host_grant_revoke_instance
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x21, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB7_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB7_12
LBB7_2:
	cbz	x21, LBB7_10
; %bb.3:
	ldr	x8, [x21]
Lloh20:
	adrp	x9, _services_host_identity@PAGE
Lloh21:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB7_7
; %bb.4:
	ldr	w8, [x21, #8]
	cmp	w8, #1
	b.ne	LBB7_7
; %bb.5:
	ldr	w8, [x21, #12]
	cmp	w8, #3
	b.ne	LBB7_7
; %bb.6:
	ldr	x8, [x21, #24]
	sub	x9, x8, #65
	cmn	x9, #64
	b.hs	LBB7_8
LBB7_7:
	mov	w19, #4                         ; =0x4
	b	LBB7_11
LBB7_8:
	cmp	x20, x8
	b.hs	LBB7_10
; %bb.9:
	mov	w19, #0                         ; =0x0
	mov	w8, #24                         ; =0x18
	madd	x8, x20, x8, x21
	strb	wzr, [x8, #40]
	b	LBB7_11
LBB7_10:
	mov	w19, #1                         ; =0x1
LBB7_11:
	bl	_nvm_file_host_leave
LBB7_12:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_grant_revoke ; -- Begin function nvm_services_host_grant_revoke
	.p2align	2
_nvm_services_host_grant_revoke:        ; @nvm_services_host_grant_revoke
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB8_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB8_10
LBB8_2:
	cbz	x20, LBB8_8
; %bb.3:
	ldr	x8, [x20]
Lloh22:
	adrp	x9, _services_host_identity@PAGE
Lloh23:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB8_7
; %bb.4:
	ldr	w8, [x20, #8]
	cmp	w8, #1
	b.ne	LBB8_7
; %bb.5:
	ldr	w8, [x20, #12]
	cmp	w8, #3
	b.ne	LBB8_7
; %bb.6:
	ldr	x8, [x20, #24]
	sub	x8, x8, #65
	cmn	x8, #64
	b.hs	LBB8_11
LBB8_7:
	mov	w19, #4                         ; =0x4
	b	LBB8_9
LBB8_8:
	mov	w19, #1                         ; =0x1
LBB8_9:
	bl	_nvm_file_host_leave
LBB8_10:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB8_11:
	mov	w19, #0                         ; =0x0
	strb	wzr, [x20, #16]
	b	LBB8_9
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_grant_destroy ; -- Begin function nvm_services_host_grant_destroy
	.p2align	2
_nvm_services_host_grant_destroy:       ; @nvm_services_host_grant_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB9_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB9_12
LBB9_2:
	cbz	x20, LBB9_9
; %bb.3:
	ldr	x0, [x20]
	cbz	x0, LBB9_10
; %bb.4:
	ldr	x8, [x0]
Lloh24:
	adrp	x9, _services_host_identity@PAGE
Lloh25:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB9_8
; %bb.5:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB9_8
; %bb.6:
	ldr	w8, [x0, #12]
	cmp	w8, #3
	b.ne	LBB9_8
; %bb.7:
	ldr	x8, [x0, #24]
	sub	x8, x8, #65
	cmn	x8, #64
	b.hs	LBB9_13
LBB9_8:
	mov	w19, #4                         ; =0x4
	b	LBB9_11
LBB9_9:
	mov	w19, #1                         ; =0x1
	b	LBB9_11
LBB9_10:
	mov	w19, #0                         ; =0x0
LBB9_11:
	bl	_nvm_file_host_leave
LBB9_12:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB9_13:
	bl	_free
	mov	w19, #0                         ; =0x0
	str	xzr, [x20]
	b	LBB9_11
	.loh AdrpAdd	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_host_authorize    ; -- Begin function nvm_services_host_authorize
	.p2align	2
_nvm_services_host_authorize:           ; @nvm_services_host_authorize
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_18
; %bb.1:
	ldr	x8, [x0]
Lloh26:
	adrp	x9, _services_host_identity@PAGE
Lloh27:
	add	x9, x9, _services_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB10_5
; %bb.2:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB10_5
; %bb.3:
	ldr	w8, [x0, #12]
	cmp	w8, #3
	b.ne	LBB10_5
; %bb.4:
	ldr	x8, [x0, #24]
	sub	x8, x8, #65
	cmn	x8, #64
	b.hs	LBB10_6
LBB10_5:
	mov	w0, #4                          ; =0x4
	ret
LBB10_6:
	ldrb	w8, [x0, #16]
	cmp	w8, #1
	b.ne	LBB10_19
; %bb.7:
	cbz	x1, LBB10_18
; %bb.8:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	w19, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	add	x21, x0, #32
	mov	w22, #1                         ; =0x1
	mov	w24, #24                        ; =0x18
	mov	w25, #3                         ; =0x3
LBB10_9:                                ; =>This Inner Loop Header: Depth=1
	mov	x26, x0
	add	x2, sp, #12
	mov	x20, x1
	mov	x0, x1
	mov	x1, x19
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB10_20
; %bb.10:                               ;   in Loop: Header=BB10_9 Depth=1
	add	w1, w19, #6
	add	x2, sp, #12
	mov	x0, x20
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB10_20
; %bb.11:                               ;   in Loop: Header=BB10_9 Depth=1
	add	w1, w19, #8
	add	x2, sp, #12
	mov	x0, x20
	bl	_nvm_services_indirect_hosted_type
	tbz	w0, #0, LBB10_13
; %bb.12:                               ;   in Loop: Header=BB10_9 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB10_14
LBB10_13:                               ;   in Loop: Header=BB10_9 Depth=1
	add	w1, w19, #7
	add	x2, sp, #12
	mov	x0, x20
	bl	_nvm_services_indirect_hosted_type
	cmp	w0, #0
	csinc	w8, w25, wzr, eq
LBB10_14:                               ;   in Loop: Header=BB10_9 Depth=1
	mov	x0, x26
	madd	x9, x23, x24, x21
	ldr	w10, [x9, #4]
	cmp	w8, w10
	b.ne	LBB10_20
; %bb.15:                               ;   in Loop: Header=BB10_9 Depth=1
	ldrb	w8, [x9, #8]
	tbz	w8, #0, LBB10_21
; %bb.16:                               ;   in Loop: Header=BB10_9 Depth=1
	mov	w23, w22
	ldr	x8, [x0, #24]
	add	w19, w19, #9
	add	w22, w22, #1
	cmp	x8, x23
	mov	x1, x20
	b.hi	LBB10_9
; %bb.17:
	add	w8, w8, w8, lsl #3
	add	x2, sp, #12
	mov	x0, x1
	mov	x1, x8
	bl	_nvm_services_indirect_hosted_type
	mov	w8, #4                          ; =0x4
	cmp	w0, #0
	csel	w0, w8, wzr, ne
	b	LBB10_22
LBB10_18:
	mov	w0, #1                          ; =0x1
	ret
LBB10_19:
	mov	w0, #3                          ; =0x3
	ret
LBB10_20:
	mov	w0, #4                          ; =0x4
	b	LBB10_22
LBB10_21:
	mov	w0, #3                          ; =0x3
LBB10_22:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpAdd	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @services_host_identity
_services_host_identity:
	.long	1                               ; 0x1

.subsections_via_symbols
