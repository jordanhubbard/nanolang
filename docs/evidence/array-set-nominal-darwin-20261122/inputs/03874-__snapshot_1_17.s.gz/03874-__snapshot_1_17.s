	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_passive_valid      ; -- Begin function nvm_passive_valid
	.globl	_nvm_passive_valid
	.p2align	2
_nvm_passive_valid:                     ; @nvm_passive_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #272]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB0_295
; %bb.1:
	ldr	w9, [x0, #352]
	ldr	x19, [x0, #344]
	orr	x8, x9, x19
	cmp	x8, #0
	cset	w8, eq
	cmp	w9, #0
	ccmp	x19, #0, #4, ne
	b.eq	LBB0_296
; %bb.2:
	ldr	x8, [x0, #280]
	cbz	x8, LBB0_296
; %bb.3:
	ldr	x8, [x0, #256]
	cmp	w9, #4
	ccmp	x8, #0, #4, hs
	b.eq	LBB0_295
; %bb.4:
	and	x8, x9, #0xfffffffc
	cmp	x8, #4
	b.eq	LBB0_295
; %bb.5:
	ldp	w8, w23, [x19], #8
	sub	x21, x9, #8
	str	w8, [sp, #104]                  ; 4-byte Folded Spill
	sub	w8, w8, #3
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #43690, lsl #16
	mul	x9, x21, x9
	lsr	x9, x9, #37
	cmn	w8, #2
	ccmp	w23, #0, #4, hs
	ccmp	w9, w23, #0, ne
	b.lo	LBB0_295
; %bb.6:
	stp	x0, x0, [sp, #136]              ; 8-byte Folded Spill
	str	xzr, [sp, #160]
	ldr	w8, [x0, #272]
	cmp	w8, #1
	csinc	w0, w8, wzr, hi
	mov	w1, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #152]
	cbz	x0, LBB0_295
; %bb.7:
	mov	w11, #0                         ; =0x0
	stp	w23, wzr, [sp, #48]             ; 8-byte Folded Spill
	mov	w12, #0                         ; =0x0
	mov	w25, #48                        ; =0x30
	mov	w28, #1                         ; =0x1
LBB0_8:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_29 Depth 2
                                        ;       Child Loop BB0_77 Depth 3
                                        ;       Child Loop BB0_57 Depth 3
                                        ;       Child Loop BB0_85 Depth 3
                                        ;       Child Loop BB0_90 Depth 3
                                        ;       Child Loop BB0_93 Depth 3
                                        ;     Child Loop BB0_98 Depth 2
                                        ;       Child Loop BB0_100 Depth 3
                                        ;         Child Loop BB0_103 Depth 4
                                        ;       Child Loop BB0_116 Depth 3
                                        ;         Child Loop BB0_134 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_138 Depth 4
                                        ;       Child Loop BB0_216 Depth 3
                                        ;       Child Loop BB0_219 Depth 3
                                        ;       Child Loop BB0_109 Depth 3
                                        ;       Child Loop BB0_156 Depth 3
                                        ;       Child Loop BB0_158 Depth 3
                                        ;         Child Loop BB0_176 Depth 4
                                        ;         Child Loop BB0_186 Depth 4
                                        ;         Child Loop BB0_180 Depth 4
                                        ;         Child Loop BB0_194 Depth 4
                                        ;       Child Loop BB0_227 Depth 3
                                        ;       Child Loop BB0_231 Depth 3
                                        ;     Child Loop BB0_260 Depth 2
                                        ;       Child Loop BB0_276 Depth 3
                                        ;       Child Loop BB0_284 Depth 3
                                        ;         Child Loop BB0_286 Depth 4
	subs	x8, x21, #4
	b.lo	LBB0_300
; %bb.9:                                ;   in Loop: Header=BB0_8 Depth=1
	cmp	x8, #4
	b.lo	LBB0_299
; %bb.10:                               ;   in Loop: Header=BB0_8 Depth=1
	sub	x8, x21, #8
	cmp	x8, #4
	b.lo	LBB0_299
; %bb.11:                               ;   in Loop: Header=BB0_8 Depth=1
	sub	x8, x21, #12
	cmp	x8, #4
	b.lo	LBB0_299
; %bb.12:                               ;   in Loop: Header=BB0_8 Depth=1
	sub	x8, x21, #16
	cmp	x8, #4
	b.lo	LBB0_299
; %bb.13:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w8, [x19]
	sub	x21, x21, #20
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
	sub	w8, w8, #1
	cmp	w8, #2
	cset	w8, lo
	and	w8, w28, w8
	cmp	w8, #1
	b.ne	LBB0_298
; %bb.14:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w13, [x19, #4]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w9, [x8, #272]
	mov	w28, #1                         ; =0x1
	cmp	w13, w9
	b.hs	LBB0_298
; %bb.15:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w20, [x19, #16]
	cbz	w20, LBB0_301
; %bb.16:                               ;   in Loop: Header=BB0_8 Depth=1
	lsr	x9, x21, #2
	mov	x10, #18725                     ; =0x4925
	movk	x10, #9362, lsl #16
	movk	x10, #37449, lsl #32
	movk	x10, #18724, lsl #48
	umulh	x9, x9, x10
	lsr	x9, x9, #1
	cmp	x9, x20
	b.lo	LBB0_298
; %bb.17:                               ;   in Loop: Header=BB0_8 Depth=1
	ldp	w9, w22, [x19, #8]
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
	cmp	w9, w22
	b.hs	LBB0_298
; %bb.18:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w9, [x8, #288]
	cmp	w22, w9
	b.hi	LBB0_298
; %bb.19:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	x8, [x8, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x14, w13, w10, x8
	ldr	w8, [x14, #8]
	subs	w10, w9, w8
	b.lo	LBB0_298
; %bb.20:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w9, [x14, #12]
	cmp	w9, w10
	b.hi	LBB0_298
; %bb.21:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	cmp	w10, w8
	b.lo	LBB0_298
; %bb.22:                               ;   in Loop: Header=BB0_8 Depth=1
	add	w8, w9, w8
	cmp	w22, w8
	b.hi	LBB0_298
; %bb.23:                               ;   in Loop: Header=BB0_8 Depth=1
	cbz	w11, LBB0_27
; %bb.24:                               ;   in Loop: Header=BB0_8 Depth=1
	cmp	w13, w12
	b.lo	LBB0_298
; %bb.25:                               ;   in Loop: Header=BB0_8 Depth=1
	cmp	w13, w12
	b.ne	LBB0_27
; %bb.26:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	cmp	w9, w8
	b.lo	LBB0_298
LBB0_27:                                ;   in Loop: Header=BB0_8 Depth=1
	stp	x13, x14, [sp, #112]            ; 16-byte Folded Spill
	str	w11, [sp, #68]                  ; 4-byte Folded Spill
	mov	x0, x20
	mov	w1, #48                         ; =0x30
	bl	_calloc
	cbz	x0, LBB0_298
; %bb.28:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	x26, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	ldp	x4, x6, [sp, #112]              ; 16-byte Folded Reload
	mov	x1, x4
	str	x22, [sp, #72]                  ; 8-byte Folded Spill
	str	w22, [sp, #52]                  ; 4-byte Folded Spill
	add	x19, x19, #20
	add	x8, x0, #104
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x8, x0, #8
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	str	w4, [sp, #108]                  ; 4-byte Folded Spill
	stp	x0, x20, [sp, #88]              ; 16-byte Folded Spill
LBB0_29:                                ;   Parent Loop BB0_8 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_77 Depth 3
                                        ;       Child Loop BB0_57 Depth 3
                                        ;       Child Loop BB0_85 Depth 3
                                        ;       Child Loop BB0_90 Depth 3
                                        ;       Child Loop BB0_93 Depth 3
	madd	x9, x24, x25, x0
	cmp	x21, #3
	b.ls	LBB0_243
; %bb.30:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x10, x19
	ldr	w8, [x10], #4
	sub	x11, x21, #4
	str	w8, [x9]
	cmp	x11, #3
	b.ls	LBB0_244
; %bb.31:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w14, [x19, #4]
	sub	x10, x21, #8
	str	w14, [x9, #4]
	cmp	x10, #3
	b.ls	LBB0_246
; %bb.32:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w27, [x19, #8]
	sub	x10, x21, #12
	str	w27, [x9, #8]
	cmp	x10, #3
	b.ls	LBB0_247
; %bb.33:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w13, [x19, #12]
	sub	x10, x21, #16
	str	w13, [x9, #12]
	cmp	x10, #4
	b.lo	LBB0_249
; %bb.34:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w12, [x19, #16]
	sub	x10, x21, #20
	str	w12, [x9, #16]
	cmp	x10, #4
	b.lo	LBB0_250
; %bb.35:                               ;   in Loop: Header=BB0_29 Depth=2
	sub	x10, x21, #24
	cmp	x10, #4
	b.lo	LBB0_251
; %bb.36:                               ;   in Loop: Header=BB0_29 Depth=2
	add	x10, x19, #28
	sub	x11, x21, #28
	tbz	w28, #0, LBB0_242
; %bb.37:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w15, [x19, #20]
	cbnz	w15, LBB0_242
; %bb.38:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w15, [x19, #24]
	cbnz	w15, LBB0_242
; %bb.39:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	x15, [sp, #128]                 ; 8-byte Folded Reload
	cmp	w8, w15
	b.lo	LBB0_242
; %bb.40:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	w28, #1                         ; =0x1
	ldr	x15, [sp, #72]                  ; 8-byte Folded Reload
	cmp	w14, w15
	b.hi	LBB0_242
; %bb.41:                               ;   in Loop: Header=BB0_29 Depth=2
	cmp	w8, w14
	b.hs	LBB0_242
; %bb.42:                               ;   in Loop: Header=BB0_29 Depth=2
	ldrh	w8, [x6, #4]
	cmp	w27, w8
	b.lo	LBB0_242
; %bb.43:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #104]                  ; 4-byte Folded Reload
	cmp	w8, #1
	ldrh	w14, [x6, #16]
	ccmp	w12, #0, #4, eq
	cset	w8, eq
	cmp	w27, w14
	b.hs	LBB0_242
; %bb.44:                               ;   in Loop: Header=BB0_29 Depth=2
	cmp	w13, w20
	b.hi	LBB0_242
; %bb.45:                               ;   in Loop: Header=BB0_29 Depth=2
	cbz	w8, LBB0_242
; %bb.46:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	cmp	w8, #1
	add	x14, x12, x13
	ccmp	w13, #0, #4, eq
	cset	w8, eq
	cmp	x14, x11, lsr #2
	b.hi	LBB0_242
; %bb.47:                               ;   in Loop: Header=BB0_29 Depth=2
	cbz	w8, LBB0_242
; %bb.48:                               ;   in Loop: Header=BB0_29 Depth=2
	str	x10, [x9, #24]
	cbz	w13, LBB0_51
; %bb.49:                               ;   in Loop: Header=BB0_29 Depth=2
	cmp	x11, #3
	cset	w28, hi
	cmp	x11, #4
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	b.lo	LBB0_52
; %bb.50:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	w14, [x19, #28]
	add	x15, x19, #32
	sub	x11, x21, #32
	b	LBB0_53
LBB0_51:                                ;   in Loop: Header=BB0_29 Depth=2
	mov	w22, #1                         ; =0x1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	b	LBB0_55
LBB0_52:                                ;   in Loop: Header=BB0_29 Depth=2
	mov	w14, #0                         ; =0x0
	mov	x15, x10
LBB0_53:                                ;   in Loop: Header=BB0_29 Depth=2
	cmp	w14, w20
	mov	w14, w14
	ccmp	x24, x14, #4, lo
	cset	w22, ne
	cmp	w13, #1
	b.ne	LBB0_74
; %bb.54:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x10, x15
LBB0_55:                                ;   in Loop: Header=BB0_29 Depth=2
	str	x10, [x9, #32]
	cbz	w12, LBB0_72
; %bb.56:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x23, #0                         ; =0x0
	sub	x25, x10, #4
	lsl	x20, x12, #2
	mov	x21, x11
	mov	x19, x10
LBB0_57:                                ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	subs	x9, x21, #4
	b.hs	LBB0_59
; %bb.58:                               ;   in Loop: Header=BB0_57 Depth=3
	mov	w28, #0                         ; =0x0
	mov	w2, #0                          ; =0x0
	b	LBB0_60
LBB0_59:                                ;   in Loop: Header=BB0_57 Depth=3
	ldr	w2, [x19], #4
	mov	x21, x9
LBB0_60:                                ;   in Loop: Header=BB0_57 Depth=3
	ldrh	w9, [x6, #4]
	cmp	w2, w9
	b.hs	LBB0_67
; %bb.61:                               ;   in Loop: Header=BB0_57 Depth=3
	cbz	x23, LBB0_63
; %bb.62:                               ;   in Loop: Header=BB0_57 Depth=3
	ldr	w9, [x25, x23]
	cmp	w2, w9
	b.ls	LBB0_67
LBB0_63:                                ;   in Loop: Header=BB0_57 Depth=3
	ldr	x9, [x8, #264]
	cbz	x9, LBB0_67
; %bb.64:                               ;   in Loop: Header=BB0_57 Depth=3
	ldr	x9, [x9, x4, lsl #3]
	cbz	x9, LBB0_67
; %bb.65:                               ;   in Loop: Header=BB0_57 Depth=3
	ldrb	w9, [x9, w2, uxtw]
	sub	w9, w9, #1
	cmp	w9, #4
	b.hi	LBB0_67
; %bb.66:                               ;   in Loop: Header=BB0_57 Depth=3
	ldp	x3, x0, [sp, #128]              ; 16-byte Folded Reload
                                        ; kill: def $w3 killed $w3 killed $x3
	bl	_guarded_input
	ldp	x4, x6, [sp, #112]              ; 16-byte Folded Reload
	ldr	w1, [sp, #108]                  ; 4-byte Folded Reload
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	tbnz	w0, #0, LBB0_68
LBB0_67:                                ;   in Loop: Header=BB0_57 Depth=3
	mov	w22, #0                         ; =0x0
LBB0_68:                                ;   in Loop: Header=BB0_57 Depth=3
	add	x23, x23, #4
	cmp	x20, x23
	b.ne	LBB0_57
; %bb.69:                               ;   in Loop: Header=BB0_29 Depth=2
	ldr	x20, [sp, #96]                  ; 8-byte Folded Reload
	cbz	x24, LBB0_73
LBB0_70:                                ;   in Loop: Header=BB0_29 Depth=2
	cmp	x24, #3
	mov	w25, #48                        ; =0x30
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b.hi	LBB0_82
; %bb.71:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, x22
	b	LBB0_92
LBB0_72:                                ;   in Loop: Header=BB0_29 Depth=2
	mov	x21, x11
	mov	x19, x10
	ldr	x20, [sp, #96]                  ; 8-byte Folded Reload
	cbnz	x24, LBB0_70
LBB0_73:                                ;   in Loop: Header=BB0_29 Depth=2
	mov	w25, #48                        ; =0x30
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b	LBB0_94
LBB0_74:                                ;   in Loop: Header=BB0_29 Depth=2
	sub	x13, x13, #1
	mov	x14, x10
	mov	x10, x15
	b	LBB0_77
LBB0_75:                                ;   in Loop: Header=BB0_77 Depth=3
	mov	w22, #0                         ; =0x0
LBB0_76:                                ;   in Loop: Header=BB0_77 Depth=3
	add	x14, x14, #4
	subs	x13, x13, #1
	b.eq	LBB0_55
LBB0_77:                                ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	subs	x16, x11, #4
	b.hs	LBB0_79
; %bb.78:                               ;   in Loop: Header=BB0_77 Depth=3
	mov	w28, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	cmp	w15, w20
	b.lo	LBB0_80
	b	LBB0_75
LBB0_79:                                ;   in Loop: Header=BB0_77 Depth=3
	ldr	w15, [x10], #4
	mov	x11, x16
	cmp	w15, w20
	b.hs	LBB0_75
LBB0_80:                                ;   in Loop: Header=BB0_77 Depth=3
	mov	w16, w15
	cmp	x24, x16
	b.eq	LBB0_75
; %bb.81:                               ;   in Loop: Header=BB0_77 Depth=3
	ldr	w16, [x14]
	cmp	w15, w16
	b.ls	LBB0_75
	b	LBB0_76
LBB0_82:                                ;   in Loop: Header=BB0_29 Depth=2
	dup.4s	v0, w27
	cmp	x24, #16
	b.hs	LBB0_84
; %bb.83:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, x22
	b	LBB0_89
LBB0_84:                                ;   in Loop: Header=BB0_29 Depth=2
	and	x10, x24, #0xfffffffffffffff0
	and	x9, x24, #0x7ffffffffffffff0
	movi.2d	v1, #0000000000000000
	mov	x11, x0
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB0_85:                                ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x11, #56
	add	x13, x11, #104
	add	x14, x11, #152
	add	x15, x11, #248
	add	x16, x11, #296
	add	x17, x11, #344
	add	x0, x11, #440
	add	x3, x11, #488
	add	x2, x11, #536
	ldr	s5, [x11, #8]
	ld1.s	{ v5 }[1], [x12]
	add	x12, x11, #632
	ld1.s	{ v5 }[2], [x13]
	ld1.s	{ v5 }[3], [x14]
	ldr	s6, [x11, #200]
	ld1.s	{ v6 }[1], [x15]
	ld1.s	{ v6 }[2], [x16]
	ld1.s	{ v6 }[3], [x17]
	add	x13, x11, #680
	ldr	s7, [x11, #392]
	ld1.s	{ v7 }[1], [x0]
	ld1.s	{ v7 }[2], [x3]
	add	x14, x11, #728
	ld1.s	{ v7 }[3], [x2]
	ldr	s16, [x11, #584]
	ld1.s	{ v16 }[1], [x12]
	ld1.s	{ v16 }[2], [x13]
	ld1.s	{ v16 }[3], [x14]
	cmeq.4s	v5, v5, v0
	xtn.4h	v5, v5
	cmeq.4s	v6, v6, v0
	xtn.4h	v6, v6
	cmeq.4s	v7, v7, v0
	xtn.4h	v7, v7
	cmeq.4s	v16, v16, v0
	xtn.4h	v16, v16
	orr.8b	v1, v1, v5
	orr.8b	v2, v2, v6
	orr.8b	v3, v3, v7
	orr.8b	v4, v4, v16
	add	x11, x11, #768
	subs	x10, x10, #16
	b.ne	LBB0_85
; %bb.86:                               ;   in Loop: Header=BB0_29 Depth=2
	orr.8b	v1, v2, v1
	orr.8b	v1, v3, v1
	orr.8b	v1, v4, v1
	shl.4h	v1, v1, #15
	cmlt.4h	v1, v1, #0
	umaxv.4h	h1, v1
	fmov	w10, s1
	eor	w10, w10, #0x1
	and	w10, w10, w22
	cmp	x24, x9
	b.ne	LBB0_88
; %bb.87:                               ;   in Loop: Header=BB0_29 Depth=2
	mov	x22, x10
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b	LBB0_94
LBB0_88:                                ;   in Loop: Header=BB0_29 Depth=2
	tst	x24, #0xc
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b.eq	LBB0_92
LBB0_89:                                ;   in Loop: Header=BB0_29 Depth=2
	and	x11, x24, #0xfffffffffffffffc
	eor	w12, w10, w22
	sub	x10, x9, x11
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	madd	x11, x9, x25, x11
	and	x9, x24, #0x7ffffffffffffffc
	dup.4h	v1, w12
LBB0_90:                                ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w12, [x11, #-96]
	ldur	w13, [x11, #-48]
	ldr	w14, [x11]
	ldr	w15, [x11, #48]
	fmov	s2, w12
	mov.s	v2[1], w13
	mov.s	v2[2], w14
	mov.s	v2[3], w15
	cmeq.4s	v2, v2, v0
	xtn.4h	v2, v2
	orr.8b	v1, v1, v2
	add	x11, x11, #192
	adds	x10, x10, #4
	b.ne	LBB0_90
; %bb.91:                               ;   in Loop: Header=BB0_29 Depth=2
	shl.4h	v0, v1, #15
	cmlt.4h	v0, v0, #0
	umaxv.4h	h0, v0
	fmov	w10, s0
	eor	w10, w10, #0x1
	and	w10, w10, w22
	mov	x22, x10
	cmp	x24, x9
	b.eq	LBB0_94
LBB0_92:                                ;   in Loop: Header=BB0_29 Depth=2
	add	x11, x9, x26
	ldr	x12, [sp, #56]                  ; 8-byte Folded Reload
	madd	x9, x9, x25, x12
	mov	x22, x10
LBB0_93:                                ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9], #48
	cmp	w10, w27
	cset	w10, ne
	and	w22, w10, w22
	adds	x11, x11, #1
	b.lo	LBB0_93
LBB0_94:                                ;   in Loop: Header=BB0_29 Depth=2
	tbz	w22, #0, LBB0_96
; %bb.95:                               ;   in Loop: Header=BB0_29 Depth=2
	add	x24, x24, #1
	sub	x26, x26, #1
	cmp	x24, x20
	b.lo	LBB0_29
LBB0_96:                                ;   in Loop: Header=BB0_8 Depth=1
	tbz	w22, #0, LBB0_256
; %bb.97:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w14, #0                         ; =0x0
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	mov	x20, x9
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
LBB0_98:                                ;   Parent Loop BB0_8 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_100 Depth 3
                                        ;         Child Loop BB0_103 Depth 4
                                        ;       Child Loop BB0_116 Depth 3
                                        ;         Child Loop BB0_134 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_138 Depth 4
                                        ;       Child Loop BB0_216 Depth 3
                                        ;       Child Loop BB0_219 Depth 3
                                        ;       Child Loop BB0_109 Depth 3
                                        ;       Child Loop BB0_156 Depth 3
                                        ;       Child Loop BB0_158 Depth 3
                                        ;         Child Loop BB0_176 Depth 4
                                        ;         Child Loop BB0_186 Depth 4
                                        ;         Child Loop BB0_180 Depth 4
                                        ;         Child Loop BB0_194 Depth 4
                                        ;       Child Loop BB0_227 Depth 3
                                        ;       Child Loop BB0_231 Depth 3
	mov	x9, #0                          ; =0x0
	b	LBB0_100
LBB0_99:                                ;   in Loop: Header=BB0_100 Depth=3
	add	x9, x9, #1
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	cmp	x9, x10
	b.eq	LBB0_257
LBB0_100:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_103 Depth 4
	madd	x11, x9, x25, x0
	ldrb	w10, [x11, #40]
	tbnz	w10, #0, LBB0_99
; %bb.101:                              ;   in Loop: Header=BB0_100 Depth=3
	ldr	w10, [x11, #12]
	cbz	w10, LBB0_105
; %bb.102:                              ;   in Loop: Header=BB0_100 Depth=3
	ldr	x12, [x11, #24]
	mov	w11, #1                         ; =0x1
LBB0_103:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_100 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x12], #4
	umaddl	x13, w13, w25, x0
	ldrb	w13, [x13, #40]
	and	w11, w13, w11
	subs	x10, x10, #1
	b.ne	LBB0_103
; %bb.104:                              ;   in Loop: Header=BB0_100 Depth=3
	tbz	w11, #0, LBB0_99
LBB0_105:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	cmp	w10, w9
	b.eq	LBB0_257
; %bb.106:                              ;   in Loop: Header=BB0_98 Depth=2
	umaddl	x24, w9, w25, x0
	ldr	w9, [x24]
	cmp	w9, w20
	b.ne	LBB0_257
; %bb.107:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	w9, [sp, #104]                  ; 4-byte Folded Reload
	cmp	w9, #2
	str	w14, [sp, #40]                  ; 4-byte Folded Spill
	b.ne	LBB0_112
; %bb.108:                              ;   in Loop: Header=BB0_98 Depth=2
	mov	x26, #0                         ; =0x0
	ldr	w9, [x24, #4]
	str	x9, [sp, #112]                  ; 8-byte Folded Spill
	mov	x22, x20
LBB0_109:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	subs	w1, w9, w22
	b.ls	LBB0_151
; %bb.110:                              ;   in Loop: Header=BB0_109 Depth=3
	ldr	x8, [x8, #280]
	add	x0, x8, w22, uxtw
	add	x2, sp, #168
	bl	_isa_decode
	cbz	w0, LBB0_291
; %bb.111:                              ;   in Loop: Header=BB0_109 Depth=3
	add	w22, w0, w22
	cmp	w26, #16, lsl #12               ; =65536
	add	x26, x26, #1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b.ne	LBB0_109
	b	LBB0_257
LBB0_112:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	mov	w1, #1                          ; =0x1
	mov	x22, x6
	bl	_calloc
	mov	x26, x0
	ldrh	w8, [x22, #4]
	cmp	w8, #1
	csinc	w0, w8, wzr, hi
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x27, x0
	cbz	x26, LBB0_290
; %bb.113:                              ;   in Loop: Header=BB0_98 Depth=2
	cbz	x27, LBB0_290
; %bb.114:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	w8, [x24, #4]
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	cmp	w20, w8
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	b.hs	LBB0_210
; %bb.115:                              ;   in Loop: Header=BB0_98 Depth=2
	str	x24, [sp, #32]                  ; 8-byte Folded Spill
	str	wzr, [sp, #80]                  ; 4-byte Folded Spill
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
LBB0_116:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_134 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_138 Depth 4
	ldr	x8, [x8, #280]
	add	x0, x8, w20, uxtw
	sub	w1, w9, w20
	add	x2, sp, #168
	bl	_isa_decode
	cbz	w0, LBB0_213
; %bb.117:                              ;   in Loop: Header=BB0_116 Depth=3
	mov	x24, x0
	ldrb	w22, [sp, #168]
	mov	x0, x22
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	bl	_allowed
	cbz	w0, LBB0_213
; %bb.118:                              ;   in Loop: Header=BB0_116 Depth=3
	mov	x0, x22
	bl	_isa_get_info
	cbz	x0, LBB0_213
; %bb.119:                              ;   in Loop: Header=BB0_116 Depth=3
	ldrb	w8, [sp, #168]
	cmp	w8, #59
	b.ne	LBB0_122
; %bb.120:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	w1, [sp, #176]
	add	x0, sp, #144
	mov	x22, x1
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_closed_function
	cbz	w0, LBB0_213
; %bb.121:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w22, w10, x9
	ldrh	w10, [x9, #4]
	ldrb	w9, [x9, #21]
	b	LBB0_123
LBB0_122:                               ;   in Loop: Header=BB0_116 Depth=3
	ldrsb	w10, [x0, #28]
	ldrsb	w9, [x0, #29]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
LBB0_123:                               ;   in Loop: Header=BB0_116 Depth=3
	tbnz	w10, #31, LBB0_213
; %bb.124:                              ;   in Loop: Header=BB0_116 Depth=3
	tbnz	w9, #31, LBB0_213
; %bb.125:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	w11, [sp, #80]                  ; 4-byte Folded Reload
	subs	w10, w11, w10
	b.lo	LBB0_213
; %bb.126:                              ;   in Loop: Header=BB0_116 Depth=3
	cmn	w9, w10
	b.hs	LBB0_213
; %bb.127:                              ;   in Loop: Header=BB0_116 Depth=3
	add	w9, w10, w9
	str	w9, [sp, #80]                   ; 4-byte Folded Spill
	ldrb	w9, [sp, #168]
	add	w20, w24, w20
	cmp	w9, #16
	b.eq	LBB0_133
; %bb.128:                              ;   in Loop: Header=BB0_116 Depth=3
	cmp	w9, #17
	b.ne	LBB0_140
; %bb.129:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w20, w8
	b.ne	LBB0_213
; %bb.130:                              ;   in Loop: Header=BB0_116 Depth=3
	ldrh	w8, [sp, #176]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	cmp	w9, w8
	b.ne	LBB0_212
; %bb.131:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	cbnz	w8, LBB0_212
; %bb.132:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	b	LBB0_141
LBB0_133:                               ;   in Loop: Header=BB0_116 Depth=3
	ldr	x14, [sp, #32]                  ; 8-byte Folded Reload
	mov	x10, #0                         ; =0x0
	ldrh	w8, [sp, #176]
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x13, [sp, #96]                  ; 8-byte Folded Reload
	mov	x9, x13
LBB0_134:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_116 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w12, [x11], #48
	cmp	w12, w8
	csel	w9, w10, w9, eq
	add	x10, x10, #1
	cmp	x13, x10
	b.ne	LBB0_134
; %bb.135:                              ;   in Loop: Header=BB0_116 Depth=3
	cmp	w9, w13
	b.hs	LBB0_142
; %bb.136:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	w8, [x14, #12]
	cbz	w8, LBB0_211
; %bb.137:                              ;   in Loop: Header=BB0_116 Depth=3
	mov	x24, x14
	ldr	x10, [x14, #24]
LBB0_138:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_116 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x10], #4
	cmp	w11, w9
	b.eq	LBB0_147
; %bb.139:                              ;   in Loop: Header=BB0_138 Depth=4
	subs	x8, x8, #1
	b.ne	LBB0_138
	b	LBB0_211
LBB0_140:                               ;   in Loop: Header=BB0_116 Depth=3
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w20, w9
	ldr	x24, [sp, #32]                  ; 8-byte Folded Reload
	b.eq	LBB0_150
LBB0_141:                               ;   in Loop: Header=BB0_116 Depth=3
	cmp	w20, w9
	b.lo	LBB0_116
	b	LBB0_221
LBB0_142:                               ;   in Loop: Header=BB0_116 Depth=3
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldrh	w9, [x9, #4]
	cmp	w8, w9
	b.hs	LBB0_212
; %bb.143:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	w9, [x14, #16]
	cbz	w9, LBB0_212
; %bb.144:                              ;   in Loop: Header=BB0_116 Depth=3
	ldr	x10, [x14, #32]
LBB0_145:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_116 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x10], #4
	cmp	w11, w8
	b.eq	LBB0_148
; %bb.146:                              ;   in Loop: Header=BB0_145 Depth=4
	subs	x9, x9, #1
	b.ne	LBB0_145
	b	LBB0_212
LBB0_147:                               ;   in Loop: Header=BB0_116 Depth=3
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, w9, uxtw]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w20, w9
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
	b.ne	LBB0_141
	b	LBB0_150
LBB0_148:                               ;   in Loop: Header=BB0_116 Depth=3
	mov	w9, #1                          ; =0x1
	strb	w9, [x27, w8, uxtw]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w20, w9
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
	b.ne	LBB0_141
; %bb.149:                              ;   in Loop: Header=BB0_98 Depth=2
	mov	x24, x14
LBB0_150:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w20, #0                         ; =0x0
	ldr	w8, [x24, #12]
	cbnz	w8, LBB0_215
	b	LBB0_217
LBB0_151:                               ;   in Loop: Header=BB0_98 Depth=2
	str	x26, [sp, #16]                  ; 8-byte Folded Spill
	mov	x0, x26
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x27, x0
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x26, x0
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #4]
	cmp	w8, #1
	csinc	w0, w8, wzr, hi
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	w22, #0                         ; =0x0
	str	x27, [sp, #80]                  ; 8-byte Folded Spill
	str	x26, [sp, #24]                  ; 8-byte Folded Spill
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	cbz	x27, LBB0_236
; %bb.152:                              ;   in Loop: Header=BB0_98 Depth=2
	cbz	x26, LBB0_236
; %bb.153:                              ;   in Loop: Header=BB0_98 Depth=2
	cbz	x0, LBB0_236
; %bb.154:                              ;   in Loop: Header=BB0_98 Depth=2
	str	x24, [sp, #32]                  ; 8-byte Folded Spill
	ldr	x23, [sp, #16]                  ; 8-byte Folded Reload
	cbz	w23, LBB0_225
; %bb.155:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x22, x8, #8
	mov	x24, #-1                        ; =0xffffffffffffffff
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
LBB0_156:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	stur	w20, [x22, #-8]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #280]
	add	x0, x8, w20, uxtw
	sub	w1, w25, w20
	add	x2, sp, #168
	bl	_isa_decode
	stur	w0, [x22, #-4]
	str	x24, [x22], #16
	add	w20, w0, w20
	subs	x23, x23, #1
	b.ne	LBB0_156
; %bb.157:                              ;   in Loop: Header=BB0_98 Depth=2
	mov	x20, #0                         ; =0x0
	ldr	x24, [sp, #80]                  ; 8-byte Folded Reload
	str	xzr, [x24, #8]
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x27, [sp, #16]                  ; 8-byte Folded Reload
LBB0_158:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_176 Depth 4
                                        ;         Child Loop BB0_186 Depth 4
                                        ;         Child Loop BB0_180 Depth 4
                                        ;         Child Loop BB0_194 Depth 4
	ldr	x8, [x11, #280]
	add	x23, x24, x20, lsl #4
	ldp	w9, w1, [x23]
	str	x9, [sp]                        ; 8-byte Folded Spill
	add	x0, x8, x9
	add	x2, sp, #168
	bl	_isa_decode
	ldrb	w26, [sp, #168]
	mov	x0, x26
	bl	_isa_get_info
	ldr	x23, [x23, #8]
	tbnz	x23, #63, LBB0_234
; %bb.159:                              ;   in Loop: Header=BB0_158 Depth=3
	mov	x8, x0
	cbz	x0, LBB0_234
; %bb.160:                              ;   in Loop: Header=BB0_158 Depth=3
	ldrb	w25, [sp, #168]
	mov	x0, x25
	mov	w1, #2                          ; =0x2
	mov	x22, x27
	mov	x27, x8
	bl	_allowed
	mov	x10, x27
	mov	x27, x22
	cmp	w25, #59
	b.eq	LBB0_164
; %bb.161:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	w26, #58
	b.eq	LBB0_164
; %bb.162:                              ;   in Loop: Header=BB0_158 Depth=3
	and	w8, w26, #0xfe
	cmp	w8, #56
	b.eq	LBB0_164
; %bb.163:                              ;   in Loop: Header=BB0_158 Depth=3
	cbz	w0, LBB0_234
LBB0_164:                               ;   in Loop: Header=BB0_158 Depth=3
	cmp	w25, #59
	b.ne	LBB0_167
; %bb.165:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	w22, [sp, #176]
	add	x0, sp, #144
	mov	x1, x22
	bl	_closed_function
	cbz	w0, LBB0_234
; %bb.166:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w22, w9, x8
	ldrh	w9, [x8, #4]
	ldrb	w8, [x8, #21]
	b	LBB0_168
LBB0_167:                               ;   in Loop: Header=BB0_158 Depth=3
	ldrsb	w9, [x10, #28]
	ldrsb	w8, [x10, #29]
LBB0_168:                               ;   in Loop: Header=BB0_158 Depth=3
	tbnz	w9, #31, LBB0_234
; %bb.169:                              ;   in Loop: Header=BB0_158 Depth=3
	tbnz	w8, #31, LBB0_234
; %bb.170:                              ;   in Loop: Header=BB0_158 Depth=3
	mov	w9, w9
	subs	x9, x23, x9
	b.lo	LBB0_234
; %bb.171:                              ;   in Loop: Header=BB0_158 Depth=3
	mvn	w10, w8
	cmp	x9, x10
	b.hi	LBB0_234
; %bb.172:                              ;   in Loop: Header=BB0_158 Depth=3
	add	x8, x9, w8, uxtw
	ldrb	w9, [sp, #168]
	add	x20, x20, #1
	cmp	w9, #17
	b.eq	LBB0_222
; %bb.173:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	x27, x20
	b.eq	LBB0_234
; %bb.174:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	w9, #16
	b.ne	LBB0_182
; %bb.175:                              ;   in Loop: Header=BB0_158 Depth=3
	mov	x10, #0                         ; =0x0
	ldrh	w11, [sp, #176]
	ldr	x13, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x15, [sp, #96]                  ; 8-byte Folded Reload
	mov	x12, x15
LBB0_176:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_158 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w14, [x13], #48
	cmp	w14, w11
	csel	w12, w10, w12, eq
	add	x10, x10, #1
	cmp	x15, x10
	b.ne	LBB0_176
; %bb.177:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	w12, w15
	b.hs	LBB0_183
; %bb.178:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	w10, [x10, #12]
	cbz	w10, LBB0_181
; %bb.179:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x11, [x11, #24]
	sub	x13, x10, #1
LBB0_180:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_158 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w10, [x11], #4
	cmp	w10, w12
	cset	w10, eq
	ccmp	x13, #0, #4, ne
	sub	x13, x13, #1
	b.ne	LBB0_180
LBB0_181:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	w11, #1                         ; =0x1
	ldr	x13, [sp, #24]                  ; 8-byte Folded Reload
	strb	w11, [x13, w12, uxtw]
	b	LBB0_190
LBB0_182:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	w10, #1                         ; =0x1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	b	LBB0_191
LBB0_183:                               ;   in Loop: Header=BB0_158 Depth=3
	ldr	x10, [sp, #120]                 ; 8-byte Folded Reload
	ldrh	w10, [x10, #4]
	cmp	w11, w10
	b.hs	LBB0_188
; %bb.184:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	w10, [x10, #16]
	cbz	w10, LBB0_190
; %bb.185:                              ;   in Loop: Header=BB0_158 Depth=3
	ldr	x12, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x12, [x12, #32]
LBB0_186:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_158 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x12], #4
	cmp	w13, w11
	b.eq	LBB0_189
; %bb.187:                              ;   in Loop: Header=BB0_186 Depth=4
	subs	x10, x10, #1
	b.ne	LBB0_186
	b	LBB0_190
LBB0_188:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	w10, #0                         ; =0x0
	b	LBB0_190
LBB0_189:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	w10, #1                         ; =0x1
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	strb	w10, [x12, w11, uxtw]
LBB0_190:                               ;   in Loop: Header=BB0_158 Depth=3
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x27, [sp, #16]                  ; 8-byte Folded Reload
LBB0_191:                               ;   in Loop: Header=BB0_158 Depth=3
	sub	w12, w26, #56
	cmp	w12, #2
	b.hi	LBB0_199
; %bb.192:                              ;   in Loop: Header=BB0_158 Depth=3
	ldrsw	x12, [sp, #176]
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	add	x11, x12, x11
	cmp	w12, #1
	ldr	x12, [sp, #112]                 ; 8-byte Folded Reload
	ccmp	x11, x12, #0, ge
	b.ge	LBB0_234
; %bb.193:                              ;   in Loop: Header=BB0_158 Depth=3
	mov	w12, #0                         ; =0x0
	mov	x13, x27
LBB0_194:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ;       Parent Loop BB0_158 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	sub	w14, w13, w12
	add	w14, w12, w14, lsr #1
	ubfiz	x15, x14, #4, #32
	ldr	w15, [x24, x15]
	cmp	w15, w11
	csel	w13, w13, w14, lo
	csinc	w12, w12, w14, hs
	cmp	w12, w13
	b.lo	LBB0_194
; %bb.195:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	w12, w27
	b.hs	LBB0_197
; %bb.196:                              ;   in Loop: Header=BB0_158 Depth=3
	ubfiz	x13, x12, #4, #32
	ldr	w13, [x24, x13]
	cmp	w13, w11
	b.eq	LBB0_198
LBB0_197:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	x12, x27
LBB0_198:                               ;   in Loop: Header=BB0_158 Depth=3
	stur	w12, [x29, #-104]
	mov	w12, #1                         ; =0x1
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	b	LBB0_200
LBB0_199:                               ;   in Loop: Header=BB0_158 Depth=3
	mov	x12, #0                         ; =0x0
LBB0_200:                               ;   in Loop: Header=BB0_158 Depth=3
	cmp	w9, #56
	b.eq	LBB0_202
; %bb.201:                              ;   in Loop: Header=BB0_158 Depth=3
	sub	x9, x29, #104
	str	w20, [x9, x12, lsl #2]
	add	x12, x12, #1
LBB0_202:                               ;   in Loop: Header=BB0_158 Depth=3
	cmp	x12, #0
	csel	w9, wzr, w10, eq
	cmp	w9, #1
	b.ne	LBB0_207
; %bb.203:                              ;   in Loop: Header=BB0_158 Depth=3
	ldur	w9, [x29, #-104]
	cmp	w9, w27
	b.hs	LBB0_234
; %bb.204:                              ;   in Loop: Header=BB0_158 Depth=3
	add	x9, x24, x9, lsl #4
	ldr	x10, [x9, #8]
	cmp	x10, #0
	csel	x13, x8, x10, lt
	cset	w14, lt
	cmp	x10, x8
	csinc	w10, w14, wzr, ne
	str	x13, [x9, #8]
	cmp	w10, #1
	ccmp	x12, #2, #0, eq
	b.lo	LBB0_207
; %bb.205:                              ;   in Loop: Header=BB0_158 Depth=3
	ldur	w9, [x29, #-100]
	cmp	w9, w27
	b.hs	LBB0_234
; %bb.206:                              ;   in Loop: Header=BB0_158 Depth=3
	add	x9, x24, x9, lsl #4
	ldr	x10, [x9, #8]
	cmp	x10, #0
	csel	x12, x8, x10, lt
	cset	w13, lt
	cmp	x10, x8
	csinc	w10, w13, wzr, ne
	str	x12, [x9, #8]
LBB0_207:                               ;   in Loop: Header=BB0_158 Depth=3
	cbz	w10, LBB0_209
; %bb.208:                              ;   in Loop: Header=BB0_158 Depth=3
	cmp	x20, x27
	b.lo	LBB0_158
LBB0_209:                               ;   in Loop: Header=BB0_98 Depth=2
	cbnz	w10, LBB0_225
	b	LBB0_234
LBB0_210:                               ;   in Loop: Header=BB0_98 Depth=2
	str	wzr, [sp, #80]                  ; 4-byte Folded Spill
	mov	w20, #1                         ; =0x1
	ldr	w8, [x24, #12]
	cbnz	w8, LBB0_215
	b	LBB0_217
LBB0_211:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, w9, uxtw]
LBB0_212:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
LBB0_213:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w20, #0                         ; =0x0
LBB0_214:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x24, [sp, #32]                  ; 8-byte Folded Reload
	ldr	w8, [x24, #12]
	cbz	w8, LBB0_217
LBB0_215:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x9, [x24, #24]
LBB0_216:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9], #4
	ldrb	w10, [x26, x10]
	and	w20, w10, w20
	subs	x8, x8, #1
	b.ne	LBB0_216
LBB0_217:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	w8, [x24, #16]
	cbz	w8, LBB0_220
; %bb.218:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	x9, [x24, #32]
LBB0_219:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9], #4
	ldrb	w10, [x27, x10]
	and	w20, w10, w20
	subs	x8, x8, #1
	b.ne	LBB0_219
LBB0_220:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	x0, x26
	bl	_free
	mov	x0, x27
	bl	_free
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	cmp	w8, #0
	cset	w8, eq
	and	w22, w20, w8
	b	LBB0_237
LBB0_221:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w20, #1                         ; =0x1
	b	LBB0_214
LBB0_222:                               ;   in Loop: Header=BB0_98 Depth=2
	cmp	x27, x20
	b.ne	LBB0_234
; %bb.223:                              ;   in Loop: Header=BB0_98 Depth=2
	ldrh	w9, [sp, #176]
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	w10, [x10, #8]
	cmp	w10, w9
	b.ne	LBB0_234
; %bb.224:                              ;   in Loop: Header=BB0_98 Depth=2
	cbnz	x8, LBB0_234
LBB0_225:                               ;   in Loop: Header=BB0_98 Depth=2
	ldp	x11, x8, [sp, #24]              ; 16-byte Folded Reload
	ldr	w8, [x8, #12]
	cbz	w8, LBB0_229
; %bb.226:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #24]
LBB0_227:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9], #4
	ldrb	w10, [x11, x10]
	tbz	w10, #0, LBB0_234
; %bb.228:                              ;   in Loop: Header=BB0_227 Depth=3
	subs	x8, x8, #1
	b.ne	LBB0_227
LBB0_229:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #16]
	cbz	w8, LBB0_233
; %bb.230:                              ;   in Loop: Header=BB0_98 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #32]
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
LBB0_231:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9], #4
	ldrb	w10, [x11, x10]
	tbz	w10, #0, LBB0_234
; %bb.232:                              ;   in Loop: Header=BB0_231 Depth=3
	subs	x8, x8, #1
	b.ne	LBB0_231
LBB0_233:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w22, #1                         ; =0x1
	b	LBB0_235
LBB0_234:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w22, #0                         ; =0x0
LBB0_235:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
	ldr	x24, [sp, #32]                  ; 8-byte Folded Reload
LBB0_236:                               ;   in Loop: Header=BB0_98 Depth=2
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_free
LBB0_237:                               ;   in Loop: Header=BB0_98 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #40]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	w14, [sp, #40]                  ; 4-byte Folded Reload
	ldr	x6, [sp, #120]                  ; 8-byte Folded Reload
	cbz	w22, LBB0_239
; %bb.238:                              ;   in Loop: Header=BB0_98 Depth=2
	add	w14, w14, #1
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	mov	x20, x9
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	cmp	w14, w9
	b.lo	LBB0_98
LBB0_239:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w23, #48                        ; =0x30
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w9, w8
	eor	w8, w22, #0x1
	csinc	w8, w8, wzr, eq
	tbnz	w8, #0, LBB0_288
; %bb.240:                              ;   in Loop: Header=BB0_8 Depth=1
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldp	w9, w8, [x9, #8]
	add	w10, w9, w8
	cmp	w9, w10
	b.hs	LBB0_288
; %bb.241:                              ;   in Loop: Header=BB0_8 Depth=1
	mov	w22, #0                         ; =0x0
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	cmp	w11, w10
	cset	w20, eq
	ldr	x10, [sp, #88]                  ; 8-byte Folded Reload
	add	x24, x10, #4
	mov	x10, x9
	b	LBB0_260
LBB0_242:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w20, #0                         ; =0x0
	mov	x21, x11
	mov	x19, x10
	b	LBB0_253
LBB0_243:                               ;   in Loop: Header=BB0_8 Depth=1
	str	wzr, [x9]
	b	LBB0_245
LBB0_244:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	x21, x11
	mov	x19, x10
LBB0_245:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	stp	wzr, wzr, [x9, #4]
	b	LBB0_248
LBB0_246:                               ;   in Loop: Header=BB0_8 Depth=1
	add	x19, x19, #8
	mov	x21, x10
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	str	wzr, [x9, #8]
	b	LBB0_248
LBB0_247:                               ;   in Loop: Header=BB0_8 Depth=1
	add	x19, x19, #12
	mov	x21, x10
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
LBB0_248:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w28, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	str	wzr, [x9, #12]
	b	LBB0_254
LBB0_249:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w28, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	add	x19, x19, #16
	b	LBB0_252
LBB0_250:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w28, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	add	x19, x19, #20
	b	LBB0_252
LBB0_251:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w28, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	add	x19, x19, #24
LBB0_252:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	x21, x10
LBB0_253:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
LBB0_254:                               ;   in Loop: Header=BB0_8 Depth=1
	bl	_free
	tbz	w20, #0, LBB0_301
; %bb.255:                              ;   in Loop: Header=BB0_8 Depth=1
	ldr	w11, [sp, #68]                  ; 4-byte Folded Reload
	add	w11, w11, #1
	cmp	w11, w23
	ldr	w12, [sp, #108]                 ; 4-byte Folded Reload
	b.lo	LBB0_8
	b	LBB0_301
LBB0_256:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w20, #0                         ; =0x0
	b	LBB0_253
LBB0_257:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w20, #0                         ; =0x0
	b	LBB0_254
LBB0_258:                               ;   in Loop: Header=BB0_260 Depth=2
	tbz	w8, #0, LBB0_293
LBB0_259:                               ;   in Loop: Header=BB0_260 Depth=2
	add	w10, w26, w25
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldp	w9, w8, [x8, #8]
	add	w11, w8, w9
	cmp	w10, w11
	b.hs	LBB0_294
LBB0_260:                               ;   Parent Loop BB0_8 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_276 Depth 3
                                        ;       Child Loop BB0_284 Depth 3
                                        ;         Child Loop BB0_286 Depth 4
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
	ldr	x11, [x11, #280]
	mov	w25, w10
	sub	w9, w9, w10
	add	w1, w9, w8
	add	x0, x11, x25
	add	x2, sp, #168
	bl	_isa_decode
	cbz	w0, LBB0_288
; %bb.261:                              ;   in Loop: Header=BB0_260 Depth=2
	mov	x26, x0
	ldrb	w27, [sp, #168]
	mov	x0, x27
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	bl	_allowed
	tbnz	w0, #0, LBB0_270
; %bb.262:                              ;   in Loop: Header=BB0_260 Depth=2
	cmp	w27, #61
	b.ls	LBB0_269
LBB0_263:                               ;   in Loop: Header=BB0_260 Depth=2
	sub	w8, w27, #160
	cmp	w8, #4
	b.hi	LBB0_265
; %bb.264:                              ;   in Loop: Header=BB0_260 Depth=2
	cmp	w8, #2
	b.ne	LBB0_270
LBB0_265:                               ;   in Loop: Header=BB0_260 Depth=2
	ldr	w8, [sp, #104]                  ; 4-byte Folded Reload
	cmp	w8, #2
	b.ne	LBB0_288
; %bb.266:                              ;   in Loop: Header=BB0_260 Depth=2
	cmp	w27, #140
	b.eq	LBB0_268
; %bb.267:                              ;   in Loop: Header=BB0_260 Depth=2
	cmp	w27, #59
	b.ne	LBB0_288
LBB0_268:                               ;   in Loop: Header=BB0_260 Depth=2
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	cmp	w25, w8
	cset	w8, eq
	orr	w22, w8, w22
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	cmp	w25, w8
	cset	w8, eq
	orr	w20, w8, w20
	b	LBB0_259
LBB0_269:                               ;   in Loop: Header=BB0_260 Depth=2
	mov	w8, #1                          ; =0x1
	lsl	x8, x8, x27
	mov	x9, #2810246167479189504        ; =0x2700000000000000
	tst	x8, x9
	b.eq	LBB0_263
LBB0_270:                               ;   in Loop: Header=BB0_260 Depth=2
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	cmp	w25, w8
	cset	w8, eq
	orr	w22, w8, w22
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	cmp	w25, w8
	cset	w8, eq
	orr	w20, w8, w20
	sub	w8, w27, #56
	cmp	w8, #2
	b.hi	LBB0_278
; %bb.271:                              ;   in Loop: Header=BB0_260 Depth=2
	ldrsw	x8, [sp, #176]
	add	x8, x8, x25
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	cmp	x8, x9
	b.le	LBB0_259
; %bb.272:                              ;   in Loop: Header=BB0_260 Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	cmp	x8, x9
	b.ge	LBB0_259
; %bb.273:                              ;   in Loop: Header=BB0_260 Depth=2
	ldr	w9, [sp, #104]                  ; 4-byte Folded Reload
	cmp	w9, #2
	b.ne	LBB0_288
; %bb.274:                              ;   in Loop: Header=BB0_260 Depth=2
	mov	x9, x24
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	b	LBB0_276
LBB0_275:                               ;   in Loop: Header=BB0_276 Depth=3
	add	x9, x9, #48
	subs	x10, x10, #1
	b.eq	LBB0_279
LBB0_276:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_260 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w11, [x9, #-4]
	cmp	w25, w11
	b.lo	LBB0_275
; %bb.277:                              ;   in Loop: Header=BB0_276 Depth=3
	ldr	w11, [x9]
	cmp	w25, w11
	ccmp	x8, x25, #0, lo
	ccmp	x8, x11, #2, hi
	b.hs	LBB0_275
LBB0_278:                               ;   in Loop: Header=BB0_260 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB0_280
LBB0_279:                               ;   in Loop: Header=BB0_260 Depth=2
	mov	w8, #0                          ; =0x0
LBB0_280:                               ;   in Loop: Header=BB0_260 Depth=2
	cmp	w27, #17
	b.ne	LBB0_258
; %bb.281:                              ;   in Loop: Header=BB0_260 Depth=2
	mov	x9, #0                          ; =0x0
	ldrh	w10, [sp, #176]
	ldr	x14, [sp, #88]                  ; 8-byte Folded Reload
	b	LBB0_284
LBB0_282:                               ;   in Loop: Header=BB0_284 Depth=3
	mov	w8, #0                          ; =0x0
LBB0_283:                               ;   in Loop: Header=BB0_284 Depth=3
	add	x9, x9, #1
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	cmp	x9, x11
	b.eq	LBB0_258
LBB0_284:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_260 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_286 Depth 4
	madd	x12, x9, x23, x14
	ldr	w11, [x12, #16]
	cbz	w11, LBB0_283
; %bb.285:                              ;   in Loop: Header=BB0_284 Depth=3
	ldr	x12, [x12, #32]
LBB0_286:                               ;   Parent Loop BB0_8 Depth=1
                                        ;     Parent Loop BB0_260 Depth=2
                                        ;       Parent Loop BB0_284 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w13, [x12], #4
	cmp	w13, w10
	b.eq	LBB0_282
; %bb.287:                              ;   in Loop: Header=BB0_286 Depth=4
	subs	x11, x11, #1
	b.ne	LBB0_286
	b	LBB0_283
LBB0_288:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w20, #0                         ; =0x0
LBB0_289:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	w23, [sp, #48]                  ; 4-byte Folded Reload
	mov	w25, #48                        ; =0x30
	b	LBB0_292
LBB0_290:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	x0, x26
	bl	_free
	mov	x0, x27
	bl	_free
LBB0_291:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w20, #0                         ; =0x0
LBB0_292:                               ;   in Loop: Header=BB0_8 Depth=1
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	b	LBB0_254
LBB0_293:                               ;   in Loop: Header=BB0_8 Depth=1
	mov	w22, #0                         ; =0x0
LBB0_294:                               ;   in Loop: Header=BB0_8 Depth=1
	and	w20, w22, w20
	b	LBB0_289
LBB0_295:
	mov	w8, #0                          ; =0x0
LBB0_296:
	ldur	x9, [x29, #-96]
Lloh3:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB0_302
; %bb.297:
	mov	x0, x8
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
LBB0_298:
	mov	w20, #0                         ; =0x0
	b	LBB0_301
LBB0_299:
	mov	w20, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	x21, x8
	b	LBB0_301
LBB0_300:
	mov	w20, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
LBB0_301:
	ldr	x0, [sp, #152]
	bl	_free
	and	w8, w20, w28
	cmp	x21, #0
	cset	w9, eq
	and	w8, w8, w9
	b	LBB0_296
LBB0_302:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function guarded_input
_guarded_input:                         ; @guarded_input
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #208]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #224]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #240]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh6:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	ldr	x8, [x0, #264]
	cbz	x8, LBB1_18
; %bb.1:
	ldr	x8, [x8, w1, uxtw #3]
	cbz	x8, LBB1_18
; %bb.2:
	ldr	x8, [x0, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x19, w1, w9, x8
	ldr	w24, [x19, #8]
	cmp	w3, w24
	b.ls	LBB1_18
; %bb.3:
	mov	x20, x1
	mov	x21, x2
	mov	x22, x0
	ldr	x8, [x0, #280]
	mov	x23, x3
	sub	w1, w3, w24
	add	x0, x8, x24
	add	x2, sp, #8
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.4:
	add	w25, w0, w24
	subs	w1, w23, w25
	b.ls	LBB1_18
; %bb.5:
	add	x24, sp, #8
	ldr	x8, [x22, #280]
	add	x0, x8, w25, uxtw
	add	x2, x24, #64
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.6:
	add	w26, w0, w25
	subs	w1, w23, w26
	b.ls	LBB1_18
; %bb.7:
	ldr	x8, [x22, #280]
	add	x0, x8, w26, uxtw
	add	x2, x24, #128
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.8:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [sp, #8]
	cmp	w9, #16
	b.ne	LBB1_19
; %bb.9:
	ldrb	w9, [sp, #72]
	cmp	w9, #140
	b.ne	LBB1_19
; %bb.10:
	ldrb	w9, [sp, #136]
	cmp	w9, #161
	b.ne	LBB1_19
; %bb.11:
	ldrh	w25, [sp, #16]
	ldrh	w13, [x19, #4]
	cmp	w25, w13
	b.hs	LBB1_18
; %bb.12:
	mov	x9, x22
	mov	w0, #0                          ; =0x0
	ldr	x13, [x22, #264]
	ldr	x12, [x13, w20, uxtw #3]
	ldrb	w12, [x12, w25, uxtw]
	cmp	w12, #2
	b.eq	LBB1_19
; %bb.13:
	sub	w13, w12, #1
	cmp	w13, #4
	b.hi	LBB1_19
; %bb.14:
	ldrb	w13, [sp, #80]
	cmp	w13, w12
	b.ne	LBB1_19
; %bb.15:
	cmp	w21, w25
	b.ne	LBB1_17
LBB1_16:
	mov	w0, #1                          ; =0x1
	b	LBB1_19
LBB1_17:
	b.hs	LBB1_21
LBB1_18:
	mov	w0, #0                          ; =0x0
LBB1_19:
	ldur	x8, [x29, #-88]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_38
; %bb.20:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #240]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #224]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
LBB1_21:
	mov	x10, x23
	add	w26, w8, w26
LBB1_22:                                ; =>This Inner Loop Header: Depth=1
	subs	w1, w10, w26
	b.ls	LBB1_18
; %bb.23:                               ;   in Loop: Header=BB1_22 Depth=1
	ldr	x8, [x9, #280]
	add	x0, x8, w26, uxtw
	add	x2, sp, #8
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.24:                               ;   in Loop: Header=BB1_22 Depth=1
	add	w26, w0, w26
	subs	w1, w23, w26
	b.ls	LBB1_18
; %bb.25:                               ;   in Loop: Header=BB1_22 Depth=1
	ldr	x8, [x22, #280]
	add	x0, x8, w26, uxtw
	add	x2, x24, #64
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.26:                               ;   in Loop: Header=BB1_22 Depth=1
	add	w26, w0, w26
	subs	w1, w23, w26
	b.ls	LBB1_18
; %bb.27:                               ;   in Loop: Header=BB1_22 Depth=1
	ldr	x8, [x22, #280]
	add	x0, x8, w26, uxtw
	add	x2, x24, #128
	bl	_isa_decode
	cbz	w0, LBB1_19
; %bb.28:                               ;   in Loop: Header=BB1_22 Depth=1
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [sp, #8]
	cmp	w9, #16
	b.ne	LBB1_19
; %bb.29:                               ;   in Loop: Header=BB1_22 Depth=1
	ldrb	w9, [sp, #72]
	cmp	w9, #140
	b.ne	LBB1_19
; %bb.30:                               ;   in Loop: Header=BB1_22 Depth=1
	ldrb	w12, [sp, #136]
	cmp	w12, #161
	b.ne	LBB1_19
; %bb.31:                               ;   in Loop: Header=BB1_22 Depth=1
	mov	w0, #0                          ; =0x0
	ldrh	w12, [sp, #16]
	ldrh	w14, [x19, #4]
	cmp	w12, w14
	b.hs	LBB1_19
; %bb.32:                               ;   in Loop: Header=BB1_22 Depth=1
	cmp	w25, w12
	b.hs	LBB1_19
; %bb.33:                               ;   in Loop: Header=BB1_22 Depth=1
	mov	x9, x22
	mov	w0, #0                          ; =0x0
	ldr	x14, [x22, #264]
	ldr	x13, [x14, w20, uxtw #3]
	ldrb	w13, [x13, w12, uxtw]
	cmp	w13, #2
	b.eq	LBB1_19
; %bb.34:                               ;   in Loop: Header=BB1_22 Depth=1
	sub	w14, w13, #1
	cmp	w14, #4
	b.hi	LBB1_19
; %bb.35:                               ;   in Loop: Header=BB1_22 Depth=1
	ldrb	w14, [sp, #80]
	cmp	w14, w13
	b.ne	LBB1_19
; %bb.36:                               ;   in Loop: Header=BB1_22 Depth=1
	cmp	w21, w12
	b.eq	LBB1_16
; %bb.37:                               ;   in Loop: Header=BB1_22 Depth=1
	mov	x10, x23
	mov	w0, #0                          ; =0x0
	add	w26, w8, w26
	mov	x25, x12
	b.hs	LBB1_22
	b	LBB1_19
LBB1_38:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function allowed
_allowed:                               ; @allowed
	.cfi_startproc
; %bb.0:
	cmp	w0, #226
	b.hi	LBB2_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh12:
	adrp	x9, lJTI2_0@PAGE
Lloh13:
	add	x9, x9, lJTI2_0@PAGEOFF
	adr	x10, LBB2_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB2_2:
	cmp	w1, #2
	cset	w0, eq
	ret
LBB2_3:
	mov	w0, #0                          ; =0x0
LBB2_4:
	ret
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
	.section	__TEXT,__const
lJTI2_0:
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_4-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_3-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
	.byte	(LBB2_2-LBB2_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function closed_function
_closed_function:                       ; @closed_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #208]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #224]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #240]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh14:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh15:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh16:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	ldr	x21, [x0]
	ldr	w8, [x21, #272]
	cmp	w1, w8
	b.hs	LBB3_2
; %bb.1:
	ldr	w8, [x0, #16]
	cmp	w8, #63
	b.ls	LBB3_5
LBB3_2:
	mov	w0, #0                          ; =0x0
LBB3_3:
	ldur	x8, [x29, #-96]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_118
; %bb.4:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #240]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #224]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
LBB3_5:
	ldr	x8, [x0, #8]
	mov	w27, w1
	ldrb	w9, [x8, x27]
	cbz	w9, LBB3_7
; %bb.6:
	cmp	w9, #2
	cset	w0, eq
	b	LBB3_3
LBB3_7:
	ldr	x9, [x21, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x22, w27, w10, x9
	ldrh	w9, [x22, #18]
	cbnz	w9, LBB3_2
; %bb.8:
	ldrh	w9, [x22, #4]
	ldrh	w10, [x22, #16]
	cmp	w9, w10
	b.hi	LBB3_2
; %bb.9:
	ldrb	w9, [x22, #21]
	cmp	w9, #1
	b.hi	LBB3_2
; %bb.10:
	ldr	w9, [x22, #12]
	cbz	w9, LBB3_2
; %bb.11:
	ldr	w10, [x22, #8]
	ldr	w11, [x21, #288]
	subs	w10, w11, w10
	ccmp	w9, w10, #2, hs
	b.hi	LBB3_2
; %bb.12:
	mov	x23, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, x27]
	ldr	w8, [x0, #16]
	add	w8, w8, #1
	str	w8, [x0, #16]
	ldp	w20, w8, [x22, #8]
	add	w19, w8, w20
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
LBB3_13:                                ; =>This Inner Loop Header: Depth=1
	subs	w1, w19, w20
	b.ls	LBB3_16
; %bb.14:                               ;   in Loop: Header=BB3_13 Depth=1
	ldr	x8, [x21, #280]
	add	x0, x8, w20, uxtw
	add	x2, sp, #128
	bl	_isa_decode
	mov	x8, x0
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	cbz	w8, LBB3_17
; %bb.15:                               ;   in Loop: Header=BB3_13 Depth=1
	add	w20, w8, w20
	cmp	w23, #16, lsl #12               ; =65536
	add	x23, x23, #1
	b.ne	LBB3_13
	b	LBB3_17
LBB3_16:
	ldrh	w8, [x22, #16]
	add	w9, w8, #63
	lsr	w9, w9, #6
	cmp	w8, #0
	csinc	w24, w9, wzr, ne
	mov	w8, #2097152                    ; =0x200000
	udiv	w8, w8, w24
	cmp	w23, w8
	b.ls	LBB3_18
LBB3_17:
	ldr	x9, [x0, #8]
	mov	w10, #3                         ; =0x3
	strb	w10, [x9, x27]
	ldr	w9, [x0, #16]
	sub	w9, w9, #1
	str	w9, [x0, #16]
	b	LBB3_2
LBB3_18:
	mov	x0, x23
	mov	w1, #80                         ; =0x50
	bl	_calloc
	mov	x25, x0
	mul	x0, x24, x23
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x20, x0
	str	x24, [sp, #72]                  ; 8-byte Folded Spill
	mov	x0, x24
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x26, x0
	mov	x0, x23
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x28, x0
	mov	w24, #3                         ; =0x3
	str	x25, [sp, #112]                 ; 8-byte Folded Spill
	cbz	x25, LBB3_117
; %bb.19:
	cmp	x20, #0
	ccmp	x26, #0, #4, ne
	ccmp	x28, #0, #4, ne
	b.eq	LBB3_117
; %bb.20:
	stp	x26, x28, [sp, #56]             ; 16-byte Folded Spill
	cbz	w23, LBB3_23
; %bb.21:
	ldr	w24, [x22, #8]
	mov	w26, #-1                        ; =0xffffffff
	mov	x28, x23
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
LBB3_22:                                ; =>This Inner Loop Header: Depth=1
	str	w24, [x25, #64]
	ldr	x8, [x21, #280]
	add	x0, x8, w24, uxtw
	sub	w1, w19, w24
	mov	x2, x25
	bl	_isa_decode
	stp	w0, w26, [x25, #68]
	add	w24, w0, w24
	add	x25, x25, #80
	subs	x28, x28, #1
	b.ne	LBB3_22
LBB3_23:
	ldrh	w8, [x22, #4]
	ands	w11, w8, #0xffff
	ldr	x17, [sp, #72]                  ; 8-byte Folded Reload
	b.eq	LBB3_30
; %bb.24:
	mov	w9, #0                          ; =0x0
	sub	w8, w11, #1
	mov	w10, #52429                     ; =0xcccd
	movk	w10, #52428, lsl #16
	umull	x10, w8, w10
	lsr	x10, x10, #34
	add	w10, w10, w10, lsl #2
	sub	w8, w8, w10
	add	w10, w8, #1
	cmp	w10, #5
	csinc	w8, wzr, w8, eq
	cmp	w11, #5
	b.lo	LBB3_27
; %bb.25:
	mov	w9, #0                          ; =0x0
	sub	w11, w11, w8
	mov	w12, #1                         ; =0x1
LBB3_26:                                ; =>This Inner Loop Header: Depth=1
	lsl	x13, x12, x9
	lsr	w14, w9, #6
	ldr	x15, [x20, w14, uxtw #3]
	orr	x13, x15, x13
	str	x13, [x20, w14, uxtw #3]
	add	w13, w9, #1
	lsr	w14, w13, #6
	ldr	x15, [x20, w14, uxtw #3]
	lsl	x13, x12, x13
	orr	x13, x15, x13
	add	w15, w9, #2
	lsl	x16, x12, x15
	str	x13, [x20, w14, uxtw #3]
	lsr	w13, w15, #6
	ldr	x14, [x20, w13, uxtw #3]
	orr	x14, x14, x16
	str	x14, [x20, w13, uxtw #3]
	add	w13, w9, #3
	lsl	x14, x12, x13
	lsr	w13, w13, #6
	ldr	x15, [x20, w13, uxtw #3]
	orr	x14, x15, x14
	str	x14, [x20, w13, uxtw #3]
	add	w13, w9, #4
	lsr	w14, w13, #6
	ldr	x15, [x20, w14, uxtw #3]
	lsl	x13, x12, x13
	orr	x13, x15, x13
	str	x13, [x20, w14, uxtw #3]
	add	w9, w9, #5
	cmp	w11, w9
	b.ne	LBB3_26
LBB3_27:
	cmp	w10, #5
	b.eq	LBB3_30
; %bb.28:
	mov	w10, #1                         ; =0x1
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
LBB3_29:                                ; =>This Inner Loop Header: Depth=1
	lsr	w11, w9, #6
	ldr	x12, [x20, w11, uxtw #3]
	lsl	x13, x10, x9
	orr	x12, x12, x13
	str	x12, [x20, w11, uxtw #3]
	add	w9, w9, #1
	subs	w8, w8, #1
	b.ne	LBB3_29
LBB3_30:
	mov	w24, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	str	wzr, [sp, #32]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	str	wzr, [x8, #72]
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #76]
	cmp	w23, #1
	cset	w8, ne
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	lsl	x8, x17, #3
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	ldr	x28, [sp, #64]                  ; 8-byte Folded Reload
LBB3_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_32 Depth 2
                                        ;     Child Loop BB3_80 Depth 2
                                        ;     Child Loop BB3_94 Depth 2
	mov	w11, #0                         ; =0x0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	mov	w8, w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	sub	w8, w8, #256, lsl #12           ; =1048576
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
LBB3_32:                                ;   Parent Loop BB3_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	cmp	w8, w11
	b.eq	LBB3_113
; %bb.33:                               ;   in Loop: Header=BB3_32 Depth=2
	str	w11, [sp, #108]                 ; 4-byte Folded Spill
	ldr	w11, [x28, w10, uxtw #2]
	add	w8, w10, #1
	cmp	w8, w23
	csinc	w10, wzr, w10, eq
	str	w10, [sp, #92]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	mov	w9, #80                         ; =0x50
	str	x11, [sp, #96]                  ; 8-byte Folded Spill
	umaddl	x25, w11, w9, x8
	strb	wzr, [x25, #76]
	ldrb	w0, [x25]
	bl	_isa_get_info
	cbz	x0, LBB3_113
; %bb.34:                               ;   in Loop: Header=BB3_32 Depth=2
	ldrb	w26, [x25]
	sub	w8, w26, #56
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	cmp	w8, #3
	cset	w9, lo
	cmp	w26, #51
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	stp	w9, w24, [sp, #36]              ; 8-byte Folded Spill
	b.eq	LBB3_37
; %bb.35:                               ;   in Loop: Header=BB3_32 Depth=2
	cmp	w26, #61
	b.eq	LBB3_39
; %bb.36:                               ;   in Loop: Header=BB3_32 Depth=2
	cmp	w26, #59
	b.ne	LBB3_40
LBB3_37:                                ;   in Loop: Header=BB3_32 Depth=2
	ldr	w26, [x25, #8]
	mov	x0, x8
	mov	x1, x26
	bl	_closed_function
	cbz	w0, LBB3_112
; %bb.38:                               ;   in Loop: Header=BB3_32 Depth=2
	ldr	x8, [x21, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w26, w9, x8
	ldrh	w28, [x8, #4]
	ldrb	w24, [x8, #21]
	b	LBB3_43
LBB3_39:                                ;   in Loop: Header=BB3_32 Depth=2
	mov	w24, #0                         ; =0x0
	ldrb	w28, [x22, #21]
	b	LBB3_43
LBB3_40:                                ;   in Loop: Header=BB3_32 Depth=2
	ldrsb	w28, [x0, #28]
	ldrsb	w24, [x0, #29]
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w8, #0xff
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	x0, x26
	mov	w1, #2                          ; =0x2
	bl	_allowed
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cmp	w8, #3
	b.lo	LBB3_43
; %bb.41:                               ;   in Loop: Header=BB3_32 Depth=2
	tbnz	w0, #0, LBB3_43
; %bb.42:                               ;   in Loop: Header=BB3_32 Depth=2
	sub	w8, w26, #136
	cmp	w8, #5
	b.hs	LBB3_57
LBB3_43:                                ;   in Loop: Header=BB3_32 Depth=2
	tbnz	w28, #31, LBB3_112
; %bb.44:                               ;   in Loop: Header=BB3_32 Depth=2
	tbnz	w24, #31, LBB3_112
; %bb.45:                               ;   in Loop: Header=BB3_32 Depth=2
	ldr	w8, [x25, #72]
	subs	w26, w8, w28
	b.lt	LBB3_112
; %bb.46:                               ;   in Loop: Header=BB3_32 Depth=2
	eor	w8, w24, #0x7fffffff
	cmp	w26, w8
	ldr	x28, [sp, #64]                  ; 8-byte Folded Reload
	b.gt	LBB3_114
; %bb.47:                               ;   in Loop: Header=BB3_32 Depth=2
	ldp	x8, x2, [sp, #72]               ; 16-byte Folded Reload
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	umull	x8, w9, w8
	add	x1, x20, x8, lsl #3
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_memcpy
	add	w26, w26, w24
	ldrb	w24, [x25]
	and	w8, w24, #0xfe
	cmp	w8, #16
	b.eq	LBB3_58
; %bb.48:                               ;   in Loop: Header=BB3_32 Depth=2
	cmp	w24, #51
	b.eq	LBB3_51
; %bb.49:                               ;   in Loop: Header=BB3_32 Depth=2
	cmp	w24, #61
	b.ne	LBB3_61
; %bb.50:                               ;   in Loop: Header=BB3_32 Depth=2
	cbnz	w26, LBB3_54
	b	LBB3_53
LBB3_51:                                ;   in Loop: Header=BB3_32 Depth=2
	ldrb	w8, [x22, #21]
	cmp	w26, w8
	b.ne	LBB3_54
; %bb.52:                               ;   in Loop: Header=BB3_32 Depth=2
	ldr	x9, [x21, #256]
	ldr	w10, [x25, #8]
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrb	w9, [x9, #21]
	cmp	w9, w8
	b.ne	LBB3_54
LBB3_53:                                ;   in Loop: Header=BB3_32 Depth=2
	mov	w9, #1                          ; =0x1
	b	LBB3_55
LBB3_54:                                ;   in Loop: Header=BB3_32 Depth=2
	mov	w9, #0                          ; =0x0
LBB3_55:                                ;   in Loop: Header=BB3_32 Depth=2
	mov	w24, #1                         ; =0x1
	ldr	w10, [sp, #92]                  ; 4-byte Folded Reload
	ldr	w11, [sp, #108]                 ; 4-byte Folded Reload
	cbz	w9, LBB3_102
; %bb.56:                               ;   in Loop: Header=BB3_32 Depth=2
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	add	w8, w8, w11
	sub	w11, w11, #1
	sub	w8, w8, #1
	cbnz	w8, LBB3_32
	b	LBB3_102
LBB3_57:                                ;   in Loop: Header=BB3_32 Depth=2
	cmp	w26, #161
	b.eq	LBB3_43
	b	LBB3_112
LBB3_58:                                ;   in Loop: Header=BB3_31 Depth=1
	ldrh	w8, [x25, #8]
	ldrh	w9, [x22, #16]
	cmp	w8, w9
	b.hs	LBB3_112
; %bb.59:                               ;   in Loop: Header=BB3_31 Depth=1
	cmp	w24, #17
	b.ne	LBB3_61
; %bb.60:                               ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #1                          ; =0x1
	lsl	x9, x9, x8
	lsr	x8, x8, #3
	and	x8, x8, #0x1ff8
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x10, [x11, x8]
	orr	x9, x10, x9
	str	x9, [x11, x8]
LBB3_61:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w8, #0xff
	cmp	w8, #2
	b.hi	LBB3_65
; %bb.62:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	w8, [x25, #64]
	ldrsw	x9, [x25, #8]
	ldr	w10, [x22, #8]
	add	x2, x9, x8
	cmp	x2, x10
	b.lt	LBB3_112
; %bb.63:                               ;   in Loop: Header=BB3_31 Depth=1
	cmp	x2, x19
	b.ge	LBB3_112
; %bb.64:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	mov	x1, x23
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_closed_target
	str	w0, [sp, #128]
	mov	w9, #1                          ; =0x1
	b	LBB3_66
LBB3_65:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	x9, #0                          ; =0x0
LBB3_66:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	ldr	w10, [sp, #44]                  ; 4-byte Folded Reload
	add	w8, w10, w8
	sub	w10, w8, #1
	str	w10, [sp, #44]                  ; 4-byte Folded Spill
	cmp	w24, #56
	b.ne	LBB3_69
; %bb.67:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	w9, [sp, #52]                   ; 4-byte Folded Reload
	and	w9, w9, #0xff
	cmp	w9, #3
	b.hs	LBB3_74
; %bb.68:                               ;   in Loop: Header=BB3_31 Depth=1
	str	wzr, [sp, #36]                  ; 4-byte Folded Spill
	b	LBB3_70
LBB3_69:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	add	w10, w10, #1
	add	x11, sp, #128
	str	w10, [x11, x9, lsl #2]
LBB3_70:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	w9, [sp, #128]
	cmp	w9, w23
	b.hs	LBB3_73
; %bb.71:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	mov	w11, #80                        ; =0x50
	umaddl	x10, w9, w11, x10
	ldr	w11, [x10, #72]
	tbnz	w11, #31, LBB3_77
; %bb.72:                               ;   in Loop: Header=BB3_31 Depth=1
	cmp	w11, w26
	b.eq	LBB3_77
LBB3_73:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #0                          ; =0x0
	b	LBB3_75
LBB3_74:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #1                          ; =0x1
LBB3_75:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	cbz	w9, LBB3_101
LBB3_76:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	ldr	w10, [sp, #108]                 ; 4-byte Folded Reload
	sub	w8, w8, w10
	add	w8, w8, #1
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	ldr	x28, [sp, #64]                  ; 8-byte Folded Reload
	ldp	w24, w8, [sp, #40]              ; 8-byte Folded Reload
	ldr	w10, [sp, #92]                  ; 4-byte Folded Reload
	cbnz	w8, LBB3_31
	b	LBB3_102
LBB3_77:                                ;   in Loop: Header=BB3_31 Depth=1
	lsr	w12, w11, #31
	str	w26, [x10, #72]
	ldr	x14, [sp, #72]                  ; 8-byte Folded Reload
	umull	x13, w9, w14
	add	x13, x20, x13, lsl #3
	ldr	x15, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB3_80
LBB3_78:                                ;   in Loop: Header=BB3_80 Depth=2
	ldr	x17, [x13]
	ldr	x16, [x15]
	and	x16, x16, x17
LBB3_79:                                ;   in Loop: Header=BB3_80 Depth=2
	cmp	x17, x16
	cset	w17, ne
	orr	w12, w17, w12
	str	x16, [x13], #8
	add	x15, x15, #8
	subs	x14, x14, #1
	b.eq	LBB3_82
LBB3_80:                                ;   Parent Loop BB3_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	tbz	w11, #31, LBB3_78
; %bb.81:                               ;   in Loop: Header=BB3_80 Depth=2
	ldr	x16, [x15]
	ldr	x17, [x13]
	b	LBB3_79
LBB3_82:                                ;   in Loop: Header=BB3_31 Depth=1
	tbz	w12, #0, LBB3_84
; %bb.83:                               ;   in Loop: Header=BB3_31 Depth=1
	ldrb	w11, [x10, #76]
	tbz	w11, #0, LBB3_85
LBB3_84:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	b	LBB3_86
LBB3_85:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	w11, #1                         ; =0x1
	strb	w11, [x10, #76]
	ldr	x12, [sp, #16]                  ; 8-byte Folded Reload
	add	w10, w12, #1
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	str	w9, [x11, w12, uxtw #2]
	cmp	w10, w23
	csinc	w12, wzr, w12, eq
	str	x12, [sp, #16]                  ; 8-byte Folded Spill
LBB3_86:                                ;   in Loop: Header=BB3_31 Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	mov	w9, w9
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w9, #0, LBB3_99
; %bb.87:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	w10, [sp, #132]
	cmp	w10, w23
	b.hs	LBB3_90
; %bb.88:                               ;   in Loop: Header=BB3_31 Depth=1
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	mov	w11, #80                        ; =0x50
	umaddl	x11, w10, w11, x9
	ldr	w9, [x11, #72]
	tbnz	w9, #31, LBB3_91
; %bb.89:                               ;   in Loop: Header=BB3_31 Depth=1
	cmp	w9, w26
	b.eq	LBB3_91
LBB3_90:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #0                          ; =0x0
	b	LBB3_100
LBB3_91:                                ;   in Loop: Header=BB3_31 Depth=1
	lsr	w12, w9, #31
	str	w26, [x11, #72]
	ldr	x15, [sp, #72]                  ; 8-byte Folded Reload
	umull	x13, w10, w15
	add	x13, x20, x13, lsl #3
	ldr	x14, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB3_94
LBB3_92:                                ;   in Loop: Header=BB3_94 Depth=2
	ldr	x16, [x14]
	ldr	x17, [x13]
LBB3_93:                                ;   in Loop: Header=BB3_94 Depth=2
	cmp	x17, x16
	cset	w17, ne
	orr	w12, w17, w12
	str	x16, [x13], #8
	add	x14, x14, #8
	subs	x15, x15, #1
	b.eq	LBB3_96
LBB3_94:                                ;   Parent Loop BB3_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	tbnz	w9, #31, LBB3_92
; %bb.95:                               ;   in Loop: Header=BB3_94 Depth=2
	ldr	x17, [x13]
	ldr	x16, [x14]
	and	x16, x16, x17
	b	LBB3_93
LBB3_96:                                ;   in Loop: Header=BB3_31 Depth=1
	tbz	w12, #0, LBB3_99
; %bb.97:                               ;   in Loop: Header=BB3_31 Depth=1
	ldrb	w9, [x11, #76]
	cmp	w9, #1
	b.eq	LBB3_100
; %bb.98:                               ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #1                          ; =0x1
	strb	w9, [x11, #76]
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	add	w11, w13, #1
	ldr	x12, [sp, #64]                  ; 8-byte Folded Reload
	str	w10, [x12, x13, lsl #2]
	cmp	w11, w23
	csinc	w13, wzr, w13, eq
	str	x13, [sp, #16]                  ; 8-byte Folded Spill
	add	w8, w8, #1
	b	LBB3_100
LBB3_99:                                ;   in Loop: Header=BB3_31 Depth=1
	mov	w9, #1                          ; =0x1
LBB3_100:                               ;   in Loop: Header=BB3_31 Depth=1
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	cbnz	w9, LBB3_76
LBB3_101:
	ldr	w24, [sp, #40]                  ; 4-byte Folded Reload
LBB3_102:
	cbz	w9, LBB3_111
; %bb.103:
	cbz	w23, LBB3_111
; %bb.104:
	mov	w8, #1                          ; =0x1
	mov	x10, x20
	ldr	x11, [sp, #112]                 ; 8-byte Folded Reload
LBB3_105:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x11, #72]
	tbnz	w9, #31, LBB3_108
; %bb.106:                              ;   in Loop: Header=BB3_105 Depth=1
	ldrb	w9, [x11]
	cmp	w9, #16
	b.ne	LBB3_108
; %bb.107:                              ;   in Loop: Header=BB3_105 Depth=1
	ldrh	w9, [x11, #8]
	lsr	x12, x9, #6
	ldr	x12, [x10, x12, lsl #3]
	lsr	x9, x12, x9
	and	w9, w9, #0x1
	b	LBB3_109
LBB3_108:                               ;   in Loop: Header=BB3_105 Depth=1
	mov	w9, #1                          ; =0x1
LBB3_109:                               ;   in Loop: Header=BB3_105 Depth=1
	cbz	w9, LBB3_111
; %bb.110:                              ;   in Loop: Header=BB3_105 Depth=1
	add	x11, x11, #80
	ldr	x12, [sp, #80]                  ; 8-byte Folded Reload
	add	x10, x10, x12
	cmp	x8, x23
	add	x8, x8, #1
	b.lo	LBB3_105
LBB3_111:
	ldp	x26, x28, [sp, #56]             ; 16-byte Folded Reload
	b	LBB3_116
LBB3_112:
	mov	w9, #0                          ; =0x0
	ldp	x26, x28, [sp, #56]             ; 16-byte Folded Reload
	b	LBB3_115
LBB3_113:
	mov	w9, #0                          ; =0x0
	ldr	x26, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB3_116
LBB3_114:
	mov	w9, #0                          ; =0x0
	ldr	x26, [sp, #56]                  ; 8-byte Folded Reload
LBB3_115:
	ldr	w24, [sp, #40]                  ; 4-byte Folded Reload
LBB3_116:
	tst	w9, w24
	mov	w8, #2                          ; =0x2
	cinc	w24, w8, eq
LBB3_117:
	ldr	x0, [sp, #112]                  ; 8-byte Folded Reload
	bl	_free
	mov	x0, x20
	bl	_free
	mov	x0, x26
	bl	_free
	mov	x0, x28
	bl	_free
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	strb	w24, [x9, x27]
	ldr	w9, [x8, #16]
	sub	w9, w9, #1
	str	w9, [x8, #16]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, x27]
	cmp	w8, #2
	cset	w0, eq
	b	LBB3_3
LBB3_118:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh14, Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function closed_target
_closed_target:                         ; @closed_target
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w1, LBB4_3
; %bb.1:
	mov	w9, #80                         ; =0x50
	mov	x10, x1
LBB4_2:                                 ; =>This Inner Loop Header: Depth=1
	sub	w11, w10, w0
	add	w11, w0, w11, lsr #1
	umaddl	x12, w11, w9, x8
	ldr	w12, [x12, #64]
	cmp	w12, w2
	csel	w10, w10, w11, lo
	csinc	w0, w0, w11, hs
	cmp	w0, w10
	b.lo	LBB4_2
LBB4_3:
	cmp	w0, w1
	b.hs	LBB4_5
; %bb.4:
	mov	w9, #80                         ; =0x50
	umaddl	x8, w0, w9, x8
	ldr	w8, [x8, #64]
	cmp	w8, w2
	b.eq	LBB4_6
LBB4_5:
	mov	x0, x1
LBB4_6:
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
