	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_services_values_storage_bound ; -- Begin function nl_services_values_storage_bound
	.p2align	2
_nl_services_values_storage_bound:      ; @nl_services_values_storage_bound
	.cfi_startproc
; %bb.0:
	sub	w8, w1, #65
	cmn	w8, #64
	ccmp	x0, #0, #4, hs
	ccmp	x2, #0, #4, ne
	b.ne	LBB0_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB0_2:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	x20, x2
	mov	w21, w1
	mov	w22, #7704                      ; =0x1e18
LBB0_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19], #4
	cmp	w8, #2
	b.eq	LBB0_6
; %bb.4:                                ;   in Loop: Header=BB0_3 Depth=1
	cmp	w8, #1
	b.ne	LBB0_10
; %bb.5:                                ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #8
	bl	_nl_file_values_storage_bound
	tbnz	w0, #0, LBB0_7
	b	LBB0_10
LBB0_6:                                 ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #8
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB0_10
LBB0_7:                                 ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #8]
	cmn	x22, x8
	b.hs	LBB0_10
; %bb.8:                                ;   in Loop: Header=BB0_3 Depth=1
	add	x22, x8, x22
	subs	x21, x21, #1
	b.ne	LBB0_3
; %bb.9:
	str	x22, [x20]
	mov	w0, #1                          ; =0x1
	b	LBB0_11
LBB0_10:
	mov	w0, #0                          ; =0x0
LBB0_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_config_storage_bound ; -- Begin function nl_services_values_config_storage_bound
	.p2align	2
_nl_services_values_config_storage_bound: ; @nl_services_values_config_storage_bound
	.cfi_startproc
; %bb.0:
	sub	w8, w1, #65
	cmn	w8, #64
	ccmp	x0, #0, #4, hs
	ccmp	x2, #0, #4, ne
	b.ne	LBB1_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB1_2:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	add	x21, x0, #16
	mov	w20, #7704                      ; =0x1e18
	mov	w22, #60000                     ; =0xea60
	mov	w23, w1
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	str	xzr, [sp, #8]
	ldur	w8, [x21, #-16]
	cmp	w8, #3
	b.ne	LBB1_11
; %bb.4:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [x21, #8]
	cmp	w8, w22
	b.hi	LBB1_23
; %bb.5:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	x0, [x21]
	cbz	x0, LBB1_8
; %bb.6:                                ;   in Loop: Header=BB1_3 Depth=1
	ldrb	w8, [x0]
	cmp	w8, #47
	b.ne	LBB1_23
; %bb.7:                                ;   in Loop: Header=BB1_3 Depth=1
	bl	_strlen
	cmp	x0, #4095
	b.hi	LBB1_23
LBB1_8:                                 ;   in Loop: Header=BB1_3 Depth=1
	add	x0, sp, #8
	bl	_nl_ws_values_minimum_storage
	cbz	w0, LBB1_23
; %bb.9:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [x21, #16]
	ldr	x9, [sp, #8]
	cmp	x8, x9
	b.lo	LBB1_23
; %bb.10:                               ;   in Loop: Header=BB1_3 Depth=1
	str	x8, [sp, #8]
	b	LBB1_20
LBB1_11:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	x9, [x21, #16]
	cbnz	x9, LBB1_23
; %bb.12:                               ;   in Loop: Header=BB1_3 Depth=1
	ldurb	w9, [x21, #-8]
	tbnz	w9, #0, LBB1_23
; %bb.13:                               ;   in Loop: Header=BB1_3 Depth=1
	ldurb	w9, [x21, #-7]
	tbnz	w9, #0, LBB1_23
; %bb.14:                               ;   in Loop: Header=BB1_3 Depth=1
	ldr	x9, [x21]
	cbnz	x9, LBB1_23
; %bb.15:                               ;   in Loop: Header=BB1_3 Depth=1
	ldr	w9, [x21, #8]
	cbnz	w9, LBB1_23
; %bb.16:                               ;   in Loop: Header=BB1_3 Depth=1
	cmp	w8, #2
	b.eq	LBB1_19
; %bb.17:                               ;   in Loop: Header=BB1_3 Depth=1
	cmp	w8, #1
	b.ne	LBB1_23
; %bb.18:                               ;   in Loop: Header=BB1_3 Depth=1
	add	x0, sp, #8
	bl	_nl_file_values_storage_bound
	tbnz	w0, #0, LBB1_20
	b	LBB1_23
LBB1_19:                                ;   in Loop: Header=BB1_3 Depth=1
	add	x0, sp, #8
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB1_23
LBB1_20:                                ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp, #8]
	cmn	x20, x8
	b.hs	LBB1_23
; %bb.21:                               ;   in Loop: Header=BB1_3 Depth=1
	add	x20, x8, x20
	add	x21, x21, #40
	subs	x23, x23, #1
	b.ne	LBB1_3
; %bb.22:
	str	x20, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB1_24
LBB1_23:
	mov	w0, #0                          ; =0x0
LBB1_24:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_create_config ; -- Begin function nl_services_values_create_config
	.p2align	2
_nl_services_values_create_config:      ; @nl_services_values_create_config
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x2, LBB2_6
; %bb.1:
	ldr	x8, [x2]
	cbnz	x8, LBB2_6
; %bb.2:
	mov	x22, x2
	add	x2, sp, #8
	mov	x20, x0
	mov	x21, x1
	bl	_nl_services_values_config_storage_bound
	cbz	w0, LBB2_6
; %bb.3:
	mov	w0, #1                          ; =0x1
	mov	w1, #7704                       ; =0x1e18
	bl	_calloc
	cbz	x0, LBB2_18
; %bb.4:
	mov	x19, x0
	cbz	w21, LBB2_19
; %bb.5:
	mov	w23, w21
	add	x24, x20, #32
	add	x21, x19, #16
	b	LBB2_10
LBB2_6:
	mov	w20, #1                         ; =0x1
LBB2_7:
	mov	x0, x20
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB2_8:                                 ;   in Loop: Header=BB2_10 Depth=1
	mov	x0, x21
	bl	_nl_socket_values_create
	cbnz	w0, LBB2_14
LBB2_9:                                 ;   in Loop: Header=BB2_10 Depth=1
	ldr	w8, [x19]
	add	w8, w8, #1
	str	w8, [x19]
	add	x24, x24, #40
	add	x21, x21, #16
	subs	x23, x23, #1
	b.eq	LBB2_19
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x24, #-32]
	stur	w8, [x21, #-8]
	cmp	w8, #2
	b.eq	LBB2_8
; %bb.11:                               ;   in Loop: Header=BB2_10 Depth=1
	cmp	w8, #1
	b.ne	LBB2_13
; %bb.12:                               ;   in Loop: Header=BB2_10 Depth=1
	mov	x0, x21
	bl	_nl_file_values_create
	cbz	w0, LBB2_9
	b	LBB2_14
LBB2_13:                                ;   in Loop: Header=BB2_10 Depth=1
	mov	x0, x24
	ldr	x1, [x0], #-24
	mov	x2, x21
	bl	_nl_ws_values_create_bounded
	cbz	w0, LBB2_9
LBB2_14:
	mov	x20, x0
	cmp	w0, #3
	b.le	LBB2_20
; %bb.15:
	sub	w8, w20, #5
	cmp	w8, #3
	b.lo	LBB2_26
; %bb.16:
	cmp	w20, #4
	b.ne	LBB2_25
; %bb.17:
	mov	w20, #4                         ; =0x4
	b	LBB2_26
LBB2_18:
	mov	w20, #6                         ; =0x6
	b	LBB2_7
LBB2_19:
	mov	w20, #0                         ; =0x0
	str	x19, [x22]
	b	LBB2_7
LBB2_20:
	cmp	w20, #1
	b.eq	LBB2_26
; %bb.21:
	cmp	w20, #2
	b.eq	LBB2_24
; %bb.22:
	cmp	w20, #3
	b.ne	LBB2_25
; %bb.23:
	mov	w20, #3                         ; =0x3
	b	LBB2_26
LBB2_24:
	mov	w20, #2                         ; =0x2
	b	LBB2_26
LBB2_25:
	mov	w20, #8                         ; =0x8
LBB2_26:
	ldr	w8, [x19]
	cbz	w8, LBB2_29
; %bb.27:
	mov	w21, #0                         ; =0x0
LBB2_28:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x21
	mov	x2, x20
	bl	_destroy_core
	add	w21, w21, #1
	ldr	w8, [x19]
	cmp	w21, w8
	b.lo	LBB2_28
LBB2_29:
	mov	x0, x19
	bl	_free
	b	LBB2_7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function from_file
_from_file:                             ; @from_file
	.cfi_startproc
; %bb.0:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function from_socket
_from_socket:                           ; @from_socket
	.cfi_startproc
; %bb.0:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function from_websocket
_from_websocket:                        ; @from_websocket
	.cfi_startproc
; %bb.0:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function destroy_core
_destroy_core:                          ; @destroy_core
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x9, x0, w1, uxtw #4
	ldr	w8, [x9, #8]
	ldr	x0, [x9, #16]
	mov	w9, #8                          ; =0x8
	cmp	w2, #8
	csel	w1, w2, w9, lo
	cmp	w8, #2
	b.eq	LBB6_3
; %bb.1:
	cmp	w8, #1
	b.ne	LBB6_4
; %bb.2:
	mov	x8, sp
	bl	_nl_file_values_destroy
	b	LBB6_5
LBB6_3:
	mov	x8, sp
	bl	_nl_socket_values_destroy
	b	LBB6_5
LBB6_4:
	mov	x8, sp
	bl	_nl_ws_values_destroy
LBB6_5:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_create      ; -- Begin function nl_services_values_create
	.p2align	2
_nl_services_values_create:             ; @nl_services_values_create
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #2576
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x8, x0
Lloh0:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB7_24
; %bb.1:
	sub	w9, w1, #65
	cmn	w9, #64
	b.lo	LBB7_24
; %bb.2:
	mov	x21, x2
	mov	x23, x1
	mov	w19, w1
	mov	w20, #7704                      ; =0x1e18
	mov	x22, x8
	mov	x24, x8
	mov	x25, x19
LBB7_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24], #4
	cmp	w8, #2
	b.eq	LBB7_6
; %bb.4:                                ;   in Loop: Header=BB7_3 Depth=1
	cmp	w8, #1
	b.ne	LBB7_11
; %bb.5:                                ;   in Loop: Header=BB7_3 Depth=1
	add	x0, sp, #8
	bl	_nl_file_values_storage_bound
	tbnz	w0, #0, LBB7_7
	b	LBB7_11
LBB7_6:                                 ;   in Loop: Header=BB7_3 Depth=1
	add	x0, sp, #8
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB7_11
LBB7_7:                                 ;   in Loop: Header=BB7_3 Depth=1
	ldr	x8, [sp, #8]
	cmn	x20, x8
	b.hs	LBB7_11
; %bb.8:                                ;   in Loop: Header=BB7_3 Depth=1
	add	x20, x8, x20
	subs	x25, x25, #1
	b.ne	LBB7_3
; %bb.9:
	add	x20, sp, #8
	add	x0, sp, #8
	mov	w1, #2560                       ; =0xa00
	bl	_bzero
	mov	x1, x23
	cmp	w23, #3
	b.hi	LBB7_12
; %bb.10:
	mov	x8, #0                          ; =0x0
	mov	x2, x21
	mov	x9, x22
	b	LBB7_21
LBB7_11:
	mov	w0, #1                          ; =0x1
	b	LBB7_24
LBB7_12:
	cmp	w1, #16
	mov	x2, x21
	mov	x9, x22
	b.hs	LBB7_14
; %bb.13:
	mov	x8, #0                          ; =0x0
	b	LBB7_18
LBB7_14:
	and	x8, x19, #0x70
	add	x10, x9, #32
	add	x11, sp, #8
	mov	x12, x8
LBB7_15:                                ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x10, #-32]
	ldp	q2, q3, [x10], #64
	add	x13, x11, #80
	add	x14, x11, #120
	add	x15, x11, #240
	add	x16, x11, #280
	add	x17, x11, #400
	add	x0, x11, #440
	add	x3, x11, #560
	add	x4, x11, #600
	str	s0, [x11]
	mov	s4, v0[1]
	str	s4, [x11, #40]
	st1.s	{ v0 }[2], [x13]
	st1.s	{ v0 }[3], [x14]
	str	s1, [x11, #160]
	mov	s0, v1[1]
	st1.s	{ v1 }[2], [x15]
	st1.s	{ v1 }[3], [x16]
	str	s0, [x11, #200]
	str	s2, [x11, #320]
	mov	s0, v2[1]
	str	s0, [x11, #360]
	st1.s	{ v2 }[2], [x17]
	st1.s	{ v2 }[3], [x0]
	str	s3, [x11, #480]
	mov	s0, v3[1]
	st1.s	{ v3 }[2], [x3]
	str	s0, [x11, #520]
	add	x11, x11, #640
	st1.s	{ v3 }[3], [x4]
	subs	x12, x12, #16
	b.ne	LBB7_15
; %bb.16:
	cmp	x8, x19
	b.eq	LBB7_23
; %bb.17:
	tst	x19, #0xc
	b.eq	LBB7_21
LBB7_18:
	mov	x12, x8
	and	x8, x19, #0x7c
	sub	x10, x12, x8
	mov	w11, #40                        ; =0x28
	add	x13, sp, #8
	umaddl	x11, w12, w11, x13
	add	x11, x11, #80
	add	x12, x9, x12, lsl #2
LBB7_19:                                ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x12], #16
	add	x13, x11, #40
	stur	s0, [x11, #-80]
	mov	s1, v0[1]
	stur	s1, [x11, #-40]
	st1.s	{ v0 }[2], [x11]
	st1.s	{ v0 }[3], [x13]
	add	x11, x11, #160
	adds	x10, x10, #4
	b.ne	LBB7_19
; %bb.20:
	cmp	x8, x19
	b.eq	LBB7_23
LBB7_21:
	add	x9, x9, x8, lsl #2
	mov	w10, #40                        ; =0x28
	umaddl	x10, w8, w10, x20
	sub	x8, x19, x8
LBB7_22:                                ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9], #4
	str	w11, [x10], #40
	subs	x8, x8, #1
	b.ne	LBB7_22
LBB7_23:
	add	x0, sp, #8
	bl	_nl_services_values_create_config
LBB7_24:
	ldur	x8, [x29, #-72]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_26
; %bb.25:
	add	sp, sp, #2576
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB7_26:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_acquire     ; -- Begin function nl_services_values_acquire
	.p2align	2
_nl_services_values_acquire:            ; @nl_services_values_acquire
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB8_14
; %bb.1:
	mov	x8, x0
	ldrb	w9, [x0, #4]
	tbz	w9, #0, LBB8_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	b	LBB8_15
LBB8_3:
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB8_15
; %bb.4:
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB8_15
; %bb.5:
	ldr	w9, [x3]
	cbnz	w9, LBB8_15
; %bb.6:
	add	x8, x8, w1, uxtw #4
	ldr	w0, [x8, #8]!
	cmp	w0, #3
	b.eq	LBB8_15
; %bb.7:
	cmp	w0, #1
	b.ne	LBB8_10
; %bb.8:
	cbnz	x2, LBB8_15
; %bb.9:
	mov	x19, x3
	mov	x9, sp
	stp	xzr, xzr, [sp, #8]
	str	xzr, [sp, #24]
	add	w10, w1, #1
	stp	w10, w0, [sp]
	ldr	x0, [x8, #8]
	add	x1, x9, #8
	bl	_nl_file_values_temp
	bl	_from_file
	b	LBB8_12
LBB8_10:
	cbz	x2, LBB8_14
; %bb.11:
	mov	x19, x3
	mov	x9, sp
	stp	xzr, xzr, [sp, #8]
	str	xzr, [sp, #24]
	add	w10, w1, #1
	stp	w10, w0, [sp]
	ldr	x0, [x8, #8]
	mov	x1, x2
	add	x2, x9, #8
	bl	_nl_socket_values_begin_connect
	bl	_from_socket
LBB8_12:
	cbnz	w0, LBB8_15
; %bb.13:
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	b	LBB8_15
LBB8_14:
	mov	w0, #1                          ; =0x1
LBB8_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_move         ; -- Begin function nl_services_value_move
	.p2align	2
_nl_services_value_move:                ; @nl_services_value_move
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cmp	x1, x2
	b.eq	LBB9_4
; %bb.1:
	cbz	x1, LBB9_4
; %bb.2:
	cbz	x2, LBB9_4
; %bb.3:
	ldr	w9, [x2]
	cbz	w9, LBB9_5
LBB9_4:
	ret
LBB9_5:
	cbz	x8, LBB9_4
; %bb.6:
	ldrb	w9, [x8, #4]
	tbz	w9, #0, LBB9_8
; %bb.7:
	mov	w0, #7                          ; =0x7
	ret
LBB9_8:
	ldr	w9, [x1]
	cbz	w9, LBB9_14
; %bb.9:
	ldr	w10, [x8]
	cmp	w9, w10
	b.hi	LBB9_14
; %bb.10:
	sub	w11, w9, #1
	ldr	w10, [x1, #4]
	add	x11, x8, w11, uxtw #4
	ldr	w8, [x11, #8]!
	cmp	w10, w8
	b.ne	LBB9_14
; %bb.11:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, sp
	stp	xzr, xzr, [sp, #8]
	str	xzr, [sp, #24]
	stp	w9, w10, [sp]
	ldr	x0, [x11, #8]
	mov	x19, x2
	mov	x20, x1
	add	x1, x1, #8
	add	x2, x8, #8
	cmp	w10, #2
	b.eq	LBB9_15
; %bb.12:
	cmp	w10, #1
	b.ne	LBB9_16
; %bb.13:
	bl	_nl_file_value_move
	bl	_from_file
	b	LBB9_17
LBB9_14:
	mov	w0, #3                          ; =0x3
	ret
LBB9_15:
	bl	_nl_socket_value_move
	bl	_from_socket
	b	LBB9_17
LBB9_16:
	bl	_nl_ws_value_move
	bl	_from_websocket
LBB9_17:
	cbnz	w0, LBB9_19
; %bb.18:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
LBB9_19:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_take_ok      ; -- Begin function nl_services_value_take_ok
	.p2align	2
_nl_services_value_take_ok:             ; @nl_services_value_take_ok
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cmp	x1, x2
	b.eq	LBB10_4
; %bb.1:
	cbz	x1, LBB10_4
; %bb.2:
	cbz	x2, LBB10_4
; %bb.3:
	ldr	w9, [x2]
	cbz	w9, LBB10_5
LBB10_4:
	ret
LBB10_5:
	cbz	x8, LBB10_4
; %bb.6:
	ldrb	w9, [x8, #4]
	tbz	w9, #0, LBB10_8
; %bb.7:
	mov	w0, #7                          ; =0x7
	ret
LBB10_8:
	ldr	w9, [x1]
	cbz	w9, LBB10_14
; %bb.9:
	ldr	w10, [x8]
	cmp	w9, w10
	b.hi	LBB10_14
; %bb.10:
	sub	w11, w9, #1
	ldr	w10, [x1, #4]
	add	x11, x8, w11, uxtw #4
	ldr	w8, [x11, #8]!
	cmp	w10, w8
	b.ne	LBB10_14
; %bb.11:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, sp
	stp	xzr, xzr, [sp, #8]
	str	xzr, [sp, #24]
	stp	w9, w10, [sp]
	ldr	x0, [x11, #8]
	mov	x19, x2
	mov	x20, x1
	add	x1, x1, #8
	add	x2, x8, #8
	cmp	w10, #2
	b.eq	LBB10_15
; %bb.12:
	cmp	w10, #1
	b.ne	LBB10_16
; %bb.13:
	bl	_nl_file_open_take_ok
	bl	_from_file
	b	LBB10_17
LBB10_14:
	mov	w0, #3                          ; =0x3
	ret
LBB10_15:
	bl	_nl_socket_connect_take_ok
	bl	_from_socket
	b	LBB10_17
LBB10_16:
	bl	_nl_ws_connect_take_ok
	bl	_from_websocket
LBB10_17:
	cbnz	w0, LBB10_19
; %bb.18:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
LBB10_19:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_view         ; -- Begin function nl_services_value_view
	.p2align	2
_nl_services_value_view:                ; @nl_services_value_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh6:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB11_15
; %bb.1:
	cbz	x2, LBB11_15
; %bb.2:
	cbz	x8, LBB11_15
; %bb.3:
	ldrb	w9, [x8, #4]
	tbz	w9, #0, LBB11_5
; %bb.4:
	mov	w0, #7                          ; =0x7
	b	LBB11_15
LBB11_5:
	ldr	w9, [x1]
	cbz	w9, LBB11_14
; %bb.6:
	ldr	w10, [x8]
	cmp	w9, w10
	b.hi	LBB11_14
; %bb.7:
	sub	w9, w9, #1
	ldr	w19, [x1, #4]
	add	x8, x8, w9, uxtw #4
	ldr	w9, [x8, #8]!
	cmp	w19, w9
	b.ne	LBB11_14
; %bb.8:
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #74]
	stp	q0, q0, [sp, #48]
	cmp	w19, #3
	b.eq	LBB11_19
; %bb.9:
	cmp	w19, #2
	b.eq	LBB11_17
; %bb.10:
	cmp	w19, #1
	b.ne	LBB11_24
; %bb.11:
	mov	x20, x2
	ldr	x0, [x8, #8]
	add	x1, x1, #8
	mov	x2, sp
	bl	_nl_file_open_view
	sub	w8, w0, #1
	cmp	w8, #7
	b.lo	LBB11_20
; %bb.12:
	cbnz	w0, LBB11_32
; %bb.13:
	ldrb	w8, [sp]
	ldur	q0, [sp, #8]
	stur	q0, [sp, #50]
	ldur	q0, [sp, #24]
	stur	q0, [sp, #66]
	b	LBB11_21
LBB11_14:
	mov	w0, #3                          ; =0x3
LBB11_15:
	ldur	x8, [x29, #-24]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB11_33
; %bb.16:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB11_17:
	mov	x20, x2
	ldr	x0, [x8, #8]
	add	x1, x1, #8
	mov	x2, sp
	bl	_nl_socket_connect_view
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB11_26
; %bb.18:
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x2, x20
	b	LBB11_23
LBB11_19:
	mov	x20, x2
	ldr	x0, [x8, #8]
	add	x1, x1, #8
	mov	x2, sp
	bl	_nl_ws_connect_view
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB11_28
LBB11_20:
	mov	w8, #0                          ; =0x0
LBB11_21:
	mov	x2, x20
LBB11_22:
	mov	w9, #0                          ; =0x0
LBB11_23:
	cbnz	w0, LBB11_15
	b	LBB11_25
LBB11_24:
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
LBB11_25:
	mov	w0, #0                          ; =0x0
	str	w19, [x2]
	strb	w8, [x2, #4]
	strb	w9, [x2, #5]
	ldp	q0, q1, [sp, #48]
	stur	q0, [x2, #6]
	stur	q1, [x2, #22]
	ldur	q0, [sp, #74]
	str	q0, [x2, #32]
	b	LBB11_15
LBB11_26:
	cbnz	w0, LBB11_30
; %bb.27:
	ldrb	w8, [sp]
	ldrb	w9, [sp, #1]
	ldur	q0, [sp, #8]
	stur	q0, [sp, #50]
	ldur	q0, [sp, #24]
	stur	q0, [sp, #66]
	ldr	x10, [sp, #40]
	stur	x10, [sp, #82]
	mov	x2, x20
	b	LBB11_23
LBB11_28:
	mov	x2, x20
	cbnz	w0, LBB11_31
; %bb.29:
	ldrb	w8, [sp]
	ldur	q0, [sp, #8]
	stur	q0, [sp, #50]
	ldur	q0, [sp, #24]
	stur	q0, [sp, #66]
	ldr	x9, [sp, #40]
	stur	x9, [sp, #82]
	b	LBB11_22
LBB11_30:
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w0, #8                          ; =0x8
	mov	x2, x20
	b	LBB11_23
LBB11_31:
	mov	w8, #0                          ; =0x0
	mov	w0, #8                          ; =0x8
	b	LBB11_22
LBB11_32:
	mov	w8, #0                          ; =0x0
	mov	w0, #8                          ; =0x8
	b	LBB11_21
LBB11_33:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_take_error   ; -- Begin function nl_services_value_take_error
	.p2align	2
_nl_services_value_take_error:          ; @nl_services_value_take_error
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB12_16
; %bb.1:
	cbz	x2, LBB12_16
; %bb.2:
	cbz	x8, LBB12_16
; %bb.3:
	ldrb	w9, [x8, #4]
	tbz	w9, #0, LBB12_5
; %bb.4:
	mov	w0, #7                          ; =0x7
	ret
LBB12_5:
	ldr	w9, [x1]
	cbz	w9, LBB12_11
; %bb.6:
	ldr	w10, [x8]
	cmp	w9, w10
	b.hi	LBB12_11
; %bb.7:
	sub	w10, w9, #1
	ldr	w9, [x1, #4]
	add	x8, x8, w10, uxtw #4
	ldr	w10, [x8, #8]!
	cmp	w9, w10
	b.ne	LBB12_11
; %bb.8:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	str	w9, [sp]
	ldr	x0, [x8, #8]
	mov	x8, sp
	mov	x19, x2
	mov	x20, x1
	add	x1, x1, #8
	orr	x2, x8, #0x8
	cmp	w9, #2
	b.eq	LBB12_12
; %bb.9:
	cmp	w9, #1
	b.ne	LBB12_13
; %bb.10:
	bl	_nl_file_open_take_error
	b	LBB12_14
LBB12_11:
	mov	w0, #3                          ; =0x3
	ret
LBB12_12:
	bl	_nl_socket_connect_take_error
	b	LBB12_14
LBB12_13:
	bl	_nl_ws_connect_take_error
LBB12_14:
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB12_17
LBB12_15:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
LBB12_16:
	ret
LBB12_17:
	cbnz	w0, LBB12_19
; %bb.18:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldr	q0, [sp, #32]
	str	q0, [x19, #32]
	b	LBB12_15
LBB12_19:
	mov	w0, #8                          ; =0x8
	b	LBB12_15
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_borrow       ; -- Begin function nl_services_value_borrow
	.p2align	2
_nl_services_value_borrow:              ; @nl_services_value_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB13_3
; %bb.1:
	cbz	x2, LBB13_3
; %bb.2:
	ldr	w9, [x2]
	cbz	w9, LBB13_4
LBB13_3:
	ret
LBB13_4:
	cbz	x8, LBB13_3
; %bb.5:
	ldrb	w9, [x8, #4]
	tbz	w9, #0, LBB13_7
; %bb.6:
	mov	w0, #7                          ; =0x7
	ret
LBB13_7:
	ldr	w9, [x1]
	cbz	w9, LBB13_13
; %bb.8:
	ldr	w10, [x8]
	cmp	w9, w10
	b.hi	LBB13_13
; %bb.9:
	sub	w11, w9, #1
	ldr	w10, [x1, #4]
	add	x11, x8, w11, uxtw #4
	ldr	w8, [x11, #8]!
	cmp	w10, w8
	b.ne	LBB13_13
; %bb.10:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x8, sp, #8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	stp	w9, w10, [sp, #8]
	ldr	x0, [x11, #8]
	mov	x19, x2
	add	x1, x1, #8
	add	x2, x8, #8
	cmp	w10, #2
	b.eq	LBB13_14
; %bb.11:
	cmp	w10, #1
	b.ne	LBB13_15
; %bb.12:
	bl	_nl_file_value_borrow
	bl	_from_file
	b	LBB13_16
LBB13_13:
	mov	w0, #3                          ; =0x3
	ret
LBB13_14:
	bl	_nl_socket_value_borrow
	bl	_from_socket
	b	LBB13_16
LBB13_15:
	bl	_nl_ws_value_borrow
	bl	_from_websocket
LBB13_16:
	cbnz	w0, LBB13_18
; %bb.17:
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldr	x8, [sp, #40]
	str	x8, [x19, #32]
LBB13_18:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_end_borrow   ; -- Begin function nl_services_value_end_borrow
	.p2align	2
_nl_services_value_end_borrow:          ; @nl_services_value_end_borrow
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB14_4
; %bb.1:
	cbz	x0, LBB14_4
; %bb.2:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB14_5
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB14_4:
	mov	w0, #1                          ; =0x1
	ret
LBB14_5:
	ldr	w8, [x1]
	cbz	w8, LBB14_11
; %bb.6:
	ldr	w9, [x0]
	cmp	w8, w9
	b.hi	LBB14_11
; %bb.7:
	sub	w9, w8, #1
	ldr	w8, [x1, #4]
	add	x9, x0, w9, uxtw #4
	ldr	w10, [x9, #8]!
	cmp	w8, w10
	b.ne	LBB14_11
; %bb.8:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x0, [x9, #8]
	mov	x19, x1
	add	x1, x1, #8
	cmp	w8, #2
	b.eq	LBB14_12
; %bb.9:
	cmp	w8, #1
	b.ne	LBB14_13
; %bb.10:
	bl	_nl_file_value_end_borrow
	b	LBB14_14
LBB14_11:
	mov	w0, #3                          ; =0x3
	ret
LBB14_12:
	bl	_nl_socket_value_end_borrow
	b	LBB14_14
LBB14_13:
	bl	_nl_ws_value_end_borrow
LBB14_14:
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB14_16
LBB14_15:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_16:
	cbnz	w0, LBB14_18
; %bb.17:
	mov	w0, #0                          ; =0x0
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB14_15
LBB14_18:
	mov	w0, #8                          ; =0x8
	b	LBB14_15
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_call         ; -- Begin function nl_services_value_call
	.p2align	2
_nl_services_value_call:                ; @nl_services_value_call
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_3
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB15_4
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB15_3:
	mov	w0, #1                          ; =0x1
	ret
LBB15_4:
	mov	x8, x0
	sub	w9, w2, #4
	mov	w0, #1                          ; =0x1
	cmn	w9, #3
	b.lo	LBB15_10
; %bb.5:
	cbz	x5, LBB15_10
; %bb.6:
	cbz	x3, LBB15_10
; %bb.7:
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB15_10
; %bb.8:
	cmp	w2, #1
	b.eq	LBB15_11
; %bb.9:
	cbz	x4, LBB15_11
LBB15_10:
	ret
LBB15_11:
	ldr	w9, [x3]
	add	w10, w1, #1
	cmp	w9, w10
	b.ne	LBB15_18
; %bb.12:
	ldr	w9, [x3, #4]
	add	x10, x8, w1, uxtw #4
	ldr	w8, [x10, #8]!
	mov	w0, #3                          ; =0x3
	cmp	w9, w8
	b.ne	LBB15_10
; %bb.13:
	cmp	w8, #3
	b.eq	LBB15_10
; %bb.14:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	movi.2d	v0, #0000000000000000
	str	xzr, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	str	w9, [sp]
	mov	x8, sp
	ldr	x0, [x10, #8]
	mov	x19, x5
	add	x1, x3, #8
	cmp	w9, #1
	b.ne	LBB15_19
; %bb.15:
	cmp	w2, #2
	b.eq	LBB15_22
; %bb.16:
	cmp	w2, #1
	b.ne	LBB15_24
; %bb.17:
	orr	x3, x8, #0x8
	mov	x2, x4
	bl	_nl_file_value_write_byte
	bl	_from_file
	b	LBB15_27
LBB15_18:
	mov	w0, #3                          ; =0x3
	ret
LBB15_19:
	cmp	w2, #2
	b.eq	LBB15_23
; %bb.20:
	cmp	w2, #1
	b.ne	LBB15_25
; %bb.21:
	orr	x3, x8, #0x8
	mov	x2, x4
	bl	_nl_socket_value_send_byte
	b	LBB15_26
LBB15_22:
	orr	x2, x8, #0x8
	bl	_nl_file_value_rewind
	bl	_from_file
	b	LBB15_27
LBB15_23:
	orr	x2, x8, #0x8
	bl	_nl_socket_value_finish_connect
	b	LBB15_26
LBB15_24:
	orr	x2, x8, #0x8
	bl	_nl_file_value_read_byte
	bl	_from_file
	b	LBB15_27
LBB15_25:
	orr	x2, x8, #0x8
	bl	_nl_socket_value_receive_byte
LBB15_26:
	bl	_from_socket
LBB15_27:
	cbnz	w0, LBB15_29
; %bb.28:
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x19, #32]
	ldr	x8, [sp, #64]
	str	x8, [x19, #64]
	ldp	q1, q0, [sp]
	stp	q1, q0, [x19]
LBB15_29:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_close        ; -- Begin function nl_services_value_close
	.p2align	2
_nl_services_value_close:               ; @nl_services_value_close
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_3
; %bb.1:
	mov	x8, x0
	ldrb	w9, [x0, #4]
	tbz	w9, #0, LBB16_4
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB16_3:
	mov	w0, #1                          ; =0x1
	ret
LBB16_4:
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB16_19
; %bb.5:
	cbz	x2, LBB16_19
; %bb.6:
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB16_19
; %bb.7:
	ldr	w9, [x2]
	add	w10, w1, #1
	cmp	w9, w10
	b.ne	LBB16_14
; %bb.8:
	ldr	w9, [x2, #4]
	add	x8, x8, w1, uxtw #4
	ldr	w10, [x8, #8]!
	mov	w0, #3                          ; =0x3
	cmp	w9, w10
	b.ne	LBB16_19
; %bb.9:
	cmp	w10, #3
	b.eq	LBB16_19
; %bb.10:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x3
	movi.2d	v0, #0000000000000000
	str	xzr, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	str	w9, [sp]
	mov	x10, sp
	ldr	x0, [x8, #8]
	mov	x20, x2
	add	x1, x2, #8
	orr	x2, x10, #0x8
	cmp	w9, #1
	b.ne	LBB16_15
; %bb.11:
	bl	_nl_file_value_close
	sub	w8, w0, #1
	cmp	w8, #7
	b.lo	LBB16_18
; %bb.12:
	cbz	w0, LBB16_17
LBB16_13:
	mov	w0, #8                          ; =0x8
	b	LBB16_18
LBB16_14:
	mov	w0, #3                          ; =0x3
	ret
LBB16_15:
	bl	_nl_socket_value_close
	sub	w8, w0, #1
	cmp	w8, #7
	b.lo	LBB16_18
; %bb.16:
	cbnz	w0, LBB16_13
LBB16_17:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x19, #32]
	ldr	x8, [sp, #64]
	str	x8, [x19, #64]
	ldp	q1, q0, [sp]
	stp	q1, q0, [x19]
LBB16_18:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB16_19:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_validate     ; -- Begin function nl_services_value_validate
	.p2align	2
_nl_services_value_validate:            ; @nl_services_value_validate
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x1, LBB17_4
; %bb.1:
	cbz	x0, LBB17_4
; %bb.2:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB17_5
; %bb.3:
	mov	w0, #7                          ; =0x7
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_4:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_5:
	ldr	w8, [x1]
	cbz	w8, LBB17_11
; %bb.6:
	ldr	w9, [x0]
	cmp	w8, w9
	b.hi	LBB17_11
; %bb.7:
	sub	w9, w8, #1
	ldr	w8, [x1, #4]
	add	x9, x0, w9, uxtw #4
	ldr	w10, [x9, #8]!
	cmp	w8, w10
	b.ne	LBB17_11
; %bb.8:
	ldr	x0, [x9, #8]
	add	x1, x1, #8
	cmp	w8, #2
	b.eq	LBB17_12
; %bb.9:
	cmp	w8, #1
	b.ne	LBB17_13
; %bb.10:
	bl	_nl_file_value_validate
	b	LBB17_14
LBB17_11:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_12:
	bl	_nl_socket_value_validate
	b	LBB17_14
LBB17_13:
	bl	_nl_ws_value_validate
LBB17_14:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_borrow_validate    ; -- Begin function nl_services_borrow_validate
	.p2align	2
_nl_services_borrow_validate:           ; @nl_services_borrow_validate
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x1, LBB18_4
; %bb.1:
	cbz	x0, LBB18_4
; %bb.2:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB18_5
; %bb.3:
	mov	w0, #7                          ; =0x7
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_4:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_5:
	ldr	w8, [x1]
	cbz	w8, LBB18_11
; %bb.6:
	ldr	w9, [x0]
	cmp	w8, w9
	b.hi	LBB18_11
; %bb.7:
	sub	w9, w8, #1
	ldr	w8, [x1, #4]
	add	x9, x0, w9, uxtw #4
	ldr	w10, [x9, #8]!
	cmp	w8, w10
	b.ne	LBB18_11
; %bb.8:
	ldr	x0, [x9, #8]
	add	x1, x1, #8
	cmp	w8, #2
	b.eq	LBB18_12
; %bb.9:
	cmp	w8, #1
	b.ne	LBB18_13
; %bb.10:
	bl	_nl_file_value_borrow_validate
	b	LBB18_14
LBB18_11:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_12:
	bl	_nl_socket_value_borrow_validate
	b	LBB18_14
LBB18_13:
	bl	_nl_ws_value_borrow_validate
LBB18_14:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_live_slots  ; -- Begin function nl_services_values_live_slots
	.p2align	2
_nl_services_values_live_slots:         ; @nl_services_values_live_slots
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB19_3
; %bb.1:
	mov	x8, x0
	ldrb	w9, [x0, #4]
	tbz	w9, #0, LBB19_5
; %bb.2:
	mov	w0, #7                          ; =0x7
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_3:
	mov	w0, #1                          ; =0x1
LBB19_4:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_5:
	mov	w0, #1                          ; =0x1
	cmp	x2, x3
	b.eq	LBB19_4
; %bb.6:
	cbz	x3, LBB19_4
; %bb.7:
	cbz	x2, LBB19_4
; %bb.8:
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB19_4
; %bb.9:
	add	x9, x8, w1, uxtw #4
	ldr	w8, [x9, #8]
	ldr	x0, [x9, #16]
	mov	x1, x2
	mov	x2, x3
	cmp	w8, #2
	b.eq	LBB19_12
; %bb.10:
	cmp	w8, #1
	b.ne	LBB19_13
; %bb.11:
	bl	_nl_file_values_live_slots
	b	LBB19_14
LBB19_12:
	bl	_nl_socket_values_live_slots
	b	LBB19_14
LBB19_13:
	bl	_nl_ws_values_live_slots
LBB19_14:
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_drop         ; -- Begin function nl_services_value_drop
	.p2align	2
_nl_services_value_drop:                ; @nl_services_value_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB20_10
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB20_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB20_3:
	cbz	x1, LBB20_10
; %bb.4:
	ldr	w8, [x1]
	cbz	w8, LBB20_12
; %bb.5:
	ldr	w9, [x0]
	cmp	w8, w9
	b.hi	LBB20_11
; %bb.6:
	sub	w9, w8, #1
	ldr	w8, [x1, #4]
	add	x9, x0, w9, uxtw #4
	ldr	w10, [x9, #8]!
	cmp	w8, w10
	b.ne	LBB20_11
; %bb.7:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x0, [x9, #8]
	mov	x19, x1
	add	x1, x1, #8
	cmp	w8, #2
	b.eq	LBB20_13
; %bb.8:
	cmp	w8, #1
	b.ne	LBB20_14
; %bb.9:
	bl	_nl_file_value_drop
	bl	_from_file
	b	LBB20_15
LBB20_10:
	mov	w0, #1                          ; =0x1
	ret
LBB20_11:
	mov	w0, #3                          ; =0x3
	ret
LBB20_12:
	mov	w0, #0                          ; =0x0
	ret
LBB20_13:
	bl	_nl_socket_value_drop
	bl	_from_socket
	b	LBB20_15
LBB20_14:
	bl	_nl_ws_value_drop
	bl	_from_websocket
LBB20_15:
	cbnz	w0, LBB20_17
; %bb.16:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
LBB20_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_report      ; -- Begin function nl_services_values_report
	.p2align	2
_nl_services_values_report:             ; @nl_services_values_report
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #6768                       ; =0x1a70
Lloh12:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh13:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2672
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB21_18
; %bb.1:
	mov	x19, x1
	cbz	x1, LBB21_18
; %bb.2:
	ldrb	w8, [x20, #4]
	cmp	w8, #1
	b.ne	LBB21_4
; %bb.3:
	add	x1, x20, #1032
	b	LBB21_17
LBB21_4:
	add	x25, sp, #96
	add	x0, x25, #8
	mov	w1, #6664                       ; =0x1a08
	bl	_bzero
	ldr	w8, [x20]
	str	w8, [sp, #100]
	cbz	w8, LBB21_14
; %bb.5:
	mov	x23, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	add	x24, x20, #16
	add	x25, x25, #24
	mov	w26, #8                         ; =0x8
	b	LBB21_9
LBB21_6:                                ;   in Loop: Header=BB21_9 Depth=1
	ldr	x0, [x24]
	mov	x1, sp
	bl	_nl_socket_values_report
	cbz	w0, LBB21_18
LBB21_7:                                ;   in Loop: Header=BB21_9 Depth=1
	ldp	q0, q1, [sp, #48]
	ldp	q3, q2, [sp, #16]
	stp	q2, q0, [x25, #32]
	ldr	q0, [sp, #80]
	stp	q1, q0, [x25, #64]
	ldr	q0, [sp]
	stp	q0, q3, [x25]
	ldr	w8, [sp]
	cmp	w8, #8
	csel	w8, w8, w26, lo
	cmp	w21, #0
	csel	w21, w8, w21, eq
	ldr	x8, [sp, #8]
LBB21_8:                                ;   in Loop: Header=BB21_9 Depth=1
	add	x22, x22, x8
	add	x23, x23, #1
	ldr	w8, [x20]
	add	x24, x24, #16
	add	x25, x25, #104
	cmp	x23, x8
	b.hs	LBB21_15
LBB21_9:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x24, #-8]
	stur	w8, [x25, #-8]
	cmp	w8, #2
	b.eq	LBB21_6
; %bb.10:                               ;   in Loop: Header=BB21_9 Depth=1
	cmp	w8, #1
	b.ne	LBB21_13
; %bb.11:                               ;   in Loop: Header=BB21_9 Depth=1
	ldr	x0, [x24]
	mov	x1, sp
	bl	_nl_file_values_report
	cbz	w0, LBB21_18
; %bb.12:                               ;   in Loop: Header=BB21_9 Depth=1
	ldp	q0, q1, [sp, #16]
	ldp	q2, q3, [sp, #48]
	stp	q1, q2, [x25, #32]
	str	q3, [x25, #64]
	ldr	q1, [sp]
	stp	q1, q0, [x25]
	ldr	x8, [sp, #8]
	ldr	w9, [sp]
	cmp	w9, #8
	csel	w9, w9, w26, lo
	cmp	w21, #0
	csel	w21, w9, w21, eq
	b	LBB21_8
LBB21_13:                               ;   in Loop: Header=BB21_9 Depth=1
	ldr	x0, [x24]
	mov	x1, sp
	bl	_nl_ws_values_report
	cbnz	w0, LBB21_7
	b	LBB21_18
LBB21_14:
	mov	w21, #0                         ; =0x0
	b	LBB21_16
LBB21_15:
	str	x22, [sp, #104]
LBB21_16:
	str	w21, [sp, #96]
	add	x1, sp, #96
LBB21_17:
	mov	x0, x19
	mov	w2, #6672                       ; =0x1a10
	bl	_memcpy
	mov	w0, #1                          ; =0x1
LBB21_18:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2672
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_finish      ; -- Begin function nl_services_values_finish
	.p2align	2
_nl_services_values_finish:             ; @nl_services_values_finish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	cmp	w1, #8
	b.hi	LBB22_16
; %bb.1:
	cbz	x20, LBB22_16
; %bb.2:
	mov	x19, x2
	cbz	x2, LBB22_16
; %bb.3:
	ldrb	w8, [x20, #4]
	tbnz	w8, #0, LBB22_15
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #4]
	str	w1, [x20, #1032]
	ldr	w8, [x20]
	str	w8, [x20, #1036]
	cbz	w8, LBB22_15
; %bb.5:
	mov	x22, #0                         ; =0x0
	mov	w23, #8                         ; =0x8
	cmp	w1, #8
	csel	w21, w1, w23, lo
	add	x24, x20, #16
	add	x25, x20, #1056
	b	LBB22_7
LBB22_6:                                ;   in Loop: Header=BB22_7 Depth=1
	add	x22, x22, #1
	ldr	w8, [x20]
	add	x24, x24, #16
	add	x25, x25, #104
	cmp	x22, x8
	b.hs	LBB22_15
LBB22_7:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x24, #-8]
	stur	w8, [x25, #-8]
	cmp	w8, #2
	b.eq	LBB22_10
; %bb.8:                                ;   in Loop: Header=BB22_7 Depth=1
	cmp	w8, #1
	b.ne	LBB22_11
; %bb.9:                                ;   in Loop: Header=BB22_7 Depth=1
	ldr	x0, [x24]
	mov	x8, sp
	mov	x1, x21
	bl	_nl_file_values_finish
	ldp	q0, q1, [sp, #16]
	ldp	q2, q3, [sp, #48]
	stp	q1, q2, [x25, #32]
	str	q3, [x25, #64]
	ldr	q1, [sp]
	stp	q1, q0, [x25]
	b	LBB22_13
LBB22_10:                               ;   in Loop: Header=BB22_7 Depth=1
	ldr	x0, [x24]
	mov	x8, sp
	mov	x1, x21
	bl	_nl_socket_values_finish
	b	LBB22_12
LBB22_11:                               ;   in Loop: Header=BB22_7 Depth=1
	ldr	x0, [x24]
	mov	x8, sp
	mov	x1, x21
	bl	_nl_ws_values_finish
LBB22_12:                               ;   in Loop: Header=BB22_7 Depth=1
	ldp	q0, q1, [sp, #48]
	ldp	q3, q2, [sp, #16]
	stp	q2, q0, [x25, #32]
	ldr	q0, [sp, #80]
	stp	q1, q0, [x25, #64]
	ldr	q0, [sp]
	stp	q0, q3, [x25]
LBB22_13:                               ;   in Loop: Header=BB22_7 Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [x20, #1040]
	add	x8, x9, x8
	str	x8, [x20, #1040]
	ldr	w8, [x20, #1032]
	cbnz	w8, LBB22_6
; %bb.14:                               ;   in Loop: Header=BB22_7 Depth=1
	ldr	w8, [sp]
	cmp	w8, #8
	csel	w8, w8, w23, lo
	str	w8, [x20, #1032]
	b	LBB22_6
LBB22_15:
	add	x1, x20, #1032
	mov	x0, x19
	mov	w2, #6672                       ; =0x1a10
	bl	_memcpy
	mov	w0, #0                          ; =0x0
LBB22_16:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_destroy     ; -- Begin function nl_services_values_destroy
	.p2align	2
_nl_services_values_destroy:            ; @nl_services_values_destroy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB23_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x20, [x0]
	mov	x0, x20
	bl	_nl_services_values_finish
	cbz	w0, LBB23_4
; %bb.2:
	mov	w0, #1                          ; =0x1
	b	LBB23_8
LBB23_3:
	mov	w0, #1                          ; =0x1
	ret
LBB23_4:
	ldr	w8, [x20]
	cbz	w8, LBB23_7
; %bb.5:
	mov	w21, #0                         ; =0x0
LBB23_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w2, [x20, #1032]
	mov	x0, x20
	mov	x1, x21
	bl	_destroy_core
	add	w21, w21, #1
	ldr	w8, [x20]
	cmp	w21, w8
	b.lo	LBB23_6
LBB23_7:
	mov	x0, x20
	bl	_free
	mov	w0, #0                          ; =0x0
	str	xzr, [x19]
LBB23_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_values_websocket_connect ; -- Begin function nl_services_values_websocket_connect
	.p2align	2
_nl_services_values_websocket_connect:  ; @nl_services_values_websocket_connect
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_7
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB24_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB24_3:
	ldr	w8, [x0]
	cmp	w1, w8
	b.hs	LBB24_7
; %bb.4:
	add	x8, x0, w1, uxtw #4
	ldr	w8, [x8, #8]
	cmp	w8, #3
	b.ne	LBB24_8
; %bb.5:
	cbz	x5, LBB24_7
; %bb.6:
	ldr	w8, [x5]
	cbz	w8, LBB24_9
LBB24_7:
	mov	w0, #1                          ; =0x1
	ret
LBB24_8:
	mov	w0, #3                          ; =0x3
	ret
LBB24_9:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x5
	mov	w8, w1
	mov	x9, sp
	stp	xzr, xzr, [sp, #8]
	str	xzr, [sp, #24]
	add	w10, w1, #1
	mov	w11, #3                         ; =0x3
	stp	w10, w11, [sp]
	add	x8, x0, x8, lsl #4
	ldr	x0, [x8, #16]
	mov	x8, x4
	add	x4, x9, #8
	mov	x1, x2
	mov	x2, x3
	mov	x3, x8
	bl	_nl_ws_values_connect
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB24_11
LBB24_10:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB24_11:
	cbnz	w0, LBB24_13
; %bb.12:
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	b	LBB24_10
LBB24_13:
	mov	w0, #8                          ; =0x8
	b	LBB24_10
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_websocket_send ; -- Begin function nl_services_value_websocket_send
	.p2align	2
_nl_services_value_websocket_send:      ; @nl_services_value_websocket_send
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB25_9
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB25_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB25_3:
	ldr	w8, [x0]
	cmp	w1, w8
	b.hs	LBB25_9
; %bb.4:
	add	x8, x0, w1, uxtw #4
	ldr	w8, [x8, #8]
	cmp	w8, #3
	b.ne	LBB25_10
; %bb.5:
	cbz	x2, LBB25_9
; %bb.6:
	ldr	w8, [x2]
	add	w9, w1, #1
	cmp	w8, w9
	b.ne	LBB25_10
; %bb.7:
	ldr	w8, [x2, #4]
	cmp	w8, #3
	b.ne	LBB25_10
; %bb.8:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, w1
	add	x8, x0, x8, lsl #4
	ldr	x0, [x8, #16]
	add	x1, x2, #8
	mov	x2, x3
	mov	x3, x4
	mov	x4, x5
	mov	x5, x6
	mov	x6, x7
	bl	_nl_ws_value_send
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB25_9:
	mov	w0, #1                          ; =0x1
	ret
LBB25_10:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_websocket_receive ; -- Begin function nl_services_value_websocket_receive
	.p2align	2
_nl_services_value_websocket_receive:   ; @nl_services_value_websocket_receive
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB26_9
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB26_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB26_3:
	ldr	w8, [x0]
	cmp	w1, w8
	b.hs	LBB26_9
; %bb.4:
	add	x8, x0, w1, uxtw #4
	ldr	w8, [x8, #8]
	cmp	w8, #3
	b.ne	LBB26_10
; %bb.5:
	cbz	x2, LBB26_9
; %bb.6:
	ldr	w8, [x2]
	add	w9, w1, #1
	cmp	w8, w9
	b.ne	LBB26_10
; %bb.7:
	ldr	w8, [x2, #4]
	cmp	w8, #3
	b.ne	LBB26_10
; %bb.8:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, w1
	add	x8, x0, x8, lsl #4
	ldr	x0, [x8, #16]
	add	x1, x2, #8
	mov	x2, x3
	mov	x3, x4
	mov	x4, x5
	bl	_nl_ws_value_receive
	mov	w8, #8                          ; =0x8
	cmp	w0, #8
	csel	w0, w0, w8, lo
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB26_9:
	mov	w0, #1                          ; =0x1
	ret
LBB26_10:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_services_value_websocket_close ; -- Begin function nl_services_value_websocket_close
	.p2align	2
_nl_services_value_websocket_close:     ; @nl_services_value_websocket_close
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB27_11
; %bb.1:
	ldrb	w8, [x0, #4]
	tbz	w8, #0, LBB27_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB27_3:
	ldr	w8, [x0]
	cmp	w1, w8
	b.hs	LBB27_11
; %bb.4:
	add	x8, x0, w1, uxtw #4
	ldr	w8, [x8, #8]
	cmp	w8, #3
	b.ne	LBB27_13
; %bb.5:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x2, LBB27_12
; %bb.6:
	cbz	x4, LBB27_12
; %bb.7:
	ldr	w9, [x2]
	add	w10, w1, #1
	cmp	w9, w10
	b.ne	LBB27_13
; %bb.8:
	ldr	w9, [x2, #4]
	cmp	w9, #3
	b.ne	LBB27_13
; %bb.9:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w9, w1
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #16]
	mov	x19, x2
	add	x1, x2, #8
	mov	x2, x3
	mov	x3, x4
	bl	_nl_ws_value_close
	sub	w8, w0, #1
	cmp	w8, #7
	b.hs	LBB27_14
LBB27_10:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB27_11:
	mov	w0, #1                          ; =0x1
LBB27_12:
	ret
LBB27_13:
	mov	w0, #3                          ; =0x3
	ret
LBB27_14:
	cbnz	w0, LBB27_16
; %bb.15:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB27_10
LBB27_16:
	mov	w0, #8                          ; =0x8
	b	LBB27_10
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
