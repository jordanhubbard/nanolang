	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_isa_tag_name                   ; -- Begin function isa_tag_name
	.p2align	2
_isa_tag_name:                          ; @isa_tag_name
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #7]
	ldrb	w8, [sp, #7]
	subs	w8, w8, #16
	b.ge	LBB0_2
	b	LBB0_1
LBB0_1:
	ldrb	w8, [sp, #7]
	mov	x9, x8
	adrp	x8, _tag_names@PAGE
	add	x8, x8, _tag_names@PAGEOFF
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]
	b	LBB0_3
LBB0_2:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #8]
	b	LBB0_3
LBB0_3:
	ldr	x0, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_get_info                   ; -- Begin function isa_get_info
	.p2align	2
_isa_get_info:                          ; @isa_get_info
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-9]
	bl	_init_instruction_table
	ldurb	w8, [x29, #-9]
	mov	x9, x8
	adrp	x8, _instruction_table@PAGE
	add	x8, x8, _instruction_table@PAGEOFF
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB1_3
LBB1_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function init_instruction_table
_init_instruction_table:                ; @init_instruction_table
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, _instruction_table_ready@PAGE
	ldrb	w8, [x8, _instruction_table_ready@PAGEOFF]
	tbz	w8, #0, LBB2_2
	b	LBB2_1
LBB2_1:
	b	LBB2_7
LBB2_2:
	stur	xzr, [x29, #-8]
	b	LBB2_3
LBB2_3:                                 ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-8]
	subs	x8, x8, #191
	b.hs	LBB2_6
	b	LBB2_4
LBB2_4:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldur	x9, [x29, #-8]
	adrp	x8, _nanoisa_schema_opcodes@PAGE
	add	x8, x8, _nanoisa_schema_opcodes@PAGEOFF
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	mov	x9, x8
	adrp	x8, _instruction_table@PAGE
	add	x8, x8, _instruction_table@PAGEOFF
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	ldr	x9, [sp, #8]
	strb	w8, [x9, #8]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	ldr	x9, [sp, #8]
	strb	w8, [x9, #9]
	ldr	x8, [sp, #8]
	add	x0, x8, #12
	ldr	x8, [sp, #16]
	add	x1, x8, #12
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #28]
	ldr	x9, [sp, #8]
	strb	w8, [x9, #28]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #29]
	ldr	x9, [sp, #8]
	strb	w8, [x9, #29]
	b	LBB2_5
LBB2_5:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #1
	stur	x8, [x29, #-8]
	b	LBB2_3
LBB2_6:
	mov	w8, #1                          ; =0x1
	adrp	x9, _instruction_table_ready@PAGE
	strb	w8, [x9, _instruction_table_ready@PAGEOFF]
	b	LBB2_7
LBB2_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_operand_size               ; -- Begin function isa_operand_size
	.p2align	2
_isa_operand_size:                      ; @isa_operand_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB3_7
	b	LBB3_1
LBB3_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB3_8
	b	LBB3_2
LBB3_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB3_9
	b	LBB3_3
LBB3_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB3_10
	b	LBB3_4
LBB3_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB3_11
	b	LBB3_5
LBB3_5:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB3_12
	b	LBB3_6
LBB3_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB3_13
	b	LBB3_14
LBB3_7:
	str	wzr, [sp, #12]
	b	LBB3_15
LBB3_8:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_9:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_10:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_11:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_12:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_13:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]
	b	LBB3_15
LBB3_14:
	str	wzr, [sp, #12]
	b	LBB3_15
LBB3_15:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_encode                     ; -- Begin function isa_encode
	.p2align	2
_isa_encode:                            ; @isa_encode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	ldrb	w0, [x8]
	bl	_isa_get_info
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	stur	wzr, [x29, #-4]
	b	LBB4_27
LBB4_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]
	str	wzr, [sp, #16]
	b	LBB4_3
LBB4_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #24]
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	b.ge	LBB4_6
	b	LBB4_4
LBB4_4:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #12
	ldrsw	x9, [sp, #16]
	ldr	w0, [x8, x9, lsl #2]
	bl	_isa_operand_size
	ldr	w8, [sp, #20]
	add	w8, w8, w0
	str	w8, [sp, #20]
	b	LBB4_5
LBB4_5:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB4_3
LBB4_6:
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ls	LBB4_8
	b	LBB4_7
LBB4_7:
	stur	wzr, [x29, #-4]
	b	LBB4_27
LBB4_8:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB4_9
LBB4_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #24]
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	b.ge	LBB4_26
	b	LBB4_10
LBB4_10:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #12
	ldrsw	x9, [sp, #8]
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB4_17
	b	LBB4_11
LBB4_11:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB4_18
	b	LBB4_12
LBB4_12:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB4_19
	b	LBB4_13
LBB4_13:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB4_20
	b	LBB4_14
LBB4_14:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB4_21
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB4_22
	b	LBB4_16
LBB4_16:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB4_23
	b	LBB4_24
LBB4_17:                                ;   in Loop: Header=BB4_9 Depth=1
	b	LBB4_24
LBB4_18:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_19:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	ldrh	w1, [x8, x9]
	bl	_write_u16
	ldr	w8, [sp, #12]
	add	w8, w8, #2
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_20:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	ldr	w1, [x8, x9]
	bl	_write_u32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_21:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	ldr	w1, [x8, x9]
	bl	_write_i32
	ldr	w8, [sp, #12]
	add	w8, w8, #4
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_22:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	ldr	x1, [x8, x9, lsl #3]
	bl	_write_i64
	ldr	w8, [sp, #12]
	add	w8, w8, #8
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_23:                                ;   in Loop: Header=BB4_9 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	ldr	d0, [x8, x9, lsl #3]
	bl	_write_f64
	ldr	w8, [sp, #12]
	add	w8, w8, #8
	str	w8, [sp, #12]
	b	LBB4_24
LBB4_24:                                ;   in Loop: Header=BB4_9 Depth=1
	b	LBB4_25
LBB4_25:                                ;   in Loop: Header=BB4_9 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB4_9
LBB4_26:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB4_27
LBB4_27:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_u16
_write_u16:                             ; @write_u16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldrb	w8, [sp, #6]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldrh	w8, [sp, #6]
	asr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_u32
_write_u32:                             ; @write_u32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldrb	w8, [sp, #4]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #2]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [sp, #8]
	strb	w8, [x9, #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_i32
_write_i32:                             ; @write_i32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_write_u32
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_i64
_write_i64:                             ; @write_i64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB8_1
LBB8_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	subs	w8, w8, #8
	b.ge	LBB8_4
	b	LBB8_2
LBB8_2:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldrb	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #24]
	ldrsw	x10, [sp, #4]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	ldr	x8, [sp, #8]
	lsr	x8, x8, #8
	str	x8, [sp, #8]
	b	LBB8_3
LBB8_3:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB8_1
LBB8_4:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_f64
_write_f64:                             ; @write_f64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	d0, [sp, #16]
	ldr	d0, [sp, #16]
	str	d0, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB9_1
LBB9_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	subs	w8, w8, #8
	b.ge	LBB9_4
	b	LBB9_2
LBB9_2:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldrb	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #24]
	ldrsw	x10, [sp, #4]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	ldr	x8, [sp, #8]
	lsr	x8, x8, #8
	str	x8, [sp, #8]
	b	LBB9_3
LBB9_3:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB9_1
LBB9_4:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_decode                     ; -- Begin function isa_decode
	.p2align	2
_isa_decode:                            ; @isa_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-24]
	subs	x8, x8, #1
	b.hs	LBB10_2
	b	LBB10_1
LBB10_1:
	stur	wzr, [x29, #-4]
	b	LBB10_25
LBB10_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	strb	w8, [sp, #31]
	ldrb	w0, [sp, #31]
	bl	_isa_get_info
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB10_4
	b	LBB10_3
LBB10_3:
	stur	wzr, [x29, #-4]
	b	LBB10_25
LBB10_4:
	ldr	x0, [sp, #32]
	mov	w1, #0                          ; =0x0
	mov	x2, #64                         ; =0x40
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldrb	w8, [sp, #31]
	ldr	x9, [sp, #32]
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #1]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB10_5
LBB10_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	b.ge	LBB10_24
	b	LBB10_6
LBB10_6:                                ;   in Loop: Header=BB10_5 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #12
	ldrsw	x9, [sp, #8]
	ldr	w0, [x8, x9, lsl #2]
	bl	_isa_operand_size
	str	w0, [sp, #4]
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #4]
	add	w8, w8, w9
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.ls	LBB10_8
	b	LBB10_7
LBB10_7:
	stur	wzr, [x29, #-4]
	b	LBB10_25
LBB10_8:                                ;   in Loop: Header=BB10_5 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #12
	ldrsw	x9, [sp, #8]
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #32]
	add	x9, x9, #40
	ldrsw	x10, [sp, #8]
	str	w8, [x9, x10, lsl #2]
	ldr	x8, [sp, #16]
	add	x8, x8, #12
	ldrsw	x9, [sp, #8]
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w8, LBB10_15
	b	LBB10_9
LBB10_9:                                ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB10_16
	b	LBB10_10
LBB10_10:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB10_17
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB10_18
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB10_19
	b	LBB10_13
LBB10_13:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB10_20
	b	LBB10_14
LBB10_14:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB10_21
	b	LBB10_22
LBB10_15:                               ;   in Loop: Header=BB10_5 Depth=1
	b	LBB10_22
LBB10_16:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldr	x9, [sp, #32]
	add	x9, x9, #8
	ldrsw	x10, [sp, #8]
	add	x9, x9, x10, lsl #3
	strb	w8, [x9]
	b	LBB10_22
LBB10_17:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_read_u16
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	strh	w0, [x8, x9]
	b	LBB10_22
LBB10_18:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_read_u32
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	str	w0, [x8, x9]
	b	LBB10_22
LBB10_19:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_read_i32
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	lsl	x9, x9, #3
	str	w0, [x8, x9]
	b	LBB10_22
LBB10_20:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_read_i64
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	str	x0, [x8, x9, lsl #3]
	b	LBB10_22
LBB10_21:                               ;   in Loop: Header=BB10_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_read_f64
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrsw	x9, [sp, #8]
	str	d0, [x8, x9, lsl #3]
	b	LBB10_22
LBB10_22:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w9, [sp, #4]
	ldr	w8, [sp, #12]
	add	w8, w8, w9
	str	w8, [sp, #12]
	b	LBB10_23
LBB10_23:                               ;   in Loop: Header=BB10_5 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB10_5
LBB10_24:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #32]
	str	w8, [x9, #56]
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB10_25
LBB10_25:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_u16
_read_u16:                              ; @read_u16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	and	w0, w8, #0xffff
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_u32
_read_u32:                              ; @read_u32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_i32
_read_i32:                              ; @read_i32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_read_u32
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_i64
_read_i64:                              ; @read_i64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	xzr, [sp, #16]
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #12]
	b	LBB14_1
LBB14_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	tbnz	w8, #31, LBB14_4
	b	LBB14_2
LBB14_2:                                ;   in Loop: Header=BB14_1 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #24]
	ldrsw	x10, [sp, #12]
	ldrb	w8, [x8, x10]
                                        ; kill: def $x8 killed $w8
	orr	x8, x8, x9, lsl #8
	str	x8, [sp, #16]
	b	LBB14_3
LBB14_3:                                ;   in Loop: Header=BB14_1 Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB14_1
LBB14_4:
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_f64
_read_f64:                              ; @read_f64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	xzr, [sp, #16]
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #12]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	tbnz	w8, #31, LBB15_4
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #24]
	ldrsw	x10, [sp, #12]
	ldrb	w8, [x8, x10]
                                        ; kill: def $x8 killed $w8
	orr	x8, x8, x9, lsl #8
	str	x8, [sp, #16]
	b	LBB15_3
LBB15_3:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB15_1
LBB15_4:
	ldr	x8, [sp, #16]
	str	x8, [sp]
	ldr	d0, [sp]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_opcode_by_name             ; -- Begin function isa_opcode_by_name
	.p2align	2
_isa_opcode_by_name:                    ; @isa_opcode_by_name
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	bl	_init_instruction_table
	str	wzr, [sp, #12]
	b	LBB16_1
LBB16_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #256
	b.ge	LBB16_7
	b	LBB16_2
LBB16_2:                                ;   in Loop: Header=BB16_1 Depth=1
	ldrsw	x8, [sp, #12]
	lsl	x9, x8, #5
	adrp	x8, _instruction_table@PAGE
	add	x8, x8, _instruction_table@PAGEOFF
	ldr	x8, [x8, x9]
	cbz	x8, LBB16_5
	b	LBB16_3
LBB16_3:                                ;   in Loop: Header=BB16_1 Depth=1
	ldrsw	x8, [sp, #12]
	lsl	x9, x8, #5
	adrp	x8, _instruction_table@PAGE
	add	x8, x8, _instruction_table@PAGEOFF
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #16]
	bl	_strcmp
	cbnz	w0, LBB16_5
	b	LBB16_4
LBB16_4:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB16_8
LBB16_5:                                ;   in Loop: Header=BB16_1 Depth=1
	b	LBB16_6
LBB16_6:                                ;   in Loop: Header=BB16_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB16_1
LBB16_7:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB16_8
LBB16_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_is_extension_prefix        ; -- Begin function isa_is_extension_prefix
	.p2align	2
_isa_is_extension_prefix:               ; @isa_is_extension_prefix
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w8, [sp, #15]
	subs	w8, w8, #255
	cset	w0, eq
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_get_extended_info          ; -- Begin function isa_get_extended_info
	.p2align	2
_isa_get_extended_info:                 ; @isa_get_extended_info
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-9]
	bl	_init_extended_table
	ldurb	w8, [x29, #-9]
	mov	x9, x8
	adrp	x8, _extended_table@PAGE
	add	x8, x8, _extended_table@PAGEOFF
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB18_2
	b	LBB18_1
LBB18_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB18_3
LBB18_2:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB18_3
LBB18_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function init_extended_table
_init_extended_table:                   ; @init_extended_table
	.cfi_startproc
; %bb.0:
	adrp	x8, _extended_table_ready@PAGE
	ldrb	w8, [x8, _extended_table_ready@PAGEOFF]
	tbz	w8, #0, LBB19_2
	b	LBB19_1
LBB19_1:
	b	LBB19_3
LBB19_2:
	mov	w8, #1                          ; =0x1
	adrp	x9, _extended_table_ready@PAGE
	strb	w8, [x9, _extended_table_ready@PAGEOFF]
	b	LBB19_3
LBB19_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_is_file_opcode             ; -- Begin function isa_is_file_opcode
	.p2align	2
_isa_is_file_opcode:                    ; @isa_is_file_opcode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #145
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.lt	LBB20_2
	b	LBB20_1
LBB20_1:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #152
	cset	w8, le
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB20_2
LBB20_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_isa_code_has_file_instructions ; -- Begin function isa_code_has_file_instructions
	.p2align	2
_isa_code_has_file_instructions:        ; @isa_code_has_file_instructions
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB21_2
	b	LBB21_1
LBB21_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_11
LBB21_2:
	stur	xzr, [x29, #-32]
	b	LBB21_3
LBB21_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.hs	LBB21_10
	b	LBB21_4
LBB21_4:                                ;   in Loop: Header=BB21_3 Depth=1
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-32]
	ldrb	w0, [x8, x9]
	bl	_isa_is_file_opcode
	tbz	w0, #0, LBB21_6
	b	LBB21_5
LBB21_5:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_11
LBB21_6:                                ;   in Loop: Header=BB21_3 Depth=1
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-32]
	add	x0, x8, x9
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-32]
	subs	x1, x8, x9
	add	x2, sp, #16
	bl	_isa_decode
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbz	w8, LBB21_8
	b	LBB21_7
LBB21_7:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	ldur	x10, [x29, #-32]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB21_9
	b	LBB21_8
LBB21_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_11
LBB21_9:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	w8, [sp, #12]
	mov	x9, x8
	ldur	x8, [x29, #-32]
	add	x8, x8, x9
	stur	x8, [x29, #-32]
	b	LBB21_3
LBB21_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_11
LBB21_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__data
	.p2align	3, 0x0                          ; @tag_names
_tag_names:
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	l_.str.5
	.quad	l_.str.6
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.9
	.quad	l_.str.10
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14
	.quad	l_.str.15
	.quad	l_.str.16

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"UNKNOWN"

.zerofill __DATA,__bss,_instruction_table,8192,3 ; @instruction_table
.zerofill __DATA,__bss,_extended_table,8192,3 ; @extended_table
l_.str.1:                               ; @.str.1
	.asciz	"void"

l_.str.2:                               ; @.str.2
	.asciz	"int"

l_.str.3:                               ; @.str.3
	.asciz	"u8"

l_.str.4:                               ; @.str.4
	.asciz	"float"

l_.str.5:                               ; @.str.5
	.asciz	"bool"

l_.str.6:                               ; @.str.6
	.asciz	"string"

l_.str.7:                               ; @.str.7
	.asciz	"bstring"

l_.str.8:                               ; @.str.8
	.asciz	"array"

l_.str.9:                               ; @.str.9
	.asciz	"struct"

l_.str.10:                              ; @.str.10
	.asciz	"enum"

l_.str.11:                              ; @.str.11
	.asciz	"union"

l_.str.12:                              ; @.str.12
	.asciz	"function"

l_.str.13:                              ; @.str.13
	.asciz	"tuple"

l_.str.14:                              ; @.str.14
	.asciz	"hashmap"

l_.str.15:                              ; @.str.15
	.asciz	"opaque"

l_.str.16:                              ; @.str.16
	.asciz	"closure"

.zerofill __DATA,__bss,_instruction_table_ready,1,0 ; @instruction_table_ready
l_.str.17:                              ; @.str.17
	.asciz	"HANDLER_PUSH"

l_.str.18:                              ; @.str.18
	.asciz	"HANDLER_POP"

l_.str.19:                              ; @.str.19
	.asciz	"PERFORM"

l_.str.20:                              ; @.str.20
	.asciz	"EFFECT_RESUME"

l_.str.21:                              ; @.str.21
	.asciz	"NOP"

l_.str.22:                              ; @.str.22
	.asciz	"PUSH_I64"

l_.str.23:                              ; @.str.23
	.asciz	"PUSH_F64"

l_.str.24:                              ; @.str.24
	.asciz	"PUSH_BOOL"

l_.str.25:                              ; @.str.25
	.asciz	"PUSH_STR"

l_.str.26:                              ; @.str.26
	.asciz	"PUSH_VOID"

l_.str.27:                              ; @.str.27
	.asciz	"PUSH_U8"

l_.str.28:                              ; @.str.28
	.asciz	"DUP"

l_.str.29:                              ; @.str.29
	.asciz	"POP"

l_.str.30:                              ; @.str.30
	.asciz	"SWAP"

l_.str.31:                              ; @.str.31
	.asciz	"ROT3"

l_.str.32:                              ; @.str.32
	.asciz	"FILE_SERVICE"

l_.str.33:                              ; @.str.33
	.asciz	"FILE_RESULT_BRANCH"

l_.str.34:                              ; @.str.34
	.asciz	"FILE_RESULT_TAKE"

l_.str.35:                              ; @.str.35
	.asciz	"FILE_DROP_LOCAL"

l_.str.36:                              ; @.str.36
	.asciz	"FILE_DROP_STACK"

l_.str.37:                              ; @.str.37
	.asciz	"FILE_CALL_REFS"

l_.str.38:                              ; @.str.38
	.asciz	"FILE_CALL_INDIRECT_REFS"

l_.str.39:                              ; @.str.39
	.asciz	"FILE_END_BORROW"

l_.str.40:                              ; @.str.40
	.asciz	"OWN_MOVE_LOCAL"

l_.str.41:                              ; @.str.41
	.asciz	"OWN_STORE_LOCAL"

l_.str.42:                              ; @.str.42
	.asciz	"OWN_PACK"

l_.str.43:                              ; @.str.43
	.asciz	"OWN_UNPACK_LOCAL"

l_.str.44:                              ; @.str.44
	.asciz	"CALL_REF"

l_.str.45:                              ; @.str.45
	.asciz	"LOAD_LOCAL"

l_.str.46:                              ; @.str.46
	.asciz	"STORE_LOCAL"

l_.str.47:                              ; @.str.47
	.asciz	"LOAD_GLOBAL"

l_.str.48:                              ; @.str.48
	.asciz	"STORE_GLOBAL"

l_.str.49:                              ; @.str.49
	.asciz	"LOAD_UPVALUE"

l_.str.50:                              ; @.str.50
	.asciz	"STORE_UPVALUE"

l_.str.51:                              ; @.str.51
	.asciz	"REGION_BEGIN"

l_.str.52:                              ; @.str.52
	.asciz	"REGION_END"

l_.str.53:                              ; @.str.53
	.asciz	"BORROW_LOCAL_SHARED"

l_.str.54:                              ; @.str.54
	.asciz	"BORROW_LOCAL_EXCLUSIVE"

l_.str.55:                              ; @.str.55
	.asciz	"REF_GET"

l_.str.56:                              ; @.str.56
	.asciz	"REF_SET"

l_.str.57:                              ; @.str.57
	.asciz	"BORROW_PATH_SHARED"

l_.str.58:                              ; @.str.58
	.asciz	"BORROW_PATH_EXCLUSIVE"

l_.str.59:                              ; @.str.59
	.asciz	"REBORROW_SHARED"

l_.str.60:                              ; @.str.60
	.asciz	"REBORROW_EXCLUSIVE"

l_.str.61:                              ; @.str.61
	.asciz	"ADD"

l_.str.62:                              ; @.str.62
	.asciz	"SUB"

l_.str.63:                              ; @.str.63
	.asciz	"MUL"

l_.str.64:                              ; @.str.64
	.asciz	"DIV"

l_.str.65:                              ; @.str.65
	.asciz	"MOD"

l_.str.66:                              ; @.str.66
	.asciz	"NEG"

l_.str.67:                              ; @.str.67
	.asciz	"EQ"

l_.str.68:                              ; @.str.68
	.asciz	"NE"

l_.str.69:                              ; @.str.69
	.asciz	"LT"

l_.str.70:                              ; @.str.70
	.asciz	"LE"

l_.str.71:                              ; @.str.71
	.asciz	"GT"

l_.str.72:                              ; @.str.72
	.asciz	"GE"

l_.str.73:                              ; @.str.73
	.asciz	"AND"

l_.str.74:                              ; @.str.74
	.asciz	"OR"

l_.str.75:                              ; @.str.75
	.asciz	"NOT"

l_.str.76:                              ; @.str.76
	.asciz	"TAIL_CALL"

l_.str.77:                              ; @.str.77
	.asciz	"JMP"

l_.str.78:                              ; @.str.78
	.asciz	"JMP_TRUE"

l_.str.79:                              ; @.str.79
	.asciz	"JMP_FALSE"

l_.str.80:                              ; @.str.80
	.asciz	"CALL"

l_.str.81:                              ; @.str.81
	.asciz	"CALL_INDIRECT"

l_.str.82:                              ; @.str.82
	.asciz	"RET"

l_.str.83:                              ; @.str.83
	.asciz	"CALL_EXTERN"

l_.str.84:                              ; @.str.84
	.asciz	"CALL_MODULE"

l_.str.85:                              ; @.str.85
	.asciz	"STR_LEN"

l_.str.86:                              ; @.str.86
	.asciz	"STR_CONCAT"

l_.str.87:                              ; @.str.87
	.asciz	"STR_SUBSTR"

l_.str.88:                              ; @.str.88
	.asciz	"STR_CONTAINS"

l_.str.89:                              ; @.str.89
	.asciz	"STR_EQ"

l_.str.90:                              ; @.str.90
	.asciz	"STR_CHAR_AT"

l_.str.91:                              ; @.str.91
	.asciz	"STR_FROM_INT"

l_.str.92:                              ; @.str.92
	.asciz	"STR_FROM_FLOAT"

l_.str.93:                              ; @.str.93
	.asciz	"STR_TRIM"

l_.str.94:                              ; @.str.94
	.asciz	"STR_TO_LOWER"

l_.str.95:                              ; @.str.95
	.asciz	"STR_TO_UPPER"

l_.str.96:                              ; @.str.96
	.asciz	"STR_STARTS_WITH"

l_.str.97:                              ; @.str.97
	.asciz	"STR_ENDS_WITH"

l_.str.98:                              ; @.str.98
	.asciz	"STR_SPLIT"

l_.str.99:                              ; @.str.99
	.asciz	"STR_REPLACE"

l_.str.100:                             ; @.str.100
	.asciz	"ARR_NEW"

l_.str.101:                             ; @.str.101
	.asciz	"ARR_PUSH"

l_.str.102:                             ; @.str.102
	.asciz	"ARR_POP"

l_.str.103:                             ; @.str.103
	.asciz	"ARR_GET"

l_.str.104:                             ; @.str.104
	.asciz	"ARR_SET"

l_.str.105:                             ; @.str.105
	.asciz	"ARR_LEN"

l_.str.106:                             ; @.str.106
	.asciz	"ARR_SLICE"

l_.str.107:                             ; @.str.107
	.asciz	"ARR_REMOVE"

l_.str.108:                             ; @.str.108
	.asciz	"ARR_LITERAL"

l_.str.109:                             ; @.str.109
	.asciz	"STRUCT_NEW"

l_.str.110:                             ; @.str.110
	.asciz	"STRUCT_GET"

l_.str.111:                             ; @.str.111
	.asciz	"STRUCT_SET"

l_.str.112:                             ; @.str.112
	.asciz	"STRUCT_LITERAL"

l_.str.113:                             ; @.str.113
	.asciz	"UNION_CONSTRUCT"

l_.str.114:                             ; @.str.114
	.asciz	"UNION_TAG"

l_.str.115:                             ; @.str.115
	.asciz	"UNION_FIELD"

l_.str.116:                             ; @.str.116
	.asciz	"MATCH_TAG"

l_.str.117:                             ; @.str.117
	.asciz	"ENUM_VAL"

l_.str.118:                             ; @.str.118
	.asciz	"TUPLE_NEW"

l_.str.119:                             ; @.str.119
	.asciz	"TUPLE_GET"

l_.str.120:                             ; @.str.120
	.asciz	"HM_NEW"

l_.str.121:                             ; @.str.121
	.asciz	"HM_GET"

l_.str.122:                             ; @.str.122
	.asciz	"HM_SET"

l_.str.123:                             ; @.str.123
	.asciz	"HM_HAS"

l_.str.124:                             ; @.str.124
	.asciz	"HM_DELETE"

l_.str.125:                             ; @.str.125
	.asciz	"HM_KEYS"

l_.str.126:                             ; @.str.126
	.asciz	"HM_VALUES"

l_.str.127:                             ; @.str.127
	.asciz	"HM_LEN"

l_.str.128:                             ; @.str.128
	.asciz	"GC_RETAIN"

l_.str.129:                             ; @.str.129
	.asciz	"GC_RELEASE"

l_.str.130:                             ; @.str.130
	.asciz	"CAST_INT"

l_.str.131:                             ; @.str.131
	.asciz	"CAST_FLOAT"

l_.str.132:                             ; @.str.132
	.asciz	"CAST_BOOL"

l_.str.133:                             ; @.str.133
	.asciz	"CAST_STRING"

l_.str.134:                             ; @.str.134
	.asciz	"TYPE_CHECK"

l_.str.135:                             ; @.str.135
	.asciz	"F64_FROM_BITS"

l_.str.136:                             ; @.str.136
	.asciz	"F64_TO_BITS"

l_.str.137:                             ; @.str.137
	.asciz	"CAST_U8"

l_.str.138:                             ; @.str.138
	.asciz	"CLOSURE_NEW"

l_.str.139:                             ; @.str.139
	.asciz	"PRINT"

l_.str.140:                             ; @.str.140
	.asciz	"ASSERT"

l_.str.141:                             ; @.str.141
	.asciz	"DEBUG_LINE"

l_.str.142:                             ; @.str.142
	.asciz	"HALT"

l_.str.143:                             ; @.str.143
	.asciz	"PRINTLN"

l_.str.144:                             ; @.str.144
	.asciz	"OPAQUE_NULL"

l_.str.145:                             ; @.str.145
	.asciz	"OPAQUE_VALID"

l_.str.146:                             ; @.str.146
	.asciz	"MEM_LOAD8"

l_.str.147:                             ; @.str.147
	.asciz	"MEM_LOAD16"

l_.str.148:                             ; @.str.148
	.asciz	"MEM_LOAD32"

l_.str.149:                             ; @.str.149
	.asciz	"MEM_LOAD64"

l_.str.150:                             ; @.str.150
	.asciz	"MEM_STORE8"

l_.str.151:                             ; @.str.151
	.asciz	"MEM_STORE16"

l_.str.152:                             ; @.str.152
	.asciz	"MEM_STORE32"

l_.str.153:                             ; @.str.153
	.asciz	"MEM_STORE64"

l_.str.154:                             ; @.str.154
	.asciz	"I64_ADD"

l_.str.155:                             ; @.str.155
	.asciz	"I64_SUB"

l_.str.156:                             ; @.str.156
	.asciz	"I64_MUL"

l_.str.157:                             ; @.str.157
	.asciz	"I64_DIV_S"

l_.str.158:                             ; @.str.158
	.asciz	"I64_REM_S"

l_.str.159:                             ; @.str.159
	.asciz	"I64_NEG"

l_.str.160:                             ; @.str.160
	.asciz	"F64_ADD"

l_.str.161:                             ; @.str.161
	.asciz	"F64_SUB"

l_.str.162:                             ; @.str.162
	.asciz	"F64_MUL"

l_.str.163:                             ; @.str.163
	.asciz	"F64_DIV"

l_.str.164:                             ; @.str.164
	.asciz	"F64_NEG"

l_.str.165:                             ; @.str.165
	.asciz	"I64_EQ"

l_.str.166:                             ; @.str.166
	.asciz	"I64_NE"

l_.str.167:                             ; @.str.167
	.asciz	"I64_LT_S"

l_.str.168:                             ; @.str.168
	.asciz	"I64_LE_S"

l_.str.169:                             ; @.str.169
	.asciz	"I64_GT_S"

l_.str.170:                             ; @.str.170
	.asciz	"I64_GE_S"

l_.str.171:                             ; @.str.171
	.asciz	"F64_EQ"

l_.str.172:                             ; @.str.172
	.asciz	"F64_NE"

l_.str.173:                             ; @.str.173
	.asciz	"F64_LT"

l_.str.174:                             ; @.str.174
	.asciz	"F64_LE"

l_.str.175:                             ; @.str.175
	.asciz	"F64_GT"

l_.str.176:                             ; @.str.176
	.asciz	"F64_GE"

l_.str.177:                             ; @.str.177
	.asciz	"BOOL_AND"

l_.str.178:                             ; @.str.178
	.asciz	"BOOL_OR"

l_.str.179:                             ; @.str.179
	.asciz	"BOOL_NOT"

l_.str.180:                             ; @.str.180
	.asciz	"I64_DIV_U"

l_.str.181:                             ; @.str.181
	.asciz	"I64_REM_U"

l_.str.182:                             ; @.str.182
	.asciz	"I64_LT_U"

l_.str.183:                             ; @.str.183
	.asciz	"I64_LE_U"

l_.str.184:                             ; @.str.184
	.asciz	"I64_GT_U"

l_.str.185:                             ; @.str.185
	.asciz	"I64_GE_U"

l_.str.186:                             ; @.str.186
	.asciz	"I64_AND"

l_.str.187:                             ; @.str.187
	.asciz	"I64_OR"

l_.str.188:                             ; @.str.188
	.asciz	"I64_XOR"

l_.str.189:                             ; @.str.189
	.asciz	"I64_INVERT"

l_.str.190:                             ; @.str.190
	.asciz	"I64_SHL"

l_.str.191:                             ; @.str.191
	.asciz	"I64_SHR_S"

l_.str.192:                             ; @.str.192
	.asciz	"I64_SHR_U"

l_.str.193:                             ; @.str.193
	.asciz	"I64_ADD_CARRY"

l_.str.194:                             ; @.str.194
	.asciz	"I64_SUB_BORROW"

l_.str.195:                             ; @.str.195
	.asciz	"I64_MUL_WIDE_S"

l_.str.196:                             ; @.str.196
	.asciz	"I64_MUL_WIDE_U"

l_.str.197:                             ; @.str.197
	.asciz	"PICK"

l_.str.198:                             ; @.str.198
	.asciz	"ROLL"

l_.str.199:                             ; @.str.199
	.asciz	"ARRAY_ADD"

l_.str.200:                             ; @.str.200
	.asciz	"ARRAY_SUB"

l_.str.201:                             ; @.str.201
	.asciz	"ARRAY_MUL"

l_.str.202:                             ; @.str.202
	.asciz	"ARRAY_DIV"

l_.str.203:                             ; @.str.203
	.asciz	"FUNCREF"

l_.str.204:                             ; @.str.204
	.asciz	"AGG_PACK"

l_.str.205:                             ; @.str.205
	.asciz	"AGG_GET"

l_.str.206:                             ; @.str.206
	.asciz	"AGG_SET"

l_.str.207:                             ; @.str.207
	.asciz	"AGG_TAG"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @nanoisa_schema_opcodes
_nanoisa_schema_opcodes:
	.quad	l_.str.17
	.byte	165                             ; 0xa5
	.byte	4                               ; 0x4
	.space	2
	.long	3                               ; 0x3
	.long	4                               ; 0x4
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.18
	.byte	166                             ; 0xa6
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.19
	.byte	167                             ; 0xa7
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.20
	.byte	168                             ; 0xa8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.21
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.22
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.long	5                               ; 0x5
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.23
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.long	6                               ; 0x6
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.24
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.25
	.byte	4                               ; 0x4
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.26
	.byte	5                               ; 0x5
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.27
	.byte	6                               ; 0x6
	.byte	1                               ; 0x1
	.space	2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.28
	.byte	7                               ; 0x7
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.29
	.byte	8                               ; 0x8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.30
	.byte	9                               ; 0x9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.31
	.byte	10                              ; 0xa
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	3                               ; 0x3
	.space	2
	.quad	l_.str.32
	.byte	145                             ; 0x91
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.33
	.byte	146                             ; 0x92
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.34
	.byte	147                             ; 0x93
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.35
	.byte	148                             ; 0x94
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.36
	.byte	149                             ; 0x95
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.37
	.byte	151                             ; 0x97
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.38
	.byte	152                             ; 0x98
	.byte	3                               ; 0x3
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.39
	.byte	150                             ; 0x96
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.40
	.byte	11                              ; 0xb
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.41
	.byte	12                              ; 0xc
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.42
	.byte	13                              ; 0xd
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.43
	.byte	14                              ; 0xe
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.44
	.byte	15                              ; 0xf
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.45
	.byte	16                              ; 0x10
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.46
	.byte	17                              ; 0x11
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.47
	.byte	18                              ; 0x12
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.48
	.byte	19                              ; 0x13
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.49
	.byte	20                              ; 0x14
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.50
	.byte	21                              ; 0x15
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.51
	.byte	22                              ; 0x16
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.52
	.byte	23                              ; 0x17
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.53
	.byte	24                              ; 0x18
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.54
	.byte	25                              ; 0x19
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.55
	.byte	26                              ; 0x1a
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.56
	.byte	27                              ; 0x1b
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.57
	.byte	28                              ; 0x1c
	.byte	3                               ; 0x3
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.58
	.byte	29                              ; 0x1d
	.byte	3                               ; 0x3
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.59
	.byte	30                              ; 0x1e
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.60
	.byte	31                              ; 0x1f
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.61
	.byte	32                              ; 0x20
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.62
	.byte	33                              ; 0x21
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.63
	.byte	34                              ; 0x22
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.64
	.byte	35                              ; 0x23
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.65
	.byte	36                              ; 0x24
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.66
	.byte	37                              ; 0x25
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.67
	.byte	40                              ; 0x28
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.68
	.byte	41                              ; 0x29
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.69
	.byte	42                              ; 0x2a
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.70
	.byte	43                              ; 0x2b
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.71
	.byte	44                              ; 0x2c
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.72
	.byte	45                              ; 0x2d
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.73
	.byte	48                              ; 0x30
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.74
	.byte	49                              ; 0x31
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.75
	.byte	50                              ; 0x32
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.76
	.byte	51                              ; 0x33
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.77
	.byte	56                              ; 0x38
	.byte	1                               ; 0x1
	.space	2
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.78
	.byte	57                              ; 0x39
	.byte	1                               ; 0x1
	.space	2
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.79
	.byte	58                              ; 0x3a
	.byte	1                               ; 0x1
	.space	2
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.80
	.byte	59                              ; 0x3b
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.81
	.byte	60                              ; 0x3c
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.82
	.byte	61                              ; 0x3d
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.83
	.byte	62                              ; 0x3e
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.84
	.byte	63                              ; 0x3f
	.byte	4                               ; 0x4
	.space	2
	.long	3                               ; 0x3
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.85
	.byte	64                              ; 0x40
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.86
	.byte	65                              ; 0x41
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.87
	.byte	66                              ; 0x42
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.88
	.byte	67                              ; 0x43
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.89
	.byte	68                              ; 0x44
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.90
	.byte	69                              ; 0x45
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.91
	.byte	70                              ; 0x46
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.92
	.byte	71                              ; 0x47
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.93
	.byte	72                              ; 0x48
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.94
	.byte	73                              ; 0x49
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.95
	.byte	74                              ; 0x4a
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.96
	.byte	75                              ; 0x4b
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.97
	.byte	76                              ; 0x4c
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.98
	.byte	77                              ; 0x4d
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.99
	.byte	78                              ; 0x4e
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.100
	.byte	80                              ; 0x50
	.byte	1                               ; 0x1
	.space	2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.101
	.byte	81                              ; 0x51
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.102
	.byte	82                              ; 0x52
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.103
	.byte	83                              ; 0x53
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.104
	.byte	84                              ; 0x54
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.105
	.byte	85                              ; 0x55
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.106
	.byte	86                              ; 0x56
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.107
	.byte	87                              ; 0x57
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.108
	.byte	88                              ; 0x58
	.byte	2                               ; 0x2
	.space	2
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.109
	.byte	96                              ; 0x60
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.110
	.byte	97                              ; 0x61
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.111
	.byte	98                              ; 0x62
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.112
	.byte	99                              ; 0x63
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.113
	.byte	104                             ; 0x68
	.byte	3                               ; 0x3
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.114
	.byte	105                             ; 0x69
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.115
	.byte	106                             ; 0x6a
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.116
	.byte	107                             ; 0x6b
	.byte	2                               ; 0x2
	.space	2
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.117
	.byte	108                             ; 0x6c
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.118
	.byte	112                             ; 0x70
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.119
	.byte	113                             ; 0x71
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.120
	.byte	120                             ; 0x78
	.byte	2                               ; 0x2
	.space	2
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.121
	.byte	121                             ; 0x79
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.122
	.byte	122                             ; 0x7a
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.123
	.byte	123                             ; 0x7b
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.124
	.byte	124                             ; 0x7c
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.125
	.byte	125                             ; 0x7d
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.126
	.byte	126                             ; 0x7e
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.127
	.byte	127                             ; 0x7f
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.128
	.byte	128                             ; 0x80
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.129
	.byte	129                             ; 0x81
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.130
	.byte	136                             ; 0x88
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.131
	.byte	137                             ; 0x89
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.132
	.byte	138                             ; 0x8a
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.133
	.byte	139                             ; 0x8b
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.134
	.byte	140                             ; 0x8c
	.byte	1                               ; 0x1
	.space	2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.135
	.byte	141                             ; 0x8d
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.136
	.byte	142                             ; 0x8e
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.137
	.byte	143                             ; 0x8f
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.138
	.byte	144                             ; 0x90
	.byte	2                               ; 0x2
	.space	2
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.139
	.byte	160                             ; 0xa0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.140
	.byte	161                             ; 0xa1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.141
	.byte	162                             ; 0xa2
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.142
	.byte	163                             ; 0xa3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.143
	.byte	164                             ; 0xa4
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.144
	.byte	176                             ; 0xb0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.145
	.byte	177                             ; 0xb1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.146
	.byte	178                             ; 0xb2
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.147
	.byte	179                             ; 0xb3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.148
	.byte	180                             ; 0xb4
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.149
	.byte	181                             ; 0xb5
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.150
	.byte	182                             ; 0xb6
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.151
	.byte	183                             ; 0xb7
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.152
	.byte	184                             ; 0xb8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.153
	.byte	185                             ; 0xb9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.space	2
	.quad	l_.str.154
	.byte	192                             ; 0xc0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.155
	.byte	193                             ; 0xc1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.156
	.byte	194                             ; 0xc2
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.157
	.byte	195                             ; 0xc3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.158
	.byte	196                             ; 0xc4
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.159
	.byte	197                             ; 0xc5
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.160
	.byte	200                             ; 0xc8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.161
	.byte	201                             ; 0xc9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.162
	.byte	202                             ; 0xca
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.163
	.byte	203                             ; 0xcb
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.164
	.byte	204                             ; 0xcc
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.165
	.byte	208                             ; 0xd0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.166
	.byte	209                             ; 0xd1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.167
	.byte	210                             ; 0xd2
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.168
	.byte	211                             ; 0xd3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.169
	.byte	212                             ; 0xd4
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.170
	.byte	213                             ; 0xd5
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.171
	.byte	216                             ; 0xd8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.172
	.byte	217                             ; 0xd9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.173
	.byte	218                             ; 0xda
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.174
	.byte	219                             ; 0xdb
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.175
	.byte	220                             ; 0xdc
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.176
	.byte	221                             ; 0xdd
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.177
	.byte	224                             ; 0xe0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.178
	.byte	225                             ; 0xe1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.179
	.byte	226                             ; 0xe2
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.180
	.byte	227                             ; 0xe3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.181
	.byte	228                             ; 0xe4
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.182
	.byte	229                             ; 0xe5
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.183
	.byte	230                             ; 0xe6
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.184
	.byte	231                             ; 0xe7
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.185
	.byte	232                             ; 0xe8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.186
	.byte	233                             ; 0xe9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.187
	.byte	234                             ; 0xea
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.188
	.byte	235                             ; 0xeb
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.189
	.byte	236                             ; 0xec
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.190
	.byte	237                             ; 0xed
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.191
	.byte	238                             ; 0xee
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.192
	.byte	239                             ; 0xef
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.193
	.byte	240                             ; 0xf0
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.194
	.byte	241                             ; 0xf1
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	3                               ; 0x3
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.195
	.byte	242                             ; 0xf2
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.196
	.byte	243                             ; 0xf3
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	2                               ; 0x2
	.space	2
	.quad	l_.str.197
	.byte	244                             ; 0xf4
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.198
	.byte	245                             ; 0xf5
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.199
	.byte	246                             ; 0xf6
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.200
	.byte	247                             ; 0xf7
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.201
	.byte	248                             ; 0xf8
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.202
	.byte	249                             ; 0xf9
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.203
	.byte	250                             ; 0xfa
	.byte	1                               ; 0x1
	.space	2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.204
	.byte	251                             ; 0xfb
	.byte	4                               ; 0x4
	.space	2
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.byte	255                             ; 0xff
	.byte	255                             ; 0xff
	.space	2
	.quad	l_.str.205
	.byte	252                             ; 0xfc
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.206
	.byte	253                             ; 0xfd
	.byte	1                               ; 0x1
	.space	2
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.byte	2                               ; 0x2
	.byte	1                               ; 0x1
	.space	2
	.quad	l_.str.207
	.byte	254                             ; 0xfe
	.byte	0                               ; 0x0
	.space	2
	.space	16
	.byte	1                               ; 0x1
	.byte	1                               ; 0x1
	.space	2

.zerofill __DATA,__bss,_extended_table_ready,1,0 ; @extended_table_ready
	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @nanoisa_extended_opcodes
_nanoisa_extended_opcodes:
	.space	32

.subsections_via_symbols
