	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_resolver_path        ; -- Begin function nl_socket_resolver_path
	.p2align	2
_nl_socket_resolver_path:               ; @nl_socket_resolver_path
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	mov	w9, #8352                       ; =0x20a0
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
Lloh5:
	adrp	x0, l_.str@PAGE
Lloh6:
	add	x0, x0, l_.str@PAGEOFF
	bl	_getenv
	mov	x21, x0
Lloh7:
	adrp	x0, l_.str.1@PAGE
Lloh8:
	add	x0, x0, l_.str.1@PAGEOFF
	bl	_getenv
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB0_17
; %bb.1:
	cbz	x20, LBB0_17
; %bb.2:
	cbz	x21, LBB0_5
; %bb.3:
	ldrb	w8, [x21]
	cmp	w8, #47
	b.ne	LBB0_16
; %bb.4:
	str	x21, [sp]
Lloh9:
	adrp	x2, l_.str.2@PAGE
Lloh10:
	add	x2, x2, l_.str.2@PAGEOFF
	b	LBB0_8
LBB0_5:
	cbz	x8, LBB0_15
; %bb.6:
	ldrb	w9, [x8]
	cmp	w9, #47
	b.ne	LBB0_16
; %bb.7:
	str	x8, [sp]
Lloh11:
	adrp	x2, l_.str.3@PAGE
Lloh12:
	add	x2, x2, l_.str.3@PAGEOFF
LBB0_8:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #152
	mov	w1, #4096                       ; =0x1000
	bl	_snprintf
	cmp	w0, #4095
	b.hi	LBB0_16
; %bb.9:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #152
	add	x1, sp, #152
	bl	_realpath$DARWIN_EXTSN
	cbz	x0, LBB0_17
; %bb.10:
	add	x0, sp, #152
	add	x1, sp, #8
	bl	_stat
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB0_17
; %bb.11:
	ldrsh	w8, [sp, #12]
	cmn	w8, #7, lsl #12                 ; =28672
	b.ge	LBB0_17
; %bb.12:
	add	x0, sp, #152
	mov	w1, #1                          ; =0x1
	bl	_access
	cbnz	w0, LBB0_16
; %bb.13:
	add	x0, sp, #152
	bl	_strlen
	cmp	x0, x20
	b.hs	LBB0_16
; %bb.14:
	add	x1, sp, #152
	add	x2, x0, #1
	mov	x0, x19
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	b	LBB0_17
LBB0_15:
	mov	w8, #4096                       ; =0x1000
	str	w8, [sp, #8]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #152
	add	x1, sp, #8
	bl	__NSGetExecutablePath
	cbz	w0, LBB0_19
LBB0_16:
	mov	w0, #0                          ; =0x0
LBB0_17:
	ldur	x8, [x29, #-40]
Lloh13:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh14:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh15:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_22
; %bb.18:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #160
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB0_19:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #152
	add	x1, sp, #152
	bl	_realpath$DARWIN_EXTSN
	cbz	x0, LBB0_16
; %bb.20:
	add	x21, sp, #152
	add	x0, sp, #152
	mov	w1, #47                         ; =0x2f
	bl	_strrchr
	cbz	x0, LBB0_16
; %bb.21:
	strb	wzr, [x0]
	str	x21, [sp]
Lloh16:
	adrp	x2, l_.str.4@PAGE
Lloh17:
	add	x2, x2, l_.str.4@PAGEOFF
	b	LBB0_8
LBB0_22:
	bl	___stack_chk_fail
	.loh AdrpAdd	Lloh7, Lloh8
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpAdd	Lloh11, Lloh12
	.loh AdrpLdrGotLdr	Lloh13, Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_socket_resolve_tcp_supervised
lCPI1_0:
	.long	11                              ; 0xb
	.long	0                               ; 0x0
lCPI1_1:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
lCPI1_2:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_resolve_tcp_supervised
	.p2align	2
_nl_socket_resolve_tcp_supervised:      ; @nl_socket_resolve_tcp_supervised
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1280
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x7
	mov	x22, x6
	mov	x23, x5
	mov	x26, x4
	mov	x21, x3
	mov	x24, x2
	mov	x25, x1
	mov	x19, x8
Lloh18:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh19:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh20:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	stur	xzr, [x19, #12]
	mov	w4, #0                          ; =0x0
	mov	x5, x7
	bl	_nl_socket_resolve_tcp
	str	x0, [x19]
	str	w1, [x19, #8]
	cbz	w26, LBB1_25
; %bb.1:
	mov	w8, w0
	cmp	x8, #7
	b.ne	LBB1_25
; %bb.2:
Lloh21:
	adrp	x8, lCPI1_0@PAGE
Lloh22:
	ldr	d0, [x8, lCPI1_0@PAGEOFF]
	str	d0, [x19]
	str	wzr, [x19, #8]
	cbz	x23, LBB1_10
; %bb.3:
	mov	w8, #-60001                     ; =0xffff159f
	mov	w9, #-60000                     ; =0xffff15a0
	add	w8, w22, w8
	cmp	w8, w9
	b.lo	LBB1_10
; %bb.4:
	ldrb	w8, [x23]
	cmp	w8, #47
	b.ne	LBB1_10
; %bb.5:
	add	x1, sp, #8
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB1_23
; %bb.6:
	ldp	x27, x28, [sp, #8]
	sub	x0, x29, #104
	bl	_pipe
	cbnz	w0, LBB1_23
; %bb.7:
	ldur	w0, [x29, #-104]
	cmp	w0, #2
	b.gt	LBB1_11
; %bb.8:
	mov	w8, #3                          ; =0x3
	str	x8, [sp]
	mov	w1, #67                         ; =0x43
	bl	_fcntl
	tbnz	w0, #31, LBB1_22
; %bb.9:
	mov	x26, x0
	ldur	w0, [x29, #-104]
	bl	_close
	stur	w26, [x29, #-104]
	b	LBB1_12
LBB1_10:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #12]
	b	LBB1_25
LBB1_11:
	mov	w8, #1                          ; =0x1
	str	x8, [sp]
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbnz	w0, #31, LBB1_22
LBB1_12:
	ldur	w0, [x29, #-100]
	cmp	w0, #3
	b.ge	LBB1_15
; %bb.13:
	mov	w8, #3                          ; =0x3
	str	x8, [sp]
	mov	w1, #67                         ; =0x43
	bl	_fcntl
	tbnz	w0, #31, LBB1_22
; %bb.14:
	mov	x26, x0
	ldur	w0, [x29, #-100]
	bl	_close
	stur	w26, [x29, #-100]
	b	LBB1_16
LBB1_15:
	mov	w8, #1                          ; =0x1
	str	x8, [sp]
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbnz	w0, #31, LBB1_22
LBB1_16:
	ldur	w0, [x29, #-104]
	mov	w8, #4                          ; =0x4
	str	x8, [sp]
	mov	w1, #4                          ; =0x4
	bl	_fcntl
	tbnz	w0, #31, LBB1_22
; %bb.17:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #476]
	add	x26, sp, #1002
	add	x0, sp, #1002
	mov	x1, x25
	mov	x2, x24
	mov	w3, #254                        ; =0xfe
	bl	___memcpy_chk
	strb	wzr, [x26, x24]
	str	x21, [sp]
Lloh23:
	adrp	x2, l_.str.5@PAGE
Lloh24:
	add	x2, x2, l_.str.5@PAGEOFF
	add	x24, sp, #470
	add	x0, sp, #470
	mov	w1, #6                          ; =0x6
	bl	_snprintf
	str	x23, [sp, #968]
	str	x26, [sp, #976]
	str	x24, [sp, #984]
	str	xzr, [sp, #992]
	add	x0, sp, #488
	bl	_posix_spawn_file_actions_init
	mov	x24, x0
	cbnz	w0, LBB1_20
; %bb.18:
	add	x0, sp, #480
	bl	_posix_spawnattr_init
	cbz	w0, LBB1_27
; %bb.19:
	mov	x24, x0
	add	x0, sp, #488
	bl	_posix_spawn_file_actions_destroy
LBB1_20:
	ldur	w0, [x29, #-100]
	bl	_close
LBB1_21:
	ldur	w0, [x29, #-104]
	bl	_close
	mov	w8, #2                          ; =0x2
	stp	w8, w24, [x19, #12]
	b	LBB1_25
LBB1_22:
	bl	___error
	ldr	w20, [x0]
	ldur	w0, [x29, #-104]
	bl	_close
	ldur	w0, [x29, #-100]
	bl	_close
	bl	___error
	str	w20, [x0]
LBB1_23:
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #12]
LBB1_24:
	bl	___error
	ldr	w8, [x0]
	str	w8, [x19, #16]
LBB1_25:
	ldur	x8, [x29, #-96]
Lloh25:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh26:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh27:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_74
; %bb.26:
	add	sp, sp, #1280
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_27:
	ldur	w1, [x29, #-100]
	add	x0, sp, #488
	mov	w2, #1                          ; =0x1
	bl	_posix_spawn_file_actions_adddup2
	cbnz	w0, LBB1_33
; %bb.28:
	ldur	w1, [x29, #-104]
	add	x0, sp, #488
	bl	_posix_spawn_file_actions_addclose
	cbnz	w0, LBB1_33
; %bb.29:
	ldur	w1, [x29, #-100]
	add	x0, sp, #488
	bl	_posix_spawn_file_actions_addclose
	cbnz	w0, LBB1_33
; %bb.30:
	add	x0, sp, #480
	mov	w1, #0                          ; =0x0
	bl	_posix_spawnattr_setpgroup
	cbnz	w0, LBB1_33
; %bb.31:
	add	x0, sp, #480
	mov	w1, #2                          ; =0x2
	bl	_posix_spawnattr_setflags
	cbnz	w0, LBB1_33
; %bb.32:
Lloh28:
	adrp	x8, _environ@GOTPAGE
Lloh29:
	ldr	x8, [x8, _environ@GOTPAGEOFF]
Lloh30:
	ldr	x5, [x8]
	add	x0, sp, #476
	add	x2, sp, #488
	add	x3, sp, #480
	add	x4, sp, #968
	mov	x1, x23
	bl	_posix_spawn
LBB1_33:
	mov	x24, x0
	add	x0, sp, #488
	bl	_posix_spawn_file_actions_destroy
	add	x0, sp, #480
	bl	_posix_spawnattr_destroy
	ldur	w0, [x29, #-100]
	bl	_close
	cbnz	w24, LBB1_21
; %bb.34:
	mov	x23, #0                         ; =0x0
	mov	w8, #1000                       ; =0x3e8
	mov	x24, #13531                     ; =0x34db
	movk	x24, #55222, lsl #16
	movk	x24, #56962, lsl #32
	movk	x24, #17179, lsl #48
	smulh	x9, x28, x24
	mul	x8, x27, x8
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	add	x8, x8, w22, uxtw
	add	x25, x8, x9
	mov	w28, #1000                      ; =0x3e8
LBB1_35:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_38 Depth 2
	add	x1, sp, #8
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB1_54
; %bb.36:                               ;   in Loop: Header=BB1_35 Depth=1
	mov	w26, #0                         ; =0x0
	mov	w8, #469                        ; =0x1d5
	sub	x22, x8, x23
	b	LBB1_38
LBB1_37:                                ;   in Loop: Header=BB1_38 Depth=2
	add	x1, sp, #8
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB1_54
LBB1_38:                                ;   Parent Loop BB1_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	x8, x9, [sp, #8]
	smulh	x9, x9, x24
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x27, x8, x28, x9
	cmp	x25, x27
	b.le	LBB1_55
; %bb.39:                               ;   in Loop: Header=BB1_38 Depth=2
	tbnz	w26, #0, LBB1_46
; %bb.40:                               ;   in Loop: Header=BB1_38 Depth=2
	ldur	w0, [x29, #-104]
	add	x8, sp, #499
	add	x1, x8, x23
	mov	x2, x22
	bl	_read
	cmp	x0, #1
	b.ge	LBB1_52
; %bb.41:                               ;   in Loop: Header=BB1_38 Depth=2
	cbz	x0, LBB1_46
; %bb.42:                               ;   in Loop: Header=BB1_38 Depth=2
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #35
	b.eq	LBB1_45
; %bb.43:                               ;   in Loop: Header=BB1_38 Depth=2
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #35
	b.eq	LBB1_45
; %bb.44:                               ;   in Loop: Header=BB1_38 Depth=2
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB1_54
LBB1_45:                                ;   in Loop: Header=BB1_38 Depth=2
	mov	w26, #0                         ; =0x0
	add	x0, sp, #8
	b	LBB1_50
LBB1_46:                                ;   in Loop: Header=BB1_38 Depth=2
	ldr	w0, [sp, #476]
	add	x1, sp, #464
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	ldr	w8, [sp, #476]
	cmp	w0, w8
	b.eq	LBB1_56
; %bb.47:                               ;   in Loop: Header=BB1_38 Depth=2
	tbz	w0, #31, LBB1_49
; %bb.48:                               ;   in Loop: Header=BB1_38 Depth=2
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB1_54
LBB1_49:                                ;   in Loop: Header=BB1_38 Depth=2
	mov	x0, #0                          ; =0x0
	mov	w26, #1                         ; =0x1
LBB1_50:                                ;   in Loop: Header=BB1_38 Depth=2
	sub	w8, w25, w27
	ldur	w9, [x29, #-104]
	cmp	w8, #10
	mov	w10, #10                        ; =0xa
	csel	w2, w8, w10, lt
	mov	w8, #1                          ; =0x1
	stp	w9, w8, [sp, #8]
	eor	w1, w26, #0x1
	bl	_poll
	tbz	w0, #31, LBB1_37
; %bb.51:                               ;   in Loop: Header=BB1_38 Depth=2
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB1_37
	b	LBB1_58
LBB1_52:                                ;   in Loop: Header=BB1_35 Depth=1
	add	x23, x0, x23
	cmp	x23, #469
	b.lo	LBB1_35
; %bb.53:
	mov	w20, #0                         ; =0x0
Lloh31:
	adrp	x8, lCPI1_2@PAGE
Lloh32:
	ldr	d0, [x8, lCPI1_2@PAGEOFF]
	stur	d0, [x19, #12]
	b	LBB1_60
LBB1_54:
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #12]
	bl	___error
	ldr	w20, [x0]
	b	LBB1_59
LBB1_55:
	mov	w20, #0                         ; =0x0
Lloh33:
	adrp	x8, lCPI1_1@PAGE
Lloh34:
	ldr	d0, [x8, lCPI1_1@PAGEOFF]
	stur	d0, [x19, #12]
	b	LBB1_60
LBB1_56:
	stp	wzr, wzr, [x19, #12]
	ldrh	w8, [sp, #464]
	tst	w8, #0xffffff7f
	b.eq	LBB1_67
; %bb.57:
	mov	w8, #5                          ; =0x5
	b	LBB1_72
LBB1_58:
	bl	___error
	ldr	w20, [x0]
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #12]
LBB1_59:
	str	w20, [x19, #16]
LBB1_60:
	ldur	w0, [x29, #-104]
	bl	_close
	ldr	w8, [sp, #476]
	neg	w0, w8
	mov	w1, #9                          ; =0x9
	bl	_kill
	tbz	w0, #31, LBB1_64
; %bb.61:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #3
	b.eq	LBB1_64
; %bb.62:
	cbnz	w20, LBB1_64
; %bb.63:
	bl	___error
	ldr	w20, [x0]
	str	w20, [x19, #16]
LBB1_64:                                ; =>This Inner Loop Header: Depth=1
	ldr	w0, [sp, #476]
	add	x1, sp, #8
	mov	w2, #0                          ; =0x0
	bl	_waitpid
	tbz	w0, #31, LBB1_25
; %bb.65:                               ;   in Loop: Header=BB1_64 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB1_64
; %bb.66:
	cbnz	w20, LBB1_25
	b	LBB1_24
LBB1_67:
	cmp	x23, #468
	b.ne	LBB1_71
; %bb.68:
	add	x0, sp, #499
	add	x3, sp, #8
	mov	x1, x21
	mov	x2, x19
	bl	_lookup_decode
	tbz	w0, #0, LBB1_71
; %bb.69:
	ldr	w8, [x19]
	cbnz	w8, LBB1_73
; %bb.70:
	add	x1, sp, #8
	mov	x0, x20
	mov	w2, #456                        ; =0x1c8
	bl	_memcpy
	b	LBB1_73
LBB1_71:
	mov	w8, #4                          ; =0x4
LBB1_72:
	str	w8, [x19, #12]
LBB1_73:
	ldur	w0, [x29, #-104]
	bl	_close
	b	LBB1_25
LBB1_74:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh18, Lloh19, Lloh20
	.loh AdrpLdr	Lloh21, Lloh22
	.loh AdrpAdd	Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh25, Lloh26, Lloh27
	.loh AdrpLdrGotLdr	Lloh28, Lloh29, Lloh30
	.loh AdrpLdr	Lloh31, Lloh32
	.loh AdrpLdr	Lloh33, Lloh34
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function lookup_decode
_lookup_decode:                         ; @lookup_decode
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	mov	w9, #19534                      ; =0x4c4e
	movk	w9, #12626, lsl #16
	cmp	w8, w9
	b.eq	LBB2_2
LBB2_1:
	mov	w0, #0                          ; =0x0
	ret
LBB2_2:
	ldrb	w8, [x0, #4]
	lsl	w8, w8, #24
	ldrb	w9, [x0, #5]
	orr	w8, w8, w9, lsl #16
	ldrb	w9, [x0, #6]
	orr	w8, w8, w9, lsl #8
	ldrb	w12, [x0, #7]
	orr	w8, w8, w12
	cmp	w8, #11
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w8
	mov	w10, #3845                      ; =0xf05
	and	w9, w9, w10
	ccmp	w9, #0, #4, ls
	b.eq	LBB2_1
; %bb.3:
	ldrb	w13, [x0, #12]
	lsl	w9, w13, #24
	tbnz	w9, #31, LBB2_1
; %bb.4:
	ldr	w9, [x0, #16]
	rev	w10, w9
	ldr	w9, [x0, #8]
	rev	w9, w9
	ldrb	w11, [x0, #13]
	ldrb	w14, [x0, #14]
	ldrb	w15, [x0, #15]
	orr	w11, w15, w11, lsl #16
	orr	w11, w11, w14, lsl #8
	bfi	w11, w13, #24, #8
	cmp	w11, #0
	ccmp	w9, #11, #4, ne
	ccmp	w10, #16, #2, eq
	b.hi	LBB2_1
; %bb.5:
	cbz	w8, LBB2_9
; %bb.6:
	cbnz	w10, LBB2_1
; %bb.7:
	mov	x14, x0
	cbz	w9, LBB2_68
; %bb.8:
	mov	w12, #10                        ; =0xa
	mov	w13, #11                        ; =0xb
	cmp	w9, #2
	csel	w13, w9, w13, eq
	cmp	w9, #6
	csel	w12, w12, w13, eq
	cmp	w8, w12
	b.eq	LBB2_12
	b	LBB2_1
LBB2_9:
	mov	x14, x0
	mov	w0, #0                          ; =0x0
	cbnz	w9, LBB2_67
; %bb.10:
	cbnz	w11, LBB2_67
; %bb.11:
	cbz	w10, LBB2_67
LBB2_12:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #464
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x12, #0                         ; =0x0
	add	x15, sp, #8
	add	x13, x15, #8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x13, #416]
	add	x16, sp, #8
	stp	q0, q0, [x13, #384]
	stp	q0, q0, [x13, #352]
	stp	q0, q0, [x13, #320]
	stp	q0, q0, [x13, #288]
	stp	q0, q0, [x13, #256]
	stur	q0, [x16, #248]
	stur	q0, [x16, #232]
	stur	q0, [x16, #216]
	stur	q0, [x16, #200]
	stur	q0, [x16, #184]
	stur	q0, [x16, #168]
	stur	q0, [x16, #152]
	stur	q0, [x16, #136]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	add	x14, x14, #20
	add	x15, x15, #32
	mov	w16, #28                        ; =0x1c
	str	x10, [sp, #8]
LBB2_13:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_32 Depth 2
	madd	x17, x12, x16, x14
	ldrb	w0, [x17]
	cmp	x12, x10
	b.hs	LBB2_35
; %bb.14:                               ;   in Loop: Header=BB2_13 Depth=1
	lsl	w0, w0, #24
	ldrb	w4, [x17, #1]
	orr	w0, w0, w4, lsl #16
	ldrb	w4, [x17, #2]
	orr	w0, w0, w4, lsl #8
	ldrb	w4, [x17, #3]
	orr	w0, w0, w4
	ldr	w4, [x17, #4]
	rev	w4, w4
	and	w5, w0, #0xfffffffd
	cmp	w5, #4
	ccmp	w4, w1, #0, eq
	b.ne	LBB2_65
; %bb.15:                               ;   in Loop: Header=BB2_13 Depth=1
	ldr	w4, [x17, #8]
	rev	w4, w4
	cmp	w0, #4
	b.ne	LBB2_29
; %bb.16:                               ;   in Loop: Header=BB2_13 Depth=1
	cbnz	w4, LBB2_65
; %bb.17:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #16]
	cbnz	w5, LBB2_65
; %bb.18:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #17]
	cbnz	w5, LBB2_65
; %bb.19:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #18]
	cbnz	w5, LBB2_65
; %bb.20:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #19]
	cbnz	w5, LBB2_65
; %bb.21:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #20]
	cbnz	w5, LBB2_65
; %bb.22:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #21]
	cbnz	w5, LBB2_65
; %bb.23:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #22]
	cbnz	w5, LBB2_65
; %bb.24:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #23]
	cbnz	w5, LBB2_65
; %bb.25:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #24]
	cbnz	w5, LBB2_65
; %bb.26:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #25]
	cbnz	w5, LBB2_65
; %bb.27:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #26]
	cbnz	w5, LBB2_65
; %bb.28:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w5, [x17, #27]
	cbnz	w5, LBB2_65
LBB2_29:                                ;   in Loop: Header=BB2_13 Depth=1
	madd	x5, x12, x16, x13
	str	w0, [x5]
	strh	w1, [x5, #20]
	strh	wzr, [x5, #22]
	str	w4, [x5, #24]
	ldur	q0, [x17, #12]
	stur	q0, [x5, #4]
	cbz	x12, LBB2_63
; %bb.30:                               ;   in Loop: Header=BB2_13 Depth=1
	mov	x5, x12
	mov	x6, x15
	b	LBB2_32
LBB2_31:                                ;   in Loop: Header=BB2_32 Depth=2
	add	x6, x6, #28
	subs	x5, x5, #1
	b.eq	LBB2_63
LBB2_32:                                ;   Parent Loop BB2_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w7, [x6, #-24]
	cmp	w7, w0
	b.ne	LBB2_31
; %bb.33:                               ;   in Loop: Header=BB2_32 Depth=2
	ldr	w7, [x6]
	cmp	w7, w4
	b.ne	LBB2_31
; %bb.34:                               ;   in Loop: Header=BB2_32 Depth=2
	ldur	x7, [x6, #-20]
	ldur	x19, [x17, #12]
	ldur	x20, [x6, #-12]
	ldur	x21, [x17, #20]
	cmp	x7, x19
	ccmp	x20, x21, #0, eq
	b.ne	LBB2_31
	b	LBB2_65
LBB2_35:                                ;   in Loop: Header=BB2_13 Depth=1
	cbnz	w0, LBB2_65
; %bb.36:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #1]
	cbnz	w0, LBB2_65
; %bb.37:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #2]
	cbnz	w0, LBB2_65
; %bb.38:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #3]
	cbnz	w0, LBB2_65
; %bb.39:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #4]
	cbnz	w0, LBB2_65
; %bb.40:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #5]
	cbnz	w0, LBB2_65
; %bb.41:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #6]
	cbnz	w0, LBB2_65
; %bb.42:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #7]
	cbnz	w0, LBB2_65
; %bb.43:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #8]
	cbnz	w0, LBB2_65
; %bb.44:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #9]
	cbnz	w0, LBB2_65
; %bb.45:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #10]
	cbnz	w0, LBB2_65
; %bb.46:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #11]
	cbnz	w0, LBB2_65
; %bb.47:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #12]
	cbnz	w0, LBB2_65
; %bb.48:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #13]
	cbnz	w0, LBB2_65
; %bb.49:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #14]
	cbnz	w0, LBB2_65
; %bb.50:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #15]
	cbnz	w0, LBB2_65
; %bb.51:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #16]
	cbnz	w0, LBB2_65
; %bb.52:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #17]
	cbnz	w0, LBB2_65
; %bb.53:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #18]
	cbnz	w0, LBB2_65
; %bb.54:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #19]
	cbnz	w0, LBB2_65
; %bb.55:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #20]
	cbnz	w0, LBB2_65
; %bb.56:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #21]
	cbnz	w0, LBB2_65
; %bb.57:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #22]
	cbnz	w0, LBB2_65
; %bb.58:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #23]
	cbnz	w0, LBB2_65
; %bb.59:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #24]
	cbnz	w0, LBB2_65
; %bb.60:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #25]
	cbnz	w0, LBB2_65
; %bb.61:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w0, [x17, #26]
	cbnz	w0, LBB2_65
; %bb.62:                               ;   in Loop: Header=BB2_13 Depth=1
	ldrb	w17, [x17, #27]
	cbnz	w17, LBB2_65
LBB2_63:                                ;   in Loop: Header=BB2_13 Depth=1
	add	x12, x12, #1
	cmp	x12, #16
	b.ne	LBB2_13
; %bb.64:
	stp	w8, w9, [x2]
	str	w11, [x2, #8]
	add	x1, sp, #8
	mov	x0, x3
	mov	w2, #456                        ; =0x1c8
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	b	LBB2_66
LBB2_65:
	mov	w0, #0                          ; =0x0
LBB2_66:
	add	sp, sp, #464
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB2_67:
	ret
LBB2_68:
	and	w12, w12, #0x3
	cmp	w12, #2
	b.eq	LBB2_1
	b	LBB2_12
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"NANOLANG_RESOLVER"

l_.str.1:                               ; @.str.1
	.asciz	"NANOLANG_ROOT"

l_.str.2:                               ; @.str.2
	.asciz	"%s"

l_.str.3:                               ; @.str.3
	.asciz	"%s/bin/nano-resolver"

l_.str.4:                               ; @.str.4
	.asciz	"%s/nano-resolver"

l_.str.5:                               ; @.str.5
	.asciz	"%u"

l_.str.6:                               ; @.str.6
	.asciz	"NLR1"

.subsections_via_symbols
