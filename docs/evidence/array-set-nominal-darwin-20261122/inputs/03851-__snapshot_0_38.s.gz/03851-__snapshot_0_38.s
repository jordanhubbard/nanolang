	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_websocket_host_enter_query ; -- Begin function nvm_websocket_host_enter_query
	.p2align	2
_nvm_websocket_host_enter_query:        ; @nvm_websocket_host_enter_query
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_nvm_file_host_enter_query
	mov	w8, #5                          ; =0x5
	cmp	w0, #0
	csel	w0, wzr, w8, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_host_leave       ; -- Begin function nvm_websocket_host_leave
	.p2align	2
_nvm_websocket_host_leave:              ; @nvm_websocket_host_leave
	.cfi_startproc
; %bb.0:
	b	_nvm_file_host_leave
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_host_enter       ; -- Begin function nvm_websocket_host_enter
	.p2align	2
_nvm_websocket_host_enter:              ; @nvm_websocket_host_enter
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB2_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB2_13
LBB2_2:
	cbz	x19, LBB2_10
; %bb.3:
	mov	w8, #4                          ; =0x4
	cmp	w21, #3
	b.ne	LBB2_12
; %bb.4:
	cmp	w20, #1
	b.ne	LBB2_12
; %bb.5:
	ldr	x9, [x19]
Lloh0:
	adrp	x10, _websocket_host_identity@PAGE
Lloh1:
	add	x10, x10, _websocket_host_identity@PAGEOFF
	cmp	x9, x10
	b.ne	LBB2_12
; %bb.6:
	ldr	w8, [x19, #8]
	cmp	w8, #1
	b.ne	LBB2_11
; %bb.7:
	ldr	w8, [x19, #12]
	cmp	w8, #3
	b.ne	LBB2_11
; %bb.8:
	ldrb	w8, [x19, #16]
	tbz	w8, #0, LBB2_14
; %bb.9:
	mov	w0, #0                          ; =0x0
	b	LBB2_13
LBB2_10:
	mov	w8, #1                          ; =0x1
	b	LBB2_12
LBB2_11:
	mov	w8, #4                          ; =0x4
LBB2_12:
	mov	x19, x8
	bl	_nvm_file_host_leave
	mov	x0, x19
LBB2_13:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB2_14:
	mov	w8, #3                          ; =0x3
	b	LBB2_12
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_host_policy      ; -- Begin function nvm_websocket_host_policy
	.p2align	2
_nvm_websocket_host_policy:             ; @nvm_websocket_host_policy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_8
; %bb.1:
	ldr	x8, [x0]
Lloh2:
	adrp	x9, _websocket_host_identity@PAGE
Lloh3:
	add	x9, x9, _websocket_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB3_7
; %bb.2:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB3_7
; %bb.3:
	ldr	w8, [x0, #12]
	cmp	w8, #3
	b.ne	LBB3_7
; %bb.4:
	ldrb	w8, [x0, #16]
	cmp	w8, #1
	b.ne	LBB3_9
; %bb.5:
	cbz	x1, LBB3_8
; %bb.6:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldur	q0, [x8, #24]
	ldr	x8, [x8, #40]
	str	x8, [x1, #16]
	str	q0, [x1]
	ret
LBB3_7:
	mov	w0, #4                          ; =0x4
	ret
LBB3_8:
	mov	w0, #1                          ; =0x1
	ret
LBB3_9:
	mov	w0, #3                          ; =0x3
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_websocket_host_grant_create
lCPI4_0:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_websocket_host_grant_create
	.p2align	2
_nvm_websocket_host_grant_create:       ; @nvm_websocket_host_grant_create
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x1
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB4_2
; %bb.1:
	mov	w21, #5                         ; =0x5
	b	LBB4_23
LBB4_2:
	mov	w21, #1                         ; =0x1
	cbz	x20, LBB4_22
; %bb.3:
	cbz	x19, LBB4_22
; %bb.4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB4_22
; %bb.5:
	ldr	w22, [x20, #8]
	mov	w8, #60000                      ; =0xea60
	cmp	w22, w8
	b.hi	LBB4_22
; %bb.6:
	ldrb	w23, [x20, #5]
	ldr	x21, [x20, #16]
	cmp	w23, #1
	b.ne	LBB4_8
; %bb.7:
	cbnz	x21, LBB4_9
	b	LBB4_15
LBB4_8:
	cbz	x21, LBB4_16
LBB4_9:
	mov	x24, #0                         ; =0x0
LBB4_10:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x21, x24]
	cbz	w8, LBB4_12
; %bb.11:                               ;   in Loop: Header=BB4_10 Depth=1
	add	x24, x24, #1
	cmp	x24, #1, lsl #12                ; =4096
	b.ne	LBB4_10
	b	LBB4_15
LBB4_12:
	mov	x8, #-4097                      ; =0xffffffffffffefff
	movk	x8, #32767, lsl #48
	tst	x24, x8
	b.eq	LBB4_15
; %bb.13:
	ldrb	w8, [x21]
	cmp	w8, #47
	b.ne	LBB4_15
; %bb.14:
	mov	w25, #0                         ; =0x0
	b	LBB4_17
LBB4_15:
	mov	w21, #1                         ; =0x1
	b	LBB4_22
LBB4_16:
	mov	x24, #0                         ; =0x0
	mov	w25, #1                         ; =0x1
LBB4_17:
	mov	w26, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #4144                       ; =0x1030
	bl	_calloc
	cbz	x0, LBB4_21
; %bb.18:
Lloh4:
	adrp	x8, _websocket_host_identity@PAGE
Lloh5:
	add	x8, x8, _websocket_host_identity@PAGEOFF
	str	x8, [x0]
Lloh6:
	adrp	x8, lCPI4_0@PAGE
Lloh7:
	ldr	d0, [x8, lCPI4_0@PAGEOFF]
	str	d0, [x0, #8]
	strb	w26, [x0, #16]
	ldrb	w8, [x20, #4]
	strb	w8, [x0, #24]
	strb	w23, [x0, #25]
	str	w22, [x0, #40]
	tbnz	w25, #0, LBB4_20
; %bb.19:
	add	x20, x0, #48
	add	x2, x24, #1
	mov	x22, x0
	mov	x0, x20
	mov	x1, x21
	mov	w3, #4096                       ; =0x1000
	bl	___memcpy_chk
	mov	x0, x22
	str	x20, [x22, #32]
LBB4_20:
	mov	w21, #0                         ; =0x0
	str	x0, [x19]
	b	LBB4_22
LBB4_21:
	mov	w21, #2                         ; =0x2
LBB4_22:
	bl	_nvm_file_host_leave
LBB4_23:
	mov	x0, x21
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_host_grant_revoke ; -- Begin function nvm_websocket_host_grant_revoke
	.p2align	2
_nvm_websocket_host_grant_revoke:       ; @nvm_websocket_host_grant_revoke
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB5_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB5_10
LBB5_2:
	cbz	x20, LBB5_8
; %bb.3:
	ldr	x8, [x20]
Lloh8:
	adrp	x9, _websocket_host_identity@PAGE
Lloh9:
	add	x9, x9, _websocket_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB5_7
; %bb.4:
	ldr	w8, [x20, #8]
	cmp	w8, #1
	b.ne	LBB5_7
; %bb.5:
	ldr	w8, [x20, #12]
	cmp	w8, #3
	b.ne	LBB5_7
; %bb.6:
	mov	w19, #0                         ; =0x0
	strb	wzr, [x20, #16]
	b	LBB5_9
LBB5_7:
	mov	w19, #4                         ; =0x4
	b	LBB5_9
LBB5_8:
	mov	w19, #1                         ; =0x1
LBB5_9:
	bl	_nvm_file_host_leave
LBB5_10:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_host_grant_destroy ; -- Begin function nvm_websocket_host_grant_destroy
	.p2align	2
_nvm_websocket_host_grant_destroy:      ; @nvm_websocket_host_grant_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB6_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB6_12
LBB6_2:
	cbz	x20, LBB6_8
; %bb.3:
	ldr	x0, [x20]
	cbz	x0, LBB6_10
; %bb.4:
	ldr	x8, [x0]
Lloh10:
	adrp	x9, _websocket_host_identity@PAGE
Lloh11:
	add	x9, x9, _websocket_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB6_9
; %bb.5:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB6_9
; %bb.6:
	ldr	w8, [x0, #12]
	cmp	w8, #3
	b.ne	LBB6_9
; %bb.7:
	bl	_free
	mov	w19, #0                         ; =0x0
	str	xzr, [x20]
	b	LBB6_11
LBB6_8:
	mov	w19, #1                         ; =0x1
	b	LBB6_11
LBB6_9:
	mov	w19, #4                         ; =0x4
	b	LBB6_11
LBB6_10:
	mov	w19, #0                         ; =0x0
LBB6_11:
	bl	_nvm_file_host_leave
LBB6_12:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @websocket_host_identity
_websocket_host_identity:
	.long	1                               ; 0x1

.subsections_via_symbols
