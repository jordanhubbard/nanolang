/Users/jkh/.worktrees/nanolang/array-set-nominal-20261122-control/compiler-sanitizers/transpiler.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  src/transpiler.c src/nanolang.h src/generated/compiler_schema.h \
  src/runtime/dyn_array.h src/runtime/gc.h src/runtime/gc_struct.h \
  src/generic_bindings.h src/module_symbol.h src/module_builder.h \
  src/stdlib_runtime.h src/builtins_registry.h \
  src/transpiler_iterative_v3_twopass.c src/utf8.h \
  src/checked_loop_binding.h
/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json:
src/nanolang.h:
src/generated/compiler_schema.h:
src/runtime/dyn_array.h:
src/runtime/gc.h:
src/runtime/gc_struct.h:
src/generic_bindings.h:
src/module_symbol.h:
src/module_builder.h:
src/stdlib_runtime.h:
src/builtins_registry.h:
src/transpiler_iterative_v3_twopass.c:
src/utf8.h:
src/checked_loop_binding.h:
