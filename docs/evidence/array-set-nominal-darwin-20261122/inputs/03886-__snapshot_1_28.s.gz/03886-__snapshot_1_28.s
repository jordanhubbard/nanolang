	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_file_nominal_storage_bound ; -- Begin function nvm_file_nominal_storage_bound
	.globl	_nvm_file_nominal_storage_bound
	.p2align	2
_nvm_file_nominal_storage_bound:        ; @nvm_file_nominal_storage_bound
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	w0, #16, lsl #12                ; =65536
	ccmp	x1, #0, #4, ls
	cset	w0, ne
	b.eq	LBB0_2
; %bb.1:
	mov	w9, #20                         ; =0x14
	mov	w10, #56                        ; =0x38
	madd	w8, w8, w9, w10
	str	x8, [x1]
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_plan  ; -- Begin function nvm_file_nominal_plan
	.globl	_nvm_file_nominal_plan
	.p2align	2
_nvm_file_nominal_plan:                 ; @nvm_file_nominal_plan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	cbz	x19, LBB1_8
; %bb.1:
	cbz	x1, LBB1_8
; %bb.2:
	mov	x23, x1
	ldr	x0, [x19, #328]
	ldr	w1, [x19, #336]
	add	x2, sp, #16
	bl	_nvm_file_nominal_decode
	cbnz	w0, LBB1_7
; %bb.3:
	ldr	w8, [x19, #432]
	cmp	w8, #5
	b.ne	LBB1_7
; %bb.4:
	ldr	x8, [x19, #400]
	cbz	x8, LBB1_7
; %bb.5:
	ldr	w8, [x19, #448]
	cbnz	w8, LBB1_7
; %bb.6:
	ldr	w8, [x19, #424]
	cbz	w8, LBB1_9
LBB1_7:
	mov	w0, #1                          ; =0x1
LBB1_8:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB1_9:
	mov	x20, #0                         ; =0x0
	add	x24, sp, #16
	mov	w25, #12                        ; =0xc
LBB1_10:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_25 Depth 2
	ldr	w28, [x24, x20, lsl #2]
	ldr	w8, [x19, #432]
	cmp	w28, w8
	b.hs	LBB1_7
; %bb.11:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	x22, [x19, #400]
	mov	x0, x20
	bl	_nl_file_catalog_method
	cbz	x0, LBB1_7
; %bb.12:                               ;   in Loop: Header=BB1_10 Depth=1
	mov	x21, x0
	ldr	x8, [x0, #56]
	cbz	x8, LBB1_7
; %bb.13:                               ;   in Loop: Header=BB1_10 Depth=1
	umaddl	x27, w28, w25, x22
	sub	x8, x8, #1
	ldrh	w9, [x27, #8]
	cmp	x8, x9
	b.ne	LBB1_7
; %bb.14:                               ;   in Loop: Header=BB1_10 Depth=1
	ldrb	w8, [x27, #11]
	cmp	w8, #3
	b.ne	LBB1_7
; %bb.15:                               ;   in Loop: Header=BB1_10 Depth=1
	ldrb	w8, [x27, #10]
	cmp	w8, #10
	b.ne	LBB1_7
; %bb.16:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	w22, [x27]
	bl	_nl_file_catalog_interface
	mov	x2, x0
	mov	x0, x19
	mov	x1, x22
	bl	_text
	cbz	w0, LBB1_7
; %bb.17:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	w1, [x27, #4]
	ldr	x2, [x21]
	mov	x0, x19
	bl	_text
	cbz	w0, LBB1_7
; %bb.18:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	x8, [x19, #408]
	cbz	x8, LBB1_20
; %bb.19:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	x22, [x8, x28, lsl #3]
	b	LBB1_21
LBB1_20:                                ;   in Loop: Header=BB1_10 Depth=1
	mov	x22, #0                         ; =0x0
LBB1_21:                                ;   in Loop: Header=BB1_10 Depth=1
	ldrh	w8, [x27, #8]
	cbz	w8, LBB1_23
; %bb.22:                               ;   in Loop: Header=BB1_10 Depth=1
	cbz	x22, LBB1_7
LBB1_23:                                ;   in Loop: Header=BB1_10 Depth=1
	cbz	w8, LBB1_29
; %bb.24:                               ;   in Loop: Header=BB1_10 Depth=1
	mov	x28, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
LBB1_25:                                ;   Parent Loop BB1_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x21, #48]
	add	x8, x8, x28
	ldr	w9, [x8, #24]
	cbnz	w9, LBB1_7
; %bb.26:                               ;   in Loop: Header=BB1_25 Depth=2
	ldr	x1, [x8, #16]
	add	x0, sp, #16
	add	x2, sp, #72
	add	x3, sp, #88
	bl	_member_type
	cbz	w0, LBB1_7
; %bb.27:                               ;   in Loop: Header=BB1_25 Depth=2
	ldrb	w8, [x22, x26]
	ldrb	w9, [sp, #72]
	cmp	w8, w9
	b.ne	LBB1_7
; %bb.28:                               ;   in Loop: Header=BB1_25 Depth=2
	add	x26, x26, #1
	ldrh	w8, [x27, #8]
	add	x28, x28, #48
	cmp	x26, x8
	b.lo	LBB1_25
	b	LBB1_30
LBB1_29:                                ;   in Loop: Header=BB1_10 Depth=1
	mov	x8, #0                          ; =0x0
LBB1_30:                                ;   in Loop: Header=BB1_10 Depth=1
	ldr	x9, [x21, #48]
	mov	w10, #48                        ; =0x30
	umaddl	x8, w8, w10, x9
	ldr	w9, [x8, #24]
	cmp	w9, #3
	b.ne	LBB1_7
; %bb.31:                               ;   in Loop: Header=BB1_10 Depth=1
	ldr	x1, [x8, #16]
	add	x0, sp, #16
	add	x2, sp, #72
	add	x3, sp, #88
	bl	_member_type
	ldrb	w8, [sp, #72]
	cmp	w0, #0
	ccmp	w8, #10, #0, ne
	b.ne	LBB1_7
; %bb.32:                               ;   in Loop: Header=BB1_10 Depth=1
	add	x20, x20, #1
	cmp	x20, #5
	b.ne	LBB1_10
; %bb.33:
	str	wzr, [sp, #12]
	add	x1, sp, #16
	add	x2, sp, #12
	mov	x0, x19
	mov	x3, #0                          ; =0x0
	bl	_layouts_read
	cbnz	w0, LBB1_8
; %bb.34:
	ldr	x1, [x19, #296]
	cbz	x1, LBB1_7
; %bb.35:
	ldr	w2, [x19, #304]
	cbz	w2, LBB1_7
; %bb.36:
	ldr	w20, [sp, #12]
	add	x0, sp, #88
	bl	_nvm_v2_cursor_init
	add	x0, sp, #88
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_7
; %bb.37:
	ldr	w8, [sp, #84]
	cmp	w8, #1
	b.ne	LBB1_7
; %bb.38:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_7
; %bb.39:
	ldr	w8, [sp, #80]
	cmp	w8, w20
	b.ne	LBB1_7
; %bb.40:
	add	x0, sp, #88
	add	x2, sp, #72
	mov	x1, x20
	bl	_nvm_v2_take
	cbnz	w0, LBB1_7
; %bb.41:
	add	x0, sp, #88
	bl	_nvm_v2_align4
	cbnz	w0, LBB1_7
; %bb.42:
	ldr	w8, [sp, #80]
	cbz	w8, LBB1_54
; %bb.43:
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #72]
	ldp	w11, w12, [sp, #36]
	ldp	w13, w14, [sp, #44]
	ldur	q1, [sp, #52]
	ushll2.2d	v0, v1, #0
	ushll.2d	v1, v1, #0
	mov	w15, #3                         ; =0x3
LBB1_44:                                ; =>This Inner Loop Header: Depth=1
	mov	w16, #0                         ; =0x0
	cmp	x11, x9
	b.eq	LBB1_50
; %bb.45:                               ;   in Loop: Header=BB1_44 Depth=1
	cmp	x12, x9
	b.eq	LBB1_50
; %bb.46:                               ;   in Loop: Header=BB1_44 Depth=1
	cmp	x13, x9
	b.eq	LBB1_50
; %bb.47:                               ;   in Loop: Header=BB1_44 Depth=1
	cmp	x14, x9
	b.ne	LBB1_49
; %bb.48:                               ;   in Loop: Header=BB1_44 Depth=1
	mov	w16, #1                         ; =0x1
	b	LBB1_50
LBB1_49:                                ;   in Loop: Header=BB1_44 Depth=1
	mov	w16, #0                         ; =0x0
	dup.2d	v2, x9
	cmeq.2d	v3, v2, v1
	cmeq.2d	v2, v2, v0
	uzp1.4s	v2, v3, v2
	xtn.4h	v2, v2
	umaxv.4h	h2, v2
	fmov	w17, s2
	tbz	w17, #0, LBB1_53
LBB1_50:                                ;   in Loop: Header=BB1_44 Depth=1
	cmp	x11, x9
	csinc	w16, w16, wzr, ne
	cmp	w16, #0
	csinc	w16, w15, wzr, ne
LBB1_51:                                ;   in Loop: Header=BB1_44 Depth=1
	ldrb	w17, [x10, x9]
	cmp	w17, w16
	b.ne	LBB1_7
; %bb.52:                               ;   in Loop: Header=BB1_44 Depth=1
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB1_44
	b	LBB1_54
LBB1_53:                                ;   in Loop: Header=BB1_44 Depth=1
	mov	w16, #0                         ; =0x0
	b	LBB1_51
LBB1_54:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_7
; %bb.55:
	ldr	w8, [sp, #80]
	ldr	w9, [x19, #272]
	cmp	w8, w9
	b.ne	LBB1_7
; %bb.56:
	cbz	w8, LBB1_84
; %bb.57:
	ldr	x9, [x19, #256]
	cbz	x9, LBB1_7
; %bb.58:
	ldp	x9, x10, [sp, #96]
	sub	x9, x9, x10
	mov	x10, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x10, #43691
	umulh	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB1_7
; %bb.59:
	mov	x21, #0                         ; =0x0
	mov	w22, #24                        ; =0x18
	b	LBB1_61
LBB1_60:                                ;   in Loop: Header=BB1_61 Depth=1
	add	x21, x21, #1
	ldr	w8, [sp, #80]
	cmp	x21, x8
	b.hs	LBB1_84
LBB1_61:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_79 Depth 2
	ldr	x24, [x19, #256]
	add	x0, sp, #88
	add	x1, sp, #70
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_7
; %bb.62:                               ;   in Loop: Header=BB1_61 Depth=1
	add	x0, sp, #88
	add	x1, sp, #68
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_7
; %bb.63:                               ;   in Loop: Header=BB1_61 Depth=1
	madd	x8, x21, x22, x24
	ldrh	w9, [sp, #70]
	ldrh	w10, [x8, #16]
	cmp	w9, w10
	b.ne	LBB1_7
; %bb.64:                               ;   in Loop: Header=BB1_61 Depth=1
	ldrh	w10, [sp, #68]
	cmp	w10, w9
	b.hi	LBB1_7
; %bb.65:                               ;   in Loop: Header=BB1_61 Depth=1
	ldrh	w11, [x8, #4]
	cmp	w10, w11
	b.ne	LBB1_7
; %bb.66:                               ;   in Loop: Header=BB1_61 Depth=1
	ldrb	w10, [x8, #21]
	cmp	w10, #1
	b.hi	LBB1_7
; %bb.67:                               ;   in Loop: Header=BB1_61 Depth=1
	ldp	x11, x12, [sp, #96]
	sub	x11, x11, x12
	cmp	x9, x11, lsr #3
	b.hs	LBB1_7
; %bb.68:                               ;   in Loop: Header=BB1_61 Depth=1
	cbz	w10, LBB1_70
; %bb.69:                               ;   in Loop: Header=BB1_61 Depth=1
	ldrb	w3, [x8, #20]
	b	LBB1_71
LBB1_70:                                ;   in Loop: Header=BB1_61 Depth=1
	mov	w3, #0                          ; =0x0
LBB1_71:                                ;   in Loop: Header=BB1_61 Depth=1
	add	x0, sp, #88
	add	x1, sp, #16
	mov	w2, #0                          ; =0x0
	bl	_descriptor_read
	cbz	w0, LBB1_7
; %bb.72:                               ;   in Loop: Header=BB1_61 Depth=1
	ldr	x8, [x19, #264]
	cbz	x8, LBB1_74
; %bb.73:                               ;   in Loop: Header=BB1_61 Depth=1
	ldr	x24, [x8, x21, lsl #3]
	b	LBB1_75
LBB1_74:                                ;   in Loop: Header=BB1_61 Depth=1
	mov	x24, #0                         ; =0x0
LBB1_75:                                ;   in Loop: Header=BB1_61 Depth=1
	ldrh	w8, [sp, #68]
	cbz	w8, LBB1_77
; %bb.76:                               ;   in Loop: Header=BB1_61 Depth=1
	cbz	x24, LBB1_7
LBB1_77:                                ;   in Loop: Header=BB1_61 Depth=1
	ldrh	w8, [sp, #70]
	cbz	w8, LBB1_60
; %bb.78:                               ;   in Loop: Header=BB1_61 Depth=1
	mov	x25, #0                         ; =0x0
LBB1_79:                                ;   Parent Loop BB1_61 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #68]
	cmp	x25, x8
	b.hs	LBB1_81
; %bb.80:                               ;   in Loop: Header=BB1_79 Depth=2
	ldrb	w3, [x24, x25]
	b	LBB1_82
LBB1_81:                                ;   in Loop: Header=BB1_79 Depth=2
	mov	w3, #-1                         ; =0xffffffff
LBB1_82:                                ;   in Loop: Header=BB1_79 Depth=2
	cmp	x25, x8
	cset	w2, lo
	add	x0, sp, #88
	add	x1, sp, #16
	bl	_descriptor_read
	tbz	w0, #0, LBB1_7
; %bb.83:                               ;   in Loop: Header=BB1_79 Depth=2
	add	x25, x25, #1
	ldrh	w8, [sp, #70]
	cmp	x25, x8
	b.lo	LBB1_79
	b	LBB1_60
LBB1_84:
	ldp	x8, x9, [sp, #96]
	cmp	x9, x8
	b.ne	LBB1_7
; %bb.85:
	mov	w8, #20                         ; =0x14
	umull	x8, w20, w8
	add	x0, x8, #56
	bl	_malloc
	cbz	x0, LBB1_89
; %bb.86:
	mov	x21, x0
	ldp	q0, q1, [sp, #16]
	stp	q0, q1, [x0]
	ldr	q0, [sp, #48]
	str	q0, [x0, #32]
	ldr	w8, [sp, #64]
	stp	w8, w20, [x0, #48]
	str	wzr, [sp, #88]
	add	x1, sp, #16
	add	x2, sp, #88
	add	x3, x0, #56
	mov	x0, x19
	bl	_layouts_read
	cbnz	w0, LBB1_90
; %bb.87:
	ldr	w8, [sp, #88]
	cmp	w8, w20
	b.ne	LBB1_90
; %bb.88:
	mov	w0, #0                          ; =0x0
	str	x21, [x23]
	b	LBB1_8
LBB1_89:
	mov	w0, #3                          ; =0x3
	b	LBB1_8
LBB1_90:
	mov	x0, x21
	bl	_free
	b	LBB1_7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_read
_layouts_read:                          ; @layouts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	ldr	x1, [x0, #312]
	cbz	x1, LBB2_3
; %bb.1:
	ldr	w8, [x0, #320]
	cbz	w8, LBB2_3
; %bb.2:
	mov	x26, x3
	mov	x19, x0
	mov	x25, x2
	add	x0, sp, #56
	mov	x2, x8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB2_5
LBB2_3:
	mov	w0, #1                          ; =0x1
LBB2_4:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB2_5:
	ldr	w8, [sp, #52]
	cmp	w8, #16, lsl #12                ; =65536
	b.ls	LBB2_7
; %bb.6:
	mov	w0, #2                          ; =0x2
	b	LBB2_4
LBB2_7:
	cmp	w8, #8
	b.lo	LBB2_3
; %bb.8:
	ldp	x9, x10, [sp, #64]
	sub	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB2_3
; %bb.9:
	ldr	w10, [x20, #20]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.10:
	mov	x9, x20
	ldr	w10, [x20, #24]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.11:
	ldr	w10, [x9, #28]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.12:
	ldr	w10, [x9, #32]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.13:
	ldr	w10, [x9, #36]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.14:
	ldr	w10, [x9, #40]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.15:
	ldr	w10, [x9, #44]
	cmp	w10, w8
	b.hs	LBB2_3
; %bb.16:
	ldr	w9, [x9, #48]
	cmp	w9, w8
	b.hs	LBB2_3
; %bb.17:
	mov	x21, #0                         ; =0x0
	str	xzr, [sp, #16]                  ; 8-byte Folded Spill
	str	wzr, [sp, #12]                  ; 4-byte Folded Spill
LBB2_18:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_42 Depth 2
	add	x0, sp, #56
	add	x1, sp, #51
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.19:                               ;   in Loop: Header=BB2_18 Depth=1
	add	x0, sp, #56
	add	x1, sp, #50
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.20:                               ;   in Loop: Header=BB2_18 Depth=1
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_3
; %bb.21:                               ;   in Loop: Header=BB2_18 Depth=1
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.22:                               ;   in Loop: Header=BB2_18 Depth=1
	ldrb	w8, [sp, #50]
	cbnz	w8, LBB2_3
; %bb.23:                               ;   in Loop: Header=BB2_18 Depth=1
	ldrb	w23, [sp, #51]
	cmp	w23, #3
	b.hi	LBB2_3
; %bb.24:                               ;   in Loop: Header=BB2_18 Depth=1
	ldr	w8, [sp, #44]
	cmn	w8, #1
	b.eq	LBB2_26
; %bb.25:                               ;   in Loop: Header=BB2_18 Depth=1
	ldr	w9, [x19, #248]
	cmp	w8, w9
	b.hs	LBB2_3
LBB2_26:                                ;   in Loop: Header=BB2_18 Depth=1
	ldrh	w24, [sp, #48]
	ldp	x8, x9, [sp, #64]
	sub	x8, x8, x9
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43691
	umulh	x8, x8, x9
	cmp	x24, x8, lsr #3
	b.hi	LBB2_3
; %bb.27:                               ;   in Loop: Header=BB2_18 Depth=1
	mov	x0, x20
	mov	x1, x21
	bl	_catalog_at
	mov	x22, x0
	cmp	w23, #3
	b.eq	LBB2_32
; %bb.28:                               ;   in Loop: Header=BB2_18 Depth=1
	cmp	w23, #2
	b.eq	LBB2_31
; %bb.29:                               ;   in Loop: Header=BB2_18 Depth=1
	cbnz	w23, LBB2_33
; %bb.30:                               ;   in Loop: Header=BB2_18 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	add	w8, w8, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB2_34
LBB2_31:                                ;   in Loop: Header=BB2_18 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	add	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_34
LBB2_32:                                ;   in Loop: Header=BB2_18 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
LBB2_33:                                ;   in Loop: Header=BB2_18 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
LBB2_34:                                ;   in Loop: Header=BB2_18 Depth=1
	cmn	w22, #1
	b.eq	LBB2_39
; %bb.35:                               ;   in Loop: Header=BB2_18 Depth=1
	mov	w24, w22
	mov	x0, x24
	bl	_nl_file_catalog_type
	cbz	x0, LBB2_3
; %bb.36:                               ;   in Loop: Header=BB2_18 Depth=1
	mov	x23, x0
	ldrb	w27, [sp, #51]
	mov	x0, x24
	bl	_nl_file_catalog_type
	ldr	w8, [x0, #16]
	cmp	w8, #2
	csel	w8, w8, wzr, eq
	cmp	w27, w8
	b.ne	LBB2_3
; %bb.37:                               ;   in Loop: Header=BB2_18 Depth=1
	ldrh	w24, [sp, #48]
	ldr	x8, [x23, #32]
	cmp	x8, x24
	b.ne	LBB2_3
; %bb.38:                               ;   in Loop: Header=BB2_18 Depth=1
	ldr	w1, [sp, #44]
	ldr	x2, [x23]
	mov	x0, x19
	bl	_text
	cbnz	w0, LBB2_40
	b	LBB2_3
LBB2_39:                                ;   in Loop: Header=BB2_18 Depth=1
	mov	x23, #0                         ; =0x0
                                        ; kill: def $w24 killed $w24 killed $x24 def $x24
LBB2_40:                                ;   in Loop: Header=BB2_18 Depth=1
	cbz	w24, LBB2_62
; %bb.41:                               ;   in Loop: Header=BB2_18 Depth=1
	mov	x24, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
LBB2_42:                                ;   Parent Loop BB2_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #56
	add	x1, sp, #43
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.43:                               ;   in Loop: Header=BB2_42 Depth=2
	add	x0, sp, #56
	add	x1, sp, #42
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.44:                               ;   in Loop: Header=BB2_42 Depth=2
	add	x0, sp, #56
	add	x1, sp, #41
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.45:                               ;   in Loop: Header=BB2_42 Depth=2
	add	x0, sp, #56
	add	x1, sp, #40
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.46:                               ;   in Loop: Header=BB2_42 Depth=2
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.47:                               ;   in Loop: Header=BB2_42 Depth=2
	add	x0, sp, #56
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.48:                               ;   in Loop: Header=BB2_42 Depth=2
	ldrb	w8, [sp, #43]
	cmp	w8, #15
	b.hi	LBB2_3
; %bb.49:                               ;   in Loop: Header=BB2_42 Depth=2
	ldrb	w8, [sp, #42]
	cbnz	w8, LBB2_3
; %bb.50:                               ;   in Loop: Header=BB2_42 Depth=2
	ldrb	w8, [sp, #41]
	cbnz	w8, LBB2_3
; %bb.51:                               ;   in Loop: Header=BB2_42 Depth=2
	ldrb	w8, [sp, #40]
	cbnz	w8, LBB2_3
; %bb.52:                               ;   in Loop: Header=BB2_42 Depth=2
	ldr	w8, [sp, #32]
	cmn	w8, #1
	b.eq	LBB2_54
; %bb.53:                               ;   in Loop: Header=BB2_42 Depth=2
	ldr	w9, [x19, #248]
	cmp	w8, w9
	b.hs	LBB2_3
LBB2_54:                                ;   in Loop: Header=BB2_42 Depth=2
	ldr	w8, [sp, #36]
	cmn	w8, #1
	b.eq	LBB2_56
; %bb.55:                               ;   in Loop: Header=BB2_42 Depth=2
	cmp	x21, x8
	b.ls	LBB2_3
LBB2_56:                                ;   in Loop: Header=BB2_42 Depth=2
	cbz	x23, LBB2_61
; %bb.57:                               ;   in Loop: Header=BB2_42 Depth=2
	ldr	x27, [x23, #24]
	add	x8, x27, x24
	ldr	x1, [x8, #16]
	add	x2, sp, #31
	add	x3, sp, #24
	mov	x0, x20
	bl	_member_type
	cbz	w0, LBB2_3
; %bb.58:                               ;   in Loop: Header=BB2_42 Depth=2
	ldrb	w8, [sp, #43]
	ldrb	w9, [sp, #31]
	cmp	w8, w9
	b.ne	LBB2_3
; %bb.59:                               ;   in Loop: Header=BB2_42 Depth=2
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #24]
	cmp	w8, w9
	b.ne	LBB2_3
; %bb.60:                               ;   in Loop: Header=BB2_42 Depth=2
	ldr	w1, [sp, #32]
	ldr	x2, [x27, x24]
	mov	x0, x19
	bl	_text
	cbz	w0, LBB2_3
LBB2_61:                                ;   in Loop: Header=BB2_42 Depth=2
	add	x28, x28, #1
	ldrh	w8, [sp, #48]
	add	x24, x24, #32
	cmp	x28, x8
	b.lo	LBB2_42
LBB2_62:                                ;   in Loop: Header=BB2_18 Depth=1
	cbz	x26, LBB2_64
; %bb.63:                               ;   in Loop: Header=BB2_18 Depth=1
	mov	w8, #20                         ; =0x14
	madd	x23, x21, x8, x26
	ldrb	w24, [sp, #51]
	cmp	w22, #3
	ccmp	w22, #0, #4, ne
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
	cmn	w22, #1
	csel	w27, wzr, w8, eq
	mov	x0, x22
	bl	_category
	stp	w21, w22, [x23]
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [x23, #8]
	strb	w24, [x23, #12]
	strb	w27, [x23, #13]
	strh	wzr, [x23, #14]
	str	w0, [x23, #16]
LBB2_64:                                ;   in Loop: Header=BB2_18 Depth=1
	add	x21, x21, #1
	ldr	w8, [sp, #52]
	cmp	x21, x8
	b.lo	LBB2_18
; %bb.65:
	ldp	x9, x10, [sp, #64]
	cmp	x10, x9
	b.ne	LBB2_3
; %bb.66:
	ldr	w9, [x19, #468]
	ldr	w10, [sp, #20]                  ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB2_3
; %bb.67:
	ldr	w9, [x19, #472]
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB2_3
; %bb.68:
	ldr	w9, [x19, #476]
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB2_3
; %bb.69:
	mov	w0, #0                          ; =0x0
	str	w8, [x25]
	b	LBB2_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_plan_free ; -- Begin function nvm_file_nominal_plan_free
	.globl	_nvm_file_nominal_plan_free
	.p2align	2
_nvm_file_nominal_plan_free:            ; @nvm_file_nominal_plan_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_layout_count ; -- Begin function nvm_file_nominal_layout_count
	.globl	_nvm_file_nominal_layout_count
	.p2align	2
_nvm_file_nominal_layout_count:         ; @nvm_file_nominal_layout_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_2
; %bb.1:
	ldr	w0, [x0, #52]
LBB4_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_layout ; -- Begin function nvm_file_nominal_layout
	.globl	_nvm_file_nominal_layout
	.p2align	2
_nvm_file_nominal_layout:               ; @nvm_file_nominal_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB5_4
; %bb.1:
	cbz	x2, LBB5_4
; %bb.2:
	ldr	w9, [x8, #52]
	cmp	w1, w9
	b.hs	LBB5_5
; %bb.3:
	mov	w9, #20                         ; =0x14
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #56]
	ldr	w8, [x8, #72]
	str	w8, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB5_4:
	ret
LBB5_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_type  ; -- Begin function nvm_file_nominal_type
	.globl	_nvm_file_nominal_type
	.p2align	2
_nvm_file_nominal_type:                 ; @nvm_file_nominal_type
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB6_5
; %bb.1:
	cmp	w1, #7
	b.hi	LBB6_5
; %bb.2:
	cbz	x2, LBB6_6
; %bb.3:
	add	x8, x0, w1, uxtw #2
	ldr	w8, [x8, #20]
	ldr	w9, [x0, #52]
	cmp	w8, w9
	b.hs	LBB6_6
; %bb.4:
	mov	w9, #20                         ; =0x14
	umaddl	x8, w8, w9, x0
	ldur	q0, [x8, #56]
	ldr	w8, [x8, #72]
	str	w8, [x2, #16]
	str	q0, [x2]
	mov	w8, #1                          ; =0x1
LBB6_5:
	mov	x0, x8
	ret
LBB6_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_source ; -- Begin function nvm_file_nominal_source
	.globl	_nvm_file_nominal_source
	.p2align	2
_nvm_file_nominal_source:               ; @nvm_file_nominal_source
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	tst	w1, #0xfffffffd
	b.ne	LBB7_10
; %bb.1:
	cbz	x8, LBB7_10
; %bb.2:
	cbz	x3, LBB7_10
; %bb.3:
	ldr	w9, [x8, #52]
	cbz	w9, LBB7_9
; %bb.4:
	add	x8, x8, #68
	b	LBB7_6
LBB7_5:                                 ;   in Loop: Header=BB7_6 Depth=1
	add	x8, x8, #20
	subs	x9, x9, #1
	b.eq	LBB7_9
LBB7_6:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x8]
	cmp	w10, w1
	b.ne	LBB7_5
; %bb.7:                                ;   in Loop: Header=BB7_6 Depth=1
	ldur	w10, [x8, #-4]
	cmp	w10, w2
	b.ne	LBB7_5
; %bb.8:
	ldur	q0, [x8, #-12]
	ldr	w8, [x8, #4]
	str	w8, [x3, #16]
	str	q0, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB7_9:
	mov	w0, #0                          ; =0x0
LBB7_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_import ; -- Begin function nvm_file_nominal_import
	.globl	_nvm_file_nominal_import
	.p2align	2
_nvm_file_nominal_import:               ; @nvm_file_nominal_import
	.cfi_startproc
; %bb.0:
	cmp	x0, #0
	ccmp	x2, #0, #4, ne
	ccmp	w1, #5, #2, ne
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB8_2
; %bb.1:
	ldr	w9, [x0, w1, uxtw #2]
	str	w9, [x2]
LBB8_2:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function text
_text:                                  ; @text
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB9_6
; %bb.1:
	ldr	x8, [x0, #232]
	cbz	x8, LBB9_6
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x21, [x0, #240]
	cbz	x21, LBB9_7
; %bb.3:
	ldr	x19, [x8, w1, uxtw #3]
	cbz	x19, LBB9_7
; %bb.4:
	mov	x20, x2
	mov	x0, x2
	mov	x22, x1
	bl	_strlen
	ldr	w8, [x21, w22, uxtw #2]
	cmp	x0, x8
	b.ne	LBB9_7
; %bb.5:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	b	LBB9_8
LBB9_6:
	mov	w0, #0                          ; =0x0
	ret
LBB9_7:
	mov	w0, #0                          ; =0x0
LBB9_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function member_type
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x3]
	cbz	x1, LBB10_21
; %bb.1:
	mov	x20, x1
	mov	x22, x0
	mov	x21, x3
Lloh0:
	adrp	x1, l_.str@PAGE
Lloh1:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_22
; %bb.2:
Lloh2:
	adrp	x1, l_.str.1@PAGE
Lloh3:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_23
; %bb.3:
Lloh4:
	adrp	x1, l_.str.2@PAGE
Lloh5:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_24
; %bb.4:
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.5:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_25
; %bb.6:
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.7:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_26
; %bb.8:
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.9:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_27
; %bb.10:
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.11:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_28
; %bb.12:
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.13:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_29
; %bb.14:
	mov	w0, #5                          ; =0x5
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.15:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_30
; %bb.16:
	mov	w0, #6                          ; =0x6
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.17:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_31
; %bb.18:
	mov	w0, #7                          ; =0x7
	bl	_nl_file_catalog_type
	cbz	x0, LBB10_35
; %bb.19:
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_32
; %bb.20:
	mov	w0, #0                          ; =0x0
	b	LBB10_35
LBB10_21:
	strb	wzr, [x19]
	b	LBB10_34
LBB10_22:
	mov	w0, #1                          ; =0x1
	strb	w0, [x19]
	b	LBB10_35
LBB10_23:
	mov	w8, #4                          ; =0x4
	strb	w8, [x19]
	b	LBB10_34
LBB10_24:
	mov	w8, #5                          ; =0x5
	strb	w8, [x19]
	b	LBB10_34
LBB10_25:
	mov	x20, #0                         ; =0x0
	b	LBB10_33
LBB10_26:
	mov	w20, #1                         ; =0x1
	b	LBB10_33
LBB10_27:
	mov	w20, #2                         ; =0x2
	b	LBB10_33
LBB10_28:
	mov	w20, #3                         ; =0x3
	b	LBB10_33
LBB10_29:
	mov	w20, #4                         ; =0x4
	b	LBB10_33
LBB10_30:
	mov	w20, #5                         ; =0x5
	b	LBB10_33
LBB10_31:
	mov	w20, #6                         ; =0x6
	b	LBB10_33
LBB10_32:
	mov	w20, #7                         ; =0x7
LBB10_33:
	mov	x0, x20
	bl	_nl_file_catalog_type
	ldr	w8, [x0, #16]
	mov	w9, #8                          ; =0x8
	mov	w10, #10                        ; =0xa
	cmp	w8, #2
	csel	w8, w10, w9, eq
	strb	w8, [x19]
	add	x8, x22, x20, lsl #2
	ldr	w8, [x8, #20]
	str	w8, [x21]
LBB10_34:
	mov	w0, #1                          ; =0x1
LBB10_35:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_at
_catalog_at:                            ; @catalog_at
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #20]
	cmp	w8, w1
	b.ne	LBB11_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB11_2:
	ldr	w8, [x0, #24]
	cmp	w8, w1
	b.ne	LBB11_4
; %bb.3:
	mov	w0, #1                          ; =0x1
	ret
LBB11_4:
	ldr	w8, [x0, #28]
	cmp	w8, w1
	b.ne	LBB11_6
; %bb.5:
	mov	w0, #2                          ; =0x2
	ret
LBB11_6:
	ldr	w8, [x0, #32]
	cmp	w8, w1
	b.ne	LBB11_8
; %bb.7:
	mov	w0, #3                          ; =0x3
	ret
LBB11_8:
	ldr	w8, [x0, #36]
	cmp	w8, w1
	b.ne	LBB11_10
; %bb.9:
	mov	w0, #4                          ; =0x4
	ret
LBB11_10:
	ldr	w8, [x0, #40]
	cmp	w8, w1
	b.ne	LBB11_12
; %bb.11:
	mov	w0, #5                          ; =0x5
	ret
LBB11_12:
	ldr	w8, [x0, #44]
	cmp	w8, w1
	b.ne	LBB11_14
; %bb.13:
	mov	w0, #6                          ; =0x6
	ret
LBB11_14:
	ldr	w8, [x0, #48]
	cmp	w8, w1
	mov	w8, #7                          ; =0x7
	csinv	w0, w8, wzr, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function category
_category:                              ; @category
	.cfi_startproc
; %bb.0:
	cmn	w0, #1
	b.eq	LBB12_5
; %bb.1:
	cmp	w0, #3
	b.eq	LBB12_4
; %bb.2:
	cbnz	w0, LBB12_6
; %bb.3:
	mov	w0, #1                          ; =0x1
	ret
LBB12_4:
	mov	w0, #2                          ; =0x2
	ret
LBB12_5:
	mov	w0, #0                          ; =0x0
	ret
LBB12_6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w0, w0
	bl	_nl_file_catalog_type
	ldr	w8, [x0, #16]
	cmp	w8, #2
	mov	w8, #3                          ; =0x3
	cinc	w0, w8, ne
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor_read
_descriptor_read:                       ; @descriptor_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x21, x2
	mov	x19, x1
	mov	x22, x0
	add	x1, sp, #15
	bl	_nvm_v2_u8
	cbnz	w0, LBB13_3
; %bb.1:
	add	x1, sp, #14
	mov	x0, x22
	bl	_nvm_v2_u8
	cbnz	w0, LBB13_3
; %bb.2:
	add	x1, sp, #12
	mov	x0, x22
	bl	_nvm_v2_u16
	cbz	w0, LBB13_5
LBB13_3:
	mov	w0, #0                          ; =0x0
LBB13_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB13_5:
	add	x1, sp, #8
	mov	x0, x22
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [sp, #14]
	cmp	w9, #0
	cset	w10, eq
	cmp	w9, #3
	cset	w11, lo
	cmp	w21, #0
	csel	w10, w11, w10, ne
	cbnz	w8, LBB13_4
; %bb.6:
	ldrh	w8, [sp, #12]
	cbnz	w8, LBB13_4
; %bb.7:
	ldrb	w21, [sp, #15]
	cmp	w21, #15
	b.hi	LBB13_4
; %bb.8:
	cbz	w10, LBB13_4
; %bb.9:
	tbnz	w20, #31, LBB13_11
; %bb.10:
	cmp	w20, w21
	b.ne	LBB13_3
LBB13_11:
	ldr	w1, [sp, #8]
	cmn	w1, #1
	b.eq	LBB13_15
; %bb.12:
	mov	x0, x19
	bl	_catalog_at
	cmn	w0, #1
	b.eq	LBB13_3
; %bb.13:
	mov	x19, x0
	mov	w0, w0
	bl	_nl_file_catalog_type
	ldr	w8, [x0, #16]
	mov	w9, #8                          ; =0x8
	mov	w10, #10                        ; =0xa
	cmp	w8, #2
	csel	w8, w10, w9, eq
	cmp	w21, w8
	b.ne	LBB13_3
; %bb.14:
	ldrb	w9, [sp, #14]
	cmp	w19, #0
	cset	w8, eq
	b	LBB13_16
LBB13_15:
	mov	w8, #0                          ; =0x0
LBB13_16:
	cmp	w9, #0
	csinc	w0, w8, wzr, ne
	b	LBB13_4
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

.subsections_via_symbols
