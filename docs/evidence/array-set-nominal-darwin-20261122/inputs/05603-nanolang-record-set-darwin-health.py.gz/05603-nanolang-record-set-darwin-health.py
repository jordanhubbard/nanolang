import time,os,json,subprocess,shutil
from pathlib import Path
samples=[]
for unused in range(3):
 a=time.process_time();b=time.monotonic()
 while time.process_time()-a<1.05:pass
 cpu=time.process_time()-a;wall=time.monotonic()-b;samples.append(dict(cpu=cpu,wall=wall,ratio=cpu/wall))
p=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
matching=[line for line in p.splitlines() if any(name in line for name in ['bootstrap_nanoisa.py','ci_qualify_as246.py','-m unittest tests.test_source_snapshots','test_nanolang_translator_affine_state']) and 'ps -axo' not in line]
record=dict(samples=samples,admitted=all(x['ratio']>=.75 and x['cpu']>=1 for x in samples) and not matching,uptime=subprocess.check_output(['uptime'],text=True).strip(),cpus=os.cpu_count(),free_bytes=shutil.disk_usage('/Users/jkh/.worktrees/nanolang').free,matching_processes=matching)
Path('/tmp/nanolang-record-set-darwin-health.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
