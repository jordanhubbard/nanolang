	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_websocket_from_module      ; -- Begin function nvm_websocket_from_module
	.p2align	2
_nvm_websocket_from_module:             ; @nvm_websocket_from_module
	.cfi_startproc
; %bb.0:
Lloh0:
	adrp	x2, _websocket_codec@PAGE
Lloh1:
	add	x2, x2, _websocket_codec@PAGEOFF
	b	_nvm_private_from_module
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_to_module        ; -- Begin function nvm_websocket_to_module
	.p2align	2
_nvm_websocket_to_module:               ; @nvm_websocket_to_module
	.cfi_startproc
; %bb.0:
Lloh2:
	adrp	x2, _websocket_codec@PAGE
Lloh3:
	add	x2, x2, _websocket_codec@PAGEOFF
	b	_nvm_private_to_module
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_serialize        ; -- Begin function nvm_websocket_serialize
	.p2align	2
_nvm_websocket_serialize:               ; @nvm_websocket_serialize
	.cfi_startproc
; %bb.0:
Lloh4:
	adrp	x4, _websocket_codec@PAGE
Lloh5:
	add	x4, x4, _websocket_codec@PAGEOFF
	b	_nvm_private_serialize
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_websocket_deserialize      ; -- Begin function nvm_websocket_deserialize
	.p2align	2
_nvm_websocket_deserialize:             ; @nvm_websocket_deserialize
	.cfi_startproc
; %bb.0:
Lloh6:
	adrp	x3, _websocket_codec@PAGE
Lloh7:
	add	x3, x3, _websocket_codec@PAGEOFF
	b	_nvm_private_deserialize
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function websocket_module
_websocket_module:                      ; @websocket_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	str	xzr, [sp, #8]
	add	x1, sp, #8
	bl	_nvm_websocket_nominal_plan
	mov	x19, x0
	ldr	x0, [sp, #8]
	bl	_nvm_websocket_nominal_plan_free
	mov	w8, #8                          ; =0x8
	mov	w9, #13                         ; =0xd
	cmp	w19, #2
	csel	w8, w9, w8, eq
	mov	w9, #1                          ; =0x1
	cmp	w19, #3
	csel	w8, w8, w9, ne
	cmp	w19, #0
	csel	w0, w19, w8, eq
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function websocket_wire
_websocket_wire:                        ; @websocket_wire
	.cfi_startproc
; %bb.0:
Lloh8:
	adrp	x3, _websocket_module@PAGE
Lloh9:
	add	x3, x3, _websocket_module@PAGEOFF
	mov	w1, #4                          ; =0x4
	mov	w2, #7                          ; =0x7
	b	_nvm_private_nominal_wire
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__const
	.p2align	3, 0x0                          ; @websocket_codec
_websocket_codec:
	.quad	_websocket_module
	.quad	_websocket_wire
	.long	104                             ; 0x68
	.space	4

.subsections_via_symbols
