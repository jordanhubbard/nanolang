#define _GNU_SOURCE
#include "collections.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

NANO_EXPORT_ARRAY_ABI(nl_hm_keys);
NANO_EXPORT_ARRAY_ABI(nl_hm_values);
NANO_EXPORT_ARRAY_ABI(nl_set_values);

/* ============================ StringBuilder ============================ */

typedef struct {
    char *buf;
    int64_t len;
    int64_t cap;
} NLStringBuilder;

static NLStringBuilder *sb_alloc(int64_t cap) {
    if (cap < 16) cap = 16;
    NLStringBuilder *sb = (NLStringBuilder*)calloc(1, sizeof(NLStringBuilder));
    if (!sb) return NULL;
    sb->buf = (char*)malloc((size_t)cap);
    if (!sb->buf) {
        free(sb);
        return NULL;
    }
    sb->buf[0] = '\0';
    sb->len = 0;
    sb->cap = cap;
    return sb;
}

static void sb_ensure(NLStringBuilder *sb, int64_t extra) {
    assert(sb);
    if (extra < 0) return;
    int64_t need = sb->len + extra + 1;
    if (need <= sb->cap) return;
    int64_t new_cap = sb->cap;
    while (new_cap < need) {
        if (new_cap > INT64_MAX / 2) {
            new_cap = need;
            break;
        }
        new_cap *= 2;
    }
    char *nb = (char*)realloc(sb->buf, (size_t)new_cap);
    if (!nb) {
        fprintf(stderr, "Error: Out of memory growing StringBuilder\n");
        exit(1);
    }
    sb->buf = nb;
    sb->cap = new_cap;
}

void* nl_sb_new(void) {
    return (void*)sb_alloc(256);
}

void* nl_sb_with_capacity(int64_t capacity) {
    return (void*)sb_alloc(capacity);
}

void nl_sb_append(void* sb_ptr, const char* text) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb || !text) return;
    size_t tlen = strnlen(text, 1024ULL * 1024ULL);
    sb_ensure(sb, (int64_t)tlen);
    memcpy(sb->buf + sb->len, text, tlen);
    sb->len += (int64_t)tlen;
    sb->buf[sb->len] = '\0';
}

void nl_sb_append_char(void* sb_ptr, int64_t ch) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb) return;
    sb_ensure(sb, 1);
    sb->buf[sb->len++] = (char)ch;
    sb->buf[sb->len] = '\0';
}

void nl_sb_clear(void* sb_ptr) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb) return;
    sb->len = 0;
    if (sb->buf) sb->buf[0] = '\0';
}

int64_t nl_sb_length(void* sb_ptr) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb) return 0;
    return sb->len;
}

int64_t nl_sb_capacity(void* sb_ptr) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb) return 0;
    return sb->cap;
}

const char* nl_sb_to_string(void* sb_ptr) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb || !sb->buf) return strdup("");
    char *out = strdup(sb->buf);
    if (!out) out = strdup("");
    return out;
}

void nl_sb_free(void* sb_ptr) {
    NLStringBuilder *sb = (NLStringBuilder*)sb_ptr;
    if (!sb) return;
    free(sb->buf);
    free(sb);
}

/* I keep public collection handles separate from allocation addresses. I never
 * recycle an identity within this loaded provider. My registry checks kind and
 * liveness before accessing payloads; exhaustion refuses new publication.
 * Callers serialize operations on the same handle, including free and borrowed
 * string reads. Independent handles may be used by independent threads. */
typedef enum { COLLECTION_MAP, COLLECTION_SET } CollectionKind;
typedef struct CollectionHandle {
    uintptr_t identity;
    CollectionKind kind;
    void *payload;
    struct CollectionHandle *next;
} CollectionHandle;
static CollectionHandle *collection_handles;
static uintptr_t collection_next_identity = 1;
static pthread_mutex_t collection_handles_lock = PTHREAD_MUTEX_INITIALIZER;

static void collection_lock(void) {
    if (pthread_mutex_lock(&collection_handles_lock)) abort();
}
static void collection_unlock(void) {
    if (pthread_mutex_unlock(&collection_handles_lock)) abort();
}
static void *collection_publish(void *payload, CollectionKind kind) {
    if (!payload) return NULL;
    collection_lock();
    uintptr_t identity = collection_next_identity;
    if (!identity || (uintptr_t)(void *)identity != identity) {
        collection_unlock(); return NULL;
    }
    CollectionHandle *entry = calloc(1, sizeof *entry);
    if (!entry) { collection_unlock(); return NULL; }
    entry->identity = identity; entry->kind = kind; entry->payload = payload;
    entry->next = collection_handles; collection_handles = entry;
    collection_next_identity = identity == UINTPTR_MAX ? 0 : identity + 1;
    collection_unlock();
    return (void *)identity;
}
static void *collection_lookup(void *identity, CollectionKind kind, bool retire) {
    if (!identity) return NULL;
    collection_lock();
    CollectionHandle **link = &collection_handles;
    while (*link) {
        CollectionHandle *entry = *link;
        if (entry->identity == (uintptr_t)identity && entry->kind == kind) {
            void *payload = entry->payload;
            if (retire) { *link = entry->next; free(entry); }
            collection_unlock(); return payload;
        }
        link = &entry->next;
    }
    collection_unlock(); return NULL;
}

/* ============================ HashMap<string,string> ============================ */

typedef struct {
    char *key;     /* NULL = empty */
    char *value;   /* Owned */
    bool tombstone;
} HMEntry;

typedef struct {
    HMEntry *entries;
    int64_t capacity;
    int64_t size;
    int64_t tombstones;
} NLHashMap;

static uint64_t fnv1a(const char *s) {
    uint64_t h = 1469598103934665603ULL;
    for (const unsigned char *p = (const unsigned char*)s; *p; p++) {
        h ^= (uint64_t)(*p);
        h *= 1099511628211ULL;
    }
    return h;
}

static NLHashMap* hm_alloc(int64_t capacity) {
    if (capacity < 16) capacity = 16;
    /* round up to power of 2 */
    int64_t cap = 1;
    while (cap < capacity) cap <<= 1;

    NLHashMap *hm = (NLHashMap*)calloc(1, sizeof(NLHashMap));
    if (!hm) return NULL;
    hm->entries = (HMEntry*)calloc((size_t)cap, sizeof(HMEntry));
    if (!hm->entries) {
        free(hm);
        return NULL;
    }
    hm->capacity = cap;
    hm->size = 0;
    hm->tombstones = 0;
    return hm;
}

static void hm_entry_free(HMEntry *e) {
    if (!e) return;
    free(e->key);
    free(e->value);
    e->key = NULL;
    e->value = NULL;
    e->tombstone = false;
}

static void hm_resize(NLHashMap *hm, int64_t new_cap) {
    NLHashMap *next = hm_alloc(new_cap);
    if (!next) {
        fprintf(stderr, "Error: Out of memory resizing HashMap\n");
        exit(1);
    }

    for (int64_t i = 0; i < hm->capacity; i++) {
        HMEntry *e = &hm->entries[i];
        if (e->key && !e->tombstone) {
            /* Re-insert */
            uint64_t h = fnv1a(e->key);
            int64_t mask = next->capacity - 1;
            int64_t idx = (int64_t)(h & (uint64_t)mask);
            while (true) {
                HMEntry *d = &next->entries[idx];
                if (!d->key) {
                    d->key = e->key;
                    d->value = e->value;
                    d->tombstone = false;
                    next->size++;
                    break;
                }
                idx = (idx + 1) & mask;
            }
            e->key = NULL;
            e->value = NULL;
        }
    }

    free(hm->entries);
    hm->entries = next->entries;
    hm->capacity = next->capacity;
    hm->size = next->size;
    hm->tombstones = 0;
    free(next);
}

static HMEntry* hm_find_slot(NLHashMap *hm, const char *key, bool *found_out) {
    if (found_out) *found_out = false;
    if (!hm || !key) return NULL;
    if ((hm->size + hm->tombstones) * 10 >= hm->capacity * 7) {
        hm_resize(hm, hm->capacity * 2);
    }

    uint64_t h = fnv1a(key);
    int64_t mask = hm->capacity - 1;
    int64_t idx = (int64_t)(h & (uint64_t)mask);
    HMEntry *first_tomb = NULL;

    while (true) {
        HMEntry *e = &hm->entries[idx];
        if (!e->key) {
            if (first_tomb) return first_tomb;
            return e;
        }
        if (e->tombstone) {
            if (!first_tomb) first_tomb = e;
        } else if (strcmp(e->key, key) == 0) {
            if (found_out) *found_out = true;
            return e;
        }
        idx = (idx + 1) & mask;
    }
}

/* I mark only my independently copied collection snapshots. My marker does
 * not destroy strings during ordinary C gc_release: existing C callers retain
 * their manual element-cleanup contract. Foreign consumers use the companion
 * after copying every element, while the result is uniquely owned. */
static void collection_snapshot_marker(void *value) { (void)value; }
static DynArray *collection_snapshot_new(void) {
    DynArray *result = dyn_array_new(ELEM_STRING);
    if (result) gc_get_header(result)->finalizer = collection_snapshot_marker;
    return result;
}
static bool collection_snapshot_release(DynArray *result) {
    if (!result || !gc_is_managed(result)) return false;
    GCHeader *header = gc_get_header(result);
    if (header->type != GC_TYPE_ARRAY || header->ref_count != 1 ||
        header->finalizer != collection_snapshot_marker ||
        !dyn_array_has_storage(result, ELEM_STRING, sizeof(char *), 0)) return false;
    for (int64_t i = 0; i < result->length; i++) {
        free(((char **)result->data)[i]);
        ((char **)result->data)[i] = NULL;
    }
    result->length = 0;
    gc_release(result);
    return true;
}
bool nl_hm_keys__nano_array_release_v1(void *result) {
    return collection_snapshot_release(result);
}
bool nl_hm_values__nano_array_release_v1(void *result) {
    return collection_snapshot_release(result);
}
bool nl_set_values__nano_array_release_v1(void *result) {
    return collection_snapshot_release(result);
}

void* nl_hm_new(void) {
    NLHashMap *hm = hm_alloc(64);
    void *identity = collection_publish(hm, COLLECTION_MAP);
    if (!identity && hm) { free(hm->entries); free(hm); }
    return identity;
}

void nl_hm_put(void* hm_ptr, const char* key, const char* value) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm || !key) return;
    if (!value) value = "";

    bool found = false;
    HMEntry *e = hm_find_slot(hm, key, &found);
    if (!e) return;

    if (found) {
        free(e->value);
        e->value = strdup(value);
        if (!e->value) e->value = strdup("");
        return;
    }

    if (e->tombstone) {
        hm->tombstones--;
        e->tombstone = false;
    }

    e->key = strdup(key);
    e->value = strdup(value);
    if (!e->key) e->key = strdup("");
    if (!e->value) e->value = strdup("");
    hm->size++;
}

bool nl_hm_has(void* hm_ptr, const char* key) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm || !key) return false;
    bool found = false;
    (void)hm_find_slot(hm, key, &found);
    return found;
}

const char* nl_hm_get(void* hm_ptr, const char* key) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm || !key) return "";
    bool found = false;
    HMEntry *e = hm_find_slot(hm, key, &found);
    if (!found || !e || !e->value) return "";
    return e->value;
}

int64_t nl_hm_size(void* hm_ptr) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm) return 0;
    return hm->size;
}

DynArray* nl_hm_keys(void* hm_ptr) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm) return collection_snapshot_new();
    DynArray *out = collection_snapshot_new();
    if (!out) return NULL;
    for (int64_t i = 0; i < hm->capacity; i++) {
        HMEntry *e = &hm->entries[i];
        if (e->key && !e->tombstone) {
            char *k = strdup(e->key);
            if (!k) { (void)collection_snapshot_release(out); return NULL; }
            dyn_array_push_string(out, k);
        }
    }
    return out;
}

DynArray* nl_hm_values(void* hm_ptr) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm) return collection_snapshot_new();
    DynArray *out = collection_snapshot_new();
    if (!out) return NULL;
    for (int64_t i = 0; i < hm->capacity; i++) {
        HMEntry *e = &hm->entries[i];
        if (e->key && !e->tombstone) {
            char *v = strdup(e->value ? e->value : "");
            if (!v) { (void)collection_snapshot_release(out); return NULL; }
            dyn_array_push_string(out, v);
        }
    }
    return out;
}

void nl_hm_remove(void* hm_ptr, const char* key) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm || !key) return;
    bool found = false;
    HMEntry *e = hm_find_slot(hm, key, &found);
    if (!found || !e) return;
    free(e->key);
    free(e->value);
    e->key = (char*)"__tomb"; /* non-NULL sentinel */
    e->value = NULL;
    e->tombstone = true;
    hm->size--;
    hm->tombstones++;
}

void nl_hm_clear(void* hm_ptr) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, false);
    if (!hm) return;
    for (int64_t i = 0; i < hm->capacity; i++) {
        HMEntry *e = &hm->entries[i];
        if (e->key && !e->tombstone) {
            hm_entry_free(e);
        } else if (e->tombstone) {
            e->key = NULL;
            e->value = NULL;
            e->tombstone = false;
        }
    }
    hm->size = 0;
    hm->tombstones = 0;
}

void nl_hm_free(void* hm_ptr) {
    NLHashMap *hm = collection_lookup(hm_ptr, COLLECTION_MAP, true);
    if (!hm) return;
    for (int64_t i = 0; i < hm->capacity; i++) {
        HMEntry *e = &hm->entries[i];
        if (e->key && !e->tombstone) {
            hm_entry_free(e);
        }
    }
    free(hm->entries);
    free(hm);
}

/* ============================ Set<string> (on top of HashMap) ============================ */

typedef struct {
    void *hm;
} NLStringSet;

void* nl_set_new(void) {
    NLStringSet *s = (NLStringSet*)calloc(1, sizeof(NLStringSet));
    if (!s) return NULL;
    s->hm = nl_hm_new();
    if (!s->hm) { free(s); return NULL; }
    void *identity = collection_publish(s, COLLECTION_SET);
    if (!identity) { nl_hm_free(s->hm); free(s); }
    return identity;
}

void nl_set_add(void* set_ptr, const char* key) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm || !key) return;
    nl_hm_put(s->hm, key, "1");
}

bool nl_set_has(void* set_ptr, const char* key) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm || !key) return false;
    return nl_hm_has(s->hm, key);
}

int64_t nl_set_size(void* set_ptr) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm) return 0;
    return nl_hm_size(s->hm);
}

DynArray* nl_set_values(void* set_ptr) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm) return collection_snapshot_new();
    return nl_hm_keys(s->hm);
}

void nl_set_remove(void* set_ptr, const char* key) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm || !key) return;
    nl_hm_remove(s->hm, key);
}

void nl_set_clear(void* set_ptr) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, false);
    if (!s || !s->hm) return;
    nl_hm_clear(s->hm);
}

void nl_set_free(void* set_ptr) {
    NLStringSet *s = collection_lookup(set_ptr, COLLECTION_SET, true);
    if (!s) return;
    if (s->hm) nl_hm_free(s->hm);
    free(s);
}
