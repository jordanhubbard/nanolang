	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_nsi_free                    ; -- Begin function nl_nsi_free
	.p2align	2
_nl_nsi_free:                           ; @nl_nsi_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	b	LBB0_3
LBB0_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #32]
	bl	_free_methods
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #48]
	bl	_free_types
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #56]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #64]
	bl	_free_errors
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #72]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #80]
	bl	_free_named
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB0_3
LBB0_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_methods
_free_methods:                          ; @free_methods
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_7
LBB1_2:
	str	xzr, [sp, #8]
	b	LBB1_3
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB1_6
	b	LBB1_4
LBB1_4:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	str	x10, [sp]                       ; 8-byte Folded Spill
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x1, [x8, #24]
	bl	_free_params
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB1_3
LBB1_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB1_7
LBB1_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_types
_free_types:                            ; @free_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	b	LBB2_7
LBB2_2:
	str	xzr, [sp, #8]
	b	LBB2_3
LBB2_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB2_6
	b	LBB2_4
LBB2_4:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	lsl	x9, x9, #6
	ldr	x0, [x8, x9]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x1, [x8, #32]
	bl	_free_members
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #40]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #48]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #56]
	bl	_free
	b	LBB2_5
LBB2_5:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB2_3
LBB2_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB2_7
LBB2_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_errors
_free_errors:                           ; @free_errors
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	b	LBB3_7
LBB3_2:
	str	xzr, [sp, #8]
	b	LBB3_3
LBB3_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB3_6
	b	LBB3_4
LBB3_4:                                 ;   in Loop: Header=BB3_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mov	x10, #24                        ; =0x18
	str	x10, [sp]                       ; 8-byte Folded Spill
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #16]
	bl	_free
	b	LBB3_5
LBB3_5:                                 ;   in Loop: Header=BB3_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB3_3
LBB3_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB3_7
LBB3_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_named
_free_named:                            ; @free_named
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	b	LBB4_7
LBB4_2:
	str	xzr, [sp, #8]
	b	LBB4_3
LBB4_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB4_6
	b	LBB4_4
LBB4_4:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	bl	_free
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	bl	_free
	b	LBB4_5
LBB4_5:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB4_3
LBB4_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB4_7
LBB4_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_load_path               ; -- Begin function nl_nsi_load_path
	.p2align	2
_nl_nsi_load_path:                      ; @nl_nsi_load_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_2:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_fopen$DARWIN_EXTSN
	stur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB5_4
	b	LBB5_3
LBB5_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_4:
	ldur	x0, [x29, #-24]
	mov	x1, #0                          ; =0x0
	mov	w2, #2                          ; =0x2
	bl	_fseek
	cbz	w0, LBB5_6
	b	LBB5_5
LBB5_5:
	ldur	x0, [x29, #-24]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_6:
	ldur	x0, [x29, #-24]
	bl	_ftell
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	tbz	x8, #63, LBB5_8
	b	LBB5_7
LBB5_7:
	ldur	x0, [x29, #-24]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_8:
	ldur	x0, [x29, #-24]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_fseek
	cbz	w0, LBB5_10
	b	LBB5_9
LBB5_9:
	ldur	x0, [x29, #-24]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_10:
	ldr	x8, [sp, #32]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB5_12
	b	LBB5_11
LBB5_11:
	ldur	x0, [x29, #-24]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_12:
	ldr	x0, [sp, #24]
	ldr	x2, [sp, #32]
	ldur	x3, [x29, #-24]
	mov	x1, #1                          ; =0x1
	bl	_fread
	ldr	x8, [sp, #32]
	subs	x8, x0, x8
	b.eq	LBB5_14
	b	LBB5_13
LBB5_13:
	ldr	x0, [sp, #24]
	bl	_free
	ldur	x0, [x29, #-24]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_14:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x0, [x29, #-24]
	bl	_fclose
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	mov	x2, #0                          ; =0x0
	bl	_nl_utf8_validate
	tbnz	w0, #0, LBB5_16
	b	LBB5_15
LBB5_15:
	ldr	x0, [sp, #24]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_16:
	ldr	x0, [sp, #24]
	bl	_cJSON_Parse
	str	x0, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_18
	b	LBB5_17
LBB5_17:
	ldr	x0, [sp, #16]
	bl	_cJSON_IsObject
	cbnz	w0, LBB5_21
	b	LBB5_18
LBB5_18:
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_20
	b	LBB5_19
LBB5_19:
	ldr	x0, [sp, #16]
	bl	_cJSON_Delete
	b	LBB5_20
LBB5_20:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB5_22
LBB5_21:
	ldr	x0, [sp, #16]
	bl	_nl_nsi_decode_object
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_cJSON_Delete
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB5_22
LBB5_22:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_decode_object           ; -- Begin function nl_nsi_decode_object
	.p2align	2
_nl_nsi_decode_object:                  ; @nl_nsi_decode_object
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsObject
	cbnz	w0, LBB6_3
	b	LBB6_2
LBB6_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_20
LBB6_3:
	mov	x0, #1                          ; =0x1
	mov	x1, #88                         ; =0x58
	bl	_calloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB6_5
	b	LBB6_4
LBB6_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_20
LBB6_5:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #24]
	ldr	x0, [sp, #24]
	bl	_cJSON_IsNumber
	cbz	w0, LBB6_7
	b	LBB6_6
LBB6_6:
	ldr	x8, [sp, #24]
	ldr	d0, [x8, #48]
	fcmp	d0, #0.0
	b.eq	LBB6_8
	b	LBB6_7
LBB6_7:
	ldr	x0, [sp, #16]
	bl	_nl_nsi_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_20
LBB6_8:
	ldr	x8, [sp, #16]
	str	wzr, [x8]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldur	x0, [x29, #-16]
	adrp	x1, _nl_nsi_decode_object.root_keys@PAGE
	add	x1, x1, _nl_nsi_decode_object.root_keys@PAGEOFF
	mov	x2, #6                          ; =0x6
	bl	_keys_allowed
	tbz	w0, #0, LBB6_18
	b	LBB6_9
LBB6_9:
	ldr	x0, [sp, #8]
	adrp	x1, _nl_nsi_decode_object.iface_keys@PAGE
	add	x1, x1, _nl_nsi_decode_object.iface_keys@PAGEOFF
	mov	x2, #2                          ; =0x2
	bl	_keys_allowed
	tbz	w0, #0, LBB6_18
	b	LBB6_10
LBB6_10:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x1, x8, #8
	bl	_parse_named
	tbz	w0, #0, LBB6_18
	b	LBB6_11
LBB6_11:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldr	x8, [sp, #16]
	add	x1, x8, #24
	ldr	x8, [sp, #16]
	add	x2, x8, #32
	bl	_parse_method_array
	tbz	w0, #0, LBB6_18
	b	LBB6_12
LBB6_12:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldr	x8, [sp, #16]
	add	x1, x8, #40
	ldr	x8, [sp, #16]
	add	x2, x8, #48
	bl	_parse_type_array
	tbz	w0, #0, LBB6_18
	b	LBB6_13
LBB6_13:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldr	x8, [sp, #16]
	add	x1, x8, #56
	ldr	x8, [sp, #16]
	add	x2, x8, #64
	bl	_parse_error_array
	tbz	w0, #0, LBB6_18
	b	LBB6_14
LBB6_14:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.6@PAGE
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldr	x8, [sp, #16]
	add	x1, x8, #72
	ldr	x8, [sp, #16]
	add	x2, x8, #80
	bl	_parse_named_array
	tbz	w0, #0, LBB6_18
	b	LBB6_15
LBB6_15:
	ldr	x0, [sp, #16]
	bl	_ids_unique
	tbz	w0, #0, LBB6_18
	b	LBB6_16
LBB6_16:
	ldr	x0, [sp, #16]
	bl	_validate_prefixes
	tbz	w0, #0, LBB6_18
	b	LBB6_17
LBB6_17:
	ldr	x0, [sp, #16]
	bl	_validate_type_bounds
	tbnz	w0, #0, LBB6_19
	b	LBB6_18
LBB6_18:
	ldr	x0, [sp, #16]
	bl	_nl_nsi_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_20
LBB6_19:
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB6_20
LBB6_20:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function keys_allowed
_keys_allowed:                          ; @keys_allowed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsObject
	cbnz	w0, LBB7_3
	b	LBB7_2
LBB7_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_21
LBB7_3:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB7_5
	b	LBB7_4
LBB7_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_6
LBB7_5:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_6
LBB7_6:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #24]
	b	LBB7_7
LBB7_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_11 Depth 2
	ldr	x8, [sp, #24]
	cbz	x8, LBB7_20
	b	LBB7_8
LBB7_8:                                 ;   in Loop: Header=BB7_7 Depth=1
	str	wzr, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB7_10
	b	LBB7_9
LBB7_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_21
LBB7_10:                                ;   in Loop: Header=BB7_7 Depth=1
	str	xzr, [sp, #16]
	b	LBB7_11
LBB7_11:                                ;   Parent Loop BB7_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.hs	LBB7_16
	b	LBB7_12
LBB7_12:                                ;   in Loop: Header=BB7_11 Depth=2
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #56]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #16]
	ldr	x1, [x8, x9, lsl #3]
	bl	_strcmp
	cbnz	w0, LBB7_14
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_7 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB7_16
LBB7_14:                                ;   in Loop: Header=BB7_11 Depth=2
	b	LBB7_15
LBB7_15:                                ;   in Loop: Header=BB7_11 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB7_11
LBB7_16:                                ;   in Loop: Header=BB7_7 Depth=1
	ldr	w8, [sp, #12]
	cbnz	w8, LBB7_18
	b	LBB7_17
LBB7_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_21
LBB7_18:                                ;   in Loop: Header=BB7_7 Depth=1
	b	LBB7_19
LBB7_19:                                ;   in Loop: Header=BB7_7 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	b	LBB7_7
LBB7_20:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_21
LBB7_21:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_named
_parse_named:                           ; @parse_named
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsObject
	cbz	w0, LBB8_3
	b	LBB8_2
LBB8_2:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB8_4
	b	LBB8_3
LBB8_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_4:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #32]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #24]
	ldr	x0, [sp, #32]
	bl	_cJSON_IsString
	cbz	w0, LBB8_6
	b	LBB8_5
LBB8_5:
	ldr	x0, [sp, #24]
	bl	_cJSON_IsString
	cbnz	w0, LBB8_7
	b	LBB8_6
LBB8_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_7:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #32]
	bl	_id_ascii_ok
	tbnz	w0, #0, LBB8_9
	b	LBB8_8
LBB8_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_9:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB8_11
	b	LBB8_10
LBB8_10:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	ldrb	w8, [x8]
	cbnz	w8, LBB8_12
	b	LBB8_11
LBB8_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_12:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #32]
	bl	_strdup
	str	x0, [sp, #16]
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #32]
	bl	_strdup
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB8_14
	b	LBB8_13
LBB8_13:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB8_15
	b	LBB8_14
LBB8_14:
	ldr	x0, [sp, #16]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_15:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB8_16
LBB8_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_method_array
_parse_method_array:                    ; @parse_method_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB9_4
	b	LBB9_3
LBB9_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_4:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB9_6
	b	LBB9_5
LBB9_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_6:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB9_8
	b	LBB9_7
LBB9_7:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_8:
	ldrsw	x0, [sp, #12]
	mov	x1, #40                         ; =0x28
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB9_10
	b	LBB9_9
LBB9_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_10:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #8]
	b	LBB9_11
LBB9_11:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	LBB9_16
	b	LBB9_12
LBB9_12:                                ;   in Loop: Header=BB9_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #8]
	bl	_cJSON_GetArrayItem
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x1, x8, x9
	bl	_parse_method
	tbnz	w0, #0, LBB9_14
	b	LBB9_13
LBB9_13:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #8]
	bl	_free_methods
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_14:                                ;   in Loop: Header=BB9_11 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB9_15
LBB9_15:                                ;   in Loop: Header=BB9_11 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB9_11
LBB9_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_17
LBB9_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_type_array
_parse_type_array:                      ; @parse_type_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB10_4
	b	LBB10_3
LBB10_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_4:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB10_6
	b	LBB10_5
LBB10_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_6:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB10_8
	b	LBB10_7
LBB10_7:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_8:
	ldrsw	x0, [sp, #12]
	mov	x1, #64                         ; =0x40
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB10_10
	b	LBB10_9
LBB10_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_10:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #8]
	b	LBB10_11
LBB10_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	LBB10_16
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #8]
	bl	_cJSON_GetArrayItem
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #8]
	add	x1, x8, x9, lsl #6
	bl	_parse_type
	tbnz	w0, #0, LBB10_14
	b	LBB10_13
LBB10_13:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #8]
	bl	_free_types
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_14:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB10_15
LBB10_15:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB10_11
LBB10_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_error_array
_parse_error_array:                     ; @parse_error_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_4:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB11_6
	b	LBB11_5
LBB11_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_6:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB11_8
	b	LBB11_7
LBB11_7:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_8:
	ldrsw	x0, [sp, #12]
	mov	x1, #24                         ; =0x18
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB11_10
	b	LBB11_9
LBB11_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_10:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #8]
	b	LBB11_11
LBB11_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	LBB11_16
	b	LBB11_12
LBB11_12:                               ;   in Loop: Header=BB11_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #8]
	bl	_cJSON_GetArrayItem
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #8]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	add	x1, x8, x9
	bl	_parse_error
	tbnz	w0, #0, LBB11_14
	b	LBB11_13
LBB11_13:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #8]
	bl	_free_errors
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_14:                               ;   in Loop: Header=BB11_11 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_11 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB11_11
LBB11_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_17
LBB11_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_named_array
_parse_named_array:                     ; @parse_named_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB12_4
	b	LBB12_3
LBB12_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_4:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB12_6
	b	LBB12_5
LBB12_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_6:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB12_8
	b	LBB12_7
LBB12_7:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_8:
	ldrsw	x0, [sp, #12]
	mov	x1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB12_10
	b	LBB12_9
LBB12_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_10:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #8]
	b	LBB12_11
LBB12_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	LBB12_17
	b	LBB12_12
LBB12_12:                               ;   in Loop: Header=BB12_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #8]
	bl	_cJSON_GetArrayItem
	str	x0, [sp]
	ldr	x0, [sp]
	adrp	x1, _parse_named_array.keys@PAGE
	add	x1, x1, _parse_named_array.keys@PAGEOFF
	mov	x2, #2                          ; =0x2
	bl	_keys_allowed
	tbz	w0, #0, LBB12_14
	b	LBB12_13
LBB12_13:                               ;   in Loop: Header=BB12_11 Depth=1
	ldr	x0, [sp]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #8]
	add	x1, x8, x9, lsl #4
	bl	_parse_named
	tbnz	w0, #0, LBB12_15
	b	LBB12_14
LBB12_14:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #8]
	bl	_free_named
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_15:                               ;   in Loop: Header=BB12_11 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB12_16
LBB12_16:                               ;   in Loop: Header=BB12_11 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB12_11
LBB12_17:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_18
LBB12_18:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ids_unique
_ids_unique:                            ; @ids_unique
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	mov	x8, #1                          ; =0x1
	stur	x8, [x29, #-24]
	str	xzr, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #7]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #64]
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #80]
	add	x9, x8, x9
	ldur	x8, [x29, #-24]
	add	x8, x8, x9
	stur	x8, [x29, #-24]
	str	xzr, [sp, #32]
	b	LBB13_1
LBB13_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB13_4
	b	LBB13_2
LBB13_2:                                ;   in Loop: Header=BB13_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #32]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x9, [x8, #24]
	ldur	x8, [x29, #-24]
	add	x8, x8, x9
	stur	x8, [x29, #-24]
	b	LBB13_3
LBB13_3:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_1
LBB13_4:
	str	xzr, [sp, #32]
	b	LBB13_5
LBB13_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB13_8
	b	LBB13_6
LBB13_6:                                ;   in Loop: Header=BB13_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #32]
	add	x8, x8, x9, lsl #6
	ldr	x9, [x8, #32]
	ldur	x8, [x29, #-24]
	add	x8, x8, x9
	stur	x8, [x29, #-24]
	b	LBB13_7
LBB13_7:                                ;   in Loop: Header=BB13_5 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_5
LBB13_8:
	ldur	x8, [x29, #-24]
	lsl	x0, x8, #3
	bl	_malloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB13_10
	b	LBB13_9
LBB13_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_47
LBB13_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	str	xzr, [sp, #32]
	b	LBB13_11
LBB13_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_13 Depth 2
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB13_18
	b	LBB13_12
LBB13_12:                               ;   in Loop: Header=BB13_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #32]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	str	xzr, [sp, #24]
	b	LBB13_13
LBB13_13:                               ;   Parent Loop BB13_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #24]
	ldr	x10, [sp, #32]
	mov	x11, #40                        ; =0x28
	mul	x10, x10, x11
	add	x9, x9, x10
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB13_16
	b	LBB13_14
LBB13_14:                               ;   in Loop: Header=BB13_13 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #32]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #24]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	b	LBB13_15
LBB13_15:                               ;   in Loop: Header=BB13_13 Depth=2
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB13_13
LBB13_16:                               ;   in Loop: Header=BB13_11 Depth=1
	b	LBB13_17
LBB13_17:                               ;   in Loop: Header=BB13_11 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_11
LBB13_18:
	str	xzr, [sp, #32]
	b	LBB13_19
LBB13_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_21 Depth 2
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB13_26
	b	LBB13_20
LBB13_20:                               ;   in Loop: Header=BB13_19 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #32]
	lsl	x9, x9, #6
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	str	xzr, [sp, #24]
	b	LBB13_21
LBB13_21:                               ;   Parent Loop BB13_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #40]
	ldr	x10, [sp, #32]
	add	x9, x9, x10, lsl #6
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB13_24
	b	LBB13_22
LBB13_22:                               ;   in Loop: Header=BB13_21 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #32]
	add	x8, x8, x9, lsl #6
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #24]
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	b	LBB13_23
LBB13_23:                               ;   in Loop: Header=BB13_21 Depth=2
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB13_21
LBB13_24:                               ;   in Loop: Header=BB13_19 Depth=1
	b	LBB13_25
LBB13_25:                               ;   in Loop: Header=BB13_19 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_19
LBB13_26:
	str	xzr, [sp, #32]
	b	LBB13_27
LBB13_27:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB13_30
	b	LBB13_28
LBB13_28:                               ;   in Loop: Header=BB13_27 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x9, [sp, #32]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	b	LBB13_29
LBB13_29:                               ;   in Loop: Header=BB13_27 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_27
LBB13_30:
	str	xzr, [sp, #32]
	b	LBB13_31
LBB13_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB13_34
	b	LBB13_32
LBB13_32:                               ;   in Loop: Header=BB13_31 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #32]
	lsl	x9, x9, #4
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	str	x8, [x9, x10, lsl #3]
	b	LBB13_33
LBB13_33:                               ;   in Loop: Header=BB13_31 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_31
LBB13_34:
	str	xzr, [sp, #32]
	b	LBB13_35
LBB13_35:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_39 Depth 2
	ldr	x9, [sp, #32]
	ldr	x10, [sp, #16]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hs	LBB13_37
	b	LBB13_36
LBB13_36:                               ;   in Loop: Header=BB13_35 Depth=1
	ldrb	w8, [sp, #7]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB13_37
LBB13_37:                               ;   in Loop: Header=BB13_35 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_46
	b	LBB13_38
LBB13_38:                               ;   in Loop: Header=BB13_35 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB13_39
LBB13_39:                               ;   Parent Loop BB13_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB13_44
	b	LBB13_40
LBB13_40:                               ;   in Loop: Header=BB13_39 Depth=2
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	ldr	x1, [x8, x9, lsl #3]
	bl	_strcmp
	cbnz	w0, LBB13_42
	b	LBB13_41
LBB13_41:                               ;   in Loop: Header=BB13_35 Depth=1
	strb	wzr, [sp, #7]
	b	LBB13_44
LBB13_42:                               ;   in Loop: Header=BB13_39 Depth=2
	b	LBB13_43
LBB13_43:                               ;   in Loop: Header=BB13_39 Depth=2
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB13_39
LBB13_44:                               ;   in Loop: Header=BB13_35 Depth=1
	b	LBB13_45
LBB13_45:                               ;   in Loop: Header=BB13_35 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB13_35
LBB13_46:
	ldr	x0, [sp, #8]
	bl	_free
	ldrb	w8, [sp, #7]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_47
LBB13_47:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validate_prefixes
_validate_prefixes:                     ; @validate_prefixes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_starts_with
	tbnz	w0, #0, LBB14_2
	b	LBB14_1
LBB14_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	mov	w1, #35                         ; =0x23
	bl	_strchr
	cbz	x0, LBB14_4
	b	LBB14_3
LBB14_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_4:
	str	xzr, [sp, #24]
	b	LBB14_5
LBB14_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_9 Depth 2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB14_16
	b	LBB14_6
LBB14_6:                                ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #24]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_fragment_of_interface
	tbnz	w0, #0, LBB14_8
	b	LBB14_7
LBB14_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_8:                                ;   in Loop: Header=BB14_5 Depth=1
	str	xzr, [sp, #16]
	b	LBB14_9
LBB14_9:                                ;   Parent Loop BB14_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #24]
	ldr	x10, [sp, #24]
	mov	x11, #40                        ; =0x28
	mul	x10, x10, x11
	add	x9, x9, x10
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB14_14
	b	LBB14_10
LBB14_10:                               ;   in Loop: Header=BB14_9 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #24]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_fragment_of_interface
	tbnz	w0, #0, LBB14_12
	b	LBB14_11
LBB14_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_12:                               ;   in Loop: Header=BB14_9 Depth=2
	b	LBB14_13
LBB14_13:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB14_9
LBB14_14:                               ;   in Loop: Header=BB14_5 Depth=1
	b	LBB14_15
LBB14_15:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB14_5
LBB14_16:
	str	xzr, [sp, #24]
	b	LBB14_17
LBB14_17:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_21 Depth 2
                                        ;     Child Loop BB14_28 Depth 2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB14_39
	b	LBB14_18
LBB14_18:                               ;   in Loop: Header=BB14_17 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	lsl	x9, x9, #6
	ldr	x1, [x8, x9]
	bl	_fragment_of_interface
	tbnz	w0, #0, LBB14_20
	b	LBB14_19
LBB14_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_20:                               ;   in Loop: Header=BB14_17 Depth=1
	str	xzr, [sp, #16]
	b	LBB14_21
LBB14_21:                               ;   Parent Loop BB14_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #40]
	ldr	x10, [sp, #24]
	add	x9, x9, x10, lsl #6
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB14_26
	b	LBB14_22
LBB14_22:                               ;   in Loop: Header=BB14_21 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #6
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_fragment_of_interface
	tbnz	w0, #0, LBB14_24
	b	LBB14_23
LBB14_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_24:                               ;   in Loop: Header=BB14_21 Depth=2
	b	LBB14_25
LBB14_25:                               ;   in Loop: Header=BB14_21 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB14_21
LBB14_26:                               ;   in Loop: Header=BB14_17 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #6
	ldr	w8, [x8, #16]
	subs	w8, w8, #7
	b.ne	LBB14_37
	b	LBB14_27
LBB14_27:                               ;   in Loop: Header=BB14_17 Depth=1
	str	wzr, [sp, #12]
	str	xzr, [sp]
	b	LBB14_28
LBB14_28:                               ;   Parent Loop BB14_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB14_34
	b	LBB14_29
LBB14_29:                               ;   in Loop: Header=BB14_28 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #6
	ldr	x8, [x8, #48]
	cbz	x8, LBB14_32
	b	LBB14_30
LBB14_30:                               ;   in Loop: Header=BB14_28 Depth=2
	ldur	x8, [x29, #-16]
	mov	x10, #40                        ; =0x28
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #6
	ldr	x0, [x8, #48]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_strcmp
	cbnz	w0, LBB14_32
	b	LBB14_31
LBB14_31:                               ;   in Loop: Header=BB14_17 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB14_34
LBB14_32:                               ;   in Loop: Header=BB14_28 Depth=2
	b	LBB14_33
LBB14_33:                               ;   in Loop: Header=BB14_28 Depth=2
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB14_28
LBB14_34:                               ;   in Loop: Header=BB14_17 Depth=1
	ldr	w8, [sp, #12]
	cbnz	w8, LBB14_36
	b	LBB14_35
LBB14_35:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_36:                               ;   in Loop: Header=BB14_17 Depth=1
	b	LBB14_37
LBB14_37:                               ;   in Loop: Header=BB14_17 Depth=1
	b	LBB14_38
LBB14_38:                               ;   in Loop: Header=BB14_17 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB14_17
LBB14_39:
	str	xzr, [sp, #24]
	b	LBB14_40
LBB14_40:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB14_45
	b	LBB14_41
LBB14_41:                               ;   in Loop: Header=BB14_40 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x9, [sp, #24]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_fragment_of_interface
	tbnz	w0, #0, LBB14_43
	b	LBB14_42
LBB14_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_43:                               ;   in Loop: Header=BB14_40 Depth=1
	b	LBB14_44
LBB14_44:                               ;   in Loop: Header=BB14_40 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB14_40
LBB14_45:
	str	xzr, [sp, #24]
	b	LBB14_46
LBB14_46:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB14_53
	b	LBB14_47
LBB14_47:                               ;   in Loop: Header=BB14_46 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #24]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	adrp	x1, l_.str.50@PAGE
	add	x1, x1, l_.str.50@PAGEOFF
	bl	_starts_with
	tbnz	w0, #0, LBB14_49
	b	LBB14_48
LBB14_48:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_49:                               ;   in Loop: Header=BB14_46 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #24]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	mov	w1, #35                         ; =0x23
	bl	_strchr
	cbz	x0, LBB14_51
	b	LBB14_50
LBB14_50:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_51:                               ;   in Loop: Header=BB14_46 Depth=1
	b	LBB14_52
LBB14_52:                               ;   in Loop: Header=BB14_46 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB14_46
LBB14_53:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_54
LBB14_54:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validate_type_bounds
_validate_type_bounds:                  ; @validate_type_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	xzr, [sp, #24]
	b	LBB15_1
LBB15_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB15_3 Depth 2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB15_10
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	str	xzr, [sp, #16]
	b	LBB15_3
LBB15_3:                                ;   Parent Loop BB15_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #24]
	ldr	x10, [sp, #24]
	mov	x11, #40                        ; =0x28
	mul	x10, x10, x11
	add	x9, x9, x10
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB15_8
	b	LBB15_4
LBB15_4:                                ;   in Loop: Header=BB15_3 Depth=2
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #24]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x1, [x8, #16]
	bl	_type_bound_ok
	tbnz	w0, #0, LBB15_6
	b	LBB15_5
LBB15_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_28
LBB15_6:                                ;   in Loop: Header=BB15_3 Depth=2
	b	LBB15_7
LBB15_7:                                ;   in Loop: Header=BB15_3 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB15_3
LBB15_8:                                ;   in Loop: Header=BB15_1 Depth=1
	b	LBB15_9
LBB15_9:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB15_1
LBB15_10:
	str	xzr, [sp, #24]
	b	LBB15_11
LBB15_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB15_13 Depth 2
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB15_27
	b	LBB15_12
LBB15_12:                               ;   in Loop: Header=BB15_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #8]
	str	xzr, [sp, #16]
	b	LBB15_13
LBB15_13:                               ;   Parent Loop BB15_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB15_19
	b	LBB15_14
LBB15_14:                               ;   in Loop: Header=BB15_13 Depth=2
	ldr	x8, [sp, #8]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #16]
	cbz	x8, LBB15_17
	b	LBB15_15
LBB15_15:                               ;   in Loop: Header=BB15_13 Depth=2
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #8]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x1, [x8, #16]
	bl	_type_bound_ok
	tbnz	w0, #0, LBB15_17
	b	LBB15_16
LBB15_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_28
LBB15_17:                               ;   in Loop: Header=BB15_13 Depth=2
	b	LBB15_18
LBB15_18:                               ;   in Loop: Header=BB15_13 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB15_13
LBB15_19:                               ;   in Loop: Header=BB15_11 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #40]
	cbz	x8, LBB15_22
	b	LBB15_20
LBB15_20:                               ;   in Loop: Header=BB15_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #40]
	bl	_type_bound_ok
	tbnz	w0, #0, LBB15_22
	b	LBB15_21
LBB15_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_28
LBB15_22:                               ;   in Loop: Header=BB15_11 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #56]
	cbz	x8, LBB15_25
	b	LBB15_23
LBB15_23:                               ;   in Loop: Header=BB15_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #56]
	bl	_type_bound_ok
	tbnz	w0, #0, LBB15_25
	b	LBB15_24
LBB15_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_28
LBB15_25:                               ;   in Loop: Header=BB15_11 Depth=1
	b	LBB15_26
LBB15_26:                               ;   in Loop: Header=BB15_11 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB15_11
LBB15_27:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_28
LBB15_28:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_interface_id            ; -- Begin function nl_nsi_interface_id
	.p2align	2
_nl_nsi_interface_id:                   ; @nl_nsi_interface_id
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB16_3
	b	LBB16_1
LBB16_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbz	x8, LBB16_3
	b	LBB16_2
LBB16_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB16_4
LBB16_3:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB16_4
LBB16_4:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_method_count            ; -- Begin function nl_nsi_method_count
	.p2align	2
_nl_nsi_method_count:                   ; @nl_nsi_method_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB17_2
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB17_3
LBB17_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB17_3
LBB17_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_method_id               ; -- Begin function nl_nsi_method_id
	.p2align	2
_nl_nsi_method_id:                      ; @nl_nsi_method_id
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB18_2
	b	LBB18_1
LBB18_1:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.lo	LBB18_3
	b	LBB18_2
LBB18_2:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp, #24]
	b	LBB18_7
LBB18_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	cbz	x8, LBB18_5
	b	LBB18_4
LBB18_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	ldr	x8, [x8, x9]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB18_6
LBB18_5:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB18_6
LBB18_6:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #24]
	b	LBB18_7
LBB18_7:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_param_count             ; -- Begin function nl_nsi_param_count
	.p2align	2
_nl_nsi_param_count:                    ; @nl_nsi_param_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB19_2
	b	LBB19_1
LBB19_1:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.lo	LBB19_3
	b	LBB19_2
LBB19_2:
	str	xzr, [sp, #24]
	b	LBB19_4
LBB19_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #24]
	str	x8, [sp, #24]
	b	LBB19_4
LBB19_4:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_param                   ; -- Begin function nl_nsi_param
	.p2align	2
_nl_nsi_param:                          ; @nl_nsi_param
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB20_2
	b	LBB20_1
LBB20_1:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.lo	LBB20_3
	b	LBB20_2
LBB20_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB20_6
LBB20_3:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #24]
	ldr	x10, [sp, #8]
	mov	x11, #40                        ; =0x28
	mul	x10, x10, x11
	add	x9, x9, x10
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.lo	LBB20_5
	b	LBB20_4
LBB20_4:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB20_6
LBB20_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #8]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #16]
	ldr	x9, [sp]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #24]
	b	LBB20_6
LBB20_6:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_find_method             ; -- Begin function nl_nsi_find_method
	.p2align	2
_nl_nsi_find_method:                    ; @nl_nsi_find_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_find_method
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_method
_find_method:                           ; @find_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB22_3
	b	LBB22_2
LBB22_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB22_10
LBB22_3:
	str	xzr, [sp]
	b	LBB22_4
LBB22_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB22_9
	b	LBB22_5
LBB22_5:                                ;   in Loop: Header=BB22_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_cstr_eq
	cbz	w0, LBB22_7
	b	LBB22_6
LBB22_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB22_10
LBB22_7:                                ;   in Loop: Header=BB22_4 Depth=1
	b	LBB22_8
LBB22_8:                                ;   in Loop: Header=BB22_4 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB22_4
LBB22_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB22_10
LBB22_10:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_nsi_compat                  ; -- Begin function nl_nsi_compat
	.p2align	2
_nl_nsi_compat:                         ; @nl_nsi_compat
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB23_3
	b	LBB23_2
LBB23_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #8]
	bl	_cstr_eq
	cbnz	w0, LBB23_5
	b	LBB23_4
LBB23_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB23_7
	b	LBB23_6
LBB23_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_7:
	stur	xzr, [x29, #-32]
	b	LBB23_8
LBB23_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_15 Depth 2
                                        ;     Child Loop BB23_22 Depth 2
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB23_32
	b	LBB23_9
LBB23_9:                                ;   in Loop: Header=BB23_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-32]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-48]
	ldr	x1, [x8]
	bl	_find_method
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB23_11
	b	LBB23_10
LBB23_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_11:                               ;   in Loop: Header=BB23_8 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	cbz	w8, LBB23_14
	b	LBB23_12
LBB23_12:                               ;   in Loop: Header=BB23_8 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #32]
	cbnz	w8, LBB23_14
	b	LBB23_13
LBB23_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_14:                               ;   in Loop: Header=BB23_8 Depth=1
	stur	xzr, [x29, #-40]
	b	LBB23_15
LBB23_15:                               ;   Parent Loop BB23_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB23_21
	b	LBB23_16
LBB23_16:                               ;   in Loop: Header=BB23_15 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #64]
	ldur	x0, [x29, #-56]
	ldr	x8, [sp, #64]
	ldr	x1, [x8]
	bl	_find_param
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbz	x8, LBB23_18
	b	LBB23_17
LBB23_17:                               ;   in Loop: Header=BB23_15 Depth=2
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #56]
	bl	_param_contract_eq
	cbnz	w0, LBB23_19
	b	LBB23_18
LBB23_18:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_19:                               ;   in Loop: Header=BB23_15 Depth=2
	b	LBB23_20
LBB23_20:                               ;   in Loop: Header=BB23_15 Depth=2
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB23_15
LBB23_21:                               ;   in Loop: Header=BB23_8 Depth=1
	stur	xzr, [x29, #-40]
	b	LBB23_22
LBB23_22:                               ;   Parent Loop BB23_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB23_30
	b	LBB23_23
LBB23_23:                               ;   in Loop: Header=BB23_22 Depth=2
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	ldr	x1, [x8, x9]
	bl	_find_param
	cbz	x0, LBB23_25
	b	LBB23_24
LBB23_24:                               ;   in Loop: Header=BB23_22 Depth=2
	b	LBB23_29
LBB23_25:                               ;   in Loop: Header=BB23_22 Depth=2
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #40]
	cbz	w8, LBB23_27
	b	LBB23_26
LBB23_26:                               ;   in Loop: Header=BB23_22 Depth=2
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #24]
	cbz	w8, LBB23_28
	b	LBB23_27
LBB23_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_28:                               ;   in Loop: Header=BB23_22 Depth=2
	b	LBB23_29
LBB23_29:                               ;   in Loop: Header=BB23_22 Depth=2
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB23_22
LBB23_30:                               ;   in Loop: Header=BB23_8 Depth=1
	b	LBB23_31
LBB23_31:                               ;   in Loop: Header=BB23_8 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB23_8
LBB23_32:
	stur	xzr, [x29, #-32]
	b	LBB23_33
LBB23_33:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_38 Depth 2
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB23_49
	b	LBB23_34
LBB23_34:                               ;   in Loop: Header=BB23_33 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #48]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #48]
	ldr	x1, [x8]
	bl	_find_type
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbz	x8, LBB23_36
	b	LBB23_35
LBB23_35:                               ;   in Loop: Header=BB23_33 Depth=1
	ldr	x0, [sp, #48]
	ldr	x1, [sp, #40]
	bl	_type_payload_eq
	cbnz	w0, LBB23_37
	b	LBB23_36
LBB23_36:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_37:                               ;   in Loop: Header=BB23_33 Depth=1
	stur	xzr, [x29, #-40]
	b	LBB23_38
LBB23_38:                               ;   Parent Loop BB23_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB23_44
	b	LBB23_39
LBB23_39:                               ;   in Loop: Header=BB23_38 Depth=2
	ldr	x8, [sp, #48]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldr	x0, [sp, #40]
	ldr	x8, [sp, #32]
	ldr	x1, [x8]
	bl	_find_member
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbz	x8, LBB23_41
	b	LBB23_40
LBB23_40:                               ;   in Loop: Header=BB23_38 Depth=2
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #24]
	ldr	x1, [x8, #16]
	bl	_cstr_eq
	cbnz	w0, LBB23_42
	b	LBB23_41
LBB23_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_42:                               ;   in Loop: Header=BB23_38 Depth=2
	b	LBB23_43
LBB23_43:                               ;   in Loop: Header=BB23_38 Depth=2
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB23_38
LBB23_44:                               ;   in Loop: Header=BB23_33 Depth=1
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB23_47
	b	LBB23_45
LBB23_45:                               ;   in Loop: Header=BB23_33 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.eq	LBB23_47
	b	LBB23_46
LBB23_46:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_47:                               ;   in Loop: Header=BB23_33 Depth=1
	b	LBB23_48
LBB23_48:                               ;   in Loop: Header=BB23_33 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB23_33
LBB23_49:
	stur	xzr, [x29, #-32]
	b	LBB23_50
LBB23_50:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB23_56
	b	LBB23_51
LBB23_51:                               ;   in Loop: Header=BB23_50 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-32]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #16]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #16]
	ldr	x1, [x8]
	bl	_find_error
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB23_53
	b	LBB23_52
LBB23_52:                               ;   in Loop: Header=BB23_50 Depth=1
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #16]
	bl	_cstr_eq
	cbnz	w0, LBB23_54
	b	LBB23_53
LBB23_53:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_57
LBB23_54:                               ;   in Loop: Header=BB23_50 Depth=1
	b	LBB23_55
LBB23_55:                               ;   in Loop: Header=BB23_50 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB23_50
LBB23_56:
	stur	wzr, [x29, #-4]
	b	LBB23_57
LBB23_57:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function cstr_eq
_cstr_eq:                               ; @cstr_eq
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB24_3
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB24_3
	b	LBB24_2
LBB24_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_7
LBB24_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB24_5
	b	LBB24_4
LBB24_4:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB24_6
	b	LBB24_5
LBB24_5:
	stur	wzr, [x29, #-4]
	b	LBB24_7
LBB24_6:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	stur	w8, [x29, #-4]
	b	LBB24_7
LBB24_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_param
_find_param:                            ; @find_param
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB25_2
	b	LBB25_1
LBB25_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB25_3
	b	LBB25_2
LBB25_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB25_10
LBB25_3:
	str	xzr, [sp]
	b	LBB25_4
LBB25_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB25_9
	b	LBB25_5
LBB25_5:                                ;   in Loop: Header=BB25_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_cstr_eq
	cbz	w0, LBB25_7
	b	LBB25_6
LBB25_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB25_10
LBB25_7:                                ;   in Loop: Header=BB25_4 Depth=1
	b	LBB25_8
LBB25_8:                                ;   in Loop: Header=BB25_4 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB25_4
LBB25_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB25_10
LBB25_10:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function param_contract_eq
_param_contract_eq:                     ; @param_contract_eq
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB26_2
	b	LBB26_1
LBB26_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB26_3
	b	LBB26_2
LBB26_2:
	stur	wzr, [x29, #-4]
	b	LBB26_11
LBB26_3:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #16]
	bl	_cstr_eq
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w0, LBB26_10
	b	LBB26_4
LBB26_4:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #24]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB26_10
	b	LBB26_5
LBB26_5:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #28]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #28]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB26_10
	b	LBB26_6
LBB26_6:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #32]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB26_10
	b	LBB26_7
LBB26_7:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #36]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #36]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB26_10
	b	LBB26_8
LBB26_8:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #40]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #40]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB26_10
	b	LBB26_9
LBB26_9:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #44]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #44]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB26_10
LBB26_10:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	stur	w8, [x29, #-4]
	b	LBB26_11
LBB26_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_type
_find_type:                             ; @find_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB27_2
	b	LBB27_1
LBB27_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB27_3
	b	LBB27_2
LBB27_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB27_10
LBB27_3:
	str	xzr, [sp]
	b	LBB27_4
LBB27_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB27_9
	b	LBB27_5
LBB27_5:                                ;   in Loop: Header=BB27_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp]
	lsl	x9, x9, #6
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_cstr_eq
	cbz	w0, LBB27_7
	b	LBB27_6
LBB27_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp]
	add	x8, x8, x9, lsl #6
	stur	x8, [x29, #-8]
	b	LBB27_10
LBB27_7:                                ;   in Loop: Header=BB27_4 Depth=1
	b	LBB27_8
LBB27_8:                                ;   in Loop: Header=BB27_4 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB27_4
LBB27_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB27_10
LBB27_10:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_payload_eq
_type_payload_eq:                       ; @type_payload_eq
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB28_2
	b	LBB28_1
LBB28_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB28_3
	b	LBB28_2
LBB28_2:
	stur	wzr, [x29, #-4]
	b	LBB28_12
LBB28_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB28_5
	b	LBB28_4
LBB28_4:
	stur	wzr, [x29, #-4]
	b	LBB28_12
LBB28_5:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #40]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #40]
	bl	_cstr_eq
	cbnz	w0, LBB28_7
	b	LBB28_6
LBB28_6:
	stur	wzr, [x29, #-4]
	b	LBB28_12
LBB28_7:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #48]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #48]
	bl	_cstr_eq
	cbnz	w0, LBB28_9
	b	LBB28_8
LBB28_8:
	stur	wzr, [x29, #-4]
	b	LBB28_12
LBB28_9:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #56]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #56]
	bl	_cstr_eq
	cbnz	w0, LBB28_11
	b	LBB28_10
LBB28_10:
	stur	wzr, [x29, #-4]
	b	LBB28_12
LBB28_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB28_12
LBB28_12:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_member
_find_member:                           ; @find_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB29_2
	b	LBB29_1
LBB29_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB29_3
	b	LBB29_2
LBB29_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB29_10
LBB29_3:
	str	xzr, [sp]
	b	LBB29_4
LBB29_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB29_9
	b	LBB29_5
LBB29_5:                                ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp, #16]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_cstr_eq
	cbz	w0, LBB29_7
	b	LBB29_6
LBB29_6:
	ldr	x8, [sp, #16]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB29_10
LBB29_7:                                ;   in Loop: Header=BB29_4 Depth=1
	b	LBB29_8
LBB29_8:                                ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB29_4
LBB29_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB29_10
LBB29_10:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_error
_find_error:                            ; @find_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB30_2
	b	LBB30_1
LBB30_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB30_3
	b	LBB30_2
LBB30_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB30_10
LBB30_3:
	str	xzr, [sp]
	b	LBB30_4
LBB30_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB30_9
	b	LBB30_5
LBB30_5:                                ;   in Loop: Header=BB30_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	ldr	x9, [sp]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_cstr_eq
	cbz	w0, LBB30_7
	b	LBB30_6
LBB30_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	ldr	x9, [sp]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-8]
	b	LBB30_10
LBB30_7:                                ;   in Loop: Header=BB30_4 Depth=1
	b	LBB30_8
LBB30_8:                                ;   in Loop: Header=BB30_4 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB30_4
LBB30_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB30_10
LBB30_10:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_params
_free_params:                           ; @free_params
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB31_2
	b	LBB31_1
LBB31_1:
	b	LBB31_7
LBB31_2:
	str	xzr, [sp, #8]
	b	LBB31_3
LBB31_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB31_6
	b	LBB31_4
LBB31_4:                                ;   in Loop: Header=BB31_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mov	x10, #48                        ; =0x30
	str	x10, [sp]                       ; 8-byte Folded Spill
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #16]
	bl	_free
	b	LBB31_5
LBB31_5:                                ;   in Loop: Header=BB31_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB31_3
LBB31_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB31_7
LBB31_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_members
_free_members:                          ; @free_members
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB32_2
	b	LBB32_1
LBB32_1:
	b	LBB32_7
LBB32_2:
	str	xzr, [sp, #8]
	b	LBB32_3
LBB32_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.hs	LBB32_6
	b	LBB32_4
LBB32_4:                                ;   in Loop: Header=BB32_3 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mov	x10, #24                        ; =0x18
	str	x10, [sp]                       ; 8-byte Folded Spill
	mul	x9, x9, x10
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #8]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x0, [x8, #16]
	bl	_free
	b	LBB32_5
LBB32_5:                                ;   in Loop: Header=BB32_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB32_3
LBB32_6:
	ldur	x0, [x29, #-8]
	bl	_free
	b	LBB32_7
LBB32_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function id_ascii_ok
_id_ascii_ok:                           ; @id_ascii_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB33_2
	b	LBB33_1
LBB33_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	cbnz	w8, LBB33_3
	b	LBB33_2
LBB33_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_10
LBB33_3:
	str	xzr, [sp, #8]
	b	LBB33_4
LBB33_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB33_9
	b	LBB33_5
LBB33_5:                                ;   in Loop: Header=BB33_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	ldrb	w0, [x8, x9]
	bl	_id_char_ok
	cbnz	w0, LBB33_7
	b	LBB33_6
LBB33_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_10
LBB33_7:                                ;   in Loop: Header=BB33_4 Depth=1
	b	LBB33_8
LBB33_8:                                ;   in Loop: Header=BB33_4 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB33_4
LBB33_9:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_10
LBB33_10:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function id_char_ok
_id_char_ok:                            ; @id_char_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-1]
	ldurb	w0, [x29, #-1]
	bl	_nl_ascii_isalnum
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w0, LBB34_7
	b	LBB34_1
LBB34_1:
	ldurb	w9, [x29, #-1]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #58
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB34_7
	b	LBB34_2
LBB34_2:
	ldurb	w9, [x29, #-1]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #47
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB34_7
	b	LBB34_3
LBB34_3:
	ldurb	w9, [x29, #-1]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #46
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB34_7
	b	LBB34_4
LBB34_4:
	ldurb	w9, [x29, #-1]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #95
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB34_7
	b	LBB34_5
LBB34_5:
	ldurb	w9, [x29, #-1]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #45
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB34_7
	b	LBB34_6
LBB34_6:
	ldurb	w8, [x29, #-1]
	subs	w8, w8, #35
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB34_7
LBB34_7:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_method
_parse_method:                          ; @parse_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	xzr, [sp, #24]
	str	xzr, [sp, #32]
	ldur	x0, [x29, #-16]
	adrp	x1, _parse_method.keys@PAGE
	add	x1, x1, _parse_method.keys@PAGEOFF
	mov	x2, #4                          ; =0x4
	bl	_keys_allowed
	tbnz	w0, #0, LBB35_2
	b	LBB35_1
LBB35_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #24
	bl	_parse_named
	tbnz	w0, #0, LBB35_4
	b	LBB35_3
LBB35_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_4:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #8]
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #24]
	ldur	x8, [x29, #-24]
	str	wzr, [x8, #32]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.11@PAGE
	add	x1, x1, l_.str.11@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB35_8
	b	LBB35_5
LBB35_5:
	ldr	x0, [sp, #8]
	bl	_cJSON_IsBool
	cbnz	w0, LBB35_7
	b	LBB35_6
LBB35_6:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_7:
	ldr	x0, [sp, #8]
	bl	_cJSON_IsTrue
	mov	w8, #0                          ; =0x0
	subs	w9, w0, #0
	csinc	w8, w8, wzr, eq
	ldur	x9, [x29, #-24]
	str	w8, [x9, #32]
	b	LBB35_8
LBB35_8:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB35_10
	b	LBB35_9
LBB35_9:
	ldr	x0, [sp, #16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB35_11
	b	LBB35_10
LBB35_10:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_11:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-24]
	add	x1, x8, #16
	ldur	x8, [x29, #-24]
	add	x2, x8, #24
	bl	_parse_param_array
	tbnz	w0, #0, LBB35_13
	b	LBB35_12
LBB35_12:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_13:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_14
LBB35_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_param_array
_parse_param_array:                     ; @parse_param_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB36_2
	b	LBB36_1
LBB36_1:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB36_4
	b	LBB36_3
LBB36_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_4:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB36_6
	b	LBB36_5
LBB36_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_6:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB36_8
	b	LBB36_7
LBB36_7:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_8:
	ldrsw	x0, [sp, #12]
	mov	x1, #48                         ; =0x30
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB36_10
	b	LBB36_9
LBB36_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_10:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #8]
	b	LBB36_11
LBB36_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ge	LBB36_16
	b	LBB36_12
LBB36_12:                               ;   in Loop: Header=BB36_11 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #8]
	bl	_cJSON_GetArrayItem
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #8]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x1, x8, x9
	bl	_parse_param
	tbnz	w0, #0, LBB36_14
	b	LBB36_13
LBB36_13:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #8]
	bl	_free_params
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_14:                               ;   in Loop: Header=BB36_11 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB36_15
LBB36_15:                               ;   in Loop: Header=BB36_11 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB36_11
LBB36_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_17
LBB36_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_param
_parse_param:                           ; @parse_param
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	xzr, [sp, #40]
	str	xzr, [sp, #48]
	str	wzr, [sp, #20]
	str	wzr, [sp, #16]
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	str	wzr, [sp, #4]
	ldur	x0, [x29, #-16]
	adrp	x1, _parse_param.keys@PAGE
	add	x1, x1, _parse_param.keys@PAGEOFF
	mov	x2, #9                          ; =0x9
	bl	_keys_allowed
	tbnz	w0, #0, LBB37_2
	b	LBB37_1
LBB37_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #40
	bl	_parse_named
	tbnz	w0, #0, LBB37_4
	b	LBB37_3
LBB37_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_4:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #8]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #24]
	ldr	x0, [sp, #24]
	bl	_cJSON_IsString
	cbz	w0, LBB37_6
	b	LBB37_5
LBB37_5:
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #32]
	bl	_id_ascii_ok
	tbnz	w0, #0, LBB37_7
	b	LBB37_6
LBB37_6:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_7:
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #32]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_starts_with
	tbnz	w0, #0, LBB37_9
	b	LBB37_8
LBB37_8:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_9:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.13@PAGE
	add	x1, x1, l_.str.13@PAGEOFF
	adrp	x2, _k_direction@PAGE
	add	x2, x2, _k_direction@PAGEOFF
	mov	w3, #4                          ; =0x4
	add	x4, sp, #20
	bl	_parse_enum
	tbz	w0, #0, LBB37_14
	b	LBB37_10
LBB37_10:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.14@PAGE
	add	x1, x1, l_.str.14@PAGEOFF
	adrp	x2, _k_ownership@PAGE
	add	x2, x2, _k_ownership@PAGEOFF
	mov	w3, #3                          ; =0x3
	add	x4, sp, #16
	bl	_parse_enum
	tbz	w0, #0, LBB37_14
	b	LBB37_11
LBB37_11:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.15@PAGE
	add	x1, x1, l_.str.15@PAGEOFF
	adrp	x2, _k_lifetime@PAGE
	add	x2, x2, _k_lifetime@PAGEOFF
	mov	w3, #4                          ; =0x4
	add	x4, sp, #12
	bl	_parse_enum
	tbz	w0, #0, LBB37_14
	b	LBB37_12
LBB37_12:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	adrp	x2, _k_mutability@PAGE
	add	x2, x2, _k_mutability@PAGEOFF
	mov	w3, #2                          ; =0x2
	add	x4, sp, #8
	bl	_parse_enum
	tbz	w0, #0, LBB37_14
	b	LBB37_13
LBB37_13:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	adrp	x2, _k_streaming@PAGE
	add	x2, x2, _k_streaming@PAGEOFF
	mov	w3, #4                          ; =0x4
	add	x4, sp, #4
	bl	_parse_enum
	tbnz	w0, #0, LBB37_15
	b	LBB37_14
LBB37_14:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_15:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.17@PAGE
	add	x1, x1, l_.str.17@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #32]
	ldr	x0, [sp, #32]
	bl	_cJSON_IsBool
	cbnz	w0, LBB37_17
	b	LBB37_16
LBB37_16:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_17:
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldur	x8, [x29, #-24]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB37_19
	b	LBB37_18
LBB37_18:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_19:
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #24]
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #28]
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #32]
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #36]
	ldr	x0, [sp, #32]
	bl	_cJSON_IsTrue
	mov	w8, #0                          ; =0x0
	subs	w9, w0, #0
	csinc	w8, w8, wzr, eq
	ldur	x9, [x29, #-24]
	str	w8, [x9, #40]
	ldr	w8, [sp, #4]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #44]
	ldur	x8, [x29, #-24]
	ldr	w0, [x8, #24]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #44]
	bl	_streaming_matches_direction
	tbnz	w0, #0, LBB37_21
	b	LBB37_20
LBB37_20:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #16]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #16]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_21:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_22
LBB37_22:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function starts_with
_starts_with:                           ; @starts_with
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	stur	w9, [x29, #-20]                 ; 4-byte Folded Spill
	cbz	x8, LBB38_3
	b	LBB38_1
LBB38_1:
	ldur	x8, [x29, #-16]
	mov	w9, #0                          ; =0x0
	stur	w9, [x29, #-20]                 ; 4-byte Folded Spill
	cbz	x8, LBB38_3
	b	LBB38_2
LBB38_2:
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	bl	_strlen
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_strncmp
	subs	w8, w0, #0
	cset	w8, eq
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b	LBB38_3
LBB38_3:
	ldur	w8, [x29, #-20]                 ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_enum
_parse_enum:                            ; @parse_enum
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	w3, [sp, #28]
	str	x4, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB39_5
	b	LBB39_1
LBB39_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB39_5
	b	LBB39_2
LBB39_2:
	ldr	x8, [sp, #32]
	cbz	x8, LBB39_5
	b	LBB39_3
LBB39_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB39_5
	b	LBB39_4
LBB39_4:
	ldr	w8, [sp, #28]
	subs	w8, w8, #0
	b.gt	LBB39_6
	b	LBB39_5
LBB39_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_16
LBB39_6:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_cJSON_IsString
	cbz	w0, LBB39_8
	b	LBB39_7
LBB39_7:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB39_9
	b	LBB39_8
LBB39_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_16
LBB39_9:
	str	wzr, [sp, #4]
	b	LBB39_10
LBB39_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.ge	LBB39_15
	b	LBB39_11
LBB39_11:                               ;   in Loop: Header=BB39_10 Depth=1
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	ldr	x8, [sp, #32]
	ldrsw	x9, [sp, #4]
	ldr	x1, [x8, x9, lsl #3]
	bl	_strcmp
	cbnz	w0, LBB39_13
	b	LBB39_12
LBB39_12:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_16
LBB39_13:                               ;   in Loop: Header=BB39_10 Depth=1
	b	LBB39_14
LBB39_14:                               ;   in Loop: Header=BB39_10 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB39_10
LBB39_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_16
LBB39_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function streaming_matches_direction
_streaming_matches_direction:           ; @streaming_matches_direction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #24]
	str	w1, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB40_2
	b	LBB40_1
LBB40_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_14
LBB40_2:
	ldr	w8, [sp, #20]
	subs	w8, w8, #1
	b.ne	LBB40_6
	b	LBB40_3
LBB40_3:
	ldr	w8, [sp, #24]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	w8, LBB40_5
	b	LBB40_4
LBB40_4:
	ldr	w8, [sp, #24]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB40_5
LBB40_5:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_14
LBB40_6:
	ldr	w8, [sp, #20]
	subs	w8, w8, #2
	b.ne	LBB40_11
	b	LBB40_7
LBB40_7:
	ldr	w9, [sp, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB40_10
	b	LBB40_8
LBB40_8:
	ldr	w9, [sp, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB40_10
	b	LBB40_9
LBB40_9:
	ldr	w8, [sp, #24]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB40_10
LBB40_10:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_14
LBB40_11:
	ldr	w8, [sp, #20]
	subs	w8, w8, #3
	b.ne	LBB40_13
	b	LBB40_12
LBB40_12:
	ldr	w8, [sp, #24]
	subs	w8, w8, #2
	cset	w8, eq
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_14
LBB40_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_14
LBB40_14:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_type
_parse_type:                            ; @parse_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sub	x1, x29, #40
	stur	xzr, [x29, #-40]
	stur	xzr, [x29, #-32]
	str	wzr, [sp, #44]
	ldur	x0, [x29, #-16]
	bl	_parse_named
	tbnz	w0, #0, LBB41_2
	b	LBB41_1
LBB41_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_2:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #8]
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #32]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #40]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #48]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #56]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbz	x8, LBB41_5
	b	LBB41_3
LBB41_3:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	adrp	x2, _k_type_kind@PAGE
	add	x2, x2, _k_type_kind@PAGEOFF
	mov	w3, #9                          ; =0x9
	add	x4, sp, #44
	bl	_parse_enum
	tbz	w0, #0, LBB41_5
	b	LBB41_4
LBB41_4:
	ldr	w8, [sp, #44]
	cbnz	w8, LBB41_6
	b	LBB41_5
LBB41_5:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_6:
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	str	xzr, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB41_8
	b	LBB41_7
LBB41_7:
	adrp	x8, _parse_type.k_record@PAGE
	add	x8, x8, _parse_type.k_record@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #24]
	b	LBB41_21
LBB41_8:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #2
	b.ne	LBB41_10
	b	LBB41_9
LBB41_9:
	adrp	x8, _parse_type.k_variant@PAGE
	add	x8, x8, _parse_type.k_variant@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #24]
	b	LBB41_20
LBB41_10:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #3
	b.ne	LBB41_12
	b	LBB41_11
LBB41_11:
	adrp	x8, _parse_type.k_array@PAGE
	add	x8, x8, _parse_type.k_array@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #24]
	b	LBB41_19
LBB41_12:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #7
	b.ne	LBB41_14
	b	LBB41_13
LBB41_13:
	adrp	x8, _parse_type.k_callback@PAGE
	add	x8, x8, _parse_type.k_callback@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #24]
	b	LBB41_18
LBB41_14:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #8
	b.ne	LBB41_16
	b	LBB41_15
LBB41_15:
	adrp	x8, _parse_type.k_async@PAGE
	add	x8, x8, _parse_type.k_async@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #24]
	b	LBB41_17
LBB41_16:
	adrp	x8, _parse_type.k_simple@PAGE
	add	x8, x8, _parse_type.k_simple@PAGEOFF
	str	x8, [sp, #32]
	mov	x8, #3                          ; =0x3
	str	x8, [sp, #24]
	b	LBB41_17
LBB41_17:
	b	LBB41_18
LBB41_18:
	b	LBB41_19
LBB41_19:
	b	LBB41_20
LBB41_20:
	b	LBB41_21
LBB41_21:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #24]
	bl	_keys_allowed
	tbnz	w0, #0, LBB41_23
	b	LBB41_22
LBB41_22:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_23:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB41_27
	b	LBB41_24
LBB41_24:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.36@PAGE
	add	x1, x1, l_.str.36@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldur	x8, [x29, #-24]
	add	x1, x8, #24
	ldur	x8, [x29, #-24]
	add	x2, x8, #32
	mov	w3, #1                          ; =0x1
	bl	_parse_member_array
	tbnz	w0, #0, LBB41_26
	b	LBB41_25
LBB41_25:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_26:
	b	LBB41_57
LBB41_27:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #2
	b.ne	LBB41_32
	b	LBB41_28
LBB41_28:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.37@PAGE
	add	x1, x1, l_.str.37@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	ldur	x8, [x29, #-24]
	add	x1, x8, #24
	ldur	x8, [x29, #-24]
	add	x2, x8, #32
	mov	w3, #0                          ; =0x0
	bl	_parse_member_array
	tbz	w0, #0, LBB41_30
	b	LBB41_29
LBB41_29:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB41_31
	b	LBB41_30
LBB41_30:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	bl	_free_members
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #24]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #32]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_31:
	b	LBB41_56
LBB41_32:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #3
	b.ne	LBB41_39
	b	LBB41_33
LBB41_33:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.38@PAGE
	add	x1, x1, l_.str.38@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_cJSON_IsString
	cbz	w0, LBB41_35
	b	LBB41_34
LBB41_34:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #32]
	bl	_type_ref_ok
	tbnz	w0, #0, LBB41_36
	b	LBB41_35
LBB41_35:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_36:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldur	x8, [x29, #-24]
	str	x0, [x8, #40]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	cbnz	x8, LBB41_38
	b	LBB41_37
LBB41_37:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_38:
	b	LBB41_55
LBB41_39:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #7
	b.ne	LBB41_46
	b	LBB41_40
LBB41_40:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_cJSON_IsString
	cbz	w0, LBB41_42
	b	LBB41_41
LBB41_41:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_id_ascii_ok
	tbnz	w0, #0, LBB41_43
	b	LBB41_42
LBB41_42:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_43:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldur	x8, [x29, #-24]
	str	x0, [x8, #48]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB41_45
	b	LBB41_44
LBB41_44:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_45:
	b	LBB41_54
LBB41_46:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	subs	w8, w8, #8
	b.ne	LBB41_53
	b	LBB41_47
LBB41_47:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.40@PAGE
	add	x1, x1, l_.str.40@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp]
	ldr	x0, [sp]
	bl	_cJSON_IsString
	cbz	w0, LBB41_49
	b	LBB41_48
LBB41_48:
	ldr	x8, [sp]
	ldr	x0, [x8, #32]
	bl	_type_ref_ok
	tbnz	w0, #0, LBB41_50
	b	LBB41_49
LBB41_49:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_50:
	ldr	x8, [sp]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldur	x8, [x29, #-24]
	str	x0, [x8, #56]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB41_52
	b	LBB41_51
LBB41_51:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_52:
	b	LBB41_53
LBB41_53:
	b	LBB41_54
LBB41_54:
	b	LBB41_55
LBB41_55:
	b	LBB41_56
LBB41_56:
	b	LBB41_57
LBB41_57:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_58
LBB41_58:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_member_array
_parse_member_array:                    ; @parse_member_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	w3, [sp, #12]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB42_2
	b	LBB42_1
LBB42_1:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsArray
	cbnz	w0, LBB42_3
	b	LBB42_2
LBB42_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_3:
	ldur	x0, [x29, #-16]
	bl	_cJSON_GetArraySize
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	tbz	w8, #31, LBB42_5
	b	LBB42_4
LBB42_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_5:
	ldr	w8, [sp, #8]
	cbnz	w8, LBB42_7
	b	LBB42_6
LBB42_6:
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_7:
	ldrsw	x0, [sp, #8]
	mov	x1, #24                         ; =0x18
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB42_9
	b	LBB42_8
LBB42_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_9:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	str	wzr, [sp, #4]
	b	LBB42_10
LBB42_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #8]
	subs	w8, w8, w9
	b.ge	LBB42_15
	b	LBB42_11
LBB42_11:                               ;   in Loop: Header=BB42_10 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #4]
	bl	_cJSON_GetArrayItem
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldrsw	x9, [sp, #4]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	add	x1, x8, x9
	ldr	w2, [sp, #12]
	bl	_parse_member
	tbnz	w0, #0, LBB42_13
	b	LBB42_12
LBB42_12:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldrsw	x1, [sp, #4]
	bl	_free_members
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_13:                               ;   in Loop: Header=BB42_10 Depth=1
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB42_14
LBB42_14:                               ;   in Loop: Header=BB42_10 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB42_10
LBB42_15:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_16
LBB42_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_ref_ok
_type_ref_ok:                           ; @type_ref_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_id_ascii_ok
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB43_2
	b	LBB43_1
LBB43_1:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_starts_with
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB43_2
LBB43_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_member
_parse_member:                          ; @parse_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldur	x0, [x29, #-16]
	adrp	x1, _parse_member.keys@PAGE
	add	x1, x1, _parse_member.keys@PAGEOFF
	mov	x2, #3                          ; =0x3
	bl	_keys_allowed
	tbnz	w0, #0, LBB44_2
	b	LBB44_1
LBB44_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #16
	bl	_parse_named
	tbnz	w0, #0, LBB44_4
	b	LBB44_3
LBB44_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_4:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #8]
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB44_11
	b	LBB44_5
LBB44_5:
	ldr	x0, [sp, #8]
	bl	_cJSON_IsString
	cbz	w0, LBB44_7
	b	LBB44_6
LBB44_6:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_type_ref_ok
	tbnz	w0, #0, LBB44_8
	b	LBB44_7
LBB44_7:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_8:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldur	x8, [x29, #-24]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB44_10
	b	LBB44_9
LBB44_9:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_10:
	b	LBB44_14
LBB44_11:
	ldur	w8, [x29, #-28]
	cbz	w8, LBB44_13
	b	LBB44_12
LBB44_12:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	bl	_free
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	bl	_free
	ldur	x8, [x29, #-24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_13:
	b	LBB44_14
LBB44_14:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_15
LBB44_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_error
_parse_error:                           ; @parse_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	xzr, [sp, #8]
	str	xzr, [sp, #16]
	ldur	x0, [x29, #-16]
	adrp	x1, _parse_error.keys@PAGE
	add	x1, x1, _parse_error.keys@PAGEOFF
	mov	x2, #3                          ; =0x3
	bl	_keys_allowed
	tbnz	w0, #0, LBB45_2
	b	LBB45_1
LBB45_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #8
	bl	_parse_named
	tbnz	w0, #0, LBB45_4
	b	LBB45_3
LBB45_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	str	x8, [x9, #8]
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str.49@PAGE
	add	x1, x1, l_.str.49@PAGEOFF
	bl	_cJSON_GetObjectItemCaseSensitive
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB45_6
	b	LBB45_5
LBB45_5:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_6:
	ldr	x0, [sp]
	bl	_cJSON_IsString
	cbz	w0, LBB45_8
	b	LBB45_7
LBB45_7:
	ldr	x8, [sp]
	ldr	x0, [x8, #32]
	bl	_version_ok
	tbnz	w0, #0, LBB45_9
	b	LBB45_8
LBB45_8:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_9:
	ldr	x8, [sp]
	ldr	x0, [x8, #32]
	bl	_strdup
	ldr	x8, [sp, #24]
	str	x0, [x8, #16]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB45_11
	b	LBB45_10
LBB45_10:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #24]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #24]
	str	xzr, [x8, #8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_12
LBB45_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function version_ok
_version_ok:                            ; @version_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB46_2
	b	LBB46_1
LBB46_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	cbnz	w8, LBB46_3
	b	LBB46_2
LBB46_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_13
LBB46_3:
	str	xzr, [sp, #8]
	b	LBB46_4
LBB46_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB46_12
	b	LBB46_5
LBB46_5:                                ;   in Loop: Header=BB46_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #7]
	ldrb	w0, [sp, #7]
	bl	_nl_ascii_isalnum
	cbnz	w0, LBB46_10
	b	LBB46_6
LBB46_6:                                ;   in Loop: Header=BB46_4 Depth=1
	ldrb	w8, [sp, #7]
	subs	w8, w8, #46
	b.eq	LBB46_10
	b	LBB46_7
LBB46_7:                                ;   in Loop: Header=BB46_4 Depth=1
	ldrb	w8, [sp, #7]
	subs	w8, w8, #95
	b.eq	LBB46_10
	b	LBB46_8
LBB46_8:                                ;   in Loop: Header=BB46_4 Depth=1
	ldrb	w8, [sp, #7]
	subs	w8, w8, #45
	b.eq	LBB46_10
	b	LBB46_9
LBB46_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_13
LBB46_10:                               ;   in Loop: Header=BB46_4 Depth=1
	b	LBB46_11
LBB46_11:                               ;   in Loop: Header=BB46_4 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB46_4
LBB46_12:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_13
LBB46_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fragment_of_interface
_fragment_of_interface:                 ; @fragment_of_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB47_2
	b	LBB47_1
LBB47_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB47_3
	b	LBB47_2
LBB47_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_8
LBB47_3:
	ldur	x0, [x29, #-16]
	bl	_strlen
	str	x0, [sp, #16]
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldr	x2, [sp, #16]
	bl	_strncmp
	cbz	w0, LBB47_5
	b	LBB47_4
LBB47_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_8
LBB47_5:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	ldrsb	w9, [x8, x9]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #35
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB47_7
	b	LBB47_6
LBB47_6:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	add	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB47_7
LBB47_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_8
LBB47_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_bound_ok
_type_bound_ok:                         ; @type_bound_ok
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_is_core_type
	tbz	w0, #0, LBB48_2
	b	LBB48_1
LBB48_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_14
LBB48_2:
	ldr	x8, [sp, #16]
	cbz	x8, LBB48_4
	b	LBB48_3
LBB48_3:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB48_5
	b	LBB48_4
LBB48_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_14
LBB48_5:
	str	xzr, [sp]
	b	LBB48_6
LBB48_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB48_13
	b	LBB48_7
LBB48_7:                                ;   in Loop: Header=BB48_6 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp]
	lsl	x9, x9, #6
	ldr	x8, [x8, x9]
	cbz	x8, LBB48_11
	b	LBB48_8
LBB48_8:                                ;   in Loop: Header=BB48_6 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp]
	lsl	x9, x9, #6
	ldr	x0, [x8, x9]
	ldr	x1, [sp, #8]
	bl	_strcmp
	cbnz	w0, LBB48_11
	b	LBB48_9
LBB48_9:                                ;   in Loop: Header=BB48_6 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp]
	add	x8, x8, x9, lsl #6
	ldr	w8, [x8, #16]
	cbz	w8, LBB48_11
	b	LBB48_10
LBB48_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_14
LBB48_11:                               ;   in Loop: Header=BB48_6 Depth=1
	b	LBB48_12
LBB48_12:                               ;   in Loop: Header=BB48_6 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB48_6
LBB48_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_14
LBB48_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function is_core_type
_is_core_type:                          ; @is_core_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB49_8
	b	LBB49_1
LBB49_1:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.51@PAGE
	add	x1, x1, l_.str.51@PAGEOFF
	bl	_strcmp
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w0, LBB49_7
	b	LBB49_2
LBB49_2:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.52@PAGE
	add	x1, x1, l_.str.52@PAGEOFF
	bl	_strcmp
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w0, LBB49_7
	b	LBB49_3
LBB49_3:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.53@PAGE
	add	x1, x1, l_.str.53@PAGEOFF
	bl	_strcmp
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w0, LBB49_7
	b	LBB49_4
LBB49_4:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.54@PAGE
	add	x1, x1, l_.str.54@PAGEOFF
	bl	_strcmp
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w0, LBB49_7
	b	LBB49_5
LBB49_5:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.55@PAGE
	add	x1, x1, l_.str.55@PAGEOFF
	bl	_strcmp
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	cbz	w0, LBB49_7
	b	LBB49_6
LBB49_6:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.56@PAGE
	add	x1, x1, l_.str.56@PAGEOFF
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB49_7
LBB49_7:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB49_8
LBB49_8:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"rb"

l_.str.1:                               ; @.str.1
	.asciz	"nsi_version"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @nl_nsi_decode_object.root_keys
_nl_nsi_decode_object.root_keys:
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	l_.str.5
	.quad	l_.str.6

	.section	__TEXT,__cstring,cstring_literals
l_.str.2:                               ; @.str.2
	.asciz	"interface"

l_.str.3:                               ; @.str.3
	.asciz	"methods"

l_.str.4:                               ; @.str.4
	.asciz	"types"

l_.str.5:                               ; @.str.5
	.asciz	"errors"

l_.str.6:                               ; @.str.6
	.asciz	"capabilities"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @nl_nsi_decode_object.iface_keys
_nl_nsi_decode_object.iface_keys:
	.quad	l_.str.7
	.quad	l_.str.8

	.section	__TEXT,__cstring,cstring_literals
l_.str.7:                               ; @.str.7
	.asciz	"id"

l_.str.8:                               ; @.str.8
	.asciz	"name"

l_.str.9:                               ; @.str.9
	.space	1

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_method.keys
_parse_method.keys:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.10
	.quad	l_.str.11

	.section	__TEXT,__cstring,cstring_literals
l_.str.10:                              ; @.str.10
	.asciz	"params"

l_.str.11:                              ; @.str.11
	.asciz	"idempotent"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_param.keys
_parse_param.keys:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14
	.quad	l_.str.15
	.quad	l_.str.16
	.quad	l_.str.17
	.quad	l_.str.18

	.section	__TEXT,__cstring,cstring_literals
l_.str.12:                              ; @.str.12
	.asciz	"type"

l_.str.13:                              ; @.str.13
	.asciz	"direction"

l_.str.14:                              ; @.str.14
	.asciz	"ownership"

l_.str.15:                              ; @.str.15
	.asciz	"lifetime"

l_.str.16:                              ; @.str.16
	.asciz	"mutability"

l_.str.17:                              ; @.str.17
	.asciz	"optional"

l_.str.18:                              ; @.str.18
	.asciz	"streaming"

l_.str.19:                              ; @.str.19
	.asciz	"nsi:"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @k_direction
_k_direction:
	.quad	l_.str.20
	.quad	l_.str.21
	.quad	l_.str.22
	.quad	l_.str.23

	.p2align	3, 0x0                          ; @k_ownership
_k_ownership:
	.quad	l_.str.24
	.quad	l_.str.25
	.quad	l_.str.26

	.p2align	3, 0x0                          ; @k_lifetime
_k_lifetime:
	.quad	l_.str.27
	.quad	l_.str.28
	.quad	l_.str.29
	.quad	l_.str.30

	.p2align	3, 0x0                          ; @k_mutability
_k_mutability:
	.quad	l_.str.31
	.quad	l_.str.32

	.p2align	3, 0x0                          ; @k_streaming
_k_streaming:
	.quad	l_.str.33
	.quad	l_.str.20
	.quad	l_.str.21
	.quad	l_.str.34

	.section	__TEXT,__cstring,cstring_literals
l_.str.20:                              ; @.str.20
	.asciz	"in"

l_.str.21:                              ; @.str.21
	.asciz	"out"

l_.str.22:                              ; @.str.22
	.asciz	"inout"

l_.str.23:                              ; @.str.23
	.asciz	"return"

l_.str.24:                              ; @.str.24
	.asciz	"borrow"

l_.str.25:                              ; @.str.25
	.asciz	"transfer"

l_.str.26:                              ; @.str.26
	.asciz	"copy"

l_.str.27:                              ; @.str.27
	.asciz	"call"

l_.str.28:                              ; @.str.28
	.asciz	"caller"

l_.str.29:                              ; @.str.29
	.asciz	"callee"

l_.str.30:                              ; @.str.30
	.asciz	"resource"

l_.str.31:                              ; @.str.31
	.asciz	"immutable"

l_.str.32:                              ; @.str.32
	.asciz	"mutable"

l_.str.33:                              ; @.str.33
	.asciz	"none"

l_.str.34:                              ; @.str.34
	.asciz	"bidi"

l_.str.35:                              ; @.str.35
	.asciz	"kind"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @k_type_kind
_k_type_kind:
	.quad	l_.str.41
	.quad	l_.str.42
	.quad	l_.str.43
	.quad	l_.str.44
	.quad	l_.str.45
	.quad	l_.str.46
	.quad	l_.str.30
	.quad	l_.str.47
	.quad	l_.str.48

	.p2align	3, 0x0                          ; @parse_type.k_record
_parse_type.k_record:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35
	.quad	l_.str.36

	.section	__TEXT,__cstring,cstring_literals
l_.str.36:                              ; @.str.36
	.asciz	"fields"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_type.k_variant
_parse_type.k_variant:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35
	.quad	l_.str.37

	.section	__TEXT,__cstring,cstring_literals
l_.str.37:                              ; @.str.37
	.asciz	"cases"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_type.k_array
_parse_type.k_array:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35
	.quad	l_.str.38

	.section	__TEXT,__cstring,cstring_literals
l_.str.38:                              ; @.str.38
	.asciz	"element"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_type.k_simple
_parse_type.k_simple:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35

	.p2align	3, 0x0                          ; @parse_type.k_callback
_parse_type.k_callback:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35
	.quad	l_.str.39

	.section	__TEXT,__cstring,cstring_literals
l_.str.39:                              ; @.str.39
	.asciz	"method"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_type.k_async
_parse_type.k_async:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.35
	.quad	l_.str.40

	.section	__TEXT,__cstring,cstring_literals
l_.str.40:                              ; @.str.40
	.asciz	"result"

l_.str.41:                              ; @.str.41
	.asciz	"opaque"

l_.str.42:                              ; @.str.42
	.asciz	"record"

l_.str.43:                              ; @.str.43
	.asciz	"variant"

l_.str.44:                              ; @.str.44
	.asciz	"array"

l_.str.45:                              ; @.str.45
	.asciz	"string"

l_.str.46:                              ; @.str.46
	.asciz	"binary"

l_.str.47:                              ; @.str.47
	.asciz	"callback"

l_.str.48:                              ; @.str.48
	.asciz	"async"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_member.keys
_parse_member.keys:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.12

	.p2align	3, 0x0                          ; @parse_error.keys
_parse_error.keys:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.49

	.section	__TEXT,__cstring,cstring_literals
l_.str.49:                              ; @.str.49
	.asciz	"version"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @parse_named_array.keys
_parse_named_array.keys:
	.quad	l_.str.7
	.quad	l_.str.8

	.section	__TEXT,__cstring,cstring_literals
l_.str.50:                              ; @.str.50
	.asciz	"cap:"

l_.str.51:                              ; @.str.51
	.asciz	"nsi:core/string"

l_.str.52:                              ; @.str.52
	.asciz	"nsi:core/int"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:core/bool"

l_.str.54:                              ; @.str.54
	.asciz	"nsi:core/unit"

l_.str.55:                              ; @.str.55
	.asciz	"nsi:core/bytes"

l_.str.56:                              ; @.str.56
	.asciz	"nsi:core/float"

.subsections_via_symbols
