	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_private_from_module        ; -- Begin function nvm_private_from_module
	.p2align	2
_nvm_private_from_module:               ; @nvm_private_from_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #336
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #48
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [x8, #16]
	str	x1, [x8, #8]
	str	x2, [x8]
	ldr	x0, [x8, #16]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB0_7
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbnz	x8, LBB0_3
	b	LBB0_2
LBB0_2:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB0_8
LBB0_3:
	add	x0, sp, #24
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x2, #248                        ; =0xf8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	x2, [x8]
	bl	_nvm_from_module_core
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB0_5
	b	LBB0_4
LBB0_4:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	add	x1, sp, #24
	mov	x2, #248                        ; =0xf8
	bl	_memcpy
	b	LBB0_6
LBB0_5:
	add	x0, sp, #24
	bl	_nvm_v2_module_free
	b	LBB0_6
LBB0_6:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-20]
	b	LBB0_8
LBB0_7:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	x1, [x8, #8]
	ldr	x2, [x8]
	bl	_nvm_from_module_core
	stur	w0, [x29, #-20]
	b	LBB0_8
LBB0_8:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_map_selected
_nvm_record_map_selected:               ; @nvm_record_map_selected
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB1_3
	b	LBB1_1
LBB1_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB1_3
	b	LBB1_2
LBB1_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB1_3
LBB1_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_from_module_core
_nvm_from_module_core:                  ; @nvm_from_module_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #680]
	str	x1, [sp, #672]
	str	x2, [sp, #664]
	ldr	x8, [sp, #680]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x8, [sp, #672]
	cbnz	x8, LBB2_3
	b	LBB2_2
LBB2_2:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_3:
	ldr	x0, [sp, #672]
	mov	w1, #0                          ; =0x0
	mov	x2, #248                        ; =0xf8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x9, [sp, #672]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9]
	ldr	x0, [sp, #680]
	ldr	x1, [sp, #664]
	bl	_nvm_private_service_module
	str	w0, [sp, #660]
	ldr	w8, [sp, #660]
	cbz	w8, LBB2_5
	b	LBB2_4
LBB2_4:
	ldr	w8, [sp, #660]
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_5:
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #328]
	ldr	x9, [sp, #672]
	str	x8, [x9, #216]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #336]
	ldr	x9, [sp, #672]
	str	w8, [x9, #224]
	strb	wzr, [sp, #659]
	ldr	x0, [sp, #680]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	strb	w0, [sp, #659]
	ldr	x0, [sp, #680]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB2_11
	b	LBB2_6
LBB2_6:
	ldr	x0, [sp, #680]
	bl	_nvm_callback_contracts_valid
	tbz	w0, #0, LBB2_11
	b	LBB2_7
LBB2_7:
	ldr	x0, [sp, #680]
	bl	_nvm_passive_valid
	tbz	w0, #0, LBB2_11
	b	LBB2_8
LBB2_8:
	ldrb	w8, [sp, #659]
	tbnz	w8, #0, LBB2_12
	b	LBB2_9
LBB2_9:
	ldr	x0, [sp, #680]
	bl	_nvm_record_array_candidate
	tbnz	w0, #0, LBB2_12
	b	LBB2_10
LBB2_10:
	ldr	x0, [sp, #680]
	bl	_nvm_retained_layouts_valid
	tbnz	w0, #0, LBB2_12
	b	LBB2_11
LBB2_11:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_12:
	strb	wzr, [sp, #658]
	ldr	x0, [sp, #680]
	bl	_nvm_owned_array_route
	subs	w8, w0, #0
	cset	w8, ne
	strb	w8, [sp, #657]
	ldrb	w8, [sp, #659]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #180]                  ; 4-byte Folded Spill
	tbnz	w8, #0, LBB2_16
	b	LBB2_13
LBB2_13:
	ldrb	w8, [sp, #657]
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #180]                  ; 4-byte Folded Spill
	tbnz	w8, #0, LBB2_16
	b	LBB2_14
LBB2_14:
	ldr	x0, [sp, #680]
	bl	_nvm_mixed_samples_candidate
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #180]                  ; 4-byte Folded Spill
	tbnz	w0, #0, LBB2_16
	b	LBB2_15
LBB2_15:
	ldr	x0, [sp, #680]
	bl	_nvm_record_array_candidate
	str	w0, [sp, #180]                  ; 4-byte Folded Spill
	b	LBB2_16
LBB2_16:
	ldr	w8, [sp, #180]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #656]
	add	x0, sp, #1880
	mov	x1, #512                        ; =0x200
	bl	_bzero
	add	x0, sp, #952
	mov	x1, #928                        ; =0x3a0
	bl	_bzero
	ldr	x8, [sp, #680]
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #656]
	tbz	w8, #0, LBB2_18
	b	LBB2_17
LBB2_17:
	add	x8, sp, #1880
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	b	LBB2_19
LBB2_18:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	b	LBB2_19
LBB2_19:
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #657]
	tbz	w8, #0, LBB2_21
	b	LBB2_20
LBB2_20:
	add	x8, sp, #952
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	b	LBB2_22
LBB2_21:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	b	LBB2_22
LBB2_22:
	ldr	x2, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x4, [sp, #664]
	add	x1, sp, #658
	bl	_conversion_ownership
	str	w0, [sp, #652]
	ldr	w8, [sp, #652]
	cbz	w8, LBB2_24
	b	LBB2_23
LBB2_23:
	ldr	w8, [sp, #652]
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_24:
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #296]
	ldr	x9, [sp, #672]
	str	x8, [x9, #184]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #304]
	ldr	x9, [sp, #672]
	str	w8, [x9, #192]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #344]
	ldr	x9, [sp, #672]
	str	x8, [x9, #200]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #352]
	ldr	x9, [sp, #672]
	str	w8, [x9, #208]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #272]
	str	w8, [sp, #648]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #432]
	str	w8, [sp, #644]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #424]
	str	w8, [sp, #640]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #448]
	str	w8, [sp, #636]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #384]
	str	w8, [sp, #632]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #392]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #140]                  ; 4-byte Folded Spill
	cbz	w8, LBB2_26
	b	LBB2_25
LBB2_25:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #392]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB2_26
LBB2_26:
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	strb	wzr, [sp, #630]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #624]
	str	wzr, [sp, #620]
	b	LBB2_27
LBB2_27:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #620]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB2_32
	b	LBB2_28
LBB2_28:                                ;   in Loop: Header=BB2_27 Depth=1
	ldr	x0, [sp, #680]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #620]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	w1, [x8, x9]
	bl	_nvm_metadata_source_key
	tbz	w0, #0, LBB2_30
	b	LBB2_29
LBB2_29:                                ;   in Loop: Header=BB2_27 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #630]
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_27 Depth=1
	b	LBB2_31
LBB2_31:                                ;   in Loop: Header=BB2_27 Depth=1
	ldr	w8, [sp, #620]
	add	w8, w8, #1
	str	w8, [sp, #620]
	b	LBB2_27
LBB2_32:
	ldrb	w8, [sp, #631]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #136]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_34
	b	LBB2_33
LBB2_33:
	ldrb	w8, [sp, #630]
	eor	w8, w8, #0x1
	str	w8, [sp, #136]                  ; 4-byte Folded Spill
	b	LBB2_34
LBB2_34:
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #619]
	ldrb	w8, [sp, #619]
	tbz	w8, #0, LBB2_42
	b	LBB2_35
LBB2_35:
	str	wzr, [sp, #612]
	b	LBB2_36
LBB2_36:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #612]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB2_41
	b	LBB2_37
LBB2_37:                                ;   in Loop: Header=BB2_36 Depth=1
	ldr	x0, [sp, #680]
	ldr	w1, [sp, #612]
	bl	_nvm_metadata_source_key
	tbz	w0, #0, LBB2_39
	b	LBB2_38
LBB2_38:
	ldr	w8, [sp, #612]
	str	w8, [sp, #624]
	b	LBB2_41
LBB2_39:                                ;   in Loop: Header=BB2_36 Depth=1
	b	LBB2_40
LBB2_40:                                ;   in Loop: Header=BB2_36 Depth=1
	ldr	w8, [sp, #612]
	add	w8, w8, #1
	str	w8, [sp, #612]
	b	LBB2_36
LBB2_41:
	b	LBB2_42
LBB2_42:
	ldrb	w8, [sp, #619]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #132]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_44
	b	LBB2_43
LBB2_43:
	ldr	w8, [sp, #624]
	adds	w8, w8, #1
	cset	w8, eq
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	b	LBB2_44
LBB2_44:
	ldr	w8, [sp, #132]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #611]
	ldrb	w8, [sp, #611]
	tbz	w8, #0, LBB2_47
	b	LBB2_45
LBB2_45:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #248]
	adds	w8, w8, #1
	b.ne	LBB2_47
	b	LBB2_46
LBB2_46:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_47:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #248]
	ldrb	w10, [sp, #611]
	mov	w9, #0                          ; =0x0
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csinc	w9, w9, wzr, eq
	add	w8, w8, w9
	str	w8, [sp, #604]
	ldr	w8, [sp, #604]
	cbz	w8, LBB2_49
	b	LBB2_48
LBB2_48:
	ldr	w8, [sp, #604]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	b	LBB2_50
LBB2_49:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	b	LBB2_50
LBB2_50:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	str	x8, [sp, #592]
	ldr	w8, [sp, #604]
	cbz	w8, LBB2_53
	b	LBB2_51
LBB2_51:
	ldr	x8, [sp, #592]
	cbnz	x8, LBB2_53
	b	LBB2_52
LBB2_52:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_53:
	str	wzr, [sp, #588]
	b	LBB2_54
LBB2_54:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #588]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB2_60
	b	LBB2_55
LBB2_55:                                ;   in Loop: Header=BB2_54 Depth=1
	ldr	x8, [sp, #592]
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #5                          ; =0x5
	strb	w8, [x9]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #240]
	cbz	x8, LBB2_57
	b	LBB2_56
LBB2_56:                                ;   in Loop: Header=BB2_54 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
	b	LBB2_58
LBB2_57:                                ;   in Loop: Header=BB2_54 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
	b	LBB2_58
LBB2_58:                                ;   in Loop: Header=BB2_54 Depth=1
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	ldr	x9, [sp, #592]
	ldr	w10, [sp, #588]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #4]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #592]
	ldr	w10, [sp, #588]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x8, [x9, #8]
	b	LBB2_59
LBB2_59:                                ;   in Loop: Header=BB2_54 Depth=1
	ldr	w8, [sp, #588]
	add	w8, w8, #1
	str	w8, [sp, #588]
	b	LBB2_54
LBB2_60:
	ldrb	w8, [sp, #611]
	tbz	w8, #0, LBB2_62
	b	LBB2_61
LBB2_61:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #248]
	str	w8, [sp, #624]
	ldr	x8, [sp, #592]
	ldr	w9, [sp, #624]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #5                          ; =0x5
	strb	w8, [x9]
	ldr	x8, [sp, #592]
	ldr	w9, [sp, #624]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #16                         ; =0x10
	str	w8, [x9, #4]
	ldr	x8, [sp, #592]
	ldr	w9, [sp, #624]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	adrp	x8, _SOURCE_FILE_KEY@PAGE
	add	x8, x8, _SOURCE_FILE_KEY@PAGEOFF
	str	x8, [x9, #8]
	b	LBB2_62
LBB2_62:
	ldr	x8, [sp, #592]
	ldr	x9, [sp, #672]
	str	x8, [x9, #24]
	ldr	w8, [sp, #604]
	ldr	x9, [sp, #672]
	str	w8, [x9, #32]
	str	xzr, [sp, #576]
	str	wzr, [sp, #572]
	b	LBB2_63
LBB2_63:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #572]
	ldr	w9, [sp, #648]
	subs	w8, w8, w9
	b.hs	LBB2_66
	b	LBB2_64
LBB2_64:                                ;   in Loop: Header=BB2_63 Depth=1
	ldr	x8, [sp, #680]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #572]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldrh	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #680]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #572]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #21]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	ldr	x8, [sp, #576]
	add	x8, x8, x9
	str	x8, [sp, #576]
	b	LBB2_65
LBB2_65:                                ;   in Loop: Header=BB2_63 Depth=1
	ldr	w8, [sp, #572]
	add	w8, w8, #1
	str	w8, [sp, #572]
	b	LBB2_63
LBB2_66:
	str	wzr, [sp, #568]
	b	LBB2_67
LBB2_67:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #568]
	ldr	w9, [sp, #644]
	subs	w8, w8, w9
	b.hs	LBB2_70
	b	LBB2_68
LBB2_68:                                ;   in Loop: Header=BB2_67 Depth=1
	ldr	x8, [sp, #680]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #568]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x9, x8, #1
	ldr	x8, [sp, #576]
	add	x8, x8, x9
	str	x8, [sp, #576]
	b	LBB2_69
LBB2_69:                                ;   in Loop: Header=BB2_67 Depth=1
	ldr	w8, [sp, #568]
	add	w8, w8, #1
	str	w8, [sp, #568]
	b	LBB2_67
LBB2_70:
	str	wzr, [sp, #564]
	b	LBB2_71
LBB2_71:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #564]
	ldr	w9, [sp, #640]
	subs	w8, w8, w9
	b.hs	LBB2_74
	b	LBB2_72
LBB2_72:                                ;   in Loop: Header=BB2_71 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #416]
	ldr	w9, [sp, #564]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	add	x9, x8, #1
	ldr	x8, [sp, #576]
	add	x8, x8, x9
	str	x8, [sp, #576]
	b	LBB2_73
LBB2_73:                                ;   in Loop: Header=BB2_71 Depth=1
	ldr	w8, [sp, #564]
	add	w8, w8, #1
	str	w8, [sp, #564]
	b	LBB2_71
LBB2_74:
	ldr	x8, [sp, #576]
	cbz	x8, LBB2_76
	b	LBB2_75
LBB2_75:
	ldr	x0, [sp, #576]
	mov	x1, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #104]                  ; 8-byte Folded Spill
	b	LBB2_77
LBB2_76:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	b	LBB2_77
LBB2_77:
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	str	x8, [sp, #552]
	ldr	x8, [sp, #576]
	cbz	x8, LBB2_80
	b	LBB2_78
LBB2_78:
	ldr	x8, [sp, #552]
	cbnz	x8, LBB2_80
	b	LBB2_79
LBB2_79:
	b	LBB2_233
LBB2_80:
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #672]
	str	x8, [x9, #232]
	str	xzr, [sp, #544]
	ldr	w8, [sp, #648]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #644]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #640]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB2_82
	b	LBB2_81
LBB2_81:
	b	LBB2_233
LBB2_82:
	ldr	w8, [sp, #648]
	ldr	w9, [sp, #644]
	add	w8, w8, w9
	ldr	w9, [sp, #640]
	add	w8, w8, w9
	str	w8, [sp, #540]
	ldr	w8, [sp, #540]
	cbz	w8, LBB2_84
	b	LBB2_83
LBB2_83:
	ldr	w8, [sp, #540]
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	str	x0, [sp, #96]                   ; 8-byte Folded Spill
	b	LBB2_85
LBB2_84:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	b	LBB2_85
LBB2_85:
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	str	x8, [sp, #528]
	ldr	w8, [sp, #540]
	cbz	w8, LBB2_88
	b	LBB2_86
LBB2_86:
	ldr	x8, [sp, #528]
	cbnz	x8, LBB2_88
	b	LBB2_87
LBB2_87:
	b	LBB2_233
LBB2_88:
	ldr	x8, [sp, #528]
	ldr	x9, [sp, #672]
	str	x8, [x9, #40]
	ldr	x8, [sp, #672]
	str	wzr, [x8, #48]
	ldr	w8, [sp, #648]
	cbz	w8, LBB2_90
	b	LBB2_89
LBB2_89:
	ldr	w8, [sp, #648]
	mov	x0, x8
	mov	x1, #32                         ; =0x20
	bl	_calloc
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB2_91
LBB2_90:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB2_91
LBB2_91:
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	str	x8, [sp, #520]
	ldr	w8, [sp, #648]
	cbz	w8, LBB2_94
	b	LBB2_92
LBB2_92:
	ldr	x8, [sp, #520]
	cbnz	x8, LBB2_94
	b	LBB2_93
LBB2_93:
	b	LBB2_233
LBB2_94:
	ldr	x8, [sp, #520]
	ldr	x9, [sp, #672]
	str	x8, [x9, #72]
	ldr	w8, [sp, #648]
	ldr	x9, [sp, #672]
	str	w8, [x9, #80]
	str	wzr, [sp, #516]
	b	LBB2_95
LBB2_95:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_101 Depth 2
	ldr	w8, [sp, #516]
	ldr	w9, [sp, #648]
	subs	w8, w8, w9
	b.hs	LBB2_124
	b	LBB2_96
LBB2_96:                                ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #680]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #516]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #504]
	ldr	x8, [sp, #544]
	str	x8, [sp, #496]
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB2_98
	b	LBB2_97
LBB2_97:                                ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	b	LBB2_99
LBB2_98:                                ;   in Loop: Header=BB2_95 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	b	LBB2_99
LBB2_99:                                ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x8, [sp, #488]
	ldrb	w8, [sp, #657]
	tbz	w8, #0, LBB2_105
	b	LBB2_100
LBB2_100:                               ;   in Loop: Header=BB2_95 Depth=1
	strh	wzr, [sp, #486]
	b	LBB2_101
LBB2_101:                               ;   Parent Loop BB2_95 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #486]
	ldr	x9, [sp, #504]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB2_104
	b	LBB2_102
LBB2_102:                               ;   in Loop: Header=BB2_101 Depth=2
	ldr	w8, [sp, #516]
                                        ; kill: def $x8 killed $w8
	mov	x9, #116                        ; =0x74
	add	x10, sp, #952
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x10, x8, #20
	ldrh	w8, [sp, #486]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	ldr	x9, [sp, #552]
	ldr	x10, [sp, #544]
	ldrh	w11, [sp, #486]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB2_103
LBB2_103:                               ;   in Loop: Header=BB2_101 Depth=2
	ldrh	w8, [sp, #486]
	add	w8, w8, #1
	strh	w8, [sp, #486]
	b	LBB2_101
LBB2_104:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_113
LBB2_105:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB2_109
	b	LBB2_106
LBB2_106:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #264]
	cbz	x8, LBB2_109
	b	LBB2_107
LBB2_107:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB2_109
	b	LBB2_108
LBB2_108:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_112
LBB2_109:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB2_111
	b	LBB2_110
LBB2_110:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB2_111
LBB2_111:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_112
LBB2_112:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_113
LBB2_113:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	mov	x9, x8
	ldr	x8, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #544]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #472]
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB2_115
	b	LBB2_114
LBB2_114:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #472]
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #504]
	ldrb	w1, [x8, #20]
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #21]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #21]
	mov	x9, x8
	ldr	x8, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #544]
	b	LBB2_115
LBB2_115:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	add	x1, sp, #448
	strh	w8, [sp, #448]
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #21]
	strh	w8, [sp, #450]
	str	wzr, [sp, #452]
	ldr	x8, [sp, #488]
	str	x8, [sp, #456]
	ldr	x8, [sp, #472]
	str	x8, [sp, #464]
	ldr	x8, [sp, #672]
	add	x0, x8, #40
	ldr	x3, [sp, #496]
	add	x2, sp, #544
	bl	_intern_signature
	ldr	x8, [sp, #520]
	ldr	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	w0, [x8, #4]
	ldr	x8, [sp, #504]
	ldr	w8, [x8]
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #5
	str	w8, [x9, x10]
	ldr	x8, [sp, #504]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	str	x8, [x9, #8]
	ldr	x8, [sp, #504]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	str	x8, [x9, #16]
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	strh	w8, [x9, #24]
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #18]
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	strh	w8, [x9, #26]
	strh	wzr, [sp, #446]
	ldrb	w8, [sp, #656]
	tbz	w8, #0, LBB2_117
	b	LBB2_116
LBB2_116:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #516]
	mov	x9, x8
	add	x8, sp, #1880
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	strh	w8, [x9, #28]
	b	LBB2_122
LBB2_117:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x0, [sp, #680]
	bl	_nvm_service_bindings_present
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB2_119
	b	LBB2_118
LBB2_118:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	x0, [sp, #680]
	ldr	w1, [sp, #516]
	add	x8, sp, #695
	add	x2, sp, #446
	bl	_nvm_verify_function_max_stack
	ldrb	w8, [sp, #695]
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	b	LBB2_119
LBB2_119:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #76]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB2_121
	b	LBB2_120
LBB2_120:                               ;   in Loop: Header=BB2_95 Depth=1
	ldrh	w8, [sp, #446]
	ldr	x9, [sp, #520]
	ldr	w10, [sp, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	strh	w8, [x9, #28]
	b	LBB2_121
LBB2_121:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_122
LBB2_122:                               ;   in Loop: Header=BB2_95 Depth=1
	b	LBB2_123
LBB2_123:                               ;   in Loop: Header=BB2_95 Depth=1
	ldr	w8, [sp, #516]
	add	w8, w8, #1
	str	w8, [sp, #516]
	b	LBB2_95
LBB2_124:
	ldr	w8, [sp, #644]
	cbz	w8, LBB2_126
	b	LBB2_125
LBB2_125:
	ldr	w8, [sp, #644]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	b	LBB2_127
LBB2_126:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	b	LBB2_127
LBB2_127:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #432]
	ldr	w8, [sp, #644]
	cbz	w8, LBB2_130
	b	LBB2_128
LBB2_128:
	ldr	x8, [sp, #432]
	cbnz	x8, LBB2_130
	b	LBB2_129
LBB2_129:
	b	LBB2_233
LBB2_130:
	ldr	x8, [sp, #432]
	ldr	x9, [sp, #672]
	str	x8, [x9, #104]
	ldr	w8, [sp, #644]
	ldr	x9, [sp, #672]
	str	w8, [x9, #112]
	str	wzr, [sp, #428]
	b	LBB2_131
LBB2_131:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #428]
	ldr	w9, [sp, #644]
	subs	w8, w8, w9
	b.hs	LBB2_142
	b	LBB2_132
LBB2_132:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #680]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #428]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #416]
	ldr	x8, [sp, #544]
	str	x8, [sp, #408]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #400]
	ldr	x8, [sp, #416]
	ldrh	w8, [x8, #8]
	cbz	w8, LBB2_138
	b	LBB2_133
LBB2_133:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #400]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #408]
	cbz	x8, LBB2_136
	b	LBB2_134
LBB2_134:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #428]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB2_136
	b	LBB2_135
LBB2_135:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #408]
	ldr	w9, [sp, #428]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldr	x8, [sp, #416]
	ldrh	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_137
LBB2_136:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #416]
	ldrh	w8, [x8, #8]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB2_137
LBB2_137:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #416]
	ldrh	w8, [x8, #8]
	mov	x9, x8
	ldr	x8, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #544]
	b	LBB2_138
LBB2_138:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #416]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #0
	cset	w8, ne
	strh	w8, [sp, #398]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #384]
	ldrh	w8, [sp, #398]
	cbz	w8, LBB2_140
	b	LBB2_139
LBB2_139:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #384]
	ldr	x8, [sp, #416]
	ldrb	w8, [x8, #10]
	ldr	x9, [sp, #552]
	ldr	x10, [sp, #544]
	add	x11, x10, #1
	str	x11, [sp, #544]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB2_140
LBB2_140:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #416]
	ldrh	w8, [x8, #8]
	add	x1, sp, #360
	strh	w8, [sp, #360]
	ldrh	w8, [sp, #398]
	strh	w8, [sp, #362]
	str	wzr, [sp, #364]
	ldr	x8, [sp, #400]
	str	x8, [sp, #368]
	ldr	x8, [sp, #384]
	str	x8, [sp, #376]
	ldr	x8, [sp, #672]
	add	x0, x8, #40
	ldr	x3, [sp, #408]
	add	x2, sp, #544
	bl	_intern_signature
	ldr	x8, [sp, #432]
	ldr	w9, [sp, #428]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	w0, [x8, #8]
	ldr	x8, [sp, #416]
	ldr	w8, [x8]
	ldr	x9, [sp, #432]
	ldr	w10, [sp, #428]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	str	w8, [x9, x10]
	ldr	x8, [sp, #416]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #432]
	ldr	w10, [sp, #428]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #4]
	ldr	x8, [sp, #680]
	ldr	x10, [x8, #400]
	ldr	w8, [sp, #428]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #11]
	ldr	x9, [sp, #432]
	ldr	w10, [sp, #428]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	strb	w8, [x9, #12]
	b	LBB2_141
LBB2_141:                               ;   in Loop: Header=BB2_131 Depth=1
	ldr	w8, [sp, #428]
	add	w8, w8, #1
	str	w8, [sp, #428]
	b	LBB2_131
LBB2_142:
	ldr	w8, [sp, #640]
	cbz	w8, LBB2_144
	b	LBB2_143
LBB2_143:
	ldr	w8, [sp, #640]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB2_145
LBB2_144:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB2_145
LBB2_145:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #672]
	str	x8, [x9, #120]
	ldr	w8, [sp, #640]
	cbz	w8, LBB2_148
	b	LBB2_146
LBB2_146:
	ldr	x8, [sp, #672]
	ldr	x8, [x8, #120]
	cbnz	x8, LBB2_148
	b	LBB2_147
LBB2_147:
	b	LBB2_233
LBB2_148:
	ldr	w8, [sp, #640]
	ldr	x9, [sp, #672]
	str	w8, [x9, #128]
	str	wzr, [sp, #356]
	b	LBB2_149
LBB2_149:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #356]
	ldr	w9, [sp, #640]
	subs	w8, w8, w9
	b.hs	LBB2_164
	b	LBB2_150
LBB2_150:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #416]
	ldr	w9, [sp, #356]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #344]
	ldr	x8, [sp, #672]
	ldr	x8, [x8, #120]
	ldr	w9, [sp, #356]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #336]
	ldr	x8, [sp, #344]
	ldr	w8, [x8]
	ldr	x9, [sp, #336]
	str	w8, [x9]
	ldr	x8, [sp, #344]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #336]
	str	w8, [x9, #12]
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #336]
	strh	w8, [x9, #4]
	ldr	x8, [sp, #344]
	ldrb	w8, [x8, #10]
	ldr	x9, [sp, #336]
	strb	w8, [x9, #6]
	ldr	x8, [sp, #344]
	ldrb	w8, [x8, #11]
	ldr	x9, [sp, #336]
	strb	w8, [x9, #7]
	ldr	x9, [sp, #336]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #8]
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #8]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB2_162
	b	LBB2_151
LBB2_151:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #544]
	str	x8, [sp, #328]
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #12]
	cbz	w8, LBB2_153
	b	LBB2_152
LBB2_152:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB2_154
LBB2_153:                               ;   in Loop: Header=BB2_149 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB2_154
LBB2_154:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #320]
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #12]
	cbz	w8, LBB2_156
	b	LBB2_155
LBB2_155:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x0, x8, x9
	ldr	x8, [sp, #344]
	add	x1, x8, #15
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #12]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB2_156
LBB2_156:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #12]
	mov	x9, x8
	ldr	x8, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #544]
	ldr	x8, [sp, #344]
	ldrb	w8, [x8, #14]
	subs	w8, w8, #0
	cset	w8, ne
	strh	w8, [sp, #318]
	ldrh	w8, [sp, #318]
	cbz	w8, LBB2_158
	b	LBB2_157
LBB2_157:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #552]
	ldr	x9, [sp, #544]
	add	x8, x8, x9
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB2_159
LBB2_158:                               ;   in Loop: Header=BB2_149 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB2_159
LBB2_159:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x8, [sp, #304]
	ldrh	w8, [sp, #318]
	cbz	w8, LBB2_161
	b	LBB2_160
LBB2_160:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #344]
	ldrb	w8, [x8, #14]
	ldr	x9, [sp, #552]
	ldr	x10, [sp, #544]
	add	x11, x10, #1
	str	x11, [sp, #544]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB2_161
LBB2_161:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	x8, [sp, #344]
	ldrh	w8, [x8, #12]
	add	x1, sp, #280
	strh	w8, [sp, #280]
	ldrh	w8, [sp, #318]
	strh	w8, [sp, #282]
	str	wzr, [sp, #284]
	ldr	x8, [sp, #320]
	str	x8, [sp, #288]
	ldr	x8, [sp, #304]
	str	x8, [sp, #296]
	ldr	x8, [sp, #672]
	add	x0, x8, #40
	ldr	x3, [sp, #328]
	add	x2, sp, #544
	bl	_intern_signature
	ldr	x8, [sp, #336]
	str	w0, [x8, #8]
	b	LBB2_162
LBB2_162:                               ;   in Loop: Header=BB2_149 Depth=1
	b	LBB2_163
LBB2_163:                               ;   in Loop: Header=BB2_149 Depth=1
	ldr	w8, [sp, #356]
	add	w8, w8, #1
	str	w8, [sp, #356]
	b	LBB2_149
LBB2_164:
	ldr	w8, [sp, #636]
	cbz	w8, LBB2_166
	b	LBB2_165
LBB2_165:
	ldr	w8, [sp, #636]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB2_167
LBB2_166:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB2_167
LBB2_167:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #272]
	ldr	w8, [sp, #636]
	cbz	w8, LBB2_170
	b	LBB2_168
LBB2_168:
	ldr	x8, [sp, #272]
	cbnz	x8, LBB2_170
	b	LBB2_169
LBB2_169:
	b	LBB2_233
LBB2_170:
	str	wzr, [sp, #268]
	b	LBB2_171
LBB2_171:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #268]
	ldr	w9, [sp, #636]
	subs	w8, w8, w9
	b.hs	LBB2_174
	b	LBB2_172
LBB2_172:                               ;   in Loop: Header=BB2_171 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #440]
	ldr	w9, [sp, #268]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #272]
	ldr	w10, [sp, #268]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	str	w8, [x9, x10]
	ldr	x8, [sp, #272]
	ldr	w9, [sp, #268]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	ldr	x9, [sp, #272]
	ldr	w10, [sp, #268]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #8]
	ldr	x8, [sp, #272]
	ldr	w9, [sp, #268]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	wzr, [x8, #12]
	b	LBB2_173
LBB2_173:                               ;   in Loop: Header=BB2_171 Depth=1
	ldr	w8, [sp, #268]
	add	w8, w8, #1
	str	w8, [sp, #268]
	b	LBB2_171
LBB2_174:
	ldr	x8, [sp, #272]
	ldr	x9, [sp, #672]
	str	x8, [x9, #136]
	ldr	w8, [sp, #636]
	ldr	x9, [sp, #672]
	str	w8, [x9, #144]
	ldr	w8, [sp, #632]
	cbz	w8, LBB2_176
	b	LBB2_175
LBB2_175:
	ldr	w8, [sp, #632]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB2_177
LBB2_176:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB2_177
LBB2_177:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #256]
	ldr	w8, [sp, #632]
	cbz	w8, LBB2_180
	b	LBB2_178
LBB2_178:
	ldr	x8, [sp, #256]
	cbnz	x8, LBB2_180
	b	LBB2_179
LBB2_179:
	b	LBB2_233
LBB2_180:
	str	wzr, [sp, #252]
	b	LBB2_181
LBB2_181:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #252]
	ldr	w9, [sp, #632]
	subs	w8, w8, w9
	b.hs	LBB2_184
	b	LBB2_182
LBB2_182:                               ;   in Loop: Header=BB2_181 Depth=1
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #376]
	ldr	w9, [sp, #252]
	mov	x10, x9
	mov	x9, #12                         ; =0xc
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w8, [x8, x10]
                                        ; kill: def $x8 killed $w8
	ldr	x10, [sp, #256]
	ldr	w11, [sp, #252]
                                        ; kill: def $x11 killed $w11
	lsl	x11, x11, #4
	str	x8, [x10, x11]
	ldr	x8, [sp, #680]
	ldr	x11, [x8, #376]
	ldr	w8, [sp, #252]
                                        ; kill: def $x8 killed $w8
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w8, [x8, #4]
	ldr	x10, [sp, #256]
	ldr	w11, [sp, #252]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11, lsl #4
	str	w8, [x10, #8]
	ldr	x8, [sp, #680]
	ldr	x10, [x8, #376]
	ldr	w8, [sp, #252]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #256]
	ldr	w10, [sp, #252]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #12]
	b	LBB2_183
LBB2_183:                               ;   in Loop: Header=BB2_181 Depth=1
	ldr	w8, [sp, #252]
	add	w8, w8, #1
	str	w8, [sp, #252]
	b	LBB2_181
LBB2_184:
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #672]
	str	x8, [x9, #152]
	ldr	w8, [sp, #632]
	ldr	x9, [sp, #672]
	str	w8, [x9, #160]
	ldr	w9, [sp, #632]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.hi	LBB2_186
	b	LBB2_185
LBB2_185:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #8]
	ands	w8, w8, #0x4
	cset	w8, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB2_186
LBB2_186:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #672]
	mov	w10, #1                         ; =0x1
	and	w8, w8, w10
	strb	w8, [x9, #228]
	ldrb	w8, [sp, #619]
	tbz	w8, #0, LBB2_189
	b	LBB2_187
LBB2_187:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #368]
	adds	w8, w8, #1
	b.ne	LBB2_189
	b	LBB2_188
LBB2_188:
	b	LBB2_233
LBB2_189:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #368]
	ldrb	w10, [sp, #619]
	mov	w9, #0                          ; =0x0
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csinc	w9, w9, wzr, eq
	add	w8, w8, w9
	str	w8, [sp, #248]
	ldr	w8, [sp, #248]
	cbz	w8, LBB2_199
	b	LBB2_190
LBB2_190:
	ldr	w8, [sp, #248]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	str	x0, [sp, #240]
	ldr	x8, [sp, #240]
	cbnz	x8, LBB2_192
	b	LBB2_191
LBB2_191:
	b	LBB2_233
LBB2_192:
	str	wzr, [sp, #236]
	b	LBB2_193
LBB2_193:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #236]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB2_196
	b	LBB2_194
LBB2_194:                               ;   in Loop: Header=BB2_193 Depth=1
	ldr	x9, [sp, #240]
	ldr	w8, [sp, #236]
	mov	x10, x8
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #360]
	ldr	w11, [sp, #236]
                                        ; kill: def $x11 killed $w11
	lsl	x11, x11, #3
	ldr	w8, [x8, x11]
	str	w8, [sp, #228]
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #360]
	ldr	w11, [sp, #236]
                                        ; kill: def $x11 killed $w11
	add	x8, x8, x11, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #232]
	ldur	x8, [sp, #228]
	str	x8, [x9, x10, lsl #3]
	b	LBB2_195
LBB2_195:                               ;   in Loop: Header=BB2_193 Depth=1
	ldr	w8, [sp, #236]
	add	w8, w8, #1
	str	w8, [sp, #236]
	b	LBB2_193
LBB2_196:
	ldrb	w8, [sp, #619]
	tbz	w8, #0, LBB2_198
	b	LBB2_197
LBB2_197:
	ldr	x9, [sp, #240]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #368]
	mov	x10, x8
	ldr	w8, [sp, #624]
	str	w8, [sp, #220]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #392]
	str	w8, [sp, #224]
	ldur	x8, [sp, #220]
	str	x8, [x9, x10, lsl #3]
	b	LBB2_198
LBB2_198:
	ldr	x8, [sp, #240]
	ldr	x9, [sp, #672]
	str	x8, [x9, #8]
	ldr	w8, [sp, #248]
	ldr	x9, [sp, #672]
	str	w8, [x9, #16]
	b	LBB2_199
LBB2_199:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #468]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #472]
	add	w8, w8, w9
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #476]
	add	w8, w8, w9
	str	w8, [sp, #216]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #320]
	cbz	w8, LBB2_209
	b	LBB2_200
LBB2_200:
	ldrb	w8, [sp, #659]
	tbz	w8, #0, LBB2_202
	b	LBB2_201
LBB2_201:
	ldr	x8, [sp, #680]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x8, [sp, #672]
	add	x2, x8, #56
	mov	x3, #0                          ; =0x0
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB2_206
LBB2_202:
	ldr	x0, [sp, #680]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB2_204
	b	LBB2_203
LBB2_203:
	ldr	x8, [sp, #680]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x8, [sp, #672]
	add	x2, x8, #56
	bl	_nvm_ownership_layouts_private_decode
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_205
LBB2_204:
	ldr	x8, [sp, #680]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x8, [sp, #672]
	add	x2, x8, #56
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_205
LBB2_205:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB2_206
LBB2_206:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #212]
	ldr	w8, [sp, #212]
	cbz	w8, LBB2_208
	b	LBB2_207
LBB2_207:
	ldr	x0, [sp, #672]
	bl	_nvm_v2_module_free
	ldr	w8, [sp, #212]
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_208:
	ldr	x9, [sp, #672]
	ldr	w8, [x9, #240]
	orr	w8, w8, #0x80
	str	w8, [x9, #240]
	b	LBB2_226
LBB2_209:
	ldr	w8, [sp, #216]
	cbz	w8, LBB2_225
	b	LBB2_210
LBB2_210:
	ldr	w8, [sp, #216]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #200]
	ldr	x8, [sp, #200]
	cbnz	x8, LBB2_212
	b	LBB2_211
LBB2_211:
	b	LBB2_233
LBB2_212:
	str	wzr, [sp, #196]
	str	wzr, [sp, #192]
	b	LBB2_213
LBB2_213:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #192]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.hs	LBB2_216
	b	LBB2_214
LBB2_214:                               ;   in Loop: Header=BB2_213 Depth=1
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	strb	wzr, [x8]
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	b	LBB2_215
LBB2_215:                               ;   in Loop: Header=BB2_213 Depth=1
	ldr	w8, [sp, #192]
	add	w8, w8, #1
	str	w8, [sp, #192]
	ldr	w8, [sp, #196]
	add	w8, w8, #1
	str	w8, [sp, #196]
	b	LBB2_213
LBB2_216:
	str	wzr, [sp, #188]
	b	LBB2_217
LBB2_217:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #188]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.hs	LBB2_220
	b	LBB2_218
LBB2_218:                               ;   in Loop: Header=BB2_217 Depth=1
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #3                          ; =0x3
	strb	w8, [x9]
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	b	LBB2_219
LBB2_219:                               ;   in Loop: Header=BB2_217 Depth=1
	ldr	w8, [sp, #188]
	add	w8, w8, #1
	str	w8, [sp, #188]
	ldr	w8, [sp, #196]
	add	w8, w8, #1
	str	w8, [sp, #196]
	b	LBB2_217
LBB2_220:
	str	wzr, [sp, #184]
	b	LBB2_221
LBB2_221:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #184]
	ldr	x9, [sp, #680]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.hs	LBB2_224
	b	LBB2_222
LBB2_222:                               ;   in Loop: Header=BB2_221 Depth=1
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldr	x8, [sp, #200]
	ldr	w9, [sp, #196]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #4
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	b	LBB2_223
LBB2_223:                               ;   in Loop: Header=BB2_221 Depth=1
	ldr	w8, [sp, #184]
	add	w8, w8, #1
	str	w8, [sp, #184]
	ldr	w8, [sp, #196]
	add	w8, w8, #1
	str	w8, [sp, #196]
	b	LBB2_221
LBB2_224:
	ldr	x8, [sp, #200]
	ldr	x9, [sp, #672]
	str	x8, [x9, #56]
	ldr	w8, [sp, #216]
	ldr	x9, [sp, #672]
	str	w8, [x9, #64]
	b	LBB2_225
LBB2_225:
	b	LBB2_226
LBB2_226:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #8]
	tbz	w8, #1, LBB2_228
	b	LBB2_227
LBB2_227:
	ldr	x9, [sp, #672]
	ldr	w8, [x9, #240]
	orr	w8, w8, #0x2
	str	w8, [x9, #240]
	b	LBB2_228
LBB2_228:
	ldr	x8, [sp, #680]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #672]
	str	x8, [x9, #168]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #288]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #672]
	str	x8, [x9, #176]
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB2_231
	b	LBB2_229
LBB2_229:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #12]
	ldr	w9, [sp, #648]
	subs	w8, w8, w9
	b.hs	LBB2_231
	b	LBB2_230
LBB2_230:
	ldr	x8, [sp, #680]
	ldr	w8, [x8, #12]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB2_232
LBB2_231:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB2_232
LBB2_232:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #672]
	str	w8, [x9, #4]
	str	wzr, [sp, #688]
	b	LBB2_234
LBB2_233:
	ldr	x0, [sp, #672]
	bl	_nvm_v2_module_free
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #688]
	b	LBB2_234
LBB2_234:
	ldr	w8, [sp, #688]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB2_236
	b	LBB2_235
LBB2_235:
	bl	___stack_chk_fail
LBB2_236:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #2400
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_private_to_module          ; -- Begin function nvm_private_to_module
	.p2align	2
_nvm_private_to_module:                 ; @nvm_private_to_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x0, [x29, #-16]
	bl	_nvm_record_map_wire_selected
	tbz	w0, #0, LBB3_7
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB3_3
	b	LBB3_2
LBB3_2:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB3_8
LBB3_3:
	add	x1, sp, #8
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	ldur	x0, [x29, #-16]
	ldr	x2, [sp, #16]
	bl	_nvm_to_module_core
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbnz	w8, LBB3_5
	b	LBB3_4
LBB3_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	b	LBB3_6
LBB3_5:
	ldr	x0, [sp, #8]
	bl	_nvm_module_free
	b	LBB3_6
LBB3_6:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB3_8
LBB3_7:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #16]
	bl	_nvm_to_module_core
	stur	w0, [x29, #-4]
	b	LBB3_8
LBB3_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_to_module_core
_nvm_to_module_core:                    ; @nvm_to_module_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1408
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #96
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #736]
	str	x1, [x8, #728]
	str	x2, [x8, #720]
	ldr	x8, [x8, #736]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #728]
	cbnz	x8, LBB4_3
	b	LBB4_2
LBB4_2:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #728]
                                        ; kill: def $x10 killed $xzr
	str	xzr, [x9]
	ldr	x0, [x8, #736]
	ldr	x1, [x8, #720]
	bl	_nvm_private_service_wire
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x8, #716]
	ldr	w8, [x8, #716]
	cbz	w8, LBB4_5
	b	LBB4_4
LBB4_4:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #716]
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_5:
	bl	_nvm_module_new
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8, #704]
	ldr	x8, [x8, #704]
	cbnz	x8, LBB4_7
	b	LBB4_6
LBB4_6:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_7:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #700]
	b	LBB4_8
LBB4_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #700]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB4_15
	b	LBB4_9
LBB4_9:                                 ;   in Loop: Header=BB4_8 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #24]
	ldr	w10, [x8, #700]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [x8, #688]
	ldr	x8, [x8, #688]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.eq	LBB4_11
	b	LBB4_10
LBB4_10:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_11:                                ;   in Loop: Header=BB4_8 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	ldr	x9, [x8, #688]
	ldr	x1, [x9, #8]
	ldr	x8, [x8, #688]
	ldr	w2, [x8, #4]
	bl	_nvm_add_string
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x9, #684]
	ldr	w8, [x9, #684]
	ldr	w9, [x9, #700]
	subs	w8, w8, w9
	b.eq	LBB4_13
	b	LBB4_12
LBB4_12:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_13:                                ;   in Loop: Header=BB4_8 Depth=1
	b	LBB4_14
LBB4_14:                                ;   in Loop: Header=BB4_8 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #700]
	add	w8, w8, #1
	str	w8, [x9, #700]
	b	LBB4_8
LBB4_15:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #680]
	b	LBB4_16
LBB4_16:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #680]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB4_21
	b	LBB4_17
LBB4_17:                                ;   in Loop: Header=BB4_16 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #8]
	ldr	w10, [x8, #680]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	str	x9, [x8, #672]
	ldr	x0, [x8, #704]
	ldr	x9, [x8, #672]
	ldr	w1, [x9]
	ldr	x8, [x8, #672]
	ldr	w2, [x8, #4]
	bl	_nvm_add_metadata
	tbnz	w0, #0, LBB4_19
	b	LBB4_18
LBB4_18:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_19:                                ;   in Loop: Header=BB4_16 Depth=1
	b	LBB4_20
LBB4_20:                                ;   in Loop: Header=BB4_16 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #680]
	add	w8, w8, #1
	str	w8, [x9, #680]
	b	LBB4_16
LBB4_21:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #176]
	cbz	x8, LBB4_30
	b	LBB4_22
LBB4_22:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #168]
	cbz	x8, LBB4_24
	b	LBB4_23
LBB4_23:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #176]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB4_25
	b	LBB4_24
LBB4_24:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_25:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #736]
	ldr	x8, [x8, #176]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #668]
	ldr	w8, [x9, #668]
	ldr	x9, [x9, #704]
	ldr	w9, [x9, #292]
	subs	w8, w8, w9
	b.ls	LBB4_29
	b	LBB4_26
LBB4_26:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x0, [x9, #280]
	ldr	w8, [x8, #668]
	mov	x1, x8
	bl	_realloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8, #656]
	ldr	x8, [x8, #656]
	cbnz	x8, LBB4_28
	b	LBB4_27
LBB4_27:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_28:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #656]
	ldr	x10, [x9, #704]
	str	x8, [x10, #280]
	ldr	w8, [x9, #668]
	ldr	x9, [x9, #704]
	str	w8, [x9, #292]
	b	LBB4_29
LBB4_29:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x0, [x9, #280]
	ldr	x9, [x8, #736]
	ldr	x1, [x9, #168]
	ldr	w8, [x8, #668]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #668]
	ldr	x9, [x9, #704]
	str	w8, [x9, #288]
	b	LBB4_30
LBB4_30:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #652]
	b	LBB4_31
LBB4_31:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #652]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #80]
	subs	w8, w8, w9
	b.hs	LBB4_44
	b	LBB4_32
LBB4_32:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #72]
	ldr	w10, [x8, #652]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	str	x9, [x8, #640]
	ldr	x9, [x8, #736]
	ldr	x11, [x9, #40]
	ldr	x9, [x8, #640]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [x8, #632]
	ldr	x8, [x8, #640]
	ldr	x8, [x8, #8]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.hi	LBB4_35
	b	LBB4_33
LBB4_33:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #640]
	ldr	x8, [x8, #16]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.hi	LBB4_35
	b	LBB4_34
LBB4_34:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #632]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #255
	b.le	LBB4_36
	b	LBB4_35
LBB4_35:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_36:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	xzr, [x8, #608]
	str	xzr, [x8, #616]
	str	xzr, [x8, #624]
	ldr	x9, [x8, #640]
	ldr	w9, [x9]
	str	w9, [x8, #608]
	ldr	x9, [x8, #632]
	ldrh	w9, [x9]
	strh	w9, [sp, #708]
	ldr	x9, [x8, #640]
	ldr	x9, [x9, #8]
                                        ; kill: def $w9 killed $w9 killed $x9
	str	w9, [x8, #616]
	ldr	x9, [x8, #640]
	ldr	x9, [x9, #16]
                                        ; kill: def $w9 killed $w9 killed $x9
	str	w9, [x8, #620]
	ldr	x9, [x8, #640]
	ldrh	w9, [x9, #24]
	strh	w9, [sp, #720]
	ldr	x9, [x8, #640]
	ldrh	w9, [x9, #26]
	strh	w9, [sp, #722]
	ldr	x9, [x8, #632]
	ldrh	w9, [x9, #2]
	strb	w9, [sp, #725]
	ldr	x8, [x8, #632]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB4_38
	b	LBB4_37
LBB4_37:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #632]
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB4_39
LBB4_38:                                ;   in Loop: Header=BB4_31 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB4_39
LBB4_39:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #60]                   ; 4-byte Folded Reload
	add	x1, sp, #704
	strb	w9, [sp, #724]
	ldr	x0, [x8, #704]
	bl	_nvm_add_function
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x8, #604]
	ldr	w8, [x8, #604]
	adds	w8, w8, #1
	b.eq	LBB4_41
	b	LBB4_40
LBB4_40:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	ldr	w1, [x8, #604]
	ldr	x9, [x8, #632]
	ldr	x2, [x9, #8]
	ldr	x8, [x8, #632]
	ldrh	w3, [x8]
	bl	_nvm_set_function_param_types
	tbnz	w0, #0, LBB4_42
	b	LBB4_41
LBB4_41:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_42:                                ;   in Loop: Header=BB4_31 Depth=1
	b	LBB4_43
LBB4_43:                                ;   in Loop: Header=BB4_31 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #652]
	add	w8, w8, #1
	str	w8, [x9, #652]
	b	LBB4_31
LBB4_44:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #600]
	b	LBB4_45
LBB4_45:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #600]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #112]
	subs	w8, w8, w9
	b.hs	LBB4_53
	b	LBB4_46
LBB4_46:                                ;   in Loop: Header=BB4_45 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #104]
	ldr	w10, [x8, #600]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [x8, #592]
	ldr	x9, [x8, #736]
	ldr	x11, [x9, #40]
	ldr	x9, [x8, #592]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [x8, #584]
	ldr	x8, [x8, #584]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB4_48
	b	LBB4_47
LBB4_47:                                ;   in Loop: Header=BB4_45 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #584]
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	str	w8, [sp, #56]                   ; 4-byte Folded Spill
	b	LBB4_49
LBB4_48:                                ;   in Loop: Header=BB4_45 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #56]                   ; 4-byte Folded Spill
	b	LBB4_49
LBB4_49:                                ;   in Loop: Header=BB4_45 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	strb	w9, [sp, #679]
	ldr	x0, [x8, #704]
	ldr	x9, [x8, #592]
	ldr	w1, [x9]
	ldr	x9, [x8, #592]
	ldr	w2, [x9, #4]
	ldr	x9, [x8, #584]
	ldrh	w3, [x9]
	ldrb	w4, [sp, #679]
	ldr	x8, [x8, #584]
	ldr	x5, [x8, #8]
	bl	_nvm_add_import
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x8, #576]
	ldr	w8, [x8, #576]
	adds	w8, w8, #1
	b.ne	LBB4_51
	b	LBB4_50
LBB4_50:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_51:                                ;   in Loop: Header=BB4_45 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #592]
	mov	x10, #12                        ; =0xc
	ldrb	w8, [x8, #12]
	ldr	x11, [x9, #704]
	ldr	x11, [x11, #400]
	ldr	w9, [x9, #576]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	strb	w8, [x9, #11]
	b	LBB4_52
LBB4_52:                                ;   in Loop: Header=BB4_45 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #600]
	add	w8, w8, #1
	str	w8, [x9, #600]
	b	LBB4_45
LBB4_53:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #572]
	b	LBB4_54
LBB4_54:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #572]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #128]
	subs	w8, w8, w9
	b.hs	LBB4_74
	b	LBB4_55
LBB4_55:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #120]
	ldr	w10, [x8, #572]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [x8, #560]
	movi.2d	v0, #0000000000000000
	str	q0, [x8, #1264]
	str	q0, [x8, #1280]
	ldr	x9, [x8, #560]
	ldr	w9, [x9]
	str	w9, [x8, #1264]
	ldr	x9, [x8, #560]
	ldr	w9, [x9, #12]
	str	w9, [x8, #1268]
	ldr	x9, [x8, #560]
	ldrh	w9, [x9, #4]
	sturh	w9, [x29, #-56]
	ldr	x9, [x8, #560]
	ldrb	w9, [x9, #6]
	sturb	w9, [x29, #-54]
	ldr	x8, [x8, #560]
	ldrb	w8, [x8, #7]
	sturb	w8, [x29, #-53]
	ldurh	w8, [x29, #-56]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB4_67
	b	LBB4_56
LBB4_56:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #560]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.lo	LBB4_58
	b	LBB4_57
LBB4_57:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_58:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x11, [x9, #40]
	ldr	x9, [x8, #560]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [x8, #552]
	ldr	x8, [x8, #552]
	ldrh	w8, [x8]
	subs	w8, w8, #16
	b.gt	LBB4_60
	b	LBB4_59
LBB4_59:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #552]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #1
	b.le	LBB4_61
	b	LBB4_60
LBB4_60:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_61:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #552]
	ldrh	w9, [x9]
	sturh	w9, [x29, #-52]
	ldr	x8, [x8, #552]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB4_63
	b	LBB4_62
LBB4_62:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #552]
	ldr	x8, [x8, #16]
	ldrb	w8, [x8]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB4_64
LBB4_63:                                ;   in Loop: Header=BB4_54 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB4_64
LBB4_64:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #52]                   ; 4-byte Folded Reload
	sturb	w9, [x29, #-50]
	ldr	x8, [x8, #552]
	ldrh	w8, [x8]
	cbz	w8, LBB4_66
	b	LBB4_65
LBB4_65:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	sub	x9, x29, #64
	add	x0, x9, #15
	ldr	x9, [x8, #552]
	ldr	x1, [x9, #8]
	ldr	x8, [x8, #552]
	ldrh	w8, [x8]
	mov	x2, x8
	mov	x3, #17                         ; =0x11
	bl	___memcpy_chk
	b	LBB4_66
LBB4_66:                                ;   in Loop: Header=BB4_54 Depth=1
	b	LBB4_70
LBB4_67:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #560]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB4_69
	b	LBB4_68
LBB4_68:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_69:                                ;   in Loop: Header=BB4_54 Depth=1
	b	LBB4_70
LBB4_70:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	sub	x1, x29, #64
	bl	_nvm_add_callback_contract
	tbnz	w0, #0, LBB4_72
	b	LBB4_71
LBB4_71:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_72:                                ;   in Loop: Header=BB4_54 Depth=1
	b	LBB4_73
LBB4_73:                                ;   in Loop: Header=BB4_54 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #572]
	add	w8, w8, #1
	str	w8, [x9, #572]
	b	LBB4_54
LBB4_74:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_callback_contracts_valid
	tbnz	w0, #0, LBB4_76
	b	LBB4_75
LBB4_75:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_76:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #548]
	b	LBB4_77
LBB4_77:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #548]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #144]
	subs	w8, w8, w9
	b.hs	LBB4_80
	b	LBB4_78
LBB4_78:                                ;   in Loop: Header=BB4_77 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x9, #704]
	ldr	x8, [x9, #736]
	ldr	x8, [x8, #136]
	ldr	w9, [x9, #548]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w1, [x8, x9]
	bl	_nvm_add_module_ref
	b	LBB4_79
LBB4_79:                                ;   in Loop: Header=BB4_77 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #548]
	add	w8, w8, #1
	str	w8, [x9, #548]
	b	LBB4_77
LBB4_80:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #544]
	b	LBB4_81
LBB4_81:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #544]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #160]
	subs	w8, w8, w9
	b.hs	LBB4_88
	b	LBB4_82
LBB4_82:                                ;   in Loop: Header=BB4_81 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #152]
	ldr	w10, [x8, #544]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [x8, #536]
	ldr	x8, [x8, #536]
	ldr	x8, [x8]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB4_84
	b	LBB4_83
LBB4_83:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_84:                                ;   in Loop: Header=BB4_81 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	ldr	x9, [x8, #536]
	ldr	x9, [x9]
	mov	x1, x9
	ldr	x9, [x8, #536]
	ldr	w2, [x9, #8]
	ldr	x8, [x8, #536]
	ldr	w3, [x8, #12]
	bl	_nvm_add_debug_entry
	tbnz	w0, #0, LBB4_86
	b	LBB4_85
LBB4_85:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_86:                                ;   in Loop: Header=BB4_81 Depth=1
	b	LBB4_87
LBB4_87:                                ;   in Loop: Header=BB4_81 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #544]
	add	w8, w8, #1
	str	w8, [x9, #544]
	b	LBB4_81
LBB4_88:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #64]
	cbz	w8, LBB4_91
	b	LBB4_89
LBB4_89:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB4_91
	b	LBB4_90
LBB4_90:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_91:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	wzr, [x8, #532]
	b	LBB4_92
LBB4_92:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #532]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB4_102
	b	LBB4_93
LBB4_93:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #736]
	ldr	x8, [x8, #56]
	ldr	w9, [x9, #532]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	cbz	w8, LBB4_96
	b	LBB4_94
LBB4_94:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB4_98
	b	LBB4_95
LBB4_95:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB4_97
	b	LBB4_99
LBB4_96:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	w8, [x9, #468]
	add	w8, w8, #1
	str	w8, [x9, #468]
	b	LBB4_100
LBB4_97:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	w8, [x9, #472]
	add	w8, w8, #1
	str	w8, [x9, #472]
	b	LBB4_100
LBB4_98:                                ;   in Loop: Header=BB4_92 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	w8, [x9, #476]
	add	w8, w8, #1
	str	w8, [x9, #476]
	b	LBB4_100
LBB4_99:                                ;   in Loop: Header=BB4_92 Depth=1
	b	LBB4_100
LBB4_100:                               ;   in Loop: Header=BB4_92 Depth=1
	b	LBB4_101
LBB4_101:                               ;   in Loop: Header=BB4_92 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #532]
	add	w8, w8, #1
	str	w8, [x9, #532]
	b	LBB4_92
LBB4_102:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #240]
	tbnz	w8, #7, LBB4_104
	b	LBB4_103
LBB4_103:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	add	x0, x8, #56
	bl	_nvm_layouts_have_facts
	tbz	w0, #0, LBB4_124
	b	LBB4_104
LBB4_104:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	x9, #4                          ; =0x4
	str	x9, [x8, #520]
	str	wzr, [x8, #516]
	b	LBB4_105
LBB4_105:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #516]
	ldr	x9, [x9, #736]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB4_112
	b	LBB4_106
LBB4_106:                               ;   in Loop: Header=BB4_105 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	ldr	x9, [x9, #56]
	ldr	w10, [x8, #516]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [x8, #504]
	ldr	x9, [x8, #504]
	ldrh	w9, [x9, #2]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	add	x9, x9, #8
	str	x9, [x8, #496]
	ldr	x8, [x8, #504]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB4_108
	b	LBB4_107
LBB4_107:                               ;   in Loop: Header=BB4_105 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #504]
	ldr	x8, [x8, #8]
	cbz	x8, LBB4_109
	b	LBB4_108
LBB4_108:                               ;   in Loop: Header=BB4_105 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #496]
	ldr	x10, [x9, #520]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_110
	b	LBB4_109
LBB4_109:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_110:                               ;   in Loop: Header=BB4_105 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x10, [x9, #496]
	ldr	x8, [x9, #520]
	add	x8, x8, x10
	str	x8, [x9, #520]
	b	LBB4_111
LBB4_111:                               ;   in Loop: Header=BB4_105 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #516]
	add	w8, w8, #1
	str	w8, [x9, #516]
	b	LBB4_105
LBB4_112:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #520]
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8, #488]
	ldr	x8, [x8, #488]
	cbnz	x8, LBB4_114
	b	LBB4_113
LBB4_113:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_114:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #736]
	add	x0, x9, #56
	ldr	x1, [x8, #488]
	ldr	x2, [x8, #520]
	bl	_nvm_v2_layouts_encode
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x8, #484]
	ldr	x1, [x8, #704]
	add	x0, sp, #96
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x2, #480                        ; =0x1e0
	bl	_memcpy
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #488]
	str	x8, [x9, #312]
	ldr	x8, [x9, #520]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #320]
	ldr	x8, [x9, #736]
	ldr	x8, [x8, #184]
	str	x8, [x9, #296]
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #192]
	str	w8, [x9, #304]
	ldr	x8, [x9, #736]
	ldr	x8, [x8, #216]
	str	x8, [x9, #328]
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #224]
	str	w8, [x9, #336]
	strb	wzr, [sp, #95]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	strb	w0, [sp, #95]
	ldr	w8, [x8, #484]
	cbnz	w8, LBB4_118
	b	LBB4_115
LBB4_115:
	ldrb	w8, [sp, #95]
	tbnz	w8, #0, LBB4_117
	b	LBB4_116
LBB4_116:
	add	x0, sp, #96
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB4_118
	b	LBB4_117
LBB4_117:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #488]
	ldr	x10, [x8, #704]
	str	x9, [x10, #312]
	ldr	x9, [x8, #520]
	ldr	x10, [x8, #704]
                                        ; kill: def $w9 killed $w9 killed $x9
	str	w9, [x10, #320]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #488]
	b	LBB4_121
LBB4_118:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #484]
	cbnz	w8, LBB4_120
	b	LBB4_119
LBB4_119:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	ldr	x8, [x8, #736]
	add	x1, x8, #56
	bl	_nvm_retain_layouts
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	w0, [x8, #484]
	b	LBB4_120
LBB4_120:
	b	LBB4_121
LBB4_121:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #488]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #484]
	cbz	w8, LBB4_123
	b	LBB4_122
LBB4_122:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #484]
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_123:
	b	LBB4_124
LBB4_124:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	str	wzr, [x9, #8]
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB4_126
	b	LBB4_125
LBB4_125:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x10, [x9, #704]
	ldr	w8, [x10, #8]
	orr	w8, w8, #0x1
	str	w8, [x10, #8]
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #4]
	ldr	x9, [x9, #704]
	str	w8, [x9, #12]
	b	LBB4_127
LBB4_126:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #704]
	str	wzr, [x8, #12]
	b	LBB4_127
LBB4_127:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #112]
	cbnz	w8, LBB4_129
	b	LBB4_128
LBB4_128:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #240]
	tbz	w8, #1, LBB4_130
	b	LBB4_129
LBB4_129:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x2
	str	w8, [x9, #8]
	b	LBB4_130
LBB4_130:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldrb	w8, [x8, #228]
	tbz	w8, #0, LBB4_132
	b	LBB4_131
LBB4_131:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x4
	str	w8, [x9, #8]
	b	LBB4_132
LBB4_132:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #224]
	cbz	w8, LBB4_136
	b	LBB4_133
LBB4_133:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #224]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	str	x0, [x9, #328]
	ldr	x8, [x8, #704]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB4_135
	b	LBB4_134
LBB4_134:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_135:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x0, [x9, #328]
	ldr	x9, [x8, #736]
	ldr	x1, [x9, #216]
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #224]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #224]
	ldr	x9, [x9, #704]
	str	w8, [x9, #336]
	b	LBB4_136
LBB4_136:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #208]
	cbz	w8, LBB4_142
	b	LBB4_137
LBB4_137:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #200]
	cbnz	x8, LBB4_139
	b	LBB4_138
LBB4_138:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_139:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #208]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	str	x0, [x9, #344]
	ldr	x8, [x8, #704]
	ldr	x8, [x8, #344]
	cbnz	x8, LBB4_141
	b	LBB4_140
LBB4_140:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_141:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x0, [x9, #344]
	ldr	x9, [x8, #736]
	ldr	x1, [x9, #200]
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #208]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #208]
	ldr	x9, [x9, #704]
	str	w8, [x9, #352]
	b	LBB4_142
LBB4_142:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #192]
	cbz	w8, LBB4_148
	b	LBB4_143
LBB4_143:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #184]
	cbnz	x8, LBB4_145
	b	LBB4_144
LBB4_144:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_145:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #192]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	str	x0, [x9, #296]
	ldr	x8, [x8, #704]
	ldr	x8, [x8, #296]
	cbnz	x8, LBB4_147
	b	LBB4_146
LBB4_146:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_147:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x0, [x9, #296]
	ldr	x9, [x8, #736]
	ldr	x1, [x9, #184]
	ldr	x8, [x8, #736]
	ldr	w8, [x8, #192]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #736]
	ldr	w8, [x8, #192]
	ldr	x9, [x9, #704]
	str	w8, [x9, #304]
	b	LBB4_148
LBB4_148:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	strb	wzr, [sp, #94]
	ldr	x0, [x8, #704]
	bl	_nvm_owned_array_route
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	subs	w9, w0, #0
	cset	w9, ne
	strb	w9, [sp, #93]
	ldr	x0, [x8, #704]
	bl	_nvm_record_array_candidate
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB4_150
	b	LBB4_149
LBB4_149:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_mixed_samples_candidate
	eor	w8, w0, #0x1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB4_150
LBB4_150:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	mov	w10, #1                         ; =0x1
	and	w9, w9, w10
	strb	w9, [sp, #92]
	strb	wzr, [sp, #91]
	ldr	x0, [x8, #704]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	strb	w0, [sp, #91]
	add	x0, sp, #848
	mov	x1, #512                        ; =0x200
	bl	_bzero
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #704]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldrb	w8, [sp, #91]
	tbnz	w8, #0, LBB4_153
	b	LBB4_151
LBB4_151:
	ldrb	w8, [sp, #93]
	tbnz	w8, #0, LBB4_153
	b	LBB4_152
LBB4_152:
	ldrb	w8, [sp, #92]
	tbz	w8, #0, LBB4_154
	b	LBB4_153
LBB4_153:
	add	x8, sp, #848
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB4_155
LBB4_154:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB4_155
LBB4_155:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x4, [x8, #720]
	add	x1, sp, #94
	mov	x3, #0                          ; =0x0
	bl	_conversion_ownership
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	cbz	w8, LBB4_157
	b	LBB4_156
LBB4_156:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #84]
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_157:
	ldrb	w8, [sp, #91]
	tbnz	w8, #0, LBB4_160
	b	LBB4_158
LBB4_158:
	ldrb	w8, [sp, #93]
	tbnz	w8, #0, LBB4_160
	b	LBB4_159
LBB4_159:
	ldrb	w8, [sp, #92]
	tbz	w8, #0, LBB4_168
	b	LBB4_160
LBB4_160:
	str	wzr, [sp, #80]
	b	LBB4_161
LBB4_161:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #80]
	ldr	x9, [x9, #704]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB4_167
	b	LBB4_162
LBB4_162:                               ;   in Loop: Header=BB4_161 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #736]
	ldr	x8, [x8, #72]
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w8, [x8, #28]
	strh	w8, [sp, #78]
	ldrh	w8, [sp, #78]
	cbz	w8, LBB4_165
	b	LBB4_163
LBB4_163:                               ;   in Loop: Header=BB4_161 Depth=1
	ldrh	w8, [sp, #78]
	ldr	w9, [sp, #80]
	mov	x10, x9
	add	x9, sp, #848
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.ge	LBB4_165
	b	LBB4_164
LBB4_164:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_165:                               ;   in Loop: Header=BB4_161 Depth=1
	b	LBB4_166
LBB4_166:                               ;   in Loop: Header=BB4_161 Depth=1
	ldr	w8, [sp, #80]
	add	w8, w8, #1
	str	w8, [sp, #80]
	b	LBB4_161
LBB4_167:
	b	LBB4_168
LBB4_168:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_passive_valid
	tbnz	w0, #0, LBB4_170
	b	LBB4_169
LBB4_169:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #704]
	bl	_nvm_module_free
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #748]
	b	LBB4_171
LBB4_170:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #704]
	ldr	x10, [x8, #728]
	str	x9, [x10]
	str	wzr, [x8, #748]
	b	LBB4_171
LBB4_171:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #748]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB4_173
	b	LBB4_172
LBB4_172:
	bl	___stack_chk_fail
LBB4_173:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #1408
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_from_nvm_module         ; -- Begin function nvm_v2_from_nvm_module
	.p2align	2
_nvm_v2_from_nvm_module:                ; @nvm_v2_from_nvm_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	bl	_nvm_private_from_module
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_to_nvm_module           ; -- Begin function nvm_v2_to_nvm_module
	.p2align	2
_nvm_v2_to_nvm_module:                  ; @nvm_v2_to_nvm_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	bl	_nvm_private_to_module
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_private_service_module
_nvm_private_service_module:            ; @nvm_private_service_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB7_7
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	cbz	x8, LBB7_5
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	cbz	x8, LBB7_5
	b	LBB7_3
LBB7_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
	cbz	w8, LBB7_5
	b	LBB7_4
LBB7_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldur	x0, [x29, #-8]
	blr	x8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_6
LBB7_5:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_6
LBB7_6:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB7_8
LBB7_7:
	ldur	x0, [x29, #-8]
	bl	_nvm_service_bindings_validate
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB7_8
LBB7_8:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function conversion_ownership
_conversion_ownership:                  ; @conversion_ownership
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #4896                       ; =0x1320
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #800
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #176
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #4248]
	str	x1, [x8, #4240]
	str	x2, [x8, #4232]
	str	x3, [x8, #4224]
	str	x4, [x8, #4216]
	ldr	x0, [x8, #4248]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB8_12
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #288
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #4208]
	ldr	x0, [x8, #4248]
	sub	x8, x29, #228
	bl	_nvm_record_map_admit
	ldur	w8, [x29, #-228]
	cbz	w8, LBB8_3
	b	LBB8_2
LBB8_2:
	ldur	w9, [x29, #-228]
	mov	w8, #13                         ; =0xd
	subs	w9, w9, #4
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4232]
	cbz	x8, LBB8_11
	b	LBB8_4
LBB8_4:
	str	wzr, [sp, #4380]
	b	LBB8_5
LBB8_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #4380]
	ldr	x9, [x9, #4248]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB8_10
	b	LBB8_6
LBB8_6:                                 ;   in Loop: Header=BB8_5 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4208]
	ldr	w1, [sp, #4380]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #248
	bl	_nvm_record_map_execution_function
	tbnz	w0, #0, LBB8_8
	b	LBB8_7
LBB8_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4208]
	bl	_nvm_record_map_execution_free
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_8:                                 ;   in Loop: Header=BB8_5 Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #4376]
	ldr	x9, [x9, #4232]
	ldr	w10, [sp, #4380]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB8_9
LBB8_9:                                 ;   in Loop: Header=BB8_5 Depth=1
	ldr	w8, [sp, #4380]
	add	w8, w8, #1
	str	w8, [sp, #4380]
	b	LBB8_5
LBB8_10:
	b	LBB8_11
LBB8_11:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4208]
	bl	_nvm_record_map_execution_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4240]
	strb	wzr, [x8]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	bl	_nvm_service_bindings_present
	tbz	w0, #0, LBB8_22
	b	LBB8_13
LBB8_13:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	ldr	x1, [x8, #4216]
	bl	_nvm_private_service_module
	str	w0, [sp, #4340]
	ldr	w8, [sp, #4340]
	cbz	w8, LBB8_15
	b	LBB8_14
LBB8_14:
	ldr	w8, [sp, #4340]
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_15:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4216]
	cbz	x8, LBB8_17
	b	LBB8_16
LBB8_16:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4240]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_17:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4248]
	ldr	x0, [x9, #328]
	ldr	x8, [x8, #4248]
	ldr	w8, [x8, #336]
	mov	x1, x8
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #192
	bl	_nvm_file_nominal_decode
	cbz	w0, LBB8_20
	b	LBB8_18
LBB8_18:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4248]
	ldr	x0, [x9, #328]
	ldr	x8, [x8, #4248]
	ldr	w8, [x8, #336]
	mov	x1, x8
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #136
	bl	_nvm_socket_nominal_decode
	cbz	w0, LBB8_20
	b	LBB8_19
LBB8_19:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4248]
	ldr	x0, [x9, #328]
	ldr	x8, [x8, #4248]
	ldr	w8, [x8, #336]
	mov	x1, x8
	add	x2, sp, #388
	bl	_nvm_multi_nominal_decode
	cbnz	w0, LBB8_21
	b	LBB8_20
LBB8_20:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4240]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_21:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	ldr	x1, [x8, #4240]
	bl	_nvm_ownership_contracts_validate
	str	w0, [sp, #4436]
	b	LBB8_64
LBB8_22:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	bl	_nvm_owned_array_route
	cbz	w0, LBB8_36
	b	LBB8_23
LBB8_23:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #376
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #200]
	ldr	x0, [x8, #4248]
	add	x8, sp, #352
	bl	_nvm_owned_array_admit
	ldr	w8, [sp, #352]
	cbz	w8, LBB8_25
	b	LBB8_24
LBB8_24:
	ldr	w9, [sp, #352]
	mov	w8, #13                         ; =0xd
	subs	w9, w9, #4
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_25:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	xzr, [x8, #4488]
	str	xzr, [x8, #4496]
	str	wzr, [sp, #348]
	b	LBB8_26
LBB8_26:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #348]
	ldr	x9, [x9, #4248]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB8_33
	b	LBB8_27
LBB8_27:                                ;   in Loop: Header=BB8_26 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #200]
	ldr	w1, [sp, #348]
	add	x2, sp, #232
	bl	_nvm_owned_array_plan_signature
	tbnz	w0, #0, LBB8_29
	b	LBB8_28
LBB8_28:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #200]
	bl	_nvm_owned_array_plan_free
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_29:                                ;   in Loop: Header=BB8_26 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w9, [sp, #236]
	ldr	w10, [sp, #348]
	mov	x11, x10
	sub	x10, x29, #248
	add	x10, x10, x11, lsl #1
	strh	w9, [x10]
	ldr	x8, [x8, #4224]
	cbz	x8, LBB8_31
	b	LBB8_30
LBB8_30:                                ;   in Loop: Header=BB8_26 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x10, [x8, #4224]
	ldr	w8, [sp, #348]
                                        ; kill: def $x8 killed $w8
	mov	x9, #116                        ; =0x74
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #232
	mov	x2, #116                        ; =0x74
	bl	_memcpy
	b	LBB8_31
LBB8_31:                                ;   in Loop: Header=BB8_26 Depth=1
	b	LBB8_32
LBB8_32:                                ;   in Loop: Header=BB8_26 Depth=1
	ldr	w8, [sp, #348]
	add	w8, w8, #1
	str	w8, [sp, #348]
	b	LBB8_26
LBB8_33:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #200]
	bl	_nvm_owned_array_plan_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4232]
	cbz	x8, LBB8_35
	b	LBB8_34
LBB8_34:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4232]
	sub	x1, x29, #248
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB8_35
LBB8_35:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4240]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_36:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB8_49
	b	LBB8_37
LBB8_37:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	bl	_nvm_mixed_samples_candidate
	tbnz	w0, #0, LBB8_49
	b	LBB8_38
LBB8_38:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #224
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #48]
	ldr	x0, [x8, #4248]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #364
	bl	_nvm_record_array_admit
	ldr	w8, [sp, #4460]
	cbz	w8, LBB8_40
	b	LBB8_39
LBB8_39:
	ldr	w9, [sp, #4460]
	mov	w8, #13                         ; =0xd
	subs	w9, w9, #4
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_40:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4232]
	cbz	x8, LBB8_48
	b	LBB8_41
LBB8_41:
	str	wzr, [sp, #220]
	b	LBB8_42
LBB8_42:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #220]
	ldr	x9, [x9, #4248]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB8_47
	b	LBB8_43
LBB8_43:                                ;   in Loop: Header=BB8_42 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	ldr	w1, [sp, #220]
	add	x2, sp, #184
	bl	_nvm_record_array_execution_function
	tbnz	w0, #0, LBB8_45
	b	LBB8_44
LBB8_44:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	bl	_nvm_record_array_execution_free
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_45:                                ;   in Loop: Header=BB8_42 Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #216]
	ldr	x9, [x9, #4232]
	ldr	w10, [sp, #220]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB8_46
LBB8_46:                                ;   in Loop: Header=BB8_42 Depth=1
	ldr	w8, [sp, #220]
	add	w8, w8, #1
	str	w8, [sp, #220]
	b	LBB8_42
LBB8_47:
	b	LBB8_48
LBB8_48:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	bl	_nvm_record_array_execution_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4240]
	strb	wzr, [x8]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_49:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	bl	_nvm_mixed_samples_candidate
	tbnz	w0, #0, LBB8_51
	b	LBB8_50
LBB8_50:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4248]
	ldr	x1, [x8, #4240]
	bl	_nvm_ownership_contracts_validate
	str	w0, [sp, #4436]
	b	LBB8_64
LBB8_51:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #176
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x0, [x8, #4248]
	add	x8, sp, #152
	bl	_nvm_mixed_samples_admit
	ldr	w8, [sp, #152]
	cbz	w8, LBB8_53
	b	LBB8_52
LBB8_52:
	ldr	w9, [sp, #152]
	mov	w8, #13                         ; =0xd
	subs	w9, w9, #4
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_53:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	xzr, [x8, #4264]
	str	xzr, [x8, #4272]
	ldr	x8, [x8, #4232]
	cbz	x8, LBB8_61
	b	LBB8_54
LBB8_54:
	str	wzr, [sp, #148]
	b	LBB8_55
LBB8_55:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #148]
	ldr	x9, [x9, #4248]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB8_60
	b	LBB8_56
LBB8_56:                                ;   in Loop: Header=BB8_55 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	w1, [sp, #148]
	add	x2, sp, #28
	bl	_nvm_mixed_samples_signature
	tbnz	w0, #0, LBB8_58
	b	LBB8_57
LBB8_57:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_mixed_samples_plan_free
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #4436]
	b	LBB8_64
LBB8_58:                                ;   in Loop: Header=BB8_55 Depth=1
	ldrh	w8, [sp, #32]
	ldr	w9, [sp, #148]
	mov	x10, x9
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #344
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB8_59
LBB8_59:                                ;   in Loop: Header=BB8_55 Depth=1
	ldr	w8, [sp, #148]
	add	w8, w8, #1
	str	w8, [sp, #148]
	b	LBB8_55
LBB8_60:
	b	LBB8_61
LBB8_61:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_mixed_samples_plan_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #4232]
	cbz	x8, LBB8_63
	b	LBB8_62
LBB8_62:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #4232]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #344
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB8_63
LBB8_63:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #4240]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	str	wzr, [sp, #4436]
	b	LBB8_64
LBB8_64:
	ldr	w8, [sp, #4436]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB8_66
	b	LBB8_65
LBB8_65:
	bl	___stack_chk_fail
LBB8_66:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #800
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function intern_signature
_intern_signature:                      ; @intern_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB9_1
LBB9_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB9_6
	b	LBB9_2
LBB9_2:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	ldr	x1, [sp, #24]
	bl	_nvm_v2_signature_equal
	tbz	w0, #0, LBB9_4
	b	LBB9_3
LBB9_3:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB9_7
LBB9_4:                                 ;   in Loop: Header=BB9_1 Depth=1
	b	LBB9_5
LBB9_5:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB9_1
LBB9_6:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x8, [sp, #24]
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldur	x10, [x29, #-16]
	ldr	w8, [x10, #8]
	add	w9, w8, #1
	str	w9, [x10, #8]
	stur	w8, [x29, #-4]
	b	LBB9_7
LBB9_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_private_service_wire
_nvm_private_service_wire:              ; @nvm_private_service_wire
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB10_7
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	cbz	x8, LBB10_5
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	cbz	x8, LBB10_5
	b	LBB10_3
LBB10_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
	cbz	w8, LBB10_5
	b	LBB10_4
LBB10_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldur	x0, [x29, #-8]
	blr	x8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB10_6
LBB10_5:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB10_6
LBB10_6:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB10_8
LBB10_7:
	ldur	x0, [x29, #-8]
	bl	_nvm_v2_service_bindings_validate
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB10_8
LBB10_8:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
_SOURCE_FILE_KEY:                       ; @SOURCE_FILE_KEY
	.asciz	"nano.source_file"

.subsections_via_symbols
