	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nl_websocket_plan_build ; -- Begin function nl_websocket_plan_build
	.globl	_nl_websocket_plan_build
	.p2align	2
_nl_websocket_plan_build:               ; @nl_websocket_plan_build
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	cbz	x19, LBB0_6
; %bb.1:
	cbz	x1, LBB0_6
; %bb.2:
	ldr	w8, [x19]
	cbnz	w8, LBB0_6
; %bb.3:
	ldr	x0, [x19, #8]
	cbz	x0, LBB0_5
; %bb.4:
	mov	x20, x1
Lloh0:
	adrp	x1, l_.str@PAGE
Lloh1:
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB0_7
LBB0_5:
	mov	w0, #1                          ; =0x1
LBB0_6:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB0_7:
	ldr	x0, [x19, #16]
	cbz	x0, LBB0_5
; %bb.8:
Lloh2:
	adrp	x1, l_.str.1@PAGE
Lloh3:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.9:
	ldr	x8, [x19, #32]
	cmp	x8, #4
	b.ne	LBB0_5
; %bb.10:
	ldr	x8, [x19, #48]
	cmp	x8, #7
	b.ne	LBB0_5
; %bb.11:
	ldr	x8, [x19, #64]
	cmp	x8, #1
	b.ne	LBB0_5
; %bb.12:
	ldr	x8, [x19, #80]
	cmp	x8, #2
	b.ne	LBB0_5
; %bb.13:
	ldr	x8, [x19, #24]
	cbz	x8, LBB0_5
; %bb.14:
	ldr	x9, [x19, #40]
	cbz	x9, LBB0_5
; %bb.15:
	ldr	x22, [x19, #56]
	cbz	x22, LBB0_5
; %bb.16:
	ldr	x21, [x19, #72]
	cbz	x21, LBB0_5
; %bb.17:
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x0, [x22]
	cbz	x0, LBB0_5
; %bb.18:
	mov	x19, x8
Lloh4:
	adrp	x1, l_.str.2@PAGE
Lloh5:
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.19:
	ldr	x8, [x22, #8]
	cbz	x8, LBB0_5
; %bb.20:
	ldrb	w9, [x8]
	cmp	w9, #105
	b.ne	LBB0_5
; %bb.21:
	ldrb	w9, [x8, #1]
	cmp	w9, #111
	b.ne	LBB0_5
; %bb.22:
	ldrb	w8, [x8, #2]
	cbnz	w8, LBB0_5
; %bb.23:
	ldr	x8, [x22, #16]
	cbz	x8, LBB0_5
; %bb.24:
	ldrb	w9, [x8]
	cmp	w9, #49
	b.ne	LBB0_5
; %bb.25:
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB0_5
; %bb.26:
	ldr	x0, [x21]
	cbz	x0, LBB0_5
; %bb.27:
Lloh6:
	adrp	x1, l_.str.100@PAGE
Lloh7:
	add	x1, x1, l_.str.100@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.28:
	ldr	x0, [x21, #8]
	cbz	x0, LBB0_5
; %bb.29:
Lloh8:
	adrp	x1, l_.str.6@PAGE
Lloh9:
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.30:
	ldr	x0, [x21, #16]
	cbz	x0, LBB0_5
; %bb.31:
Lloh10:
	adrp	x1, l_.str.101@PAGE
Lloh11:
	add	x1, x1, l_.str.101@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.32:
	ldr	x0, [x21, #24]
	cbz	x0, LBB0_5
; %bb.33:
Lloh12:
	adrp	x1, l_.str.102@PAGE
Lloh13:
	add	x1, x1, l_.str.102@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB0_5
; %bb.34:
	mov	x21, #0                         ; =0x0
	mov	w22, #40                        ; =0x28
	mov	w23, #96                        ; =0x60
Lloh14:
	adrp	x24, _methods@PAGE
Lloh15:
	add	x24, x24, _methods@PAGEOFF
LBB0_35:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_46 Depth 2
	madd	x27, x21, x22, x19
	madd	x26, x21, x23, x24
	ldr	x0, [x27]
	ldr	x1, [x26]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_37
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=1
	cmp	x0, x1
	b.eq	LBB0_38
	b	LBB0_5
LBB0_37:                                ;   in Loop: Header=BB0_35 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_38:                                ;   in Loop: Header=BB0_35 Depth=1
	ldr	x0, [x27, #8]
	ldr	x1, [x26, #8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_40
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=1
	cmp	x0, x1
	b.eq	LBB0_41
	b	LBB0_5
LBB0_40:                                ;   in Loop: Header=BB0_35 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=1
	ldr	w8, [x27, #32]
	cbnz	w8, LBB0_5
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=1
	ldr	x25, [x27, #24]
	ldr	x8, [x26, #56]
	cmp	x25, x8
	b.ne	LBB0_5
; %bb.43:                               ;   in Loop: Header=BB0_35 Depth=1
	ldr	x8, [x27, #16]
	cbz	x8, LBB0_5
; %bb.44:                               ;   in Loop: Header=BB0_35 Depth=1
	cbz	x25, LBB0_63
; %bb.45:                               ;   in Loop: Header=BB0_35 Depth=1
	ldr	x9, [x26, #48]
	add	x26, x8, #24
	add	x27, x9, #24
LBB0_46:                                ;   Parent Loop BB0_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x26, #-24]
	ldur	x1, [x27, #-24]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_48
; %bb.47:                               ;   in Loop: Header=BB0_46 Depth=2
	cmp	x0, x1
	b.eq	LBB0_49
	b	LBB0_5
LBB0_48:                                ;   in Loop: Header=BB0_46 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_49:                                ;   in Loop: Header=BB0_46 Depth=2
	ldur	x0, [x26, #-16]
	ldur	x1, [x27, #-16]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_51
; %bb.50:                               ;   in Loop: Header=BB0_46 Depth=2
	cmp	x0, x1
	b.eq	LBB0_52
	b	LBB0_5
LBB0_51:                                ;   in Loop: Header=BB0_46 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_52:                                ;   in Loop: Header=BB0_46 Depth=2
	ldur	x0, [x26, #-8]
	ldur	x1, [x27, #-8]
	cbz	x0, LBB0_55
; %bb.53:                               ;   in Loop: Header=BB0_46 Depth=2
	cbz	x1, LBB0_55
; %bb.54:                               ;   in Loop: Header=BB0_46 Depth=2
	bl	_strcmp
	cbz	w0, LBB0_56
	b	LBB0_5
LBB0_55:                                ;   in Loop: Header=BB0_46 Depth=2
	cmp	x0, x1
	b.ne	LBB0_5
LBB0_56:                                ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26]
	ldr	w9, [x27]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.57:                               ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26, #4]
	ldr	w9, [x27, #4]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.58:                               ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26, #8]
	ldr	w9, [x27, #8]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.59:                               ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26, #12]
	ldr	w9, [x27, #12]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.60:                               ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26, #16]
	cbnz	w8, LBB0_5
; %bb.61:                               ;   in Loop: Header=BB0_46 Depth=2
	ldr	w8, [x26, #20]
	cbnz	w8, LBB0_5
; %bb.62:                               ;   in Loop: Header=BB0_46 Depth=2
	add	x26, x26, #48
	add	x27, x27, #48
	subs	x25, x25, #1
	b.ne	LBB0_46
LBB0_63:                                ;   in Loop: Header=BB0_35 Depth=1
	add	x21, x21, #1
	cmp	x21, #4
	b.ne	LBB0_35
; %bb.64:
	mov	x19, #0                         ; =0x0
	mov	w21, #40                        ; =0x28
Lloh16:
	adrp	x22, _types@PAGE
Lloh17:
	add	x22, x22, _types@PAGEOFF
LBB0_65:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_81 Depth 2
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x25, x8, x19, lsl #6
	madd	x24, x19, x21, x22
	ldr	x0, [x25]
	ldr	x1, [x24]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_67
; %bb.66:                               ;   in Loop: Header=BB0_65 Depth=1
	cmp	x0, x1
	b.eq	LBB0_68
	b	LBB0_5
LBB0_67:                                ;   in Loop: Header=BB0_65 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_68:                                ;   in Loop: Header=BB0_65 Depth=1
	ldr	x0, [x25, #8]
	ldr	x1, [x24, #8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_70
; %bb.69:                               ;   in Loop: Header=BB0_65 Depth=1
	cmp	x0, x1
	b.eq	LBB0_71
	b	LBB0_5
LBB0_70:                                ;   in Loop: Header=BB0_65 Depth=1
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_71:                                ;   in Loop: Header=BB0_65 Depth=1
	ldr	w8, [x25, #16]
	ldr	w9, [x24, #16]
	cmp	w8, w9
	b.ne	LBB0_5
; %bb.72:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x23, [x25, #32]
	ldr	x8, [x24, #32]
	cmp	x23, x8
	b.ne	LBB0_5
; %bb.73:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x8, [x25, #40]
	cbnz	x8, LBB0_5
; %bb.74:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x8, [x25, #48]
	cbnz	x8, LBB0_5
; %bb.75:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x8, [x25, #56]
	cbnz	x8, LBB0_5
; %bb.76:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x8, [x25, #24]
	cbz	x23, LBB0_90
; %bb.77:                               ;   in Loop: Header=BB0_65 Depth=1
	cbz	x8, LBB0_5
; %bb.78:                               ;   in Loop: Header=BB0_65 Depth=1
	ldr	x9, [x24, #24]
	add	x24, x9, #16
	add	x25, x8, #16
	b	LBB0_81
LBB0_79:                                ;   in Loop: Header=BB0_81 Depth=2
	cmp	x0, x1
	b.ne	LBB0_5
LBB0_80:                                ;   in Loop: Header=BB0_81 Depth=2
	add	x24, x24, #32
	add	x25, x25, #24
	subs	x23, x23, #1
	b.eq	LBB0_91
LBB0_81:                                ;   Parent Loop BB0_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x25, #-16]
	ldur	x1, [x24, #-16]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_83
; %bb.82:                               ;   in Loop: Header=BB0_81 Depth=2
	cmp	x0, x1
	b.eq	LBB0_84
	b	LBB0_5
LBB0_83:                                ;   in Loop: Header=BB0_81 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_84:                                ;   in Loop: Header=BB0_81 Depth=2
	ldur	x0, [x25, #-8]
	ldur	x1, [x24, #-8]
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	b.ne	LBB0_86
; %bb.85:                               ;   in Loop: Header=BB0_81 Depth=2
	cmp	x0, x1
	b.eq	LBB0_87
	b	LBB0_5
LBB0_86:                                ;   in Loop: Header=BB0_81 Depth=2
	bl	_strcmp
	cbnz	w0, LBB0_5
LBB0_87:                                ;   in Loop: Header=BB0_81 Depth=2
	ldr	x0, [x25]
	ldr	x1, [x24]
	cbz	x0, LBB0_79
; %bb.88:                               ;   in Loop: Header=BB0_81 Depth=2
	cbz	x1, LBB0_79
; %bb.89:                               ;   in Loop: Header=BB0_81 Depth=2
	bl	_strcmp
	cbz	w0, LBB0_80
	b	LBB0_5
LBB0_90:                                ;   in Loop: Header=BB0_65 Depth=1
	cbnz	x8, LBB0_5
LBB0_91:                                ;   in Loop: Header=BB0_65 Depth=1
	add	x19, x19, #1
	cmp	x19, #7
	b.ne	LBB0_65
; %bb.92:
	mov	w0, #8                          ; =0x8
	bl	_malloc
	cbz	x0, LBB0_94
; %bb.93:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
Lloh18:
	adrp	x9, _catalog@PAGE
Lloh19:
	add	x9, x9, _catalog@PAGEOFF
	str	x9, [x8]
	str	x8, [x20]
	b	LBB0_6
LBB0_94:
	mov	w0, #2                          ; =0x2
	b	LBB0_6
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_free ; -- Begin function nl_websocket_plan_free
	.globl	_nl_websocket_plan_free
	.p2align	2
_nl_websocket_plan_free:                ; @nl_websocket_plan_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_storage_size ; -- Begin function nl_websocket_plan_storage_size
	.globl	_nl_websocket_plan_storage_size
	.p2align	2
_nl_websocket_plan_storage_size:        ; @nl_websocket_plan_storage_size
	.cfi_startproc
; %bb.0:
	mov	w0, #8                          ; =0x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_interface ; -- Begin function nl_websocket_plan_interface
	.globl	_nl_websocket_plan_interface
	.p2align	2
_nl_websocket_plan_interface:           ; @nl_websocket_plan_interface
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8]
LBB3_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_method_count ; -- Begin function nl_websocket_plan_method_count
	.globl	_nl_websocket_plan_method_count
	.p2align	2
_nl_websocket_plan_method_count:        ; @nl_websocket_plan_method_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #64]
LBB4_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_type_count ; -- Begin function nl_websocket_plan_type_count
	.globl	_nl_websocket_plan_type_count
	.p2align	2
_nl_websocket_plan_type_count:          ; @nl_websocket_plan_type_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #80]
LBB5_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_capability_count ; -- Begin function nl_websocket_plan_capability_count
	.globl	_nl_websocket_plan_capability_count
	.p2align	2
_nl_websocket_plan_capability_count:    ; @nl_websocket_plan_capability_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #48]
LBB6_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_method ; -- Begin function nl_websocket_plan_method
	.globl	_nl_websocket_plan_method
	.p2align	2
_nl_websocket_plan_method:              ; @nl_websocket_plan_method
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_3
; %bb.1:
	ldr	x8, [x0]
	ldr	x9, [x8, #64]
	cmp	x1, x9
	b.hs	LBB7_4
; %bb.2:
	ldr	x8, [x8, #56]
	mov	w9, #96                         ; =0x60
	madd	x0, x1, x9, x8
LBB7_3:
	ret
LBB7_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_type ; -- Begin function nl_websocket_plan_type
	.globl	_nl_websocket_plan_type
	.p2align	2
_nl_websocket_plan_type:                ; @nl_websocket_plan_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_3
; %bb.1:
	ldr	x8, [x0]
	ldr	x9, [x8, #80]
	cmp	x1, x9
	b.hs	LBB8_4
; %bb.2:
	ldr	x8, [x8, #72]
	mov	w9, #40                         ; =0x28
	madd	x0, x1, x9, x8
LBB8_3:
	ret
LBB8_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_capability ; -- Begin function nl_websocket_plan_capability
	.globl	_nl_websocket_plan_capability
	.p2align	2
_nl_websocket_plan_capability:          ; @nl_websocket_plan_capability
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_3
; %bb.1:
	ldr	x8, [x0]
	ldr	x9, [x8, #48]
	cmp	x1, x9
	b.hs	LBB9_4
; %bb.2:
	ldr	x8, [x8, #40]
	add	x0, x8, x1, lsl #4
LBB9_3:
	ret
LBB9_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_interface ; -- Begin function nl_websocket_catalog_interface
	.globl	_nl_websocket_catalog_interface
	.p2align	2
_nl_websocket_catalog_interface:        ; @nl_websocket_catalog_interface
	.cfi_startproc
; %bb.0:
Lloh20:
	adrp	x0, l_.str@PAGE
Lloh21:
	add	x0, x0, l_.str@PAGEOFF
	ret
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_method ; -- Begin function nl_websocket_catalog_method
	.globl	_nl_websocket_catalog_method
	.p2align	2
_nl_websocket_catalog_method:           ; @nl_websocket_catalog_method
	.cfi_startproc
; %bb.0:
	mov	w8, #96                         ; =0x60
Lloh22:
	adrp	x9, _methods@PAGE
Lloh23:
	add	x9, x9, _methods@PAGEOFF
	madd	x8, x0, x8, x9
	cmp	x0, #4
	csel	x0, x8, xzr, lo
	ret
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_type ; -- Begin function nl_websocket_catalog_type
	.globl	_nl_websocket_catalog_type
	.p2align	2
_nl_websocket_catalog_type:             ; @nl_websocket_catalog_type
	.cfi_startproc
; %bb.0:
	mov	w8, #40                         ; =0x28
Lloh24:
	adrp	x9, _types@PAGE
Lloh25:
	add	x9, x9, _types@PAGEOFF
	madd	x8, x0, x8, x9
	cmp	x0, #7
	csel	x0, x8, xzr, lo
	ret
	.loh AdrpAdd	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_capability ; -- Begin function nl_websocket_catalog_capability
	.globl	_nl_websocket_catalog_capability
	.p2align	2
_nl_websocket_catalog_capability:       ; @nl_websocket_catalog_capability
	.cfi_startproc
; %bb.0:
Lloh26:
	adrp	x8, _capabilities@PAGE
Lloh27:
	add	x8, x8, _capabilities@PAGEOFF
	add	x8, x8, x0, lsl #4
	cmp	x0, #2
	csel	x0, x8, xzr, lo
	ret
	.loh AdrpAdd	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__const
	.p2align	3, 0x0                          ; @catalog
_catalog:
	.quad	l_.str
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	_capabilities
	.quad	2                               ; 0x2
	.quad	_methods
	.quad	4                               ; 0x4
	.quad	_types
	.quad	7                               ; 0x7

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/websocket"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @capabilities
_capabilities:
	.quad	l_.str.100
	.quad	l_.str.6
	.quad	l_.str.101
	.quad	l_.str.102

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"websocket"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/websocket#io"

l_.str.3:                               ; @.str.3
	.asciz	"io"

l_.str.4:                               ; @.str.4
	.asciz	"1"

l_.str.5:                               ; @.str.5
	.asciz	"nsi:nanolang/websocket#connect"

l_.str.6:                               ; @.str.6
	.asciz	"connect"

l_.str.7:                               ; @.str.7
	.asciz	"nsi_nanolang_websocket_connect"

l_.str.8:                               ; @.str.8
	.asciz	"nsi.websocket.v1.connect"

l_.str.9:                               ; @.str.9
	.asciz	"nsi:nanolang/websocket#Connection"

l_.str.10:                              ; @.str.10
	.asciz	"nsi:nanolang/websocket#send"

l_.str.11:                              ; @.str.11
	.asciz	"send"

l_.str.12:                              ; @.str.12
	.asciz	"nsi_nanolang_websocket_send"

l_.str.13:                              ; @.str.13
	.asciz	"nsi.websocket.v1.send"

l_.str.14:                              ; @.str.14
	.asciz	"nsi:nanolang/websocket#receive"

l_.str.15:                              ; @.str.15
	.asciz	"receive"

l_.str.16:                              ; @.str.16
	.asciz	"nsi_nanolang_websocket_receive"

l_.str.17:                              ; @.str.17
	.asciz	"nsi.websocket.v1.receive"

l_.str.18:                              ; @.str.18
	.asciz	"nsi:nanolang/websocket#close"

l_.str.19:                              ; @.str.19
	.asciz	"close"

l_.str.20:                              ; @.str.20
	.asciz	"nsi_nanolang_websocket_close"

l_.str.21:                              ; @.str.21
	.asciz	"nsi.websocket.v1.close"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @methods
_methods:
	.quad	l_.str.5
	.quad	l_.str.6
	.quad	l_.str.7
	.quad	l_.str.8
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	19                              ; 0x13
	.long	0                               ; 0x0
	.quad	_connect_params
	.quad	3                               ; 0x3
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.9
	.space	16
	.quad	l_.str.10
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_send_params
	.quad	4                               ; 0x4
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.14
	.quad	l_.str.15
	.quad	l_.str.16
	.quad	l_.str.17
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_receive_params
	.quad	3                               ; 0x3
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.18
	.quad	l_.str.19
	.quad	l_.str.20
	.quad	l_.str.21
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.quad	_close_params
	.quad	3                               ; 0x3
	.long	2                               ; 0x2
	.space	4
	.quad	0
	.long	2                               ; 0x2
	.space	4
	.quad	0

	.section	__TEXT,__cstring,cstring_literals
l_.str.23:                              ; @.str.23
	.asciz	"nsi:nanolang/websocket#connect.url"

l_.str.24:                              ; @.str.24
	.asciz	"url"

l_.str.25:                              ; @.str.25
	.asciz	"nsi:core/string"

l_.str.26:                              ; @.str.26
	.asciz	"nsi:nanolang/websocket#connect.timeout_ms"

l_.str.27:                              ; @.str.27
	.asciz	"timeout_ms"

l_.str.28:                              ; @.str.28
	.asciz	"nsi:core/int"

l_.str.29:                              ; @.str.29
	.asciz	"nsi:nanolang/websocket#connect.result"

l_.str.30:                              ; @.str.30
	.asciz	"result"

l_.str.31:                              ; @.str.31
	.asciz	"nsi:nanolang/websocket#ConnectResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @connect_params
_connect_params:
	.quad	l_.str.23
	.quad	l_.str.24
	.quad	l_.str.25
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.26
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.29
	.quad	l_.str.30
	.quad	l_.str.31
	.long	3                               ; 0x3
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.33:                              ; @.str.33
	.asciz	"nsi:nanolang/websocket#send.connection"

l_.str.34:                              ; @.str.34
	.asciz	"connection"

l_.str.35:                              ; @.str.35
	.asciz	"nsi:nanolang/websocket#send.message"

l_.str.36:                              ; @.str.36
	.asciz	"message"

l_.str.37:                              ; @.str.37
	.asciz	"nsi:nanolang/websocket#Message"

l_.str.38:                              ; @.str.38
	.asciz	"nsi:nanolang/websocket#send.timeout_ms"

l_.str.39:                              ; @.str.39
	.asciz	"nsi:nanolang/websocket#send.result"

l_.str.40:                              ; @.str.40
	.asciz	"nsi:nanolang/websocket#SendResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @send_params
_send_params:
	.quad	l_.str.33
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.35
	.quad	l_.str.36
	.quad	l_.str.37
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.38
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.39
	.quad	l_.str.30
	.quad	l_.str.40
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.42:                              ; @.str.42
	.asciz	"nsi:nanolang/websocket#receive.connection"

l_.str.43:                              ; @.str.43
	.asciz	"nsi:nanolang/websocket#receive.timeout_ms"

l_.str.44:                              ; @.str.44
	.asciz	"nsi:nanolang/websocket#receive.result"

l_.str.45:                              ; @.str.45
	.asciz	"nsi:nanolang/websocket#ReceiveResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @receive_params
_receive_params:
	.quad	l_.str.42
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.43
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.44
	.quad	l_.str.30
	.quad	l_.str.45
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.47:                              ; @.str.47
	.asciz	"nsi:nanolang/websocket#close.connection"

l_.str.48:                              ; @.str.48
	.asciz	"nsi:nanolang/websocket#close.timeout_ms"

l_.str.49:                              ; @.str.49
	.asciz	"nsi:nanolang/websocket#close.result"

l_.str.50:                              ; @.str.50
	.asciz	"nsi:nanolang/websocket#CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @close_params
_close_params:
	.quad	l_.str.47
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.48
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.49
	.quad	l_.str.30
	.quad	l_.str.50
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.52:                              ; @.str.52
	.asciz	"Connection"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:nanolang/websocket#WebSocketError"

l_.str.54:                              ; @.str.54
	.asciz	"WebSocketError"

l_.str.55:                              ; @.str.55
	.asciz	"Message"

l_.str.56:                              ; @.str.56
	.asciz	"ConnectResult"

l_.str.57:                              ; @.str.57
	.asciz	"SendResult"

l_.str.58:                              ; @.str.58
	.asciz	"ReceiveResult"

l_.str.59:                              ; @.str.59
	.asciz	"CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @types
_types:
	.quad	l_.str.9
	.quad	l_.str.52
	.long	6                               ; 0x6
	.space	4
	.quad	0
	.quad	0                               ; 0x0
	.quad	l_.str.53
	.quad	l_.str.54
	.long	1                               ; 0x1
	.space	4
	.quad	_error_fields
	.quad	9                               ; 0x9
	.quad	l_.str.37
	.quad	l_.str.55
	.long	1                               ; 0x1
	.space	4
	.quad	_message_fields
	.quad	2                               ; 0x2
	.quad	l_.str.31
	.quad	l_.str.56
	.long	2                               ; 0x2
	.space	4
	.quad	_ConnectResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.40
	.quad	l_.str.57
	.long	2                               ; 0x2
	.space	4
	.quad	_SendResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.45
	.quad	l_.str.58
	.long	2                               ; 0x2
	.space	4
	.quad	_ReceiveResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.50
	.quad	l_.str.59
	.long	2                               ; 0x2
	.space	4
	.quad	_CloseResult_cases
	.quad	2                               ; 0x2

	.section	__TEXT,__cstring,cstring_literals
l_.str.61:                              ; @.str.61
	.asciz	"nsi:nanolang/websocket#WebSocketError.status"

l_.str.62:                              ; @.str.62
	.asciz	"status"

l_.str.63:                              ; @.str.63
	.asciz	"nsi:nanolang/websocket#WebSocketError.host_errno"

l_.str.64:                              ; @.str.64
	.asciz	"host_errno"

l_.str.65:                              ; @.str.65
	.asciz	"nsi:nanolang/websocket#WebSocketError.resolver_error"

l_.str.66:                              ; @.str.66
	.asciz	"resolver_error"

l_.str.67:                              ; @.str.67
	.asciz	"nsi:nanolang/websocket#WebSocketError.supervisor_status"

l_.str.68:                              ; @.str.68
	.asciz	"supervisor_status"

l_.str.69:                              ; @.str.69
	.asciz	"nsi:nanolang/websocket#WebSocketError.close_code"

l_.str.70:                              ; @.str.70
	.asciz	"close_code"

l_.str.71:                              ; @.str.71
	.asciz	"nsi:nanolang/websocket#WebSocketError.cleanup_errno"

l_.str.72:                              ; @.str.72
	.asciz	"cleanup_errno"

l_.str.73:                              ; @.str.73
	.asciz	"nsi:nanolang/websocket#WebSocketError.cleanup_failed"

l_.str.74:                              ; @.str.74
	.asciz	"cleanup_failed"

l_.str.75:                              ; @.str.75
	.asciz	"nsi:core/bool"

l_.str.76:                              ; @.str.76
	.asciz	"nsi:nanolang/websocket#WebSocketError.closure_unknown"

l_.str.77:                              ; @.str.77
	.asciz	"closure_unknown"

l_.str.78:                              ; @.str.78
	.asciz	"nsi:nanolang/websocket#WebSocketError.terminal"

l_.str.79:                              ; @.str.79
	.asciz	"terminal"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @error_fields
_error_fields:
	.quad	l_.str.61
	.quad	l_.str.62
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.63
	.quad	l_.str.64
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.65
	.quad	l_.str.66
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.67
	.quad	l_.str.68
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.69
	.quad	l_.str.70
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.71
	.quad	l_.str.72
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.73
	.quad	l_.str.74
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.76
	.quad	l_.str.77
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.78
	.quad	l_.str.79
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.81:                              ; @.str.81
	.asciz	"nsi:nanolang/websocket#Message.binary"

l_.str.82:                              ; @.str.82
	.asciz	"binary"

l_.str.83:                              ; @.str.83
	.asciz	"nsi:nanolang/websocket#Message.data"

l_.str.84:                              ; @.str.84
	.asciz	"data"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @message_fields
_message_fields:
	.quad	l_.str.81
	.quad	l_.str.82
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.83
	.quad	l_.str.84
	.quad	l_.str.25
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.86:                              ; @.str.86
	.asciz	"nsi:nanolang/websocket#ConnectResult.Ok"

l_.str.87:                              ; @.str.87
	.asciz	"Ok"

l_.str.88:                              ; @.str.88
	.asciz	"nsi:nanolang/websocket#ConnectResult.Error"

l_.str.89:                              ; @.str.89
	.asciz	"Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ConnectResult_cases
_ConnectResult_cases:
	.quad	l_.str.86
	.quad	l_.str.87
	.quad	l_.str.9
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.88
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.91:                              ; @.str.91
	.asciz	"nsi:nanolang/websocket#SendResult.Ok"

l_.str.92:                              ; @.str.92
	.asciz	"nsi:nanolang/websocket#SendResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @SendResult_cases
_SendResult_cases:
	.quad	l_.str.91
	.quad	l_.str.87
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.92
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.94:                              ; @.str.94
	.asciz	"nsi:nanolang/websocket#ReceiveResult.Ok"

l_.str.95:                              ; @.str.95
	.asciz	"nsi:nanolang/websocket#ReceiveResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ReceiveResult_cases
_ReceiveResult_cases:
	.quad	l_.str.94
	.quad	l_.str.87
	.quad	l_.str.37
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.95
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.97:                              ; @.str.97
	.asciz	"nsi:nanolang/websocket#CloseResult.Ok"

l_.str.98:                              ; @.str.98
	.asciz	"nsi:nanolang/websocket#CloseResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @CloseResult_cases
_CloseResult_cases:
	.quad	l_.str.97
	.quad	l_.str.87
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.98
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.100:                             ; @.str.100
	.asciz	"cap:nanolang/websocket.connect"

l_.str.101:                             ; @.str.101
	.asciz	"cap:nanolang/net.lookup"

l_.str.102:                             ; @.str.102
	.asciz	"lookup"

.subsections_via_symbols
