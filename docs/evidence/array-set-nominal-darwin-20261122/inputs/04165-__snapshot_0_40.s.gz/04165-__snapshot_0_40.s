	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_vm_heap_init                   ; -- Begin function vm_heap_init
	.p2align	2
_vm_heap_init:                          ; @vm_heap_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #96                         ; =0x60
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x9, [sp, #8]
	mov	w8, #256                        ; =0x100
	str	w8, [x9, #56]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #60]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #56]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldr	x8, [sp, #8]
	str	x0, [x8, #48]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #8]
	str	wzr, [x8, #56]
	b	LBB0_2
LBB0_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_heap_destroy                ; -- Begin function vm_heap_destroy
	.p2align	2
_vm_heap_destroy:                       ; @vm_heap_destroy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x0, [x29, #-8]
	bl	_vm_gc_collect_cycles
	ldur	x0, [x29, #-8]
	bl	_vm_gc_cycle_buffer_free
	stur	wzr, [x29, #-12]
	b	LBB1_1
LBB1_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_6 Depth 2
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #56]
	subs	w8, w8, w9
	b.hs	LBB1_10
	b	LBB1_2
LBB1_2:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #48]
	cbz	x8, LBB1_4
	b	LBB1_3
LBB1_3:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #48]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_5
LBB1_4:                                 ;   in Loop: Header=BB1_1 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #24]
	b	LBB1_6
LBB1_6:                                 ;   Parent Loop BB1_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	cbz	x8, LBB1_8
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_6 Depth=2
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	str	x8, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB1_6
LBB1_8:                                 ;   in Loop: Header=BB1_1 Depth=1
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldur	w8, [x29, #-12]
	add	w8, w8, #1
	stur	w8, [x29, #-12]
	b	LBB1_1
LBB1_10:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #48]
	bl	_free
	ldur	x8, [x29, #-8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #48]
	ldur	x8, [x29, #-8]
	str	wzr, [x8, #56]
	ldur	x8, [x29, #-8]
	str	wzr, [x8, #60]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_retain                      ; -- Begin function vm_retain
	.p2align	2
_vm_retain:                             ; @vm_retain
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_val_is_heap_obj
	tbnz	w0, #0, LBB2_2
	b	LBB2_1
LBB2_1:
	b	LBB2_7
LBB2_2:
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB2_4
	b	LBB2_3
LBB2_3:
	b	LBB2_7
LBB2_4:
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]
	ldr	x8, [sp, #24]
	cbz	x8, LBB2_6
	b	LBB2_5
LBB2_5:
	ldr	x9, [sp, #24]
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	b	LBB2_6
LBB2_6:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB2_7
LBB2_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_is_heap_obj
_val_is_heap_obj:                       ; @val_is_heap_obj
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #5
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_1
LBB3_1:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #6
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_2
LBB3_2:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #7
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_3
LBB3_3:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_4
LBB3_4:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_5
LBB3_5:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #12
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_6
LBB3_6:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #13
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB3_8
	b	LBB3_7
LBB3_7:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #15
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB3_8
LBB3_8:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_bstring_adopt               ; -- Begin function vm_bstring_adopt
	.p2align	2
_vm_bstring_adopt:                      ; @vm_bstring_adopt
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_8
LBB4_2:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB4_4
	b	LBB4_3
LBB4_3:
	mov	x0, #16                         ; =0x10
	bl	_malloc
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_5
LBB4_4:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB4_5
LBB4_5:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB4_7
	b	LBB4_6
LBB4_6:
	ldr	x0, [sp, #24]
	bl	_nl_string_free_owned_storage
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB4_8
LBB4_7:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp, #16]
	mov	w8, #6                          ; =0x6
	strb	w8, [x9, #4]
	ldr	x8, [sp, #16]
	strb	wzr, [x8, #5]
	ldr	x8, [sp, #16]
	strb	wzr, [x8, #6]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	add	x10, x8, #48
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB4_8
LBB4_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_string_free_owned_storage
_nl_string_free_owned_storage:          ; @nl_string_free_owned_storage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	b	LBB5_3
LBB5_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB5_3
LBB5_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_bstring_clear               ; -- Begin function vm_bstring_clear
	.p2align	2
_vm_bstring_clear:                      ; @vm_bstring_clear
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB6_3
	b	LBB6_2
LBB6_2:
	b	LBB6_4
LBB6_3:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #16]
	add	x10, x8, #32
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldr	x8, [sp]
	ldr	x0, [x8, #8]
	bl	_nl_string_free_owned_storage
	ldr	x8, [sp]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #8]
	b	LBB6_4
LBB6_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_release                     ; -- Begin function vm_release
	.p2align	2
_vm_release:                            ; @vm_release
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	stur	x0, [x29, #-24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_val_is_heap_obj
	tbnz	w0, #0, LBB7_2
	b	LBB7_1
LBB7_1:
	b	LBB7_32
LBB7_2:
	ldur	x8, [x29, #-8]
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB7_4
	b	LBB7_3
LBB7_3:
	b	LBB7_32
LBB7_4:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB7_6
	b	LBB7_5
LBB7_5:
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #40]
	add	x8, x8, #1
	str	x8, [x9, #40]
	b	LBB7_6
LBB7_6:
	ldr	x8, [sp, #32]
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	cbnz	w8, LBB7_8
	b	LBB7_7
LBB7_7:
	b	LBB7_32
LBB7_8:
	ldr	x9, [sp, #24]
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB7_12
	b	LBB7_9
LBB7_9:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB7_11
	b	LBB7_10
LBB7_10:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	bl	_vm_gc_note_suspect
	b	LBB7_11
LBB7_11:
	b	LBB7_32
LBB7_12:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB7_15
	b	LBB7_13
LBB7_13:
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB7_15
	b	LBB7_14
LBB7_14:
	ldr	x8, [sp, #24]
	strb	wzr, [x8, #5]
	b	LBB7_32
LBB7_15:
	ldurb	w8, [x29, #-16]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #5
	b.eq	LBB7_24
	b	LBB7_16
LBB7_16:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB7_23
	b	LBB7_17
LBB7_17:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #7
	b.eq	LBB7_25
	b	LBB7_18
LBB7_18:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB7_26
	b	LBB7_19
LBB7_19:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB7_27
	b	LBB7_20
LBB7_20:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB7_28
	b	LBB7_21
LBB7_21:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB7_29
	b	LBB7_22
LBB7_22:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB7_30
	b	LBB7_31
LBB7_23:
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #16]
	bl	_vm_bstring_clear
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #8]
	add	x8, x8, #16
	str	x8, [x9, #8]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_free
	b	LBB7_32
LBB7_24:
	ldur	x8, [x29, #-8]
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #24
	add	x10, x8, #1
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-24]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #8]
	bl	_vm_intern_unlink
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB7_32
LBB7_25:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_array
	b	LBB7_32
LBB7_26:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_struct
	b	LBB7_32
LBB7_27:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_union
	b	LBB7_32
LBB7_28:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_tuple
	b	LBB7_32
LBB7_29:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_hashmap
	b	LBB7_32
LBB7_30:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-8]
	bl	_release_closure
	b	LBB7_32
LBB7_31:
	b	LBB7_32
LBB7_32:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_intern_unlink
_vm_intern_unlink:                      ; @vm_intern_unlink
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #56]
	cbnz	w8, LBB8_2
	b	LBB8_1
LBB8_1:
	b	LBB8_7
LBB8_2:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #56]
	subs	w9, w9, #1
	and	w8, w8, w9
	str	w8, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #48]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp]
	b	LBB8_3
LBB8_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB8_7
	b	LBB8_4
LBB8_4:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	LBB8_6
	b	LBB8_5
LBB8_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp]
	str	x8, [x9]
	ldr	x8, [sp, #16]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldr	x9, [sp, #24]
	ldr	w8, [x9, #60]
	subs	w8, w8, #1
	str	w8, [x9, #60]
	b	LBB8_7
LBB8_6:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8]
	add	x8, x8, #16
	str	x8, [sp]
	b	LBB8_3
LBB8_7:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_array
_release_array:                         ; @release_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [sp, #16]
	ldrb	w0, [x8, #8]
	bl	_vm_array_elem_size
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mul	x8, x8, x0
	add	x10, x8, #40
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x0, [sp, #16]
	bl	_free
	b	LBB9_7
LBB9_2:
	str	wzr, [sp, #12]
	b	LBB9_3
LBB9_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB9_6
	b	LBB9_4
LBB9_4:                                 ;   in Loop: Header=BB9_3 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_release
	b	LBB9_5
LBB9_5:                                 ;   in Loop: Header=BB9_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB9_3
LBB9_6:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #40
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x0, [sp, #16]
	bl	_free
	b	LBB9_7
LBB9_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_struct
_release_struct:                        ; @release_struct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	wzr, [x29, #-20]
	b	LBB10_1
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB10_4
	b	LBB10_2
LBB10_2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_release
	b	LBB10_3
LBB10_3:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB10_1
LBB10_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	cbz	x8, LBB10_12
	b	LBB10_5
LBB10_5:
	str	wzr, [sp, #24]
	b	LBB10_6
LBB10_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB10_11
	b	LBB10_7
LBB10_7:                                ;   in Loop: Header=BB10_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB10_9
	b	LBB10_8
LBB10_8:                                ;   in Loop: Header=BB10_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_string
	str	x0, [sp, #8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #16]
	bl	_vm_release
	b	LBB10_9
LBB10_9:                                ;   in Loop: Header=BB10_6 Depth=1
	b	LBB10_10
LBB10_10:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB10_6
LBB10_11:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #16]
	bl	_free
	b	LBB10_12
LBB10_12:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #32
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #24]
	bl	_free
	ldur	x0, [x29, #-16]
	bl	_free
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_union
_release_union:                         ; @release_union
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB11_1
LBB11_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB11_4
	b	LBB11_2
LBB11_2:                                ;   in Loop: Header=BB11_1 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_release
	b	LBB11_3
LBB11_3:                                ;   in Loop: Header=BB11_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB11_1
LBB11_4:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #14]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #24
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x0, [sp, #16]
	bl	_free
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_tuple
_release_tuple:                         ; @release_tuple
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB12_1
LBB12_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB12_4
	b	LBB12_2
LBB12_2:                                ;   in Loop: Header=BB12_1 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	add	x8, x8, #16
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_release
	b	LBB12_3
LBB12_3:                                ;   in Loop: Header=BB12_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB12_1
LBB12_4:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x8, x8, #16
	str	x8, [sp]
	ldr	x10, [sp]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_free
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_hashmap
_release_hashmap:                       ; @release_hashmap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB13_1
LBB13_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB13_6
	b	LBB13_2
LBB13_2:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB13_4
	b	LBB13_3
LBB13_3:                                ;   in Loop: Header=BB13_1 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	ldr	x2, [x8, #16]
	bl	_vm_release
	ldur	x0, [x29, #-8]
	ldr	x8, [sp]
	ldr	x1, [x8, #24]
	ldr	x2, [x8, #32]
	bl	_vm_release
	b	LBB13_4
LBB13_4:                                ;   in Loop: Header=BB13_1 Depth=1
	b	LBB13_5
LBB13_5:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB13_1
LBB13_6:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	add	x10, x8, #32
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x0, [sp, #16]
	bl	_free
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_closure
_release_closure:                       ; @release_closure
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strh	wzr, [sp, #14]
	b	LBB14_1
LBB14_1:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB14_4
	b	LBB14_2
LBB14_2:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	add	x8, x8, #24
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_release
	b	LBB14_3
LBB14_3:                                ;   in Loop: Header=BB14_1 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB14_1
LBB14_4:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x8, x8, #24
	str	x8, [sp]
	ldr	x10, [sp]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #16]
	subs	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_free
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_new                  ; -- Begin function vm_string_new
	.p2align	2
_vm_string_new:                         ; @vm_string_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #24
	add	x8, x8, #1
	adds	x8, x8, #1
	b.hi	LBB15_3
	b	LBB15_1
LBB15_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB15_4
	b	LBB15_2
LBB15_2:
	ldur	w8, [x29, #-28]
	cbz	w8, LBB15_4
	b	LBB15_3
LBB15_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_15
LBB15_4:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB15_6
	b	LBB15_5
LBB15_5:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB15_6
LBB15_6:
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-28]
	bl	_fnv1a
	str	w0, [sp, #32]
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #32]
	ldur	x2, [x29, #-24]
	ldur	w3, [x29, #-28]
	bl	_vm_intern_lookup
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbz	x8, LBB15_10
	b	LBB15_7
LBB15_7:
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB15_9
	b	LBB15_8
LBB15_8:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_15
LBB15_9:
	ldr	x9, [sp, #24]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #24]
	stur	x8, [x29, #-8]
	b	LBB15_15
LBB15_10:
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #24
	add	x8, x8, #1
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_malloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB15_12
	b	LBB15_11
LBB15_11:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_15
LBB15_12:
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp, #8]
	mov	w8, #5                          ; =0x5
	strb	w8, [x9, #4]
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #5]
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #6]
	ldur	w8, [x29, #-28]
	ldr	x9, [sp, #8]
	str	w8, [x9, #8]
	ldr	w8, [sp, #32]
	ldr	x9, [sp, #8]
	str	w8, [x9, #12]
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldr	x8, [sp, #8]
	add	x0, x8, #24
	ldur	x1, [x29, #-24]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #8]
	add	x8, x8, #24
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	bl	_vm_intern_insert
	tbnz	w0, #0, LBB15_14
	b	LBB15_13
LBB15_13:
	ldr	x0, [sp, #8]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_15
LBB15_14:
	ldr	x10, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB15_15
LBB15_15:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fnv1a
_fnv1a:                                 ; @fnv1a
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	mov	w8, #40389                      ; =0x9dc5
	movk	w8, #33052, lsl #16
	str	w8, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB16_1
LBB16_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.hs	LBB16_4
	b	LBB16_2
LBB16_2:                                ;   in Loop: Header=BB16_1 Depth=1
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldrb	w9, [x8, x9]
	ldr	w8, [sp, #16]
	eor	w8, w8, w9
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
	mov	w9, #403                        ; =0x193
	movk	w9, #256, lsl #16
	mul	w8, w8, w9
	str	w8, [sp, #16]
	b	LBB16_3
LBB16_3:                                ;   in Loop: Header=BB16_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB16_1
LBB16_4:
	ldr	w0, [sp, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_intern_lookup
_vm_intern_lookup:                      ; @vm_intern_lookup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	str	w3, [sp, #12]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #56]
	cbnz	w8, LBB17_2
	b	LBB17_1
LBB17_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB17_11
LBB17_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #56]
	subs	w9, w9, #1
	and	w8, w8, w9
	str	w8, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp]
	b	LBB17_3
LBB17_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	cbz	x8, LBB17_10
	b	LBB17_4
LBB17_4:                                ;   in Loop: Header=BB17_3 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB17_8
	b	LBB17_5
LBB17_5:                                ;   in Loop: Header=BB17_3 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB17_8
	b	LBB17_6
LBB17_6:                                ;   in Loop: Header=BB17_3 Depth=1
	ldr	x8, [sp]
	add	x0, x8, #24
	ldr	x1, [sp, #16]
	ldr	w8, [sp, #12]
	mov	x2, x8
	bl	_memcmp
	cbnz	w0, LBB17_8
	b	LBB17_7
LBB17_7:
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB17_11
LBB17_8:                                ;   in Loop: Header=BB17_3 Depth=1
	b	LBB17_9
LBB17_9:                                ;   in Loop: Header=BB17_3 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	str	x8, [sp]
	b	LBB17_3
LBB17_10:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB17_11
LBB17_11:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_intern_insert
_vm_intern_insert:                      ; @vm_intern_insert
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_vm_intern_maybe_grow
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #56]
	cbnz	w8, LBB18_2
	b	LBB18_1
LBB18_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_3
LBB18_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #56]
	subs	w9, w9, #1
	and	w8, w8, w9
	str	w8, [sp, #4]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #48]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #8]
	str	x8, [x9, #16]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #48]
	ldr	w10, [sp, #4]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	ldr	x10, [sp, #16]
	ldr	w8, [x10, #60]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #60]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB18_3
LBB18_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_concat               ; -- Begin function vm_string_concat
	.p2align	2
_vm_string_concat:                      ; @vm_string_concat
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB19_2
	b	LBB19_1
LBB19_1:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB19_3
	b	LBB19_2
LBB19_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB19_11
LBB19_3:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.hi	LBB19_5
	b	LBB19_4
LBB19_4:
	ldr	x8, [sp, #40]
	add	x8, x8, #24
	add	x8, x8, #1
	adds	x8, x8, #1
	b.ls	LBB19_6
	b	LBB19_5
LBB19_5:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB19_11
LBB19_6:
	ldr	x8, [sp, #40]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
	cbnz	w8, LBB19_8
	b	LBB19_7
LBB19_7:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_vm_string_new
	stur	x0, [x29, #-8]
	b	LBB19_11
LBB19_8:
	ldr	w8, [sp, #36]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB19_10
	b	LBB19_9
LBB19_9:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB19_11
LBB19_10:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-24]
	add	x1, x8, #24
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-32]
	add	x1, x8, #24
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	mov	x2, x8
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	w2, [sp, #36]
	bl	_vm_string_new
	str	x0, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB19_11
LBB19_11:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_substr               ; -- Begin function vm_string_substr
	.p2align	2
_vm_string_substr:                      ; @vm_string_substr
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	w2, [sp, #20]
	str	w3, [sp, #16]
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB20_2
	b	LBB20_1
LBB20_1:
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_vm_string_new
	stur	x0, [x29, #-8]
	b	LBB20_5
LBB20_2:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	str	w8, [sp, #12]
	ldr	w8, [sp, #16]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ls	LBB20_4
	b	LBB20_3
LBB20_3:
	ldr	w8, [sp, #12]
	str	w8, [sp, #16]
	b	LBB20_4
LBB20_4:
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #24]
	add	x8, x8, #24
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	ldr	w2, [sp, #16]
	bl	_vm_string_new
	stur	x0, [x29, #-8]
	b	LBB20_5
LBB20_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_cstr                  ; -- Begin function vmstring_cstr
	.p2align	2
_vmstring_cstr:                         ; @vmstring_cstr
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB21_2
	b	LBB21_1
LBB21_1:
	ldr	x8, [sp, #8]
	add	x8, x8, #24
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB21_3
LBB21_2:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB21_3
LBB21_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_len                   ; -- Begin function vmstring_len
	.p2align	2
_vmstring_len:                          ; @vmstring_len
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB22_3
LBB22_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB22_3
LBB22_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_equal                 ; -- Begin function vmstring_equal
	.p2align	2
_vmstring_equal:                        ; @vmstring_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB23_2
	b	LBB23_1
LBB23_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB23_7
LBB23_2:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB23_4
	b	LBB23_3
LBB23_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB23_7
LBB23_4:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.eq	LBB23_6
	b	LBB23_5
LBB23_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB23_7
LBB23_6:
	ldr	x8, [sp, #16]
	add	x0, x8, #24
	ldr	x8, [sp, #8]
	add	x1, x8, #24
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #8]
	mov	x2, x8
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB23_7
LBB23_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_compare               ; -- Begin function vmstring_compare
	.p2align	2
_vmstring_compare:                      ; @vmstring_compare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB24_2
	b	LBB24_1
LBB24_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_3
LBB24_2:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #8]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_3
LBB24_3:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #20]
	ldur	x8, [x29, #-16]
	add	x0, x8, #24
	ldr	x8, [sp, #24]
	add	x1, x8, #24
	ldr	w8, [sp, #20]
	mov	x2, x8
	bl	_memcmp
	str	w0, [sp, #16]
	ldr	w8, [sp, #16]
	cbz	w8, LBB24_5
	b	LBB24_4
LBB24_4:
	ldr	w8, [sp, #16]
	stur	w8, [x29, #-4]
	b	LBB24_10
LBB24_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB24_7
	b	LBB24_6
LBB24_6:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB24_10
LBB24_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ls	LBB24_9
	b	LBB24_8
LBB24_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_10
LBB24_9:
	stur	wzr, [x29, #-4]
	b	LBB24_10
LBB24_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_find                  ; -- Begin function vmstring_find
	.p2align	2
_vmstring_find:                         ; @vmstring_find
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-28]
	ldur	w8, [x29, #-28]
	cbnz	w8, LBB25_2
	b	LBB25_1
LBB25_1:
	stur	xzr, [x29, #-8]
	b	LBB25_11
LBB25_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	str	w8, [sp, #32]
	ldur	w8, [x29, #-28]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	b.ls	LBB25_4
	b	LBB25_3
LBB25_3:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-8]
	b	LBB25_11
LBB25_4:
	ldur	x8, [x29, #-16]
	add	x8, x8, #24
	str	x8, [sp, #24]
	ldur	x8, [x29, #-24]
	add	x8, x8, #24
	str	x8, [sp, #16]
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	str	w8, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB25_5
LBB25_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.hi	LBB25_10
	b	LBB25_6
LBB25_6:                                ;   in Loop: Header=BB25_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x1, [sp, #16]
	ldur	w8, [x29, #-28]
	mov	x2, x8
	bl	_memcmp
	cbnz	w0, LBB25_8
	b	LBB25_7
LBB25_7:
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-8]
	b	LBB25_11
LBB25_8:                                ;   in Loop: Header=BB25_5 Depth=1
	b	LBB25_9
LBB25_9:                                ;   in Loop: Header=BB25_5 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB25_5
LBB25_10:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-8]
	b	LBB25_11
LBB25_11:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_contains              ; -- Begin function vmstring_contains
	.p2align	2
_vmstring_contains:                     ; @vmstring_contains
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	bl	_vmstring_find
	subs	x8, x0, #0
	cset	w0, ge
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vmstring_char_at               ; -- Begin function vmstring_char_at
	.p2align	2
_vmstring_char_at:                      ; @vmstring_char_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	w2, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB27_2
	b	LBB27_1
LBB27_1:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_vm_string_new
	stur	x0, [x29, #-8]
	b	LBB27_3
LBB27_2:
	ldr	x0, [sp, #16]
	ldr	x8, [sp, #8]
	add	x8, x8, #24
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	mov	w2, #1                          ; =0x1
	bl	_vm_string_new
	stur	x0, [x29, #-8]
	b	LBB27_3
LBB27_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_replacement_length   ; -- Begin function vm_string_replacement_length
	.p2align	2
_vm_string_replacement_length:          ; @vm_string_replacement_length
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	w0, [sp, #40]
	str	w1, [sp, #36]
	str	w2, [sp, #32]
	str	x3, [sp, #24]
	str	x4, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB28_2
	b	LBB28_1
LBB28_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_2:
	ldr	w8, [sp, #36]
	cbnz	w8, LBB28_6
	b	LBB28_3
LBB28_3:
	ldr	x8, [sp, #24]
	cbz	x8, LBB28_5
	b	LBB28_4
LBB28_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_5:
	ldr	w8, [sp, #40]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_6:
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #40]
	ldr	w10, [sp, #36]
	udiv	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB28_8
	b	LBB28_7
LBB28_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_8:
	ldr	w8, [sp, #40]
	ldr	x9, [sp, #24]
                                        ; kill: def $w9 killed $w9 killed $x9
	ldr	w10, [sp, #36]
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #12]
	ldr	w8, [sp, #32]
	cbz	w8, LBB28_11
	b	LBB28_9
LBB28_9:
	ldr	x8, [sp, #24]
	ldr	w10, [sp, #12]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	ldr	w10, [sp, #32]
	udiv	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB28_11
	b	LBB28_10
LBB28_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_11:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #24]
                                        ; kill: def $w9 killed $w9 killed $x9
	ldr	w10, [sp, #32]
	mul	w9, w9, w10
	add	w8, w8, w9
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB28_12
LBB28_12:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_from_int             ; -- Begin function vm_string_from_int
	.p2align	2
_vm_string_from_int:                    ; @vm_string_from_int
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x8, [sp, #32]
	mov	x9, sp
	str	x8, [x9]
	sub	x0, x29, #40
	mov	x3, #32                         ; =0x20
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	tbnz	w8, #31, LBB29_2
	b	LBB29_1
LBB29_1:
	ldrsw	x8, [sp, #28]
	subs	x8, x8, #32
	b.lo	LBB29_3
	b	LBB29_2
LBB29_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #48]
	b	LBB29_4
LBB29_3:
	ldr	x0, [sp, #40]
	ldr	w2, [sp, #28]
	sub	x1, x29, #40
	bl	_vm_string_new
	str	x0, [sp, #48]
	b	LBB29_4
LBB29_4:
	ldr	x8, [sp, #48]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB29_6
	b	LBB29_5
LBB29_5:
	bl	___stack_chk_fail
LBB29_6:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_from_float           ; -- Begin function vm_string_from_float
	.p2align	2
_vm_string_from_float:                  ; @vm_string_from_float
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #24]
	str	d0, [sp, #16]
	ldr	d0, [sp, #16]
	add	x0, sp, #40
	mov	x1, #64                         ; =0x40
	bl	_nano_rt_f64_format
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	tbnz	w8, #31, LBB30_2
	b	LBB30_1
LBB30_1:
	ldrsw	x8, [sp, #12]
	subs	x8, x8, #64
	b.lo	LBB30_3
	b	LBB30_2
LBB30_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	b	LBB30_4
LBB30_3:
	ldr	x0, [sp, #24]
	ldr	w2, [sp, #12]
	add	x1, sp, #40
	bl	_vm_string_new
	str	x0, [sp, #32]
	b	LBB30_4
LBB30_4:
	ldr	x8, [sp, #32]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB30_6
	b	LBB30_5
LBB30_5:
	bl	___stack_chk_fail
LBB30_6:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nano_rt_f64_format
_nano_rt_f64_format:                    ; @nano_rt_f64_format
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	d0, [sp, #24]
	ldr	d0, [sp, #24]
	bl	_nano_rt_f64_nonfinite
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB31_2
	b	LBB31_1
LBB31_1:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldr	x8, [sp, #16]
	mov	x9, sp
	str	x8, [x9]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.7@PAGE
	add	x4, x4, l_.str.7@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB31_3
LBB31_2:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldr	d0, [sp, #24]
	mov	x8, sp
	str	d0, [x8]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.8@PAGE
	add	x4, x4, l_.str.8@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB31_3
LBB31_3:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_string_from_bool            ; -- Begin function vm_string_from_bool
	.p2align	2
_vm_string_from_bool:                   ; @vm_string_from_bool
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	sturb	w1, [x29, #-9]
	ldurb	w8, [x29, #-9]
	tbz	w8, #0, LBB32_2
	b	LBB32_1
LBB32_1:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	mov	w2, #4                          ; =0x4
	bl	_vm_string_new
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB32_3
LBB32_2:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	mov	w2, #5                          ; =0x5
	bl	_vm_string_new
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB32_3
LBB32_3:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_type_unboxable        ; -- Begin function vm_array_type_unboxable
	.p2align	2
_vm_array_type_unboxable:               ; @vm_array_type_unboxable
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB33_4
	b	LBB33_1
LBB33_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB33_4
	b	LBB33_2
LBB33_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB33_4
	b	LBB33_3
LBB33_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB33_4
LBB33_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_elem_size             ; -- Begin function vm_array_elem_size
	.p2align	2
_vm_array_elem_size:                    ; @vm_array_elem_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #7]
	ldrb	w8, [sp, #7]
	str	w8, [sp]                        ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB34_4
	b	LBB34_1
LBB34_1:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB34_7
	b	LBB34_2
LBB34_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB34_5
	b	LBB34_3
LBB34_3:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB34_6
	b	LBB34_8
LBB34_4:
	mov	x8, #8                          ; =0x8
	str	x8, [sp, #8]
	b	LBB34_9
LBB34_5:
	mov	x8, #8                          ; =0x8
	str	x8, [sp, #8]
	b	LBB34_9
LBB34_6:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #8]
	b	LBB34_9
LBB34_7:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #8]
	b	LBB34_9
LBB34_8:
	str	xzr, [sp, #8]
	b	LBB34_9
LBB34_9:
	ldr	x0, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_new                   ; -- Begin function vm_array_new
	.p2align	2
_vm_array_new:                          ; @vm_array_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	str	w2, [sp, #24]
	ldr	w8, [sp, #24]
	subs	w8, w8, #8
	b.hs	LBB35_2
	b	LBB35_1
LBB35_1:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #24]
	b	LBB35_2
LBB35_2:
	mov	x0, #40                         ; =0x28
	bl	_malloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB35_4
	b	LBB35_3
LBB35_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB35_12
LBB35_4:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp, #16]
	mov	w8, #7                          ; =0x7
	strb	w8, [x9, #4]
	ldr	x8, [sp, #16]
	strb	wzr, [x8, #5]
	ldr	x8, [sp, #16]
	strb	wzr, [x8, #6]
	ldurb	w8, [x29, #-17]
	ldr	x9, [sp, #16]
	strb	w8, [x9, #8]
	ldurb	w0, [x29, #-17]
	bl	_vm_array_type_unboxable
	mov	w8, #0                          ; =0x0
	ands	w9, w0, #0x1
	csinc	w8, w8, wzr, eq
	ldr	x9, [sp, #16]
	strb	w8, [x9, #9]
	ldr	x8, [sp, #16]
	str	wzr, [x8, #12]
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #16]
	str	w8, [x9, #16]
	ldr	x8, [sp, #16]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	ldr	x8, [sp, #16]
	str	xzr, [x8, #32]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB35_8
	b	LBB35_5
LBB35_5:
	ldurb	w0, [x29, #-17]
	bl	_vm_array_elem_size
	str	x0, [sp, #8]
	ldr	w8, [sp, #24]
	mov	x0, x8
	ldr	x1, [sp, #8]
	bl	_calloc
	ldr	x8, [sp, #16]
	str	x0, [x8, #32]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB35_7
	b	LBB35_6
LBB35_6:
	ldr	x0, [sp, #16]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB35_12
LBB35_7:
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #8]
	mul	x8, x8, x9
	add	x10, x8, #40
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	b	LBB35_11
LBB35_8:
	ldr	w8, [sp, #24]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #16]
	str	x0, [x8, #24]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB35_10
	b	LBB35_9
LBB35_9:
	ldr	x0, [sp, #16]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB35_12
LBB35_10:
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #40
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	b	LBB35_11
LBB35_11:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB35_12
LBB35_12:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_swap_scalar_storage   ; -- Begin function vm_array_swap_scalar_storage
	.p2align	2
_vm_array_swap_scalar_storage:          ; @vm_array_swap_scalar_storage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB36_4
	b	LBB36_1
LBB36_1:
	ldur	x8, [x29, #-16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB36_4
	b	LBB36_2
LBB36_2:
	ldur	x8, [x29, #-8]
	ldrb	w9, [x8, #8]
	ldur	x8, [x29, #-16]
	ldrb	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB36_4
	b	LBB36_3
LBB36_3:
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #9]
	ldur	x9, [x29, #-16]
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB36_4
LBB36_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbnz	w8, #0, LBB36_6
	b	LBB36_5
LBB36_5:
	adrp	x0, l___func__.vm_array_swap_scalar_storage@PAGE
	add	x0, x0, l___func__.vm_array_swap_scalar_storage@PAGEOFF
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	mov	w2, #726                        ; =0x2d6
	adrp	x3, l_.str.5@PAGE
	add	x3, x3, l_.str.5@PAGEOFF
	bl	___assert_rtn
LBB36_6:
	b	LBB36_7
LBB36_7:
	ldur	x8, [x29, #-8]
	ldrb	w0, [x8, #8]
	bl	_vm_array_type_unboxable
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbnz	w0, #0, LBB36_9
	b	LBB36_8
LBB36_8:
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB36_9
LBB36_9:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	tbnz	w8, #0, LBB36_11
	b	LBB36_10
LBB36_10:
	adrp	x0, l___func__.vm_array_swap_scalar_storage@PAGE
	add	x0, x0, l___func__.vm_array_swap_scalar_storage@PAGEOFF
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	mov	w2, #727                        ; =0x2d7
	adrp	x3, l_.str.6@PAGE
	add	x3, x3, l_.str.6@PAGEOFF
	bl	___assert_rtn
LBB36_11:
	b	LBB36_12
LBB36_12:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #12]
	stur	w8, [x29, #-20]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #16]
	str	w8, [sp, #24]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #24]
	str	x8, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #32]
	str	x8, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-8]
	str	w8, [x9, #12]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #16]
	ldur	x9, [x29, #-8]
	str	w8, [x9, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-8]
	str	x8, [x9, #24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-8]
	str	x8, [x9, #32]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #12]
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #16]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #24]
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #32]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_push                  ; -- Begin function vm_array_push
	.p2align	2
_vm_array_push:                         ; @vm_array_push
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB37_2
	b	LBB37_1
LBB37_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_9
LBB37_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB37_6
	b	LBB37_3
LBB37_3:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_array_grow
	tbnz	w0, #0, LBB37_5
	b	LBB37_4
LBB37_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_9
LBB37_5:
	b	LBB37_6
LBB37_6:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB37_8
	b	LBB37_7
LBB37_7:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	w1, [x8, #12]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #32]
	bl	_packed_store
	ldr	x10, [sp, #8]
	ldr	w8, [x10, #12]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #12]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB37_9
LBB37_8:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	x11, [sp, #8]
	ldr	w9, [x11, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #4]                   ; 4-byte Folded Spill
	add	w10, w10, #1
	str	w10, [x11, #12]
	ldur	q0, [sp, #24]
	str	q0, [x8, x9, lsl #4]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #32]
	bl	_vm_retain
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB37_9
LBB37_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_grow
_array_grow:                            ; @array_grow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	cbz	w8, LBB38_2
	b	LBB38_1
LBB38_1:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	lsl	w8, w8, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB38_3
LBB38_2:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB38_3
LBB38_3:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-28]
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB38_5
	b	LBB38_4
LBB38_4:
	ldur	x8, [x29, #-24]
	ldrb	w0, [x8, #8]
	bl	_vm_array_elem_size
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB38_6
LBB38_5:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB38_6
LBB38_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #40]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ls	LBB38_8
	b	LBB38_7
LBB38_7:
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	ldr	x10, [sp, #40]
	mov	x9, #4294967295                 ; =0xffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB38_9
	b	LBB38_8
LBB38_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_17
LBB38_9:
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB38_13
	b	LBB38_10
LBB38_10:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #32]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #40]
	mul	x1, x8, x9
	bl	_realloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB38_12
	b	LBB38_11
LBB38_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_17
LBB38_12:
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #32]
	b	LBB38_16
LBB38_13:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #4
	bl	_realloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB38_15
	b	LBB38_14
LBB38_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_17
LBB38_15:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #24]
	b	LBB38_16
LBB38_16:
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #40]
	mul	x10, x8, x9
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_17
LBB38_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function packed_store
_packed_store:                          ; @packed_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x2, [sp, #48]
	str	x3, [sp, #56]
	str	x0, [sp, #40]
	str	w1, [sp, #36]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #8]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB39_4
	b	LBB39_1
LBB39_1:
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB39_13
	b	LBB39_2
LBB39_2:
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB39_8
	b	LBB39_3
LBB39_3:
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB39_12
	b	LBB39_17
LBB39_4:
	ldrb	w8, [sp, #48]
	subs	w8, w8, #2
	b.ne	LBB39_6
	b	LBB39_5
LBB39_5:
	ldrb	w8, [sp, #56]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB39_7
LBB39_6:
	ldr	x8, [sp, #56]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB39_7
LBB39_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #32]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB39_18
LBB39_8:
	ldrb	w8, [sp, #48]
	subs	w8, w8, #1
	b.ne	LBB39_10
	b	LBB39_9
LBB39_9:
	ldr	d0, [sp, #56]
	scvtf	d0, d0
	str	d0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB39_11
LBB39_10:
	ldr	d0, [sp, #56]
	str	d0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB39_11
LBB39_11:
	ldr	d0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	str	d0, [x8, x9, lsl #3]
	b	LBB39_18
LBB39_12:
	ldrb	w9, [sp, #56]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #32]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB39_18
LBB39_13:
	ldrb	w8, [sp, #48]
	subs	w8, w8, #1
	b.ne	LBB39_15
	b	LBB39_14
LBB39_14:
	ldr	x8, [sp, #56]
                                        ; kill: def $w8 killed $w8 killed $x8
	and	w8, w8, #0xff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_16
LBB39_15:
	ldrb	w8, [sp, #56]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB39_16
LBB39_16:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #32]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB39_18
LBB39_17:
	b	LBB39_18
LBB39_18:
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_pop                   ; -- Begin function vm_array_pop
	.p2align	2
_vm_array_pop:                          ; @vm_array_pop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB40_2
	b	LBB40_1
LBB40_1:
	bl	_val_void
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB40_5
LBB40_2:
	ldr	x9, [sp, #8]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB40_4
	b	LBB40_3
LBB40_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	w1, [x8, #12]
	bl	_packed_load
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB40_5
LBB40_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [x8, x9, lsl #4]
	str	q0, [sp, #16]
	b	LBB40_5
LBB40_5:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_void
_val_void:                              ; @val_void
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	xzr, [sp]
	str	xzr, [sp, #8]
	strb	wzr, [sp]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function packed_load
_packed_load:                           ; @packed_load
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #8]
	str	w8, [sp]                        ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB42_4
	b	LBB42_1
LBB42_1:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB42_7
	b	LBB42_2
LBB42_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB42_5
	b	LBB42_3
LBB42_3:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB42_6
	b	LBB42_8
LBB42_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_int
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB42_9
LBB42_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	d0, [x8, x9, lsl #3]
	bl	_val_float
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB42_9
LBB42_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w0, ne
	bl	_val_bool
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB42_9
LBB42_7:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	bl	_val_u8
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB42_9
LBB42_8:
	bl	_val_void
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB42_9
LBB42_9:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_get                   ; -- Begin function vm_array_get
	.p2align	2
_vm_array_get:                          ; @vm_array_get
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB43_2
	b	LBB43_1
LBB43_1:
	bl	_val_void
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB43_5
LBB43_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB43_4
	b	LBB43_3
LBB43_3:
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_packed_load
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	b	LBB43_5
LBB43_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [x8, x9, lsl #4]
	str	q0, [sp, #16]
	b	LBB43_5
LBB43_5:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_set                   ; -- Begin function vm_array_set
	.p2align	2
_vm_array_set:                          ; @vm_array_set
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #16]
	str	x3, [sp, #24]
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB44_2
	b	LBB44_1
LBB44_1:
	b	LBB44_5
LBB44_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB44_4
	b	LBB44_3
LBB44_3:
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #24]
	bl	_packed_store
	b	LBB44_5
LBB44_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [sp, #16]
	str	q0, [x8, x9, lsl #4]
	b	LBB44_5
LBB44_5:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_slice                 ; -- Begin function vm_array_slice
	.p2align	2
_vm_array_slice:                        ; @vm_array_slice
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	w3, [sp, #32]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB45_2
	b	LBB45_1
LBB45_1:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	stur	w8, [x29, #-28]
	b	LBB45_2
LBB45_2:
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.ls	LBB45_4
	b	LBB45_3
LBB45_3:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	str	w8, [sp, #32]
	b	LBB45_4
LBB45_4:
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.hi	LBB45_6
	b	LBB45_5
LBB45_5:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-24]
	ldrb	w1, [x8, #8]
	mov	w2, #8                          ; =0x8
	bl	_vm_array_new
	stur	x0, [x29, #-8]
	b	LBB45_15
LBB45_6:
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	str	w8, [sp, #28]
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-24]
	ldrb	w1, [x8, #8]
	ldr	w2, [sp, #28]
	bl	_vm_array_new
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB45_8
	b	LBB45_7
LBB45_7:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB45_15
LBB45_8:
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB45_10
	b	LBB45_9
LBB45_9:
	ldur	x8, [x29, #-24]
	ldrb	w0, [x8, #8]
	bl	_vm_array_elem_size
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #32]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #8]
	mul	x9, x9, x10
	add	x1, x8, x9
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #8]
	mul	x2, x8, x9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #16]
	str	w8, [x9, #12]
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB45_15
LBB45_10:
	str	wzr, [sp, #4]
	b	LBB45_11
LBB45_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.hs	LBB45_14
	b	LBB45_12
LBB45_12:                               ;   in Loop: Header=BB45_11 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldr	x10, [x10, #24]
	ldur	w11, [x29, #-28]
	ldr	w12, [sp, #4]
	add	w11, w11, w12
	ldr	q0, [x10, w11, uxtw #4]
	str	q0, [x8, x9, lsl #4]
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_vm_retain
	b	LBB45_13
LBB45_13:                               ;   in Loop: Header=BB45_11 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB45_11
LBB45_14:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #16]
	str	w8, [x9, #12]
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB45_15
LBB45_15:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_array_remove                ; -- Begin function vm_array_remove
	.p2align	2
_vm_array_remove:                       ; @vm_array_remove
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB46_2
	b	LBB46_1
LBB46_1:
	b	LBB46_9
LBB46_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB46_4
	b	LBB46_3
LBB46_3:
	ldur	x8, [x29, #-16]
	ldrb	w0, [x8, #8]
	bl	_vm_array_elem_size
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-32]
	mul	x9, x9, x10
	add	x0, x8, x9
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
	add	w9, w9, #1
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-32]
	mul	x9, x9, x10
	add	x1, x8, x9
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	subs	w8, w8, #1
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-32]
	mul	x2, x8, x9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memmove_chk
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	b	LBB46_9
LBB46_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [x8, x9, lsl #4]
	str	q0, [sp, #48]
	ldur	w8, [x29, #-20]
	str	w8, [sp, #44]
	b	LBB46_5
LBB46_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w9, w9, #1
	subs	w8, w8, w9
	b.hs	LBB46_8
	b	LBB46_6
LBB46_6:                                ;   in Loop: Header=BB46_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-16]
	ldr	x10, [x10, #24]
	ldr	w11, [sp, #44]
	add	w11, w11, #1
	ldr	q0, [x10, w11, uxtw #4]
	str	q0, [x8, x9, lsl #4]
	b	LBB46_7
LBB46_7:                                ;   in Loop: Header=BB46_5 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB46_5
LBB46_8:
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	bl	_val_void
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x0, [sp, #24]
	str	x1, [sp, #32]
	ldur	q0, [sp, #24]
	str	q0, [x8, x9, lsl #4]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #56]
	bl	_vm_release
	b	LBB46_9
LBB46_9:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_struct_new                  ; -- Begin function vm_struct_new
	.p2align	2
_vm_struct_new:                         ; @vm_struct_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	mov	x0, #32                         ; =0x20
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB47_2
	b	LBB47_1
LBB47_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB47_6
LBB47_2:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp]
	mov	w8, #8                          ; =0x8
	strb	w8, [x9, #4]
	ldr	x8, [sp]
	strb	wzr, [x8, #5]
	ldr	x8, [sp]
	strb	wzr, [x8, #6]
	ldr	w8, [sp, #12]
	ldr	x9, [sp]
	str	w8, [x9, #8]
	ldr	w8, [sp, #8]
	ldr	x9, [sp]
	str	w8, [x9, #12]
	ldr	x8, [sp]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldr	w8, [sp, #8]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp]
	str	x0, [x8, #24]
	ldr	w8, [sp, #8]
	cbz	w8, LBB47_5
	b	LBB47_3
LBB47_3:
	ldr	x8, [sp]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB47_5
	b	LBB47_4
LBB47_4:
	ldr	x0, [sp]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB47_6
LBB47_5:
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #32
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB47_6
LBB47_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_union_new                   ; -- Begin function vm_union_new
	.p2align	2
_vm_union_new:                          ; @vm_union_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	strh	w3, [sp, #8]
	mov	x0, #24                         ; =0x18
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB48_2
	b	LBB48_1
LBB48_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB48_6
LBB48_2:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp]
	mov	w8, #10                         ; =0xa
	strb	w8, [x9, #4]
	ldr	x8, [sp]
	strb	wzr, [x8, #5]
	ldr	x8, [sp]
	strb	wzr, [x8, #6]
	ldr	w8, [sp, #12]
	ldr	x9, [sp]
	str	w8, [x9, #8]
	ldrh	w8, [sp, #10]
	ldr	x9, [sp]
	strh	w8, [x9, #12]
	ldrh	w8, [sp, #8]
	ldr	x9, [sp]
	strh	w8, [x9, #14]
	ldrh	w8, [sp, #8]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp]
	str	x0, [x8, #16]
	ldrh	w8, [sp, #8]
	cbz	w8, LBB48_5
	b	LBB48_3
LBB48_3:
	ldr	x8, [sp]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB48_5
	b	LBB48_4
LBB48_4:
	ldr	x0, [sp]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB48_6
LBB48_5:
	ldrh	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x10, x8, #24
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB48_6
LBB48_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_tuple_new                   ; -- Begin function vm_tuple_new
	.p2align	2
_vm_tuple_new:                          ; @vm_tuple_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x8, x8, #16
	str	x8, [sp, #16]
	ldr	x1, [sp, #16]
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB49_2
	b	LBB49_1
LBB49_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB49_3
LBB49_2:
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp, #8]
	mov	w8, #12                         ; =0xc
	strb	w8, [x9, #4]
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #5]
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #6]
	ldur	w8, [x29, #-20]
	ldr	x9, [sp, #8]
	str	w8, [x9, #8]
	ldr	x10, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB49_3
LBB49_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_closure_new                 ; -- Begin function vm_closure_new
	.p2align	2
_vm_closure_new:                        ; @vm_closure_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	ldurh	w8, [x29, #-22]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x8, x8, #24
	str	x8, [sp, #16]
	ldr	x1, [sp, #16]
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB50_2
	b	LBB50_1
LBB50_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB50_3
LBB50_2:
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x10, [sp, #8]
	mov	w9, #15                         ; =0xf
	strb	w9, [x10, #4]
	ldr	x9, [sp, #8]
	strb	wzr, [x9, #5]
	ldr	x9, [sp, #8]
	strb	wzr, [x9, #6]
	ldur	w9, [x29, #-20]
	ldr	x10, [sp, #8]
	str	w9, [x10, #8]
	ldr	x9, [sp, #8]
	str	w8, [x9, #12]
	ldurh	w8, [x29, #-22]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #16]
	ldr	x10, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB50_3
LBB50_3:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_new                 ; -- Begin function vm_hashmap_new
	.p2align	2
_vm_hashmap_new:                        ; @vm_hashmap_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strb	w1, [sp, #15]
	strb	w2, [sp, #14]
	mov	x0, #32                         ; =0x20
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB51_2
	b	LBB51_1
LBB51_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB51_5
LBB51_2:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldr	x9, [sp]
	mov	w8, #13                         ; =0xd
	strb	w8, [x9, #4]
	ldr	x8, [sp]
	strb	wzr, [x8, #5]
	ldr	x8, [sp]
	strb	wzr, [x8, #6]
	ldrb	w8, [sp, #15]
	ldr	x9, [sp]
	strb	w8, [x9, #8]
	ldrb	w8, [sp, #14]
	ldr	x9, [sp]
	strb	w8, [x9, #9]
	ldr	x8, [sp]
	str	wzr, [x8, #12]
	ldr	x8, [sp]
	str	wzr, [x8, #16]
	ldr	x9, [sp]
	mov	w8, #16                         ; =0x10
	str	w8, [x9, #20]
	mov	x0, #16                         ; =0x10
	mov	x1, #40                         ; =0x28
	bl	_calloc
	ldr	x8, [sp]
	str	x0, [x8, #24]
	ldr	x8, [sp]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB51_4
	b	LBB51_3
LBB51_3:
	ldr	x0, [sp]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB51_5
LBB51_4:
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, #672
	str	x8, [x9]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldr	x0, [sp, #16]
	bl	_vm_gc_maybe_collect
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB51_5
LBB51_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_new             ; -- Begin function vm_rm_ordinary_new
	.p2align	2
_vm_rm_ordinary_new:                    ; @vm_rm_ordinary_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB52_4
	b	LBB52_1
LBB52_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB52_4
	b	LBB52_2
LBB52_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB52_4
	b	LBB52_3
LBB52_3:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbz	w0, #0, LBB52_5
	b	LBB52_4
LBB52_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB52_8
LBB52_5:
	ldr	x0, [sp, #16]
	mov	w1, #5                          ; =0x5
	mov	w2, #1                          ; =0x1
	bl	_vm_hashmap_new
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB52_7
	b	LBB52_6
LBB52_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB52_8
LBB52_7:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB52_8
LBB52_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_private_dag
_vm_rm_private_dag:                     ; @vm_rm_private_dag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_set             ; -- Begin function vm_rm_ordinary_set
	.p2align	2
_vm_rm_ordinary_set:                    ; @vm_rm_ordinary_set
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	str	x4, [sp, #40]
	str	x5, [sp, #48]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB54_6
	b	LBB54_1
LBB54_1:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB54_6
	b	LBB54_2
LBB54_2:
	ldr	x0, [sp, #32]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB54_6
	b	LBB54_3
LBB54_3:
	ldr	x0, [sp, #24]
	bl	_vm_rm_ordinary_header
	tbz	w0, #0, LBB54_6
	b	LBB54_4
LBB54_4:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	bl	_vm_rm_ordinary_string
	tbz	w0, #0, LBB54_6
	b	LBB54_5
LBB54_5:
	ldrb	w8, [sp, #40]
	subs	w8, w8, #1
	b.eq	LBB54_7
	b	LBB54_6
LBB54_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_7:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #20
	add	x4, sp, #19
	bl	_hm_find_slot
	tbnz	w0, #0, LBB54_9
	b	LBB54_8
LBB54_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_9:
	ldrb	w8, [sp, #19]
	tbz	w8, #0, LBB54_14
	b	LBB54_10
LBB54_10:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB54_12
	b	LBB54_11
LBB54_11:
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB54_13
	b	LBB54_12
LBB54_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_13:
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldur	q0, [sp, #40]
	stur	q0, [x8, #24]
	stur	wzr, [x29, #-4]
	b	LBB54_34
LBB54_14:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB54_16
	b	LBB54_15
LBB54_15:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_16:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	cbz	w8, LBB54_22
	b	LBB54_17
LBB54_17:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB54_21
	b	LBB54_18
LBB54_18:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #16]
	cbz	w8, LBB54_21
	b	LBB54_19
LBB54_19:
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB54_21
	b	LBB54_20
LBB54_20:
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #24]
	cbz	w8, LBB54_22
	b	LBB54_21
LBB54_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_22:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #8]
	ldr	d0, [sp, #8]
	ucvtf	d0, d0
	ldr	x8, [sp, #24]
	ldr	s2, [x8, #20]
                                        ; implicit-def: $d1
	mov.16b	v1, v2
	ucvtf	d1, d1
	fdiv	d0, d0, d1
	fmov	d1, #0.75000000
	fcmp	d0, d1
	b.le	LBB54_31
	b	LBB54_23
LBB54_23:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #20]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.hi	LBB54_25
	b	LBB54_24
LBB54_24:
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #20]
	lsl	w2, w8, #1
	bl	_hm_resize
	tbnz	w0, #0, LBB54_26
	b	LBB54_25
LBB54_25:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_26:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #20
	add	x4, sp, #19
	bl	_hm_find_slot
	tbz	w0, #0, LBB54_29
	b	LBB54_27
LBB54_27:
	ldrb	w8, [sp, #19]
	tbnz	w8, #0, LBB54_29
	b	LBB54_28
LBB54_28:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	cbz	w8, LBB54_30
	b	LBB54_29
LBB54_29:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_34
LBB54_30:
	b	LBB54_31
LBB54_31:
	ldr	x0, [sp, #32]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	bl	_vm_retain
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB54_33
	b	LBB54_32
LBB54_32:
	ldr	x9, [sp, #24]
	ldr	w8, [x9, #16]
	subs	w8, w8, #1
	str	w8, [x9, #16]
	b	LBB54_33
LBB54_33:
	ldr	x8, [sp, #24]
	ldr	x11, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldur	q0, [x29, #-24]
	stur	q0, [x8, #8]
	ldr	x8, [sp, #24]
	ldr	x11, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldur	q0, [sp, #40]
	stur	q0, [x8, #24]
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x9, [sp, #24]
	ldr	w8, [x9, #12]
	add	w8, w8, #1
	str	w8, [x9, #12]
	stur	wzr, [x29, #-4]
	b	LBB54_34
LBB54_34:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ordinary_header
_vm_rm_ordinary_header:                 ; @vm_rm_ordinary_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_vm_rm_import_header
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB55_6
	b	LBB55_1
LBB55_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	cbz	w8, LBB55_3
	b	LBB55_2
LBB55_2:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #5]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB55_6
	b	LBB55_3
LBB55_3:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	mov	w9, #1                          ; =0x1
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	w8, LBB55_5
	b	LBB55_4
LBB55_4:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB55_5
LBB55_5:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB55_6
LBB55_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ordinary_string
_vm_rm_ordinary_string:                 ; @vm_rm_ordinary_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_vm_rm_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB56_2
	b	LBB56_1
LBB56_1:
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB56_2
LBB56_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function hm_find_slot
_hm_find_slot:                          ; @hm_find_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-16]
	stur	x0, [x29, #-32]
	str	x3, [sp, #40]
	str	x4, [sp, #32]
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	bl	_hash_value
	ldur	x8, [x29, #-32]
	ldr	w9, [x8, #20]
	udiv	w8, w0, w9
	mul	w8, w8, w9
	subs	w8, w0, w8
	str	w8, [sp, #28]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB57_1
LBB57_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB57_16
	b	LBB57_2
LBB57_2:                                ;   in Loop: Header=BB57_1 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	cbnz	w8, LBB57_7
	b	LBB57_3
LBB57_3:
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB57_5
	b	LBB57_4
LBB57_4:
	ldr	w8, [sp, #24]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB57_6
LBB57_5:
	ldr	w8, [sp, #28]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB57_6
LBB57_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #40]
	str	w8, [x9]
	ldr	x8, [sp, #32]
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_19
LBB57_7:                                ;   in Loop: Header=BB57_1 Depth=1
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB57_11
	b	LBB57_8
LBB57_8:                                ;   in Loop: Header=BB57_1 Depth=1
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB57_10
	b	LBB57_9
LBB57_9:                                ;   in Loop: Header=BB57_1 Depth=1
	ldr	w8, [sp, #28]
	str	w8, [sp, #24]
	b	LBB57_10
LBB57_10:                               ;   in Loop: Header=BB57_1 Depth=1
	b	LBB57_14
LBB57_11:                               ;   in Loop: Header=BB57_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	ldur	x2, [x29, #-24]
	ldur	x3, [x29, #-16]
	bl	_val_equal
	tbz	w0, #0, LBB57_13
	b	LBB57_12
LBB57_12:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #40]
	str	w8, [x9]
	ldr	x9, [sp, #32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_19
LBB57_13:                               ;   in Loop: Header=BB57_1 Depth=1
	b	LBB57_14
LBB57_14:                               ;   in Loop: Header=BB57_1 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	ldur	x9, [x29, #-32]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #28]
	b	LBB57_15
LBB57_15:                               ;   in Loop: Header=BB57_1 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB57_1
LBB57_16:
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB57_18
	b	LBB57_17
LBB57_17:
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #40]
	str	w8, [x9]
	ldr	x8, [sp, #32]
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_19
LBB57_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_19
LBB57_19:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function hm_resize
_hm_resize:                             ; @hm_resize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #20]
	stur	w8, [x29, #-44]
	ldur	w8, [x29, #-28]
	cbz	w8, LBB58_2
	b	LBB58_1
LBB58_1:
	ldur	w8, [x29, #-28]
	mov	x9, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	udiv	x9, x8, x9
	mov	x8, #40                         ; =0x28
	subs	x8, x8, x9
	b.ls	LBB58_3
	b	LBB58_2
LBB58_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_16
LBB58_3:
	ldur	w8, [x29, #-28]
	mov	x0, x8
	mov	x1, #40                         ; =0x28
	bl	_calloc
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB58_5
	b	LBB58_4
LBB58_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_16
LBB58_5:
	ldur	x8, [x29, #-24]
	ldr	q0, [x8]
	str	q0, [sp, #32]
	ldr	q0, [x8, #16]
	str	q0, [sp, #48]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #56]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #52]
	str	wzr, [sp, #44]
	str	wzr, [sp, #48]
	str	wzr, [sp, #28]
	b	LBB58_6
LBB58_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB58_13
	b	LBB58_7
LBB58_7:                                ;   in Loop: Header=BB58_6 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB58_11
	b	LBB58_8
LBB58_8:                                ;   in Loop: Header=BB58_6 Depth=1
	ldur	x10, [x29, #-40]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #8]
	ldr	x2, [x8, #16]
	add	x0, sp, #32
	add	x3, sp, #24
	add	x4, sp, #23
	bl	_hm_find_slot
	tbnz	w0, #0, LBB58_10
	b	LBB58_9
LBB58_9:
	ldur	x0, [x29, #-56]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_16
LBB58_10:                               ;   in Loop: Header=BB58_6 Depth=1
	ldr	x11, [sp, #56]
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldur	x10, [x29, #-40]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x10, [sp, #56]
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB58_11
LBB58_11:                               ;   in Loop: Header=BB58_6 Depth=1
	b	LBB58_12
LBB58_12:                               ;   in Loop: Header=BB58_6 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB58_6
LBB58_13:
	ldur	x8, [x29, #-24]
	ldr	q0, [sp, #32]
	str	q0, [x8]
	ldr	q0, [sp, #48]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB58_15
	b	LBB58_14
LBB58_14:
	ldur	w8, [x29, #-28]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	ldur	x9, [x29, #-16]
	ldr	x11, [x9]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x11
	str	x8, [x9]
	b	LBB58_15
LBB58_15:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-16]
	bl	_vm_gc_maybe_collect
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_16
LBB58_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_delete          ; -- Begin function vm_rm_ordinary_delete
	.p2align	2
_vm_rm_ordinary_delete:                 ; @vm_rm_ordinary_delete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB59_5
	b	LBB59_1
LBB59_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB59_5
	b	LBB59_2
LBB59_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB59_5
	b	LBB59_3
LBB59_3:
	ldr	x0, [sp, #8]
	bl	_vm_rm_ordinary_header
	tbz	w0, #0, LBB59_5
	b	LBB59_4
LBB59_4:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	bl	_vm_rm_ordinary_string
	tbnz	w0, #0, LBB59_6
	b	LBB59_5
LBB59_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB59_7
LBB59_6:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #32]
	bl	_vm_rm_delete_validated
	stur	w0, [x29, #-4]
	b	LBB59_7
LBB59_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_delete_validated
_vm_rm_delete_validated:                ; @vm_rm_delete_validated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	sub	x3, x29, #44
	sub	x4, x29, #45
	bl	_hm_find_slot
	tbz	w0, #0, LBB60_2
	b	LBB60_1
LBB60_1:
	ldurb	w8, [x29, #-45]
	tbnz	w8, #0, LBB60_3
	b	LBB60_2
LBB60_2:
	stur	wzr, [x29, #-4]
	b	LBB60_9
LBB60_3:
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB60_7
	b	LBB60_4
LBB60_4:
	ldur	x8, [x29, #-56]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_string
	tbz	w0, #0, LBB60_7
	b	LBB60_5
LBB60_5:
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	LBB60_7
	b	LBB60_6
LBB60_6:
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB60_8
	b	LBB60_7
LBB60_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB60_9
LBB60_8:
	ldur	x8, [x29, #-56]
	ldur	q0, [x8, #8]
	str	q0, [sp, #48]
	ldur	x8, [x29, #-56]
	str	x8, [sp]                        ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	q0, [sp, #32]
	stur	q0, [x8, #8]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	q0, [sp, #16]
	stur	q0, [x8, #24]
	ldur	x9, [x29, #-56]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldur	x9, [x29, #-40]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	ldur	x9, [x29, #-40]
	ldr	w8, [x9, #16]
	add	w8, w8, #1
	str	w8, [x9, #16]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #56]
	bl	_vm_release
	stur	wzr, [x29, #-4]
	b	LBB60_9
LBB60_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_get             ; -- Begin function vm_rm_ordinary_get
	.p2align	2
_vm_rm_ordinary_get:                    ; @vm_rm_ordinary_get
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x0, [x29, #-32]
	str	x1, [sp, #40]
	str	x4, [sp, #32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB61_6
	b	LBB61_1
LBB61_1:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB61_6
	b	LBB61_2
LBB61_2:
	ldur	x0, [x29, #-32]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB61_6
	b	LBB61_3
LBB61_3:
	ldr	x8, [sp, #32]
	cbz	x8, LBB61_6
	b	LBB61_4
LBB61_4:
	ldr	x0, [sp, #40]
	bl	_vm_rm_ordinary_header
	tbz	w0, #0, LBB61_6
	b	LBB61_5
LBB61_5:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	bl	_vm_rm_ordinary_string
	tbnz	w0, #0, LBB61_7
	b	LBB61_6
LBB61_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB61_15
LBB61_7:
	ldr	x0, [sp, #40]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #28
	add	x4, sp, #27
	bl	_hm_find_slot
	tbnz	w0, #0, LBB61_9
	b	LBB61_8
LBB61_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB61_15
LBB61_9:
	bl	_val_void
	str	x0, [sp]
	str	x1, [sp, #8]
	ldrb	w8, [sp, #27]
	tbz	w8, #0, LBB61_14
	b	LBB61_10
LBB61_10:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB61_12
	b	LBB61_11
LBB61_11:
	ldr	x8, [sp, #40]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB61_13
	b	LBB61_12
LBB61_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB61_15
LBB61_13:
	ldr	x8, [sp, #40]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldur	q0, [x8, #24]
	str	q0, [sp]
	b	LBB61_14
LBB61_14:
	ldr	x8, [sp, #32]
	ldr	q0, [sp]
	str	q0, [x8]
	stur	wzr, [x29, #-4]
	b	LBB61_15
LBB61_15:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_has             ; -- Begin function vm_rm_ordinary_has
	.p2align	2
_vm_rm_ordinary_has:                    ; @vm_rm_ordinary_has
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	str	x4, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB62_6
	b	LBB62_1
LBB62_1:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB62_6
	b	LBB62_2
LBB62_2:
	ldr	x0, [sp, #32]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB62_6
	b	LBB62_3
LBB62_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB62_6
	b	LBB62_4
LBB62_4:
	ldr	x0, [sp, #24]
	bl	_vm_rm_ordinary_header
	tbz	w0, #0, LBB62_6
	b	LBB62_5
LBB62_5:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	bl	_vm_rm_ordinary_string
	tbnz	w0, #0, LBB62_7
	b	LBB62_6
LBB62_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB62_14
LBB62_7:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #12
	add	x4, sp, #11
	bl	_hm_find_slot
	tbnz	w0, #0, LBB62_9
	b	LBB62_8
LBB62_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB62_14
LBB62_9:
	ldrb	w8, [sp, #11]
	tbz	w8, #0, LBB62_13
	b	LBB62_10
LBB62_10:
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB62_12
	b	LBB62_11
LBB62_11:
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB62_13
	b	LBB62_12
LBB62_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB62_14
LBB62_13:
	ldrb	w8, [sp, #11]
	ldr	x9, [sp, #16]
	and	w8, w8, #0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB62_14
LBB62_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_len             ; -- Begin function vm_rm_ordinary_len
	.p2align	2
_vm_rm_ordinary_len:                    ; @vm_rm_ordinary_len
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB63_5
	b	LBB63_1
LBB63_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB63_5
	b	LBB63_2
LBB63_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB63_5
	b	LBB63_3
LBB63_3:
	ldr	x8, [sp]
	cbz	x8, LBB63_5
	b	LBB63_4
LBB63_4:
	ldr	x0, [sp, #8]
	bl	_vm_rm_ordinary_header
	tbnz	w0, #0, LBB63_6
	b	LBB63_5
LBB63_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB63_7
LBB63_6:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [sp]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB63_7
LBB63_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_heap_import_validate     ; -- Begin function vm_rm_heap_import_validate
	.p2align	2
_vm_rm_heap_import_validate:            ; @vm_rm_heap_import_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_vm_rm_validate_using
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_validate_using
_vm_rm_validate_using:                  ; @vm_rm_validate_using
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB65_2
	b	LBB65_1
LBB65_1:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #8]
	mov	x9, #33554432                   ; =0x2000000
	subs	x8, x8, x9
	b.ls	LBB65_3
	b	LBB65_2
LBB65_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_3:
	ldur	x0, [x29, #-24]
	mov	x1, #16                         ; =0x10
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB65_5
	b	LBB65_4
LBB65_4:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_5:
	ldurb	w8, [x29, #-25]
	tbz	w8, #0, LBB65_7
	b	LBB65_6
LBB65_6:
	ldur	x0, [x29, #-16]
	bl	_vm_rm_import_header
	tbnz	w0, #0, LBB65_9
	b	LBB65_8
LBB65_7:
	ldur	x0, [x29, #-16]
	bl	_vm_rm_map_header
	tbnz	w0, #0, LBB65_9
	b	LBB65_8
LBB65_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #16]
	cbz	w8, LBB65_11
	b	LBB65_10
LBB65_10:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldurb	w8, [x29, #-25]
	and	w2, w8, #0x1
	bl	_vm_rm_validate_tombstones
	stur	w0, [x29, #-4]
	b	LBB65_54
LBB65_11:
	stur	wzr, [x29, #-32]
	stur	wzr, [x29, #-36]
	b	LBB65_12
LBB65_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB65_30 Depth 2
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB65_53
	b	LBB65_13
LBB65_13:                               ;   in Loop: Header=BB65_12 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #8                          ; =0x8
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB65_15
	b	LBB65_14
LBB65_14:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_15:                               ;   in Loop: Header=BB65_12 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	cbnz	w8, LBB65_17
	b	LBB65_16
LBB65_16:                               ;   in Loop: Header=BB65_12 Depth=1
	b	LBB65_52
LBB65_17:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB65_20
	b	LBB65_18
LBB65_18:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #48]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_string
	tbz	w0, #0, LBB65_20
	b	LBB65_19
LBB65_19:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB65_21
	b	LBB65_20
LBB65_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_21:                               ;   in Loop: Header=BB65_12 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #40]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB65_23
	b	LBB65_22
LBB65_22:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_23:                               ;   in Loop: Header=BB65_12 Depth=1
	ldurb	w8, [x29, #-25]
	tbz	w8, #0, LBB65_27
	b	LBB65_24
LBB65_24:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #5]
	cbnz	w8, LBB65_26
	b	LBB65_25
LBB65_25:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #24
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbz	w8, LBB65_27
	b	LBB65_26
LBB65_26:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_27:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #40]
	add	x0, x8, #24
	ldr	x8, [sp, #40]
	ldr	w1, [x8, #8]
	bl	_fnv1a
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #12]
	subs	w8, w0, w8
	b.eq	LBB65_29
	b	LBB65_28
LBB65_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_29:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #36]
	strb	wzr, [sp, #35]
	str	wzr, [sp, #28]
	b	LBB65_30
LBB65_30:                               ;   Parent Loop BB65_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB65_49
	b	LBB65_31
LBB65_31:                               ;   in Loop: Header=BB65_30 Depth=2
	ldur	x0, [x29, #-24]
	mov	x1, #4                          ; =0x4
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB65_33
	b	LBB65_32
LBB65_32:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_33:                               ;   in Loop: Header=BB65_30 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	cbnz	w8, LBB65_35
	b	LBB65_34
LBB65_34:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_35:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB65_37
	b	LBB65_36
LBB65_36:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_string
	tbnz	w0, #0, LBB65_38
	b	LBB65_37
LBB65_37:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_38:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB65_40
	b	LBB65_39
LBB65_39:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB65_41
LBB65_40:                               ;   in Loop: Header=BB65_30 Depth=2
	mov	x8, #1                          ; =0x1
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB65_41
LBB65_41:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #8]
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB65_43
	b	LBB65_42
LBB65_42:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_43:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #48]
	ldr	x0, [x9, #8]
	ldr	x1, [x9, #16]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_val_equal
	tbz	w0, #0, LBB65_47
	b	LBB65_44
LBB65_44:                               ;   in Loop: Header=BB65_12 Depth=1
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.eq	LBB65_46
	b	LBB65_45
LBB65_45:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_46:                               ;   in Loop: Header=BB65_12 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #35]
	b	LBB65_49
LBB65_47:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #36]
	b	LBB65_48
LBB65_48:                               ;   in Loop: Header=BB65_30 Depth=2
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB65_30
LBB65_49:                               ;   in Loop: Header=BB65_12 Depth=1
	ldrb	w8, [sp, #35]
	tbnz	w8, #0, LBB65_51
	b	LBB65_50
LBB65_50:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_51:                               ;   in Loop: Header=BB65_12 Depth=1
	b	LBB65_52
LBB65_52:                               ;   in Loop: Header=BB65_12 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB65_12
LBB65_53:
	ldur	w8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	cset	w8, ne
	stur	w8, [x29, #-4]
	b	LBB65_54
LBB65_54:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_new          ; -- Begin function vm_rm_ordinary_ss_new
	.p2align	2
_vm_rm_ordinary_ss_new:                 ; @vm_rm_ordinary_ss_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB66_4
	b	LBB66_1
LBB66_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB66_4
	b	LBB66_2
LBB66_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB66_4
	b	LBB66_3
LBB66_3:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB66_5
	b	LBB66_4
LBB66_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB66_8
LBB66_5:
	ldr	x0, [sp, #16]
	mov	w2, #5                          ; =0x5
	mov	x1, x2
	bl	_vm_hashmap_new
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB66_7
	b	LBB66_6
LBB66_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB66_8
LBB66_7:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB66_8
LBB66_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_set          ; -- Begin function vm_rm_ordinary_ss_set
	.p2align	2
_vm_rm_ordinary_ss_set:                 ; @vm_rm_ordinary_ss_set
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	str	x4, [sp, #24]
	str	x5, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB67_6
	b	LBB67_1
LBB67_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB67_6
	b	LBB67_2
LBB67_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB67_6
	b	LBB67_3
LBB67_3:
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbz	w0, #0, LBB67_6
	b	LBB67_4
LBB67_4:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	bl	_vm_rm_ss_string
	tbz	w0, #0, LBB67_6
	b	LBB67_5
LBB67_5:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB67_7
	b	LBB67_6
LBB67_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB67_8
LBB67_7:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldur	x2, [x29, #-24]
	ldur	x3, [x29, #-16]
	ldr	x4, [sp, #24]
	ldr	x5, [sp, #32]
	bl	_vm_rm_ss_set_validated
	stur	w0, [x29, #-4]
	b	LBB67_8
LBB67_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_header
_vm_rm_ss_header:                       ; @vm_rm_ss_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strb	w1, [sp, #7]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB68_18
	b	LBB68_1
LBB68_1:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #13
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB68_18
	b	LBB68_2
LBB68_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	w8, LBB68_18
	b	LBB68_3
LBB68_3:
	ldrb	w8, [sp, #7]
	tbz	w8, #0, LBB68_9
	b	LBB68_4
LBB68_4:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #6]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.gt	LBB68_18
	b	LBB68_5
LBB68_5:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	cbz	w8, LBB68_7
	b	LBB68_6
LBB68_6:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #5]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB68_18
	b	LBB68_7
LBB68_7:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB68_10
	b	LBB68_8
LBB68_8:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #5]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB68_10
	b	LBB68_18
LBB68_9:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbnz	w8, LBB68_18
	b	LBB68_10
LBB68_10:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB68_18
	b	LBB68_11
LBB68_11:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #9]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB68_18
	b	LBB68_12
LBB68_12:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB68_18
	b	LBB68_13
LBB68_13:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #16
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.lo	LBB68_18
	b	LBB68_14
LBB68_14:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	subs	w9, w9, #1
	and	w8, w8, w9
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbnz	w8, LBB68_18
	b	LBB68_15
LBB68_15:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	mov	x9, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	udiv	x10, x8, x9
	mov	x9, #40                         ; =0x28
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hi	LBB68_18
	b	LBB68_16
LBB68_16:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #12]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hi	LBB68_18
	b	LBB68_17
LBB68_17:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	ldr	x10, [sp, #8]
	ldr	w10, [x10, #12]
	subs	w9, w9, w10
	subs	w8, w8, w9
	cset	w8, ls
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB68_18
LBB68_18:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_string
_vm_rm_ss_string:                       ; @vm_rm_ss_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	str	x1, [sp, #8]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	bl	_vm_rm_ordinary_string
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_set_validated
_vm_rm_ss_set_validated:                ; @vm_rm_ss_set_validated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x4, [x29, #-40]
	stur	x5, [x29, #-32]
	stur	x0, [x29, #-48]
	str	x1, [sp, #56]
	ldr	x0, [sp, #56]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #52
	add	x4, sp, #51
	bl	_hm_find_slot
	tbnz	w0, #0, LBB70_2
	b	LBB70_1
LBB70_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_2:
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB70_10
	b	LBB70_3
LBB70_3:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB70_6
	b	LBB70_4
LBB70_4:
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_ss_string
	tbz	w0, #0, LBB70_6
	b	LBB70_5
LBB70_5:
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB70_7
	b	LBB70_6
LBB70_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_7:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB70_9
	b	LBB70_8
LBB70_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_9:
	ldr	x8, [sp, #40]
	ldur	q0, [x8, #24]
	str	q0, [sp, #16]
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-32]
	bl	_vm_retain
	ldr	x8, [sp, #40]
	ldur	q0, [x29, #-40]
	stur	q0, [x8, #24]
	ldur	x0, [x29, #-48]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_vm_release
	stur	wzr, [x29, #-4]
	b	LBB70_32
LBB70_10:
	ldur	x9, [x29, #-16]
	ldur	x10, [x29, #-32]
	mov	w8, #2                          ; =0x2
	subs	x9, x9, x10
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #12]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	ldr	w10, [sp, #12]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB70_12
	b	LBB70_11
LBB70_11:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	ldr	w10, [sp, #12]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB70_13
	b	LBB70_12
LBB70_12:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_13:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	cbz	w8, LBB70_15
	b	LBB70_14
LBB70_14:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB70_19
	b	LBB70_15
LBB70_15:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB70_19
	b	LBB70_16
LBB70_16:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #24]
	cbnz	w8, LBB70_19
	b	LBB70_17
LBB70_17:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB70_20
	b	LBB70_18
LBB70_18:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #16]
	cbnz	w8, LBB70_20
	b	LBB70_19
LBB70_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_20:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp]
	ldr	d0, [sp]
	ucvtf	d0, d0
	ldr	x8, [sp, #56]
	ldr	s2, [x8, #20]
                                        ; implicit-def: $d1
	mov.16b	v1, v2
	ucvtf	d1, d1
	fdiv	d0, d0, d1
	fmov	d1, #0.75000000
	fcmp	d0, d1
	b.le	LBB70_29
	b	LBB70_21
LBB70_21:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #20]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.hi	LBB70_23
	b	LBB70_22
LBB70_22:
	ldur	x0, [x29, #-48]
	ldr	x1, [sp, #56]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #20]
	lsl	w2, w8, #1
	bl	_hm_resize
	tbnz	w0, #0, LBB70_24
	b	LBB70_23
LBB70_23:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_24:
	ldr	x0, [sp, #56]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #52
	add	x4, sp, #51
	bl	_hm_find_slot
	tbz	w0, #0, LBB70_27
	b	LBB70_25
LBB70_25:
	ldrb	w8, [sp, #51]
	tbnz	w8, #0, LBB70_27
	b	LBB70_26
LBB70_26:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	cbz	w8, LBB70_28
	b	LBB70_27
LBB70_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB70_32
LBB70_28:
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	b	LBB70_29
LBB70_29:
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	bl	_vm_retain
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-32]
	bl	_vm_retain
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB70_31
	b	LBB70_30
LBB70_30:
	ldr	x9, [sp, #56]
	ldr	w8, [x9, #16]
	subs	w8, w8, #1
	str	w8, [x9, #16]
	b	LBB70_31
LBB70_31:
	ldr	x8, [sp, #40]
	ldur	q0, [x29, #-24]
	stur	q0, [x8, #8]
	ldr	x8, [sp, #40]
	ldur	q0, [x29, #-40]
	stur	q0, [x8, #24]
	ldr	x9, [sp, #40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x9, [sp, #56]
	ldr	w8, [x9, #12]
	add	w8, w8, #1
	str	w8, [x9, #12]
	stur	wzr, [x29, #-4]
	b	LBB70_32
LBB70_32:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_get_owned    ; -- Begin function vm_rm_ordinary_ss_get_owned
	.p2align	2
_vm_rm_ordinary_ss_get_owned:           ; @vm_rm_ordinary_ss_get_owned
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x4, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB71_6
	b	LBB71_1
LBB71_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB71_6
	b	LBB71_2
LBB71_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB71_6
	b	LBB71_3
LBB71_3:
	ldr	x8, [sp]
	cbz	x8, LBB71_6
	b	LBB71_4
LBB71_4:
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbz	w0, #0, LBB71_6
	b	LBB71_5
LBB71_5:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB71_7
	b	LBB71_6
LBB71_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB71_8
LBB71_7:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x4, [sp]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #32]
	bl	_vm_rm_ss_get_validated
	stur	w0, [x29, #-4]
	b	LBB71_8
LBB71_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_get_validated
_vm_rm_ss_get_validated:                ; @vm_rm_ss_get_validated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	str	x4, [sp, #48]
	bl	_val_void
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #44
	add	x4, sp, #43
	bl	_hm_find_slot
	tbz	w0, #0, LBB72_8
	b	LBB72_1
LBB72_1:
	ldrb	w8, [sp, #43]
	tbz	w8, #0, LBB72_8
	b	LBB72_2
LBB72_2:
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB72_4
	b	LBB72_3
LBB72_3:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB72_5
	b	LBB72_4
LBB72_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB72_9
LBB72_5:
	ldr	x8, [sp, #8]
	ldur	q0, [x8, #24]
	str	q0, [sp, #16]
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB72_7
	b	LBB72_6
LBB72_6:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB72_9
LBB72_7:
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_vm_retain
	b	LBB72_8
LBB72_8:
	ldr	x8, [sp, #48]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	stur	wzr, [x29, #-4]
	b	LBB72_9
LBB72_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_delete       ; -- Begin function vm_rm_ordinary_ss_delete
	.p2align	2
_vm_rm_ordinary_ss_delete:              ; @vm_rm_ordinary_ss_delete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB73_5
	b	LBB73_1
LBB73_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB73_5
	b	LBB73_2
LBB73_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB73_5
	b	LBB73_3
LBB73_3:
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbz	w0, #0, LBB73_5
	b	LBB73_4
LBB73_4:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB73_6
	b	LBB73_5
LBB73_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB73_7
LBB73_6:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #32]
	bl	_vm_rm_ss_delete_validated
	stur	w0, [x29, #-4]
	b	LBB73_7
LBB73_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_delete_validated
_vm_rm_ss_delete_validated:             ; @vm_rm_ss_delete_validated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	sub	x3, x29, #44
	sub	x4, x29, #45
	bl	_hm_find_slot
	tbz	w0, #0, LBB74_2
	b	LBB74_1
LBB74_1:
	ldurb	w8, [x29, #-45]
	tbnz	w8, #0, LBB74_3
	b	LBB74_2
LBB74_2:
	stur	wzr, [x29, #-4]
	b	LBB74_9
LBB74_3:
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB74_7
	b	LBB74_4
LBB74_4:
	ldur	x8, [x29, #-56]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_ss_string
	tbz	w0, #0, LBB74_7
	b	LBB74_5
LBB74_5:
	ldur	x8, [x29, #-56]
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #32]
	bl	_vm_rm_ss_string
	tbz	w0, #0, LBB74_7
	b	LBB74_6
LBB74_6:
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB74_8
	b	LBB74_7
LBB74_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB74_9
LBB74_8:
	ldur	x8, [x29, #-56]
	ldur	q0, [x8, #8]
	str	q0, [sp, #64]
	ldur	x8, [x29, #-56]
	ldur	q0, [x8, #24]
	str	q0, [sp, #48]
	ldur	x8, [x29, #-56]
	str	x8, [sp]                        ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	q0, [sp, #32]
	stur	q0, [x8, #8]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	q0, [sp, #16]
	stur	q0, [x8, #24]
	ldur	x9, [x29, #-56]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldur	x9, [x29, #-40]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	ldur	x9, [x29, #-40]
	ldr	w8, [x9, #16]
	add	w8, w8, #1
	str	w8, [x9, #16]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #64]
	ldr	x2, [sp, #72]
	bl	_vm_release
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #56]
	bl	_vm_release
	stur	wzr, [x29, #-4]
	b	LBB74_9
LBB74_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_has          ; -- Begin function vm_rm_ordinary_ss_has
	.p2align	2
_vm_rm_ordinary_ss_has:                 ; @vm_rm_ordinary_ss_has
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x4, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB75_6
	b	LBB75_1
LBB75_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB75_6
	b	LBB75_2
LBB75_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB75_6
	b	LBB75_3
LBB75_3:
	ldr	x8, [sp]
	cbz	x8, LBB75_6
	b	LBB75_4
LBB75_4:
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbz	w0, #0, LBB75_6
	b	LBB75_5
LBB75_5:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB75_7
	b	LBB75_6
LBB75_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB75_8
LBB75_7:
	ldr	x0, [sp, #8]
	ldr	x3, [sp]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #32]
	bl	_vm_rm_ss_has_validated
	stur	w0, [x29, #-4]
	b	LBB75_8
LBB75_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_has_validated
_vm_rm_ss_has_validated:                ; @vm_rm_ss_has_validated
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #24]
	str	x2, [sp, #32]
	str	x0, [sp, #16]
	str	x3, [sp, #8]
	add	x4, sp, #3
	strb	wzr, [sp, #3]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #32]
	add	x3, sp, #4
	bl	_hm_find_slot
	tbnz	w0, #0, LBB76_2
	b	LBB76_1
LBB76_1:
	strb	wzr, [sp, #3]
	b	LBB76_2
LBB76_2:
	ldrb	w8, [sp, #3]
	tbz	w8, #0, LBB76_6
	b	LBB76_3
LBB76_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB76_5
	b	LBB76_4
LBB76_4:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB76_6
	b	LBB76_5
LBB76_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB76_7
LBB76_6:
	ldrb	w8, [sp, #3]
	ldr	x9, [sp, #8]
	and	w8, w8, #0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB76_7
LBB76_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_ordinary_ss_len          ; -- Begin function vm_rm_ordinary_ss_len
	.p2align	2
_vm_rm_ordinary_ss_len:                 ; @vm_rm_ordinary_ss_len
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB77_5
	b	LBB77_1
LBB77_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB77_5
	b	LBB77_2
LBB77_2:
	ldr	x0, [sp, #16]
	bl	_vm_rm_private_dag
	tbnz	w0, #0, LBB77_5
	b	LBB77_3
LBB77_3:
	ldr	x8, [sp]
	cbz	x8, LBB77_5
	b	LBB77_4
LBB77_4:
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbnz	w0, #0, LBB77_6
	b	LBB77_5
LBB77_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB77_7
LBB77_6:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [sp]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB77_7
LBB77_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_rm_heap_ss_import_validate  ; -- Begin function vm_rm_heap_ss_import_validate
	.p2align	2
_vm_rm_heap_ss_import_validate:         ; @vm_rm_heap_ss_import_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_vm_rm_ss_validate_using
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_ss_validate_using
_vm_rm_ss_validate_using:               ; @vm_rm_ss_validate_using
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB79_3
	b	LBB79_1
LBB79_1:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB79_3
	b	LBB79_2
LBB79_2:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #8]
	mov	x9, #33554432                   ; =0x2000000
	subs	x8, x8, x9
	b.ls	LBB79_4
	b	LBB79_3
LBB79_3:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_4:
	ldur	x0, [x29, #-24]
	mov	x1, #16                         ; =0x10
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_6
	b	LBB79_5
LBB79_5:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_6:
	ldur	x0, [x29, #-16]
	ldurb	w8, [x29, #-25]
	and	w1, w8, #0x1
	bl	_vm_rm_ss_header
	tbnz	w0, #0, LBB79_8
	b	LBB79_7
LBB79_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_8:
	stur	wzr, [x29, #-32]
	stur	wzr, [x29, #-36]
	stur	wzr, [x29, #-40]
	b	LBB79_9
LBB79_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB79_37 Depth 2
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB79_65
	b	LBB79_10
LBB79_10:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #8                          ; =0x8
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_12
	b	LBB79_11
LBB79_11:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_12:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.eq	LBB79_20
	b	LBB79_13
LBB79_13:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.gt	LBB79_16
	b	LBB79_14
LBB79_14:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB79_16
	b	LBB79_15
LBB79_15:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #24]
	cbz	w8, LBB79_17
	b	LBB79_16
LBB79_16:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_17:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB79_19
	b	LBB79_18
LBB79_18:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB79_19
LBB79_19:                               ;   in Loop: Header=BB79_9 Depth=1
	b	LBB79_64
LBB79_20:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB79_22
	b	LBB79_21
LBB79_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_22:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #16                         ; =0x10
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_24
	b	LBB79_23
LBB79_23:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_24:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #24]
	ldr	x1, [x8, #32]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB79_26
	b	LBB79_25
LBB79_25:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_26:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #32]
	str	x8, [sp, #56]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_28
	b	LBB79_27
LBB79_27:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_28:                               ;   in Loop: Header=BB79_9 Depth=1
	ldr	x8, [sp, #56]
	add	x8, x8, #24
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbnz	w8, LBB79_30
	b	LBB79_29
LBB79_29:                               ;   in Loop: Header=BB79_9 Depth=1
	ldr	x8, [sp, #56]
	add	x0, x8, #24
	ldr	x8, [sp, #56]
	ldr	w1, [x8, #8]
	bl	_fnv1a
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #12]
	subs	w8, w0, w8
	b.eq	LBB79_31
	b	LBB79_30
LBB79_30:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_31:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_33
	b	LBB79_32
LBB79_32:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_33:                               ;   in Loop: Header=BB79_9 Depth=1
	ldr	x8, [sp, #48]
	add	x8, x8, #24
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbnz	w8, LBB79_35
	b	LBB79_34
LBB79_34:                               ;   in Loop: Header=BB79_9 Depth=1
	ldr	x8, [sp, #48]
	add	x0, x8, #24
	ldr	x8, [sp, #48]
	ldr	w1, [x8, #8]
	bl	_fnv1a
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #12]
	subs	w8, w0, w8
	b.eq	LBB79_36
	b	LBB79_35
LBB79_35:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_36:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #44]
	strb	wzr, [sp, #43]
	str	wzr, [sp, #36]
	b	LBB79_37
LBB79_37:                               ;   Parent Loop BB79_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB79_61
	b	LBB79_38
LBB79_38:                               ;   in Loop: Header=BB79_37 Depth=2
	ldur	x0, [x29, #-24]
	mov	x1, #4                          ; =0x4
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_40
	b	LBB79_39
LBB79_39:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_40:                               ;   in Loop: Header=BB79_37 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbnz	w8, LBB79_42
	b	LBB79_41
LBB79_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_42:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB79_47
	b	LBB79_43
LBB79_43:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB79_45
	b	LBB79_44
LBB79_44:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #24]
	cbz	w8, LBB79_46
	b	LBB79_45
LBB79_45:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_46:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB79_60
LBB79_47:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB79_49
	b	LBB79_48
LBB79_48:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_ss_string
	tbnz	w0, #0, LBB79_50
	b	LBB79_49
LBB79_49:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_50:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB79_52
	b	LBB79_51
LBB79_51:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB79_53
LBB79_52:                               ;   in Loop: Header=BB79_37 Depth=2
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB79_53
LBB79_53:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #16]
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB79_55
	b	LBB79_54
LBB79_54:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_55:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	x9, [sp, #24]
	ldur	x8, [x29, #-48]
	ldr	x0, [x9, #8]
	ldr	x1, [x9, #16]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_val_equal
	tbz	w0, #0, LBB79_59
	b	LBB79_56
LBB79_56:                               ;   in Loop: Header=BB79_9 Depth=1
	ldr	w8, [sp, #44]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	b.eq	LBB79_58
	b	LBB79_57
LBB79_57:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_58:                               ;   in Loop: Header=BB79_9 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #43]
	b	LBB79_61
LBB79_59:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #44]
	b	LBB79_60
LBB79_60:                               ;   in Loop: Header=BB79_37 Depth=2
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB79_37
LBB79_61:                               ;   in Loop: Header=BB79_9 Depth=1
	ldrb	w8, [sp, #43]
	tbnz	w8, #0, LBB79_63
	b	LBB79_62
LBB79_62:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_63:                               ;   in Loop: Header=BB79_9 Depth=1
	b	LBB79_64
LBB79_64:                               ;   in Loop: Header=BB79_9 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB79_9
LBB79_65:
	ldur	w9, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB79_67
	b	LBB79_66
LBB79_66:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB79_67
LBB79_67:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	cset	w8, eq
	stur	w8, [x29, #-4]
	b	LBB79_68
LBB79_68:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_get                 ; -- Begin function vm_hashmap_get
	.p2align	2
_vm_hashmap_get:                        ; @vm_hashmap_get
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	add	x3, sp, #4
	add	x4, sp, #3
	bl	_hm_find_slot
	tbz	w0, #0, LBB80_3
	b	LBB80_1
LBB80_1:
	ldrb	w8, [sp, #3]
	tbz	w8, #0, LBB80_3
	b	LBB80_2
LBB80_2:
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldur	q0, [x8, #24]
	stur	q0, [x29, #-16]
	b	LBB80_4
LBB80_3:
	bl	_val_void
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB80_4
LBB80_4:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_set                 ; -- Begin function vm_hashmap_set
	.p2align	2
_vm_hashmap_set:                        ; @vm_hashmap_set
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-16]
	stur	x4, [x29, #-40]
	stur	x5, [x29, #-32]
	stur	x0, [x29, #-48]
	str	x1, [sp, #56]
	ldr	x0, [sp, #56]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #52
	add	x4, sp, #51
	bl	_hm_find_slot
	tbnz	w0, #0, LBB81_2
	b	LBB81_1
LBB81_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB81_14
LBB81_2:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB81_4
	b	LBB81_3
LBB81_3:
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldur	q0, [x8, #24]
	str	q0, [sp, #16]
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-32]
	bl	_vm_retain
	ldr	x8, [sp, #40]
	ldur	q0, [x29, #-40]
	stur	q0, [x8, #24]
	ldur	x0, [x29, #-48]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_vm_release
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB81_14
LBB81_4:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #8]
	ldr	d0, [sp, #8]
	ucvtf	d0, d0
	ldr	x8, [sp, #56]
	ldr	s2, [x8, #20]
                                        ; implicit-def: $d1
	mov.16b	v1, v2
	ucvtf	d1, d1
	fdiv	d0, d0, d1
	fmov	d1, #0.75000000
	fcmp	d0, d1
	b.le	LBB81_11
	b	LBB81_5
LBB81_5:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #20]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.hi	LBB81_7
	b	LBB81_6
LBB81_6:
	ldur	x0, [x29, #-48]
	ldr	x1, [sp, #56]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #20]
	lsl	w2, w8, #1
	bl	_hm_resize
	tbnz	w0, #0, LBB81_8
	b	LBB81_7
LBB81_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB81_14
LBB81_8:
	ldr	x0, [sp, #56]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	add	x3, sp, #52
	add	x4, sp, #51
	bl	_hm_find_slot
	tbnz	w0, #0, LBB81_10
	b	LBB81_9
LBB81_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB81_14
LBB81_10:
	b	LBB81_11
LBB81_11:
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB81_13
	b	LBB81_12
LBB81_12:
	ldr	x9, [sp, #56]
	ldr	w8, [x9, #16]
	subs	w8, w8, #1
	str	w8, [x9, #16]
	b	LBB81_13
LBB81_13:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x8, [sp]
	ldur	q0, [x29, #-24]
	stur	q0, [x8, #8]
	ldr	x8, [sp]
	ldur	q0, [x29, #-40]
	stur	q0, [x8, #24]
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-24]
	ldur	x2, [x29, #-16]
	bl	_vm_retain
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-32]
	bl	_vm_retain
	ldr	x10, [sp, #56]
	ldr	w8, [x10, #12]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #12]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB81_14
LBB81_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_has                 ; -- Begin function vm_hashmap_has
	.p2align	2
_vm_hashmap_has:                        ; @vm_hashmap_has
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	add	x3, sp, #20
	add	x4, sp, #19
	bl	_hm_find_slot
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB82_2
	b	LBB82_1
LBB82_1:
	ldrb	w8, [sp, #19]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB82_2
LBB82_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_delete              ; -- Begin function vm_hashmap_delete
	.p2align	2
_vm_hashmap_delete:                     ; @vm_hashmap_delete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-16]
	stur	x3, [x29, #-8]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	sub	x3, x29, #36
	sub	x4, x29, #37
	bl	_hm_find_slot
	tbz	w0, #0, LBB83_2
	b	LBB83_1
LBB83_1:
	ldurb	w8, [x29, #-37]
	tbnz	w8, #0, LBB83_3
	b	LBB83_2
LBB83_2:
	b	LBB83_4
LBB83_3:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldur	q0, [x8, #8]
	str	q0, [sp, #64]
	ldur	x8, [x29, #-48]
	ldur	q0, [x8, #24]
	str	q0, [sp, #48]
	ldur	x8, [x29, #-48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	q0, [sp, #32]
	stur	q0, [x8, #8]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	q0, [sp, #16]
	stur	q0, [x8, #24]
	ldur	x9, [x29, #-48]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #12]
	subs	w8, w8, #1
	str	w8, [x9, #12]
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #16]
	add	w8, w8, #1
	str	w8, [x9, #16]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #64]
	ldr	x2, [sp, #72]
	bl	_vm_release
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #56]
	bl	_vm_release
	b	LBB83_4
LBB83_4:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_keys                ; -- Begin function vm_hashmap_keys
	.p2align	2
_vm_hashmap_keys:                       ; @vm_hashmap_keys
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	b.ls	LBB84_2
	b	LBB84_1
LBB84_1:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB84_3
LBB84_2:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB84_3
LBB84_3:
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #12]                   ; 4-byte Folded Reload
	bl	_vm_array_new
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB84_5
	b	LBB84_4
LBB84_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB84_13
LBB84_5:
	stur	wzr, [x29, #-36]
	b	LBB84_6
LBB84_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB84_12
	b	LBB84_7
LBB84_7:                                ;   in Loop: Header=BB84_6 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB84_10
	b	LBB84_8
LBB84_8:                                ;   in Loop: Header=BB84_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	ldr	x8, [sp, #48]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_vm_array_push
	tbnz	w0, #0, LBB84_10
	b	LBB84_9
LBB84_9:
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x0, [x29, #-32]
	bl	_val_array
	mov	x8, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #32]
	str	x1, [sp, #40]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #40]
	bl	_vm_release
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB84_13
LBB84_10:                               ;   in Loop: Header=BB84_6 Depth=1
	b	LBB84_11
LBB84_11:                               ;   in Loop: Header=BB84_6 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB84_6
LBB84_12:
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-8]
	b	LBB84_13
LBB84_13:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_array
_val_array:                             ; @val_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #7                          ; =0x7
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_hashmap_values              ; -- Begin function vm_hashmap_values
	.p2align	2
_vm_hashmap_values:                     ; @vm_hashmap_values
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #9]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	b.ls	LBB86_2
	b	LBB86_1
LBB86_1:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB86_3
LBB86_2:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB86_3
LBB86_3:
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #12]                   ; 4-byte Folded Reload
	bl	_vm_array_new
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB86_5
	b	LBB86_4
LBB86_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB86_13
LBB86_5:
	stur	wzr, [x29, #-36]
	b	LBB86_6
LBB86_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB86_12
	b	LBB86_7
LBB86_7:                                ;   in Loop: Header=BB86_6 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB86_10
	b	LBB86_8
LBB86_8:                                ;   in Loop: Header=BB86_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	ldr	x8, [sp, #48]
	ldr	x2, [x8, #24]
	ldr	x3, [x8, #32]
	bl	_vm_array_push
	tbnz	w0, #0, LBB86_10
	b	LBB86_9
LBB86_9:
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x0, [x29, #-32]
	bl	_val_array
	mov	x8, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #32]
	str	x1, [sp, #40]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #40]
	bl	_vm_release
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB86_13
LBB86_10:                               ;   in Loop: Header=BB86_6 Depth=1
	b	LBB86_11
LBB86_11:                               ;   in Loop: Header=BB86_6 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB86_6
LBB86_12:
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-8]
	b	LBB86_13
LBB86_13:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_string
_val_string:                            ; @val_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #5                          ; =0x5
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_intern_maybe_grow
_vm_intern_maybe_grow:                  ; @vm_intern_maybe_grow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #60]
	mov	x9, x8
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #56]
                                        ; kill: def $x8 killed $w8
	mov	x10, #3                         ; =0x3
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w10
	subs	x8, x8, x9, lsl #2
	b.ls	LBB88_2
	b	LBB88_1
LBB88_1:
	b	LBB88_17
LBB88_2:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #56]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB88_4
	b	LBB88_3
LBB88_3:
	b	LBB88_17
LBB88_4:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #56]
	cbz	w8, LBB88_6
	b	LBB88_5
LBB88_5:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #56]
	lsl	w8, w8, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB88_7
LBB88_6:
	mov	w8, #256                        ; =0x100
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB88_7
LBB88_7:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-12]
	ldur	w8, [x29, #-12]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	stur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB88_9
	b	LBB88_8
LBB88_8:
	b	LBB88_17
LBB88_9:
	stur	wzr, [x29, #-28]
	b	LBB88_10
LBB88_10:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB88_12 Depth 2
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #56]
	subs	w8, w8, w9
	b.hs	LBB88_16
	b	LBB88_11
LBB88_11:                               ;   in Loop: Header=BB88_10 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #48]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	b	LBB88_12
LBB88_12:                               ;   Parent Loop BB88_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]
	cbz	x8, LBB88_14
	b	LBB88_13
LBB88_13:                               ;   in Loop: Header=BB88_12 Depth=2
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #16]
	str	x8, [sp, #16]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-12]
	subs	w9, w9, #1
	and	w8, w8, w9
	str	w8, [sp, #12]
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #24]
	str	x8, [x9, #16]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	ldr	x8, [sp, #16]
	str	x8, [sp, #24]
	b	LBB88_12
LBB88_14:                               ;   in Loop: Header=BB88_10 Depth=1
	b	LBB88_15
LBB88_15:                               ;   in Loop: Header=BB88_10 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB88_10
LBB88_16:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #48]
	bl	_free
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-8]
	str	x8, [x9, #48]
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	str	w8, [x9, #56]
	b	LBB88_17
LBB88_17:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nano_rt_f64_nonfinite
_nano_rt_f64_nonfinite:                 ; @nano_rt_f64_nonfinite
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	d0, [sp, #16]
	ldr	d0, [sp, #16]
	str	d0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	x9, #9218868437227405312        ; =0x7ff0000000000000
	and	x8, x8, #0x7ff0000000000000
	subs	x8, x8, x9
	b.eq	LBB89_2
	b	LBB89_1
LBB89_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB89_5
LBB89_2:
	ldr	x8, [sp, #8]
	and	x8, x8, #0xfffffffffffff
	cbz	x8, LBB89_4
	b	LBB89_3
LBB89_3:
	ldr	x8, [sp, #8]
	lsr	x10, x8, #63
	adrp	x9, l_.str.10@PAGE
	add	x9, x9, l_.str.10@PAGEOFF
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	subs	x10, x10, #0
	csel	x8, x8, x9, ne
	str	x8, [sp, #24]
	b	LBB89_5
LBB89_4:
	ldr	x8, [sp, #8]
	lsr	x10, x8, #63
	adrp	x9, l_.str.12@PAGE
	add	x9, x9, l_.str.12@PAGEOFF
	adrp	x8, l_.str.11@PAGE
	add	x8, x8, l_.str.11@PAGEOFF
	subs	x10, x10, #0
	csel	x8, x8, x9, ne
	str	x8, [sp, #24]
	b	LBB89_5
LBB89_5:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_int
_val_int:                               ; @val_int
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_float
_val_float:                             ; @val_float
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	d0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #3                          ; =0x3
	strb	w8, [sp, #16]
	ldr	d0, [sp, #8]
	str	d0, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_bool
_val_bool:                              ; @val_bool
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #15]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #4                          ; =0x4
	strb	w8, [sp, #16]
	ldrb	w8, [sp, #15]
	and	w8, w8, #0x1
	strb	w8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_u8
_val_u8:                                ; @val_u8
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #15]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #16]
	ldrb	w8, [sp, #15]
	strb	w8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_import_header
_vm_rm_import_header:                   ; @vm_rm_import_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB94_12
	b	LBB94_1
LBB94_1:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #13
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB94_12
	b	LBB94_2
LBB94_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB94_12
	b	LBB94_3
LBB94_3:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #6]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.gt	LBB94_12
	b	LBB94_4
LBB94_4:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB94_12
	b	LBB94_5
LBB94_5:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #9]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB94_12
	b	LBB94_6
LBB94_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB94_12
	b	LBB94_7
LBB94_7:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #16
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.lo	LBB94_12
	b	LBB94_8
LBB94_8:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	subs	w9, w9, #1
	and	w8, w8, w9
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	w8, LBB94_12
	b	LBB94_9
LBB94_9:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	mov	x9, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	udiv	x10, x8, x9
	mov	x9, #40                         ; =0x28
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hi	LBB94_12
	b	LBB94_10
LBB94_10:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #12]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hi	LBB94_12
	b	LBB94_11
LBB94_11:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	ldr	x10, [sp, #8]
	ldr	w10, [x10, #12]
	subs	w9, w9, w10
	subs	w8, w8, w9
	cset	w8, ls
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB94_12
LBB94_12:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_string
_vm_rm_string:                          ; @vm_rm_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldrb	w9, [sp, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB95_6
	b	LBB95_1
LBB95_1:
	ldr	x8, [sp, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB95_6
	b	LBB95_2
LBB95_2:
	ldr	x8, [sp, #24]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB95_6
	b	LBB95_3
LBB95_3:
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	w8, LBB95_6
	b	LBB95_4
LBB95_4:
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB95_6
	b	LBB95_5
LBB95_5:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #24
	add	x8, x8, #1
	adds	x8, x8, #1
	cset	w8, ls
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB95_6
LBB95_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function hash_value
_hash_value:                            ; @hash_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	x1, [sp, #16]
	ldrb	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB96_4
	b	LBB96_1
LBB96_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB96_9
	b	LBB96_2
LBB96_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB96_5
	b	LBB96_3
LBB96_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #9
	b.eq	LBB96_10
	b	LBB96_11
LBB96_4:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #16]
	eor	x8, x8, x9, asr #32
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #28]
	b	LBB96_12
LBB96_5:
	ldr	x8, [sp, #16]
	cbz	x8, LBB96_7
	b	LBB96_6
LBB96_6:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB96_8
LBB96_7:
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB96_8
LBB96_8:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #28]
	b	LBB96_12
LBB96_9:
	ldrb	w9, [sp, #16]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #28]
	b	LBB96_12
LBB96_10:
	ldr	w8, [sp, #16]
	str	w8, [sp, #28]
	b	LBB96_12
LBB96_11:
	str	wzr, [sp, #28]
	b	LBB96_12
LBB96_12:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_observation_charge
_vm_rm_observation_charge:              ; @vm_rm_observation_charge
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB97_3
	b	LBB97_1
LBB97_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB97_3
	b	LBB97_2
LBB97_2:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	ldr	x10, [sp, #16]
	ldr	x10, [x10]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB97_4
	b	LBB97_3
LBB97_3:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #16]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB97_5
LBB97_4:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB97_5
LBB97_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_map_header
_vm_rm_map_header:                      ; @vm_rm_map_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB98_12
	b	LBB98_1
LBB98_1:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #13
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB98_12
	b	LBB98_2
LBB98_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB98_12
	b	LBB98_3
LBB98_3:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	w8, LBB98_12
	b	LBB98_4
LBB98_4:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB98_12
	b	LBB98_5
LBB98_5:
	ldr	x8, [sp, #8]
	ldrb	w9, [x8, #9]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB98_12
	b	LBB98_6
LBB98_6:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB98_12
	b	LBB98_7
LBB98_7:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #16
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.lo	LBB98_12
	b	LBB98_8
LBB98_8:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	subs	w9, w9, #1
	and	w8, w8, w9
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	w8, LBB98_12
	b	LBB98_9
LBB98_9:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #20]
	mov	x9, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	udiv	x10, x8, x9
	mov	x9, #40                         ; =0x28
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hi	LBB98_12
	b	LBB98_10
LBB98_10:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #12]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hi	LBB98_12
	b	LBB98_11
LBB98_11:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #20]
	ldr	x10, [sp, #8]
	ldr	w10, [x10, #12]
	subs	w9, w9, w10
	subs	w8, w8, w9
	cset	w8, ls
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB98_12
LBB98_12:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function vm_rm_validate_tombstones
_vm_rm_validate_tombstones:             ; @vm_rm_validate_tombstones
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	stur	wzr, [x29, #-32]
	stur	wzr, [x29, #-36]
	stur	wzr, [x29, #-40]
	b	LBB99_1
LBB99_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB99_24 Depth 2
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB99_52
	b	LBB99_2
LBB99_2:                                ;   in Loop: Header=BB99_1 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #8                          ; =0x8
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB99_4
	b	LBB99_3
LBB99_3:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_4:                                ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	cbnz	w8, LBB99_6
	b	LBB99_5
LBB99_5:                                ;   in Loop: Header=BB99_1 Depth=1
	b	LBB99_51
LBB99_6:                                ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB99_11
	b	LBB99_7
LBB99_7:                                ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB99_9
	b	LBB99_8
LBB99_8:                                ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #24]
	cbz	w8, LBB99_10
	b	LBB99_9
LBB99_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_10:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB99_51
LBB99_11:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB99_14
	b	LBB99_12
LBB99_12:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_string
	tbz	w0, #0, LBB99_14
	b	LBB99_13
LBB99_13:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB99_15
	b	LBB99_14
LBB99_14:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_15:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #56]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB99_17
	b	LBB99_16
LBB99_16:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_17:                               ;   in Loop: Header=BB99_1 Depth=1
	ldurb	w8, [x29, #-25]
	tbz	w8, #0, LBB99_21
	b	LBB99_18
LBB99_18:                               ;   in Loop: Header=BB99_1 Depth=1
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #5]
	cbnz	w8, LBB99_20
	b	LBB99_19
LBB99_19:                               ;   in Loop: Header=BB99_1 Depth=1
	ldr	x8, [sp, #56]
	add	x8, x8, #24
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbz	w8, LBB99_21
	b	LBB99_20
LBB99_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_21:                               ;   in Loop: Header=BB99_1 Depth=1
	ldr	x8, [sp, #56]
	add	x0, x8, #24
	ldr	x8, [sp, #56]
	ldr	w1, [x8, #8]
	bl	_fnv1a
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #12]
	subs	w8, w0, w8
	b.eq	LBB99_23
	b	LBB99_22
LBB99_22:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_23:                               ;   in Loop: Header=BB99_1 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #52]
	strb	wzr, [sp, #51]
	str	wzr, [sp, #44]
	b	LBB99_24
LBB99_24:                               ;   Parent Loop BB99_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB99_48
	b	LBB99_25
LBB99_25:                               ;   in Loop: Header=BB99_24 Depth=2
	ldur	x0, [x29, #-24]
	mov	x1, #4                          ; =0x4
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB99_27
	b	LBB99_26
LBB99_26:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_27:                               ;   in Loop: Header=BB99_24 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	cbnz	w8, LBB99_29
	b	LBB99_28
LBB99_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_29:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB99_34
	b	LBB99_30
LBB99_30:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB99_32
	b	LBB99_31
LBB99_31:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #24]
	cbz	w8, LBB99_33
	b	LBB99_32
LBB99_32:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_33:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #52]
	b	LBB99_47
LBB99_34:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB99_36
	b	LBB99_35
LBB99_35:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_vm_rm_string
	tbnz	w0, #0, LBB99_37
	b	LBB99_36
LBB99_36:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_37:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB99_39
	b	LBB99_38
LBB99_38:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB99_40
LBB99_39:                               ;   in Loop: Header=BB99_24 Depth=2
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB99_40
LBB99_40:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #24]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #24]
	bl	_vm_rm_observation_charge
	tbnz	w0, #0, LBB99_42
	b	LBB99_41
LBB99_41:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_42:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	x9, [sp, #32]
	ldur	x8, [x29, #-48]
	ldr	x0, [x9, #8]
	ldr	x1, [x9, #16]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_val_equal
	tbz	w0, #0, LBB99_46
	b	LBB99_43
LBB99_43:                               ;   in Loop: Header=BB99_1 Depth=1
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	b.eq	LBB99_45
	b	LBB99_44
LBB99_44:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_45:                               ;   in Loop: Header=BB99_1 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #51]
	b	LBB99_48
LBB99_46:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	w10, [x9, #20]
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #52]
	b	LBB99_47
LBB99_47:                               ;   in Loop: Header=BB99_24 Depth=2
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB99_24
LBB99_48:                               ;   in Loop: Header=BB99_1 Depth=1
	ldrb	w8, [sp, #51]
	tbnz	w8, #0, LBB99_50
	b	LBB99_49
LBB99_49:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_50:                               ;   in Loop: Header=BB99_1 Depth=1
	b	LBB99_51
LBB99_51:                               ;   in Loop: Header=BB99_1 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB99_1
LBB99_52:
	ldur	w9, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB99_54
	b	LBB99_53
LBB99_53:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB99_54
LBB99_54:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	cset	w8, eq
	stur	w8, [x29, #-4]
	b	LBB99_55
LBB99_55:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

l_.str.1:                               ; @.str.1
	.asciz	"%lld"

l_.str.2:                               ; @.str.2
	.asciz	"true"

l_.str.3:                               ; @.str.3
	.asciz	"false"

l___func__.vm_array_swap_scalar_storage: ; @__func__.vm_array_swap_scalar_storage
	.asciz	"vm_array_swap_scalar_storage"

l_.str.4:                               ; @.str.4
	.asciz	"heap.c"

l_.str.5:                               ; @.str.5
	.asciz	"a && b && a->elem_type == b->elem_type && a->unboxed == b->unboxed"

l_.str.6:                               ; @.str.6
	.asciz	"vm_array_type_unboxable(a->elem_type) || a->elem_type == TAG_STRING"

l_.str.7:                               ; @.str.7
	.asciz	"%s"

l_.str.8:                               ; @.str.8
	.asciz	"%g"

l_.str.9:                               ; @.str.9
	.asciz	"-nan"

l_.str.10:                              ; @.str.10
	.asciz	"nan"

l_.str.11:                              ; @.str.11
	.asciz	"-inf"

l_.str.12:                              ; @.str.12
	.asciz	"inf"

.subsections_via_symbols
