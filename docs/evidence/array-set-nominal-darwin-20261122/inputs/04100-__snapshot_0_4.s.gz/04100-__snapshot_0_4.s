	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_binding_allocation_bound ; -- Begin function nl_socket_binding_allocation_bound
	.p2align	2
_nl_socket_binding_allocation_bound:    ; @nl_socket_binding_allocation_bound
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	mov	x8, #32                         ; =0x20
	str	x8, [sp, #8]
	str	xzr, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB0_17
	b	LBB0_1
LBB0_1:
	mov	x0, sp
	mov	x1, #16                         ; =0x10
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_2
LBB0_2:
	mov	x0, sp
	mov	x1, #48                         ; =0x30
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_3
LBB0_3:
	mov	x0, sp
	mov	x1, #40                         ; =0x28
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_4
LBB0_4:
	mov	x0, sp
	mov	x1, #24                         ; =0x18
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_5
LBB0_5:
	mov	x0, sp
	mov	x1, #64                         ; =0x40
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_6
LBB0_6:
	mov	x0, sp
	mov	x1, #24                         ; =0x18
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_7
LBB0_7:
	add	x0, sp, #8
	mov	x1, #2                          ; =0x2
	mov	x2, #1                          ; =0x1
	movk	x2, #16, lsl #16
	bl	_fb_product
	tbz	w0, #0, LBB0_17
	b	LBB0_8
LBB0_8:
	add	x0, sp, #8
	mov	x1, #1                          ; =0x1
	movk	x1, #16, lsl #16
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_9
LBB0_9:
	add	x0, sp, #8
	mov	x1, #8193                       ; =0x2001
	mov	x2, #64                         ; =0x40
	bl	_fb_product
	tbz	w0, #0, LBB0_17
	b	LBB0_10
LBB0_10:
	add	x0, sp, #8
	mov	x1, #2                          ; =0x2
	mov	x2, #16384                      ; =0x4000
	movk	x2, #16, lsl #16
	bl	_fb_product
	tbz	w0, #0, LBB0_17
	b	LBB0_11
LBB0_11:
	add	x0, sp, #8
	mov	x1, #4097                       ; =0x1001
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_12
LBB0_12:
	add	x0, sp, #8
	mov	x1, #88                         ; =0x58
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_13
LBB0_13:
	ldr	x2, [sp]
	add	x0, sp, #8
	mov	x1, #8192                       ; =0x2000
	bl	_fb_product
	tbz	w0, #0, LBB0_17
	b	LBB0_14
LBB0_14:
	add	x0, sp, #8
	mov	x1, #257                        ; =0x101
	mov	x2, #8                          ; =0x8
	bl	_fb_product
	tbz	w0, #0, LBB0_17
	b	LBB0_15
LBB0_15:
	bl	_nl_socket_plan_storage_size
	mov	x1, x0
	add	x0, sp, #8
	bl	_fb_add
	tbz	w0, #0, LBB0_17
	b	LBB0_16
LBB0_16:
	ldr	x8, [sp, #8]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB0_18
	b	LBB0_17
LBB0_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_19
LBB0_18:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_19
LBB0_19:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_add
_fb_add:                                ; @fb_add
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x10, [x9]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_2
	b	LBB1_1
LBB1_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_2:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_3:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_product
_fb_product:                            ; @fb_product
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x8, [sp, #8]
	ldr	x10, [sp, #16]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.hi	LBB2_3
	b	LBB2_2
LBB2_2:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	mul	x1, x8, x9
	bl	_fb_add
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB2_3
LBB2_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_prepare      ; -- Begin function nl_socket_binding_prepare
	.p2align	2
_nl_socket_binding_prepare:             ; @nl_socket_binding_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_2:
	sub	x0, x29, #40
	bl	_nl_socket_binding_allocation_bound
	tbnz	w0, #0, LBB3_4
	b	LBB3_3
LBB3_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_4:
	sub	x2, x29, #48
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-48]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	bl	_fb_decode
	stur	w0, [x29, #-52]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB3_6
	b	LBB3_5
LBB3_5:
	ldur	w8, [x29, #-52]
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_6:
	adrp	x8, l___const.nl_socket_binding_prepare.json@PAGE
	add	x8, x8, l___const.nl_socket_binding_prepare.json@PAGEOFF
	ldr	q0, [x8]
	add	x0, sp, #64
	str	q0, [sp, #64]
	ldr	q0, [x8, #16]
	str	q0, [sp, #80]
	adrp	x8, l___const.nl_socket_binding_prepare.source@PAGE
	add	x8, x8, l___const.nl_socket_binding_prepare.source@PAGEOFF
	ldr	q0, [x8]
	add	x9, sp, #32
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	str	q0, [sp, #32]
	ldr	q0, [x8, #16]
	str	q0, [sp, #48]
	ldur	x1, [x29, #-48]
	bl	_fb_render_interface
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x1, [x29, #-48]
	bl	_fb_render_source
	mov	x8, #32                         ; =0x20
	str	x8, [sp, #24]
	ldrb	w8, [sp, #88]
	tbz	w8, #0, LBB3_10
	b	LBB3_7
LBB3_7:
	ldrb	w8, [sp, #56]
	tbz	w8, #0, LBB3_10
	b	LBB3_8
LBB3_8:
	ldr	x8, [sp, #72]
	add	x1, x8, #1
	add	x0, sp, #24
	bl	_fb_add
	tbz	w0, #0, LBB3_10
	b	LBB3_9
LBB3_9:
	ldr	x8, [sp, #40]
	add	x1, x8, #1
	add	x0, sp, #24
	bl	_fb_add
	tbnz	w0, #0, LBB3_11
	b	LBB3_10
LBB3_10:
	ldur	x0, [x29, #-48]
	bl	_nl_nsi_free
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_11:
	ldr	x0, [sp, #24]
	bl	_malloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB3_13
	b	LBB3_12
LBB3_12:
	ldur	x0, [x29, #-48]
	bl	_nl_nsi_free
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_13:
	add	x0, sp, #64
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	add	x8, sp, #32
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	str	x8, [x9, #16]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #16]
	str	x8, [x9, #24]
	ldr	x8, [sp, #16]
	add	x8, x8, #32
	str	x8, [sp, #64]
	ldr	x8, [sp, #72]
	str	x8, [sp, #80]
	str	xzr, [sp, #72]
	ldr	x8, [sp, #16]
	add	x8, x8, #32
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #32]
	ldr	x8, [sp, #40]
	str	x8, [sp, #48]
	str	xzr, [sp, #40]
	ldur	x1, [x29, #-48]
	bl	_fb_render_interface
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldur	x1, [x29, #-48]
	bl	_fb_render_source
	ldur	x0, [x29, #-48]
	bl	_nl_nsi_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-48]
	ldrb	w8, [sp, #88]
	tbz	w8, #0, LBB3_17
	b	LBB3_14
LBB3_14:
	ldrb	w8, [sp, #56]
	tbz	w8, #0, LBB3_17
	b	LBB3_15
LBB3_15:
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB3_17
	b	LBB3_16
LBB3_16:
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB3_18
	b	LBB3_17
LBB3_17:
	ldr	x0, [sp, #16]
	bl	_free
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_18:
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #72]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #40]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #16]
	add	x0, x8, #32
	ldr	x8, [sp, #16]
	ldr	x1, [x8]
	sub	x2, x29, #48
	bl	_fb_decode
	stur	w0, [x29, #-52]
	ldur	x0, [x29, #-48]
	bl	_nl_nsi_free
	ldur	w8, [x29, #-52]
	cbz	w8, LBB3_20
	b	LBB3_19
LBB3_19:
	ldr	x0, [sp, #16]
	bl	_free
	ldur	w8, [x29, #-52]
	stur	w8, [x29, #-4]
	b	LBB3_21
LBB3_20:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB3_21
LBB3_21:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_decode
_fb_decode:                             ; @fb_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	bl	_fb_preflight
	stur	w0, [x29, #-36]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_2:
	ldur	x8, [x29, #-24]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB4_4
	b	LBB4_3
LBB4_3:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_4:
	ldr	x0, [sp, #32]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-24]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	add	x8, x8, x9
	strb	wzr, [x8]
	add	x2, sp, #24
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	ldr	x0, [sp, #32]
	ldur	x8, [x29, #-24]
	add	x1, x8, #1
	mov	w3, #1                          ; =0x1
	bl	_cJSON_ParseWithLengthOpts
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB4_6
	b	LBB4_5
LBB4_5:
	ldr	x0, [sp, #32]
	bl	_free
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_6:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	ldur	x10, [x29, #-24]
	add	x9, x9, x10
	subs	x8, x8, x9
	b.ne	LBB4_8
	b	LBB4_7
LBB4_7:
	ldr	x0, [sp, #16]
	mov	x1, #0                          ; =0x0
	bl	_fb_unique_keys
	tbnz	w0, #0, LBB4_9
	b	LBB4_8
LBB4_8:
	ldr	x0, [sp, #16]
	bl	_cJSON_Delete
	ldr	x0, [sp, #32]
	bl	_free
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_9:
	ldr	x0, [sp, #16]
	bl	_nl_nsi_decode_object
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_cJSON_Delete
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x8, [sp, #8]
	cbnz	x8, LBB4_11
	b	LBB4_10
LBB4_10:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_11:
	ldr	x0, [sp, #8]
	bl	_binding_catalog_validate
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB4_13
	b	LBB4_12
LBB4_12:
	ldr	x0, [sp, #8]
	bl	_nl_nsi_free
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB4_14
LBB4_13:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB4_14
LBB4_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_render_interface
_fb_render_interface:                   ; @fb_render_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x2, [x8, #16]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.17@PAGE
	add	x1, x1, l_.str.17@PAGEOFF
	bl	_fb_write
	stur	xzr, [x29, #-24]
	b	LBB5_1
LBB5_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_5 Depth 2
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB5_12
	b	LBB5_2
LBB5_2:                                 ;   in Loop: Header=BB5_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-24]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB5_4
	b	LBB5_3
LBB5_3:                                 ;   in Loop: Header=BB5_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fb_write
	b	LBB5_4
LBB5_4:                                 ;   in Loop: Header=BB5_1 Depth=1
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8]
	ldur	x8, [x29, #-32]
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_fb_write
	stur	xzr, [x29, #-40]
	b	LBB5_5
LBB5_5:                                 ;   Parent Loop BB5_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.hs	LBB5_10
	b	LBB5_6
LBB5_6:                                 ;   in Loop: Header=BB5_5 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-40]
	cbz	x8, LBB5_8
	b	LBB5_7
LBB5_7:                                 ;   in Loop: Header=BB5_5 Depth=2
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fb_write
	b	LBB5_8
LBB5_8:                                 ;   in Loop: Header=BB5_5 Depth=2
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	x1, [x8]
	ldur	x8, [x29, #-48]
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	x1, [x8, #16]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.21@PAGE
	add	x1, x1, l_.str.21@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #24]
	mov	x9, x8
	adrp	x8, _fb_render_interface.directions@PAGE
	add	x8, x8, _fb_render_interface.directions@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.22@PAGE
	add	x1, x1, l_.str.22@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #28]
	mov	x9, x8
	adrp	x8, _fb_render_interface.ownerships@PAGE
	add	x8, x8, _fb_render_interface.ownerships@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.23@PAGE
	add	x1, x1, l_.str.23@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	mov	x9, x8
	adrp	x8, _fb_render_interface.lifetimes@PAGE
	add	x8, x8, _fb_render_interface.lifetimes@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.24@PAGE
	add	x1, x1, l_.str.24@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #36]
	mov	x9, x8
	adrp	x8, _fb_render_interface.mutability@PAGE
	add	x8, x8, _fb_render_interface.mutability@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.25@PAGE
	add	x1, x1, l_.str.25@PAGEOFF
	bl	_fb_write
	b	LBB5_9
LBB5_9:                                 ;   in Loop: Header=BB5_5 Depth=2
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB5_5
LBB5_10:                                ;   in Loop: Header=BB5_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.26@PAGE
	add	x1, x1, l_.str.26@PAGEOFF
	bl	_fb_write
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_1 Depth=1
	ldur	x8, [x29, #-24]
	add	x8, x8, #1
	stur	x8, [x29, #-24]
	b	LBB5_1
LBB5_12:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.27@PAGE
	add	x1, x1, l_.str.27@PAGEOFF
	bl	_fb_write
	str	xzr, [sp, #56]
	b	LBB5_13
LBB5_13:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_21 Depth 2
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB5_31
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #56]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #48]
	ldr	x8, [sp, #56]
	cbz	x8, LBB5_16
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fb_write
	b	LBB5_16
LBB5_16:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8]
	ldr	x8, [sp, #48]
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.28@PAGE
	add	x1, x1, l_.str.28@PAGEOFF
	bl	_fb_write
	ldur	x8, [x29, #-8]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB5_18
	b	LBB5_17
LBB5_17:                                ;   in Loop: Header=BB5_13 Depth=1
	adrp	x8, l_.str.29@PAGE
	add	x8, x8, l_.str.29@PAGEOFF
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_19
LBB5_18:                                ;   in Loop: Header=BB5_13 Depth=1
	ldr	x8, [sp, #48]
	ldr	w10, [x8, #16]
	adrp	x9, l_.str.13@PAGE
	add	x9, x9, l_.str.13@PAGEOFF
	adrp	x8, l_.str.30@PAGE
	add	x8, x8, l_.str.30@PAGEOFF
	subs	w10, w10, #2
	csel	x8, x8, x9, eq
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_19
LBB5_19:                                ;   in Loop: Header=BB5_13 Depth=1
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	bl	_fb_quote
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #16]
	subs	w8, w8, #6
	b.eq	LBB5_29
	b	LBB5_20
LBB5_20:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #48]
	ldr	w10, [x8, #16]
	adrp	x9, l_.str.32@PAGE
	add	x9, x9, l_.str.32@PAGEOFF
	adrp	x8, l_.str.31@PAGE
	add	x8, x8, l_.str.31@PAGEOFF
	subs	w10, w10, #1
	csel	x1, x8, x9, eq
	bl	_fb_write
	str	xzr, [sp, #40]
	b	LBB5_21
LBB5_21:                                ;   Parent Loop BB5_13 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB5_28
	b	LBB5_22
LBB5_22:                                ;   in Loop: Header=BB5_21 Depth=2
	ldr	x8, [sp, #48]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldr	x8, [sp, #40]
	cbz	x8, LBB5_24
	b	LBB5_23
LBB5_23:                                ;   in Loop: Header=BB5_21 Depth=2
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fb_write
	b	LBB5_24
LBB5_24:                                ;   in Loop: Header=BB5_21 Depth=2
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #32]
	ldr	x1, [x8]
	ldr	x8, [sp, #32]
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	cbz	x8, LBB5_26
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_21 Depth=2
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #32]
	ldr	x1, [x8, #16]
	bl	_fb_quote
	b	LBB5_26
LBB5_26:                                ;   in Loop: Header=BB5_21 Depth=2
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_fb_write
	b	LBB5_27
LBB5_27:                                ;   in Loop: Header=BB5_21 Depth=2
	ldr	x8, [sp, #40]
	add	x8, x8, #1
	str	x8, [sp, #40]
	b	LBB5_21
LBB5_28:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.34@PAGE
	add	x1, x1, l_.str.34@PAGEOFF
	bl	_fb_write
	b	LBB5_29
LBB5_29:                                ;   in Loop: Header=BB5_13 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_fb_write
	b	LBB5_30
LBB5_30:                                ;   in Loop: Header=BB5_13 Depth=1
	ldr	x8, [sp, #56]
	add	x8, x8, #1
	str	x8, [sp, #56]
	b	LBB5_13
LBB5_31:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x1, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.36@PAGE
	add	x1, x1, l_.str.36@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x1, [x8, #16]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.37@PAGE
	add	x1, x1, l_.str.37@PAGEOFF
	bl	_fb_write
	str	xzr, [sp, #24]
	b	LBB5_32
LBB5_32:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB5_37
	b	LBB5_33
LBB5_33:                                ;   in Loop: Header=BB5_32 Depth=1
	ldr	x8, [sp, #24]
	cbz	x8, LBB5_35
	b	LBB5_34
LBB5_34:                                ;   in Loop: Header=BB5_32 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fb_write
	b	LBB5_35
LBB5_35:                                ;   in Loop: Header=BB5_32 Depth=1
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #24]
	lsl	x9, x9, #4
	ldr	x1, [x8, x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #24]
	add	x8, x8, x9, lsl #4
	ldr	x2, [x8, #8]
	bl	_fb_named
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_fb_write
	b	LBB5_36
LBB5_36:                                ;   in Loop: Header=BB5_32 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB5_32
LBB5_37:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.38@PAGE
	add	x1, x1, l_.str.38@PAGEOFF
	bl	_fb_write
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_render_source
_fb_render_source:                      ; @fb_render_source
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.43@PAGE
	add	x1, x1, l_.str.43@PAGEOFF
	bl	_fb_write
	ldr	x0, [sp, #8]
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	bl	_fb_quote
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.44@PAGE
	add	x1, x1, l_.str.44@PAGEOFF
	bl	_fb_write
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_free         ; -- Begin function nl_socket_binding_free
	.p2align	2
_nl_socket_binding_free:                ; @nl_socket_binding_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_interface_bytes ; -- Begin function nl_socket_binding_interface_bytes
	.p2align	2
_nl_socket_binding_interface_bytes:     ; @nl_socket_binding_interface_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB8_3
	b	LBB8_2
LBB8_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB8_4
LBB8_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	add	x8, x8, #32
	str	x8, [sp, #24]
	b	LBB8_4
LBB8_4:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_source_bytes ; -- Begin function nl_socket_binding_source_bytes
	.p2align	2
_nl_socket_binding_source_bytes:        ; @nl_socket_binding_source_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB9_3
	b	LBB9_2
LBB9_2:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB9_4
LBB9_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	add	x8, x8, #32
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB9_4
LBB9_4:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_storage_size ; -- Begin function nl_socket_binding_storage_size
	.p2align	2
_nl_socket_binding_storage_size:        ; @nl_socket_binding_storage_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_binding_peak_bound   ; -- Begin function nl_socket_binding_peak_bound
	.p2align	2
_nl_socket_binding_peak_bound:          ; @nl_socket_binding_peak_bound
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_preflight
_fb_preflight:                          ; @fb_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB12_3
	b	LBB12_2
LBB12_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_3:
	ldur	x8, [x29, #-24]
	subs	x8, x8, #256, lsl #12           ; =1048576
	b.ls	LBB12_5
	b	LBB12_4
LBB12_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_5:
	ldur	x0, [x29, #-16]
	ldur	x2, [x29, #-24]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB12_7
	b	LBB12_6
LBB12_6:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	mov	x2, #0                          ; =0x0
	bl	_nl_utf8_validate
	tbnz	w0, #0, LBB12_8
	b	LBB12_7
LBB12_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_8:
	ldur	x8, [x29, #-16]
	add	x0, sp, #8
	str	x8, [sp, #8]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #16]
	str	xzr, [sp, #24]
	str	xzr, [sp, #32]
	str	xzr, [sp, #40]
	str	wzr, [sp, #48]
	str	wzr, [sp, #52]
	bl	_fb_skip
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.eq	LBB12_10
	b	LBB12_9
LBB12_9:
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #123
	b.eq	LBB12_11
	b	LBB12_10
LBB12_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_11:
	add	x0, sp, #8
	mov	x1, #0                          ; =0x0
	bl	_fb_value
	tbnz	w0, #0, LBB12_13
	b	LBB12_12
LBB12_12:
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_13:
	add	x0, sp, #8
	bl	_fb_skip
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	cset	w8, ne
	stur	w8, [x29, #-4]
	b	LBB12_14
LBB12_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_unique_keys
_fb_unique_keys:                        ; @fb_unique_keys
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldr	x8, [sp, #24]
	subs	x8, x8, #64
	b.ls	LBB13_2
	b	LBB13_1
LBB13_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_24
LBB13_2:
	ldur	x0, [x29, #-16]
	bl	_cJSON_IsObject
	cbz	w0, LBB13_17
	b	LBB13_3
LBB13_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #16]
	b	LBB13_4
LBB13_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_8 Depth 2
	ldr	x8, [sp, #16]
	cbz	x8, LBB13_16
	b	LBB13_5
LBB13_5:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB13_7
	b	LBB13_6
LBB13_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_24
LBB13_7:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	b	LBB13_8
LBB13_8:                                ;   Parent Loop BB13_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #8]
	cbz	x8, LBB13_14
	b	LBB13_9
LBB13_9:                                ;   in Loop: Header=BB13_8 Depth=2
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #56]
	cbz	x8, LBB13_11
	b	LBB13_10
LBB13_10:                               ;   in Loop: Header=BB13_8 Depth=2
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #56]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #56]
	bl	_strcmp
	cbnz	w0, LBB13_12
	b	LBB13_11
LBB13_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_24
LBB13_12:                               ;   in Loop: Header=BB13_8 Depth=2
	b	LBB13_13
LBB13_13:                               ;   in Loop: Header=BB13_8 Depth=2
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp, #8]
	b	LBB13_8
LBB13_14:                               ;   in Loop: Header=BB13_4 Depth=1
	b	LBB13_15
LBB13_15:                               ;   in Loop: Header=BB13_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	b	LBB13_4
LBB13_16:
	b	LBB13_17
LBB13_17:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	str	x8, [sp]
	b	LBB13_18
LBB13_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	cbz	x8, LBB13_23
	b	LBB13_19
LBB13_19:                               ;   in Loop: Header=BB13_18 Depth=1
	ldr	x0, [sp]
	ldr	x8, [sp, #24]
	add	x1, x8, #1
	bl	_fb_unique_keys
	tbnz	w0, #0, LBB13_21
	b	LBB13_20
LBB13_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_24
LBB13_21:                               ;   in Loop: Header=BB13_18 Depth=1
	b	LBB13_22
LBB13_22:                               ;   in Loop: Header=BB13_18 Depth=1
	ldr	x8, [sp]
	ldr	x8, [x8]
	str	x8, [sp]
	b	LBB13_18
LBB13_23:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_24
LBB13_24:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function binding_catalog_validate
_binding_catalog_validate:              ; @binding_catalog_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	add	x1, sp, #16
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldur	x0, [x29, #-8]
	bl	_nl_socket_plan_build
	str	w0, [sp, #12]
	ldr	x0, [sp, #16]
	bl	_nl_socket_plan_free
	ldr	w8, [sp, #12]
	cbnz	w8, LBB14_2
	b	LBB14_1
LBB14_1:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB14_3
LBB14_2:
	ldr	w9, [sp, #12]
	mov	w8, #3                          ; =0x3
	subs	w9, w9, #2
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB14_3
LBB14_3:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_skip
_fb_skip:                               ; @fb_skip
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB15_3
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_space
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB15_3
LBB15_3:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_5
	b	LBB15_4
LBB15_4:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x9, [sp, #8]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB15_1
LBB15_5:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_value
_fb_value:                              ; @fb_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	bl	_fb_skip
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.ne	LBB16_2
	b	LBB16_1
LBB16_1:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	stur	w1, [x29, #-52]                 ; 4-byte Folded Spill
	bl	_fb_fail
	ldur	w8, [x29, #-52]                 ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	ldrb	w8, [x8]
	sturb	w8, [x29, #-25]
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #34
	b.ne	LBB16_4
	b	LBB16_3
LBB16_3:
	ldur	x0, [x29, #-16]
	bl	_fb_string
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_4:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #45
	b.eq	LBB16_6
	b	LBB16_5
LBB16_5:
	ldurb	w0, [x29, #-25]
	bl	_fb_digit
	tbz	w0, #0, LBB16_7
	b	LBB16_6
LBB16_6:
	ldur	x0, [x29, #-16]
	bl	_fb_number
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_7:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #123
	b.eq	LBB16_9
	b	LBB16_8
LBB16_8:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #91
	b.ne	LBB16_42
	b	LBB16_9
LBB16_9:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #123
	cset	w8, eq
	sturb	w8, [x29, #-26]
	ldurb	w10, [x29, #-26]
	mov	w9, #93                         ; =0x5d
	mov	w8, #125                        ; =0x7d
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	sturb	w8, [x29, #-27]
	stur	xzr, [x29, #-40]
	ldur	x8, [x29, #-24]
	subs	x8, x8, #64
	b.ne	LBB16_11
	b	LBB16_10
LBB16_10:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_11:
	ldurb	w8, [x29, #-26]
	tbz	w8, #0, LBB16_14
	b	LBB16_12
LBB16_12:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	subs	x8, x8, #256
	b.ls	LBB16_14
	b	LBB16_13
LBB16_13:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_14:
	ldur	x0, [x29, #-16]
	bl	_fb_token
	tbnz	w0, #0, LBB16_16
	b	LBB16_15
LBB16_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_16:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_fb_skip
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB16_19
	b	LBB16_17
LBB16_17:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	ldurb	w9, [x29, #-27]
	subs	w8, w8, w9
	b.ne	LBB16_19
	b	LBB16_18
LBB16_18:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_fb_token
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_19:
	b	LBB16_20
LBB16_20:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	ldurb	w11, [x29, #-26]
	mov	w10, #256                       ; =0x100
	mov	w9, #64                         ; =0x40
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB16_22
	b	LBB16_21
LBB16_21:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_22:                               ;   in Loop: Header=BB16_20 Depth=1
	ldurb	w8, [x29, #-26]
	tbz	w8, #0, LBB16_31
	b	LBB16_23
LBB16_23:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	bl	_fb_string
	tbnz	w0, #0, LBB16_25
	b	LBB16_24
LBB16_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_25:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	bl	_fb_skip
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB16_27
	b	LBB16_26
LBB16_26:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #58
	b.eq	LBB16_28
	b	LBB16_27
LBB16_27:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #56]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_28:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	bl	_fb_token
	tbnz	w0, #0, LBB16_30
	b	LBB16_29
LBB16_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_30:                               ;   in Loop: Header=BB16_20 Depth=1
	b	LBB16_31
LBB16_31:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-24]
	add	x1, x8, #1
	bl	_fb_value
	tbnz	w0, #0, LBB16_33
	b	LBB16_32
LBB16_32:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_33:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	bl	_fb_skip
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.ne	LBB16_35
	b	LBB16_34
LBB16_34:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_35:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	add	x8, x8, x9
	ldrb	w8, [x8]
	sturb	w8, [x29, #-25]
	ldur	x0, [x29, #-16]
	bl	_fb_token
	tbnz	w0, #0, LBB16_37
	b	LBB16_36
LBB16_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_37:                               ;   in Loop: Header=BB16_20 Depth=1
	ldurb	w8, [x29, #-25]
	ldurb	w9, [x29, #-27]
	subs	w8, w8, w9
	b.ne	LBB16_39
	b	LBB16_38
LBB16_38:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_39:                               ;   in Loop: Header=BB16_20 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #44
	b.eq	LBB16_41
	b	LBB16_40
LBB16_40:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #48]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_41:                               ;   in Loop: Header=BB16_20 Depth=1
	ldur	x0, [x29, #-16]
	bl	_fb_skip
	b	LBB16_20
LBB16_42:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #116
	b.ne	LBB16_44
	b	LBB16_43
LBB16_43:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB16_48
LBB16_44:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #102
	b.ne	LBB16_46
	b	LBB16_45
LBB16_45:
	adrp	x8, l_.str.1@PAGE
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB16_47
LBB16_46:
	ldurb	w10, [x29, #-25]
	mov	x9, #0                          ; =0x0
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	subs	w10, w10, #110
	csel	x8, x8, x9, eq
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB16_47
LBB16_47:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB16_48
LBB16_48:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB16_51
	b	LBB16_49
LBB16_49:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-48]
	bl	_strlen
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	subs	x8, x8, x0
	b.lo	LBB16_51
	b	LBB16_50
LBB16_50:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-48]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-48]
	bl	_strlen
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbz	w0, LBB16_52
	b	LBB16_51
LBB16_51:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_52:
	ldur	x0, [x29, #-48]
	bl	_strlen
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, x0
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	bl	_fb_token
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_53
LBB16_53:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_space
_fb_space:                              ; @fb_space
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #32
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB17_4
	b	LBB17_1
LBB17_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #9
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB17_4
	b	LBB17_2
LBB17_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #13
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB17_4
	b	LBB17_3
LBB17_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #10
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB17_4
LBB17_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_fail
_fb_fail:                               ; @fb_fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	str	w8, [x9, #40]
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_string
_fb_string:                             ; @fb_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x0, [x29, #-16]
	bl	_fb_token
	tbnz	w0, #0, LBB19_2
	b	LBB19_1
LBB19_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB19_4
	b	LBB19_3
LBB19_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #34
	b.eq	LBB19_5
	b	LBB19_4
LBB19_4:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-24]
	b	LBB19_6
LBB19_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB19_49
	b	LBB19_7
LBB19_7:                                ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	add	x8, x8, x9
	ldrb	w8, [x8]
	sturb	w8, [x29, #-25]
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #34
	b.ne	LBB19_11
	b	LBB19_8
LBB19_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	subs	x8, x8, #1
	subs	x8, x8, #1, lsl #12             ; =4096
	b.ls	LBB19_10
	b	LBB19_9
LBB19_9:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_11:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	subs	x8, x8, #1, lsl #12             ; =4096
	b.ls	LBB19_13
	b	LBB19_12
LBB19_12:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_13:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #32
	b.ge	LBB19_15
	b	LBB19_14
LBB19_14:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_15:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #92
	b.eq	LBB19_17
	b	LBB19_16
LBB19_16:                               ;   in Loop: Header=BB19_6 Depth=1
	b	LBB19_6
LBB19_17:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.ne	LBB19_19
	b	LBB19_18
LBB19_18:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_19:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	add	x8, x8, x9
	ldrb	w8, [x8]
	sturb	w8, [x29, #-25]
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #34
	b.eq	LBB19_27
	b	LBB19_20
LBB19_20:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #92
	b.eq	LBB19_27
	b	LBB19_21
LBB19_21:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #47
	b.eq	LBB19_27
	b	LBB19_22
LBB19_22:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #98
	b.eq	LBB19_27
	b	LBB19_23
LBB19_23:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #102
	b.eq	LBB19_27
	b	LBB19_24
LBB19_24:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #110
	b.eq	LBB19_27
	b	LBB19_25
LBB19_25:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #114
	b.eq	LBB19_27
	b	LBB19_26
LBB19_26:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #116
	b.ne	LBB19_28
	b	LBB19_27
LBB19_27:                               ;   in Loop: Header=BB19_6 Depth=1
	b	LBB19_6
LBB19_28:                               ;   in Loop: Header=BB19_6 Depth=1
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #117
	b.eq	LBB19_30
	b	LBB19_29
LBB19_29:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_30:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x0, [x29, #-16]
	add	x1, sp, #32
	bl	_fb_hex4
	tbnz	w0, #0, LBB19_32
	b	LBB19_31
LBB19_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_32:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	cbz	w8, LBB19_35
	b	LBB19_33
LBB19_33:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	mov	w9, #56320                      ; =0xdc00
	subs	w8, w8, w9
	b.lo	LBB19_36
	b	LBB19_34
LBB19_34:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	subs	w8, w8, #14, lsl #12            ; =57344
	b.hs	LBB19_36
	b	LBB19_35
LBB19_35:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_36:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	mov	w9, #55296                      ; =0xd800
	subs	w8, w8, w9
	b.lo	LBB19_48
	b	LBB19_37
LBB19_37:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	mov	w9, #56319                      ; =0xdbff
	subs	w8, w8, w9
	b.hi	LBB19_48
	b	LBB19_38
LBB19_38:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	subs	x8, x8, #2
	b.lo	LBB19_41
	b	LBB19_39
LBB19_39:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #92
	b.ne	LBB19_41
	b	LBB19_40
LBB19_40:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	add	x9, x9, #1
	ldrb	w8, [x8, x9]
	subs	w8, w8, #117
	b.eq	LBB19_42
	b	LBB19_41
LBB19_41:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_42:                               ;   in Loop: Header=BB19_6 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #2
	str	x8, [x9, #16]
	ldur	x0, [x29, #-16]
	add	x1, sp, #32
	bl	_fb_hex4
	tbnz	w0, #0, LBB19_44
	b	LBB19_43
LBB19_43:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_44:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	mov	w9, #56320                      ; =0xdc00
	subs	w8, w8, w9
	b.lo	LBB19_46
	b	LBB19_45
LBB19_45:                               ;   in Loop: Header=BB19_6 Depth=1
	ldr	w8, [sp, #32]
	subs	w8, w8, #14, lsl #12            ; =57344
	b.lo	LBB19_47
	b	LBB19_46
LBB19_46:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_47:                               ;   in Loop: Header=BB19_6 Depth=1
	b	LBB19_48
LBB19_48:                               ;   in Loop: Header=BB19_6 Depth=1
	b	LBB19_6
LBB19_49:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp]                        ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB19_50
LBB19_50:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_digit
_fb_digit:                              ; @fb_digit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #48
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.lt	LBB20_2
	b	LBB20_1
LBB20_1:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #57
	cset	w8, le
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB20_2
LBB20_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_number
_fb_number:                             ; @fb_number
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-24]
	ldur	x0, [x29, #-16]
	bl	_fb_token
	tbnz	w0, #0, LBB21_2
	b	LBB21_1
LBB21_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_45
LBB21_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #45
	b.ne	LBB21_4
	b	LBB21_3
LBB21_3:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_4
LBB21_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB21_6
	b	LBB21_5
LBB21_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	tbnz	w0, #0, LBB21_7
	b	LBB21_6
LBB21_6:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	stur	w1, [x29, #-28]                 ; 4-byte Folded Spill
	bl	_fb_fail
	ldur	w8, [x29, #-28]                 ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB21_45
LBB21_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #48
	b.ne	LBB21_9
	b	LBB21_8
LBB21_8:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_15
LBB21_9:
	b	LBB21_10
LBB21_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #32]                   ; 4-byte Folded Spill
	b.hs	LBB21_12
	b	LBB21_11
LBB21_11:                               ;   in Loop: Header=BB21_10 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	str	w0, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB21_12
LBB21_12:                               ;   in Loop: Header=BB21_10 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB21_14
	b	LBB21_13
LBB21_13:                               ;   in Loop: Header=BB21_10 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_10
LBB21_14:
	b	LBB21_15
LBB21_15:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB21_26
	b	LBB21_16
LBB21_16:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB21_26
	b	LBB21_17
LBB21_17:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB21_19
	b	LBB21_18
LBB21_18:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	tbnz	w0, #0, LBB21_20
	b	LBB21_19
LBB21_19:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB21_45
LBB21_20:
	b	LBB21_21
LBB21_21:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b.hs	LBB21_23
	b	LBB21_22
LBB21_22:                               ;   in Loop: Header=BB21_21 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB21_23
LBB21_23:                               ;   in Loop: Header=BB21_21 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB21_25
	b	LBB21_24
LBB21_24:                               ;   in Loop: Header=BB21_21 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_21
LBB21_25:
	b	LBB21_26
LBB21_26:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB21_42
	b	LBB21_27
LBB21_27:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #101
	b.eq	LBB21_29
	b	LBB21_28
LBB21_28:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #69
	b.ne	LBB21_42
	b	LBB21_29
LBB21_29:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hs	LBB21_33
	b	LBB21_30
LBB21_30:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #43
	b.eq	LBB21_32
	b	LBB21_31
LBB21_31:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w8, [x8, x9]
	subs	w8, w8, #45
	b.ne	LBB21_33
	b	LBB21_32
LBB21_32:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_33
LBB21_33:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB21_35
	b	LBB21_34
LBB21_34:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	tbnz	w0, #0, LBB21_36
	b	LBB21_35
LBB21_35:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB21_45
LBB21_36:
	b	LBB21_37
LBB21_37:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.hs	LBB21_39
	b	LBB21_38
LBB21_38:                               ;   in Loop: Header=BB21_37 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_digit
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB21_39
LBB21_39:                               ;   in Loop: Header=BB21_37 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB21_41
	b	LBB21_40
LBB21_40:                               ;   in Loop: Header=BB21_37 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9, #16]
	add	x8, x8, #1
	str	x8, [x9, #16]
	b	LBB21_37
LBB21_41:
	b	LBB21_42
LBB21_42:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	mov	w0, #1                          ; =0x1
	subs	x8, x8, #1, lsl #12             ; =4096
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.ls	LBB21_44
	b	LBB21_43
LBB21_43:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB21_44
LBB21_44:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_45
LBB21_45:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_token
_fb_token:                              ; @fb_token
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	ldr	x8, [x8, #24]
	subs	x8, x8, #2, lsl #12             ; =8192
	b.ne	LBB22_2
	b	LBB22_1
LBB22_1:
	ldr	x0, [sp]
	mov	w1, #2                          ; =0x2
	bl	_fb_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_3
LBB22_2:
	ldr	x9, [sp]
	ldr	x8, [x9, #24]
	add	x8, x8, #1
	str	x8, [x9, #24]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_3
LBB22_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_hex4
_fb_hex4:                               ; @fb_hex4
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	wzr, [x29, #-28]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	subs	x8, x8, #4
	b.hs	LBB23_2
	b	LBB23_1
LBB23_1:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB23_9
LBB23_2:
	str	xzr, [sp, #24]
	b	LBB23_3
LBB23_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	subs	x8, x8, #4
	b.hs	LBB23_8
	b	LBB23_4
LBB23_4:                                ;   in Loop: Header=BB23_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11, #16]
	add	x10, x9, #1
	str	x10, [x11, #16]
	ldrb	w0, [x8, x9]
	bl	_fb_hex
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	tbz	w8, #31, LBB23_6
	b	LBB23_5
LBB23_5:
	ldur	x0, [x29, #-16]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	bl	_fb_fail
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB23_9
LBB23_6:                                ;   in Loop: Header=BB23_3 Depth=1
	ldur	w9, [x29, #-28]
	ldr	w8, [sp, #20]
	orr	w8, w8, w9, lsl #4
	stur	w8, [x29, #-28]
	b	LBB23_7
LBB23_7:                                ;   in Loop: Header=BB23_3 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB23_3
LBB23_8:
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB23_9
LBB23_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_hex
_fb_hex:                                ; @fb_hex
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #11]
	ldrb	w8, [sp, #11]
	subs	w8, w8, #48
	b.lt	LBB24_3
	b	LBB24_1
LBB24_1:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #57
	b.gt	LBB24_3
	b	LBB24_2
LBB24_2:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #48
	str	w8, [sp, #12]
	b	LBB24_10
LBB24_3:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #97
	b.lt	LBB24_6
	b	LBB24_4
LBB24_4:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #102
	b.gt	LBB24_6
	b	LBB24_5
LBB24_5:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #97
	add	w8, w8, #10
	str	w8, [sp, #12]
	b	LBB24_10
LBB24_6:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #65
	b.lt	LBB24_9
	b	LBB24_7
LBB24_7:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #70
	b.gt	LBB24_9
	b	LBB24_8
LBB24_8:
	ldrb	w8, [sp, #11]
	subs	w8, w8, #65
	add	w8, w8, #10
	str	w8, [sp, #12]
	b	LBB24_10
LBB24_9:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]
	b	LBB24_10
LBB24_10:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_write
_fb_write:                              ; @fb_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB25_2
	b	LBB25_1
LBB25_1:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	x10, [x9, #8]
	mov	x9, #1048576                    ; =0x100000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB25_3
	b	LBB25_2
LBB25_2:
	ldur	x8, [x29, #-8]
	strb	wzr, [x8, #24]
	b	LBB25_8
LBB25_3:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	cbz	x8, LBB25_7
	b	LBB25_4
LBB25_4:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #16]
	ldur	x10, [x29, #-8]
	ldr	x10, [x10, #8]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB25_6
	b	LBB25_5
LBB25_5:
	ldur	x8, [x29, #-8]
	strb	wzr, [x8, #24]
	b	LBB25_8
LBB25_6:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9, #8]
	add	x0, x8, x9
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB25_7
LBB25_7:
	ldr	x10, [sp, #8]
	ldur	x9, [x29, #-8]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	b	LBB25_8
LBB25_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_named
_fb_named:                              ; @fb_named
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_fb_quote
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.40@PAGE
	add	x1, x1, l_.str.40@PAGEOFF
	bl	_fb_write
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #8]
	bl	_fb_quote
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fb_quote
_fb_quote:                              ; @fb_quote
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.41@PAGE
	add	x1, x1, l_.str.41@PAGEOFF
	bl	_fb_write
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]
	b	LBB27_1
LBB27_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	w8, LBB27_3
	b	LBB27_2
LBB27_2:                                ;   in Loop: Header=BB27_1 Depth=1
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #24]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB27_3
LBB27_3:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB27_13
	b	LBB27_4
LBB27_4:                                ;   in Loop: Header=BB27_1 Depth=1
	add	x8, sp, #16
	str	wzr, [sp, #16]
	stur	wzr, [x8, #3]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #34
	b.eq	LBB27_6
	b	LBB27_5
LBB27_5:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB27_7
	b	LBB27_6
LBB27_6:                                ;   in Loop: Header=BB27_1 Depth=1
	mov	w8, #92                         ; =0x5c
	strb	w8, [sp, #16]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	strb	w8, [sp, #17]
	b	LBB27_11
LBB27_7:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #32
	b.ge	LBB27_9
	b	LBB27_8
LBB27_8:                                ;   in Loop: Header=BB27_1 Depth=1
	adrp	x8, l_.str.42@PAGE
	add	x8, x8, l_.str.42@PAGEOFF
	ldr	w8, [x8]
	str	w8, [sp, #16]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	asr	w9, w8, #4
	adrp	x8, _fb_quote.hex@PAGE
	add	x8, x8, _fb_quote.hex@PAGEOFF
	add	x9, x8, w9, sxtw
	ldrb	w9, [x9]
	strb	w9, [sp, #20]
	ldr	x9, [sp, #24]
	ldrb	w9, [x9]
	and	w9, w9, #0xf
	add	x8, x8, w9, sxtw
	ldrb	w8, [x8]
	strb	w8, [sp, #21]
	b	LBB27_10
LBB27_9:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	strb	w8, [sp, #16]
	b	LBB27_10
LBB27_10:                               ;   in Loop: Header=BB27_1 Depth=1
	b	LBB27_11
LBB27_11:                               ;   in Loop: Header=BB27_1 Depth=1
	ldur	x0, [x29, #-8]
	add	x1, sp, #16
	bl	_fb_write
	b	LBB27_12
LBB27_12:                               ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB27_1
LBB27_13:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.41@PAGE
	add	x1, x1, l_.str.41@PAGEOFF
	bl	_fb_write
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @__const.nl_socket_binding_prepare.json
l___const.nl_socket_binding_prepare.json:
	.quad	0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	7

	.p2align	3, 0x0                          ; @__const.nl_socket_binding_prepare.source
l___const.nl_socket_binding_prepare.source:
	.quad	0
	.quad	0                               ; 0x0
	.quad	0                               ; 0x0
	.byte	1                               ; 0x1
	.space	7

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"true"

l_.str.1:                               ; @.str.1
	.asciz	"false"

l_.str.2:                               ; @.str.2
	.asciz	"null"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @fb_render_interface.directions
_fb_render_interface.directions:
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	l_.str.5
	.quad	l_.str.6

	.section	__TEXT,__cstring,cstring_literals
l_.str.3:                               ; @.str.3
	.asciz	"in"

l_.str.4:                               ; @.str.4
	.asciz	"out"

l_.str.5:                               ; @.str.5
	.asciz	"inout"

l_.str.6:                               ; @.str.6
	.asciz	"return"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @fb_render_interface.ownerships
_fb_render_interface.ownerships:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.9

	.section	__TEXT,__cstring,cstring_literals
l_.str.7:                               ; @.str.7
	.asciz	"borrow"

l_.str.8:                               ; @.str.8
	.asciz	"transfer"

l_.str.9:                               ; @.str.9
	.asciz	"copy"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @fb_render_interface.lifetimes
_fb_render_interface.lifetimes:
	.quad	l_.str.10
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13

	.section	__TEXT,__cstring,cstring_literals
l_.str.10:                              ; @.str.10
	.asciz	"call"

l_.str.11:                              ; @.str.11
	.asciz	"caller"

l_.str.12:                              ; @.str.12
	.asciz	"callee"

l_.str.13:                              ; @.str.13
	.asciz	"resource"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @fb_render_interface.mutability
_fb_render_interface.mutability:
	.quad	l_.str.14
	.quad	l_.str.15

	.section	__TEXT,__cstring,cstring_literals
l_.str.14:                              ; @.str.14
	.asciz	"immutable"

l_.str.15:                              ; @.str.15
	.asciz	"mutable"

l_.str.16:                              ; @.str.16
	.asciz	"{\"nsi_version\":0,\"interface\":"

l_.str.17:                              ; @.str.17
	.asciz	"},\"methods\":["

l_.str.18:                              ; @.str.18
	.asciz	","

l_.str.19:                              ; @.str.19
	.asciz	",\"idempotent\":false,\"params\":["

l_.str.20:                              ; @.str.20
	.asciz	",\"type\":"

l_.str.21:                              ; @.str.21
	.asciz	",\"direction\":"

l_.str.22:                              ; @.str.22
	.asciz	",\"ownership\":"

l_.str.23:                              ; @.str.23
	.asciz	",\"lifetime\":"

l_.str.24:                              ; @.str.24
	.asciz	",\"mutability\":"

l_.str.25:                              ; @.str.25
	.asciz	",\"optional\":false,\"streaming\":\"none\"}"

l_.str.26:                              ; @.str.26
	.asciz	"]}"

l_.str.27:                              ; @.str.27
	.asciz	"],\"types\":["

l_.str.28:                              ; @.str.28
	.asciz	",\"kind\":"

l_.str.29:                              ; @.str.29
	.asciz	"record"

l_.str.30:                              ; @.str.30
	.asciz	"variant"

l_.str.31:                              ; @.str.31
	.asciz	",\"fields\":["

l_.str.32:                              ; @.str.32
	.asciz	",\"cases\":["

l_.str.33:                              ; @.str.33
	.asciz	"}"

l_.str.34:                              ; @.str.34
	.asciz	"]"

l_.str.35:                              ; @.str.35
	.asciz	"],\"errors\":["

l_.str.36:                              ; @.str.36
	.asciz	",\"version\":"

l_.str.37:                              ; @.str.37
	.asciz	"}],\"capabilities\":["

l_.str.38:                              ; @.str.38
	.asciz	"]}\n"

l_.str.39:                              ; @.str.39
	.asciz	"{\"id\":"

l_.str.40:                              ; @.str.40
	.asciz	",\"name\":"

	.section	__TEXT,__const
_fb_quote.hex:                          ; @fb_quote.hex
	.asciz	"0123456789abcdef"

	.section	__TEXT,__cstring,cstring_literals
l_.str.41:                              ; @.str.41
	.asciz	"\""

l_.str.42:                              ; @.str.42
	.asciz	"\\u00"

l_.str.43:                              ; @.str.43
	.asciz	"# I declare catalog1; this declaration alone grants no host authority.\nservice "

l_.str.44:                              ; @.str.44
	.asciz	" catalog 1 from \"interface.nsi.json\"\n"

.subsections_via_symbols
