	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_asm_assemble                   ; -- Begin function asm_assemble
	.p2align	2
_asm_assemble:                          ; @asm_assemble
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_asm_assemble_impl
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function asm_assemble_impl
_asm_assemble_impl:                     ; @asm_assemble_impl
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #576
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #288]
	str	x1, [sp, #280]
	strb	w2, [sp, #279]
	ldr	x0, [sp, #280]
	mov	w1, #0                          ; =0x0
	mov	x2, #264                        ; =0x108
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	add	x0, sp, #128
	bl	_asm_state_init
	bl	_nvm_module_new
	str	x0, [sp, #128]
	ldr	x8, [sp, #128]
	cbz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #216]
	cbnz	x8, LBB1_3
	b	LBB1_2
LBB1_2:
	ldr	x9, [sp, #280]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #280]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.3@PAGE
	add	x4, x4, l_.str.3@PAGEOFF
	bl	___snprintf_chk
	add	x8, sp, #128
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	bl	_asm_state_cleanup
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_3:
	ldr	x1, [sp, #288]
	ldr	x2, [sp, #280]
	add	x0, sp, #128
	bl	_collect_function_symbols
	tbnz	w0, #0, LBB1_5
	b	LBB1_4
LBB1_4:
	add	x8, sp, #128
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_asm_state_cleanup
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_5:
	ldr	x8, [sp, #288]
	str	x8, [sp, #120]
	str	wzr, [sp, #268]
	b	LBB1_6
LBB1_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_8 Depth 2
                                        ;     Child Loop BB1_15 Depth 2
	ldr	x8, [sp, #120]
	ldrb	w8, [x8]
	cbz	w8, LBB1_29
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_6 Depth=1
	ldr	w8, [sp, #268]
	add	w8, w8, #1
	str	w8, [sp, #268]
	ldr	x8, [sp, #120]
	str	x8, [sp, #112]
	b	LBB1_8
LBB1_8:                                 ;   Parent Loop BB1_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #120]
	ldrsb	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #52]                   ; 4-byte Folded Spill
	cbz	w8, LBB1_10
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_8 Depth=2
	ldr	x8, [sp, #120]
	ldrsb	w8, [x8]
	subs	w8, w8, #10
	cset	w8, ne
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB1_10
LBB1_10:                                ;   in Loop: Header=BB1_8 Depth=2
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB1_12
	b	LBB1_11
LBB1_11:                                ;   in Loop: Header=BB1_8 Depth=2
	ldr	x8, [sp, #120]
	add	x8, x8, #1
	str	x8, [sp, #120]
	b	LBB1_8
LBB1_12:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x8, [sp, #120]
	ldr	x9, [sp, #112]
	subs	x8, x8, x9
	str	x8, [sp, #104]
	ldr	x8, [sp, #104]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB1_14
	b	LBB1_13
LBB1_13:
	ldr	x9, [sp, #280]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	add	x8, sp, #128
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #268]
	ldr	x9, [sp, #280]
	str	w8, [x9, #4]
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_asm_state_cleanup
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_14:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x0, [sp, #96]
	ldr	x1, [sp, #112]
	ldr	x2, [sp, #104]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #104]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x0, [sp, #96]
	bl	_strip_trailing_comment
	ldr	x0, [sp, #96]
	bl	_strlen
	str	x0, [sp, #88]
	b	LBB1_15
LBB1_15:                                ;   Parent Loop BB1_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #88]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #0
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b.ls	LBB1_20
	b	LBB1_16
LBB1_16:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #88]
	subs	x9, x9, #1
	ldrsb	w9, [x8, x9]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #32
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b.eq	LBB1_19
	b	LBB1_17
LBB1_17:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #88]
	subs	x9, x9, #1
	ldrsb	w9, [x8, x9]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #9
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b.eq	LBB1_19
	b	LBB1_18
LBB1_18:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #88]
	subs	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #13
	cset	w8, eq
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB1_20
LBB1_20:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB1_22
	b	LBB1_21
LBB1_21:                                ;   in Loop: Header=BB1_15 Depth=2
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #88]
	subs	x9, x9, #1
	str	x9, [sp, #88]
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB1_15
LBB1_22:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x1, [sp, #96]
	ldr	x2, [sp, #280]
	add	x0, sp, #128
	bl	_process_line
	strb	w0, [sp, #87]
	ldrb	w8, [sp, #232]
	tbz	w8, #0, LBB1_24
	b	LBB1_23
LBB1_23:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x9, [sp, #280]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #280]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.4@PAGE
	add	x4, x4, l_.str.4@PAGEOFF
	bl	___snprintf_chk
	strb	wzr, [sp, #87]
	b	LBB1_24
LBB1_24:                                ;   in Loop: Header=BB1_6 Depth=1
	ldrb	w8, [sp, #87]
	tbnz	w8, #0, LBB1_26
	b	LBB1_25
LBB1_25:
	add	x8, sp, #128
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #268]
	ldr	x9, [sp, #280]
	str	w8, [x9, #4]
	ldr	x0, [sp, #96]
	bl	_free
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_asm_state_cleanup
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_26:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x0, [sp, #96]
	bl	_free
	ldr	x8, [sp, #120]
	ldrsb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB1_28
	b	LBB1_27
LBB1_27:                                ;   in Loop: Header=BB1_6 Depth=1
	ldr	x8, [sp, #120]
	add	x8, x8, #1
	str	x8, [sp, #120]
	b	LBB1_28
LBB1_28:                                ;   in Loop: Header=BB1_6 Depth=1
	b	LBB1_6
LBB1_29:
	ldrb	w8, [sp, #200]
	tbz	w8, #0, LBB1_31
	b	LBB1_30
LBB1_30:
	ldr	x9, [sp, #280]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	add	x8, sp, #128
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #268]
	ldr	x9, [sp, #280]
	str	w8, [x9, #4]
	ldr	x8, [sp, #280]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #128]
	bl	_nvm_module_free
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_asm_state_cleanup
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_31:
	add	x0, sp, #128
	ldr	x8, [sp, #128]
	str	x8, [sp, #72]
	bl	_asm_state_cleanup
	ldrb	w8, [sp, #279]
	tbz	w8, #0, LBB1_35
	b	LBB1_32
LBB1_32:
	ldr	x0, [sp, #72]
	add	x8, sp, #311
	bl	_nvm_verify
	ldrb	w8, [sp, #311]
	tbnz	w8, #0, LBB1_34
	b	LBB1_33
LBB1_33:
	ldr	x9, [sp, #280]
	mov	w8, #7                          ; =0x7
	str	w8, [x9]
	ldr	x8, [sp, #280]
	add	x0, x8, #8
	add	x8, sp, #311
	add	x8, x8, #1
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.6@PAGE
	add	x4, x4, l_.str.6@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #72]
	bl	_nvm_module_free
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	b	LBB1_36
LBB1_34:
	b	LBB1_35
LBB1_35:
	ldr	x8, [sp, #72]
	str	x8, [sp, #296]
	b	LBB1_36
LBB1_36:
	ldr	x8, [sp, #296]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB1_38
	b	LBB1_37
LBB1_37:
	bl	___stack_chk_fail
LBB1_38:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #576
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_asm_assemble_unverified        ; -- Begin function asm_assemble_unverified
	.p2align	2
_asm_assemble_unverified:               ; @asm_assemble_unverified
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_asm_assemble_impl
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_asm_assemble_file              ; -- Begin function asm_assemble_file
	.p2align	2
_asm_assemble_file:                     ; @asm_assemble_file
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_fopen
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldur	x9, [x29, #-24]
	mov	w8, #9                          ; =0x9
	str	w8, [x9]
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB3_8
LBB3_2:
	ldur	x0, [x29, #-32]
	mov	x1, #0                          ; =0x0
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fseek
	ldur	x0, [x29, #-32]
	bl	_ftell
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #40]
	ldur	x0, [x29, #-32]
	mov	w2, #0                          ; =0x0
	bl	_fseek
	ldr	x8, [sp, #40]
	tbnz	x8, #63, LBB3_4
	b	LBB3_3
LBB3_3:
	ldr	x8, [sp, #40]
	subs	x8, x8, #2560, lsl #12          ; =10485760
	b.le	LBB3_5
	b	LBB3_4
LBB3_4:
	ldur	x9, [x29, #-24]
	mov	w8, #9                          ; =0x9
	str	w8, [x9]
	ldur	x8, [x29, #-24]
	add	x0, x8, #8
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.2@PAGE
	add	x4, x4, l_.str.2@PAGEOFF
	bl	___snprintf_chk
	ldur	x0, [x29, #-32]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB3_8
LBB3_5:
	ldr	x8, [sp, #40]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB3_7
	b	LBB3_6
LBB3_6:
	ldur	x9, [x29, #-24]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x0, [x29, #-32]
	bl	_fclose
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB3_8
LBB3_7:
	ldr	x0, [sp, #32]
	ldr	x2, [sp, #40]
	ldur	x3, [x29, #-32]
	mov	x1, #1                          ; =0x1
	bl	_fread
	str	x0, [sp, #24]
	ldur	x0, [x29, #-32]
	bl	_fclose
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x0, [sp, #32]
	ldur	x1, [x29, #-24]
	bl	_asm_assemble
	str	x0, [sp, #16]
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB3_8
LBB3_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function asm_state_init
_asm_state_init:                        ; @asm_state_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #144                        ; =0x90
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x9, [sp, #8]
	mov	w8, #4096                       ; =0x1000
	str	w8, [x9, #100]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #100]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #8]
	str	x0, [x8, #88]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function asm_state_cleanup
_asm_state_cleanup:                     ; @asm_state_cleanup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	b	LBB5_1
LBB5_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbz	x8, LBB5_3
	b	LBB5_2
LBB5_2:                                 ;   in Loop: Header=BB5_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #32]
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	b	LBB5_1
LBB5_3:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #88]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #56]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #128]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_function_symbols
_collect_function_symbols:              ; @collect_function_symbols
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #88]
	str	x1, [sp, #80]
	str	x2, [sp, #72]
	ldr	x8, [sp, #80]
	str	x8, [sp, #64]
	str	wzr, [sp, #60]
	str	wzr, [sp, #56]
	b	LBB6_1
LBB6_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_3 Depth 2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	cbz	w8, LBB6_21
	b	LBB6_2
LBB6_2:                                 ;   in Loop: Header=BB6_1 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	ldr	x8, [sp, #64]
	str	x8, [sp, #48]
	b	LBB6_3
LBB6_3:                                 ;   Parent Loop BB6_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	w8, LBB6_5
	b	LBB6_4
LBB6_4:                                 ;   in Loop: Header=BB6_3 Depth=2
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8]
	subs	w8, w8, #10
	cset	w8, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB6_5
LBB6_5:                                 ;   in Loop: Header=BB6_3 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB6_7
	b	LBB6_6
LBB6_6:                                 ;   in Loop: Header=BB6_3 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB6_3
LBB6_7:                                 ;   in Loop: Header=BB6_1 Depth=1
	ldr	x8, [sp, #64]
	ldr	x9, [sp, #48]
	subs	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB6_9
	b	LBB6_8
LBB6_8:
	ldr	x9, [sp, #72]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #72]
	str	w8, [x9, #4]
	ldr	x8, [sp, #72]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #16]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.3@PAGE
	add	x4, x4, l_.str.3@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB6_22
LBB6_9:                                 ;   in Loop: Header=BB6_1 Depth=1
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #40]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #40]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #32]
	add	x0, sp, #24
	str	x8, [sp, #24]
	bl	_skip_whitespace
	ldr	x0, [sp, #24]
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	mov	x2, #9                          ; =0x9
	bl	_strncmp
	cbnz	w0, LBB6_18
	b	LBB6_10
LBB6_10:                                ;   in Loop: Header=BB6_1 Depth=1
	ldr	x8, [sp, #24]
	ldrsb	w8, [x8, #9]
	subs	w8, w8, #32
	b.eq	LBB6_12
	b	LBB6_11
LBB6_11:                                ;   in Loop: Header=BB6_1 Depth=1
	ldr	x8, [sp, #24]
	ldrsb	w8, [x8, #9]
	subs	w8, w8, #9
	b.ne	LBB6_18
	b	LBB6_12
LBB6_12:                                ;   in Loop: Header=BB6_1 Depth=1
	add	x0, sp, #24
	ldr	x8, [sp, #24]
	add	x8, x8, #9
	str	x8, [sp, #24]
	add	x1, sp, #104
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB6_17
	b	LBB6_13
LBB6_13:                                ;   in Loop: Header=BB6_1 Depth=1
	ldr	x0, [sp, #88]
	ldr	w3, [sp, #56]
	add	w8, w3, #1
	str	w8, [sp, #56]
	ldr	x4, [sp, #72]
	mov	w1, #0                          ; =0x0
	add	x2, sp, #104
	bl	_add_symbol
	tbnz	w0, #0, LBB6_17
	b	LBB6_14
LBB6_14:
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #72]
	str	w8, [x9, #4]
	ldr	x8, [sp, #72]
	ldr	w8, [x8]
	subs	w8, w8, #11
	b.ne	LBB6_16
	b	LBB6_15
LBB6_15:
	ldr	x8, [sp, #72]
	add	x0, x8, #8
	mov	x9, sp
	add	x8, sp, #104
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.8@PAGE
	add	x4, x4, l_.str.8@PAGEOFF
	bl	___snprintf_chk
	b	LBB6_16
LBB6_16:
	ldr	x0, [sp, #32]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB6_22
LBB6_17:                                ;   in Loop: Header=BB6_1 Depth=1
	b	LBB6_18
LBB6_18:                                ;   in Loop: Header=BB6_1 Depth=1
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB6_20
	b	LBB6_19
LBB6_19:                                ;   in Loop: Header=BB6_1 Depth=1
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB6_20
LBB6_20:                                ;   in Loop: Header=BB6_1 Depth=1
	b	LBB6_1
LBB6_21:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #103]
	b	LBB6_22
LBB6_22:
	ldrb	w8, [sp, #103]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB6_24
	b	LBB6_23
LBB6_23:
	bl	___stack_chk_fail
LBB6_24:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function strip_trailing_comment
_strip_trailing_comment:                ; @strip_trailing_comment
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	strb	wzr, [sp, #23]
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]
	b	LBB7_1
LBB7_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	cbz	w8, LBB7_14
	b	LBB7_2
LBB7_2:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldrb	w8, [sp, #23]
	tbz	w8, #0, LBB7_6
	b	LBB7_3
LBB7_3:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB7_6
	b	LBB7_4
LBB7_4:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8, #1]
	cbz	w8, LBB7_6
	b	LBB7_5
LBB7_5:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB7_13
LBB7_6:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8]
	subs	w8, w8, #34
	b.ne	LBB7_8
	b	LBB7_7
LBB7_7:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldrb	w8, [sp, #23]
	mov	w9, #1                          ; =0x1
	eor	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #23]
	b	LBB7_13
LBB7_8:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldrb	w8, [sp, #23]
	tbnz	w8, #0, LBB7_12
	b	LBB7_9
LBB7_9:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8]
	subs	w8, w8, #59
	b.eq	LBB7_11
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8]
	subs	w8, w8, #35
	b.ne	LBB7_12
	b	LBB7_11
LBB7_11:
	ldr	x8, [sp, #8]
	strb	wzr, [x8]
	b	LBB7_14
LBB7_12:                                ;   in Loop: Header=BB7_1 Depth=1
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_1 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB7_1
LBB7_14:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function process_line
_process_line:                          ; @process_line
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #11232                      ; =0x2be0
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #3040
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	str	x8, [sp, #456]                  ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #1408]
	str	x1, [sp, #1400]
	str	x2, [sp, #1392]
	ldr	x8, [sp, #1400]
	add	x0, sp, #1384
	str	x8, [sp, #1384]
	bl	_skip_whitespace
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	cbz	w8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #59
	b.eq	LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #35
	b.ne	LBB8_4
	b	LBB8_3
LBB8_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_4:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	b.ne	LBB8_481
	b	LBB8_5
LBB8_5:
	add	x0, sp, #1384
	ldr	x8, [sp, #1384]
	add	x8, x8, #1
	str	x8, [sp, #1384]
	sub	x1, x29, #88
	mov	x2, #64                         ; =0x40
	bl	_parse_identifier
	tbnz	w0, #0, LBB8_7
	b	LBB8_6
LBB8_6:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #452]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #448]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.13@PAGE
	add	x4, x4, l_.str.13@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #448]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #452]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_7:
	sub	x0, x29, #88
	adrp	x1, l_.str.14@PAGE
	add	x1, x1, l_.str.14@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_32
	b	LBB8_8
LBB8_8:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_10
	b	LBB8_9
LBB8_9:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldr	x9, [sp, #1408]
	ldr	w10, [x9, #96]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB8_11
	b	LBB8_10
LBB8_10:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.15@PAGE
	add	x1, x1, l_.str.15@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_11:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #1376]
	str	wzr, [sp, #1372]
	ldr	x0, [sp, #1376]
	bl	_malloc
	str	x0, [sp, #1360]
	ldr	x8, [sp, #1360]
	cbnz	x8, LBB8_13
	b	LBB8_12
LBB8_12:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_13:
	ldr	x1, [sp, #1360]
	ldr	x2, [sp, #1376]
	add	x0, sp, #1384
	add	x3, sp, #1372
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #444]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_16
	b	LBB8_14
LBB8_14:
	ldr	w8, [sp, #1372]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #444]                  ; 4-byte Folded Spill
	cbz	w8, LBB8_16
	b	LBB8_15
LBB8_15:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	str	w0, [sp, #444]                  ; 4-byte Folded Spill
	b	LBB8_16
LBB8_16:
	ldr	w8, [sp, #444]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #1359]
	str	wzr, [sp, #1352]
	b	LBB8_17
LBB8_17:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #1359]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #440]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB8_19
	b	LBB8_18
LBB8_18:                                ;   in Loop: Header=BB8_17 Depth=1
	ldr	w8, [sp, #1352]
	ldr	w9, [sp, #1372]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #440]                  ; 4-byte Folded Spill
	b	LBB8_19
LBB8_19:                                ;   in Loop: Header=BB8_17 Depth=1
	ldr	w8, [sp, #440]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB8_25
	b	LBB8_20
LBB8_20:                                ;   in Loop: Header=BB8_17 Depth=1
	ldr	x8, [sp, #1360]
	ldr	w9, [sp, #1352]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #32
	b.lt	LBB8_22
	b	LBB8_21
LBB8_21:                                ;   in Loop: Header=BB8_17 Depth=1
	ldr	x8, [sp, #1360]
	ldr	w9, [sp, #1352]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #127
	b.ne	LBB8_23
	b	LBB8_22
LBB8_22:                                ;   in Loop: Header=BB8_17 Depth=1
	strb	wzr, [sp, #1359]
	b	LBB8_23
LBB8_23:                                ;   in Loop: Header=BB8_17 Depth=1
	b	LBB8_24
LBB8_24:                                ;   in Loop: Header=BB8_17 Depth=1
	ldr	w8, [sp, #1352]
	add	w8, w8, #1
	str	w8, [sp, #1352]
	b	LBB8_17
LBB8_25:
	ldrb	w8, [sp, #1359]
	tbnz	w8, #0, LBB8_27
	b	LBB8_26
LBB8_26:
	ldr	x0, [sp, #1360]
	bl	_free
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.17@PAGE
	add	x1, x1, l_.str.17@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_27:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #96]
	add	w10, w8, w9
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	sub	x0, x29, #152
	str	x0, [sp, #424]                  ; 8-byte Folded Spill
	mov	x3, #64                         ; =0x40
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.18@PAGE
	add	x4, x4, l_.str.18@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #424]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	str	x8, [sp, #432]                  ; 8-byte Folded Spill
	bl	_strlen
	ldr	x1, [sp, #424]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #432]                  ; 8-byte Folded Reload
	mov	x2, x8
	bl	_nvm_add_string
	str	w0, [sp, #1348]
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x1, [sp, #1360]
	ldr	w2, [sp, #1372]
	bl	_nvm_add_string
	str	w0, [sp, #1344]
	ldr	x0, [sp, #1360]
	bl	_free
	ldr	w8, [sp, #1348]
	adds	w8, w8, #1
	b.eq	LBB8_30
	b	LBB8_28
LBB8_28:
	ldr	w8, [sp, #1344]
	adds	w8, w8, #1
	b.eq	LBB8_30
	b	LBB8_29
LBB8_29:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #1348]
	ldr	w2, [sp, #1344]
	bl	_nvm_add_metadata
	tbnz	w0, #0, LBB8_31
	b	LBB8_30
LBB8_30:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_31:
	add	x1, sp, #1343
	strb	wzr, [sp, #1343]
	ldr	x0, [sp, #1408]
	mov	w2, #1                          ; =0x1
	str	w2, [sp, #420]                  ; 4-byte Folded Spill
	bl	_fn_emit
	ldr	w9, [sp, #420]                  ; 4-byte Folded Reload
	and	w8, w9, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_32:
	sub	x0, x29, #88
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_54
	b	LBB8_33
LBB8_33:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_35
	b	LBB8_34
LBB8_34:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.21@PAGE
	add	x1, x1, l_.str.21@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_35:
	movi.2d	v0, #0000000000000000
	stur	q0, [x29, #-192]
	stur	q0, [x29, #-176]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #1342]
	str	wzr, [sp, #1336]
	b	LBB8_36
LBB8_36:                                ; =>This Inner Loop Header: Depth=1
	ldr	w9, [sp, #1336]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #4
	str	w8, [sp, #416]                  ; 4-byte Folded Spill
	b.hs	LBB8_38
	b	LBB8_37
LBB8_37:                                ;   in Loop: Header=BB8_36 Depth=1
	ldrb	w8, [sp, #1342]
	str	w8, [sp, #416]                  ; 4-byte Folded Spill
	b	LBB8_38
LBB8_38:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	w8, [sp, #416]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB8_44
	b	LBB8_39
LBB8_39:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #1328]
	str	wzr, [sp, #1324]
	ldr	x0, [sp, #1328]
	bl	_malloc
	ldr	w8, [sp, #1336]
	mov	x9, x8
	sub	x8, x29, #192
	str	x0, [x8, x9, lsl #3]
	ldr	w9, [sp, #1336]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #412]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_42
	b	LBB8_40
LBB8_40:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	w8, [sp, #1336]
	mov	x9, x8
	sub	x8, x29, #192
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp, #1328]
	add	x0, sp, #1384
	add	x3, sp, #1324
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #412]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_42
	b	LBB8_41
LBB8_41:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	w8, [sp, #1336]
	mov	x9, x8
	sub	x8, x29, #192
	ldr	x0, [x8, x9, lsl #3]
	bl	_strlen
	ldr	w8, [sp, #1324]
                                        ; kill: def $x8 killed $w8
	subs	x8, x0, x8
	cset	w8, eq
	str	w8, [sp, #412]                  ; 4-byte Folded Spill
	b	LBB8_42
LBB8_42:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	w8, [sp, #412]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #1342]
	b	LBB8_43
LBB8_43:                                ;   in Loop: Header=BB8_36 Depth=1
	ldr	w8, [sp, #1336]
	add	w8, w8, #1
	str	w8, [sp, #1336]
	b	LBB8_36
LBB8_44:
	ldrb	w8, [sp, #1342]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #408]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB8_47
	b	LBB8_45
LBB8_45:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_47
	b	LBB8_46
LBB8_46:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	w1, [x8, #76]
	ldur	x2, [x29, #-192]
	ldur	x3, [x29, #-184]
	ldur	x4, [x29, #-176]
	ldur	x5, [x29, #-168]
	bl	_nvm_add_generic_binding
	str	w0, [sp, #408]                  ; 4-byte Folded Spill
	b	LBB8_47
LBB8_47:
	ldr	w8, [sp, #408]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #1342]
	str	wzr, [sp, #1320]
	b	LBB8_48
LBB8_48:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #1320]
	subs	w8, w8, #4
	b.hs	LBB8_51
	b	LBB8_49
LBB8_49:                                ;   in Loop: Header=BB8_48 Depth=1
	ldr	w8, [sp, #1320]
	mov	x9, x8
	sub	x8, x29, #192
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB8_50
LBB8_50:                                ;   in Loop: Header=BB8_48 Depth=1
	ldr	w8, [sp, #1320]
	add	w8, w8, #1
	str	w8, [sp, #1320]
	b	LBB8_48
LBB8_51:
	ldrb	w8, [sp, #1342]
	tbnz	w8, #0, LBB8_53
	b	LBB8_52
LBB8_52:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.22@PAGE
	add	x1, x1, l_.str.22@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_53:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_54:
	sub	x0, x29, #88
	adrp	x1, l_.str.23@PAGE
	add	x1, x1, l_.str.23@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_63
	b	LBB8_55
LBB8_55:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_59
	b	LBB8_56
LBB8_56:
	add	x0, sp, #1384
	add	x1, sp, #1318
	bl	_parse_uint16
	tbz	w0, #0, LBB8_59
	b	LBB8_57
LBB8_57:
	ldrh	w8, [sp, #1318]
	subs	w8, w8, #1
	b.gt	LBB8_59
	b	LBB8_58
LBB8_58:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_60
	b	LBB8_59
LBB8_59:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.24@PAGE
	add	x1, x1, l_.str.24@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_60:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	w1, [x8, #76]
	ldrh	w8, [sp, #1318]
	subs	w8, w8, #0
	cset	w2, ne
	bl	_nvm_add_function_purity
	tbnz	w0, #0, LBB8_62
	b	LBB8_61
LBB8_61:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.25@PAGE
	add	x1, x1, l_.str.25@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_62:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_63:
	sub	x0, x29, #88
	adrp	x1, l_.str.26@PAGE
	add	x1, x1, l_.str.26@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_78
	b	LBB8_64
LBB8_64:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_69
	b	LBB8_65
LBB8_65:
	add	x0, sp, #1384
	add	x1, sp, #1312
	bl	_parse_uint32
	tbz	w0, #0, LBB8_69
	b	LBB8_66
LBB8_66:
	add	x0, sp, #1384
	add	x1, sp, #1308
	bl	_parse_uint32
	tbz	w0, #0, LBB8_69
	b	LBB8_67
LBB8_67:
	add	x0, sp, #1384
	add	x1, sp, #1304
	bl	_parse_uint32
	tbz	w0, #0, LBB8_69
	b	LBB8_68
LBB8_68:
	add	x0, sp, #1384
	add	x1, sp, #1300
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_70
	b	LBB8_69
LBB8_69:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.27@PAGE
	add	x1, x1, l_.str.27@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_70:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #1288]
	ldr	x0, [sp, #1288]
	bl	_malloc
	str	x0, [sp, #1280]
	str	wzr, [sp, #1276]
	ldr	x8, [sp, #1280]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #404]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_75
	b	LBB8_71
LBB8_71:
	ldr	x1, [sp, #1280]
	ldr	x2, [sp, #1288]
	add	x0, sp, #1384
	add	x3, sp, #1276
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_75
	b	LBB8_72
LBB8_72:
	ldr	x0, [sp, #1280]
	bl	_strlen
	mov	x8, x0
	ldr	w9, [sp, #1276]
                                        ; kill: def $x9 killed $w9
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #404]                  ; 4-byte Folded Spill
	b.ne	LBB8_75
	b	LBB8_73
LBB8_73:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_75
	b	LBB8_74
LBB8_74:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	w1, [x8, #76]
	ldr	w2, [sp, #1312]
	ldr	w3, [sp, #1308]
	ldr	w4, [sp, #1304]
	ldr	w5, [sp, #1300]
	ldr	x6, [sp, #1280]
	bl	_nvm_add_match_coverage
	str	w0, [sp, #404]                  ; 4-byte Folded Spill
	b	LBB8_75
LBB8_75:
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #1275]
	ldr	x0, [sp, #1280]
	bl	_free
	ldrb	w8, [sp, #1275]
	tbnz	w8, #0, LBB8_77
	b	LBB8_76
LBB8_76:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.28@PAGE
	add	x1, x1, l_.str.28@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_77:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_78:
	sub	x0, x29, #88
	adrp	x1, l_.str.29@PAGE
	add	x1, x1, l_.str.29@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_87
	b	LBB8_79
LBB8_79:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_83
	b	LBB8_80
LBB8_80:
	add	x0, sp, #1384
	add	x1, sp, #1272
	bl	_parse_uint16
	tbz	w0, #0, LBB8_83
	b	LBB8_81
LBB8_81:
	ldrh	w8, [sp, #1272]
	subs	w8, w8, #63
	b.gt	LBB8_83
	b	LBB8_82
LBB8_82:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_84
	b	LBB8_83
LBB8_83:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.30@PAGE
	add	x1, x1, l_.str.30@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_84:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	w1, [x8, #76]
	ldrh	w2, [sp, #1272]
	bl	_nvm_add_function_effects
	tbnz	w0, #0, LBB8_86
	b	LBB8_85
LBB8_85:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.31@PAGE
	add	x1, x1, l_.str.31@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_86:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_87:
	sub	x0, x29, #88
	adrp	x1, l_.str.32@PAGE
	add	x1, x1, l_.str.32@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_109
	b	LBB8_88
LBB8_88:
	add	x0, sp, #1200
	mov	x2, #72                         ; =0x48
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_97
	b	LBB8_89
LBB8_89:
	add	x0, sp, #1384
	add	x1, sp, #1200
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_90
LBB8_90:
	add	x8, sp, #1200
	add	x1, x8, #4
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_91
LBB8_91:
	add	x8, sp, #1200
	add	x1, x8, #8
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_92
LBB8_92:
	add	x8, sp, #1200
	add	x1, x8, #12
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_93
LBB8_93:
	add	x8, sp, #1200
	add	x1, x8, #16
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_94
LBB8_94:
	add	x8, sp, #1200
	add	x1, x8, #20
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_95
LBB8_95:
	add	x0, sp, #1384
	add	x1, sp, #1196
	bl	_parse_uint32
	tbz	w0, #0, LBB8_97
	b	LBB8_96
LBB8_96:
	add	x0, sp, #1384
	add	x1, sp, #1192
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_98
	b	LBB8_97
LBB8_97:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_98:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #1184]
	ldr	x0, [sp, #1184]
	bl	_malloc
	str	x0, [sp, #1176]
	ldr	x0, [sp, #1184]
	bl	_malloc
	str	x0, [sp, #1168]
	ldr	x0, [sp, #1184]
	bl	_malloc
	str	x0, [sp, #1160]
	ldr	w8, [sp, #1196]
	str	w8, [sp, #1224]
	ldr	w8, [sp, #1192]
	str	w8, [sp, #1228]
	ldr	x8, [sp, #1176]
	str	x8, [sp, #1232]
	ldr	x8, [sp, #1168]
	str	x8, [sp, #1240]
	ldr	x8, [sp, #1160]
	str	x8, [sp, #1248]
	ldr	x8, [sp, #1176]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #400]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_106
	b	LBB8_99
LBB8_99:
	ldr	x8, [sp, #1168]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #400]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_106
	b	LBB8_100
LBB8_100:
	ldr	x8, [sp, #1160]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #400]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_106
	b	LBB8_101
LBB8_101:
	ldr	x1, [sp, #1176]
	ldr	x2, [sp, #1184]
	add	x8, sp, #1200
	add	x3, x8, #56
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_106
	b	LBB8_102
LBB8_102:
	ldr	x1, [sp, #1168]
	ldr	x2, [sp, #1184]
	add	x8, sp, #1200
	add	x3, x8, #60
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_106
	b	LBB8_103
LBB8_103:
	ldr	x1, [sp, #1160]
	ldr	x2, [sp, #1184]
	add	x8, sp, #1200
	add	x3, x8, #64
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_106
	b	LBB8_104
LBB8_104:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_106
	b	LBB8_105
LBB8_105:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #1200
	bl	_nvm_add_borrow_place
	str	w0, [sp, #400]                  ; 4-byte Folded Spill
	b	LBB8_106
LBB8_106:
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #1159]
	ldr	x0, [sp, #1176]
	bl	_free
	ldr	x0, [sp, #1168]
	bl	_free
	ldr	x0, [sp, #1160]
	bl	_free
	ldrb	w8, [sp, #1159]
	tbnz	w8, #0, LBB8_108
	b	LBB8_107
LBB8_107:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.34@PAGE
	add	x1, x1, l_.str.34@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_108:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_109:
	sub	x0, x29, #88
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_128
	b	LBB8_110
LBB8_110:
	add	x0, sp, #1088
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_116
	b	LBB8_111
LBB8_111:
	add	x0, sp, #1384
	add	x1, sp, #1088
	bl	_parse_uint32
	tbz	w0, #0, LBB8_116
	b	LBB8_112
LBB8_112:
	add	x8, sp, #1088
	add	x1, x8, #4
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_116
	b	LBB8_113
LBB8_113:
	add	x8, sp, #1088
	add	x1, x8, #8
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_116
	b	LBB8_114
LBB8_114:
	add	x0, sp, #1384
	add	x1, sp, #1084
	bl	_parse_uint32
	tbz	w0, #0, LBB8_116
	b	LBB8_115
LBB8_115:
	add	x0, sp, #1384
	add	x1, sp, #1080
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_117
	b	LBB8_116
LBB8_116:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.36@PAGE
	add	x1, x1, l_.str.36@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_117:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #1072]
	ldr	x0, [sp, #1072]
	bl	_malloc
	str	x0, [sp, #1064]
	ldr	x0, [sp, #1072]
	bl	_malloc
	str	x0, [sp, #1056]
	ldr	x0, [sp, #1072]
	bl	_malloc
	str	x0, [sp, #1048]
	ldr	w8, [sp, #1084]
	str	w8, [sp, #1100]
	ldr	w8, [sp, #1080]
	str	w8, [sp, #1104]
	ldr	x8, [sp, #1064]
	str	x8, [sp, #1112]
	ldr	x8, [sp, #1056]
	str	x8, [sp, #1120]
	ldr	x8, [sp, #1048]
	str	x8, [sp, #1128]
	ldr	x8, [sp, #1064]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #396]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_125
	b	LBB8_118
LBB8_118:
	ldr	x8, [sp, #1056]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #396]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_125
	b	LBB8_119
LBB8_119:
	ldr	x8, [sp, #1048]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #396]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_125
	b	LBB8_120
LBB8_120:
	ldr	x1, [sp, #1064]
	ldr	x2, [sp, #1072]
	add	x8, sp, #1088
	add	x3, x8, #48
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_125
	b	LBB8_121
LBB8_121:
	ldr	x1, [sp, #1056]
	ldr	x2, [sp, #1072]
	add	x8, sp, #1088
	add	x3, x8, #52
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_125
	b	LBB8_122
LBB8_122:
	ldr	x1, [sp, #1048]
	ldr	x2, [sp, #1072]
	add	x8, sp, #1088
	add	x3, x8, #56
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_125
	b	LBB8_123
LBB8_123:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_125
	b	LBB8_124
LBB8_124:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #1088
	bl	_nvm_add_field_read
	str	w0, [sp, #396]                  ; 4-byte Folded Spill
	b	LBB8_125
LBB8_125:
	ldr	w8, [sp, #396]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #1047]
	ldr	x0, [sp, #1064]
	bl	_free
	ldr	x0, [sp, #1056]
	bl	_free
	ldr	x0, [sp, #1048]
	bl	_free
	ldrb	w8, [sp, #1047]
	tbnz	w8, #0, LBB8_127
	b	LBB8_126
LBB8_126:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.37@PAGE
	add	x1, x1, l_.str.37@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_127:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_128:
	sub	x0, x29, #88
	adrp	x1, l_.str.38@PAGE
	add	x1, x1, l_.str.38@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_147
	b	LBB8_129
LBB8_129:
	add	x0, sp, #976
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_135
	b	LBB8_130
LBB8_130:
	add	x0, sp, #1384
	add	x1, sp, #976
	bl	_parse_uint32
	tbz	w0, #0, LBB8_135
	b	LBB8_131
LBB8_131:
	add	x8, sp, #976
	add	x1, x8, #4
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_135
	b	LBB8_132
LBB8_132:
	add	x8, sp, #976
	add	x1, x8, #8
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_135
	b	LBB8_133
LBB8_133:
	add	x0, sp, #1384
	add	x1, sp, #972
	bl	_parse_uint32
	tbz	w0, #0, LBB8_135
	b	LBB8_134
LBB8_134:
	add	x0, sp, #1384
	add	x1, sp, #968
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_136
	b	LBB8_135
LBB8_135:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_136:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #960]
	ldr	x0, [sp, #960]
	bl	_malloc
	str	x0, [sp, #952]
	ldr	x0, [sp, #960]
	bl	_malloc
	str	x0, [sp, #944]
	ldr	x0, [sp, #960]
	bl	_malloc
	str	x0, [sp, #936]
	ldr	w8, [sp, #972]
	str	w8, [sp, #988]
	ldr	w8, [sp, #968]
	str	w8, [sp, #992]
	ldr	x8, [sp, #952]
	str	x8, [sp, #1000]
	ldr	x8, [sp, #944]
	str	x8, [sp, #1008]
	ldr	x8, [sp, #936]
	str	x8, [sp, #1016]
	ldr	x8, [sp, #952]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #392]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_144
	b	LBB8_137
LBB8_137:
	ldr	x8, [sp, #944]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #392]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_144
	b	LBB8_138
LBB8_138:
	ldr	x8, [sp, #936]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #392]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_144
	b	LBB8_139
LBB8_139:
	ldr	x1, [sp, #952]
	ldr	x2, [sp, #960]
	add	x8, sp, #976
	add	x3, x8, #48
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_144
	b	LBB8_140
LBB8_140:
	ldr	x1, [sp, #944]
	ldr	x2, [sp, #960]
	add	x8, sp, #976
	add	x3, x8, #52
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_144
	b	LBB8_141
LBB8_141:
	ldr	x1, [sp, #936]
	ldr	x2, [sp, #960]
	add	x8, sp, #976
	add	x3, x8, #56
	add	x0, sp, #1384
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_144
	b	LBB8_142
LBB8_142:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_144
	b	LBB8_143
LBB8_143:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #976
	bl	_nvm_add_field_write
	str	w0, [sp, #392]                  ; 4-byte Folded Spill
	b	LBB8_144
LBB8_144:
	ldr	w8, [sp, #392]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #935]
	ldr	x0, [sp, #952]
	bl	_free
	ldr	x0, [sp, #944]
	bl	_free
	ldr	x0, [sp, #936]
	bl	_free
	ldrb	w8, [sp, #935]
	tbnz	w8, #0, LBB8_146
	b	LBB8_145
LBB8_145:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.40@PAGE
	add	x1, x1, l_.str.40@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_146:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_147:
	sub	x0, x29, #88
	adrp	x1, l_.str.41@PAGE
	add	x1, x1, l_.str.41@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_166
	b	LBB8_148
LBB8_148:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_154
	b	LBB8_149
LBB8_149:
	add	x0, sp, #1384
	add	x1, sp, #928
	bl	_parse_uint32
	tbz	w0, #0, LBB8_154
	b	LBB8_150
LBB8_150:
	add	x0, sp, #1384
	add	x1, sp, #924
	bl	_parse_uint32
	tbz	w0, #0, LBB8_154
	b	LBB8_151
LBB8_151:
	add	x0, sp, #1384
	add	x1, sp, #920
	bl	_parse_uint32
	tbz	w0, #0, LBB8_154
	b	LBB8_152
LBB8_152:
	add	x0, sp, #1384
	add	x1, sp, #916
	bl	_parse_uint32
	tbz	w0, #0, LBB8_154
	b	LBB8_153
LBB8_153:
	add	x0, sp, #1384
	add	x1, sp, #912
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_155
	b	LBB8_154
LBB8_154:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.42@PAGE
	add	x1, x1, l_.str.42@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_155:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #904]
	ldr	x0, [sp, #904]
	bl	_malloc
	str	x0, [sp, #896]
	ldr	x0, [sp, #904]
	bl	_malloc
	str	x0, [sp, #888]
	str	wzr, [sp, #884]
	str	wzr, [sp, #880]
	ldr	x8, [sp, #896]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #388]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_163
	b	LBB8_156
LBB8_156:
	ldr	x8, [sp, #888]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #388]                  ; 4-byte Folded Spill
	cbz	x8, LBB8_163
	b	LBB8_157
LBB8_157:
	ldr	x1, [sp, #896]
	ldr	x2, [sp, #904]
	add	x0, sp, #1384
	add	x3, sp, #884
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_163
	b	LBB8_158
LBB8_158:
	ldr	x0, [sp, #896]
	bl	_strlen
	ldr	w8, [sp, #884]
	mov	x9, x8
	mov	w8, #0                          ; =0x0
	subs	x9, x0, x9
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	b.ne	LBB8_163
	b	LBB8_159
LBB8_159:
	ldr	x1, [sp, #888]
	ldr	x2, [sp, #904]
	add	x0, sp, #1384
	add	x3, sp, #880
	bl	_parse_quoted_string
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_163
	b	LBB8_160
LBB8_160:
	ldr	x0, [sp, #888]
	bl	_strlen
	mov	x8, x0
	ldr	w9, [sp, #880]
                                        ; kill: def $x9 killed $w9
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #388]                  ; 4-byte Folded Spill
	b.ne	LBB8_163
	b	LBB8_161
LBB8_161:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_163
	b	LBB8_162
LBB8_162:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #928]
	ldr	w2, [sp, #924]
	ldr	w3, [sp, #920]
	ldr	w4, [sp, #916]
	ldr	w5, [sp, #912]
	ldr	x6, [sp, #896]
	ldr	x7, [sp, #888]
	bl	_nvm_add_affine_use
	str	w0, [sp, #388]                  ; 4-byte Folded Spill
	b	LBB8_163
LBB8_163:
	ldr	w8, [sp, #388]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #879]
	ldr	x0, [sp, #896]
	bl	_free
	ldr	x0, [sp, #888]
	bl	_free
	ldrb	w8, [sp, #879]
	tbnz	w8, #0, LBB8_165
	b	LBB8_164
LBB8_164:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.43@PAGE
	add	x1, x1, l_.str.43@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_165:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_166:
	sub	x0, x29, #88
	adrp	x1, l_.str.44@PAGE
	add	x1, x1, l_.str.44@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_175
	b	LBB8_167
LBB8_167:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_173
	b	LBB8_168
LBB8_168:
	add	x0, sp, #1384
	add	x1, sp, #872
	bl	_parse_uint32
	tbz	w0, #0, LBB8_173
	b	LBB8_169
LBB8_169:
	add	x0, sp, #1384
	add	x1, sp, #870
	bl	_parse_uint16
	tbz	w0, #0, LBB8_173
	b	LBB8_170
LBB8_170:
	ldrh	w8, [sp, #870]
	subs	w8, w8, #1
	b.gt	LBB8_173
	b	LBB8_171
LBB8_171:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbz	w0, #0, LBB8_173
	b	LBB8_172
LBB8_172:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #872]
	ldrh	w2, [sp, #870]
	bl	_nvm_add_function_affine
	tbnz	w0, #0, LBB8_174
	b	LBB8_173
LBB8_173:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.45@PAGE
	add	x1, x1, l_.str.45@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_174:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_175:
	sub	x0, x29, #88
	adrp	x1, l_.str.46@PAGE
	add	x1, x1, l_.str.46@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_184
	b	LBB8_176
LBB8_176:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_180
	b	LBB8_177
LBB8_177:
	add	x0, sp, #1384
	add	x1, sp, #868
	bl	_parse_uint16
	tbz	w0, #0, LBB8_180
	b	LBB8_178
LBB8_178:
	ldrh	w8, [sp, #868]
	subs	w8, w8, #1
	b.gt	LBB8_180
	b	LBB8_179
LBB8_179:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_181
	b	LBB8_180
LBB8_180:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.47@PAGE
	add	x1, x1, l_.str.47@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_181:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	w1, [x8, #76]
	ldrh	w2, [sp, #868]
	bl	_nvm_add_function_affine
	tbnz	w0, #0, LBB8_183
	b	LBB8_182
LBB8_182:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.48@PAGE
	add	x1, x1, l_.str.48@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_183:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_184:
	sub	x0, x29, #88
	adrp	x1, l_.str.49@PAGE
	add	x1, x1, l_.str.49@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_187
	b	LBB8_185
LBB8_185:
	sub	x0, x29, #88
	adrp	x1, l_.str.50@PAGE
	add	x1, x1, l_.str.50@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_187
	b	LBB8_186
LBB8_186:
	sub	x0, x29, #88
	adrp	x1, l_.str.51@PAGE
	add	x1, x1, l_.str.51@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_224
	b	LBB8_187
LBB8_187:
	sub	x0, x29, #88
	adrp	x1, l_.str.51@PAGE
	add	x1, x1, l_.str.51@PAGEOFF
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	strb	w8, [sp, #867]
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_193
	b	LBB8_188
LBB8_188:
	add	x0, sp, #1384
	add	x1, sp, #864
	bl	_parse_uint16
	tbz	w0, #0, LBB8_193
	b	LBB8_189
LBB8_189:
	ldrh	w8, [sp, #864]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #867]
	tbz	w8, #0, LBB8_191
	b	LBB8_190
LBB8_190:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #18]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	b	LBB8_192
LBB8_191:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	b	LBB8_192
LBB8_192:
	ldr	w8, [sp, #384]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #380]                  ; 4-byte Folded Reload
	subs	w8, w8, w9
	b.lt	LBB8_194
	b	LBB8_193
LBB8_193:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.52@PAGE
	add	x1, x1, l_.str.52@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_194:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #856]
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #8]
	str	x8, [sp, #848]
	b	LBB8_195
LBB8_195:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #848]
	cbz	x8, LBB8_202
	b	LBB8_196
LBB8_196:                               ;   in Loop: Header=BB8_195 Depth=1
	ldr	x8, [sp, #848]
	ldrb	w8, [x8, #25]
	and	w8, w8, #0x1
	ldrb	w9, [sp, #867]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB8_200
	b	LBB8_197
LBB8_197:                               ;   in Loop: Header=BB8_195 Depth=1
	ldr	x8, [sp, #848]
	ldrh	w8, [x8]
	ldrh	w9, [sp, #864]
	subs	w8, w8, w9
	b.ne	LBB8_200
	b	LBB8_198
LBB8_198:                               ;   in Loop: Header=BB8_195 Depth=1
	ldr	x8, [sp, #848]
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB8_200
	b	LBB8_199
LBB8_199:                               ;   in Loop: Header=BB8_195 Depth=1
	ldr	x8, [sp, #848]
	str	x8, [sp, #856]
	b	LBB8_200
LBB8_200:                               ;   in Loop: Header=BB8_195 Depth=1
	b	LBB8_201
LBB8_201:                               ;   in Loop: Header=BB8_195 Depth=1
	ldr	x8, [sp, #848]
	ldr	x8, [x8, #32]
	str	x8, [sp, #848]
	b	LBB8_195
LBB8_202:
	sub	x0, x29, #88
	adrp	x1, l_.str.50@PAGE
	add	x1, x1, l_.str.50@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_207
	b	LBB8_203
LBB8_203:
	ldr	x8, [sp, #856]
	cbz	x8, LBB8_205
	b	LBB8_204
LBB8_204:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_206
	b	LBB8_205
LBB8_205:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.53@PAGE
	add	x1, x1, l_.str.53@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_206:
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #96]
	ldr	x9, [sp, #856]
	str	w8, [x9, #8]
	ldr	x9, [sp, #856]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_207:
	ldr	x8, [sp, #856]
	cbz	x8, LBB8_209
	b	LBB8_208
LBB8_208:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.54@PAGE
	add	x1, x1, l_.str.54@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_209:
	ldr	x0, [sp, #1384]
	bl	_strlen
	add	x8, x0, #1
	str	x8, [sp, #840]
	str	wzr, [sp, #836]
	ldr	x0, [sp, #840]
	bl	_malloc
	str	x0, [sp, #824]
	ldr	x8, [sp, #824]
	cbnz	x8, LBB8_211
	b	LBB8_210
LBB8_210:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.55@PAGE
	add	x1, x1, l_.str.55@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_211:
	ldr	x1, [sp, #824]
	ldr	x2, [sp, #840]
	add	x0, sp, #1384
	add	x3, sp, #836
	bl	_parse_quoted_string
	tbz	w0, #0, LBB8_214
	b	LBB8_212
LBB8_212:
	ldr	w8, [sp, #836]
	cbz	w8, LBB8_214
	b	LBB8_213
LBB8_213:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_215
	b	LBB8_214
LBB8_214:
	ldr	x0, [sp, #824]
	bl	_free
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.56@PAGE
	add	x1, x1, l_.str.56@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_215:
	mov	x0, #1                          ; =0x1
	mov	x1, #40                         ; =0x28
	bl	_calloc
	str	x0, [sp, #816]
	ldr	x8, [sp, #816]
	cbnz	x8, LBB8_217
	b	LBB8_216
LBB8_216:
	ldr	x0, [sp, #824]
	bl	_free
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.55@PAGE
	add	x1, x1, l_.str.55@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_217:
	ldrb	w8, [sp, #867]
	ldr	x9, [sp, #816]
	mov	w10, #1                         ; =0x1
	and	w8, w8, w10
	strb	w8, [x9, #25]
	ldrh	w8, [sp, #864]
	ldr	x9, [sp, #816]
	strh	w8, [x9]
	ldrb	w8, [sp, #867]
	tbz	w8, #0, LBB8_219
	b	LBB8_218
LBB8_218:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	b	LBB8_220
LBB8_219:
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #96]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	b	LBB8_220
LBB8_220:
	ldr	w8, [sp, #376]                  ; 4-byte Folded Reload
	ldr	x9, [sp, #816]
	str	w8, [x9, #4]
	ldr	x8, [sp, #824]
	ldr	x9, [sp, #816]
	str	x8, [x9, #16]
	ldr	w8, [sp, #836]
	ldr	x9, [sp, #816]
	str	w8, [x9, #12]
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #16]
	cbz	x8, LBB8_222
	b	LBB8_221
LBB8_221:
	ldr	x8, [sp, #816]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9, #16]
	str	x8, [x9, #32]
	b	LBB8_223
LBB8_222:
	ldr	x8, [sp, #816]
	ldr	x9, [sp, #1408]
	str	x8, [x9, #8]
	b	LBB8_223
LBB8_223:
	ldr	x8, [sp, #816]
	ldr	x9, [sp, #1408]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_224:
	sub	x0, x29, #88
	adrp	x1, l_.str.57@PAGE
	add	x1, x1, l_.str.57@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_234
	b	LBB8_225
LBB8_225:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_230
	b	LBB8_226
LBB8_226:
	add	x0, sp, #1384
	add	x1, sp, #812
	bl	_parse_uint32
	tbz	w0, #0, LBB8_230
	b	LBB8_227
LBB8_227:
	add	x0, sp, #1384
	add	x1, sp, #808
	bl	_parse_uint32
	tbz	w0, #0, LBB8_230
	b	LBB8_228
LBB8_228:
	add	x0, sp, #1384
	add	x1, sp, #804
	bl	_parse_uint32
	tbz	w0, #0, LBB8_230
	b	LBB8_229
LBB8_229:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_231
	b	LBB8_230
LBB8_230:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #368]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.58@PAGE
	add	x4, x4, l_.str.58@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #368]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #372]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_231:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #812]
	ldr	w2, [sp, #808]
	ldr	w3, [sp, #804]
	bl	_nvm_add_debug_entry
	tbnz	w0, #0, LBB8_233
	b	LBB8_232
LBB8_232:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #364]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.59@PAGE
	add	x4, x4, l_.str.59@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_233:
	ldr	x8, [sp, #1408]
	ldr	x9, [x8]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x4
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_234:
	sub	x0, x29, #88
	adrp	x1, l_.str.60@PAGE
	add	x1, x1, l_.str.60@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_245
	b	LBB8_235
LBB8_235:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_241
	b	LBB8_236
LBB8_236:
	add	x0, sp, #1384
	add	x1, sp, #800
	bl	_parse_uint32
	tbz	w0, #0, LBB8_241
	b	LBB8_237
LBB8_237:
	add	x0, sp, #1384
	add	x1, sp, #796
	bl	_parse_uint32
	tbz	w0, #0, LBB8_241
	b	LBB8_238
LBB8_238:
	ldr	w8, [sp, #800]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB8_241
	b	LBB8_239
LBB8_239:
	ldr	w8, [sp, #796]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB8_241
	b	LBB8_240
LBB8_240:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_242
	b	LBB8_241
LBB8_241:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #360]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.61@PAGE
	add	x4, x4, l_.str.61@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_242:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #800]
	ldr	w2, [sp, #796]
	bl	_nvm_add_metadata
	tbnz	w0, #0, LBB8_244
	b	LBB8_243
LBB8_243:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #356]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.62@PAGE
	add	x4, x4, l_.str.62@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #356]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_244:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_245:
	sub	x0, x29, #88
	adrp	x1, l_.str.63@PAGE
	add	x1, x1, l_.str.63@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_248
	b	LBB8_246
LBB8_246:
	sub	x0, x29, #88
	adrp	x1, l_.str.64@PAGE
	add	x1, x1, l_.str.64@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_248
	b	LBB8_247
LBB8_247:
	sub	x0, x29, #88
	adrp	x1, l_.str.65@PAGE
	add	x1, x1, l_.str.65@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_249
	b	LBB8_248
LBB8_248:
	ldr	x0, [sp, #1408]
	ldr	x2, [sp, #1384]
	ldr	x3, [sp, #1392]
	sub	x1, x29, #88
	bl	_par_directive
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_249:
	sub	x0, x29, #88
	adrp	x1, l_.str.66@PAGE
	add	x1, x1, l_.str.66@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_252
	b	LBB8_250
LBB8_250:
	sub	x0, x29, #88
	adrp	x1, l_.str.67@PAGE
	add	x1, x1, l_.str.67@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_252
	b	LBB8_251
LBB8_251:
	sub	x0, x29, #88
	adrp	x1, l_.str.68@PAGE
	add	x1, x1, l_.str.68@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_253
	b	LBB8_252
LBB8_252:
	ldr	x0, [sp, #1408]
	ldr	x2, [sp, #1384]
	ldr	x3, [sp, #1392]
	sub	x1, x29, #88
	bl	_flow_directive
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_253:
	sub	x0, x29, #88
	adrp	x1, l_.str.69@PAGE
	add	x1, x1, l_.str.69@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_256
	b	LBB8_254
LBB8_254:
	sub	x0, x29, #88
	adrp	x1, l_.str.70@PAGE
	add	x1, x1, l_.str.70@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_256
	b	LBB8_255
LBB8_255:
	sub	x0, x29, #88
	adrp	x1, l_.str.71@PAGE
	add	x1, x1, l_.str.71@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_299
	b	LBB8_256
LBB8_256:
	sub	x0, x29, #88
	str	x0, [sp, #344]                  ; 8-byte Folded Spill
	adrp	x1, l_.str.70@PAGE
	add	x1, x1, l_.str.70@PAGEOFF
	bl	_strcmp
	mov	x8, x0
	ldr	x0, [sp, #344]                  ; 8-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, eq
	strb	w8, [sp, #795]
	adrp	x1, l_.str.71@PAGE
	add	x1, x1, l_.str.71@PAGEOFF
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	strb	w8, [sp, #794]
	ldrb	w8, [sp, #794]
	tbz	w8, #0, LBB8_258
	b	LBB8_257
LBB8_257:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #296
	str	x8, [sp, #336]                  ; 8-byte Folded Spill
	b	LBB8_262
LBB8_258:
	ldrb	w8, [sp, #795]
	tbz	w8, #0, LBB8_260
	b	LBB8_259
LBB8_259:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #312
	str	x8, [sp, #328]                  ; 8-byte Folded Spill
	b	LBB8_261
LBB8_260:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #344
	str	x8, [sp, #328]                  ; 8-byte Folded Spill
	b	LBB8_261
LBB8_261:
	ldr	x8, [sp, #328]                  ; 8-byte Folded Reload
	str	x8, [sp, #336]                  ; 8-byte Folded Spill
	b	LBB8_262
LBB8_262:
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	str	x8, [sp, #784]
	ldrb	w8, [sp, #794]
	tbz	w8, #0, LBB8_264
	b	LBB8_263
LBB8_263:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #304
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	b	LBB8_268
LBB8_264:
	ldrb	w8, [sp, #795]
	tbz	w8, #0, LBB8_266
	b	LBB8_265
LBB8_265:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #320
	str	x8, [sp, #312]                  ; 8-byte Folded Spill
	b	LBB8_267
LBB8_266:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	add	x8, x8, #352
	str	x8, [sp, #312]                  ; 8-byte Folded Spill
	b	LBB8_267
LBB8_267:
	ldr	x8, [sp, #312]                  ; 8-byte Folded Reload
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	b	LBB8_268
LBB8_268:
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	str	x8, [sp, #776]
	ldrb	w8, [sp, #795]
	tbnz	w8, #0, LBB8_272
	b	LBB8_269
LBB8_269:
	ldrb	w8, [sp, #794]
	tbnz	w8, #0, LBB8_272
	b	LBB8_270
LBB8_270:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #105]
	tbz	w8, #0, LBB8_272
	b	LBB8_271
LBB8_271:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.72@PAGE
	add	x1, x1, l_.str.72@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_272:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_277
	b	LBB8_273
LBB8_273:
	add	x0, sp, #1384
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2864
	mov	x2, #4096                       ; =0x1000
	add	x3, sp, #772
	bl	_parse_quoted_string
	tbz	w0, #0, LBB8_277
	b	LBB8_274
LBB8_274:
	ldr	w8, [sp, #772]
	cbz	w8, LBB8_277
	b	LBB8_275
LBB8_275:
	ldr	w8, [sp, #772]
	mov	w10, #2                         ; =0x2
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbnz	w8, LBB8_277
	b	LBB8_276
LBB8_276:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	tbnz	w0, #0, LBB8_278
	b	LBB8_277
LBB8_277:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #304]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.73@PAGE
	add	x4, x4, l_.str.73@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #304]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #308]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_278:
	str	wzr, [sp, #768]
	b	LBB8_279
LBB8_279:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #768]
	ldr	w9, [sp, #772]
	subs	w8, w8, w9
	b.hs	LBB8_284
	b	LBB8_280
LBB8_280:                               ;   in Loop: Header=BB8_279 Depth=1
	ldr	w8, [sp, #768]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2864
	ldrb	w0, [x8, x9]
	bl	_isxdigit
	cbnz	w0, LBB8_282
	b	LBB8_281
LBB8_281:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #296]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.74@PAGE
	add	x4, x4, l_.str.74@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #300]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_282:                               ;   in Loop: Header=BB8_279 Depth=1
	b	LBB8_283
LBB8_283:                               ;   in Loop: Header=BB8_279 Depth=1
	ldr	w8, [sp, #768]
	add	w8, w8, #1
	str	w8, [sp, #768]
	b	LBB8_279
LBB8_284:
	ldr	w8, [sp, #772]
	mov	w9, #2                          ; =0x2
	udiv	w8, w8, w9
	str	w8, [sp, #764]
	ldr	w8, [sp, #764]
	ldr	x9, [sp, #776]
	ldr	w10, [x9]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB8_286
	b	LBB8_285
LBB8_285:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_286:
	ldr	x8, [sp, #784]
	ldr	x0, [x8]
	ldr	x8, [sp, #776]
	ldr	w8, [x8]
	ldr	w9, [sp, #764]
	add	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	bl	_realloc
	str	x0, [sp, #752]
	ldr	x8, [sp, #752]
	cbnz	x8, LBB8_288
	b	LBB8_287
LBB8_287:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_288:
	str	wzr, [sp, #748]
	b	LBB8_289
LBB8_289:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #748]
	ldr	w9, [sp, #764]
	subs	w8, w8, w9
	b.hs	LBB8_298
	b	LBB8_290
LBB8_290:                               ;   in Loop: Header=BB8_289 Depth=1
	ldr	w8, [sp, #748]
	lsl	w9, w8, #1
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2864
	str	x8, [sp, #288]                  ; 8-byte Folded Spill
	ldrb	w0, [x8, w9, uxtw]
	bl	_tolower
	ldr	x8, [sp, #288]                  ; 8-byte Folded Reload
	strb	w0, [sp, #747]
	ldr	w9, [sp, #748]
	lsl	w9, w9, #1
	add	w9, w9, #1
	ldrb	w0, [x8, w9, uxtw]
	bl	_tolower
	strb	w0, [sp, #746]
	ldrb	w8, [sp, #747]
	subs	w8, w8, #57
	b.gt	LBB8_292
	b	LBB8_291
LBB8_291:                               ;   in Loop: Header=BB8_289 Depth=1
	ldrb	w8, [sp, #747]
	subs	w8, w8, #48
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	b	LBB8_293
LBB8_292:                               ;   in Loop: Header=BB8_289 Depth=1
	ldrb	w8, [sp, #747]
	subs	w8, w8, #97
	add	w8, w8, #10
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	b	LBB8_293
LBB8_293:                               ;   in Loop: Header=BB8_289 Depth=1
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	str	w8, [sp, #740]
	ldrb	w8, [sp, #746]
	subs	w8, w8, #57
	b.gt	LBB8_295
	b	LBB8_294
LBB8_294:                               ;   in Loop: Header=BB8_289 Depth=1
	ldrb	w8, [sp, #746]
	subs	w8, w8, #48
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	b	LBB8_296
LBB8_295:                               ;   in Loop: Header=BB8_289 Depth=1
	ldrb	w8, [sp, #746]
	subs	w8, w8, #97
	add	w8, w8, #10
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	b	LBB8_296
LBB8_296:                               ;   in Loop: Header=BB8_289 Depth=1
	ldr	w8, [sp, #280]                  ; 4-byte Folded Reload
	str	w8, [sp, #736]
	ldr	w9, [sp, #740]
	ldr	w8, [sp, #736]
	add	w8, w8, w9, lsl #4
	ldr	x9, [sp, #752]
	ldr	x10, [sp, #776]
	ldr	w10, [x10]
	ldr	w11, [sp, #748]
	add	w10, w10, w11
	strb	w8, [x9, w10, uxtw]
	b	LBB8_297
LBB8_297:                               ;   in Loop: Header=BB8_289 Depth=1
	ldr	w8, [sp, #748]
	add	w8, w8, #1
	str	w8, [sp, #748]
	b	LBB8_289
LBB8_298:
	ldr	x8, [sp, #752]
	ldr	x9, [sp, #784]
	str	x8, [x9]
	ldr	w10, [sp, #764]
	ldr	x9, [sp, #776]
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_299:
	sub	x0, x29, #88
	adrp	x1, l_.str.75@PAGE
	add	x1, x1, l_.str.75@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_316
	b	LBB8_300
LBB8_300:
	add	x0, sp, #1384
	ldr	x8, [sp, #1384]
	str	x8, [sp, #720]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2736
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	strb	w0, [sp, #719]
	ldrb	w8, [sp, #719]
	tbnz	w8, #0, LBB8_302
	b	LBB8_301
LBB8_301:
	ldr	x8, [sp, #720]
	str	x8, [sp, #1384]
	b	LBB8_302
LBB8_302:
	ldr	x0, [sp, #1384]
	bl	_strlen
	str	x0, [sp, #704]
	ldr	x8, [sp, #704]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.lo	LBB8_304
	b	LBB8_303
LBB8_303:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #276]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.76@PAGE
	add	x4, x4, l_.str.76@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #276]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_304:
	ldr	x8, [sp, #704]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #696]
	ldr	x8, [sp, #696]
	cbnz	x8, LBB8_306
	b	LBB8_305
LBB8_305:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #272]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.77@PAGE
	add	x4, x4, l_.str.77@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #272]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_306:
	ldr	x1, [sp, #696]
	ldr	x8, [sp, #704]
	add	x2, x8, #1
	add	x0, sp, #1384
	add	x3, sp, #732
	bl	_parse_quoted_string
	tbnz	w0, #0, LBB8_308
	b	LBB8_307
LBB8_307:
	ldr	x0, [sp, #696]
	bl	_free
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #264]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.78@PAGE
	add	x4, x4, l_.str.78@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #268]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_308:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x1, [sp, #696]
	ldr	w2, [sp, #732]
	bl	_nvm_add_string
	str	w0, [sp, #692]
	ldr	x0, [sp, #696]
	bl	_free
	ldr	w8, [sp, #692]
	adds	w8, w8, #1
	b.ne	LBB8_310
	b	LBB8_309
LBB8_309:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #260]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.79@PAGE
	add	x4, x4, l_.str.79@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #260]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_310:
	ldrb	w8, [sp, #719]
	tbz	w8, #0, LBB8_315
	b	LBB8_311
LBB8_311:
	ldr	x0, [sp, #1408]
	ldr	w3, [sp, #692]
	ldr	x4, [sp, #1392]
	mov	w1, #4                          ; =0x4
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2736
	bl	_add_symbol
	tbnz	w0, #0, LBB8_315
	b	LBB8_312
LBB8_312:
	ldr	x8, [sp, #1392]
	ldr	w8, [x8]
	subs	w8, w8, #11
	b.eq	LBB8_314
	b	LBB8_313
LBB8_313:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_314:
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x9, sp
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2736
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #256]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.80@PAGE
	add	x4, x4, l_.str.80@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #256]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_315:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_316:
	sub	x0, x29, #88
	adrp	x1, l_.str.81@PAGE
	add	x1, x1, l_.str.81@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_318
	b	LBB8_317
LBB8_317:
	ldr	x0, [sp, #1408]
	ldr	x1, [sp, #1384]
	ldr	x2, [sp, #1392]
	bl	_assemble_import
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_318:
	sub	x0, x29, #88
	adrp	x1, l_.str.82@PAGE
	add	x1, x1, l_.str.82@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_340
	b	LBB8_319
LBB8_319:
	movi.2d	v0, #0000000000000000
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2704
	str	q0, [sp, #6800]
	str	q0, [sp, #6816]
	add	x0, sp, #1384
	bl	_parse_uint32
	tbz	w0, #0, LBB8_329
	b	LBB8_320
LBB8_320:
	add	x0, sp, #1384
	add	x1, sp, #688
	bl	_parse_uint32
	tbz	w0, #0, LBB8_329
	b	LBB8_321
LBB8_321:
	ldr	w8, [sp, #688]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hs	LBB8_329
	b	LBB8_322
LBB8_322:
	add	x0, sp, #1384
	add	x1, sp, #2704
	mov	x2, #4096                       ; =0x1000
	add	x3, sp, #680
	bl	_parse_quoted_string
	tbz	w0, #0, LBB8_329
	b	LBB8_323
LBB8_323:
	add	x0, sp, #1384
	add	x1, sp, #684
	bl	_parse_uint32
	tbz	w0, #0, LBB8_329
	b	LBB8_324
LBB8_324:
	ldr	w8, [sp, #684]
	subs	w8, w8, #1
	b.ne	LBB8_329
	b	LBB8_325
LBB8_325:
	add	x0, sp, #1384
	add	x1, sp, #2672
	mov	x2, #32                         ; =0x20
	bl	_parse_identifier
	tbz	w0, #0, LBB8_329
	b	LBB8_326
LBB8_326:
	add	x0, sp, #2672
	adrp	x1, l_.str.83@PAGE
	add	x1, x1, l_.str.83@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_328
	b	LBB8_327
LBB8_327:
	add	x0, sp, #2672
	adrp	x1, l_.str.84@PAGE
	add	x1, x1, l_.str.84@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_329
	b	LBB8_328
LBB8_328:
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x1, x8, #14
	add	x0, sp, #1384
	bl	_parse_result_tag
	tbnz	w0, #0, LBB8_330
	b	LBB8_329
LBB8_329:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #248]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.85@PAGE
	add	x4, x4, l_.str.85@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #248]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #252]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_330:
	ldr	x9, [sp, #456]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #688]
	strh	w8, [sp, #6808]
	ldr	w8, [sp, #684]
	strb	w8, [x9, #10]
	add	x0, sp, #2672
	adrp	x1, l_.str.84@PAGE
	add	x1, x1, l_.str.84@PAGEOFF
	bl	_strcmp
	ldr	x9, [sp, #456]                  ; 8-byte Folded Reload
	mov	w8, #0                          ; =0x0
	subs	w10, w0, #0
	csinc	w8, w8, wzr, ne
	strb	w8, [x9, #11]
	b	LBB8_331
LBB8_331:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #1384]
	bl	_at_line_end
	tbnz	w0, #0, LBB8_336
	b	LBB8_332
LBB8_332:                               ;   in Loop: Header=BB8_331 Depth=1
	ldrh	w8, [sp, #6812]
	subs	w8, w8, #16
	b.ge	LBB8_334
	b	LBB8_333
LBB8_333:                               ;   in Loop: Header=BB8_331 Depth=1
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x8, x8, #15
	ldrh	w9, [sp, #6812]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	add	x0, sp, #1384
	bl	_parse_result_tag
	tbnz	w0, #0, LBB8_335
	b	LBB8_334
LBB8_334:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #244]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #240]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.86@PAGE
	add	x4, x4, l_.str.86@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #240]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #244]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_335:                               ;   in Loop: Header=BB8_331 Depth=1
	ldrh	w8, [sp, #6812]
	add	w8, w8, #1
	strh	w8, [sp, #6812]
	b	LBB8_331
LBB8_336:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w2, [sp, #680]
	add	x1, sp, #2704
	bl	_nvm_add_string
	str	w0, [sp, #6804]
	ldr	w8, [sp, #6804]
	adds	w8, w8, #1
	b.eq	LBB8_338
	b	LBB8_337
LBB8_337:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2704
	bl	_nvm_add_callback_contract
	tbnz	w0, #0, LBB8_339
	b	LBB8_338
LBB8_338:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #236]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.87@PAGE
	add	x4, x4, l_.str.87@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #236]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_339:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_340:
	sub	x0, x29, #88
	adrp	x1, l_.str.88@PAGE
	add	x1, x1, l_.str.88@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_366
	b	LBB8_341
LBB8_341:
	add	x1, sp, #676
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #676]
	add	x0, sp, #1384
	ldr	x8, [sp, #1384]
	str	x8, [sp, #664]
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_347
	b	LBB8_342
LBB8_342:
	ldr	x8, [sp, #664]
	add	x0, sp, #1384
	str	x8, [sp, #1384]
	add	x1, sp, #2544
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB8_346
	b	LBB8_343
LBB8_343:
	ldr	x0, [sp, #1408]
	mov	w1, #0                          ; =0x0
	add	x2, sp, #2544
	bl	_find_symbol
	str	w0, [sp, #660]
	ldr	w8, [sp, #660]
	tbnz	w8, #31, LBB8_345
	b	LBB8_344
LBB8_344:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #40]
	ldrsw	x9, [sp, #660]
	mov	x10, #136                       ; =0x88
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #128]
	str	w8, [sp, #676]
	b	LBB8_345
LBB8_345:
	b	LBB8_346
LBB8_346:
	b	LBB8_347
LBB8_347:
	ldr	w8, [sp, #676]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB8_349
	b	LBB8_348
LBB8_348:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #232]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.89@PAGE
	add	x4, x4, l_.str.89@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #232]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_349:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #676]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #4]
	strh	w8, [sp, #658]
	ldrh	w8, [sp, #658]
	cbz	w8, LBB8_351
	b	LBB8_350
LBB8_350:
	ldrh	w8, [sp, #658]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #224]                  ; 8-byte Folded Spill
	b	LBB8_352
LBB8_351:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
	b	LBB8_352
LBB8_352:
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	x8, [sp, #648]
	ldrh	w8, [sp, #658]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #220]                  ; 4-byte Folded Spill
	cbz	w8, LBB8_354
	b	LBB8_353
LBB8_353:
	ldr	x8, [sp, #648]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #220]                  ; 4-byte Folded Spill
	b	LBB8_354
LBB8_354:
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #647]
	strh	wzr, [sp, #644]
	b	LBB8_355
LBB8_355:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #647]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #216]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB8_357
	b	LBB8_356
LBB8_356:                               ;   in Loop: Header=BB8_355 Depth=1
	ldrh	w8, [sp, #644]
	ldrh	w9, [sp, #658]
	subs	w8, w8, w9
	cset	w8, lt
	str	w8, [sp, #216]                  ; 4-byte Folded Spill
	b	LBB8_357
LBB8_357:                               ;   in Loop: Header=BB8_355 Depth=1
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB8_360
	b	LBB8_358
LBB8_358:                               ;   in Loop: Header=BB8_355 Depth=1
	ldr	x8, [sp, #648]
	ldrh	w9, [sp, #644]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	add	x0, sp, #1384
	bl	_parse_result_tag
	strb	w0, [sp, #647]
	b	LBB8_359
LBB8_359:                               ;   in Loop: Header=BB8_355 Depth=1
	ldrh	w8, [sp, #644]
	add	w8, w8, #1
	strh	w8, [sp, #644]
	b	LBB8_355
LBB8_360:
	ldrb	w8, [sp, #647]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #212]                  ; 4-byte Folded Spill
	tbz	w8, #0, LBB8_363
	b	LBB8_361
LBB8_361:
	ldr	x0, [sp, #1384]
	bl	_at_line_end
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #212]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB8_363
	b	LBB8_362
LBB8_362:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w1, [sp, #676]
	ldr	x2, [sp, #648]
	ldrh	w3, [sp, #658]
	bl	_nvm_set_function_param_types
	str	w0, [sp, #212]                  ; 4-byte Folded Spill
	b	LBB8_363
LBB8_363:
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #647]
	ldr	x0, [sp, #648]
	bl	_free
	ldrb	w8, [sp, #647]
	tbnz	w8, #0, LBB8_365
	b	LBB8_364
LBB8_364:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.90@PAGE
	add	x4, x4, l_.str.90@PAGEOFF
	bl	___snprintf_chk
	b	LBB8_365
LBB8_365:
	ldrb	w8, [sp, #647]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_366:
	sub	x0, x29, #88
	adrp	x1, l_.str.91@PAGE
	add	x1, x1, l_.str.91@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_379
	b	LBB8_367
LBB8_367:
	add	x0, sp, #1384
	add	x1, sp, #640
	bl	_parse_uint32
	tbz	w0, #0, LBB8_374
	b	LBB8_368
LBB8_368:
	ldr	w8, [sp, #640]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB8_374
	b	LBB8_369
LBB8_369:
	add	x0, sp, #1384
	add	x1, sp, #2512
	mov	x2, #32                         ; =0x20
	bl	_parse_identifier
	tbz	w0, #0, LBB8_374
	b	LBB8_370
LBB8_370:
	ldr	x0, [sp, #1384]
	bl	_at_line_end
	tbz	w0, #0, LBB8_374
	b	LBB8_371
LBB8_371:
	add	x0, sp, #2512
	adrp	x1, l_.str.92@PAGE
	add	x1, x1, l_.str.92@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_375
	b	LBB8_372
LBB8_372:
	add	x0, sp, #2512
	adrp	x1, l_.str.93@PAGE
	add	x1, x1, l_.str.93@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_375
	b	LBB8_373
LBB8_373:
	add	x0, sp, #2512
	adrp	x1, l_.str.94@PAGE
	add	x1, x1, l_.str.94@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB8_375
	b	LBB8_374
LBB8_374:
	ldr	x9, [sp, #1392]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #208]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.95@PAGE
	add	x4, x4, l_.str.95@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_375:
	add	x0, sp, #2512
	adrp	x1, l_.str.94@PAGE
	add	x1, x1, l_.str.94@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_377
	b	LBB8_376
LBB8_376:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #204]                  ; 4-byte Folded Spill
	b	LBB8_378
LBB8_377:
	add	x0, sp, #2512
	adrp	x1, l_.str.93@PAGE
	add	x1, x1, l_.str.93@PAGEOFF
	bl	_strcmp
	mov	w8, #0                          ; =0x0
	subs	w9, w0, #0
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #204]                  ; 4-byte Folded Spill
	b	LBB8_378
LBB8_378:
	ldr	w8, [sp, #204]                  ; 4-byte Folded Reload
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	x11, [x9, #400]
	ldr	w9, [sp, #640]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	strb	w8, [x9, #11]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_379:
	sub	x0, x29, #88
	adrp	x1, l_.str.96@PAGE
	add	x1, x1, l_.str.96@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_383
	b	LBB8_380
LBB8_380:
	add	x3, sp, #636
	str	wzr, [sp, #636]
	add	x0, sp, #1384
	add	x1, sp, #2256
	mov	x2, #256                        ; =0x100
	bl	_parse_quoted_string
	tbnz	w0, #0, LBB8_382
	b	LBB8_381
LBB8_381:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #200]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #196]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.97@PAGE
	add	x4, x4, l_.str.97@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #196]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #200]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_382:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	w2, [sp, #636]
	add	x1, sp, #2256
	bl	_nvm_add_string
	mov	x1, x0
	ldr	x0, [sp, #184]                  ; 8-byte Folded Reload
	bl	_nvm_add_module_ref
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_383:
	sub	x0, x29, #88
	adrp	x1, l_.str.98@PAGE
	add	x1, x1, l_.str.98@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_389
	b	LBB8_384
LBB8_384:
	add	x0, sp, #1384
	add	x1, sp, #632
	bl	_parse_uint32
	tbz	w0, #0, LBB8_387
	b	LBB8_385
LBB8_385:
	add	x0, sp, #1384
	add	x1, sp, #628
	bl	_parse_uint32
	tbz	w0, #0, LBB8_387
	b	LBB8_386
LBB8_386:
	add	x0, sp, #1384
	add	x1, sp, #624
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_388
	b	LBB8_387
LBB8_387:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #180]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #176]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.99@PAGE
	add	x4, x4, l_.str.99@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #176]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #180]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_388:
	ldr	w8, [sp, #632]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	str	w8, [x9, #468]
	ldr	w8, [sp, #628]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	str	w8, [x9, #472]
	ldr	w8, [sp, #624]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	str	w8, [x9, #476]
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_389:
	sub	x0, x29, #88
	adrp	x1, l_.str.100@PAGE
	add	x1, x1, l_.str.100@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_400
	b	LBB8_390
LBB8_390:
	add	x0, sp, #1384
	add	x1, sp, #620
	bl	_parse_symbol_kind
	tbz	w0, #0, LBB8_394
	b	LBB8_391
LBB8_391:
	add	x0, sp, #1384
	add	x1, sp, #2128
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB8_394
	b	LBB8_392
LBB8_392:
	add	x0, sp, #1384
	add	x1, sp, #616
	bl	_parse_uint32
	tbz	w0, #0, LBB8_394
	b	LBB8_393
LBB8_393:
	ldr	x0, [sp, #1384]
	bl	_at_line_end
	tbnz	w0, #0, LBB8_395
	b	LBB8_394
LBB8_394:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #168]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.101@PAGE
	add	x4, x4, l_.str.101@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #168]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #172]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_395:
	ldr	x0, [sp, #1408]
	ldr	w1, [sp, #620]
	ldr	w3, [sp, #616]
	ldr	x4, [sp, #1392]
	add	x2, sp, #2128
	bl	_add_symbol
	tbnz	w0, #0, LBB8_399
	b	LBB8_396
LBB8_396:
	ldr	x8, [sp, #1392]
	ldr	w8, [x8]
	subs	w8, w8, #11
	b.eq	LBB8_398
	b	LBB8_397
LBB8_397:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_398:
	ldr	x8, [sp, #1392]
	add	x8, x8, #8
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	ldr	w0, [sp, #620]
	bl	_symbol_kind_name
	mov	x8, x0
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	add	x8, sp, #2128
	str	x8, [x9, #8]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #164]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.102@PAGE
	add	x4, x4, l_.str.102@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #164]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_399:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_400:
	sub	x0, x29, #88
	adrp	x1, l_.str.103@PAGE
	add	x1, x1, l_.str.103@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_420
	b	LBB8_401
LBB8_401:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbz	w8, #0, LBB8_403
	b	LBB8_402
LBB8_402:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #148]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #144]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.104@PAGE
	add	x4, x4, l_.str.104@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #144]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #148]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_403:
	add	x0, sp, #1384
	add	x1, sp, #1872
	mov	x2, #256                        ; =0x100
	bl	_parse_identifier
	tbnz	w0, #0, LBB8_405
	b	LBB8_404
LBB8_404:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #136]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.105@PAGE
	add	x4, x4, l_.str.105@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #140]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_405:
	add	x0, sp, #1384
	add	x1, sp, #612
	bl	_parse_uint32
	tbz	w0, #0, LBB8_411
	b	LBB8_406
LBB8_406:
	add	x0, sp, #1384
	add	x1, sp, #608
	bl	_parse_uint32
	tbz	w0, #0, LBB8_411
	b	LBB8_407
LBB8_407:
	add	x0, sp, #1384
	add	x1, sp, #604
	bl	_parse_uint32
	tbz	w0, #0, LBB8_411
	b	LBB8_408
LBB8_408:
	add	x0, sp, #1384
	add	x1, sp, #603
	bl	_parse_result_tag
	tbz	w0, #0, LBB8_411
	b	LBB8_409
LBB8_409:
	add	x0, sp, #1384
	add	x1, sp, #602
	bl	_parse_uint8
	tbz	w0, #0, LBB8_411
	b	LBB8_410
LBB8_410:
	ldrb	w8, [sp, #602]
	subs	w8, w8, #0
	cset	w8, eq
	ldrb	w9, [sp, #603]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB8_412
	b	LBB8_411
LBB8_411:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #128]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.106@PAGE
	add	x4, x4, l_.str.106@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #132]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_412:
	str	xzr, [sp, #576]
	str	xzr, [sp, #584]
	str	xzr, [sp, #592]
	ldr	x8, [sp, #1408]
	ldr	x8, [x8]
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	add	x0, sp, #1872
	str	x0, [sp, #112]                  ; 8-byte Folded Spill
	bl	_strlen
	ldr	x1, [sp, #112]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	mov	x2, x8
	bl	_nvm_add_string
	str	w0, [sp, #576]
	ldr	w8, [sp, #576]
	adds	w8, w8, #1
	b.ne	LBB8_414
	b	LBB8_413
LBB8_413:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #108]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.107@PAGE
	add	x4, x4, l_.str.107@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_414:
	ldr	w8, [sp, #612]
	add	x1, sp, #576
	strh	w8, [sp, #580]
	ldr	w8, [sp, #608]
	strh	w8, [sp, #592]
	ldr	w8, [sp, #604]
	strh	w8, [sp, #594]
	ldrb	w8, [sp, #603]
	strb	w8, [sp, #596]
	ldrb	w8, [sp, #602]
	strb	w8, [sp, #597]
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	bl	_nvm_add_function
	ldr	x8, [sp, #1408]
	str	w0, [x8, #76]
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #76]
	adds	w8, w8, #1
	b.ne	LBB8_416
	b	LBB8_415
LBB8_415:
	ldr	x9, [sp, #1392]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #104]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.108@PAGE
	add	x4, x4, l_.str.108@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #104]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_416:
	ldr	x0, [sp, #1408]
	mov	w1, #0                          ; =0x0
	add	x2, sp, #1872
	bl	_find_symbol
	str	w0, [sp, #572]
	ldr	w8, [sp, #572]
	tbnz	w8, #31, LBB8_418
	b	LBB8_417
LBB8_417:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #40]
	ldrsw	x9, [sp, #572]
	mov	x10, #136                       ; =0x88
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #128]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.eq	LBB8_419
	b	LBB8_418
LBB8_418:
	ldr	x9, [sp, #1392]
	mov	w8, #11                         ; =0xb
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x9, sp
	add	x8, sp, #1872
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #100]                  ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.8@PAGE
	add	x4, x4, l_.str.8@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_419:
	ldr	x9, [sp, #1408]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #72]
	ldr	x8, [sp, #1408]
	str	wzr, [x8, #96]
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_420:
	sub	x0, x29, #88
	adrp	x1, l_.str.109@PAGE
	add	x1, x1, l_.str.109@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_451
	b	LBB8_421
LBB8_421:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #106]
	tbz	w8, #0, LBB8_423
	b	LBB8_422
LBB8_422:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.110@PAGE
	add	x1, x1, l_.str.110@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_423:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_425
	b	LBB8_424
LBB8_424:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #96]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #92]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.111@PAGE
	add	x4, x4, l_.str.111@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #92]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #96]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_425:
	str	wzr, [sp, #568]
	b	LBB8_426
LBB8_426:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #568]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB8_434
	b	LBB8_427
LBB8_427:                               ;   in Loop: Header=BB8_426 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x10, [x8, #56]
	ldr	w8, [sp, #568]
                                        ; kill: def $x8 killed $w8
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #560]
	ldr	x8, [sp, #560]
	ldr	w8, [x8, #136]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.eq	LBB8_429
	b	LBB8_428
LBB8_428:                               ;   in Loop: Header=BB8_426 Depth=1
	b	LBB8_433
LBB8_429:                               ;   in Loop: Header=BB8_426 Depth=1
	ldr	x0, [sp, #1408]
	ldr	x1, [sp, #560]
	ldr	x8, [sp, #1408]
	ldr	w2, [x8, #76]
	bl	_find_label
	str	w0, [sp, #556]
	ldr	w8, [sp, #556]
	tbnz	w8, #31, LBB8_431
	b	LBB8_430
LBB8_430:                               ;   in Loop: Header=BB8_426 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #556]
	mov	x10, #140                       ; =0x8c
	mul	x9, x9, x10
	add	x8, x8, x9
	ldrb	w8, [x8, #136]
	tbnz	w8, #0, LBB8_432
	b	LBB8_431
LBB8_431:
	ldr	x9, [sp, #1392]
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	ldr	x8, [sp, #560]
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #88]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.112@PAGE
	add	x4, x4, l_.str.112@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_432:                               ;   in Loop: Header=BB8_426 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #556]
	mov	x10, #140                       ; =0x8c
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #128]
	ldr	x9, [sp, #560]
	ldr	w9, [x9, #132]
	subs	w8, w8, w9
	str	w8, [sp, #552]
	ldr	w8, [sp, #552]
	str	w8, [sp, #548]
	ldrb	w8, [sp, #548]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9, #88]
	ldr	x10, [sp, #560]
	ldr	w10, [x10, #128]
	add	w10, w10, #0
	strb	w8, [x9, w10, uxtw]
	ldr	w8, [sp, #548]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [sp, #1408]
	ldr	x9, [x9, #88]
	ldr	x10, [sp, #560]
	ldr	w10, [x10, #128]
	add	w10, w10, #1
	strb	w8, [x9, w10, uxtw]
	ldr	w8, [sp, #548]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x9, [sp, #1408]
	ldr	x9, [x9, #88]
	ldr	x10, [sp, #560]
	ldr	w10, [x10, #128]
	add	w10, w10, #2
	strb	w8, [x9, w10, uxtw]
	ldr	w8, [sp, #548]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [sp, #1408]
	ldr	x9, [x9, #88]
	ldr	x10, [sp, #560]
	ldr	w10, [x10, #128]
	add	w10, w10, #3
	strb	w8, [x9, w10, uxtw]
	b	LBB8_433
LBB8_433:                               ;   in Loop: Header=BB8_426 Depth=1
	ldr	w8, [sp, #568]
	add	w8, w8, #1
	str	w8, [sp, #568]
	b	LBB8_426
LBB8_434:
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	ldr	x8, [sp, #1408]
	ldr	x1, [x8, #88]
	ldr	x8, [sp, #1408]
	ldr	w2, [x8, #96]
	bl	_nvm_append_code
	str	w0, [sp, #544]
	ldr	w8, [sp, #544]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	x12, [x9, #256]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	str	w8, [x9, #8]
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #96]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #12]
	b	LBB8_435
LBB8_435:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #8]
	cbz	x8, LBB8_444
	b	LBB8_436
LBB8_436:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #8]
	str	x8, [sp, #536]
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #76]
	str	w8, [sp, #504]
	ldr	x8, [sp, #536]
	ldr	w8, [x8, #4]
	str	w8, [sp, #508]
	ldr	x8, [sp, #536]
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB8_438
	b	LBB8_437
LBB8_437:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #536]
	ldr	w8, [x8, #8]
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB8_439
LBB8_438:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #1408]
	ldr	w8, [x8, #96]
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB8_439
LBB8_439:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	str	w8, [sp, #512]
	ldr	x8, [sp, #536]
	ldrh	w8, [x8]
	strh	w8, [sp, #516]
	strh	wzr, [sp, #518]
	ldr	x8, [sp, #536]
	ldr	x8, [x8, #16]
	str	x8, [sp, #520]
	ldr	x8, [sp, #536]
	ldr	w8, [x8, #12]
	str	w8, [sp, #528]
	str	wzr, [sp, #532]
	ldr	x8, [sp, #536]
	ldrb	w8, [x8, #25]
	tbz	w8, #0, LBB8_441
	b	LBB8_440
LBB8_440:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #504
	bl	_nvm_add_upvalue_binding
	tbnz	w0, #0, LBB8_443
	b	LBB8_442
LBB8_441:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x0, [x8]
	add	x1, sp, #504
	bl	_nvm_add_local_binding
	tbnz	w0, #0, LBB8_443
	b	LBB8_442
LBB8_442:
	ldr	x0, [sp, #1392]
	adrp	x1, l_.str.113@PAGE
	add	x1, x1, l_.str.113@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_443:                               ;   in Loop: Header=BB8_435 Depth=1
	ldr	x8, [sp, #536]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #1408]
	str	x8, [x9, #8]
	ldr	x8, [sp, #536]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x0, [sp, #536]
	bl	_free
	b	LBB8_435
LBB8_444:
	ldr	x8, [sp, #1408]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldr	x8, [sp, #1408]
	strb	wzr, [x8, #72]
	str	wzr, [sp, #500]
	str	wzr, [sp, #496]
	b	LBB8_445
LBB8_445:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #496]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB8_450
	b	LBB8_446
LBB8_446:                               ;   in Loop: Header=BB8_445 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x10, [x8, #56]
	ldr	w8, [sp, #496]
                                        ; kill: def $x8 killed $w8
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #136]
	ldr	x9, [sp, #1408]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.eq	LBB8_448
	b	LBB8_447
LBB8_447:                               ;   in Loop: Header=BB8_445 Depth=1
	ldr	x8, [sp, #1408]
	ldr	x11, [x8, #56]
	ldr	w8, [sp, #500]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	str	w9, [sp, #500]
	mov	x9, #140                        ; =0x8c
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldr	x8, [sp, #1408]
	ldr	x10, [x8, #56]
	ldr	w8, [sp, #496]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #140                        ; =0x8c
	bl	_memcpy
	b	LBB8_448
LBB8_448:                               ;   in Loop: Header=BB8_445 Depth=1
	b	LBB8_449
LBB8_449:                               ;   in Loop: Header=BB8_445 Depth=1
	ldr	w8, [sp, #496]
	add	w8, w8, #1
	str	w8, [sp, #496]
	b	LBB8_445
LBB8_450:
	ldr	w8, [sp, #500]
	ldr	x9, [sp, #1408]
	str	w8, [x9, #64]
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_451:
	sub	x0, x29, #88
	adrp	x1, l_.str.114@PAGE
	add	x1, x1, l_.str.114@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_468
	b	LBB8_452
LBB8_452:
	add	x0, sp, #1384
	ldr	x8, [sp, #1384]
	str	x8, [sp, #480]
	bl	_skip_whitespace
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #65
	b.lt	LBB8_454
	b	LBB8_453
LBB8_453:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #90
	b.le	LBB8_458
	b	LBB8_454
LBB8_454:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #97
	b.lt	LBB8_456
	b	LBB8_455
LBB8_455:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #122
	b.le	LBB8_458
	b	LBB8_456
LBB8_456:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #95
	b.eq	LBB8_458
	b	LBB8_457
LBB8_457:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #36
	b.ne	LBB8_462
	b	LBB8_458
LBB8_458:
	add	x0, sp, #1384
	add	x1, sp, #1744
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB8_462
	b	LBB8_459
LBB8_459:
	ldr	x0, [sp, #1408]
	mov	w1, #0                          ; =0x0
	add	x2, sp, #1744
	bl	_find_symbol
	str	w0, [sp, #476]
	ldr	w8, [sp, #476]
	tbz	w8, #31, LBB8_461
	b	LBB8_460
LBB8_460:
	ldr	x9, [sp, #1392]
	mov	w8, #10                         ; =0xa
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x9, sp
	add	x8, sp, #1744
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #80]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.115@PAGE
	add	x4, x4, l_.str.115@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_461:
	ldr	x8, [sp, #1408]
	ldr	x8, [x8, #40]
	ldrsw	x9, [sp, #476]
	mov	x10, #136                       ; =0x88
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #128]
	str	w8, [sp, #492]
	b	LBB8_465
LBB8_462:
	ldr	x8, [sp, #480]
	add	x0, sp, #1384
	str	x8, [sp, #1384]
	add	x1, sp, #492
	bl	_parse_uint32
	tbnz	w0, #0, LBB8_464
	b	LBB8_463
LBB8_463:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #72]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.116@PAGE
	add	x4, x4, l_.str.116@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #76]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_464:
	b	LBB8_465
LBB8_465:
	ldr	x0, [sp, #1384]
	bl	_at_line_end
	tbnz	w0, #0, LBB8_467
	b	LBB8_466
LBB8_466:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #64]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.117@PAGE
	add	x4, x4, l_.str.117@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #68]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_467:
	ldr	w8, [sp, #492]
	ldr	x9, [sp, #1408]
	ldr	x9, [x9]
	str	w8, [x9, #12]
	ldr	x8, [sp, #1408]
	ldr	x9, [x8]
	ldr	w8, [x9, #8]
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #60]                  ; 4-byte Folded Spill
	orr	w8, w8, #0x1
	str	w8, [x9, #8]
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_468:
	sub	x0, x29, #88
	adrp	x1, l_.str.118@PAGE
	add	x1, x1, l_.str.118@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_480
	b	LBB8_469
LBB8_469:
	add	x0, sp, #1384
	add	x1, sp, #1680
	mov	x2, #64                         ; =0x40
	bl	_parse_identifier
	tbnz	w0, #0, LBB8_471
	b	LBB8_470
LBB8_470:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #56]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #52]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.119@PAGE
	add	x4, x4, l_.str.119@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_471:
	add	x0, sp, #1680
	adrp	x1, l_.str.120@PAGE
	add	x1, x1, l_.str.120@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_473
	b	LBB8_472
LBB8_472:
	ldr	x8, [sp, #1408]
	ldr	x9, [x8]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x1
	str	w8, [x9, #8]
	b	LBB8_479
LBB8_473:
	add	x0, sp, #1680
	adrp	x1, l_.str.121@PAGE
	add	x1, x1, l_.str.121@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_475
	b	LBB8_474
LBB8_474:
	ldr	x8, [sp, #1408]
	ldr	x9, [x8]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x2
	str	w8, [x9, #8]
	b	LBB8_478
LBB8_475:
	add	x0, sp, #1680
	adrp	x1, l_.str.122@PAGE
	add	x1, x1, l_.str.122@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB8_477
	b	LBB8_476
LBB8_476:
	ldr	x8, [sp, #1408]
	ldr	x9, [x8]
	ldr	w8, [x9, #8]
	orr	w8, w8, #0x4
	str	w8, [x9, #8]
	b	LBB8_477
LBB8_477:
	b	LBB8_478
LBB8_478:
	b	LBB8_479
LBB8_479:
	ldr	x0, [sp, #1384]
	ldr	x1, [sp, #1392]
	bl	_require_line_end
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_480:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x9, sp
	sub	x8, x29, #88
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #44]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.123@PAGE
	add	x4, x4, l_.str.123@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #48]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_481:
	add	x0, sp, #1384
	ldr	x8, [sp, #1384]
	str	x8, [sp, #464]
	add	x1, sp, #1552
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB8_497
	b	LBB8_482
LBB8_482:
	add	x0, sp, #1384
	bl	_skip_whitespace
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #58
	b.ne	LBB8_496
	b	LBB8_483
LBB8_483:
	ldr	x8, [sp, #1384]
	add	x8, x8, #1
	str	x8, [sp, #1384]
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_485
	b	LBB8_484
LBB8_484:
	ldr	x9, [sp, #1392]
	mov	w8, #6                          ; =0x6
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #40]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.124@PAGE
	add	x4, x4, l_.str.124@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_485:
	ldr	x0, [sp, #1408]
	ldr	x8, [sp, #1408]
	ldr	w2, [x8, #96]
	ldr	x3, [sp, #1392]
	add	x1, sp, #1552
	bl	_add_label
	tbnz	w0, #0, LBB8_489
	b	LBB8_486
LBB8_486:
	ldr	x8, [sp, #1392]
	ldr	w8, [x8]
	subs	w8, w8, #5
	b.eq	LBB8_488
	b	LBB8_487
LBB8_487:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_488:
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x9, sp
	add	x8, sp, #1552
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #36]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.125@PAGE
	add	x4, x4, l_.str.125@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_489:
	add	x0, sp, #1384
	bl	_skip_whitespace
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	cbz	w8, LBB8_495
	b	LBB8_490
LBB8_490:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #59
	b.eq	LBB8_495
	b	LBB8_491
LBB8_491:
	ldr	x8, [sp, #1384]
	ldrsb	w8, [x8]
	subs	w8, w8, #35
	b.eq	LBB8_495
	b	LBB8_492
LBB8_492:
	add	x0, sp, #1384
	add	x1, sp, #1488
	mov	x2, #64                         ; =0x40
	bl	_parse_identifier
	tbnz	w0, #0, LBB8_494
	b	LBB8_493
LBB8_493:
	ldr	x8, [sp, #1392]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_494:
	ldr	x0, [sp, #1408]
	ldr	x3, [sp, #1392]
	add	x1, sp, #1488
	add	x2, sp, #1384
	bl	_assemble_instruction
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_495:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_496:
	ldr	x8, [sp, #464]
	str	x8, [sp, #1384]
	b	LBB8_498
LBB8_497:
	ldr	x8, [sp, #464]
	str	x8, [sp, #1384]
	b	LBB8_498
LBB8_498:
	ldr	x8, [sp, #1408]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB8_500
	b	LBB8_499
LBB8_499:
	ldr	x9, [sp, #1392]
	mov	w8, #6                          ; =0x6
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #32]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.126@PAGE
	add	x4, x4, l_.str.126@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_500:
	add	x0, sp, #1384
	add	x1, sp, #1424
	mov	x2, #64                         ; =0x40
	bl	_parse_identifier
	tbnz	w0, #0, LBB8_502
	b	LBB8_501
LBB8_501:
	ldr	x9, [sp, #1392]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #1392]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #24]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.127@PAGE
	add	x4, x4, l_.str.127@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_502:
	ldr	x0, [sp, #1408]
	ldr	x3, [sp, #1392]
	add	x1, sp, #1424
	add	x2, sp, #1384
	bl	_assemble_instruction
	and	w8, w0, #0x1
	strb	w8, [sp, #1423]
	b	LBB8_503
LBB8_503:
	ldrb	w8, [sp, #1423]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB8_505
	b	LBB8_504
LBB8_504:
	bl	___stack_chk_fail
LBB8_505:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #3040
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function skip_whitespace
_skip_whitespace:                       ; @skip_whitespace
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	b	LBB9_1
LBB9_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #32
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB9_3
	b	LBB9_2
LBB9_2:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB9_3
LBB9_3:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB9_5
	b	LBB9_4
LBB9_4:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB9_1
LBB9_5:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_identifier
_parse_identifier:                      ; @parse_identifier
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x0, [x29, #-16]
	bl	_skip_whitespace
	str	xzr, [sp, #8]
	b	LBB10_1
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #65
	b.lt	LBB10_3
	b	LBB10_2
LBB10_2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #90
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.le	LBB10_10
	b	LBB10_3
LBB10_3:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #97
	b.lt	LBB10_5
	b	LBB10_4
LBB10_4:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #122
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.le	LBB10_10
	b	LBB10_5
LBB10_5:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #48
	b.lt	LBB10_7
	b	LBB10_6
LBB10_6:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #57
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.le	LBB10_10
	b	LBB10_7
LBB10_7:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #95
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB10_10
	b	LBB10_8
LBB10_8:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #36
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB10_10
	b	LBB10_9
LBB10_9:                                ;   in Loop: Header=BB10_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #46
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB10_10
LBB10_10:                               ;   in Loop: Header=BB10_1 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_14
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_1 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.lo	LBB10_13
	b	LBB10_12
LBB10_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_15
LBB10_13:                               ;   in Loop: Header=BB10_1 Depth=1
	ldur	x10, [x29, #-16]
	ldr	x8, [x10]
	add	x9, x8, #1
	str	x9, [x10]
	ldrb	w8, [x8]
	ldr	x9, [sp, #24]
	ldr	x10, [sp, #8]
	add	x11, x10, #1
	str	x11, [sp, #8]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB10_1
LBB10_14:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #0
	cset	w8, hi
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_15
LBB10_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_symbol
_add_symbol:                            ; @add_symbol
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	w3, [x29, #-36]
	str	x4, [sp, #32]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldur	x2, [x29, #-32]
	bl	_find_symbol
	tbnz	w0, #31, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x9, [sp, #32]
	mov	w8, #11                         ; =0xb
	str	w8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_5
LBB11_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #40]
	ldur	x8, [x29, #-16]
	add	x1, x8, #52
	ldur	x8, [x29, #-16]
	ldr	w2, [x8, #48]
	ldr	x4, [sp, #32]
	mov	x3, #136                        ; =0x88
	bl	_reserve_table
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_5
LBB11_4:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #40]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #40]
	ldur	x11, [x29, #-16]
	ldr	w8, [x11, #48]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #12]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	str	w9, [x11, #48]
	mov	x9, #136                        ; =0x88
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-32]
	mov	x9, sp
	str	x8, [x9]
	mov	x3, #128                        ; =0x80
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.9@PAGE
	add	x4, x4, l_.str.9@PAGEOFF
	bl	___snprintf_chk
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	ldur	w8, [x29, #-20]
	ldr	x10, [sp, #16]
	str	w8, [x10, #132]
	ldur	w8, [x29, #-36]
	ldr	x10, [sp, #16]
	str	w8, [x10, #128]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB11_5
LBB11_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_symbol
_find_symbol:                           ; @find_symbol
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB12_1
LBB12_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.hs	LBB12_7
	b	LBB12_2
LBB12_2:                                ;   in Loop: Header=BB12_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #40]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #136                        ; =0x88
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #132]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB12_5
	b	LBB12_3
LBB12_3:                                ;   in Loop: Header=BB12_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #40]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #136                        ; =0x88
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	ldr	x1, [sp, #16]
	bl	_strcmp
	cbnz	w0, LBB12_5
	b	LBB12_4
LBB12_4:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB12_8
LBB12_5:                                ;   in Loop: Header=BB12_1 Depth=1
	b	LBB12_6
LBB12_6:                                ;   in Loop: Header=BB12_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB12_1
LBB12_7:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB12_8
LBB12_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function reserve_table
_reserve_table:                         ; @reserve_table
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #40]
	str	x4, [sp, #32]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB13_2
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-16]
	stur	x8, [x29, #-8]
	b	LBB13_15
LBB13_2:
	ldur	w8, [x29, #-28]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.lo	LBB13_4
	b	LBB13_3
LBB13_3:
	ldr	x9, [sp, #32]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.10@PAGE
	add	x4, x4, l_.str.10@PAGEOFF
	bl	___snprintf_chk
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_15
LBB13_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	cbz	w8, LBB13_9
	b	LBB13_5
LBB13_5:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	mov	w9, #1073741823                 ; =0x3fffffff
	subs	w8, w8, w9
	b.ls	LBB13_7
	b	LBB13_6
LBB13_6:
	mov	w8, #2147483647                 ; =0x7fffffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_8
LBB13_7:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	lsl	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_8
LBB13_8:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB13_10
LBB13_9:
	mov	w8, #64                         ; =0x40
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB13_10
LBB13_10:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #28]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	ldr	x10, [sp, #40]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB13_12
	b	LBB13_11
LBB13_11:
	ldr	x9, [sp, #32]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.11@PAGE
	add	x4, x4, l_.str.11@PAGEOFF
	bl	___snprintf_chk
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_15
LBB13_12:
	ldur	x0, [x29, #-16]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #40]
	mul	x1, x8, x9
	bl	_realloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB13_14
	b	LBB13_13
LBB13_13:
	ldr	x9, [sp, #32]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldr	x8, [sp, #32]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.12@PAGE
	add	x4, x4, l_.str.12@PAGEOFF
	bl	___snprintf_chk
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_15
LBB13_14:
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB13_15
LBB13_15:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function par_error
_par_error:                             ; @par_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x9, [x29, #-8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #16]
	mov	x10, sp
	str	x9, [x10]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #12]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.9@PAGE
	add	x4, x4, l_.str.9@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_quoted_string
_parse_quoted_string:                   ; @parse_quoted_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldur	x0, [x29, #-16]
	bl	_skip_whitespace
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #34
	b.eq	LBB15_2
	b	LBB15_1
LBB15_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_2:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	str	wzr, [sp, #20]
	b	LBB15_3
LBB15_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #34
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_5
	b	LBB15_4
LBB15_4:                                ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB15_5
LBB15_5:                                ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_34
	b	LBB15_6
LBB15_6:                                ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.lo	LBB15_8
	b	LBB15_7
LBB15_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_8:                                ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #92
	b.ne	LBB15_32
	b	LBB15_9
LBB15_9:                                ;   in Loop: Header=BB15_3 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	cbnz	w8, LBB15_11
	b	LBB15_10
LBB15_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_11:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #34
	b.eq	LBB15_22
	b	LBB15_12
LBB15_12:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #48
	b.eq	LBB15_23
	b	LBB15_13
LBB15_13:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #92
	b.eq	LBB15_21
	b	LBB15_14
LBB15_14:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #110
	b.eq	LBB15_18
	b	LBB15_15
LBB15_15:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #114
	b.eq	LBB15_19
	b	LBB15_16
LBB15_16:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #116
	b.eq	LBB15_20
	b	LBB15_17
LBB15_17:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #120
	b.eq	LBB15_24
	b	LBB15_30
LBB15_18:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x9, x8, x9
	mov	w8, #10                         ; =0xa
	strb	w8, [x9]
	b	LBB15_31
LBB15_19:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x9, x8, x9
	mov	w8, #13                         ; =0xd
	strb	w8, [x9]
	b	LBB15_31
LBB15_20:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x9, x8, x9
	mov	w8, #9                          ; =0x9
	strb	w8, [x9]
	b	LBB15_31
LBB15_21:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x9, x8, x9
	mov	w8, #92                         ; =0x5c
	strb	w8, [x9]
	b	LBB15_31
LBB15_22:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x9, x8, x9
	mov	w8, #34                         ; =0x22
	strb	w8, [x9]
	b	LBB15_31
LBB15_23:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [sp, #20]
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB15_31
LBB15_24:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w0, [x8, #1]
	bl	_hex_digit_value
	str	w0, [sp, #16]
	ldr	w8, [sp, #16]
	tbz	w8, #31, LBB15_26
	b	LBB15_25
LBB15_25:                               ;   in Loop: Header=BB15_3 Depth=1
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB15_27
LBB15_26:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w0, [x8, #2]
	bl	_hex_digit_value
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB15_27
LBB15_27:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #12]
	ldr	w8, [sp, #12]
	tbz	w8, #31, LBB15_29
	b	LBB15_28
LBB15_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_29:                               ;   in Loop: Header=BB15_3 Depth=1
	ldr	w9, [sp, #16]
	ldr	w8, [sp, #12]
	orr	w8, w8, w9, lsl #4
	ldur	x9, [x29, #-24]
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #20]
	strb	w8, [x9, x10]
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, #2
	str	x8, [x9]
	b	LBB15_31
LBB15_30:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #20]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB15_31
LBB15_31:                               ;   in Loop: Header=BB15_3 Depth=1
	b	LBB15_33
LBB15_32:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [sp, #20]
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB15_33
LBB15_33:                               ;   in Loop: Header=BB15_3 Depth=1
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	b	LBB15_3
LBB15_34:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #34
	b.eq	LBB15_36
	b	LBB15_35
LBB15_35:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_36:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	add	x8, x8, #1
	str	x8, [x9]
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #24]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_37
LBB15_37:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function require_line_end
_require_line_end:                      ; @require_line_end
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
	sub	x0, x29, #16
	stur	x8, [x29, #-16]
	str	x1, [sp, #24]
	bl	_skip_whitespace
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	cbnz	w8, LBB16_2
	b	LBB16_1
LBB16_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_3
LBB16_2:
	ldr	x9, [sp, #24]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	ldur	x8, [x29, #-16]
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #16]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.128@PAGE
	add	x4, x4, l_.str.128@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB16_3
LBB16_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_emit
_fn_emit:                               ; @fn_emit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #104]
	tbz	w8, #0, LBB17_2
	b	LBB17_1
LBB17_1:
	b	LBB17_14
LBB17_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-8]
	ldr	w10, [x9, #96]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB17_4
	b	LBB17_3
LBB17_3:
	ldur	x9, [x29, #-8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #104]
	b	LBB17_14
LBB17_4:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #96]
	ldur	w9, [x29, #-20]
	add	w8, w8, w9
	str	w8, [sp, #24]
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #100]
	subs	w8, w8, w9
	b.ls	LBB17_13
	b	LBB17_5
LBB17_5:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #100]
	str	w8, [sp, #20]
	b	LBB17_6
LBB17_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.hs	LBB17_10
	b	LBB17_7
LBB17_7:                                ;   in Loop: Header=BB17_6 Depth=1
	ldr	w8, [sp, #20]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB17_9
	b	LBB17_8
LBB17_8:
	ldr	w8, [sp, #24]
	str	w8, [sp, #20]
	b	LBB17_10
LBB17_9:                                ;   in Loop: Header=BB17_6 Depth=1
	ldr	w8, [sp, #20]
	lsl	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB17_6
LBB17_10:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #88]
	ldr	w8, [sp, #20]
	mov	x1, x8
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB17_12
	b	LBB17_11
LBB17_11:
	ldur	x9, [x29, #-8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #104]
	b	LBB17_14
LBB17_12:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-8]
	str	x8, [x9, #88]
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-8]
	str	w8, [x9, #100]
	b	LBB17_13
LBB17_13:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #88]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #96]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x1, [x29, #-16]
	ldur	w8, [x29, #-20]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	w10, [x29, #-20]
	ldur	x9, [x29, #-8]
	ldr	w8, [x9, #96]
	add	w8, w8, w10
	str	w8, [x9, #96]
	b	LBB17_14
LBB17_14:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_uint16
_parse_uint16:                          ; @parse_uint16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	mov	x1, sp
	bl	_parse_int64
	tbnz	w0, #0, LBB18_2
	b	LBB18_1
LBB18_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_6
LBB18_2:
	ldr	x8, [sp]
	tbnz	x8, #63, LBB18_4
	b	LBB18_3
LBB18_3:
	ldr	x8, [sp]
	subs	x8, x8, #16, lsl #12            ; =65536
	b.lt	LBB18_5
	b	LBB18_4
LBB18_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_6
LBB18_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
                                        ; kill: def $w8 killed $w8 killed $x8
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_6
LBB18_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_uint32
_parse_uint32:                          ; @parse_uint32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	mov	x1, sp
	bl	_parse_int64
	tbnz	w0, #0, LBB19_2
	b	LBB19_1
LBB19_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_6
LBB19_2:
	ldr	x8, [sp]
	tbnz	x8, #63, LBB19_4
	b	LBB19_3
LBB19_3:
	ldr	x8, [sp]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.le	LBB19_5
	b	LBB19_4
LBB19_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_6
LBB19_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_6
LBB19_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function par_directive
_par_directive:                         ; @par_directive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	str	x2, [sp, #56]
	str	x3, [sp, #48]
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #128]
	cbz	x8, LBB20_2
	b	LBB20_1
LBB20_1:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.129@PAGE
	add	x1, x1, l_.str.129@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_2:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB20_4
	b	LBB20_3
LBB20_3:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.130@PAGE
	add	x1, x1, l_.str.130@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_4:
	ldr	x8, [sp, #72]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldr	x9, [sp, #72]
	ldr	w10, [x9, #96]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB20_6
	b	LBB20_5
LBB20_5:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.131@PAGE
	add	x1, x1, l_.str.131@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_6:
	ldr	x8, [sp, #72]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #96]
	add	w8, w8, w9
	str	w8, [sp, #44]
	ldr	x0, [sp, #64]
	adrp	x1, l_.str.63@PAGE
	add	x1, x1, l_.str.63@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB20_25
	b	LBB20_7
LBB20_7:
	ldr	x0, [sp, #56]
	ldr	x1, [sp, #48]
	bl	_require_line_end
	tbnz	w0, #0, LBB20_9
	b	LBB20_8
LBB20_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_9:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #106]
	tbz	w8, #0, LBB20_11
	b	LBB20_10
LBB20_10:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.132@PAGE
	add	x1, x1, l_.str.132@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_11:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #105]
	tbnz	w8, #0, LBB20_18
	b	LBB20_12
LBB20_12:
	ldr	x8, [sp, #72]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	cbz	w8, LBB20_14
	b	LBB20_13
LBB20_13:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.72@PAGE
	add	x1, x1, l_.str.72@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_14:
	ldr	x0, [sp, #72]
	ldr	x2, [sp, #48]
	mov	w1, #2                          ; =0x2
	bl	_passive_word
	tbz	w0, #0, LBB20_16
	b	LBB20_15
LBB20_15:
	ldr	x0, [sp, #72]
	ldr	x2, [sp, #48]
	mov	w1, #0                          ; =0x0
	bl	_passive_word
	tbnz	w0, #0, LBB20_17
	b	LBB20_16
LBB20_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_17:
	ldr	x9, [sp, #72]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #105]
	b	LBB20_18
LBB20_18:
	ldr	x8, [sp, #72]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	ldr	x9, [sp, #72]
	str	w8, [x9, #112]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-28]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #76]
	stur	w8, [x29, #-24]
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-20]
	stur	wzr, [x29, #-16]
	stur	wzr, [x29, #-12]
	str	wzr, [sp, #40]
	b	LBB20_19
LBB20_19:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #40]
	subs	w8, w8, #5
	b.hs	LBB20_24
	b	LBB20_20
LBB20_20:                               ;   in Loop: Header=BB20_19 Depth=1
	ldr	x0, [sp, #72]
	ldr	w8, [sp, #40]
	mov	x9, x8
	sub	x8, x29, #28
	ldr	w1, [x8, x9, lsl #2]
	ldr	x2, [sp, #48]
	bl	_passive_word
	tbnz	w0, #0, LBB20_22
	b	LBB20_21
LBB20_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_22:                               ;   in Loop: Header=BB20_19 Depth=1
	b	LBB20_23
LBB20_23:                               ;   in Loop: Header=BB20_19 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB20_19
LBB20_24:
	ldr	x9, [sp, #72]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #106]
	ldr	x8, [sp, #72]
	strb	wzr, [x8, #107]
	ldr	x8, [sp, #72]
	str	wzr, [x8, #124]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_25:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #106]
	tbnz	w8, #0, LBB20_27
	b	LBB20_26
LBB20_26:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.133@PAGE
	add	x1, x1, l_.str.133@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_27:
	ldr	x0, [sp, #64]
	adrp	x1, l_.str.65@PAGE
	add	x1, x1, l_.str.65@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB20_33
	b	LBB20_28
LBB20_28:
	ldr	x0, [sp, #56]
	ldr	x1, [sp, #48]
	bl	_require_line_end
	tbnz	w0, #0, LBB20_30
	b	LBB20_29
LBB20_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_30:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #107]
	tbnz	w8, #0, LBB20_32
	b	LBB20_31
LBB20_31:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.134@PAGE
	add	x1, x1, l_.str.134@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_32:
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #116]
	mov	w9, #4                          ; =0x4
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	add	w1, w8, #4
	ldr	w2, [sp, #44]
	bl	_passive_patch
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #112]
	add	w1, w8, #12
	ldr	w2, [sp, #44]
	bl	_passive_patch
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #112]
	add	w1, w8, #16
	ldr	x8, [sp, #72]
	ldr	w2, [x8, #124]
	bl	_passive_patch
	ldr	w1, [sp, #16]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w9, [x8, #120]
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
	add	w2, w9, #1
	str	w2, [x8, #120]
	bl	_passive_patch
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x8, [sp, #72]
	strb	wzr, [x8, #107]
	ldr	x8, [sp, #72]
	strb	wzr, [x8, #106]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_33:
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_parse_uint32
	tbz	w0, #0, LBB20_35
	b	LBB20_34
LBB20_34:
	ldr	w8, [sp, #36]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lo	LBB20_36
	b	LBB20_35
LBB20_35:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.135@PAGE
	add	x1, x1, l_.str.135@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_36:
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #107]
	tbz	w8, #0, LBB20_38
	b	LBB20_37
LBB20_37:
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #116]
	add	w1, w8, #4
	ldr	w2, [sp, #44]
	bl	_passive_patch
	b	LBB20_38
LBB20_38:
	ldr	x8, [sp, #72]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	ldr	x9, [sp, #72]
	str	w8, [x9, #116]
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-56]
	stur	wzr, [x29, #-52]
	ldr	w8, [sp, #36]
	stur	w8, [x29, #-48]
	stur	wzr, [x29, #-44]
	stur	wzr, [x29, #-40]
	stur	wzr, [x29, #-36]
	stur	wzr, [x29, #-32]
	str	wzr, [sp, #32]
	b	LBB20_39
LBB20_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	subs	w8, w8, #7
	b.hs	LBB20_44
	b	LBB20_40
LBB20_40:                               ;   in Loop: Header=BB20_39 Depth=1
	ldr	x0, [sp, #72]
	ldr	w8, [sp, #32]
	mov	x9, x8
	sub	x8, x29, #56
	ldr	w1, [x8, x9, lsl #2]
	ldr	x2, [sp, #48]
	bl	_passive_word
	tbnz	w0, #0, LBB20_42
	b	LBB20_41
LBB20_41:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_42:                               ;   in Loop: Header=BB20_39 Depth=1
	b	LBB20_43
LBB20_43:                               ;   in Loop: Header=BB20_39 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB20_39
LBB20_44:
	str	wzr, [sp, #28]
	b	LBB20_45
LBB20_45:                               ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #56
	bl	_skip_whitespace
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	cbnz	w8, LBB20_47
	b	LBB20_46
LBB20_46:
	b	LBB20_53
LBB20_47:                               ;   in Loop: Header=BB20_45 Depth=1
	add	x0, sp, #56
	add	x1, sp, #24
	bl	_parse_uint32
	tbz	w0, #0, LBB20_49
	b	LBB20_48
LBB20_48:                               ;   in Loop: Header=BB20_45 Depth=1
	ldr	w8, [sp, #24]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lo	LBB20_50
	b	LBB20_49
LBB20_49:
	ldr	x0, [sp, #48]
	adrp	x1, l_.str.136@PAGE
	add	x1, x1, l_.str.136@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_50:                               ;   in Loop: Header=BB20_45 Depth=1
	ldr	x0, [sp, #72]
	ldr	w1, [sp, #24]
	ldr	x2, [sp, #48]
	bl	_passive_word
	tbnz	w0, #0, LBB20_52
	b	LBB20_51
LBB20_51:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_52:                               ;   in Loop: Header=BB20_45 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB20_45
LBB20_53:
	ldr	x0, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #116]
	add	w1, w8, #16
	ldr	w2, [sp, #28]
	bl	_passive_patch
	ldr	x10, [sp, #72]
	ldr	w8, [x10, #124]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #124]
	ldr	x10, [sp, #72]
	mov	w8, #1                          ; =0x1
	strb	w8, [x10, #107]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-57]
	b	LBB20_54
LBB20_54:
	ldurb	w8, [x29, #-57]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB20_56
	b	LBB20_55
LBB20_55:
	bl	___stack_chk_fail
LBB20_56:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function flow_directive
_flow_directive:                        ; @flow_directive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-48]
	stur	x1, [x29, #-56]
	stur	x2, [x29, #-64]
	stur	x3, [x29, #-72]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB21_2
	b	LBB21_1
LBB21_1:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.139@PAGE
	add	x1, x1, l_.str.139@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_2:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldur	x9, [x29, #-48]
	ldr	w10, [x9, #96]
	mov	w9, #-1                         ; =0xffffffff
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB21_4
	b	LBB21_3
LBB21_3:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.140@PAGE
	add	x1, x1, l_.str.140@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_4:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #96]
	add	w8, w8, w9
	stur	w8, [x29, #-76]
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.66@PAGE
	add	x1, x1, l_.str.66@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB21_16
	b	LBB21_5
LBB21_5:
	sub	x0, x29, #64
	sub	x1, x29, #80
	bl	_parse_uint32
	tbz	w0, #0, LBB21_8
	b	LBB21_6
LBB21_6:
	ldur	w8, [x29, #-80]
	cbz	w8, LBB21_8
	b	LBB21_7
LBB21_7:
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ls	LBB21_9
	b	LBB21_8
LBB21_8:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.141@PAGE
	add	x1, x1, l_.str.141@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_9:
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-72]
	bl	_require_line_end
	tbnz	w0, #0, LBB21_11
	b	LBB21_10
LBB21_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_11:
	ldur	x0, [x29, #-48]
	ldur	x3, [x29, #-72]
	adrp	x1, l_.str.63@PAGE
	add	x1, x1, l_.str.63@PAGEOFF
	adrp	x2, l_.str.142@PAGE
	add	x2, x2, l_.str.142@PAGEOFF
	bl	_par_directive
	tbnz	w0, #0, LBB21_13
	b	LBB21_12
LBB21_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_13:
	ldur	w8, [x29, #-80]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldur	x8, [x29, #-48]
	str	x0, [x8, #128]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #128]
	cbnz	x8, LBB21_15
	b	LBB21_14
LBB21_14:
	ldur	x9, [x29, #-72]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-72]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #16]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.143@PAGE
	add	x4, x4, l_.str.143@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_15:
	ldur	w8, [x29, #-80]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #136]
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w1, [x8, #112]
	mov	w2, #2                          ; =0x2
	bl	_passive_patch
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_16:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #128]
	cbnz	x8, LBB21_18
	b	LBB21_17
LBB21_17:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.144@PAGE
	add	x1, x1, l_.str.144@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_18:
	ldur	x0, [x29, #-56]
	adrp	x1, l_.str.68@PAGE
	add	x1, x1, l_.str.68@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB21_30
	b	LBB21_19
LBB21_19:
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-72]
	bl	_require_line_end
	tbnz	w0, #0, LBB21_21
	b	LBB21_20
LBB21_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_21:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #124]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #136]
	subs	w8, w8, w9
	b.eq	LBB21_23
	b	LBB21_22
LBB21_22:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.145@PAGE
	add	x1, x1, l_.str.145@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_23:
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #116]
	add	w1, w8, #4
	ldur	w2, [x29, #-76]
	bl	_passive_patch
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #112]
	add	w8, w8, #20
	stur	w8, [x29, #-84]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	str	w8, [sp, #88]
	ldr	w8, [sp, #88]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB21_25
	b	LBB21_24
LBB21_24:
	ldur	x9, [x29, #-72]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-72]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #12]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.146@PAGE
	add	x4, x4, l_.str.146@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_25:
	str	wzr, [sp, #76]
	str	wzr, [sp, #72]
	b	LBB21_26
LBB21_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #72]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #136]
	subs	w8, w8, w9
	b.hs	LBB21_29
	b	LBB21_27
LBB21_27:                               ;   in Loop: Header=BB21_26 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #128]
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #64]
	ldr	x8, [sp, #80]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	x8, [x8, #344]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	ldr	w8, [sp, #68]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	w9, [sp, #68]
	ldr	w8, [sp, #76]
	add	w8, w8, w9
	str	w8, [sp, #76]
	b	LBB21_28
LBB21_28:                               ;   in Loop: Header=BB21_26 Depth=1
	ldr	w8, [sp, #72]
	add	w8, w8, #1
	str	w8, [sp, #72]
	b	LBB21_26
LBB21_29:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	x8, [x8, #344]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x1, [sp, #80]
	ldr	w8, [sp, #88]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x0, [sp, #80]
	bl	_free
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #128]
	bl	_free
	ldur	x8, [x29, #-48]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #128]
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #112]
	add	w1, w8, #12
	ldur	w2, [x29, #-76]
	bl	_passive_patch
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #112]
	add	w1, w8, #16
	ldur	x8, [x29, #-48]
	ldr	w2, [x8, #136]
	bl	_passive_patch
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w9, [x8, #120]
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #8]                   ; 4-byte Folded Spill
	add	w2, w9, #1
	str	w2, [x8, #120]
	mov	w1, #4                          ; =0x4
	bl	_passive_patch
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	ldur	x8, [x29, #-48]
	strb	wzr, [x8, #107]
	ldur	x8, [x29, #-48]
	strb	wzr, [x8, #106]
	ldur	x8, [x29, #-48]
	str	wzr, [x8, #136]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_30:
	sub	x0, x29, #64
	add	x1, sp, #60
	bl	_parse_uint32
	tbz	w0, #0, LBB21_36
	b	LBB21_31
LBB21_31:
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #136]
	subs	w8, w8, w9
	b.hs	LBB21_36
	b	LBB21_32
LBB21_32:
	sub	x0, x29, #64
	add	x1, sp, #56
	bl	_parse_uint32
	tbz	w0, #0, LBB21_36
	b	LBB21_33
LBB21_33:
	ldr	w8, [sp, #56]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hs	LBB21_36
	b	LBB21_34
LBB21_34:
	sub	x0, x29, #64
	add	x1, sp, #52
	bl	_parse_uint32
	tbz	w0, #0, LBB21_36
	b	LBB21_35
LBB21_35:
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #136]
	subs	w8, w8, w9
	b.ls	LBB21_37
	b	LBB21_36
LBB21_36:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.147@PAGE
	add	x1, x1, l_.str.147@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_37:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #128]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	cbz	w8, LBB21_39
	b	LBB21_38
LBB21_38:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.148@PAGE
	add	x1, x1, l_.str.148@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_39:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #107]
	tbz	w8, #0, LBB21_41
	b	LBB21_40
LBB21_40:
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #116]
	add	w1, w8, #4
	ldur	w2, [x29, #-76]
	bl	_passive_patch
	b	LBB21_41
LBB21_41:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	str	w8, [sp, #48]
	ldur	w8, [x29, #-76]
	stur	w8, [x29, #-36]
	stur	wzr, [x29, #-32]
	ldr	w8, [sp, #56]
	stur	w8, [x29, #-28]
	ldr	w8, [sp, #52]
	stur	w8, [x29, #-24]
	stur	wzr, [x29, #-20]
	stur	wzr, [x29, #-16]
	stur	wzr, [x29, #-12]
	str	wzr, [sp, #44]
	b	LBB21_42
LBB21_42:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	subs	w8, w8, #7
	b.hs	LBB21_47
	b	LBB21_43
LBB21_43:                               ;   in Loop: Header=BB21_42 Depth=1
	ldur	x0, [x29, #-48]
	ldr	w8, [sp, #44]
	mov	x9, x8
	sub	x8, x29, #36
	ldr	w1, [x8, x9, lsl #2]
	ldur	x2, [x29, #-72]
	bl	_passive_word
	tbnz	w0, #0, LBB21_45
	b	LBB21_44
LBB21_44:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_45:                               ;   in Loop: Header=BB21_42 Depth=1
	b	LBB21_46
LBB21_46:                               ;   in Loop: Header=BB21_42 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB21_42
LBB21_47:
	str	wzr, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB21_48
LBB21_48:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #52]
	subs	w8, w8, w9
	b.hs	LBB21_58
	b	LBB21_49
LBB21_49:                               ;   in Loop: Header=BB21_48 Depth=1
	sub	x0, x29, #64
	add	x1, sp, #32
	bl	_parse_uint32
	tbz	w0, #0, LBB21_53
	b	LBB21_50
LBB21_50:                               ;   in Loop: Header=BB21_48 Depth=1
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #136]
	subs	w8, w8, w9
	b.hs	LBB21_53
	b	LBB21_51
LBB21_51:                               ;   in Loop: Header=BB21_48 Depth=1
	ldr	w8, [sp, #36]
	cbz	w8, LBB21_54
	b	LBB21_52
LBB21_52:                               ;   in Loop: Header=BB21_48 Depth=1
	ldr	w8, [sp, #32]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.hi	LBB21_54
	b	LBB21_53
LBB21_53:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.149@PAGE
	add	x1, x1, l_.str.149@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_54:                               ;   in Loop: Header=BB21_48 Depth=1
	ldur	x0, [x29, #-48]
	ldr	w1, [sp, #32]
	ldur	x2, [x29, #-72]
	bl	_passive_word
	tbnz	w0, #0, LBB21_56
	b	LBB21_55
LBB21_55:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_56:                               ;   in Loop: Header=BB21_48 Depth=1
	ldr	w8, [sp, #32]
	str	w8, [sp, #40]
	b	LBB21_57
LBB21_57:                               ;   in Loop: Header=BB21_48 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB21_48
LBB21_58:
	sub	x0, x29, #64
	add	x1, sp, #28
	bl	_parse_uint32
	tbz	w0, #0, LBB21_60
	b	LBB21_59
LBB21_59:
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ls	LBB21_61
	b	LBB21_60
LBB21_60:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.150@PAGE
	add	x1, x1, l_.str.150@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_61:
	ldur	x0, [x29, #-48]
	ldr	w8, [sp, #48]
	add	w1, w8, #16
	ldr	w2, [sp, #28]
	bl	_passive_patch
	str	wzr, [sp, #40]
	str	wzr, [sp, #24]
	b	LBB21_62
LBB21_62:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.hs	LBB21_72
	b	LBB21_63
LBB21_63:                               ;   in Loop: Header=BB21_62 Depth=1
	sub	x0, x29, #64
	add	x1, sp, #20
	bl	_parse_uint32
	tbz	w0, #0, LBB21_67
	b	LBB21_64
LBB21_64:                               ;   in Loop: Header=BB21_62 Depth=1
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB21_67
	b	LBB21_65
LBB21_65:                               ;   in Loop: Header=BB21_62 Depth=1
	ldr	w8, [sp, #24]
	cbz	w8, LBB21_68
	b	LBB21_66
LBB21_66:                               ;   in Loop: Header=BB21_62 Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.hi	LBB21_68
	b	LBB21_67
LBB21_67:
	ldur	x0, [x29, #-72]
	adrp	x1, l_.str.151@PAGE
	add	x1, x1, l_.str.151@PAGEOFF
	bl	_par_error
	and	w8, w0, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_68:                               ;   in Loop: Header=BB21_62 Depth=1
	ldur	x0, [x29, #-48]
	ldr	w1, [sp, #20]
	ldur	x2, [x29, #-72]
	bl	_passive_word
	tbnz	w0, #0, LBB21_70
	b	LBB21_69
LBB21_69:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_70:                               ;   in Loop: Header=BB21_62 Depth=1
	ldr	w8, [sp, #20]
	str	w8, [sp, #40]
	b	LBB21_71
LBB21_71:                               ;   in Loop: Header=BB21_62 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB21_62
LBB21_72:
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-72]
	bl	_require_line_end
	tbnz	w0, #0, LBB21_74
	b	LBB21_73
LBB21_73:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_74:
	ldr	w8, [sp, #48]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #128]
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #3
	str	w8, [x9, x10]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #128]
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	str	w8, [x9, #4]
	ldr	w8, [sp, #48]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #116]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #107]
	ldur	x10, [x29, #-48]
	ldr	w8, [x10, #124]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #124]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-37]
	b	LBB21_75
LBB21_75:
	ldurb	w8, [x29, #-37]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB21_77
	b	LBB21_76
LBB21_76:
	bl	___stack_chk_fail
LBB21_77:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function assemble_import
_assemble_import:                       ; @assemble_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-40]
	stur	x1, [x29, #-48]
	stur	x2, [x29, #-56]
	ldur	x0, [x29, #-48]
	bl	_strlen
	stur	x0, [x29, #-64]
	ldur	x8, [x29, #-64]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.lo	LBB22_2
	b	LBB22_1
LBB22_1:
	ldur	x9, [x29, #-56]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #88]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.152@PAGE
	add	x4, x4, l_.str.152@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_2:
	ldur	x8, [x29, #-64]
	add	x8, x8, #1
	stur	x8, [x29, #-72]
	ldur	x0, [x29, #-72]
	bl	_malloc
	stur	x0, [x29, #-80]
	ldur	x8, [x29, #-80]
	cbnz	x8, LBB22_4
	b	LBB22_3
LBB22_3:
	ldur	x9, [x29, #-56]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #84]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.153@PAGE
	add	x4, x4, l_.str.153@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_4:
	sub	x3, x29, #84
	stur	wzr, [x29, #-84]
	stur	wzr, [x29, #-88]
	ldur	x1, [x29, #-80]
	ldur	x2, [x29, #-72]
	sub	x0, x29, #48
	bl	_parse_quoted_string
	sturb	w0, [x29, #-90]
	ldurb	w8, [x29, #-90]
	tbz	w8, #0, LBB22_6
	b	LBB22_5
LBB22_5:
	ldur	x8, [x29, #-80]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	b	LBB22_7
LBB22_6:
	ldur	x8, [x29, #-80]
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	b	LBB22_7
LBB22_7:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #104]
	ldurb	w8, [x29, #-90]
	tbz	w8, #0, LBB22_10
	b	LBB22_8
LBB22_8:
	ldr	x1, [sp, #104]
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #104]
	ldur	x10, [x29, #-80]
	subs	x9, x9, x10
	subs	x2, x8, x9
	sub	x0, x29, #48
	sub	x3, x29, #88
	bl	_parse_quoted_string
	tbz	w0, #0, LBB22_10
	b	LBB22_9
LBB22_9:
	sub	x0, x29, #48
	sub	x1, x29, #89
	bl	_parse_result_tag
	tbnz	w0, #0, LBB22_11
	b	LBB22_10
LBB22_10:
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #64]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.154@PAGE
	add	x4, x4, l_.str.154@PAGEOFF
	bl	___snprintf_chk
	ldur	x0, [x29, #-80]
	bl	_free
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #68]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_11:
	strh	wzr, [sp, #102]
	b	LBB22_12
LBB22_12:                               ; =>This Inner Loop Header: Depth=1
	sub	x0, x29, #48
	bl	_skip_whitespace
	ldur	x0, [x29, #-48]
	bl	_at_line_end
	tbz	w0, #0, LBB22_14
	b	LBB22_13
LBB22_13:
	b	LBB22_18
LBB22_14:                               ;   in Loop: Header=BB22_12 Depth=1
	ldrh	w8, [sp, #102]
	subs	w8, w8, #16
	b.ge	LBB22_16
	b	LBB22_15
LBB22_15:                               ;   in Loop: Header=BB22_12 Depth=1
	ldrh	w8, [sp, #102]
	mov	x9, x8
	sub	x8, x29, #24
	add	x1, x8, x9
	sub	x0, x29, #48
	bl	_parse_result_tag
	tbnz	w0, #0, LBB22_17
	b	LBB22_16
LBB22_16:
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	mov	x9, sp
	mov	x8, #16                         ; =0x10
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #56]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.155@PAGE
	add	x4, x4, l_.str.155@PAGEOFF
	bl	___snprintf_chk
	ldur	x0, [x29, #-80]
	bl	_free
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #60]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_17:                               ;   in Loop: Header=BB22_12 Depth=1
	ldrh	w8, [sp, #102]
	add	w8, w8, #1
	strh	w8, [sp, #102]
	b	LBB22_12
LBB22_18:
	ldur	x8, [x29, #-40]
	ldr	x0, [x8]
	ldur	x1, [x29, #-80]
	ldur	w2, [x29, #-84]
	bl	_nvm_add_string
	str	w0, [sp, #96]
	ldr	w8, [sp, #96]
	adds	w8, w8, #1
	b.ne	LBB22_20
	b	LBB22_19
LBB22_19:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB22_21
LBB22_20:
	ldur	x8, [x29, #-40]
	ldr	x0, [x8]
	ldr	x1, [sp, #104]
	ldur	w2, [x29, #-88]
	bl	_nvm_add_string
	str	w0, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB22_21
LBB22_21:
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [sp, #92]
	ldur	x0, [x29, #-80]
	bl	_free
	ldr	w8, [sp, #96]
	adds	w8, w8, #1
	b.eq	LBB22_27
	b	LBB22_22
LBB22_22:
	ldr	w8, [sp, #92]
	adds	w8, w8, #1
	b.eq	LBB22_27
	b	LBB22_23
LBB22_23:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #96]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #92]
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	ldrh	w8, [sp, #102]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	ldurb	w8, [x29, #-89]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	ldrh	w8, [sp, #102]
	cbz	w8, LBB22_25
	b	LBB22_24
LBB22_24:
	sub	x8, x29, #24
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB22_26
LBB22_25:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB22_26
LBB22_26:
	ldr	w4, [sp, #48]                   ; 4-byte Folded Reload
	ldr	w3, [sp, #44]                   ; 4-byte Folded Reload
	ldr	w2, [sp, #40]                   ; 4-byte Folded Reload
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x5, [sp, #16]                   ; 8-byte Folded Reload
	bl	_nvm_add_import
	adds	w8, w0, #1
	b.ne	LBB22_28
	b	LBB22_27
LBB22_27:
	ldur	x9, [x29, #-56]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #12]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.156@PAGE
	add	x4, x4, l_.str.156@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_28:
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-56]
	bl	_require_line_end
	and	w8, w0, #0x1
	sturb	w8, [x29, #-25]
	b	LBB22_29
LBB22_29:
	ldurb	w8, [x29, #-25]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB22_31
	b	LBB22_30
LBB22_30:
	bl	___stack_chk_fail
LBB22_31:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_result_tag
_parse_result_tag:                      ; @parse_result_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x0, [sp, #24]
	add	x1, sp, #40
	mov	x2, #32                         ; =0x20
	bl	_parse_identifier
	tbnz	w0, #0, LBB23_2
	b	LBB23_1
LBB23_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB23_9
LBB23_2:
	strb	wzr, [sp, #15]
	b	LBB23_3
LBB23_3:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #15]
	subs	w8, w8, #16
	b.ge	LBB23_8
	b	LBB23_4
LBB23_4:                                ;   in Loop: Header=BB23_3 Depth=1
	ldrb	w0, [sp, #15]
	bl	_isa_tag_name
	mov	x1, x0
	add	x0, sp, #40
	bl	_strcmp
	cbnz	w0, LBB23_6
	b	LBB23_5
LBB23_5:
	ldrb	w8, [sp, #15]
	ldr	x9, [sp, #16]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB23_9
LBB23_6:                                ;   in Loop: Header=BB23_3 Depth=1
	b	LBB23_7
LBB23_7:                                ;   in Loop: Header=BB23_3 Depth=1
	ldrb	w8, [sp, #15]
	add	w8, w8, #1
	strb	w8, [sp, #15]
	b	LBB23_3
LBB23_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB23_9
LBB23_9:
	ldrb	w8, [sp, #39]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB23_11
	b	LBB23_10
LBB23_10:
	bl	___stack_chk_fail
LBB23_11:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function at_line_end
_at_line_end:                           ; @at_line_end
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
	add	x0, sp, #8
	str	x8, [sp, #8]
	bl	_skip_whitespace
	ldr	x8, [sp, #8]
	ldrsb	w8, [x8]
	subs	w8, w8, #0
	cset	w0, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_symbol_kind
_parse_symbol_kind:                     ; @parse_symbol_kind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x0, [sp, #24]
	add	x1, sp, #40
	mov	x2, #32                         ; =0x20
	bl	_parse_identifier
	tbnz	w0, #0, LBB25_2
	b	LBB25_1
LBB25_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB25_18
LBB25_2:
	add	x0, sp, #40
	adrp	x1, l_.str.103@PAGE
	add	x1, x1, l_.str.103@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB25_4
	b	LBB25_3
LBB25_3:
	ldr	x8, [sp, #16]
	str	wzr, [x8]
	b	LBB25_17
LBB25_4:
	add	x0, sp, #40
	adrp	x1, l_.str.81@PAGE
	add	x1, x1, l_.str.81@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB25_6
	b	LBB25_5
LBB25_5:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	b	LBB25_16
LBB25_6:
	add	x0, sp, #40
	adrp	x1, l_.str.157@PAGE
	add	x1, x1, l_.str.157@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB25_8
	b	LBB25_7
LBB25_7:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	b	LBB25_15
LBB25_8:
	add	x0, sp, #40
	adrp	x1, l_.str.158@PAGE
	add	x1, x1, l_.str.158@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB25_10
	b	LBB25_9
LBB25_9:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	b	LBB25_14
LBB25_10:
	add	x0, sp, #40
	adrp	x1, l_.str.159@PAGE
	add	x1, x1, l_.str.159@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB25_12
	b	LBB25_11
LBB25_11:
	ldr	x9, [sp, #16]
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	b	LBB25_13
LBB25_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB25_18
LBB25_13:
	b	LBB25_14
LBB25_14:
	b	LBB25_15
LBB25_15:
	b	LBB25_16
LBB25_16:
	b	LBB25_17
LBB25_17:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB25_18
LBB25_18:
	ldrb	w8, [sp, #39]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB25_20
	b	LBB25_19
LBB25_19:
	bl	___stack_chk_fail
LBB25_20:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function symbol_kind_name
_symbol_kind_name:                      ; @symbol_kind_name
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	mov	x9, x8
	adrp	x8, _symbol_kind_name.names@PAGE
	add	x8, x8, _symbol_kind_name.names@PAGEOFF
	ldr	x0, [x8, x9, lsl #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_uint8
_parse_uint8:                           ; @parse_uint8
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	mov	x1, sp
	bl	_parse_int64
	tbnz	w0, #0, LBB27_2
	b	LBB27_1
LBB27_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_6
LBB27_2:
	ldr	x8, [sp]
	tbnz	x8, #63, LBB27_4
	b	LBB27_3
LBB27_3:
	ldr	x8, [sp]
	subs	x8, x8, #255
	b.le	LBB27_5
	b	LBB27_4
LBB27_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_6
LBB27_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_6
LBB27_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_label
_find_label:                            ; @find_label
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	w2, [sp, #4]
	str	wzr, [sp]
	b	LBB28_1
LBB28_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB28_7
	b	LBB28_2
LBB28_2:                                ;   in Loop: Header=BB28_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp]
                                        ; kill: def $x8 killed $w8
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #132]
	ldr	w9, [sp, #4]
	subs	w8, w8, w9
	b.ne	LBB28_5
	b	LBB28_3
LBB28_3:                                ;   in Loop: Header=BB28_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp]
                                        ; kill: def $x8 killed $w8
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	ldr	x1, [sp, #8]
	bl	_strcmp
	cbnz	w0, LBB28_5
	b	LBB28_4
LBB28_4:
	ldr	w8, [sp]
	stur	w8, [x29, #-4]
	b	LBB28_8
LBB28_5:                                ;   in Loop: Header=BB28_1 Depth=1
	b	LBB28_6
LBB28_6:                                ;   in Loop: Header=BB28_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB28_1
LBB28_7:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB28_8
LBB28_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_label
_add_label:                             ; @add_label
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #40]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	w2, [x8, #76]
	bl	_find_label
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	tbnz	w8, #31, LBB29_3
	b	LBB29_1
LBB29_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #36]
	mov	x10, #140                       ; =0x8c
	mul	x9, x9, x10
	add	x8, x8, x9
	ldrb	w8, [x8, #136]
	tbz	w8, #0, LBB29_3
	b	LBB29_2
LBB29_2:
	ldr	x9, [sp, #40]
	mov	w8, #5                          ; =0x5
	str	w8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_8
LBB29_3:
	ldr	w8, [sp, #36]
	tbnz	w8, #31, LBB29_5
	b	LBB29_4
LBB29_4:
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #24]
	ldrsw	x11, [sp, #36]
	mov	x10, #140                       ; =0x8c
	mul	x11, x11, x10
	add	x9, x9, x11
	str	w8, [x9, #128]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldrsw	x9, [sp, #36]
	mul	x9, x9, x10
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #136]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_8
LBB29_5:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-16]
	add	x1, x8, #36
	ldur	x8, [x29, #-16]
	ldr	w2, [x8, #32]
	ldr	x4, [sp, #40]
	mov	x3, #140                        ; =0x8c
	bl	_reserve_table
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB29_7
	b	LBB29_6
LBB29_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_8
LBB29_7:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #24]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	x11, [x29, #-16]
	ldr	w8, [x11, #32]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #12]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	str	w9, [x11, #32]
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-24]
	mov	x9, sp
	str	x8, [x9]
	mov	x3, #128                        ; =0x80
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.9@PAGE
	add	x4, x4, l_.str.9@PAGEOFF
	bl	___snprintf_chk
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	ldur	w8, [x29, #-28]
	ldr	x10, [sp, #16]
	str	w8, [x10, #128]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #76]
	ldr	x10, [sp, #16]
	str	w8, [x10, #132]
	ldr	x10, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x10, #136]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB29_8
LBB29_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function assemble_instruction
_assemble_instruction:                  ; @assemble_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	ldur	x0, [x29, #-40]
	bl	_isa_opcode_by_name
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	tbz	w8, #31, LBB30_2
	b	LBB30_1
LBB30_1:
	ldur	x9, [x29, #-56]
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x0, x8, #8
	ldur	x8, [x29, #-40]
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #20]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.160@PAGE
	add	x4, x4, l_.str.160@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB30_16
LBB30_2:
	ldur	w8, [x29, #-60]
	and	w0, w8, #0xff
	bl	_isa_get_info
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbnz	x8, LBB30_4
	b	LBB30_3
LBB30_3:
	ldur	x9, [x29, #-56]
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB30_16
LBB30_4:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #96]
	str	w8, [sp, #52]
	ldur	w8, [x29, #-60]
	add	x1, sp, #51
	strb	w8, [sp, #51]
	ldur	x0, [x29, #-32]
	mov	w2, #1                          ; =0x1
	bl	_fn_emit
	str	wzr, [sp, #44]
	b	LBB30_5
LBB30_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #56]
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	b.ge	LBB30_15
	b	LBB30_6
LBB30_6:                                ;   in Loop: Header=BB30_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #96]
	str	w8, [sp, #40]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #64]
	str	w8, [sp, #36]
	ldr	x8, [sp, #56]
	add	x8, x8, #12
	ldrsw	x9, [sp, #44]
	ldr	w1, [x8, x9, lsl #2]
	ldur	w8, [x29, #-60]
	ldr	w3, [sp, #44]
	ldur	x4, [x29, #-48]
	ldur	x5, [x29, #-32]
	ldr	w6, [sp, #52]
	ldur	x7, [x29, #-56]
	sub	x0, x29, #16
	and	w2, w8, #0xff
	bl	_encode_operand
	str	w0, [sp, #32]
	ldur	x8, [x29, #-56]
	ldr	w8, [x8]
	cbz	w8, LBB30_8
	b	LBB30_7
LBB30_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB30_16
LBB30_8:                                ;   in Loop: Header=BB30_5 Depth=1
	ldr	x8, [sp, #56]
	add	x8, x8, #12
	ldrsw	x9, [sp, #44]
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #4
	b.ne	LBB30_13
	b	LBB30_9
LBB30_9:                                ;   in Loop: Header=BB30_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #64]
	ldr	w9, [sp, #36]
	subs	w8, w8, w9
	b.ls	LBB30_13
	b	LBB30_10
LBB30_10:                               ;   in Loop: Header=BB30_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #56]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #64]
	subs	w8, w8, #1
	mov	w9, #140                        ; =0x8c
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #128]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.eq	LBB30_12
	b	LBB30_11
LBB30_11:                               ;   in Loop: Header=BB30_5 Depth=1
	ldr	w8, [sp, #40]
	ldr	x9, [sp, #24]
	str	w8, [x9, #128]
	b	LBB30_12
LBB30_12:                               ;   in Loop: Header=BB30_5 Depth=1
	b	LBB30_13
LBB30_13:                               ;   in Loop: Header=BB30_5 Depth=1
	ldur	x0, [x29, #-32]
	ldr	w2, [sp, #32]
	sub	x1, x29, #16
	bl	_fn_emit
	b	LBB30_14
LBB30_14:                               ;   in Loop: Header=BB30_5 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB30_5
LBB30_15:
	ldur	x8, [x29, #-48]
	ldr	x0, [x8]
	ldur	x1, [x29, #-56]
	bl	_require_line_end
	and	w8, w0, #0x1
	sturb	w8, [x29, #-17]
	b	LBB30_16
LBB30_16:
	ldurb	w8, [x29, #-17]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB30_18
	b	LBB30_17
LBB30_17:
	bl	___stack_chk_fail
LBB30_18:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function hex_digit_value
_hex_digit_value:                       ; @hex_digit_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #11]
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #48
	b.lt	LBB31_3
	b	LBB31_1
LBB31_1:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #57
	b.gt	LBB31_3
	b	LBB31_2
LBB31_2:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #48
	str	w8, [sp, #12]
	b	LBB31_10
LBB31_3:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #97
	b.lt	LBB31_6
	b	LBB31_4
LBB31_4:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #102
	b.gt	LBB31_6
	b	LBB31_5
LBB31_5:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #97
	add	w8, w8, #10
	str	w8, [sp, #12]
	b	LBB31_10
LBB31_6:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #65
	b.lt	LBB31_9
	b	LBB31_7
LBB31_7:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #70
	b.gt	LBB31_9
	b	LBB31_8
LBB31_8:
	ldrsb	w8, [sp, #11]
	subs	w8, w8, #65
	add	w8, w8, #10
	str	w8, [sp, #12]
	b	LBB31_10
LBB31_9:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]
	b	LBB31_10
LBB31_10:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_int64
_parse_int64:                           ; @parse_int64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x0, [x29, #-16]
	bl	_skip_whitespace
	bl	___error
	mov	w2, #0                          ; =0x0
	str	wzr, [x0]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	add	x1, sp, #16
	bl	_strtoll
	str	x0, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.eq	LBB32_2
	b	LBB32_1
LBB32_1:
	bl	___error
	ldr	w8, [x0]
	cbz	w8, LBB32_3
	b	LBB32_2
LBB32_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_4
LBB32_3:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_4
LBB32_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function passive_word
_passive_word:                          ; @passive_word
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w8, [x8, #352]
	stur	w8, [x29, #-36]
	ldur	w8, [x29, #-36]
	adds	w8, w8, #5
	b.ls	LBB33_2
	b	LBB33_1
LBB33_1:
	ldur	x9, [x29, #-32]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #20]                   ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.137@PAGE
	add	x4, x4, l_.str.137@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_16
LBB33_2:
	ldur	w8, [x29, #-36]
	add	w8, w8, #4
	str	w8, [sp, #40]
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #108]
	subs	w8, w8, w9
	b.ls	LBB33_15
	b	LBB33_3
LBB33_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #108]
	cbz	w8, LBB33_5
	b	LBB33_4
LBB33_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #108]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB33_6
LBB33_5:
	mov	w8, #128                        ; =0x80
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB33_6
LBB33_6:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #36]
	b	LBB33_7
LBB33_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.hs	LBB33_12
	b	LBB33_8
LBB33_8:                                ;   in Loop: Header=BB33_7 Depth=1
	ldr	w8, [sp, #36]
	mov	w9, #2147483647                 ; =0x7fffffff
	subs	w8, w8, w9
	b.ls	LBB33_10
	b	LBB33_9
LBB33_9:                                ;   in Loop: Header=BB33_7 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB33_11
LBB33_10:                               ;   in Loop: Header=BB33_7 Depth=1
	ldr	w8, [sp, #36]
	lsl	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB33_11
LBB33_11:                               ;   in Loop: Header=BB33_7 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #36]
	b	LBB33_7
LBB33_12:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #344]
	ldr	w8, [sp, #36]
	mov	x1, x8
	bl	_realloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB33_14
	b	LBB33_13
LBB33_13:
	ldur	x9, [x29, #-32]
	mov	w8, #8                          ; =0x8
	str	w8, [x9]
	ldur	x8, [x29, #-32]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #8]                    ; 4-byte Folded Spill
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.138@PAGE
	add	x4, x4, l_.str.138@PAGEOFF
	bl	___snprintf_chk
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_16
LBB33_14:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	str	x8, [x9, #344]
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #108]
	b	LBB33_15
LBB33_15:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-36]
	ldur	w2, [x29, #-20]
	bl	_passive_patch
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	str	w8, [x9, #352]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_16
LBB33_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function passive_patch
_passive_patch:                         ; @passive_patch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	str	w2, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB34_1
LBB34_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #4
	b.hs	LBB34_4
	b	LBB34_2
LBB34_2:                                ;   in Loop: Header=BB34_1 Depth=1
	ldr	w8, [sp, #16]
	ldr	w10, [sp, #12]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #344]
	ldr	w10, [sp, #20]
	ldr	w11, [sp, #12]
	add	w10, w10, w11
	strb	w8, [x9, w10, uxtw]
	b	LBB34_3
LBB34_3:                                ;   in Loop: Header=BB34_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB34_1
LBB34_4:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function encode_operand
_encode_operand:                        ; @encode_operand
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #496
	stp	x28, x27, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	add	x29, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #184
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8]
	str	w1, [sp, #180]
	strb	w2, [sp, #179]
	str	w3, [sp, #172]
	str	x4, [sp, #160]
	str	x5, [sp, #152]
	str	w6, [sp, #148]
	str	x7, [sp, #136]
	ldr	w8, [sp, #180]
	subs	w8, w8, #2
	b.eq	LBB35_2
	b	LBB35_1
LBB35_1:
	ldr	w8, [sp, #180]
	subs	w8, w8, #3
	b.ne	LBB35_19
	b	LBB35_2
LBB35_2:
	ldrb	w0, [sp, #179]
	ldr	w1, [sp, #172]
	add	x2, sp, #132
	bl	_operand_symbol_kind
	tbz	w0, #0, LBB35_19
	b	LBB35_3
LBB35_3:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	str	x8, [sp, #120]
	ldr	x0, [sp, #160]
	bl	_skip_whitespace
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #65
	b.lt	LBB35_5
	b	LBB35_4
LBB35_4:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #90
	b.le	LBB35_9
	b	LBB35_5
LBB35_5:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #97
	b.lt	LBB35_7
	b	LBB35_6
LBB35_6:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #122
	b.le	LBB35_9
	b	LBB35_7
LBB35_7:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #95
	b.eq	LBB35_9
	b	LBB35_8
LBB35_8:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #36
	b.ne	LBB35_18
	b	LBB35_9
LBB35_9:
	ldr	x0, [sp, #160]
	sub	x1, x29, #152
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbz	w0, #0, LBB35_18
	b	LBB35_10
LBB35_10:
	ldr	x0, [sp, #152]
	ldr	w1, [sp, #132]
	sub	x2, x29, #152
	bl	_find_symbol
	str	w0, [sp, #116]
	ldr	w8, [sp, #116]
	tbz	w8, #31, LBB35_12
	b	LBB35_11
LBB35_11:
	ldr	x9, [sp, #136]
	mov	w8, #10                         ; =0xa
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x8, x8, #8
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #132]
	bl	_symbol_kind_name
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	sub	x8, x29, #152
	str	x8, [x9, #8]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.161@PAGE
	add	x4, x4, l_.str.161@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_12:
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #40]
	ldrsw	x9, [sp, #116]
	mov	x10, #136                       ; =0x88
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #128]
	str	w8, [sp, #112]
	ldr	w8, [sp, #180]
	subs	w8, w8, #2
	b.ne	LBB35_15
	b	LBB35_13
LBB35_13:
	ldr	w8, [sp, #112]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lo	LBB35_15
	b	LBB35_14
LBB35_14:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x8, x8, #8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w0, [sp, #132]
	bl	_symbol_kind_name
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	sub	x8, x29, #152
	str	x8, [x9, #8]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.162@PAGE
	add	x4, x4, l_.str.162@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_15:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #112]
	ldr	x10, [x9]
	strb	w8, [x10]
	ldr	w8, [sp, #112]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [x9]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #180]
	subs	w8, w8, #3
	b.ne	LBB35_17
	b	LBB35_16
LBB35_16:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #112]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x10, [x9]
	strb	w8, [x10, #2]
	ldr	w8, [sp, #112]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [x9]
	strb	w8, [x9, #3]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_17:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_18:
	ldr	x8, [sp, #120]
	ldr	x9, [sp, #160]
	str	x8, [x9]
	b	LBB35_19
LBB35_19:
	ldr	w8, [sp, #180]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	cbz	w8, LBB35_63
	b	LBB35_20
LBB35_20:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB35_26
	b	LBB35_21
LBB35_21:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB35_29
	b	LBB35_22
LBB35_22:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB35_32
	b	LBB35_23
LBB35_23:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB35_35
	b	LBB35_24
LBB35_24:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB35_49
	b	LBB35_25
LBB35_25:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB35_56
	b	LBB35_64
LBB35_26:
	ldr	x0, [sp, #160]
	add	x1, sp, #111
	bl	_parse_uint8
	tbnz	w0, #0, LBB35_28
	b	LBB35_27
LBB35_27:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.163@PAGE
	add	x4, x4, l_.str.163@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_28:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #111]
	ldr	x9, [x9]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_29:
	ldr	x0, [sp, #160]
	add	x1, sp, #108
	bl	_parse_uint16
	tbnz	w0, #0, LBB35_31
	b	LBB35_30
LBB35_30:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.164@PAGE
	add	x4, x4, l_.str.164@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_31:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #108]
	ldr	x10, [x9]
	strb	w8, [x10]
	ldrh	w8, [sp, #108]
	asr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x9, [x9]
	strb	w8, [x9, #1]
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_32:
	ldr	x0, [sp, #160]
	add	x1, sp, #104
	bl	_parse_uint32
	tbnz	w0, #0, LBB35_34
	b	LBB35_33
LBB35_33:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.165@PAGE
	add	x4, x4, l_.str.165@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_34:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #104]
	ldr	x10, [x9]
	strb	w8, [x10]
	ldr	w8, [sp, #104]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x10, [x9]
	strb	w8, [x10, #1]
	ldr	w8, [sp, #104]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x10, [x9]
	strb	w8, [x10, #2]
	ldr	w8, [sp, #104]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [x9]
	strb	w8, [x9, #3]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_35:
	ldr	x0, [sp, #160]
	bl	_skip_whitespace
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #65
	b.lt	LBB35_37
	b	LBB35_36
LBB35_36:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #90
	b.le	LBB35_41
	b	LBB35_37
LBB35_37:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #97
	b.lt	LBB35_39
	b	LBB35_38
LBB35_38:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #122
	b.le	LBB35_41
	b	LBB35_39
LBB35_39:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #95
	b.eq	LBB35_41
	b	LBB35_40
LBB35_40:
	ldr	x8, [sp, #160]
	ldr	x8, [x8]
	ldrsb	w8, [x8]
	subs	w8, w8, #36
	b.ne	LBB35_46
	b	LBB35_41
LBB35_41:
	ldr	x0, [sp, #160]
	add	x1, sp, #200
	mov	x2, #128                        ; =0x80
	bl	_parse_identifier
	tbnz	w0, #0, LBB35_43
	b	LBB35_42
LBB35_42:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.166@PAGE
	add	x4, x4, l_.str.166@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_43:
	ldr	x0, [sp, #152]
	ldr	w3, [sp, #148]
	ldr	x4, [sp, #136]
	add	x1, sp, #200
	mov	w2, #0                          ; =0x0
	bl	_add_patch
	tbnz	w0, #0, LBB35_45
	b	LBB35_44
LBB35_44:
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_45:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #0                          ; =0x0
	mov	x2, #4                          ; =0x4
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_46:
	ldr	x0, [sp, #160]
	add	x1, sp, #100
	bl	_parse_int32
	tbnz	w0, #0, LBB35_48
	b	LBB35_47
LBB35_47:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.167@PAGE
	add	x4, x4, l_.str.167@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_48:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #100]
	str	w8, [sp, #96]
	ldrb	w8, [sp, #96]
	ldr	x10, [x9]
	strb	w8, [x10]
	ldr	w8, [sp, #96]
	lsr	w8, w8, #8
	and	w8, w8, #0xff
	ldr	x10, [x9]
	strb	w8, [x10, #1]
	ldr	w8, [sp, #96]
	lsr	w8, w8, #16
	and	w8, w8, #0xff
	ldr	x10, [x9]
	strb	w8, [x10, #2]
	ldr	w8, [sp, #96]
	lsr	w8, w8, #24
	and	w8, w8, #0xff
	ldr	x9, [x9]
	strb	w8, [x9, #3]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_49:
	ldr	x0, [sp, #160]
	add	x1, sp, #88
	bl	_parse_int64
	tbnz	w0, #0, LBB35_51
	b	LBB35_50
LBB35_50:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.168@PAGE
	add	x4, x4, l_.str.168@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_51:
	ldr	x8, [sp, #88]
	str	x8, [sp, #80]
	str	wzr, [sp, #76]
	b	LBB35_52
LBB35_52:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	subs	w8, w8, #8
	b.ge	LBB35_55
	b	LBB35_53
LBB35_53:                               ;   in Loop: Header=BB35_52 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #80]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [x9]
	ldrsw	x10, [sp, #76]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	ldr	x8, [sp, #80]
	lsr	x8, x8, #8
	str	x8, [sp, #80]
	b	LBB35_54
LBB35_54:                               ;   in Loop: Header=BB35_52 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB35_52
LBB35_55:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_56:
	ldr	x0, [sp, #160]
	add	x1, sp, #64
	bl	_parse_double
	tbnz	w0, #0, LBB35_58
	b	LBB35_57
LBB35_57:
	ldr	x9, [sp, #136]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldr	x8, [sp, #136]
	add	x0, x8, #8
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.169@PAGE
	add	x4, x4, l_.str.169@PAGEOFF
	bl	___snprintf_chk
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_58:
	ldr	x8, [sp, #64]
	str	x8, [sp, #56]
	str	wzr, [sp, #52]
	b	LBB35_59
LBB35_59:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	subs	w8, w8, #8
	b.ge	LBB35_62
	b	LBB35_60
LBB35_60:                               ;   in Loop: Header=BB35_59 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [sp, #56]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [x9]
	ldrsw	x10, [sp, #52]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	ldr	x8, [sp, #56]
	lsr	x8, x8, #8
	str	x8, [sp, #56]
	b	LBB35_61
LBB35_61:                               ;   in Loop: Header=BB35_59 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB35_59
LBB35_62:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #196]
	b	LBB35_65
LBB35_63:
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_64:
	str	wzr, [sp, #196]
	b	LBB35_65
LBB35_65:
	ldr	w8, [sp, #196]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB35_67
	b	LBB35_66
LBB35_66:
	bl	___stack_chk_fail
LBB35_67:
	ldr	w0, [sp, #16]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #464]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function operand_symbol_kind
_operand_symbol_kind:                   ; @operand_symbol_kind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #30]
	str	w1, [sp, #24]
	str	x2, [sp, #16]
	ldr	w8, [sp, #24]
	cbnz	w8, LBB36_23
	b	LBB36_1
LBB36_1:
	ldrb	w8, [sp, #30]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #4
	b.eq	LBB36_18
	b	LBB36_2
LBB36_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #51
	b.eq	LBB36_16
	b	LBB36_3
LBB36_3:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB36_16
	b	LBB36_4
LBB36_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #62
	b.eq	LBB36_17
	b	LBB36_5
LBB36_5:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #96
	b.eq	LBB36_19
	b	LBB36_6
LBB36_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #97
	subs	w8, w8, #1
	b.ls	LBB36_20
	b	LBB36_7
LBB36_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #99
	b.eq	LBB36_19
	b	LBB36_8
LBB36_8:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #104
	b.eq	LBB36_19
	b	LBB36_9
LBB36_9:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #106
	b.eq	LBB36_20
	b	LBB36_10
LBB36_10:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #108
	b.eq	LBB36_19
	b	LBB36_11
LBB36_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #144
	b.eq	LBB36_16
	b	LBB36_12
LBB36_12:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #165
	b.eq	LBB36_18
	b	LBB36_13
LBB36_13:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #167
	b.eq	LBB36_18
	b	LBB36_14
LBB36_14:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #250
	b.eq	LBB36_16
	b	LBB36_15
LBB36_15:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #252
	subs	w8, w8, #1
	b.ls	LBB36_20
	b	LBB36_21
LBB36_16:
	ldr	x8, [sp, #16]
	str	wzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_17:
	ldr	x8, [sp, #16]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	and	w8, w9, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_18:
	ldr	x9, [sp, #16]
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_19:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_20:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_21:
	b	LBB36_22
LBB36_22:
	b	LBB36_23
LBB36_23:
	ldrb	w8, [sp, #30]
	subs	w8, w8, #251
	b.ne	LBB36_26
	b	LBB36_24
LBB36_24:
	ldr	w8, [sp, #24]
	subs	w8, w8, #1
	b.ne	LBB36_26
	b	LBB36_25
LBB36_25:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_26:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_27
LBB36_27:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_patch
_add_patch:                             ; @add_patch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	stur	w3, [x29, #-32]
	str	x4, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #56]
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-16]
	ldr	w2, [x9, #64]
	ldr	x4, [sp, #40]
	add	x1, x8, #68
	mov	x3, #140                        ; =0x8c
	bl	_reserve_table
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB37_2
	b	LBB37_1
LBB37_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_3
LBB37_2:
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #56]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #56]
	ldur	x11, [x29, #-16]
	ldr	w8, [x11, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #20]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	str	w9, [x11, #64]
	mov	x9, #140                        ; =0x8c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-24]
	mov	x9, sp
	str	x8, [x9]
	mov	x3, #128                        ; =0x80
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.9@PAGE
	add	x4, x4, l_.str.9@PAGEOFF
	bl	___snprintf_chk
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	ldur	w8, [x29, #-28]
	ldr	x10, [sp, #24]
	str	w8, [x10, #128]
	ldur	w8, [x29, #-32]
	ldr	x10, [sp, #24]
	str	w8, [x10, #132]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #76]
	ldr	x10, [sp, #24]
	str	w8, [x10, #136]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB37_3
LBB37_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_int32
_parse_int32:                           ; @parse_int32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	mov	x1, sp
	bl	_parse_int64
	tbnz	w0, #0, LBB38_2
	b	LBB38_1
LBB38_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_6
LBB38_2:
	ldr	x8, [sp]
	mov	x9, #-2147483648                ; =0xffffffff80000000
	subs	x8, x8, x9
	b.lt	LBB38_4
	b	LBB38_3
LBB38_3:
	ldr	x8, [sp]
	mov	x9, #2147483647                 ; =0x7fffffff
	subs	x8, x8, x9
	b.le	LBB38_5
	b	LBB38_4
LBB38_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_6
LBB38_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_6
LBB38_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function parse_double
_parse_double:                          ; @parse_double
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	bl	_skip_whitespace
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	adrp	x1, l_.str.170@PAGE
	add	x1, x1, l_.str.170@PAGEOFF
	mov	x2, #5                          ; =0x5
	bl	_strncmp
	cbnz	w0, LBB39_21
	b	LBB39_1
LBB39_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #5
	stur	x8, [x29, #-32]
	str	xzr, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB39_2
LBB39_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	subs	w8, w8, #16
	b.hs	LBB39_17
	b	LBB39_3
LBB39_3:                                ;   in Loop: Header=BB39_2 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #35]
	ldrb	w8, [sp, #35]
	subs	w8, w8, #48
	b.lt	LBB39_6
	b	LBB39_4
LBB39_4:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #57
	b.gt	LBB39_6
	b	LBB39_5
LBB39_5:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #48
	str	w8, [sp, #28]
	b	LBB39_15
LBB39_6:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #97
	b.lt	LBB39_9
	b	LBB39_7
LBB39_7:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #102
	b.gt	LBB39_9
	b	LBB39_8
LBB39_8:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #97
	add	w8, w8, #10
	str	w8, [sp, #28]
	b	LBB39_14
LBB39_9:                                ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #65
	b.lt	LBB39_12
	b	LBB39_10
LBB39_10:                               ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #70
	b.gt	LBB39_12
	b	LBB39_11
LBB39_11:                               ;   in Loop: Header=BB39_2 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #65
	add	w8, w8, #10
	str	w8, [sp, #28]
	b	LBB39_13
LBB39_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_27
LBB39_13:                               ;   in Loop: Header=BB39_2 Depth=1
	b	LBB39_14
LBB39_14:                               ;   in Loop: Header=BB39_2 Depth=1
	b	LBB39_15
LBB39_15:                               ;   in Loop: Header=BB39_2 Depth=1
	ldr	x9, [sp, #40]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	orr	x8, x8, x9, lsl #4
	str	x8, [sp, #40]
	b	LBB39_16
LBB39_16:                               ;   in Loop: Header=BB39_2 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB39_2
LBB39_17:
	ldur	x8, [x29, #-32]
	ldrsb	w8, [x8, #16]
	cbz	w8, LBB39_20
	b	LBB39_18
LBB39_18:
	ldur	x8, [x29, #-32]
	ldrb	w0, [x8, #16]
	bl	_isspace
	cbnz	w0, LBB39_20
	b	LBB39_19
LBB39_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_27
LBB39_20:
	ldur	x0, [x29, #-24]
	add	x1, sp, #40
	mov	x2, #8                          ; =0x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-32]
	add	x8, x8, #16
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_27
LBB39_21:
	bl	___error
	str	wzr, [x0]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	add	x1, sp, #16
	bl	_strtod
	str	d0, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.eq	LBB39_25
	b	LBB39_22
LBB39_22:
	bl	___error
	ldr	w8, [x0]
	cbz	w8, LBB39_26
	b	LBB39_23
LBB39_23:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #34
	b.ne	LBB39_25
	b	LBB39_24
LBB39_24:
	ldr	d0, [sp, #8]
	bl	___fpclassifyd
	subs	w8, w0, #5
	b.eq	LBB39_26
	b	LBB39_25
LBB39_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_27
LBB39_26:
	ldr	d0, [sp, #8]
	ldur	x8, [x29, #-24]
	str	d0, [x8]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_27
LBB39_27:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"r"

l_.str.1:                               ; @.str.1
	.asciz	"Cannot open file: %s"

l_.str.2:                               ; @.str.2
	.asciz	"File too large or unreadable: %s"

l_.str.3:                               ; @.str.3
	.asciz	"Out of memory"

l_.str.4:                               ; @.str.4
	.asciz	"I cannot grow my function code buffer."

l_.str.5:                               ; @.str.5
	.asciz	"Unterminated .function (missing .end)"

l_.str.6:                               ; @.str.6
	.asciz	"Assembled module failed verification: %.210s"

l_.str.7:                               ; @.str.7
	.asciz	".function"

l_.str.8:                               ; @.str.8
	.asciz	"Duplicate function symbol: %.200s"

l_.str.9:                               ; @.str.9
	.asciz	"%s"

l_.str.10:                              ; @.str.10
	.asciz	"I reached my assembler table index limit"

l_.str.11:                              ; @.str.11
	.asciz	"I cannot represent this assembler table size"

l_.str.12:                              ; @.str.12
	.asciz	"I cannot grow this assembler table"

l_.str.13:                              ; @.str.13
	.asciz	"Invalid directive"

l_.str.14:                              ; @.str.14
	.asciz	"shadow"

l_.str.15:                              ; @.str.15
	.asciz	"I require a shadow marker inside a bounded function."

l_.str.16:                              ; @.str.16
	.asciz	"I cannot allocate a shadow name."

l_.str.17:                              ; @.str.17
	.asciz	"I require one nonempty shadow name without control bytes."

l_.str.18:                              ; @.str.18
	.asciz	"nanolang.shadow.offset.%u"

l_.str.19:                              ; @.str.19
	.asciz	"I cannot retain a shadow execution marker."

l_.str.20:                              ; @.str.20
	.asciz	"generic_binding"

l_.str.21:                              ; @.str.21
	.asciz	"I require generic_binding inside a function."

l_.str.22:                              ; @.str.22
	.asciz	"I require four quoted, unambiguous generic binding fields."

l_.str.23:                              ; @.str.23
	.asciz	"function_purity"

l_.str.24:                              ; @.str.24
	.asciz	"I require function_purity 0 or 1 inside a function."

l_.str.25:                              ; @.str.25
	.asciz	"I cannot retain an ambiguous function purity declaration."

l_.str.26:                              ; @.str.26
	.asciz	"match_coverage"

l_.str.27:                              ; @.str.27
	.asciz	"I require match line, column, coverage and coordinate provenance inside a function."

l_.str.28:                              ; @.str.28
	.asciz	"I require an unambiguous match coverage record with a quoted source path."

l_.str.29:                              ; @.str.29
	.asciz	"function_effects"

l_.str.30:                              ; @.str.30
	.asciz	"I require function_effects a mask from 0 through 63 inside a function."

l_.str.31:                              ; @.str.31
	.asciz	"I cannot retain an ambiguous function effect summary."

l_.str.32:                              ; @.str.32
	.asciz	"borrow_place"

l_.str.33:                              ; @.str.33
	.asciz	"I require an indexed checked borrow source event outside a function."

l_.str.34:                              ; @.str.34
	.asciz	"I require an unambiguous checked borrow source event with valid counted strings."

l_.str.35:                              ; @.str.35
	.asciz	"field_read"

l_.str.36:                              ; @.str.36
	.asciz	"I require an indexed checked field-read source event outside a function."

l_.str.37:                              ; @.str.37
	.asciz	"I require an unambiguous checked field-read source event with valid counted strings."

l_.str.38:                              ; @.str.38
	.asciz	"field_write"

l_.str.39:                              ; @.str.39
	.asciz	"I require an indexed checked field-write source event outside a function."

l_.str.40:                              ; @.str.40
	.asciz	"I require an unambiguous checked field-write source event with valid counted strings."

l_.str.41:                              ; @.str.41
	.asciz	"affine_use"

l_.str.42:                              ; @.str.42
	.asciz	"I require an indexed affine source use outside a function body."

l_.str.43:                              ; @.str.43
	.asciz	"I require an unambiguous affine use with quoted source path and binding."

l_.str.44:                              ; @.str.44
	.asciz	"affine_completion"

l_.str.45:                              ; @.str.45
	.asciz	"I require an unambiguous affine completion for an existing function outside its body."

l_.str.46:                              ; @.str.46
	.asciz	"function_affine"

l_.str.47:                              ; @.str.47
	.asciz	"I require function_affine 0 or 1 inside a function."

l_.str.48:                              ; @.str.48
	.asciz	"I cannot retain an ambiguous function affine completion fact."

l_.str.49:                              ; @.str.49
	.asciz	"local_begin"

l_.str.50:                              ; @.str.50
	.asciz	"local_end"

l_.str.51:                              ; @.str.51
	.asciz	"upvalue_name"

l_.str.52:                              ; @.str.52
	.asciz	"I require a declared local slot inside a function."

l_.str.53:                              ; @.str.53
	.asciz	"I require an open local-name marker before its end."

l_.str.54:                              ; @.str.54
	.asciz	"I require disjoint local-name markers for one slot."

l_.str.55:                              ; @.str.55
	.asciz	"I cannot allocate a local-name marker."

l_.str.56:                              ; @.str.56
	.asciz	"I require one nonempty quoted local name."

l_.str.57:                              ; @.str.57
	.asciz	"debug"

l_.str.58:                              ; @.str.58
	.asciz	"I require three unsigned 32-bit DEBUG operands outside functions"

l_.str.59:                              ; @.str.59
	.asciz	"I cannot retain this DEBUG entry"

l_.str.60:                              ; @.str.60
	.asciz	"metadata"

l_.str.61:                              ; @.str.61
	.asciz	"I require two declared string indices outside functions for metadata"

l_.str.62:                              ; @.str.62
	.asciz	"I cannot retain this advisory metadata entry"

l_.str.63:                              ; @.str.63
	.asciz	"par_begin"

l_.str.64:                              ; @.str.64
	.asciz	"par_node"

l_.str.65:                              ; @.str.65
	.asciz	"par_end"

l_.str.66:                              ; @.str.66
	.asciz	"flow_begin"

l_.str.67:                              ; @.str.67
	.asciz	"flow_node"

l_.str.68:                              ; @.str.68
	.asciz	"flow_end"

l_.str.69:                              ; @.str.69
	.asciz	"passive"

l_.str.70:                              ; @.str.70
	.asciz	"layouts"

l_.str.71:                              ; @.str.71
	.asciz	"ownership"

l_.str.72:                              ; @.str.72
	.asciz	"I cannot mix raw passive chunks and producer markers."

l_.str.73:                              ; @.str.73
	.asciz	"I expect a nonempty quoted hexadecimal metadata chunk outside functions"

l_.str.74:                              ; @.str.74
	.asciz	"I require hexadecimal metadata bytes"

l_.str.75:                              ; @.str.75
	.asciz	"string"

l_.str.76:                              ; @.str.76
	.asciz	"I require a string literal within the u32 length limit"

l_.str.77:                              ; @.str.77
	.asciz	"I cannot allocate this string literal"

l_.str.78:                              ; @.str.78
	.asciz	"Expected quoted string after .string"

l_.str.79:                              ; @.str.79
	.asciz	"I cannot retain this string literal"

l_.str.80:                              ; @.str.80
	.asciz	"Duplicate constant symbol: %.200s"

l_.str.81:                              ; @.str.81
	.asciz	"import"

l_.str.82:                              ; @.str.82
	.asciz	"callback"

l_.str.83:                              ; @.str.83
	.asciz	"owner"

l_.str.84:                              ; @.str.84
	.asciz	"worker"

l_.str.85:                              ; @.str.85
	.asciz	"I expect .callback import parameter \"adapter\" 1 owner|worker result [parameters]"

l_.str.86:                              ; @.str.86
	.asciz	"I need at most 16 callback parameter tags"

l_.str.87:                              ; @.str.87
	.asciz	"I could not add this callback contract"

l_.str.88:                              ; @.str.88
	.asciz	"parameters"

l_.str.89:                              ; @.str.89
	.asciz	"I need an existing function name or index for .parameters"

l_.str.90:                              ; @.str.90
	.asciz	"I need exact-arity tags for .parameters"

l_.str.91:                              ; @.str.91
	.asciz	"import_kind"

l_.str.92:                              ; @.str.92
	.asciz	"ffi"

l_.str.93:                              ; @.str.93
	.asciz	"coprocess"

l_.str.94:                              ; @.str.94
	.asciz	"artifact"

l_.str.95:                              ; @.str.95
	.asciz	"I expect .import_kind index ffi|coprocess|artifact"

l_.str.96:                              ; @.str.96
	.asciz	"module_ref"

l_.str.97:                              ; @.str.97
	.asciz	"Expected: .module_ref \"name\""

l_.str.98:                              ; @.str.98
	.asciz	"types"

l_.str.99:                              ; @.str.99
	.asciz	"Expected: .types <structs> <enums> <unions>"

l_.str.100:                             ; @.str.100
	.asciz	"symbol"

l_.str.101:                             ; @.str.101
	.asciz	"Expected: .symbol function|import|field|type|constant name index"

l_.str.102:                             ; @.str.102
	.asciz	"Duplicate %s symbol: %.200s"

l_.str.103:                             ; @.str.103
	.asciz	"function"

l_.str.104:                             ; @.str.104
	.asciz	"Nested .function not allowed"

l_.str.105:                             ; @.str.105
	.asciz	"Expected function name after .function"

l_.str.106:                             ; @.str.106
	.asciz	"Expected: .function name arity locals upvalues result-tag result-count"

l_.str.107:                             ; @.str.107
	.asciz	"I cannot allocate the function name."

l_.str.108:                             ; @.str.108
	.asciz	"I cannot allocate the function entry."

l_.str.109:                             ; @.str.109
	.asciz	"end"

l_.str.110:                             ; @.str.110
	.asciz	"I require the passive block's end marker before ending the function."

l_.str.111:                             ; @.str.111
	.asciz	".end without matching .function"

l_.str.112:                             ; @.str.112
	.asciz	"Undefined label: %s"

l_.str.113:                             ; @.str.113
	.asciz	"I cannot retain this lexical local name."

l_.str.114:                             ; @.str.114
	.asciz	"entry"

l_.str.115:                             ; @.str.115
	.asciz	"Undefined function symbol: %s"

l_.str.116:                             ; @.str.116
	.asciz	"Expected function name or index after .entry"

l_.str.117:                             ; @.str.117
	.asciz	"Unexpected text after .entry operand"

l_.str.118:                             ; @.str.118
	.asciz	"flag"

l_.str.119:                             ; @.str.119
	.asciz	"Expected flag name after .flag"

l_.str.120:                             ; @.str.120
	.asciz	"has_main"

l_.str.121:                             ; @.str.121
	.asciz	"needs_extern"

l_.str.122:                             ; @.str.122
	.asciz	"debug_info"

l_.str.123:                             ; @.str.123
	.asciz	"Unknown directive: .%s"

l_.str.124:                             ; @.str.124
	.asciz	"Label outside .function/.end block"

l_.str.125:                             ; @.str.125
	.asciz	"Duplicate label: %s"

l_.str.126:                             ; @.str.126
	.asciz	"Instruction outside .function/.end block"

l_.str.127:                             ; @.str.127
	.asciz	"Expected instruction mnemonic"

l_.str.128:                             ; @.str.128
	.asciz	"Unexpected trailing input: %s"

l_.str.129:                             ; @.str.129
	.asciz	"I cannot mix par markers into a flow block."

l_.str.130:                             ; @.str.130
	.asciz	"I require passive producer markers inside a function."

l_.str.131:                             ; @.str.131
	.asciz	"I cannot represent the passive instruction offset."

l_.str.132:                             ; @.str.132
	.asciz	"I cannot nest passive producer blocks."

l_.str.133:                             ; @.str.133
	.asciz	"I require .par_begin before a passive node or end marker."

l_.str.134:                             ; @.str.134
	.asciz	"I require at least one node in a passive producer block."

l_.str.135:                             ; @.str.135
	.asciz	"I require a local index after .par_node."

l_.str.136:                             ; @.str.136
	.asciz	"I require parameter indices after the passive result local."

l_.str.137:                             ; @.str.137
	.asciz	"I cannot grow the passive record."

l_.str.138:                             ; @.str.138
	.asciz	"I cannot allocate the passive record."

l_.str.139:                             ; @.str.139
	.asciz	"I require flow producer markers inside a function."

l_.str.140:                             ; @.str.140
	.asciz	"I cannot represent the flow instruction offset."

l_.str.141:                             ; @.str.141
	.asciz	"I require a positive flow node count within the function locals."

l_.str.142:                             ; @.str.142
	.space	1

l_.str.143:                             ; @.str.143
	.asciz	"I cannot allocate the flow marker index."

l_.str.144:                             ; @.str.144
	.asciz	"I require .flow_begin before a flow node or end marker."

l_.str.145:                             ; @.str.145
	.asciz	"I require every source node exactly once before .flow_end."

l_.str.146:                             ; @.str.146
	.asciz	"I cannot order the flow records."

l_.str.147:                             ; @.str.147
	.asciz	"I require a source ID, result local and dependency count after .flow_node."

l_.str.148:                             ; @.str.148
	.asciz	"I require distinct flow source IDs."

l_.str.149:                             ; @.str.149
	.asciz	"I require sorted distinct source IDs for flow dependencies."

l_.str.150:                             ; @.str.150
	.asciz	"I require a parameter-read count after flow dependencies."

l_.str.151:                             ; @.str.151
	.asciz	"I require sorted distinct parameter indices for flow reads."

l_.str.152:                             ; @.str.152
	.asciz	"I require import names within the u32 string length limit"

l_.str.153:                             ; @.str.153
	.asciz	"I cannot allocate import names"

l_.str.154:                             ; @.str.154
	.asciz	"I expect .import \"module\" \"symbol\" return-tag [param-tags...]"

l_.str.155:                             ; @.str.155
	.asciz	"I require at most %d valid parameter tags after .import"

l_.str.156:                             ; @.str.156
	.asciz	"I cannot retain this import declaration"

l_.str.157:                             ; @.str.157
	.asciz	"field"

l_.str.158:                             ; @.str.158
	.asciz	"type"

l_.str.159:                             ; @.str.159
	.asciz	"constant"

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @symbol_kind_name.names
_symbol_kind_name.names:
	.quad	l_.str.103
	.quad	l_.str.81
	.quad	l_.str.157
	.quad	l_.str.158
	.quad	l_.str.159

	.section	__TEXT,__cstring,cstring_literals
l_.str.160:                             ; @.str.160
	.asciz	"Unknown opcode: %s"

l_.str.161:                             ; @.str.161
	.asciz	"Undefined %s symbol: %s"

l_.str.162:                             ; @.str.162
	.asciz	"%s symbol out of u16 range: %s"

l_.str.163:                             ; @.str.163
	.asciz	"Expected u8 operand"

l_.str.164:                             ; @.str.164
	.asciz	"Expected u16 operand"

l_.str.165:                             ; @.str.165
	.asciz	"Expected u32 operand"

l_.str.166:                             ; @.str.166
	.asciz	"Expected label or i32 operand"

l_.str.167:                             ; @.str.167
	.asciz	"Expected i32 operand"

l_.str.168:                             ; @.str.168
	.asciz	"Expected i64 operand"

l_.str.169:                             ; @.str.169
	.asciz	"Expected f64 operand"

l_.str.170:                             ; @.str.170
	.asciz	"bits:"

.subsections_via_symbols
