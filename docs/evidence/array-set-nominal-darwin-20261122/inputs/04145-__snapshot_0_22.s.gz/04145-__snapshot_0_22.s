	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_result_name             ; -- Begin function nvm_v2_result_name
	.p2align	2
_nvm_v2_result_name:                    ; @nvm_v2_result_name
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	subs	x8, x8, #14
	b.hi	LBB0_17
; %bb.1:
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	adrp	x10, lJTI0_0@PAGE
	add	x10, x10, lJTI0_0@PAGEOFF
Ltmp1:
	adr	x8, Ltmp1
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB0_2:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_3:
	adrp	x8, l_.str.1@PAGE
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_4:
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_5:
	adrp	x8, l_.str.3@PAGE
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_6:
	adrp	x8, l_.str.4@PAGE
	add	x8, x8, l_.str.4@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_7:
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_8:
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_9:
	adrp	x8, l_.str.7@PAGE
	add	x8, x8, l_.str.7@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_10:
	adrp	x8, l_.str.8@PAGE
	add	x8, x8, l_.str.8@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_11:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_12:
	adrp	x8, l_.str.10@PAGE
	add	x8, x8, l_.str.10@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_13:
	adrp	x8, l_.str.11@PAGE
	add	x8, x8, l_.str.11@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_14:
	adrp	x8, l_.str.12@PAGE
	add	x8, x8, l_.str.12@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_15:
	adrp	x8, l_.str.13@PAGE
	add	x8, x8, l_.str.13@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_16:
	adrp	x8, l_.str.14@PAGE
	add	x8, x8, l_.str.14@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_17:
	adrp	x8, l_.str.15@PAGE
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [sp, #24]
	b	LBB0_18
LBB0_18:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI0_0:
	.long	LBB0_2-Ltmp1
	.long	LBB0_3-Ltmp1
	.long	LBB0_4-Ltmp1
	.long	LBB0_5-Ltmp1
	.long	LBB0_6-Ltmp1
	.long	LBB0_7-Ltmp1
	.long	LBB0_8-Ltmp1
	.long	LBB0_9-Ltmp1
	.long	LBB0_10-Ltmp1
	.long	LBB0_11-Ltmp1
	.long	LBB0_12-Ltmp1
	.long	LBB0_13-Ltmp1
	.long	LBB0_14-Ltmp1
	.long	LBB0_15-Ltmp1
	.long	LBB0_16-Ltmp1
                                        ; -- End function
	.globl	_nvm_v2_read_header             ; -- Begin function nvm_v2_read_header
	.p2align	2
_nvm_v2_read_header:                    ; @nvm_v2_read_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB1_3
	b	LBB1_2
LBB1_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_3:
	ldur	x8, [x29, #-24]
	subs	x8, x8, #40
	b.hs	LBB1_5
	b	LBB1_4
LBB1_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_5:
	str	wzr, [sp, #12]
	b	LBB1_6
LBB1_6:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #4
	b.ge	LBB1_9
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #12]
	add	w9, w9, #0
	add	x8, x8, w9, sxtw
	ldrb	w8, [x8]
	ldrsw	x10, [sp, #12]
	add	x9, sp, #16
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB1_8
LBB1_8:                                 ;   in Loop: Header=BB1_6 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB1_6
LBB1_9:
	ldur	x8, [x29, #-16]
	add	x0, x8, #4
	bl	_rd16
	strh	w0, [sp, #20]
	ldur	x8, [x29, #-16]
	add	x0, x8, #6
	bl	_rd16
	strh	w0, [sp, #22]
	ldur	x8, [x29, #-16]
	add	x0, x8, #8
	bl	_rd32
	str	w0, [sp, #24]
	ldur	x8, [x29, #-16]
	add	x0, x8, #12
	bl	_rd64
	str	x0, [sp, #32]
	ldur	x8, [x29, #-16]
	add	x0, x8, #20
	bl	_rd32
	str	w0, [sp, #40]
	ldur	x8, [x29, #-16]
	add	x0, x8, #24
	bl	_rd32
	str	w0, [sp, #44]
	ldur	x8, [x29, #-16]
	add	x0, x8, #28
	bl	_rd32
	str	w0, [sp, #48]
	ldur	x8, [x29, #-16]
	add	x0, x8, #32
	bl	_rd32
	str	w0, [sp, #52]
	ldur	x8, [x29, #-16]
	add	x0, x8, #36
	bl	_rd32
	str	w0, [sp, #56]
	ldrb	w8, [sp, #16]
	subs	w8, w8, #78
	b.ne	LBB1_13
	b	LBB1_10
LBB1_10:
	ldrb	w8, [sp, #17]
	subs	w8, w8, #86
	b.ne	LBB1_13
	b	LBB1_11
LBB1_11:
	ldrb	w8, [sp, #18]
	subs	w8, w8, #77
	b.ne	LBB1_13
	b	LBB1_12
LBB1_12:
	ldrb	w8, [sp, #19]
	subs	w8, w8, #2
	b.eq	LBB1_14
	b	LBB1_13
LBB1_13:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_14:
	ldrh	w8, [sp, #20]
	subs	w8, w8, #1
	b.eq	LBB1_16
	b	LBB1_15
LBB1_15:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_16:
	ldr	w8, [sp, #40]
	subs	w8, w8, #40
	b.eq	LBB1_18
	b	LBB1_17
LBB1_17:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_18:
	ldr	w8, [sp, #24]
	and	w8, w8, #0xfffffc00
	cbz	w8, LBB1_20
	b	LBB1_19
LBB1_19:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_20:
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.eq	LBB1_22
	b	LBB1_21
LBB1_21:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_22:
	ldr	w8, [sp, #52]
	cbz	w8, LBB1_24
	b	LBB1_23
LBB1_23:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB1_25
LBB1_24:
	ldur	x0, [x29, #-32]
	add	x1, sp, #16
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB1_25
LBB1_25:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rd16
_rd16:                                  ; @rd16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	and	w0, w8, #0xffff
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rd32
_rd32:                                  ; @rd32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rd64
_rd64:                                  ; @rd64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	xzr, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB4_1
LBB4_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #8
	b.ge	LBB4_4
	b	LBB4_2
LBB4_2:                                 ;   in Loop: Header=BB4_1 Depth=1
	ldr	x8, [sp, #24]
	ldrsw	x9, [sp, #12]
	ldrb	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #12]
	lsl	w9, w9, #3
                                        ; kill: def $x9 killed $w9
	lsl	x9, x8, x9
	ldr	x8, [sp, #16]
	orr	x8, x8, x9
	str	x8, [sp, #16]
	b	LBB4_3
LBB4_3:                                 ;   in Loop: Header=BB4_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB4_1
LBB4_4:
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_read_section            ; -- Begin function nvm_v2_read_section
	.p2align	2
_nvm_v2_read_section:                   ; @nvm_v2_read_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	w3, [sp, #28]
	str	x4, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #32]
	cbz	x8, LBB5_3
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB5_4
	b	LBB5_3
LBB5_3:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB5_14
LBB5_4:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.lo	LBB5_6
	b	LBB5_5
LBB5_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB5_14
LBB5_6:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #28]
	cbz	w8, LBB5_9
	b	LBB5_7
LBB5_7:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #28]
                                        ; kill: def $x9 killed $w9
	udiv	x8, x8, x9
	subs	x8, x8, #24
	b.eq	LBB5_9
	b	LBB5_8
LBB5_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB5_14
LBB5_9:
	ldur	x8, [x29, #-24]
	subs	x8, x8, #40
	b.hs	LBB5_11
	b	LBB5_10
LBB5_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB5_14
LBB5_11:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-24]
	subs	x9, x9, #40
	subs	x8, x8, x9
	b.ls	LBB5_13
	b	LBB5_12
LBB5_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB5_14
LBB5_13:
	ldur	x8, [x29, #-16]
	add	x10, x8, #40
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x0, [sp]
	bl	_rd32
	ldr	x8, [sp, #16]
	str	w0, [x8]
	ldr	x8, [sp]
	add	x0, x8, #4
	bl	_rd32
	ldr	x8, [sp, #16]
	str	w0, [x8, #4]
	ldr	x8, [sp]
	add	x0, x8, #8
	bl	_rd64
	ldr	x8, [sp, #16]
	str	x0, [x8, #8]
	ldr	x8, [sp]
	add	x0, x8, #16
	bl	_rd64
	ldr	x8, [sp, #16]
	str	x0, [x8, #16]
	stur	wzr, [x29, #-4]
	b	LBB5_14
LBB5_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_validate                ; -- Begin function nvm_v2_validate
	.p2align	2
_nvm_v2_validate:                       ; @nvm_v2_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	sub	x2, x29, #72
	bl	_nvm_v2_read_header
	stur	w0, [x29, #-76]
	ldur	w8, [x29, #-76]
	cbz	w8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldur	w8, [x29, #-76]
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_2:
	ldur	w8, [x29, #-44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	stur	x8, [x29, #-88]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB6_5
	b	LBB6_3
LBB6_3:
	ldur	x8, [x29, #-88]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	udiv	x8, x8, x9
	subs	x8, x8, #24
	b.eq	LBB6_5
	b	LBB6_4
LBB6_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_5:
	ldur	x8, [x29, #-88]
	ldur	x9, [x29, #-56]
	subs	x9, x9, #40
	subs	x8, x8, x9
	b.ls	LBB6_7
	b	LBB6_6
LBB6_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_7:
	ldur	x8, [x29, #-88]
	add	x8, x8, #40
	stur	x8, [x29, #-96]
	stur	xzr, [x29, #-104]
	stur	wzr, [x29, #-108]
	b	LBB6_8
LBB6_8:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-108]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB6_27
	b	LBB6_9
LBB6_9:                                 ;   in Loop: Header=BB6_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldur	w3, [x29, #-108]
	sub	x2, x29, #72
	add	x4, sp, #88
	bl	_nvm_v2_read_section
	stur	w0, [x29, #-76]
	ldur	w8, [x29, #-76]
	cbz	w8, LBB6_11
	b	LBB6_10
LBB6_10:
	ldur	w8, [x29, #-76]
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_11:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	w8, [sp, #92]
	cbz	w8, LBB6_13
	b	LBB6_12
LBB6_12:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_13:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	w8, [sp, #88]
	subs	w8, w8, #1
	b.lo	LBB6_15
	b	LBB6_14
LBB6_14:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	w8, [sp, #88]
	subs	w8, w8, #14
	b.ls	LBB6_16
	b	LBB6_15
LBB6_15:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_16:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	w8, [sp, #88]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x8, x8, x9
	str	x8, [sp, #80]
	ldur	x8, [x29, #-104]
	ldr	x9, [sp, #80]
	and	x8, x8, x9
	cbz	x8, LBB6_18
	b	LBB6_17
LBB6_17:
	mov	w8, #11                         ; =0xb
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_18:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	x9, [sp, #80]
	ldur	x8, [x29, #-104]
	orr	x8, x8, x9
	stur	x8, [x29, #-104]
	ldr	x8, [sp, #96]
	ldur	x9, [x29, #-56]
	subs	x8, x8, x9
	b.ls	LBB6_20
	b	LBB6_19
LBB6_19:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_20:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	x8, [sp, #104]
	ldur	x9, [x29, #-56]
	ldr	x10, [sp, #96]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB6_22
	b	LBB6_21
LBB6_21:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_22:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	x8, [sp, #104]
	cbz	x8, LBB6_25
	b	LBB6_23
LBB6_23:                                ;   in Loop: Header=BB6_8 Depth=1
	ldr	x8, [sp, #96]
	ldur	x9, [x29, #-96]
	subs	x8, x8, x9
	b.hs	LBB6_25
	b	LBB6_24
LBB6_24:
	mov	w8, #10                         ; =0xa
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_25:                                ;   in Loop: Header=BB6_8 Depth=1
	b	LBB6_26
LBB6_26:                                ;   in Loop: Header=BB6_8 Depth=1
	ldur	w8, [x29, #-108]
	add	w8, w8, #1
	stur	w8, [x29, #-108]
	b	LBB6_8
LBB6_27:
	str	wzr, [sp, #76]
	b	LBB6_28
LBB6_28:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_34 Depth 2
	ldr	w8, [sp, #76]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB6_50
	b	LBB6_29
LBB6_29:                                ;   in Loop: Header=BB6_28 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldr	w3, [sp, #76]
	sub	x2, x29, #72
	add	x4, sp, #48
	bl	_nvm_v2_read_section
	cbz	w0, LBB6_31
	b	LBB6_30
LBB6_30:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_31:                                ;   in Loop: Header=BB6_28 Depth=1
	ldr	x8, [sp, #64]
	cbnz	x8, LBB6_33
	b	LBB6_32
LBB6_32:                                ;   in Loop: Header=BB6_28 Depth=1
	b	LBB6_49
LBB6_33:                                ;   in Loop: Header=BB6_28 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB6_34
LBB6_34:                                ;   Parent Loop BB6_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #44]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB6_48
	b	LBB6_35
LBB6_35:                                ;   in Loop: Header=BB6_34 Depth=2
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldr	w3, [sp, #44]
	sub	x2, x29, #72
	add	x4, sp, #16
	bl	_nvm_v2_read_section
	cbz	w0, LBB6_37
	b	LBB6_36
LBB6_36:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_37:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	x8, [sp, #32]
	cbnz	x8, LBB6_39
	b	LBB6_38
LBB6_38:                                ;   in Loop: Header=BB6_34 Depth=2
	b	LBB6_47
LBB6_39:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.lo	LBB6_41
	b	LBB6_40
LBB6_40:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #24]
	subs	x9, x8, x9
	ldr	x10, [sp, #32]
	mov	w8, #1                          ; =0x1
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB6_44
	b	LBB6_41
LBB6_41:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	x9, [sp, #24]
	ldr	x10, [sp, #56]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.lo	LBB6_43
	b	LBB6_42
LBB6_42:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #56]
	subs	x8, x8, x9
	ldr	x9, [sp, #64]
	subs	x8, x8, x9
	cset	w8, hs
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB6_43
LBB6_43:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_44
LBB6_44:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #15]
	ldrb	w8, [sp, #15]
	tbnz	w8, #0, LBB6_46
	b	LBB6_45
LBB6_45:
	mov	w8, #10                         ; =0xa
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_46:                                ;   in Loop: Header=BB6_34 Depth=2
	b	LBB6_47
LBB6_47:                                ;   in Loop: Header=BB6_34 Depth=2
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB6_34
LBB6_48:                                ;   in Loop: Header=BB6_28 Depth=1
	b	LBB6_49
LBB6_49:                                ;   in Loop: Header=BB6_28 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB6_28
LBB6_50:
	ldur	x8, [x29, #-16]
	add	x0, x8, #40
	ldur	x8, [x29, #-56]
	subs	x8, x8, #40
	mov	x1, x8
	bl	_nvm_crc32
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.eq	LBB6_52
	b	LBB6_51
LBB6_51:
	mov	w8, #12                         ; =0xc
	stur	w8, [x29, #-4]
	b	LBB6_53
LBB6_52:
	stur	wzr, [x29, #-4]
	b	LBB6_53
LBB6_53:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_write_header            ; -- Begin function nvm_v2_write_header
	.p2align	2
_nvm_v2_write_header:                   ; @nvm_v2_write_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB7_3
	b	LBB7_2
LBB7_2:
	b	LBB7_8
LBB7_3:
	str	wzr, [sp, #12]
	b	LBB7_4
LBB7_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #4
	b.ge	LBB7_7
	b	LBB7_5
LBB7_5:                                 ;   in Loop: Header=BB7_4 Depth=1
	ldr	x8, [sp, #16]
	ldrsw	x9, [sp, #12]
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldur	x9, [x29, #-8]
	ldr	w10, [sp, #12]
	add	w10, w10, #0
	add	x9, x9, w10, sxtw
	strb	w8, [x9]
	b	LBB7_6
LBB7_6:                                 ;   in Loop: Header=BB7_4 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB7_4
LBB7_7:
	ldur	x8, [x29, #-8]
	add	x0, x8, #4
	ldr	x8, [sp, #16]
	ldrh	w1, [x8, #4]
	bl	_wr16
	ldur	x8, [x29, #-8]
	add	x0, x8, #6
	ldr	x8, [sp, #16]
	ldrh	w1, [x8, #6]
	bl	_wr16
	ldur	x8, [x29, #-8]
	add	x0, x8, #8
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #8]
	bl	_wr32
	ldur	x8, [x29, #-8]
	add	x0, x8, #12
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #16]
	bl	_wr64
	ldur	x8, [x29, #-8]
	add	x0, x8, #20
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #24]
	bl	_wr32
	ldur	x8, [x29, #-8]
	add	x0, x8, #24
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #28]
	bl	_wr32
	ldur	x8, [x29, #-8]
	add	x0, x8, #28
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #32]
	bl	_wr32
	ldur	x8, [x29, #-8]
	add	x0, x8, #32
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #36]
	bl	_wr32
	ldur	x8, [x29, #-8]
	add	x0, x8, #36
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #40]
	bl	_wr32
	b	LBB7_8
LBB7_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wr16
_wr16:                                  ; @wr16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldrh	w8, [sp, #6]
	asr	w8, w8, #8
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wr32
_wr32:                                  ; @wr32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #8
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #16
	ldr	x9, [sp, #8]
	strb	w8, [x9, #2]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #24
	ldr	x9, [sp, #8]
	strb	w8, [x9, #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wr64
_wr64:                                  ; @wr64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB10_1
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #8
	b.ge	LBB10_4
	b	LBB10_2
LBB10_2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #12]
	lsl	w9, w9, #3
                                        ; kill: def $x9 killed $w9
	lsr	x8, x8, x9
	ldr	x9, [sp, #24]
	ldrsw	x10, [sp, #12]
                                        ; kill: def $w8 killed $w8 killed $x8
	strb	w8, [x9, x10]
	b	LBB10_3
LBB10_3:                                ;   in Loop: Header=BB10_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB10_1
LBB10_4:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_write_section           ; -- Begin function nvm_v2_write_section
	.p2align	2
_nvm_v2_write_section:                  ; @nvm_v2_write_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp, #8]
	cbz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp]
	cbnz	x8, LBB11_3
	b	LBB11_2
LBB11_2:
	b	LBB11_4
LBB11_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp]
	ldr	w1, [x8]
	bl	_wr32
	ldr	x8, [sp, #8]
	add	x0, x8, #4
	ldr	x8, [sp]
	ldr	w1, [x8, #4]
	bl	_wr32
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	bl	_wr64
	ldr	x8, [sp, #8]
	add	x0, x8, #16
	ldr	x8, [sp]
	ldr	x1, [x8, #16]
	bl	_wr64
	b	LBB11_4
LBB11_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"ok"

l_.str.1:                               ; @.str.1
	.asciz	"truncated"

l_.str.2:                               ; @.str.2
	.asciz	"bad-magic"

l_.str.3:                               ; @.str.3
	.asciz	"unsupported-format-version"

l_.str.4:                               ; @.str.4
	.asciz	"bad-header-size"

l_.str.5:                               ; @.str.5
	.asciz	"unknown-feature-bit"

l_.str.6:                               ; @.str.6
	.asciz	"total-size-mismatch"

l_.str.7:                               ; @.str.7
	.asciz	"reserved-flags-set"

l_.str.8:                               ; @.str.8
	.asciz	"unknown-section-type"

l_.str.9:                               ; @.str.9
	.asciz	"section-out-of-range"

l_.str.10:                              ; @.str.10
	.asciz	"section-overlap"

l_.str.11:                              ; @.str.11
	.asciz	"duplicate-section"

l_.str.12:                              ; @.str.12
	.asciz	"checksum-mismatch"

l_.str.13:                              ; @.str.13
	.asciz	"index-out-of-range"

l_.str.14:                              ; @.str.14
	.asciz	"feature-bits-mismatch"

l_.str.15:                              ; @.str.15
	.asciz	"unknown"

.subsections_via_symbols
