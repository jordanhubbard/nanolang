	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_reference_place_valid      ; -- Begin function nvm_reference_place_valid
	.p2align	2
_nvm_reference_place_valid:             ; @nvm_reference_place_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x0, [x29, #-32]
	bl	_descriptor_valid
	tbz	w0, #0, LBB0_5
	b	LBB0_1
LBB0_1:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB0_5
	b	LBB0_2
LBB0_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	cbz	x8, LBB0_5
	b	LBB0_3
LBB0_3:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB0_5
	b	LBB0_4
LBB0_4:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB0_6
	b	LBB0_5
LBB0_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_6:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_scalar_root
	tbnz	w0, #0, LBB0_8
	b	LBB0_7
LBB0_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_8:
	ldur	w8, [x29, #-20]
	stur	w8, [x29, #-36]
	sturh	wzr, [x29, #-38]
	b	LBB0_9
LBB0_9:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-38]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.ge	LBB0_18
	b	LBB0_10
LBB0_10:                                ;   in Loop: Header=BB0_9 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #32]
	ldr	x0, [sp, #32]
	bl	_record_valid
	tbz	w0, #0, LBB0_12
	b	LBB0_11
LBB0_11:                                ;   in Loop: Header=BB0_9 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-38]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB0_13
	b	LBB0_12
LBB0_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_13:                                ;   in Loop: Header=BB0_9 Depth=1
	ldr	x8, [sp, #32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-38]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB0_15
	b	LBB0_14
LBB0_14:                                ;   in Loop: Header=BB0_9 Depth=1
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.lo	LBB0_16
	b	LBB0_15
LBB0_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_16:                                ;   in Loop: Header=BB0_9 Depth=1
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #4]
	stur	w8, [x29, #-36]
	b	LBB0_17
LBB0_17:                                ;   in Loop: Header=BB0_9 Depth=1
	ldurh	w8, [x29, #-38]
	add	w8, w8, #1
	sturh	w8, [x29, #-38]
	b	LBB0_9
LBB0_18:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.eq	LBB0_20
	b	LBB0_19
LBB0_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_20:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_record_valid
	tbnz	w0, #0, LBB0_22
	b	LBB0_21
LBB0_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_22:
	strh	wzr, [sp, #14]
	b	LBB0_23
LBB0_23:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB0_29
	b	LBB0_24
LBB0_24:                                ;   in Loop: Header=BB0_23 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w0, [x8]
	bl	_scalar
	tbz	w0, #0, LBB0_26
	b	LBB0_25
LBB0_25:                                ;   in Loop: Header=BB0_23 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB0_27
	b	LBB0_26
LBB0_26:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_27:                                ;   in Loop: Header=BB0_23 Depth=1
	b	LBB0_28
LBB0_28:                                ;   in Loop: Header=BB0_23 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB0_23
LBB0_29:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_30
LBB0_30:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor_valid
_descriptor_valid:                      ; @descriptor_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB1_7
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB1_7
	b	LBB1_2
LBB1_2:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #24]
	cbz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB1_7
	b	LBB1_4
LBB1_4:
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #32]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB1_6
	b	LBB1_5
LBB1_5:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #32]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB1_6
LBB1_6:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB1_7
LBB1_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar_root
_scalar_root:                           ; @scalar_root
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-32]
	ldur	x0, [x29, #-32]
	bl	_record_valid
	tbnz	w0, #0, LBB2_2
	b	LBB2_1
LBB2_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_33
LBB2_2:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-33]
	sturh	wzr, [x29, #-36]
	b	LBB2_3
LBB2_3:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB2_9
	b	LBB2_4
LBB2_4:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldrb	w0, [x8]
	bl	_scalar
	tbz	w0, #0, LBB2_6
	b	LBB2_5
LBB2_5:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB2_7
	b	LBB2_6
LBB2_6:
	sturb	wzr, [x29, #-33]
	b	LBB2_9
LBB2_7:                                 ;   in Loop: Header=BB2_3 Depth=1
	b	LBB2_8
LBB2_8:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldurh	w8, [x29, #-36]
	add	w8, w8, #1
	sturh	w8, [x29, #-36]
	b	LBB2_3
LBB2_9:
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB2_11
	b	LBB2_10
LBB2_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_33
LBB2_11:
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x1, #1                          ; =0x1
	add	x0, x8, #1
	bl	_calloc
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbnz	x8, LBB2_13
	b	LBB2_12
LBB2_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_33
LBB2_13:
	ldr	x8, [sp, #56]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	strb	w8, [sp, #55]
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB2_14
LBB2_14:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_22 Depth 2
	ldr	w8, [sp, #48]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	w8, LBB2_16
	b	LBB2_15
LBB2_15:                                ;   in Loop: Header=BB2_14 Depth=1
	ldrb	w8, [sp, #55]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_16
LBB2_16:                                ;   in Loop: Header=BB2_14 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB2_32
	b	LBB2_17
LBB2_17:                                ;   in Loop: Header=BB2_14 Depth=1
	ldr	w8, [sp, #48]
	subs	w8, w8, #1
	str	w8, [sp, #48]
	str	w8, [sp, #44]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbnz	w8, LBB2_19
	b	LBB2_18
LBB2_18:                                ;   in Loop: Header=BB2_14 Depth=1
	b	LBB2_14
LBB2_19:                                ;   in Loop: Header=BB2_14 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #32]
	ldr	x0, [sp, #32]
	bl	_record_valid
	tbnz	w0, #0, LBB2_21
	b	LBB2_20
LBB2_20:
	strb	wzr, [sp, #55]
	b	LBB2_32
LBB2_21:                                ;   in Loop: Header=BB2_14 Depth=1
	strh	wzr, [sp, #30]
	b	LBB2_22
LBB2_22:                                ;   Parent Loop BB2_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB2_31
	b	LBB2_23
LBB2_23:                                ;   in Loop: Header=BB2_22 Depth=2
	ldr	x8, [sp, #32]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w0, [x8]
	bl	_scalar
	tbz	w0, #0, LBB2_26
	b	LBB2_24
LBB2_24:                                ;   in Loop: Header=BB2_22 Depth=2
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.ne	LBB2_26
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_22 Depth=2
	b	LBB2_30
LBB2_26:                                ;   in Loop: Header=BB2_22 Depth=2
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB2_28
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_22 Depth=2
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.lo	LBB2_29
	b	LBB2_28
LBB2_28:                                ;   in Loop: Header=BB2_14 Depth=1
	strb	wzr, [sp, #55]
	b	LBB2_31
LBB2_29:                                ;   in Loop: Header=BB2_22 Depth=2
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_22 Depth=2
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB2_22
LBB2_31:                                ;   in Loop: Header=BB2_14 Depth=1
	b	LBB2_14
LBB2_32:
	ldr	x0, [sp, #56]
	bl	_free
	ldrb	w8, [sp, #55]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_33
LBB2_33:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_valid
_record_valid:                          ; @record_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	w8, LBB3_4
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	mov	w9, #1                          ; =0x1
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	w8, LBB3_3
	b	LBB3_2
LBB3_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB3_3
LBB3_3:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB3_4
LBB3_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_4
	b	LBB4_1
LBB4_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_4
	b	LBB4_2
LBB4_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_4
	b	LBB4_3
LBB4_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_4
LBB4_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_reference_places_overlap   ; -- Begin function nvm_reference_places_overlap
	.p2align	2
_nvm_reference_places_overlap:          ; @nvm_reference_places_overlap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_descriptor_valid
	tbz	w0, #0, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x0, [sp, #8]
	bl	_descriptor_valid
	tbnz	w0, #0, LBB5_3
	b	LBB5_2
LBB5_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_16
LBB5_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB5_5
	b	LBB5_4
LBB5_4:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB5_6
	b	LBB5_5
LBB5_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_16
LBB5_6:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #24]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.ge	LBB5_8
	b	LBB5_7
LBB5_7:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #24]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB5_9
LBB5_8:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #24]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB5_9
LBB5_9:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	strh	w8, [sp, #6]
	strh	wzr, [sp, #4]
	b	LBB5_10
LBB5_10:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #4]
	ldrh	w9, [sp, #6]
	subs	w8, w8, w9
	b.ge	LBB5_15
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_10 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #16]
	ldrh	w10, [sp, #4]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.eq	LBB5_13
	b	LBB5_12
LBB5_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_16
LBB5_13:                                ;   in Loop: Header=BB5_10 Depth=1
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_10 Depth=1
	ldrh	w8, [sp, #4]
	add	w8, w8, #1
	strh	w8, [sp, #4]
	b	LBB5_10
LBB5_15:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_16
LBB5_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_reference_holds_conflict   ; -- Begin function nvm_reference_holds_conflict
	.p2align	2
_nvm_reference_holds_conflict:          ; @nvm_reference_holds_conflict
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_descriptor_valid
	tbz	w0, #0, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x0, [sp, #8]
	bl	_descriptor_valid
	tbnz	w0, #0, LBB6_3
	b	LBB6_2
LBB6_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_7
LBB6_3:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #32]
	subs	w8, w8, #2
	b.eq	LBB6_5
	b	LBB6_4
LBB6_4:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #32]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #2
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB6_6
	b	LBB6_5
LBB6_5:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_nvm_reference_places_overlap
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_6
LBB6_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_7
LBB6_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_reference_owner_access_conflicts ; -- Begin function nvm_reference_owner_access_conflicts
	.p2align	2
_nvm_reference_owner_access_conflicts:  ; @nvm_reference_owner_access_conflicts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	strb	w2, [sp, #7]
	ldr	x0, [sp, #16]
	bl	_descriptor_valid
	tbz	w0, #0, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x0, [sp, #8]
	bl	_descriptor_valid
	tbnz	w0, #0, LBB7_3
	b	LBB7_2
LBB7_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_7
LBB7_3:
	ldrb	w8, [sp, #7]
	tbnz	w8, #0, LBB7_5
	b	LBB7_4
LBB7_4:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #32]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #2
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB7_6
	b	LBB7_5
LBB7_5:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_nvm_reference_places_overlap
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB7_6
LBB7_6:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_7
LBB7_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
