	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_signature_equal         ; -- Begin function nvm_v2_signature_equal
	.p2align	2
_nvm_v2_signature_equal:                ; @nvm_v2_signature_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_11
LBB0_2:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.eq	LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_11
LBB0_4:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	cbz	w8, LBB0_7
	b	LBB0_5
LBB0_5:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	mov	x2, x8
	bl	_memcmp
	cbz	w0, LBB0_7
	b	LBB0_6
LBB0_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_11
LBB0_7:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB0_10
	b	LBB0_8
LBB0_8:
	ldr	x8, [sp, #16]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #16]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	mov	x2, x8
	bl	_memcmp
	cbz	w0, LBB0_10
	b	LBB0_9
LBB0_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_11
LBB0_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_11
LBB0_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_signatures_decode       ; -- Begin function nvm_v2_signatures_decode
	.p2align	2
_nvm_v2_signatures_decode:              ; @nvm_v2_signatures_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #8]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-24]
	add	x0, sp, #56
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, sp, #52
	bl	_nvm_v2_u32
	str	w0, [sp, #48]
	ldr	w8, [sp, #48]
	cbz	w8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB1_22
LBB1_2:
	ldr	w8, [sp, #52]
	cbnz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	stur	wzr, [x29, #-4]
	b	LBB1_22
LBB1_4:
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #72]
	subs	x9, x9, x10
	mov	x10, #4                         ; =0x4
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_6
	b	LBB1_5
LBB1_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_22
LBB1_6:
	ldr	w8, [sp, #52]
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB1_8
	b	LBB1_7
LBB1_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_22
LBB1_8:
	str	wzr, [sp, #36]
	b	LBB1_9
LBB1_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #52]
	subs	w8, w8, w9
	b.hs	LBB1_20
	b	LBB1_10
LBB1_10:                                ;   in Loop: Header=BB1_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #34
	bl	_nvm_v2_u16
	str	w0, [sp, #48]
	cbz	w0, LBB1_12
	b	LBB1_11
LBB1_11:
	b	LBB1_21
LBB1_12:                                ;   in Loop: Header=BB1_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #32
	bl	_nvm_v2_u16
	str	w0, [sp, #48]
	cbz	w0, LBB1_14
	b	LBB1_13
LBB1_13:
	b	LBB1_21
LBB1_14:                                ;   in Loop: Header=BB1_9 Depth=1
	add	x2, sp, #24
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	ldrh	w1, [sp, #34]
	add	x0, sp, #56
	bl	_take_tags
	str	w0, [sp, #48]
	cbz	w0, LBB1_16
	b	LBB1_15
LBB1_15:
	b	LBB1_21
LBB1_16:                                ;   in Loop: Header=BB1_9 Depth=1
	ldrh	w1, [sp, #32]
	add	x0, sp, #56
	add	x2, sp, #16
	bl	_take_tags
	str	w0, [sp, #48]
	cbz	w0, LBB1_18
	b	LBB1_17
LBB1_17:
	b	LBB1_21
LBB1_18:                                ;   in Loop: Header=BB1_9 Depth=1
	ldrh	w8, [sp, #34]
	ldr	x12, [sp, #40]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	strh	w8, [x9]
	ldrh	w8, [sp, #32]
	ldr	x12, [sp, #40]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	strh	w8, [x9, #2]
	ldr	x8, [sp, #24]
	ldr	x12, [sp, #40]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	str	x8, [x9, #8]
	ldr	x8, [sp, #16]
	ldr	x11, [sp, #40]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x8, [x9, #16]
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_9 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB1_9
LBB1_20:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #8]
	stur	wzr, [x29, #-4]
	b	LBB1_22
LBB1_21:
	ldr	x0, [sp, #40]
	bl	_free
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB1_22
LBB1_22:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function take_tags
_take_tags:                             ; @take_tags
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	x2, [sp, #32]
	add	x2, sp, #24
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	ldur	x0, [x29, #-16]
	ldurh	w8, [x29, #-18]
	mov	x1, x8
	bl	_nvm_v2_take
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB2_14
LBB2_2:
	strh	wzr, [sp, #18]
	b	LBB2_3
LBB2_3:                                 ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #18]
	ldurh	w9, [x29, #-18]
	subs	w8, w8, w9
	b.ge	LBB2_8
	b	LBB2_4
LBB2_4:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [sp, #24]
	ldrh	w9, [sp, #18]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #16
	b.lt	LBB2_6
	b	LBB2_5
LBB2_5:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB2_14
LBB2_6:                                 ;   in Loop: Header=BB2_3 Depth=1
	b	LBB2_7
LBB2_7:                                 ;   in Loop: Header=BB2_3 Depth=1
	ldrh	w8, [sp, #18]
	add	w8, w8, #1
	strh	w8, [sp, #18]
	b	LBB2_3
LBB2_8:
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_align4
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB2_10
	b	LBB2_9
LBB2_9:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB2_14
LBB2_10:
	ldurh	w8, [x29, #-18]
	cbz	w8, LBB2_12
	b	LBB2_11
LBB2_11:
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB2_13
LBB2_12:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB2_13
LBB2_13:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB2_14
LBB2_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_signatures_free         ; -- Begin function nvm_v2_signatures_free
	.p2align	2
_nvm_v2_signatures_free:                ; @nvm_v2_signatures_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	b	LBB3_3
LBB3_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #8]
	b	LBB3_3
LBB3_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_signatures_encoded_size ; -- Begin function nvm_v2_signatures_encoded_size
	.p2align	2
_nvm_v2_signatures_encoded_size:        ; @nvm_v2_signatures_encoded_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	mov	x8, #4                          ; =0x4
	stur	x8, [x29, #-16]
	stur	wzr, [x29, #-20]
	b	LBB4_1
LBB4_1:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB4_4
	b	LBB4_2
LBB4_2:                                 ;   in Loop: Header=BB4_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrh	w8, [x8, x9]
	mov	x0, x8
	bl	_padded
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x0, #4
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	ldr	x10, [x8]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	mov	x0, x8
	bl	_padded
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x9, x8, x0
	ldur	x8, [x29, #-16]
	add	x8, x8, x9
	stur	x8, [x29, #-16]
	b	LBB4_3
LBB4_3:                                 ;   in Loop: Header=BB4_1 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB4_1
LBB4_4:
	ldur	x0, [x29, #-16]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function padded
_padded:                                ; @padded
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x8, x8, #3
	and	x0, x8, #0xfffffffffffffffc
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_signatures_encode       ; -- Begin function nvm_v2_signatures_encode
	.p2align	2
_nvm_v2_signatures_encode:              ; @nvm_v2_signatures_encode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_signatures_encoded_size
	str	x0, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB6_2
	b	LBB6_1
LBB6_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB6_11
LBB6_2:
	ldur	x0, [x29, #-24]
	ldr	x2, [sp, #24]
	mov	w1, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #16
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #24
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	str	wzr, [sp, #12]
	b	LBB6_3
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB6_10
	b	LBB6_4
LBB6_4:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x11, [x8]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrh	w8, [x8]
	strh	w8, [sp, #10]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	strh	w8, [sp, #8]
	ldrh	w8, [sp, #10]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	add	x9, x9, x10
	strb	w8, [x9]
	ldrh	w8, [sp, #10]
	asr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldrh	w8, [sp, #8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	add	x9, x9, x10
	strb	w8, [x9]
	ldrh	w8, [sp, #8]
	asr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldrh	w8, [sp, #10]
	cbz	w8, LBB6_6
	b	LBB6_5
LBB6_5:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #16]
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #8]
	ldrh	w8, [sp, #10]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB6_6
LBB6_6:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldrh	w8, [sp, #10]
	mov	x0, x8
	bl	_padded
	ldr	x8, [sp, #16]
	add	x8, x8, x0
	str	x8, [sp, #16]
	ldrh	w8, [sp, #8]
	cbz	w8, LBB6_8
	b	LBB6_7
LBB6_7:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #16]
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #16]
	ldrh	w8, [sp, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB6_8
LBB6_8:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldrh	w8, [sp, #8]
	mov	x0, x8
	bl	_padded
	ldr	x8, [sp, #16]
	add	x8, x8, x0
	str	x8, [sp, #16]
	b	LBB6_9
LBB6_9:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB6_3
LBB6_10:
	stur	wzr, [x29, #-4]
	b	LBB6_11
LBB6_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
