	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_mixed_samples_plan_free ; -- Begin function nvm_mixed_samples_plan_free
	.globl	_nvm_mixed_samples_plan_free
	.p2align	2
_nvm_mixed_samples_plan_free:           ; @nvm_mixed_samples_plan_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_mixed_samples_proof_free
	ldr	x0, [x19, #25552]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_mixed_samples_prepare
lCPI1_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI1_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI1_2:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_mixed_samples_prepare
	.globl	_nvm_mixed_samples_prepare
	.p2align	2
_nvm_mixed_samples_prepare:             ; @nvm_mixed_samples_prepare
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #816
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cbz	x1, LBB1_3
; %bb.1:
	mov	x20, x0
	mov	x23, x1
	bl	_nvm_service_execution_pending
	cbz	w0, LBB1_4
; %bb.2:
Lloh3:
	adrp	x8, lCPI1_2@PAGE
Lloh4:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [x19]
Lloh5:
	adrp	x8, l_.str.1@PAGE
Lloh6:
	add	x8, x8, l_.str.1@PAGEOFF
	b	LBB1_42
LBB1_3:
Lloh7:
	adrp	x8, lCPI1_0@PAGE
Lloh8:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [x19]
Lloh9:
	adrp	x8, l_.str@PAGE
Lloh10:
	add	x8, x8, l_.str@PAGEOFF
	b	LBB1_42
LBB1_4:
	str	xzr, [sp, #24]
	mov	x8, sp
	add	x1, sp, #24
	mov	x0, x20
	bl	_nvm_analyze_mixed_samples
	ldr	w8, [sp]
	cbz	w8, LBB1_6
; %bb.5:
	ldr	q0, [sp]
	str	q0, [x19]
	ldr	x8, [sp, #16]
	b	LBB1_42
LBB1_6:
	ldr	x0, [sp, #24]
	ldr	x8, [x0]
	ldr	x11, [x8]
	ldr	w10, [x11, #8]
	cbz	w10, LBB1_9
; %bb.7:
	cmp	w10, #7
	b.hi	LBB1_10
; %bb.8:
	mov	x12, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	b	LBB1_19
LBB1_9:
	mov	w9, #0                          ; =0x0
	b	LBB1_21
LBB1_10:
	cmp	w10, #64
	b.hs	LBB1_12
; %bb.11:
	mov	x12, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	b	LBB1_16
LBB1_12:
	and	x12, x10, #0xffffffc0
	mov	w9, #4312                       ; =0x10d8
	add	x9, x11, x9
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #1
	mov	x13, x12
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB1_13:                                ; =>This Inner Loop Header: Depth=1
	ldp	q5, q6, [x9, #-192]
	ldp	q7, q16, [x9, #-160]
	ldp	q17, q18, [x9, #-128]
	ldp	q19, q20, [x9, #-96]
	ldp	q21, q22, [x9, #-64]
	ldp	q23, q24, [x9, #-32]
	ldp	q25, q26, [x9]
	cmeq.4s	v16, v16, v1
	cmeq.4s	v7, v7, v1
	uzp1.8h	v7, v7, v16
	cmeq.4s	v6, v6, v1
	cmeq.4s	v5, v5, v1
	ldp	q16, q27, [x9, #32]
	uzp1.8h	v5, v5, v6
	uzp1.16b	v5, v5, v7
	cmeq.4s	v6, v20, v1
	cmeq.4s	v7, v19, v1
	uzp1.8h	v6, v7, v6
	cmeq.4s	v7, v18, v1
	cmeq.4s	v17, v17, v1
	uzp1.8h	v7, v17, v7
	uzp1.16b	v6, v7, v6
	cmeq.4s	v7, v24, v1
	cmeq.4s	v17, v23, v1
	uzp1.8h	v7, v17, v7
	cmeq.4s	v17, v22, v1
	cmeq.4s	v18, v21, v1
	uzp1.8h	v17, v18, v17
	uzp1.16b	v7, v17, v7
	cmeq.4s	v17, v27, v1
	cmeq.4s	v16, v16, v1
	uzp1.8h	v16, v16, v17
	cmeq.4s	v17, v26, v1
	cmeq.4s	v18, v25, v1
	uzp1.8h	v17, v18, v17
	uzp1.16b	v16, v17, v16
	orr.16b	v0, v0, v5
	orr.16b	v2, v2, v6
	orr.16b	v3, v3, v7
	orr.16b	v4, v4, v16
	add	x9, x9, #256
	subs	x13, x13, #64
	b.ne	LBB1_13
; %bb.14:
	orr.16b	v0, v2, v0
	orr.16b	v0, v3, v0
	orr.16b	v0, v4, v0
	shl.16b	v0, v0, #7
	cmlt.16b	v0, v0, #0
	umaxv.16b	b0, v0
	fmov	w9, s0
	and	w9, w9, #0x1
	cmp	x12, x10
	b.eq	LBB1_21
; %bb.15:
	tst	x10, #0x38
	b.eq	LBB1_19
LBB1_16:
	mov	x13, x12
	movi.2d	v0, #0000000000000000
	mov.b	v0[0], w9
	and	x12, x10, #0xfffffff8
	sub	x9, x13, x12
	add	x13, x11, x13, lsl #2
	mov	w14, #4120                      ; =0x1018
	add	x13, x13, x14
	movi.4s	v1, #1
LBB1_17:                                ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x13], #32
	cmeq.4s	v3, v3, v1
	cmeq.4s	v2, v2, v1
	uzp1.8h	v2, v2, v3
	xtn.8b	v2, v2
	orr.8b	v0, v0, v2
	adds	x9, x9, #8
	b.ne	LBB1_17
; %bb.18:
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w9, s0
	and	w9, w9, #0x1
	cmp	x12, x10
	b.eq	LBB1_21
LBB1_19:
	add	x11, x11, x12, lsl #2
	mov	w13, #4120                      ; =0x1018
	add	x11, x11, x13
	sub	x10, x10, x12
LBB1_20:                                ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x11], #4
	cmp	w12, #1
	cset	w12, eq
	orr	w9, w9, w12
	subs	x10, x10, #1
	b.ne	LBB1_20
LBB1_21:
	ldr	w10, [x8, #8]
	cbz	w10, LBB1_41
; %bb.22:
	cmp	w10, #7
	b.hi	LBB1_24
; %bb.23:
	mov	x11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	b	LBB1_33
LBB1_24:
	cmp	w10, #64
	b.hs	LBB1_26
; %bb.25:
	mov	x11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	b	LBB1_30
LBB1_26:
	mov	x12, #0                         ; =0x0
	and	x11, x10, #0xffffffc0
	lsr	x13, x10, #6
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #9
	movi.2d	v0, #0000000000000000
	movi.16b	v1, #7
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB1_27:                                ; =>This Inner Loop Header: Depth=1
	add	x14, x8, x12
	add	x15, x14, #74
	ldr	b5, [x14, #50]
	ld1.b	{ v5 }[1], [x15]
	add	x15, x14, #98
	ld1.b	{ v5 }[2], [x15]
	add	x15, x14, #122
	ld1.b	{ v5 }[3], [x15]
	add	x15, x14, #146
	ld1.b	{ v5 }[4], [x15]
	add	x15, x14, #170
	ld1.b	{ v5 }[5], [x15]
	add	x15, x14, #194
	ld1.b	{ v5 }[6], [x15]
	add	x15, x14, #218
	ld1.b	{ v5 }[7], [x15]
	add	x15, x14, #266
	ldur	b6, [x14, #242]
	ld1.b	{ v6 }[1], [x15]
	add	x15, x14, #290
	ld1.b	{ v6 }[2], [x15]
	add	x15, x14, #314
	ld1.b	{ v6 }[3], [x15]
	add	x15, x14, #338
	ld1.b	{ v6 }[4], [x15]
	add	x15, x14, #362
	ld1.b	{ v6 }[5], [x15]
	add	x15, x14, #386
	ld1.b	{ v6 }[6], [x15]
	add	x15, x14, #410
	ld1.b	{ v6 }[7], [x15]
	add	x15, x14, #458
	ldr	b7, [x14, #434]
	ld1.b	{ v7 }[1], [x15]
	add	x15, x14, #482
	ld1.b	{ v7 }[2], [x15]
	add	x15, x14, #506
	ld1.b	{ v7 }[3], [x15]
	add	x15, x14, #530
	ld1.b	{ v7 }[4], [x15]
	add	x15, x14, #554
	ld1.b	{ v7 }[5], [x15]
	add	x15, x14, #578
	ld1.b	{ v7 }[6], [x15]
	add	x15, x14, #602
	ld1.b	{ v7 }[7], [x15]
	add	x15, x14, #650
	ldr	b16, [x14, #626]
	ld1.b	{ v16 }[1], [x15]
	add	x15, x14, #674
	ld1.b	{ v16 }[2], [x15]
	add	x15, x14, #698
	ld1.b	{ v16 }[3], [x15]
	add	x15, x14, #722
	ld1.b	{ v16 }[4], [x15]
	add	x15, x14, #746
	ld1.b	{ v16 }[5], [x15]
	add	x15, x14, #770
	ld1.b	{ v16 }[6], [x15]
	add	x15, x14, #794
	ld1.b	{ v16 }[7], [x15]
	add	x15, x14, #842
	ldr	b17, [x14, #818]
	ld1.b	{ v17 }[1], [x15]
	add	x15, x14, #866
	ld1.b	{ v17 }[2], [x15]
	add	x15, x14, #890
	ld1.b	{ v17 }[3], [x15]
	add	x15, x14, #914
	ld1.b	{ v17 }[4], [x15]
	add	x15, x14, #938
	ld1.b	{ v17 }[5], [x15]
	add	x15, x14, #962
	ld1.b	{ v17 }[6], [x15]
	add	x15, x14, #986
	ld1.b	{ v17 }[7], [x15]
	add	x15, x14, #1034
	ldr	b18, [x14, #1010]
	ld1.b	{ v18 }[1], [x15]
	add	x15, x14, #1058
	ld1.b	{ v18 }[2], [x15]
	add	x15, x14, #1082
	ld1.b	{ v18 }[3], [x15]
	add	x15, x14, #1106
	ld1.b	{ v18 }[4], [x15]
	add	x15, x14, #1130
	ld1.b	{ v18 }[5], [x15]
	add	x15, x14, #1154
	ld1.b	{ v18 }[6], [x15]
	add	x15, x14, #1178
	ld1.b	{ v18 }[7], [x15]
	add	x15, x14, #1226
	ldr	b19, [x14, #1202]
	ld1.b	{ v19 }[1], [x15]
	add	x15, x14, #1250
	ld1.b	{ v19 }[2], [x15]
	add	x15, x14, #1274
	ld1.b	{ v19 }[3], [x15]
	add	x15, x14, #1298
	ld1.b	{ v19 }[4], [x15]
	add	x15, x14, #1322
	ld1.b	{ v19 }[5], [x15]
	add	x15, x14, #1346
	ld1.b	{ v19 }[6], [x15]
	add	x15, x14, #1370
	ld1.b	{ v19 }[7], [x15]
	add	x15, x14, #1418
	ldr	b20, [x14, #1394]
	ld1.b	{ v20 }[1], [x15]
	add	x15, x14, #1442
	ld1.b	{ v20 }[2], [x15]
	add	x15, x14, #1466
	ld1.b	{ v20 }[3], [x15]
	add	x15, x14, #1490
	ld1.b	{ v20 }[4], [x15]
	add	x15, x14, #1514
	ld1.b	{ v20 }[5], [x15]
	add	x15, x14, #1538
	ld1.b	{ v20 }[6], [x15]
	add	x14, x14, #1562
	ld1.b	{ v20 }[7], [x14]
	zip1.2d	v5, v5, v6
	zip1.2d	v6, v7, v16
	zip1.2d	v7, v17, v18
	zip1.2d	v16, v19, v20
	cmeq.16b	v5, v5, v1
	cmeq.16b	v6, v6, v1
	cmeq.16b	v7, v7, v1
	cmeq.16b	v16, v16, v1
	orr.16b	v0, v0, v5
	orr.16b	v2, v2, v6
	orr.16b	v3, v3, v7
	orr.16b	v4, v4, v16
	add	x12, x12, #1536
	cmp	x13, x12
	b.ne	LBB1_27
; %bb.28:
	orr.16b	v0, v2, v0
	orr.16b	v0, v3, v0
	orr.16b	v0, v4, v0
	shl.16b	v0, v0, #7
	cmlt.16b	v0, v0, #0
	umaxv.16b	b0, v0
	fmov	w12, s0
	and	w12, w12, #0x1
	cmp	x11, x10
	b.eq	LBB1_35
; %bb.29:
	tst	x10, #0x38
	b.eq	LBB1_33
LBB1_30:
	mov	x13, x11
	movi.2d	v0, #0000000000000000
	mov.b	v0[0], w12
	and	x11, x10, #0xfffffff8
	sub	x12, x13, x11
	mov	w14, #24                        ; =0x18
	umaddl	x13, w13, w14, x8
	add	x13, x13, #122
	movi.8b	v1, #7
LBB1_31:                                ; =>This Inner Loop Header: Depth=1
	sub	x14, x13, #48
	sub	x15, x13, #24
	add	x16, x13, #24
	add	x17, x13, #48
	add	x1, x13, #72
	add	x2, x13, #96
	ldur	b2, [x13, #-72]
	ld1.b	{ v2 }[1], [x14]
	ld1.b	{ v2 }[2], [x15]
	ld1.b	{ v2 }[3], [x13]
	ld1.b	{ v2 }[4], [x16]
	ld1.b	{ v2 }[5], [x17]
	ld1.b	{ v2 }[6], [x1]
	ld1.b	{ v2 }[7], [x2]
	cmeq.8b	v2, v2, v1
	orr.8b	v0, v0, v2
	add	x13, x13, #192
	adds	x12, x12, #8
	b.ne	LBB1_31
; %bb.32:
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w12, s0
	and	w12, w12, #0x1
	cmp	x11, x10
	b.eq	LBB1_35
LBB1_33:
	mov	w13, #24                        ; =0x18
	umaddl	x8, w11, w13, x8
	add	x8, x8, #50
	sub	x10, x10, x11
LBB1_34:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #24
	cmp	w11, #7
	cset	w11, eq
	orr	w12, w12, w11
	subs	x10, x10, #1
	b.ne	LBB1_34
LBB1_35:
	and	w8, w9, w12
	tbz	w8, #0, LBB1_41
; %bb.36:
	ldr	w8, [x0, #40]
	cbz	w8, LBB1_41
; %bb.37:
	add	x8, sp, #551
	mov	x0, x20
	bl	_verify_module_ranges
	ldrb	w8, [sp, #551]
	tbz	w8, #0, LBB1_44
; %bb.38:
	mov	x0, x20
	bl	_nvm_retained_layouts_valid
	tbz	w0, #0, LBB1_46
; %bb.39:
	add	x8, sp, #294
	mov	x0, x20
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #294]
	tbz	w8, #0, LBB1_54
; %bb.40:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #37]
	b	LBB1_47
LBB1_41:
	bl	_nvm_mixed_samples_proof_free
Lloh11:
	adrp	x8, lCPI1_2@PAGE
Lloh12:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [x19]
Lloh13:
	adrp	x8, l_.str.2@PAGE
Lloh14:
	add	x8, x8, l_.str.2@PAGEOFF
LBB1_42:
	str	x8, [x19, #16]
	ldur	x8, [x29, #-56]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_58
; %bb.43:
	add	sp, sp, #816
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB1_44:
	add	x0, sp, #37
	add	x1, sp, #551
LBB1_45:
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB1_47
LBB1_46:
Lloh18:
	adrp	x0, l_.str.103@PAGE
Lloh19:
	add	x0, x0, l_.str.103@PAGEOFF
	add	x8, sp, #37
	bl	_fail
LBB1_47:
	ldrb	w8, [sp, #37]
	cmp	w8, #1
	b.ne	LBB1_53
; %bb.48:
	mov	x0, x20
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB1_53
; %bb.49:
	mov	w0, #1                          ; =0x1
	mov	w1, #25568                      ; =0x63e0
	bl	_calloc
	mov	x21, x0
	ldr	x0, [sp, #24]
	cbz	x21, LBB1_55
; %bb.50:
	str	x0, [x21]
	mov	x0, x20
	mov	x1, x21
	bl	_mp_signatures
	tbz	w0, #0, LBB1_56
; %bb.51:
	ldr	w22, [x20, #320]
	mov	x0, x22
	bl	_malloc
	str	x0, [x21, #25552]
	cbz	x0, LBB1_57
; %bb.52:
	ldr	x1, [x20, #312]
	mov	x2, x22
	bl	_memcpy
	mov	w8, #25560                      ; =0x63d8
	str	w22, [x21, x8]
	str	x21, [x23]
	stp	xzr, xzr, [x19]
Lloh20:
	adrp	x8, l_.str.7@PAGE
Lloh21:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB1_42
LBB1_53:
	ldr	x0, [sp, #24]
	bl	_nvm_mixed_samples_proof_free
Lloh22:
	adrp	x8, lCPI1_0@PAGE
Lloh23:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [x19]
Lloh24:
	adrp	x8, l_.str.3@PAGE
Lloh25:
	add	x8, x8, l_.str.3@PAGEOFF
	b	LBB1_42
LBB1_54:
	add	x0, sp, #37
	add	x1, sp, #294
	b	LBB1_45
LBB1_55:
	bl	_nvm_mixed_samples_proof_free
Lloh26:
	adrp	x8, lCPI1_1@PAGE
Lloh27:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [x19]
Lloh28:
	adrp	x8, l_.str.4@PAGE
Lloh29:
	add	x8, x8, l_.str.4@PAGEOFF
	b	LBB1_42
LBB1_56:
	mov	x0, x21
	bl	_nvm_mixed_samples_plan_free
Lloh30:
	adrp	x8, lCPI1_0@PAGE
Lloh31:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [x19]
Lloh32:
	adrp	x8, l_.str.5@PAGE
Lloh33:
	add	x8, x8, l_.str.5@PAGEOFF
	b	LBB1_42
LBB1_57:
	mov	x0, x21
	bl	_nvm_mixed_samples_plan_free
Lloh34:
	adrp	x8, lCPI1_1@PAGE
Lloh35:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [x19]
Lloh36:
	adrp	x8, l_.str.6@PAGE
Lloh37:
	add	x8, x8, l_.str.6@PAGEOFF
	b	LBB1_42
LBB1_58:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpAdrp	Lloh3, Lloh5
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpAdrp	Lloh7, Lloh9
	.loh AdrpLdr	Lloh7, Lloh8
	.loh AdrpAdd	Lloh13, Lloh14
	.loh AdrpAdrp	Lloh11, Lloh13
	.loh AdrpLdr	Lloh11, Lloh12
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_structure_checked
_verify_structure_checked:              ; @verify_structure_checked
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x23, x3
	mov	x20, x2
	mov	x22, x1
	mov	x21, x0
	mov	x19, x8
Lloh38:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh39:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh40:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	cbz	x2, LBB2_2
; %bb.1:
	strb	wzr, [x20]
LBB2_2:
	add	x8, sp, #295
	mov	x0, x21
	bl	_verify_module_ranges
	ldrb	w8, [sp, #295]
	tbz	w8, #0, LBB2_9
; %bb.3:
	mov	w24, #0                         ; =0x0
	strb	wzr, [sp, #35]
	tbz	w23, #0, LBB2_11
LBB2_4:
	mov	x0, x21
	bl	_nvm_retained_layouts_valid
	tbz	w0, #0, LBB2_13
; %bb.5:
	add	x8, sp, #36
	mov	x0, x21
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #36]
	tbz	w8, #0, LBB2_25
; %bb.6:
	cbz	x20, LBB2_8
; %bb.7:
	strb	w24, [x20]
LBB2_8:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB2_15
LBB2_9:
	add	x1, sp, #295
LBB2_10:
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB2_15
LBB2_11:
	add	x1, sp, #35
	mov	x0, x21
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB2_17
; %bb.12:
Lloh41:
	adrp	x0, l_.str.101@PAGE
Lloh42:
	add	x0, x0, l_.str.101@PAGEOFF
	b	LBB2_14
LBB2_13:
Lloh43:
	adrp	x0, l_.str.103@PAGE
Lloh44:
	add	x0, x0, l_.str.103@PAGEOFF
LBB2_14:
	mov	x8, x19
	bl	_fail
LBB2_15:
	ldur	x8, [x29, #-72]
Lloh45:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh46:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh47:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_27
; %bb.16:
	add	sp, sp, #560
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB2_17:
	mov	w24, #0                         ; =0x0
	tbnz	w22, #0, LBB2_4
; %bb.18:
	ldrb	w8, [sp, #35]
	tbz	w8, #0, LBB2_4
; %bb.19:
	ldr	w8, [x21, #272]
	cbz	w8, LBB2_23
; %bb.20:
	mov	w22, #0                         ; =0x0
LBB2_21:                                ; =>This Inner Loop Header: Depth=1
	add	x8, sp, #36
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #36]
	tbz	w8, #0, LBB2_26
; %bb.22:                               ;   in Loop: Header=BB2_21 Depth=1
	add	w22, w22, #1
	ldr	w8, [x21, #272]
	cmp	w22, w8
	b.lo	LBB2_21
LBB2_23:
	mov	x8, x19
	mov	x0, x21
	bl	_nvm_verify_owned_module
	ldrb	w8, [x19]
	cmp	w8, #1
	b.ne	LBB2_15
; %bb.24:
	mov	w24, #1                         ; =0x1
	b	LBB2_4
LBB2_25:
	add	x1, sp, #36
	b	LBB2_10
LBB2_26:
	add	x8, sp, #36
	add	x8, x8, #16
	ldr	w9, [sp, #40]
	stp	x9, x8, [sp, #8]
	str	x22, [sp]
Lloh48:
	adrp	x0, l_.str.102@PAGE
Lloh49:
	add	x0, x0, l_.str.102@PAGEOFF
	b	LBB2_14
LBB2_27:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh38, Lloh39, Lloh40
	.loh AdrpAdd	Lloh41, Lloh42
	.loh AdrpAdd	Lloh43, Lloh44
	.loh AdrpLdrGotLdr	Lloh45, Lloh46, Lloh47
	.loh AdrpAdd	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mp_signatures
_mp_signatures:                         ; @mp_signatures
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x1
	mov	x20, x0
	ldr	x8, [x1]
	ldr	x8, [x8]
	ldr	x23, [x8]
	ldr	x1, [x23, #5144]
	ldr	w2, [x23, #5152]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_45
; %bb.1:
	ldr	w8, [sp, #36]
	sub	w8, w8, #3
	cmn	w8, #2
	b.lo	LBB3_45
; %bb.2:
	add	x0, sp, #40
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_45
; %bb.3:
	ldr	w1, [sp, #32]
	ldr	w8, [x23, #8]
	cmp	w1, w8
	b.ne	LBB3_45
; %bb.4:
	add	x0, sp, #40
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbnz	w0, LBB3_45
; %bb.5:
	add	x0, sp, #40
	bl	_nvm_v2_align4
	cbnz	w0, LBB3_45
; %bb.6:
	add	x0, sp, #40
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_45
; %bb.7:
	ldr	w8, [sp, #28]
	ldr	w9, [x20, #272]
	cmp	w8, w9
	b.ne	LBB3_45
; %bb.8:
	mov	w9, #25544                      ; =0x63c8
	str	w8, [x19, x9]
	cbz	w8, LBB3_47
; %bb.9:
	mov	x25, #0                         ; =0x0
	add	x8, x19, #8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x27, x19, #968
	add	x26, x19, #16
LBB3_10:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_33 Depth 2
	ldr	x22, [x20, #256]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w9, #120                        ; =0x78
	madd	x21, x25, x9, x8
	add	x0, sp, #40
	add	x1, x21, #2
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_45
; %bb.11:                               ;   in Loop: Header=BB3_10 Depth=1
	ldurh	w8, [x21, #2]
	cmp	w8, #256
	b.hi	LBB3_45
; %bb.12:                               ;   in Loop: Header=BB3_10 Depth=1
	add	x0, sp, #40
	mov	x1, x21
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_45
; %bb.13:                               ;   in Loop: Header=BB3_10 Depth=1
	ldrh	w8, [x21]
	cmp	w8, #8
	b.hi	LBB3_45
; %bb.14:                               ;   in Loop: Header=BB3_10 Depth=1
	ldurh	w9, [x21, #2]
	cmp	w8, w9
	b.hi	LBB3_45
; %bb.15:                               ;   in Loop: Header=BB3_10 Depth=1
	mov	w10, #24                        ; =0x18
	madd	x22, x25, x10, x22
	ldrh	w10, [x22, #4]
	cmp	w8, w10
	b.ne	LBB3_45
; %bb.16:                               ;   in Loop: Header=BB3_10 Depth=1
	ldrh	w8, [x22, #16]
	cmp	w9, w8
	b.ne	LBB3_45
; %bb.17:                               ;   in Loop: Header=BB3_10 Depth=1
	ldr	x1, [x19]
	add	x0, sp, #40
	add	x2, x21, #104
	bl	_mp_declaration
	cbz	w0, LBB3_46
; %bb.18:                               ;   in Loop: Header=BB3_10 Depth=1
	ldr	x8, [x21, #104]
	tst	x8, #0xff00
	b.ne	LBB3_45
; %bb.19:                               ;   in Loop: Header=BB3_10 Depth=1
	ldr	w9, [x21, #112]
	and	w10, w8, #0xff
	cmp	w9, #1
	b.eq	LBB3_22
; %bb.20:                               ;   in Loop: Header=BB3_10 Depth=1
	cmp	w9, #2
	b.ne	LBB3_45
; %bb.21:                               ;   in Loop: Header=BB3_10 Depth=1
	and	x11, x8, #0xff
	cmp	x11, #8
	b.eq	LBB3_25
	b	LBB3_45
LBB3_22:                                ;   in Loop: Header=BB3_10 Depth=1
	cmp	w10, #4
	b.hi	LBB3_24
; %bb.23:                               ;   in Loop: Header=BB3_10 Depth=1
	mov	w11, #1                         ; =0x1
	lsl	w11, w11, w10
	mov	w12, #22                        ; =0x16
	tst	w11, w12
	b.ne	LBB3_25
LBB3_24:                                ;   in Loop: Header=BB3_10 Depth=1
	tst	x8, #0xff
	b.ne	LBB3_45
LBB3_25:                                ;   in Loop: Header=BB3_10 Depth=1
	ldrb	w11, [x22, #20]
	cmp	w11, w10
	b.ne	LBB3_45
; %bb.26:                               ;   in Loop: Header=BB3_10 Depth=1
	ldrb	w11, [x22, #21]
	cmp	w10, #0
	cset	w10, ne
	cmp	w11, w10
	b.ne	LBB3_45
; %bb.27:                               ;   in Loop: Header=BB3_10 Depth=1
	ldr	x10, [x19]
	add	x10, x10, x25, lsl #1
	ldrh	w11, [x10, #24]
	strh	w11, [x21, #4]
	ldrh	w10, [x21, #2]
	add	w11, w10, w11
	lsr	w11, w11, #16
	cbnz	w11, LBB3_45
; %bb.28:                               ;   in Loop: Header=BB3_10 Depth=1
	cmp	w9, #2
	b.ne	LBB3_30
; %bb.29:                               ;   in Loop: Header=BB3_10 Depth=1
	lsr	x8, x8, #32
	ldr	x9, [x23]
	add	x8, x9, x8, lsl #4
	ldrh	w8, [x8, #2]
	strh	w8, [x21, #116]
LBB3_30:                                ;   in Loop: Header=BB3_10 Depth=1
	cbz	w10, LBB3_44
; %bb.31:                               ;   in Loop: Header=BB3_10 Depth=1
	mov	x24, #0                         ; =0x0
	mov	x22, x27
	mov	x28, x26
	b	LBB3_33
LBB3_32:                                ;   in Loop: Header=BB3_33 Depth=2
	add	x24, x24, #1
	ldurh	w8, [x21, #2]
	add	x28, x28, #12
	add	x22, x22, #12
	cmp	x24, x8
	b.hs	LBB3_44
LBB3_33:                                ;   Parent Loop BB3_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x1, [x19]
	add	x0, sp, #40
	mov	x2, x22
	bl	_mp_declaration
	cbz	w0, LBB3_46
; %bb.34:                               ;   in Loop: Header=BB3_33 Depth=2
	ldrh	w8, [x21]
	cmp	x24, x8
	b.hs	LBB3_32
; %bb.35:                               ;   in Loop: Header=BB3_33 Depth=2
	ldr	x8, [x22]
	tst	x8, #0xff00
	b.ne	LBB3_45
; %bb.36:                               ;   in Loop: Header=BB3_33 Depth=2
	ldr	w9, [x22, #8]
	cmp	w9, #2
	b.eq	LBB3_40
; %bb.37:                               ;   in Loop: Header=BB3_33 Depth=2
	cmp	w9, #1
	b.ne	LBB3_45
; %bb.38:                               ;   in Loop: Header=BB3_33 Depth=2
	mov	w0, #0                          ; =0x0
	and	w8, w8, #0xff
	cmp	w8, #4
	b.hi	LBB3_46
; %bb.39:                               ;   in Loop: Header=BB3_33 Depth=2
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	mov	w9, #22                         ; =0x16
	tst	w8, w9
	b.ne	LBB3_41
	b	LBB3_46
LBB3_40:                                ;   in Loop: Header=BB3_33 Depth=2
	and	x8, x8, #0xff
	cmp	x8, #8
	b.ne	LBB3_45
LBB3_41:                                ;   in Loop: Header=BB3_33 Depth=2
	ldr	x8, [x22]
	ldr	w9, [x22, #8]
	str	w9, [x28, #8]
	str	x8, [x28]
	ldr	x8, [x20, #264]
	cbz	x8, LBB3_32
; %bb.42:                               ;   in Loop: Header=BB3_33 Depth=2
	ldr	x8, [x8, x25, lsl #3]
	cbz	x8, LBB3_32
; %bb.43:                               ;   in Loop: Header=BB3_33 Depth=2
	ldrb	w8, [x8, x24]
	ldrb	w9, [x28]
	cmp	w8, w9
	b.eq	LBB3_32
	b	LBB3_45
LBB3_44:                                ;   in Loop: Header=BB3_10 Depth=1
	add	x25, x25, #1
	ldr	w8, [sp, #28]
	add	x26, x26, #120
	add	x27, x27, #3072
	mov	w0, #1                          ; =0x1
	cmp	x25, x8
	b.lo	LBB3_10
	b	LBB3_46
LBB3_45:
	mov	w0, #0                          ; =0x0
LBB3_46:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB3_47:
	mov	w0, #1                          ; =0x1
	b	LBB3_46
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_signature ; -- Begin function nvm_mixed_samples_signature
	.globl	_nvm_mixed_samples_signature
	.p2align	2
_nvm_mixed_samples_signature:           ; @nvm_mixed_samples_signature
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB4_4
; %bb.1:
	cbz	x2, LBB4_4
; %bb.2:
	mov	w8, #25544                      ; =0x63c8
	ldr	w8, [x0, x8]
	cmp	w1, w8
	b.hs	LBB4_5
; %bb.3:
	mov	w8, #120                        ; =0x78
	umaddl	x8, w1, w8, x0
	ldur	q0, [x8, #8]
	ldur	q1, [x8, #24]
	ldur	q2, [x8, #40]
	ldur	q3, [x8, #56]
	stp	q2, q3, [x2, #32]
	stp	q0, q1, [x2]
	ldur	q0, [x8, #72]
	ldur	q1, [x8, #88]
	ldur	q2, [x8, #104]
	ldr	x8, [x8, #120]
	str	x8, [x2, #112]
	stp	q1, q2, [x2, #80]
	str	q0, [x2, #64]
	mov	w8, #1                          ; =0x1
LBB4_4:
	mov	x0, x8
	ret
LBB4_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_local ; -- Begin function nvm_mixed_samples_local
	.globl	_nvm_mixed_samples_local
	.p2align	2
_nvm_mixed_samples_local:               ; @nvm_mixed_samples_local
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB5_5
; %bb.1:
	cbz	x3, LBB5_5
; %bb.2:
	mov	w8, #25544                      ; =0x63c8
	ldr	w8, [x0, x8]
	cmp	w1, w8
	b.hs	LBB5_6
; %bb.3:
	mov	w8, #120                        ; =0x78
	umaddl	x8, w1, w8, x0
	ldrh	w8, [x8, #10]
	cmp	w2, w8
	b.hs	LBB5_6
; %bb.4:
	mov	w8, w1
	mov	w9, #3072                       ; =0xc00
	umaddl	x8, w8, w9, x0
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	ldr	x9, [x8, #968]
	ldr	w8, [x8, #976]
	str	w8, [x3, #8]
	str	x9, [x3]
	mov	w8, #1                          ; =0x1
LBB5_5:
	mov	x0, x8
	ret
LBB5_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_record ; -- Begin function nvm_mixed_samples_record
	.globl	_nvm_mixed_samples_record
	.p2align	2
_nvm_mixed_samples_record:              ; @nvm_mixed_samples_record
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB6_10
; %bb.1:
	cbz	x2, LBB6_10
; %bb.2:
	ldr	x11, [x8]
	ldr	x8, [x11]
	ldr	x8, [x8]
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB6_8
; %bb.3:
	add	x9, x8, w1, uxtw #2
	ldr	w9, [x9, #24]
	ldr	w10, [x8, #8]
	cmp	w9, w10
	b.hs	LBB6_8
; %bb.4:
	add	x10, x11, x9, lsl #2
	ldr	w10, [x10, #44]
	cmn	w10, #1
	b.eq	LBB6_8
; %bb.5:
	ldr	w12, [x11, #40]
	cmp	w10, w12
	b.hs	LBB6_8
; %bb.6:
	add	x11, x11, x10, lsl #2
	ldr	w11, [x11, #1068]
	cmp	w11, w9
	b.ne	LBB6_8
; %bb.7:
	add	x11, x8, x9, lsl #2
	ldr	w11, [x11, #4120]
	cmp	w11, #1
	b.ne	LBB6_9
LBB6_8:
	mov	w0, #0                          ; =0x0
	ret
LBB6_9:
	ldr	x8, [x8]
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	stp	w1, w9, [x2]
	stp	w10, w8, [x2, #8]
	mov	w0, #1                          ; =0x1
LBB6_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_transport ; -- Begin function nvm_mixed_samples_transport
	.globl	_nvm_mixed_samples_transport
	.p2align	2
_nvm_mixed_samples_transport:           ; @nvm_mixed_samples_transport
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB7_2
; %bb.1:
	ldr	x9, [x8]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	x10, [x8, #25552]
	mov	w11, #25560                     ; =0x63d8
	ldr	w8, [x8, x11]
	ldr	x11, [x9, #5144]
	ldr	w9, [x9, #5152]
	stp	x10, x11, [x1]
	stp	w8, w9, [x1, #16]
LBB7_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_obligations ; -- Begin function nvm_mixed_samples_obligations
	.globl	_nvm_mixed_samples_obligations
	.p2align	2
_nvm_mixed_samples_obligations:         ; @nvm_mixed_samples_obligations
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_2
; %bb.1:
	ldr	x0, [x0]
LBB8_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_candidate ; -- Begin function nvm_mixed_samples_candidate
	.globl	_nvm_mixed_samples_candidate
	.p2align	2
_nvm_mixed_samples_candidate:           ; @nvm_mixed_samples_candidate
	.cfi_startproc
; %bb.0:
	mov	x1, #0                          ; =0x0
	b	_nvm_mixed_samples_candidate_classified
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_samples_candidate_classified ; -- Begin function nvm_mixed_samples_candidate_classified
	.globl	_nvm_mixed_samples_candidate_classified
	.p2align	2
_nvm_mixed_samples_candidate_classified: ; @nvm_mixed_samples_candidate_classified
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_11
; %bb.1:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	bl	_nvm_service_pending_classified
	tbnz	w0, #0, LBB10_9
; %bb.2:
	ldr	x1, [x19, #296]
	cbz	x1, LBB10_9
; %bb.3:
	ldr	x8, [x19, #312]
	cbz	x8, LBB10_9
; %bb.4:
	ldr	w2, [x19, #304]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_9
; %bb.5:
	ldr	w8, [sp, #36]
	sub	w8, w8, #3
	cmn	w8, #2
	b.lo	LBB10_9
; %bb.6:
	add	x0, sp, #40
	add	x1, sp, #32
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB10_10
; %bb.7:
	ldr	w1, [sp, #32]
	cmp	w1, #256
	b.hi	LBB10_10
; %bb.8:
	add	x0, sp, #40
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbz	w0, LBB10_12
LBB10_9:
	mov	w0, #0                          ; =0x0
LBB10_10:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB10_11:
	ret
LBB10_12:
	ldr	w8, [sp, #32]
	cbz	w8, LBB10_9
; %bb.13:
	mov	w9, #0                          ; =0x0
	ldr	x10, [sp, #16]
LBB10_14:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #1
	orr	w9, w9, w11, lsr #1
	and	w9, w9, #0x1
	subs	x8, x8, #1
	b.ne	LBB10_14
; %bb.15:
	tbz	w9, #0, LBB10_9
; %bb.16:
	ldr	x1, [x19, #312]
	ldr	w2, [x19, #320]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_9
; %bb.17:
	ldp	w8, w9, [sp, #28]
	cmp	w8, w9
	b.ne	LBB10_9
; %bb.18:
	cbz	w8, LBB10_31
; %bb.19:
	mov	w19, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	w21, #65536                     ; =0x10000
LBB10_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_27 Depth 2
	add	x0, sp, #40
	add	x1, sp, #15
	bl	_nvm_v2_u8
	cbnz	w0, LBB10_32
; %bb.21:                               ;   in Loop: Header=BB10_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #14
	bl	_nvm_v2_u8
	cbnz	w0, LBB10_32
; %bb.22:                               ;   in Loop: Header=BB10_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #12
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_32
; %bb.23:                               ;   in Loop: Header=BB10_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_32
; %bb.24:                               ;   in Loop: Header=BB10_20 Depth=1
	ldrh	w22, [sp, #12]
	sub	w8, w21, w20
	cmp	w8, w22
	b.lo	LBB10_32
; %bb.25:                               ;   in Loop: Header=BB10_20 Depth=1
	cbz	w22, LBB10_30
; %bb.26:                               ;   in Loop: Header=BB10_20 Depth=1
	mov	w23, #0                         ; =0x0
LBB10_27:                               ;   Parent Loop BB10_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #40
	mov	x2, sp
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cmp	w0, #0
	cset	w8, eq
	cbnz	w0, LBB10_33
; %bb.28:                               ;   in Loop: Header=BB10_27 Depth=2
	ldr	x9, [sp]
	ldrb	w9, [x9]
	cmp	w9, #7
	b.eq	LBB10_33
; %bb.29:                               ;   in Loop: Header=BB10_27 Depth=2
	add	w23, w23, #1
	ldrh	w8, [sp, #12]
	cmp	w23, w8
	b.lo	LBB10_27
LBB10_30:                               ;   in Loop: Header=BB10_20 Depth=1
	add	w20, w20, w22
	add	w19, w19, #1
	ldr	w8, [sp, #32]
	cmp	w19, w8
	b.lo	LBB10_20
LBB10_31:
	mov	w9, #0                          ; =0x0
                                        ; implicit-def: $w8
	b	LBB10_34
LBB10_32:
	mov	w8, #0                          ; =0x0
LBB10_33:
	mov	w9, #1                          ; =0x1
LBB10_34:
	and	w0, w9, w8
	b	LBB10_10
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_mixed_samples_admit
lCPI11_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI11_1:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_mixed_samples_admit
	.globl	_nvm_mixed_samples_admit
	.p2align	2
_nvm_mixed_samples_admit:               ; @nvm_mixed_samples_admit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x8
	cbz	x1, LBB11_4
; %bb.1:
	mov	x20, x0
	mov	x23, x1
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	tbz	w0, #0, LBB11_5
; %bb.2:
	str	xzr, [sp, #24]
	mov	x8, sp
	add	x1, sp, #24
	mov	x0, x20
	bl	_nvm_mixed_samples_prepare
	ldr	w8, [sp]
	cbz	w8, LBB11_7
; %bb.3:
	ldr	q0, [sp]
	str	q0, [x19]
	ldr	x8, [sp, #16]
	b	LBB11_6
LBB11_4:
Lloh50:
	adrp	x8, lCPI11_1@PAGE
Lloh51:
	ldr	q0, [x8, lCPI11_1@PAGEOFF]
	str	q0, [x19]
Lloh52:
	adrp	x8, l_.str.8@PAGE
Lloh53:
	add	x8, x8, l_.str.8@PAGEOFF
	b	LBB11_6
LBB11_5:
Lloh54:
	adrp	x8, lCPI11_0@PAGE
Lloh55:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x19]
Lloh56:
	adrp	x8, l_.str.9@PAGE
Lloh57:
	add	x8, x8, l_.str.9@PAGEOFF
LBB11_6:
	str	x8, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB11_7:
	ldr	x21, [sp, #24]
	ldrb	w8, [x21, #112]
	cmp	w8, #5
	cset	w9, lo
	mov	w10, #22                        ; =0x16
	lsr	w8, w10, w8
	and	w24, w9, w8
	ldr	w8, [x20, #272]
	cbz	w8, LBB11_12
; %bb.8:
	mov	x25, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
Lloh58:
	adrp	x22, l_.str.10@PAGE
Lloh59:
	add	x22, x22, l_.str.10@PAGEOFF
	b	LBB11_10
LBB11_9:                                ;   in Loop: Header=BB11_10 Depth=1
	add	x26, x26, #1
	ldr	w8, [x20, #272]
	add	x25, x25, #24
	cmp	x26, x8
	b.hs	LBB11_12
LBB11_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #256]
	ldr	w1, [x8, x25]
	mov	x0, x20
	bl	_nvm_get_string
	cbz	x0, LBB11_9
; %bb.11:                               ;   in Loop: Header=BB11_10 Depth=1
	mov	x1, x22
	bl	_strcmp
	cmp	w0, #0
	cset	w8, ne
	and	w24, w8, w24
	b	LBB11_9
LBB11_12:
	tbz	w24, #0, LBB11_14
; %bb.13:
	str	x21, [x23]
	stp	xzr, xzr, [x19]
Lloh60:
	adrp	x8, l_.str.12@PAGE
Lloh61:
	add	x8, x8, l_.str.12@PAGEOFF
	b	LBB11_6
LBB11_14:
	cbz	x21, LBB11_16
; %bb.15:
	ldr	x0, [x21]
	bl	_nvm_mixed_samples_proof_free
	ldr	x0, [x21, #25552]
	bl	_free
	mov	x0, x21
	bl	_free
LBB11_16:
Lloh62:
	adrp	x8, lCPI11_0@PAGE
Lloh63:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x19]
Lloh64:
	adrp	x8, l_.str.11@PAGE
Lloh65:
	add	x8, x8, l_.str.11@PAGEOFF
	b	LBB11_6
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_free ; -- Begin function nvm_owned_array_plan_free
	.globl	_nvm_owned_array_plan_free
	.p2align	2
_nvm_owned_array_plan_free:             ; @nvm_owned_array_plan_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB12_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_owned_array_lifetime_facts_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB12_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_prepare_owned_array_authority
lCPI13_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI13_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_prepare_owned_array_authority
	.globl	_nvm_prepare_owned_array_authority
	.p2align	2
_nvm_prepare_owned_array_authority:     ; @nvm_prepare_owned_array_authority
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #816
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
Lloh66:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh67:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh68:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	cbz	x1, LBB13_3
; %bb.1:
	mov	x20, x0
	mov	x21, x1
	str	xzr, [sp, #24]
	mov	x8, sp
	add	x1, sp, #24
	bl	_nvm_analyze_owned_array_lifetimes
	ldr	w8, [sp]
	cbz	w8, LBB13_4
; %bb.2:
	ldr	q0, [sp]
	str	q0, [x19]
	ldr	x8, [sp, #16]
	b	LBB13_16
LBB13_3:
Lloh69:
	adrp	x8, lCPI13_0@PAGE
Lloh70:
	ldr	q0, [x8, lCPI13_0@PAGEOFF]
	str	q0, [x19]
Lloh71:
	adrp	x8, l_.str.13@PAGE
Lloh72:
	add	x8, x8, l_.str.13@PAGEOFF
	b	LBB13_16
LBB13_4:
	add	x8, sp, #551
	mov	x0, x20
	bl	_verify_module_ranges
	ldrb	w8, [sp, #551]
	tbz	w8, #0, LBB13_8
; %bb.5:
	mov	x0, x20
	bl	_nvm_retained_layouts_valid
	tbz	w0, #0, LBB13_10
; %bb.6:
	add	x8, sp, #294
	mov	x0, x20
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #294]
	tbz	w8, #0, LBB13_18
; %bb.7:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #37]
	b	LBB13_11
LBB13_8:
	add	x0, sp, #37
	add	x1, sp, #551
LBB13_9:
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB13_11
LBB13_10:
Lloh73:
	adrp	x0, l_.str.103@PAGE
Lloh74:
	add	x0, x0, l_.str.103@PAGEOFF
	add	x8, sp, #37
	bl	_fail
LBB13_11:
	ldrb	w8, [sp, #37]
	cmp	w8, #1
	b.ne	LBB13_15
; %bb.12:
	mov	x0, x20
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB13_15
; %bb.13:
	mov	w0, #1                          ; =0x1
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp, #24]
	cbz	x8, LBB13_19
; %bb.14:
	str	x0, [x8]
	str	x8, [x21]
	stp	xzr, xzr, [x19]
Lloh75:
	adrp	x8, l_.str.16@PAGE
Lloh76:
	add	x8, x8, l_.str.16@PAGEOFF
	b	LBB13_16
LBB13_15:
	ldr	x0, [sp, #24]
	bl	_nvm_owned_array_lifetime_facts_free
Lloh77:
	adrp	x8, lCPI13_0@PAGE
Lloh78:
	ldr	q0, [x8, lCPI13_0@PAGEOFF]
	str	q0, [x19]
Lloh79:
	adrp	x8, l_.str.14@PAGE
Lloh80:
	add	x8, x8, l_.str.14@PAGEOFF
LBB13_16:
	str	x8, [x19, #16]
	ldur	x8, [x29, #-40]
Lloh81:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh82:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh83:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB13_20
; %bb.17:
	add	sp, sp, #816
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB13_18:
	add	x0, sp, #37
	add	x1, sp, #294
	b	LBB13_9
LBB13_19:
	bl	_nvm_owned_array_lifetime_facts_free
Lloh84:
	adrp	x8, lCPI13_1@PAGE
Lloh85:
	ldr	q0, [x8, lCPI13_1@PAGEOFF]
	str	q0, [x19]
Lloh86:
	adrp	x8, l_.str.15@PAGE
Lloh87:
	add	x8, x8, l_.str.15@PAGEOFF
	b	LBB13_16
LBB13_20:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh66, Lloh67, Lloh68
	.loh AdrpAdd	Lloh71, Lloh72
	.loh AdrpAdrp	Lloh69, Lloh71
	.loh AdrpLdr	Lloh69, Lloh70
	.loh AdrpAdd	Lloh73, Lloh74
	.loh AdrpAdd	Lloh75, Lloh76
	.loh AdrpAdd	Lloh79, Lloh80
	.loh AdrpAdrp	Lloh77, Lloh79
	.loh AdrpLdr	Lloh77, Lloh78
	.loh AdrpLdrGotLdr	Lloh81, Lloh82, Lloh83
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_counts ; -- Begin function nvm_owned_array_plan_counts
	.globl	_nvm_owned_array_plan_counts
	.p2align	2
_nvm_owned_array_plan_counts:           ; @nvm_owned_array_plan_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB14_2
; %bb.1:
	ldr	x8, [x8]
	ldr	q0, [x8, #16]
	ldr	w8, [x8, #32]
	str	w8, [x1, #16]
	str	q0, [x1]
LBB14_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_signature ; -- Begin function nvm_owned_array_plan_signature
	.globl	_nvm_owned_array_plan_signature
	.p2align	2
_nvm_owned_array_plan_signature:        ; @nvm_owned_array_plan_signature
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB15_4
; %bb.1:
	cbz	x2, LBB15_4
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB15_5
; %bb.3:
	mov	w9, #116                        ; =0x74
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #36]
	ldur	q1, [x8, #52]
	ldur	q2, [x8, #68]
	ldur	q3, [x8, #84]
	stp	q2, q3, [x2, #32]
	stp	q0, q1, [x2]
	ldur	q0, [x8, #100]
	ldur	q1, [x8, #116]
	ldur	q2, [x8, #132]
	ldr	w8, [x8, #148]
	str	w8, [x2, #112]
	stp	q1, q2, [x2, #80]
	str	q0, [x2, #64]
	mov	w0, #1                          ; =0x1
LBB15_4:
	ret
LBB15_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_local ; -- Begin function nvm_owned_array_plan_local
	.globl	_nvm_owned_array_plan_local
	.p2align	2
_nvm_owned_array_plan_local:            ; @nvm_owned_array_plan_local
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB16_5
; %bb.1:
	cbz	x3, LBB16_5
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB16_6
; %bb.3:
	mov	w9, #116                        ; =0x74
	umaddl	x9, w1, w9, x8
	ldrh	w9, [x9, #36]
	cmp	w2, w9
	b.hs	LBB16_6
; %bb.4:
	mov	w9, w1
	mov	w10, #3072                      ; =0xc00
	umaddl	x8, w9, w10, x8
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	add	x9, x8, #964
	ldr	x9, [x9]
	ldr	w8, [x8, #972]
	str	w8, [x3, #8]
	str	x9, [x3]
	mov	w0, #1                          ; =0x1
LBB16_5:
	ret
LBB16_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_layout ; -- Begin function nvm_owned_array_plan_layout
	.globl	_nvm_owned_array_plan_layout
	.p2align	2
_nvm_owned_array_plan_layout:           ; @nvm_owned_array_plan_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #8]
	b	_nvm_owned_array_layout_fact
LBB17_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_source ; -- Begin function nvm_owned_array_plan_source
	.globl	_nvm_owned_array_plan_source
	.p2align	2
_nvm_owned_array_plan_source:           ; @nvm_owned_array_plan_source
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #8]
	b	_nvm_owned_array_source_layout
LBB18_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_transport ; -- Begin function nvm_owned_array_plan_transport
	.globl	_nvm_owned_array_plan_transport
	.p2align	2
_nvm_owned_array_plan_transport:        ; @nvm_owned_array_plan_transport
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB19_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8, #8]
	b	_nvm_owned_array_transport
LBB19_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_plan_obligation ; -- Begin function nvm_owned_array_plan_obligation
	.globl	_nvm_owned_array_plan_obligation
	.p2align	2
_nvm_owned_array_plan_obligation:       ; @nvm_owned_array_plan_obligation
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB20_4
; %bb.1:
	cbz	x2, LBB20_4
; %bb.2:
	ldr	x8, [x8]
	ldr	w9, [x8, #20]
	cmp	w1, w9
	b.hs	LBB20_5
; %bb.3:
	mov	w9, #28                         ; =0x1c
	umaddl	x8, w1, w9, x8
	mov	w9, #25540                      ; =0x63c4
	ldr	q0, [x8, x9]
	ldr	q1, [x8, #25552]
	stur	q1, [x2, #12]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB20_4:
	ret
LBB20_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_route  ; -- Begin function nvm_owned_array_route
	.globl	_nvm_owned_array_route
	.p2align	2
_nvm_owned_array_route:                 ; @nvm_owned_array_route
	.cfi_startproc
; %bb.0:
	mov	x1, #0                          ; =0x0
	b	_nvm_owned_array_route_classified
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_route_classified ; -- Begin function nvm_owned_array_route_classified
	.globl	_nvm_owned_array_route_classified
	.p2align	2
_nvm_owned_array_route_classified:      ; @nvm_owned_array_route_classified
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB22_13
; %bb.1:
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	bl	_nvm_service_pending_classified
	tbz	w0, #0, LBB22_3
LBB22_2:
	mov	w0, #0                          ; =0x0
	b	LBB22_12
LBB22_3:
	ldr	x1, [x19, #296]
	ldr	w2, [x19, #304]
	cbz	x1, LBB22_11
; %bb.4:
	cbz	w2, LBB22_10
; %bb.5:
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB22_10
; %bb.6:
	ldr	w8, [sp, #52]
	sub	w8, w8, #4
	cmn	w8, #3
	b.lo	LBB22_10
; %bb.7:
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #2                          ; =0x2
	cbnz	w8, LBB22_12
; %bb.8:
	ldr	w1, [sp, #48]
	cmp	w1, #256
	b.hi	LBB22_12
; %bb.9:
	add	x0, sp, #56
	add	x2, sp, #32
	bl	_nvm_v2_take
	cbz	w0, LBB22_14
LBB22_10:
	mov	w0, #2                          ; =0x2
	b	LBB22_12
LBB22_11:
	mov	w8, #2                          ; =0x2
	cmp	w2, #0
	csel	w0, wzr, w8, eq
LBB22_12:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
LBB22_13:
	ret
LBB22_14:
	ldr	w8, [sp, #48]
	cbz	w8, LBB22_2
; %bb.15:
	mov	w9, #0                          ; =0x0
	ldr	x10, [sp, #32]
	mov	x11, x8
LBB22_16:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10], #1
	orr	w9, w9, w12, lsr #1
	and	w9, w9, #0x1
	subs	x11, x11, #1
	b.ne	LBB22_16
; %bb.17:
	cbz	w9, LBB22_2
; %bb.18:
	ldr	x9, [sp, #32]
LBB22_19:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cmp	w10, #3
	b.hi	LBB22_10
; %bb.20:                               ;   in Loop: Header=BB22_19 Depth=1
	and	w11, w10, #0x1
	cmp	w10, #2
	ccmp	w11, #0, #0, hs
	b.eq	LBB22_10
; %bb.21:                               ;   in Loop: Header=BB22_19 Depth=1
	subs	x8, x8, #1
	b.ne	LBB22_19
; %bb.22:
	add	x0, sp, #56
	bl	_nvm_v2_align4
	cbnz	w0, LBB22_10
; %bb.23:
	add	x0, sp, #56
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB22_10
; %bb.24:
	ldr	w8, [sp, #28]
	ldr	w9, [x19, #272]
	cmp	w8, w9
	b.ne	LBB22_10
; %bb.25:
	ldr	x1, [x19, #312]
	cbz	x1, LBB22_10
; %bb.26:
	ldr	w2, [x19, #320]
	cbz	w2, LBB22_10
; %bb.27:
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB22_10
; %bb.28:
	ldp	w8, w9, [sp, #44]
	cmp	w8, w9
	b.ne	LBB22_10
; %bb.29:
	cbz	w8, LBB22_47
; %bb.30:
	mov	x20, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	mov	w22, #65536                     ; =0x10000
LBB22_31:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB22_40 Depth 2
	add	x0, sp, #56
	add	x1, sp, #27
	bl	_nvm_v2_u8
	cbnz	w0, LBB22_10
; %bb.32:                               ;   in Loop: Header=BB22_31 Depth=1
	add	x0, sp, #56
	add	x1, sp, #26
	bl	_nvm_v2_u8
	cbnz	w0, LBB22_10
; %bb.33:                               ;   in Loop: Header=BB22_31 Depth=1
	add	x0, sp, #56
	add	x1, sp, #24
	bl	_nvm_v2_u16
	cbnz	w0, LBB22_10
; %bb.34:                               ;   in Loop: Header=BB22_31 Depth=1
	add	x0, sp, #56
	add	x1, sp, #20
	bl	_nvm_v2_u32
	cbnz	w0, LBB22_10
; %bb.35:                               ;   in Loop: Header=BB22_31 Depth=1
	ldrh	w23, [sp, #24]
	sub	w8, w22, w21
	cmp	w8, w23
	b.lo	LBB22_10
; %bb.36:                               ;   in Loop: Header=BB22_31 Depth=1
	ldrb	w8, [sp, #26]
	cbnz	w8, LBB22_10
; %bb.37:                               ;   in Loop: Header=BB22_31 Depth=1
	ldrb	w8, [sp, #27]
	cmp	w8, #3
	b.hi	LBB22_10
; %bb.38:                               ;   in Loop: Header=BB22_31 Depth=1
	cbz	w23, LBB22_46
; %bb.39:                               ;   in Loop: Header=BB22_31 Depth=1
	mov	w24, #0                         ; =0x0
LBB22_40:                               ;   Parent Loop BB22_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #56
	add	x2, sp, #8
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB22_10
; %bb.41:                               ;   in Loop: Header=BB22_40 Depth=2
	ldr	x9, [sp, #8]
	ldrb	w8, [x9]
	cmp	w8, #15
	b.hi	LBB22_10
; %bb.42:                               ;   in Loop: Header=BB22_40 Depth=2
	ldrb	w10, [x9, #1]
	cbnz	w10, LBB22_10
; %bb.43:                               ;   in Loop: Header=BB22_40 Depth=2
	ldrb	w10, [x9, #2]
	cbnz	w10, LBB22_10
; %bb.44:                               ;   in Loop: Header=BB22_40 Depth=2
	ldrb	w9, [x9, #3]
	cbnz	w9, LBB22_10
; %bb.45:                               ;   in Loop: Header=BB22_40 Depth=2
	ldr	x9, [sp, #32]
	ldrb	w9, [x9, x20]
	ubfx	w9, w9, #1, #1
	cmp	w8, #7
	csel	w8, wzr, w9, ne
	orr	w19, w8, w19
	add	w24, w24, #1
	ldrh	w8, [sp, #24]
	cmp	w24, w8
	b.lo	LBB22_40
LBB22_46:                               ;   in Loop: Header=BB22_31 Depth=1
	add	w21, w21, w23
	add	x20, x20, #1
	ldr	w8, [sp, #48]
	cmp	x20, x8
	b.lo	LBB22_31
	b	LBB22_48
LBB22_47:
	mov	w19, #0                         ; =0x0
LBB22_48:
	ldp	x9, x8, [sp, #64]
	mov	w0, #2                          ; =0x2
	cmp	x8, x9
	b.ne	LBB22_12
; %bb.49:
	ldr	w8, [sp, #52]
	cmp	w8, #3
	cset	w8, eq
	and	w9, w19, #0x1
	tst	w9, w8
	csel	w0, w0, w9, ne
	b	LBB22_12
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_owned_array_admit
lCPI23_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI23_1:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_owned_array_admit
	.globl	_nvm_owned_array_admit
	.p2align	2
_nvm_owned_array_admit:                 ; @nvm_owned_array_admit
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #800
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh88:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh89:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh90:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x1, LBB23_3
; %bb.1:
	mov	x20, x0
	mov	x23, x1
	bl	_nvm_service_execution_pending
	cbz	w0, LBB23_4
; %bb.2:
Lloh91:
	adrp	x8, lCPI23_0@PAGE
Lloh92:
	ldr	q0, [x8, lCPI23_0@PAGEOFF]
	str	q0, [x19]
Lloh93:
	adrp	x8, l_.str.18@PAGE
Lloh94:
	add	x8, x8, l_.str.18@PAGEOFF
	b	LBB23_41
LBB23_3:
Lloh95:
	adrp	x8, lCPI23_1@PAGE
Lloh96:
	ldr	q0, [x8, lCPI23_1@PAGEOFF]
	str	q0, [x19]
Lloh97:
	adrp	x8, l_.str.17@PAGE
Lloh98:
	add	x8, x8, l_.str.17@PAGEOFF
	b	LBB23_41
LBB23_4:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cmp	w0, #1
	b.ne	LBB23_9
; %bb.5:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x29, #-128]
	stp	q0, q0, [x29, #-160]
	stp	q0, q0, [x29, #-192]
	stp	q0, q0, [x29, #-224]
	ldr	w8, [x20, #272]
	cbz	w8, LBB23_39
; %bb.6:
	ldr	x9, [x20, #256]
	cbz	x9, LBB23_39
; %bb.7:
	cmp	w8, #8
	b.ls	LBB23_10
LBB23_8:
	mov	w8, #3                          ; =0x3
	b	LBB23_40
LBB23_9:
	cmp	w0, #2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
	stp	w8, wzr, [x19]
	str	xzr, [x19, #8]
Lloh99:
	adrp	x8, l_.str.19@PAGE
Lloh100:
	add	x8, x8, l_.str.19@PAGEOFF
	b	LBB23_41
LBB23_10:
	ldr	x1, [x20, #296]
	ldr	w2, [x20, #304]
	add	x0, sp, #16
	bl	_nvm_v2_cursor_init
	add	x0, sp, #16
	add	x1, sp, #160
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_39
; %bb.11:
	ldr	w8, [sp, #160]
	sub	w8, w8, #3
	cmn	w8, #2
	b.lo	LBB23_39
; %bb.12:
	add	x0, sp, #16
	sub	x1, x29, #228
	bl	_nvm_v2_u32
	mov	w8, #2                          ; =0x2
	cbnz	w0, LBB23_40
; %bb.13:
	ldur	w1, [x29, #-228]
	cmp	w1, #256
	b.hi	LBB23_40
; %bb.14:
	add	x0, sp, #16
	add	x2, sp, #136
	bl	_nvm_v2_take
	cbnz	w0, LBB23_39
; %bb.15:
	add	x0, sp, #16
	bl	_nvm_v2_align4
	cbnz	w0, LBB23_39
; %bb.16:
	add	x0, sp, #16
	sub	x1, x29, #228
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_39
; %bb.17:
	ldur	w8, [x29, #-228]
	ldr	w9, [x20, #272]
	cmp	w8, w9
	b.ne	LBB23_39
; %bb.18:
	cbz	w8, LBB23_37
; %bb.19:
	mov	x21, #0                         ; =0x0
	mov	w24, #24                        ; =0x18
	sub	x25, x29, #224
	mov	w26, #1                         ; =0x1
	mov	w27, #310                       ; =0x136
	sub	x28, x29, #160
LBB23_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_30 Depth 2
	ldr	x8, [x20, #256]
	madd	x22, x21, x24, x8
	ldrh	w8, [x22, #4]
	cmp	w8, #8
	b.hi	LBB23_8
; %bb.21:                               ;   in Loop: Header=BB23_20 Depth=1
	ldrh	w8, [x22, #16]
	cmp	w8, #256
	b.hi	LBB23_8
; %bb.22:                               ;   in Loop: Header=BB23_20 Depth=1
	add	x0, sp, #16
	sub	x1, x29, #230
	bl	_nvm_v2_u16
	cbnz	w0, LBB23_39
; %bb.23:                               ;   in Loop: Header=BB23_20 Depth=1
	add	x0, sp, #16
	sub	x1, x29, #232
	bl	_nvm_v2_u16
	cbnz	w0, LBB23_39
; %bb.24:                               ;   in Loop: Header=BB23_20 Depth=1
	ldurh	w9, [x29, #-230]
	ldrh	w8, [x22, #16]
	cmp	w9, w8
	b.ne	LBB23_39
; %bb.25:                               ;   in Loop: Header=BB23_20 Depth=1
	ldurh	w10, [x29, #-232]
	mov	w8, #2                          ; =0x2
	cmp	w10, w9
	b.hi	LBB23_40
; %bb.26:                               ;   in Loop: Header=BB23_20 Depth=1
	ldrh	w9, [x22, #4]
	cmp	w10, w9
	b.ne	LBB23_40
; %bb.27:                               ;   in Loop: Header=BB23_20 Depth=1
	sub	x8, x29, #160
	add	x8, x8, x21, lsl #3
	str	x8, [x25, x21, lsl #3]
	mov	x22, #-1                        ; =0xffffffffffffffff
	b	LBB23_30
LBB23_28:                               ;   in Loop: Header=BB23_30 Depth=2
	strb	w8, [x28, x22]
LBB23_29:                               ;   in Loop: Header=BB23_30 Depth=2
	ldurh	w8, [x29, #-230]
	add	x22, x22, #1
	cmp	x22, x8
	b.hs	LBB23_36
LBB23_30:                               ;   Parent Loop BB23_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #16
	add	x2, sp, #168
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB23_39
; %bb.31:                               ;   in Loop: Header=BB23_30 Depth=2
	ldurh	w8, [x29, #-232]
	cmp	x22, w8, uxth
	b.hs	LBB23_29
; %bb.32:                               ;   in Loop: Header=BB23_30 Depth=2
	ldr	x8, [sp, #168]
	ldrb	w8, [x8]
	cmp	w8, #8
	lsl	w9, w26, w8
	and	w9, w9, w27
	ccmp	w9, #0, #4, ls
	b.eq	LBB23_83
; %bb.33:                               ;   in Loop: Header=BB23_30 Depth=2
	ldr	x9, [x20, #264]
	cbz	x9, LBB23_28
; %bb.34:                               ;   in Loop: Header=BB23_30 Depth=2
	ldr	x9, [x9, x21, lsl #3]
	cbz	x9, LBB23_28
; %bb.35:                               ;   in Loop: Header=BB23_30 Depth=2
	ldrb	w9, [x9, x22]
	cmp	w9, #0
	ccmp	w9, w8, #4, ne
	b.eq	LBB23_28
	b	LBB23_83
LBB23_36:                               ;   in Loop: Header=BB23_20 Depth=1
	add	x21, x21, #1
	ldur	w8, [x29, #-228]
	add	x28, x28, #8
	cmp	x21, x8
	b.lo	LBB23_20
LBB23_37:
	add	x0, sp, #168
	mov	x1, x20
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	sub	x8, x29, #224
	str	x8, [sp, #432]
	str	xzr, [sp, #160]
	add	x8, sp, #136
	add	x0, sp, #168
	add	x1, sp, #160
	bl	_nvm_prepare_owned_array_authority
	ldr	w8, [sp, #136]
	cbz	w8, LBB23_43
; %bb.38:
	ldur	q0, [sp, #136]
	str	q0, [x19]
	ldr	x8, [sp, #152]
	b	LBB23_41
LBB23_39:
	mov	w8, #2                          ; =0x2
LBB23_40:
	stp	w8, wzr, [x19]
	str	xzr, [x19, #8]
Lloh101:
	adrp	x8, l_.str.20@PAGE
Lloh102:
	add	x8, x8, l_.str.20@PAGEOFF
LBB23_41:
	str	x8, [x19, #16]
	ldur	x8, [x29, #-96]
Lloh103:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh104:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh105:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB23_90
; %bb.42:
	add	sp, sp, #800
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB23_43:
	ldr	x21, [sp, #160]
	cbz	x21, LBB23_46
; %bb.44:
	ldr	x8, [x21]
	ldr	w9, [x8, #16]
	cbz	w9, LBB23_46
; %bb.45:
	ldrh	w9, [x8, #38]
	cbz	w9, LBB23_84
LBB23_46:
	mov	w24, #0                         ; =0x0
	ldr	w8, [x20, #272]
	cbz	w8, LBB23_87
LBB23_47:
	mov	x25, #0                         ; =0x0
	add	x8, sp, #16
	add	x9, x8, #56
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	add	x27, x8, #20
	mov	w28, #24                        ; =0x18
	mov	w26, #116                       ; =0x74
Lloh106:
	adrp	x22, l_.str.10@PAGE
Lloh107:
	add	x22, x22, l_.str.10@PAGEOFF
	b	LBB23_50
LBB23_48:                               ;   in Loop: Header=BB23_50 Depth=1
	mov	w24, #0                         ; =0x0
LBB23_49:                               ;   in Loop: Header=BB23_50 Depth=1
	add	x25, x25, #1
	ldr	w8, [x20, #272]
	cmp	x25, x8
	b.hs	LBB23_87
LBB23_50:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_61 Depth 2
                                        ;     Child Loop BB23_81 Depth 2
	ldr	x8, [x20, #256]
	mul	x9, x25, x28
	ldr	w1, [x8, x9]
	mov	x0, x20
	bl	_nvm_get_string
	cbz	x0, LBB23_52
; %bb.51:                               ;   in Loop: Header=BB23_50 Depth=1
	mov	x1, x22
	bl	_strcmp
	cmp	w0, #0
	cset	w8, ne
	and	w24, w8, w24
LBB23_52:                               ;   in Loop: Header=BB23_50 Depth=1
	cbz	x21, LBB23_48
; %bb.53:                               ;   in Loop: Header=BB23_50 Depth=1
	ldr	x8, [x21]
	ldr	w9, [x8, #16]
	cmp	x25, x9
	b.hs	LBB23_48
; %bb.54:                               ;   in Loop: Header=BB23_50 Depth=1
	madd	x8, x25, x26, x8
	ldur	q0, [x8, #100]
	str	q0, [sp, #80]
	ldur	q0, [x8, #116]
	str	q0, [sp, #96]
	ldur	q0, [x8, #132]
	str	q0, [sp, #112]
	ldr	w9, [x8, #148]
	str	w9, [sp, #128]
	ldur	q0, [x8, #36]
	str	q0, [sp, #16]
	ldur	q0, [x8, #52]
	str	q0, [sp, #32]
	ldur	q0, [x8, #68]
	str	q0, [sp, #48]
	ldur	q0, [x8, #84]
	str	q0, [sp, #64]
	ldr	x8, [x20, #264]
	cbz	x8, LBB23_49
; %bb.55:                               ;   in Loop: Header=BB23_50 Depth=1
	ldr	x8, [x8, x25, lsl #3]
	cbz	x8, LBB23_49
; %bb.56:                               ;   in Loop: Header=BB23_50 Depth=1
	ldrh	w9, [sp, #18]
	cbz	w9, LBB23_49
; %bb.57:                               ;   in Loop: Header=BB23_50 Depth=1
	cmp	w9, #8
	b.hs	LBB23_59
; %bb.58:                               ;   in Loop: Header=BB23_50 Depth=1
	mov	x11, #0                         ; =0x0
	b	LBB23_78
LBB23_59:                               ;   in Loop: Header=BB23_50 Depth=1
	mov	x10, #0                         ; =0x0
	and	x11, x9, #0xfff8
	neg	x11, x11
	add	x12, x8, #3
	ldr	x13, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB23_61
LBB23_60:                               ;   in Loop: Header=BB23_61 Depth=2
	sub	x10, x10, #8
	add	x13, x13, #96
	add	x12, x12, #8
	cmp	x11, x10
	b.eq	LBB23_77
LBB23_61:                               ;   Parent Loop BB23_50 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w14, [x12, #-3]
	cbz	w14, LBB23_63
; %bb.62:                               ;   in Loop: Header=BB23_61 Depth=2
	ldurb	w15, [x13, #-36]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_63:                               ;   in Loop: Header=BB23_61 Depth=2
	ldurb	w14, [x12, #-2]
	cbz	w14, LBB23_65
; %bb.64:                               ;   in Loop: Header=BB23_61 Depth=2
	ldurb	w15, [x13, #-24]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_65:                               ;   in Loop: Header=BB23_61 Depth=2
	ldurb	w14, [x12, #-1]
	cbz	w14, LBB23_67
; %bb.66:                               ;   in Loop: Header=BB23_61 Depth=2
	ldurb	w15, [x13, #-12]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_67:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w14, [x12]
	cbz	w14, LBB23_69
; %bb.68:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w15, [x13]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_69:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w14, [x12, #1]
	cbz	w14, LBB23_71
; %bb.70:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w15, [x13, #12]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_71:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w14, [x12, #2]
	cbz	w14, LBB23_73
; %bb.72:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w15, [x13, #24]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_73:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w14, [x12, #3]
	cbz	w14, LBB23_75
; %bb.74:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w15, [x13, #36]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
LBB23_75:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w14, [x12, #4]
	cbz	w14, LBB23_60
; %bb.76:                               ;   in Loop: Header=BB23_61 Depth=2
	ldrb	w15, [x13, #48]
	cmp	w14, w15
	cset	w14, eq
	and	w24, w14, w24
	b	LBB23_60
LBB23_77:                               ;   in Loop: Header=BB23_50 Depth=1
	neg	x11, x10
LBB23_78:                               ;   in Loop: Header=BB23_50 Depth=1
	and	x9, x9, #0x7
	cbz	x9, LBB23_49
; %bb.79:                               ;   in Loop: Header=BB23_50 Depth=1
	mov	w10, #12                        ; =0xc
	madd	x10, x11, x10, x27
	add	x8, x8, x11
	b	LBB23_81
LBB23_80:                               ;   in Loop: Header=BB23_81 Depth=2
	add	x10, x10, #12
	subs	x9, x9, #1
	b.eq	LBB23_49
LBB23_81:                               ;   Parent Loop BB23_50 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x8], #1
	cbz	w11, LBB23_80
; %bb.82:                               ;   in Loop: Header=BB23_81 Depth=2
	ldrb	w12, [x10]
	cmp	w11, w12
	cset	w11, eq
	and	w24, w11, w24
	b	LBB23_80
LBB23_83:
	mov	w8, #1                          ; =0x1
	b	LBB23_40
LBB23_84:
	ldrb	w8, [x8, #44]
	cmp	w8, #4
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	mov	w9, #22                         ; =0x16
	and	w8, w8, w9
	ccmp	w8, #0, #4, ls
	b.eq	LBB23_46
; %bb.85:
	ldrb	w8, [x20, #8]
	tbz	w8, #0, LBB23_46
; %bb.86:
	ldr	w8, [x20, #12]
	cmp	w8, #0
	cset	w24, eq
	ldr	w8, [x20, #272]
	cbnz	w8, LBB23_47
LBB23_87:
	tbz	w24, #0, LBB23_89
; %bb.88:
	str	x21, [x23]
	stp	xzr, xzr, [x19]
Lloh108:
	adrp	x8, l_.str.22@PAGE
Lloh109:
	add	x8, x8, l_.str.22@PAGEOFF
	b	LBB23_41
LBB23_89:
	mov	x0, x21
	bl	_nvm_owned_array_plan_free
Lloh110:
	adrp	x8, lCPI23_0@PAGE
Lloh111:
	ldr	q0, [x8, lCPI23_0@PAGEOFF]
	str	q0, [x19]
Lloh112:
	adrp	x8, l_.str.21@PAGE
Lloh113:
	add	x8, x8, l_.str.21@PAGEOFF
	b	LBB23_41
LBB23_90:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh88, Lloh89, Lloh90
	.loh AdrpAdd	Lloh93, Lloh94
	.loh AdrpAdrp	Lloh91, Lloh93
	.loh AdrpLdr	Lloh91, Lloh92
	.loh AdrpAdd	Lloh97, Lloh98
	.loh AdrpAdrp	Lloh95, Lloh97
	.loh AdrpLdr	Lloh95, Lloh96
	.loh AdrpAdd	Lloh99, Lloh100
	.loh AdrpAdd	Lloh101, Lloh102
	.loh AdrpLdrGotLdr	Lloh103, Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_structure_free ; -- Begin function nvm_record_array_structure_free
	.globl	_nvm_record_array_structure_free
	.p2align	2
_nvm_record_array_structure_free:       ; @nvm_record_array_structure_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB24_4
; %bb.2:
	mov	x21, #0                         ; =0x0
	add	x20, x19, #16
LBB24_3:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	bl	_vm_decoded_function_free
	add	x21, x21, #1
	ldr	w8, [x19, #8]
	add	x20, x20, #32
	cmp	x21, x8
	b.lo	LBB24_3
LBB24_4:
	ldr	x0, [x19]
	bl	_nvm_ownership_declarations_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB24_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_structure_prepare ; -- Begin function nvm_record_array_structure_prepare
	.globl	_nvm_record_array_structure_prepare
	.p2align	2
_nvm_record_array_structure_prepare:    ; @nvm_record_array_structure_prepare
	.cfi_startproc
; %bb.0:
	mov	x3, #0                          ; =0x0
	b	_record_structure_prepare
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function record_structure_prepare
lCPI26_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
lCPI26_1:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
lCPI26_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_record_structure_prepare:              ; @record_structure_prepare
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1328
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh114:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh115:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh116:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	cbz	x0, LBB26_9
; %bb.1:
	cbz	x1, LBB26_9
; %bb.2:
	cbz	x2, LBB26_9
; %bb.3:
	ldr	x9, [x1]
	cbnz	x9, LBB26_8
; %bb.4:
	ldr	x9, [x1, #16]
	cbnz	x9, LBB26_8
; %bb.5:
	ldr	x9, [x1, #8]
	cbnz	x9, LBB26_8
; %bb.6:
	ldrb	w9, [x1, #24]
	tbnz	w9, #0, LBB26_8
; %bb.7:
	ldrb	w9, [x1, #25]
	cmp	w9, #1
	b.ne	LBB26_12
LBB26_8:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
Lloh117:
	adrp	x9, lCPI26_0@PAGE
Lloh118:
	ldr	d0, [x9, lCPI26_0@PAGEOFF]
	str	d0, [x8]
Lloh119:
	adrp	x9, l_.str.25@PAGE
Lloh120:
	add	x9, x9, l_.str.25@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	str	wzr, [x8, #200]
	mov	w9, #26478                      ; =0x676e
	movk	w9, #46, lsl #16
	str	w9, [x8, #44]
	stur	q1, [x8, #28]
	b	LBB26_10
LBB26_9:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stur	q0, [x8, #40]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
Lloh121:
	adrp	x9, lCPI26_0@PAGE
Lloh122:
	ldr	d0, [x9, lCPI26_0@PAGEOFF]
	str	d0, [x8]
Lloh123:
	adrp	x9, l_.str.24@PAGE
Lloh124:
	add	x9, x9, l_.str.24@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	str	wzr, [x8, #200]
	stur	q1, [x8, #28]
	ldur	x9, [x9, #30]
	stur	x9, [x8, #42]
LBB26_10:
	ldur	x8, [x29, #-96]
Lloh125:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh126:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh127:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB26_26
; %bb.11:
	add	sp, sp, #1328
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB26_12:
	mov	x20, x0
	mov	x26, x3
	mov	x25, x2
	mov	x0, x1
	mov	x19, x1
	mov	w1, #65536                      ; =0x10000
	mov	x24, x8
	bl	_nvm_ra_bytes
	mov	x9, x24
	cbz	w0, LBB26_17
; %bb.13:
	mov	x10, x19
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB26_17
; %bb.14:
	ldrb	w8, [x10, #25]
	tbnz	w8, #0, LBB26_17
; %bb.15:
	ldr	x8, [x10, #16]
	cmp	x8, #4080, lsl #12              ; =16711680
	b.ls	LBB26_18
; %bb.16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x10, #24]
LBB26_17:
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #24]
	stur	q0, [x9, #8]
	stur	q0, [x9, #40]
	stur	q0, [x9, #184]
	stur	q0, [x9, #168]
	stur	q0, [x9, #152]
	stur	q0, [x9, #136]
	stur	q0, [x9, #120]
	stur	q0, [x9, #104]
	stur	q0, [x9, #88]
	stur	q0, [x9, #72]
	stur	q0, [x9, #56]
Lloh128:
	adrp	x8, lCPI26_2@PAGE
Lloh129:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x9]
Lloh130:
	adrp	x8, l_.str.26@PAGE
Lloh131:
	add	x8, x8, l_.str.26@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x9, #12]
	str	wzr, [x9, #200]
	stur	q1, [x9, #28]
	ldr	x8, [x8, #32]
	stur	x8, [x9, #44]
	b	LBB26_10
LBB26_18:
	add	x8, x8, #16, lsl #12            ; =65536
	str	x8, [x10, #16]
	ldr	x11, [x20, #328]
	cbnz	x11, LBB26_25
; %bb.19:
	mov	x10, x20
	ldr	w11, [x20, #336]
	cbnz	w11, LBB26_25
; %bb.20:
	ldr	w11, [x10, #432]
	cbnz	w11, LBB26_25
; %bb.21:
	ldr	w11, [x10, #448]
	cbnz	w11, LBB26_25
; %bb.22:
	ldr	x11, [x10, #344]
	cbnz	x11, LBB26_25
; %bb.23:
	ldr	w11, [x10, #352]
	cbnz	w11, LBB26_25
; %bb.24:
	ldr	w11, [x10, #424]
	cbz	w11, LBB26_27
LBB26_25:
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #24]
	stur	q0, [x9, #8]
	stur	q0, [x9, #40]
	stur	q0, [x9, #56]
	stur	q0, [x9, #184]
	stur	q0, [x9, #168]
	stur	q0, [x9, #152]
	stur	q0, [x9, #136]
	stur	q0, [x9, #120]
	stur	q0, [x9, #104]
	stur	q0, [x9, #88]
	stur	q0, [x9, #72]
Lloh132:
	adrp	x8, lCPI26_1@PAGE
Lloh133:
	ldr	d0, [x8, lCPI26_1@PAGEOFF]
	str	d0, [x9]
Lloh134:
	adrp	x8, l_.str.27@PAGE
Lloh135:
	add	x8, x8, l_.str.27@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x9, #12]
	str	wzr, [x9, #200]
	stur	q1, [x9, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x9, #44]
	ldur	q0, [x8, #43]
	stur	q0, [x9, #55]
	b	LBB26_10
LBB26_26:
	bl	___stack_chk_fail
LBB26_27:
	ldr	w10, [x10, #272]
	cmp	w10, #256
	b.hi	LBB26_30
; %bb.28:
	ldr	w9, [x20, #248]
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB26_30
; %bb.29:
	ldr	w11, [x20, #288]
	mov	w12, #1                         ; =0x1
	movk	w12, #256, lsl #16
	cmp	w11, w12
	b.lo	LBB26_32
LBB26_30:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh136:
	adrp	x8, lCPI26_2@PAGE
Lloh137:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh138:
	adrp	x8, l_.str.28@PAGE
Lloh139:
	add	x8, x8, l_.str.28@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #25710                      ; =0x646e
LBB26_31:
	movk	w8, #46, lsl #16
	stur	w8, [x24, #43]
	stur	q1, [x24, #28]
	b	LBB26_10
LBB26_32:
	cbz	w10, LBB26_41
; %bb.33:
	ldr	x12, [x20, #256]
	cbz	x12, LBB26_41
; %bb.34:
	cbz	w11, LBB26_36
; %bb.35:
	ldr	x11, [x20, #280]
	cbz	x11, LBB26_41
LBB26_36:
	cbz	w9, LBB26_39
; %bb.37:
	ldr	x11, [x20, #232]
	cbz	x11, LBB26_41
; %bb.38:
	ldr	x11, [x20, #240]
	cbz	x11, LBB26_41
LBB26_39:
	ldr	w11, [x20, #224]
	cmp	w11, #16
	b.hi	LBB26_41
; %bb.40:
	ldr	w11, [x20, #16]
	cmp	w11, #17
	b.lo	LBB26_42
LBB26_41:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #56]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
Lloh140:
	adrp	x8, lCPI26_0@PAGE
Lloh141:
	ldr	d0, [x8, lCPI26_0@PAGEOFF]
	str	d0, [x24]
Lloh142:
	adrp	x8, l_.str.29@PAGE
Lloh143:
	add	x8, x8, l_.str.29@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	stur	q1, [x24, #28]
	ldur	q0, [x8, #30]
	stur	q0, [x24, #42]
	b	LBB26_10
LBB26_42:
	ldrb	w11, [x20]
	cmp	w11, #78
	b.ne	LBB26_59
; %bb.43:
	ldrb	w11, [x20, #1]
	cmp	w11, #86
	b.ne	LBB26_59
; %bb.44:
	ldrb	w11, [x20, #2]
	cmp	w11, #77
	b.ne	LBB26_59
; %bb.45:
	ldrb	w11, [x20, #3]
	cmp	w11, #1
	b.ne	LBB26_59
; %bb.46:
	ldr	w11, [x20, #4]
	cmp	w11, #2
	b.ne	LBB26_59
; %bb.47:
	ldr	w11, [x20, #8]
	cmp	w11, #8
	b.hs	LBB26_59
; %bb.48:
	tbz	w11, #0, LBB26_60
; %bb.49:
	ldr	w11, [x20, #12]
	cmp	w11, w10
	b.hs	LBB26_60
; %bb.50:
	cbz	w9, LBB26_57
; %bb.51:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x20, #232]
	mov	w12, #16777216                  ; =0x1000000
LBB26_52:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11, x10, lsl #3]
	cbz	x13, LBB26_107
; %bb.53:                               ;   in Loop: Header=BB26_52 Depth=1
	cmp	x8, x12
	b.hi	LBB26_109
; %bb.54:                               ;   in Loop: Header=BB26_52 Depth=1
	ldr	x14, [x20, #240]
	ldr	w14, [x14, x10, lsl #2]
	sub	x15, x12, x8
	cmp	x15, x14
	b.ls	LBB26_109
; %bb.55:                               ;   in Loop: Header=BB26_52 Depth=1
	add	x8, x14, x8
	add	x8, x8, #1
	str	x8, [x19, #16]
	ldrb	w13, [x13, x14]
	cbnz	w13, LBB26_111
; %bb.56:                               ;   in Loop: Header=BB26_52 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.ne	LBB26_52
LBB26_57:
	ldr	w9, [x20, #368]
	lsl	x9, x9, #5
	mov	w10, #16777216                  ; =0x1000000
	sub	x11, x10, x8
	cmp	x8, x10
	ccmp	x9, x11, #2, ls
	b.lo	LBB26_61
; %bb.58:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #56]
	stur	q0, [x24, #72]
	stur	q0, [x24, #88]
	stur	q0, [x24, #104]
	stur	q0, [x24, #120]
	stur	q0, [x24, #136]
	stur	q0, [x24, #152]
	stur	q0, [x24, #168]
	stur	q0, [x24, #184]
Lloh144:
	adrp	x8, lCPI26_2@PAGE
Lloh145:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh146:
	adrp	x8, l_.str.35@PAGE
Lloh147:
	add	x8, x8, l_.str.35@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x24, #28]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
	str	wzr, [x24, #200]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x24, #44]
	stur	q1, [x24, #12]
	b	LBB26_10
LBB26_59:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #56]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
Lloh148:
	adrp	x8, lCPI26_0@PAGE
Lloh149:
	ldr	d0, [x8, lCPI26_0@PAGEOFF]
	str	d0, [x24]
Lloh150:
	adrp	x8, l_.str.30@PAGE
Lloh151:
	add	x8, x8, l_.str.30@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	stur	q1, [x24, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x24, #44]
	b	LBB26_10
LBB26_60:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh152:
	adrp	x8, lCPI26_1@PAGE
Lloh153:
	ldr	d0, [x8, lCPI26_1@PAGEOFF]
	str	d0, [x24]
Lloh154:
	adrp	x8, l_.str.31@PAGE
Lloh155:
	add	x8, x8, l_.str.31@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x24, #44]
	stur	q1, [x24, #28]
	b	LBB26_10
LBB26_61:
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [x19, #16]
	mov	x0, x20
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB26_112
; %bb.62:
	add	x0, sp, #288
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	ldr	w8, [x20, #272]
	cbz	w8, LBB26_114
; %bb.63:
	mov	w27, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
LBB26_64:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_79 Depth 2
                                        ;     Child Loop BB26_87 Depth 2
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	madd	x28, x22, x10, x9
	ldr	w9, [x28, #12]
	cbnz	w9, LBB26_66
; %bb.65:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrb	w10, [x28, #21]
	cbnz	w10, LBB26_147
LBB26_66:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrh	w10, [x28, #16]
	cmp	w10, #257
	b.hs	LBB26_141
; %bb.67:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrh	w10, [x28, #18]
	cbnz	w10, LBB26_126
; %bb.68:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrb	w10, [x28, #21]
	cmp	w10, #1
	b.hi	LBB26_126
; %bb.69:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrb	w10, [x28, #20]
	cmp	w10, #6
	b.lo	LBB26_71
; %bb.70:                               ;   in Loop: Header=BB26_64 Depth=1
	sub	w10, w10, #7
	cmp	w10, #2
	b.hs	LBB26_126
LBB26_71:                               ;   in Loop: Header=BB26_64 Depth=1
	ldr	w10, [x28, #8]
	ldr	w11, [x20, #288]
	subs	w10, w11, w10
	ccmp	w9, w10, #2, hs
	b.hi	LBB26_142
; %bb.72:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrb	w10, [x19, #24]
	tbnz	w10, #0, LBB26_144
; %bb.73:                               ;   in Loop: Header=BB26_64 Depth=1
	ldrb	w10, [x19, #25]
	tbnz	w10, #0, LBB26_144
; %bb.74:                               ;   in Loop: Header=BB26_64 Depth=1
	ldr	x10, [x19, #16]
	mov	w11, #16777216                  ; =0x1000000
	cmp	x10, x11
	b.hi	LBB26_143
; %bb.75:                               ;   in Loop: Header=BB26_64 Depth=1
	add	x11, x8, x9
	add	x11, x11, #256
	mov	w12, #16777216                  ; =0x1000000
	sub	x12, x12, x10
	cmp	x11, x12
	b.hi	LBB26_143
; %bb.76:                               ;   in Loop: Header=BB26_64 Depth=1
	add	x10, x10, x11
	str	x10, [x19, #16]
	ldrh	w10, [x28, #4]
	cbz	x10, LBB26_84
; %bb.77:                               ;   in Loop: Header=BB26_64 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x12, [x20, #264]
	b	LBB26_79
LBB26_78:                               ;   in Loop: Header=BB26_79 Depth=2
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB26_84
LBB26_79:                               ;   Parent Loop BB26_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x11, #256
	b.eq	LBB26_120
; %bb.80:                               ;   in Loop: Header=BB26_79 Depth=2
	cbz	x12, LBB26_78
; %bb.81:                               ;   in Loop: Header=BB26_79 Depth=2
	ldr	x13, [x12, x22, lsl #3]
	cbz	x13, LBB26_78
; %bb.82:                               ;   in Loop: Header=BB26_79 Depth=2
	ldrb	w13, [x13, x11]
	cmp	w13, #6
	b.lo	LBB26_78
; %bb.83:                               ;   in Loop: Header=BB26_79 Depth=2
	sub	w13, w13, #7
	cmp	w13, #2
	b.lo	LBB26_78
	b	LBB26_146
LBB26_84:                               ;   in Loop: Header=BB26_64 Depth=1
	cbz	w9, LBB26_100
; %bb.85:                               ;   in Loop: Header=BB26_64 Depth=1
	mov	w23, #0                         ; =0x0
	b	LBB26_87
LBB26_86:                               ;   in Loop: Header=BB26_87 Depth=2
	ldr	w9, [x28, #12]
	add	w23, w21, w23
	cmp	w23, w9
	b.hs	LBB26_99
LBB26_87:                               ;   Parent Loop BB26_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x20, #280]
	ldr	w10, [x28, #8]
	add	x8, x8, x10
	add	x0, x8, w23, uxtw
	sub	w1, w9, w23
	add	x2, sp, #24
	bl	_isa_decode
	cbz	w0, LBB26_124
; %bb.88:                               ;   in Loop: Header=BB26_87 Depth=2
	add	w27, w27, #1
	cmp	w27, #16, lsl #12               ; =65536
	b.hi	LBB26_125
; %bb.89:                               ;   in Loop: Header=BB26_87 Depth=2
	mov	x21, x0
	add	x9, sp, #288
	ldr	w8, [x9, x22, lsl #2]
	add	w8, w8, #1
	str	w8, [x9, x22, lsl #2]
	ldrb	w0, [sp, #24]
	bl	_nvm_record_array_opcode_supported
	tbz	w0, #0, LBB26_93
; %bb.90:                               ;   in Loop: Header=BB26_87 Depth=2
	ldrb	w8, [sp, #24]
	cmp	w8, #251
	b.ne	LBB26_97
; %bb.91:                               ;   in Loop: Header=BB26_87 Depth=2
	ldrb	w8, [sp, #32]
	cbnz	w8, LBB26_121
; %bb.92:                               ;   in Loop: Header=BB26_87 Depth=2
	ldrh	w8, [sp, #48]
	cbz	w8, LBB26_86
	b	LBB26_121
LBB26_93:                               ;   in Loop: Header=BB26_87 Depth=2
	cbz	x26, LBB26_121
; %bb.94:                               ;   in Loop: Header=BB26_87 Depth=2
	ldrsb	w8, [sp, #24]
	subs	w8, w8, #120
	b.lt	LBB26_121
; %bb.95:                               ;   in Loop: Header=BB26_87 Depth=2
	mov	w9, #159                        ; =0x9f
	lsr	w9, w9, w8
	tbz	w9, #0, LBB26_121
; %bb.96:                               ;   in Loop: Header=BB26_87 Depth=2
	ubfiz	x8, x8, #3, #5
	mov	x9, #31096                      ; =0x7978
	movk	x9, #31610, lsl #16
	movk	x9, #124, lsl #32
	movk	x9, #32512, lsl #48
	lsr	x8, x9, x8
	and	w8, w8, #0x7f
LBB26_97:                               ;   in Loop: Header=BB26_87 Depth=2
	and	w8, w8, #0xfe
	cmp	w8, #18
	b.ne	LBB26_86
; %bb.98:                               ;   in Loop: Header=BB26_87 Depth=2
	ldr	w8, [sp, #32]
	cmp	w8, #256
	b.lo	LBB26_86
	b	LBB26_137
LBB26_99:                               ;   in Loop: Header=BB26_64 Depth=1
	ldr	w8, [x20, #272]
LBB26_100:                              ;   in Loop: Header=BB26_64 Depth=1
	add	x22, x22, #1
	cmp	x22, x8
	b.lo	LBB26_64
; %bb.101:
	ldrb	w10, [x19, #24]
	cbz	x8, LBB26_115
; %bb.102:
	mov	x9, #0                          ; =0x0
	ldr	x12, [x20, #256]
	add	x11, x8, #32
	add	x12, x12, #12
	mov	w13, #16777216                  ; =0x1000000
LBB26_103:                              ; =>This Inner Loop Header: Depth=1
	tbnz	w10, #0, LBB26_149
; %bb.104:                              ;   in Loop: Header=BB26_103 Depth=1
	ldrb	w14, [x19, #25]
	tbnz	w14, #0, LBB26_149
; %bb.105:                              ;   in Loop: Header=BB26_103 Depth=1
	ldr	w14, [x12]
	ldurh	w15, [x12, #-8]
	add	x14, x11, x14
	add	x14, x14, x15
	ldr	x15, [x19, #16]
	sub	x16, x13, x15
	cmp	x15, x13
	ccmp	x14, x16, #2, ls
	b.hi	LBB26_148
; %bb.106:                              ;   in Loop: Header=BB26_103 Depth=1
	add	x12, x12, #24
	add	x14, x15, x14
	str	x14, [x19, #16]
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB26_103
	b	LBB26_116
LBB26_107:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh156:
	adrp	x8, lCPI26_0@PAGE
Lloh157:
	ldr	d0, [x8, lCPI26_0@PAGEOFF]
	str	d0, [x24]
Lloh158:
	adrp	x8, l_.str.32@PAGE
Lloh159:
	add	x8, x8, l_.str.32@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #26478                      ; =0x676e
LBB26_108:
	movk	w8, #46, lsl #16
	str	w8, [x24, #44]
	stur	q1, [x24, #28]
	b	LBB26_10
LBB26_109:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #56]
	stur	q0, [x24, #72]
	stur	q0, [x24, #88]
	stur	q0, [x24, #104]
	stur	q0, [x24, #120]
	stur	q0, [x24, #136]
	stur	q0, [x24, #152]
	stur	q0, [x24, #168]
	stur	q0, [x24, #184]
Lloh160:
	adrp	x8, lCPI26_2@PAGE
Lloh161:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh162:
	adrp	x8, l_.str.33@PAGE
Lloh163:
	add	x8, x8, l_.str.33@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x24, #28]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, #24]
	str	wzr, [x24, #200]
	stur	q1, [x24, #12]
LBB26_110:
	ldr	x8, [x8, #32]
	stur	x8, [x24, #44]
	b	LBB26_10
LBB26_111:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh164:
	adrp	x8, lCPI26_0@PAGE
Lloh165:
	ldr	d0, [x8, lCPI26_0@PAGEOFF]
	str	d0, [x24]
Lloh166:
	adrp	x8, l_.str.34@PAGE
Lloh167:
	add	x8, x8, l_.str.34@PAGEOFF
	b	LBB26_113
LBB26_112:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh168:
	adrp	x8, lCPI26_0@PAGE
Lloh169:
	ldr	d0, [x8, lCPI26_0@PAGEOFF]
	str	d0, [x24]
Lloh170:
	adrp	x8, l_.str.36@PAGE
Lloh171:
	add	x8, x8, l_.str.36@PAGEOFF
LBB26_113:
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	stur	q1, [x24, #28]
	ldur	x8, [x8, #30]
	stur	x8, [x24, #42]
	b	LBB26_10
LBB26_114:
	ldrb	w10, [x19, #24]
LBB26_115:
	tbnz	w10, #0, LBB26_119
LBB26_116:
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB26_119
; %bb.117:
	ldr	x8, [x19, #16]
	mov	w9, #65505                      ; =0xffe1
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.lo	LBB26_128
; %bb.118:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_119:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh172:
	adrp	x8, lCPI26_2@PAGE
Lloh173:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh174:
	adrp	x8, l_.str.49@PAGE
Lloh175:
	add	x8, x8, l_.str.49@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	stur	q1, [x24, #28]
	ldur	q0, [x8, #25]
	stur	q0, [x24, #37]
	b	LBB26_10
LBB26_120:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	str	wzr, [x24, #200]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x24]
Lloh176:
	adrp	x8, l_.str.42@PAGE
Lloh177:
	add	x8, x8, l_.str.42@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x24, #12]
	ldur	q0, [x8, #14]
	stur	q0, [x24, #26]
	b	LBB26_10
LBB26_121:
	str	wzr, [x24, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	mov	w8, #1                          ; =0x1
	stp	w8, w22, [x24]
Lloh178:
	adrp	x8, l_.str.104@PAGE
Lloh179:
	add	x8, x8, l_.str.104@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	ldur	q3, [x8, #42]
	stur	q3, [x24, #54]
LBB26_122:
	stur	q2, [x24, #44]
LBB26_123:
	stur	q1, [x24, #28]
	stur	q0, [x24, #12]
	b	LBB26_10
LBB26_124:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh180:
	adrp	x8, l_.str.44@PAGE
Lloh181:
	add	x8, x8, l_.str.44@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w9, #2                          ; =0x2
	b	LBB26_127
LBB26_125:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh182:
	adrp	x8, l_.str.45@PAGE
Lloh183:
	add	x8, x8, l_.str.45@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x24]
	stur	q1, [x24, #28]
	b	LBB26_10
LBB26_126:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh184:
	adrp	x8, l_.str.39@PAGE
Lloh185:
	add	x8, x8, l_.str.39@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w9, #1                          ; =0x1
LBB26_127:
	stp	w9, w22, [x24]
	stur	q1, [x24, #28]
	ldur	q0, [x8, #27]
	stur	q0, [x24, #39]
	b	LBB26_10
LBB26_128:
	add	x8, x8, #32
	str	x8, [x19, #16]
	add	x21, sp, #24
	add	x8, sp, #24
	mov	x0, x20
	bl	_verify_module_ranges
	ldrb	w8, [sp, #24]
	tbz	w8, #0, LBB26_138
; %bb.129:
	add	x21, sp, #24
	add	x8, sp, #24
	mov	x0, x20
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #24]
	tbz	w8, #0, LBB26_138
; %bb.130:
	mov	x0, x19
	mov	w1, #16777216                   ; =0x1000000
	bl	_nvm_ra_bytes
	cbz	w0, LBB26_135
; %bb.131:
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB26_135
; %bb.132:
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB26_135
; %bb.133:
	ldr	x8, [x19, #16]
	cmp	x8, #3840, lsl #12              ; =15728640
	b.ls	LBB26_150
; %bb.134:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_135:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh186:
	adrp	x8, lCPI26_2@PAGE
Lloh187:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh188:
	adrp	x8, l_.str.50@PAGE
Lloh189:
	add	x8, x8, l_.str.50@PAGEOFF
LBB26_136:
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	stur	q1, [x24, #28]
	ldur	q0, [x8, #28]
	stur	q0, [x24, #40]
	b	LBB26_10
LBB26_137:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	str	wzr, [x24, #200]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x24]
Lloh190:
	adrp	x8, l_.str.47@PAGE
Lloh191:
	add	x8, x8, l_.str.47@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x24, #12]
	ldur	q0, [x8, #11]
	stur	q0, [x24, #23]
	b	LBB26_10
LBB26_138:
	add	x8, x21, #1
	str	wzr, [x24, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
Lloh192:
	adrp	x9, lCPI26_0@PAGE
Lloh193:
	ldr	d0, [x9, lCPI26_0@PAGEOFF]
	str	d0, [x24]
LBB26_139:
	str	x8, [sp]
LBB26_140:
Lloh194:
	adrp	x2, l_.str.67@PAGE
Lloh195:
	add	x2, x2, l_.str.67@PAGEOFF
	add	x0, x24, #12
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB26_10
LBB26_141:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	str	wzr, [x24, #200]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x24]
Lloh196:
	adrp	x8, l_.str.38@PAGE
Lloh197:
	add	x8, x8, l_.str.38@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x24, #12]
	ldur	q0, [x8, #10]
	stur	q0, [x24, #22]
	b	LBB26_10
LBB26_142:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh198:
	adrp	x8, l_.str.40@PAGE
Lloh199:
	add	x8, x8, l_.str.40@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w9, #2                          ; =0x2
	stp	w9, w22, [x24]
	stur	q1, [x24, #28]
	b	LBB26_110
LBB26_143:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_144:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh200:
	adrp	x8, l_.str.41@PAGE
Lloh201:
	add	x8, x8, l_.str.41@PAGEOFF
LBB26_145:
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x24]
	mov	w8, #25710                      ; =0x646e
	b	LBB26_108
LBB26_146:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh202:
	adrp	x8, l_.str.43@PAGE
Lloh203:
	add	x8, x8, l_.str.43@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w8, #1                          ; =0x1
	stp	w8, w22, [x24]
	mov	w8, #29543                      ; =0x7367
	b	LBB26_31
LBB26_147:
	str	wzr, [x24, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	mov	w8, #2                          ; =0x2
	stp	w8, w22, [x24]
Lloh204:
	adrp	x8, l_.str.37@PAGE
Lloh205:
	add	x8, x8, l_.str.37@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	ldr	x8, [x8, #48]
	stur	x8, [x24, #60]
	b	LBB26_122
LBB26_148:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_149:
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #56]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
Lloh206:
	adrp	x8, l_.str.48@PAGE
Lloh207:
	add	x8, x8, l_.str.48@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x24, #12]
	str	wzr, [x24, #200]
	mov	w10, #3                         ; =0x3
	stp	w10, w9, [x24]
	stur	q1, [x24, #28]
	ldur	q0, [x8, #29]
	stur	q0, [x24, #41]
	b	LBB26_10
LBB26_150:
	add	x8, x8, #256, lsl #12           ; =1048576
	mov	x0, x19
	str	x8, [x19, #16]
	mov	w1, #8720                       ; =0x2210
	bl	_nvm_ra_alloc
	cbz	x0, LBB26_158
; %bb.151:
	mov	x21, x0
	str	xzr, [sp, #16]
	cbz	x26, LBB26_159
; %bb.152:
	mov	x0, x19
	mov	w1, #2097152                    ; =0x200000
	bl	_nvm_ra_bytes
	cbz	w0, LBB26_157
; %bb.153:
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB26_157
; %bb.154:
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB26_157
; %bb.155:
	ldr	x8, [x19, #16]
	cmp	x8, #3072, lsl #12              ; =12582912
	b.ls	LBB26_160
; %bb.156:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_157:
	mov	x0, x21
	bl	_nvm_record_array_structure_free
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #40]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh208:
	adrp	x8, lCPI26_2@PAGE
Lloh209:
	ldr	d0, [x8, lCPI26_2@PAGEOFF]
	str	d0, [x24]
Lloh210:
	adrp	x8, l_.str.106@PAGE
Lloh211:
	add	x8, x8, l_.str.106@PAGEOFF
	b	LBB26_136
LBB26_158:
	ldrb	w8, [x19, #24]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #8]
	cinc	w8, w8, eq
	stur	q0, [x24, #24]
	stur	q0, [x24, #40]
	stur	q0, [x24, #56]
	stur	q0, [x24, #72]
	stur	q0, [x24, #88]
	stur	q0, [x24, #104]
	stur	q0, [x24, #120]
	stur	q0, [x24, #136]
	stur	q0, [x24, #152]
	stur	q0, [x24, #168]
	stur	q0, [x24, #184]
	str	wzr, [x24, #200]
	stp	w8, wzr, [x24]
Lloh212:
	adrp	x8, l_.str.105@PAGE
Lloh213:
	add	x8, x8, l_.str.105@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	stur	x8, [x24, #44]
	b	LBB26_123
LBB26_159:
	mov	x0, x20
	mov	x1, x21
	bl	_nvm_prepare_ownership_declarations
	mov	x23, x0
	mov	x22, x1
	b	LBB26_163
LBB26_160:
	add	x8, x8, #1024, lsl #12          ; =4194304
	str	x8, [x19, #16]
	add	x1, sp, #16
	mov	x0, x20
	mov	x2, x21
	bl	_nvm_prepare_map_declarations_split
	mov	x22, x1
	mov	x23, x0
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB26_164
; %bb.161:
	cmp	w23, #1
	b.eq	LBB26_165
; %bb.162:
	cmp	w23, #0
	mov	w8, #1                          ; =0x1
	cinc	x23, x8, ne
LBB26_163:
	cbz	w23, LBB26_165
LBB26_164:
	ldr	x0, [sp, #16]
	bl	_nvm_map_declarations_free
	mov	x0, x21
	bl	_nvm_record_array_structure_free
	sub	w8, w23, #3
	str	wzr, [x24, #200]
	cmp	w23, #1
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #184]
	mov	w9, #1                          ; =0x1
	cinc	w9, w9, ne
	stur	q0, [x24, #168]
	cmp	w8, #2
	csel	w8, w23, w9, lo
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stp	w8, wzr, [x24]
	str	x22, [sp]
	b	LBB26_140
LBB26_165:
	ldr	w8, [x20, #272]
	str	w8, [x21, #8]
	cbz	w8, LBB26_176
; %bb.166:
	mov	w22, #0                         ; =0x0
	mov	w8, #8208                       ; =0x2010
	add	x8, x21, x8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x27, x21, #16
LBB26_167:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_168 Depth 2
	add	x8, sp, #288
	ldr	w28, [x8, w22, uxtw #2]
	mov	w9, #16                         ; =0x10
	mov	w23, w22
LBB26_168:                              ;   Parent Loop BB26_167 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x8, x9
	lsl	x9, x9, #1
	cmp	x8, x28
	b.lo	LBB26_168
; %bb.169:                              ;   in Loop: Header=BB26_167 Depth=1
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w23, w10, x9
	ldr	w9, [x9, #12]
	add	w9, w9, #1
	add	x9, x9, w9, uxtw #2
	mov	w10, #312                       ; =0x138
	mul	x8, x8, x10
	cmp	w28, #0
	csel	x8, xzr, x8, eq
	add	x1, x9, x8
	mov	x0, x19
	bl	_nvm_ra_bytes
	cbz	w0, LBB26_180
; %bb.170:                              ;   in Loop: Header=BB26_167 Depth=1
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB26_180
; %bb.171:                              ;   in Loop: Header=BB26_167 Depth=1
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB26_180
; %bb.172:                              ;   in Loop: Header=BB26_167 Depth=1
	ldr	x8, [x19, #16]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB26_179
; %bb.173:                              ;   in Loop: Header=BB26_167 Depth=1
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w23, w10, x9
	ldr	w9, [x9, #12]
	lsl	w10, w28, #4
	add	x9, x9, x10
	mov	w10, #16777216                  ; =0x1000000
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB26_179
; %bb.174:                              ;   in Loop: Header=BB26_167 Depth=1
	add	x8, x8, x9
	mov	x5, x19
	str	x8, [x19, #16]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x4, x8, x23, lsl #1
	add	x6, x27, x23, lsl #5
	add	x8, sp, #24
	mov	x0, x20
	mov	x1, x22
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_body
	ldrb	w8, [sp, #24]
	tbz	w8, #0, LBB26_181
; %bb.175:                              ;   in Loop: Header=BB26_167 Depth=1
	add	w22, w22, #1
	ldr	w8, [x21, #8]
	cmp	w22, w8
	b.lo	LBB26_167
LBB26_176:
	cbz	x26, LBB26_178
; %bb.177:
	ldr	x8, [sp, #16]
	str	x8, [x26]
LBB26_178:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #32]
	stp	q0, q0, [x24]
	stp	q0, q0, [x24, #64]
	stp	q0, q0, [x24, #96]
	stp	q0, q0, [x24, #128]
	stp	q0, q0, [x24, #160]
	stur	q0, [x24, #188]
Lloh214:
	adrp	x8, l_.str.55@PAGE
Lloh215:
	add	x8, x8, l_.str.55@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x24, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x24, #44]
	str	x21, [x25]
	ldur	x8, [x8, #46]
	stur	x8, [x24, #58]
	stur	q1, [x24, #12]
	b	LBB26_10
LBB26_179:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB26_180:
	ldr	x0, [sp, #16]
	bl	_nvm_map_declarations_free
	mov	x0, x21
	bl	_nvm_record_array_structure_free
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
Lloh216:
	adrp	x8, l_.str.53@PAGE
Lloh217:
	add	x8, x8, l_.str.53@PAGEOFF
	b	LBB26_145
LBB26_181:
	ldr	x0, [sp, #16]
	bl	_nvm_map_declarations_free
	mov	x0, x21
	bl	_nvm_record_array_structure_free
	ldrb	w8, [x19, #24]
	tbz	w8, #0, LBB26_183
; %bb.182:
	mov	w19, #3                         ; =0x3
	b	LBB26_185
LBB26_183:
	ldrb	w8, [x19, #25]
	mov	w19, #4                         ; =0x4
	tbnz	w8, #0, LBB26_185
; %bb.184:
	add	x8, sp, #24
Lloh218:
	adrp	x1, l_.str.54@PAGE
Lloh219:
	add	x1, x1, l_.str.54@PAGEOFF
	add	x0, x8, #1
	bl	_strstr
	cmp	x0, #0
	mov	w8, #2                          ; =0x2
	csel	w19, w8, w19, eq
LBB26_185:
	add	x8, sp, #24
	str	wzr, [x24, #200]
	add	x8, x8, #1
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #184]
	stur	q0, [x24, #168]
	stur	q0, [x24, #152]
	stur	q0, [x24, #136]
	stur	q0, [x24, #120]
	stur	q0, [x24, #104]
	stur	q0, [x24, #88]
	stur	q0, [x24, #72]
	stur	q0, [x24, #56]
	stur	q0, [x24, #40]
	stur	q0, [x24, #24]
	stur	q0, [x24, #8]
	stp	w19, w22, [x24]
	b	LBB26_139
	.loh AdrpLdrGotLdr	Lloh114, Lloh115, Lloh116
	.loh AdrpAdd	Lloh119, Lloh120
	.loh AdrpAdrp	Lloh117, Lloh119
	.loh AdrpLdr	Lloh117, Lloh118
	.loh AdrpAdd	Lloh123, Lloh124
	.loh AdrpAdrp	Lloh121, Lloh123
	.loh AdrpLdr	Lloh121, Lloh122
	.loh AdrpLdrGotLdr	Lloh125, Lloh126, Lloh127
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdrp	Lloh128, Lloh130
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdrp	Lloh136, Lloh138
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdrp	Lloh144, Lloh146
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdrp	Lloh152, Lloh154
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdrp	Lloh208, Lloh210
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh218, Lloh219
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_record_map_structure_prepare
lCPI27_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_record_map_structure_prepare
	.globl	_nvm_record_map_structure_prepare
	.p2align	2
_nvm_record_map_structure_prepare:      ; @nvm_record_map_structure_prepare
	.cfi_startproc
; %bb.0:
	cbz	x3, LBB27_2
; %bb.1:
	b	_record_structure_prepare
LBB27_2:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
Lloh220:
	adrp	x9, lCPI27_0@PAGE
Lloh221:
	ldr	d0, [x9, lCPI27_0@PAGEOFF]
	str	d0, [x8]
Lloh222:
	adrp	x9, l_.str.23@PAGE
Lloh223:
	add	x9, x9, l_.str.23@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	str	wzr, [x8, #200]
	mov	w9, #29813                      ; =0x7475
	movk	w9, #46, lsl #16
	str	w9, [x8, #44]
	stur	q1, [x8, #28]
	ret
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdrp	Lloh220, Lloh222
	.loh AdrpLdr	Lloh220, Lloh221
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_union_structure_free ; -- Begin function nvm_record_union_structure_free
	.globl	_nvm_record_union_structure_free
	.p2align	2
_nvm_record_union_structure_free:       ; @nvm_record_union_structure_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB28_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB28_6
; %bb.2:
	ldr	w8, [x20, #8]
	cbz	w8, LBB28_5
; %bb.3:
	mov	x22, #0                         ; =0x0
	add	x21, x20, #16
LBB28_4:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x21
	bl	_vm_decoded_function_free
	add	x22, x22, #1
	ldr	w8, [x20, #8]
	add	x21, x21, #32
	cmp	x22, x8
	b.lo	LBB28_4
LBB28_5:
	ldr	x0, [x20]
	bl	_nvm_ownership_declarations_free
	mov	x0, x20
	bl	_free
LBB28_6:
	ldr	x0, [x19, #8]
	bl	_nvm_union_field_declarations_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB28_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_record_union_structure_prepare
lCPI29_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
lCPI29_1:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
lCPI29_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_record_union_structure_prepare
	.globl	_nvm_record_union_structure_prepare
	.p2align	2
_nvm_record_union_structure_prepare:    ; @nvm_record_union_structure_prepare
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1632
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh224:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh225:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh226:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	cbz	x0, LBB29_9
; %bb.1:
	cbz	x1, LBB29_9
; %bb.2:
	cbz	x2, LBB29_9
; %bb.3:
	ldr	x9, [x1]
	cbnz	x9, LBB29_8
; %bb.4:
	ldr	x9, [x1, #16]
	cbnz	x9, LBB29_8
; %bb.5:
	ldr	x9, [x1, #8]
	cbnz	x9, LBB29_8
; %bb.6:
	ldrb	w9, [x1, #24]
	tbnz	w9, #0, LBB29_8
; %bb.7:
	ldrb	w9, [x1, #25]
	cmp	w9, #1
	b.ne	LBB29_12
LBB29_8:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #40]
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
Lloh227:
	adrp	x9, lCPI29_0@PAGE
Lloh228:
	ldr	d0, [x9, lCPI29_0@PAGEOFF]
	str	d0, [x8]
Lloh229:
	adrp	x9, l_.str.25@PAGE
Lloh230:
	add	x9, x9, l_.str.25@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	str	wzr, [x8, #200]
	mov	w9, #26478                      ; =0x676e
	movk	w9, #46, lsl #16
	str	w9, [x8, #44]
	stur	q1, [x8, #28]
	b	LBB29_10
LBB29_9:
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	stur	q0, [x8, #40]
	stur	q0, [x8, #184]
	stur	q0, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	stur	q0, [x8, #120]
	stur	q0, [x8, #104]
	stur	q0, [x8, #88]
	stur	q0, [x8, #72]
	stur	q0, [x8, #56]
Lloh231:
	adrp	x9, lCPI29_0@PAGE
Lloh232:
	ldr	d0, [x9, lCPI29_0@PAGEOFF]
	str	d0, [x8]
Lloh233:
	adrp	x9, l_.str.24@PAGE
Lloh234:
	add	x9, x9, l_.str.24@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	str	wzr, [x8, #200]
	stur	q1, [x8, #28]
	ldur	x9, [x9, #30]
	stur	x9, [x8, #42]
LBB29_10:
	ldur	x8, [x29, #-96]
Lloh235:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh236:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh237:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB29_26
; %bb.11:
	add	sp, sp, #1632
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB29_12:
	mov	x20, x0
	mov	x24, x2
	mov	x0, x1
	mov	x19, x1
	mov	w1, #65536                      ; =0x10000
	mov	x23, x8
	bl	_nvm_ra_bytes
	mov	x9, x23
	cbz	w0, LBB29_17
; %bb.13:
	mov	x10, x19
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB29_17
; %bb.14:
	ldrb	w8, [x10, #25]
	tbnz	w8, #0, LBB29_17
; %bb.15:
	ldr	x8, [x10, #16]
	cmp	x8, #4080, lsl #12              ; =16711680
	b.ls	LBB29_18
; %bb.16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x10, #24]
LBB29_17:
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #24]
	stur	q0, [x9, #8]
	stur	q0, [x9, #40]
	stur	q0, [x9, #184]
	stur	q0, [x9, #168]
	stur	q0, [x9, #152]
	stur	q0, [x9, #136]
	stur	q0, [x9, #120]
	stur	q0, [x9, #104]
	stur	q0, [x9, #88]
	stur	q0, [x9, #72]
	stur	q0, [x9, #56]
Lloh238:
	adrp	x8, lCPI29_2@PAGE
Lloh239:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x9]
Lloh240:
	adrp	x8, l_.str.26@PAGE
Lloh241:
	add	x8, x8, l_.str.26@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x9, #12]
	str	wzr, [x9, #200]
	stur	q1, [x9, #28]
	ldr	x8, [x8, #32]
	stur	x8, [x9, #44]
	b	LBB29_10
LBB29_18:
	add	x8, x8, #16, lsl #12            ; =65536
	str	x8, [x10, #16]
	ldr	x11, [x20, #328]
	cbnz	x11, LBB29_25
; %bb.19:
	mov	x10, x20
	ldr	w11, [x20, #336]
	cbnz	w11, LBB29_25
; %bb.20:
	ldr	w11, [x10, #432]
	cbnz	w11, LBB29_25
; %bb.21:
	ldr	w11, [x10, #448]
	cbnz	w11, LBB29_25
; %bb.22:
	ldr	x11, [x10, #344]
	cbnz	x11, LBB29_25
; %bb.23:
	ldr	w11, [x10, #352]
	cbnz	w11, LBB29_25
; %bb.24:
	ldr	w11, [x10, #424]
	cbz	w11, LBB29_27
LBB29_25:
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #24]
	stur	q0, [x9, #8]
	stur	q0, [x9, #40]
	stur	q0, [x9, #56]
	stur	q0, [x9, #184]
	stur	q0, [x9, #168]
	stur	q0, [x9, #152]
	stur	q0, [x9, #136]
	stur	q0, [x9, #120]
	stur	q0, [x9, #104]
	stur	q0, [x9, #88]
	stur	q0, [x9, #72]
Lloh242:
	adrp	x8, lCPI29_1@PAGE
Lloh243:
	ldr	d0, [x8, lCPI29_1@PAGEOFF]
	str	d0, [x9]
Lloh244:
	adrp	x8, l_.str.27@PAGE
Lloh245:
	add	x8, x8, l_.str.27@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x9, #12]
	str	wzr, [x9, #200]
	stur	q1, [x9, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x9, #44]
	ldur	q0, [x8, #43]
	stur	q0, [x9, #55]
	b	LBB29_10
LBB29_26:
	bl	___stack_chk_fail
LBB29_27:
	ldr	w10, [x10, #272]
	cmp	w10, #256
	b.hi	LBB29_30
; %bb.28:
	ldr	w9, [x20, #248]
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB29_30
; %bb.29:
	ldr	w11, [x20, #288]
	mov	w12, #1                         ; =0x1
	movk	w12, #256, lsl #16
	cmp	w11, w12
	b.lo	LBB29_32
LBB29_30:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh246:
	adrp	x8, lCPI29_2@PAGE
Lloh247:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x23]
Lloh248:
	adrp	x8, l_.str.28@PAGE
Lloh249:
	add	x8, x8, l_.str.28@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #25710                      ; =0x646e
LBB29_31:
	movk	w8, #46, lsl #16
	stur	w8, [x23, #43]
	stur	q1, [x23, #28]
	b	LBB29_10
LBB29_32:
	cbz	w10, LBB29_41
; %bb.33:
	ldr	x12, [x20, #256]
	cbz	x12, LBB29_41
; %bb.34:
	cbz	w11, LBB29_36
; %bb.35:
	ldr	x11, [x20, #280]
	cbz	x11, LBB29_41
LBB29_36:
	cbz	w9, LBB29_39
; %bb.37:
	ldr	x11, [x20, #232]
	cbz	x11, LBB29_41
; %bb.38:
	ldr	x11, [x20, #240]
	cbz	x11, LBB29_41
LBB29_39:
	ldr	w11, [x20, #224]
	cmp	w11, #16
	b.hi	LBB29_41
; %bb.40:
	ldr	w11, [x20, #16]
	cmp	w11, #17
	b.lo	LBB29_42
LBB29_41:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
Lloh250:
	adrp	x8, lCPI29_0@PAGE
Lloh251:
	ldr	d0, [x8, lCPI29_0@PAGEOFF]
	str	d0, [x23]
Lloh252:
	adrp	x8, l_.str.29@PAGE
Lloh253:
	add	x8, x8, l_.str.29@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	stur	q1, [x23, #28]
	ldur	q0, [x8, #30]
	stur	q0, [x23, #42]
	b	LBB29_10
LBB29_42:
	ldrb	w11, [x20]
	cmp	w11, #78
	b.ne	LBB29_59
; %bb.43:
	ldrb	w11, [x20, #1]
	cmp	w11, #86
	b.ne	LBB29_59
; %bb.44:
	ldrb	w11, [x20, #2]
	cmp	w11, #77
	b.ne	LBB29_59
; %bb.45:
	ldrb	w11, [x20, #3]
	cmp	w11, #1
	b.ne	LBB29_59
; %bb.46:
	ldr	w11, [x20, #4]
	cmp	w11, #2
	b.ne	LBB29_59
; %bb.47:
	ldr	w11, [x20, #8]
	cmp	w11, #8
	b.hs	LBB29_59
; %bb.48:
	tbz	w11, #0, LBB29_60
; %bb.49:
	ldr	w11, [x20, #12]
	cmp	w11, w10
	b.hs	LBB29_60
; %bb.50:
	cbz	w9, LBB29_57
; %bb.51:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x20, #232]
	mov	w12, #16777216                  ; =0x1000000
LBB29_52:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11, x10, lsl #3]
	cbz	x13, LBB29_106
; %bb.53:                               ;   in Loop: Header=BB29_52 Depth=1
	cmp	x8, x12
	b.hi	LBB29_108
; %bb.54:                               ;   in Loop: Header=BB29_52 Depth=1
	ldr	x14, [x20, #240]
	ldr	w14, [x14, x10, lsl #2]
	sub	x15, x12, x8
	cmp	x15, x14
	b.ls	LBB29_108
; %bb.55:                               ;   in Loop: Header=BB29_52 Depth=1
	add	x8, x14, x8
	add	x8, x8, #1
	str	x8, [x19, #16]
	ldrb	w13, [x13, x14]
	cbnz	w13, LBB29_110
; %bb.56:                               ;   in Loop: Header=BB29_52 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.ne	LBB29_52
LBB29_57:
	ldr	w9, [x20, #368]
	lsl	x9, x9, #5
	mov	w10, #16777216                  ; =0x1000000
	sub	x11, x10, x8
	cmp	x8, x10
	ccmp	x9, x11, #2, ls
	b.lo	LBB29_61
; %bb.58:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	stur	q0, [x23, #120]
	stur	q0, [x23, #136]
	stur	q0, [x23, #152]
	stur	q0, [x23, #168]
	stur	q0, [x23, #184]
Lloh254:
	adrp	x8, lCPI29_2@PAGE
Lloh255:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x23]
Lloh256:
	adrp	x8, l_.str.35@PAGE
Lloh257:
	add	x8, x8, l_.str.35@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x23, #28]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
	str	wzr, [x23, #200]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x23, #44]
	stur	q1, [x23, #12]
	b	LBB29_10
LBB29_59:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
Lloh258:
	adrp	x8, lCPI29_0@PAGE
Lloh259:
	ldr	d0, [x8, lCPI29_0@PAGEOFF]
	str	d0, [x23]
Lloh260:
	adrp	x8, l_.str.30@PAGE
Lloh261:
	add	x8, x8, l_.str.30@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	stur	q1, [x23, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x23, #44]
	b	LBB29_10
LBB29_60:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh262:
	adrp	x8, lCPI29_1@PAGE
Lloh263:
	ldr	d0, [x8, lCPI29_1@PAGEOFF]
	str	d0, [x23]
Lloh264:
	adrp	x8, l_.str.31@PAGE
Lloh265:
	add	x8, x8, l_.str.31@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x23, #44]
	stur	q1, [x23, #28]
	b	LBB29_10
LBB29_61:
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [x19, #16]
	mov	x0, x20
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB29_111
; %bb.62:
	add	x25, sp, #592
	add	x0, sp, #592
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	ldr	w8, [x20, #272]
	cbz	w8, LBB29_113
; %bb.63:
	mov	w26, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
LBB29_64:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_79 Depth 2
                                        ;     Child Loop BB29_87 Depth 2
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	madd	x27, x22, x10, x9
	ldr	w9, [x27, #12]
	cbnz	w9, LBB29_66
; %bb.65:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrb	w10, [x27, #21]
	cbnz	w10, LBB29_144
LBB29_66:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrh	w10, [x27, #16]
	cmp	w10, #257
	b.hs	LBB29_139
; %bb.67:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrh	w10, [x27, #18]
	cbnz	w10, LBB29_122
; %bb.68:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrb	w10, [x27, #21]
	cmp	w10, #1
	b.hi	LBB29_122
; %bb.69:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrb	w10, [x27, #20]
	cmp	w10, #6
	b.lo	LBB29_71
; %bb.70:                               ;   in Loop: Header=BB29_64 Depth=1
	cmp	w10, #10
	mov	w11, #1                         ; =0x1
	lsl	w10, w11, w10
	mov	w11, #1408                      ; =0x580
	and	w10, w10, w11
	ccmp	w10, #0, #4, ls
	b.eq	LBB29_122
LBB29_71:                               ;   in Loop: Header=BB29_64 Depth=1
	ldr	w10, [x27, #8]
	ldr	w11, [x20, #288]
	subs	w10, w11, w10
	ccmp	w9, w10, #2, hs
	b.hi	LBB29_140
; %bb.72:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrb	w10, [x19, #24]
	tbnz	w10, #0, LBB29_142
; %bb.73:                               ;   in Loop: Header=BB29_64 Depth=1
	ldrb	w10, [x19, #25]
	tbnz	w10, #0, LBB29_142
; %bb.74:                               ;   in Loop: Header=BB29_64 Depth=1
	ldr	x10, [x19, #16]
	mov	w11, #16777216                  ; =0x1000000
	cmp	x10, x11
	b.hi	LBB29_141
; %bb.75:                               ;   in Loop: Header=BB29_64 Depth=1
	add	x11, x8, x9
	add	x11, x11, #256
	mov	w12, #16777216                  ; =0x1000000
	sub	x12, x12, x10
	cmp	x11, x12
	b.hi	LBB29_141
; %bb.76:                               ;   in Loop: Header=BB29_64 Depth=1
	add	x10, x10, x11
	str	x10, [x19, #16]
	ldrh	w10, [x27, #4]
	cbz	x10, LBB29_84
; %bb.77:                               ;   in Loop: Header=BB29_64 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x12, [x20, #264]
	b	LBB29_79
LBB29_78:                               ;   in Loop: Header=BB29_79 Depth=2
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB29_84
LBB29_79:                               ;   Parent Loop BB29_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x11, #256
	b.eq	LBB29_119
; %bb.80:                               ;   in Loop: Header=BB29_79 Depth=2
	cbz	x12, LBB29_78
; %bb.81:                               ;   in Loop: Header=BB29_79 Depth=2
	ldr	x13, [x12, x22, lsl #3]
	cbz	x13, LBB29_78
; %bb.82:                               ;   in Loop: Header=BB29_79 Depth=2
	ldrb	w13, [x13, x11]
	cmp	w13, #6
	b.lo	LBB29_78
; %bb.83:                               ;   in Loop: Header=BB29_79 Depth=2
	cmp	w13, #10
	mov	w14, #1                         ; =0x1
	lsl	w13, w14, w13
	mov	w14, #1408                      ; =0x580
	and	w13, w13, w14
	ccmp	w13, #0, #4, ls
	b.ne	LBB29_78
	b	LBB29_145
LBB29_84:                               ;   in Loop: Header=BB29_64 Depth=1
	cbz	w9, LBB29_99
; %bb.85:                               ;   in Loop: Header=BB29_64 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB29_87
LBB29_86:                               ;   in Loop: Header=BB29_87 Depth=2
	ldr	w9, [x27, #12]
	add	w28, w21, w28
	cmp	w28, w9
	b.hs	LBB29_98
LBB29_87:                               ;   Parent Loop BB29_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x20, #280]
	ldr	w10, [x27, #8]
	add	x8, x8, x10
	add	x0, x8, w28, uxtw
	sub	w1, w9, w28
	add	x2, sp, #328
	bl	_isa_decode
	cbz	w0, LBB29_120
; %bb.88:                               ;   in Loop: Header=BB29_87 Depth=2
	add	w26, w26, #1
	cmp	w26, #16, lsl #12               ; =65536
	b.hi	LBB29_121
; %bb.89:                               ;   in Loop: Header=BB29_87 Depth=2
	mov	x21, x0
	ldr	w8, [x25, x22, lsl #2]
	add	w8, w8, #1
	str	w8, [x25, x22, lsl #2]
	ldrb	w0, [sp, #328]
	bl	_nvm_record_array_opcode_supported
	ldrb	w8, [sp, #328]
	tbz	w0, #0, LBB29_94
; %bb.90:                               ;   in Loop: Header=BB29_87 Depth=2
	cmp	w8, #251
	b.ne	LBB29_96
; %bb.91:                               ;   in Loop: Header=BB29_87 Depth=2
	ldrb	w8, [sp, #336]
	cmp	w8, #1
	b.hi	LBB29_132
; %bb.92:                               ;   in Loop: Header=BB29_87 Depth=2
	cbnz	w8, LBB29_86
; %bb.93:                               ;   in Loop: Header=BB29_87 Depth=2
	ldrh	w8, [sp, #352]
	cbz	w8, LBB29_86
	b	LBB29_132
LBB29_94:                               ;   in Loop: Header=BB29_87 Depth=2
	cmp	w8, #163
	b.eq	LBB29_96
; %bb.95:                               ;   in Loop: Header=BB29_87 Depth=2
	cmp	w8, #254
	b.ne	LBB29_132
LBB29_96:                               ;   in Loop: Header=BB29_87 Depth=2
	and	w8, w8, #0xfe
	cmp	w8, #18
	b.ne	LBB29_86
; %bb.97:                               ;   in Loop: Header=BB29_87 Depth=2
	ldr	w8, [sp, #336]
	cmp	w8, #256
	b.lo	LBB29_86
	b	LBB29_135
LBB29_98:                               ;   in Loop: Header=BB29_64 Depth=1
	ldr	w8, [x20, #272]
LBB29_99:                               ;   in Loop: Header=BB29_64 Depth=1
	add	x22, x22, #1
	cmp	x22, x8
	b.lo	LBB29_64
; %bb.100:
	ldrb	w10, [x19, #24]
	cbz	x8, LBB29_114
; %bb.101:
	mov	x9, #0                          ; =0x0
	ldr	x12, [x20, #256]
	add	x11, x8, #32
	add	x12, x12, #12
	mov	w13, #16777216                  ; =0x1000000
LBB29_102:                              ; =>This Inner Loop Header: Depth=1
	tbnz	w10, #0, LBB29_147
; %bb.103:                              ;   in Loop: Header=BB29_102 Depth=1
	ldrb	w14, [x19, #25]
	tbnz	w14, #0, LBB29_147
; %bb.104:                              ;   in Loop: Header=BB29_102 Depth=1
	ldr	w14, [x12]
	ldurh	w15, [x12, #-8]
	add	x14, x11, x14
	add	x14, x14, x15
	ldr	x15, [x19, #16]
	sub	x16, x13, x15
	cmp	x15, x13
	ccmp	x14, x16, #2, ls
	b.hi	LBB29_146
; %bb.105:                              ;   in Loop: Header=BB29_102 Depth=1
	add	x12, x12, #24
	add	x14, x15, x14
	str	x14, [x19, #16]
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB29_102
	b	LBB29_115
LBB29_106:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh266:
	adrp	x8, lCPI29_0@PAGE
Lloh267:
	ldr	d0, [x8, lCPI29_0@PAGEOFF]
	str	d0, [x23]
Lloh268:
	adrp	x8, l_.str.32@PAGE
Lloh269:
	add	x8, x8, l_.str.32@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #26478                      ; =0x676e
LBB29_107:
	movk	w8, #46, lsl #16
	str	w8, [x23, #44]
	stur	q1, [x23, #28]
	b	LBB29_10
LBB29_108:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	stur	q0, [x23, #120]
	stur	q0, [x23, #136]
	stur	q0, [x23, #152]
	stur	q0, [x23, #168]
	stur	q0, [x23, #184]
Lloh270:
	adrp	x8, lCPI29_2@PAGE
Lloh271:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x23]
Lloh272:
	adrp	x8, l_.str.33@PAGE
Lloh273:
	add	x8, x8, l_.str.33@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x23, #28]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, #24]
	str	wzr, [x23, #200]
	stur	q1, [x23, #12]
LBB29_109:
	ldr	x8, [x8, #32]
	stur	x8, [x23, #44]
	b	LBB29_10
LBB29_110:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh274:
	adrp	x8, lCPI29_0@PAGE
Lloh275:
	ldr	d0, [x8, lCPI29_0@PAGEOFF]
	str	d0, [x23]
Lloh276:
	adrp	x8, l_.str.34@PAGE
Lloh277:
	add	x8, x8, l_.str.34@PAGEOFF
	b	LBB29_112
LBB29_111:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh278:
	adrp	x8, lCPI29_0@PAGE
Lloh279:
	ldr	d0, [x8, lCPI29_0@PAGEOFF]
	str	d0, [x23]
Lloh280:
	adrp	x8, l_.str.36@PAGE
Lloh281:
	add	x8, x8, l_.str.36@PAGEOFF
LBB29_112:
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	stur	q1, [x23, #28]
	ldur	x8, [x8, #30]
	stur	x8, [x23, #42]
	b	LBB29_10
LBB29_113:
	ldrb	w10, [x19, #24]
LBB29_114:
	tbnz	w10, #0, LBB29_118
LBB29_115:
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB29_118
; %bb.116:
	ldr	x8, [x19, #16]
	mov	w9, #65505                      ; =0xffe1
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.lo	LBB29_124
; %bb.117:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB29_118:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh282:
	adrp	x8, lCPI29_2@PAGE
Lloh283:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x23]
Lloh284:
	adrp	x8, l_.str.49@PAGE
Lloh285:
	add	x8, x8, l_.str.49@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	stur	q1, [x23, #28]
	ldur	q0, [x8, #25]
	stur	q0, [x23, #37]
	b	LBB29_10
LBB29_119:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	str	wzr, [x23, #200]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x23]
Lloh286:
	adrp	x8, l_.str.42@PAGE
Lloh287:
	add	x8, x8, l_.str.42@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x23, #12]
	ldur	q0, [x8, #14]
	stur	q0, [x23, #26]
	b	LBB29_10
LBB29_120:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh288:
	adrp	x8, l_.str.44@PAGE
Lloh289:
	add	x8, x8, l_.str.44@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w9, #2                          ; =0x2
	b	LBB29_123
LBB29_121:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh290:
	adrp	x8, l_.str.45@PAGE
Lloh291:
	add	x8, x8, l_.str.45@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x23]
	stur	q1, [x23, #28]
	b	LBB29_10
LBB29_122:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh292:
	adrp	x8, l_.str.39@PAGE
Lloh293:
	add	x8, x8, l_.str.39@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w9, #1                          ; =0x1
LBB29_123:
	stp	w9, w22, [x23]
	stur	q1, [x23, #28]
	ldur	q0, [x8, #27]
	stur	q0, [x23, #39]
	b	LBB29_10
LBB29_124:
	add	x8, x8, #32
	str	x8, [x19, #16]
	add	x21, sp, #328
	add	x8, sp, #328
	mov	x0, x20
	bl	_verify_module_ranges
	ldrb	w8, [sp, #328]
	tbz	w8, #0, LBB29_136
; %bb.125:
	add	x21, sp, #328
	add	x8, sp, #328
	mov	x0, x20
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #328]
	tbz	w8, #0, LBB29_136
; %bb.126:
	mov	x0, x19
	mov	w1, #16777216                   ; =0x1000000
	bl	_nvm_ra_bytes
	cbz	w0, LBB29_131
; %bb.127:
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB29_131
; %bb.128:
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB29_131
; %bb.129:
	ldr	x8, [x19, #16]
	cmp	x8, #3840, lsl #12              ; =15728640
	b.ls	LBB29_148
; %bb.130:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB29_131:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh294:
	adrp	x8, lCPI29_2@PAGE
Lloh295:
	ldr	d0, [x8, lCPI29_2@PAGEOFF]
	str	d0, [x23]
Lloh296:
	adrp	x8, l_.str.50@PAGE
Lloh297:
	add	x8, x8, l_.str.50@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	stur	q1, [x23, #28]
	ldur	q0, [x8, #28]
	stur	q0, [x23, #40]
	b	LBB29_10
LBB29_132:
	str	wzr, [x23, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	mov	w8, #1                          ; =0x1
	stp	w8, w22, [x23]
Lloh298:
	adrp	x8, l_.str.46@PAGE
Lloh299:
	add	x8, x8, l_.str.46@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	ldur	q3, [x8, #41]
	stur	q3, [x23, #53]
LBB29_133:
	stur	q2, [x23, #44]
LBB29_134:
	stur	q1, [x23, #28]
	stur	q0, [x23, #12]
	b	LBB29_10
LBB29_135:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	str	wzr, [x23, #200]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x23]
Lloh300:
	adrp	x8, l_.str.47@PAGE
Lloh301:
	add	x8, x8, l_.str.47@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x23, #12]
	ldur	q0, [x8, #11]
	stur	q0, [x23, #23]
	b	LBB29_10
LBB29_136:
	add	x8, x21, #1
	str	wzr, [x23, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
Lloh302:
	adrp	x9, lCPI29_0@PAGE
Lloh303:
	ldr	d0, [x9, lCPI29_0@PAGEOFF]
	str	d0, [x23]
LBB29_137:
	str	x8, [sp]
LBB29_138:
Lloh304:
	adrp	x2, l_.str.67@PAGE
Lloh305:
	add	x2, x2, l_.str.67@PAGEOFF
	add	x0, x23, #12
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB29_10
LBB29_139:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	str	wzr, [x23, #200]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x23]
Lloh306:
	adrp	x8, l_.str.38@PAGE
Lloh307:
	add	x8, x8, l_.str.38@PAGEOFF
	ldr	q0, [x8]
	stur	q0, [x23, #12]
	ldur	q0, [x8, #10]
	stur	q0, [x23, #22]
	b	LBB29_10
LBB29_140:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh308:
	adrp	x8, l_.str.40@PAGE
Lloh309:
	add	x8, x8, l_.str.40@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w9, #2                          ; =0x2
	stp	w9, w22, [x23]
	stur	q1, [x23, #28]
	b	LBB29_109
LBB29_141:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB29_142:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh310:
	adrp	x8, l_.str.41@PAGE
Lloh311:
	add	x8, x8, l_.str.41@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #3                          ; =0x3
	stp	w8, w22, [x23]
LBB29_143:
	mov	w8, #25710                      ; =0x646e
	b	LBB29_107
LBB29_144:
	str	wzr, [x23, #200]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	mov	w8, #2                          ; =0x2
	stp	w8, w22, [x23]
Lloh312:
	adrp	x8, l_.str.37@PAGE
Lloh313:
	add	x8, x8, l_.str.37@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	ldr	x8, [x8, #48]
	stur	x8, [x23, #60]
	b	LBB29_133
LBB29_145:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh314:
	adrp	x8, l_.str.43@PAGE
Lloh315:
	add	x8, x8, l_.str.43@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #1                          ; =0x1
	stp	w8, w22, [x23]
	mov	w8, #29543                      ; =0x7367
	b	LBB29_31
LBB29_146:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB29_147:
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
Lloh316:
	adrp	x8, l_.str.48@PAGE
Lloh317:
	add	x8, x8, l_.str.48@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w10, #3                         ; =0x3
	stp	w10, w9, [x23]
	stur	q1, [x23, #28]
	ldur	q0, [x8, #29]
	stur	q0, [x23, #41]
	b	LBB29_10
LBB29_148:
	add	x8, x8, #256, lsl #12           ; =1048576
	mov	x0, x19
	str	x8, [x19, #16]
	mov	w1, #16                         ; =0x10
	bl	_nvm_ra_alloc
	cbz	x0, LBB29_152
; %bb.149:
	mov	x22, x0
	mov	x0, x19
	mov	w1, #8720                       ; =0x2210
	bl	_nvm_ra_alloc
	str	x0, [x22]
	cbz	x0, LBB29_153
; %bb.150:
	add	x8, sp, #32
	add	x1, x22, #8
	mov	x0, x20
	bl	_nvm_union_field_declarations_prepare
	ldr	w8, [sp, #32]
	cbz	w8, LBB29_154
; %bb.151:
	mov	x0, x22
	bl	_nvm_record_union_structure_free
	ldr	w8, [sp, #32]
	sub	w9, w8, #3
	cmp	w8, #1
	mov	w10, #1                         ; =0x1
	ldr	x11, [sp, #40]
	cinc	w10, w10, ne
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #8]
	cmp	w9, #2
	csel	w8, w8, w10, lo
	stur	q0, [x23, #24]
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	stur	q0, [x23, #120]
	stur	q0, [x23, #136]
	stur	q0, [x23, #152]
	stur	q0, [x23, #168]
	stur	q0, [x23, #184]
	str	wzr, [x23, #200]
	stp	w8, wzr, [x23]
	str	x11, [sp]
	b	LBB29_138
LBB29_152:
	ldrb	w8, [x19, #24]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #8]
	cinc	w8, w8, eq
	stur	q0, [x23, #24]
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	stur	q0, [x23, #120]
	stur	q0, [x23, #136]
	stur	q0, [x23, #152]
	stur	q0, [x23, #168]
	stur	q0, [x23, #184]
	str	wzr, [x23, #200]
	stp	w8, wzr, [x23]
Lloh318:
	adrp	x8, l_.str.51@PAGE
Lloh319:
	add	x8, x8, l_.str.51@PAGEOFF
	ldp	q0, q1, [x8]
	ldur	q2, [x8, #28]
	stur	q2, [x23, #40]
	b	LBB29_134
LBB29_153:
	mov	x0, x22
	bl	_nvm_record_union_structure_free
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #56]
	stur	q0, [x23, #8]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	stur	q0, [x23, #120]
	stur	q0, [x23, #136]
	stur	q0, [x23, #152]
	stur	q0, [x23, #168]
	stur	q0, [x23, #184]
Lloh320:
	adrp	x8, l_.str.52@PAGE
Lloh321:
	add	x8, x8, l_.str.52@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x23, #28]
	ldur	q0, [x8, #30]
	stur	q0, [x23, #42]
	ldrb	w8, [x19, #24]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	str	wzr, [x23, #200]
	stp	w8, wzr, [x23]
	stur	q1, [x23, #12]
	b	LBB29_10
LBB29_154:
	ldr	x25, [x22]
	ldr	w8, [x20, #272]
	str	w8, [x25, #8]
	cbz	w8, LBB29_165
; %bb.155:
	mov	w21, #0                         ; =0x0
	mov	w8, #8208                       ; =0x2010
	add	x8, x25, x8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	add	x8, x25, #16
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w26, #16777216                  ; =0x1000000
LBB29_156:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_157 Depth 2
	add	x8, sp, #592
	ldr	w28, [x8, w21, uxtw #2]
	mov	w9, #16                         ; =0x10
	mov	w27, w21
LBB29_157:                              ;   Parent Loop BB29_156 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x8, x9
	lsl	x9, x9, #1
	cmp	x8, x28
	b.lo	LBB29_157
; %bb.158:                              ;   in Loop: Header=BB29_156 Depth=1
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w27, w10, x9
	ldr	w9, [x9, #12]
	add	w9, w9, #1
	add	x9, x9, w9, uxtw #2
	mov	w10, #312                       ; =0x138
	mul	x8, x8, x10
	cmp	w28, #0
	csel	x8, xzr, x8, eq
	add	x1, x9, x8
	mov	x0, x19
	bl	_nvm_ra_bytes
	cbz	w0, LBB29_167
; %bb.159:                              ;   in Loop: Header=BB29_156 Depth=1
	ldrb	w8, [x19, #24]
	tbnz	w8, #0, LBB29_167
; %bb.160:                              ;   in Loop: Header=BB29_156 Depth=1
	ldrb	w8, [x19, #25]
	tbnz	w8, #0, LBB29_167
; %bb.161:                              ;   in Loop: Header=BB29_156 Depth=1
	ldr	x8, [x19, #16]
	cmp	x8, x26
	b.hi	LBB29_166
; %bb.162:                              ;   in Loop: Header=BB29_156 Depth=1
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w27, w10, x9
	ldr	w9, [x9, #12]
	lsl	w10, w28, #4
	add	x9, x9, x10
	sub	x10, x26, x8
	cmp	x9, x10
	b.hi	LBB29_166
; %bb.163:                              ;   in Loop: Header=BB29_156 Depth=1
	add	x8, x8, x9
	mov	x5, x19
	str	x8, [x19, #16]
	ldp	x8, x9, [sp, #16]               ; 16-byte Folded Reload
	add	x4, x9, x27, lsl #1
	add	x6, x8, x27, lsl #5
	add	x8, sp, #71
	mov	x0, x20
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_body
	add	x0, sp, #328
	add	x1, sp, #71
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #328]
	tbz	w8, #0, LBB29_168
; %bb.164:                              ;   in Loop: Header=BB29_156 Depth=1
	add	w21, w21, #1
	ldr	w8, [x25, #8]
	cmp	w21, w8
	b.lo	LBB29_156
LBB29_165:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #32]
	stp	q0, q0, [x23]
	stp	q0, q0, [x23, #64]
	stp	q0, q0, [x23, #96]
	stp	q0, q0, [x23, #128]
	stp	q0, q0, [x23, #160]
	stur	q0, [x23, #188]
Lloh322:
	adrp	x8, l_.str.55@PAGE
Lloh323:
	add	x8, x8, l_.str.55@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x23, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x23, #44]
	str	x22, [x24]
	ldur	x8, [x8, #46]
	stur	x8, [x23, #58]
	stur	q1, [x23, #12]
	b	LBB29_10
LBB29_166:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #24]
LBB29_167:
	mov	x0, x22
	bl	_nvm_record_union_structure_free
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
Lloh324:
	adrp	x8, l_.str.53@PAGE
Lloh325:
	add	x8, x8, l_.str.53@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x23, #12]
	str	wzr, [x23, #200]
	mov	w8, #3                          ; =0x3
	stp	w8, w21, [x23]
	b	LBB29_143
LBB29_168:
	mov	x0, x22
	bl	_nvm_record_union_structure_free
	ldrb	w8, [x19, #24]
	tbz	w8, #0, LBB29_170
; %bb.169:
	mov	w19, #3                         ; =0x3
	b	LBB29_172
LBB29_170:
	ldrb	w8, [x19, #25]
	mov	w19, #4                         ; =0x4
	tbnz	w8, #0, LBB29_172
; %bb.171:
	add	x8, sp, #328
Lloh326:
	adrp	x1, l_.str.54@PAGE
Lloh327:
	add	x1, x1, l_.str.54@PAGEOFF
	add	x0, x8, #1
	bl	_strstr
	cmp	x0, #0
	mov	w8, #2                          ; =0x2
	csel	w19, w8, w19, eq
LBB29_172:
	add	x8, sp, #328
	str	wzr, [x23, #200]
	add	x8, x8, #1
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #184]
	stur	q0, [x23, #168]
	stur	q0, [x23, #152]
	stur	q0, [x23, #136]
	stur	q0, [x23, #120]
	stur	q0, [x23, #104]
	stur	q0, [x23, #88]
	stur	q0, [x23, #72]
	stur	q0, [x23, #56]
	stur	q0, [x23, #40]
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	stp	w19, w21, [x23]
	b	LBB29_137
	.loh AdrpLdrGotLdr	Lloh224, Lloh225, Lloh226
	.loh AdrpAdd	Lloh229, Lloh230
	.loh AdrpAdrp	Lloh227, Lloh229
	.loh AdrpLdr	Lloh227, Lloh228
	.loh AdrpAdd	Lloh233, Lloh234
	.loh AdrpAdrp	Lloh231, Lloh233
	.loh AdrpLdr	Lloh231, Lloh232
	.loh AdrpLdrGotLdr	Lloh235, Lloh236, Lloh237
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdrp	Lloh238, Lloh240
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdrp	Lloh246, Lloh248
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdrp	Lloh254, Lloh256
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdrp	Lloh258, Lloh260
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdrp	Lloh274, Lloh276
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdrp	Lloh278, Lloh280
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdrp	Lloh294, Lloh296
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpLdr	Lloh302, Lloh303
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpAdd	Lloh326, Lloh327
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_ra_bytes
_nvm_ra_bytes:                          ; @nvm_ra_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB30_9
; %bb.1:
	ldrb	w8, [x0, #24]
	tbz	w8, #0, LBB30_3
; %bb.2:
	mov	w0, #0                          ; =0x0
	ret
LBB30_3:
	ldrb	w8, [x0, #25]
	tbz	w8, #0, LBB30_5
; %bb.4:
	mov	w0, #0                          ; =0x0
	ret
LBB30_5:
	ldr	x8, [x0]
	mov	w9, #67108864                   ; =0x4000000
	sub	x10, x9, x8
	cmp	x8, x9
	ccmp	x1, x10, #2, ls
	b.ls	LBB30_7
; %bb.6:
	mov	w9, #1                          ; =0x1
	strb	w9, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
LBB30_7:
	ldr	x9, [x0, #8]
	add	x8, x8, x1
	cmp	x9, x8
	str	x8, [x0]
	b.hs	LBB30_9
; %bb.8:
	str	x8, [x0, #8]
LBB30_9:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_module_ranges
_verify_module_ranges:                  ; @verify_module_ranges
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB31_3
; %bb.1:
	mov	x19, x0
	mov	x20, x8
	bl	_nvm_service_execution_pending
	cbz	w0, LBB31_5
; %bb.2:
Lloh328:
	adrp	x0, l_.str.108@PAGE
Lloh329:
	add	x0, x0, l_.str.108@PAGEOFF
	mov	x8, x20
	b	LBB31_4
LBB31_3:
Lloh330:
	adrp	x0, l_.str.107@PAGE
Lloh331:
	add	x0, x0, l_.str.107@PAGEOFF
LBB31_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	b	_fail
LBB31_5:
	ldr	x9, [x19, #280]
	cbz	x9, LBB31_33
LBB31_6:
	ldrb	w9, [x19, #8]
	tbnz	w9, #0, LBB31_9
; %bb.7:
	ldr	w10, [x19, #272]
	cbnz	w10, LBB31_10
LBB31_8:
	mov	w9, #1                          ; =0x1
	strb	w9, [x20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x20, #1]
	stur	q0, [x20, #17]
	stur	q0, [x20, #33]
	stur	q0, [x20, #49]
	stur	q0, [x20, #65]
	stur	q0, [x20, #81]
	stur	q0, [x20, #97]
	stur	q0, [x20, #113]
	stur	q0, [x20, #129]
	stur	q0, [x20, #145]
	stur	q0, [x20, #161]
	stur	q0, [x20, #177]
	stur	q0, [x20, #193]
	stur	q0, [x20, #209]
	stur	q0, [x20, #225]
	stur	q0, [x20, #241]
	b	LBB31_45
LBB31_9:
	ldr	w9, [x19, #12]
	ldr	w10, [x19, #272]
	cmp	w9, w10
	b.hs	LBB31_35
LBB31_10:
	mov	x12, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	ldr	x13, [x19, #256]
	ldr	w11, [x19, #288]
	add	x14, x13, #12
	mov	w15, #24                        ; =0x18
	b	LBB31_12
LBB31_11:                               ;   in Loop: Header=BB31_12 Depth=1
	add	w16, w9, #1
	sub	x12, x12, #1
	cmp	w16, w10
	b.eq	LBB31_8
LBB31_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB31_20 Depth 2
                                        ;     Child Loop BB31_30 Depth 2
	mov	w9, w16
	umaddl	x0, w16, w15, x13
	ldr	w16, [x0, #8]
	subs	w1, w11, w16
	b.lo	LBB31_37
; %bb.13:                               ;   in Loop: Header=BB31_12 Depth=1
	ldr	w17, [x0, #12]
	cmp	w17, w1
	b.hi	LBB31_38
; %bb.14:                               ;   in Loop: Header=BB31_12 Depth=1
	ldr	w1, [x0]
	ldr	w2, [x19, #248]
	cmp	w1, w2
	b.hs	LBB31_39
; %bb.15:                               ;   in Loop: Header=BB31_12 Depth=1
	ldrb	w1, [x0, #20]
	cmp	w1, #16
	b.hs	LBB31_40
; %bb.16:                               ;   in Loop: Header=BB31_12 Depth=1
	ldr	x2, [x19, #264]
	cbz	x2, LBB31_22
; %bb.17:                               ;   in Loop: Header=BB31_12 Depth=1
	ldr	x2, [x2, x9, lsl #3]
	cbz	x2, LBB31_22
; %bb.18:                               ;   in Loop: Header=BB31_12 Depth=1
	ldrh	w3, [x0, #4]
	cbz	x3, LBB31_22
; %bb.19:                               ;   in Loop: Header=BB31_12 Depth=1
	mov	x4, #0                          ; =0x0
LBB31_20:                               ;   Parent Loop BB31_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w5, [x2, x4]
	cmp	w5, #16
	b.hs	LBB31_36
; %bb.21:                               ;   in Loop: Header=BB31_20 Depth=2
	add	x4, x4, #1
	cmp	x3, x4
	b.ne	LBB31_20
LBB31_22:                               ;   in Loop: Header=BB31_12 Depth=1
	ldrb	w2, [x0, #21]
	cmp	w2, #0
	cset	w3, eq
	cmp	w1, #0
	cset	w1, ne
	eor	w1, w3, w1
	tbz	w1, #0, LBB31_41
; %bb.23:                               ;   in Loop: Header=BB31_12 Depth=1
	ldrh	w1, [x0, #16]
	ldrh	w0, [x0, #4]
	cmp	w1, w0
	b.lo	LBB31_42
; %bb.24:                               ;   in Loop: Header=BB31_12 Depth=1
	cbz	w2, LBB31_26
; %bb.25:                               ;   in Loop: Header=BB31_12 Depth=1
	cbz	w17, LBB31_43
LBB31_26:                               ;   in Loop: Header=BB31_12 Depth=1
	cbz	w17, LBB31_11
; %bb.27:                               ;   in Loop: Header=BB31_12 Depth=1
	cbz	w9, LBB31_11
; %bb.28:                               ;   in Loop: Header=BB31_12 Depth=1
	mov	x0, #0                          ; =0x0
	add	w17, w16, w17
	mov	x1, x14
	b	LBB31_30
LBB31_29:                               ;   in Loop: Header=BB31_30 Depth=2
	sub	x0, x0, #1
	add	x1, x1, #24
	cmp	x12, x0
	b.eq	LBB31_11
LBB31_30:                               ;   Parent Loop BB31_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w2, [x1]
	cbz	w2, LBB31_29
; %bb.31:                               ;   in Loop: Header=BB31_30 Depth=2
	ldur	w3, [x1, #-4]
	add	w2, w3, w2
	cmp	w16, w2
	ccmp	w3, w17, #2, lo
	b.hs	LBB31_29
; %bb.32:
	neg	x10, x0
	stp	x9, x10, [sp]
Lloh332:
	adrp	x0, l_.str.119@PAGE
Lloh333:
	add	x0, x0, l_.str.119@PAGEOFF
	b	LBB31_44
LBB31_33:
	ldr	w9, [x19, #288]
	cbz	w9, LBB31_6
; %bb.34:
	str	x9, [sp]
Lloh334:
	adrp	x0, l_.str.109@PAGE
Lloh335:
	add	x0, x0, l_.str.109@PAGEOFF
	b	LBB31_44
LBB31_35:
	stp	x9, x10, [sp]
Lloh336:
	adrp	x0, l_.str.110@PAGE
Lloh337:
	add	x0, x0, l_.str.110@PAGEOFF
	b	LBB31_44
LBB31_36:
	stp	x9, x4, [sp]
Lloh338:
	adrp	x0, l_.str.115@PAGE
Lloh339:
	add	x0, x0, l_.str.115@PAGEOFF
	b	LBB31_44
LBB31_37:
	stp	x16, x11, [sp, #8]
	str	x9, [sp]
Lloh340:
	adrp	x0, l_.str.111@PAGE
Lloh341:
	add	x0, x0, l_.str.111@PAGEOFF
	b	LBB31_44
LBB31_38:
	stp	x17, x11, [sp, #16]
	stp	x9, x16, [sp]
Lloh342:
	adrp	x0, l_.str.112@PAGE
Lloh343:
	add	x0, x0, l_.str.112@PAGEOFF
	b	LBB31_44
LBB31_39:
	stp	x1, x2, [sp, #8]
	str	x9, [sp]
Lloh344:
	adrp	x0, l_.str.113@PAGE
Lloh345:
	add	x0, x0, l_.str.113@PAGEOFF
	b	LBB31_44
LBB31_40:
	stp	x9, x1, [sp]
Lloh346:
	adrp	x0, l_.str.114@PAGE
Lloh347:
	add	x0, x0, l_.str.114@PAGEOFF
	b	LBB31_44
LBB31_41:
	str	x9, [sp]
Lloh348:
	adrp	x0, l_.str.116@PAGE
Lloh349:
	add	x0, x0, l_.str.116@PAGEOFF
	b	LBB31_44
LBB31_42:
	stp	x1, x0, [sp, #8]
	str	x9, [sp]
Lloh350:
	adrp	x0, l_.str.117@PAGE
Lloh351:
	add	x0, x0, l_.str.117@PAGEOFF
	b	LBB31_44
LBB31_43:
	stp	x9, x2, [sp]
Lloh352:
	adrp	x0, l_.str.118@PAGE
Lloh353:
	add	x0, x0, l_.str.118@PAGEOFF
LBB31_44:
	mov	x8, x20
	bl	_fail
LBB31_45:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh336, Lloh337
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh352, Lloh353
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_module_contracts_and_imports
_verify_module_contracts_and_imports:   ; @verify_module_contracts_and_imports
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x0
	mov	x19, x8
	bl	_nvm_passive_valid
	tbz	w0, #0, LBB32_4
; %bb.1:
	mov	x0, x20
	bl	_nvm_callback_contracts_valid
	cbz	w0, LBB32_5
; %bb.2:
	ldr	w8, [x20, #432]
	cbz	w8, LBB32_22
; %bb.3:
	mov	w8, #0                          ; =0x0
	mov	w23, #12                        ; =0xc
	b	LBB32_8
LBB32_4:
Lloh354:
	adrp	x0, l_.str.120@PAGE
Lloh355:
	add	x0, x0, l_.str.120@PAGEOFF
	b	LBB32_6
LBB32_5:
Lloh356:
	adrp	x0, l_.str.121@PAGE
Lloh357:
	add	x0, x0, l_.str.121@PAGEOFF
LBB32_6:
	mov	x8, x19
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_fail
LBB32_7:                                ;   in Loop: Header=BB32_8 Depth=1
	add	w8, w22, #1
	ldr	w9, [x20, #432]
	cmp	w8, w9
	b.hs	LBB32_22
LBB32_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_20 Depth 2
	ldr	x9, [x20, #400]
	mov	w22, w8
	umaddl	x24, w8, w23, x9
	ldr	w1, [x24]
	ldr	w8, [x20, #248]
	cmp	w1, w8
	b.hs	LBB32_27
; %bb.9:                                ;   in Loop: Header=BB32_8 Depth=1
	ldr	w9, [x24, #4]
	cmp	w9, w8
	b.hs	LBB32_28
; %bb.10:                               ;   in Loop: Header=BB32_8 Depth=1
	ldrb	w8, [x24, #11]
	cmp	w8, #3
	b.hs	LBB32_29
; %bb.11:                               ;   in Loop: Header=BB32_8 Depth=1
	cmp	w8, #2
	b.ne	LBB32_15
; %bb.12:                               ;   in Loop: Header=BB32_8 Depth=1
	mov	x0, x20
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_get_string
	cbz	x0, LBB32_26
; %bb.13:                               ;   in Loop: Header=BB32_8 Depth=1
	ldrb	w8, [x0]
	cmp	w8, #47
	b.ne	LBB32_26
; %bb.14:                               ;   in Loop: Header=BB32_8 Depth=1
	bl	_strlen
	mov	x21, x0
	ldr	w1, [x24]
	mov	x0, x20
	bl	_nvm_get_string_len
	cmp	x21, w0, uxtw
	b.ne	LBB32_26
LBB32_15:                               ;   in Loop: Header=BB32_8 Depth=1
	ldrb	w8, [x24, #10]
	cmp	w8, #16
	b.hs	LBB32_30
; %bb.16:                               ;   in Loop: Header=BB32_8 Depth=1
	ldrh	w8, [x24, #8]
	cmp	w8, #17
	b.hs	LBB32_31
; %bb.17:                               ;   in Loop: Header=BB32_8 Depth=1
	cbz	w8, LBB32_7
; %bb.18:                               ;   in Loop: Header=BB32_8 Depth=1
	ldr	x9, [x20, #408]
	ldr	x9, [x9, x22, lsl #3]
	cbz	x9, LBB32_32
; %bb.19:                               ;   in Loop: Header=BB32_8 Depth=1
	mov	x10, #0                         ; =0x0
LBB32_20:                               ;   Parent Loop BB32_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x9, x10]
	cmp	w11, #16
	b.hs	LBB32_23
; %bb.21:                               ;   in Loop: Header=BB32_20 Depth=2
	add	x10, x10, #1
	cmp	x8, x10
	b.ne	LBB32_20
	b	LBB32_7
LBB32_22:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB32_25
LBB32_23:
	stp	x10, x11, [sp, #8]
	str	x22, [sp]
Lloh358:
	adrp	x0, l_.str.129@PAGE
Lloh359:
	add	x0, x0, l_.str.129@PAGEOFF
LBB32_24:
	mov	x8, x19
	bl	_fail
LBB32_25:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB32_26:
	str	x22, [sp]
Lloh360:
	adrp	x0, l_.str.125@PAGE
Lloh361:
	add	x0, x0, l_.str.125@PAGEOFF
	b	LBB32_24
LBB32_27:
	stp	x1, x8, [sp, #8]
	str	x22, [sp]
Lloh362:
	adrp	x0, l_.str.122@PAGE
Lloh363:
	add	x0, x0, l_.str.122@PAGEOFF
	b	LBB32_24
LBB32_28:
	stp	x9, x8, [sp, #8]
	str	x22, [sp]
Lloh364:
	adrp	x0, l_.str.123@PAGE
Lloh365:
	add	x0, x0, l_.str.123@PAGEOFF
	b	LBB32_24
LBB32_29:
	stp	x22, x8, [sp]
Lloh366:
	adrp	x0, l_.str.124@PAGE
Lloh367:
	add	x0, x0, l_.str.124@PAGEOFF
	b	LBB32_24
LBB32_30:
	stp	x22, x8, [sp]
Lloh368:
	adrp	x0, l_.str.126@PAGE
Lloh369:
	add	x0, x0, l_.str.126@PAGEOFF
	b	LBB32_24
LBB32_31:
	mov	w9, #16                         ; =0x10
	stp	x8, x9, [sp, #8]
	str	x22, [sp]
Lloh370:
	adrp	x0, l_.str.127@PAGE
Lloh371:
	add	x0, x0, l_.str.127@PAGEOFF
	b	LBB32_24
LBB32_32:
	stp	x22, x8, [sp]
Lloh372:
	adrp	x0, l_.str.128@PAGE
Lloh373:
	add	x0, x0, l_.str.128@PAGEOFF
	b	LBB32_24
	.loh AdrpAdd	Lloh354, Lloh355
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh364, Lloh365
	.loh AdrpAdd	Lloh366, Lloh367
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh372, Lloh373
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_ra_alloc
_nvm_ra_alloc:                          ; @nvm_ra_alloc
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0, #24]
	tbnz	w8, #0, LBB33_4
; %bb.1:
	ldrb	w8, [x0, #25]
	tbnz	w8, #0, LBB33_4
; %bb.2:
	ldr	x8, [x0]
	mov	w9, #67108864                   ; =0x4000000
	sub	x10, x9, x8
	cmp	x8, x9
	ccmp	x1, x10, #2, ls
	b.ls	LBB33_5
; %bb.3:
	mov	w9, #1                          ; =0x1
	strb	w9, [x0, #24]
LBB33_4:
	mov	x0, #0                          ; =0x0
	ret
LBB33_5:
	ldr	x9, [x0, #8]
	add	x8, x8, x1
	cmp	x9, x8
	str	x8, [x0]
	b.hs	LBB33_7
; %bb.6:
	str	x8, [x0, #8]
LBB33_7:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w20, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	bl	_calloc
	cbnz	x0, LBB33_9
; %bb.8:
	strb	w20, [x19, #25]
LBB33_9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_function_body
_verify_function_body:                  ; @verify_function_body
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x24, x6
	mov	x23, x5
	mov	x26, x4
	mov	x25, x3
	mov	x28, x2
	mov	x21, x1
	mov	x27, x0
	mov	x22, x8
Lloh374:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh375:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh376:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	ldr	x19, [x0, #256]
	add	x20, sp, #424
	add	x2, sp, #128
	add	x3, sp, #424
	bl	_vm_decode_function
	cbz	w0, LBB34_3
; %bb.1:
	ldr	w8, [sp, #136]
	cbz	w8, LBB34_4
; %bb.2:
	stp	x28, x25, [sp, #72]             ; 16-byte Folded Spill
	stp	x22, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x26, [sp, #88]             ; 16-byte Folded Spill
	mov	x22, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w8, #24                         ; =0x18
	str	x21, [sp, #104]                 ; 8-byte Folded Spill
	umaddl	x11, w21, w8, x19
	b	LBB34_7
LBB34_3:
	str	x20, [sp]
Lloh377:
	adrp	x0, l_.str.67@PAGE
Lloh378:
	add	x0, x0, l_.str.67@PAGEOFF
	b	LBB34_150
LBB34_4:
	mov	w19, #1                         ; =0x1
	b	LBB34_56
LBB34_5:                                ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #468]
	sub	w9, w8, #1
	cmp	w9, w21
	b.lo	LBB34_179
LBB34_6:                                ;   in Loop: Header=BB34_7 Depth=1
	add	x28, x28, #1
	ldr	w8, [sp, #136]
	add	x22, x22, #104
	cmp	x28, x8
	b.hs	LBB34_55
LBB34_7:                                ; =>This Inner Loop Header: Depth=1
	cbz	x23, LBB34_12
; %bb.8:                                ;   in Loop: Header=BB34_7 Depth=1
	ldrb	w8, [x23, #24]
	tbnz	w8, #0, LBB34_146
; %bb.9:                                ;   in Loop: Header=BB34_7 Depth=1
	ldrb	w8, [x23, #25]
	tbnz	w8, #0, LBB34_146
; %bb.10:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [x23, #16]
	mov	w9, #65529                      ; =0xfff9
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.hs	LBB34_145
; %bb.11:                               ;   in Loop: Header=BB34_7 Depth=1
	add	x8, x8, #8
	str	x8, [x23, #16]
LBB34_12:                               ;   in Loop: Header=BB34_7 Depth=1
	mov	x20, x11
	ldr	x8, [sp, #128]
	add	x8, x8, x22
	ldr	w19, [x8]
	ldrb	w27, [x8, #40]
	ldr	w21, [x8, #48]
	ldr	w24, [x8, #56]
	ldrh	w25, [x8, #64]
	ldrh	w26, [x8, #72]
	mov	x0, x27
	bl	_isa_get_info
	cbz	x0, LBB34_54
; %bb.13:                               ;   in Loop: Header=BB34_7 Depth=1
	sub	w8, w27, #4
	cmp	w8, #251
	mov	x11, x20
	b.hi	LBB34_6
; %bb.14:                               ;   in Loop: Header=BB34_7 Depth=1
Lloh379:
	adrp	x12, lJTI34_0@PAGE
Lloh380:
	add	x12, x12, lJTI34_0@PAGEOFF
	adr	x9, LBB34_5
	ldrh	w10, [x12, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB34_15:                               ;   in Loop: Header=BB34_7 Depth=1
	add	x27, x19, w21, sxtw
	lsr	x8, x27, #32
	cbnz	x8, LBB34_175
; %bb.16:                               ;   in Loop: Header=BB34_7 Depth=1
	add	x0, sp, #128
	mov	x1, x27
	bl	_vm_decoded_function_has_boundary
	mov	x11, x20
	tbnz	w0, #0, LBB34_6
	b	LBB34_175
LBB34_17:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #272]
	cmp	w21, w8
	b.hs	LBB34_184
; %bb.18:                               ;   in Loop: Header=BB34_7 Depth=1
	cmp	w27, #51
	b.ne	LBB34_6
; %bb.19:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w21, w9, x8
	ldrb	w9, [x8, #21]
	ldrb	w10, [x11, #21]
	cmp	w9, w10
	b.ne	LBB34_188
; %bb.20:                               ;   in Loop: Header=BB34_7 Depth=1
	ldrb	w8, [x8, #20]
	ldrb	w9, [x11, #20]
	cmp	w8, w9
	b.eq	LBB34_6
	b	LBB34_188
LBB34_21:                               ;   in Loop: Header=BB34_7 Depth=1
	tst	w21, #0xffff
	b.ne	LBB34_181
; %bb.22:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w24, #0xffff
	ldrh	w9, [x11, #18]
	cmp	w8, w9
	b.lo	LBB34_6
	b	LBB34_187
LBB34_23:                               ;   in Loop: Header=BB34_7 Depth=1
	cmp	w21, #1, lsl #12                ; =4096
	b.lo	LBB34_6
	b	LBB34_180
LBB34_24:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w21, #0xff
	cmp	w8, #16
	b.lo	LBB34_6
	b	LBB34_182
LBB34_25:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w21, #0xffff
	ldrh	w9, [x11, #16]
	cmp	w8, w9
	b.lo	LBB34_6
	b	LBB34_183
LBB34_26:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x9, #272]
	cmp	w21, w8
	b.hs	LBB34_203
; %bb.27:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w24, #0xffff
	ldr	x9, [x9, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w21, w10, x9
	ldrh	w9, [x9, #18]
	cmp	w8, w9
	b.eq	LBB34_6
	b	LBB34_207
LBB34_28:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cmp	w21, w8
	b.hs	LBB34_185
; %bb.29:                               ;   in Loop: Header=BB34_7 Depth=1
	ldrh	w8, [x11, #16]
	add	w9, w26, w25
	cmp	w9, w8
	b.hi	LBB34_185
; %bb.30:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #128]
	add	x8, x8, x22
	ldr	w8, [x8, #8]
	ldp	w9, w10, [x11, #8]
	add	w9, w10, w9
	cmp	w8, w9
	b.lo	LBB34_6
	b	LBB34_208
LBB34_31:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #476]
	sub	w9, w8, #1
	cmp	w9, w21
	b.hs	LBB34_6
	b	LBB34_202
LBB34_32:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	w8, LBB34_6
; %bb.33:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cmp	w21, w8
	b.hs	LBB34_212
; %bb.34:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, w21, uxtw #3]
	cbz	x9, LBB34_213
; %bb.35:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	w8, [x9, #272]
	cmp	w24, w8
	b.hs	LBB34_214
; %bb.36:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [x9, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x9, w24, w9, x8
	ldrh	w8, [x9, #4]
	cmp	w25, w8
	b.ne	LBB34_216
; %bb.37:                               ;   in Loop: Header=BB34_7 Depth=1
	ldrb	w8, [x9, #21]
	cmp	w26, w8
	b.eq	LBB34_6
	b	LBB34_217
LBB34_38:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w21, #0xff
	cmp	w8, #16
	b.lo	LBB34_6
	b	LBB34_197
LBB34_39:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #432]
	cmp	w21, w8
	b.lo	LBB34_6
	b	LBB34_201
LBB34_40:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w21, #0xff
	cmp	w8, #3
	b.hs	LBB34_196
; %bb.41:                               ;   in Loop: Header=BB34_7 Depth=1
	cmp	w8, #1
	b.eq	LBB34_52
; %bb.42:                               ;   in Loop: Header=BB34_7 Depth=1
	cbnz	w8, LBB34_6
; %bb.43:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #468]
	sub	w9, w8, #1
	cmp	w9, w24
	b.hs	LBB34_6
	b	LBB34_221
LBB34_44:                               ;   in Loop: Header=BB34_7 Depth=1
	add	x27, x19, w24, sxtw
	lsr	x8, x27, #32
	cbnz	x8, LBB34_186
; %bb.45:                               ;   in Loop: Header=BB34_7 Depth=1
	add	x0, sp, #128
	mov	x1, x27
	bl	_vm_decoded_function_has_boundary
	mov	x11, x20
	tbnz	w0, #0, LBB34_6
	b	LBB34_186
LBB34_46:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #472]
	sub	w9, w8, #1
	cmp	w9, w21
	b.hs	LBB34_6
	b	LBB34_200
LBB34_47:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cmp	w21, w8
	b.lo	LBB34_6
	b	LBB34_205
LBB34_48:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cmp	w21, w8
	b.lo	LBB34_6
	b	LBB34_198
LBB34_49:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #272]
	cmp	w21, w8
	b.lo	LBB34_6
	b	LBB34_204
LBB34_50:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w21, #0xff
	cmp	w8, #16
	b.hs	LBB34_199
; %bb.51:                               ;   in Loop: Header=BB34_7 Depth=1
	and	w8, w24, #0xff
	cmp	w8, #16
	b.lo	LBB34_6
	b	LBB34_206
LBB34_52:                               ;   in Loop: Header=BB34_7 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #476]
	sub	w9, w8, #1
	cmp	w9, w24
	b.hs	LBB34_6
; %bb.53:
	stp	x24, x8, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh381:
	adrp	x0, l_.str.160@PAGE
Lloh382:
	add	x0, x0, l_.str.160@PAGEOFF
	b	LBB34_147
LBB34_54:
	ldr	w8, [x20, #8]
	add	w8, w8, w19
	stp	x27, x8, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh383:
	adrp	x0, l_.str.131@PAGE
Lloh384:
	add	x0, x0, l_.str.131@PAGEOFF
	b	LBB34_147
LBB34_55:
	add	w19, w8, #1
	ldp	x21, x22, [sp, #104]            ; 16-byte Folded Reload
	ldp	x24, x26, [sp, #88]             ; 16-byte Folded Reload
	ldr	x27, [sp, #120]                 ; 8-byte Folded Reload
LBB34_56:
	add	x8, x19, x19, lsl #1
	lsl	x20, x8, #2
	cbz	x23, LBB34_66
; %bb.57:
	ldrb	w8, [x23, #24]
	tbnz	w8, #0, LBB34_149
; %bb.58:
	ldrb	w8, [x23, #25]
	tbnz	w8, #0, LBB34_149
; %bb.59:
	ldr	x8, [x23]
	mov	w9, #67108864                   ; =0x4000000
	cmp	x8, x9
	b.hi	LBB34_148
; %bb.60:
	sub	x9, x9, x8
	cmp	x20, x9
	b.hi	LBB34_148
; %bb.61:
	ldr	x9, [x23, #8]
	add	x8, x8, x20
	cmp	x9, x8
	str	x8, [x23]
	b.hs	LBB34_63
; %bb.62:
	str	x8, [x23, #8]
LBB34_63:
	ldr	x8, [x23, #16]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB34_148
; %bb.64:
	lsl	x10, x19, #5
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB34_148
; %bb.65:
	add	x8, x8, x10
	str	x8, [x23, #16]
LBB34_66:
	lsl	x25, x19, #2
	mov	x0, x25
	bl	_malloc
	mov	x28, x0
	mov	x0, x25
	bl	_malloc
	stp	x26, x21, [sp, #96]             ; 16-byte Folded Spill
	str	x24, [sp, #88]                  ; 8-byte Folded Spill
	str	x27, [sp, #120]                 ; 8-byte Folded Spill
	str	x20, [sp, #40]                  ; 8-byte Folded Spill
	cbz	x28, LBB34_70
; %bb.67:
	cbz	x0, LBB34_70
; %bb.68:
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	mov	x0, x25
	bl	_malloc
	cbz	x0, LBB34_155
; %bb.69:
	mov	x24, x0
	str	x22, [sp, #112]                 ; 8-byte Folded Spill
	mov	w8, w21
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	cmp	x19, #1
	csinc	x8, x19, xzr, hi
	mov	x19, x28
	lsl	x28, x8, #2
	mov	w1, #255                        ; =0xff
	mov	x2, x28
	bl	_memset
	str	wzr, [x24]
	mov	x0, x19
	mov	w1, #255                        ; =0xff
	mov	x2, x28
	bl	_memset
	mov	x22, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	str	x19, [sp, #72]                  ; 8-byte Folded Spill
	str	wzr, [x19]
	ldr	x12, [sp, #80]                  ; 8-byte Folded Reload
	str	wzr, [x12]
	mov	w14, #1                         ; =0x1
	str	x24, [sp, #56]                  ; 8-byte Folded Spill
	b	LBB34_73
LBB34_70:
	mov	x19, x0
	mov	x0, x28
	bl	_free
	mov	x0, x19
	b	LBB34_156
LBB34_71:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	ldr	w14, [sp, #68]                  ; 4-byte Folded Reload
LBB34_72:                               ;   in Loop: Header=BB34_73 Depth=1
	add	x22, x22, #1
	cmp	x22, w14, uxtw
	b.hs	LBB34_176
LBB34_73:                               ; =>This Inner Loop Header: Depth=1
	ldr	w21, [x12, x22, lsl #2]
	ldr	w8, [sp, #136]
	cmp	w21, w8
	b.eq	LBB34_72
; %bb.74:                               ;   in Loop: Header=BB34_73 Depth=1
	str	w14, [sp, #68]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #128]
	mov	w9, #104                        ; =0x68
	umaddl	x25, w21, w9, x8
	ldrb	w0, [x25, #40]
	bl	_isa_get_info
	ldrsb	w19, [x0, #28]
	ldrsb	w8, [x0, #29]
	ldrb	w26, [x25, #40]
	cmp	w26, #243
	b.gt	LBB34_78
; %bb.75:                               ;   in Loop: Header=BB34_73 Depth=1
	sub	w9, w26, #51
	cmp	w9, #116
	b.hi	LBB34_91
; %bb.76:                               ;   in Loop: Header=BB34_73 Depth=1
Lloh385:
	adrp	x12, lJTI34_1@PAGE
Lloh386:
	add	x12, x12, lJTI34_1@PAGEOFF
	adr	x10, LBB34_77
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB34_77:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w19, [x25, #56]
	mov	w8, #1                          ; =0x1
	b	LBB34_91
LBB34_78:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #244
	b.eq	LBB34_89
; %bb.79:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #245
	b.eq	LBB34_90
; %bb.80:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #251
	b.ne	LBB34_91
; %bb.81:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w19, [x25, #72]
	mov	w8, #1                          ; =0x1
	b	LBB34_91
LBB34_82:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	ldr	w9, [x25, #48]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w19, [x8, #4]
	ldrb	w8, [x8, #21]
	b	LBB34_91
LBB34_83:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w19, [x25, #48]
	mov	w8, #1                          ; =0x1
	b	LBB34_91
LBB34_84:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #400]
	ldr	w9, [x25, #48]
	mov	w10, #12                        ; =0xc
	umaddl	x8, w9, w10, x8
	ldrh	w19, [x8, #8]
	ldrb	w8, [x8, #10]
	cmp	w8, #0
	cset	w8, ne
	b	LBB34_91
LBB34_85:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w8, [x25, #48]
	add	w19, w8, #1
	ldrh	w8, [x25, #56]
	b	LBB34_91
LBB34_86:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w19, [x25, #64]
	mov	w8, #1                          ; =0x1
	b	LBB34_91
LBB34_87:                               ;   in Loop: Header=BB34_73 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #256]
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrb	w24, [x9, #21]
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w20, [x9, x21, lsl #2]
	mov	x19, x24
	b	LBB34_97
LBB34_88:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w19, [x25, #64]
	ldrh	w8, [x25, #72]
	b	LBB34_91
LBB34_89:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w8, [x25, #48]
	add	w19, w8, #1
	add	w8, w8, #2
	b	LBB34_91
LBB34_90:                               ;   in Loop: Header=BB34_73 Depth=1
	ldrh	w8, [x25, #48]
	add	w8, w8, #1
	mov	x19, x8
LBB34_91:                               ;   in Loop: Header=BB34_73 Depth=1
	tbnz	w19, #31, LBB34_190
; %bb.92:                               ;   in Loop: Header=BB34_73 Depth=1
	tbnz	w8, #31, LBB34_190
; %bb.93:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w20, [x9, x21, lsl #2]
	cmp	w26, #168
	b.eq	LBB34_101
; %bb.94:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #165
	b.eq	LBB34_99
; %bb.95:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #61
	b.ne	LBB34_104
; %bb.96:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #256]
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	ldrb	w24, [x9, #21]
LBB34_97:                               ;   in Loop: Header=BB34_73 Depth=1
	cmp	w20, w24
	b.ne	LBB34_215
; %bb.98:                               ;   in Loop: Header=BB34_73 Depth=1
	mov	w27, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	mov	x20, x24
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB34_105
LBB34_99:                               ;   in Loop: Header=BB34_73 Depth=1
	ldr	w9, [x24, x21, lsl #2]
	cbnz	w9, LBB34_219
; %bb.100:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w27, #1                         ; =0x1
	b	LBB34_105
LBB34_101:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w20, #1
	b.ne	LBB34_209
; %bb.102:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w9, [x24, x21, lsl #2]
	cbnz	w9, LBB34_209
; %bb.103:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w27, #0                         ; =0x0
	mov	w20, #1                         ; =0x1
	b	LBB34_105
LBB34_104:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w9, #0                          ; =0x0
	mov	w27, #0                         ; =0x0
LBB34_105:                              ;   in Loop: Header=BB34_73 Depth=1
	subs	w10, w20, w19
	b.lt	LBB34_189
; %bb.106:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w24, [x24, x21, lsl #2]
	cmp	w26, #129
	b.eq	LBB34_109
; %bb.107:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	x19, x24
	cmp	w26, #128
	b.ne	LBB34_110
; %bb.108:                              ;   in Loop: Header=BB34_73 Depth=1
	add	w19, w24, #1
	b	LBB34_110
LBB34_109:                              ;   in Loop: Header=BB34_73 Depth=1
	sub	w19, w24, #1
LBB34_110:                              ;   in Loop: Header=BB34_73 Depth=1
	tbnz	w19, #31, LBB34_191
; %bb.111:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w24, #0
	csel	w9, wzr, w9, eq
	cmp	w9, #1
	b.eq	LBB34_194
; %bb.112:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w20, w28
	csel	w9, w20, w28, gt
	add	w20, w10, w8
	cmp	w20, w9
	csel	w28, w20, w9, gt
	sub	w8, w26, #56
	cmp	w8, #3
	b.lo	LBB34_115
; %bb.113:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #165
	b.eq	LBB34_115
; %bb.114:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #107
	b.ne	LBB34_127
LBB34_115:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldr	w8, [x8, #8]
	ldr	w24, [x25, #8]
	subs	w1, w24, w8
	b.lo	LBB34_178
; %bb.116:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w8, [sp, #140]
	cmp	w1, w8
	b.ne	LBB34_118
; %bb.117:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w9, [sp, #136]
	b	LBB34_120
LBB34_118:                              ;   in Loop: Header=BB34_73 Depth=1
	add	x0, sp, #128
	bl	_vm_decoded_function_at
	cbz	x0, LBB34_178
; %bb.119:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #128]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w9, w8, w9
LBB34_120:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w8, #0                          ; =0x0
	stur	w9, [x29, #-104]
	mov	w9, #1                          ; =0x1
LBB34_121:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x12, [sp, #80]                  ; 8-byte Folded Reload
	cmp	w26, #61
	b.hi	LBB34_123
; %bb.122:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w10, #1                         ; =0x1
	lsl	x10, x10, x26
	mov	x11, #2380152403065307136       ; =0x2108000000000000
	tst	x10, x11
	b.ne	LBB34_125
LBB34_123:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #163
	b.eq	LBB34_125
; %bb.124:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w26, #168
	b.ne	LBB34_128
LBB34_125:                              ;   in Loop: Header=BB34_73 Depth=1
	tbnz	w8, #0, LBB34_71
; %bb.126:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB34_129
LBB34_127:                              ;   in Loop: Header=BB34_73 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	b	LBB34_121
LBB34_128:                              ;   in Loop: Header=BB34_73 Depth=1
	add	w10, w21, #1
	sub	x11, x29, #104
	str	w10, [x11, x9, lsl #2]
LBB34_129:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w10, [sp, #136]
	ldur	w9, [x29, #-104]
	cmp	w27, #0
	csel	w24, wzr, w20, ne
	csel	w26, wzr, w19, ne
	cmp	w9, w10
	b.ne	LBB34_132
; %bb.130:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	w14, [sp, #68]                  ; 4-byte Folded Reload
	cbnz	w19, LBB34_211
; %bb.131:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #256]
	ldr	x11, [sp, #48]                  ; 8-byte Folded Reload
	mov	w13, #24                        ; =0x18
	umaddl	x9, w11, w13, x9
	ldrb	w21, [x9, #21]
	cmp	w20, w21
	b.eq	LBB34_136
	b	LBB34_218
LBB34_132:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	ldr	w21, [x11, x9, lsl #2]
	tbnz	w21, #31, LBB34_135
; %bb.133:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	ldr	w27, [x11, x9, lsl #2]
	cmp	w27, w26
	b.ne	LBB34_222
; %bb.134:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w21, w24
	ldr	w14, [sp, #68]                  ; 4-byte Folded Reload
	b.eq	LBB34_136
	b	LBB34_229
LBB34_135:                              ;   in Loop: Header=BB34_73 Depth=1
	str	w24, [x11, x9, lsl #2]
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	str	w26, [x11, x9, lsl #2]
	ldr	w11, [sp, #68]                  ; 4-byte Folded Reload
	str	w9, [x12, w11, uxtw #2]
	add	w14, w11, #1
LBB34_136:                              ;   in Loop: Header=BB34_73 Depth=1
	tbz	w8, #0, LBB34_138
; %bb.137:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB34_72
LBB34_138:                              ;   in Loop: Header=BB34_73 Depth=1
	ldur	w9, [x29, #-100]
	cmp	w9, w10
	b.ne	LBB34_141
; %bb.139:                              ;   in Loop: Header=BB34_73 Depth=1
	cbnz	w19, LBB34_211
; %bb.140:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	ldp	x9, x24, [sp, #48]              ; 16-byte Folded Reload
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrb	w21, [x8, #21]
	cmp	w20, w21
	b.eq	LBB34_72
	b	LBB34_223
LBB34_141:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w21, [x8, x9, lsl #2]
	tbnz	w21, #31, LBB34_144
; %bb.142:                              ;   in Loop: Header=BB34_73 Depth=1
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	ldr	w27, [x24, x9, lsl #2]
	cmp	w27, w19
	b.ne	LBB34_225
; %bb.143:                              ;   in Loop: Header=BB34_73 Depth=1
	cmp	w21, w20
	b.eq	LBB34_72
	b	LBB34_228
LBB34_144:                              ;   in Loop: Header=BB34_73 Depth=1
	str	w20, [x8, x9, lsl #2]
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	str	w19, [x24, x9, lsl #2]
	str	w9, [x12, w14, uxtw #2]
	add	w14, w14, #1
	b	LBB34_72
LBB34_145:
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #24]
LBB34_146:
Lloh387:
	adrp	x0, l_.str.130@PAGE
Lloh388:
	add	x0, x0, l_.str.130@PAGEOFF
LBB34_147:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	bl	_fail
	add	x0, sp, #128
	bl	_vm_decoded_function_free
	b	LBB34_151
LBB34_148:
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #24]
LBB34_149:
	add	x0, sp, #128
	bl	_vm_decoded_function_free
Lloh389:
	adrp	x0, l_.str.166@PAGE
Lloh390:
	add	x0, x0, l_.str.166@PAGEOFF
LBB34_150:
	mov	x8, x22
	bl	_fail
LBB34_151:
	ldur	x8, [x29, #-96]
Lloh391:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh392:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh393:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB34_230
; %bb.152:
	add	sp, sp, #704
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB34_153:
	add	x19, sp, #164
	add	x8, sp, #164
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #164]
	tbz	w8, #0, LBB34_174
; %bb.154:
Lloh394:
	adrp	x0, l_.str.133@PAGE
Lloh395:
	add	x0, x0, l_.str.133@PAGEOFF
	b	LBB34_147
LBB34_155:
	mov	x0, x28
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
LBB34_156:
	bl	_free
	mov	x8, x21
	str	x8, [sp]
Lloh396:
	adrp	x0, l_.str.168@PAGE
Lloh397:
	add	x0, x0, l_.str.168@PAGEOFF
LBB34_157:
	add	x8, sp, #164
	bl	_fail
LBB34_158:
	mov	w28, #0                         ; =0x0
LBB34_159:
	cbz	x23, LBB34_162
; %bb.160:
	ldr	x8, [x23]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	sub	x8, x8, x9
	str	x8, [x23]
	and	w8, w28, #0xffff
	cmp	w8, #257
	b.lo	LBB34_164
; %bb.161:
	add	x0, sp, #128
	bl	_vm_decoded_function_free
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #24]
Lloh398:
	adrp	x0, l_.str.167@PAGE
Lloh399:
	add	x0, x0, l_.str.167@PAGEOFF
	b	LBB34_150
LBB34_162:
	ldrb	w8, [sp, #164]
	tbz	w8, #0, LBB34_166
; %bb.163:
	add	x8, sp, #164
	add	x2, sp, #128
	and	w3, w28, #0xffff
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	bl	_nvm_verify_function_types
	b	LBB34_166
LBB34_164:
	ldrb	w8, [sp, #164]
	tbz	w8, #0, LBB34_166
; %bb.165:
	add	x8, sp, #164
	add	x2, sp, #128
	and	w3, w28, #0xffff
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x4, x23
	bl	_nvm_verify_function_types_record_array
LBB34_166:
	ldrb	w8, [sp, #164]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	cbz	x9, LBB34_169
; %bb.167:
	cbz	w8, LBB34_169
; %bb.168:
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	strh	w28, [x9]
LBB34_169:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	cbz	x9, LBB34_172
; %bb.170:
	cbz	w8, LBB34_172
; %bb.171:
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x9]
	b	LBB34_173
LBB34_172:
	add	x0, sp, #128
	bl	_vm_decoded_function_free
LBB34_173:
	add	x1, sp, #164
	mov	x0, x22
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB34_151
LBB34_174:
	add	x8, x19, #16
	str	x8, [sp]
Lloh400:
	adrp	x0, l_.str.132@PAGE
Lloh401:
	add	x0, x0, l_.str.132@PAGEOFF
	b	LBB34_147
LBB34_175:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	stp	x8, x27, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	str	x8, [sp]
Lloh402:
	adrp	x0, l_.str.134@PAGE
Lloh403:
	add	x0, x0, l_.str.134@PAGEOFF
	b	LBB34_147
LBB34_176:
	mov	x19, x12
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x0, x24
	bl	_free
	ldp	x22, x8, [sp, #112]             ; 16-byte Folded Reload
	ldr	x8, [x8, #256]
	mov	w9, #24                         ; =0x18
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	umaddl	x8, w10, w9, x8
	ldrh	w9, [x8, #16]
	add	w8, w28, w9
	cmp	w8, #16, lsl #12                ; =65536
	b.lo	LBB34_192
; %bb.177:
	stp	x9, x28, [sp, #16]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh404:
	adrp	x0, l_.str.181@PAGE
Lloh405:
	add	x0, x0, l_.str.181@PAGEOFF
	b	LBB34_157
LBB34_178:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	ldr	w8, [x25]
	stp	x8, x24, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh406:
	adrp	x0, l_.str.176@PAGE
Lloh407:
	add	x0, x0, l_.str.176@PAGEOFF
	b	LBB34_227
LBB34_179:
	ldr	x9, [x0]
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	stp	x21, x8, [sp, #24]
	stp	x9, x10, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh408:
	adrp	x0, l_.str.155@PAGE
Lloh409:
	add	x0, x0, l_.str.155@PAGEOFF
	b	LBB34_147
LBB34_180:
	ldr	x8, [x0]
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	mov	w10, #4096                      ; =0x1000
	stp	x21, x10, [sp, #24]
	stp	x8, x9, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh410:
	adrp	x0, l_.str.151@PAGE
Lloh411:
	add	x0, x0, l_.str.151@PAGEOFF
	b	LBB34_147
LBB34_181:
	ldr	x8, [x0]
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x8, x9, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh412:
	adrp	x0, l_.str.153@PAGE
Lloh413:
	add	x0, x0, l_.str.153@PAGEOFF
	b	LBB34_147
LBB34_182:
	ldr	x9, [x0]
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	mov	w11, #16                        ; =0x10
	stp	x8, x11, [sp, #24]
	stp	x9, x10, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh414:
	adrp	x0, l_.str.161@PAGE
Lloh415:
	add	x0, x0, l_.str.161@PAGEOFF
	b	LBB34_147
LBB34_183:
	ldr	x10, [x0]
	ldr	w11, [x11, #8]
	add	w11, w11, w19
	stp	x8, x9, [sp, #24]
	stp	x10, x11, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh416:
	adrp	x0, l_.str.152@PAGE
Lloh417:
	add	x0, x0, l_.str.152@PAGEOFF
	b	LBB34_147
LBB34_184:
	ldr	x9, [x0]
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	stp	x21, x8, [sp, #24]
	stp	x9, x10, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh418:
	adrp	x0, l_.str.139@PAGE
Lloh419:
	add	x0, x0, l_.str.139@PAGEOFF
	b	LBB34_147
LBB34_185:
Lloh420:
	adrp	x0, l_.str.135@PAGE
Lloh421:
	add	x0, x0, l_.str.135@PAGEOFF
	b	LBB34_147
LBB34_186:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	stp	x8, x27, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh422:
	adrp	x0, l_.str.138@PAGE
Lloh423:
	add	x0, x0, l_.str.138@PAGEOFF
	b	LBB34_147
LBB34_187:
	ldr	x10, [x0]
	ldr	w11, [x11, #8]
	add	w11, w11, w19
	stp	x8, x9, [sp, #24]
	stp	x10, x11, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh424:
	adrp	x0, l_.str.154@PAGE
Lloh425:
	add	x0, x0, l_.str.154@PAGEOFF
	b	LBB34_147
LBB34_188:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh426:
	adrp	x0, l_.str.140@PAGE
Lloh427:
	add	x0, x0, l_.str.140@PAGEOFF
	b	LBB34_147
LBB34_189:
	mov	x21, x0
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x8, [x21]
                                        ; kill: def $w20 killed $w20 killed $x20 def $x20
	ldr	w9, [x25]
	stp	x19, x20, [sp, #24]
	stp	x9, x8, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh428:
	adrp	x0, l_.str.173@PAGE
Lloh429:
	add	x0, x0, l_.str.173@PAGEOFF
	b	LBB34_220
LBB34_190:
	mov	x19, x0
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x8, [x19]
	ldr	w9, [x25]
	stp	x8, x9, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh430:
	adrp	x0, l_.str.169@PAGE
Lloh431:
	add	x0, x0, l_.str.169@PAGEOFF
	b	LBB34_220
LBB34_191:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	ldr	w8, [x25]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh432:
	adrp	x0, l_.str.174@PAGE
Lloh433:
	add	x0, x0, l_.str.174@PAGEOFF
	b	LBB34_220
LBB34_192:
	cmp	w28, #16, lsl #12               ; =65536
	b.lt	LBB34_210
; %bb.193:
	mov	w8, #65535                      ; =0xffff
	str	x8, [sp, #16]
                                        ; kill: def $w28 killed $w28 killed $x28 def $x28
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x28, [sp]
Lloh434:
	adrp	x0, l_.str.182@PAGE
Lloh435:
	add	x0, x0, l_.str.182@PAGEOFF
	b	LBB34_157
LBB34_194:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	ldr	w8, [x25]
	stp	x8, x24, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh436:
	adrp	x0, l_.str.175@PAGE
Lloh437:
	add	x0, x0, l_.str.175@PAGEOFF
	b	LBB34_220
LBB34_195:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	str	x8, [sp, #16]
	mov	w8, #255                        ; =0xff
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh438:
	adrp	x0, l_.str.165@PAGE
Lloh439:
	add	x0, x0, l_.str.165@PAGEOFF
	b	LBB34_147
LBB34_196:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x9, x8, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh440:
	adrp	x0, l_.str.158@PAGE
Lloh441:
	add	x0, x0, l_.str.158@PAGEOFF
	b	LBB34_147
LBB34_197:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	mov	w10, #16                        ; =0x10
	stp	x8, x10, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh442:
	adrp	x0, l_.str.164@PAGE
Lloh443:
	add	x0, x0, l_.str.164@PAGEOFF
	b	LBB34_147
LBB34_198:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x21, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh444:
	adrp	x0, l_.str.149@PAGE
Lloh445:
	add	x0, x0, l_.str.149@PAGEOFF
	b	LBB34_147
LBB34_199:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	mov	w10, #16                        ; =0x10
	stp	x8, x10, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh446:
	adrp	x0, l_.str.162@PAGE
Lloh447:
	add	x0, x0, l_.str.162@PAGEOFF
	b	LBB34_147
LBB34_200:
	ldr	x9, [x0]
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	stp	x21, x8, [sp, #24]
	stp	x9, x10, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh448:
	adrp	x0, l_.str.156@PAGE
Lloh449:
	add	x0, x0, l_.str.156@PAGEOFF
	b	LBB34_147
LBB34_201:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x21, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh450:
	adrp	x0, l_.str.150@PAGE
Lloh451:
	add	x0, x0, l_.str.150@PAGEOFF
	b	LBB34_147
LBB34_202:
	ldr	x9, [x0]
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	stp	x21, x8, [sp, #24]
	stp	x9, x10, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh452:
	adrp	x0, l_.str.157@PAGE
Lloh453:
	add	x0, x0, l_.str.157@PAGEOFF
	b	LBB34_147
LBB34_203:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x21, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh454:
	adrp	x0, l_.str.146@PAGE
Lloh455:
	add	x0, x0, l_.str.146@PAGEOFF
	b	LBB34_147
LBB34_204:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x21, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh456:
	adrp	x0, l_.str.148@PAGE
Lloh457:
	add	x0, x0, l_.str.148@PAGEOFF
	b	LBB34_147
LBB34_205:
Lloh458:
	adrp	x0, l_.str.137@PAGE
Lloh459:
	add	x0, x0, l_.str.137@PAGEOFF
	b	LBB34_147
LBB34_206:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	mov	w10, #16                        ; =0x10
	stp	x8, x10, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh460:
	adrp	x0, l_.str.163@PAGE
Lloh461:
	add	x0, x0, l_.str.163@PAGEOFF
	b	LBB34_147
LBB34_207:
	ldr	w10, [x11, #8]
	add	w10, w10, w19
	stp	x8, x9, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x10, [sp]
Lloh462:
	adrp	x0, l_.str.147@PAGE
Lloh463:
	add	x0, x0, l_.str.147@PAGEOFF
	b	LBB34_147
LBB34_208:
Lloh464:
	adrp	x0, l_.str.136@PAGE
Lloh465:
	add	x0, x0, l_.str.136@PAGEOFF
	b	LBB34_147
LBB34_209:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
Lloh466:
	adrp	x0, l_.str.172@PAGE
Lloh467:
	add	x0, x0, l_.str.172@PAGEOFF
	b	LBB34_220
LBB34_210:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #164]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #165]
	stur	q0, [sp, #181]
	stur	q0, [sp, #197]
	stur	q0, [sp, #213]
	stur	q0, [sp, #229]
	stur	q0, [sp, #245]
	add	x8, sp, #164
	stur	q0, [x8, #97]
	stur	q0, [x8, #113]
	stur	q0, [x8, #129]
	stur	q0, [x8, #145]
	stur	q0, [x8, #161]
	stur	q0, [x8, #177]
	stur	q0, [x8, #193]
	stur	q0, [x8, #209]
	stur	q0, [x8, #225]
	stur	q0, [x8, #241]
	b	LBB34_159
LBB34_211:
	mov	x20, x12
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x20
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	ldr	w8, [x25]
	stp	x8, x19, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh468:
	adrp	x0, l_.str.177@PAGE
Lloh469:
	add	x0, x0, l_.str.177@PAGEOFF
	b	LBB34_227
LBB34_212:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	stp	x21, x9, [sp, #16]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh470:
	adrp	x0, l_.str.141@PAGE
Lloh471:
	add	x0, x0, l_.str.141@PAGEOFF
	b	LBB34_147
LBB34_213:
	ldr	w8, [x11, #8]
	add	w8, w8, w19
	stp	x8, x21, [sp, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	str	x9, [sp]
Lloh472:
	adrp	x0, l_.str.142@PAGE
Lloh473:
	add	x0, x0, l_.str.142@PAGEOFF
	b	LBB34_147
LBB34_214:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x24, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh474:
	adrp	x0, l_.str.143@PAGE
Lloh475:
	add	x0, x0, l_.str.143@PAGEOFF
	b	LBB34_147
LBB34_215:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	ldr	w8, [x25]
	stp	x8, x24, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x20, [sp]
Lloh476:
	adrp	x0, l_.str.170@PAGE
Lloh477:
	add	x0, x0, l_.str.170@PAGEOFF
	b	LBB34_220
LBB34_216:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x25, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh478:
	adrp	x0, l_.str.144@PAGE
Lloh479:
	add	x0, x0, l_.str.144@PAGEOFF
	b	LBB34_147
LBB34_217:
	ldr	w9, [x11, #8]
	add	w9, w9, w19
	stp	x26, x8, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x9, [sp]
Lloh480:
	adrp	x0, l_.str.145@PAGE
Lloh481:
	add	x0, x0, l_.str.145@PAGEOFF
	b	LBB34_147
LBB34_218:
	ldr	x22, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB34_224
LBB34_219:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
Lloh482:
	adrp	x0, l_.str.171@PAGE
Lloh483:
	add	x0, x0, l_.str.171@PAGEOFF
LBB34_220:
	add	x8, sp, #164
	bl	_fail
	mov	w28, #0                         ; =0x0
	ldr	x22, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB34_159
LBB34_221:
	stp	x24, x8, [sp, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	str	x8, [sp]
Lloh484:
	adrp	x0, l_.str.159@PAGE
Lloh485:
	add	x0, x0, l_.str.159@PAGEOFF
	b	LBB34_147
LBB34_222:
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB34_226
LBB34_223:
	ldr	x22, [sp, #112]                 ; 8-byte Folded Reload
LBB34_224:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	w8, [x25]
	stp	x20, x21, [sp, #16]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	stp	x9, x8, [sp]
Lloh486:
	adrp	x0, l_.str.178@PAGE
Lloh487:
	add	x0, x0, l_.str.178@PAGEOFF
	b	LBB34_157
LBB34_225:
	mov	x26, x19
LBB34_226:
	ldr	x8, [sp, #128]
	mov	w10, #104                       ; =0x68
	umull	x9, w9, w10
	ldr	w19, [x8, x9]
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x24
	bl	_free
	stp	x27, x26, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x19, [sp]
Lloh488:
	adrp	x0, l_.str.179@PAGE
Lloh489:
	add	x0, x0, l_.str.179@PAGEOFF
LBB34_227:
	add	x8, sp, #164
	bl	_fail
	ldr	x22, [sp, #112]                 ; 8-byte Folded Reload
	b	LBB34_158
LBB34_228:
	mov	x24, x20
LBB34_229:
	ldr	x22, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #128]
	mov	w10, #104                       ; =0x68
	umull	x9, w9, w10
	ldr	w19, [x8, x9]
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	stp	x21, x24, [sp, #16]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	stp	x8, x19, [sp]
Lloh490:
	adrp	x0, l_.str.180@PAGE
Lloh491:
	add	x0, x0, l_.str.180@PAGEOFF
	b	LBB34_157
LBB34_230:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh374, Lloh375, Lloh376
	.loh AdrpAdd	Lloh377, Lloh378
	.loh AdrpAdd	Lloh379, Lloh380
	.loh AdrpAdd	Lloh381, Lloh382
	.loh AdrpAdd	Lloh383, Lloh384
	.loh AdrpAdd	Lloh385, Lloh386
	.loh AdrpAdd	Lloh387, Lloh388
	.loh AdrpAdd	Lloh389, Lloh390
	.loh AdrpLdrGotLdr	Lloh391, Lloh392, Lloh393
	.loh AdrpAdd	Lloh394, Lloh395
	.loh AdrpAdd	Lloh396, Lloh397
	.loh AdrpAdd	Lloh398, Lloh399
	.loh AdrpAdd	Lloh400, Lloh401
	.loh AdrpAdd	Lloh402, Lloh403
	.loh AdrpAdd	Lloh404, Lloh405
	.loh AdrpAdd	Lloh406, Lloh407
	.loh AdrpAdd	Lloh408, Lloh409
	.loh AdrpAdd	Lloh410, Lloh411
	.loh AdrpAdd	Lloh412, Lloh413
	.loh AdrpAdd	Lloh414, Lloh415
	.loh AdrpAdd	Lloh416, Lloh417
	.loh AdrpAdd	Lloh418, Lloh419
	.loh AdrpAdd	Lloh420, Lloh421
	.loh AdrpAdd	Lloh422, Lloh423
	.loh AdrpAdd	Lloh424, Lloh425
	.loh AdrpAdd	Lloh426, Lloh427
	.loh AdrpAdd	Lloh428, Lloh429
	.loh AdrpAdd	Lloh430, Lloh431
	.loh AdrpAdd	Lloh432, Lloh433
	.loh AdrpAdd	Lloh434, Lloh435
	.loh AdrpAdd	Lloh436, Lloh437
	.loh AdrpAdd	Lloh438, Lloh439
	.loh AdrpAdd	Lloh440, Lloh441
	.loh AdrpAdd	Lloh442, Lloh443
	.loh AdrpAdd	Lloh444, Lloh445
	.loh AdrpAdd	Lloh446, Lloh447
	.loh AdrpAdd	Lloh448, Lloh449
	.loh AdrpAdd	Lloh450, Lloh451
	.loh AdrpAdd	Lloh452, Lloh453
	.loh AdrpAdd	Lloh454, Lloh455
	.loh AdrpAdd	Lloh456, Lloh457
	.loh AdrpAdd	Lloh458, Lloh459
	.loh AdrpAdd	Lloh460, Lloh461
	.loh AdrpAdd	Lloh462, Lloh463
	.loh AdrpAdd	Lloh464, Lloh465
	.loh AdrpAdd	Lloh466, Lloh467
	.loh AdrpAdd	Lloh468, Lloh469
	.loh AdrpAdd	Lloh470, Lloh471
	.loh AdrpAdd	Lloh472, Lloh473
	.loh AdrpAdd	Lloh474, Lloh475
	.loh AdrpAdd	Lloh476, Lloh477
	.loh AdrpAdd	Lloh478, Lloh479
	.loh AdrpAdd	Lloh480, Lloh481
	.loh AdrpAdd	Lloh482, Lloh483
	.loh AdrpAdd	Lloh484, Lloh485
	.loh AdrpAdd	Lloh486, Lloh487
	.loh AdrpAdd	Lloh488, Lloh489
	.loh AdrpAdd	Lloh490, Lloh491
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI34_0:
	.short	(LBB34_48-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_25-LBB34_5)>>2
	.short	(LBB34_25-LBB34_5)>>2
	.short	(LBB34_23-LBB34_5)>>2
	.short	(LBB34_23-LBB34_5)>>2
	.short	(LBB34_21-LBB34_5)>>2
	.short	(LBB34_21-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_153-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_17-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_15-LBB34_5)>>2
	.short	(LBB34_15-LBB34_5)>>2
	.short	(LBB34_15-LBB34_5)>>2
	.short	(LBB34_17-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_39-LBB34_5)>>2
	.short	(LBB34_32-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_24-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_38-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_5-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_5-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_31-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_44-LBB34_5)>>2
	.short	(LBB34_46-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_50-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_24-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_26-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_28-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_47-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_49-LBB34_5)>>2
	.short	(LBB34_40-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_6-LBB34_5)>>2
	.short	(LBB34_195-LBB34_5)>>2
lJTI34_1:
	.byte	(LBB34_82-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_82-LBB34_77)>>2
	.byte	(LBB34_85-LBB34_77)>>2
	.byte	(LBB34_87-LBB34_77)>>2
	.byte	(LBB34_84-LBB34_77)>>2
	.byte	(LBB34_88-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_77-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_77-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_86-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_83-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_77-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_91-LBB34_77)>>2
	.byte	(LBB34_77-LBB34_77)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_verify_affine_function ; -- Begin function nvm_verify_affine_function
	.globl	_nvm_verify_affine_function
	.p2align	2
_nvm_verify_affine_function:            ; @nvm_verify_affine_function
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #496
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x20, x1
	mov	x21, x0
	mov	x19, x8
Lloh492:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh493:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh494:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	add	x8, sp, #231
	mov	w1, #1                          ; =0x1
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_structure_checked
	ldrb	w8, [sp, #231]
	tbz	w8, #0, LBB35_3
; %bb.1:
	add	x22, sp, #20
	add	x8, sp, #20
	mov	x0, x21
	mov	x1, x20
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #20]
	tbz	w8, #0, LBB35_4
; %bb.2:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB35_5
LBB35_3:
	add	x1, sp, #231
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB35_5
LBB35_4:
	add	x8, x22, #16
	ldr	w9, [sp, #24]
	stp	x9, x8, [sp]
Lloh495:
	adrp	x0, l_.str.56@PAGE
Lloh496:
	add	x0, x0, l_.str.56@PAGEOFF
	mov	x8, x19
	bl	_fail
LBB35_5:
	ldur	x8, [x29, #-56]
Lloh497:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh498:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh499:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB35_7
; %bb.6:
	add	sp, sp, #496
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB35_7:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh492, Lloh493, Lloh494
	.loh AdrpAdd	Lloh495, Lloh496
	.loh AdrpLdrGotLdr	Lloh497, Lloh498, Lloh499
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fail
_fail:                                  ; @fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x2, x0
	strb	wzr, [x8, #256]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	add	x9, x29, #16
	str	x9, [sp, #8]
	add	x0, x8, #1
	add	x3, x29, #16
	mov	w1, #256                        ; =0x100
	bl	_vsnprintf
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_uses_owned_transfers ; -- Begin function nvm_uses_owned_transfers
	.globl	_nvm_uses_owned_transfers
	.p2align	2
_nvm_uses_owned_transfers:              ; @nvm_uses_owned_transfers
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB37_13
; %bb.1:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	ldr	w8, [x0, #272]
	cbz	w8, LBB37_15
; %bb.2:
	ldr	x8, [x19, #256]
	cbz	x8, LBB37_14
; %bb.3:
	mov	x20, #0                         ; =0x0
	mov	w21, #24                        ; =0x18
	b	LBB37_5
LBB37_4:                                ;   in Loop: Header=BB37_5 Depth=1
	mov	w0, #0                          ; =0x0
	add	x20, x20, #1
	ldr	w8, [x19, #272]
	cmp	x20, x8
	b.hs	LBB37_16
LBB37_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB37_10 Depth 2
	ldr	x8, [x19, #256]
	madd	x22, x20, x21, x8
	ldr	w8, [x22, #8]
	ldr	w9, [x19, #288]
	subs	w9, w9, w8
	b.lo	LBB37_14
; %bb.6:                                ;   in Loop: Header=BB37_5 Depth=1
	ldr	w8, [x22, #12]
	cmp	w8, w9
	b.hi	LBB37_14
; %bb.7:                                ;   in Loop: Header=BB37_5 Depth=1
	cbz	w8, LBB37_4
; %bb.8:                                ;   in Loop: Header=BB37_5 Depth=1
	ldr	x9, [x19, #280]
	cbz	x9, LBB37_14
; %bb.9:                                ;   in Loop: Header=BB37_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB37_10:                               ;   Parent Loop BB37_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [x19, #280]
	ldr	w10, [x22, #8]
	add	x9, x9, x10
	add	x0, x9, w23, uxtw
	sub	w1, w8, w23
	mov	x2, sp
	bl	_isa_decode
	cbz	w0, LBB37_4
; %bb.11:                               ;   in Loop: Header=BB37_10 Depth=2
	ldrb	w8, [sp]
	sub	w9, w8, #11
	sub	w8, w8, #22
	cmp	w9, #5
	ccmp	w8, #9, #0, hs
	b.ls	LBB37_14
; %bb.12:                               ;   in Loop: Header=BB37_10 Depth=2
	ldr	w8, [x22, #12]
	add	w23, w0, w23
	cmp	w23, w8
	b.lo	LBB37_10
	b	LBB37_4
LBB37_13:
	mov	w0, #1                          ; =0x1
	ret
LBB37_14:
	mov	w0, #1                          ; =0x1
	b	LBB37_16
LBB37_15:
	mov	w0, #0                          ; =0x0
LBB37_16:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify_owned_module ; -- Begin function nvm_verify_owned_module
	.globl	_nvm_verify_owned_module
	.p2align	2
_nvm_verify_owned_module:               ; @nvm_verify_owned_module
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2864
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	x19, x8
Lloh500:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh501:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh502:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	add	x8, sp, #2591
	mov	w1, #1                          ; =0x1
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_structure_checked
	ldrb	w8, [sp, #2591]
	tbz	w8, #0, LBB38_10
; %bb.1:
	ldr	w8, [x20, #304]
	cbz	w8, LBB38_8
; %bb.2:
	ldr	w8, [x20, #272]
	sub	w8, w8, #9
	cmn	w8, #8
	b.lo	LBB38_8
; %bb.3:
	ldr	w8, [x20, #12]
	cbnz	w8, LBB38_8
; %bb.4:
	ldr	w8, [x20, #432]
	cbnz	w8, LBB38_8
; %bb.5:
	ldr	w8, [x20, #448]
	cbnz	w8, LBB38_8
; %bb.6:
	ldr	w8, [x20, #424]
	cbnz	w8, LBB38_8
; %bb.7:
	ldr	w8, [x20, #352]
	cbz	w8, LBB38_13
LBB38_8:
	ldur	x8, [x29, #-96]
Lloh503:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh504:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh505:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_123
; %bb.9:
Lloh506:
	adrp	x0, l_.str.57@PAGE
Lloh507:
	add	x0, x0, l_.str.57@PAGEOFF
	mov	x8, x19
	add	sp, sp, #2864
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_fail
LBB38_10:
	add	x1, sp, #2591
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
LBB38_11:
	ldur	x8, [x29, #-96]
Lloh508:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh509:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh510:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_123
; %bb.12:
	add	sp, sp, #2864
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB38_13:
	add	x1, sp, #540
	add	x3, sp, #72
	mov	x0, x20
	mov	w2, #256                        ; =0x100
	bl	_nvm_ownership_globals
	cbz	w0, LBB38_16
; %bb.14:
Lloh511:
	adrp	x0, l_.str.58@PAGE
Lloh512:
	add	x0, x0, l_.str.58@PAGEOFF
LBB38_15:
	mov	x8, x19
	bl	_fail
	b	LBB38_11
LBB38_16:
	ldr	w8, [sp, #72]
	cbz	w8, LBB38_23
; %bb.17:
	add	x9, sp, #540
	add	x9, x9, #4
	b	LBB38_20
LBB38_18:                               ;   in Loop: Header=BB38_20 Depth=1
	ldr	x10, [x20, #296]
	ldr	w11, [x9]
	add	w11, w11, #8
	ldrb	w10, [x10, w11, uxtw]
	tbnz	w10, #1, LBB38_22
LBB38_19:                               ;   in Loop: Header=BB38_20 Depth=1
	add	x9, x9, #8
	subs	x8, x8, #1
	b.eq	LBB38_23
LBB38_20:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	cmp	w10, #10
	b.eq	LBB38_18
; %bb.21:                               ;   in Loop: Header=BB38_20 Depth=1
	cmp	w10, #8
	b.ne	LBB38_19
LBB38_22:
Lloh513:
	adrp	x0, l_.str.59@PAGE
Lloh514:
	add	x0, x0, l_.str.59@PAGEOFF
	b	LBB38_15
LBB38_23:
	mov	x0, x20
	bl	_nvm_affine_value_call_graph
	mov	x21, x0
	ldr	w8, [x20, #272]
	tbnz	w0, #0, LBB38_26
; %bb.24:
	cmp	w8, #3
	b.lo	LBB38_26
; %bb.25:
Lloh515:
	adrp	x0, l_.str.60@PAGE
Lloh516:
	add	x0, x0, l_.str.60@PAGEOFF
	b	LBB38_15
LBB38_26:
	cbz	w8, LBB38_57
; %bb.27:
	mov	x22, #0                         ; =0x0
	eor	w8, w21, #0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	mov	w28, #1                         ; =0x1
LBB38_28:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_45 Depth 2
	ldr	x8, [x20, #256]
	mov	w9, #24                         ; =0x18
	madd	x27, x22, x9, x8
	ldr	w1, [x27]
	mov	x0, x20
	bl	_nvm_get_string
	ldrh	w8, [x27, #4]
	cbz	x22, LBB38_31
; %bb.29:                               ;   in Loop: Header=BB38_28 Depth=1
	cmp	w8, #0
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	csel	w9, wzr, w9, ne
	tbnz	w9, #0, LBB38_59
; %bb.30:                               ;   in Loop: Header=BB38_28 Depth=1
	cmp	w8, #8
	b.ls	LBB38_32
	b	LBB38_59
LBB38_31:                               ;   in Loop: Header=BB38_28 Depth=1
	cbnz	w8, LBB38_59
LBB38_32:                               ;   in Loop: Header=BB38_28 Depth=1
	ldrh	w8, [x27, #18]
	cbnz	w8, LBB38_59
; %bb.33:                               ;   in Loop: Header=BB38_28 Depth=1
	cmp	x22, #0
	csel	w8, wzr, w21, eq
	tbnz	w8, #0, LBB38_36
; %bb.34:                               ;   in Loop: Header=BB38_28 Depth=1
	ldrb	w8, [x27, #21]
	cmp	w8, #1
	b.ne	LBB38_59
; %bb.35:                               ;   in Loop: Header=BB38_28 Depth=1
	ldrb	w8, [x27, #20]
	cmp	w8, #4
	lsl	w8, w28, w8
	mov	w9, #22                         ; =0x16
	and	w8, w8, w9
	ccmp	w8, #0, #4, ls
	b.eq	LBB38_59
LBB38_36:                               ;   in Loop: Header=BB38_28 Depth=1
	ldrh	w24, [x27, #16]
	cmp	w24, #256
	b.hi	LBB38_59
; %bb.37:                               ;   in Loop: Header=BB38_28 Depth=1
	cbz	x0, LBB38_39
; %bb.38:                               ;   in Loop: Header=BB38_28 Depth=1
Lloh517:
	adrp	x1, l_.str.10@PAGE
Lloh518:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB38_59
LBB38_39:                               ;   in Loop: Header=BB38_28 Depth=1
	mov	x0, x20
	mov	x1, x22
	mov	x2, x24
	bl	_nvm_affine_state_create
	cbz	x0, LBB38_78
; %bb.40:                               ;   in Loop: Header=BB38_28 Depth=1
	mov	x24, x0
	bl	_nvm_affine_has_array_types
	cbnz	w0, LBB38_79
; %bb.41:                               ;   in Loop: Header=BB38_28 Depth=1
	strh	wzr, [sp, #56]
	add	x1, sp, #284
	add	x2, sp, #56
	mov	x0, x24
	bl	_nvm_affine_value_result
	mov	x25, x0
	ldrh	w8, [x27, #16]
	cbz	w8, LBB38_55
; %bb.42:                               ;   in Loop: Header=BB38_28 Depth=1
	mov	w26, #0                         ; =0x0
	cmp	x22, #0
	csinc	w23, w21, wzr, ne
	b	LBB38_45
LBB38_43:                               ;   in Loop: Header=BB38_45 Depth=2
	mov	w25, #0                         ; =0x0
LBB38_44:                               ;   in Loop: Header=BB38_45 Depth=2
	add	w26, w26, #1
	ldrh	w8, [x27, #16]
	cmp	w8, w26, uxth
	b.ls	LBB38_55
LBB38_45:                               ;   Parent Loop BB38_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	tbnz	w23, #0, LBB38_48
; %bb.46:                               ;   in Loop: Header=BB38_45 Depth=2
	ldrh	w8, [x27, #4]
	cmp	w8, w26, uxth
	b.ls	LBB38_48
; %bb.47:                               ;   in Loop: Header=BB38_45 Depth=2
	and	w1, w26, #0xffff
	add	x2, sp, #76
	add	x3, sp, #24
	mov	x0, x24
	bl	_nvm_affine_parameter_at
	and	w25, w0, w25
	b	LBB38_44
LBB38_48:                               ;   in Loop: Header=BB38_45 Depth=2
	and	w1, w26, #0xffff
	add	x2, sp, #76
	mov	x0, x24
	bl	_nvm_affine_local_type
	cbz	w0, LBB38_43
; %bb.49:                               ;   in Loop: Header=BB38_45 Depth=2
	ldrb	w8, [sp, #76]
	cmp	w8, #10
	lsl	w9, w28, w8
	mov	w10, #1302                      ; =0x516
	and	w9, w9, w10
	ccmp	w9, #0, #4, ls
	b.ne	LBB38_44
; %bb.50:                               ;   in Loop: Header=BB38_45 Depth=2
	ldr	w9, [sp, #80]
	cmp	w8, #3
	b.ne	LBB38_53
; %bb.51:                               ;   in Loop: Header=BB38_45 Depth=2
	ldrh	w10, [x27, #4]
	cmp	w10, w26, uxth
	b.hi	LBB38_53
; %bb.52:                               ;   in Loop: Header=BB38_45 Depth=2
	cmn	w9, #1
	b.eq	LBB38_44
LBB38_53:                               ;   in Loop: Header=BB38_45 Depth=2
	cmp	w8, #5
	eor	w8, w21, #0x1
	csinc	w8, w8, wzr, eq
	tbnz	w8, #0, LBB38_43
; %bb.54:                               ;   in Loop: Header=BB38_45 Depth=2
	cmn	w9, #1
	b.eq	LBB38_44
	b	LBB38_43
LBB38_55:                               ;   in Loop: Header=BB38_28 Depth=1
	mov	x0, x24
	bl	_nvm_affine_state_free
	tbz	w25, #0, LBB38_80
; %bb.56:                               ;   in Loop: Header=BB38_28 Depth=1
	add	x22, x22, #1
	ldr	w8, [x20, #272]
	cmp	x22, x8
	b.lo	LBB38_28
LBB38_57:
	stp	xzr, xzr, [sp, #56]
	ldr	x0, [x20, #312]
	ldr	w1, [x20, #320]
	add	x2, sp, #56
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB38_60
; %bb.58:
Lloh519:
	adrp	x0, l_.str.65@PAGE
Lloh520:
	add	x0, x0, l_.str.65@PAGEOFF
	b	LBB38_15
LBB38_59:
Lloh521:
	adrp	x0, l_.str.61@PAGE
Lloh522:
	add	x0, x0, l_.str.61@PAGEOFF
	b	LBB38_15
LBB38_60:
	ldr	w8, [sp, #64]
	cbz	w8, LBB38_81
; %bb.61:
	mov	x23, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w24, #1                         ; =0x1
	mov	w25, #-1                        ; =0xffffffff
	mov	w26, #1302                      ; =0x516
	mov	w27, #1                         ; =0x1
	b	LBB38_65
LBB38_62:                               ;   in Loop: Header=BB38_65 Depth=1
	mov	w27, #0                         ; =0x0
LBB38_63:                               ;   in Loop: Header=BB38_65 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #64]
LBB38_64:                               ;   in Loop: Header=BB38_65 Depth=1
	add	x23, x23, #1
	cmp	x23, x8
	b.hs	LBB38_76
LBB38_65:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_75 Depth 2
	ldr	x9, [sp, #56]
	add	x10, x9, x23, lsl #4
	ldrb	w11, [x10]
	cmp	w11, #2
	b.ne	LBB38_69
; %bb.66:                               ;   in Loop: Header=BB38_65 Depth=1
	ldr	x8, [x20, #296]
	add	w9, w23, #8
	ldrb	w8, [x8, w9, uxtw]
	and	w9, w8, #0x1
	cmp	w8, #0
	ccmp	w9, #0, #0, ne
	b.eq	LBB38_62
; %bb.67:                               ;   in Loop: Header=BB38_65 Depth=1
	add	x3, sp, #284
	mov	x0, x20
	mov	x1, x22
	mov	w2, #0                          ; =0x0
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB38_62
; %bb.68:                               ;   in Loop: Header=BB38_65 Depth=1
	ldr	w8, [sp, #284]
	cmp	x23, x8
	b.eq	LBB38_63
	b	LBB38_62
LBB38_69:                               ;   in Loop: Header=BB38_65 Depth=1
	ldr	x9, [x20, #296]
	add	w12, w23, #8
	ldrb	w9, [x9, w12, uxtw]
	and	w12, w9, #0x1
	ldrh	w9, [x10, #2]
	cmp	w11, #0
	ccmp	w12, #0, #4, eq
	b.ne	LBB38_71
; %bb.70:                               ;   in Loop: Header=BB38_65 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB38_73
LBB38_71:                               ;   in Loop: Header=BB38_65 Depth=1
	cmp	w9, #256
	b.ls	LBB38_73
; %bb.72:                               ;   in Loop: Header=BB38_65 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB38_74
LBB38_73:                               ;   in Loop: Header=BB38_65 Depth=1
	cbz	w9, LBB38_64
LBB38_74:                               ;   in Loop: Header=BB38_65 Depth=1
	ldr	x10, [x10, #8]
	add	x10, x10, #4
LBB38_75:                               ;   Parent Loop BB38_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x10, #-4]
	ldr	w12, [x10], #12
	cmp	x12, x25
	ccmp	x23, x12, #2, ne
	cset	w13, hi
	and	w13, w13, w27
	cmp	w11, #5
	csel	w14, wzr, w21, ne
	cmn	w12, #1
	csel	w12, wzr, w14, ne
	and	w12, w12, w27
	cmp	w11, #10
	lsl	w11, w24, w11
	and	w11, w11, w26
	ccmp	w11, #0, #4, ls
	csel	w27, w13, w12, ne
	subs	x9, x9, #1
	b.ne	LBB38_75
	b	LBB38_64
LBB38_76:
	add	x0, sp, #56
	bl	_nvm_v2_layouts_free
	tbnz	w27, #0, LBB38_82
; %bb.77:
Lloh523:
	adrp	x0, l_.str.66@PAGE
Lloh524:
	add	x0, x0, l_.str.66@PAGEOFF
	b	LBB38_15
LBB38_78:
Lloh525:
	adrp	x0, l_.str.62@PAGE
Lloh526:
	add	x0, x0, l_.str.62@PAGEOFF
	b	LBB38_15
LBB38_79:
	mov	x0, x24
	bl	_nvm_affine_state_free
Lloh527:
	adrp	x0, l_.str.63@PAGE
Lloh528:
	add	x0, x0, l_.str.63@PAGEOFF
	b	LBB38_15
LBB38_80:
Lloh529:
	adrp	x0, l_.str.64@PAGE
Lloh530:
	add	x0, x0, l_.str.64@PAGEOFF
	b	LBB38_15
LBB38_81:
	add	x0, sp, #56
	bl	_nvm_v2_layouts_free
LBB38_82:
	ldr	w8, [sp, #72]
	cmp	w8, #0
	cset	w24, ne
	ldr	w9, [x20, #272]
	cbz	w9, LBB38_118
; %bb.83:
	mov	x22, #0                         ; =0x0
	mov	w28, #1                         ; =0x1
	b	LBB38_85
LBB38_84:                               ;   in Loop: Header=BB38_85 Depth=1
	add	x22, x22, #1
	ldr	w8, [x20, #272]
	cmp	x22, x8
	b.hs	LBB38_121
LBB38_85:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_90 Depth 2
	add	x2, sp, #24
	add	x3, sp, #284
	mov	x0, x20
	mov	x1, x22
	bl	_vm_decode_function
	cbz	w0, LBB38_120
; %bb.86:                               ;   in Loop: Header=BB38_85 Depth=1
	ldr	w27, [sp, #32]
	cbz	w27, LBB38_116
; %bb.87:                               ;   in Loop: Header=BB38_85 Depth=1
	ldr	x8, [sp, #24]
	cmp	x22, #0
	csinc	w9, w21, wzr, eq
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	csinc	w26, w21, wzr, ne
	add	x25, x8, #56
	b	LBB38_90
LBB38_88:                               ;   in Loop: Header=BB38_90 Depth=2
	mov	w28, #0                         ; =0x0
LBB38_89:                               ;   in Loop: Header=BB38_90 Depth=2
	add	x25, x25, #104
	subs	x27, x27, #1
	b.eq	LBB38_116
LBB38_90:                               ;   Parent Loop BB38_85 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w23, [x25, #-16]
	sub	w8, w23, #11
	tst	w8, #0xfc
	cset	w8, eq
	cmp	w23, #251
	b.ne	LBB38_92
; %bb.91:                               ;   in Loop: Header=BB38_90 Depth=2
	ldurb	w8, [x25, #-8]
	cmp	w8, #1
	cset	w8, eq
	orr	w24, w8, w24
	b	LBB38_107
LBB38_92:                               ;   in Loop: Header=BB38_90 Depth=2
	orr	w24, w8, w24
	mov	x0, x23
	mov	x1, x21
	bl	_owned_runtime_opcode
	and	w28, w0, w28
	cmp	w23, #59
	b.eq	LBB38_103
; %bb.93:                               ;   in Loop: Header=BB38_90 Depth=2
	cmp	w23, #15
	b.eq	LBB38_100
; %bb.94:                               ;   in Loop: Header=BB38_90 Depth=2
	cmp	w23, #4
	b.ne	LBB38_107
; %bb.95:                               ;   in Loop: Header=BB38_90 Depth=2
	ldur	w8, [x25, #-8]
	ldr	w9, [x20, #248]
	cmp	w8, w9
	b.hs	LBB38_106
; %bb.96:                               ;   in Loop: Header=BB38_90 Depth=2
	ldr	x10, [x20, #232]
	cbz	x10, LBB38_106
; %bb.97:                               ;   in Loop: Header=BB38_90 Depth=2
	ldr	x9, [x20, #240]
	cbz	x9, LBB38_106
; %bb.98:                               ;   in Loop: Header=BB38_90 Depth=2
	ldr	x0, [x10, x8, lsl #3]
	cbz	x0, LBB38_106
; %bb.99:                               ;   in Loop: Header=BB38_90 Depth=2
	ldr	w2, [x9, x8, lsl #2]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB38_106
	b	LBB38_107
LBB38_100:                              ;   in Loop: Header=BB38_90 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB38_106
; %bb.101:                              ;   in Loop: Header=BB38_90 Depth=2
	ldr	w8, [x20, #272]
	cmp	w8, #2
	b.ne	LBB38_88
; %bb.102:                              ;   in Loop: Header=BB38_90 Depth=2
	ldur	w8, [x25, #-8]
	cmp	w8, #1
	b.ne	LBB38_88
	b	LBB38_89
LBB38_103:                              ;   in Loop: Header=BB38_90 Depth=2
	cbz	w21, LBB38_106
; %bb.104:                              ;   in Loop: Header=BB38_90 Depth=2
	ldur	w8, [x25, #-8]
	cbz	w8, LBB38_88
; %bb.105:                              ;   in Loop: Header=BB38_90 Depth=2
	ldr	w9, [x20, #272]
	cmp	w8, w9
	cset	w8, lo
	and	w28, w8, w28
	b	LBB38_89
LBB38_106:                              ;   in Loop: Header=BB38_90 Depth=2
	mov	w28, #0                         ; =0x0
LBB38_107:                              ;   in Loop: Header=BB38_90 Depth=2
	tbnz	w26, #0, LBB38_89
; %bb.108:                              ;   in Loop: Header=BB38_90 Depth=2
	cmp	w23, #29
	b.hi	LBB38_114
; %bb.109:                              ;   in Loop: Header=BB38_90 Depth=2
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w23
	mov	w9, #22528                      ; =0x5800
	movk	w9, #3, lsl #16
	tst	w8, w9
	b.eq	LBB38_111
; %bb.110:                              ;   in Loop: Header=BB38_90 Depth=2
	ldurh	w8, [x25, #-8]
	b	LBB38_113
LBB38_111:                              ;   in Loop: Header=BB38_90 Depth=2
	mov	w9, #855638016                  ; =0x33000000
	tst	w8, w9
	b.eq	LBB38_114
; %bb.112:                              ;   in Loop: Header=BB38_90 Depth=2
	ldrh	w8, [x25]
LBB38_113:                              ;   in Loop: Header=BB38_90 Depth=2
	ldr	x9, [x20, #256]
	mov	w10, #24                        ; =0x18
	madd	x9, x22, x10, x9
	ldrh	w9, [x9, #4]
	cmp	w8, w9
	b.lo	LBB38_88
	b	LBB38_89
LBB38_114:                              ;   in Loop: Header=BB38_90 Depth=2
	cmp	w23, #97
	b.eq	LBB38_88
; %bb.115:                              ;   in Loop: Header=BB38_90 Depth=2
	cmp	w23, #252
	b.eq	LBB38_88
	b	LBB38_89
LBB38_116:                              ;   in Loop: Header=BB38_85 Depth=1
	add	x0, sp, #24
	bl	_vm_decoded_function_free
	cbz	x22, LBB38_84
; %bb.117:                              ;   in Loop: Header=BB38_85 Depth=1
	add	x8, sp, #76
	mov	x0, x20
	mov	x1, x22
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #76]
	and	w28, w8, w28
	b	LBB38_84
LBB38_118:
	cbz	w8, LBB38_122
LBB38_119:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	bl	_nvm_verify_affine_function
	b	LBB38_11
LBB38_120:
	add	x8, sp, #284
	str	x8, [sp]
Lloh531:
	adrp	x0, l_.str.67@PAGE
Lloh532:
	add	x0, x0, l_.str.67@PAGEOFF
	b	LBB38_15
LBB38_121:
	and	w8, w28, w24
	tbnz	w8, #0, LBB38_119
LBB38_122:
Lloh533:
	adrp	x0, l_.str.68@PAGE
Lloh534:
	add	x0, x0, l_.str.68@PAGEOFF
	b	LBB38_15
LBB38_123:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh500, Lloh501, Lloh502
	.loh AdrpLdrGotLdr	Lloh503, Lloh504, Lloh505
	.loh AdrpAdd	Lloh506, Lloh507
	.loh AdrpLdrGotLdr	Lloh508, Lloh509, Lloh510
	.loh AdrpAdd	Lloh511, Lloh512
	.loh AdrpAdd	Lloh513, Lloh514
	.loh AdrpAdd	Lloh515, Lloh516
	.loh AdrpAdd	Lloh517, Lloh518
	.loh AdrpAdd	Lloh519, Lloh520
	.loh AdrpAdd	Lloh521, Lloh522
	.loh AdrpAdd	Lloh523, Lloh524
	.loh AdrpAdd	Lloh525, Lloh526
	.loh AdrpAdd	Lloh527, Lloh528
	.loh AdrpAdd	Lloh529, Lloh530
	.loh AdrpAdd	Lloh531, Lloh532
	.loh AdrpAdd	Lloh533, Lloh534
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function owned_runtime_opcode
_owned_runtime_opcode:                  ; @owned_runtime_opcode
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB39_4
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh535:
	adrp	x9, lJTI39_0@PAGE
Lloh536:
	add	x9, x9, lJTI39_0@PAGEOFF
	adr	x10, LBB39_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB39_2:
	ret
LBB39_3:
	mov	x0, x1
	ret
LBB39_4:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh535, Lloh536
	.cfi_endproc
	.section	__TEXT,__const
lJTI39_0:
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_3-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
	.byte	(LBB39_4-LBB39_2)>>2
	.byte	(LBB39_2-LBB39_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_verify_function    ; -- Begin function nvm_verify_function
	.globl	_nvm_verify_function
	.p2align	2
_nvm_verify_function:                   ; @nvm_verify_function
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	b	_verify_function_impl
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_function_impl
_verify_function_impl:                  ; @verify_function_impl
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #544
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, x8
Lloh537:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh538:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh539:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	bl	_nvm_service_execution_pending
	cbz	w0, LBB41_3
; %bb.1:
	ldur	x8, [x29, #-56]
Lloh540:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh541:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh542:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.2:
Lloh543:
	adrp	x0, l_.str.70@PAGE
Lloh544:
	add	x0, x0, l_.str.70@PAGEOFF
	mov	x8, x19
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	b	_fail
LBB41_3:
	mov	x0, x22
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB41_6
; %bb.4:
	ldur	x8, [x29, #-56]
Lloh545:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh546:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh547:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.5:
	mov	x8, x19
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, #0                          ; =0x0
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	b	_verify_record_maps
LBB41_6:
	mov	x0, x22
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbz	w0, LBB41_9
; %bb.7:
	ldur	x8, [x29, #-56]
Lloh548:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh549:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh550:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.8:
	mov	x8, x19
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	b	_verify_owned_arrays
LBB41_9:
	mov	x0, x22
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	cbz	w0, LBB41_12
; %bb.10:
	ldur	x8, [x29, #-56]
Lloh551:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh552:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh553:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.11:
	mov	x8, x19
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	b	_verify_mixed_samples
LBB41_12:
	mov	x0, x22
	bl	_nvm_record_array_candidate
	cbz	w0, LBB41_15
; %bb.13:
	ldur	x8, [x29, #-56]
Lloh554:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh555:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh556:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.14:
	mov	x8, x19
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, #0                          ; =0x0
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	b	_verify_record_arrays
LBB41_15:
	strb	wzr, [sp, #21]
	add	x8, sp, #279
	add	x2, sp, #21
	mov	x0, x22
	mov	w1, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_structure_checked
	ldrb	w8, [sp, #279]
	tbz	w8, #0, LBB41_23
; %bb.16:
	ldr	w8, [x22, #272]
	cmp	w21, w8
	b.hs	LBB41_24
; %bb.17:
	ldr	w8, [x22, #304]
	cbz	w8, LBB41_25
; %bb.18:
	ldrb	w8, [sp, #21]
	tbnz	w8, #0, LBB41_20
; %bb.19:
	add	x8, sp, #22
	mov	x0, x22
	bl	_nvm_verify_owned_module
	ldrb	w8, [sp, #22]
	tbz	w8, #0, LBB41_25
LBB41_20:
	cbz	x20, LBB41_22
; %bb.21:
	mov	w8, #256                        ; =0x100
	strh	w8, [x20]
LBB41_22:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB41_26
LBB41_23:
	add	x1, sp, #279
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB41_26
LBB41_24:
	stp	x21, x8, [sp]
Lloh557:
	adrp	x0, l_.str.185@PAGE
Lloh558:
	add	x0, x0, l_.str.185@PAGEOFF
	mov	x8, x19
	bl	_fail
	b	LBB41_26
LBB41_25:
	mov	x8, x19
	mov	x0, x22
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x4, x20
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_verify_function_body
LBB41_26:
	ldur	x8, [x29, #-56]
Lloh559:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh560:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh561:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB41_28
; %bb.27:
	add	sp, sp, #544
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB41_28:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh537, Lloh538, Lloh539
	.loh AdrpLdrGotLdr	Lloh540, Lloh541, Lloh542
	.loh AdrpAdd	Lloh543, Lloh544
	.loh AdrpLdrGotLdr	Lloh545, Lloh546, Lloh547
	.loh AdrpLdrGotLdr	Lloh548, Lloh549, Lloh550
	.loh AdrpLdrGotLdr	Lloh551, Lloh552, Lloh553
	.loh AdrpLdrGotLdr	Lloh554, Lloh555, Lloh556
	.loh AdrpAdd	Lloh557, Lloh558
	.loh AdrpLdrGotLdr	Lloh559, Lloh560, Lloh561
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify_function_max_stack ; -- Begin function nvm_verify_function_max_stack
	.globl	_nvm_verify_function_max_stack
	.p2align	2
_nvm_verify_function_max_stack:         ; @nvm_verify_function_max_stack
	.cfi_startproc
; %bb.0:
	b	_verify_function_impl
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify_declared_max_stacks ; -- Begin function nvm_verify_declared_max_stacks
	.globl	_nvm_verify_declared_max_stacks
	.p2align	2
_nvm_verify_declared_max_stacks:        ; @nvm_verify_declared_max_stacks
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh562:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh563:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh564:
	ldr	x9, [x9]
	stur	x9, [x29, #-56]
	cbz	x0, LBB43_4
; %bb.1:
	ldr	w9, [x0, #272]
	cmp	w2, w9
	b.ne	LBB43_4
; %bb.2:
	cbnz	x1, LBB43_7
; %bb.3:
	cbz	w2, LBB43_7
LBB43_4:
	ldur	x9, [x29, #-56]
Lloh565:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh566:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh567:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB43_46
; %bb.5:
Lloh568:
	adrp	x0, l_.str.69@PAGE
Lloh569:
	add	x0, x0, l_.str.69@PAGEOFF
LBB43_6:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_fail
LBB43_7:
	cbz	w2, LBB43_10
; %bb.8:
	mov	w23, w2
	cmp	w2, #7
	b.hi	LBB43_11
; %bb.9:
	mov	x22, x8
	mov	x9, #0                          ; =0x0
	mov	w21, #0                         ; =0x0
	b	LBB43_20
LBB43_10:
	mov	x19, x1
	mov	x22, x8
	mov	x20, x0
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #3
	b.lo	LBB43_23
	b	LBB43_29
LBB43_11:
	cmp	w2, #64
	b.hs	LBB43_13
; %bb.12:
	mov	x22, x8
	mov	x9, #0                          ; =0x0
	mov	w21, #0                         ; =0x0
	b	LBB43_17
LBB43_13:
	and	x9, x23, #0xffffffc0
	add	x10, x1, #64
	movi.2d	v0, #0000000000000000
	mov	x11, x9
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB43_14:                               ; =>This Inner Loop Header: Depth=1
	ldp	q4, q5, [x10, #-64]
	ldp	q6, q7, [x10, #-32]
	ldp	q16, q17, [x10]
	ldp	q18, q19, [x10, #32]
	cmeq.8h	v5, v5, #0
	cmeq.8h	v4, v4, #0
	uzp1.16b	v4, v4, v5
	cmeq.8h	v5, v7, #0
	cmeq.8h	v6, v6, #0
	uzp1.16b	v5, v6, v5
	cmeq.8h	v6, v17, #0
	cmeq.8h	v7, v16, #0
	uzp1.16b	v6, v7, v6
	cmeq.8h	v7, v19, #0
	cmeq.8h	v16, v18, #0
	uzp1.16b	v7, v16, v7
	orn.16b	v0, v0, v4
	orn.16b	v1, v1, v5
	orn.16b	v2, v2, v6
	orn.16b	v3, v3, v7
	add	x10, x10, #128
	subs	x11, x11, #64
	b.ne	LBB43_14
; %bb.15:
	orr.16b	v0, v1, v0
	orr.16b	v1, v3, v2
	orr.16b	v0, v1, v0
	shl.16b	v0, v0, #7
	cmlt.16b	v0, v0, #0
	umaxv.16b	b0, v0
	fmov	w10, s0
	and	w21, w10, #0x1
	mov	x22, x8
	cmp	x9, x23
	b.eq	LBB43_22
; %bb.16:
	tst	x23, #0x38
	b.eq	LBB43_20
LBB43_17:
	mov	x10, x9
	and	x9, x23, #0xfffffff8
	movi.2d	v0, #0000000000000000
	mov.b	v0[0], w21
	sub	x8, x10, x9
	add	x10, x1, x10, lsl #1
LBB43_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x10], #16
	cmtst.8h	v1, v1, v1
	xtn.8b	v1, v1
	orr.8b	v0, v0, v1
	adds	x8, x8, #8
	b.ne	LBB43_18
; %bb.19:
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	and	w21, w8, #0x1
	cmp	x9, x23
	b.eq	LBB43_22
LBB43_20:
	add	x8, x1, x9, lsl #1
	sub	x9, x23, x9
LBB43_21:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x8], #2
	cmp	w10, #0
	cset	w10, ne
	orr	w21, w21, w10
	subs	x9, x9, #1
	b.ne	LBB43_21
LBB43_22:
	mov	x19, x1
	mov	x20, x0
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #3
	b.hs	LBB43_25
LBB43_23:
	ldur	x8, [x29, #-56]
Lloh570:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh571:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh572:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB43_46
; %bb.24:
	mov	x8, x22
	mov	x0, x20
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, x19
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_verify_record_maps
LBB43_25:
	tbz	w21, #0, LBB43_29
; %bb.26:
	mov	x0, x20
	bl	_nvm_service_execution_pending
	cbz	w0, LBB43_31
; %bb.27:
	ldur	x8, [x29, #-56]
Lloh573:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh574:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh575:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB43_46
; %bb.28:
Lloh576:
	adrp	x0, l_.str.70@PAGE
Lloh577:
	add	x0, x0, l_.str.70@PAGEOFF
	mov	x8, x22
	b	LBB43_6
LBB43_29:
	mov	w8, #1                          ; =0x1
	strb	w8, [x22]
	movi.2d	v0, #0000000000000000
	stur	q0, [x22, #1]
	stur	q0, [x22, #17]
	stur	q0, [x22, #33]
	stur	q0, [x22, #49]
	stur	q0, [x22, #65]
	stur	q0, [x22, #81]
	stur	q0, [x22, #97]
	stur	q0, [x22, #113]
	stur	q0, [x22, #129]
	stur	q0, [x22, #145]
	stur	q0, [x22, #161]
	stur	q0, [x22, #177]
	stur	q0, [x22, #193]
	stur	q0, [x22, #209]
	stur	q0, [x22, #225]
	stur	q0, [x22, #241]
Lloh578:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh579:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh580:
	ldr	x8, [x8]
	ldur	x9, [x29, #-56]
	cmp	x8, x9
	b.ne	LBB43_46
LBB43_30:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB43_31:
	mov	x0, x20
	bl	_nvm_record_array_candidate
	cbz	w0, LBB43_34
; %bb.32:
	ldur	x8, [x29, #-56]
Lloh581:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh582:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh583:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB43_46
; %bb.33:
	mov	x8, x22
	mov	x0, x20
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, x19
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_verify_record_arrays
LBB43_34:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbnz	w0, LBB43_36
; %bb.35:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	cbz	w0, LBB43_47
LBB43_36:
	mov	x21, #0                         ; =0x0
	mov	x9, x19
	mov	x0, x20
	b	LBB43_39
LBB43_37:                               ;   in Loop: Header=BB43_39 Depth=1
	mov	x9, x19
	mov	x0, x20
LBB43_38:                               ;   in Loop: Header=BB43_39 Depth=1
	add	x21, x21, #1
	cmp	x23, x21
	b.eq	LBB43_43
LBB43_39:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w10, [x9, x21, lsl #1]
	cbz	w10, LBB43_38
; %bb.40:                               ;   in Loop: Header=BB43_39 Depth=1
	strh	wzr, [sp, #36]
	add	x8, sp, #39
	add	x2, sp, #36
	mov	x1, x21
	bl	_verify_function_impl
	ldrb	w8, [sp, #39]
	tbz	w8, #0, LBB43_44
; %bb.41:                               ;   in Loop: Header=BB43_39 Depth=1
	ldrh	w10, [x19, x21, lsl #1]
	ldrh	w11, [sp, #36]
	cmp	w10, w11
	b.hs	LBB43_37
; %bb.42:
	stp	x10, x11, [sp, #8]
	str	x21, [sp]
Lloh584:
	adrp	x0, l_.str.71@PAGE
Lloh585:
	add	x0, x0, l_.str.71@PAGEOFF
	mov	x8, x22
	bl	_fail
	b	LBB43_45
LBB43_43:
	mov	w9, #1                          ; =0x1
	strb	w9, [x22]
	movi.2d	v0, #0000000000000000
	stur	q0, [x22, #1]
	stur	q0, [x22, #17]
	stur	q0, [x22, #33]
	stur	q0, [x22, #49]
	stur	q0, [x22, #65]
	stur	q0, [x22, #81]
	stur	q0, [x22, #97]
	stur	q0, [x22, #113]
	stur	q0, [x22, #129]
	stur	q0, [x22, #145]
	stur	q0, [x22, #161]
	stur	q0, [x22, #177]
	stur	q0, [x22, #193]
	stur	q0, [x22, #209]
	stur	q0, [x22, #225]
	stur	q0, [x22, #241]
	b	LBB43_45
LBB43_44:
	add	x1, sp, #39
	mov	x0, x22
	mov	w2, #257                        ; =0x101
	bl	_memcpy
LBB43_45:
	ldur	x8, [x29, #-56]
Lloh586:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh587:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh588:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB43_30
LBB43_46:
	bl	___stack_chk_fail
LBB43_47:
	ldur	x8, [x29, #-56]
Lloh589:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh590:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh591:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB43_46
; %bb.48:
	mov	x8, x22
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	x3, x19
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_verify_functions_with_structure
	.loh AdrpLdrGotLdr	Lloh562, Lloh563, Lloh564
	.loh AdrpLdrGotLdr	Lloh565, Lloh566, Lloh567
	.loh AdrpAdd	Lloh568, Lloh569
	.loh AdrpLdrGotLdr	Lloh570, Lloh571, Lloh572
	.loh AdrpLdrGotLdr	Lloh573, Lloh574, Lloh575
	.loh AdrpAdd	Lloh576, Lloh577
	.loh AdrpLdrGotLdr	Lloh578, Lloh579, Lloh580
	.loh AdrpLdrGotLdr	Lloh581, Lloh582, Lloh583
	.loh AdrpAdd	Lloh584, Lloh585
	.loh AdrpLdrGotLdr	Lloh586, Lloh587, Lloh588
	.loh AdrpLdrGotLdr	Lloh589, Lloh590, Lloh591
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_record_maps
_verify_record_maps:                    ; @verify_record_maps
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #464
	stp	x26, x25, [sp, #384]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #400]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #416]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x20, x8
	add	x24, sp, #160
Lloh592:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh593:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh594:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	str	xzr, [x24]
	add	x23, sp, #172
	add	x8, sp, #172
	add	x1, sp, #160
	bl	_nvm_record_map_admit
	ldr	w8, [sp, #172]
	cbz	w8, LBB44_2
; %bb.1:
	add	x8, x23, #12
	str	x8, [sp]
Lloh595:
	adrp	x0, l_.str.186@PAGE
Lloh596:
	add	x0, x0, l_.str.186@PAGEOFF
	mov	x8, x20
	bl	_fail
	b	LBB44_10
LBB44_2:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x20, #1]
	stur	q0, [x20, #17]
	stur	q0, [x20, #33]
	stur	q0, [x20, #49]
	stur	q0, [x20, #65]
	stur	q0, [x20, #81]
	stur	q0, [x20, #97]
	stur	q0, [x20, #113]
	stur	q0, [x20, #129]
	stur	q0, [x20, #145]
	stur	q0, [x20, #161]
	stur	q0, [x20, #177]
	stur	q0, [x20, #193]
	stur	q0, [x20, #209]
	stur	q0, [x20, #225]
	stur	q0, [x20, #241]
	ldr	x0, [x24]
	add	x1, sp, #64
	bl	_nvm_record_map_execution_counts
	cbz	w0, LBB44_5
; %bb.3:
	ldr	w8, [sp, #64]
	cmn	w22, #1
	b.eq	LBB44_12
; %bb.4:
	cmp	w22, w8
	b.lo	LBB44_12
LBB44_5:
Lloh597:
	adrp	x0, l_.str.187@PAGE
Lloh598:
	add	x0, x0, l_.str.187@PAGEOFF
	mov	x8, x20
	bl	_fail
LBB44_6:
	mov	w25, #0                         ; =0x0
LBB44_7:
	ldr	x0, [x24]
	bl	_nvm_record_map_execution_free
	cbz	x19, LBB44_10
; %bb.8:
	ldrb	w8, [x20]
	tbz	w8, #0, LBB44_10
; %bb.9:
	strh	w25, [x19]
LBB44_10:
	ldur	x8, [x29, #-72]
Lloh599:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh600:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh601:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB44_21
; %bb.11:
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #432]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #416]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #400]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
LBB44_12:
	cbz	w8, LBB44_6
; %bb.13:
	mov	x23, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w22, w22
	b	LBB44_15
LBB44_14:                               ;   in Loop: Header=BB44_15 Depth=1
	cmp	x22, x23
	csel	w25, w8, w25, eq
	add	x23, x23, #1
	ldr	w8, [sp, #64]
	cmp	x23, x8
	b.hs	LBB44_7
LBB44_15:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x24]
	add	x2, sp, #28
	mov	x1, x23
	bl	_nvm_record_map_execution_function
	tbz	w0, #0, LBB44_19
; %bb.16:                               ;   in Loop: Header=BB44_15 Depth=1
	ldrh	w8, [sp, #60]
	cbz	x21, LBB44_14
; %bb.17:                               ;   in Loop: Header=BB44_15 Depth=1
	ldrh	w9, [x21, x23, lsl #1]
	cmp	w9, #0
	ccmp	w9, w8, #2, ne
	b.hs	LBB44_14
; %bb.18:
	stp	x9, x8, [sp, #8]
	str	x23, [sp]
Lloh602:
	adrp	x0, l_.str.71@PAGE
Lloh603:
	add	x0, x0, l_.str.71@PAGEOFF
	b	LBB44_20
LBB44_19:
Lloh604:
	adrp	x0, l_.str.188@PAGE
Lloh605:
	add	x0, x0, l_.str.188@PAGEOFF
LBB44_20:
	mov	x8, x20
	bl	_fail
	b	LBB44_7
LBB44_21:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh592, Lloh593, Lloh594
	.loh AdrpAdd	Lloh595, Lloh596
	.loh AdrpAdd	Lloh597, Lloh598
	.loh AdrpLdrGotLdr	Lloh599, Lloh600, Lloh601
	.loh AdrpAdd	Lloh602, Lloh603
	.loh AdrpAdd	Lloh604, Lloh605
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_record_arrays
_verify_record_arrays:                  ; @verify_record_arrays
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #368]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #384]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x20, x8
Lloh606:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh607:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh608:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	str	xzr, [sp, #128]
	add	x23, sp, #140
	add	x8, sp, #140
	add	x1, sp, #128
	bl	_nvm_record_array_admit
	ldr	w8, [sp, #140]
	cbz	w8, LBB45_2
; %bb.1:
	add	x8, x23, #12
	str	x8, [sp]
Lloh609:
	adrp	x0, l_.str.189@PAGE
Lloh610:
	add	x0, x0, l_.str.189@PAGEOFF
	mov	x8, x20
	bl	_fail
	b	LBB45_10
LBB45_2:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x20, #1]
	stur	q0, [x20, #17]
	stur	q0, [x20, #33]
	stur	q0, [x20, #49]
	stur	q0, [x20, #65]
	stur	q0, [x20, #81]
	stur	q0, [x20, #97]
	stur	q0, [x20, #113]
	stur	q0, [x20, #129]
	stur	q0, [x20, #145]
	stur	q0, [x20, #161]
	stur	q0, [x20, #177]
	stur	q0, [x20, #193]
	stur	q0, [x20, #209]
	stur	q0, [x20, #225]
	stur	q0, [x20, #241]
	ldr	x0, [sp, #128]
	add	x1, sp, #64
	bl	_nvm_record_array_execution_counts
	cbz	w0, LBB45_5
; %bb.3:
	ldr	w8, [sp, #64]
	cmn	w22, #1
	b.eq	LBB45_12
; %bb.4:
	cmp	w22, w8
	b.lo	LBB45_12
LBB45_5:
Lloh611:
	adrp	x0, l_.str.190@PAGE
Lloh612:
	add	x0, x0, l_.str.190@PAGEOFF
	mov	x8, x20
	bl	_fail
LBB45_6:
	mov	w24, #0                         ; =0x0
LBB45_7:
	ldr	x0, [sp, #128]
	bl	_nvm_record_array_execution_free
	cbz	x19, LBB45_10
; %bb.8:
	ldrb	w8, [x20]
	tbz	w8, #0, LBB45_10
; %bb.9:
	strh	w24, [x19]
LBB45_10:
	ldur	x8, [x29, #-72]
Lloh613:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh614:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh615:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB45_21
; %bb.11:
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #400]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #384]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
LBB45_12:
	cbz	w8, LBB45_6
; %bb.13:
	mov	x23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w22, w22
	b	LBB45_15
LBB45_14:                               ;   in Loop: Header=BB45_15 Depth=1
	cmp	x22, x23
	csel	w24, w8, w24, eq
	add	x23, x23, #1
	ldr	w8, [sp, #64]
	cmp	x23, x8
	b.hs	LBB45_7
LBB45_15:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #128]
	add	x2, sp, #28
	mov	x1, x23
	bl	_nvm_record_array_execution_function
	tbz	w0, #0, LBB45_19
; %bb.16:                               ;   in Loop: Header=BB45_15 Depth=1
	ldrh	w8, [sp, #60]
	cbz	x21, LBB45_14
; %bb.17:                               ;   in Loop: Header=BB45_15 Depth=1
	ldrh	w9, [x21, x23, lsl #1]
	cmp	w9, #0
	ccmp	w9, w8, #2, ne
	b.hs	LBB45_14
; %bb.18:
	stp	x9, x8, [sp, #8]
	str	x23, [sp]
Lloh616:
	adrp	x0, l_.str.71@PAGE
Lloh617:
	add	x0, x0, l_.str.71@PAGEOFF
	b	LBB45_20
LBB45_19:
Lloh618:
	adrp	x0, l_.str.191@PAGE
Lloh619:
	add	x0, x0, l_.str.191@PAGEOFF
LBB45_20:
	mov	x8, x20
	bl	_fail
	b	LBB45_7
LBB45_21:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh606, Lloh607, Lloh608
	.loh AdrpAdd	Lloh609, Lloh610
	.loh AdrpAdd	Lloh611, Lloh612
	.loh AdrpLdrGotLdr	Lloh613, Lloh614, Lloh615
	.loh AdrpAdd	Lloh616, Lloh617
	.loh AdrpAdd	Lloh618, Lloh619
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_functions_with_structure
_verify_functions_with_structure:       ; @verify_functions_with_structure
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	mov	x19, x8
Lloh620:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh621:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh622:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	strb	wzr, [sp, #37]
	add	x8, sp, #295
	add	x2, sp, #37
	mov	w1, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_structure_checked
	ldrb	w8, [sp, #295]
	tbz	w8, #0, LBB46_21
; %bb.1:
	ldrb	w8, [sp, #37]
	tbz	w8, #0, LBB46_3
; %bb.2:
	mov	w26, #1                         ; =0x1
	cbnz	w21, LBB46_6
	b	LBB46_9
LBB46_3:
	ldr	w8, [x23, #272]
	cbz	w8, LBB46_8
; %bb.4:
	ldr	w8, [x23, #304]
	cbz	w8, LBB46_22
; %bb.5:
	add	x8, sp, #38
	mov	x0, x23
	bl	_nvm_verify_owned_module
	ldrb	w26, [sp, #38]
	cbz	w21, LBB46_9
LBB46_6:
	tbz	w26, #0, LBB46_9
; %bb.7:
Lloh623:
	adrp	x0, l_.str.82@PAGE
Lloh624:
	add	x0, x0, l_.str.82@PAGEOFF
	b	LBB46_20
LBB46_8:
	mov	w26, #0                         ; =0x0
LBB46_9:
	ldr	w8, [x23, #272]
	cbz	w8, LBB46_23
LBB46_10:
	mov	x24, #0                         ; =0x0
	add	x9, sp, #38
	cmp	x20, #0
	csel	x25, xzr, x9, eq
	mov	w27, #256                       ; =0x100
	b	LBB46_13
LBB46_11:                               ;   in Loop: Header=BB46_13 Depth=1
	ldr	w8, [x23, #272]
LBB46_12:                               ;   in Loop: Header=BB46_13 Depth=1
	add	x24, x24, #1
	cmp	x24, x8
	b.hs	LBB46_23
LBB46_13:                               ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB46_15
; %bb.14:                               ;   in Loop: Header=BB46_13 Depth=1
	ldrh	w9, [x20, x24, lsl #1]
	cbz	w9, LBB46_12
LBB46_15:                               ;   in Loop: Header=BB46_13 Depth=1
	strh	w27, [sp, #38]
	tbnz	w26, #0, LBB46_17
; %bb.16:                               ;   in Loop: Header=BB46_13 Depth=1
	add	x8, sp, #295
	mov	x0, x23
	mov	x1, x24
	mov	x2, x22
	mov	x3, x21
	mov	x4, x25
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_verify_function_body
	ldrb	w8, [sp, #295]
	tbz	w8, #0, LBB46_21
LBB46_17:                               ;   in Loop: Header=BB46_13 Depth=1
	cbz	x20, LBB46_11
; %bb.18:                               ;   in Loop: Header=BB46_13 Depth=1
	ldrh	w8, [x20, x24, lsl #1]
	ldrh	w9, [sp, #38]
	cmp	w8, w9
	b.hs	LBB46_11
; %bb.19:
	stp	x8, x9, [sp, #8]
	str	x24, [sp]
Lloh625:
	adrp	x0, l_.str.71@PAGE
Lloh626:
	add	x0, x0, l_.str.71@PAGEOFF
LBB46_20:
	mov	x8, x19
	bl	_fail
	b	LBB46_24
LBB46_21:
	add	x1, sp, #295
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
	b	LBB46_24
LBB46_22:
	mov	w26, #0                         ; =0x0
	ldr	w8, [x23, #272]
	cbnz	w8, LBB46_10
LBB46_23:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
LBB46_24:
	ldur	x8, [x29, #-88]
Lloh627:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh628:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh629:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB46_26
; %bb.25:
	add	sp, sp, #560
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB46_26:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh620, Lloh621, Lloh622
	.loh AdrpAdd	Lloh623, Lloh624
	.loh AdrpAdd	Lloh625, Lloh626
	.loh AdrpLdrGotLdr	Lloh627, Lloh628, Lloh629
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify             ; -- Begin function nvm_verify
	.globl	_nvm_verify
	.p2align	2
_nvm_verify:                            ; @nvm_verify
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	x20, x8
	bl	_nvm_service_execution_pending
	cbz	w0, LBB47_2
; %bb.1:
Lloh630:
	adrp	x0, l_.str.70@PAGE
Lloh631:
	add	x0, x0, l_.str.70@PAGEOFF
	mov	x8, x20
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_fail
LBB47_2:
	mov	x0, x19
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB47_4
; %bb.3:
	mov	x8, x20
	mov	x0, x19
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_verify_record_maps
LBB47_4:
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbz	w0, LBB47_6
; %bb.5:
	mov	x8, x20
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_verify_owned_arrays
LBB47_6:
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	cbz	w0, LBB47_8
; %bb.7:
	mov	x8, x20
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_verify_mixed_samples
LBB47_8:
	mov	x0, x19
	bl	_nvm_record_array_candidate
	mov	x8, x20
	cbz	w0, LBB47_10
; %bb.9:
	mov	x0, x19
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_verify_record_arrays
LBB47_10:
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_verify_functions_with_structure
	.loh AdrpAdd	Lloh630, Lloh631
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_owned_arrays
_verify_owned_arrays:                   ; @verify_owned_arrays
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x2
	mov	x21, x1
	mov	x19, x8
	str	xzr, [sp, #56]
	add	x8, sp, #32
	add	x1, sp, #56
	bl	_nvm_owned_array_admit
	ldr	w8, [sp, #32]
	cbz	w8, LBB48_2
; %bb.1:
	ldr	x9, [sp, #48]
	ldp	w10, w11, [sp, #36]
	stp	x11, x9, [sp, #16]
	stp	x8, x10, [sp]
Lloh632:
	adrp	x0, l_.str.192@PAGE
Lloh633:
	add	x0, x0, l_.str.192@PAGEOFF
	b	LBB48_10
LBB48_2:
	ldr	x22, [sp, #56]
	cbz	x22, LBB48_9
; %bb.3:
	ldr	x0, [x22]
	ldr	w24, [x0, #16]
                                        ; implicit-def: $w23
	cmp	w21, w24
	b.hs	LBB48_5
; %bb.4:
	mov	w8, #116                        ; =0x74
	umaddl	x8, w21, w8, x0
	ldrh	w23, [x8, #40]
LBB48_5:
	bl	_nvm_owned_array_lifetime_facts_free
	mov	x0, x22
	bl	_free
	cmp	w21, w24
	b.hs	LBB48_9
; %bb.6:
	cbz	x20, LBB48_8
; %bb.7:
	strh	w23, [x20]
LBB48_8:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB48_11
LBB48_9:
Lloh634:
	adrp	x0, l_.str.193@PAGE
Lloh635:
	add	x0, x0, l_.str.193@PAGEOFF
LBB48_10:
	mov	x8, x19
	bl	_fail
LBB48_11:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpAdd	Lloh632, Lloh633
	.loh AdrpAdd	Lloh634, Lloh635
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_mixed_samples
_verify_mixed_samples:                  ; @verify_mixed_samples
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x22, x1
	mov	x19, x8
	stur	xzr, [x29, #-40]
	add	x8, sp, #32
	sub	x1, x29, #40
	bl	_nvm_mixed_samples_admit
	ldr	w8, [sp, #32]
	cbz	w8, LBB49_2
; %bb.1:
	ldr	x9, [sp, #48]
	ldp	w10, w11, [sp, #36]
	stp	x11, x9, [sp, #16]
	stp	x8, x10, [sp]
Lloh636:
	adrp	x0, l_.str.194@PAGE
Lloh637:
	add	x0, x0, l_.str.194@PAGEOFF
	b	LBB49_7
LBB49_2:
	ldur	x21, [x29, #-40]
	mov	w8, #25544                      ; =0x63c8
	ldr	w8, [x21, x8]
	cmp	w22, w8
	b.hs	LBB49_6
; %bb.3:
	mov	w8, #120                        ; =0x78
	umaddl	x8, w22, w8, x21
	ldrh	w22, [x8, #12]
	ldr	x0, [x21]
	bl	_nvm_mixed_samples_proof_free
	ldr	x0, [x21, #25552]
	bl	_free
	mov	x0, x21
	bl	_free
	cbz	x20, LBB49_5
; %bb.4:
	strh	w22, [x20]
LBB49_5:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB49_8
LBB49_6:
	ldr	x0, [x21]
	bl	_nvm_mixed_samples_proof_free
	ldr	x0, [x21, #25552]
	bl	_free
	mov	x0, x21
	bl	_free
Lloh638:
	adrp	x0, l_.str.195@PAGE
Lloh639:
	add	x0, x0, l_.str.195@PAGEOFF
LBB49_7:
	mov	x8, x19
	bl	_fail
LBB49_8:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpAdd	Lloh636, Lloh637
	.loh AdrpAdd	Lloh638, Lloh639
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify_linked      ; -- Begin function nvm_verify_linked
	.globl	_nvm_verify_linked
	.p2align	2
_nvm_verify_linked:                     ; @nvm_verify_linked
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x21, x2
	mov	x20, x0
	cbnz	x1, LBB50_5
; %bb.1:
	cbz	w21, LBB50_5
; %bb.2:
	str	x21, [sp]
Lloh640:
	adrp	x0, l_.str.72@PAGE
Lloh641:
	add	x0, x0, l_.str.72@PAGEOFF
LBB50_3:
	bl	_fail
LBB50_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB50_5:
	mov	x19, x8
	cbz	w21, LBB50_13
; %bb.6:
	mov	w23, w21
	mov	x24, x23
	mov	x22, x1
	mov	x25, x1
LBB50_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x25], #8
	bl	_nvm_service_execution_pending
	cbnz	w0, LBB50_15
; %bb.8:                                ;   in Loop: Header=BB50_7 Depth=1
	subs	x24, x24, #1
	b.ne	LBB50_7
; %bb.9:
	mov	x0, x20
	bl	_nvm_service_execution_pending
	tbnz	w0, #0, LBB50_14
; %bb.10:
	mov	x24, x22
LBB50_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x24], #8
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.ls	LBB50_25
; %bb.12:                               ;   in Loop: Header=BB50_11 Depth=1
	subs	x23, x23, #1
	b.ne	LBB50_11
	b	LBB50_16
LBB50_13:
	mov	x22, x1
	mov	x0, x20
	bl	_nvm_service_execution_pending
	cbz	w0, LBB50_16
LBB50_14:
Lloh642:
	adrp	x0, l_.str.70@PAGE
Lloh643:
	add	x0, x0, l_.str.70@PAGEOFF
	b	LBB50_30
LBB50_15:
Lloh644:
	adrp	x0, l_.str.73@PAGE
Lloh645:
	add	x0, x0, l_.str.73@PAGEOFF
	b	LBB50_30
LBB50_16:
	mov	x0, x20
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #3
	b.hs	LBB50_19
; %bb.17:
	cbz	w21, LBB50_26
; %bb.18:
Lloh646:
	adrp	x0, l_.str.75@PAGE
Lloh647:
	add	x0, x0, l_.str.75@PAGEOFF
	b	LBB50_30
LBB50_19:
	cbz	w21, LBB50_27
; %bb.20:
	mov	w23, w21
	mov	x24, x23
	mov	x25, x22
LBB50_21:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x25], #8
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbnz	w0, LBB50_29
; %bb.22:                               ;   in Loop: Header=BB50_21 Depth=1
	subs	x24, x24, #1
	b.ne	LBB50_21
; %bb.23:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbz	w0, LBB50_33
; %bb.24:
Lloh648:
	adrp	x0, l_.str.77@PAGE
Lloh649:
	add	x0, x0, l_.str.77@PAGEOFF
	b	LBB50_30
LBB50_25:
Lloh650:
	adrp	x0, l_.str.74@PAGE
Lloh651:
	add	x0, x0, l_.str.74@PAGEOFF
	b	LBB50_30
LBB50_26:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_verify_record_maps
LBB50_27:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbz	w0, LBB50_31
; %bb.28:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_verify_owned_arrays
LBB50_29:
Lloh652:
	adrp	x0, l_.str.76@PAGE
Lloh653:
	add	x0, x0, l_.str.76@PAGEOFF
LBB50_30:
	mov	x8, x19
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_fail
LBB50_31:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	tbz	w0, #0, LBB50_38
; %bb.32:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_verify_mixed_samples
LBB50_33:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	tbz	w0, #0, LBB50_35
; %bb.34:
Lloh654:
	adrp	x0, l_.str.78@PAGE
Lloh655:
	add	x0, x0, l_.str.78@PAGEOFF
	b	LBB50_30
LBB50_35:
	mov	x24, x22
LBB50_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x24], #8
	bl	_nvm_record_array_candidate
	cbnz	w0, LBB50_56
; %bb.37:                               ;   in Loop: Header=BB50_36 Depth=1
	subs	x23, x23, #1
	b.ne	LBB50_36
LBB50_38:
	mov	x0, x20
	bl	_nvm_record_array_candidate
	cbz	w0, LBB50_41
; %bb.39:
	cbz	w21, LBB50_57
; %bb.40:
Lloh656:
	adrp	x0, l_.str.80@PAGE
Lloh657:
	add	x0, x0, l_.str.80@PAGEOFF
	b	LBB50_30
LBB50_41:
	mov	x8, x19
	cbz	w21, LBB50_60
; %bb.42:
	mov	w23, w21
	mov	x24, x23
	mov	x25, x22
LBB50_43:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x25], #8
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	cbnz	w0, LBB50_58
; %bb.44:                               ;   in Loop: Header=BB50_43 Depth=1
	subs	x24, x24, #1
	b.ne	LBB50_43
; %bb.45:
	strb	wzr, [sp, #15]
	cbz	x20, LBB50_49
; %bb.46:
	add	x1, sp, #15
	mov	x0, x20
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB50_48
; %bb.47:
	ldrb	w8, [sp, #15]
	tbnz	w8, #0, LBB50_55
LBB50_48:
	mov	x0, x20
	bl	_nvm_uses_owned_transfers
	tbnz	w0, #0, LBB50_55
LBB50_49:
	mov	x24, x22
	b	LBB50_52
LBB50_50:                               ;   in Loop: Header=BB50_52 Depth=1
	ldr	x0, [x24]
	bl	_nvm_uses_owned_transfers
	tbnz	w0, #0, LBB50_55
LBB50_51:                               ;   in Loop: Header=BB50_52 Depth=1
	add	x24, x24, #8
	subs	x23, x23, #1
	b.eq	LBB50_59
LBB50_52:                               ; =>This Inner Loop Header: Depth=1
	strb	wzr, [sp, #15]
	ldr	x0, [x24]
	cbz	x0, LBB50_51
; %bb.53:                               ;   in Loop: Header=BB50_52 Depth=1
	add	x1, sp, #15
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB50_50
; %bb.54:                               ;   in Loop: Header=BB50_52 Depth=1
	ldrb	w8, [sp, #15]
	tbz	w8, #0, LBB50_50
LBB50_55:
Lloh658:
	adrp	x0, l_.str.82@PAGE
Lloh659:
	add	x0, x0, l_.str.82@PAGEOFF
	mov	x8, x19
	b	LBB50_3
LBB50_56:
Lloh660:
	adrp	x0, l_.str.79@PAGE
Lloh661:
	add	x0, x0, l_.str.79@PAGEOFF
	b	LBB50_30
LBB50_57:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	b	_verify_record_arrays
LBB50_58:
Lloh662:
	adrp	x0, l_.str.81@PAGE
Lloh663:
	add	x0, x0, l_.str.81@PAGEOFF
	b	LBB50_30
LBB50_59:
	mov	x8, x19
LBB50_60:
	mov	x0, x20
	mov	x1, x22
	mov	x2, x21
	mov	x3, #0                          ; =0x0
	bl	_verify_functions_with_structure
	b	LBB50_4
	.loh AdrpAdd	Lloh640, Lloh641
	.loh AdrpAdd	Lloh642, Lloh643
	.loh AdrpAdd	Lloh644, Lloh645
	.loh AdrpAdd	Lloh646, Lloh647
	.loh AdrpAdd	Lloh648, Lloh649
	.loh AdrpAdd	Lloh650, Lloh651
	.loh AdrpAdd	Lloh652, Lloh653
	.loh AdrpAdd	Lloh654, Lloh655
	.loh AdrpAdd	Lloh656, Lloh657
	.loh AdrpAdd	Lloh658, Lloh659
	.loh AdrpAdd	Lloh660, Lloh661
	.loh AdrpAdd	Lloh662, Lloh663
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_verify_profile     ; -- Begin function nvm_verify_profile
	.globl	_nvm_verify_profile
	.p2align	2
_nvm_verify_profile:                    ; @nvm_verify_profile
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #592
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x1
Lloh664:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh665:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh666:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	cmp	w1, #6
	b.lo	LBB51_3
; %bb.1:
	str	x21, [sp]
Lloh667:
	adrp	x0, l_.str.83@PAGE
Lloh668:
	add	x0, x0, l_.str.83@PAGEOFF
LBB51_2:
	bl	_fail
	b	LBB51_9
LBB51_3:
	mov	x20, x0
	mov	x19, x8
	add	x8, sp, #319
	bl	_nvm_verify
	cbz	w21, LBB51_8
; %bb.4:
	ldrb	w8, [sp, #319]
	tbz	w8, #0, LBB51_8
; %bb.5:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	cbz	w0, LBB51_11
; %bb.6:
	ldur	x8, [x29, #-96]
Lloh669:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh670:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh671:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.7:
Lloh672:
	adrp	x0, l_.str.84@PAGE
Lloh673:
	add	x0, x0, l_.str.84@PAGEOFF
	b	LBB51_20
LBB51_8:
	add	x1, sp, #319
	mov	x0, x19
	mov	w2, #257                        ; =0x101
	bl	_memcpy
LBB51_9:
	ldur	x8, [x29, #-96]
Lloh674:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh675:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh676:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.10:
	add	sp, sp, #592
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB51_11:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	cbz	w0, LBB51_14
; %bb.12:
	ldur	x8, [x29, #-96]
Lloh677:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh678:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh679:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.13:
Lloh680:
	adrp	x0, l_.str.85@PAGE
Lloh681:
	add	x0, x0, l_.str.85@PAGEOFF
	b	LBB51_20
LBB51_14:
	mov	x0, x20
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB51_17
; %bb.15:
	ldur	x8, [x29, #-96]
Lloh682:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh683:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh684:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.16:
Lloh685:
	adrp	x0, l_.str.86@PAGE
Lloh686:
	add	x0, x0, l_.str.86@PAGEOFF
	b	LBB51_20
LBB51_17:
	mov	x0, x20
	bl	_nvm_record_array_candidate
	cbz	w0, LBB51_22
; %bb.18:
	ldur	x8, [x29, #-96]
Lloh687:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh688:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh689:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.19:
Lloh690:
	adrp	x0, l_.str.87@PAGE
Lloh691:
	add	x0, x0, l_.str.87@PAGEOFF
LBB51_20:
	mov	x8, x19
LBB51_21:
	add	sp, sp, #592
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_fail
LBB51_22:
	cmp	w21, #5
	cset	w23, eq
	and	w26, w21, #0x6
	cmp	w26, #4
	mov	x8, x19
	b.ne	LBB51_27
; %bb.23:
	ldr	w24, [x20, #432]
	cbz	w24, LBB51_25
; %bb.24:
	ldr	w9, [x20, #424]
	cbz	w9, LBB51_33
LBB51_25:
	ldur	x9, [x29, #-96]
Lloh692:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh693:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh694:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB51_129
; %bb.26:
Lloh695:
	adrp	x0, l_.str.88@PAGE
Lloh696:
	add	x0, x0, l_.str.88@PAGEOFF
	b	LBB51_21
LBB51_27:
	cmp	w21, #3
	cset	w9, eq
	b.ne	LBB51_31
; %bb.28:
	ldr	w10, [x20, #468]
	cbnz	w10, LBB51_30
; %bb.29:
	ldr	w10, [x20, #320]
	cbz	w10, LBB51_45
LBB51_30:
	mov	w10, #1                         ; =0x1
	b	LBB51_32
LBB51_31:
	mov	w10, #0                         ; =0x0
LBB51_32:
	ldr	w11, [x20, #432]
	cbnz	w11, LBB51_43
	b	LBB51_40
LBB51_33:
	mov	w22, #0                         ; =0x0
	b	LBB51_36
LBB51_34:                               ;   in Loop: Header=BB51_36 Depth=1
	mov	x8, x19
	cbz	w0, LBB51_38
LBB51_35:                               ;   in Loop: Header=BB51_36 Depth=1
	add	w22, w22, #1
	cmp	w24, w22
	b.eq	LBB51_39
LBB51_36:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	mov	x1, x22
	bl	_nvm_portable_file_read_import
	cmp	w21, #5
	b.eq	LBB51_34
; %bb.37:                               ;   in Loop: Header=BB51_36 Depth=1
	cmp	w0, #1
	mov	x8, x19
	b.eq	LBB51_35
LBB51_38:
	str	x22, [sp]
Lloh697:
	adrp	x0, l_.str.89@PAGE
Lloh698:
	add	x0, x0, l_.str.89@PAGEOFF
	b	LBB51_2
LBB51_39:
	mov	w9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
LBB51_40:
	ldr	w11, [x20, #448]
	cbnz	w11, LBB51_43
; %bb.41:
	ldr	w11, [x20, #476]
	cbnz	w11, LBB51_43
; %bb.42:
	ldr	w11, [x20, #352]
	cbz	w11, LBB51_46
LBB51_43:
	ldur	x9, [x29, #-96]
Lloh699:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh700:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh701:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB51_129
; %bb.44:
Lloh702:
	adrp	x0, l_.str.90@PAGE
Lloh703:
	add	x0, x0, l_.str.90@PAGEOFF
	b	LBB51_21
LBB51_45:
	ldr	w10, [x20, #304]
	cmp	w10, #0
	cset	w10, ne
	b	LBB51_32
LBB51_46:
	tbz	w10, #0, LBB51_50
LBB51_47:
	str	w10, [sp, #100]                 ; 4-byte Folded Spill
	ldrb	w8, [x20, #8]
	tbnz	w8, #0, LBB51_53
; %bb.48:
	ldur	x8, [x29, #-96]
Lloh704:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh705:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh706:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.49:
Lloh707:
	adrp	x0, l_.str.91@PAGE
Lloh708:
	add	x0, x0, l_.str.91@PAGEOFF
	b	LBB51_20
LBB51_50:
	ldr	w11, [x20, #468]
	cbnz	w11, LBB51_43
; %bb.51:
	ldr	w11, [x20, #304]
	cbnz	w11, LBB51_43
; %bb.52:
	ldr	w11, [x20, #320]
	cbnz	w11, LBB51_43
	b	LBB51_47
LBB51_53:
	ldr	x8, [x20, #256]
	ldr	w10, [x20, #12]
	mov	w11, #24                        ; =0x18
	umaddl	x11, w10, w11, x8
	ldrb	w12, [x11, #21]
	cmp	w12, #1
	b.ne	LBB51_58
; %bb.54:
	ldrb	w11, [x11, #20]
	cmp	w11, #1
	ccmp	w11, #4, #4, ne
	b.ne	LBB51_58
; %bb.55:
	mov	w11, #24                        ; =0x18
	umaddl	x8, w10, w11, x8
	ldrh	w8, [x8, #4]
	cbz	w8, LBB51_60
; %bb.56:
	ldur	x8, [x29, #-96]
Lloh709:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh710:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh711:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.57:
Lloh712:
	adrp	x0, l_.str.93@PAGE
Lloh713:
	add	x0, x0, l_.str.93@PAGEOFF
	b	LBB51_20
LBB51_58:
	ldur	x8, [x29, #-96]
Lloh714:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh715:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh716:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB51_129
; %bb.59:
Lloh717:
	adrp	x0, l_.str.92@PAGE
Lloh718:
	add	x0, x0, l_.str.92@PAGEOFF
	b	LBB51_20
LBB51_60:
	mov	x22, x23
	cmp	w26, #4
	csinc	w8, w9, wzr, ne
	cmp	w21, #2
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldr	w8, [x20, #272]
	cbz	w8, LBB51_124
; %bb.61:
	str	wzr, [sp, #96]                  ; 4-byte Folded Spill
	str	wzr, [sp, #76]                  ; 4-byte Folded Spill
	mov	w23, #0                         ; =0x0
	cmp	w26, #4
	ccmp	w26, #2, #4, ne
	cset	w8, eq
	stp	w8, wzr, [sp, #44]              ; 8-byte Folded Spill
LBB51_62:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB51_83 Depth 2
                                        ;     Child Loop BB51_92 Depth 2
	ldr	x8, [x20, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w23, w9, x8
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	ldr	w1, [x8]
	mov	x0, x20
	bl	_nvm_get_string
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB51_68
; %bb.63:                               ;   in Loop: Header=BB51_62 Depth=1
	cbz	x0, LBB51_68
; %bb.64:                               ;   in Loop: Header=BB51_62 Depth=1
Lloh719:
	adrp	x1, l_.str.10@PAGE
Lloh720:
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB51_66
; %bb.65:                               ;   in Loop: Header=BB51_62 Depth=1
	str	wzr, [sp, #48]                  ; 4-byte Folded Spill
	b	LBB51_68
LBB51_66:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #4]
	cbnz	w8, LBB51_139
; %bb.67:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
LBB51_68:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	w8, w23
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB51_138
; %bb.69:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #21]
	cmp	w8, #1
	b.eq	LBB51_72
; %bb.70:                               ;   in Loop: Header=BB51_62 Depth=1
	cbnz	w8, LBB51_138
; %bb.71:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #20]
	cbz	w8, LBB51_79
	b	LBB51_138
LBB51_72:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #20]
	sub	w9, w8, #1
	cmp	w9, #9
	b.hs	LBB51_75
; %bb.73:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	w10, #271                       ; =0x10f
	lsr	w9, w10, w9
	tbz	w9, #0, LBB51_75
; %bb.74:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	w8, #0                          ; =0x0
	b	LBB51_79
LBB51_75:                               ;   in Loop: Header=BB51_62 Depth=1
	cmp	w8, #5
	ldr	w9, [sp, #44]                   ; 4-byte Folded Reload
	csel	w11, wzr, w9, ne
	cmp	w8, #7
	ldr	w9, [sp, #84]                   ; 4-byte Folded Reload
	csel	w10, wzr, w9, ne
	cmp	w8, #8
	ldr	w9, [sp, #100]                  ; 4-byte Folded Reload
	csel	w9, wzr, w9, ne
	tbnz	w11, #0, LBB51_78
; %bb.76:                               ;   in Loop: Header=BB51_62 Depth=1
	tbnz	w10, #0, LBB51_78
; %bb.77:                               ;   in Loop: Header=BB51_62 Depth=1
	tbz	w9, #0, LBB51_138
LBB51_78:                               ;   in Loop: Header=BB51_62 Depth=1
	cmp	w8, #5
	cset	w8, eq
LBB51_79:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	w9, [sp, #96]                   ; 4-byte Folded Reload
	orr	w9, w9, w8
	str	w9, [sp, #96]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #4]
	cbz	x8, LBB51_89
; %bb.80:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20, #264]
	b	LBB51_83
LBB51_81:                               ;   in Loop: Header=BB51_83 Depth=2
	cmp	w26, #4
	b.eq	LBB51_130
LBB51_82:                               ;   in Loop: Header=BB51_83 Depth=2
	add	x9, x9, #1
	cmp	x8, x9
	b.eq	LBB51_89
LBB51_83:                               ;   Parent Loop BB51_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x10, LBB51_81
; %bb.84:                               ;   in Loop: Header=BB51_83 Depth=2
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x11, [x10, x11, lsl #3]
	cbz	x11, LBB51_81
; %bb.85:                               ;   in Loop: Header=BB51_83 Depth=2
	ldrb	w12, [x11, x9]
	cmp	w12, #5
	ldr	w11, [sp, #52]                  ; 4-byte Folded Reload
	csel	w11, wzr, w11, ne
	cset	w13, eq
	cmp	w12, #7
	ldr	w14, [sp, #84]                  ; 4-byte Folded Reload
	csel	w14, wzr, w14, ne
	ldr	w15, [sp, #96]                  ; 4-byte Folded Reload
	orr	w15, w15, w13
	str	w15, [sp, #96]                  ; 4-byte Folded Spill
	cmp	w12, #8
	ldr	w13, [sp, #100]                 ; 4-byte Folded Reload
	csel	w13, wzr, w13, ne
	tbnz	w14, #0, LBB51_82
; %bb.86:                               ;   in Loop: Header=BB51_83 Depth=2
	cmp	w12, #5
	ccmp	w12, #9, #4, hs
	b.eq	LBB51_82
; %bb.87:                               ;   in Loop: Header=BB51_83 Depth=2
	tbnz	w11, #0, LBB51_82
; %bb.88:                               ;   in Loop: Header=BB51_83 Depth=2
	tbnz	w13, #0, LBB51_82
	b	LBB51_131
LBB51_89:                               ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cbz	w8, LBB51_122
; %bb.90:                               ;   in Loop: Header=BB51_62 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB51_92
LBB51_91:                               ;   in Loop: Header=BB51_92 Depth=2
	and	w8, w22, #0x1
	ldp	w9, w10, [sp, #68]              ; 8-byte Folded Reload
	orr	w22, w10, w8
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	orr	w8, w9, w8
	str	w8, [sp, #96]                   ; 4-byte Folded Spill
	ldp	w8, w9, [sp, #76]               ; 8-byte Folded Reload
	and	w8, w8, #0x1
	orr	w8, w9, w8
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	add	w28, w23, w28
	cmp	w28, w8
	b.hs	LBB51_122
LBB51_92:                               ;   Parent Loop BB51_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	ldr	x8, [x20, #280]
	ldr	x10, [sp, #88]                  ; 8-byte Folded Reload
	ldp	w9, w10, [x10, #8]
	add	x8, x8, x9
	add	x0, x8, w28, uxtw
	sub	w1, w10, w28
	add	x2, sp, #112
	bl	_isa_decode
	mov	x23, x0
	ldrb	w24, [sp, #112]
	sub	w8, w24, #80
	cmp	w8, #9
	b.hs	LBB51_95
; %bb.93:                               ;   in Loop: Header=BB51_92 Depth=2
	mov	w9, #279                        ; =0x117
	lsr	w8, w9, w8
	tbz	w8, #0, LBB51_95
; %bb.94:                               ;   in Loop: Header=BB51_92 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB51_96
LBB51_95:                               ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #86
	cset	w8, eq
LBB51_96:                               ;   in Loop: Header=BB51_92 Depth=2
	str	w8, [sp, #72]                   ; 4-byte Folded Spill
	sub	w8, w24, #4
	cmp	w8, #62
	b.hi	LBB51_99
; %bb.97:                               ;   in Loop: Header=BB51_92 Depth=2
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	x9, #1                          ; =0x1
	movk	x9, #24576, lsl #48
	tst	x8, x9
	b.eq	LBB51_99
; %bb.98:                               ;   in Loop: Header=BB51_92 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB51_100
LBB51_99:                               ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #139
	cset	w8, eq
LBB51_100:                              ;   in Loop: Header=BB51_92 Depth=2
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB51_102
; %bb.101:                              ;   in Loop: Header=BB51_92 Depth=2
	str	wzr, [sp, #80]                  ; 4-byte Folded Spill
	b	LBB51_105
LBB51_102:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
	cmp	w24, #32
	b.eq	LBB51_105
; %bb.103:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #136
	b.eq	LBB51_105
; %bb.104:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #137
	cset	w8, eq
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
LBB51_105:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w26, #4
	b.eq	LBB51_107
; %bb.106:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w26, #2
	b.ne	LBB51_114
LBB51_107:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w27, #1                         ; =0x1
	cmp	w24, #4
	b.eq	LBB51_115
; %bb.108:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #64
	b.eq	LBB51_115
; %bb.109:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #68
	b.eq	LBB51_115
; %bb.110:                              ;   in Loop: Header=BB51_92 Depth=2
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	cbz	w8, LBB51_114
; %bb.111:                              ;   in Loop: Header=BB51_92 Depth=2
	sub	w8, w24, #65
	cmp	w8, #23
	b.hi	LBB51_113
; %bb.112:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	mov	w9, #49143                      ; =0xbff7
	movk	w9, #191, lsl #16
	tst	w8, w9
	b.ne	LBB51_115
LBB51_113:                              ;   in Loop: Header=BB51_92 Depth=2
	cmp	w24, #139
	b.eq	LBB51_115
LBB51_114:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w27, #0                         ; =0x0
LBB51_115:                              ;   in Loop: Header=BB51_92 Depth=2
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	cbz	w8, LBB51_118
; %bb.116:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w25, #1                         ; =0x1
	sub	w8, w24, #96
	cmp	w8, #4
	b.lo	LBB51_119
; %bb.117:                              ;   in Loop: Header=BB51_92 Depth=2
	sub	w8, w24, #251
	cmp	w8, #3
	b.lo	LBB51_119
LBB51_118:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	w25, #0                         ; =0x0
LBB51_119:                              ;   in Loop: Header=BB51_92 Depth=2
	cbz	w23, LBB51_128
; %bb.120:                              ;   in Loop: Header=BB51_92 Depth=2
	mov	x0, x24
	bl	_profile_supported
	cmp	w24, #62
	ccmp	w26, #4, #0, eq
	b.eq	LBB51_91
; %bb.121:                              ;   in Loop: Header=BB51_92 Depth=2
	orr	w8, w25, w27
	orr	w8, w8, w0
	tbnz	w8, #0, LBB51_91
	b	LBB51_128
LBB51_122:                              ;   in Loop: Header=BB51_62 Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	w23, w8, #1
	ldr	w8, [x20, #272]
	cmp	w23, w8
	b.lo	LBB51_62
; %bb.123:
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #76]                   ; 4-byte Folded Reload
	and	w23, w8, w9
	b	LBB51_125
LBB51_124:
	mov	w23, #0                         ; =0x0
LBB51_125:
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	orr	w8, w22, w8
	tbz	w8, #0, LBB51_135
; %bb.126:
	str	xzr, [sp, #104]
	add	x8, sp, #112
	cmp	w21, #5
	b.ne	LBB51_132
; %bb.127:
	add	x1, sp, #104
	mov	x0, x20
	bl	_nvm_select_portable_read_heap
	b	LBB51_133
LBB51_128:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	stp	x8, x28, [sp, #8]
	str	x24, [sp]
Lloh721:
	adrp	x0, l_.str.98@PAGE
Lloh722:
	add	x0, x0, l_.str.98@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_129:
	bl	___stack_chk_fail
LBB51_130:
Lloh723:
	adrp	x0, l_.str.96@PAGE
Lloh724:
	add	x0, x0, l_.str.96@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_131:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	x8, [sp]
Lloh725:
	adrp	x0, l_.str.97@PAGE
Lloh726:
	add	x0, x0, l_.str.97@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_132:
	and	w1, w22, #0x1
	add	x2, sp, #104
	mov	x0, x20
	bl	_nvm_select_managed_heap
LBB51_133:
	ldr	x0, [sp, #104]
	bl	_nvm_managed_heap_plan_free
	ldr	w8, [sp, #112]
	cbz	w8, LBB51_135
; %bb.134:
	add	x9, sp, #112
	add	x9, x9, #12
	ldp	w10, w11, [sp, #116]
	stp	x11, x9, [sp, #16]
	stp	x8, x10, [sp]
Lloh727:
	adrp	x0, l_.str.99@PAGE
Lloh728:
	add	x0, x0, l_.str.99@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_135:
	tbz	w23, #0, LBB51_137
; %bb.136:
Lloh729:
	adrp	x0, l_.str.100@PAGE
Lloh730:
	add	x0, x0, l_.str.100@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_137:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #1]
	stur	q0, [x19, #17]
	stur	q0, [x19, #33]
	stur	q0, [x19, #49]
	stur	q0, [x19, #65]
	stur	q0, [x19, #81]
	stur	q0, [x19, #97]
	stur	q0, [x19, #113]
	stur	q0, [x19, #129]
	stur	q0, [x19, #145]
	stur	q0, [x19, #161]
	stur	q0, [x19, #177]
	stur	q0, [x19, #193]
	stur	q0, [x19, #209]
	stur	q0, [x19, #225]
	stur	q0, [x19, #241]
	b	LBB51_9
LBB51_138:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	x8, [sp]
Lloh731:
	adrp	x0, l_.str.95@PAGE
Lloh732:
	add	x0, x0, l_.str.95@PAGEOFF
	mov	x8, x19
	b	LBB51_2
LBB51_139:
Lloh733:
	adrp	x0, l_.str.94@PAGE
Lloh734:
	add	x0, x0, l_.str.94@PAGEOFF
	mov	x8, x19
	b	LBB51_2
	.loh AdrpLdrGotLdr	Lloh664, Lloh665, Lloh666
	.loh AdrpAdd	Lloh667, Lloh668
	.loh AdrpLdrGotLdr	Lloh669, Lloh670, Lloh671
	.loh AdrpAdd	Lloh672, Lloh673
	.loh AdrpLdrGotLdr	Lloh674, Lloh675, Lloh676
	.loh AdrpLdrGotLdr	Lloh677, Lloh678, Lloh679
	.loh AdrpAdd	Lloh680, Lloh681
	.loh AdrpLdrGotLdr	Lloh682, Lloh683, Lloh684
	.loh AdrpAdd	Lloh685, Lloh686
	.loh AdrpLdrGotLdr	Lloh687, Lloh688, Lloh689
	.loh AdrpAdd	Lloh690, Lloh691
	.loh AdrpLdrGotLdr	Lloh692, Lloh693, Lloh694
	.loh AdrpAdd	Lloh695, Lloh696
	.loh AdrpAdd	Lloh697, Lloh698
	.loh AdrpLdrGotLdr	Lloh699, Lloh700, Lloh701
	.loh AdrpAdd	Lloh702, Lloh703
	.loh AdrpLdrGotLdr	Lloh704, Lloh705, Lloh706
	.loh AdrpAdd	Lloh707, Lloh708
	.loh AdrpLdrGotLdr	Lloh709, Lloh710, Lloh711
	.loh AdrpAdd	Lloh712, Lloh713
	.loh AdrpLdrGotLdr	Lloh714, Lloh715, Lloh716
	.loh AdrpAdd	Lloh717, Lloh718
	.loh AdrpAdd	Lloh719, Lloh720
	.loh AdrpAdd	Lloh721, Lloh722
	.loh AdrpAdd	Lloh723, Lloh724
	.loh AdrpAdd	Lloh725, Lloh726
	.loh AdrpAdd	Lloh727, Lloh728
	.loh AdrpAdd	Lloh729, Lloh730
	.loh AdrpAdd	Lloh731, Lloh732
	.loh AdrpAdd	Lloh733, Lloh734
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_portable_file_read_import
_nvm_portable_file_read_import:         ; @nvm_portable_file_read_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB52_15
; %bb.1:
	ldr	w8, [x0, #432]
	cmp	w1, w8
	b.hs	LBB52_14
; %bb.2:
	ldr	x9, [x0, #400]
	cbz	x9, LBB52_14
; %bb.3:
	ldr	x11, [x0, #408]
	cbz	x11, LBB52_14
; %bb.4:
	ldr	x10, [x0, #232]
	cbz	x10, LBB52_14
; %bb.5:
	ldr	x8, [x0, #240]
	cbz	x8, LBB52_14
; %bb.6:
	mov	w12, #12                        ; =0xc
	umaddl	x13, w1, w12, x9
	ldr	w12, [x13]
	ldr	w14, [x0, #248]
	cmp	w12, w14
	b.hs	LBB52_14
; %bb.7:
	ldr	w9, [x13, #4]
	cmp	w9, w14
	b.hs	LBB52_14
; %bb.8:
	ldrb	w14, [x13, #11]
	cbnz	w14, LBB52_14
; %bb.9:
	ldrh	w14, [x13, #8]
	cmp	w14, #1
	b.ne	LBB52_14
; %bb.10:
	ldrb	w13, [x13, #10]
	orr	w14, w13, #0x2
	cmp	w14, #7
	b.ne	LBB52_14
; %bb.11:
	ldr	x11, [x11, w1, uxtw #3]
	cbz	x11, LBB52_14
; %bb.12:
	ldrb	w11, [x11]
	cmp	w11, #5
	b.ne	LBB52_14
; %bb.13:
	ldr	w11, [x8, x12, lsl #2]
	cbz	w11, LBB52_16
LBB52_14:
	mov	w0, #0                          ; =0x0
LBB52_15:
	ret
LBB52_16:
	ldr	x10, [x10, x9, lsl #3]
	cbz	x10, LBB52_14
; %bb.17:
	cmp	w13, #7
	b.eq	LBB52_23
; %bb.18:
	cmp	w13, #5
	b.ne	LBB52_14
; %bb.19:
	ldr	w11, [x8, x9, lsl #2]
	cmp	w11, #12
	b.eq	LBB52_34
; %bb.20:
	cmp	w11, #9
	b.ne	LBB52_35
; %bb.21:
	ldr	x8, [x10]
	ldrb	w9, [x10, #8]
	mov	x10, #26982                     ; =0x6966
	movk	x10, #25964, lsl #16
	movk	x10, #29279, lsl #32
	movk	x10, #24933, lsl #48
	cmp	x8, x10
	mov	w8, #100                        ; =0x64
	ccmp	w9, w8, #0, eq
	b.ne	LBB52_14
; %bb.22:
	mov	w0, #1                          ; =0x1
	ret
LBB52_23:
	ldr	w11, [x8, x9, lsl #2]
	cmp	w11, #18
	b.eq	LBB52_28
; %bb.24:
	cmp	w11, #15
	b.ne	LBB52_30
; %bb.25:
	ldr	x12, [x10]
	ldrb	w13, [x10, #8]
	mov	x14, #26982                     ; =0x6966
	movk	x14, #25964, lsl #16
	movk	x14, #29279, lsl #32
	movk	x14, #24933, lsl #48
	cmp	x12, x14
	mov	w12, #100                       ; =0x64
	ccmp	w13, w12, #0, eq
	b.ne	LBB52_14
; %bb.26:
	ldur	w12, [x10, #9]
	ldurh	w13, [x10, #13]
	mov	w14, #25183                     ; =0x625f
	movk	w14, #29817, lsl #16
	cmp	w12, w14
	mov	w12, #29541                     ; =0x7365
	ccmp	w13, w12, #0, eq
	b.eq	LBB52_33
; %bb.27:
	cmp	w11, #18
	b.ne	LBB52_30
LBB52_28:
	ldr	x11, [x10]
	ldr	w12, [x10, #8]
	mov	x13, #28022                     ; =0x6d76
	movk	x13, #26207, lsl #16
	movk	x13, #27753, lsl #32
	movk	x13, #24421, lsl #48
	cmp	x11, x13
	mov	w11, #25970                     ; =0x6572
	movk	w11, #25697, lsl #16
	ccmp	w12, w11, #0, eq
	b.ne	LBB52_30
; %bb.29:
	ldr	w11, [x10, #12]
	ldrh	w12, [x10, #16]
	mov	w13, #25183                     ; =0x625f
	movk	w13, #29817, lsl #16
	cmp	w11, w13
	mov	w11, #29541                     ; =0x7365
	ccmp	w12, w11, #0, eq
	b.eq	LBB52_33
LBB52_30:
	ldr	w8, [x8, x9, lsl #2]
	cmp	w8, #21
	b.ne	LBB52_14
; %bb.31:
	ldr	x8, [x10]
	ldur	x9, [x10, #7]
	mov	x11, #27758                     ; =0x6c6e
	movk	x11, #28511, lsl #16
	movk	x11, #24435, lsl #32
	movk	x11, #26982, lsl #48
	cmp	x8, x11
	mov	x8, #27753                      ; =0x6c69
	movk	x8, #24421, lsl #16
	movk	x8, #25970, lsl #32
	movk	x8, #25697, lsl #48
	ccmp	x9, x8, #0, eq
	b.ne	LBB52_14
; %bb.32:
	ldur	w8, [x10, #15]
	ldurh	w9, [x10, #19]
	mov	w10, #25183                     ; =0x625f
	movk	w10, #29817, lsl #16
	cmp	w8, w10
	mov	w8, #29541                      ; =0x7365
	ccmp	w9, w8, #0, eq
	b.ne	LBB52_14
LBB52_33:
	mov	w0, #2                          ; =0x2
	ret
LBB52_34:
	ldr	x11, [x10]
	ldr	w12, [x10, #8]
	mov	x13, #28022                     ; =0x6d76
	movk	x13, #26207, lsl #16
	movk	x13, #27753, lsl #32
	movk	x13, #24421, lsl #48
	cmp	x11, x13
	mov	w11, #25970                     ; =0x6572
	movk	w11, #25697, lsl #16
	ccmp	w12, w11, #0, eq
	b.eq	LBB52_37
LBB52_35:
	ldr	w8, [x8, x9, lsl #2]
	cmp	w8, #15
	b.ne	LBB52_14
; %bb.36:
	ldr	x8, [x10]
	ldur	x9, [x10, #7]
	mov	x10, #27758                     ; =0x6c6e
	movk	x10, #28511, lsl #16
	movk	x10, #24435, lsl #32
	movk	x10, #26982, lsl #48
	cmp	x8, x10
	mov	x8, #27753                      ; =0x6c69
	movk	x8, #24421, lsl #16
	movk	x8, #25970, lsl #32
	movk	x8, #25697, lsl #48
	ccmp	x9, x8, #0, eq
	b.ne	LBB52_14
LBB52_37:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function profile_supported
_profile_supported:                     ; @profile_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #226
	b.hi	LBB53_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh735:
	adrp	x9, lJTI53_0@PAGE
Lloh736:
	add	x9, x9, lJTI53_0@PAGEOFF
	adr	x10, LBB53_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB53_2:
	ret
LBB53_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh735, Lloh736
	.cfi_endproc
	.section	__TEXT,__const
lJTI53_0:
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_3-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
	.byte	(LBB53_2-LBB53_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function mp_declaration
_mp_declaration:                        ; @mp_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	str	wzr, [sp, #24]
	str	xzr, [sp, #16]
	add	x22, sp, #16
	add	x1, sp, #16
	bl	_nvm_v2_u8
	cbnz	w0, LBB54_2
; %bb.1:
	orr	x1, x22, #0x1
	mov	x0, x21
	bl	_nvm_v2_u8
	cbz	w0, LBB54_4
LBB54_2:
	mov	w0, #0                          ; =0x0
LBB54_3:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB54_4:
	add	x1, sp, #14
	mov	x0, x21
	bl	_nvm_v2_u16
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB54_3
; %bb.5:
	ldrh	w8, [sp, #14]
	cbnz	w8, LBB54_3
; %bb.6:
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB54_3
; %bb.7:
	add	x8, sp, #16
	orr	x1, x8, #0x4
	mov	x0, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB54_2
; %bb.8:
	ldrb	w9, [sp, #16]
	ldr	w8, [sp, #20]
	cmp	w9, #8
	b.ne	LBB54_12
; %bb.9:
	ldr	x9, [x20]
	ldr	x9, [x9]
	ldr	w10, [x9, #8]
	cmp	w8, w10
	b.hs	LBB54_2
; %bb.10:
	add	x9, x9, x8, lsl #2
	ldr	w9, [x9, #4120]
	cmp	w9, #1
	b.ne	LBB54_16
; %bb.11:
	mov	w8, #2                          ; =0x2
	b	LBB54_18
LBB54_12:
	cmn	w8, #1
	b.ne	LBB54_2
; %bb.13:
	cmp	w9, #7
	b.eq	LBB54_17
; %bb.14:
	cmp	w9, #4
	b.hi	LBB54_2
; %bb.15:
	mov	w8, #1                          ; =0x1
	b	LBB54_18
LBB54_16:
	add	x8, x20, x8, lsl #2
	ldr	w8, [x8, #44]
	cmn	w8, #1
	b.eq	LBB54_19
LBB54_17:
	mov	w8, #3                          ; =0x3
LBB54_18:
	str	w8, [sp, #24]
LBB54_19:
	ldr	x8, [sp, #16]
	str	x8, [x19]
	ldr	w8, [sp, #24]
	str	w8, [x19, #8]
	mov	w0, #1                          ; =0x1
	b	LBB54_3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an output for private mixed preparation."

l_.str.1:                               ; @.str.1
	.asciz	"I refuse service contracts before mixed preparation."

l_.str.2:                               ; @.str.2
	.asciz	"I require an owner and proved ordinary FLOAT-array record graph."

l_.str.3:                               ; @.str.3
	.asciz	"I require complete common structure for private mixed preparation."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate my private mixed plan."

l_.str.5:                               ; @.str.5
	.asciz	"I require exact checked mixed signature transport."

l_.str.6:                               ; @.str.6
	.asciz	"I could not retain my mixed layout transport."

l_.str.7:                               ; @.str.7
	.asciz	"I prepared mixed facts; runtime checks and admission remain unavailable."

l_.str.8:                               ; @.str.8
	.asciz	"I require an output for mixed admission."

l_.str.9:                               ; @.str.9
	.asciz	"I require the explicit mixed Samples candidate."

l_.str.10:                              ; @.str.10
	.asciz	"__init__"

l_.str.11:                              ; @.str.11
	.asciz	"I require a scalar mixed entry without initializer functions."

l_.str.12:                              ; @.str.12
	.asciz	"I admit my closed mixed runtime with exact scalar checks and owner obligations."

l_.str.13:                              ; @.str.13
	.asciz	"I require an output for private owner preparation."

l_.str.14:                              ; @.str.14
	.asciz	"I require complete common structure and metadata for owner preparation."

l_.str.15:                              ; @.str.15
	.asciz	"I could not allocate the private owner plan."

l_.str.16:                              ; @.str.16
	.asciz	"I prepared private origin, lifetime, scalar and structural facts; I grant no runtime permission."

l_.str.17:                              ; @.str.17
	.asciz	"I require an owner ARRAY admission output."

l_.str.18:                              ; @.str.18
	.asciz	"I refuse service contracts before owner ARRAY admission."

l_.str.19:                              ; @.str.19
	.asciz	"I require an exact owner ARRAY candidate."

l_.str.20:                              ; @.str.20
	.asciz	"I require bounded exact owner ARRAY parameter declarations."

l_.str.21:                              ; @.str.21
	.asciz	"I require exact owner ARRAY parameter tags and a no-argument scalar entry without initializers."

l_.str.22:                              ; @.str.22
	.asciz	"I admit exact owner ARRAY runtime authority."

l_.str.23:                              ; @.str.23
	.asciz	"I require a map declaration output."

l_.str.24:                              ; @.str.24
	.asciz	"I require private preparation inputs."

l_.str.25:                              ; @.str.25
	.asciz	"I require fresh private accounting."

l_.str.26:                              ; @.str.26
	.asciz	"I reached my fixed scratch reservation."

l_.str.27:                              ; @.str.27
	.asciz	"I require a closed ordinary module without host contracts."

l_.str.28:                              ; @.str.28
	.asciz	"I reached my private module bound."

l_.str.29:                              ; @.str.29
	.asciz	"I require consistent original module storage."

l_.str.30:                              ; @.str.30
	.asciz	"I require the original in-memory module header."

l_.str.31:                              ; @.str.31
	.asciz	"I require a bounded module entry."

l_.str.32:                              ; @.str.32
	.asciz	"I require a present counted string."

l_.str.33:                              ; @.str.33
	.asciz	"I reached my counted-string work bound."

l_.str.34:                              ; @.str.34
	.asciz	"I require terminated counted strings."

l_.str.35:                              ; @.str.35
	.asciz	"I reached my metadata work bound."

l_.str.36:                              ; @.str.36
	.asciz	"I require consistent source metadata."

l_.str.37:                              ; @.str.37
	.asciz	"I require a value-producing body for a declared result."

l_.str.38:                              ; @.str.38
	.asciz	"I reached my local bound."

l_.str.39:                              ; @.str.39
	.asciz	"I require ordinary direct-call signatures."

l_.str.40:                              ; @.str.40
	.asciz	"I require bounded original code ranges."

l_.str.41:                              ; @.str.41
	.asciz	"I reached my structural scan bound."

l_.str.42:                              ; @.str.42
	.asciz	"I reached my parameter bound."

l_.str.43:                              ; @.str.43
	.asciz	"I require ordinary parameter tags."

l_.str.44:                              ; @.str.44
	.asciz	"I require decodable original instructions."

l_.str.45:                              ; @.str.45
	.asciz	"I reached my instruction bound."

l_.str.46:                              ; @.str.46
	.asciz	"I have no ordinary union-field transfer for this opcode."

l_.str.47:                              ; @.str.47
	.asciz	"I reached my global bound."

l_.str.48:                              ; @.str.48
	.asciz	"I reached my shared structural rescan bound."

l_.str.49:                              ; @.str.49
	.asciz	"I reached my empty contract-check bound."

l_.str.50:                              ; @.str.50
	.asciz	"I reached my declaration reservation bound."

l_.str.51:                              ; @.str.51
	.asciz	"I could not allocate union structure owner."

l_.str.52:                              ; @.str.52
	.asciz	"I could not allocate union structure carrier."

l_.str.53:                              ; @.str.53
	.asciz	"I reached my decoded storage bound."

l_.str.54:                              ; @.str.54
	.asciz	"allocat"

l_.str.55:                              ; @.str.55
	.asciz	"I copied bounded structure, not executable authority."

l_.str.56:                              ; @.str.56
	.asciz	"I refuse reference lifetime and ownership instruction dataflow at %u: %s"

l_.str.57:                              ; @.str.57
	.asciz	"I require standalone ownership instruction execution semantics without linked contracts"

l_.str.58:                              ; @.str.58
	.asciz	"I require exact global declarations before owned execution"

l_.str.59:                              ; @.str.59
	.asciz	"I require explicit record/resource global transfers and lifetime"

l_.str.60:                              ; @.str.60
	.asciz	"I require a bounded acyclic value graph or my separate borrowed helper"

l_.str.61:                              ; @.str.61
	.asciz	"I require a scalar entry and exact bounded value-result helper signatures"

l_.str.62:                              ; @.str.62
	.asciz	"I require complete ownership local declarations"

l_.str.63:                              ; @.str.63
	.asciz	"I require matched collection runtime cleanup before typed-array execution"

l_.str.64:                              ; @.str.64
	.asciz	"I require value entry locals and exact borrowed or consuming value helper parameters"

l_.str.65:                              ; @.str.65
	.asciz	"I require complete owned record layouts"

l_.str.66:                              ; @.str.66
	.asciz	"I require exact scalar, retained STRING or owned-child record fields before execution"

l_.str.67:                              ; @.str.67
	.asciz	"%s"

l_.str.68:                              ; @.str.68
	.asciz	"I require explicit owned entry execution and a non-escaping scalar helper"

l_.str.69:                              ; @.str.69
	.asciz	"I require one declared stack depth per function"

l_.str.70:                              ; @.str.70
	.asciz	"I refuse service contracts before mixed execution selection"

l_.str.71:                              ; @.str.71
	.asciz	"function %u declares max_stack %u but reaches %u"

l_.str.72:                              ; @.str.72
	.asciz	"linked_count %u but linked_modules table is NULL"

l_.str.73:                              ; @.str.73
	.asciz	"I refuse linked service contracts before reviewed dispatch admission"

l_.str.74:                              ; @.str.74
	.asciz	"I refuse record-map authority in linked verification."

l_.str.75:                              ; @.str.75
	.asciz	"I refuse linked record-map execution contracts."

l_.str.76:                              ; @.str.76
	.asciz	"I refuse an owner ARRAY candidate or invalid descriptor in a linked graph"

l_.str.77:                              ; @.str.77
	.asciz	"I refuse linked owner ARRAY execution contracts"

l_.str.78:                              ; @.str.78
	.asciz	"I refuse linked mixed ownership execution contracts"

l_.str.79:                              ; @.str.79
	.asciz	"I refuse a record-array module in a linked graph."

l_.str.80:                              ; @.str.80
	.asciz	"I refuse linked record-array execution contracts."

l_.str.81:                              ; @.str.81
	.asciz	"I refuse a mixed module in a linked graph"

l_.str.82:                              ; @.str.82
	.asciz	"I refuse linked ownership execution contracts"

l_.str.83:                              ; @.str.83
	.asciz	"I do not recognize verifier profile %d"

l_.str.84:                              ; @.str.84
	.asciz	"I keep owner ARRAY candidates outside closed backend profiles"

l_.str.85:                              ; @.str.85
	.asciz	"I keep mixed ownership outside closed backend profiles"

l_.str.86:                              ; @.str.86
	.asciz	"I keep record-map authority outside unqualified backend profiles."

l_.str.87:                              ; @.str.87
	.asciz	"I keep record-array authority outside unqualified backend profiles."

l_.str.88:                              ; @.str.88
	.asciz	"I require explicit portable read-text declarations without callbacks"

l_.str.89:                              ; @.str.89
	.asciz	"I require exact portable read-text import %u"

l_.str.90:                              ; @.str.90
	.asciz	"I support only closed scalar modules without imports, nominal layouts or ownership/passive contracts"

l_.str.91:                              ; @.str.91
	.asciz	"I require an explicit executable entry point"

l_.str.92:                              ; @.str.92
	.asciz	"I require an integer/bool executable entry result"

l_.str.93:                              ; @.str.93
	.asciz	"I require a zero-argument scalar entry point"

l_.str.94:                              ; @.str.94
	.asciz	"I require a zero-argument scalar module initializer"

l_.str.95:                              ; @.str.95
	.asciz	"I require zero void results or one admitted closed-profile result and no captures in function %u"

l_.str.96:                              ; @.str.96
	.asciz	"I require explicit portable function parameter tags"

l_.str.97:                              ; @.str.97
	.asciz	"I require admitted closed-profile parameters in function %u"

l_.str.98:                              ; @.str.98
	.asciz	"I do not support opcode 0x%02x at function %u offset %u in my scalar LLVM profile"

l_.str.99:                              ; @.str.99
	.asciz	"I cannot establish mutable array eligibility (status %u) at function %u offset %u: %s"

l_.str.100:                             ; @.str.100
	.asciz	"I refuse ADD/CAST_INT/CAST_FLOAT in the literal-string profile"

l_.str.101:                             ; @.str.101
	.asciz	"I found invalid ownership declarations"

l_.str.102:                             ; @.str.102
	.asciz	"I refuse reference lifetime and ownership instruction dataflow in function[%u] at %u: %s"

l_.str.103:                             ; @.str.103
	.asciz	"I found invalid retained layout metadata"

l_.str.104:                             ; @.str.104
	.asciz	"I have no ordinary record-array transfer for this opcode."

l_.str.105:                             ; @.str.105
	.asciz	"I could not allocate private structure."

l_.str.106:                             ; @.str.106
	.asciz	"I reached my map declaration overlap bound."

l_.str.107:                             ; @.str.107
	.asciz	"module is NULL"

l_.str.108:                             ; @.str.108
	.asciz	"I require reviewed service lifetime and dispatch admission before execution"

l_.str.109:                             ; @.str.109
	.asciz	"code pointer is NULL but code_size=%u"

l_.str.110:                             ; @.str.110
	.asciz	"entry_point %u >= function_count %u"

l_.str.111:                             ; @.str.111
	.asciz	"function[%u] code_offset %u > code_size %u"

l_.str.112:                             ; @.str.112
	.asciz	"function[%u] code range exceeds code_size: offset %u, length %u, code_size %u"

l_.str.113:                             ; @.str.113
	.asciz	"function[%u] name_idx %u >= string_count %u"

l_.str.114:                             ; @.str.114
	.asciz	"function[%u] result_tag %u is invalid"

l_.str.115:                             ; @.str.115
	.asciz	"I found an invalid parameter tag in function[%u] parameter[%u]"

l_.str.116:                             ; @.str.116
	.asciz	"function[%u] result signature must be void/0 or non-void/nonzero"

l_.str.117:                             ; @.str.117
	.asciz	"function[%u] local_count %u is smaller than arity %u"

l_.str.118:                             ; @.str.118
	.asciz	"I require a body for function[%u] with %u declared result(s)."

l_.str.119:                             ; @.str.119
	.asciz	"function[%u] code range overlaps function[%u]"

l_.str.120:                             ; @.str.120
	.asciz	"I found invalid passive eligibility metadata"

l_.str.121:                             ; @.str.121
	.asciz	"I found an invalid retained callback import contract"

l_.str.122:                             ; @.str.122
	.asciz	"import[%u] module_name_idx %u >= string_count %u"

l_.str.123:                             ; @.str.123
	.asciz	"import[%u] function_name_idx %u >= string_count %u"

l_.str.124:                             ; @.str.124
	.asciz	"import[%u] has unknown kind %u"

l_.str.125:                             ; @.str.125
	.asciz	"import[%u] artifact path must be absolute and contain no NUL"

l_.str.126:                             ; @.str.126
	.asciz	"import[%u] return_type %u is not a valid value tag"

l_.str.127:                             ; @.str.127
	.asciz	"import[%u] param_count %u exceeds the foreign-call argument limit of %u"

l_.str.128:                             ; @.str.128
	.asciz	"import[%u] declares %u params but has no param type array"

l_.str.129:                             ; @.str.129
	.asciz	"import[%u] param[%u] type %u is not a valid value tag"

l_.str.130:                             ; @.str.130
	.asciz	"I reached my private operand-check work bound."

l_.str.131:                             ; @.str.131
	.asciz	"function[%u] unknown opcode 0x%02x at offset %u"

l_.str.132:                             ; @.str.132
	.asciz	"I refuse reference lifetime and ownership instruction dataflow: %s"

l_.str.133:                             ; @.str.133
	.asciz	"I require owned-transfer execution semantics before execution"

l_.str.134:                             ; @.str.134
	.asciz	"function[%u] jump at offset %u targets %ld (not an instruction boundary)"

l_.str.135:                             ; @.str.135
	.asciz	"I require valid handler names and parameter slots."

l_.str.136:                             ; @.str.136
	.asciz	"I require an executable handler arm."

l_.str.137:                             ; @.str.137
	.asciz	"I require a valid effect operation name."

l_.str.138:                             ; @.str.138
	.asciz	"function[%u] match_tag at offset %u targets %ld (not an instruction boundary)"

l_.str.139:                             ; @.str.139
	.asciz	"function[%u] %s at offset %u: fn_idx %u >= function_count %u"

l_.str.140:                             ; @.str.140
	.asciz	"function[%u] OP_TAIL_CALL at offset %u has incompatible result signature"

l_.str.141:                             ; @.str.141
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: module_idx %u >= linked_count %u"

l_.str.142:                             ; @.str.142
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: linked module %u is unresolved"

l_.str.143:                             ; @.str.143
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: fn_idx %u >= linked function_count %u"

l_.str.144:                             ; @.str.144
	.asciz	"function[%u] OP_CALL_MODULE at offset %u declares arity %u but linked callee takes %u"

l_.str.145:                             ; @.str.145
	.asciz	"function[%u] OP_CALL_MODULE at offset %u declares %u results but linked callee returns %u"

l_.str.146:                             ; @.str.146
	.asciz	"function[%u] OP_CLOSURE_NEW at offset %u: fn_idx %u >= function_count %u"

l_.str.147:                             ; @.str.147
	.asciz	"function[%u] OP_CLOSURE_NEW at offset %u: capture_count %u does not match upvalue_count %u"

l_.str.148:                             ; @.str.148
	.asciz	"function[%u] OP_FUNCREF at offset %u: fn_idx %u >= function_count %u"

l_.str.149:                             ; @.str.149
	.asciz	"function[%u] OP_PUSH_STR at offset %u: str_idx %u >= string_count %u"

l_.str.150:                             ; @.str.150
	.asciz	"function[%u] OP_CALL_EXTERN at offset %u: import_idx %u >= import_count %u"

l_.str.151:                             ; @.str.151
	.asciz	"function[%u] %s at offset %u: global index %u >= limit %u"

l_.str.152:                             ; @.str.152
	.asciz	"function[%u] %s at offset %u: slot %u >= local_count %u"

l_.str.153:                             ; @.str.153
	.asciz	"function[%u] %s at offset %u: upvalue depth must be zero"

l_.str.154:                             ; @.str.154
	.asciz	"function[%u] %s at offset %u: upvalue index %u >= upvalue_count %u"

l_.str.155:                             ; @.str.155
	.asciz	"function[%u] %s at offset %u: struct def_idx %u >= struct_count %u"

l_.str.156:                             ; @.str.156
	.asciz	"function[%u] %s at offset %u: enum def_idx %u >= enum_count %u"

l_.str.157:                             ; @.str.157
	.asciz	"function[%u] %s at offset %u: union def_idx %u >= union_count %u"

l_.str.158:                             ; @.str.158
	.asciz	"function[%u] AGG_PACK at offset %u: invalid kind %u"

l_.str.159:                             ; @.str.159
	.asciz	"function[%u] AGG_PACK record layout %u >= struct_count %u"

l_.str.160:                             ; @.str.160
	.asciz	"function[%u] AGG_PACK variant layout %u >= union_count %u"

l_.str.161:                             ; @.str.161
	.asciz	"function[%u] %s at offset %u: type tag %u >= TAG_COUNT %u"

l_.str.162:                             ; @.str.162
	.asciz	"function[%u] OP_HM_NEW at offset %u: key tag %u >= TAG_COUNT %u"

l_.str.163:                             ; @.str.163
	.asciz	"function[%u] OP_HM_NEW at offset %u: value tag %u >= TAG_COUNT %u"

l_.str.164:                             ; @.str.164
	.asciz	"function[%u] OP_ARR_LITERAL at offset %u: element tag %u >= TAG_COUNT %u"

l_.str.165:                             ; @.str.165
	.asciz	"function[%u] opcode 0x%02x at offset %u is outside the primary plane"

l_.str.166:                             ; @.str.166
	.asciz	"I reached my private stack-check budget."

l_.str.167:                             ; @.str.167
	.asciz	"I reached my private stack bound."

l_.str.168:                             ; @.str.168
	.asciz	"function[%u] could not allocate stack verifier state"

l_.str.169:                             ; @.str.169
	.asciz	"function[%u] %s at offset %u has no known stack effect"

l_.str.170:                             ; @.str.170
	.asciz	"function[%u] returns with %d values at offset %u but declares %u"

l_.str.171:                             ; @.str.171
	.asciz	"I cannot install a nonlocal-return handler across outstanding explicit retains."

l_.str.172:                             ; @.str.172
	.asciz	"I require one result and balanced ownership when resuming an effect."

l_.str.173:                             ; @.str.173
	.asciz	"function[%u] stack underflow at offset %u (%s needs %d, has %d)"

l_.str.174:                             ; @.str.174
	.asciz	"function[%u] releases a reference it does not hold at offset %u"

l_.str.175:                             ; @.str.175
	.asciz	"function[%u] returns at offset %u still holding %d retained reference(s)"

l_.str.176:                             ; @.str.176
	.asciz	"function[%u] branch at offset %u targets %u, which is not an instruction boundary in this function"

l_.str.177:                             ; @.str.177
	.asciz	"function[%u] reaches its end after offset %u still holding %d retained reference(s)"

l_.str.178:                             ; @.str.178
	.asciz	"function[%u] reaches its end after offset %u with %d values but declares %u"

l_.str.179:                             ; @.str.179
	.asciz	"function[%u] incompatible ownership balance at offset %u (%d and %d)"

l_.str.180:                             ; @.str.180
	.asciz	"function[%u] incompatible stack heights at offset %u (%d and %d)"

l_.str.181:                             ; @.str.181
	.asciz	"function[%u] frame needs %u slots (%u locals + operand depth %d), more than a frame can address"

l_.str.182:                             ; @.str.182
	.asciz	"function[%u] maximum operand depth %d exceeds %u"

l_.str.185:                             ; @.str.185
	.asciz	"function index %u >= function_count %u"

l_.str.186:                             ; @.str.186
	.asciz	"I refuse record-map admission: %s"

l_.str.187:                             ; @.str.187
	.asciz	"I require an existing record-map function."

l_.str.188:                             ; @.str.188
	.asciz	"I require complete record-map function facts."

l_.str.189:                             ; @.str.189
	.asciz	"I refuse record-array admission: %s"

l_.str.190:                             ; @.str.190
	.asciz	"I require an existing record-array function."

l_.str.191:                             ; @.str.191
	.asciz	"I require complete record-array function facts."

l_.str.192:                             ; @.str.192
	.asciz	"I refuse owner ARRAY admission (status %u) at function %u offset %u: %s"

l_.str.193:                             ; @.str.193
	.asciz	"I require an existing owner ARRAY function index"

l_.str.194:                             ; @.str.194
	.asciz	"I refuse mixed admission (status %u) at function %u offset %u: %s"

l_.str.195:                             ; @.str.195
	.asciz	"I require an existing mixed function index"

l_.str.196:                             ; @.str.196
	.asciz	"file_read"

l_.str.197:                             ; @.str.197
	.asciz	"vm_file_read"

l_.str.198:                             ; @.str.198
	.asciz	"nl_os_file_read"

l_.str.199:                             ; @.str.199
	.asciz	"_bytes"

.subsections_via_symbols
