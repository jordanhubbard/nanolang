	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_websocket_execute_indirect_bytes
lCPI0_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_websocket_execute_indirect_bytes
	.p2align	2
_nvm_websocket_execute_indirect_bytes:  ; @nvm_websocket_execute_indirect_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1424
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	mov	x19, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w1, #1                          ; =0x1
	mov	w2, #3                          ; =0x3
	bl	_nvm_websocket_host_enter
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w0, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w0, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w0, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w8, #4                          ; =0x4
	b	LBB0_10
LBB0_5:
	cbz	w0, LBB0_16
; %bb.6:
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB0_10
LBB0_7:
	mov	w8, #2                          ; =0x2
	b	LBB0_10
LBB0_8:
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	str	q0, [x19, #32]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #11                         ; =0xb
	b	LBB0_13
LBB0_9:
	mov	w8, #5                          ; =0x5
LBB0_10:
	mov	x9, #0                          ; =0x0
	str	xzr, [x19, #144]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	mov	w10, #1                         ; =0x1
	str	w10, [x19]
	cbz	x21, LBB0_13
; %bb.11:
	cmp	w0, #5
	b.eq	LBB0_13
; %bb.12:
	ldr	x9, [x21, #8]
LBB0_13:
	str	x9, [x19, #128]
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	stur	q0, [x19, #108]
	str	wzr, [x19, #124]
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
LBB0_14:
	ldur	x8, [x29, #-104]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_373
; %bb.15:
	add	sp, sp, #1424
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_16:
	add	x26, sp, #160
	cbz	x21, LBB0_25
; %bb.17:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB0_27
; %bb.18:
	ldr	x8, [x21, #8]
	cbz	x20, LBB0_26
; %bb.19:
	mov	w9, #16961                      ; =0x4241
	movk	w9, #15, lsl #16
	cmp	x8, x9
	b.hs	LBB0_26
; %bb.20:
	ldr	q0, [x21]
	str	q0, [x26]
	str	xzr, [sp, #144]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	add	x1, sp, #24
	mov	x0, x24
	bl	_nvm_websocket_host_policy
	cmp	w0, #1
	b.le	LBB0_30
; %bb.21:
	cmp	w0, #5
	b.eq	LBB0_33
; %bb.22:
	cmp	w0, #3
	b.eq	LBB0_34
; %bb.23:
	cmp	w0, #2
	b.ne	LBB0_32
; %bb.24:
	mov	w0, #4                          ; =0x4
	b	LBB0_35
LBB0_25:
	mov	x8, #0                          ; =0x0
LBB0_26:
	stp	xzr, xzr, [sp, #384]
	b	LBB0_28
LBB0_27:
	stp	xzr, xzr, [sp, #384]
	ldr	x8, [x21, #8]
LBB0_28:
Lloh6:
	adrp	x9, lCPI0_0@PAGE
Lloh7:
	ldr	d0, [x9, lCPI0_0@PAGEOFF]
	str	d0, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	stur	q0, [x19, #108]
	str	wzr, [x19, #124]
	str	x8, [x19, #128]
	ldr	q0, [x26, #224]
	stur	q0, [x19, #136]
LBB0_29:
	bl	_nvm_websocket_host_leave
	b	LBB0_14
LBB0_30:
	cbz	w0, LBB0_36
; %bb.31:
	cmp	w0, #1
	b.eq	LBB0_35
LBB0_32:
	mov	w0, #2                          ; =0x2
	b	LBB0_35
LBB0_33:
	mov	w0, #11                         ; =0xb
	b	LBB0_35
LBB0_34:
	mov	w0, #5                          ; =0x5
LBB0_35:
	movi.2d	v0, #0000000000000000
	mov.d	v0[1], v0[0]
	stur	q0, [x19, #136]
	ldr	x8, [sp, #168]
Lloh8:
	adrp	x9, lCPI0_0@PAGE
Lloh9:
	ldr	d0, [x9, lCPI0_0@PAGEOFF]
	str	d0, [x19]
	str	w0, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	stur	q0, [x19, #108]
	str	wzr, [x19, #124]
	str	x8, [x19, #128]
	b	LBB0_29
LBB0_36:
	str	xzr, [sp, #288]
	add	x3, sp, #160
	add	x4, sp, #288
	mov	x0, x23
	mov	x1, x22
	mov	w2, #0                          ; =0x0
	bl	_nvm_websocket_runtime_indirect_create
	cbz	w0, LBB0_38
; %bb.37:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #336]
	stp	q0, q0, [x26, #224]
	stp	q0, q0, [x26, #304]
	stp	q0, q0, [x26, #272]
	str	q0, [x26, #256]
	ldr	x8, [sp, #168]
	str	xzr, [sp, #528]
	str	x8, [sp, #512]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #384]
	str	w0, [sp, #392]
	b	LBB0_146
LBB0_38:
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_indirect_plan
	mov	x21, x0
	add	x1, sp, #1000
	bl	_nvm_websocket_indirect_hosted_startup
	cbz	w0, LBB0_145
; %bb.39:
	ldrb	w8, [sp, #1088]
	tbnz	w8, #0, LBB0_145
; %bb.40:
	ldr	w8, [sp, #1012]
	cbz	w8, LBB0_143
; %bb.41:
	mov	w22, #0                         ; =0x0
	mov	w25, #415                       ; =0x19f
	mov	w27, #151                       ; =0x97
LBB0_42:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_46 Depth 2
                                        ;       Child Loop BB0_54 Depth 3
                                        ;         Child Loop BB0_86 Depth 4
                                        ;         Child Loop BB0_125 Depth 4
	add	x2, sp, #184
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_function
	cbz	w0, LBB0_145
; %bb.43:                               ;   in Loop: Header=BB0_42 Depth=1
	ldrb	w8, [sp, #264]
	cbnz	w8, LBB0_145
; %bb.44:                               ;   in Loop: Header=BB0_42 Depth=1
	ldrh	w8, [sp, #192]
	cbz	w8, LBB0_142
; %bb.45:                               ;   in Loop: Header=BB0_42 Depth=1
	mov	w28, #0                         ; =0x0
LBB0_46:                                ;   Parent Loop BB0_42 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_54 Depth 3
                                        ;         Child Loop BB0_86 Depth 4
                                        ;         Child Loop BB0_125 Depth 4
	and	w2, w28, #0xffff
	add	x3, sp, #384
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_instruction
	cbz	w0, LBB0_145
; %bb.47:                               ;   in Loop: Header=BB0_46 Depth=2
	ldrb	w0, [sp, #392]
	bl	_fcd_supported
	ldrb	w8, [sp, #460]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_145
; %bb.48:                               ;   in Loop: Header=BB0_46 Depth=2
	and	w2, w28, #0xffff
	add	x3, sp, #1108
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_variant_count
	cbz	w0, LBB0_145
; %bb.49:                               ;   in Loop: Header=BB0_46 Depth=2
	ldrb	w8, [sp, #1108]
	cmp	w8, #16
	b.hi	LBB0_145
; %bb.50:                               ;   in Loop: Header=BB0_46 Depth=2
	tst	w28, #0xffff
	b.ne	LBB0_52
; %bb.51:                               ;   in Loop: Header=BB0_46 Depth=2
	cbz	w8, LBB0_145
LBB0_52:                                ;   in Loop: Header=BB0_46 Depth=2
	cbz	w8, LBB0_141
; %bb.53:                               ;   in Loop: Header=BB0_46 Depth=2
	mov	w24, #0                         ; =0x0
LBB0_54:                                ;   Parent Loop BB0_42 Depth=1
                                        ;     Parent Loop BB0_46 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_86 Depth 4
                                        ;         Child Loop BB0_125 Depth 4
	and	w2, w28, #0xffff
	and	w3, w24, #0xff
	add	x4, sp, #1192
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_variant
	cbz	w0, LBB0_145
; %bb.55:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1212]
	tbz	w8, #0, LBB0_145
; %bb.56:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w23, [sp, #392]
	mov	x0, x23
	bl	_fcd_supported
	cbz	w0, LBB0_145
; %bb.57:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w23, #147
	b.gt	LBB0_61
; %bb.58:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #60
	b.gt	LBB0_89
; %bb.59:                               ;   in Loop: Header=BB0_54 Depth=3
	sub	w9, w23, #59
	cmp	w9, #2
	b.lo	LBB0_63
; %bb.60:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #15
	b.eq	LBB0_63
	b	LBB0_64
LBB0_61:                                ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #150
	b.le	LBB0_92
; %bb.62:                               ;   in Loop: Header=BB0_54 Depth=3
	sub	w9, w23, #151
	cmp	w9, #2
	b.hs	LBB0_137
LBB0_63:                                ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #5                          ; =0x5
LBB0_64:                                ;   in Loop: Header=BB0_54 Depth=3
	ldr	w9, [sp, #1224]
	cmp	w9, w8
	b.ne	LBB0_145
; %bb.65:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1214]
	cmp	w23, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.66:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1213]
	cmp	w23, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.67:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #1                          ; =0x1
	sub	w9, w23, #59
	cmp	w9, #2
	b.lo	LBB0_70
; %bb.68:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #152
	b.eq	LBB0_70
; %bb.69:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #15
	ccmp	w23, w27, #4, ne
	cset	w8, eq
LBB0_70:                                ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #145
	ldrb	w9, [sp, #1215]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_145
; %bb.71:                               ;   in Loop: Header=BB0_54 Depth=3
	cbz	w8, LBB0_88
; %bb.72:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1240]
	ldr	w9, [sp, #384]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.73:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #-1                         ; =0xffffffff
	cmp	w23, #60
	b.eq	LBB0_76
; %bb.74:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #152
	b.eq	LBB0_76
; %bb.75:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #400]
LBB0_76:                                ;   in Loop: Header=BB0_54 Depth=3
	ldr	w9, [sp, #1244]
	cmp	w9, w8
	b.ne	LBB0_145
; %bb.77:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #145
	cset	w8, ne
	ldr	w9, [sp, #1236]
	cmp	w9, w8
	b.ne	LBB0_145
; %bb.78:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #145
	b.ne	LBB0_95
; %bb.79:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w23, [sp, #976]
	add	x2, sp, #296
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_websocket_indirect_hosted_import
	cbz	w0, LBB0_145
; %bb.80:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #296]
	ldr	w9, [sp, #1244]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.81:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	x0, x23
	bl	_nl_websocket_catalog_method
	cbz	x0, LBB0_145
; %bb.82:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1252]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.83:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1256]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.84:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [x0, #44]
	cmp	w8, #1
	mov	w8, #399                        ; =0x18f
	csel	w8, w25, w8, eq
	ldr	x10, [x0, #56]
	cmp	x10, #2
	b.lo	LBB0_87
; %bb.85:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	x9, [x0, #48]
	add	x9, x9, #40
	sub	x10, x10, #1
LBB0_86:                                ;   Parent Loop BB0_42 Depth=1
                                        ;     Parent Loop BB0_46 Depth=2
                                        ;       Parent Loop BB0_54 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w11, [x9], #48
	orr	w12, w8, #0x20
	cmp	w11, #1
	csel	w8, w12, w8, eq
	orr	w12, w8, #0x400
	cmp	w11, #5
	csel	w8, w12, w8, eq
	subs	x10, x10, #1
	b.ne	LBB0_86
LBB0_87:                                ;   in Loop: Header=BB0_54 Depth=3
	mov	w9, #0                          ; =0x0
	b	LBB0_96
LBB0_88:                                ;   in Loop: Header=BB0_54 Depth=3
	mov	w9, #0                          ; =0x0
	mov	w8, #128                        ; =0x80
	b	LBB0_97
LBB0_89:                                ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #61
	b.eq	LBB0_139
; %bb.90:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #145
	b.ne	LBB0_64
; %bb.91:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_64
LBB0_92:                                ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #148
	b.eq	LBB0_140
; %bb.93:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #149
	b.ne	LBB0_64
; %bb.94:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_64
LBB0_95:                                ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #448                        ; =0x1c0
	mov	w9, #64                         ; =0x40
LBB0_96:                                ;   in Loop: Header=BB0_54 Depth=3
	ldr	w10, [sp, #1248]
	cmp	w10, w8
	b.ne	LBB0_145
LBB0_97:                                ;   in Loop: Header=BB0_54 Depth=3
	ldr	w10, [sp, #1228]
	cmp	w10, w9
	b.ne	LBB0_145
; %bb.98:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w10, [sp, #1232]
	bic	w8, w8, w9
	cmp	w10, w8
	b.ne	LBB0_145
; %bb.99:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrh	w8, [sp, #1216]
	ldrh	w9, [sp, #1194]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.100:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrh	w8, [sp, #1218]
	ldrh	w9, [sp, #1204]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.101:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1292]
	ldrb	w9, [sp, #460]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_145
; %bb.102:                              ;   in Loop: Header=BB0_54 Depth=3
	tbnz	w8, #0, LBB0_104
; %bb.103:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w9, [sp, #1293]
	cmp	w9, #255
	b.eq	LBB0_109
	b	LBB0_145
LBB0_104:                               ;   in Loop: Header=BB0_54 Depth=3
	cbz	w9, LBB0_145
; %bb.105:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrh	w2, [sp, #456]
	ldrh	w8, [sp, #192]
	cmp	w2, w8
	b.hs	LBB0_145
; %bb.106:                              ;   in Loop: Header=BB0_54 Depth=3
	add	x3, sp, #296
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_variant_count
	cbz	w0, LBB0_145
; %bb.107:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1293]
	ldrb	w9, [sp, #296]
	cmp	w8, w9
	b.hs	LBB0_145
; %bb.108:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1292]
LBB0_109:                               ;   in Loop: Header=BB0_54 Depth=3
	tbnz	w8, #1, LBB0_111
; %bb.110:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1294]
	cmp	w8, #255
	b.eq	LBB0_115
	b	LBB0_145
LBB0_111:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #460]
	cmp	w8, #2
	b.lo	LBB0_145
; %bb.112:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrh	w2, [sp, #458]
	ldrh	w8, [sp, #192]
	cmp	w2, w8
	b.hs	LBB0_145
; %bb.113:                              ;   in Loop: Header=BB0_54 Depth=3
	add	x3, sp, #296
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_variant_count
	cbz	w0, LBB0_145
; %bb.114:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #1294]
	ldrb	w9, [sp, #296]
	cmp	w8, w9
	b.hs	LBB0_145
LBB0_115:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #392]
	cmp	w8, #152
	b.eq	LBB0_117
; %bb.116:                              ;   in Loop: Header=BB0_54 Depth=3
	cmp	w8, #60
	b.ne	LBB0_131
LBB0_117:                               ;   in Loop: Header=BB0_54 Depth=3
	and	w2, w28, #0xffff
	and	w3, w24, #0xff
	add	x4, sp, #1112
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_call
	cbz	w0, LBB0_145
; %bb.118:                              ;   in Loop: Header=BB0_54 Depth=3
	ldr	x8, [sp, #1120]
	cbz	x8, LBB0_145
; %bb.119:                              ;   in Loop: Header=BB0_54 Depth=3
	ldr	x9, [sp, #1128]
	cmp	x8, x9
	b.ne	LBB0_145
; %bb.120:                              ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1112]
	cmp	w8, w22
	b.ne	LBB0_145
; %bb.121:                              ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1116]
	ldr	w9, [sp, #384]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.122:                              ;   in Loop: Header=BB0_54 Depth=3
	ldr	w8, [sp, #1144]
	cmn	w8, #1
	b.ne	LBB0_145
; %bb.123:                              ;   in Loop: Header=BB0_54 Depth=3
	mov	x23, #0                         ; =0x0
	b	LBB0_125
LBB0_124:                               ;   in Loop: Header=BB0_125 Depth=4
	add	x23, x23, #1
	cmp	x23, #64
	b.eq	LBB0_130
LBB0_125:                               ;   Parent Loop BB0_42 Depth=1
                                        ;     Parent Loop BB0_46 Depth=2
                                        ;       Parent Loop BB0_54 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x8, [sp, #1120]
	lsr	x8, x8, x23
	tbz	w8, #0, LBB0_124
; %bb.126:                              ;   in Loop: Header=BB0_125 Depth=4
	add	x2, sp, #296
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_websocket_indirect_hosted_function
	cbz	w0, LBB0_145
; %bb.127:                              ;   in Loop: Header=BB0_125 Depth=4
	ldrb	w8, [sp, #376]
	cbnz	w8, LBB0_145
; %bb.128:                              ;   in Loop: Header=BB0_125 Depth=4
	ldrh	w8, [sp, #308]
	ldrh	w9, [sp, #1160]
	cmp	w8, w9
	b.ne	LBB0_145
; %bb.129:                              ;   in Loop: Header=BB0_125 Depth=4
	ldrb	w8, [sp, #312]
	ldrb	w9, [sp, #1166]
	cmp	w8, w9
	b.eq	LBB0_124
	b	LBB0_145
LBB0_130:                               ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #392]
LBB0_131:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w8, #15
	b.eq	LBB0_134
; %bb.132:                              ;   in Loop: Header=BB0_54 Depth=3
	cmp	w8, #151
	b.eq	LBB0_134
; %bb.133:                              ;   in Loop: Header=BB0_54 Depth=3
	cmp	w8, #59
	b.ne	LBB0_136
LBB0_134:                               ;   in Loop: Header=BB0_54 Depth=3
	ldr	w1, [sp, #400]
	add	x2, sp, #296
	mov	x0, x21
	bl	_nvm_websocket_indirect_hosted_function
	cbz	w0, LBB0_145
; %bb.135:                              ;   in Loop: Header=BB0_54 Depth=3
	ldrb	w8, [sp, #376]
	cbnz	w8, LBB0_145
LBB0_136:                               ;   in Loop: Header=BB0_54 Depth=3
	add	w24, w24, #1
	ldrb	w8, [sp, #1108]
	cmp	w8, w24, uxtb
	b.hi	LBB0_54
	b	LBB0_141
LBB0_137:                               ;   in Loop: Header=BB0_54 Depth=3
	cmp	w23, #161
	b.ne	LBB0_64
; %bb.138:                              ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_64
LBB0_139:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #4                          ; =0x4
	b	LBB0_64
LBB0_140:                               ;   in Loop: Header=BB0_54 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_64
LBB0_141:                               ;   in Loop: Header=BB0_46 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #192]
	cmp	w8, w28, uxth
	b.hi	LBB0_46
LBB0_142:                               ;   in Loop: Header=BB0_42 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #1012]
	cmp	w22, w8
	b.lo	LBB0_42
LBB0_143:
	ldr	x0, [sp, #288]
	add	x1, sp, #24
	bl	_nvm_websocket_runtime_policy
	cbz	w0, LBB0_165
; %bb.144:
	mov	x22, x0
	add	x8, sp, #384
	add	x0, sp, #288
	mov	x1, #0                          ; =0x0
	bl	_nvm_websocket_runtime_indirect_destroy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #336]
	stp	q0, q0, [x26, #224]
	stp	q0, q0, [x26, #256]
	stp	q0, q0, [x26, #288]
	str	q0, [x26, #320]
	ldr	x8, [sp, #168]
	str	xzr, [sp, #528]
	str	x8, [sp, #512]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #384]
	str	w22, [sp, #392]
	b	LBB0_146
LBB0_145:
	add	x8, sp, #384
	add	x0, sp, #288
	mov	x1, #0                          ; =0x0
	bl	_nvm_websocket_runtime_indirect_destroy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #336]
	stp	q0, q0, [x26, #224]
	stp	q0, q0, [x26, #256]
	stp	q0, q0, [x26, #288]
	str	q0, [x26, #320]
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #168]
	str	xzr, [sp, #528]
	str	x9, [sp, #512]
	mov	w9, #2                          ; =0x2
	str	w8, [sp, #384]
	str	w9, [sp, #392]
LBB0_146:
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x26, #244]
LBB0_147:
	ldp	q0, q1, [x26, #320]
	stp	q0, q1, [x19, #96]
	ldr	q0, [x26, #352]
	str	q0, [x19, #128]
	ldr	x8, [sp, #528]
	str	x8, [x19, #144]
	ldp	q0, q1, [x26, #256]
	stp	q0, q1, [x19, #32]
	ldp	q0, q1, [x26, #288]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [x26, #224]
	stp	q0, q1, [x19]
	ldr	w8, [x19, #8]
	cbnz	w8, LBB0_164
; %bb.148:
	ldrb	w8, [x19, #12]
	tbz	w8, #0, LBB0_163
; %bb.149:
	ldr	w9, [x19, #16]
	mov	w8, #10                         ; =0xa
	cbnz	w9, LBB0_164
; %bb.150:
	ldr	w9, [x19, #32]
	cbnz	w9, LBB0_164
; %bb.151:
	ldr	x9, [x19, #40]
	cbnz	x9, LBB0_164
; %bb.152:
	ldrb	w9, [sp, #48]
	mov	w8, #6                          ; =0x6
	tbz	w9, #0, LBB0_164
; %bb.153:
	ldrb	w9, [sp, #49]
	tbnz	w9, #0, LBB0_164
; %bb.154:
	ldrb	w9, [sp, #50]
	tbnz	w9, #0, LBB0_164
; %bb.155:
	ldrb	w9, [sp, #53]
	cbnz	w9, LBB0_164
; %bb.156:
	ldr	w9, [sp, #64]
	cbnz	w9, LBB0_164
; %bb.157:
	ldr	w9, [sp, #56]
	cmn	w9, #1
	b.ne	LBB0_164
; %bb.158:
	ldr	w9, [sp, #60]
	cmn	w9, #1
	b.ne	LBB0_164
; %bb.159:
	ldrb	w9, [sp, #72]
	cmp	w9, #1
	b.ne	LBB0_164
; %bb.160:
	ldrb	w9, [sp, #52]
	cmp	w9, #4
	b.eq	LBB0_170
; %bb.161:
	cmp	w9, #1
	b.ne	LBB0_164
; %bb.162:
	ldr	x10, [sp, #80]
	b	LBB0_171
LBB0_163:
	mov	w8, #5                          ; =0x5
LBB0_164:
	ldurh	w9, [x19, #13]
	strh	w9, [sp, #1000]
	ldurb	w9, [x19, #15]
	strb	w9, [sp, #1002]
	ldur	x9, [x19, #20]
	str	x9, [sp, #1192]
	ldur	w9, [x19, #28]
	str	w9, [sp, #1200]
	ldp	q0, q1, [x19, #80]
	stp	q0, q1, [x26, #256]
	ldur	q0, [x19, #112]
	str	q0, [x26, #288]
	ldp	q1, q0, [x19, #48]
	stp	q1, q0, [x26, #224]
	str	w8, [x19, #8]
	ldrb	w8, [sp, #1002]
	sturb	w8, [x19, #15]
	ldrh	w8, [sp, #1000]
	sturh	w8, [x19, #13]
	mov	w8, w9
	stur	w8, [x19, #28]
	ldr	x8, [sp, #1192]
	stur	x8, [x19, #20]
	ldp	q0, q1, [x26, #272]
	stp	q0, q1, [x19, #96]
	ldp	q1, q2, [x26, #240]
	stp	q1, q2, [x19, #64]
	ldr	q0, [x26, #224]
	stur	q0, [x19, #48]
	b	LBB0_29
LBB0_165:
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_begin
	cbnz	w0, LBB0_167
; %bb.166:
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_frame_start
	cbz	w0, LBB0_172
LBB0_167:
	mov	x1, x0
LBB0_168:
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_fail
LBB0_169:
	add	x8, sp, #384
	add	x0, sp, #288
	add	x1, sp, #48
	bl	_nvm_websocket_runtime_indirect_destroy
	b	LBB0_147
LBB0_170:
	ldr	x10, [sp, #80]
	cmp	x10, #1
	b.hi	LBB0_164
LBB0_171:
	mov	w8, #0                          ; =0x0
	strb	w9, [x20]
	stur	wzr, [x20, #1]
	str	wzr, [x20, #4]
	str	x10, [x20, #8]
	b	LBB0_164
LBB0_172:
	mov	w25, #-1                        ; =0xffffffff
	b	LBB0_174
LBB0_173:                               ;   in Loop: Header=BB0_174 Depth=1
	cbnz	w1, LBB0_168
LBB0_174:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_276 Depth 2
                                        ;     Child Loop BB0_250 Depth 2
	ldr	x0, [sp, #288]
	add	x1, sp, #296
	bl	_nvm_websocket_runtime_indirect_frame_view
	cbz	w0, LBB0_372
; %bb.175:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #349]
	tbnz	w8, #0, LBB0_372
; %bb.176:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #300]
	cbnz	w8, LBB0_372
; %bb.177:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #304]
	ldrh	w2, [sp, #308]
	add	x3, sp, #384
	mov	x0, x21
	bl	_nvm_websocket_indirect_hosted_instruction
	cbz	w0, LBB0_372
; %bb.178:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #304]
	ldrh	w2, [sp, #308]
	ldrb	w3, [sp, #348]
	add	x4, sp, #184
	mov	x0, x21
	bl	_nvm_websocket_indirect_hosted_variant
	cbz	w0, LBB0_372
; %bb.179:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #204]
	tbz	w8, #0, LBB0_372
; %bb.180:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w8, [sp, #186]
	ldr	w9, [sp, #336]
	cmp	w9, w8
	b.ne	LBB0_372
; %bb.181:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_indirect_enter
	cbnz	w0, LBB0_167
; %bb.182:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	w23, #0                         ; =0x0
	ldr	x24, [sp, #288]
	ldr	w28, [sp, #336]
	ldrb	w9, [sp, #392]
	str	w25, [sp, #1108]
	str	w25, [sp, #1104]
	mov	w8, #2                          ; =0x2
	cmp	w9, #255
	b.eq	LBB0_294
; %bb.183:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x22, x9
Lloh10:
	adrp	x12, lJTI0_0@PAGE
Lloh11:
	add	x12, x12, lJTI0_0@PAGEOFF
	adr	x10, LBB0_184
	ldrh	w11, [x12, x9, lsl #1]
	add	x10, x10, x11, lsl #2
	br	x10
LBB0_184:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_call
	b	LBB0_316
LBB0_185:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	w28, LBB0_314
; %bb.186:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	tbz	w0, #0, LBB0_314
; %bb.187:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w22, #252
	b.eq	LBB0_189
; %bb.188:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w22, #106
	b.ne	LBB0_295
LBB0_189:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	ldrh	w2, [sp, #400]
	mov	x0, x24
	mov	x3, x1
	bl	_nvm_websocket_runtime_project
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_190:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	w28, LBB0_314
; %bb.191:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.192:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1000
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	tbz	w0, #0, LBB0_314
; %bb.193:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1000]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.194:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1001]
	tbnz	w8, #0, LBB0_336
; %bb.195:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1002]
	tbnz	w8, #0, LBB0_336
; %bb.196:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1005]
	cbnz	w8, LBB0_336
; %bb.197:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1016]
	cbnz	w8, LBB0_336
; %bb.198:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1004]
	cmp	w8, #4
	b.ne	LBB0_336
; %bb.199:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1008]
	cmn	w8, #1
	b.ne	LBB0_336
; %bb.200:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1012]
	cmn	w8, #1
	b.ne	LBB0_336
; %bb.201:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1024]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.202:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x8, [sp, #1032]
	cmp	x8, #2
	b.hs	LBB0_336
; %bb.203:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	mov	x0, x24
	bl	_nvm_websocket_runtime_drop
	cbnz	w0, LBB0_167
; %bb.204:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x8, [sp, #1032]
	cmp	w22, #161
	b.ne	LBB0_324
; %bb.205:                              ;   in Loop: Header=BB0_174 Depth=1
	cbnz	x8, LBB0_310
; %bb.206:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	mov	w1, #9                          ; =0x9
	b	LBB0_315
LBB0_207:                               ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.208:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x8, x22
	cmp	w8, #3
	mov	w9, #4                          ; =0x4
	csel	w9, w9, wzr, eq
	cmp	w8, #1
	csinc	w2, w9, wzr, ne
	b.ne	LBB0_292
; %bb.209:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x3, [sp, #400]
	b	LBB0_303
LBB0_210:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w23, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
LBB0_211:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	w28, w8
	b.lo	LBB0_314
LBB0_212:                               ;   in Loop: Header=BB0_174 Depth=1
	sub	w27, w28, w8
	and	w1, w27, #0xffff
	add	x2, sp, #1112
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	tbz	w0, #0, LBB0_314
; %bb.213:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1112]
	add	x2, sp, #1192
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	tbz	w0, #0, LBB0_314
; %bb.214:                              ;   in Loop: Header=BB0_174 Depth=1
	tbz	w23, #0, LBB0_312
LBB0_215:                               ;   in Loop: Header=BB0_174 Depth=1
	and	w9, w22, #0xfe
	cmp	w22, #50
	mov	w8, #48                         ; =0x30
	ccmp	w9, w8, #4, ne
	cset	w10, eq
	sub	w11, w22, #48
	cmp	w11, #3
	cset	w12, lo
	cmp	w9, #40
	ldrb	w11, [sp, #1196]
	and	w9, w11, #0xff
	ccmp	w9, #4, #0, eq
	csinc	w10, w10, wzr, ne
	csinc	w9, w12, wzr, ne
	cmp	w10, #0
	mov	w10, #4                         ; =0x4
	csinc	w10, w10, wzr, ne
	ldrb	w12, [sp, #1192]
	cmp	w12, #1
	b.ne	LBB0_336
; %bb.216:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w12, [sp, #1193]
	tbnz	w12, #0, LBB0_336
; %bb.217:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w12, [sp, #1194]
	tbnz	w12, #0, LBB0_336
; %bb.218:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w12, [sp, #1197]
	cbnz	w12, LBB0_336
; %bb.219:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w12, [sp, #1208]
	cbnz	w12, LBB0_336
; %bb.220:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w10, w11, uxtb
	b.ne	LBB0_336
; %bb.221:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w11, [sp, #1200]
	cmn	w11, #1
	b.ne	LBB0_336
; %bb.222:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w11, [sp, #1204]
	cmn	w11, #1
	b.ne	LBB0_336
; %bb.223:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1216]
	cmp	w11, #1
	b.ne	LBB0_336
; %bb.224:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x8, x22
	cbz	w9, LBB0_226
; %bb.225:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x11, [sp, #1224]
	cmp	x11, #2
	b.hs	LBB0_336
LBB0_226:                               ;   in Loop: Header=BB0_174 Depth=1
	tbz	w23, #0, LBB0_325
LBB0_227:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	x10, [sp, #1328]
	cmp	w23, #0
	csel	x9, xzr, x10, ne
	sub	w11, w8, #32
	cmp	w11, #181
	b.hi	LBB0_314
; %bb.228:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x8, [sp, #1224]
Lloh12:
	adrp	x14, lJTI0_1@PAGE
Lloh13:
	add	x14, x14, lJTI0_1@PAGEOFF
	adr	x12, LBB0_229
	ldrh	w13, [x14, x11, lsl #1]
	add	x12, x12, x13, lsl #2
	br	x12
LBB0_229:                               ;   in Loop: Header=BB0_174 Depth=1
	add	x27, x9, x8
	b	LBB0_366
LBB0_230:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	w28, LBB0_314
; %bb.231:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.232:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1000
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	tbz	w0, #0, LBB0_314
; %bb.233:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w22, #8
	b.ne	LBB0_259
; %bb.234:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1001]
	tbnz	w8, #0, LBB0_336
; %bb.235:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1002]
	tbz	w8, #0, LBB0_259
	b	LBB0_336
LBB0_236:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w1, [sp, #400]
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_local
	cbz	w0, LBB0_314
; %bb.237:                              ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	cbz	w0, LBB0_314
; %bb.238:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1000
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	tbz	w0, #0, LBB0_314
; %bb.239:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1000]
	cmp	w8, #1
	b.ne	LBB0_336
; %bb.240:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1002]
	tbnz	w8, #0, LBB0_336
; %bb.241:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1001]
	cmp	w22, #11
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_336
; %bb.242:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	ldr	w2, [sp, #1104]
	mov	x0, x24
	cmp	w22, #16
	b.ne	LBB0_337
; %bb.243:                              ;   in Loop: Header=BB0_174 Depth=1
	bl	_nvm_websocket_runtime_copy
	b	LBB0_338
LBB0_244:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_store
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_245:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_borrow
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_246:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w8, [sp, #416]
	ldrh	w9, [sp, #408]
	cmp	w22, #251
	csel	w9, w8, w9, eq
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	ldrh	w9, [sp, #424]
	csel	w8, w9, w8, eq
	and	w9, w8, #0xffff
	cmp	w9, #9
	b.hi	LBB0_314
; %bb.247:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w28, w9
	b.lo	LBB0_314
; %bb.248:                              ;   in Loop: Header=BB0_174 Depth=1
	tst	w8, #0xffff
	b.eq	LBB0_305
; %bb.249:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x27, #0                         ; =0x0
	and	x22, x8, #0xffff
	sub	w28, w28, w8
	add	x23, sp, #1192
LBB0_250:                               ;   Parent Loop BB0_174 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w8, w28, w27
	and	w1, w8, #0xffff
	mov	x0, x24
	mov	x2, x23
	bl	_nvm_websocket_runtime_frame_operand
	tbz	w0, #0, LBB0_314
; %bb.251:                              ;   in Loop: Header=BB0_250 Depth=2
	add	x27, x27, #1
	add	x23, x23, #4
	cmp	x22, x27
	b.ne	LBB0_250
; %bb.252:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w5, [sp, #1192]
	str	w5, [sp, #1104]
	b	LBB0_307
LBB0_253:                               ;   in Loop: Header=BB0_174 Depth=1
	str	w25, [sp, #1192]
	cmp	w22, #68
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
	cmp	w28, w8
	b.lo	LBB0_314
; %bb.254:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, w8
	and	w1, w8, #0xffff
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.255:                              ;   in Loop: Header=BB0_174 Depth=1
	cmp	w22, #68
	b.ne	LBB0_308
; %bb.256:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1192
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.257:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w3, [sp, #1192]
	b	LBB0_309
LBB0_258:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w1, [sp, #400]
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_local
	tbz	w0, #0, LBB0_314
LBB0_259:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	mov	x0, x24
	bl	_nvm_websocket_runtime_drop
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_260:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_end_reference
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_261:                               ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.262:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1104]
	mov	x0, x24
	bl	_nvm_websocket_runtime_indirect_funcref
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_263:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	w28, LBB0_314
; %bb.264:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.265:                              ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.266:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	ldr	w2, [sp, #1104]
	mov	x0, x24
	bl	_nvm_websocket_runtime_copy
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_267:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w22, [sp, #976]
	str	w25, [sp, #996]
	mov	x0, x24
	bl	_nvm_websocket_runtime_indirect_plan
	add	x2, sp, #1112
	mov	x1, x22
	bl	_nvm_websocket_indirect_hosted_import
	cbz	w0, LBB0_314
; %bb.268:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1112]
	ldr	w9, [sp, #400]
	cmp	w8, w9
	b.ne	LBB0_314
; %bb.269:                              ;   in Loop: Header=BB0_174 Depth=1
	add	x1, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_scratch
	cbz	w0, LBB0_314
; %bb.270:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x22
	bl	_nl_websocket_catalog_method
	cbz	x0, LBB0_314
; %bb.271:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x8, [x0, #56]
	cbz	x8, LBB0_314
; %bb.272:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w9, [x0, #44]
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cmp	w9, #1
	cset	w10, eq
	csetm	x9, eq
	mvn	x10, x10
	add	x10, x10, x8
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
	cmp	x10, #2
	b.hi	LBB0_314
; %bb.273:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x28, x10
	b.lo	LBB0_314
; %bb.274:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cbz	x10, LBB0_278
; %bb.275:                              ;   in Loop: Header=BB0_174 Depth=1
	sub	x8, x28, x8
	sub	x8, x8, x9
	add	x22, x8, #1
	add	x23, sp, #1192
	ldr	x27, [sp, #16]                  ; 8-byte Folded Reload
LBB0_276:                               ;   Parent Loop BB0_174 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w1, w22, #0xffff
	mov	x0, x24
	mov	x2, x23
	bl	_nvm_websocket_runtime_frame_operand
	tbz	w0, #0, LBB0_314
; %bb.277:                              ;   in Loop: Header=BB0_276 Depth=2
	add	x23, x23, #4
	add	x22, x22, #1
	subs	x27, x27, #1
	b.ne	LBB0_276
LBB0_278:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB0_339
; %bb.279:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w1, [sp, #408]
	add	x2, sp, #996
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reference
	cbz	w0, LBB0_314
; %bb.280:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w2, [sp, #996]
	b	LBB0_340
LBB0_281:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_return
	b	LBB0_316
LBB0_282:                               ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.283:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1104]
	mov	x0, x24
	bl	_nvm_websocket_runtime_string_literal
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_284:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_region_begin
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_285:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_region_end
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_286:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w1, [sp, #400]
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_local
	cbz	w0, LBB0_314
; %bb.287:                              ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.288:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	ldrb	w8, [sp, #408]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w2, w8, ne
	ldr	w3, [sp, #1104]
	mov	x0, x24
	bl	_nvm_websocket_runtime_take
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_289:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w1, [sp, #400]
	add	x2, sp, #1108
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_local
	tbz	w0, #0, LBB0_314
; %bb.290:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1192
	mov	x0, x24
	bl	_nvm_websocket_runtime_result_arm
	mov	x1, x0
	cbnz	w0, LBB0_317
; %bb.291:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1192]
	cmp	w8, #3
	cset	w23, eq
	b	LBB0_311
LBB0_292:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	w22, #3
	b.ne	LBB0_302
; %bb.293:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w3, [sp, #400]
	b	LBB0_303
LBB0_294:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x22, x9
	cmp	w28, w8
	b.hs	LBB0_212
	b	LBB0_314
LBB0_295:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1000
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	cbz	w0, LBB0_322
; %bb.296:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1001]
	mov	w1, #6                          ; =0x6
	tbnz	w8, #0, LBB0_323
; %bb.297:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #1002]
	tbnz	w8, #0, LBB0_323
; %bb.298:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w8, [sp, #1016]
	cmp	w8, #3
	b.ne	LBB0_323
; %bb.299:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	add	x2, sp, #1192
	mov	x0, x24
	bl	_nvm_websocket_runtime_result_arm
	cbnz	w0, LBB0_316
; %bb.300:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	mov	x0, x24
	bl	_nvm_websocket_runtime_drop
	cbnz	w0, LBB0_316
; %bb.301:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1108]
	ldr	w8, [sp, #1192]
	cmp	w8, #3
	cset	w3, eq
	mov	x0, x24
	mov	w2, #1                          ; =0x1
	b	LBB0_304
LBB0_302:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x3, #0                          ; =0x0
LBB0_303:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1104]
	mov	x0, x24
LBB0_304:                               ;   in Loop: Header=BB0_174 Depth=1
	bl	_nvm_websocket_runtime_scalar
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_305:                               ;   in Loop: Header=BB0_174 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1104
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	cbz	w0, LBB0_314
; %bb.306:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x22, #0                         ; =0x0
	ldr	w5, [sp, #1104]
LBB0_307:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #976]
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w2, w8, #0xffff
	add	x3, sp, #1192
	mov	x0, x24
	mov	x4, x22
	bl	_nvm_websocket_runtime_construct
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_308:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w3, #-1                         ; =0xffffffff
LBB0_309:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w2, [sp, #1108]
	mov	x0, x24
	mov	x1, x22
	mov	x4, x2
	bl	_nvm_websocket_runtime_string_operation
	cbnz	w0, LBB0_167
LBB0_310:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_311:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_websocket_runtime_frame_next
	b	LBB0_316
LBB0_312:                               ;   in Loop: Header=BB0_174 Depth=1
	add	w8, w27, #1
	and	w1, w8, #0xffff
	add	x8, sp, #1112
	add	x2, x8, #4
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_operand
	cbz	w0, LBB0_314
; %bb.313:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1116]
	add	x8, sp, #1192
	add	x2, x8, #104
	mov	x0, x24
	bl	_nvm_websocket_runtime_view
	tbnz	w0, #0, LBB0_215
LBB0_314:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	mov	w1, #5                          ; =0x5
LBB0_315:                               ;   in Loop: Header=BB0_174 Depth=1
	bl	_nvm_websocket_runtime_fail
LBB0_316:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x1, x0
LBB0_317:                               ;   in Loop: Header=BB0_174 Depth=1
	cbnz	w1, LBB0_168
; %bb.318:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w8, [sp, #392]
	cmp	w8, #61
	b.ne	LBB0_173
; %bb.319:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrh	w8, [sp, #316]
	cmp	w8, #1
	b.ne	LBB0_173
; %bb.320:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x0, [sp, #288]
	add	x1, sp, #1192
	bl	_nvm_websocket_runtime_current_root
	tbz	w0, #0, LBB0_169
; %bb.321:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x0, [sp, #288]
	bl	_nvm_websocket_runtime_frame_start
	mov	x1, x0
	b	LBB0_173
LBB0_322:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w1, #5                          ; =0x5
LBB0_323:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	b	LBB0_315
LBB0_324:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, #0
	cset	w8, ne
	cmp	w22, #57
	cset	w9, ne
	eor	w23, w9, w8
	b	LBB0_311
LBB0_325:                               ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1296]
	cmp	w11, #1
	b.ne	LBB0_336
; %bb.326:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1297]
	tbnz	w11, #0, LBB0_336
; %bb.327:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1298]
	tbnz	w11, #0, LBB0_336
; %bb.328:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1301]
	cbnz	w11, LBB0_336
; %bb.329:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w11, [sp, #1312]
	cbnz	w11, LBB0_336
; %bb.330:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w11, [sp, #1300]
	cmp	w11, w10
	b.ne	LBB0_336
; %bb.331:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w10, [sp, #1304]
	cmn	w10, #1
	b.ne	LBB0_336
; %bb.332:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w10, [sp, #1308]
	cmn	w10, #1
	b.ne	LBB0_336
; %bb.333:                              ;   in Loop: Header=BB0_174 Depth=1
	ldrb	w10, [sp, #1320]
	cmp	w10, #1
	b.ne	LBB0_336
; %bb.334:                              ;   in Loop: Header=BB0_174 Depth=1
	cbz	w9, LBB0_227
; %bb.335:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x9, [sp, #1328]
	cmp	x9, #1
	b.ls	LBB0_227
LBB0_336:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	mov	w1, #6                          ; =0x6
	b	LBB0_315
LBB0_337:                               ;   in Loop: Header=BB0_174 Depth=1
	bl	_nvm_websocket_runtime_move
LBB0_338:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x1, x0
	cbz	w0, LBB0_310
	b	LBB0_168
LBB0_339:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w2, #-1                         ; =0xffffffff
LBB0_340:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #400]
	ldr	w5, [sp, #1104]
	add	x3, sp, #1192
	mov	x0, x24
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	bl	_nvm_websocket_runtime_service
	mov	x1, x0
	cbnz	w0, LBB0_317
; %bb.341:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	sub	w8, w28, w8
	and	w1, w8, #0xffff
	add	x2, sp, #992
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_reserve
	tbz	w0, #0, LBB0_314
; %bb.342:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1104]
	ldr	w2, [sp, #992]
	mov	x0, x24
	bl	_nvm_websocket_runtime_move
	cbz	w0, LBB0_310
	b	LBB0_167
LBB0_343:                               ;   in Loop: Header=BB0_174 Depth=1
	sub	x27, x8, x9
	b	LBB0_366
LBB0_344:                               ;   in Loop: Header=BB0_174 Depth=1
	mul	x27, x9, x8
	b	LBB0_366
LBB0_345:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	x9, LBB0_352
; %bb.346:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x27, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x27
	b.ne	LBB0_348
; %bb.347:                              ;   in Loop: Header=BB0_174 Depth=1
	cmn	x9, #1
	b.eq	LBB0_366
LBB0_348:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w22, #1                         ; =0x1
	sdiv	x27, x8, x10
	b	LBB0_367
LBB0_349:                               ;   in Loop: Header=BB0_174 Depth=1
	cbz	x9, LBB0_352
; %bb.350:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x11, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x11
	b.ne	LBB0_365
; %bb.351:                              ;   in Loop: Header=BB0_174 Depth=1
	cmn	x9, #1
	b.ne	LBB0_365
LBB0_352:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	x27, #0                         ; =0x0
	b	LBB0_366
LBB0_353:                               ;   in Loop: Header=BB0_174 Depth=1
	neg	x27, x8
	b	LBB0_366
LBB0_354:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	b	LBB0_364
LBB0_355:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	b	LBB0_362
LBB0_356:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	cset	w27, lt
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_357:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	cset	w27, le
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_358:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	cset	w27, gt
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_359:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, x9
	cset	w27, ge
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_360:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, #0
	ccmp	x9, #0, #4, ne
	b	LBB0_362
LBB0_361:                               ;   in Loop: Header=BB0_174 Depth=1
	orr	x8, x8, x9
	cmp	x8, #0
LBB0_362:                               ;   in Loop: Header=BB0_174 Depth=1
	cset	w27, ne
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_363:                               ;   in Loop: Header=BB0_174 Depth=1
	cmp	x8, #0
LBB0_364:                               ;   in Loop: Header=BB0_174 Depth=1
	cset	w27, eq
	mov	w22, #4                         ; =0x4
	b	LBB0_367
LBB0_365:                               ;   in Loop: Header=BB0_174 Depth=1
	sdiv	x9, x8, x10
	msub	x27, x9, x10, x8
LBB0_366:                               ;   in Loop: Header=BB0_174 Depth=1
	mov	w22, #1                         ; =0x1
LBB0_367:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1112]
	mov	x0, x24
	bl	_nvm_websocket_runtime_drop
	cbnz	w0, LBB0_316
; %bb.368:                              ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w23, #0, LBB0_370
; %bb.369:                              ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1116]
	mov	x0, x24
	bl	_nvm_websocket_runtime_drop
	cbnz	w0, LBB0_316
LBB0_370:                               ;   in Loop: Header=BB0_174 Depth=1
	ldr	w1, [sp, #1112]
	mov	x0, x24
	mov	x2, x22
	mov	x3, x27
	bl	_nvm_websocket_runtime_scalar
	mov	x1, x0
	cbnz	w0, LBB0_317
; %bb.371:                              ;   in Loop: Header=BB0_174 Depth=1
	mov	x0, x24
	bl	_nvm_websocket_runtime_frame_next
	b	LBB0_316
LBB0_372:
	ldr	x0, [sp, #288]
	mov	w1, #5                          ; =0x5
	bl	_nvm_websocket_runtime_fail
	cbnz	w0, LBB0_167
	b	LBB0_169
LBB0_373:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_311-LBB0_184)>>2
	.short	(LBB0_207-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_207-LBB0_184)>>2
	.short	(LBB0_282-LBB0_184)>>2
	.short	(LBB0_207-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_263-LBB0_184)>>2
	.short	(LBB0_230-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_236-LBB0_184)>>2
	.short	(LBB0_244-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_184-LBB0_184)>>2
	.short	(LBB0_236-LBB0_184)>>2
	.short	(LBB0_244-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_284-LBB0_184)>>2
	.short	(LBB0_285-LBB0_184)>>2
	.short	(LBB0_245-LBB0_184)>>2
	.short	(LBB0_245-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_210-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_210-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_311-LBB0_184)>>2
	.short	(LBB0_190-LBB0_184)>>2
	.short	(LBB0_190-LBB0_184)>>2
	.short	(LBB0_184-LBB0_184)>>2
	.short	(LBB0_184-LBB0_184)>>2
	.short	(LBB0_281-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_253-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_253-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_246-LBB0_184)>>2
	.short	(LBB0_185-LBB0_184)>>2
	.short	(LBB0_185-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_267-LBB0_184)>>2
	.short	(LBB0_289-LBB0_184)>>2
	.short	(LBB0_286-LBB0_184)>>2
	.short	(LBB0_258-LBB0_184)>>2
	.short	(LBB0_230-LBB0_184)>>2
	.short	(LBB0_260-LBB0_184)>>2
	.short	(LBB0_184-LBB0_184)>>2
	.short	(LBB0_184-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_190-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_210-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_261-LBB0_184)>>2
	.short	(LBB0_246-LBB0_184)>>2
	.short	(LBB0_185-LBB0_184)>>2
	.short	(LBB0_211-LBB0_184)>>2
	.short	(LBB0_185-LBB0_184)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_229-LBB0_229)>>2
	.short	(LBB0_343-LBB0_229)>>2
	.short	(LBB0_344-LBB0_229)>>2
	.short	(LBB0_345-LBB0_229)>>2
	.short	(LBB0_349-LBB0_229)>>2
	.short	(LBB0_353-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_354-LBB0_229)>>2
	.short	(LBB0_355-LBB0_229)>>2
	.short	(LBB0_356-LBB0_229)>>2
	.short	(LBB0_357-LBB0_229)>>2
	.short	(LBB0_358-LBB0_229)>>2
	.short	(LBB0_359-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_360-LBB0_229)>>2
	.short	(LBB0_361-LBB0_229)>>2
	.short	(LBB0_363-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_229-LBB0_229)>>2
	.short	(LBB0_343-LBB0_229)>>2
	.short	(LBB0_344-LBB0_229)>>2
	.short	(LBB0_345-LBB0_229)>>2
	.short	(LBB0_349-LBB0_229)>>2
	.short	(LBB0_353-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_314-LBB0_229)>>2
	.short	(LBB0_354-LBB0_229)>>2
	.short	(LBB0_355-LBB0_229)>>2
	.short	(LBB0_356-LBB0_229)>>2
	.short	(LBB0_357-LBB0_229)>>2
	.short	(LBB0_358-LBB0_229)>>2
	.short	(LBB0_359-LBB0_229)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB1_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh14:
	adrp	x9, lJTI1_0@PAGE
Lloh15:
	add	x9, x9, lJTI1_0@PAGEOFF
	adr	x10, LBB1_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB1_2:
	ret
LBB1_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
	.section	__TEXT,__const
lJTI1_0:
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
                                        ; -- End function
.subsections_via_symbols
