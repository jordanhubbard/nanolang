	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_layouts_have_facts ; -- Begin function nvm_layouts_have_facts
	.globl	_nvm_layouts_have_facts
	.p2align	2
_nvm_layouts_have_facts:                ; @nvm_layouts_have_facts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_8
; %bb.1:
	ldr	w8, [x0, #8]
	cbz	w8, LBB0_7
; %bb.2:
	ldr	x9, [x0]
	cbz	x9, LBB0_7
; %bb.3:
	add	x9, x9, #4
LBB0_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9]
	cmn	w10, #1
	b.ne	LBB0_9
; %bb.5:                                ;   in Loop: Header=BB0_4 Depth=1
	ldurh	w10, [x9, #-2]
	cbnz	w10, LBB0_9
; %bb.6:                                ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #16
	subs	x8, x8, #1
	b.ne	LBB0_4
LBB0_7:
	mov	w0, #0                          ; =0x0
LBB0_8:
	ret
LBB0_9:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_retained_layouts_valid ; -- Begin function nvm_retained_layouts_valid
	.globl	_nvm_retained_layouts_valid
	.p2align	2
_nvm_retained_layouts_valid:            ; @nvm_retained_layouts_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_30
; %bb.1:
	mov	x9, x0
	ldr	w1, [x0, #320]
	ldr	x8, [x0, #312]
	orr	x10, x1, x8
	cmp	x10, #0
	cset	w0, eq
	cmp	w1, #0
	ccmp	x8, #0, #4, ne
	b.eq	LBB1_30
; %bb.2:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x9
	stp	xzr, xzr, [sp]
	mov	x2, sp
	mov	x0, x8
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB1_4
; %bb.3:
	mov	w0, #0                          ; =0x0
	b	LBB1_29
LBB1_4:
	mov	x0, sp
	bl	_nvm_v2_layouts_encoded_size
	ldr	w9, [x19, #320]
	cmp	x0, x9
	b.ne	LBB1_27
; %bb.5:
	mov	x8, x19
	ldr	w12, [sp, #8]
	cbz	w12, LBB1_23
; %bb.6:
	mov	x13, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	ldr	x14, [sp]
	b	LBB1_8
LBB1_7:                                 ;   in Loop: Header=BB1_8 Depth=1
	add	x13, x13, #1
	cmp	x13, x12
	b.eq	LBB1_24
LBB1_8:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_21 Depth 2
	add	x15, x14, x13, lsl #4
	ldr	w16, [x15, #4]
	cmn	w16, #1
	b.eq	LBB1_10
; %bb.9:                                ;   in Loop: Header=BB1_8 Depth=1
	ldr	w17, [x8, #248]
	cmp	w16, w17
	b.hs	LBB1_27
LBB1_10:                                ;   in Loop: Header=BB1_8 Depth=1
	mov	w16, #0                         ; =0x0
	ldrb	w17, [x15]
	cmp	w17, #1
	b.gt	LBB1_13
; %bb.11:                               ;   in Loop: Header=BB1_8 Depth=1
	cbz	w17, LBB1_16
; %bb.12:                               ;   in Loop: Header=BB1_8 Depth=1
	cmp	w17, #1
	b.eq	LBB1_18
	b	LBB1_28
LBB1_13:                                ;   in Loop: Header=BB1_8 Depth=1
	cmp	w17, #2
	b.eq	LBB1_17
; %bb.14:                               ;   in Loop: Header=BB1_8 Depth=1
	cmp	w17, #3
	b.ne	LBB1_28
; %bb.15:                               ;   in Loop: Header=BB1_8 Depth=1
	add	w10, w10, #1
	b	LBB1_18
LBB1_16:                                ;   in Loop: Header=BB1_8 Depth=1
	add	w11, w11, #1
	b	LBB1_18
LBB1_17:                                ;   in Loop: Header=BB1_8 Depth=1
	add	w9, w9, #1
LBB1_18:                                ;   in Loop: Header=BB1_8 Depth=1
	ldrh	w16, [x15, #2]
	cbz	x16, LBB1_7
; %bb.19:                               ;   in Loop: Header=BB1_8 Depth=1
	ldr	x15, [x15, #8]
	add	x15, x15, #8
	b	LBB1_21
LBB1_20:                                ;   in Loop: Header=BB1_21 Depth=2
	subs	x16, x16, #1
	b.eq	LBB1_7
LBB1_21:                                ;   Parent Loop BB1_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w17, [x15], #12
	cmn	w17, #1
	b.eq	LBB1_20
; %bb.22:                               ;   in Loop: Header=BB1_21 Depth=2
	ldr	w0, [x8, #248]
	cmp	w17, w0
	b.lo	LBB1_20
	b	LBB1_27
LBB1_23:
	mov	w11, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
LBB1_24:
	ldr	w12, [x8, #468]
	cmp	w11, w12
	b.ne	LBB1_27
; %bb.25:
	ldr	w11, [x8, #472]
	cmp	w10, w11
	b.ne	LBB1_27
; %bb.26:
	ldr	w8, [x8, #476]
	cmp	w9, w8
	cset	w16, eq
	b	LBB1_28
LBB1_27:
	mov	w16, #0                         ; =0x0
LBB1_28:
	mov	x19, x16
	mov	x0, sp
	bl	_nvm_v2_layouts_free
	mov	x0, x19
LBB1_29:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB1_30:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_retain_layouts     ; -- Begin function nvm_retain_layouts
	.globl	_nvm_retain_layouts
	.p2align	2
_nvm_retain_layouts:                    ; @nvm_retain_layouts
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x20, x0
	mov	w0, #13                         ; =0xd
	cbz	x20, LBB2_10
; %bb.1:
	cbz	x1, LBB2_10
; %bb.2:
	ldr	w8, [x1, #8]
	cbz	w8, LBB2_8
; %bb.3:
	ldr	x9, [x1]
	cbz	x9, LBB2_10
; %bb.4:
	add	x9, x9, #8
	b	LBB2_6
LBB2_5:                                 ;   in Loop: Header=BB2_6 Depth=1
	add	x9, x9, #16
	subs	x8, x8, #1
	b.eq	LBB2_8
LBB2_6:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w10, [x9, #-6]
	cbz	w10, LBB2_5
; %bb.7:                                ;   in Loop: Header=BB2_6 Depth=1
	ldr	x10, [x9]
	cbnz	x10, LBB2_5
	b	LBB2_9
LBB2_8:
	mov	x22, x1
	mov	x0, x1
	bl	_nvm_v2_layouts_encoded_size
	lsr	x8, x0, #32
	cbz	x8, LBB2_11
LBB2_9:
	mov	w0, #13                         ; =0xd
LBB2_10:
	add	sp, sp, #480
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB2_11:
	mov	x19, x0
	bl	_malloc
	cbz	x0, LBB2_14
; %bb.12:
	mov	x21, x0
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	bl	_nvm_v2_layouts_encode
	cbz	w0, LBB2_15
; %bb.13:
	mov	x19, x0
	mov	x0, x21
	bl	_free
	mov	x0, x19
	b	LBB2_10
LBB2_14:
	mov	w0, #1                          ; =0x1
	b	LBB2_10
LBB2_15:
	mov	x0, sp
	mov	x1, x20
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	str	x21, [sp, #312]
	str	w19, [sp, #320]
	mov	x0, sp
	bl	_nvm_retained_layouts_valid
	tbz	w0, #0, LBB2_17
; %bb.16:
	ldr	x0, [x20, #312]
	bl	_free
	mov	w0, #0                          ; =0x0
	str	x21, [x20, #312]
	str	w19, [x20, #320]
	b	LBB2_10
LBB2_17:
	mov	x0, x21
	bl	_free
	b	LBB2_9
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_plan_free   ; -- Begin function nvm_record_plan_free
	.globl	_nvm_record_plan_free
	.p2align	2
_nvm_record_plan_free:                  ; @nvm_record_plan_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #24]
	bl	_free
	ldr	x0, [x19, #32]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB3_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_describe_managed_records
lCPI4_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI4_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI4_2:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_describe_managed_records
	.globl	_nvm_describe_managed_records
	.p2align	2
_nvm_describe_managed_records:          ; @nvm_describe_managed_records
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #1088
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh0:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
	cbz	x0, LBB4_7
; %bb.1:
	cbz	x1, LBB4_7
; %bb.2:
	ldr	x10, [x0, #312]
	ldr	w9, [x0, #320]
	cmp	w9, #0
	cset	w11, eq
	cmp	x10, #0
	cset	w10, ne
	cmp	w10, w11
	b.eq	LBB4_7
; %bb.3:
	ldr	x10, [x0, #296]
	cmp	x10, #0
	cset	w10, eq
	ldr	w11, [x0, #304]
	cmp	w11, #0
	cset	w11, ne
	eor	w10, w10, w11
	tbz	w10, #0, LBB4_7
; %bb.4:
	cbz	w9, LBB4_11
; %bb.5:
	mov	x25, x1
	mov	x23, x8
	strb	wzr, [sp, #55]
	add	x8, sp, #16
	add	x1, sp, #55
	mov	x20, x0
	bl	_record_preflight
	ldr	w8, [sp, #16]
	cbz	w8, LBB4_12
LBB4_6:
	ldr	q0, [sp, #16]
	str	q0, [x23]
	ldr	x8, [sp, #32]
	b	LBB4_14
LBB4_7:
Lloh3:
	adrp	x9, lCPI4_0@PAGE
Lloh4:
	ldr	q0, [x9, lCPI4_0@PAGEOFF]
	str	q0, [x8]
Lloh5:
	adrp	x9, l_.str@PAGE
Lloh6:
	add	x9, x9, l_.str@PAGEOFF
LBB4_8:
	str	x9, [x8, #16]
LBB4_9:
	ldur	x8, [x29, #-72]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_87
; %bb.10:
	add	sp, sp, #1088
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB4_11:
Lloh10:
	adrp	x9, lCPI4_2@PAGE
Lloh11:
	ldr	q0, [x9, lCPI4_2@PAGEOFF]
	str	q0, [x8]
Lloh12:
	adrp	x9, l_.str.1@PAGE
Lloh13:
	add	x9, x9, l_.str.1@PAGEOFF
	b	LBB4_8
LBB4_12:
	stp	xzr, xzr, [sp]
	ldr	x0, [x20, #312]
	ldr	w1, [x20, #320]
	mov	x2, sp
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB4_15
; %bb.13:
	mov	w8, #2                          ; =0x2
	mov	w9, #4                          ; =0x4
	cmp	w0, #1
	csel	w8, w9, w8, eq
	stp	w8, wzr, [x23]
	str	xzr, [x23, #8]
Lloh14:
	adrp	x8, l_.str.2@PAGE
Lloh15:
	add	x8, x8, l_.str.2@PAGEOFF
LBB4_14:
	str	x8, [x23, #16]
	b	LBB4_9
LBB4_15:
	ldr	w21, [sp, #8]
	mov	x0, x20
	cbz	w21, LBB4_32
; %bb.16:
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp]
	b	LBB4_18
LBB4_17:                                ;   in Loop: Header=BB4_18 Depth=1
	add	x8, x8, #1
	cmp	x8, x21
	b.eq	LBB4_32
LBB4_18:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_22 Depth 2
	add	x12, x9, x8, lsl #4
	ldrb	w10, [x12]
	cbnz	w10, LBB4_17
; %bb.19:                               ;   in Loop: Header=BB4_18 Depth=1
	ldrh	w11, [x12, #2]
	cbz	x11, LBB4_17
; %bb.20:                               ;   in Loop: Header=BB4_18 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x12, [x12, #8]
	add	x12, x12, #4
	b	LBB4_22
LBB4_21:                                ;   in Loop: Header=BB4_22 Depth=2
	add	x10, x10, #1
	add	x12, x12, #12
	cmp	x11, x10
	b.eq	LBB4_17
LBB4_22:                                ;   Parent Loop BB4_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w14, [x12, #-4]
	cmp	w14, #6
	b.lo	LBB4_24
; %bb.23:                               ;   in Loop: Header=BB4_22 Depth=2
	sub	w13, w14, #7
	cmp	w13, #3
	b.hs	LBB4_68
LBB4_24:                                ;   in Loop: Header=BB4_22 Depth=2
	ldr	w13, [x12]
	cmp	w14, #8
	b.ne	LBB4_27
; %bb.25:                               ;   in Loop: Header=BB4_22 Depth=2
	cmn	w13, #1
	b.eq	LBB4_30
; %bb.26:                               ;   in Loop: Header=BB4_22 Depth=2
	lsl	x13, x13, #4
	ldrb	w13, [x9, x13]
	cbz	w13, LBB4_21
	b	LBB4_30
LBB4_27:                                ;   in Loop: Header=BB4_22 Depth=2
	cmn	w13, #1
	b.eq	LBB4_21
; %bb.28:                               ;   in Loop: Header=BB4_22 Depth=2
	cmp	w14, #9
	b.ne	LBB4_30
; %bb.29:                               ;   in Loop: Header=BB4_22 Depth=2
	lsl	x13, x13, #4
	ldrb	w13, [x9, x13]
	cmp	w13, #3
	b.eq	LBB4_21
LBB4_30:
	mov	w9, #2                          ; =0x2
	stp	w9, w8, [sp, #16]
	stp	w10, wzr, [sp, #24]
Lloh16:
	adrp	x8, l_.str.4@PAGE
Lloh17:
	add	x8, x8, l_.str.4@PAGEOFF
LBB4_31:
	str	x8, [sp, #32]
	b	LBB4_36
LBB4_32:
	ldr	w8, [x0, #304]
	cbz	w8, LBB4_37
; %bb.33:
	add	x2, sp, #56
	mov	x1, x21
	bl	_nvm_ownership_layout_authorities
	cbz	w0, LBB4_39
; %bb.34:
	mov	w8, #0                          ; =0x0
Lloh18:
	adrp	x9, l_.str.5@PAGE
Lloh19:
	add	x9, x9, l_.str.5@PAGEOFF
LBB4_35:
	mov	w10, #1                         ; =0x1
	stp	w10, w8, [sp, #16]
	stp	xzr, x9, [sp, #24]
LBB4_36:
	mov	x0, sp
	bl	_nvm_v2_layouts_free
	b	LBB4_6
LBB4_37:
	ldrb	w8, [sp, #55]
	cmp	w8, #1
	b.ne	LBB4_46
; %bb.38:
Lloh20:
	adrp	x8, lCPI4_2@PAGE
Lloh21:
	ldr	q0, [x8, lCPI4_2@PAGEOFF]
	str	q0, [sp, #16]
Lloh22:
	adrp	x8, l_.str.7@PAGE
Lloh23:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB4_31
LBB4_39:
	ldr	w21, [sp, #8]
	cbz	w21, LBB4_45
; %bb.40:
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp]
	add	x10, sp, #56
	b	LBB4_42
LBB4_41:                                ;   in Loop: Header=BB4_42 Depth=1
	add	x8, x8, #1
	cmp	x21, x8
	b.eq	LBB4_45
LBB4_42:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9], #16
	cbnz	w11, LBB4_41
; %bb.43:                               ;   in Loop: Header=BB4_42 Depth=1
	ldr	w11, [x10, x8, lsl #2]
	cmp	w11, #1
	b.eq	LBB4_41
; %bb.44:
Lloh24:
	adrp	x9, l_.str.6@PAGE
Lloh25:
	add	x9, x9, l_.str.6@PAGEOFF
	b	LBB4_35
LBB4_45:
	mov	w24, #1                         ; =0x1
                                        ; kill: def $w21 killed $w21 killed $x21 def $x21
	b	LBB4_47
LBB4_46:
	mov	w24, #0                         ; =0x0
LBB4_47:
	mov	w0, #1                          ; =0x1
	mov	w1, #48                         ; =0x30
	bl	_calloc
	cbz	x0, LBB4_50
; %bb.48:
	mov	x19, x0
	ldr	w22, [x20, #468]
	str	w22, [x0, #16]
	cbz	w22, LBB4_51
; %bb.49:
	mov	x0, x22
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x20, x0
	str	x0, [x19, #24]
	b	LBB4_52
LBB4_50:
Lloh26:
	adrp	x8, lCPI4_1@PAGE
Lloh27:
	ldr	q0, [x8, lCPI4_1@PAGEOFF]
	str	q0, [sp, #16]
Lloh28:
	adrp	x8, l_.str.8@PAGE
Lloh29:
	add	x8, x8, l_.str.8@PAGEOFF
	b	LBB4_31
LBB4_51:
	mov	x20, #0                         ; =0x0
LBB4_52:
	cbz	w21, LBB4_54
; %bb.53:
	mov	w0, w21
	mov	w1, #4                          ; =0x4
	bl	_calloc
	str	x0, [x19, #32]
	b	LBB4_55
LBB4_54:
	mov	x0, #0                          ; =0x0
LBB4_55:
	mov	x8, x23
	cbz	w22, LBB4_58
; %bb.56:
	cbnz	x20, LBB4_58
LBB4_57:
	mov	x0, x19
	bl	_nvm_record_plan_free
Lloh30:
	adrp	x8, lCPI4_1@PAGE
Lloh31:
	ldr	q0, [x8, lCPI4_1@PAGEOFF]
	str	q0, [sp, #16]
Lloh32:
	adrp	x8, l_.str.9@PAGE
Lloh33:
	add	x8, x8, l_.str.9@PAGEOFF
	b	LBB4_31
LBB4_58:
	cbz	w21, LBB4_67
; %bb.59:
	cbz	x0, LBB4_57
; %bb.60:
	ldr	x12, [sp]
	mov	w13, w21
	and	x9, x13, #0x7
	cmp	w21, #8
	b.hs	LBB4_69
; %bb.61:
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
LBB4_62:
	cbz	x9, LBB4_67
; %bb.63:
	add	x12, x12, x10, lsl #4
	mov	w13, #-1                        ; =0xffffffff
	b	LBB4_65
LBB4_64:                                ;   in Loop: Header=BB4_65 Depth=1
	add	x10, x10, #1
	subs	x9, x9, #1
	b.eq	LBB4_67
LBB4_65:                                ; =>This Inner Loop Header: Depth=1
	str	w13, [x0, x10, lsl #2]
	ldrb	w14, [x12], #16
	cbnz	w14, LBB4_64
; %bb.66:                               ;   in Loop: Header=BB4_65 Depth=1
	str	w10, [x20, w11, uxtw #2]
	str	w11, [x0, x10, lsl #2]
	add	w11, w11, #1
	b	LBB4_64
LBB4_67:
	ldr	q0, [sp]
	str	q0, [x19]
	str	w24, [x19, #40]
	str	x19, [x25]
	stp	xzr, xzr, [x8]
Lloh34:
	adrp	x9, l_.str.10@PAGE
Lloh35:
	add	x9, x9, l_.str.10@PAGEOFF
	b	LBB4_8
LBB4_68:
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [sp, #16]
	stp	w10, wzr, [sp, #24]
Lloh36:
	adrp	x8, l_.str.3@PAGE
Lloh37:
	add	x8, x8, l_.str.3@PAGEOFF
	b	LBB4_31
LBB4_69:
	mov	x10, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	and	x13, x13, #0xfffffff8
	add	x14, x0, #16
	add	x15, x12, #64
	mov	w16, #-1                        ; =0xffffffff
	b	LBB4_71
LBB4_70:                                ;   in Loop: Header=BB4_71 Depth=1
	add	x10, x10, #8
	add	x14, x14, #32
	add	x15, x15, #128
	cmp	x13, x10
	b.eq	LBB4_62
LBB4_71:                                ; =>This Inner Loop Header: Depth=1
	stur	w16, [x14, #-16]
	ldurb	w17, [x15, #-64]
	cbnz	w17, LBB4_73
; %bb.72:                               ;   in Loop: Header=BB4_71 Depth=1
	str	w10, [x20, w11, uxtw #2]
	stur	w11, [x14, #-16]
	add	w11, w11, #1
LBB4_73:                                ;   in Loop: Header=BB4_71 Depth=1
	stur	w16, [x14, #-12]
	ldurb	w17, [x15, #-48]
	cbnz	w17, LBB4_75
; %bb.74:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #1
	str	w17, [x20, w11, uxtw #2]
	stur	w11, [x14, #-12]
	add	w11, w11, #1
LBB4_75:                                ;   in Loop: Header=BB4_71 Depth=1
	stur	w16, [x14, #-8]
	ldurb	w17, [x15, #-32]
	cbnz	w17, LBB4_77
; %bb.76:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #2
	str	w17, [x20, w11, uxtw #2]
	stur	w11, [x14, #-8]
	add	w11, w11, #1
LBB4_77:                                ;   in Loop: Header=BB4_71 Depth=1
	stur	w16, [x14, #-4]
	ldurb	w17, [x15, #-16]
	cbnz	w17, LBB4_79
; %bb.78:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #3
	str	w17, [x20, w11, uxtw #2]
	stur	w11, [x14, #-4]
	add	w11, w11, #1
LBB4_79:                                ;   in Loop: Header=BB4_71 Depth=1
	str	w16, [x14]
	ldrb	w17, [x15]
	cbnz	w17, LBB4_81
; %bb.80:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #4
	str	w17, [x20, w11, uxtw #2]
	str	w11, [x14]
	add	w11, w11, #1
LBB4_81:                                ;   in Loop: Header=BB4_71 Depth=1
	str	w16, [x14, #4]
	ldrb	w17, [x15, #16]
	cbnz	w17, LBB4_83
; %bb.82:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #5
	str	w17, [x20, w11, uxtw #2]
	str	w11, [x14, #4]
	add	w11, w11, #1
LBB4_83:                                ;   in Loop: Header=BB4_71 Depth=1
	str	w16, [x14, #8]
	ldrb	w17, [x15, #32]
	cbnz	w17, LBB4_85
; %bb.84:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #6
	str	w17, [x20, w11, uxtw #2]
	str	w11, [x14, #8]
	add	w11, w11, #1
LBB4_85:                                ;   in Loop: Header=BB4_71 Depth=1
	str	w16, [x14, #12]
	ldrb	w17, [x15, #48]
	cbnz	w17, LBB4_70
; %bb.86:                               ;   in Loop: Header=BB4_71 Depth=1
	add	w17, w10, #7
	str	w17, [x20, w11, uxtw #2]
	str	w11, [x14, #12]
	add	w11, w11, #1
	b	LBB4_70
LBB4_87:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpAdrp	Lloh3, Lloh5
	.loh AdrpLdr	Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function record_preflight
lCPI5_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI5_1:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_record_preflight:                      ; @record_preflight
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #3168
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x21, x0
	mov	x19, x8
Lloh38:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh39:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh40:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	ldr	x1, [x0, #312]
	ldr	w2, [x0, #320]
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB5_2
; %bb.1:
Lloh41:
	adrp	x8, lCPI5_0@PAGE
Lloh42:
	ldr	q0, [x8, lCPI5_0@PAGEOFF]
	str	q0, [x19]
Lloh43:
	adrp	x8, l_.str.26@PAGE
Lloh44:
	add	x8, x8, l_.str.26@PAGEOFF
	b	LBB5_48
LBB5_2:
	ldr	w8, [sp, #52]
	cmp	w8, #256
	b.ls	LBB5_4
; %bb.3:
Lloh45:
	adrp	x8, lCPI5_1@PAGE
Lloh46:
	ldr	q0, [x8, lCPI5_1@PAGEOFF]
	str	q0, [x19]
Lloh47:
	adrp	x8, l_.str.40@PAGE
Lloh48:
	add	x8, x8, l_.str.40@PAGEOFF
	b	LBB5_48
LBB5_4:
	cbz	w8, LBB5_36
; %bb.5:
	str	x20, [sp, #8]                   ; 8-byte Folded Spill
	mov	x23, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
Lloh49:
	adrp	x8, l_.str.41@PAGE
Lloh50:
	add	x8, x8, l_.str.41@PAGEOFF
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w26, #1                         ; =0x1
LBB5_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_18 Depth 2
	add	x0, sp, #56
	add	x1, sp, #51
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_46
; %bb.7:                                ;   in Loop: Header=BB5_6 Depth=1
	add	x0, sp, #56
	add	x1, sp, #50
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_46
; %bb.8:                                ;   in Loop: Header=BB5_6 Depth=1
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u16
	cbnz	w0, LBB5_46
; %bb.9:                                ;   in Loop: Header=BB5_6 Depth=1
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	mov	w8, #2                          ; =0x2
	cbnz	w0, LBB5_47
; %bb.10:                               ;   in Loop: Header=BB5_6 Depth=1
	ldrb	w9, [sp, #50]
	cbnz	w9, LBB5_47
; %bb.11:                               ;   in Loop: Header=BB5_6 Depth=1
	ldrb	w9, [sp, #51]
	cmp	w9, #3
	b.hi	LBB5_47
; %bb.12:                               ;   in Loop: Header=BB5_6 Depth=1
	ldr	w8, [sp, #44]
	cmn	w8, #1
	b.eq	LBB5_14
; %bb.13:                               ;   in Loop: Header=BB5_6 Depth=1
	ldr	w10, [x21, #248]
	cmp	w8, w10
	b.hs	LBB5_46
LBB5_14:                                ;   in Loop: Header=BB5_6 Depth=1
	cmp	w9, #0
	cinc	w27, w27, eq
	cmp	w9, #3
	cinc	w25, w25, eq
	cmp	w9, #2
	cinc	w24, w24, eq
	ldrh	w28, [sp, #48]
	mov	w8, #65536                      ; =0x10000
	sub	w8, w8, w20
	cmp	w8, w28
	b.lo	LBB5_51
; %bb.15:                               ;   in Loop: Header=BB5_6 Depth=1
	str	w20, [sp, #28]                  ; 4-byte Folded Spill
	cmp	w9, #0
	cset	w8, eq
	ldr	x9, [sp, #72]
	add	x10, sp, #1104
	str	x9, [x10, x23, lsl #3]
	add	x9, sp, #80
	str	w28, [x9, x23, lsl #2]
	and	w26, w26, w8
	cbz	w28, LBB5_33
; %bb.16:                               ;   in Loop: Header=BB5_6 Depth=1
	mov	w20, #0                         ; =0x0
	b	LBB5_18
LBB5_17:                                ;   in Loop: Header=BB5_18 Depth=2
	cmn	w9, #1
	cset	w10, ne
	cmp	x23, x9
	csel	w11, wzr, w10, hs
	orr	w22, w11, w22
	sub	w11, w8, #1
	cmp	w11, #5
	ccmn	w9, #1, #0, lo
	cset	w9, eq
	cmp	w8, #8
	csel	w8, w10, w9, eq
	and	w26, w26, w8
	add	w20, w20, #1
	ldrh	w8, [sp, #48]
	cmp	w20, w8
	b.hs	LBB5_33
LBB5_18:                                ;   Parent Loop BB5_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #56
	add	x1, sp, #43
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_35
; %bb.19:                               ;   in Loop: Header=BB5_18 Depth=2
	add	x0, sp, #56
	add	x1, sp, #42
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_35
; %bb.20:                               ;   in Loop: Header=BB5_18 Depth=2
	add	x0, sp, #56
	add	x1, sp, #41
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_35
; %bb.21:                               ;   in Loop: Header=BB5_18 Depth=2
	add	x0, sp, #56
	add	x1, sp, #40
	bl	_nvm_v2_u8
	cbnz	w0, LBB5_35
; %bb.22:                               ;   in Loop: Header=BB5_18 Depth=2
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_35
; %bb.23:                               ;   in Loop: Header=BB5_18 Depth=2
	add	x0, sp, #56
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_35
; %bb.24:                               ;   in Loop: Header=BB5_18 Depth=2
	ldrb	w8, [sp, #42]
	cbnz	w8, LBB5_35
; %bb.25:                               ;   in Loop: Header=BB5_18 Depth=2
	ldrb	w8, [sp, #41]
	cbnz	w8, LBB5_35
; %bb.26:                               ;   in Loop: Header=BB5_18 Depth=2
	ldrb	w8, [sp, #40]
	cbnz	w8, LBB5_35
; %bb.27:                               ;   in Loop: Header=BB5_18 Depth=2
	ldrb	w8, [sp, #43]
	cmp	w8, #15
	b.hi	LBB5_35
; %bb.28:                               ;   in Loop: Header=BB5_18 Depth=2
	ldr	w9, [sp, #36]
	cmn	w9, #1
	b.eq	LBB5_31
; %bb.29:                               ;   in Loop: Header=BB5_18 Depth=2
	cmp	x23, x9
	b.eq	LBB5_35
; %bb.30:                               ;   in Loop: Header=BB5_18 Depth=2
	ldr	w10, [sp, #52]
	cmp	w9, w10
	b.hs	LBB5_35
LBB5_31:                                ;   in Loop: Header=BB5_18 Depth=2
	ldr	w10, [sp, #32]
	cmn	w10, #1
	b.eq	LBB5_17
; %bb.32:                               ;   in Loop: Header=BB5_18 Depth=2
	ldr	w11, [x21, #248]
	cmp	w10, w11
	b.lo	LBB5_17
	b	LBB5_35
LBB5_33:                                ;   in Loop: Header=BB5_6 Depth=1
	ldr	w20, [sp, #28]                  ; 4-byte Folded Reload
	add	w20, w20, w28
	add	x23, x23, #1
	ldr	w1, [sp, #52]
	cmp	x23, x1
	b.lo	LBB5_6
; %bb.34:
	ldr	x20, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB5_37
LBB5_35:
	mov	w8, #2                          ; =0x2
	stp	w8, w23, [x19]
	stp	w20, wzr, [x19, #8]
Lloh51:
	adrp	x8, l_.str.43@PAGE
Lloh52:
	add	x8, x8, l_.str.43@PAGEOFF
	b	LBB5_48
LBB5_36:
	mov	w1, #0                          ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w26, #1                         ; =0x1
LBB5_37:
	ldp	x9, x8, [sp, #64]
	cmp	x8, x9
	b.ne	LBB5_45
; %bb.38:
	ldr	w8, [x21, #468]
	cmp	w27, w8
	b.ne	LBB5_45
; %bb.39:
	ldr	w8, [x21, #472]
	cmp	w25, w8
	b.ne	LBB5_45
; %bb.40:
	ldr	w8, [x21, #476]
	cmp	w24, w8
	b.ne	LBB5_45
; %bb.41:
	tbz	w22, #0, LBB5_44
; %bb.42:
	tbz	w26, #0, LBB5_52
; %bb.43:
	add	x2, sp, #1104
	add	x3, sp, #80
	mov	x8, x19
	mov	x0, x21
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_record_forward_preflight
	ldr	w8, [x19]
	cbnz	w8, LBB5_49
LBB5_44:
	and	w8, w22, #0x1
	strb	w8, [x20]
	stp	xzr, xzr, [x19]
Lloh53:
	adrp	x8, l_.str.46@PAGE
Lloh54:
	add	x8, x8, l_.str.46@PAGEOFF
	b	LBB5_48
LBB5_45:
Lloh55:
	adrp	x8, lCPI5_0@PAGE
Lloh56:
	ldr	q0, [x8, lCPI5_0@PAGEOFF]
	str	q0, [x19]
Lloh57:
	adrp	x8, l_.str.44@PAGE
Lloh58:
	add	x8, x8, l_.str.44@PAGEOFF
	b	LBB5_48
LBB5_46:
	mov	w8, #2                          ; =0x2
LBB5_47:
	stp	w8, w23, [x19]
	str	xzr, [x19, #8]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
LBB5_48:
	str	x8, [x19, #16]
LBB5_49:
	ldur	x8, [x29, #-96]
Lloh59:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh60:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh61:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_53
; %bb.50:
	add	sp, sp, #3168
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB5_51:
	mov	w8, #3                          ; =0x3
Lloh62:
	adrp	x9, l_.str.42@PAGE
Lloh63:
	add	x9, x9, l_.str.42@PAGEOFF
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB5_47
LBB5_52:
Lloh64:
	adrp	x8, lCPI5_0@PAGE
Lloh65:
	ldr	q0, [x8, lCPI5_0@PAGEOFF]
	str	q0, [x19]
Lloh66:
	adrp	x8, l_.str.45@PAGE
Lloh67:
	add	x8, x8, l_.str.45@PAGEOFF
	b	LBB5_48
LBB5_53:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh38, Lloh39, Lloh40
	.loh AdrpAdd	Lloh43, Lloh44
	.loh AdrpAdrp	Lloh41, Lloh43
	.loh AdrpLdr	Lloh41, Lloh42
	.loh AdrpAdd	Lloh47, Lloh48
	.loh AdrpAdrp	Lloh45, Lloh47
	.loh AdrpLdr	Lloh45, Lloh46
	.loh AdrpAdd	Lloh49, Lloh50
	.loh AdrpAdd	Lloh51, Lloh52
	.loh AdrpAdd	Lloh53, Lloh54
	.loh AdrpAdd	Lloh57, Lloh58
	.loh AdrpAdrp	Lloh55, Lloh57
	.loh AdrpLdr	Lloh55, Lloh56
	.loh AdrpLdrGotLdr	Lloh59, Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_mixed_layout_view_free ; -- Begin function nvm_mixed_layout_view_free
	.globl	_nvm_mixed_layout_view_free
	.p2align	2
_nvm_mixed_layout_view_free:            ; @nvm_mixed_layout_view_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #5144]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB6_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_describe_mixed_layouts
lCPI7_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI7_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI7_2:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI7_3:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_describe_mixed_layouts
	.globl	_nvm_describe_mixed_layouts
	.p2align	2
_nvm_describe_mixed_layouts:            ; @nvm_describe_mixed_layouts
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #848
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh68:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh69:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh70:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
	cbz	x0, LBB7_7
; %bb.1:
	cbz	x1, LBB7_7
; %bb.2:
	ldr	x10, [x0, #312]
	ldr	w9, [x0, #320]
	cmp	w9, #0
	cset	w11, eq
	cmp	x10, #0
	cset	w10, ne
	cmp	w10, w11
	b.eq	LBB7_7
; %bb.3:
	ldr	x10, [x0, #296]
	cmp	x10, #0
	cset	w11, eq
	ldr	w10, [x0, #304]
	cmp	w10, #0
	cset	w12, ne
	eor	w11, w11, w12
	tbz	w11, #0, LBB7_7
; %bb.4:
	cbz	w9, LBB7_11
; %bb.5:
	mov	w9, #1                          ; =0x1
	movk	w9, #256, lsl #16
	cmp	w10, w9
	b.lo	LBB7_12
; %bb.6:
Lloh71:
	adrp	x9, lCPI7_2@PAGE
Lloh72:
	ldr	q0, [x9, lCPI7_2@PAGEOFF]
	str	q0, [x8]
Lloh73:
	adrp	x9, l_.str.13@PAGE
Lloh74:
	add	x9, x9, l_.str.13@PAGEOFF
	b	LBB7_8
LBB7_7:
Lloh75:
	adrp	x9, lCPI7_0@PAGE
Lloh76:
	ldr	q0, [x9, lCPI7_0@PAGEOFF]
	str	q0, [x8]
Lloh77:
	adrp	x9, l_.str.11@PAGE
Lloh78:
	add	x9, x9, l_.str.11@PAGEOFF
LBB7_8:
	str	x9, [x8, #16]
LBB7_9:
	ldur	x8, [x29, #-72]
Lloh79:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh80:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh81:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_64
; %bb.10:
	add	sp, sp, #848
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB7_11:
Lloh82:
	adrp	x9, lCPI7_3@PAGE
Lloh83:
	ldr	q0, [x9, lCPI7_3@PAGEOFF]
	str	q0, [x8]
Lloh84:
	adrp	x9, l_.str.12@PAGE
Lloh85:
	add	x9, x9, l_.str.12@PAGEOFF
	b	LBB7_8
LBB7_12:
	mov	x23, x1
	mov	x22, x8
	add	x8, sp, #32
	add	x1, sp, #63
	mov	x19, x0
	bl	_record_preflight
	ldr	w8, [sp, #32]
	cbz	w8, LBB7_14
LBB7_13:
	ldr	q0, [sp, #32]
	str	q0, [x22]
	ldr	x8, [sp, #48]
	str	x8, [x22, #16]
	b	LBB7_9
LBB7_14:
	ldr	x1, [x19, #312]
	ldr	w2, [x19, #320]
	add	x0, sp, #8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB7_16
; %bb.15:
Lloh86:
	adrp	x8, lCPI7_0@PAGE
Lloh87:
	ldr	q0, [x8, lCPI7_0@PAGEOFF]
	str	q0, [x22]
Lloh88:
	adrp	x8, l_.str.14@PAGE
Lloh89:
	add	x8, x8, l_.str.14@PAGEOFF
	str	x8, [x22, #16]
	b	LBB7_9
LBB7_16:
	add	x24, sp, #64
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #736]
	stp	q0, q0, [x24, #704]
	stp	q0, q0, [x24, #672]
	stp	q0, q0, [x24, #640]
	stp	q0, q0, [x24, #608]
	stp	q0, q0, [x24, #576]
	stp	q0, q0, [x24, #544]
	stp	q0, q0, [x24, #512]
	ldr	w1, [sp, #4]
	add	x3, sp, #576
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_mixed_ownership_read
	tbz	w0, #0, LBB7_20
; %bb.17:
	mov	w0, #1                          ; =0x1
	mov	w1, #5160                       ; =0x1428
	bl	_calloc
	cbz	x0, LBB7_21
; %bb.18:
	mov	x20, x0
	ldr	x0, [x19, #312]
	ldr	w1, [x19, #320]
	mov	x2, x20
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB7_22
; %bb.19:
	mov	w8, #2                          ; =0x2
	mov	w9, #4                          ; =0x4
	cmp	w0, #1
	csel	w8, w9, w8, eq
Lloh90:
	adrp	x24, l_.str.17@PAGE
Lloh91:
	add	x24, x24, l_.str.17@PAGEOFF
	b	LBB7_30
LBB7_20:
Lloh92:
	adrp	x8, lCPI7_0@PAGE
Lloh93:
	ldr	q0, [x8, lCPI7_0@PAGEOFF]
	str	q0, [x22]
Lloh94:
	adrp	x8, l_.str.15@PAGE
Lloh95:
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [x22, #16]
	b	LBB7_9
LBB7_21:
Lloh96:
	adrp	x8, lCPI7_1@PAGE
Lloh97:
	ldr	q0, [x8, lCPI7_1@PAGEOFF]
	str	q0, [x22]
Lloh98:
	adrp	x8, l_.str.16@PAGE
Lloh99:
	add	x8, x8, l_.str.16@PAGEOFF
	str	x8, [x22, #16]
	b	LBB7_9
LBB7_22:
	ldr	w1, [sp, #4]
	add	x3, sp, #576
	mov	x0, x19
	mov	x2, x20
	bl	_mixed_ownership_read
	cbz	w0, LBB7_28
; %bb.23:
	ldr	w25, [sp, #4]
	cbz	w25, LBB7_34
; %bb.24:
	mov	x9, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	add	x10, sp, #576
LBB7_25:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10, x9]
	orr	w8, w8, w11, lsr #1
	and	w8, w8, #0x1
	add	x9, x9, #1
	cmp	x25, x9
	b.ne	LBB7_25
; %bb.26:
	cbz	w8, LBB7_31
; %bb.27:
	ldrb	w8, [sp, #63]
	tbz	w8, #0, LBB7_31
LBB7_28:
Lloh100:
	adrp	x24, l_.str.20@PAGE
Lloh101:
	add	x24, x24, l_.str.20@PAGEOFF
LBB7_29:
	mov	w8, #2                          ; =0x2
LBB7_30:
	stp	w8, wzr, [sp, #32]
	stp	xzr, x24, [sp, #40]
	mov	x0, x20
	bl	_nvm_mixed_layout_view_free
	b	LBB7_13
LBB7_31:
	mov	w21, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #480]
	stp	q0, q0, [x24, #448]
	stp	q0, q0, [x24, #416]
	stp	q0, q0, [x24, #384]
	stp	q0, q0, [x24, #352]
	stp	q0, q0, [x24, #320]
	stp	q0, q0, [x24, #288]
	stp	q0, q0, [x24, #256]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [x24, #80]
	stp	q0, q0, [x24, #112]
	stp	q0, q0, [x24, #144]
	stp	q0, q0, [x24, #176]
	stp	q0, q0, [x24, #208]
	str	q0, [x24, #240]
Lloh102:
	adrp	x24, l_.str.20@PAGE
Lloh103:
	add	x24, x24, l_.str.20@PAGEOFF
	str	q0, [sp, #128]
LBB7_32:                                ; =>This Inner Loop Header: Depth=1
	add	x2, sp, #576
	add	x3, sp, #320
	add	x4, sp, #64
	mov	x0, x20
	mov	x1, x21
	bl	_mixed_classify
	tbz	w0, #0, LBB7_29
; %bb.33:                               ;   in Loop: Header=BB7_32 Depth=1
	add	w21, w21, #1
	cmp	w25, w21
	b.ne	LBB7_32
LBB7_34:
	add	x21, x20, #24
	add	x24, x20, #2072
	mov	x0, x21
	mov	w1, #255                        ; =0xff
	mov	w2, #1024                       ; =0x400
	bl	_memset
	mov	x8, #0                          ; =0x0
	movi.2d	v0, #0xffffffffffffffff
LBB7_35:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x20, x8
	add	x10, x9, #1048
	str	q0, [x10]
	add	x10, x9, #1064
	str	q0, [x10]
	add	x10, x9, #1080
	add	x11, x9, #1096
	str	q0, [x10]
	str	q0, [x11]
	add	x10, x9, #3096
	add	x11, x9, #3112
	add	x12, x9, #3128
	add	x13, x9, #3144
	str	q0, [x10]
	str	q0, [x11]
	str	q0, [x12]
	str	q0, [x13]
	add	x10, x9, #2072
	add	x11, x9, #2088
	add	x12, x9, #2104
	add	x9, x9, #2120
	str	q0, [x10]
	str	q0, [x11]
	str	q0, [x12]
	add	x8, x8, #64
	str	q0, [x9]
	cmp	x8, #1024
	b.ne	LBB7_35
; %bb.36:
	mov	x11, x22
	mov	x12, x23
	mov	x13, x19
	cbz	w25, LBB7_45
; %bb.37:
	ldr	x10, [x20]
	and	x8, x25, #0x3
	cmp	w25, #4
	b.hs	LBB7_49
; %bb.38:
	mov	x9, #0                          ; =0x0
LBB7_39:
	mov	x11, x22
	mov	x12, x23
	mov	x13, x19
	cbz	x8, LBB7_45
; %bb.40:
	add	x14, x20, x9, lsl #2
	add	x10, x10, x9, lsl #4
	b	LBB7_42
LBB7_41:                                ;   in Loop: Header=BB7_42 Depth=1
	add	x14, x14, #4
	add	w9, w9, #1
	subs	x8, x8, #1
	b.eq	LBB7_45
LBB7_42:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w15, [x10], #16
	cbnz	w15, LBB7_41
; %bb.43:                               ;   in Loop: Header=BB7_42 Depth=1
	ldr	w15, [x20, #16]
	str	w15, [x14, #1048]
	add	w16, w15, #1
	str	w16, [x20, #16]
	str	w9, [x21, x15, lsl #2]
	ldr	w15, [x14, #4120]
	cmp	w15, #2
	b.ne	LBB7_41
; %bb.44:                               ;   in Loop: Header=BB7_42 Depth=1
	ldr	w15, [x20, #20]
	str	w15, [x14, #3096]
	add	w16, w15, #1
	str	w16, [x20, #20]
	str	w9, [x24, x15, lsl #2]
	b	LBB7_41
LBB7_45:
	ldr	w21, [x13, #304]
	cbz	w21, LBB7_48
; %bb.46:
	mov	x0, x21
	bl	_malloc
	str	x0, [x20, #5144]
	cbz	x0, LBB7_63
; %bb.47:
	ldr	x1, [x19, #296]
	mov	x2, x21
	bl	_memcpy
	str	w21, [x20, #5152]
	mov	x11, x22
	mov	x12, x23
LBB7_48:
	str	x20, [x12]
	stp	xzr, xzr, [x11]
Lloh104:
	adrp	x8, l_.str.19@PAGE
Lloh105:
	add	x8, x8, l_.str.19@PAGEOFF
	str	x8, [x11, #16]
	b	LBB7_9
LBB7_49:
	mov	x9, #0                          ; =0x0
	and	x11, x25, #0xfffffffc
	add	x12, x10, #32
	mov	w13, #3096                      ; =0xc18
	b	LBB7_51
LBB7_50:                                ;   in Loop: Header=BB7_51 Depth=1
	add	x12, x12, #64
	add	x9, x9, #4
	add	x13, x13, #16
	cmp	x11, x9
	b.eq	LBB7_39
LBB7_51:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w14, [x12, #-32]
	cbnz	w14, LBB7_54
; %bb.52:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w14, [x20, #16]
	add	x15, x20, x9, lsl #2
	str	w14, [x15, #1048]
	add	w15, w14, #1
	str	w15, [x20, #16]
	str	w9, [x21, x14, lsl #2]
	add	x14, x20, x13
	ldr	w14, [x14, #1024]
	cmp	w14, #2
	b.ne	LBB7_54
; %bb.53:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w14, [x20, #20]
	str	w14, [x20, x13]
	add	w15, w14, #1
	str	w15, [x20, #20]
	str	w9, [x24, x14, lsl #2]
LBB7_54:                                ;   in Loop: Header=BB7_51 Depth=1
	ldurb	w14, [x12, #-16]
	cbnz	w14, LBB7_57
; %bb.55:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w15, [x20, #16]
	add	x14, x20, x9, lsl #2
	str	w15, [x14, #1052]
	add	w14, w15, #1
	str	w14, [x20, #16]
	add	x14, x9, #1
	str	w14, [x21, x15, lsl #2]
	add	x15, x20, x13
	ldr	w16, [x15, #1028]
	cmp	w16, #2
	b.ne	LBB7_57
; %bb.56:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w16, [x20, #20]
	str	w16, [x15, #4]
	add	w15, w16, #1
	str	w15, [x20, #20]
	str	w14, [x24, x16, lsl #2]
LBB7_57:                                ;   in Loop: Header=BB7_51 Depth=1
	ldrb	w14, [x12]
	cbnz	w14, LBB7_60
; %bb.58:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w15, [x20, #16]
	add	x14, x20, x9, lsl #2
	str	w15, [x14, #1056]
	add	w14, w15, #1
	str	w14, [x20, #16]
	add	x14, x9, #2
	str	w14, [x21, x15, lsl #2]
	add	x15, x20, x13
	ldr	w16, [x15, #1032]
	cmp	w16, #2
	b.ne	LBB7_60
; %bb.59:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w16, [x20, #20]
	str	w16, [x15, #8]
	add	w15, w16, #1
	str	w15, [x20, #20]
	str	w14, [x24, x16, lsl #2]
LBB7_60:                                ;   in Loop: Header=BB7_51 Depth=1
	ldrb	w14, [x12, #16]
	cbnz	w14, LBB7_50
; %bb.61:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w15, [x20, #16]
	add	x14, x20, x9, lsl #2
	str	w15, [x14, #1060]
	add	w14, w15, #1
	str	w14, [x20, #16]
	add	x14, x9, #3
	str	w14, [x21, x15, lsl #2]
	add	x15, x20, x13
	ldr	w16, [x15, #1036]
	cmp	w16, #2
	b.ne	LBB7_50
; %bb.62:                               ;   in Loop: Header=BB7_51 Depth=1
	ldr	w16, [x20, #20]
	str	w16, [x15, #12]
	add	w15, w16, #1
	str	w15, [x20, #20]
	str	w14, [x24, x16, lsl #2]
	b	LBB7_50
LBB7_63:
Lloh106:
	adrp	x24, l_.str.18@PAGE
Lloh107:
	add	x24, x24, l_.str.18@PAGEOFF
	mov	w8, #4                          ; =0x4
	b	LBB7_30
LBB7_64:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh68, Lloh69, Lloh70
	.loh AdrpAdd	Lloh73, Lloh74
	.loh AdrpAdrp	Lloh71, Lloh73
	.loh AdrpLdr	Lloh71, Lloh72
	.loh AdrpAdd	Lloh77, Lloh78
	.loh AdrpAdrp	Lloh75, Lloh77
	.loh AdrpLdr	Lloh75, Lloh76
	.loh AdrpLdrGotLdr	Lloh79, Lloh80, Lloh81
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh98
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mixed_ownership_read
_mixed_ownership_read:                  ; @mixed_ownership_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x2
	ldr	w2, [x0, #304]
	cbz	w2, LBB8_7
; %bb.1:
	mov	x19, x1
	mov	x23, x3
	mov	x24, x0
	ldr	x1, [x0, #296]
	add	x0, sp, #88
	bl	_nvm_v2_cursor_init
	add	x0, sp, #88
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_6
; %bb.2:
	ldr	w8, [sp, #84]
	sub	w8, w8, #3
	cmn	w8, #2
	b.lo	LBB8_6
; %bb.3:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB8_8
; %bb.4:
	ldr	w8, [sp, #80]
	cmp	w8, w19
	b.ne	LBB8_8
; %bb.5:
	mov	w1, w19
	add	x0, sp, #88
	add	x2, sp, #72
	bl	_nvm_v2_take
	cbz	w0, LBB8_9
LBB8_6:
	mov	w0, #0                          ; =0x0
	b	LBB8_8
LBB8_7:
	mov	w0, #1                          ; =0x1
LBB8_8:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB8_9:
	ldr	x1, [sp, #72]
	ldr	w21, [sp, #80]
	mov	x22, x23
	mov	x0, x23
	mov	x2, x21
	bl	_memcpy
	cbz	w21, LBB8_13
LBB8_10:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x22], #1
	cmp	w9, #3
	b.hi	LBB8_6
; %bb.11:                               ;   in Loop: Header=BB8_10 Depth=1
	and	w10, w9, #0x1
	cmp	w9, #2
	ccmp	w10, #0, #0, hs
	b.eq	LBB8_6
; %bb.12:                               ;   in Loop: Header=BB8_10 Depth=1
	subs	x21, x21, #1
	b.ne	LBB8_10
LBB8_13:
	add	x0, sp, #88
	bl	_nvm_v2_align4
	cbnz	w0, LBB8_6
; %bb.14:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_6
; %bb.15:
	ldr	w9, [sp, #80]
	ldr	w10, [x24, #272]
	cmp	w9, w10
	b.ne	LBB8_6
; %bb.16:
	cbz	w9, LBB8_58
; %bb.17:
	mov	x8, x24
	ldr	x9, [x24, #256]
	cbz	x9, LBB8_6
; %bb.18:
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
	mov	w22, #24                        ; =0x18
LBB8_19:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_28 Depth 2
	ldr	x21, [x8, #256]
	add	x0, sp, #88
	add	x1, sp, #70
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.20:                               ;   in Loop: Header=BB8_19 Depth=1
	add	x0, sp, #88
	add	x1, sp, #68
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.21:                               ;   in Loop: Header=BB8_19 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	madd	x26, x8, x22, x21
	ldrh	w8, [sp, #70]
	ldrh	w9, [x26, #16]
	cmp	w8, w9
	b.ne	LBB8_6
; %bb.22:                               ;   in Loop: Header=BB8_19 Depth=1
	ldrh	w9, [sp, #68]
	cmp	w9, w8
	b.hi	LBB8_6
; %bb.23:                               ;   in Loop: Header=BB8_19 Depth=1
	ldrh	w8, [x26, #4]
	cmp	w9, w8
	b.ne	LBB8_6
; %bb.24:                               ;   in Loop: Header=BB8_19 Depth=1
	ldrb	w8, [x26, #21]
	cmp	w8, #1
	b.hi	LBB8_6
; %bb.25:                               ;   in Loop: Header=BB8_19 Depth=1
	mov	x27, #0                         ; =0x0
	mov	x8, #-1                         ; =0xffffffffffffffff
	b	LBB8_28
LBB8_26:                                ;   in Loop: Header=BB8_28 Depth=2
	cbnz	w8, LBB8_6
LBB8_27:                                ;   in Loop: Header=BB8_28 Depth=2
	ldrh	w9, [sp, #70]
	mov	x8, x28
	cmp	x27, x9
	add	x27, x27, #1
	b.hs	LBB8_57
LBB8_28:                                ;   Parent Loop BB8_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	adds	x28, x8, #1
	mov	x9, x24
	b.lo	LBB8_31
; %bb.29:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrb	w10, [x26, #21]
	cbz	w10, LBB8_32
; %bb.30:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrb	w25, [x26, #20]
	b	LBB8_33
LBB8_31:                                ;   in Loop: Header=BB8_28 Depth=2
	mov	w25, #-1                        ; =0xffffffff
	b	LBB8_33
LBB8_32:                                ;   in Loop: Header=BB8_28 Depth=2
	mov	w25, #0                         ; =0x0
LBB8_33:                                ;   in Loop: Header=BB8_28 Depth=2
	ldrh	w10, [sp, #68]
	sub	x22, x27, #1
	and	x21, x10, #0xffff
	cmp	x22, x21
	b.hs	LBB8_38
; %bb.34:                               ;   in Loop: Header=BB8_28 Depth=2
	ldr	x9, [x9, #264]
	cbz	x9, LBB8_37
; %bb.35:                               ;   in Loop: Header=BB8_28 Depth=2
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [x9, x10, lsl #3]
	cbz	x9, LBB8_37
; %bb.36:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrb	w25, [x9, x8]
	b	LBB8_38
LBB8_37:                                ;   in Loop: Header=BB8_28 Depth=2
	mov	w25, #0                         ; =0x0
LBB8_38:                                ;   in Loop: Header=BB8_28 Depth=2
	add	x0, sp, #88
	add	x1, sp, #67
	bl	_nvm_v2_u8
	cbnz	w0, LBB8_6
; %bb.39:                               ;   in Loop: Header=BB8_28 Depth=2
	add	x0, sp, #88
	add	x1, sp, #66
	bl	_nvm_v2_u8
	cbnz	w0, LBB8_6
; %bb.40:                               ;   in Loop: Header=BB8_28 Depth=2
	add	x0, sp, #88
	add	x1, sp, #64
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.41:                               ;   in Loop: Header=BB8_28 Depth=2
	add	x0, sp, #88
	add	x1, sp, #60
	bl	_nvm_v2_u32
	ldrb	w8, [sp, #66]
	cmp	w8, #0
	cset	w9, ne
	cmp	w8, #2
	cset	w10, hi
	cmp	x22, x21
	csel	w10, w10, w9, lo
	cbnz	w0, LBB8_6
; %bb.42:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrh	w9, [sp, #64]
	cbnz	w9, LBB8_6
; %bb.43:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrb	w9, [sp, #67]
	cmp	w9, #15
	b.hi	LBB8_6
; %bb.44:                               ;   in Loop: Header=BB8_28 Depth=2
	tbnz	w10, #0, LBB8_6
; %bb.45:                               ;   in Loop: Header=BB8_28 Depth=2
	tbnz	w25, #31, LBB8_47
; %bb.46:                               ;   in Loop: Header=BB8_28 Depth=2
	cmp	w25, w9
	b.ne	LBB8_6
LBB8_47:                                ;   in Loop: Header=BB8_28 Depth=2
	ldr	w1, [sp, #60]
	cmn	w1, #1
	b.eq	LBB8_26
; %bb.48:                               ;   in Loop: Header=BB8_28 Depth=2
	cmp	w1, w19
	b.hs	LBB8_6
; %bb.49:                               ;   in Loop: Header=BB8_28 Depth=2
	cmp	w9, #8
	b.ne	LBB8_6
; %bb.50:                               ;   in Loop: Header=BB8_28 Depth=2
	ldrb	w9, [x23, x1]
	tbz	w9, #0, LBB8_6
; %bb.51:                               ;   in Loop: Header=BB8_28 Depth=2
	cbz	x20, LBB8_53
; %bb.52:                               ;   in Loop: Header=BB8_28 Depth=2
	ldr	x10, [x20]
	lsl	x11, x1, #4
	ldrb	w10, [x10, x11]
	cbnz	w10, LBB8_6
LBB8_53:                                ;   in Loop: Header=BB8_28 Depth=2
	cbz	w8, LBB8_27
; %bb.54:                               ;   in Loop: Header=BB8_28 Depth=2
	tbz	w9, #1, LBB8_6
; %bb.55:                               ;   in Loop: Header=BB8_28 Depth=2
	cbz	x20, LBB8_27
; %bb.56:                               ;   in Loop: Header=BB8_28 Depth=2
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #16]
	stp	wzr, w1, [sp, #24]
	str	xzr, [sp, #32]
	stp	wzr, w1, [sp, #40]
	stp	w8, wzr, [sp, #48]
	add	x2, sp, #16
	mov	x0, x20
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_reference_place_valid
	cbnz	w0, LBB8_27
	b	LBB8_6
LBB8_57:                                ;   in Loop: Header=BB8_19 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x9, x9, #1
	ldr	w8, [sp, #80]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	cmp	x9, x8
	mov	x8, x24
	mov	w22, #24                        ; =0x18
	b.lo	LBB8_19
LBB8_58:
	ldr	w8, [sp, #84]
	cmp	w8, #2
	b.ne	LBB8_72
; %bb.59:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB8_8
; %bb.60:
	ldr	w8, [sp, #80]
	cmp	w8, #256
	b.hi	LBB8_8
; %bb.61:
	cbz	w8, LBB8_72
; %bb.62:
	mov	w19, #0                         ; =0x0
LBB8_63:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_68 Depth 2
	add	x0, sp, #88
	add	x1, sp, #16
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.64:                               ;   in Loop: Header=BB8_63 Depth=1
	add	x0, sp, #88
	add	x1, sp, #60
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.65:                               ;   in Loop: Header=BB8_63 Depth=1
	ldrh	w8, [sp, #60]
	cbnz	w8, LBB8_6
; %bb.66:                               ;   in Loop: Header=BB8_63 Depth=1
	ldrh	w8, [sp, #16]
	sub	w8, w8, #33
	cmn	w8, #32
	b.lo	LBB8_6
; %bb.67:                               ;   in Loop: Header=BB8_63 Depth=1
	mov	w20, #0                         ; =0x0
LBB8_68:                                ;   Parent Loop BB8_63 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #88
	add	x1, sp, #70
	bl	_nvm_v2_u16
	cbnz	w0, LBB8_6
; %bb.69:                               ;   in Loop: Header=BB8_68 Depth=2
	add	w20, w20, #1
	ldrh	w8, [sp, #16]
	cmp	w20, w8
	b.lo	LBB8_68
; %bb.70:                               ;   in Loop: Header=BB8_63 Depth=1
	add	x0, sp, #88
	bl	_nvm_v2_align4
	cbnz	w0, LBB8_6
; %bb.71:                               ;   in Loop: Header=BB8_63 Depth=1
	add	w19, w19, #1
	ldr	w8, [sp, #80]
	cmp	w19, w8
	b.lo	LBB8_63
LBB8_72:
	ldp	x9, x8, [sp, #96]
	cmp	x8, x9
	cset	w0, eq
	b	LBB8_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mixed_classify
_mixed_classify:                        ; @mixed_classify
	.cfi_startproc
; %bb.0:
	mov	w9, w1
	ldrb	w8, [x3, x9]
	cmp	w8, #2
	b.eq	LBB9_3
; %bb.1:
	cmp	w8, #1
	b.ne	LBB9_4
; %bb.2:
	mov	w0, #0                          ; =0x0
	ret
LBB9_3:
	mov	w0, #1                          ; =0x1
	ret
LBB9_4:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w8, #1                          ; =0x1
	strb	w8, [x3, x9]
	ldr	x8, [x0]
	add	x20, x8, x9, lsl #4
	ldrb	w24, [x2, x9]
	tst	w24, #0x1
	cset	w15, eq
	ldrb	w8, [x20]
	tbz	w24, #0, LBB9_7
; %bb.5:
	cbz	w8, LBB9_9
LBB9_6:
	mov	w8, #0                          ; =0x0
	b	LBB9_32
LBB9_7:
	cbz	w8, LBB9_9
; %bb.8:
	mov	w8, #2                          ; =0x2
	strb	w8, [x3, x9]
	b	LBB9_31
LBB9_9:
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	ldrh	w9, [x20, #2]
	cbz	w9, LBB9_27
; %bb.10:
	mov	x25, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	mov	w8, #4120                       ; =0x1018
	add	x8, x0, x8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	b	LBB9_14
LBB9_11:                                ;   in Loop: Header=BB9_14 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, x19, lsl #2]
	cmp	w8, #0
	cset	w12, eq
	cmp	w8, #3
	cset	w11, eq
	mov	x4, x23
	ldrb	w8, [x23, x19]
	cmp	w8, #0
	cset	w10, ne
	ldrh	w9, [x20, #2]
	mov	x3, x21
	mov	x0, x27
	mov	x8, x28
	ldp	w15, w16, [sp, #24]             ; 8-byte Folded Reload
LBB9_12:                                ;   in Loop: Header=BB9_14 Depth=1
	orr	w15, w15, w12
	orr	w16, w16, w11
	and	w8, w8, w10
LBB9_13:                                ;   in Loop: Header=BB9_14 Depth=1
	add	x26, x26, #1
	add	x25, x25, #12
	cmp	x26, w9, uxtw
	b.hs	LBB9_28
LBB9_14:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20, #8]
	add	x10, x10, x25
	ldr	w19, [x10, #4]
	ldrb	w11, [x10]
	cmp	w11, #8
	b.ne	LBB9_21
; %bb.15:                               ;   in Loop: Header=BB9_14 Depth=1
	cmn	w19, #1
	b.eq	LBB9_25
; %bb.16:                               ;   in Loop: Header=BB9_14 Depth=1
	ldr	x9, [x0]
	lsl	x10, x19, #4
	ldrb	w9, [x9, x10]
	cbnz	w9, LBB9_6
; %bb.17:                               ;   in Loop: Header=BB9_14 Depth=1
	stp	w15, w16, [sp, #24]             ; 8-byte Folded Spill
	mov	x28, x8
	mov	x27, x0
	mov	x1, x19
	mov	x22, x2
	mov	x21, x3
	mov	x23, x4
	bl	_mixed_classify
	cbz	w0, LBB9_6
; %bb.18:                               ;   in Loop: Header=BB9_14 Depth=1
	mov	x2, x22
	tbz	w24, #0, LBB9_11
; %bb.19:                               ;   in Loop: Header=BB9_14 Depth=1
	tbnz	w24, #1, LBB9_11
; %bb.20:                               ;   in Loop: Header=BB9_14 Depth=1
	ldrb	w8, [x2, x19]
	tbz	w8, #1, LBB9_11
	b	LBB9_6
LBB9_21:                                ;   in Loop: Header=BB9_14 Depth=1
	cmn	w19, #1
	b.eq	LBB9_24
; %bb.22:                               ;   in Loop: Header=BB9_14 Depth=1
	cmp	w11, #9
	b.ne	LBB9_6
; %bb.23:                               ;   in Loop: Header=BB9_14 Depth=1
	ldr	x10, [x0]
	lsl	x12, x19, #4
	ldrb	w10, [x10, x12]
	cmp	w10, #3
	b.ne	LBB9_6
LBB9_24:                                ;   in Loop: Header=BB9_14 Depth=1
	sub	w10, w11, #1
	cmp	w10, #4
	cset	w10, lo
	sub	w12, w11, #6
	cmp	w11, #7
	cset	w11, eq
	cset	w13, ne
	cmn	w12, #5
	csel	w12, wzr, w13, hs
	b	LBB9_12
LBB9_25:                                ;   in Loop: Header=BB9_14 Depth=1
	mov	w8, #0                          ; =0x0
	tbnz	w24, #0, LBB9_32
; %bb.26:                               ;   in Loop: Header=BB9_14 Depth=1
	mov	w15, #1                         ; =0x1
	b	LBB9_13
LBB9_27:
	mov	w16, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
LBB9_28:
	tbz	w24, #1, LBB9_30
; %bb.29:
	orn	w9, w15, w8
	orr	w9, w9, w16
	tbnz	w9, #0, LBB9_6
LBB9_30:
	and	w8, w24, w8
	eor	w9, w15, #0x1
	and	w8, w8, w9
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	strb	w8, [x4, x11]
	tst	w16, #0x1
	mov	w8, #2                          ; =0x2
	cinc	w9, w8, ne
	tst	w24, #0x2
	csinc	w9, w9, wzr, eq
	tst	w15, #0x1
	csel	w9, wzr, w9, ne
	add	x10, x0, x11, lsl #2
	str	w9, [x10, #4120]
	strb	w8, [x3, x11]
LBB9_31:
	mov	w8, #1                          ; =0x1
LBB9_32:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_layouts_free ; -- Begin function nvm_owned_array_layouts_free
	.globl	_nvm_owned_array_layouts_free
	.p2align	2
_nvm_owned_array_layouts_free:          ; @nvm_owned_array_layouts_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #10272]
	bl	_free
	ldr	x0, [x19, #10280]
	bl	_free
	ldr	x0, [x19, #10288]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB10_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_describe_owned_array_layouts
lCPI11_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI11_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI11_2:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI11_3:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_describe_owned_array_layouts
	.globl	_nvm_describe_owned_array_layouts
	.p2align	2
_nvm_describe_owned_array_layouts:      ; @nvm_describe_owned_array_layouts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #352]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #368]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #384]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh108:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh109:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh110:
	ldr	x9, [x9]
	stur	x9, [x29, #-88]
	cbz	x0, LBB11_7
; %bb.1:
	cbz	x1, LBB11_7
; %bb.2:
	ldr	x9, [x0, #312]
	cmp	x9, #0
	cset	w9, eq
	ldr	w10, [x0, #320]
	cmp	w10, #0
	cset	w10, ne
	cmp	w9, w10
	b.eq	LBB11_7
; %bb.3:
	ldr	x9, [x0, #296]
	cmp	x9, #0
	cset	w9, eq
	ldr	w10, [x0, #304]
	cmp	w10, #0
	cset	w10, ne
	eor	w9, w9, w10
	tbz	w9, #0, LBB11_7
; %bb.4:
	mov	x26, x1
	mov	x25, x8
	mov	x19, x0
	bl	_nvm_service_execution_pending
	cbz	w0, LBB11_11
; %bb.5:
Lloh111:
	adrp	x8, lCPI11_2@PAGE
Lloh112:
	ldr	q0, [x8, lCPI11_2@PAGEOFF]
	str	q0, [x25]
Lloh113:
	adrp	x8, l_.str.22@PAGE
Lloh114:
	add	x8, x8, l_.str.22@PAGEOFF
LBB11_6:
	str	x8, [x25, #16]
	b	LBB11_9
LBB11_7:
Lloh115:
	adrp	x9, lCPI11_0@PAGE
Lloh116:
	ldr	q0, [x9, lCPI11_0@PAGEOFF]
	str	q0, [x8]
Lloh117:
	adrp	x9, l_.str.21@PAGE
Lloh118:
	add	x9, x9, l_.str.21@PAGEOFF
LBB11_8:
	str	x9, [x8, #16]
LBB11_9:
	ldur	x8, [x29, #-88]
Lloh119:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh120:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh121:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB11_37
; %bb.10:
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #400]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #384]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #368]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
LBB11_11:
	ldr	w9, [x19, #320]
	mov	x8, x25
	cbz	w9, LBB11_15
; %bb.12:
	mov	x0, x19
	ldr	w9, [x19, #304]
	cbz	w9, LBB11_15
; %bb.13:
	mov	w10, #1                         ; =0x1
	movk	w10, #256, lsl #16
	cmp	w9, w10
	b.lo	LBB11_16
; %bb.14:
Lloh122:
	adrp	x9, lCPI11_3@PAGE
Lloh123:
	ldr	q0, [x9, lCPI11_3@PAGEOFF]
	str	q0, [x8]
Lloh124:
	adrp	x9, l_.str.24@PAGE
Lloh125:
	add	x9, x9, l_.str.24@PAGEOFF
	b	LBB11_8
LBB11_15:
Lloh126:
	adrp	x9, lCPI11_2@PAGE
Lloh127:
	ldr	q0, [x9, lCPI11_2@PAGEOFF]
	str	q0, [x8]
Lloh128:
	adrp	x9, l_.str.23@PAGE
Lloh129:
	add	x9, x9, l_.str.23@PAGEOFF
	b	LBB11_8
LBB11_16:
	strb	wzr, [sp, #63]
	add	x8, sp, #32
	add	x1, sp, #63
	bl	_record_preflight
	ldr	w8, [sp, #32]
	cbz	w8, LBB11_18
LBB11_17:
	ldr	q0, [sp, #32]
	str	q0, [x25]
	ldr	x8, [sp, #48]
	b	LBB11_6
LBB11_18:
	ldrb	w8, [sp, #63]
	cmp	w8, #1
	b.ne	LBB11_20
; %bb.19:
Lloh130:
	adrp	x8, lCPI11_2@PAGE
Lloh131:
	ldr	q0, [x8, lCPI11_2@PAGEOFF]
	str	q0, [x25]
Lloh132:
	adrp	x8, l_.str.25@PAGE
Lloh133:
	add	x8, x8, l_.str.25@PAGEOFF
	b	LBB11_6
LBB11_20:
	ldr	x1, [x19, #312]
	ldr	w2, [x19, #320]
	add	x0, sp, #8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB11_22
; %bb.21:
Lloh134:
	adrp	x8, lCPI11_0@PAGE
Lloh135:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x25]
Lloh136:
	adrp	x8, l_.str.26@PAGE
Lloh137:
	add	x8, x8, l_.str.26@PAGEOFF
	b	LBB11_6
LBB11_22:
	add	x8, sp, #64
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	str	q0, [x8, #80]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	str	q0, [sp, #64]
	ldr	w1, [sp, #4]
	add	x3, sp, #64
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_mixed_ownership_read
	tbz	w0, #0, LBB11_27
; %bb.23:
	mov	w0, #1                          ; =0x1
	mov	w1, #10304                      ; =0x2840
	bl	_calloc
	cbz	x0, LBB11_28
; %bb.24:
	mov	x20, x0
	ldr	x0, [x19, #312]
	ldr	w1, [x19, #320]
	mov	x2, x20
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB11_29
; %bb.25:
	mov	w8, #2                          ; =0x2
	mov	w9, #4                          ; =0x4
	cmp	w0, #1
	csel	w9, w9, w8, eq
Lloh138:
	adrp	x8, l_.str.28@PAGE
Lloh139:
	add	x8, x8, l_.str.28@PAGEOFF
LBB11_26:
	stp	w9, wzr, [sp, #32]
	stp	xzr, x8, [sp, #40]
	b	LBB11_30
LBB11_27:
Lloh140:
	adrp	x8, lCPI11_0@PAGE
Lloh141:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x25]
Lloh142:
	adrp	x8, l_.str.15@PAGE
Lloh143:
	add	x8, x8, l_.str.15@PAGEOFF
	b	LBB11_6
LBB11_28:
Lloh144:
	adrp	x8, lCPI11_1@PAGE
Lloh145:
	ldr	q0, [x8, lCPI11_1@PAGEOFF]
	str	q0, [x25]
Lloh146:
	adrp	x8, l_.str.27@PAGE
Lloh147:
	add	x8, x8, l_.str.27@PAGEOFF
	b	LBB11_6
LBB11_29:
	ldr	w21, [sp, #4]
	str	w21, [x20, #16]
	add	x8, sp, #32
	add	x1, sp, #64
	mov	x0, x20
	bl	_oa_classify
	ldr	w8, [sp, #32]
	cbz	w8, LBB11_31
LBB11_30:
	mov	x0, x20
	bl	_nvm_owned_array_layouts_free
	b	LBB11_17
LBB11_31:
	add	x3, sp, #64
	mov	x0, x19
	mov	x1, x21
	mov	x2, x20
	bl	_mixed_ownership_read
	cbz	w0, LBB11_36
; %bb.32:
	add	x8, sp, #32
	mov	x0, x20
	bl	_oa_paths
	ldr	w8, [sp, #32]
	cbnz	w8, LBB11_30
; %bb.33:
	ldr	w21, [x19, #320]
	mov	x0, x21
	bl	_malloc
	mov	x23, x0
	str	x0, [x20, #10280]
	ldr	w22, [x19, #304]
	mov	x0, x22
	bl	_malloc
	str	x0, [x20, #10288]
Lloh148:
	adrp	x8, l_.str.30@PAGE
Lloh149:
	add	x8, x8, l_.str.30@PAGEOFF
	mov	w9, #4                          ; =0x4
	cbz	x23, LBB11_26
; %bb.34:
	mov	x24, x0
	cbz	x0, LBB11_26
; %bb.35:
	ldr	x1, [x19, #312]
	mov	x0, x23
	mov	x2, x21
	bl	_memcpy
	str	w21, [x20, #10296]
	ldr	x1, [x19, #296]
	mov	x0, x24
	mov	x2, x22
	bl	_memcpy
	str	w22, [x20, #10300]
	str	x20, [x26]
	stp	xzr, xzr, [x25]
Lloh150:
	adrp	x8, l_.str.31@PAGE
Lloh151:
	add	x8, x8, l_.str.31@PAGEOFF
	b	LBB11_6
LBB11_36:
Lloh152:
	adrp	x8, l_.str.29@PAGE
Lloh153:
	add	x8, x8, l_.str.29@PAGEOFF
	mov	w9, #1                          ; =0x1
	b	LBB11_26
LBB11_37:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh108, Lloh109, Lloh110
	.loh AdrpAdd	Lloh113, Lloh114
	.loh AdrpAdrp	Lloh111, Lloh113
	.loh AdrpLdr	Lloh111, Lloh112
	.loh AdrpAdd	Lloh117, Lloh118
	.loh AdrpAdrp	Lloh115, Lloh117
	.loh AdrpLdr	Lloh115, Lloh116
	.loh AdrpLdrGotLdr	Lloh119, Lloh120, Lloh121
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdrp	Lloh122, Lloh124
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdrp	Lloh134, Lloh136
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdrp	Lloh144, Lloh146
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oa_classify
_oa_classify:                           ; @oa_classify
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	ldr	w10, [x0, #8]
	cbz	w10, LBB12_32
; %bb.1:
	mov	x9, #0                          ; =0x0
	mov	x11, x0
	ldr	x12, [x11], #32
	mov	w13, #8224                      ; =0x2020
	add	x13, x0, x13
	mov	w14, #9248                      ; =0x2420
	add	x14, x0, x14
	movi.2d	v0, #0xffffffffffffffff
	mov	w15, #65536                     ; =0x10000
	mov	w16, #12                        ; =0xc
	mov	w17, #1                         ; =0x1
	mov	w2, #22                         ; =0x16
LBB12_2:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_8 Depth 2
                                        ;       Child Loop BB12_9 Depth 3
	add	x21, x12, x9, lsl #4
	add	x3, x11, x9, lsl #5
	ldrh	w4, [x21, #2]
	ldrb	w5, [x1, x9]
	str	w9, [x3]
	stur	d0, [x3, #4]
	str	xzr, [x3, #16]
	str	w4, [x3, #12]
	strb	w5, [x3, #24]
	mov	x6, x3
	str	wzr, [x6, #25]!
	str	wzr, [x3, #28]
	ldrb	w5, [x21]
	ldrb	w4, [x1, x9]
	cbz	w5, LBB12_5
; %bb.3:                                ;   in Loop: Header=BB12_2 Depth=1
	cbnz	w4, LBB12_35
LBB12_4:                                ;   in Loop: Header=BB12_2 Depth=1
	add	x9, x9, #1
	cmp	x9, x10
	b.ne	LBB12_2
	b	LBB12_32
LBB12_5:                                ;   in Loop: Header=BB12_2 Depth=1
	tbz	w4, #0, LBB12_36
; %bb.6:                                ;   in Loop: Header=BB12_2 Depth=1
	and	w4, w4, #0x2
	ldr	w5, [x0, #20]
	str	w5, [x3, #4]
	add	w7, w5, #1
	str	w7, [x0, #20]
	str	w9, [x13, x5, lsl #2]
	ldrh	w22, [x21, #2]
	cbz	x22, LBB12_26
; %bb.7:                                ;   in Loop: Header=BB12_2 Depth=1
	mov	w20, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	mov	w5, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	ldr	x23, [x21, #8]
	lsr	w21, w4, #1
	neg	x22, x22
	add	x23, x23, #4
LBB12_8:                                ;   Parent Loop BB12_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB12_9 Depth 3
	madd	x24, x7, x16, x23
	add	x7, x7, #1
LBB12_9:                                ;   Parent Loop BB12_2 Depth=1
                                        ;     Parent Loop BB12_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w25, [x24, #-4]
	cmp	w25, #8
	b.ne	LBB12_16
; %bb.10:                               ;   in Loop: Header=BB12_9 Depth=3
	ldr	w25, [x24], #12
	cmp	x9, x25
	b.ls	LBB12_33
; %bb.11:                               ;   in Loop: Header=BB12_9 Depth=3
	lsl	x26, x25, #4
	ldrb	w26, [x12, x26]
	cbnz	w26, LBB12_33
; %bb.12:                               ;   in Loop: Header=BB12_9 Depth=3
	ldrb	w26, [x1, x25]
	tbz	w26, #0, LBB12_33
; %bb.13:                               ;   in Loop: Header=BB12_9 Depth=3
	ubfx	w26, w26, #1, #1
	cmp	w21, w26
	b.ne	LBB12_33
; %bb.14:                               ;   in Loop: Header=BB12_9 Depth=3
	add	x25, x11, x25, lsl #5
	ldrb	w26, [x25, #26]
	orr	w5, w5, w26
	strb	w5, [x3, #26]
	ldrb	w26, [x25, #27]
	orr	w19, w19, w26
	strb	w19, [x3, #27]
	cbnz	w4, LBB12_22
; %bb.15:                               ;   in Loop: Header=BB12_9 Depth=3
	add	x7, x7, #1
	add	x25, x22, x7
	cmp	x25, #1
	b.ne	LBB12_9
	b	LBB12_27
LBB12_16:                               ;   in Loop: Header=BB12_8 Depth=2
	cmp	w4, #0
	ccmp	w25, #3, #0, eq
	cset	w26, eq
	cmp	w25, #4
	lsl	w27, w17, w25
	and	w27, w27, w2
	ccmp	w27, #0, #4, ls
	csel	w26, w17, w26, ne
	ldr	w24, [x24]
	cmn	w24, #1
	b.ne	LBB12_37
; %bb.17:                               ;   in Loop: Header=BB12_8 Depth=2
	tbnz	w26, #0, LBB12_19
; %bb.18:                               ;   in Loop: Header=BB12_8 Depth=2
	orr	w24, w25, #0x2
	cmp	w24, #7
	b.ne	LBB12_37
LBB12_19:                               ;   in Loop: Header=BB12_8 Depth=2
	cmp	w25, #7
	cset	w24, eq
	orr	w5, w5, w24
	strb	w5, [x3, #26]
	cmp	w25, #5
	cset	w24, eq
	orr	w19, w19, w24
	strb	w19, [x3, #27]
	mov	x24, x21
LBB12_20:                               ;   in Loop: Header=BB12_8 Depth=2
	ldr	w25, [x3, #20]
	sub	w26, w15, w25
	cmp	w24, w26
	b.hi	LBB12_38
; %bb.21:                               ;   in Loop: Header=BB12_8 Depth=2
	add	w24, w25, w24
	str	w24, [x3, #20]
	cmn	x22, x7
	b.ne	LBB12_8
	b	LBB12_31
LBB12_22:                               ;   in Loop: Header=BB12_8 Depth=2
	ldrb	w24, [x25, #25]
	cmp	w24, #32
	b.hs	LBB12_40
; %bb.23:                               ;   in Loop: Header=BB12_8 Depth=2
	cmp	w24, w20
	b.lo	LBB12_25
; %bb.24:                               ;   in Loop: Header=BB12_8 Depth=2
	add	w20, w24, #1
	strb	w20, [x6]
LBB12_25:                               ;   in Loop: Header=BB12_8 Depth=2
	ldr	w24, [x25, #20]
	b	LBB12_20
LBB12_26:                               ;   in Loop: Header=BB12_2 Depth=1
	mov	w5, #0                          ; =0x0
LBB12_27:                               ;   in Loop: Header=BB12_2 Depth=1
	mov	w6, #0                          ; =0x0
LBB12_28:                               ;   in Loop: Header=BB12_2 Depth=1
	and	w6, w6, #0x1
	strb	w6, [x3, #28]
	ldr	w6, [x0, #28]
	str	w6, [x3, #16]
	ldr	w7, [x3, #20]
	sub	w19, w15, w6
	cmp	w7, w19
	b.hi	LBB12_39
; %bb.29:                               ;   in Loop: Header=BB12_2 Depth=1
	cmp	w4, #0
	cset	w4, ne
	add	w6, w7, w6
	str	w6, [x0, #28]
	orr	w4, w4, w5
	tbnz	w4, #0, LBB12_4
; %bb.30:                               ;   in Loop: Header=BB12_2 Depth=1
	ldr	w4, [x0, #24]
	str	w4, [x3, #8]
	add	w3, w4, #1
	str	w3, [x0, #24]
	str	w9, [x14, x4, lsl #2]
	b	LBB12_4
LBB12_31:                               ;   in Loop: Header=BB12_2 Depth=1
	orr	w6, w5, w19
	cmp	w4, #0
	csel	w6, wzr, w6, eq
	b	LBB12_28
LBB12_32:
	stp	xzr, xzr, [x8]
Lloh154:
	adrp	x9, l_.str.58@PAGE
Lloh155:
	add	x9, x9, l_.str.58@PAGEOFF
	b	LBB12_34
LBB12_33:
	sub	w10, w7, #1
	and	w10, w10, #0xffff
	mov	w11, #1                         ; =0x1
	stp	w11, w9, [x8]
	stp	w10, wzr, [x8, #8]
Lloh156:
	adrp	x9, l_.str.53@PAGE
Lloh157:
	add	x9, x9, l_.str.53@PAGEOFF
LBB12_34:
	str	x9, [x8, #16]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB12_35:
	mov	w10, #1                         ; =0x1
	stp	w10, w9, [x8]
	str	xzr, [x8, #8]
Lloh158:
	adrp	x9, l_.str.51@PAGE
Lloh159:
	add	x9, x9, l_.str.51@PAGEOFF
	b	LBB12_34
LBB12_36:
	mov	w10, #1                         ; =0x1
	stp	w10, w9, [x8]
	str	xzr, [x8, #8]
Lloh160:
	adrp	x9, l_.str.52@PAGE
Lloh161:
	add	x9, x9, l_.str.52@PAGEOFF
	b	LBB12_34
LBB12_37:
	sub	w10, w7, #1
	and	w10, w10, #0xffff
	mov	w11, #1                         ; =0x1
	stp	w11, w9, [x8]
	stp	w10, wzr, [x8, #8]
Lloh162:
	adrp	x9, l_.str.55@PAGE
Lloh163:
	add	x9, x9, l_.str.55@PAGEOFF
	b	LBB12_34
LBB12_38:
	sub	w10, w7, #1
	and	w10, w10, #0xffff
	mov	w11, #3                         ; =0x3
	stp	w11, w9, [x8]
	stp	w10, wzr, [x8, #8]
Lloh164:
	adrp	x9, l_.str.56@PAGE
Lloh165:
	add	x9, x9, l_.str.56@PAGEOFF
	b	LBB12_34
LBB12_39:
	mov	w10, #3                         ; =0x3
	stp	w10, w9, [x8]
	str	xzr, [x8, #8]
Lloh166:
	adrp	x9, l_.str.57@PAGE
Lloh167:
	add	x9, x9, l_.str.57@PAGEOFF
	b	LBB12_34
LBB12_40:
	sub	w10, w7, #1
	and	w10, w10, #0xffff
	mov	w11, #3                         ; =0x3
	stp	w11, w9, [x8]
	stp	w10, wzr, [x8, #8]
Lloh168:
	adrp	x9, l_.str.54@PAGE
Lloh169:
	add	x9, x9, l_.str.54@PAGEOFF
	b	LBB12_34
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh168, Lloh169
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oa_paths
lCPI13_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oa_paths:                              ; @oa_paths
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	x19, x8
	ldr	w0, [x0, #28]
	cbz	w0, LBB13_2
; %bb.1:
	mov	w1, #76                         ; =0x4c
	bl	_calloc
	str	x0, [x20, #10272]
	cbz	x0, LBB13_21
LBB13_2:
	ldr	w8, [x20, #8]
	cbz	w8, LBB13_20
; %bb.3:
	mov	x21, #0                         ; =0x0
	add	x10, x20, #32
	mov	w24, #76                        ; =0x4c
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	b	LBB13_5
LBB13_4:                                ;   in Loop: Header=BB13_5 Depth=1
	add	x21, x21, #1
	cmp	x21, x8
	b.hs	LBB13_20
LBB13_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_10 Depth 2
                                        ;       Child Loop BB13_13 Depth 3
	add	x26, x10, x21, lsl #5
	ldrb	w9, [x26, #24]
	tbz	w9, #1, LBB13_4
; %bb.6:                                ;   in Loop: Header=BB13_5 Depth=1
	ldr	x8, [x20]
	add	x27, x8, x21, lsl #4
	ldr	w25, [x26, #16]
	ldrh	w8, [x27, #2]
	cbz	w8, LBB13_15
; %bb.7:                                ;   in Loop: Header=BB13_5 Depth=1
	mov	x28, #0                         ; =0x0
	b	LBB13_10
LBB13_8:                                ;   in Loop: Header=BB13_10 Depth=2
	ldr	x9, [x20, #10272]
	umaddl	x9, w25, w24, x9
	add	w25, w25, #1
	stp	w21, w21, [x9]
	strb	w8, [x9, #10]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #8]
	strh	w28, [x9, #12]
LBB13_9:                                ;   in Loop: Header=BB13_10 Depth=2
	add	x28, x28, #1
	ldrh	w8, [x27, #2]
	cmp	x28, x8
	b.hs	LBB13_18
LBB13_10:                               ;   Parent Loop BB13_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB13_13 Depth 3
	ldr	x8, [x27, #8]
	mov	w9, #12                         ; =0xc
	madd	x9, x28, x9, x8
	ldrb	w8, [x9]
	cmp	w8, #8
	b.ne	LBB13_8
; %bb.11:                               ;   in Loop: Header=BB13_10 Depth=2
	ldr	w8, [x9, #4]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x23, x9, x8, lsl #5
	ldr	w8, [x23, #20]
	cbz	w8, LBB13_9
; %bb.12:                               ;   in Loop: Header=BB13_10 Depth=2
	mov	w22, #0                         ; =0x0
	mov	x9, x25
LBB13_13:                               ;   Parent Loop BB13_5 Depth=1
                                        ;     Parent Loop BB13_10 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x11, [x20, #10272]
	ldr	w8, [x23, #16]
	add	w8, w22, w8
	umaddl	x8, w8, w24, x11
	ldrh	w10, [x8, #8]
	cmp	w10, #31
	b.hi	LBB13_19
; %bb.14:                               ;   in Loop: Header=BB13_13 Depth=3
	add	w25, w9, #1
	umaddl	x9, w9, w24, x11
	ldr	w11, [x8, #4]
	stp	w21, w11, [x9]
	ldrb	w11, [x8, #10]
	strb	w11, [x9, #10]
	add	w10, w10, #1
	strh	w10, [x9, #8]
	strh	w28, [x9, #12]
	ldrh	w10, [x8, #8]
	lsl	x2, x10, #1
	add	x0, x9, #14
	add	x1, x8, #12
	bl	_memcpy
	add	w22, w22, #1
	ldr	w8, [x23, #20]
	mov	x9, x25
	cmp	w22, w8
	b.lo	LBB13_13
	b	LBB13_9
LBB13_15:                               ;   in Loop: Header=BB13_5 Depth=1
	mov	x8, x25
LBB13_16:                               ;   in Loop: Header=BB13_5 Depth=1
	ldr	w9, [x26, #20]
	add	w8, w9, w8
	cmp	w25, w8
	b.ne	LBB13_23
; %bb.17:                               ;   in Loop: Header=BB13_5 Depth=1
	ldr	w8, [x20, #8]
	b	LBB13_4
LBB13_18:                               ;   in Loop: Header=BB13_5 Depth=1
	ldr	w8, [x26, #16]
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB13_16
LBB13_19:
	and	w8, w28, #0xffff
	mov	w9, #3                          ; =0x3
	stp	w9, w21, [x19]
	stp	w8, wzr, [x19, #8]
Lloh170:
	adrp	x8, l_.str.61@PAGE
Lloh171:
	add	x8, x8, l_.str.61@PAGEOFF
	b	LBB13_22
LBB13_20:
	stp	xzr, xzr, [x19]
Lloh172:
	adrp	x8, l_.str.63@PAGE
Lloh173:
	add	x8, x8, l_.str.63@PAGEOFF
	b	LBB13_22
LBB13_21:
Lloh174:
	adrp	x8, lCPI13_0@PAGE
Lloh175:
	ldr	q0, [x8, lCPI13_0@PAGEOFF]
	str	q0, [x19]
Lloh176:
	adrp	x8, l_.str.60@PAGE
Lloh177:
	add	x8, x8, l_.str.60@PAGEOFF
LBB13_22:
	str	x8, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB13_23:
	mov	w8, #2                          ; =0x2
	stp	w8, w21, [x19]
	str	xzr, [x19, #8]
Lloh178:
	adrp	x8, l_.str.62@PAGE
Lloh179:
	add	x8, x8, l_.str.62@PAGEOFF
	b	LBB13_22
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdd	Lloh178, Lloh179
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_layout_counts ; -- Begin function nvm_owned_array_layout_counts
	.globl	_nvm_owned_array_layout_counts
	.p2align	2
_nvm_owned_array_layout_counts:         ; @nvm_owned_array_layout_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB14_2
; %bb.1:
	ldr	q0, [x8, #16]
	str	q0, [x1]
LBB14_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_layout_fact ; -- Begin function nvm_owned_array_layout_fact
	.globl	_nvm_owned_array_layout_fact
	.p2align	2
_nvm_owned_array_layout_fact:           ; @nvm_owned_array_layout_fact
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB15_4
; %bb.1:
	cbz	x2, LBB15_4
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB15_5
; %bb.3:
	mov	w9, w1
	add	x8, x8, x9, lsl #5
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB15_4:
	ret
LBB15_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_source_layout ; -- Begin function nvm_owned_array_source_layout
	.globl	_nvm_owned_array_source_layout
	.p2align	2
_nvm_owned_array_source_layout:         ; @nvm_owned_array_source_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB16_4
; %bb.1:
	cbz	x2, LBB16_4
; %bb.2:
	ldr	w9, [x8, #20]
	cmp	w1, w9
	b.hs	LBB16_5
; %bb.3:
	add	x8, x8, w1, uxtw #2
	ldr	w8, [x8, #8224]
	str	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB16_4:
	ret
LBB16_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_managed_layout ; -- Begin function nvm_owned_array_managed_layout
	.globl	_nvm_owned_array_managed_layout
	.p2align	2
_nvm_owned_array_managed_layout:        ; @nvm_owned_array_managed_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB17_4
; %bb.1:
	cbz	x2, LBB17_4
; %bb.2:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB17_5
; %bb.3:
	add	x8, x8, w1, uxtw #2
	ldr	w8, [x8, #9248]
	str	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB17_4:
	ret
LBB17_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_leaf_path ; -- Begin function nvm_owned_array_leaf_path
	.globl	_nvm_owned_array_leaf_path
	.p2align	2
_nvm_owned_array_leaf_path:             ; @nvm_owned_array_leaf_path
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB18_5
; %bb.1:
	cbz	x2, LBB18_5
; %bb.2:
	ldr	w9, [x8, #28]
	cmp	w1, w9
	b.hs	LBB18_4
; %bb.3:
	ldr	x8, [x8, #10272]
	mov	w9, #76                         ; =0x4c
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8]
	str	q0, [x2]
	ldp	q0, q1, [x8, #16]
	ldr	q2, [x8, #48]
	ldur	q3, [x8, #60]
	stur	q3, [x2, #60]
	stp	q1, q2, [x2, #32]
	str	q0, [x2, #16]
	mov	w0, #1                          ; =0x1
	ret
LBB18_4:
	mov	w0, #0                          ; =0x0
LBB18_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_layout_field ; -- Begin function nvm_owned_array_layout_field
	.globl	_nvm_owned_array_layout_field
	.p2align	2
_nvm_owned_array_layout_field:          ; @nvm_owned_array_layout_field
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB19_6
; %bb.1:
	cbz	x3, LBB19_6
; %bb.2:
	ldr	w9, [x8, #8]
	cmp	w1, w9
	b.hs	LBB19_5
; %bb.3:
	ldr	x8, [x8]
	add	x8, x8, w1, uxtw #4
	ldrh	w9, [x8, #2]
	cmp	w2, w9
	b.hs	LBB19_5
; %bb.4:
	ldr	x8, [x8, #8]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w2, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x3, #8]
	str	x9, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB19_5:
	mov	w0, #0                          ; =0x0
LBB19_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_transport ; -- Begin function nvm_owned_array_transport
	.globl	_nvm_owned_array_transport
	.p2align	2
_nvm_owned_array_transport:             ; @nvm_owned_array_transport
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB20_2
; %bb.1:
	mov	w9, #10280                      ; =0x2828
	ldr	q0, [x8, x9]
	str	q0, [x1]
	ldr	d0, [x8, #10296]
	str	d0, [x1, #16]
LBB20_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origins_free ; -- Begin function nvm_owned_array_origins_free
	.globl	_nvm_owned_array_origins_free
	.p2align	2
_nvm_owned_array_origins_free:          ; @nvm_owned_array_origins_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB21_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x19, [x0]
	cbz	x19, LBB21_3
; %bb.2:
	mov	x20, x0
	mov	x0, x19
	bl	_nvm_v2_layouts_free
	ldr	x0, [x19, #10272]
	bl	_free
	ldr	x0, [x19, #10280]
	bl	_free
	ldr	x0, [x19, #10288]
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x0, x20
LBB21_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB21_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_analyze_owned_array_origins
lCPI22_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI22_1:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI22_2:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_analyze_owned_array_origins
	.globl	_nvm_analyze_owned_array_origins
	.p2align	2
_nvm_analyze_owned_array_origins:       ; @nvm_analyze_owned_array_origins
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x8
	cbz	x0, LBB22_29
; %bb.1:
	cbz	x1, LBB22_29
; %bb.2:
	mov	x20, x0
	mov	x24, x1
	bl	_nvm_service_execution_pending
	cbz	w0, LBB22_4
; %bb.3:
Lloh180:
	adrp	x8, lCPI22_1@PAGE
Lloh181:
	ldr	q0, [x8, lCPI22_1@PAGEOFF]
	str	q0, [x19]
Lloh182:
	adrp	x8, l_.str.33@PAGE
Lloh183:
	add	x8, x8, l_.str.33@PAGEOFF
	b	LBB22_30
LBB22_4:
	ldr	x9, [x20, #256]
	cbz	x9, LBB22_29
; %bb.5:
	ldr	x8, [x20, #280]
	cbz	x8, LBB22_29
; %bb.6:
	ldr	w8, [x20, #272]
	cbz	w8, LBB22_29
; %bb.7:
	ldr	w10, [x20, #288]
	cbz	w10, LBB22_29
; %bb.8:
	ldrb	w10, [x20]
	cmp	w10, #78
	b.ne	LBB22_29
; %bb.9:
	ldrb	w10, [x20, #1]
	cmp	w10, #86
	b.ne	LBB22_29
; %bb.10:
	ldrb	w10, [x20, #2]
	cmp	w10, #77
	b.ne	LBB22_29
; %bb.11:
	ldrb	w10, [x20, #3]
	cmp	w10, #1
	b.ne	LBB22_29
; %bb.12:
	ldr	w10, [x20, #4]
	cmp	w10, #2
	b.ne	LBB22_29
; %bb.13:
	cmp	w8, #8
	b.hi	LBB22_21
; %bb.14:
	ldr	w10, [x20, #12]
	cbnz	w10, LBB22_21
; %bb.15:
	ldr	w10, [x20, #8]
	and	w10, w10, #0xfffffffb
	cmp	w10, #1
	b.ne	LBB22_21
; %bb.16:
	ldr	w10, [x20, #432]
	cbnz	w10, LBB22_21
; %bb.17:
	ldr	w10, [x20, #448]
	cbnz	w10, LBB22_21
; %bb.18:
	ldr	w10, [x20, #424]
	cbnz	w10, LBB22_21
; %bb.19:
	ldr	w10, [x20, #352]
	cbnz	w10, LBB22_21
; %bb.20:
	ldr	x10, [x20, #344]
	cbz	x10, LBB22_22
LBB22_21:
Lloh184:
	adrp	x8, lCPI22_1@PAGE
Lloh185:
	ldr	q0, [x8, lCPI22_1@PAGEOFF]
	str	q0, [x19]
Lloh186:
	adrp	x8, l_.str.34@PAGE
Lloh187:
	add	x8, x8, l_.str.34@PAGEOFF
	b	LBB22_30
LBB22_22:
	ldrh	w11, [x9, #16]
	cmp	w11, #256
	b.hi	LBB22_24
; %bb.23:
	ldrh	w10, [x9, #4]
	cmp	w10, #8
	b.ls	LBB22_26
LBB22_24:
	mov	w9, #0                          ; =0x0
LBB22_25:
	mov	w8, #3                          ; =0x3
	stp	w8, w9, [x19]
Lloh188:
	adrp	x8, l_.str.35@PAGE
Lloh189:
	add	x8, x8, l_.str.35@PAGEOFF
	stp	xzr, x8, [x19, #8]
	b	LBB22_31
LBB22_26:
	cmp	w10, w11
	b.hi	LBB22_29
; %bb.27:
	ldrb	w11, [x9, #21]
	cmp	w11, #1
	b.hi	LBB22_29
; %bb.28:
	ldrh	w11, [x9, #18]
	orr	w10, w11, w10
	cbz	w10, LBB22_32
LBB22_29:
Lloh190:
	adrp	x8, l___const.nvm_analyze_owned_array_origins.invalid@PAGE
Lloh191:
	add	x8, x8, l___const.nvm_analyze_owned_array_origins.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x19]
	ldr	x8, [x8, #16]
LBB22_30:
	str	x8, [x19, #16]
LBB22_31:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB22_32:
	cmp	w8, #1
	b.ne	LBB22_55
LBB22_33:
	str	xzr, [sp, #24]
	mov	x8, sp
	add	x1, sp, #24
	mov	x0, x20
	bl	_nvm_describe_owned_array_layouts
	ldr	w8, [sp]
	sub	w9, w8, #3
	cmp	w9, #2
	b.lo	LBB22_63
; %bb.34:
	cbnz	w8, LBB22_62
; %bb.35:
	mov	w0, #1                          ; =0x1
	mov	w1, #35744                      ; =0x8ba0
	movk	w1, #6, lsl #16
	bl	_calloc
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #17624                      ; =0x44d8
	movk	w1, #9, lsl #16
	bl	_calloc
	mov	x21, x0
	cbz	x22, LBB22_64
; %bb.36:
	cbz	x21, LBB22_64
; %bb.37:
	add	x8, x22, #104, lsl #12          ; =425984
	add	x26, x8, #2952
	add	x8, x22, #100, lsl #12          ; =409600
	add	x25, x8, #848
	stp	x20, x21, [x22]
Lloh192:
	adrp	x8, l___const.nvm_analyze_owned_array_origins.invalid@PAGE
Lloh193:
	add	x8, x8, l___const.nvm_analyze_owned_array_origins.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x26]
	ldr	x8, [x8, #16]
	str	x8, [x26, #16]
	ldr	x8, [sp, #24]
	str	x8, [x21]
	ldr	w8, [x20, #272]
	str	w8, [x21, #8]
	mov	x0, x22
	bl	_oq_paths
	cbz	w0, LBB22_50
; %bb.38:
	mov	x0, x22
	bl	_oq_descriptors
	cbz	w0, LBB22_50
; %bb.39:
	mov	x0, x22
	bl	_oq_decode
	cbz	w0, LBB22_50
; %bb.40:
	ldr	w8, [x20, #272]
	cbz	w8, LBB22_44
; %bb.41:
	mov	w23, #0                         ; =0x0
LBB22_42:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x22
	mov	x1, x23
	bl	_oq_function
	tbz	w0, #0, LBB22_50
; %bb.43:                               ;   in Loop: Header=BB22_42 Depth=1
	add	w23, w23, #1
	ldr	w8, [x20, #272]
	cmp	w23, w8
	b.lo	LBB22_42
LBB22_44:
	mov	x0, x22
	mov	w1, #0                          ; =0x0
	bl	_oq_reachable
	ldr	x8, [x21, #816]
	cbnz	x8, LBB22_48
; %bb.45:
	ldr	x8, [x21, #824]
	cbnz	x8, LBB22_48
; %bb.46:
	ldr	x8, [x21, #832]
	cbnz	x8, LBB22_48
; %bb.47:
	ldr	x8, [x21, #840]
	cbz	x8, LBB22_66
LBB22_48:
Lloh194:
	adrp	x8, lCPI22_1@PAGE
Lloh195:
	ldr	q0, [x8, lCPI22_1@PAGEOFF]
	str	q0, [x26]
Lloh196:
	adrp	x8, l_.str.37@PAGE
Lloh197:
	add	x8, x8, l_.str.37@PAGEOFF
LBB22_49:
	str	x8, [x26, #16]
LBB22_50:
	ldr	w8, [x25, #16]
	cbz	w8, LBB22_53
; %bb.51:
	mov	x20, #0                         ; =0x0
	mov	w8, #17320                      ; =0x43a8
	add	x23, x22, x8
LBB22_52:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x23], #96
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x25, #16]
	cmp	x20, x8
	b.lo	LBB22_52
LBB22_53:
	ldr	q0, [x26]
	str	q0, [x19]
	ldr	x8, [x26, #16]
	str	x8, [x19, #16]
	ldr	x0, [x25]
	bl	_free
	ldr	x0, [x25, #2080]
	bl	_free
	mov	x0, x22
	bl	_free
	ldr	w8, [x19]
	cbz	w8, LBB22_65
; %bb.54:
	mov	x0, x21
	bl	_nvm_owned_array_origins_free
	b	LBB22_31
LBB22_55:
	add	x10, x9, #45
	mov	w9, #1                          ; =0x1
LBB22_56:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w11, [x10, #-5]
	cmp	w11, #256
	b.hi	LBB22_25
; %bb.57:                               ;   in Loop: Header=BB22_56 Depth=1
	ldurh	w12, [x10, #-17]
	cmp	w12, #9
	b.hs	LBB22_25
; %bb.58:                               ;   in Loop: Header=BB22_56 Depth=1
	cmp	w12, w11
	b.hi	LBB22_29
; %bb.59:                               ;   in Loop: Header=BB22_56 Depth=1
	ldrb	w11, [x10]
	cmp	w11, #1
	b.hi	LBB22_29
; %bb.60:                               ;   in Loop: Header=BB22_56 Depth=1
	ldurh	w11, [x10, #-3]
	cbnz	w11, LBB22_29
; %bb.61:                               ;   in Loop: Header=BB22_56 Depth=1
	add	w9, w9, #1
	add	x10, x10, #24
	cmp	w8, w9
	b.ne	LBB22_56
	b	LBB22_33
LBB22_62:
	cmp	w8, #2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
LBB22_63:
	stp	w8, wzr, [x19]
	ldr	x8, [sp, #16]
	stp	xzr, x8, [x19, #8]
	b	LBB22_31
LBB22_64:
	mov	x0, x22
	bl	_free
	mov	x0, x21
	bl	_free
	ldr	x0, [sp, #24]
	bl	_nvm_owned_array_layouts_free
Lloh198:
	adrp	x8, lCPI22_0@PAGE
Lloh199:
	ldr	q0, [x8, lCPI22_0@PAGEOFF]
	str	q0, [x19]
Lloh200:
	adrp	x8, l_.str.36@PAGE
Lloh201:
	add	x8, x8, l_.str.36@PAGEOFF
	b	LBB22_30
LBB22_65:
	str	x21, [x24]
	b	LBB22_31
LBB22_66:
	ldr	w8, [x21, #12]
	cmp	w8, #64
	b.hs	LBB22_69
; %bb.67:
	ldr	x9, [x21, #808]
	lsr	x8, x9, x8
	cbz	x8, LBB22_69
; %bb.68:
Lloh202:
	adrp	x8, lCPI22_2@PAGE
Lloh203:
	ldr	q0, [x8, lCPI22_2@PAGEOFF]
	str	q0, [x26]
Lloh204:
	adrp	x8, l_.str.38@PAGE
Lloh205:
	add	x8, x8, l_.str.38@PAGEOFF
	b	LBB22_49
LBB22_69:
	ldr	w8, [x25, #16]
	str	w8, [x21, #16]
	stp	xzr, xzr, [x26]
Lloh206:
	adrp	x8, l_.str.39@PAGE
Lloh207:
	add	x8, x8, l_.str.39@PAGEOFF
	b	LBB22_49
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdrp	Lloh194, Lloh196
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdrp	Lloh198, Lloh200
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpAdd	Lloh206, Lloh207
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_paths
lCPI23_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_paths:                              ; @oq_paths
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	add	x8, x0, #100, lsl #12           ; =409600
	add	x20, x8, #848
	ldr	x8, [x0, #8]
	ldr	x21, [x8]
	cbz	x21, LBB23_13
; %bb.1:
	ldr	w22, [x21, #16]
	ldr	w0, [x21, #28]
	cbz	w0, LBB23_3
; %bb.2:
	mov	w1, #4                          ; =0x4
	bl	_calloc
	str	x0, [x20, #2080]
	cbz	x0, LBB23_16
LBB23_3:
	cbz	w22, LBB23_13
; %bb.4:
	mov	x8, #0                          ; =0x0
	mov	w11, #0                         ; =0x0
	add	x9, x21, #32
	add	x10, x19, #100, lsl #12         ; =409600
	add	x10, x10, #1900
	add	x12, x19, #100, lsl #12         ; =409600
	add	x12, x12, #876
	mov	w13, #76                        ; =0x4c
	b	LBB23_7
LBB23_5:                                ;   in Loop: Header=BB23_7 Depth=1
	str	w11, [x10, x8, lsl #2]
LBB23_6:                                ;   in Loop: Header=BB23_7 Depth=1
	add	x8, x8, #1
	cmp	x8, x22
	b.eq	LBB23_13
LBB23_7:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_10 Depth 2
	ldr	w14, [x21, #16]
	cmp	x8, x14
	b.hs	LBB23_5
; %bb.8:                                ;   in Loop: Header=BB23_7 Depth=1
	add	x15, x9, x8, lsl #5
	ldp	w14, w15, [x15, #16]
	str	w11, [x10, x8, lsl #2]
	cbnz	w15, LBB23_10
	b	LBB23_6
LBB23_9:                                ;   in Loop: Header=BB23_10 Depth=2
	add	w14, w14, #1
	subs	x15, x15, #1
	b.eq	LBB23_6
LBB23_10:                               ;   Parent Loop BB23_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w16, [x21, #28]
	cmp	w14, w16
	b.hs	LBB23_9
; %bb.11:                               ;   in Loop: Header=BB23_10 Depth=2
	ldr	x16, [x21, #10272]
	umaddl	x16, w14, w13, x16
	ldrb	w16, [x16, #10]
	cmp	w16, #7
	b.ne	LBB23_9
; %bb.12:                               ;   in Loop: Header=BB23_10 Depth=2
	ldr	x16, [x20, #2080]
	str	w14, [x16, w11, uxtw #2]
	add	w11, w11, #1
	ldr	w16, [x12, x8, lsl #2]
	add	w16, w16, #1
	str	w16, [x12, x8, lsl #2]
	b	LBB23_9
LBB23_13:
	mov	w0, #65536                      ; =0x10000
	mov	w1, #40                         ; =0x28
	bl	_calloc
	str	x0, [x20]
	cbz	x0, LBB23_15
; %bb.14:
	mov	w0, #1                          ; =0x1
	b	LBB23_18
LBB23_15:
Lloh208:
	adrp	x8, l_.str.65@PAGE
Lloh209:
	add	x8, x8, l_.str.65@PAGEOFF
	b	LBB23_17
LBB23_16:
Lloh210:
	adrp	x8, l_.str.64@PAGE
Lloh211:
	add	x8, x8, l_.str.64@PAGEOFF
LBB23_17:
	mov	w0, #0                          ; =0x0
	add	x9, x19, #104, lsl #12          ; =425984
Lloh212:
	adrp	x10, lCPI23_0@PAGE
Lloh213:
	ldr	q0, [x10, lCPI23_0@PAGEOFF]
	add	x9, x9, #2952
	str	q0, [x9]
	str	x8, [x9, #16]
LBB23_18:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpLdr	Lloh212, Lloh213
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_descriptors
_oq_descriptors:                        ; @oq_descriptors
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB24_2
; %bb.1:
	ldr	x1, [x8, #10288]
	ldr	w2, [x8, #10300]
	b	LBB24_3
LBB24_2:
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
LBB24_3:
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u32
	cbnz	w0, LBB24_60
; %bb.4:
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB24_60
; %bb.5:
	ldr	w1, [sp, #52]
	add	x0, sp, #56
	add	x2, sp, #40
	bl	_nvm_v2_take
	cbnz	w0, LBB24_60
; %bb.6:
	add	x0, sp, #56
	bl	_nvm_v2_align4
	cbnz	w0, LBB24_60
; %bb.7:
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB24_60
; %bb.8:
	ldr	w8, [sp, #52]
	ldr	x9, [x19]
	ldr	w9, [x9, #272]
	cmp	w8, w9
	b.ne	LBB24_60
; %bb.9:
	cbz	w8, LBB24_55
; %bb.10:
	mov	x21, #0                         ; =0x0
	add	x20, x19, #104, lsl #12         ; =425984
	add	x25, sp, #24
	add	x8, x19, #100, lsl #12          ; =409600
	add	x8, x8, #876
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x24, x19, #16
	mov	w26, #24                        ; =0x18
Lloh214:
	adrp	x22, l_.str.66@PAGE
Lloh215:
	add	x22, x22, l_.str.66@PAGEOFF
	mov	x27, x24
LBB24_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_16 Depth 2
	ldr	x8, [x19]
	ldr	x23, [x8, #256]
	add	x0, sp, #56
	add	x1, sp, #38
	bl	_nvm_v2_u16
	cbnz	w0, LBB24_60
; %bb.12:                               ;   in Loop: Header=BB24_11 Depth=1
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_nvm_v2_u16
	cbnz	w0, LBB24_60
; %bb.13:                               ;   in Loop: Header=BB24_11 Depth=1
	madd	x28, x21, x26, x23
	ldrh	w8, [sp, #38]
	ldrh	w9, [x28, #16]
	cmp	w8, w9
	b.ne	LBB24_60
; %bb.14:                               ;   in Loop: Header=BB24_11 Depth=1
	ldrh	w8, [sp, #36]
	ldrh	w9, [x28, #4]
	cmp	w8, w9
	b.ne	LBB24_60
; %bb.15:                               ;   in Loop: Header=BB24_11 Depth=1
	mov	x23, #0                         ; =0x0
	mov	w8, #2152                       ; =0x868
	madd	x26, x21, x8, x24
LBB24_16:                               ;   Parent Loop BB24_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #56
	add	x1, sp, #24
	bl	_nvm_v2_u8
	cbnz	w0, LBB24_60
; %bb.17:                               ;   in Loop: Header=BB24_16 Depth=2
	add	x0, sp, #56
	add	x1, sp, #23
	bl	_nvm_v2_u8
	cbnz	w0, LBB24_60
; %bb.18:                               ;   in Loop: Header=BB24_16 Depth=2
	add	x0, sp, #56
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB24_60
; %bb.19:                               ;   in Loop: Header=BB24_16 Depth=2
	add	x0, sp, #56
	orr	x1, x25, #0x4
	bl	_nvm_v2_u32
	cbnz	w0, LBB24_60
; %bb.20:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrb	w8, [sp, #23]
	mov	w9, #1                          ; =0x1
	cbnz	w8, LBB24_59
; %bb.21:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrh	w8, [sp, #20]
	cbnz	w8, LBB24_59
; %bb.22:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	x8, [sp, #24]
	lsr	x10, x8, #32
	and	x9, x8, #0xff
	cbz	x23, LBB24_28
; %bb.23:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrh	w11, [sp, #36]
	cmp	x23, x11
	b.ls	LBB24_28
; %bb.24:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	x9, #8
	b.ne	LBB24_45
; %bb.25:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	x9, [x19, #8]
	ldr	x9, [x9]
	cbz	x9, LBB24_56
; %bb.26:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	w11, [x9, #16]
	cmp	w11, w10
	b.ls	LBB24_56
; %bb.27:                               ;   in Loop: Header=BB24_16 Depth=2
	add	x9, x9, x10, lsl #5
	ldrb	w9, [x9, #56]
	tbnz	w9, #1, LBB24_48
	b	LBB24_56
LBB24_28:                               ;   in Loop: Header=BB24_16 Depth=2
	and	w11, w8, #0xff
	cmp	x9, #8
	b.ne	LBB24_32
; %bb.29:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	x9, [x19, #8]
	ldr	x9, [x9]
	cbz	x9, LBB24_57
; %bb.30:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	w12, [x9, #16]
	cmp	w12, w10
	b.ls	LBB24_57
; %bb.31:                               ;   in Loop: Header=BB24_16 Depth=2
	add	x9, x9, x10, lsl #5
	ldrb	w9, [x9, #56]
	tbnz	w9, #1, LBB24_37
	b	LBB24_57
LBB24_32:                               ;   in Loop: Header=BB24_16 Depth=2
	mov	w9, #-1                         ; =0xffffffff
	cmp	x10, x9
	b.ne	LBB24_57
; %bb.33:                               ;   in Loop: Header=BB24_16 Depth=2
	mov	w9, #1                          ; =0x1
	cmp	w11, #5
	b.hi	LBB24_58
; %bb.34:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	w11, #3
	b.eq	LBB24_58
; %bb.35:                               ;   in Loop: Header=BB24_16 Depth=2
	cbz	x23, LBB24_37
; %bb.36:                               ;   in Loop: Header=BB24_16 Depth=2
	cbz	w11, LBB24_58
LBB24_37:                               ;   in Loop: Header=BB24_16 Depth=2
	cbnz	x23, LBB24_48
; %bb.38:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrb	w9, [x28, #21]
	cbnz	w9, LBB24_40
; %bb.39:                               ;   in Loop: Header=BB24_16 Depth=2
	cbnz	w11, LBB24_60
LBB24_40:                               ;   in Loop: Header=BB24_16 Depth=2
	cbz	w9, LBB24_42
; %bb.41:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrb	w9, [x28, #20]
	cmp	w9, w11
	b.ne	LBB24_60
LBB24_42:                               ;   in Loop: Header=BB24_16 Depth=2
	cbz	x21, LBB24_50
; %bb.43:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	w11, #8
	b.ne	LBB24_52
; %bb.44:                               ;   in Loop: Header=BB24_16 Depth=2
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, x10, lsl #2]
	cmp	w9, #256
	b.ls	LBB24_52
	b	LBB24_62
LBB24_45:                               ;   in Loop: Header=BB24_16 Depth=2
	mov	w9, #-1                         ; =0xffffffff
	cmp	x10, x9
	b.ne	LBB24_56
; %bb.46:                               ;   in Loop: Header=BB24_16 Depth=2
	and	w9, w8, #0xff
	cmp	w9, #5
	b.hi	LBB24_53
; %bb.47:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	w9, #3
	b.eq	LBB24_53
LBB24_48:                               ;   in Loop: Header=BB24_16 Depth=2
	str	x8, [x27, x23, lsl #3]
LBB24_49:                               ;   in Loop: Header=BB24_16 Depth=2
	ldrh	w8, [sp, #38]
	cmp	x23, x8
	add	x23, x23, #1
	b.lo	LBB24_16
	b	LBB24_54
LBB24_50:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	w11, #3
	b.lo	LBB24_52
; %bb.51:                               ;   in Loop: Header=BB24_16 Depth=2
	cmp	w11, #4
	b.ne	LBB24_63
LBB24_52:                               ;   in Loop: Header=BB24_16 Depth=2
	str	x8, [x26]
	b	LBB24_49
LBB24_53:                               ;   in Loop: Header=BB24_16 Depth=2
	and	w9, w9, #0xfffffffb
	cmp	w9, #3
	b.eq	LBB24_48
	b	LBB24_56
LBB24_54:                               ;   in Loop: Header=BB24_11 Depth=1
	add	x21, x21, #1
	ldr	w8, [sp, #52]
	add	x27, x27, #2152
	mov	w0, #1                          ; =0x1
	cmp	x21, x8
	mov	w26, #24                        ; =0x18
	b.lo	LBB24_11
	b	LBB24_61
LBB24_55:
	mov	w0, #1                          ; =0x1
	b	LBB24_61
LBB24_56:
	mov	w9, #1                          ; =0x1
Lloh216:
	adrp	x22, l_.str.68@PAGE
Lloh217:
	add	x22, x22, l_.str.68@PAGEOFF
	b	LBB24_59
LBB24_57:
	mov	w9, #1                          ; =0x1
LBB24_58:
Lloh218:
	adrp	x22, l_.str.67@PAGE
Lloh219:
	add	x22, x22, l_.str.67@PAGEOFF
LBB24_59:
	str	w9, [x20, #2952]
	str	w21, [x20, #2956]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #2960]
	str	x22, [x20, #2968]
LBB24_60:
	mov	w0, #0                          ; =0x0
LBB24_61:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB24_62:
	mov	w9, #3                          ; =0x3
Lloh220:
	adrp	x22, l_.str.70@PAGE
Lloh221:
	add	x22, x22, l_.str.70@PAGEOFF
	b	LBB24_59
LBB24_63:
	mov	x21, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
Lloh222:
	adrp	x22, l_.str.69@PAGE
Lloh223:
	add	x22, x22, l_.str.69@PAGEOFF
	b	LBB24_59
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh222, Lloh223
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_decode
_oq_decode:                             ; @oq_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x28, [x0]
	ldr	w22, [x28, #272]
	mov	w19, #1                         ; =0x1
	cbz	w22, LBB25_75
; %bb.1:
	mov	x20, x0
	mov	x26, #0                         ; =0x0
	add	x8, x0, #104, lsl #12           ; =425984
	add	x10, x8, #2952
	add	x27, x0, #16
	mov	w8, #17232                      ; =0x4350
	add	x8, x0, x8
	stp	x10, x8, [sp, #24]              ; 16-byte Folded Spill
	add	x9, x0, #100, lsl #12           ; =409600
	ldr	w24, [x9, #864]
	mov	w9, #24                         ; =0x18
	mov	w10, #2152                      ; =0x868
Lloh224:
	adrp	x1, l_.str.72@PAGE
Lloh225:
	add	x1, x1, l_.str.72@PAGEOFF
LBB25_2:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_10 Depth 2
                                        ;     Child Loop BB25_16 Depth 2
	ldr	x23, [x28, #256]
	mov	w8, w26
	umaddl	x25, w8, w9, x23
	umaddl	x21, w8, w10, x27
	str	w24, [x21, #2056]
	ldr	w8, [x25]
	ldr	w9, [x28, #248]
	cmp	w8, w9
	b.hs	LBB25_47
; %bb.3:                                ;   in Loop: Header=BB25_2 Depth=1
	ldr	x9, [x28, #232]
	cbz	x9, LBB25_47
; %bb.4:                                ;   in Loop: Header=BB25_2 Depth=1
	ldr	x0, [x9, x8, lsl #3]
	cbz	x0, LBB25_47
; %bb.5:                                ;   in Loop: Header=BB25_2 Depth=1
	bl	_strcmp
	cbz	w0, LBB25_53
; %bb.6:                                ;   in Loop: Header=BB25_2 Depth=1
	ldr	w9, [x25, #8]
	ldr	w10, [x28, #288]
	cmp	w10, w9
	b.lo	LBB25_51
; %bb.7:                                ;   in Loop: Header=BB25_2 Depth=1
	ldr	w8, [x25, #12]
	sub	w11, w8, #1
	sub	w10, w10, w9
	cmp	w11, w10
	b.hs	LBB25_51
; %bb.8:                                ;   in Loop: Header=BB25_2 Depth=1
	cbz	w26, LBB25_13
; %bb.9:                                ;   in Loop: Header=BB25_2 Depth=1
	add	x10, x8, x9
	add	x11, x23, #12
	mov	x12, x26
LBB25_10:                               ;   Parent Loop BB25_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w13, w14, [x11, #-4]
	add	x14, x14, x13
	cmp	x14, x9
	ccmp	x10, x13, #0, hi
	b.hi	LBB25_46
; %bb.11:                               ;   in Loop: Header=BB25_10 Depth=2
	add	x11, x11, #24
	subs	x12, x12, #1
	b.ne	LBB25_10
; %bb.12:                               ;   in Loop: Header=BB25_2 Depth=1
	cbz	w8, LBB25_43
LBB25_13:                               ;   in Loop: Header=BB25_2 Depth=1
	str	x27, [sp, #8]                   ; 8-byte Folded Spill
	mov	w27, #0                         ; =0x0
	add	x9, x21, #8
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	w11, #17248                     ; =0x4360
	movk	w11, #6, lsl #16
	b	LBB25_16
LBB25_14:                               ;   in Loop: Header=BB25_16 Depth=2
	ldrb	w8, [x22, #8]
	cmp	w8, #1
	b.hi	LBB25_72
LBB25_15:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	w24, [x20, x11]
	mov	w8, #-1                         ; =0xffffffff
	stp	w24, w8, [x22, #72]
	ldr	w8, [x25, #12]
	add	w27, w23, w27
	cmp	w27, w8
	b.hs	LBB25_42
LBB25_16:                               ;   Parent Loop BB25_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w24, #1, lsl #12                ; =4096
	b.eq	LBB25_49
; %bb.17:                               ;   in Loop: Header=BB25_16 Depth=2
	add	w9, w24, #1
	str	w9, [x20, x11]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w10, #96                        ; =0x60
	umaddl	x22, w24, w10, x9
	stp	w26, w27, [x22, #64]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x22, #80]
	ldr	x9, [x28, #280]
	ldr	w10, [x25, #8]
	add	x9, x9, x10
	add	x0, x9, w27, uxtw
	sub	w1, w8, w27
	mov	x2, x22
	mov	w24, #17248                     ; =0x4360
	movk	w24, #6, lsl #16
	bl	_isa_decode
	cbz	w0, LBB25_50
; %bb.18:                               ;   in Loop: Header=BB25_16 Depth=2
	mov	x23, x0
	ldr	x8, [x20, #8]
	ldr	w9, [x20, x24]
	sub	w9, w9, #1
	mov	w10, #28                        ; =0x1c
	umaddl	x8, w9, w10, x8
	mov	w9, #34008                      ; =0x84d8
	movk	w9, #7, lsl #16
	add	x8, x8, x9
	ldrb	w9, [x22]
	stp	w26, w27, [x8]
	str	xzr, [x8, #8]
	stur	xzr, [x8, #14]
	strb	w9, [x8, #22]
	stur	wzr, [x8, #23]
	strb	wzr, [x8, #27]
	ldrb	w24, [x22]
	add	x1, sp, #46
	mov	x0, x24
	bl	_oq_scalar
	tbz	w0, #31, LBB25_21
; %bb.19:                               ;   in Loop: Header=BB25_16 Depth=2
	cmp	w24, #252
	b.hi	LBB25_78
; %bb.20:                               ;   in Loop: Header=BB25_16 Depth=2
Lloh226:
	adrp	x10, lJTI25_0@PAGE
Lloh227:
	add	x10, x10, lJTI25_0@PAGEOFF
	adr	x8, LBB25_21
	ldrb	w9, [x10, x24]
	add	x8, x8, x9, lsl #2
	br	x8
LBB25_21:                               ;   in Loop: Header=BB25_16 Depth=2
	cmp	w24, #59
	mov	w11, #17248                     ; =0x4360
	movk	w11, #6, lsl #16
	b.hi	LBB25_39
; %bb.22:                               ;   in Loop: Header=BB25_16 Depth=2
	lsl	x8, x19, x24
	mov	w9, #22528                      ; =0x5800
	movk	w9, #3, lsl #16
	tst	x8, x9
	b.eq	LBB25_34
; %bb.23:                               ;   in Loop: Header=BB25_16 Depth=2
	ldrh	w8, [x22, #8]
	ldrh	w9, [x25, #16]
	cmp	w8, w9
	b.hs	LBB25_52
LBB25_24:                               ;   in Loop: Header=BB25_16 Depth=2
	sub	w8, w24, #13
	and	w8, w8, #0xff
	cmp	w8, #1
	b.hi	LBB25_30
; %bb.25:                               ;   in Loop: Header=BB25_16 Depth=2
	add	x8, x22, #8
	cmp	w24, #13
	b.eq	LBB25_27
; %bb.26:                               ;   in Loop: Header=BB25_16 Depth=2
	ldrh	w8, [x8]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #3
	ldrb	w9, [x8], #4
	cmp	w9, #8
	b.ne	LBB25_48
LBB25_27:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	x9, [x20, #8]
	ldr	x9, [x9]
	cbz	x9, LBB25_48
; %bb.28:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	w8, [x8]
	ldr	w10, [x9, #16]
	cmp	w8, w10
	b.hs	LBB25_48
; %bb.29:                               ;   in Loop: Header=BB25_16 Depth=2
	add	x8, x9, x8, lsl #5
	ldrb	w8, [x8, #56]
	tbz	w8, #1, LBB25_48
LBB25_30:                               ;   in Loop: Header=BB25_16 Depth=2
	and	w8, w24, #0xfffffff7
	cmp	w8, #80
	b.ne	LBB25_15
; %bb.31:                               ;   in Loop: Header=BB25_16 Depth=2
	ldrb	w8, [x22, #8]
	cmp	w8, #3
	b.ne	LBB25_54
; %bb.32:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	x8, [x20, #8]
	ldr	w9, [x8, #12]
	cmp	w9, #64
	b.eq	LBB25_55
; %bb.33:                               ;   in Loop: Header=BB25_16 Depth=2
	add	w10, w9, #1
	str	w10, [x8, #12]
	strh	w9, [x22, #80]
	sxth	x9, w9
	mov	w10, #12                        ; =0xc
	smaddl	x8, w9, w10, x8
	stp	w26, w27, [x8, #20]
	strb	w24, [x8, #28]
	sturh	wzr, [x8, #29]
	strb	wzr, [x8, #31]
	b	LBB25_15
LBB25_34:                               ;   in Loop: Header=BB25_16 Depth=2
	cmp	x24, #4
	b.eq	LBB25_40
; %bb.35:                               ;   in Loop: Header=BB25_16 Depth=2
	cmp	x24, #59
	b.ne	LBB25_39
; %bb.36:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	w8, [x22, #8]
	ldr	w9, [x28, #272]
	cmp	w8, w9
	b.hs	LBB25_71
; %bb.37:                               ;   in Loop: Header=BB25_16 Depth=2
	cbz	w8, LBB25_73
; %bb.38:                               ;   in Loop: Header=BB25_16 Depth=2
	lsl	w8, w19, w8
	ldrb	w9, [x21, #2080]
	orr	w8, w9, w8
	strb	w8, [x21, #2080]
	b	LBB25_15
LBB25_39:                               ;   in Loop: Header=BB25_16 Depth=2
	cmp	w24, #3
	b.eq	LBB25_14
	b	LBB25_24
LBB25_40:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	w8, [x22, #8]
	ldr	w9, [x28, #248]
	cmp	w8, w9
	b.hs	LBB25_56
; %bb.41:                               ;   in Loop: Header=BB25_16 Depth=2
	ldr	x9, [x28, #232]
	ldr	x8, [x9, x8, lsl #3]
	cbnz	x8, LBB25_15
	b	LBB25_56
LBB25_42:                               ;   in Loop: Header=BB25_2 Depth=1
	ldr	w22, [x28, #272]
	ldr	x27, [sp, #8]                   ; 8-byte Folded Reload
LBB25_43:                               ;   in Loop: Header=BB25_2 Depth=1
	str	w24, [x21, #2060]
	add	x26, x26, #1
	cmp	w26, w22
	mov	w9, #24                         ; =0x18
	mov	w10, #2152                      ; =0x868
Lloh228:
	adrp	x1, l_.str.72@PAGE
Lloh229:
	add	x1, x1, l_.str.72@PAGEOFF
	b.lo	LBB25_2
; %bb.44:
	cbz	w22, LBB25_76
; %bb.45:
	mov	x26, #0                         ; =0x0
	mov	w8, w22
	mov	w9, #17300                      ; =0x4394
	add	x9, x20, x9
	mov	w10, #2152                      ; =0x868
	mov	w11, #96                        ; =0x60
	b	LBB25_58
LBB25_46:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
Lloh230:
	adrp	x10, l_.str.75@PAGE
Lloh231:
	add	x10, x10, l_.str.75@PAGEOFF
	b	LBB25_74
LBB25_47:
	mov	w27, #0                         ; =0x0
	mov	w8, #2                          ; =0x2
Lloh232:
	adrp	x10, l_.str.71@PAGE
Lloh233:
	add	x10, x10, l_.str.71@PAGEOFF
	b	LBB25_74
LBB25_48:
	mov	w8, #1                          ; =0x1
Lloh234:
	adrp	x10, l_.str.84@PAGE
Lloh235:
	add	x10, x10, l_.str.84@PAGEOFF
	b	LBB25_74
LBB25_49:
	mov	w8, #3                          ; =0x3
Lloh236:
	adrp	x10, l_.str.76@PAGE
Lloh237:
	add	x10, x10, l_.str.76@PAGEOFF
	b	LBB25_74
LBB25_50:
	mov	w8, #2                          ; =0x2
Lloh238:
	adrp	x10, l_.str.77@PAGE
Lloh239:
	add	x10, x10, l_.str.77@PAGEOFF
	b	LBB25_74
LBB25_51:
	mov	w27, #0                         ; =0x0
	mov	w8, #2                          ; =0x2
Lloh240:
	adrp	x10, l_.str.74@PAGE
Lloh241:
	add	x10, x10, l_.str.74@PAGEOFF
	b	LBB25_74
LBB25_52:
	mov	w8, #2                          ; =0x2
Lloh242:
	adrp	x10, l_.str.81@PAGE
Lloh243:
	add	x10, x10, l_.str.81@PAGEOFF
	b	LBB25_74
LBB25_53:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
Lloh244:
	adrp	x10, l_.str.73@PAGE
Lloh245:
	add	x10, x10, l_.str.73@PAGEOFF
	b	LBB25_74
LBB25_54:
	mov	w8, #1                          ; =0x1
Lloh246:
	adrp	x10, l_.str.85@PAGE
Lloh247:
	add	x10, x10, l_.str.85@PAGEOFF
	b	LBB25_74
LBB25_55:
	mov	w8, #3                          ; =0x3
Lloh248:
	adrp	x10, l_.str.86@PAGE
Lloh249:
	add	x10, x10, l_.str.86@PAGEOFF
	b	LBB25_74
LBB25_56:
	mov	w8, #2                          ; =0x2
Lloh250:
	adrp	x10, l_.str.80@PAGE
Lloh251:
	add	x10, x10, l_.str.80@PAGEOFF
	b	LBB25_74
LBB25_57:                               ;   in Loop: Header=BB25_58 Depth=1
	add	x26, x26, #1
	mov	w19, #1                         ; =0x1
	cmp	x26, x8
	mov	x27, x4
	b.eq	LBB25_75
LBB25_58:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_61 Depth 2
                                        ;       Child Loop BB25_64 Depth 3
	mov	x4, x27
	madd	x13, x26, x10, x27
	ldr	w12, [x13, #2056]
	ldr	w13, [x13, #2060]
	cmp	w12, w13
	b.hs	LBB25_57
; %bb.59:                               ;   in Loop: Header=BB25_58 Depth=1
	umaddl	x14, w12, w11, x9
	mov	x15, x12
	b	LBB25_61
LBB25_60:                               ;   in Loop: Header=BB25_61 Depth=2
	add	x15, x15, #1
	cmp	x15, x13
	b.eq	LBB25_57
LBB25_61:                               ;   Parent Loop BB25_58 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB25_64 Depth 3
	ldr	x16, [sp, #32]                  ; 8-byte Folded Reload
	madd	x16, x15, x11, x16
	ldrb	w17, [x16]
	sub	w0, w17, #56
	cmp	w0, #2
	b.hi	LBB25_67
; %bb.62:                               ;   in Loop: Header=BB25_61 Depth=2
	ldr	w27, [x16, #68]
	ldrsw	x0, [x16, #8]
	add	x0, x0, x27
	mov	x1, x14
	mov	x2, x12
	b	LBB25_64
LBB25_63:                               ;   in Loop: Header=BB25_64 Depth=3
	add	x2, x2, #1
	cmp	x13, x2
	b.eq	LBB25_66
LBB25_64:                               ;   Parent Loop BB25_58 Depth=1
                                        ;     Parent Loop BB25_61 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w3, [x1], #96
	cmp	x0, x3
	b.ne	LBB25_63
; %bb.65:                               ;   in Loop: Header=BB25_64 Depth=3
	str	w2, [x16, #76]
	b	LBB25_63
LBB25_66:                               ;   in Loop: Header=BB25_61 Depth=2
	ldr	w0, [x16, #76]
	cmn	w0, #1
	b.eq	LBB25_77
LBB25_67:                               ;   in Loop: Header=BB25_61 Depth=2
	ldr	w0, [x16, #72]
	cmp	w0, w13
	b.ne	LBB25_60
; %bb.68:                               ;   in Loop: Header=BB25_61 Depth=2
	cmp	w17, #56
	b.eq	LBB25_60
; %bb.69:                               ;   in Loop: Header=BB25_61 Depth=2
	cmp	w17, #61
	b.eq	LBB25_60
; %bb.70:
	ldr	w27, [x16, #68]
Lloh252:
	adrp	x10, l_.str.88@PAGE
Lloh253:
	add	x10, x10, l_.str.88@PAGEOFF
	mov	w8, #1                          ; =0x1
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	b	LBB25_74
LBB25_71:
	mov	w8, #2                          ; =0x2
Lloh254:
	adrp	x10, l_.str.82@PAGE
Lloh255:
	add	x10, x10, l_.str.82@PAGEOFF
	b	LBB25_74
LBB25_72:
	mov	w8, #2                          ; =0x2
Lloh256:
	adrp	x10, l_.str.79@PAGE
Lloh257:
	add	x10, x10, l_.str.79@PAGEOFF
	b	LBB25_74
LBB25_73:
	mov	w8, #1                          ; =0x1
Lloh258:
	adrp	x10, l_.str.83@PAGE
Lloh259:
	add	x10, x10, l_.str.83@PAGEOFF
LBB25_74:
	mov	w19, #0                         ; =0x0
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	stp	w8, w26, [x9]
	stp	w27, wzr, [x9, #8]
	str	x10, [x9, #16]
LBB25_75:
	mov	x0, x19
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB25_76:
	mov	w19, #1                         ; =0x1
	b	LBB25_75
LBB25_77:
Lloh260:
	adrp	x10, l_.str.87@PAGE
Lloh261:
	add	x10, x10, l_.str.87@PAGEOFF
	mov	w8, #2                          ; =0x2
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	b	LBB25_74
LBB25_78:
Lloh262:
	adrp	x10, l_.str.78@PAGE
Lloh263:
	add	x10, x10, l_.str.78@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB25_74
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.cfi_endproc
	.section	__TEXT,__const
lJTI25_0:
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_78-LBB25_21)>>2
	.byte	(LBB25_21-LBB25_21)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_function
lCPI26_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_function:                           ; @oq_function
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #33040                      ; =0x8110
Lloh264:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh265:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh266:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh267:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh268:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w8, #2152                       ; =0x868
	umaddl	x8, w1, w8, x0
	ldrb	w9, [x8, #2097]
	cmp	w9, #2
	b.eq	LBB26_49
; %bb.1:
	mov	x20, x1
	mov	x19, x0
	add	x10, x0, #104, lsl #12          ; =425984
	add	x23, x10, #2936
	cmp	w9, #1
	b.ne	LBB26_3
; %bb.2:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	stp	w8, w20, [x23, #16]
Lloh269:
	adrp	x8, l_.str.89@PAGE
Lloh270:
	add	x8, x8, l_.str.89@PAGEOFF
	stp	xzr, x8, [x23, #24]
	b	LBB26_50
LBB26_3:
	add	x22, x8, #16
	mov	w8, #1                          ; =0x1
	strb	w8, [x22, #2081]
	ldr	x24, [x19]
	ldr	w8, [x24, #272]
	cbz	w8, LBB26_9
; %bb.4:
	mov	w21, #0                         ; =0x0
	b	LBB26_6
LBB26_5:                                ;   in Loop: Header=BB26_6 Depth=1
	add	w21, w21, #1
	ldr	w8, [x24, #272]
	cmp	w21, w8
	b.hs	LBB26_9
LBB26_6:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x22, #2080]
	lsr	w8, w8, w21
	tbz	w8, #0, LBB26_5
; %bb.7:                                ;   in Loop: Header=BB26_6 Depth=1
	mov	x0, x19
	mov	x1, x21
	bl	_oq_function
	cbz	w0, LBB26_50
; %bb.8:                                ;   in Loop: Header=BB26_6 Depth=1
	ldr	x24, [x19]
	b	LBB26_5
LBB26_9:
	add	x8, x19, #100, lsl #12          ; =409600
	add	x21, x8, #848
	mov	w25, w20
	ldr	x8, [x19, #8]
	mov	w9, #56                         ; =0x38
	umaddl	x26, w25, w9, x8
	cmp	w20, #0
	cset	w8, ne
	strb	w8, [x26, #801]
	add	x0, sp, #248
	mov	w1, #32768                      ; =0x8000
	bl	_bzero
	ldr	x8, [x24, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w25, w9, x8
	ldrh	w9, [x8, #16]
	cbz	x9, LBB26_12
; %bb.10:
	add	x10, sp, #248
	mov	x11, #-4294967295               ; =0xffffffff00000001
	movi.2d	v0, #0000000000000000
	mov	w12, #1                         ; =0x1
LBB26_11:                               ; =>This Inner Loop Header: Depth=1
	str	x11, [x10]
	str	xzr, [x10, #56]
	stur	q0, [x10, #8]
	stur	q0, [x10, #24]
	stur	q0, [x10, #40]
	strb	w12, [x10, #57]
	add	x10, x10, #64
	subs	x9, x9, #1
	b.ne	LBB26_11
LBB26_12:
	add	x24, x26, #792
	ldrh	w9, [x8, #4]
	cbz	w9, LBB26_25
; %bb.13:
	mov	x9, #0                          ; =0x0
	add	x10, sp, #80
	add	x11, x22, #8
	add	x12, x22, #2064
	add	x13, x19, #100, lsl #12         ; =409600
	add	x13, x13, #876
	add	x14, x19, #100, lsl #12         ; =409600
	add	x14, x14, #1900
	mov	w16, #1                         ; =0x1
	mov	w17, #-1                        ; =0xffffffff
	movi.2d	v0, #0000000000000000
	add	x3, sp, #160
	mov	w4, #40                         ; =0x28
	mov	w5, #30720                      ; =0x7800
	mov	w6, #120                        ; =0x78
	mov	w7, #76                         ; =0x4c
	b	LBB26_15
LBB26_14:                               ;   in Loop: Header=BB26_15 Depth=1
	add	x9, x9, #1
	ldrh	w15, [x8, #4]
	cmp	x9, x15
	b.hs	LBB26_25
LBB26_15:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_22 Depth 2
	add	x0, x11, x9, lsl #3
	ldrb	w1, [x0]
	ldr	w26, [x0, #4]
	add	x15, sp, #248
	add	x28, x15, x9, lsl #6
	lsl	w0, w16, w1
	strh	w0, [x28]
	strh	wzr, [x28, #2]
	str	w17, [x28, #4]
	stur	q0, [x28, #8]
	stur	q0, [x28, #24]
	stur	q0, [x28, #40]
	str	xzr, [x28, #56]
	cmp	x1, #8
	b.ne	LBB26_14
; %bb.16:                               ;   in Loop: Header=BB26_15 Depth=1
	ldr	w0, [x24]
	strh	w0, [x12, x9, lsl #1]
	ldr	w2, [x13, w26, uxtw #2]
	mov	w15, #256                       ; =0x100
	sub	w0, w15, w0
	cmp	w2, w0
	b.hi	LBB26_31
; %bb.17:                               ;   in Loop: Header=BB26_15 Depth=1
	ldr	w27, [x21, #8]
	mov	w15, #65536                     ; =0x10000
	sub	w0, w15, w27
	cmp	w2, w0
	b.hi	LBB26_32
; %bb.18:                               ;   in Loop: Header=BB26_15 Depth=1
	ldr	w0, [x21, #24]
	mov	w15, #262144                    ; =0x40000
	sub	w1, w15, w0
	cmp	w2, w1
	b.hi	LBB26_33
; %bb.19:                               ;   in Loop: Header=BB26_15 Depth=1
	add	w0, w0, w2
	str	w0, [x21, #24]
	add	w0, w27, w2
	str	w0, [x21, #8]
	mov	w15, #256                       ; =0x100
	stp	w15, w26, [x28]
	str	w27, [x28, #8]
	stur	q0, [x28, #12]
	stur	q0, [x28, #28]
	stur	q0, [x28, #40]
	strb	w16, [x28, #56]
	stur	wzr, [x28, #57]
	str	wzr, [x28, #60]
	cbz	w2, LBB26_14
; %bb.20:                               ;   in Loop: Header=BB26_15 Depth=1
	mov	x28, #0                         ; =0x0
	b	LBB26_22
LBB26_21:                               ;   in Loop: Header=BB26_22 Depth=2
	umaddl	x15, w25, w5, x2
	umaddl	x15, w30, w6, x15
	add	x15, x15, #1240
	ldp	q1, q2, [sp, #80]
	stur	q1, [x15, #4]
	ldur	q1, [x10, #60]
	ldp	q3, q4, [sp, #160]
	stp	q1, q3, [x15, #64]
	ldp	q5, q1, [sp, #112]
	stur	q1, [x15, #52]
	stur	q5, [x15, #36]
	stur	q2, [x15, #20]
	strh	w9, [x15]
	strh	wzr, [x15, #2]
	str	q4, [x15, #96]
	ldr	x0, [sp, #192]
	str	x0, [x15, #112]
	add	x28, x28, #1
	ldr	w15, [x13, w26, uxtw #2]
	cmp	x28, x15
	b.hs	LBB26_14
LBB26_22:                               ;   Parent Loop BB26_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w30, [x24]
	add	w0, w30, #1
	str	w0, [x24]
	stp	q0, q0, [sp, #160]
	str	xzr, [sp, #192]
	lsl	x0, x16, x30
	lsr	x1, x30, #3
	and	x1, x1, #0x1ffffff8
	add	x1, x1, x3
	str	x0, [x1, #8]
	ldr	x0, [x21]
	add	w1, w27, w28
	umaddl	x0, w1, w4, x0
	ldr	x1, [sp, #192]
	str	x1, [x0, #32]
	ldp	q2, q1, [sp, #160]
	stp	q2, q1, [x0]
	ldr	x2, [x19, #8]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #112]
	stur	q0, [x10, #60]
	ldr	x1, [x2]
	cbz	x1, LBB26_21
; %bb.23:                               ;   in Loop: Header=BB26_22 Depth=2
	ldr	w0, [x14, w26, uxtw #2]
	ldr	x15, [x21, #2080]
	add	w0, w28, w0
	ldr	w0, [x15, w0, uxtw #2]
	ldr	w15, [x1, #28]
	cmp	w0, w15
	b.hs	LBB26_21
; %bb.24:                               ;   in Loop: Header=BB26_22 Depth=2
	ldr	x15, [x1, #10272]
	umaddl	x15, w0, w7, x15
	ldp	q1, q2, [x15, #32]
	stp	q1, q2, [sp, #112]
	ldur	q1, [x15, #60]
	stur	q1, [x10, #60]
	ldp	q2, q1, [x15]
	stp	q2, q1, [sp, #80]
	b	LBB26_21
LBB26_25:
	ldr	w1, [x22, #2056]
	add	x2, sp, #248
	mov	x0, x19
	mov	w3, #0                          ; =0x0
	bl	_oq_join
	cbz	w0, LBB26_50
; %bb.26:
	add	x8, x19, #100, lsl #12          ; =409600
	add	x26, x8, #2936
	mov	w8, #17316                      ; =0x43a4
	add	x27, x19, x8
	mov	w28, #96                        ; =0x60
LBB26_27:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23, #8]
	cbz	w8, LBB26_34
; %bb.28:                               ;   in Loop: Header=BB26_27 Depth=1
	ldr	w9, [x21, #20]
	add	w10, w9, #1
	str	w10, [x21, #20]
	cmp	w9, #64, lsl #12                ; =262144
	b.eq	LBB26_46
; %bb.29:                               ;   in Loop: Header=BB26_27 Depth=1
	ldr	w9, [x23]
	ldr	w1, [x26, x9, lsl #2]
	add	w9, w9, #1
	and	w9, w9, #0xfff
	str	w9, [x23]
	sub	w8, w8, #1
	str	w8, [x23, #8]
	umull	x8, w1, w28
	strb	wzr, [x27, x8]
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_step
	tbnz	w0, #0, LBB26_27
; %bb.30:
	mov	w0, #0                          ; =0x0
	b	LBB26_50
LBB26_31:
	mov	w0, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	stp	w8, w20, [x23, #16]
Lloh271:
	adrp	x8, l_.str.90@PAGE
Lloh272:
	add	x8, x8, l_.str.90@PAGEOFF
	stp	xzr, x8, [x23, #24]
	b	LBB26_50
LBB26_32:
	mov	w0, #0                          ; =0x0
Lloh273:
	adrp	x8, lCPI26_0@PAGE
Lloh274:
	ldr	q0, [x8, lCPI26_0@PAGEOFF]
	str	q0, [x23, #16]
Lloh275:
	adrp	x8, l_.str.94@PAGE
Lloh276:
	add	x8, x8, l_.str.94@PAGEOFF
	str	x8, [x23, #32]
	b	LBB26_50
LBB26_33:
	mov	w0, #0                          ; =0x0
Lloh277:
	adrp	x8, lCPI26_0@PAGE
Lloh278:
	ldr	q0, [x8, lCPI26_0@PAGEOFF]
	str	q0, [x23, #16]
Lloh279:
	adrp	x8, l_.str.95@PAGE
Lloh280:
	add	x8, x8, l_.str.95@PAGEOFF
	str	x8, [x23, #32]
	b	LBB26_50
LBB26_34:
	ldr	w9, [x22, #2056]
	ldr	w10, [x22, #2060]
	cmp	w9, w10
	b.hs	LBB26_38
; %bb.35:
	mov	w8, #96                         ; =0x60
	umaddl	x8, w9, w8, x19
	mov	w11, #17300                     ; =0x4394
	add	x8, x8, x11
	sub	x9, x10, x9
LBB26_36:                               ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x8, #20]
	cbz	x10, LBB26_52
; %bb.37:                               ;   in Loop: Header=BB26_36 Depth=1
	add	x8, x8, #96
	subs	x9, x9, #1
	b.ne	LBB26_36
LBB26_38:
	ldrb	w8, [x22, #2082]
	tbz	w8, #0, LBB26_47
; %bb.39:
	ldrb	w8, [x22]
	cmp	w8, #8
	b.ne	LBB26_48
; %bb.40:
	ldr	w8, [x22, #4]
	add	x8, x19, x8, lsl #2
	add	x9, x8, #100, lsl #12           ; =409600
	ldr	w8, [x9, #876]
	str	w8, [x24, #4]
	cbz	w8, LBB26_48
; %bb.41:
	mov	x8, #0                          ; =0x0
	add	x9, x19, #100, lsl #12          ; =409600
	add	x9, x9, #1900
	mov	w10, #30720                     ; =0x7800
	mov	w11, #50392                     ; =0xc4d8
	movk	w11, #3, lsl #16
	umaddl	x10, w25, w10, x11
	movi.2d	v0, #0000000000000000
	mov	w11, #40                        ; =0x28
	mov	w12, #76                        ; =0x4c
	b	LBB26_43
LBB26_42:                               ;   in Loop: Header=BB26_43 Depth=1
	ldr	x14, [x21]
	ldr	w15, [x22, #2096]
	add	w15, w8, w15
	umaddl	x14, w15, w11, x14
	ldp	q1, q2, [x14]
	stp	q1, q2, [sp, #208]
	ldr	x14, [x14, #32]
	add	x13, x13, x10
	ldp	q2, q1, [sp]
	stur	q1, [x13, #20]
	ldp	q1, q3, [sp, #32]
	stur	q1, [x13, #36]
	str	x14, [sp, #240]
	str	wzr, [x13]
	stur	q3, [x13, #52]
	stur	q2, [x13, #4]
	ldp	q1, q2, [sp, #208]
	stp	q1, q2, [x13, #80]
	ldur	q2, [sp, #60]
	str	x14, [x13, #112]
	str	q2, [x13, #64]
	add	x8, x8, #1
	ldr	w13, [x24, #4]
	add	x10, x10, #120
	cmp	x8, x13
	b.hs	LBB26_48
LBB26_43:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x19, #8]
	ldr	w15, [x22, #4]
	stp	q0, q0, [sp]
	stp	q0, q0, [sp, #32]
	stur	q0, [sp, #60]
	ldr	x14, [x13]
	cbz	x14, LBB26_42
; %bb.44:                               ;   in Loop: Header=BB26_43 Depth=1
	ldr	w15, [x9, x15, lsl #2]
	ldr	x16, [x21, #2080]
	add	w15, w8, w15
	ldr	w15, [x16, w15, uxtw #2]
	ldr	w16, [x14, #28]
	cmp	w15, w16
	b.hs	LBB26_42
; %bb.45:                               ;   in Loop: Header=BB26_43 Depth=1
	ldr	x14, [x14, #10272]
	umaddl	x14, w15, w12, x14
	ldp	q1, q2, [x14, #32]
	stp	q1, q2, [sp, #32]
	ldur	q1, [x14, #60]
	stur	q1, [sp, #60]
	ldp	q2, q1, [x14]
	stp	q2, q1, [sp]
	b	LBB26_42
LBB26_46:
	mov	w0, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	stp	w8, w20, [x23, #16]
Lloh281:
	adrp	x8, l_.str.91@PAGE
Lloh282:
	add	x8, x8, l_.str.91@PAGEOFF
	stp	xzr, x8, [x23, #24]
	b	LBB26_50
LBB26_47:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	stp	w8, w20, [x23, #16]
Lloh283:
	adrp	x8, l_.str.93@PAGE
Lloh284:
	add	x8, x8, l_.str.93@PAGEOFF
	stp	xzr, x8, [x23, #24]
	b	LBB26_50
LBB26_48:
	mov	w8, #2                          ; =0x2
	strb	w8, [x22, #2081]
LBB26_49:
	mov	w0, #1                          ; =0x1
LBB26_50:
	ldur	x8, [x29, #-104]
Lloh285:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh286:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh287:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB26_53
; %bb.51:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #272
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB26_52:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x8]
	mov	w9, #1                          ; =0x1
	stp	w9, w20, [x23, #16]
	stp	w8, wzr, [x23, #24]
Lloh288:
	adrp	x8, l_.str.92@PAGE
Lloh289:
	add	x8, x8, l_.str.92@PAGEOFF
	str	x8, [x23, #32]
	b	LBB26_50
LBB26_53:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh266, Lloh267, Lloh268
	.loh AdrpAdd	Lloh269, Lloh270
	.loh AdrpAdd	Lloh271, Lloh272
	.loh AdrpAdd	Lloh275, Lloh276
	.loh AdrpAdrp	Lloh273, Lloh275
	.loh AdrpLdr	Lloh273, Lloh274
	.loh AdrpAdd	Lloh279, Lloh280
	.loh AdrpAdrp	Lloh277, Lloh279
	.loh AdrpLdr	Lloh277, Lloh278
	.loh AdrpAdd	Lloh281, Lloh282
	.loh AdrpAdd	Lloh283, Lloh284
	.loh AdrpLdrGotLdr	Lloh285, Lloh286, Lloh287
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpLdrGot	Lloh264, Lloh265
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_reachable
_oq_reachable:                          ; @oq_reachable
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
                                        ; kill: def $w1 killed $w1 def $x1
	ldr	x9, [x0, #8]
	ubfiz	x8, x1, #6, #32
	sub	x8, x8, w1, uxtw #3
	add	x9, x9, #800
	ldrb	w10, [x9, x8]
	tbnz	w10, #0, LBB27_6
; %bb.1:
	mov	x19, x0
	mov	w10, #1                         ; =0x1
	strb	w10, [x9, x8]
	ldr	x8, [x0]
	ldr	w9, [x8, #272]
	cbz	w9, LBB27_6
; %bb.2:
	mov	w20, #0                         ; =0x0
	mov	w9, w1
	mov	w10, #2152                      ; =0x868
	umull	x21, w9, w10
	add	x22, x19, #2096
	b	LBB27_4
LBB27_3:                                ;   in Loop: Header=BB27_4 Depth=1
	add	w20, w20, #1
	ldr	w9, [x8, #272]
	cmp	w20, w9
	b.hs	LBB27_6
LBB27_4:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x22, x21]
	lsr	w9, w9, w20
	tbz	w9, #0, LBB27_3
; %bb.5:                                ;   in Loop: Header=BB27_4 Depth=1
	mov	x0, x19
	mov	x1, x20
	bl	_oq_reachable
	ldr	x8, [x19]
	b	LBB27_3
LBB27_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_counts ; -- Begin function nvm_owned_array_origin_counts
	.globl	_nvm_owned_array_origin_counts
	.p2align	2
_nvm_owned_array_origin_counts:         ; @nvm_owned_array_origin_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB28_2
; %bb.1:
	ldr	x9, [x8, #8]
	ldr	w8, [x8, #16]
	str	w8, [x1, #8]
	str	x9, [x1]
LBB28_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_site ; -- Begin function nvm_owned_array_origin_site
	.globl	_nvm_owned_array_origin_site
	.p2align	2
_nvm_owned_array_origin_site:           ; @nvm_owned_array_origin_site
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB29_4
; %bb.1:
	cbz	x2, LBB29_4
; %bb.2:
	ldr	w9, [x8, #12]
	cmp	w1, w9
	b.hs	LBB29_5
; %bb.3:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldur	x9, [x8, #20]
	ldr	w8, [x8, #28]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB29_4:
	ret
LBB29_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_summary ; -- Begin function nvm_owned_array_origin_summary
	.globl	_nvm_owned_array_origin_summary
	.p2align	2
_nvm_owned_array_origin_summary:        ; @nvm_owned_array_origin_summary
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB30_4
; %bb.1:
	cbz	x2, LBB30_4
; %bb.2:
	ldr	w9, [x8, #8]
	cmp	w1, w9
	b.hs	LBB30_5
; %bb.3:
	mov	w9, #56                         ; =0x38
	umaddl	x8, w1, w9, x8
	add	x9, x8, #792
	ldp	q0, q1, [x9]
	ldr	q2, [x9, #32]
	ldr	x8, [x8, #840]
	str	x8, [x2, #48]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB30_4:
	ret
LBB30_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_input ; -- Begin function nvm_owned_array_origin_input
	.globl	_nvm_owned_array_origin_input
	.p2align	2
_nvm_owned_array_origin_input:          ; @nvm_owned_array_origin_input
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB31_5
; %bb.1:
	cbz	x3, LBB31_5
; %bb.2:
	ldr	w8, [x0, #8]
	cmp	w1, w8
	b.hs	LBB31_6
; %bb.3:
	mov	w8, #56                         ; =0x38
	umaddl	x8, w1, w8, x0
	ldr	w8, [x8, #792]
	cmp	w2, w8
	b.hs	LBB31_6
; %bb.4:
	mov	w8, w1
	mov	w9, #30720                      ; =0x7800
	umaddl	x8, w8, w9, x0
	mov	w9, #120                        ; =0x78
	umaddl	x8, w2, w9, x8
	add	x9, x8, #1240
	ldp	q0, q1, [x9]
	ldp	q2, q3, [x9, #32]
	stp	q2, q3, [x3, #32]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x9, #64]
	ldr	q2, [x9, #96]
	ldr	x8, [x8, #1352]
	str	x8, [x3, #112]
	stp	q1, q2, [x3, #80]
	str	q0, [x3, #64]
	mov	w8, #1                          ; =0x1
LBB31_5:
	mov	x0, x8
	ret
LBB31_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_result ; -- Begin function nvm_owned_array_origin_result
	.globl	_nvm_owned_array_origin_result
	.p2align	2
_nvm_owned_array_origin_result:         ; @nvm_owned_array_origin_result
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB32_5
; %bb.1:
	cbz	x3, LBB32_5
; %bb.2:
	ldr	w8, [x0, #8]
	cmp	w1, w8
	b.hs	LBB32_6
; %bb.3:
	mov	w8, #56                         ; =0x38
	umaddl	x8, w1, w8, x0
	ldr	w8, [x8, #796]
	cmp	w2, w8
	b.hs	LBB32_6
; %bb.4:
	mov	w8, w1
	mov	w9, #30720                      ; =0x7800
	umaddl	x8, w8, w9, x0
	mov	w9, #120                        ; =0x78
	umaddl	x8, w2, w9, x8
	add	x8, x8, #60, lsl #12            ; =245760
	add	x8, x8, #1240
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x3, #32]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x3, #112]
	stp	q1, q2, [x3, #80]
	str	q0, [x3, #64]
	mov	w8, #1                          ; =0x1
LBB32_5:
	mov	x0, x8
	ret
LBB32_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_owned_array_origin_obligation ; -- Begin function nvm_owned_array_origin_obligation
	.globl	_nvm_owned_array_origin_obligation
	.p2align	2
_nvm_owned_array_origin_obligation:     ; @nvm_owned_array_origin_obligation
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB33_4
; %bb.1:
	cbz	x2, LBB33_4
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB33_5
; %bb.3:
	mov	w9, #28                         ; =0x1c
	umaddl	x8, w1, w9, x8
	add	x8, x8, #120, lsl #12           ; =491520
	add	x8, x8, #1240
	ldr	q0, [x8]
	ldur	q1, [x8, #12]
	stur	q1, [x2, #12]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB33_4:
	ret
LBB33_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_forward_preflight
_record_forward_preflight:              ; @record_forward_preflight
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
Lloh290:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh291:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh292:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	add	x25, sp, #2112
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x25, #224]
	stp	q0, q0, [x25, #192]
	stp	q0, q0, [x25, #160]
	stp	q0, q0, [x25, #128]
	stp	q0, q0, [x25, #96]
	stp	q0, q0, [x25, #64]
	stp	q0, q0, [x25, #32]
	stp	q0, q0, [x25]
	cbz	w1, LBB34_22
; %bb.1:
	mov	x20, x3
	mov	x22, x1
	mov	x23, x0
	mov	x26, #0                         ; =0x0
	mov	w8, w1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x10, sp, #64
	b	LBB34_3
LBB34_2:                                ;   in Loop: Header=BB34_3 Depth=1
	add	x26, x26, #1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x26, x8
	b.eq	LBB34_22
LBB34_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB34_7 Depth 2
	ldrb	w8, [x25, x26]
	cbnz	w8, LBB34_2
; %bb.4:                                ;   in Loop: Header=BB34_3 Depth=1
	stp	w26, wzr, [sp, #64]
	mov	w21, #1                         ; =0x1
	strb	w21, [x25, x26]
	b	LBB34_7
LBB34_5:                                ;   in Loop: Header=BB34_7 Depth=2
	mov	w9, #2                          ; =0x2
	strb	w9, [x25, w24, uxtw]
	mov	x21, x8
LBB34_6:                                ;   in Loop: Header=BB34_7 Depth=2
	cbz	w21, LBB34_2
LBB34_7:                                ;   Parent Loop BB34_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	w8, w21, #1
	add	x19, x10, w8, uxtw #3
	ldp	w24, w27, [x19]
	ldr	w9, [x20, w24, uxtw #2]
	cmp	w27, w9
	b.eq	LBB34_5
; %bb.8:                                ;   in Loop: Header=BB34_7 Depth=2
	b.hi	LBB34_20
; %bb.9:                                ;   in Loop: Header=BB34_7 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x28, [x8, w24, uxtw #3]
	ldr	w2, [x23, #320]
	subs	x8, x2, x28
	b.lo	LBB34_20
; %bb.10:                               ;   in Loop: Header=BB34_7 Depth=2
	cmp	x8, #12
	b.lo	LBB34_20
; %bb.11:                               ;   in Loop: Header=BB34_7 Depth=2
	sub	w8, w8, #12
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #43690, lsl #16
	umull	x8, w8, w9
	lsr	x8, x8, #35
	cmp	w8, w27
	b.lo	LBB34_20
; %bb.12:                               ;   in Loop: Header=BB34_7 Depth=2
	ldr	x1, [x23, #312]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	mov	w8, #12                         ; =0xc
	umaddl	x8, w27, w8, x28
	add	x8, x8, #4
	str	x8, [sp, #56]
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB34_20
; %bb.13:                               ;   in Loop: Header=BB34_7 Depth=2
	add	w8, w27, #1
	str	w8, [x19, #4]
	ldr	w8, [sp, #36]
	cmn	w8, #1
	b.eq	LBB34_19
; %bb.14:                               ;   in Loop: Header=BB34_7 Depth=2
	cmp	w8, w22
	add	x10, sp, #64
	b.hs	LBB34_25
; %bb.15:                               ;   in Loop: Header=BB34_7 Depth=2
	ldrb	w9, [x25, w8, uxtw]
	cmp	w9, #2
	b.eq	LBB34_6
; %bb.16:                               ;   in Loop: Header=BB34_7 Depth=2
	cmp	w9, #1
	b.eq	LBB34_25
; %bb.17:                               ;   in Loop: Header=BB34_7 Depth=2
	cmp	w21, w22
	b.hs	LBB34_26
; %bb.18:                               ;   in Loop: Header=BB34_7 Depth=2
	mov	w9, #1                          ; =0x1
	strb	w9, [x25, w8, uxtw]
	add	x9, x10, w21, uxtw #3
	stp	w8, wzr, [x9]
	add	w21, w21, #1
	b	LBB34_6
LBB34_19:                               ;   in Loop: Header=BB34_7 Depth=2
	add	x10, sp, #64
	b	LBB34_6
LBB34_20:
Lloh293:
	adrp	x8, l_.str.47@PAGE
Lloh294:
	add	x8, x8, l_.str.47@PAGEOFF
LBB34_21:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w27, wzr, [x9, #8]
	str	x8, [x9, #16]
	mov	w8, #2                          ; =0x2
	stp	w8, w24, [x9]
	b	LBB34_23
LBB34_22:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	xzr, xzr, [x9]
Lloh295:
	adrp	x8, l_.str.50@PAGE
Lloh296:
	add	x8, x8, l_.str.50@PAGEOFF
	str	x8, [x9, #16]
LBB34_23:
	ldur	x8, [x29, #-104]
Lloh297:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh298:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh299:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB34_27
; %bb.24:
	add	sp, sp, #2400
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB34_25:
Lloh300:
	adrp	x8, l_.str.48@PAGE
Lloh301:
	add	x8, x8, l_.str.48@PAGEOFF
	b	LBB34_21
LBB34_26:
Lloh302:
	adrp	x8, l_.str.49@PAGE
Lloh303:
	add	x8, x8, l_.str.49@PAGEOFF
	b	LBB34_21
LBB34_27:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh290, Lloh291, Lloh292
	.loh AdrpAdd	Lloh293, Lloh294
	.loh AdrpAdd	Lloh295, Lloh296
	.loh AdrpLdrGotLdr	Lloh297, Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh302, Lloh303
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_scalar
_oq_scalar:                             ; @oq_scalar
	.cfi_startproc
; %bb.0:
	strh	wzr, [x1]
	sub	w8, w0, #1
	cmp	w8, #225
	b.hi	LBB35_12
; %bb.1:
Lloh304:
	adrp	x9, lJTI35_0@PAGE
Lloh305:
	add	x9, x9, lJTI35_0@PAGEOFF
	adr	x10, LBB35_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB35_2:
	mov	w8, #2                          ; =0x2
	strh	w8, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB35_3:
	mov	w8, #2                          ; =0x2
	b	LBB35_8
LBB35_4:
	mov	w8, #8                          ; =0x8
	b	LBB35_8
LBB35_5:
	mov	w8, #8                          ; =0x8
	strh	w8, [x1]
	mov	w0, #3                          ; =0x3
	ret
LBB35_6:
	mov	w0, #4                          ; =0x4
	ret
LBB35_7:
	mov	w8, #16                         ; =0x10
LBB35_8:
	strh	w8, [x1]
	mov	w0, #4                          ; =0x4
	ret
LBB35_9:
	mov	w0, #3                          ; =0x3
	ret
LBB35_10:
	mov	w0, #0                          ; =0x0
	ret
LBB35_11:
	mov	w0, #2                          ; =0x2
	ret
LBB35_12:
	mov	w0, #-1                         ; =0xffffffff
LBB35_13:
	ret
	.loh AdrpAdd	Lloh304, Lloh305
	.cfi_endproc
	.section	__TEXT,__const
lJTI35_0:
	.byte	(LBB35_13-LBB35_2)>>2
	.byte	(LBB35_9-LBB35_2)>>2
	.byte	(LBB35_6-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_10-LBB35_2)>>2
	.byte	(LBB35_11-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_6-LBB35_2)>>2
	.byte	(LBB35_6-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_2-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_5-LBB35_2)>>2
	.byte	(LBB35_5-LBB35_2)>>2
	.byte	(LBB35_5-LBB35_2)>>2
	.byte	(LBB35_5-LBB35_2)>>2
	.byte	(LBB35_5-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_3-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_4-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_12-LBB35_2)>>2
	.byte	(LBB35_7-LBB35_2)>>2
	.byte	(LBB35_7-LBB35_2)>>2
	.byte	(LBB35_7-LBB35_2)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_make_owner
lCPI36_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_make_owner:                         ; @oq_make_owner
	.cfi_startproc
; %bb.0:
	add	x8, x0, #104, lsl #12           ; =425984
	add	x8, x8, #2952
	add	x9, x0, #100, lsl #12           ; =409600
	add	x9, x9, #856
	add	x10, x0, w1, uxtw #2
	add	x11, x10, #100, lsl #12         ; =409600
	ldr	w11, [x11, #876]
	ldr	w10, [x9]
	mov	w12, #65536                     ; =0x10000
	sub	w12, w12, w10
	cmp	w11, w12
	b.ls	LBB36_2
; %bb.1:
	mov	w0, #0                          ; =0x0
Lloh306:
	adrp	x9, lCPI36_0@PAGE
Lloh307:
	ldr	q0, [x9, lCPI36_0@PAGEOFF]
	str	q0, [x8]
Lloh308:
	adrp	x9, l_.str.94@PAGE
Lloh309:
	add	x9, x9, l_.str.94@PAGEOFF
	str	x9, [x8, #16]
	ret
LBB36_2:
	ldr	w12, [x9, #16]
	mov	w13, #262144                    ; =0x40000
	sub	w13, w13, w12
	cmp	w11, w13
	b.ls	LBB36_4
; %bb.3:
	mov	w0, #0                          ; =0x0
Lloh310:
	adrp	x9, lCPI36_0@PAGE
Lloh311:
	ldr	q0, [x9, lCPI36_0@PAGEOFF]
	str	q0, [x8]
Lloh312:
	adrp	x9, l_.str.95@PAGE
Lloh313:
	add	x9, x9, l_.str.95@PAGEOFF
	str	x9, [x8, #16]
	ret
LBB36_4:
	add	w8, w12, w11
	str	w8, [x9, #16]
	add	w8, w10, w11
	str	w8, [x9]
	mov	w8, #256                        ; =0x100
	stp	w8, w1, [x2]
	str	w10, [x2, #8]
	movi.2d	v0, #0000000000000000
	stur	q0, [x2, #12]
	stur	q0, [x2, #28]
	stur	q0, [x2, #40]
	mov	w0, #1                          ; =0x1
	strb	w0, [x2, #56]
	stur	wzr, [x2, #57]
	str	wzr, [x2, #60]
	ret
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdrp	Lloh306, Lloh308
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdrp	Lloh310, Lloh312
	.loh AdrpLdr	Lloh310, Lloh311
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_join
lCPI37_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_join:                               ; @oq_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x8, x0, #104, lsl #12           ; =425984
	add	x22, x8, #2940
	add	x8, x0, #100, lsl #12           ; =409600
	add	x26, x8, #860
	ldr	w8, [x26, #4]
	cmp	w1, w8
	b.hs	LBB37_3
; %bb.1:
	mov	x19, x0
	mov	w8, #96                         ; =0x60
	umaddl	x8, w1, w8, x0
	mov	w9, #17232                      ; =0x4350
	add	x23, x8, x9
	ldr	w25, [x23, #64]
	cmp	w3, #257
	b.lo	LBB37_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x23, #68]
	mov	w9, #3                          ; =0x3
	stp	w9, w25, [x22, #12]
	stp	w8, wzr, [x22, #20]
Lloh314:
	adrp	x8, l_.str.97@PAGE
Lloh315:
	add	x8, x8, l_.str.97@PAGEOFF
	b	LBB37_4
LBB37_3:
	mov	w0, #0                          ; =0x0
Lloh316:
	adrp	x8, lCPI37_0@PAGE
Lloh317:
	ldr	q0, [x8, lCPI37_0@PAGEOFF]
	stur	q0, [x22, #12]
Lloh318:
	adrp	x8, l_.str.96@PAGE
Lloh319:
	add	x8, x8, l_.str.96@PAGEOFF
LBB37_4:
	stur	x8, [x22, #28]
LBB37_5:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB37_6:
	mov	x20, x2
	ldr	x8, [x19]
	ldr	x8, [x8, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w25, w9, x8
	ldrh	w27, [x8, #16]
	ldrsh	w8, [x23, #82]
	tbnz	w8, #31, LBB37_9
; %bb.7:
	cmp	w8, w3
	b.eq	LBB37_9
; %bb.8:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x23, #68]
	mov	w9, #2                          ; =0x2
	stp	w9, w25, [x22, #12]
	stp	w8, wzr, [x22, #20]
Lloh320:
	adrp	x8, l_.str.98@PAGE
Lloh321:
	add	x8, x8, l_.str.98@PAGEOFF
	b	LBB37_4
LBB37_9:
	sturb	wzr, [x29, #-81]
	ldr	x8, [x23, #88]
	cbz	x8, LBB37_16
; %bb.10:
	adds	w8, w27, w3
	b.eq	LBB37_15
; %bb.11:
	mov	x24, x1
	mov	x21, #0                         ; =0x0
	ubfiz	x25, x8, #6, #32
LBB37_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #88]
	add	x9, x20, x21
	ldp	w4, w5, [x23, #64]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #16]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [sp, #48]
	add	x1, x8, x21
	add	x2, sp, #16
	sub	x3, x29, #81
	mov	x0, x19
	bl	_oq_merge_value
	tbz	w0, #0, LBB37_18
; %bb.13:                               ;   in Loop: Header=BB37_12 Depth=1
	add	x21, x21, #64
	cmp	x25, x21
	b.ne	LBB37_12
; %bb.14:
	ldurb	w8, [x29, #-81]
	cmp	w8, #1
	b.eq	LBB37_21
LBB37_15:
	mov	w0, #1                          ; =0x1
	b	LBB37_5
LBB37_16:
	add	x21, x27, #256
	ldr	w28, [x26]
	mov	w8, #1048576                    ; =0x100000
	sub	w8, w8, w28
	cmp	w21, w8
	b.ls	LBB37_19
; %bb.17:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x23, #68]
	mov	w9, #3                          ; =0x3
	stp	w9, w25, [x22, #12]
	stp	w8, wzr, [x22, #20]
Lloh322:
	adrp	x8, l_.str.99@PAGE
Lloh323:
	add	x8, x8, l_.str.99@PAGEOFF
	b	LBB37_4
LBB37_18:
	mov	w0, #0                          ; =0x0
	b	LBB37_5
LBB37_19:
	str	w3, [sp, #12]                   ; 4-byte Folded Spill
	mov	x24, x1
	mov	x0, x21
	mov	w1, #64                         ; =0x40
	bl	_calloc
	str	x0, [x23, #88]
	cbz	x0, LBB37_23
; %bb.20:
	add	w8, w28, w21
	str	w8, [x26]
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	strh	w8, [x23, #82]
	add	w8, w27, w8
	lsl	w2, w8, #6
	mov	x1, x20
	bl	_memcpy
LBB37_21:
	mov	w8, w24
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #5
	mov	w9, #17316                      ; =0x43a4
	add	x9, x19, x9
	ldrb	w10, [x9, x8]
	mov	w0, #1                          ; =0x1
	tbnz	w10, #0, LBB37_5
; %bb.22:
	strb	w0, [x9, x8]
	ldr	w8, [x22]
	add	x8, x19, x8, lsl #2
	mov	w9, #19320                      ; =0x4b78
	movk	w9, #6, lsl #16
	str	w24, [x8, x9]
	ldp	w8, w9, [x22]
	add	w8, w8, #1
	and	w8, w8, #0xfff
	add	w9, w9, #1
	stp	w8, w9, [x22]
	b	LBB37_5
LBB37_23:
	ldr	w8, [x23, #68]
	mov	w9, #4                          ; =0x4
	stp	w9, w25, [x22, #12]
	stp	w8, wzr, [x22, #20]
Lloh324:
	adrp	x8, l_.str.100@PAGE
Lloh325:
	add	x8, x8, l_.str.100@PAGEOFF
	b	LBB37_4
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdrp	Lloh316, Lloh318
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh324, Lloh325
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_step
lCPI38_0:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	8                               ; 0x8
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_step:                               ; @oq_step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #33152                      ; =0x8180
Lloh326:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh327:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x1
	mov	x27, x0
Lloh328:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh329:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh330:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	add	x8, x0, #104, lsl #12           ; =425984
	add	x24, x8, #2952
	mov	w8, #96                         ; =0x60
	umaddl	x8, w1, w8, x0
	mov	w9, #17232                      ; =0x4350
	add	x26, x8, x9
	ldr	w22, [x26, #64]
	mov	x19, x0
	ldr	x9, [x19], #16
	ldr	x9, [x9, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x20, w22, w10, x9
	ldr	x1, [x8, #17320]
	ldrh	w8, [x20, #16]
	ldrh	w9, [x26, #82]
	str	x9, [sp, #112]                  ; 8-byte Folded Spill
	add	x8, x9, x8
	lsl	x2, x8, #6
	add	x21, sp, #360
	add	x0, sp, #360
	mov	w3, #32768                      ; =0x8000
	bl	___memcpy_chk
	ldrh	w28, [x20, #16]
	ldrb	w25, [x26]
	mov	x0, x25
	bl	_isa_get_info
	cbz	x0, LBB38_3
; %bb.1:
	stp	x24, x26, [sp, #96]             ; 16-byte Folded Spill
	mov	w8, #2152                       ; =0x868
	umaddl	x13, w22, w8, x19
	add	x1, x21, x28, lsl #6
	cmp	w25, #88
	mov	x11, x22
	str	x27, [sp, #88]                  ; 8-byte Folded Spill
	b.ne	LBB38_4
; %bb.2:
	mov	w21, #0                         ; =0x0
	ldr	x22, [sp, #104]                 ; 8-byte Folded Reload
	ldrh	w27, [x22, #16]
	mov	w24, #1                         ; =0x1
	tbz	w27, #31, LBB38_22
	b	LBB38_24
LBB38_3:
	ldr	w8, [x26, #68]
	mov	w9, #2                          ; =0x2
	stp	w9, w22, [x24]
	stp	w8, wzr, [x24, #8]
Lloh331:
	adrp	x8, l_.str.102@PAGE
Lloh332:
	add	x8, x8, l_.str.102@PAGEOFF
	str	x8, [x24, #16]
	b	LBB38_26
LBB38_4:
	cmp	w25, #14
	cset	w21, eq
	sub	w8, w25, #13
	and	w8, w8, #0xff
	cmp	w8, #1
	ldr	x22, [sp, #104]                 ; 8-byte Folded Reload
	b.hi	LBB38_10
; %bb.5:
	add	x8, x22, #8
	cmp	w25, #13
	b.eq	LBB38_7
; %bb.6:
	ldrh	w8, [x8]
	add	x8, x13, x8, lsl #3
	add	x8, x8, #12
LBB38_7:
	ldr	x9, [x27, #8]
	ldr	x9, [x9]
	cbz	x9, LBB38_13
; %bb.8:
	ldr	w8, [x8]
	ldr	w10, [x9, #16]
	cmp	w8, w10
	b.hs	LBB38_13
; %bb.9:
	add	x8, x9, x8, lsl #5
	ldr	w8, [x8, #44]
	b	LBB38_14
LBB38_10:
	cmp	w25, #61
	b.eq	LBB38_15
; %bb.11:
	cmp	w25, #59
	b.ne	LBB38_21
; %bb.12:
	mov	w21, #0                         ; =0x0
	ldr	x8, [x27]
	ldr	x8, [x8, #256]
	ldr	w9, [x22, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w27, [x8, #4]
	ldrb	w24, [x8, #21]
	tbz	w27, #31, LBB38_22
	b	LBB38_24
LBB38_13:
	mov	w8, #0                          ; =0x0
LBB38_14:
	cmp	w25, #13
	csel	w27, w8, wzr, eq
	csinc	w24, w8, wzr, ne
	tbz	w27, #31, LBB38_22
	b	LBB38_24
LBB38_15:
	ldrb	w8, [x20, #21]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB38_40
; %bb.16:
	cbz	w9, LBB38_52
; %bb.17:
	mov	x19, x11
	mov	x23, x13
	ldr	x2, [x13]
	mov	x0, x27
	mov	x21, x1
	bl	_oq_type
	tbz	w0, #0, LBB38_54
; %bb.18:
	ldp	q0, q1, [x21]
	str	q0, [sp, #240]
	ldp	q0, q2, [x21, #32]
	mov	x20, x21
	add	x8, sp, #240
	stp	q1, q0, [x8, #16]
	str	q2, [x8, #48]
	add	x2, sp, #240
	mov	x0, x27
	mov	x1, x19
	bl	_oq_require
	tbz	w0, #0, LBB38_176
; %bb.19:
	ldrb	w8, [x23, #2082]
	tbz	w8, #0, LBB38_61
; %bb.20:
	strb	wzr, [sp, #304]
	ldr	w5, [x22, #68]
	ldp	q0, q1, [x20]
	str	q0, [sp, #240]
	ldp	q0, q2, [x20, #32]
	add	x8, sp, #240
	stp	q1, q0, [x8, #16]
	str	q2, [x8, #48]
	add	x1, x23, #2088
	add	x2, sp, #240
	add	x3, sp, #304
	mov	x0, x27
	mov	x4, x19
	bl	_oq_merge_value
	cbz	w0, LBB38_26
	b	LBB38_53
LBB38_21:
	ldrsb	w27, [x0, #28]
	ldrsb	w24, [x0, #29]
	tbnz	w27, #31, LBB38_24
LBB38_22:
	tbnz	w24, #31, LBB38_24
; %bb.23:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	subs	w8, w8, w27
	b.hs	LBB38_28
LBB38_24:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #68]
	mov	w9, #2                          ; =0x2
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	stp	w9, w11, [x10]
	stp	w8, wzr, [x10, #8]
Lloh333:
	adrp	x8, l_.str.105@PAGE
Lloh334:
	add	x8, x8, l_.str.105@PAGEOFF
LBB38_25:
	str	x8, [x10, #16]
LBB38_26:
	ldur	x8, [x29, #-104]
Lloh335:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh336:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh337:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_191
; %bb.27:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #384
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB38_28:
	add	w26, w8, w24
	cmp	w26, #257
	b.lo	LBB38_30
; %bb.29:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #68]
	mov	w9, #3                          ; =0x3
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	stp	w9, w11, [x10]
	stp	w8, wzr, [x10, #8]
Lloh338:
	adrp	x8, l_.str.106@PAGE
Lloh339:
	add	x8, x8, l_.str.106@PAGEOFF
	b	LBB38_25
LBB38_30:
	stp	x13, x1, [sp, #56]              ; 16-byte Folded Spill
	stp	x11, x8, [sp, #72]              ; 16-byte Folded Spill
	mov	w8, w23
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x23, [x9, #8]
	mov	w9, #28                         ; =0x1c
	umaddl	x8, w8, w9, x23
	add	x8, x8, #120, lsl #12           ; =491520
	add	x22, x8, #1240
	add	x1, sp, #174
	mov	x0, x25
	bl	_oq_scalar
	tbnz	w0, #31, LBB38_33
; %bb.31:
	str	xzr, [sp, #232]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #216]
	stur	q0, [sp, #200]
	stur	q0, [sp, #184]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w0
	strh	w8, [sp, #176]
	strh	wzr, [sp, #178]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #180]
	cmp	w27, #3
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	b.lo	LBB38_41
; %bb.32:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #2                         ; =0x2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh340:
	adrp	x8, l_.str.107@PAGE
Lloh341:
	add	x8, x8, l_.str.107@PAGEOFF
	b	LBB38_25
LBB38_33:
	str	w24, [sp, #52]                  ; 4-byte Folded Spill
	str	x26, [sp, #40]                  ; 8-byte Folded Spill
	cmp	w25, #252
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	b.hi	LBB38_145
; %bb.34:
	mov	x2, x25
	mov	x24, x22
Lloh342:
	adrp	x8, lJTI38_0@PAGE
Lloh343:
	add	x8, x8, lJTI38_0@PAGEOFF
	adr	x9, LBB38_35
	ldrh	w10, [x8, x25, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB38_35:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x19, x8, x3, lsl #6
	ldrh	w11, [x19]
	mov	x9, x19
	ldr	x8, [x9, #2]!
	add	x14, sp, #240
	str	x8, [x14, #64]
	ldp	x8, x28, [x19, #8]
	stur	x8, [x14, #70]
	ldp	q1, q0, [x19, #16]
	ldp	x20, x25, [x19, #32]
	ldr	x27, [x19, #24]
	ldr	x21, [x19, #48]
	ldrb	w8, [x19, #56]
	ldrb	w12, [x19, #57]
	mov	x10, x19
	ldr	w13, [x10, #58]!
	str	w13, [sp, #168]
	cmp	w8, #0
	ldrh	w13, [x19, #62]
Lloh344:
	adrp	x8, l_.str.121@PAGE
Lloh345:
	add	x8, x8, l_.str.121@PAGEOFF
	ccmp	w12, #0, #0, eq
	strh	w13, [sp, #172]
	b.ne	LBB38_174
; %bb.36:
	cmp	w11, #128
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	b.ne	LBB38_175
; %bb.37:
	cmeq.2d	v1, v1, #0
	cmeq.2d	v0, v0, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB38_111
; %bb.38:
	cbnz	x21, LBB38_111
; %bb.39:
Lloh346:
	adrp	x8, l_.str.121@PAGE
Lloh347:
	add	x8, x8, l_.str.121@PAGEOFF
	b	LBB38_175
LBB38_40:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #68]
	mov	w9, #2                          ; =0x2
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	stp	w9, w11, [x10]
	stp	w8, wzr, [x10, #8]
Lloh348:
	adrp	x8, l_.str.103@PAGE
Lloh349:
	add	x8, x8, l_.str.103@PAGEOFF
	b	LBB38_25
LBB38_41:
	str	w24, [sp, #52]                  ; 4-byte Folded Spill
	str	x26, [sp, #40]                  ; 8-byte Folded Spill
	strb	w27, [x22, #23]
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	cmp	w8, w3
	mov	x2, x25
	b.ls	LBB38_180
; %bb.42:
	mov	x8, #0                          ; =0x0
	ldrh	w9, [sp, #174]
	add	x10, x22, #14
	add	w13, w2, #40
	lsl	x11, x28, #6
	add	x11, x11, x3, lsl #6
	add	x12, sp, #360
	add	x11, x11, x12
	add	x11, x11, #48
	ldr	x12, [sp, #112]                 ; 8-byte Folded Reload
	sub	x12, x12, x3
Lloh350:
	adrp	x14, lCPI38_0@PAGE
Lloh351:
	ldr	q0, [x14, lCPI38_0@PAGEOFF]
	and	w13, w13, #0xff
	mov	w14, #1                         ; =0x1
	b	LBB38_45
LBB38_43:                               ;   in Loop: Header=BB38_45 Depth=1
	lsl	w15, w14, w8
	ldrb	w16, [x22, #24]
	orr	w15, w16, w15
	strb	w15, [x22, #24]
LBB38_44:                               ;   in Loop: Header=BB38_45 Depth=1
	add	x11, x11, #64
	add	x8, x8, #1
	add	x10, x10, #2
	cmp	x12, x8
	b.eq	LBB38_180
LBB38_45:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w15, [x11, #8]
	ldrb	w16, [x11, #9]
	ldp	q2, q1, [x11, #-32]
	cmeq.2d	v1, v1, #0
	cmeq.2d	v2, v2, #0
	uzp1.4s	v1, v2, v1
	bic.16b	v1, v0, v1
	addv.4s	s1, v1
	fmov	w17, s1
	and	w17, w17, #0xff
	cmp	w15, #0
	and	w15, w17, #0xf
	ccmp	w15, #0, #0, eq
	ccmp	w16, #0, #0, eq
	b.ne	LBB38_55
; %bb.46:                               ;   in Loop: Header=BB38_45 Depth=1
	ldurh	w15, [x11, #-48]
	ldr	x16, [x11]
	sub	w17, w15, #1
	cmp	x16, #0
	ccmp	w17, #31, #2, eq
	b.hs	LBB38_55
; %bb.47:                               ;   in Loop: Header=BB38_45 Depth=1
	ldrh	w16, [x22, #8]
	orr	w16, w16, w15
	strh	w16, [x22, #8]
	ldrh	w16, [x22, #10]
	orr	w16, w16, w9
	strh	w16, [x22, #10]
	ldrh	w16, [x10]
	orr	w16, w16, w15
	strh	w16, [x10]
	strh	w9, [x10, #4]
	cbz	w9, LBB38_44
; %bb.48:                               ;   in Loop: Header=BB38_45 Depth=1
	cmp	w15, w9
	b.eq	LBB38_44
; %bb.49:                               ;   in Loop: Header=BB38_45 Depth=1
	cmp	w13, #5
	b.hi	LBB38_51
; %bb.50:                               ;   in Loop: Header=BB38_45 Depth=1
	and	w15, w15, #0x1e
	cmp	w15, #8
	b.eq	LBB38_43
LBB38_51:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh352:
	adrp	x8, l_.str.109@PAGE
Lloh353:
	add	x8, x8, l_.str.109@PAGEOFF
	b	LBB38_25
LBB38_52:
	ldrb	w8, [x13, #2082]
	tbz	w8, #0, LBB38_56
LBB38_53:
	mov	w0, #1                          ; =0x1
	b	LBB38_26
LBB38_54:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #68]
	mov	w9, #1                          ; =0x1
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	stp	w9, w19, [x10]
	stp	w8, wzr, [x10, #8]
Lloh354:
	adrp	x8, l_.str.104@PAGE
Lloh355:
	add	x8, x8, l_.str.104@PAGEOFF
	b	LBB38_25
LBB38_55:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh356:
	adrp	x8, l_.str.108@PAGE
Lloh357:
	add	x8, x8, l_.str.108@PAGEOFF
	b	LBB38_25
LBB38_56:
	mov	w8, #1                          ; =0x1
	strb	w8, [x13, #2082]
	mov	w0, #1                          ; =0x1
	b	LBB38_26
LBB38_57:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #23]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, x9, x3, lsl #6
	ldrh	w10, [x9]
	ldrh	w11, [x24, #14]
	orr	w10, w11, w10
	strh	w10, [x24, #14]
	mov	w10, #16                        ; =0x10
	strh	w10, [x24, #18]
	ldrh	w11, [x9]
	ldrh	w12, [x24, #8]
	orr	w11, w12, w11
	strh	w11, [x24, #8]
	strh	w10, [x24, #10]
	ldrb	w10, [x9, #56]
	and	w10, w10, #0xff
	ldrb	w11, [x9, #57]
	orr	w10, w11, w10
	cbnz	w10, LBB38_60
; %bb.58:
	ldp	q1, q0, [x9, #16]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w10, s0
	tbnz	w10, #0, LBB38_60
; %bb.59:
	ldrh	w10, [x9]
	ldr	x9, [x9, #48]
	cmp	x9, #0
	ccmp	w10, #16, #0, eq
	b.eq	LBB38_180
LBB38_60:
	mov	w0, #0                          ; =0x0
	ldp	x10, x9, [sp, #96]              ; 16-byte Folded Reload
	ldr	w9, [x9, #68]
	str	w8, [x10]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w8, w9, [x10, #4]
	str	wzr, [x10, #12]
Lloh358:
	adrp	x8, l_.str.126@PAGE
Lloh359:
	add	x8, x8, l_.str.126@PAGEOFF
	b	LBB38_25
LBB38_61:
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #2082]
	add	x8, x23, #2088
	ldp	q0, q1, [x20]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x20, #32]
	stp	q0, q1, [x8, #32]
	mov	w0, #1                          ; =0x1
	b	LBB38_26
LBB38_62:
	ldp	x8, x10, [sp, #104]             ; 16-byte Folded Reload
	ldrh	w8, [x8, #8]
	add	x9, sp, #360
	add	x23, x9, x8, lsl #6
	ldp	q0, q1, [x23]
	stp	q0, q1, [sp, #176]
	ldp	q0, q1, [x23, #32]
	stp	q0, q1, [sp, #208]
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	cbz	w10, LBB38_79
; %bb.63:
	add	x9, x9, x28, lsl #6
	add	x9, x9, #56
	b	LBB38_65
LBB38_64:                               ;   in Loop: Header=BB38_65 Depth=1
	add	x9, x9, #64
	subs	x10, x10, #1
	b.eq	LBB38_79
LBB38_65:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9]
	cmp	w11, #2
	b.ne	LBB38_64
; %bb.66:                               ;   in Loop: Header=BB38_65 Depth=1
	ldurh	w11, [x9, #-54]
	cmp	w11, w8
	b.ne	LBB38_64
; %bb.67:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh360:
	adrp	x8, l_.str.114@PAGE
Lloh361:
	add	x8, x8, l_.str.114@PAGEOFF
	b	LBB38_25
LBB38_68:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #23]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, x9, x3, lsl #6
	ldrh	w10, [x9]
	ldrh	w11, [x24, #14]
	orr	w10, w11, w10
	strh	w10, [x24, #14]
	mov	w10, #2                         ; =0x2
	strh	w10, [x24, #18]
	ldrh	w11, [x9]
	ldrh	w12, [x24, #8]
	orr	w11, w12, w11
	strh	w11, [x24, #8]
	strh	w10, [x24, #10]
	ldrb	w10, [x9, #56]
	and	w10, w10, #0xff
	ldrb	w11, [x9, #57]
	orr	w10, w11, w10
	cbnz	w10, LBB38_71
; %bb.69:
	ldp	q1, q0, [x9, #16]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w10, s0
	tbnz	w10, #0, LBB38_71
; %bb.70:
	ldrh	w10, [x9]
	ldr	x9, [x9, #48]
	cmp	x9, #0
	ccmp	w10, #2, #0, eq
	b.eq	LBB38_180
LBB38_71:
	mov	w0, #0                          ; =0x0
	ldp	x10, x9, [sp, #96]              ; 16-byte Folded Reload
	ldr	w9, [x9, #68]
	str	w8, [x10]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w8, w9, [x10, #4]
	str	wzr, [x10, #12]
Lloh362:
	adrp	x8, l_.str.125@PAGE
Lloh363:
	add	x8, x8, l_.str.125@PAGEOFF
	b	LBB38_25
LBB38_72:
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	cmp	w10, w3
	b.ls	LBB38_78
; %bb.73:
	lsl	x8, x28, #6
	add	x8, x8, x3, lsl #6
	add	x9, sp, #360
	add	x8, x8, x9
	add	x8, x8, #57
	sub	x9, x10, x3
LBB38_74:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x8, #-1]
	and	w10, w10, #0xff
	ldrb	w11, [x8]
	orr	w10, w11, w10
	cbnz	w10, LBB38_148
; %bb.75:                               ;   in Loop: Header=BB38_74 Depth=1
	ldur	q0, [x8, #-25]
	ldur	q1, [x8, #-41]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w10, s0
	tbnz	w10, #0, LBB38_148
; %bb.76:                               ;   in Loop: Header=BB38_74 Depth=1
	ldurh	w10, [x8, #-57]
	ldur	x11, [x8, #-9]
	cmp	x11, #0
	ccmp	w10, #8, #0, eq
	b.ne	LBB38_148
; %bb.77:                               ;   in Loop: Header=BB38_74 Depth=1
	add	x8, x8, #64
	subs	x9, x9, #1
	b.ne	LBB38_74
LBB38_78:
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #184]
	str	xzr, [sp, #232]
	stur	q0, [sp, #216]
	stur	q0, [sp, #200]
	mov	x8, #-65408                     ; =0xffffffffffff0080
	movk	x8, #0, lsl #16
	str	x8, [sp, #176]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrsh	x8, [x8, #80]
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	str	x8, [sp, #192]
	b	LBB38_180
LBB38_79:
	ldrb	w9, [sp, #232]
	cmp	w9, #1
	b.ne	LBB38_86
; %bb.80:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #3
	mov	x25, x2
	ldr	x2, [x8, #8]
	mov	x1, x23
	bl	_oq_type
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	tbz	w0, #0, LBB38_86
; %bb.81:
	mov	x2, x25
	mov	x8, #-4294967295                ; =0xffffffff00000001
	str	x8, [x23]
	str	xzr, [x23, #56]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #8]
	stur	q0, [x23, #24]
	stur	q0, [x23, #40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #57]
	cbz	w21, LBB38_180
; %bb.82:
	ldr	w21, [sp, #52]                  ; 4-byte Folded Reload
	cmp	w21, #1
	b.lt	LBB38_188
; %bb.83:
	mov	w19, #0                         ; =0x0
	ldr	x26, [sp, #112]                 ; 8-byte Folded Reload
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
LBB38_84:                               ; =>This Inner Loop Header: Depth=1
	and	x8, x26, #0xffff
	add	x3, x9, x8, lsl #6
	add	x1, sp, #176
	and	w2, w19, #0xffff
	mov	x0, x20
	bl	_oq_child
	cbz	w0, LBB38_26
; %bb.85:                               ;   in Loop: Header=BB38_84 Depth=1
	add	w26, w26, #1
	add	w19, w19, #1
	cmp	w21, w19
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	x2, x25
	b.ne	LBB38_84
	b	LBB38_183
LBB38_86:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh364:
	adrp	x8, l_.str.115@PAGE
Lloh365:
	add	x8, x8, l_.str.115@PAGEOFF
	b	LBB38_25
LBB38_87:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x8, x8, x3, lsl #6
	ldrb	w9, [x8, #56]
	ldrb	w10, [x8, #57]
	cmp	w9, #2
	ccmp	w10, #0, #0, eq
	b.ne	LBB38_147
; %bb.88:
	ldrh	w9, [x8, #2]
	ldrh	w10, [x20, #16]
	cmp	w9, w10
	b.hs	LBB38_147
; %bb.89:
	add	x10, sp, #360
	add	x10, x10, x9, lsl #6
	ldrb	w10, [x10, #56]
	cmp	w10, #1
	b.ne	LBB38_147
; %bb.90:
	mov	x20, x2
	ldrh	w10, [x8]
	ldr	x11, [sp, #104]                 ; 8-byte Folded Reload
	ldrh	w2, [x11, #8]
	strh	w10, [sp, #240]
	strh	w9, [sp, #242]
	ldur	q0, [x8, #4]
	stur	q0, [sp, #244]
	ldur	q0, [x8, #20]
	add	x10, sp, #240
	stur	q0, [x10, #20]
	ldur	q0, [x8, #36]
	stur	q0, [x10, #36]
	ldur	w9, [x8, #52]
	str	w9, [x10, #52]
	mov	w9, #2                          ; =0x2
	strh	w9, [x10, #56]
	ldur	w9, [x8, #58]
	stur	w9, [x10, #58]
	ldurh	w8, [x8, #62]
	strh	w8, [x10, #62]
	add	x1, sp, #240
	add	x3, sp, #176
	ldr	x19, [sp, #88]                  ; 8-byte Folded Reload
	mov	x0, x19
	bl	_oq_child
	cbz	w0, LBB38_26
; %bb.91:
	add	x2, sp, #176
	mov	x0, x19
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_require
	mov	x2, x20
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	tbz	w0, #0, LBB38_176
	b	LBB38_180
LBB38_92:
	str	x2, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w1, [x8, #8]
	add	x2, sp, #176
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_make_owner
	cbz	w0, LBB38_26
; %bb.93:
	cbz	w27, LBB38_162
; %bb.94:
	mov	w8, #0                          ; =0x0
	str	wzr, [sp, #56]                  ; 4-byte Folded Spill
	add	x15, sp, #240
	ldp	x3, x9, [sp, #80]               ; 16-byte Folded Reload
	add	x9, x9, #100, lsl #12           ; =409600
	add	x10, x9, #876
	ldr	w9, [sp, #184]
	stp	x9, x10, [sp, #8]               ; 16-byte Folded Spill
	add	x13, sp, #240
	b	LBB38_97
LBB38_95:                               ;   in Loop: Header=BB38_97 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x8, [x8, x14]
	ldr	w22, [sp, #56]                  ; 4-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	w9, w9, w22
	add	w10, w22, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w9, w11, x8
	add	x9, sp, #304
	ldur	q0, [x9, #4]
	ldur	q1, [x9, #20]
	stp	q0, q1, [x8]
	ldur	x9, [x9, #36]
	str	x9, [x8, #32]
	str	w10, [sp, #56]                  ; 4-byte Folded Spill
	add	x15, sp, #240
	ldr	w0, [sp, #112]                  ; 4-byte Folded Reload
LBB38_96:                               ;   in Loop: Header=BB38_97 Depth=1
	add	w8, w0, #1
	cmp	w8, w27
	b.hs	LBB38_163
LBB38_97:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_109 Depth 2
	and	w14, w8, #0xffff
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	str	w14, [sp, #112]                 ; 4-byte Folded Spill
	cbz	x9, LBB38_102
; %bb.98:                               ;   in Loop: Header=BB38_97 Depth=1
	ldr	w10, [x9, #8]
	ldr	x12, [sp, #24]                  ; 8-byte Folded Reload
	cmp	w12, w10
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	b.hs	LBB38_101
; %bb.99:                               ;   in Loop: Header=BB38_97 Depth=1
	ldr	x9, [x9]
	add	x9, x9, x12, lsl #4
	ldrh	w10, [x9, #2]
	cmp	w14, w10
	b.hs	LBB38_101
; %bb.100:                              ;   in Loop: Header=BB38_97 Depth=1
	ldr	x9, [x9, #8]
	mov	w10, #12                        ; =0xc
	umaddl	x9, w14, w10, x9
	ldrb	w10, [x9]
	ldr	w9, [x9, #4]
	lsl	x9, x9, #32
	b	LBB38_103
LBB38_101:                              ;   in Loop: Header=BB38_97 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB38_103
LBB38_102:                              ;   in Loop: Header=BB38_97 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
LBB38_103:                              ;   in Loop: Header=BB38_97 Depth=1
	add	w8, w8, w3
	add	x20, x11, x8, lsl #6
	ldp	w21, w24, [x20]
	ldr	w19, [x20, #8]
	ldur	q0, [x20, #12]
	ldur	q1, [x20, #28]
	stp	q0, q1, [x13, #64]
	ldur	q0, [x20, #40]
	stur	q0, [x13, #92]
	ldr	x28, [x20, #56]
	stp	w21, w24, [sp, #240]
	str	w19, [sp, #248]
	ldur	q0, [x20, #12]
	stur	q0, [x15, #12]
	ldur	q0, [x20, #28]
	stur	q0, [x15, #28]
	ldur	q0, [x20, #40]
	stur	q0, [x15, #40]
	str	x28, [x13, #56]
	add	x1, sp, #240
	mov	x25, x10
	orr	x2, x9, x10
	ldr	x23, [sp, #88]                  ; 8-byte Folded Reload
	add	x22, sp, #240
	mov	x0, x23
	add	x26, sp, #240
	bl	_oq_type
	tbz	w0, #0, LBB38_178
; %bb.104:                              ;   in Loop: Header=BB38_97 Depth=1
	stp	w21, w24, [sp, #240]
	str	w19, [sp, #248]
	ldur	q0, [x20, #12]
	stur	q0, [x22, #12]
	ldur	q0, [x20, #28]
	stur	q0, [x22, #28]
	ldur	q0, [x20, #40]
	stur	q0, [x22, #40]
	str	x28, [x26, #56]
	add	x2, sp, #240
	mov	x0, x23
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_require
	cbz	w0, LBB38_176
; %bb.105:                              ;   in Loop: Header=BB38_97 Depth=1
	cmp	x25, #7
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	add	x13, sp, #240
	mov	w14, #17232                     ; =0x4350
	movk	w14, #6, lsl #16
	b.eq	LBB38_95
; %bb.106:                              ;   in Loop: Header=BB38_97 Depth=1
	cmp	x25, #8
	add	x15, sp, #240
	ldr	x16, [sp, #16]                  ; 8-byte Folded Reload
	ldr	w0, [sp, #112]                  ; 4-byte Folded Reload
	b.ne	LBB38_96
; %bb.107:                              ;   in Loop: Header=BB38_97 Depth=1
	ldr	w8, [x16, w24, uxtw #2]
	mov	w17, #40                        ; =0x28
	cbz	w8, LBB38_96
; %bb.108:                              ;   in Loop: Header=BB38_97 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	add	x9, x10, w9, uxtw
	ldr	x12, [sp, #88]                  ; 8-byte Folded Reload
LBB38_109:                              ;   Parent Loop BB38_97 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x10, [x12, x14]
	add	w11, w9, w8
	umaddl	x11, w11, w17, x10
	umaddl	x10, w19, w17, x10
	ldp	q0, q1, [x10]
	ldr	x10, [x10, #32]
	str	x10, [x11, #32]
	stp	q0, q1, [x11]
	add	x8, x8, #1
	ldr	w10, [x16, w24, uxtw #2]
	add	w19, w19, #1
	cmp	x8, x10
	b.lo	LBB38_109
; %bb.110:                              ;   in Loop: Header=BB38_97 Depth=1
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	add	w9, w9, w8
	str	w9, [sp, #56]                   ; 4-byte Folded Spill
	b	LBB38_96
LBB38_111:
	mov	x23, x2
	mov	w8, #128                        ; =0x80
	strh	w8, [sp, #240]
	ldr	x8, [x9]
	stur	x8, [sp, #242]
	ldur	x8, [x9, #6]
	str	x8, [sp, #248]
	stp	x28, x27, [x14, #16]
	stp	x20, x25, [x14, #32]
	str	x21, [x14, #48]
	strh	wzr, [x14, #56]
	ldr	w8, [x10]
	stur	w8, [x14, #58]
	ldrh	w8, [x10, #4]
	strh	w8, [x14, #62]
	add	x2, sp, #240
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_require
	cbz	w0, LBB38_176
; %bb.112:
	mov	x2, x23
	sub	w8, w2, #83
	and	w8, w8, #0xff
	cmp	w8, #1
	ldp	x10, x1, [sp, #64]              ; 16-byte Folded Reload
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	add	x12, sp, #240
	b.hi	LBB38_117
; %bb.113:
	ldrb	w8, [x19, #120]
	and	w8, w8, #0xff
	ldrb	w9, [x19, #121]
	orr	w8, w9, w8
	cbnz	w8, LBB38_177
; %bb.114:
	ldp	q1, q0, [x19, #80]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w9, s0
Lloh366:
	adrp	x8, l_.str.122@PAGE
Lloh367:
	add	x8, x8, l_.str.122@PAGEOFF
	tbnz	w9, #0, LBB38_175
; %bb.115:
	ldr	x9, [x19, #112]
	cbnz	x9, LBB38_175
; %bb.116:
	ldrh	w9, [x19, #64]
	cmp	w9, #2
	b.ne	LBB38_175
LBB38_117:
	cmp	w2, #83
	b.gt	LBB38_165
; %bb.118:
	cmp	w2, #81
	b.ne	LBB38_172
	b	LBB38_167
LBB38_119:
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	add	x23, x9, x3, lsl #6
	ldp	q0, q1, [x23]
	stp	q0, q1, [sp, #176]
	ldp	q1, q0, [x23, #32]
	stp	q1, q0, [sp, #208]
	ldrb	w9, [sp, #232]
	cbnz	w9, LBB38_122
; %bb.120:
	add	x9, sp, #360
	add	x19, x9, x8, lsl #6
	ldrb	w9, [x19, #56]
	cbnz	w9, LBB38_122
; %bb.121:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #3
	mov	x20, x2
	ldr	x2, [x8, #8]
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x1, x23
	bl	_oq_type
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	tbnz	w0, #0, LBB38_138
LBB38_122:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh368:
	adrp	x8, l_.str.113@PAGE
Lloh369:
	add	x8, x8, l_.str.113@PAGEOFF
	b	LBB38_25
LBB38_123:
	str	xzr, [sp, #232]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #216]
	stur	q0, [sp, #200]
	stur	q0, [sp, #184]
	mov	x8, #-65504                     ; =0xffffffffffff0020
LBB38_124:
	movk	x8, #0, lsl #16
	str	x8, [sp, #176]
	b	LBB38_180
LBB38_125:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x8, x8, x3, lsl #6
	ldrb	w8, [x8, #56]
	cbz	w8, LBB38_180
; %bb.126:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh370:
	adrp	x8, l_.str.111@PAGE
Lloh371:
	add	x8, x8, l_.str.111@PAGEOFF
	b	LBB38_25
LBB38_127:
	mov	x20, x2
	ldr	x21, [sp, #104]                 ; 8-byte Folded Reload
	ldrh	w19, [x21, #8]
	add	x8, sp, #360
	add	x1, x8, x19, lsl #6
	ldp	q0, q1, [x1]
	stp	q0, q1, [sp, #176]
	ldp	q0, q1, [x1, #32]
	stp	q0, q1, [sp, #208]
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x8, x8, x19, lsl #3
	ldr	x2, [x8, #8]
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_oq_type
	cbz	w0, LBB38_149
; %bb.128:
	ldrb	w8, [sp, #232]
	mov	x2, x20
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	cbz	w8, LBB38_180
; %bb.129:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #232]
	strh	w19, [sp, #178]
	b	LBB38_180
LBB38_130:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x26, [sp, #112]                 ; 8-byte Folded Reload
	add	x8, x8, x26, lsl #6
	ldp	q0, q1, [x8, #-64]
	stp	q0, q1, [sp, #176]
	ldp	q2, q3, [x8, #-32]
	stp	q2, q3, [sp, #208]
	ldp	q4, q5, [x8, #-128]
	stp	q4, q5, [x8, #-64]
	ldp	q4, q5, [x8, #-96]
	stp	q4, q5, [x8, #-32]
	stp	q0, q1, [x8, #-128]
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	stp	q2, q3, [x8, #-96]
	b	LBB38_151
LBB38_131:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	add	x8, x8, x10, lsl #6
	ldurb	w9, [x8, #-8]
	cbz	w9, LBB38_150
; %bb.132:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh372:
	adrp	x8, l_.str.110@PAGE
Lloh373:
	add	x8, x8, l_.str.110@PAGEOFF
	b	LBB38_25
LBB38_133:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x26, [sp, #112]                 ; 8-byte Folded Reload
	add	x8, x8, x26, lsl #6
	ldp	q0, q1, [x8, #-64]
	stp	q0, q1, [sp, #176]
	ldp	q0, q1, [x8, #-32]
	stp	q0, q1, [sp, #208]
	ldp	q0, q1, [x8, #-128]
	stp	q0, q1, [x8, #-64]
	ldp	q0, q1, [x8, #-96]
	stp	q0, q1, [x8, #-32]
	ldp	q0, q1, [x8, #-192]
	ldp	q2, q3, [x8, #-160]
	stp	q2, q3, [x8, #-96]
	stp	q0, q1, [x8, #-128]
	ldp	q0, q1, [sp, #176]
	ldp	q2, q3, [sp, #208]
	stp	q2, q3, [x8, #-160]
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	stp	q0, q1, [x8, #-192]
	b	LBB38_151
LBB38_134:
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #8]
	add	x9, sp, #360
	add	x19, x9, x8, lsl #6
	ldrb	w9, [x19, #56]
	cbnz	w9, LBB38_146
; %bb.135:
	ldrh	w9, [x19]
	cmp	w9, #1
	b.ne	LBB38_146
; %bb.136:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	add	x23, x9, x3, lsl #6
	ldrb	w9, [x23, #56]
	cmp	w9, #1
	b.ne	LBB38_146
; %bb.137:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #3
	mov	x20, x2
	ldr	x2, [x8, #8]
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x1, x23
	bl	_oq_type
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	tbz	w0, #0, LBB38_146
LBB38_138:
	mov	x2, x20
	ldp	q0, q1, [x23]
	ldp	q2, q3, [x23, #32]
	stp	q2, q3, [x19, #32]
	stp	q0, q1, [x19]
	b	LBB38_180
LBB38_139:
	mov	x25, x2
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w22, [x8, #8]
	mov	w8, #2152                       ; =0x868
	umaddl	x19, w22, w8, x19
	cbz	w27, LBB38_152
; %bb.140:
	mov	w20, #0                         ; =0x0
	add	x21, x19, #8
	mov	x23, x3
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x28, [sp, #88]                  ; 8-byte Folded Reload
LBB38_141:                              ; =>This Inner Loop Header: Depth=1
	mov	w8, w23
	add	x24, x9, x8, lsl #6
	ldr	x2, [x21, w20, uxtw #3]
	mov	x0, x28
	mov	x1, x24
	bl	_oq_type
	tbz	w0, #0, LBB38_161
; %bb.142:                              ;   in Loop: Header=BB38_141 Depth=1
	ldp	q0, q1, [x24]
	str	q0, [sp, #240]
	ldp	q0, q2, [x24, #32]
	add	x8, sp, #240
	stp	q1, q0, [x8, #16]
	str	q2, [x8, #48]
	add	x2, sp, #240
	mov	x0, x28
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_oq_require
	tbz	w0, #0, LBB38_176
; %bb.143:                              ;   in Loop: Header=BB38_141 Depth=1
	add	w20, w20, #1
	add	w23, w23, #1
	cmp	w20, w27
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	b.lo	LBB38_141
; %bb.144:
	ldp	x3, x20, [sp, #80]              ; 16-byte Folded Reload
	ldr	x23, [x20, #8]
	b	LBB38_153
LBB38_145:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh374:
	adrp	x8, l_.str.127@PAGE
Lloh375:
	add	x8, x8, l_.str.127@PAGEOFF
	b	LBB38_25
LBB38_146:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh376:
	adrp	x8, l_.str.116@PAGE
Lloh377:
	add	x8, x8, l_.str.116@PAGEOFF
	b	LBB38_25
LBB38_147:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh378:
	adrp	x8, l_.str.119@PAGE
Lloh379:
	add	x8, x8, l_.str.119@PAGEOFF
	b	LBB38_25
LBB38_148:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh380:
	adrp	x8, l_.str.120@PAGE
Lloh381:
	add	x8, x8, l_.str.120@PAGEOFF
	b	LBB38_25
LBB38_149:
	ldr	w8, [x21, #68]
	mov	w11, #1                         ; =0x1
	ldr	x10, [sp, #96]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh382:
	adrp	x8, l_.str.112@PAGE
Lloh383:
	add	x8, x8, l_.str.112@PAGEOFF
	b	LBB38_25
LBB38_150:
	ldp	q0, q1, [x8, #-64]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x8, #-32]
	stp	q0, q1, [x8, #32]
	add	w26, w10, #1
LBB38_151:
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	b	LBB38_186
LBB38_152:
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
LBB38_153:
	add	x24, x9, x3, lsl #6
	mov	w8, #56                         ; =0x38
	umaddl	x8, w22, w8, x23
	add	x9, x8, #808
	ldr	x8, [x8, #840]
	add	x10, sp, #240
	str	x8, [x10, #32]
	ldp	q0, q1, [x9]
	str	q0, [sp, #240]
	str	q1, [x10, #16]
	add	x4, sp, #240
	add	x5, sp, #128
	mov	x0, x20
	ldr	x21, [sp, #72]                  ; 8-byte Folded Reload
	mov	x1, x21
	mov	x2, x22
	mov	x3, x24
	bl	_oq_substitute
	cbz	w0, LBB38_26
; %bb.154:
	ldr	x8, [x20, #8]
	mov	w9, #56                         ; =0x38
	umaddl	x8, w21, w9, x8
	add	x0, x8, #808
	add	x1, sp, #128
	bl	_oq_union
	mov	x2, x25
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	cbz	w8, LBB38_180
; %bb.155:
	add	x8, x19, #2088
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #176]
	ldp	q1, q0, [x8, #32]
	stp	q1, q0, [sp, #208]
	ldrb	w8, [sp, #232]
	cbz	w8, LBB38_180
; %bb.156:
	ldr	w1, [sp, #180]
	add	x2, sp, #176
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	mov	x0, x20
	bl	_oq_make_owner
	cbz	w0, LBB38_26
; %bb.157:
	add	x8, x20, #100, lsl #12          ; =409600
	add	x20, x8, #876
	ldr	w21, [sp, #180]
	ldr	w8, [x20, x21, lsl #2]
	mov	x2, x25
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	mov	w9, #17232                      ; =0x4350
	movk	w9, #6, lsl #16
	cbz	w8, LBB38_180
; %bb.158:
	mov	x23, #0                         ; =0x0
	ldr	w28, [sp, #184]
	mov	w27, #40                        ; =0x28
LBB38_159:                              ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x8, [x0, x9]
	ldr	w9, [x19, #2096]
	add	w9, w23, w9
	umaddl	x9, w9, w27, x8
	umaddl	x5, w28, w27, x8
	ldp	q0, q1, [x9]
	str	q0, [sp, #240]
	add	x10, sp, #240
	str	q1, [x10, #16]
	ldr	x8, [x9, #32]
	str	x8, [x10, #32]
	add	x4, sp, #240
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, x22
	mov	x3, x24
	bl	_oq_substitute
	tbz	w0, #0, LBB38_176
; %bb.160:                              ;   in Loop: Header=BB38_159 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, x21, lsl #2]
	add	w28, w28, #1
	cmp	x23, x8
	mov	x2, x25
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	mov	w9, #17232                      ; =0x4350
	movk	w9, #6, lsl #16
	b.lo	LBB38_159
	b	LBB38_180
LBB38_161:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh384:
	adrp	x8, l_.str.124@PAGE
Lloh385:
	add	x8, x8, l_.str.124@PAGEOFF
	b	LBB38_25
LBB38_162:
	str	wzr, [sp, #56]                  ; 4-byte Folded Spill
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
LBB38_163:
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #2
	add	x9, x8, #100, lsl #12           ; =409600
	ldr	w8, [x9, #876]
	ldr	w9, [sp, #56]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.eq	LBB38_180
; %bb.164:
	mov	w0, #0                          ; =0x0
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #2                         ; =0x2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh386:
	adrp	x8, l_.str.118@PAGE
Lloh387:
	add	x8, x8, l_.str.118@PAGEOFF
	b	LBB38_25
LBB38_165:
	cmp	w2, #85
	b.eq	LBB38_190
; %bb.166:
	cmp	w2, #84
	b.ne	LBB38_179
LBB38_167:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	add	x9, x10, x8, lsl #6
	ldurb	w8, [x9, #-8]
	and	w8, w8, #0xff
	ldurb	w10, [x9, #-7]
	orr	w8, w10, w8
	cbnz	w8, LBB38_189
; %bb.168:
	ldp	q1, q0, [x9, #-48]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w10, s0
Lloh388:
	adrp	x8, l_.str.123@PAGE
Lloh389:
	add	x8, x8, l_.str.123@PAGEOFF
	tbnz	w10, #0, LBB38_174
; %bb.169:
	ldur	x10, [x9, #-16]
	cbnz	x10, LBB38_174
; %bb.170:
	ldurh	w9, [x9, #-64]
	cmp	w9, #8
	ldp	x1, x3, [sp, #72]               ; 16-byte Folded Reload
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
	add	x12, sp, #240
	b.ne	LBB38_175
; %bb.171:
	mov	x2, x23
	mov	x24, x22
LBB38_172:
	cmp	w2, #83
	b.ne	LBB38_179
; %bb.173:
	str	xzr, [sp, #232]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #216]
	stur	q0, [sp, #200]
	stur	q0, [sp, #184]
	mov	x8, #-65527                     ; =0xffffffffffff0009
	movk	x8, #0, lsl #16
	str	x8, [sp, #176]
	mov	w8, #9                          ; =0x9
	strh	w8, [x24, #12]
	b	LBB38_180
LBB38_174:
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x11, [sp, #96]                  ; 8-byte Folded Reload
LBB38_175:
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w9, [x9, #68]
	mov	w10, #1                         ; =0x1
	stp	w10, w1, [x11]
	stp	w9, wzr, [x11, #8]
	str	x8, [x11, #16]
LBB38_176:
	mov	w0, #0                          ; =0x0
	b	LBB38_26
LBB38_177:
Lloh390:
	adrp	x8, l_.str.122@PAGE
Lloh391:
	add	x8, x8, l_.str.122@PAGEOFF
	b	LBB38_175
LBB38_178:
	ldp	x10, x8, [sp, #96]              ; 16-byte Folded Reload
	ldr	w8, [x8, #68]
	mov	w11, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w11, w9, [x10]
	stp	w8, wzr, [x10, #8]
Lloh392:
	adrp	x8, l_.str.117@PAGE
Lloh393:
	add	x8, x8, l_.str.117@PAGEOFF
	str	x8, [x10, #16]
	mov	w0, #0                          ; =0x0
	b	LBB38_26
LBB38_179:
	mov	w8, #128                        ; =0x80
	strh	w8, [sp, #176]
	ldr	x8, [x12, #64]
	stur	x8, [sp, #178]
	ldur	x8, [x12, #70]
	stp	x8, x28, [sp, #184]
	stp	x27, x20, [sp, #200]
	stp	x25, x21, [sp, #216]
	strh	wzr, [sp, #232]
	ldr	w8, [sp, #168]
	stur	w8, [sp, #234]
	ldrh	w8, [sp, #172]
	strh	w8, [sp, #238]
LBB38_180:
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	cbz	w8, LBB38_182
; %bb.181:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x8, x8, x3, lsl #6
	ldp	q0, q1, [sp, #176]
	stp	q0, q1, [x8]
	ldp	q0, q1, [sp, #208]
	stp	q0, q1, [x8, #32]
LBB38_182:
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #40]                  ; 8-byte Folded Reload
LBB38_183:
	sub	w8, w2, #56
	cmp	w8, #2
	b.hi	LBB38_186
; %bb.184:
	ldr	x21, [sp, #104]                 ; 8-byte Folded Reload
	ldr	w1, [x21, #76]
	mov	x19, x2
	add	x2, sp, #360
	and	w3, w26, #0xffff
	mov	x0, x20
	bl	_oq_join
	cmp	w19, #56
	b.eq	LBB38_26
; %bb.185:
	cbnz	w0, LBB38_187
	b	LBB38_26
LBB38_186:
	ldr	x21, [sp, #104]                 ; 8-byte Folded Reload
LBB38_187:
	ldr	w1, [x21, #72]
	add	x2, sp, #360
	and	w3, w26, #0xffff
	mov	x0, x20
	bl	_oq_join
	b	LBB38_26
LBB38_188:
	ldr	x26, [sp, #112]                 ; 8-byte Folded Reload
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	b	LBB38_183
LBB38_189:
Lloh394:
	adrp	x8, l_.str.123@PAGE
Lloh395:
	add	x8, x8, l_.str.123@PAGEOFF
	b	LBB38_175
LBB38_190:
	str	xzr, [sp, #232]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #216]
	stur	q0, [sp, #200]
	stur	q0, [sp, #184]
	mov	x8, #-65534                     ; =0xffffffffffff0002
	b	LBB38_124
LBB38_191:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh328, Lloh329, Lloh330
	.loh AdrpAdd	Lloh331, Lloh332
	.loh AdrpAdd	Lloh333, Lloh334
	.loh AdrpLdrGotLdr	Lloh335, Lloh336, Lloh337
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpLdr	Lloh350, Lloh351
	.loh AdrpAdd	Lloh352, Lloh353
	.loh AdrpAdd	Lloh354, Lloh355
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh364, Lloh365
	.loh AdrpAdd	Lloh366, Lloh367
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh372, Lloh373
	.loh AdrpAdd	Lloh374, Lloh375
	.loh AdrpAdd	Lloh376, Lloh377
	.loh AdrpAdd	Lloh378, Lloh379
	.loh AdrpAdd	Lloh380, Lloh381
	.loh AdrpAdd	Lloh382, Lloh383
	.loh AdrpAdd	Lloh384, Lloh385
	.loh AdrpAdd	Lloh386, Lloh387
	.loh AdrpAdd	Lloh388, Lloh389
	.loh AdrpAdd	Lloh390, Lloh391
	.loh AdrpAdd	Lloh392, Lloh393
	.loh AdrpAdd	Lloh394, Lloh395
	.loh AdrpLdrGot	Lloh326, Lloh327
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI38_0:
	.short	(LBB38_180-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_123-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_131-LBB38_35)>>2
	.short	(LBB38_125-LBB38_35)>>2
	.short	(LBB38_130-LBB38_35)>>2
	.short	(LBB38_133-LBB38_35)>>2
	.short	(LBB38_62-LBB38_35)>>2
	.short	(LBB38_134-LBB38_35)>>2
	.short	(LBB38_92-LBB38_35)>>2
	.short	(LBB38_62-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_127-LBB38_35)>>2
	.short	(LBB38_119-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_180-LBB38_35)>>2
	.short	(LBB38_57-LBB38_35)>>2
	.short	(LBB38_57-LBB38_35)>>2
	.short	(LBB38_139-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_72-LBB38_35)>>2
	.short	(LBB38_35-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_35-LBB38_35)>>2
	.short	(LBB38_35-LBB38_35)>>2
	.short	(LBB38_35-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_72-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_68-LBB38_35)>>2
	.short	(LBB38_57-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_68-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_145-LBB38_35)>>2
	.short	(LBB38_87-LBB38_35)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_merge_value
lCPI39_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_merge_value:                        ; @oq_merge_value
	.cfi_startproc
; %bb.0:
	add	x8, x0, #104, lsl #12           ; =425984
	add	x8, x8, #2952
	ldrb	w9, [x1, #56]
	ldrb	w10, [x2, #56]
	and	w10, w10, #0xff
	orr	w11, w9, w10
	cbnz	w11, LBB39_5
; %bb.1:
	ldrh	w10, [x1]
	ldrh	w11, [x2]
LBB39_2:
	ldrb	w12, [x1, #57]
	and	w13, w12, #0xff
	orr	w11, w11, w10
	strh	w11, [x1]
	ldrb	w14, [x2, #57]
	orr	w12, w14, w12
	and	w14, w12, #0xff
	strb	w12, [x1, #57]
	cmp	w10, w11
	ccmp	w13, w14, #0, eq
	cset	w10, ne
	ldrb	w11, [x3]
	orr	w10, w11, w10
	strb	w10, [x3]
	ldp	x11, x12, [x2, #16]
	ldp	x13, x14, [x2, #32]
	ldp	x15, x16, [x1, #16]
	orr	x11, x15, x11
	cmp	x11, x15
	ldr	x15, [x2, #48]
	orr	x12, x16, x12
	ccmp	x12, x16, #0, eq
	stp	x11, x12, [x1, #16]
	ldp	x11, x12, [x1, #32]
	orr	x13, x11, x13
	ccmp	x13, x11, #0, eq
	orr	x11, x12, x14
	ccmp	x11, x12, #0, eq
	stp	x13, x11, [x1, #32]
	ldr	x11, [x1, #48]
	orr	x12, x11, x15
	ccmp	x12, x11, #0, eq
	cset	w11, ne
	str	x12, [x1, #48]
	orr	w10, w10, w11
	strb	w10, [x3]
	cbz	w9, LBB39_10
; %bb.3:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x9, x0, #100, lsl #12           ; =409600
	add	x6, x9, #848
	ldr	w10, [x1, #4]
	add	x10, x0, x10, lsl #2
	add	x11, x10, #100, lsl #12         ; =409600
	ldr	w19, [x11, #876]
	ldr	w11, [x6, #24]
	mov	w12, #262144                    ; =0x40000
	sub	w12, w12, w11
	cmp	w19, w12
	b.ls	LBB39_11
LBB39_4:
	mov	w0, #0                          ; =0x0
Lloh396:
	adrp	x9, lCPI39_0@PAGE
Lloh397:
	ldr	q0, [x9, lCPI39_0@PAGEOFF]
	str	q0, [x8]
Lloh398:
	adrp	x9, l_.str.95@PAGE
Lloh399:
	add	x9, x9, l_.str.95@PAGEOFF
	str	x9, [x8, #16]
	b	LBB39_20
LBB39_5:
	cmp	w9, w10
	b.ne	LBB39_9
; %bb.6:
	ldr	w10, [x1, #4]
	ldr	w11, [x2, #4]
	cmp	w10, w11
	b.ne	LBB39_9
; %bb.7:
	ldrh	w10, [x1, #2]
	ldrh	w11, [x2, #2]
	cmp	w10, w11
	b.ne	LBB39_9
; %bb.8:
	ldrh	w11, [x1]
	ldrh	w12, [x2]
	mov	x10, x11
	cmp	w11, w12
	b.eq	LBB39_2
LBB39_9:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	stp	w9, w4, [x8]
	stp	w5, wzr, [x8, #8]
Lloh400:
	adrp	x9, l_.str.101@PAGE
Lloh401:
	add	x9, x9, l_.str.101@PAGEOFF
	str	x9, [x8, #16]
	ret
LBB39_10:
	mov	w0, #1                          ; =0x1
	ret
LBB39_11:
	add	w7, w11, w19
	str	w7, [x6, #24]
	cbz	w19, LBB39_19
; %bb.12:
	ldr	x11, [x6]
	ldr	w10, [x1, #8]
	ldr	w26, [x2, #8]
	cmp	w19, #8
	b.hs	LBB39_21
; %bb.13:
	mov	x12, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
LBB39_14:
	add	w14, w26, w12
	add	w13, w10, w12
	sub	x15, x19, x12
	mov	w17, #40                        ; =0x28
LBB39_15:                               ; =>This Inner Loop Header: Depth=1
	umaddl	x9, w13, w17, x11
	ldr	x12, [x9, #32]
	umaddl	x4, w14, w17, x11
	ldr	x5, [x4, #32]
	ldp	q1, q0, [x9]
	ldp	q3, q2, [x4]
	orr.16b	v3, v3, v1
	orr.16b	v2, v2, v0
	bics	xzr, x5, x12
	cset	w9, ne
	cmeq.2d	v0, v2, v0
	cmeq.2d	v1, v3, v1
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w12, s0
	orr	w9, w12, w9
	orr	w16, w9, w16
	add	w14, w14, #1
	add	w13, w13, #1
	subs	x15, x15, #1
	b.ne	LBB39_15
LBB39_16:
	tbz	w16, #0, LBB39_19
; %bb.17:
	mov	w14, #17240                     ; =0x4358
	movk	w14, #6, lsl #16
	ldr	w13, [x0, x14]
	mov	w9, #65536                      ; =0x10000
	sub	w9, w9, w13
	cmp	w19, w9
	b.ls	LBB39_27
; %bb.18:
	mov	w0, #0                          ; =0x0
Lloh402:
	adrp	x9, lCPI39_0@PAGE
Lloh403:
	ldr	q0, [x9, lCPI39_0@PAGEOFF]
	str	q0, [x8]
Lloh404:
	adrp	x9, l_.str.94@PAGE
Lloh405:
	add	x9, x9, l_.str.94@PAGEOFF
	str	x9, [x8, #16]
	b	LBB39_20
LBB39_19:
	mov	w0, #1                          ; =0x1
LBB39_20:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB39_21:
	mov	w16, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	sub	x17, x19, #1
	cmn	w10, w17
	cset	w5, hs
	cmn	w26, w17
	cset	w4, hs
	tbnz	w5, #0, LBB39_14
; %bb.22:
	tbnz	w4, #0, LBB39_14
; %bb.23:
	lsr	x17, x17, #32
	cbnz	x17, LBB39_14
; %bb.24:
	stp	x3, x8, [sp, #8]                ; 16-byte Folded Spill
	str	w7, [sp, #36]                   ; 4-byte Folded Spill
	str	x6, [sp, #40]                   ; 8-byte Folded Spill
	mov	x16, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	str	x19, [sp, #24]                  ; 8-byte Folded Spill
	and	x12, x19, #0xfffffff8
	mov	w17, #40                        ; =0x28
	movi.2d	v1, #0000000000000000
LBB39_25:                               ; =>This Inner Loop Header: Depth=1
	add	w4, w10, w16
	add	w5, w4, #1
	add	w20, w4, #2
	add	w22, w4, #3
	add	w23, w4, #4
	add	w24, w4, #5
	add	w7, w4, #6
	add	w19, w4, #7
	umaddl	x6, w4, w17, x11
	umaddl	x21, w5, w17, x11
	umaddl	x5, w20, w17, x11
	umaddl	x22, w22, w17, x11
	umaddl	x4, w23, w17, x11
	umaddl	x20, w24, w17, x11
	ldr	d2, [x5]
	add	x23, x22, #16
	add	x24, x22, #24
	add	x25, x22, #32
	ld1.d	{ v2 }[1], [x22], #8
	mov	x8, x26
	add	x26, x21, #16
	ldp	d28, d25, [x6]
	add	x27, x21, #24
	add	x28, x21, #32
	ld1.d	{ v28 }[1], [x21], #8
	umaddl	x30, w7, w17, x11
	umaddl	x19, w19, w17, x11
	mov	x3, x12
	add	x12, x20, #16
	add	x9, x20, #24
	add	x13, x20, #32
	ldp	d26, d23, [x4]
	mov	x7, x20
	ld1.d	{ v26 }[1], [x7], #8
	add	x20, x19, #16
	ldp	d29, d24, [x30]
	add	x14, x19, #24
	add	x15, x19, #32
	ld1.d	{ v29 }[1], [x19], #8
	ldp	d22, d18, [x6, #16]
	ld1.d	{ v22 }[1], [x26]
	mov	x26, x8
	ldp	d27, d21, [x5, #8]
	ld1.d	{ v21 }[1], [x23]
	ldp	d20, d7, [x30, #16]
	ld1.d	{ v20 }[1], [x20]
	ldp	d19, d17, [x4, #16]
	ld1.d	{ v19 }[1], [x12]
	ldr	d3, [x6, #32]
	ld1.d	{ v18 }[1], [x27]
	ldp	d16, d5, [x5, #24]
	ld1.d	{ v16 }[1], [x24]
	ldr	d4, [x30, #32]
	ld1.d	{ v7 }[1], [x14]
	ldr	d6, [x4, #32]
	ld1.d	{ v17 }[1], [x9]
	ld1.d	{ v3 }[1], [x28]
	ld1.d	{ v5 }[1], [x25]
	ld1.d	{ v4 }[1], [x15]
	ld1.d	{ v6 }[1], [x13]
	ld1.d	{ v25 }[1], [x21]
	add	w9, w26, w16
	add	w12, w9, #1
	add	w13, w9, #2
	add	w14, w9, #3
	ld1.d	{ v27 }[1], [x22]
	add	w15, w9, #4
	add	w6, w9, #5
	add	w22, w9, #6
	add	w23, w9, #7
	ld1.d	{ v24 }[1], [x19]
	umaddl	x21, w9, w17, x11
	umaddl	x5, w12, w17, x11
	umaddl	x20, w13, w17, x11
	umaddl	x4, w14, w17, x11
	ld1.d	{ v23 }[1], [x7]
	umaddl	x19, w15, w17, x11
	ldr	d30, [x20]
	mov	x24, x4
	ld1.d	{ v30 }[1], [x24], #8
	umaddl	x6, w6, w17, x11
	ldr	d31, [x21]
	mov	x25, x5
	ld1.d	{ v31 }[1], [x25], #8
	umaddl	x22, w22, w17, x11
	umaddl	x7, w23, w17, x11
	mov	x23, x6
	orr.16b	v31, v31, v28
	cmeq.2d	v28, v31, v28
	ldr	d31, [x19]
	ld1.d	{ v31 }[1], [x23], #8
	orr.16b	v30, v30, v2
	cmeq.2d	v2, v30, v2
	ldr	d30, [x22]
	mov	x9, x7
	ld1.d	{ v30 }[1], [x9], #8
	orr.16b	v30, v30, v29
	uzp1.4s	v2, v28, v2
	cmeq.2d	v28, v30, v29
	ldp	d29, d30, [x21, #8]
	orr.16b	v31, v31, v26
	ld1.d	{ v29 }[1], [x25]
	cmeq.2d	v26, v31, v26
	uzp1.4s	v26, v26, v28
	ldp	d28, d31, [x20, #8]
	ld1.d	{ v28 }[1], [x24]
	orr.16b	v28, v28, v27
	orr.16b	v29, v29, v25
	cmeq.2d	v25, v29, v25
	cmeq.2d	v27, v28, v27
	ldp	d28, d29, [x22, #8]
	ld1.d	{ v28 }[1], [x9]
	orr.16b	v28, v28, v24
	cmeq.2d	v24, v28, v24
	uzp1.4s	v25, v25, v27
	ldp	d28, d27, [x19, #8]
	ld1.d	{ v28 }[1], [x23]
	orr.16b	v28, v28, v23
	cmeq.2d	v23, v28, v23
	uzp1.4s	v23, v23, v24
	add	x9, x5, #16
	ld1.d	{ v30 }[1], [x9]
	orr.16b	v24, v30, v22
	cmeq.2d	v22, v24, v22
	add	x9, x4, #16
	ld1.d	{ v31 }[1], [x9]
	orr.16b	v24, v31, v21
	cmeq.2d	v21, v24, v21
	uzp1.4s	v21, v22, v21
	add	x9, x7, #16
	ld1.d	{ v29 }[1], [x9]
	orr.16b	v22, v29, v20
	cmeq.2d	v20, v22, v20
	mvn.16b	v2, v2
	orn.16b	v2, v2, v25
	add	x9, x6, #16
	add	x12, x5, #24
	add	x13, x4, #24
	add	x14, x6, #24
	ld1.d	{ v27 }[1], [x9]
	add	x9, x7, #24
	orr.16b	v22, v27, v19
	cmeq.2d	v19, v22, v19
	uzp1.4s	v19, v19, v20
	ldp	d20, d22, [x21, #24]
	ld1.d	{ v20 }[1], [x12]
	mvn.16b	v24, v26
	orr.16b	v20, v20, v18
	cmeq.2d	v18, v20, v18
	orn.16b	v20, v24, v23
	ldp	d23, d24, [x20, #24]
	ld1.d	{ v23 }[1], [x13]
	orr.16b	v23, v23, v16
	orn.16b	v2, v2, v21
	cmeq.2d	v16, v23, v16
	ldp	d21, d23, [x22, #24]
	ld1.d	{ v21 }[1], [x9]
	orn.16b	v19, v20, v19
	uzp1.4s	v16, v18, v16
	ldp	d18, d20, [x19, #24]
	ld1.d	{ v18 }[1], [x14]
	orr.16b	v21, v21, v7
	cmeq.2d	v7, v21, v7
	orr.16b	v18, v18, v17
	cmeq.2d	v17, v18, v17
	uzp1.4s	v7, v17, v7
	orn.16b	v2, v2, v16
	orn.16b	v7, v19, v7
	add	x9, x5, #32
	ld1.d	{ v22 }[1], [x9]
	orr.16b	v16, v22, v3
	cmeq.2d	v3, v16, v3
	add	x9, x4, #32
	ld1.d	{ v24 }[1], [x9]
	orr.16b	v16, v24, v5
	cmeq.2d	v5, v16, v5
	uzp1.4s	v3, v3, v5
	add	x9, x6, #32
	add	x12, x7, #32
	ld1.d	{ v23 }[1], [x12]
	mov	x12, x3
	ld1.d	{ v20 }[1], [x9]
	orr.16b	v5, v23, v4
	cmeq.2d	v4, v5, v4
	orr.16b	v5, v20, v6
	cmeq.2d	v5, v5, v6
	uzp1.4s	v4, v5, v4
	orn.16b	v2, v2, v3
	orn.16b	v3, v7, v4
	xtn.4h	v2, v2
	orr.8b	v0, v0, v2
	xtn.4h	v2, v3
	orr.8b	v1, v1, v2
	add	x16, x16, #8
	cmp	x3, x16
	b.ne	LBB39_25
; %bb.26:
	orr.8b	v0, v1, v0
	shl.4h	v0, v0, #15
	cmlt.4h	v0, v0, #0
	umaxv.4h	h0, v0
	fmov	w9, s0
	and	w16, w9, #0x1
	ldp	x8, x19, [sp, #16]              ; 16-byte Folded Reload
	cmp	x12, x19
	ldr	x6, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w7, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	b.ne	LBB39_14
	b	LBB39_16
LBB39_27:
	mov	w9, #262144                     ; =0x40000
	sub	w9, w9, w7
	cmp	w19, w9
	b.hi	LBB39_4
; %bb.28:
	mov	x8, #0                          ; =0x0
	add	w9, w7, w19
	str	w9, [x6, #24]
	add	w9, w13, w19
	str	w9, [x0, x14]
	mov	w12, #40                        ; =0x28
LBB39_29:                               ; =>This Inner Loop Header: Depth=1
	add	w9, w13, w8
	umaddl	x14, w9, w12, x11
	ldr	w15, [x1, #8]
	add	w15, w8, w15
	umaddl	x11, w15, w12, x11
	ldp	q0, q1, [x11]
	ldr	x11, [x11, #32]
	str	x11, [x14, #32]
	stp	q0, q1, [x14]
	ldr	x11, [x6]
	umaddl	x9, w9, w12, x11
	ldr	w14, [x2, #8]
	add	w14, w8, w14
	umaddl	x14, w14, w12, x11
	ldp	q0, q1, [x14]
	ldp	q2, q3, [x9]
	orr.16b	v0, v2, v0
	orr.16b	v1, v3, v1
	ldr	x14, [x14, #32]
	stp	q0, q1, [x9]
	ldr	x15, [x9, #32]
	orr	x14, x15, x14
	str	x14, [x9, #32]
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	LBB39_29
; %bb.30:
	str	w13, [x1, #8]
	mov	w0, #1                          ; =0x1
	strb	w0, [x3]
	b	LBB39_20
	.loh AdrpAdd	Lloh398, Lloh399
	.loh AdrpAdrp	Lloh396, Lloh398
	.loh AdrpLdr	Lloh396, Lloh397
	.loh AdrpAdd	Lloh400, Lloh401
	.loh AdrpAdd	Lloh404, Lloh405
	.loh AdrpAdrp	Lloh402, Lloh404
	.loh AdrpLdr	Lloh402, Lloh403
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_union
_oq_union:                              ; @oq_union
	.cfi_startproc
; %bb.0:
	ldr	x8, [x1]
	ldp	x9, x10, [x0]
	orr	x8, x8, x9
	str	x8, [x0]
	ldr	x8, [x1, #8]
	orr	x8, x8, x10
	str	x8, [x0, #8]
	ldr	x8, [x1, #16]
	ldp	x9, x10, [x0, #16]
	orr	x8, x8, x9
	str	x8, [x0, #16]
	ldr	x8, [x1, #24]
	orr	x8, x8, x10
	str	x8, [x0, #24]
	ldr	x8, [x0, #32]
	ldr	x9, [x1, #32]
	orr	x8, x9, x8
	str	x8, [x0, #32]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_type
_oq_type:                               ; @oq_type
	.cfi_startproc
; %bb.0:
	and	w8, w2, #0xff
	cmp	w8, #7
	b.eq	LBB41_9
; %bb.1:
	cmp	w8, #8
	b.ne	LBB41_12
; %bb.2:
	ldrb	w8, [x1, #56]
	cmp	w8, #1
	b.ne	LBB41_15
; %bb.3:
	ldrb	w8, [x1, #57]
	cbnz	w8, LBB41_15
; %bb.4:
	ldrh	w8, [x1]
	cmp	w8, #256
	b.ne	LBB41_15
; %bb.5:
	lsr	x8, x2, #32
	ldr	w9, [x1, #4]
	cmp	w9, w8
	b.ne	LBB41_15
; %bb.6:
	ldr	x9, [x0, #8]
	ldr	x9, [x9]
	cbz	x9, LBB41_15
; %bb.7:
	ldr	w10, [x9, #16]
	cmp	w10, w8
	b.ls	LBB41_15
; %bb.8:
	add	x8, x9, x8, lsl #5
	ldrb	w8, [x8, #56]
	ubfx	w8, w8, #1, #1
	and	w0, w8, #0x1
	ret
LBB41_9:
	mov	w8, #0                          ; =0x0
	ldrb	w9, [x1, #56]
	ldrb	w10, [x1, #57]
	cmp	w9, #0
	ccmp	w10, #0, #0, eq
	b.ne	LBB41_14
; %bb.10:
	ldrh	w9, [x1]
	cmp	w9, #128
	b.ne	LBB41_14
; %bb.11:
	ldr	x8, [x1, #48]
	ldp	q1, q0, [x1, #16]
	cmp	x8, #0
	cset	w8, ne
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w9, s0
	orr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB41_12:
	ldrb	w8, [x1, #56]
	and	w8, w8, #0xff
	ldrb	w9, [x1, #57]
	orr	w8, w9, w8
	cbnz	w8, LBB41_15
; %bb.13:
	ldr	x8, [x1, #48]
	ldrh	w9, [x1]
	and	w9, w9, #0xffff
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w2
	ldp	q1, q0, [x1, #16]
	cmp	x8, #0
	cset	w8, eq
	cmp	w9, w10, uxth
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w9, s0
	bic	w8, w8, w9
	csel	w8, wzr, w8, ne
LBB41_14:
	and	w0, w8, #0x1
	ret
LBB41_15:
	and	w0, wzr, #0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_require
lCPI42_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI42_1:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	8                               ; 0x8
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_require:                            ; @oq_require
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	add	x8, x0, #104, lsl #12           ; =425984
	add	x8, x8, #2952
	ldrb	w9, [x2, #56]
	cbz	w9, LBB42_3
; %bb.1:
	add	x9, x0, #100, lsl #12           ; =409600
	add	x10, x9, #848
	ldr	w9, [x2, #4]
	add	x9, x0, x9, lsl #2
	add	x11, x9, #100, lsl #12          ; =409600
	ldr	w9, [x11, #876]
	ldr	w11, [x10, #24]
	mov	w12, #262144                    ; =0x40000
	sub	w12, w12, w11
	cmp	w9, w12
	b.ls	LBB42_8
; %bb.2:
	mov	w0, #0                          ; =0x0
Lloh406:
	adrp	x9, lCPI42_0@PAGE
Lloh407:
	ldr	q0, [x9, lCPI42_0@PAGEOFF]
	str	q0, [x8]
Lloh408:
	adrp	x9, l_.str.95@PAGE
Lloh409:
	add	x9, x9, l_.str.95@PAGEOFF
	str	x9, [x8, #16]
	add	sp, sp, #16
	ret
LBB42_3:
	ldrh	w9, [x2]
	cmp	w9, #128
	b.ne	LBB42_16
; %bb.4:
	ldrb	w9, [x2, #57]
	cbnz	w9, LBB42_7
; %bb.5:
	ldr	x9, [x2, #16]
	cbnz	x9, LBB42_15
; %bb.6:
	ldur	q0, [x2, #40]
	ldur	q1, [x2, #24]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
Lloh410:
	adrp	x10, lCPI42_1@PAGE
Lloh411:
	ldr	q1, [x10, lCPI42_1@PAGEOFF]
	bic.16b	v0, v1, v0
	addv.4s	s0, v0
	fmov	w10, s0
	and	w10, w10, #0xff
	tst	w10, #0xf
	b.ne	LBB42_15
LBB42_7:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8]
Lloh412:
	adrp	x9, l_.str.129@PAGE
Lloh413:
	add	x9, x9, l_.str.129@PAGEOFF
	b	LBB42_14
LBB42_8:
	add	w11, w11, w9
	str	w11, [x10, #24]
	cbz	w9, LBB42_16
; %bb.9:
	ldr	x10, [x10]
	ldr	w11, [x2, #8]
	mov	w12, #56                        ; =0x38
	umull	x12, w1, w12
	mov	w13, #40                        ; =0x28
	b	LBB42_11
LBB42_10:                               ;   in Loop: Header=BB42_11 Depth=1
	ldp	q1, q0, [x15]
	ldr	x15, [x0, #8]
	add	x15, x15, x12
	add	x16, x15, #808
	ldp	q2, q3, [x16]
	orr.16b	v1, v2, v1
	orr.16b	v0, v3, v0
	stp	q1, q0, [x16]
	ldr	x16, [x15, #840]
	orr	x14, x16, x14
	str	x14, [x15, #840]
	add	w11, w11, #1
	subs	x9, x9, #1
	b.eq	LBB42_16
LBB42_11:                               ; =>This Inner Loop Header: Depth=1
	umaddl	x15, w11, w13, x10
	ldr	x14, [x15, #32]
	ldp	q1, q0, [x15]
	cmeq.2d	v0, v0, #0
	cmeq.2d	v1, v1, #0
	uzp1.4s	v0, v1, v0
	mvn.16b	v0, v0
	umaxv.4s	s0, v0
	fmov	w16, s0
	tbnz	w16, #0, LBB42_10
; %bb.12:                               ;   in Loop: Header=BB42_11 Depth=1
	cbnz	x14, LBB42_10
; %bb.13:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8]
Lloh414:
	adrp	x9, l_.str.128@PAGE
Lloh415:
	add	x9, x9, l_.str.128@PAGEOFF
LBB42_14:
	stp	xzr, x9, [x8, #8]
	add	sp, sp, #16
	ret
LBB42_15:
	ldr	x8, [x0, #8]
	mov	w10, #56                        ; =0x38
	umaddl	x8, w1, w10, x8
	ldur	q0, [x2, #24]
	ldp	q1, q2, [x8, #816]
	orr.16b	v0, v1, v0
	ldur	q1, [x2, #40]
	ldr	x10, [x8, #808]
	orr	x9, x10, x9
	str	x9, [x8, #808]
	orr.16b	v1, v2, v1
	stp	q0, q1, [x8, #816]
LBB42_16:
	mov	w0, #1                          ; =0x1
	add	sp, sp, #16
	ret
	.loh AdrpAdd	Lloh408, Lloh409
	.loh AdrpAdrp	Lloh406, Lloh408
	.loh AdrpLdr	Lloh406, Lloh407
	.loh AdrpLdr	Lloh410, Lloh411
	.loh AdrpAdd	Lloh412, Lloh413
	.loh AdrpAdd	Lloh414, Lloh415
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_child
lCPI43_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI43_1:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_child:                              ; @oq_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh416:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh417:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh418:
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	add	x8, x0, #104, lsl #12           ; =425984
	add	x9, x8, #2952
	ldr	x8, [x0, #8]
	ldr	x11, [x8]
	cbz	x11, LBB43_5
; %bb.1:
	ldr	w15, [x1, #4]
	ldr	w8, [x11, #8]
	cmp	w15, w8
	b.hs	LBB43_5
; %bb.2:
	ldr	x8, [x11]
	add	x8, x8, x15, lsl #4
	ldrh	w10, [x8, #2]
	cmp	w2, w10
	b.hs	LBB43_5
; %bb.3:
	add	x10, x0, #100, lsl #12          ; =409600
	add	x12, x10, #848
	ldr	x8, [x8, #8]
	mov	w10, #12                        ; =0xc
	umaddl	x10, w2, w10, x8
	ldrb	w8, [x10]
	ldr	w10, [x10, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #28]
	stp	q0, q0, [sp]
	add	x13, x0, #100, lsl #12          ; =409600
	add	x13, x13, #876
	ldr	w4, [x13, x15, lsl #2]
	ldr	w14, [x12, #24]
	mov	w16, #262144                    ; =0x40000
	sub	w16, w16, w14
	cmp	w4, w16
	b.ls	LBB43_9
; %bb.4:
	mov	w0, #0                          ; =0x0
Lloh419:
	adrp	x8, lCPI43_1@PAGE
Lloh420:
	ldr	q0, [x8, lCPI43_1@PAGEOFF]
	str	q0, [x9]
Lloh421:
	adrp	x8, l_.str.95@PAGE
Lloh422:
	add	x8, x8, l_.str.95@PAGEOFF
	b	LBB43_6
LBB43_5:
	mov	w0, #0                          ; =0x0
Lloh423:
	adrp	x8, lCPI43_0@PAGE
Lloh424:
	ldr	q0, [x8, lCPI43_0@PAGEOFF]
	str	q0, [x9]
Lloh425:
	adrp	x8, l_.str.130@PAGE
Lloh426:
	add	x8, x8, l_.str.130@PAGEOFF
LBB43_6:
	str	x8, [x9, #16]
LBB43_7:
	ldur	x8, [x29, #-24]
Lloh427:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh428:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh429:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB43_56
; %bb.8:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB43_9:
	add	w14, w14, w4
	str	w14, [x12, #24]
	cbz	w4, LBB43_18
; %bb.10:
	ldr	x14, [x12, #2080]
	add	x15, x0, x15, lsl #2
	add	x16, x15, #100, lsl #12         ; =409600
	ldr	w17, [x16, #1900]
	ldr	w15, [x11, #28]
	and	x16, x4, #0x7
	cmp	w4, #8
	b.hs	LBB43_28
; %bb.11:
	mov	x0, #0                          ; =0x0
	mov	w7, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
LBB43_12:
	cbz	x16, LBB43_19
; %bb.13:
	add	w17, w17, w0
	mov	w0, #76                         ; =0x4c
	b	LBB43_16
LBB43_14:                               ;   in Loop: Header=BB43_16 Depth=1
	ldr	x5, [x11, #10272]
	umaddl	x4, w4, w0, x5
	ldrh	w4, [x4, #12]
LBB43_15:                               ;   in Loop: Header=BB43_16 Depth=1
	cmp	w4, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w17, w17, #1
	subs	x16, x16, #1
	b.eq	LBB43_19
LBB43_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	w4, [x14, w17, uxtw #2]
	cmp	w4, w15
	b.lo	LBB43_14
; %bb.17:                               ;   in Loop: Header=BB43_16 Depth=1
	mov	w4, #0                          ; =0x0
	b	LBB43_15
LBB43_18:
	mov	w6, #0                          ; =0x0
	mov	w7, #0                          ; =0x0
LBB43_19:
	cmp	w8, #7
	b.eq	LBB43_23
; %bb.20:
	cmp	w8, #8
	b.ne	LBB43_25
; %bb.21:
	ldr	w11, [x13, w10, uxtw #2]
	cmp	w7, w11
	b.ne	LBB43_54
; %bb.22:
	ldrb	w9, [x1, #56]
	ldrh	w11, [x1, #2]
	ldr	w12, [x1, #8]
	add	w13, w12, w6
	b	LBB43_27
LBB43_23:
	cmp	w7, #1
	b.ne	LBB43_55
; %bb.24:
	mov	w11, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	ldr	x10, [x12]
	ldr	w12, [x1, #8]
	add	w12, w12, w6
	mov	w14, #40                        ; =0x28
	umaddl	x10, w12, w14, x10
	ldp	q0, q1, [x10]
	stur	q0, [sp, #4]
	stur	q1, [sp, #20]
	ldr	x10, [x10, #32]
	stur	x10, [sp, #36]
	b	LBB43_26
LBB43_25:
	mov	w11, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
LBB43_26:
	mov	w10, #-1                        ; =0xffffffff
LBB43_27:
	ldp	q0, q1, [sp]
	stur	q0, [x3, #12]
	mov	w12, #1                         ; =0x1
	lsl	w8, w12, w8
	strh	w8, [x3]
	strh	w11, [x3, #2]
	stp	w10, w13, [x3, #4]
	stur	q1, [x3, #28]
	ldur	q0, [sp, #28]
	stur	q0, [x3, #40]
	strb	w9, [x3, #56]
	stur	wzr, [x3, #57]
	mov	w0, #1                          ; =0x1
	str	wzr, [x3, #60]
	b	LBB43_7
LBB43_28:
	mov	x0, #0                          ; =0x0
	mov	w7, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	and	x4, x4, #0xfffffff8
	mov	w5, #76                         ; =0x4c
	b	LBB43_31
LBB43_29:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
LBB43_30:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	x0, x0, #8
	cmp	x4, x0
	b.eq	LBB43_12
LBB43_31:                               ; =>This Inner Loop Header: Depth=1
	add	w19, w17, w0
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_33
; %bb.32:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_34
LBB43_33:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_34:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #1
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_36
; %bb.35:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_37
LBB43_36:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_37:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #2
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_39
; %bb.38:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_40
LBB43_39:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_40:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #3
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_42
; %bb.41:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_43
LBB43_42:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_43:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #4
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_45
; %bb.44:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_46
LBB43_45:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_46:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #5
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_48
; %bb.47:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_49
LBB43_48:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_49:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #6
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.hs	LBB43_51
; %bb.50:                               ;   in Loop: Header=BB43_31 Depth=1
	ldr	x20, [x11, #10272]
	umaddl	x19, w19, w5, x20
	ldrh	w19, [x19, #12]
	b	LBB43_52
LBB43_51:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
LBB43_52:                               ;   in Loop: Header=BB43_31 Depth=1
	cmp	w19, w2
	cinc	w6, w6, lo
	cinc	w7, w7, eq
	add	w19, w17, w0
	add	w19, w19, #7
	ldr	w19, [x14, w19, uxtw #2]
	cmp	w19, w15
	b.lo	LBB43_29
; %bb.53:                               ;   in Loop: Header=BB43_31 Depth=1
	mov	w19, #0                         ; =0x0
	b	LBB43_30
LBB43_54:
	mov	w0, #0                          ; =0x0
Lloh430:
	adrp	x8, lCPI43_0@PAGE
Lloh431:
	ldr	q0, [x8, lCPI43_0@PAGEOFF]
	str	q0, [x9]
Lloh432:
	adrp	x8, l_.str.132@PAGE
Lloh433:
	add	x8, x8, l_.str.132@PAGEOFF
	b	LBB43_6
LBB43_55:
	mov	w0, #0                          ; =0x0
Lloh434:
	adrp	x8, lCPI43_0@PAGE
Lloh435:
	ldr	q0, [x8, lCPI43_0@PAGEOFF]
	str	q0, [x9]
Lloh436:
	adrp	x8, l_.str.131@PAGE
Lloh437:
	add	x8, x8, l_.str.131@PAGEOFF
	b	LBB43_6
LBB43_56:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh416, Lloh417, Lloh418
	.loh AdrpAdd	Lloh421, Lloh422
	.loh AdrpAdrp	Lloh419, Lloh421
	.loh AdrpLdr	Lloh419, Lloh420
	.loh AdrpAdd	Lloh425, Lloh426
	.loh AdrpAdrp	Lloh423, Lloh425
	.loh AdrpLdr	Lloh423, Lloh424
	.loh AdrpLdrGotLdr	Lloh427, Lloh428, Lloh429
	.loh AdrpAdd	Lloh432, Lloh433
	.loh AdrpAdrp	Lloh430, Lloh432
	.loh AdrpLdr	Lloh430, Lloh431
	.loh AdrpAdd	Lloh436, Lloh437
	.loh AdrpAdrp	Lloh434, Lloh436
	.loh AdrpLdr	Lloh434, Lloh435
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function oq_substitute
lCPI44_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_oq_substitute:                         ; @oq_substitute
	.cfi_startproc
; %bb.0:
	add	x8, x0, #104, lsl #12           ; =425984
	add	x8, x8, #2952
	add	x9, x0, #100, lsl #12           ; =409600
	add	x9, x9, #848
	ldr	w13, [x9, #24]
	sub	w10, w13, #64, lsl #12          ; =262144
	sub	w10, w10, #1
	cmn	w10, #256
	b.hs	LBB44_11
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x14, [x0, #8]
	mov	w11, #56                        ; =0x38
	umaddl	x11, w2, w11, x14
	mov	w15, w2
	add	x12, x11, #792
	ldr	x11, [x4]
	add	w13, w13, #256
	str	w13, [x9, #24]
	mov	w13, #30720                     ; =0x7800
	umaddl	x16, w15, w13, x14
	mov	w13, #2152                      ; =0x868
	umaddl	x13, w15, w13, x0
	add	x13, x13, #2080
	add	x14, x0, #100, lsl #12          ; =409600
	add	x14, x14, #876
	add	x15, x16, #1244
	movi.2d	v0, #0000000000000000
	mov	w16, #40                        ; =0x28
	movi.2d	v1, #0000000000000000
	b	LBB44_4
LBB44_2:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x0, [x17]
	ldur	q2, [x17, #24]
	ldur	q3, [x17, #8]
	orr	x11, x0, x11
	orr.16b	v0, v3, v0
	orr.16b	v1, v2, v1
LBB44_3:                                ;   in Loop: Header=BB44_4 Depth=1
	add	x10, x10, #1
	add	x15, x15, #120
	cmp	x10, #256
	b.eq	LBB44_13
LBB44_4:                                ; =>This Inner Loop Header: Depth=1
	lsr	w17, w10, #6
	add	w17, w17, #1
	ldr	x17, [x4, w17, uxtw #3]
	lsr	x17, x17, x10
	tbz	w17, #0, LBB44_3
; %bb.5:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	w17, [x12]
	cmp	x10, x17
	b.hs	LBB44_14
; %bb.6:                                ;   in Loop: Header=BB44_4 Depth=1
	ldurh	w0, [x15, #-4]
	add	x17, x3, x0, lsl #6
	ldr	w2, [x17, #4]
	ldrh	w0, [x13, x0, lsl #1]
	ldr	w6, [x15]
	cmp	w2, w6
	ccmp	x10, x0, #0, eq
	b.lo	LBB44_12
; %bb.7:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	w2, [x14, x2, lsl #2]
	sub	w6, w10, w0
	cmp	w6, w2
	b.hs	LBB44_12
; %bb.8:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	w17, [x17, #8]
	ldr	x2, [x9]
	sub	w17, w17, w0
	add	w17, w10, w17
	umaddl	x17, w17, w16, x2
	ldp	q3, q2, [x17]
	cmeq.2d	v2, v2, #0
	cmeq.2d	v3, v3, #0
	uzp1.4s	v2, v3, v2
	mvn.16b	v2, v2
	umaxv.4s	s2, v2
	fmov	w0, s2
	tbnz	w0, #0, LBB44_2
; %bb.9:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x0, [x17, #32]
	cbnz	x0, LBB44_2
; %bb.10:
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8]
Lloh438:
	adrp	x9, l_.str.135@PAGE
Lloh439:
	add	x9, x9, l_.str.135@PAGEOFF
	stp	xzr, x9, [x8, #8]
	ret
LBB44_11:
	mov	w0, #0                          ; =0x0
Lloh440:
	adrp	x9, lCPI44_0@PAGE
Lloh441:
	ldr	q0, [x9, lCPI44_0@PAGEOFF]
	str	q0, [x8]
Lloh442:
	adrp	x9, l_.str.95@PAGE
Lloh443:
	add	x9, x9, l_.str.95@PAGEOFF
	str	x9, [x8, #16]
	ret
LBB44_12:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8]
Lloh444:
	adrp	x9, l_.str.134@PAGE
Lloh445:
	add	x9, x9, l_.str.134@PAGEOFF
	stp	xzr, x9, [x8, #8]
	ret
LBB44_13:
	str	x11, [x5]
	stur	q0, [x5, #8]
	mov	w0, #1                          ; =0x1
	stur	q1, [x5, #24]
	ret
LBB44_14:
	mov	w0, #0                          ; =0x0
	mov	w9, #2                          ; =0x2
	stp	w9, w1, [x8]
Lloh446:
	adrp	x9, l_.str.133@PAGE
Lloh447:
	add	x9, x9, l_.str.133@PAGEOFF
	stp	xzr, x9, [x8, #8]
	ret
	.loh AdrpAdd	Lloh438, Lloh439
	.loh AdrpAdd	Lloh442, Lloh443
	.loh AdrpAdrp	Lloh440, Lloh442
	.loh AdrpLdr	Lloh440, Lloh441
	.loh AdrpAdd	Lloh444, Lloh445
	.loh AdrpAdd	Lloh446, Lloh447
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require a consistent module and plan output."

l_.str.1:                               ; @.str.1
	.asciz	"I require retained layout facts, not count-only placeholders."

l_.str.2:                               ; @.str.2
	.asciz	"I could not own the preflighted retained fields."

l_.str.3:                               ; @.str.3
	.asciz	"I have not described this record field kind."

l_.str.4:                               ; @.str.4
	.asciz	"I require nested kind identity to match the field tag."

l_.str.5:                               ; @.str.5
	.asciz	"I could not establish checked ownership declarations."

l_.str.6:                               ; @.str.6
	.asciz	"I require explicit ordinary authority for every record."

l_.str.7:                               ; @.str.7
	.asciz	"I require explicit ordinary authority for forward records."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate my record plan."

l_.str.9:                               ; @.str.9
	.asciz	"I could not allocate my exact record maps."

l_.str.10:                              ; @.str.10
	.asciz	"I described record identities without executable admission."

l_.str.11:                              ; @.str.11
	.asciz	"I require consistent mixed descriptor inputs."

l_.str.12:                              ; @.str.12
	.asciz	"I require retained mixed layout facts."

l_.str.13:                              ; @.str.13
	.asciz	"I reached my mixed ownership byte budget."

l_.str.14:                              ; @.str.14
	.asciz	"I require a complete mixed layout count."

l_.str.15:                              ; @.str.15
	.asciz	"I require exact ownership transport before allocation."

l_.str.16:                              ; @.str.16
	.asciz	"I could not allocate my mixed descriptor view."

l_.str.17:                              ; @.str.17
	.asciz	"I could not materialize my checked retained layouts."

l_.str.18:                              ; @.str.18
	.asciz	"I could not retain my exact ownership descriptors."

l_.str.19:                              ; @.str.19
	.asciz	"I described mixed identities without executable authority."

l_.str.20:                              ; @.str.20
	.asciz	"I require consistent acyclic mixed declaration facts."

l_.str.21:                              ; @.str.21
	.asciz	"I require consistent owner-array descriptor inputs."

l_.str.22:                              ; @.str.22
	.asciz	"I refuse service claims before owner-array description."

l_.str.23:                              ; @.str.23
	.asciz	"I require retained layouts and explicit ownership facts."

l_.str.24:                              ; @.str.24
	.asciz	"I reached my ownership transport budget."

l_.str.25:                              ; @.str.25
	.asciz	"I retain prior-only owner-array layout dependencies."

l_.str.26:                              ; @.str.26
	.asciz	"I require a complete layout count."

l_.str.27:                              ; @.str.27
	.asciz	"I could not allocate my owner-array descriptor view."

l_.str.28:                              ; @.str.28
	.asciz	"I could not materialize preflighted owner-array layouts."

l_.str.29:                              ; @.str.29
	.asciz	"I retain exact scalar-only borrowed roots."

l_.str.30:                              ; @.str.30
	.asciz	"I could not retain original descriptor transport."

l_.str.31:                              ; @.str.31
	.asciz	"I described pending owner ARRAY fields without runtime admission."

l_.str.32:                              ; @.str.32
	.asciz	"I require a complete immutable module envelope and output."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_owned_array_origins.invalid
l___const.nvm_analyze_owned_array_origins.invalid:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.32

	.section	__TEXT,__cstring,cstring_literals
l_.str.33:                              ; @.str.33
	.asciz	"I refuse service claims before origin analysis."

l_.str.34:                              ; @.str.34
	.asciz	"I require one explicit standalone entry and at most eight functions."

l_.str.35:                              ; @.str.35
	.asciz	"I reached my local or argument limit."

l_.str.36:                              ; @.str.36
	.asciz	"I could not allocate my bounded origin query."

l_.str.37:                              ; @.str.37
	.asciz	"I require closed entry obligations without formal bits."

l_.str.38:                              ; @.str.38
	.asciz	"I require existing concrete entry origins."

l_.str.39:                              ; @.str.39
	.asciz	"I proved conditional owner origins and a closed entry only; execution authority remains separate."

l_.str.40:                              ; @.str.40
	.asciz	"I reached my record layout limit."

l_.str.41:                              ; @.str.41
	.asciz	"I require canonical layout headers and names."

l_.str.42:                              ; @.str.42
	.asciz	"I reached my retained field limit."

l_.str.43:                              ; @.str.43
	.asciz	"I require canonical closed fields and names."

l_.str.44:                              ; @.str.44
	.asciz	"I require exact retained bytes and per-kind counts."

l_.str.45:                              ; @.str.45
	.asciz	"I require exact all-record scalar/string forward layouts."

l_.str.46:                              ; @.str.46
	.asciz	"I validated only retained byte structure."

l_.str.47:                              ; @.str.47
	.asciz	"I require a complete preflighted field."

l_.str.48:                              ; @.str.48
	.asciz	"I require an exact acyclic record graph."

l_.str.49:                              ; @.str.49
	.asciz	"I require bounded record graph depth."

l_.str.50:                              ; @.str.50
	.asciz	"I validated the exact forward record graph."

l_.str.51:                              ; @.str.51
	.asciz	"I retain passive non-record declarations without owner authority."

l_.str.52:                              ; @.str.52
	.asciz	"I require explicit complete record declarations."

l_.str.53:                              ; @.str.53
	.asciz	"I require prior children in the same owner or ordinary category."

l_.str.54:                              ; @.str.54
	.asciz	"I reached my owner nesting limit."

l_.str.55:                              ; @.str.55
	.asciz	"I require exact scalar, STRING or pending ARRAY leaves."

l_.str.56:                              ; @.str.56
	.asciz	"I reached my expanded owner leaf-path budget."

l_.str.57:                              ; @.str.57
	.asciz	"I reached my total owner leaf-path budget."

l_.str.58:                              ; @.str.58
	.asciz	"I described pending owner leaves without element proof."

l_.str.60:                              ; @.str.60
	.asciz	"I could not allocate my bounded owner leaf paths."

l_.str.61:                              ; @.str.61
	.asciz	"I reached my retained leaf-path length limit."

l_.str.62:                              ; @.str.62
	.asciz	"I require exact expanded leaf-path counts."

l_.str.63:                              ; @.str.63
	.asciz	"I retained bounded owner leaf paths."

l_.str.64:                              ; @.str.64
	.asciz	"I could not allocate ARRAY path indices."

l_.str.65:                              ; @.str.65
	.asciz	"I could not allocate bounded intermediate field facts."

l_.str.66:                              ; @.str.66
	.asciz	"I keep borrowed modes outside owner ARRAY origins."

l_.str.67:                              ; @.str.67
	.asciz	"I require exact scalar or owner signatures."

l_.str.68:                              ; @.str.68
	.asciz	"I require modeled exact local types."

l_.str.69:                              ; @.str.69
	.asciz	"I retain a scalar or VOID entry result."

l_.str.70:                              ; @.str.70
	.asciz	"I reached my result ARRAY path budget."

l_.str.71:                              ; @.str.71
	.asciz	"I require complete function names."

l_.str.72:                              ; @.str.72
	.asciz	"__init__"

l_.str.73:                              ; @.str.73
	.asciz	"I keep initializer entry roots outside this query."

l_.str.74:                              ; @.str.74
	.asciz	"I require complete nonempty code ranges."

l_.str.75:                              ; @.str.75
	.asciz	"I require distinct function code ranges."

l_.str.76:                              ; @.str.76
	.asciz	"I reached my instruction budget."

l_.str.77:                              ; @.str.77
	.asciz	"I require complete decoded instructions."

l_.str.78:                              ; @.str.78
	.asciz	"I have no owner-origin transfer for this opcode."

l_.str.79:                              ; @.str.79
	.asciz	"I require canonical BOOL immediates."

l_.str.80:                              ; @.str.80
	.asciz	"I require an existing STRING constant."

l_.str.81:                              ; @.str.81
	.asciz	"I require an existing local."

l_.str.82:                              ; @.str.82
	.asciz	"I require an existing callee."

l_.str.83:                              ; @.str.83
	.asciz	"I do not call my selected entry."

l_.str.84:                              ; @.str.84
	.asciz	"I require an exact owner declaration."

l_.str.85:                              ; @.str.85
	.asciz	"I require declared FLOAT array sites."

l_.str.86:                              ; @.str.86
	.asciz	"I reached my concrete origin budget."

l_.str.87:                              ; @.str.87
	.asciz	"I require an instruction-boundary branch target."

l_.str.88:                              ; @.str.88
	.asciz	"I require explicit terminal control flow."

l_.str.89:                              ; @.str.89
	.asciz	"I require an acyclic complete call graph."

l_.str.90:                              ; @.str.90
	.asciz	"I reached my formal ARRAY path budget."

l_.str.91:                              ; @.str.91
	.asciz	"I reached my origin fixed-point visit budget."

l_.str.92:                              ; @.str.92
	.asciz	"I require checked state for every declared instruction."

l_.str.93:                              ; @.str.93
	.asciz	"I require at least one checked return per function."

l_.str.94:                              ; @.str.94
	.asciz	"I reached my intermediate owner-field fact budget."

l_.str.95:                              ; @.str.95
	.asciz	"I reached my field-transfer work budget."

l_.str.96:                              ; @.str.96
	.asciz	"I require a valid state destination."

l_.str.97:                              ; @.str.97
	.asciz	"I reached my stack limit."

l_.str.98:                              ; @.str.98
	.asciz	"I require equal join stack heights."

l_.str.99:                              ; @.str.99
	.asciz	"I reached my state cell budget."

l_.str.100:                             ; @.str.100
	.asciz	"I could not allocate instruction state."

l_.str.101:                             ; @.str.101
	.asciz	"I require matching initialized owner identities at joins."

l_.str.102:                             ; @.str.102
	.asciz	"I require opcode metadata."

l_.str.103:                             ; @.str.103
	.asciz	"I require the declared return count."

l_.str.104:                             ; @.str.104
	.asciz	"I require an exact complete returned value."

l_.str.105:                             ; @.str.105
	.asciz	"I require complete operand stacks."

l_.str.106:                             ; @.str.106
	.asciz	"I reached my stack budget."

l_.str.107:                             ; @.str.107
	.asciz	"I require bounded scalar operand rows."

l_.str.108:                             ; @.str.108
	.asciz	"I require modeled scalar operand alternatives."

l_.str.109:                             ; @.str.109
	.asciz	"I require exact typed scalar operands or a checked optional FLOAT comparison."

l_.str.110:                             ; @.str.110
	.asciz	"I do not duplicate owners or observations."

l_.str.111:                             ; @.str.111
	.asciz	"I require explicit owner consumption."

l_.str.112:                             ; @.str.112
	.asciz	"I require initialized exact local alternatives."

l_.str.113:                             ; @.str.113
	.asciz	"I require an exact ordinary local store."

l_.str.114:                             ; @.str.114
	.asciz	"I keep an observed owner live until projection completes."

l_.str.115:                             ; @.str.115
	.asciz	"I require an intact exact owner source."

l_.str.116:                             ; @.str.116
	.asciz	"I require an empty exact owner destination."

l_.str.117:                             ; @.str.117
	.asciz	"I require exact owner constructor field facts."

l_.str.118:                             ; @.str.118
	.asciz	"I require exact constructor path counts."

l_.str.119:                             ; @.str.119
	.asciz	"I require a live exact owner observation."

l_.str.120:                             ; @.str.120
	.asciz	"I require exact FLOAT literal elements."

l_.str.121:                             ; @.str.121
	.asciz	"I require concrete or conditional FLOAT array origins."

l_.str.122:                             ; @.str.122
	.asciz	"I require exact INT indices."

l_.str.123:                             ; @.str.123
	.asciz	"I require FLOAT writes through every alias."

l_.str.124:                             ; @.str.124
	.asciz	"I require exact positional call field facts."

l_.str.125:                             ; @.str.125
	.asciz	"I require exact INT output operands."

l_.str.126:                             ; @.str.126
	.asciz	"I require exact BOOL control operands."

l_.str.127:                             ; @.str.127
	.asciz	"I require an explicit origin transfer."

l_.str.128:                             ; @.str.128
	.asciz	"I require every owner ARRAY path origin."

l_.str.129:                             ; @.str.129
	.asciz	"I require positive ARRAY origins."

l_.str.130:                             ; @.str.130
	.asciz	"I require an existing exact owner field."

l_.str.131:                             ; @.str.131
	.asciz	"I require one direct ARRAY leaf."

l_.str.132:                             ; @.str.132
	.asciz	"I require exact child path expansion."

l_.str.133:                             ; @.str.133
	.asciz	"I refuse an unbound callee formal bit."

l_.str.134:                             ; @.str.134
	.asciz	"I require exact actual nominal path indexing."

l_.str.135:                             ; @.str.135
	.asciz	"I require initialized actual field origins."

.subsections_via_symbols
