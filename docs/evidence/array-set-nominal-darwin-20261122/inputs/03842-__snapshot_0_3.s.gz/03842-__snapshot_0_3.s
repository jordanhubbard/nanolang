	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm2c_emit_file_bytes          ; -- Begin function nvm2c_emit_file_bytes
	.p2align	2
_nvm2c_emit_file_bytes:                 ; @nvm2c_emit_file_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1040
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x5
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	bl	_nvm_file_host_enter_query
	mov	x25, x0
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w25, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w25, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w25, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w25, #4                         ; =0x4
	b	LBB0_128
LBB0_5:
	cbz	w25, LBB0_10
; %bb.6:
	cmp	w25, #1
	b.eq	LBB0_128
LBB0_7:
	mov	w25, #2                         ; =0x2
	b	LBB0_128
LBB0_8:
	mov	w25, #11                        ; =0xb
	b	LBB0_128
LBB0_9:
	mov	w25, #5                         ; =0x5
	b	LBB0_128
LBB0_10:
	cbz	x23, LBB0_123
; %bb.11:
	cbz	x24, LBB0_123
; %bb.12:
	cbz	x21, LBB0_123
; %bb.13:
	cbnz	x20, LBB0_15
; %bb.14:
	cbnz	x19, LBB0_126
LBB0_15:
	cbz	x22, LBB0_123
; %bb.16:
	ldrb	w8, [x22]
	cbz	w8, LBB0_123
; %bb.17:
	and	w8, w8, #0xffffffdf
	sub	w8, w8, #65
	cmp	w8, #25
	b.hi	LBB0_123
; %bb.18:
	ldrb	w12, [x22, #1]
	cbz	w12, LBB0_24
; %bb.19:
	mov	w8, #1                          ; =0x1
	mov	w9, #2                          ; =0x2
	mov	w10, #223                       ; =0xdf
	mov	w11, #95                        ; =0x5f
LBB0_20:                                ; =>This Inner Loop Header: Depth=1
	and	w13, w12, w10
	sub	w13, w13, #65
	cmp	w13, #26
	b.lo	LBB0_22
; %bb.21:                               ;   in Loop: Header=BB0_20 Depth=1
	sub	w13, w12, #58
	cmn	w13, #10
	ccmp	w12, w11, #4, lo
	b.ne	LBB0_123
LBB0_22:                                ;   in Loop: Header=BB0_20 Depth=1
	cmp	x9, #64
	b.eq	LBB0_123
; %bb.23:                               ;   in Loop: Header=BB0_20 Depth=1
	add	x8, x8, #1
	ldrb	w12, [x22, x9]
	add	x9, x9, #1
	cbnz	w12, LBB0_20
LBB0_24:
	str	xzr, [sp, #192]
	add	x2, sp, #192
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_file_hosted_prepare
	mov	x25, x0
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB0_130
; %bb.25:
	cbnz	w25, LBB0_129
; %bb.26:
	ldr	x0, [sp, #192]
	add	x1, sp, #136
	bl	_nvm_file_hosted_startup
	cbz	w0, LBB0_133
; %bb.27:
	ldr	x25, [sp, #192]
	add	x1, sp, #200
	mov	x0, x25
	bl	_nvm_file_hosted_startup
	cbz	w0, LBB0_133
; %bb.28:
	ldr	w8, [sp, #208]
	cbz	w8, LBB0_76
; %bb.29:
	mov	w26, #0                         ; =0x0
Lloh0:
	adrp	x27, lJTI0_0@PAGE
Lloh1:
	add	x27, x27, lJTI0_0@PAGEOFF
LBB0_30:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_34 Depth 2
	sub	x2, x29, #168
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_hosted_function
	cbz	w0, LBB0_133
; %bb.31:                               ;   in Loop: Header=BB0_30 Depth=1
	ldurh	w8, [x29, #-160]
	cbz	w8, LBB0_75
; %bb.32:                               ;   in Loop: Header=BB0_30 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB0_34
LBB0_33:                                ;   in Loop: Header=BB0_34 Depth=2
	add	w28, w28, #1
	ldurh	w8, [x29, #-160]
	cmp	w8, w28, uxth
	b.ls	LBB0_75
LBB0_34:                                ;   Parent Loop BB0_30 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w2, w28, #0xffff
	add	x3, sp, #352
	add	x4, sp, #272
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_hosted_instruction
	cbz	w0, LBB0_133
; %bb.35:                               ;   in Loop: Header=BB0_34 Depth=2
	ldrb	w8, [sp, #360]
	cmp	w8, #255
	b.eq	LBB0_133
; %bb.36:                               ;   in Loop: Header=BB0_34 Depth=2
	adr	x9, LBB0_37
	ldrh	w10, [x27, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB0_37:                                ;   in Loop: Header=BB0_34 Depth=2
	ldrb	w9, [sp, #272]
	cmp	w9, #1
	b.ne	LBB0_33
; %bb.38:                               ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #0                          ; =0x0
	cmp	w8, #147
	b.gt	LBB0_42
; %bb.39:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #60
	b.gt	LBB0_46
; %bb.40:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #15
	b.eq	LBB0_52
; %bb.41:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #59
	b.eq	LBB0_52
	b	LBB0_55
LBB0_42:                                ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #150
	b.gt	LBB0_49
; %bb.43:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #148
	b.eq	LBB0_53
; %bb.44:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #149
	b.ne	LBB0_55
; %bb.45:                               ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #2                          ; =0x2
	b	LBB0_55
LBB0_46:                                ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #61
	b.eq	LBB0_54
; %bb.47:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #145
	b.ne	LBB0_55
; %bb.48:                               ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #6                          ; =0x6
	b	LBB0_55
LBB0_49:                                ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #151
	b.eq	LBB0_52
; %bb.50:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #161
	b.ne	LBB0_55
; %bb.51:                               ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #3                          ; =0x3
	b	LBB0_55
LBB0_52:                                ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #5                          ; =0x5
	b	LBB0_55
LBB0_53:                                ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #1                          ; =0x1
	b	LBB0_55
LBB0_54:                                ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #4                          ; =0x4
LBB0_55:                                ;   in Loop: Header=BB0_34 Depth=2
	ldr	w10, [sp, #284]
	cmp	w10, w9
	b.ne	LBB0_133
; %bb.56:                               ;   in Loop: Header=BB0_34 Depth=2
	ldrb	w9, [sp, #274]
	cmp	w8, #146
	cset	w10, eq
	cmp	w9, w10
	b.ne	LBB0_133
; %bb.57:                               ;   in Loop: Header=BB0_34 Depth=2
	ldrb	w9, [sp, #273]
	cmp	w8, #61
	cset	w10, eq
	cmp	w9, w10
	b.ne	LBB0_133
; %bb.58:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #15
	mov	w9, #151                        ; =0x97
	ccmp	w8, w9, #4, ne
	cset	w9, eq
	cmp	w8, #59
	mov	w10, #1                         ; =0x1
	csel	w9, w10, w9, eq
	cmp	w8, #145
	ldrb	w10, [sp, #275]
	csinc	w9, w9, wzr, ne
	cmp	w10, w9
	b.ne	LBB0_133
; %bb.59:                               ;   in Loop: Header=BB0_34 Depth=2
	cbz	w9, LBB0_70
; %bb.60:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w9, [sp, #300]
	ldr	w10, [sp, #352]
	cmp	w9, w10
	b.ne	LBB0_133
; %bb.61:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w1, [sp, #304]
	ldr	w9, [sp, #368]
	cmp	w1, w9
	b.ne	LBB0_133
; %bb.62:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #145
	cset	w9, ne
	ldr	w10, [sp, #296]
	cmp	w10, w9
	b.ne	LBB0_133
; %bb.63:                               ;   in Loop: Header=BB0_34 Depth=2
	cmp	w8, #145
	b.ne	LBB0_71
; %bb.64:                               ;   in Loop: Header=BB0_34 Depth=2
	add	x2, sp, #96
	mov	x0, x25
	bl	_nvm_file_hosted_import
	cbz	w0, LBB0_133
; %bb.65:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w0, [sp, #96]
	ldr	w8, [sp, #944]
	cmp	w0, w8
	b.ne	LBB0_133
; %bb.66:                               ;   in Loop: Header=BB0_34 Depth=2
	bl	_nl_file_catalog_method
	cbz	x0, LBB0_133
; %bb.67:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w8, [sp, #312]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_133
; %bb.68:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w8, [sp, #316]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_133
; %bb.69:                               ;   in Loop: Header=BB0_34 Depth=2
	mov	w8, #0                          ; =0x0
	ldr	w9, [sp, #96]
	subs	w10, w9, #1
	cmp	w10, #3
	mov	w10, #399                       ; =0x18f
	mov	w11, #415                       ; =0x19f
	csel	w10, w11, w10, lo
	orr	w11, w10, #0x20
	cmp	w9, #1
	csel	w9, w11, w10, eq
	b	LBB0_72
LBB0_70:                                ;   in Loop: Header=BB0_34 Depth=2
	mov	w8, #0                          ; =0x0
	mov	w9, #128                        ; =0x80
	b	LBB0_73
LBB0_71:                                ;   in Loop: Header=BB0_34 Depth=2
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
LBB0_72:                                ;   in Loop: Header=BB0_34 Depth=2
	ldr	w10, [sp, #308]
	cmp	w10, w9
	b.ne	LBB0_133
LBB0_73:                                ;   in Loop: Header=BB0_34 Depth=2
	ldr	w10, [sp, #288]
	cmp	w10, w8
	b.ne	LBB0_133
; %bb.74:                               ;   in Loop: Header=BB0_34 Depth=2
	ldr	w10, [sp, #292]
	bic	w8, w9, w8
	cmp	w10, w8
	b.eq	LBB0_33
	b	LBB0_133
LBB0_75:                                ;   in Loop: Header=BB0_30 Depth=1
	add	w26, w26, #1
	ldr	w8, [sp, #208]
	cmp	w26, w8
	b.lo	LBB0_30
LBB0_76:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
Lloh2:
	adrp	x8, l_.str.19@PAGE
Lloh3:
	add	x8, x8, l_.str.19@PAGEOFF
	str	x8, [sp]
Lloh4:
	adrp	x25, l_.str.18@PAGE
Lloh5:
	add	x25, x25, l_.str.18@PAGEOFF
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh6:
	adrp	x8, l_.str.20@PAGE
Lloh7:
	add	x8, x8, l_.str.20@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh8:
	adrp	x8, l_.str.28@PAGE
Lloh9:
	add	x8, x8, l_.str.28@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh10:
	adrp	x8, l_.str.29@PAGE
Lloh11:
	add	x8, x8, l_.str.29@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh12:
	adrp	x8, l_.str.27@PAGE
Lloh13:
	add	x8, x8, l_.str.27@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh14:
	adrp	x8, l_.str.30@PAGE
Lloh15:
	add	x8, x8, l_.str.30@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh16:
	adrp	x8, l_.str.31@PAGE
Lloh17:
	add	x8, x8, l_.str.31@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh18:
	adrp	x8, l_.str.32@PAGE
Lloh19:
	add	x8, x8, l_.str.32@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh20:
	adrp	x8, l_.str.33@PAGE
Lloh21:
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh22:
	adrp	x8, l_.str.34@PAGE
Lloh23:
	add	x8, x8, l_.str.34@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh24:
	adrp	x8, l_.str.35@PAGE
Lloh25:
	add	x8, x8, l_.str.35@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh26:
	adrp	x8, l_.str.36@PAGE
Lloh27:
	add	x8, x8, l_.str.36@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh28:
	adrp	x8, l_.str.37@PAGE
Lloh29:
	add	x8, x8, l_.str.37@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh30:
	adrp	x26, l_.str.38@PAGE
Lloh31:
	add	x26, x26, l_.str.38@PAGEOFF
	str	x26, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh32:
	adrp	x8, l_.str.39@PAGE
Lloh33:
	add	x8, x8, l_.str.39@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh34:
	adrp	x8, l_.str.40@PAGE
Lloh35:
	add	x8, x8, l_.str.40@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
	str	x26, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
Lloh36:
	adrp	x1, l_.str.5@PAGE
Lloh37:
	add	x1, x1, l_.str.5@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	mov	x26, #0                         ; =0x0
	mov	w27, #23                        ; =0x17
Lloh38:
	adrp	x28, l_.str.2@PAGE
Lloh39:
	add	x28, x28, l_.str.2@PAGEOFF
Lloh40:
	adrp	x25, l_.str.6@PAGE
Lloh41:
	add	x25, x25, l_.str.6@PAGEOFF
LBB0_77:                                ; =>This Inner Loop Header: Depth=1
	mov	x8, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x8, #43691
	umulh	x8, x26, x8
	lsr	x8, x8, #4
	mov	w9, #24                         ; =0x18
	madd	x8, x8, x9, x27
	ldrb	w9, [x24], #1
	cmp	x8, #0
Lloh42:
	adrp	x8, l_.str.7@PAGE
Lloh43:
	add	x8, x8, l_.str.7@PAGEOFF
	csel	x8, x8, x28, eq
	stp	x9, x8, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
	add	x26, x26, #1
	sub	x27, x27, #1
	sub	x23, x23, #1
	cbnz	x23, LBB0_77
; %bb.78:
Lloh44:
	adrp	x1, l_.str.8@PAGE
Lloh45:
	add	x1, x1, l_.str.8@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	ldr	x9, [sp, #192]
	ldp	w24, w23, [sp, #136]
	ldp	w27, w26, [sp, #144]
	ldp	x25, x28, [sp, #152]
	ldrh	w8, [sp, #168]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #172]
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #176]
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #184]
	stp	x8, x9, [sp, #80]               ; 16-byte Folded Spill
Lloh46:
	adrp	x1, l_.str.41@PAGE
Lloh47:
	add	x1, x1, l_.str.41@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
Lloh48:
	adrp	x8, l_.str.42@PAGE
Lloh49:
	add	x8, x8, l_.str.42@PAGEOFF
	stp	x8, x24, [sp]
Lloh50:
	adrp	x24, l_.str.118@PAGE
Lloh51:
	add	x24, x24, l_.str.118@PAGEOFF
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh52:
	adrp	x8, l_.str.43@PAGE
Lloh53:
	add	x8, x8, l_.str.43@PAGEOFF
	stp	x8, x23, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh54:
	adrp	x8, l_.str.44@PAGE
Lloh55:
	add	x8, x8, l_.str.44@PAGEOFF
	str	x27, [sp, #48]                  ; 8-byte Folded Spill
	stp	x8, x27, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh56:
	adrp	x8, l_.str.45@PAGE
Lloh57:
	add	x8, x8, l_.str.45@PAGEOFF
	stp	x8, x26, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh58:
	adrp	x8, l_.str.46@PAGE
Lloh59:
	add	x8, x8, l_.str.46@PAGEOFF
	stp	x8, x25, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh60:
	adrp	x8, l_.str.47@PAGE
Lloh61:
	add	x8, x8, l_.str.47@PAGEOFF
	stp	x8, x28, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh62:
	adrp	x8, l_.str.48@PAGE
Lloh63:
	add	x8, x8, l_.str.48@PAGEOFF
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh64:
	adrp	x8, l_.str.49@PAGE
Lloh65:
	add	x8, x8, l_.str.49@PAGEOFF
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh66:
	adrp	x8, l_.str.50@PAGE
Lloh67:
	add	x8, x8, l_.str.50@PAGEOFF
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
Lloh68:
	adrp	x8, l_.str.51@PAGE
Lloh69:
	add	x8, x8, l_.str.51@PAGEOFF
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	mov	w25, #0                         ; =0x0
Lloh70:
	adrp	x23, l_.str.55@PAGE
Lloh71:
	add	x23, x23, l_.str.55@PAGEOFF
Lloh72:
	adrp	x27, l_.str.56@PAGE
Lloh73:
	add	x27, x27, l_.str.56@PAGEOFF
Lloh74:
	adrp	x26, l_.str.57@PAGE
Lloh75:
	add	x26, x26, l_.str.57@PAGEOFF
Lloh76:
	adrp	x28, l_.str.58@PAGE
Lloh77:
	add	x28, x28, l_.str.58@PAGEOFF
LBB0_79:                                ; =>This Inner Loop Header: Depth=1
	add	x2, sp, #352
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x1, x25
	bl	_nvm_file_hosted_type
	tbz	w0, #0, LBB0_136
; %bb.80:                               ;   in Loop: Header=BB0_79 Depth=1
	str	x25, [sp]
	add	x0, sp, #96
Lloh78:
	adrp	x1, l_.str.52@PAGE
Lloh79:
	add	x1, x1, l_.str.52@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #352]
	str	x8, [sp, #8]
Lloh80:
	adrp	x8, l_.str.53@PAGE
Lloh81:
	add	x8, x8, l_.str.53@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	ldr	w8, [sp, #356]
	str	x8, [sp, #8]
Lloh82:
	adrp	x8, l_.str.54@PAGE
Lloh83:
	add	x8, x8, l_.str.54@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	ldr	w8, [sp, #360]
	stp	x23, x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	ldrb	w8, [sp, #364]
	stp	x27, x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	ldrb	w8, [sp, #365]
	stp	x26, x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	ldr	w8, [sp, #368]
	stp	x28, x8, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	add	w25, w25, #1
	cmp	w25, #8
	b.ne	LBB0_79
; %bb.81:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	cbz	w8, LBB0_122
; %bb.82:
	str	xzr, [sp, #80]                  ; 8-byte Folded Spill
	add	x8, sp, #352
	add	x25, x8, #72
	add	x28, x8, #48
	add	x9, x8, #16
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	add	x24, x8, #78
Lloh84:
	adrp	x26, l_.str.118@PAGE
Lloh85:
	add	x26, x26, l_.str.118@PAGEOFF
LBB0_83:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_86 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;       Child Loop BB0_94 Depth 3
                                        ;       Child Loop BB0_99 Depth 3
                                        ;       Child Loop BB0_117 Depth 3
	sub	x2, x29, #168
	ldp	x1, x0, [sp, #80]               ; 16-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_file_hosted_function
	tbz	w0, #0, LBB0_136
; %bb.84:                               ;   in Loop: Header=BB0_83 Depth=1
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	mov	x8, x23
	str	x8, [sp]
	add	x0, sp, #96
Lloh86:
	adrp	x1, l_.str.59@PAGE
Lloh87:
	add	x1, x1, l_.str.59@PAGEOFF
	bl	_fn_text
	ldur	w8, [x29, #-168]
	str	x8, [sp, #8]
Lloh88:
	adrp	x8, l_.str.60@PAGE
Lloh89:
	add	x8, x8, l_.str.60@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldur	w8, [x29, #-164]
	str	x8, [sp, #8]
Lloh90:
	adrp	x8, l_.str.61@PAGE
Lloh91:
	add	x8, x8, l_.str.61@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-160]
	str	x8, [sp, #8]
Lloh92:
	adrp	x8, l_.str.62@PAGE
Lloh93:
	add	x8, x8, l_.str.62@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-156]
	str	x8, [sp, #8]
Lloh94:
	adrp	x8, l_.str.63@PAGE
Lloh95:
	add	x8, x8, l_.str.63@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-154]
	str	x8, [sp, #8]
Lloh96:
	adrp	x8, l_.str.64@PAGE
Lloh97:
	add	x8, x8, l_.str.64@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurb	w8, [x29, #-152]
	str	x8, [sp, #8]
Lloh98:
	adrp	x8, l_.str.65@PAGE
Lloh99:
	add	x8, x8, l_.str.65@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	sub	x8, x29, #168
	ldur	x2, [x8, #20]
	ldur	x3, [x8, #28]
	add	x0, sp, #96
Lloh100:
	adrp	x1, l_.str.66@PAGE
Lloh101:
	add	x1, x1, l_.str.66@PAGEOFF
	bl	_fn_declaration
	ldurh	w8, [x29, #-132]
	str	x8, [sp, #8]
Lloh102:
	adrp	x8, l_.str.67@PAGE
Lloh103:
	add	x8, x8, l_.str.67@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-130]
	str	x8, [sp, #8]
Lloh104:
	adrp	x8, l_.str.68@PAGE
Lloh105:
	add	x8, x8, l_.str.68@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-128]
	str	x8, [sp, #8]
Lloh106:
	adrp	x8, l_.str.69@PAGE
Lloh107:
	add	x8, x8, l_.str.69@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-126]
	str	x8, [sp, #8]
Lloh108:
	adrp	x8, l_.str.70@PAGE
Lloh109:
	add	x8, x8, l_.str.70@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-124]
	str	x8, [sp, #8]
Lloh110:
	adrp	x8, l_.str.71@PAGE
Lloh111:
	add	x8, x8, l_.str.71@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldur	w8, [x29, #-120]
	str	x8, [sp, #8]
Lloh112:
	adrp	x8, l_.str.72@PAGE
Lloh113:
	add	x8, x8, l_.str.72@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldur	w8, [x29, #-116]
	str	x8, [sp, #8]
Lloh114:
	adrp	x8, l_.str.73@PAGE
Lloh115:
	add	x8, x8, l_.str.73@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldur	x9, [x29, #-112]
Lloh116:
	adrp	x8, l_.str.74@PAGE
Lloh117:
	add	x8, x8, l_.str.74@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldur	x9, [x29, #-104]
Lloh118:
	adrp	x8, l_.str.75@PAGE
Lloh119:
	add	x8, x8, l_.str.75@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldurh	w8, [x29, #-128]
	cbz	w8, LBB0_88
; %bb.85:                               ;   in Loop: Header=BB0_83 Depth=1
	mov	w27, #0                         ; =0x0
LBB0_86:                                ;   Parent Loop BB0_83 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #352
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x1, x23
	mov	x2, x27
	bl	_nvm_file_hosted_local
	tbz	w0, #0, LBB0_136
; %bb.87:                               ;   in Loop: Header=BB0_86 Depth=2
	stp	x23, x27, [sp]
	add	x0, sp, #96
Lloh120:
	adrp	x1, l_.str.76@PAGE
Lloh121:
	add	x1, x1, l_.str.76@PAGEOFF
	bl	_fn_text
	ldp	x2, x3, [sp, #352]
	add	x0, sp, #96
Lloh122:
	adrp	x1, l_.str.77@PAGE
Lloh123:
	add	x1, x1, l_.str.77@PAGEOFF
	bl	_fn_declaration
	add	w27, w27, #1
	ldurh	w8, [x29, #-128]
	cmp	w27, w8
	b.lo	LBB0_86
LBB0_88:                                ;   in Loop: Header=BB0_83 Depth=1
	ldurh	w8, [x29, #-160]
Lloh124:
	adrp	x27, l_.str.85@PAGE
Lloh125:
	add	x27, x27, l_.str.85@PAGEOFF
	cbz	w8, LBB0_121
; %bb.89:                               ;   in Loop: Header=BB0_83 Depth=1
	mov	w9, #0                          ; =0x0
	mov	x8, x23
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	b	LBB0_91
LBB0_90:                                ;   in Loop: Header=BB0_91 Depth=2
	ldp	x9, x23, [sp, #72]              ; 16-byte Folded Reload
	add	w9, w9, #1
	ldurh	w8, [x29, #-160]
	cmp	w9, w8
Lloh126:
	adrp	x27, l_.str.85@PAGE
Lloh127:
	add	x27, x27, l_.str.85@PAGEOFF
	b.hs	LBB0_121
LBB0_91:                                ;   Parent Loop BB0_83 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_94 Depth 3
                                        ;       Child Loop BB0_99 Depth 3
                                        ;       Child Loop BB0_117 Depth 3
	add	x3, sp, #352
	add	x4, sp, #272
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x1, x23
	mov	x23, x9
	mov	x2, x23
	bl	_nvm_file_hosted_instruction
	tbz	w0, #0, LBB0_136
; %bb.92:                               ;   in Loop: Header=BB0_91 Depth=2
	str	x23, [sp, #72]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	stp	x8, x23, [sp]
	add	x0, sp, #96
Lloh128:
	adrp	x1, l_.str.78@PAGE
Lloh129:
	add	x1, x1, l_.str.78@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #352]
	str	x8, [sp, #8]
Lloh130:
	adrp	x8, l_.str.79@PAGE
Lloh131:
	add	x8, x8, l_.str.79@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #360]
	str	x8, [sp, #8]
Lloh132:
	adrp	x8, l_.str.80@PAGE
Lloh133:
	add	x8, x8, l_.str.80@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #361]
	str	x8, [sp, #8]
Lloh134:
	adrp	x8, l_.str.81@PAGE
Lloh135:
	add	x8, x8, l_.str.81@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #416]
	str	x8, [sp, #8]
Lloh136:
	adrp	x8, l_.str.82@PAGE
Lloh137:
	add	x8, x8, l_.str.82@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #428]
	str	x8, [sp, #8]
Lloh138:
	adrp	x8, l_.str.83@PAGE
Lloh139:
	add	x8, x8, l_.str.83@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #944]
	str	x8, [sp, #8]
Lloh140:
	adrp	x8, l_.str.84@PAGE
Lloh141:
	add	x8, x8, l_.str.84@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #428]
	cbz	w8, LBB0_95
; %bb.93:                               ;   in Loop: Header=BB0_91 Depth=2
	mov	x23, #0                         ; =0x0
LBB0_94:                                ;   Parent Loop BB0_83 Depth=1
                                        ;     Parent Loop BB0_91 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x25, x23, lsl #1]
	stp	x23, x8, [sp]
	add	x0, sp, #96
	mov	x1, x27
	bl	_fn_text
	add	x23, x23, #1
	ldrb	w8, [sp, #428]
	cmp	x23, x8
	b.lo	LBB0_94
LBB0_95:                                ;   in Loop: Header=BB0_91 Depth=2
	ldrb	w8, [sp, #361]
	cbz	w8, LBB0_109
; %bb.96:                               ;   in Loop: Header=BB0_91 Depth=2
	mov	x27, #0                         ; =0x0
	ldr	x23, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB0_99
LBB0_97:                                ;   in Loop: Header=BB0_99 Depth=3
	ldrsw	x9, [x23]
Lloh142:
	adrp	x10, l_.str.89@PAGE
Lloh143:
	add	x10, x10, l_.str.89@PAGEOFF
LBB0_98:                                ;   in Loop: Header=BB0_99 Depth=3
	stp	x10, x9, [sp, #24]
	stp	x8, x27, [sp, #8]
	add	x0, sp, #96
	str	x27, [sp]
Lloh144:
	adrp	x1, l_.str.91@PAGE
Lloh145:
	add	x1, x1, l_.str.91@PAGEOFF
	bl	_fn_text
	add	x27, x27, #1
	ldrb	w8, [sp, #361]
	add	x23, x23, #8
	cmp	x27, x8
	b.hs	LBB0_109
LBB0_99:                                ;   Parent Loop BB0_83 Depth=1
                                        ;     Parent Loop BB0_91 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x28, x27, lsl #2]
	cmp	w8, #2
	b.le	LBB0_104
; %bb.100:                              ;   in Loop: Header=BB0_99 Depth=3
	cmp	w8, #3
	b.eq	LBB0_108
; %bb.101:                              ;   in Loop: Header=BB0_99 Depth=3
	cmp	w8, #4
	b.eq	LBB0_97
; %bb.102:                              ;   in Loop: Header=BB0_99 Depth=3
	cmp	w8, #5
	b.ne	LBB0_136
; %bb.103:                              ;   in Loop: Header=BB0_99 Depth=3
	ldr	x9, [x23]
Lloh146:
	adrp	x10, l_.str.90@PAGE
Lloh147:
	add	x10, x10, l_.str.90@PAGEOFF
	b	LBB0_98
LBB0_104:                               ;   in Loop: Header=BB0_99 Depth=3
	cmp	w8, #1
	b.eq	LBB0_107
; %bb.105:                              ;   in Loop: Header=BB0_99 Depth=3
	cmp	w8, #2
	b.ne	LBB0_136
; %bb.106:                              ;   in Loop: Header=BB0_99 Depth=3
	ldrh	w9, [x23]
Lloh148:
	adrp	x10, l_.str.87@PAGE
Lloh149:
	add	x10, x10, l_.str.87@PAGEOFF
	b	LBB0_98
LBB0_107:                               ;   in Loop: Header=BB0_99 Depth=3
	ldrb	w9, [x23]
Lloh150:
	adrp	x10, l_.str.86@PAGE
Lloh151:
	add	x10, x10, l_.str.86@PAGEOFF
	b	LBB0_98
LBB0_108:                               ;   in Loop: Header=BB0_99 Depth=3
	ldr	w9, [x23]
Lloh152:
	adrp	x10, l_.str.88@PAGE
Lloh153:
	add	x10, x10, l_.str.88@PAGEOFF
	b	LBB0_98
LBB0_109:                               ;   in Loop: Header=BB0_91 Depth=2
	ldrb	w8, [sp, #272]
	str	x8, [sp, #8]
Lloh154:
	adrp	x8, l_.str.92@PAGE
Lloh155:
	add	x8, x8, l_.str.92@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #273]
	str	x8, [sp, #8]
Lloh156:
	adrp	x8, l_.str.93@PAGE
Lloh157:
	add	x8, x8, l_.str.93@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #274]
	str	x8, [sp, #8]
Lloh158:
	adrp	x8, l_.str.94@PAGE
Lloh159:
	add	x8, x8, l_.str.94@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #275]
	str	x8, [sp, #8]
Lloh160:
	adrp	x8, l_.str.95@PAGE
Lloh161:
	add	x8, x8, l_.str.95@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #276]
	str	x8, [sp, #8]
Lloh162:
	adrp	x8, l_.str.96@PAGE
Lloh163:
	add	x8, x8, l_.str.96@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #278]
	str	x8, [sp, #8]
Lloh164:
	adrp	x8, l_.str.97@PAGE
Lloh165:
	add	x8, x8, l_.str.97@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #280]
	str	x8, [sp, #8]
Lloh166:
	adrp	x8, l_.str.98@PAGE
Lloh167:
	add	x8, x8, l_.str.98@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #284]
	str	x8, [sp, #8]
Lloh168:
	adrp	x8, l_.str.99@PAGE
Lloh169:
	add	x8, x8, l_.str.99@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #288]
	str	x8, [sp, #8]
Lloh170:
	adrp	x8, l_.str.100@PAGE
Lloh171:
	add	x8, x8, l_.str.100@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #292]
	str	x8, [sp, #8]
Lloh172:
	adrp	x8, l_.str.101@PAGE
Lloh173:
	add	x8, x8, l_.str.101@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #275]
	cmp	w8, #1
	b.ne	LBB0_111
; %bb.110:                              ;   in Loop: Header=BB0_91 Depth=2
	ldr	w8, [sp, #296]
	str	x8, [sp, #8]
Lloh174:
	adrp	x8, l_.str.102@PAGE
Lloh175:
	add	x8, x8, l_.str.102@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #300]
	str	x8, [sp, #8]
Lloh176:
	adrp	x8, l_.str.103@PAGE
Lloh177:
	add	x8, x8, l_.str.103@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #304]
	str	x8, [sp, #8]
Lloh178:
	adrp	x8, l_.str.104@PAGE
Lloh179:
	add	x8, x8, l_.str.104@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #308]
	str	x8, [sp, #8]
Lloh180:
	adrp	x8, l_.str.105@PAGE
Lloh181:
	add	x8, x8, l_.str.105@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #312]
	str	x8, [sp, #8]
Lloh182:
	adrp	x8, l_.str.106@PAGE
Lloh183:
	add	x8, x8, l_.str.106@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #316]
	str	x8, [sp, #8]
Lloh184:
	adrp	x8, l_.str.107@PAGE
Lloh185:
	add	x8, x8, l_.str.107@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #320]
	str	x8, [sp, #8]
Lloh186:
	adrp	x8, l_.str.108@PAGE
Lloh187:
	add	x8, x8, l_.str.108@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #322]
	str	x8, [sp, #8]
Lloh188:
	adrp	x8, l_.str.109@PAGE
Lloh189:
	add	x8, x8, l_.str.109@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrh	w8, [sp, #324]
	str	x8, [sp, #8]
Lloh190:
	adrp	x8, l_.str.110@PAGE
Lloh191:
	add	x8, x8, l_.str.110@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldrb	w8, [sp, #326]
	str	x8, [sp, #8]
Lloh192:
	adrp	x8, l_.str.111@PAGE
Lloh193:
	add	x8, x8, l_.str.111@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #344]
	str	x8, [sp, #8]
Lloh194:
	adrp	x8, l_.str.112@PAGE
Lloh195:
	add	x8, x8, l_.str.112@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldr	w8, [sp, #348]
	str	x8, [sp, #8]
Lloh196:
	adrp	x8, l_.str.113@PAGE
Lloh197:
	add	x8, x8, l_.str.113@PAGEOFF
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x26
	bl	_fn_text
	ldp	x2, x3, [sp, #328]
	add	x0, sp, #96
Lloh198:
	adrp	x1, l_.str.114@PAGE
Lloh199:
	add	x1, x1, l_.str.114@PAGEOFF
	bl	_fn_declaration
LBB0_111:                               ;   in Loop: Header=BB0_91 Depth=2
	ldrb	w8, [sp, #360]
	cmp	w8, #15
	b.eq	LBB0_114
; %bb.112:                              ;   in Loop: Header=BB0_91 Depth=2
	cmp	w8, #151
	b.eq	LBB0_114
; %bb.113:                              ;   in Loop: Header=BB0_91 Depth=2
	cmp	w8, #59
	b.ne	LBB0_119
LBB0_114:                               ;   in Loop: Header=BB0_91 Depth=2
	ldr	w1, [sp, #368]
	add	x2, sp, #200
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_nvm_file_hosted_function
	cbz	w0, LBB0_136
; %bb.115:                              ;   in Loop: Header=BB0_91 Depth=2
	ldrh	w8, [sp, #212]
Lloh200:
	adrp	x27, l_.str.115@PAGE
Lloh201:
	add	x27, x27, l_.str.115@PAGEOFF
	cbz	w8, LBB0_118
; %bb.116:                              ;   in Loop: Header=BB0_91 Depth=2
	mov	x23, #0                         ; =0x0
LBB0_117:                               ;   Parent Loop BB0_83 Depth=1
                                        ;     Parent Loop BB0_91 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x24, x23, lsl #1]
	stp	x23, x8, [sp]
	add	x0, sp, #96
	mov	x1, x27
	bl	_fn_text
	add	x23, x23, #1
	ldrh	w8, [sp, #212]
	cmp	x23, x8
	b.lo	LBB0_117
LBB0_118:                               ;   in Loop: Header=BB0_91 Depth=2
	ldrb	w8, [sp, #360]
LBB0_119:                               ;   in Loop: Header=BB0_91 Depth=2
	cmp	w8, #145
	b.ne	LBB0_90
; %bb.120:                              ;   in Loop: Header=BB0_91 Depth=2
	ldr	w8, [sp, #368]
	ldr	w9, [sp, #944]
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh202:
	adrp	x1, l_.str.116@PAGE
Lloh203:
	add	x1, x1, l_.str.116@PAGEOFF
	bl	_fn_text
	b	LBB0_90
LBB0_121:                               ;   in Loop: Header=BB0_83 Depth=1
	add	w23, w23, #1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x23, [sp, #80]                  ; 8-byte Folded Spill
	cmp	w23, w8
	b.ne	LBB0_83
LBB0_122:
Lloh204:
	adrp	x1, l_.str.117@PAGE
Lloh205:
	add	x1, x1, l_.str.117@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	b	LBB0_137
LBB0_123:
	mov	w25, #1                         ; =0x1
	cbz	x20, LBB0_127
; %bb.124:
	cbz	x19, LBB0_127
; %bb.125:
Lloh206:
	adrp	x2, l_.str@PAGE
Lloh207:
	add	x2, x2, l_.str@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
LBB0_126:
	mov	w25, #1                         ; =0x1
LBB0_127:
	bl	_nvm_file_host_leave
LBB0_128:
	mov	x0, x25
	add	sp, sp, #1040
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_129:
	cmp	w25, #2
	mov	w8, #1                          ; =0x1
	cinc	w25, w8, eq
LBB0_130:
	cbz	x19, LBB0_127
; %bb.131:
	mov	x8, x25
Lloh208:
	adrp	x9, l_.str.2@PAGE
Lloh209:
	add	x9, x9, l_.str.2@PAGEOFF
	stp	x9, x8, [sp]
Lloh210:
	adrp	x2, l_.str.1@PAGE
Lloh211:
	add	x2, x2, l_.str.1@PAGEOFF
LBB0_132:
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
	b	LBB0_127
LBB0_133:
	ldr	x0, [sp, #192]
	bl	_nvm_file_hosted_free
	cbz	x19, LBB0_135
; %bb.134:
Lloh212:
	adrp	x8, l_.str.2@PAGE
Lloh213:
	add	x8, x8, l_.str.2@PAGEOFF
	str	x8, [sp]
Lloh214:
	adrp	x2, l_.str.4@PAGE
Lloh215:
	add	x2, x2, l_.str.4@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
LBB0_135:
	mov	w25, #2                         ; =0x2
	b	LBB0_127
LBB0_136:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
LBB0_137:
	ldr	w8, [sp, #144]
	cbz	w8, LBB0_242
; %bb.138:
	mov	w24, #0                         ; =0x0
Lloh216:
	adrp	x23, l_.str.9@PAGE
Lloh217:
	add	x23, x23, l_.str.9@PAGEOFF
LBB0_139:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #96
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #144]
	cmp	w24, w8
	b.lo	LBB0_139
; %bb.140:
	cbz	w8, LBB0_242
; %bb.141:
	mov	w23, #0                         ; =0x0
Lloh218:
	adrp	x27, l_.str.128@PAGE
Lloh219:
	add	x27, x27, l_.str.128@PAGEOFF
Lloh220:
	adrp	x25, l_.str.126@PAGE
Lloh221:
	add	x25, x25, l_.str.126@PAGEOFF
	b	LBB0_144
LBB0_142:                               ;   in Loop: Header=BB0_144 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
LBB0_143:                               ;   in Loop: Header=BB0_144 Depth=1
	add	w23, w23, #1
	ldr	w8, [sp, #144]
	cmp	w23, w8
	b.hs	LBB0_242
LBB0_144:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_147 Depth 2
                                        ;     Child Loop BB0_153 Depth 2
	ldr	x26, [sp, #192]
	sub	x2, x29, #168
	mov	x0, x26
	mov	x1, x23
	bl	_nvm_file_hosted_function
	tbz	w0, #0, LBB0_142
; %bb.145:                              ;   in Loop: Header=BB0_144 Depth=1
	mov	x8, x23
	str	x8, [sp]
	add	x0, sp, #96
Lloh222:
	adrp	x1, l_.str.125@PAGE
Lloh223:
	add	x1, x1, l_.str.125@PAGEOFF
	bl	_fn_text
	ldurh	w8, [x29, #-160]
	cbz	w8, LBB0_148
; %bb.146:                              ;   in Loop: Header=BB0_144 Depth=1
	mov	w24, #0                         ; =0x0
LBB0_147:                               ;   Parent Loop BB0_144 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	x24, [sp]
	add	x0, sp, #96
	mov	x1, x25
	bl	_fn_text
	add	w24, w24, #1
	ldurh	w8, [x29, #-160]
	cmp	w24, w8
	b.lo	LBB0_147
LBB0_148:                               ;   in Loop: Header=BB0_144 Depth=1
	add	x0, sp, #96
Lloh224:
	adrp	x1, l_.str.127@PAGE
Lloh225:
	add	x1, x1, l_.str.127@PAGEOFF
	bl	_fn_text
	ldurh	w8, [x29, #-160]
	cbz	w8, LBB0_239
; %bb.149:                              ;   in Loop: Header=BB0_144 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB0_153
LBB0_150:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
LBB0_151:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	x27, x25
LBB0_152:                               ;   in Loop: Header=BB0_153 Depth=2
	add	w28, w28, #1
	ldurh	w8, [x29, #-160]
	cmp	w28, w8
	b.hs	LBB0_239
LBB0_153:                               ;   Parent Loop BB0_144 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #352
	add	x4, sp, #272
	mov	x0, x26
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_file_hosted_instruction
	cbz	w0, LBB0_240
; %bb.154:                              ;   in Loop: Header=BB0_153 Depth=2
	str	x28, [sp]
	add	x0, sp, #96
	mov	x1, x27
	bl	_fn_text
	ldrb	w8, [sp, #272]
	tbz	w8, #0, LBB0_160
; %bb.155:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	x25, x27
	ldrh	w8, [sp, #276]
	str	x8, [sp, #16]
	mov	x8, x28
	stp	x23, x8, [sp]
	add	x0, sp, #96
Lloh226:
	adrp	x1, l_.str.130@PAGE
Lloh227:
	add	x1, x1, l_.str.130@PAGEOFF
	bl	_fn_text
	ldrb	w24, [sp, #360]
	cmp	w24, #255
	b.eq	LBB0_205
; %bb.156:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w27, #1                         ; =0x1
Lloh228:
	adrp	x10, lJTI0_1@PAGE
Lloh229:
	add	x10, x10, lJTI0_1@PAGEOFF
	adr	x8, LBB0_157
	ldrh	w9, [x10, x24, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB0_157:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh230:
	adrp	x1, l_.str.148@PAGE
Lloh231:
	add	x1, x1, l_.str.148@PAGEOFF
	bl	_fn_text
	cmp	w24, #252
	b.eq	LBB0_159
; %bb.158:                              ;   in Loop: Header=BB0_153 Depth=2
	cmp	w24, #106
	b.ne	LBB0_187
LBB0_159:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #368]
	str	x8, [sp]
	add	x0, sp, #96
Lloh232:
	adrp	x1, l_.str.159@PAGE
Lloh233:
	add	x1, x1, l_.str.159@PAGEOFF
	b	LBB0_234
LBB0_160:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh234:
	adrp	x1, l_.str.129@PAGE
Lloh235:
	add	x1, x1, l_.str.129@PAGEOFF
LBB0_161:                               ;   in Loop: Header=BB0_153 Depth=2
	bl	_fn_text
	b	LBB0_152
LBB0_162:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrb	w8, [sp, #428]
	cmp	w8, #1
	b.ne	LBB0_150
; %bb.163:                              ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #424]
	ldr	w9, [sp, #368]
	stp	x9, x8, [sp]
	add	x0, sp, #96
Lloh236:
	adrp	x1, l_.str.161@PAGE
Lloh237:
	add	x1, x1, l_.str.161@PAGEOFF
	b	LBB0_237
LBB0_164:                               ;   in Loop: Header=BB0_153 Depth=2
	cmp	w24, #3
	mov	w8, #4                          ; =0x4
	csel	w8, w8, wzr, eq
	cmp	w24, #1
	csinc	w8, w8, wzr, ne
	b.ne	LBB0_184
; %bb.165:                              ;   in Loop: Header=BB0_153 Depth=2
	ldr	x9, [sp, #368]
	b	LBB0_210
LBB0_166:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh238:
	adrp	x1, l_.str.151@PAGE
Lloh239:
	add	x1, x1, l_.str.151@PAGEOFF
	bl	_fn_text
	cmp	w24, #161
	b.ne	LBB0_186
; %bb.167:                              ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh240:
	adrp	x1, l_.str.152@PAGE
Lloh241:
	add	x1, x1, l_.str.152@PAGEOFF
	b	LBB0_234
LBB0_168:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #384]
	ldrh	w9, [sp, #376]
	cmp	w24, #251
	csel	w24, w8, w9, eq
	ldrh	w9, [sp, #392]
	csel	w8, w9, w8, eq
	and	w27, w8, #0xffff
	cmp	w27, #8
	b.hs	LBB0_150
; %bb.169:                              ;   in Loop: Header=BB0_153 Depth=2
	cbz	w27, LBB0_211
; %bb.170:                              ;   in Loop: Header=BB0_153 Depth=2
	str	x27, [sp]
	add	x0, sp, #96
Lloh242:
	adrp	x1, l_.str.154@PAGE
Lloh243:
	add	x1, x1, l_.str.154@PAGEOFF
	bl	_fn_text
	stp	x27, xzr, [sp]
	add	x0, sp, #96
Lloh244:
	adrp	x1, l_.str.155@PAGE
Lloh245:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #1
	b.eq	LBB0_177
; %bb.171:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #1                          ; =0x1
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh246:
	adrp	x1, l_.str.155@PAGE
Lloh247:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #2
	b.eq	LBB0_177
; %bb.172:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #2                          ; =0x2
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh248:
	adrp	x1, l_.str.155@PAGE
Lloh249:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #3
	b.eq	LBB0_177
; %bb.173:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #3                          ; =0x3
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh250:
	adrp	x1, l_.str.155@PAGE
Lloh251:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #4
	b.eq	LBB0_177
; %bb.174:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #4                          ; =0x4
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh252:
	adrp	x1, l_.str.155@PAGE
Lloh253:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #5
	b.eq	LBB0_177
; %bb.175:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #5                          ; =0x5
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh254:
	adrp	x1, l_.str.155@PAGE
Lloh255:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #6
	b.eq	LBB0_177
; %bb.176:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w9, #6                          ; =0x6
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh256:
	adrp	x1, l_.str.155@PAGE
Lloh257:
	add	x1, x1, l_.str.155@PAGEOFF
	bl	_fn_text
LBB0_177:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh258:
	adrp	x1, l_.str.156@PAGE
Lloh259:
	add	x1, x1, l_.str.156@PAGEOFF
	b	LBB0_212
LBB0_178:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh260:
	adrp	x1, l_.str.139@PAGE
Lloh261:
	add	x1, x1, l_.str.139@PAGEOFF
	b	LBB0_234
LBB0_179:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh262:
	adrp	x1, l_.str.142@PAGE
Lloh263:
	add	x1, x1, l_.str.142@PAGEOFF
	b	LBB0_234
LBB0_180:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #368]
	cmp	w24, #11
	cset	w9, eq
Lloh264:
	adrp	x10, l_.str.138@PAGE
Lloh265:
	add	x10, x10, l_.str.138@PAGEOFF
Lloh266:
	adrp	x11, l_.str.137@PAGE
Lloh267:
	add	x11, x11, l_.str.137@PAGEOFF
	csel	x10, x11, x10, eq
	stp	x9, x10, [sp, #8]
	add	x0, sp, #96
	str	x8, [sp]
Lloh268:
	adrp	x1, l_.str.136@PAGE
Lloh269:
	add	x1, x1, l_.str.136@PAGEOFF
	b	LBB0_234
LBB0_181:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh270:
	adrp	x1, l_.str.133@PAGE
Lloh271:
	add	x1, x1, l_.str.133@PAGEOFF
	bl	_fn_text
	cmp	w24, #8
	b.ne	LBB0_183
; %bb.182:                              ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh272:
	adrp	x1, l_.str.134@PAGE
Lloh273:
	add	x1, x1, l_.str.134@PAGEOFF
	bl	_fn_text
LBB0_183:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh274:
	adrp	x1, l_.str.135@PAGE
Lloh275:
	add	x1, x1, l_.str.135@PAGEOFF
	b	LBB0_234
LBB0_184:                               ;   in Loop: Header=BB0_153 Depth=2
	cmp	w24, #3
	b.ne	LBB0_209
; %bb.185:                              ;   in Loop: Header=BB0_153 Depth=2
	ldrb	w9, [sp, #368]
	b	LBB0_210
LBB0_186:                               ;   in Loop: Header=BB0_153 Depth=2
	cmp	w24, #57
	cset	w8, eq
	str	x8, [sp]
	add	x0, sp, #96
Lloh276:
	adrp	x1, l_.str.153@PAGE
Lloh277:
	add	x1, x1, l_.str.153@PAGEOFF
	b	LBB0_201
LBB0_187:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh278:
	adrp	x1, l_.str.160@PAGE
Lloh279:
	add	x1, x1, l_.str.160@PAGEOFF
	b	LBB0_234
LBB0_188:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh280:
	adrp	x1, l_.str.141@PAGE
Lloh281:
	add	x1, x1, l_.str.141@PAGEOFF
	b	LBB0_234
LBB0_189:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #368]
	str	x8, [sp]
	add	x0, sp, #96
Lloh282:
	adrp	x1, l_.str.144@PAGE
Lloh283:
	add	x1, x1, l_.str.144@PAGEOFF
	b	LBB0_234
LBB0_190:                               ;   in Loop: Header=BB0_153 Depth=2
	ldr	w24, [sp, #944]
	subs	w8, w24, #1
	str	w8, [sp, #88]                   ; 4-byte Folded Spill
	cset	w27, eq
	add	x0, sp, #96
Lloh284:
	adrp	x1, l_.str.147@PAGE
Lloh285:
	add	x1, x1, l_.str.147@PAGEOFF
	bl	_fn_text
	cmp	w24, #4
	csinc	w27, w27, wzr, ne
	b.eq	LBB0_192
; %bb.191:                              ;   in Loop: Header=BB0_153 Depth=2
	cmp	w24, #1
	b.ne	LBB0_193
LBB0_192:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh286:
	adrp	x1, l_.str.148@PAGE
Lloh287:
	add	x1, x1, l_.str.148@PAGEOFF
	bl	_fn_text
LBB0_193:                               ;   in Loop: Header=BB0_153 Depth=2
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	cmp	w8, #2
	b.hi	LBB0_195
; %bb.194:                              ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #376]
	str	x8, [sp]
	add	x0, sp, #96
Lloh288:
	adrp	x1, l_.str.149@PAGE
Lloh289:
	add	x1, x1, l_.str.149@PAGEOFF
	bl	_fn_text
LBB0_195:                               ;   in Loop: Header=BB0_153 Depth=2
	ldr	w8, [sp, #368]
	stp	x8, x27, [sp]
	add	x0, sp, #96
Lloh290:
	adrp	x1, l_.str.150@PAGE
Lloh291:
	add	x1, x1, l_.str.150@PAGEOFF
	b	LBB0_234
LBB0_196:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh292:
	adrp	x1, l_.str.132@PAGE
Lloh293:
	add	x1, x1, l_.str.132@PAGEOFF
	b	LBB0_234
LBB0_197:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh294:
	adrp	x1, l_.str.143@PAGE
Lloh295:
	add	x1, x1, l_.str.143@PAGEOFF
	b	LBB0_234
LBB0_198:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh296:
	adrp	x1, l_.str.140@PAGE
Lloh297:
	add	x1, x1, l_.str.140@PAGEOFF
	b	LBB0_234
LBB0_199:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh298:
	adrp	x1, l_.str.162@PAGE
Lloh299:
	add	x1, x1, l_.str.162@PAGEOFF
	b	LBB0_237
LBB0_200:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #368]
	str	x8, [sp]
	add	x0, sp, #96
Lloh300:
	adrp	x1, l_.str.145@PAGE
Lloh301:
	add	x1, x1, l_.str.145@PAGEOFF
LBB0_201:                               ;   in Loop: Header=BB0_153 Depth=2
	bl	_fn_text
	ldrb	w8, [sp, #428]
	cmp	w8, #2
	mov	x27, x25
	b.ne	LBB0_203
; %bb.202:                              ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #426]
	ldrh	w9, [sp, #424]
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh302:
	adrp	x1, l_.str.163@PAGE
Lloh303:
	add	x1, x1, l_.str.163@PAGEOFF
	b	LBB0_161
LBB0_203:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
	b	LBB0_152
LBB0_204:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #368]
	ldrb	w9, [sp, #376]
	cmp	w9, #0
	mov	w9, #2                          ; =0x2
	cinc	x9, x9, ne
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh304:
	adrp	x1, l_.str.146@PAGE
Lloh305:
	add	x1, x1, l_.str.146@PAGEOFF
	b	LBB0_234
LBB0_205:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w27, #0                         ; =0x0
LBB0_206:                               ;   in Loop: Header=BB0_153 Depth=2
	and	w8, w24, #0xfe
	str	w8, [sp, #88]                   ; 4-byte Folded Spill
	cmp	w8, #48
	mov	w8, #50                         ; =0x32
	ccmp	w24, w8, #4, ne
	mov	w8, #4                          ; =0x4
	csinc	w8, w8, wzr, eq
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	sub	w8, w24, #32
	cmp	w8, #181
	b.hi	LBB0_238
; %bb.207:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh306:
	adrp	x11, lJTI0_2@PAGE
Lloh307:
	add	x11, x11, lJTI0_2@PAGEOFF
	adr	x9, LBB0_208
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
Lloh308:
	adrp	x8, l_.str.165@PAGE
Lloh309:
	add	x8, x8, l_.str.165@PAGEOFF
	br	x9
LBB0_208:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh310:
	adrp	x8, l_.str.166@PAGE
Lloh311:
	add	x8, x8, l_.str.166@PAGEOFF
	b	LBB0_226
LBB0_209:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	x9, #0                          ; =0x0
LBB0_210:                               ;   in Loop: Header=BB0_153 Depth=2
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh312:
	adrp	x1, l_.str.131@PAGE
Lloh313:
	add	x1, x1, l_.str.131@PAGEOFF
	b	LBB0_234
LBB0_211:                               ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh314:
	adrp	x1, l_.str.157@PAGE
Lloh315:
	add	x1, x1, l_.str.157@PAGEOFF
LBB0_212:                               ;   in Loop: Header=BB0_153 Depth=2
	bl	_fn_text
	ldr	w8, [sp, #944]
	and	x9, x24, #0xffff
	stp	x9, x27, [sp, #8]
	str	x8, [sp]
	add	x0, sp, #96
Lloh316:
	adrp	x1, l_.str.158@PAGE
Lloh317:
	add	x1, x1, l_.str.158@PAGEOFF
	b	LBB0_234
LBB0_213:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh318:
	adrp	x8, l_.str.176@PAGE
Lloh319:
	add	x8, x8, l_.str.176@PAGEOFF
	b	LBB0_226
LBB0_214:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh320:
	adrp	x8, l_.str.169@PAGE
Lloh321:
	add	x8, x8, l_.str.169@PAGEOFF
	b	LBB0_226
LBB0_215:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh322:
	adrp	x8, l_.str.170@PAGE
Lloh323:
	add	x8, x8, l_.str.170@PAGEOFF
	b	LBB0_226
LBB0_216:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh324:
	adrp	x8, l_.str.174@PAGE
Lloh325:
	add	x8, x8, l_.str.174@PAGEOFF
	b	LBB0_226
LBB0_217:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh326:
	adrp	x8, l_.str.167@PAGE
Lloh327:
	add	x8, x8, l_.str.167@PAGEOFF
	b	LBB0_226
LBB0_218:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh328:
	adrp	x8, l_.str.171@PAGE
Lloh329:
	add	x8, x8, l_.str.171@PAGEOFF
	b	LBB0_226
LBB0_219:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #1                         ; =0x1
Lloh330:
	adrp	x8, l_.str.168@PAGE
Lloh331:
	add	x8, x8, l_.str.168@PAGEOFF
	b	LBB0_226
LBB0_220:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh332:
	adrp	x8, l_.str.172@PAGE
Lloh333:
	add	x8, x8, l_.str.172@PAGEOFF
	b	LBB0_226
LBB0_221:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh334:
	adrp	x8, l_.str.173@PAGE
Lloh335:
	add	x8, x8, l_.str.173@PAGEOFF
	b	LBB0_226
LBB0_222:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh336:
	adrp	x8, l_.str.175@PAGE
Lloh337:
	add	x8, x8, l_.str.175@PAGEOFF
	b	LBB0_226
LBB0_223:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh338:
	adrp	x8, l_.str.177@PAGE
Lloh339:
	add	x8, x8, l_.str.177@PAGEOFF
	b	LBB0_226
LBB0_224:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh340:
	adrp	x8, l_.str.179@PAGE
Lloh341:
	add	x8, x8, l_.str.179@PAGEOFF
	b	LBB0_226
LBB0_225:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w12, #4                         ; =0x4
Lloh342:
	adrp	x8, l_.str.178@PAGE
Lloh343:
	add	x8, x8, l_.str.178@PAGEOFF
LBB0_226:                               ;   in Loop: Header=BB0_153 Depth=2
	stp	x8, x12, [sp, #64]              ; 16-byte Folded Spill
	cmp	w27, #0
	mov	w8, #1                          ; =0x1
	cinc	x24, x8, eq
	str	x24, [sp]
	add	x0, sp, #96
Lloh344:
	adrp	x1, l_.str.154@PAGE
Lloh345:
	add	x1, x1, l_.str.154@PAGEOFF
	bl	_fn_text
	stp	xzr, xzr, [sp, #16]
	add	x0, sp, #96
	stp	x24, xzr, [sp]
Lloh346:
	adrp	x1, l_.str.180@PAGE
Lloh347:
	add	x1, x1, l_.str.180@PAGEOFF
	bl	_fn_text
	tbnz	w27, #0, LBB0_228
; %bb.227:                              ;   in Loop: Header=BB0_153 Depth=2
	mov	w8, #1                          ; =0x1
	stp	x8, x8, [sp, #16]
	add	x0, sp, #96
	stp	x8, x8, [sp]
Lloh348:
	adrp	x1, l_.str.180@PAGE
Lloh349:
	add	x1, x1, l_.str.180@PAGEOFF
	bl	_fn_text
LBB0_228:                               ;   in Loop: Header=BB0_153 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #96
Lloh350:
	adrp	x1, l_.str.181@PAGE
Lloh351:
	add	x1, x1, l_.str.181@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	cmp	w8, #40
Lloh352:
	adrp	x24, l_.str.183@PAGE
Lloh353:
	add	x24, x24, l_.str.183@PAGEOFF
	b.ne	LBB0_230
; %bb.229:                              ;   in Loop: Header=BB0_153 Depth=2
	add	x0, sp, #96
Lloh354:
	adrp	x1, l_.str.182@PAGE
Lloh355:
	add	x1, x1, l_.str.182@PAGEOFF
	bl	_fn_text
LBB0_230:                               ;   in Loop: Header=BB0_153 Depth=2
	str	xzr, [sp]
	add	x0, sp, #96
	mov	x1, x24
	bl	_fn_text
	tbz	w27, #0, LBB0_232
; %bb.231:                              ;   in Loop: Header=BB0_153 Depth=2
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
Lloh356:
	adrp	x8, l_.str.185@PAGE
Lloh357:
	add	x8, x8, l_.str.185@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh358:
	adrp	x1, l_.str.184@PAGE
Lloh359:
	add	x1, x1, l_.str.184@PAGEOFF
	bl	_fn_text
	mov	w8, #0                          ; =0x0
Lloh360:
	adrp	x27, l_.str.187@PAGE
Lloh361:
	add	x27, x27, l_.str.187@PAGEOFF
	b	LBB0_233
LBB0_232:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	x1, x24
	mov	w24, #1                         ; =0x1
	str	x24, [sp]
	add	x0, sp, #96
	bl	_fn_text
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
Lloh362:
	adrp	x8, l_.str.186@PAGE
Lloh363:
	add	x8, x8, l_.str.186@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #96
Lloh364:
	adrp	x1, l_.str.184@PAGE
Lloh365:
	add	x1, x1, l_.str.184@PAGEOFF
	bl	_fn_text
	str	xzr, [sp]
	add	x0, sp, #96
Lloh366:
	adrp	x27, l_.str.187@PAGE
Lloh367:
	add	x27, x27, l_.str.187@PAGEOFF
	mov	x1, x27
	bl	_fn_text
	mov	x8, x24
LBB0_233:                               ;   in Loop: Header=BB0_153 Depth=2
	str	x8, [sp]
	add	x0, sp, #96
	mov	x1, x27
	bl	_fn_text
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #96
Lloh368:
	adrp	x1, l_.str.188@PAGE
Lloh369:
	add	x1, x1, l_.str.188@PAGEOFF
LBB0_234:                               ;   in Loop: Header=BB0_153 Depth=2
	bl	_fn_text
LBB0_235:                               ;   in Loop: Header=BB0_153 Depth=2
	ldrb	w8, [sp, #428]
	cmp	w8, #1
	b.ne	LBB0_150
; %bb.236:                              ;   in Loop: Header=BB0_153 Depth=2
	ldrh	w8, [sp, #424]
	str	x8, [sp]
	add	x0, sp, #96
Lloh370:
	adrp	x1, l_.str.164@PAGE
Lloh371:
	add	x1, x1, l_.str.164@PAGEOFF
LBB0_237:                               ;   in Loop: Header=BB0_153 Depth=2
	bl	_fn_text
	b	LBB0_151
LBB0_238:                               ;   in Loop: Header=BB0_153 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
	b	LBB0_235
LBB0_239:                               ;   in Loop: Header=BB0_144 Depth=1
	add	x0, sp, #96
Lloh372:
	adrp	x1, l_.str.38@PAGE
Lloh373:
	add	x1, x1, l_.str.38@PAGEOFF
	bl	_fn_text
	b	LBB0_241
LBB0_240:                               ;   in Loop: Header=BB0_144 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #120]
LBB0_241:                               ;   in Loop: Header=BB0_144 Depth=1
Lloh374:
	adrp	x25, l_.str.126@PAGE
Lloh375:
	add	x25, x25, l_.str.126@PAGEOFF
	b	LBB0_143
LBB0_242:
Lloh376:
	adrp	x1, l_.str.10@PAGE
Lloh377:
	add	x1, x1, l_.str.10@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
Lloh378:
	adrp	x1, l_.str.12@PAGE
Lloh379:
	add	x1, x1, l_.str.12@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	ldr	w8, [sp, #144]
	cbz	w8, LBB0_245
; %bb.243:
	mov	w24, #0                         ; =0x0
Lloh380:
	adrp	x23, l_.str.13@PAGE
Lloh381:
	add	x23, x23, l_.str.13@PAGEOFF
LBB0_244:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #96
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #144]
	cmp	w24, w8
	b.lo	LBB0_244
LBB0_245:
	ldr	w8, [sp, #140]
	cmn	w8, #1
	b.eq	LBB0_247
; %bb.246:
	str	x8, [sp]
Lloh382:
	adrp	x1, l_.str.14@PAGE
Lloh383:
	add	x1, x1, l_.str.14@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
LBB0_247:
	ldr	w8, [sp, #136]
	stp	x8, x8, [sp]
Lloh384:
	adrp	x1, l_.str.15@PAGE
Lloh385:
	add	x1, x1, l_.str.15@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	str	x22, [sp]
Lloh386:
	adrp	x1, l_.str.16@PAGE
Lloh387:
	add	x1, x1, l_.str.16@PAGEOFF
	add	x0, sp, #96
	bl	_fn_text
	ldr	x0, [sp, #192]
	bl	_nvm_file_hosted_free
	ldr	w25, [sp, #120]
	ldr	x0, [sp, #96]
	cbz	w25, LBB0_250
; %bb.248:
	bl	_free
	cbz	x19, LBB0_127
; %bb.249:
Lloh388:
	adrp	x8, l_.str.2@PAGE
Lloh389:
	add	x8, x8, l_.str.2@PAGEOFF
	stp	x8, x25, [sp]
Lloh390:
	adrp	x2, l_.str.17@PAGE
Lloh391:
	add	x2, x2, l_.str.17@PAGEOFF
	b	LBB0_132
LBB0_250:
	str	x0, [x21]
	cbz	x19, LBB0_127
; %bb.251:
	strb	wzr, [x20]
	b	LBB0_127
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh110, Lloh111
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpAdd	Lloh326, Lloh327
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh336, Lloh337
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpAdd	Lloh352, Lloh353
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh354, Lloh355
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh366, Lloh367
	.loh AdrpAdd	Lloh364, Lloh365
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh372, Lloh373
	.loh AdrpAdd	Lloh374, Lloh375
	.loh AdrpAdd	Lloh378, Lloh379
	.loh AdrpAdd	Lloh376, Lloh377
	.loh AdrpAdd	Lloh380, Lloh381
	.loh AdrpAdd	Lloh382, Lloh383
	.loh AdrpAdd	Lloh386, Lloh387
	.loh AdrpAdd	Lloh384, Lloh385
	.loh AdrpAdd	Lloh390, Lloh391
	.loh AdrpAdd	Lloh388, Lloh389
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.short	(LBB0_133-LBB0_37)>>2
	.short	(LBB0_37-LBB0_37)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_235-LBB0_157)>>2
	.short	(LBB0_164-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_164-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_164-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_196-LBB0_157)>>2
	.short	(LBB0_181-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_180-LBB0_157)>>2
	.short	(LBB0_178-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_162-LBB0_157)>>2
	.short	(LBB0_180-LBB0_157)>>2
	.short	(LBB0_178-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_198-LBB0_157)>>2
	.short	(LBB0_188-LBB0_157)>>2
	.short	(LBB0_179-LBB0_157)>>2
	.short	(LBB0_179-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_206-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_206-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_235-LBB0_157)>>2
	.short	(LBB0_166-LBB0_157)>>2
	.short	(LBB0_166-LBB0_157)>>2
	.short	(LBB0_162-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_199-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_168-LBB0_157)>>2
	.short	(LBB0_157-LBB0_157)>>2
	.short	(LBB0_157-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_190-LBB0_157)>>2
	.short	(LBB0_200-LBB0_157)>>2
	.short	(LBB0_204-LBB0_157)>>2
	.short	(LBB0_189-LBB0_157)>>2
	.short	(LBB0_181-LBB0_157)>>2
	.short	(LBB0_197-LBB0_157)>>2
	.short	(LBB0_162-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_166-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_206-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_168-LBB0_157)>>2
	.short	(LBB0_157-LBB0_157)>>2
	.short	(LBB0_205-LBB0_157)>>2
	.short	(LBB0_157-LBB0_157)>>2
lJTI0_2:
	.byte	(LBB0_226-LBB0_208)>>2
	.byte	(LBB0_208-LBB0_208)>>2
	.byte	(LBB0_217-LBB0_208)>>2
	.byte	(LBB0_219-LBB0_208)>>2
	.byte	(LBB0_214-LBB0_208)>>2
	.byte	(LBB0_215-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_218-LBB0_208)>>2
	.byte	(LBB0_220-LBB0_208)>>2
	.byte	(LBB0_221-LBB0_208)>>2
	.byte	(LBB0_216-LBB0_208)>>2
	.byte	(LBB0_222-LBB0_208)>>2
	.byte	(LBB0_213-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_223-LBB0_208)>>2
	.byte	(LBB0_225-LBB0_208)>>2
	.byte	(LBB0_224-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_226-LBB0_208)>>2
	.byte	(LBB0_208-LBB0_208)>>2
	.byte	(LBB0_217-LBB0_208)>>2
	.byte	(LBB0_219-LBB0_208)>>2
	.byte	(LBB0_214-LBB0_208)>>2
	.byte	(LBB0_215-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_238-LBB0_208)>>2
	.byte	(LBB0_218-LBB0_208)>>2
	.byte	(LBB0_220-LBB0_208)>>2
	.byte	(LBB0_221-LBB0_208)>>2
	.byte	(LBB0_216-LBB0_208)>>2
	.byte	(LBB0_222-LBB0_208)>>2
	.byte	(LBB0_213-LBB0_208)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fn_text
_fn_text:                               ; @fn_text
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cbz	w8, LBB1_2
; %bb.1:
	ret
LBB1_2:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	add	x8, x29, #16
	stp	x8, x8, [sp]
	add	x3, x29, #16
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, x20
	bl	_vsnprintf
	tbnz	w0, #31, LBB1_17
; %bb.3:
	lsr	w8, w0, #27
	cbnz	w8, LBB1_5
; %bb.4:
	mov	w22, w0
	ldr	x8, [x19, #8]
	mov	w9, #134217727                  ; =0x7ffffff
	sub	x9, x9, x22
	cmp	x8, x9
	b.ls	LBB1_6
LBB1_5:
	mov	w8, #3                          ; =0x3
	b	LBB1_18
LBB1_6:
	ldr	x21, [x19, #16]
	add	x9, x8, x22
	cmp	x9, x21
	b.hs	LBB1_8
; %bb.7:
	mov	x23, x0
	ldr	x0, [x19]
	b	LBB1_15
LBB1_8:
	mov	w8, #4096                       ; =0x1000
	cmp	x21, #0
	csel	x21, x8, x21, eq
	cmp	x21, x9
	b.hi	LBB1_13
; %bb.9:
	mov	w8, #67108864                   ; =0x4000000
LBB1_10:                                ; =>This Inner Loop Header: Depth=1
	cmp	x21, x8
	b.hi	LBB1_12
; %bb.11:                               ;   in Loop: Header=BB1_10 Depth=1
	lsl	x21, x21, #1
	cmp	x21, x9
	b.ls	LBB1_10
	b	LBB1_13
LBB1_12:
	mov	w21, #134217728                 ; =0x8000000
LBB1_13:
	mov	x23, x0
	ldr	x0, [x19]
	mov	x1, x21
	bl	_realloc
	cbz	x0, LBB1_20
; %bb.14:
	str	x0, [x19]
	str	x21, [x19, #16]
	ldr	x8, [x19, #8]
LBB1_15:
	sub	x1, x21, x8
	ldr	x3, [sp, #8]
	add	x0, x0, x8
	mov	x2, x20
	bl	_vsnprintf
	cmp	w0, w23
	b.ne	LBB1_17
; %bb.16:
	ldr	x8, [x19, #8]
	add	x8, x8, x22
	str	x8, [x19, #8]
	b	LBB1_19
LBB1_17:
	mov	w8, #1                          ; =0x1
LBB1_18:
	str	w8, [x19, #24]
LBB1_19:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB1_20:
	mov	w8, #4                          ; =0x4
	b	LBB1_18
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_declaration
_fn_declaration:                        ; @fn_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x3
	mov	x24, x2
	mov	x20, x1
	mov	x19, x0
Lloh392:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh393:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh394:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	lsr	x27, x2, #32
	lsr	x25, x3, #32
Lloh395:
	adrp	x8, l_.str.120@PAGE
Lloh396:
	add	x8, x8, l_.str.120@PAGEOFF
	stp	x1, x8, [sp]
Lloh397:
	adrp	x21, l_.str.119@PAGE
Lloh398:
	add	x21, x21, l_.str.119@PAGEOFF
	add	x26, sp, #24
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	and	x8, x24, #0xff
	stp	x26, x8, [sp]
Lloh399:
	adrp	x23, l_.str.118@PAGE
Lloh400:
	add	x23, x23, l_.str.118@PAGEOFF
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh401:
	adrp	x8, l_.str.121@PAGE
Lloh402:
	add	x8, x8, l_.str.121@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	ubfx	x8, x24, #8, #8
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh403:
	adrp	x8, l_.str.122@PAGE
Lloh404:
	add	x8, x8, l_.str.122@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x27, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh405:
	adrp	x8, l_.str.123@PAGE
Lloh406:
	add	x8, x8, l_.str.123@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	mov	w8, w22
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh407:
	adrp	x8, l_.str.124@PAGE
Lloh408:
	add	x8, x8, l_.str.124@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x25, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldur	x8, [x29, #-88]
Lloh409:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh410:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh411:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_2
; %bb.1:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB2_2:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh409, Lloh410, Lloh411
	.loh AdrpAdd	Lloh407, Lloh408
	.loh AdrpAdd	Lloh405, Lloh406
	.loh AdrpAdd	Lloh403, Lloh404
	.loh AdrpAdd	Lloh401, Lloh402
	.loh AdrpAdd	Lloh399, Lloh400
	.loh AdrpAdd	Lloh397, Lloh398
	.loh AdrpAdd	Lloh395, Lloh396
	.loh AdrpLdrGotLdr	Lloh392, Lloh393, Lloh394
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require exact File bytes and a valid entry identifier"

l_.str.1:                               ; @.str.1
	.asciz	"I refuse %sFile native preparation (%u)"

l_.str.2:                               ; @.str.2
	.space	1

l_.str.4:                               ; @.str.4
	.asciz	"I lack complete %sFile native instruction coverage"

l_.str.5:                               ; @.str.5
	.asciz	"static const uint8_t nf_module[]={\n"

l_.str.6:                               ; @.str.6
	.asciz	"%u,%s"

l_.str.7:                               ; @.str.7
	.asciz	"\n"

l_.str.8:                               ; @.str.8
	.asciz	"\n};\n"

l_.str.9:                               ; @.str.9
	.asciz	"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *,uint64_t *);\n"

l_.str.10:                              ; @.str.10
	.asciz	"static NvmFileRuntimeReport nf_execute(NvmFileRuntimeView *out){\n"

l_.str.12:                              ; @.str.12
	.asciz	"if(!out)return nf_refused(NVM_FILE_RUNTIME_INVALID);\nif(!nvm_file_runtime_native_abi(1u,sizeof(NvmFileRuntimeView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeReport)))return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED);\nNvmFileRuntime *c=NULL;uint64_t steps=0;uint32_t root;\nNvmFileRuntimeStatus status=nvm_file_runtime_create(nf_module,sizeof nf_module,NVM_FILE_RUNTIME_NATIVE,&c);\nif(status!=NVM_FILE_RUNTIME_OK)return nf_refused(status);\nif(!nf_agrees(nvm_file_runtime_plan(c))){(void)nvm_file_runtime_destroy(&c,NULL);return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED);}\nstatus=nvm_file_runtime_begin(c);\n(void)nf_bits;(void)nf_scalar;\n"

l_.str.13:                              ; @.str.13
	.asciz	"(void)nf_function_%u;\n"

l_.str.14:                              ; @.str.14
	.asciz	"if(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c,&steps);\n"

l_.str.15:                              ; @.str.15
	.asciz	"if(status==NVM_FILE_RUNTIME_OK && (!nvm_file_runtime_current_root(c,&root) || root!=%u))status=nf_bad(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c,&steps);\nif(status==NVM_FILE_RUNTIME_OK && nvm_file_runtime_current_root(c,&root))status=nf_bad(c);\nif(status!=NVM_FILE_RUNTIME_OK)(void)nvm_file_runtime_fail(c,status);\nreturn nvm_file_runtime_destroy(&c,out);\n}\n#undef NF_TRY\n"

l_.str.16:                              ; @.str.16
	.asciz	"NvmFileRuntimeReport nvm_file_program_%s(NvmFileHostGrant *grant,NvmFileScalar *out){\nNvmFileHostStatus entered=nvm_file_host_enter(grant,NVM_FILE_HOST_ABI,NVM_FILE_HOST_CATALOG);\nif(entered!=NVM_FILE_HOST_OK)return nvm_file_public_refused(nvm_file_public_grant_status(entered));\nNvmFileRuntimeView view={0};NvmFileRuntimeReport report;\nif(!out)report=nvm_file_public_refused(NVM_FILE_RUNTIME_INVALID);\nelse{report=nf_execute(&view);report=nvm_file_public_publish(report,&view,out);}\nnvm_file_host_leave();return report;\n}\n"

l_.str.17:                              ; @.str.17
	.asciz	"I refuse %sFile native emission (%u)"

l_.str.18:                              ; @.str.18
	.asciz	"%s"

l_.str.19:                              ; @.str.19
	.asciz	"#include <nanolang/file/nanoisa/file_native_public.h>\n"

l_.str.20:                              ; @.str.20
	.asciz	"#include <limits.h>\n#include <string.h>\n"

l_.str.27:                              ; @.str.27
	.asciz	"#endif\n"

l_.str.28:                              ; @.str.28
	.asciz	"#if NVM_FILE_NATIVE_ABI != 1u\n"

l_.str.29:                              ; @.str.29
	.asciz	"#error I require the qualified File native semantic ABI revision\n"

l_.str.30:                              ; @.str.30
	.asciz	"#define NF_TRY(expr) do { NvmFileRuntimeStatus nf_status_=(expr); if(nf_status_!=NVM_FILE_RUNTIME_OK)return nf_status_; } while(0)\n"

l_.str.31:                              ; @.str.31
	.asciz	"static NvmFileRuntimeStatus nf_bad(NvmFileRuntime *c){return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_STATE);}\n"

l_.str.32:                              ; @.str.32
	.asciz	"static int64_t nf_bits(uint64_t x){int64_t y;memcpy(&y,&x,sizeof y);return y;}\n"

l_.str.33:                              ; @.str.33
	.asciz	"static bool nf_scalar(const NvmFileRuntimeView *v,uint8_t tag){\n"

l_.str.34:                              ; @.str.34
	.asciz	" return v->initialized && !v->owning && !v->formal && !v->type.mode &&\n"

l_.str.35:                              ; @.str.35
	.asciz	" v->type.category==NVM_FILE_CATEGORY_UNKNOWN && v->type.tag==tag &&\n"

l_.str.36:                              ; @.str.36
	.asciz	" v->type.global_index==NVM_V2_NO_INDEX && v->type.catalog_ordinal==NVM_V2_NO_INDEX &&\n"

l_.str.37:                              ; @.str.37
	.asciz	" v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);\n"

l_.str.38:                              ; @.str.38
	.asciz	"}\n"

l_.str.39:                              ; @.str.39
	.asciz	"static NvmFileRuntimeReport nf_refused(NvmFileRuntimeStatus status){\n"

l_.str.40:                              ; @.str.40
	.asciz	" NvmFileRuntimeReport r={0};r.status=status;r.function=r.instruction=NVM_V2_NO_INDEX;return r;\n"

l_.str.41:                              ; @.str.41
	.asciz	"static bool nf_agrees(const NvmFileHostedPlan *p){\nNvmFileHostedStartup s; NvmFileHostedFunction f; NvmFileFlowDeclaration l;\nNvmFileCodeInstruction in; NvmFileBodyInstruction fact; NvmFileNominalLayout t;\nuint32_t ordinal; (void)l;(void)ordinal;\nif(!nvm_file_hosted_startup(p,&s))return false;\n"

l_.str.42:                              ; @.str.42
	.asciz	"s.entry"

l_.str.43:                              ; @.str.43
	.asciz	"s.initializer"

l_.str.44:                              ; @.str.44
	.asciz	"s.functions"

l_.str.45:                              ; @.str.45
	.asciz	"s.features"

l_.str.46:                              ; @.str.46
	.asciz	"s.vm_value_slots"

l_.str.47:                              ; @.str.47
	.asciz	"s.native_value_slots"

l_.str.48:                              ; @.str.48
	.asciz	"s.frames"

l_.str.49:                              ; @.str.49
	.asciz	"s.reference_slots"

l_.str.50:                              ; @.str.50
	.asciz	"s.region_slots"

l_.str.51:                              ; @.str.51
	.asciz	"s.allocation_bound"

l_.str.52:                              ; @.str.52
	.asciz	"if(!nvm_file_hosted_type(p,%u,&t))return false;\n"

l_.str.53:                              ; @.str.53
	.asciz	"t.global_index"

l_.str.54:                              ; @.str.54
	.asciz	"t.catalog_ordinal"

l_.str.55:                              ; @.str.55
	.asciz	"t.source_ordinal"

l_.str.56:                              ; @.str.56
	.asciz	"t.layout_kind"

l_.str.57:                              ; @.str.57
	.asciz	"t.ownership_flags"

l_.str.58:                              ; @.str.58
	.asciz	"t.category"

l_.str.59:                              ; @.str.59
	.asciz	"if(!nvm_file_hosted_function(p,%u,&f))return false;\n"

l_.str.60:                              ; @.str.60
	.asciz	"f.code.code_offset"

l_.str.61:                              ; @.str.61
	.asciz	"f.code.code_length"

l_.str.62:                              ; @.str.62
	.asciz	"f.code.instruction_count"

l_.str.63:                              ; @.str.63
	.asciz	"f.code.declaration.parameters"

l_.str.64:                              ; @.str.64
	.asciz	"f.code.declaration.locals"

l_.str.65:                              ; @.str.65
	.asciz	"f.code.declaration.result_count"

l_.str.66:                              ; @.str.66
	.asciz	"f.code.declaration.result."

l_.str.67:                              ; @.str.67
	.asciz	"f.declared_stack"

l_.str.68:                              ; @.str.68
	.asciz	"f.operand_peak"

l_.str.69:                              ; @.str.69
	.asciz	"f.locals"

l_.str.70:                              ; @.str.70
	.asciz	"f.staging_slots"

l_.str.71:                              ; @.str.71
	.asciz	"f.frames"

l_.str.72:                              ; @.str.72
	.asciz	"f.reference_slots"

l_.str.73:                              ; @.str.73
	.asciz	"f.region_slots"

l_.str.74:                              ; @.str.74
	.asciz	"f.vm_value_slots"

l_.str.75:                              ; @.str.75
	.asciz	"f.native_value_slots"

l_.str.76:                              ; @.str.76
	.asciz	"if(!nvm_file_hosted_local(p,%u,%u,&l))return false;\n"

l_.str.77:                              ; @.str.77
	.asciz	"l."

l_.str.78:                              ; @.str.78
	.asciz	"if(!nvm_file_hosted_instruction(p,%u,%u,&in,&fact))return false;\n"

l_.str.79:                              ; @.str.79
	.asciz	"in.byte_offset"

l_.str.80:                              ; @.str.80
	.asciz	"in.decoded.opcode"

l_.str.81:                              ; @.str.81
	.asciz	"in.decoded.operand_count"

l_.str.82:                              ; @.str.82
	.asciz	"in.decoded.byte_length"

l_.str.83:                              ; @.str.83
	.asciz	"in.successor_count"

l_.str.84:                              ; @.str.84
	.asciz	"in.catalog_ordinal"

l_.str.85:                              ; @.str.85
	.asciz	"if(in.successors[%u]!=%u)return false;\n"

l_.str.86:                              ; @.str.86
	.asciz	"u8"

l_.str.87:                              ; @.str.87
	.asciz	"u16"

l_.str.88:                              ; @.str.88
	.asciz	"u32"

l_.str.89:                              ; @.str.89
	.asciz	"i32"

l_.str.90:                              ; @.str.90
	.asciz	"i64"

l_.str.91:                              ; @.str.91
	.asciz	"if(in.decoded.operand_types[%u]!=%u || (uint64_t)in.decoded.operands[%u].%s!=UINT64_C(%llu))return false;\n"

l_.str.92:                              ; @.str.92
	.asciz	"fact.reachable"

l_.str.93:                              ; @.str.93
	.asciz	"fact.exit_checked"

l_.str.94:                              ; @.str.94
	.asciz	"fact.refinement"

l_.str.95:                              ; @.str.95
	.asciz	"fact.has_obligation"

l_.str.96:                              ; @.str.96
	.asciz	"fact.input_stack"

l_.str.97:                              ; @.str.97
	.asciz	"fact.output_stack"

l_.str.98:                              ; @.str.98
	.asciz	"fact.cleanup_local"

l_.str.99:                              ; @.str.99
	.asciz	"fact.cleanup"

l_.str.100:                             ; @.str.100
	.asciz	"fact.discharged_checks"

l_.str.101:                             ; @.str.101
	.asciz	"fact.pending_checks"

l_.str.102:                             ; @.str.102
	.asciz	"fact.obligation.kind"

l_.str.103:                             ; @.str.103
	.asciz	"fact.obligation.site"

l_.str.104:                             ; @.str.104
	.asciz	"fact.obligation.target"

l_.str.105:                             ; @.str.105
	.asciz	"fact.obligation.checks"

l_.str.106:                             ; @.str.106
	.asciz	"fact.obligation.required_rights"

l_.str.107:                             ; @.str.107
	.asciz	"fact.obligation.acquired_rights"

l_.str.108:                             ; @.str.108
	.asciz	"fact.obligation.parameters"

l_.str.109:                             ; @.str.109
	.asciz	"fact.obligation.owned_inputs"

l_.str.110:                             ; @.str.110
	.asciz	"fact.obligation.borrowed_inputs"

l_.str.111:                             ; @.str.111
	.asciz	"fact.obligation.result_count"

l_.str.112:                             ; @.str.112
	.asciz	"fact.obligation.outcomes[0]"

l_.str.113:                             ; @.str.113
	.asciz	"fact.obligation.outcomes[1]"

l_.str.114:                             ; @.str.114
	.asciz	"fact.obligation.result."

l_.str.115:                             ; @.str.115
	.asciz	"if(in.call_references[%u]!=%u)return false;\n"

l_.str.116:                             ; @.str.116
	.asciz	"if(!nvm_file_hosted_import(p,%u,&ordinal) || ordinal!=%u)return false;\n"

l_.str.117:                             ; @.str.117
	.asciz	"return true;}\n"

l_.str.118:                             ; @.str.118
	.asciz	"if((uint64_t)(%s)!=UINT64_C(%llu))return false;\n"

l_.str.119:                             ; @.str.119
	.asciz	"%s%s"

l_.str.120:                             ; @.str.120
	.asciz	"tag"

l_.str.121:                             ; @.str.121
	.asciz	"mode"

l_.str.122:                             ; @.str.122
	.asciz	"global_index"

l_.str.123:                             ; @.str.123
	.asciz	"catalog_ordinal"

l_.str.124:                             ; @.str.124
	.asciz	"category"

l_.str.125:                             ; @.str.125
	.asciz	"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *c,uint64_t *steps){\nNvmFileRuntimeFrameView f; NvmFileRuntimeView value,values[2]; NvmFileFlowArm arm;\nuint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];\nuint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;\n(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;\n(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;\n"

l_.str.126:                             ; @.str.126
	.asciz	"if(0)goto nf_label_%u;\n"

l_.str.127:                             ; @.str.127
	.asciz	"goto nf_label_0;\n"

l_.str.128:                             ; @.str.128
	.asciz	"nf_label_%u:\n"

l_.str.129:                             ; @.str.129
	.asciz	"return nf_bad(c);\n"

l_.str.130:                             ; @.str.130
	.asciz	"if(!nvm_file_runtime_frame_view(c,&f) || f.mode!=NVM_FILE_RUNTIME_NATIVE || f.function!=%u || f.instruction!=%u || f.stack_count!=%u)return nf_bad(c);\nif(*steps==UINT64_MAX)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_LIMIT);\n++*steps;\n"

l_.str.131:                             ; @.str.131
	.asciz	"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_scalar(c,dst,%u,nf_bits(UINT64_C(%llu))));\n"

l_.str.132:                             ; @.str.132
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_copy(c,src,dst));\n"

l_.str.133:                             ; @.str.133
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n"

l_.str.134:                             ; @.str.134
	.asciz	"if(value.owning || value.formal)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"

l_.str.135:                             ; @.str.135
	.asciz	"NF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.136:                             ; @.str.136
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(!value.initialized || value.formal || value.owning!=%u)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_%s(c,src,dst));\n"

l_.str.137:                             ; @.str.137
	.asciz	"move"

l_.str.138:                             ; @.str.138
	.asciz	"copy"

l_.str.139:                             ; @.str.139
	.asciz	"NF_TRY(nvm_file_runtime_frame_store(c));\n"

l_.str.140:                             ; @.str.140
	.asciz	"NF_TRY(nvm_file_runtime_frame_region_begin(c));\n"

l_.str.141:                             ; @.str.141
	.asciz	"NF_TRY(nvm_file_runtime_frame_region_end(c));\n"

l_.str.142:                             ; @.str.142
	.asciz	"NF_TRY(nvm_file_runtime_frame_borrow(c));\n"

l_.str.143:                             ; @.str.143
	.asciz	"NF_TRY(nvm_file_runtime_frame_end_reference(c));\n"

l_.str.144:                             ; @.str.144
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.145:                             ; @.str.145
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nedge=arm==NVM_FILE_FLOW_ARM_ERROR;\n"

l_.str.146:                             ; @.str.146
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_take(c,src,%u,dst));\n"

l_.str.147:                             ; @.str.147
	.asciz	"src=reference=NVM_FILE_RUNTIME_NO_SLOT;\nif(!nvm_file_runtime_frame_scratch(c,&dst))return nf_bad(c);\n"

l_.str.148:                             ; @.str.148
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return nf_bad(c);\n"

l_.str.149:                             ; @.str.149
	.asciz	"if(!nvm_file_runtime_frame_reference(c,%u,&reference))return nf_bad(c);\n"

l_.str.150:                             ; @.str.150
	.asciz	"NF_TRY(nvm_file_runtime_service(c,%u,reference,src,dst));\nif(!nvm_file_runtime_frame_reserve(c,(uint16_t)(f.stack_count-%u),&output))return nf_bad(c);\nNF_TRY(nvm_file_runtime_move(c,dst,output));\n"

l_.str.151:                             ; @.str.151
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(!nf_scalar(&value,TAG_BOOL))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.152:                             ; @.str.152
	.asciz	"if(!value.values[0])return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_ASSERT);\n"

l_.str.153:                             ; @.str.153
	.asciz	"edge=(value.values[0]!=0)==%u;\n"

l_.str.154:                             ; @.str.154
	.asciz	"if(f.stack_count<%u)return nf_bad(c);\n"

l_.str.155:                             ; @.str.155
	.asciz	"if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&inputs[%u]))return nf_bad(c);\n"

l_.str.156:                             ; @.str.156
	.asciz	"dst=inputs[0];\n"

l_.str.157:                             ; @.str.157
	.asciz	"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"

l_.str.158:                             ; @.str.158
	.asciz	"NF_TRY(nvm_file_runtime_construct(c,%u,%u,inputs,%u,dst));\n"

l_.str.159:                             ; @.str.159
	.asciz	"NF_TRY(nvm_file_runtime_project(c,src,%u,src));\n"

l_.str.160:                             ; @.str.160
	.asciz	"if(!nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(value.owning || value.formal || value.type.category!=NVM_FILE_CATEGORY_SCALAR_RESULT)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nNF_TRY(nvm_file_runtime_drop(c,src));\nNF_TRY(nvm_file_runtime_scalar(c,src,TAG_INT,arm==NVM_FILE_FLOW_ARM_ERROR));\n"

l_.str.161:                             ; @.str.161
	.asciz	"NF_TRY(nvm_file_runtime_frame_call(c));\nNF_TRY(nf_function_%u(c,steps));\ngoto nf_label_%u;\n"

l_.str.162:                             ; @.str.162
	.asciz	"return nvm_file_runtime_frame_return(c);\n"

l_.str.163:                             ; @.str.163
	.asciz	"NF_TRY(nvm_file_runtime_frame_next(c,edge));\nif(edge)goto nf_label_%u;\ngoto nf_label_%u;\n"

l_.str.164:                             ; @.str.164
	.asciz	"NF_TRY(nvm_file_runtime_frame_next(c,0));\ngoto nf_label_%u;\n"

l_.str.165:                             ; @.str.165
	.asciz	"nf_bits((uint64_t)a+(uint64_t)z)"

l_.str.166:                             ; @.str.166
	.asciz	"nf_bits((uint64_t)a-(uint64_t)z)"

l_.str.167:                             ; @.str.167
	.asciz	"nf_bits((uint64_t)a*(uint64_t)z)"

l_.str.168:                             ; @.str.168
	.asciz	"!z?0:a==INT64_MIN&&z==-1?INT64_MIN:a/z"

l_.str.169:                             ; @.str.169
	.asciz	"!z||(a==INT64_MIN&&z==-1)?0:a%z"

l_.str.170:                             ; @.str.170
	.asciz	"nf_bits(UINT64_C(0)-(uint64_t)a)"

l_.str.171:                             ; @.str.171
	.asciz	"a==z"

l_.str.172:                             ; @.str.172
	.asciz	"a!=z"

l_.str.173:                             ; @.str.173
	.asciz	"a<z"

l_.str.174:                             ; @.str.174
	.asciz	"a<=z"

l_.str.175:                             ; @.str.175
	.asciz	"a>z"

l_.str.176:                             ; @.str.176
	.asciz	"a>=z"

l_.str.177:                             ; @.str.177
	.asciz	"a&&z"

l_.str.178:                             ; @.str.178
	.asciz	"a||z"

l_.str.179:                             ; @.str.179
	.asciz	"!a"

l_.str.180:                             ; @.str.180
	.asciz	"if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&roots[%u]) || !nvm_file_runtime_view(c,roots[%u],&values[%u]))return nf_bad(c);\n"

l_.str.181:                             ; @.str.181
	.asciz	"tag=%u;\n"

l_.str.182:                             ; @.str.182
	.asciz	"if(values[0].type.tag==TAG_BOOL)tag=TAG_BOOL;\n"

l_.str.183:                             ; @.str.183
	.asciz	"if(!nf_scalar(&values[%u],tag))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"

l_.str.184:                             ; @.str.184
	.asciz	"a=values[0].values[0];z=%s;r=(%s);\n"

l_.str.185:                             ; @.str.185
	.asciz	"0"

l_.str.186:                             ; @.str.186
	.asciz	"values[1].values[0]"

l_.str.187:                             ; @.str.187
	.asciz	"NF_TRY(nvm_file_runtime_drop(c,roots[%u]));\n"

l_.str.188:                             ; @.str.188
	.asciz	"NF_TRY(nvm_file_runtime_scalar(c,roots[0],%u,r));\n"

.subsections_via_symbols
