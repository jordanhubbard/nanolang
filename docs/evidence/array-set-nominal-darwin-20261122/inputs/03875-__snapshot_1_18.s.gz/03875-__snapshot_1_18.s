	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_reference_place_valid ; -- Begin function nvm_reference_place_valid
	.globl	_nvm_reference_place_valid
	.p2align	2
_nvm_reference_place_valid:             ; @nvm_reference_place_valid
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB0_12
; %bb.1:
	ldr	x9, [x2]
	cbz	x9, LBB0_12
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x8, x0
	ldrh	w20, [x2, #24]
	cbz	x20, LBB0_4
; %bb.3:
	ldr	x9, [x2, #16]
	cbz	x9, LBB0_10
LBB0_4:
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB0_11
; %bb.5:
	ldr	w9, [x2, #32]
	sub	w9, w9, #1
	cmp	w9, #1
	b.hi	LBB0_11
; %bb.6:
	ldr	x19, [x8]
	cbz	x19, LBB0_10
; %bb.7:
	ldr	w9, [x2, #12]
	cmp	w9, w1
	b.ne	LBB0_10
; %bb.8:
	ldr	w8, [x8, #8]
	cmp	w1, w8
	b.hs	LBB0_10
; %bb.9:
	add	x9, x19, w1, uxtw #4
	ldrb	w8, [x9]
	cbz	w8, LBB0_13
LBB0_10:
	mov	w0, #0                          ; =0x0
LBB0_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB0_12:
	mov	w0, #0                          ; =0x0
	ret
LBB0_13:
	ldrh	w8, [x9, #2]
	cbz	x8, LBB0_22
; %bb.14:
	ldr	x9, [x9, #8]
	cbz	x9, LBB0_10
; %bb.15:
	mov	w23, w1
	add	x9, x9, #4
LBB0_16:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	sub	w10, w10, #1
	cmp	w10, #3
	b.hi	LBB0_19
; %bb.17:                               ;   in Loop: Header=BB0_16 Depth=1
	ldr	w10, [x9], #12
	cmn	w10, #1
	b.ne	LBB0_19
; %bb.18:                               ;   in Loop: Header=BB0_16 Depth=1
	subs	x8, x8, #1
	b.ne	LBB0_16
	b	LBB0_22
LBB0_19:
	mov	x22, x1
	mov	x21, x2
	mov	w24, #1                         ; =0x1
	add	x0, x23, #1
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB0_11
; %bb.20:
	strb	w24, [x0, x23]
	adds	w8, w22, #1
	b.lo	LBB0_40
LBB0_21:
	bl	_free
	mov	x1, x22
	mov	x2, x21
LBB0_22:
	cbz	w20, LBB0_31
; %bb.23:
	mov	x8, #0                          ; =0x0
	lsl	x9, x20, #1
	mov	w10, #12                        ; =0xc
LBB0_24:                                ; =>This Inner Loop Header: Depth=1
	add	x11, x19, w1, uxtw #4
	ldrb	w12, [x11]
	cbnz	w12, LBB0_10
; %bb.25:                               ;   in Loop: Header=BB0_24 Depth=1
	ldrh	w12, [x11, #2]
	cbz	w12, LBB0_27
; %bb.26:                               ;   in Loop: Header=BB0_24 Depth=1
	ldr	x13, [x11, #8]
	cbz	x13, LBB0_10
LBB0_27:                                ;   in Loop: Header=BB0_24 Depth=1
	ldr	x13, [x2, #16]
	ldrh	w13, [x13, x8]
	cmp	w13, w12
	b.hs	LBB0_10
; %bb.28:                               ;   in Loop: Header=BB0_24 Depth=1
	ldr	x11, [x11, #8]
	umaddl	x11, w13, w10, x11
	ldrb	w12, [x11]
	cmp	w12, #8
	b.ne	LBB0_10
; %bb.29:                               ;   in Loop: Header=BB0_24 Depth=1
	ldr	w11, [x11, #4]
	cmp	w11, w1
	b.hs	LBB0_10
; %bb.30:                               ;   in Loop: Header=BB0_24 Depth=1
	add	x8, x8, #2
	mov	x1, x11
	cmp	x9, x8
	b.ne	LBB0_24
	b	LBB0_32
LBB0_31:
	mov	x11, x1
LBB0_32:
	ldr	w8, [x2, #28]
	cmp	w11, w8
	b.ne	LBB0_10
; %bb.33:
	add	x9, x19, w11, uxtw #4
	ldrb	w8, [x9]
	cbnz	w8, LBB0_10
; %bb.34:
	ldrh	w8, [x9, #2]
	cbz	x8, LBB0_54
; %bb.35:
	ldr	x9, [x9, #8]
	cbz	x9, LBB0_10
; %bb.36:
	add	x9, x9, #4
	mov	w0, #1                          ; =0x1
LBB0_37:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	sub	w10, w10, #1
	cmp	w10, #3
	b.hi	LBB0_10
; %bb.38:                               ;   in Loop: Header=BB0_37 Depth=1
	ldr	w10, [x9], #12
	cmn	w10, #1
	b.ne	LBB0_10
; %bb.39:                               ;   in Loop: Header=BB0_37 Depth=1
	subs	x8, x8, #1
	b.ne	LBB0_37
	b	LBB0_11
LBB0_40:
	mov	w9, #1                          ; =0x1
	b	LBB0_42
LBB0_41:                                ;   in Loop: Header=BB0_42 Depth=1
	cbz	x8, LBB0_21
LBB0_42:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_49 Depth 2
	sub	x8, x8, #1
	ldrb	w10, [x0, x8]
	cbz	w10, LBB0_41
; %bb.43:                               ;   in Loop: Header=BB0_42 Depth=1
	add	x11, x19, x8, lsl #4
	ldrb	w10, [x11]
	cbnz	w10, LBB0_53
; %bb.44:                               ;   in Loop: Header=BB0_42 Depth=1
	ldrh	w10, [x11, #2]
	cbz	x10, LBB0_41
; %bb.45:                               ;   in Loop: Header=BB0_42 Depth=1
	ldr	x11, [x11, #8]
	cbz	x11, LBB0_53
; %bb.46:                               ;   in Loop: Header=BB0_42 Depth=1
	add	x11, x11, #4
	b	LBB0_49
LBB0_47:                                ;   in Loop: Header=BB0_49 Depth=2
	ldr	w12, [x11]
	cmn	w12, #1
	b.ne	LBB0_53
LBB0_48:                                ;   in Loop: Header=BB0_49 Depth=2
	add	x11, x11, #12
	subs	x10, x10, #1
	b.eq	LBB0_41
LBB0_49:                                ;   Parent Loop BB0_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w12, [x11, #-4]
	sub	w13, w12, #1
	cmp	w13, #3
	b.ls	LBB0_47
; %bb.50:                               ;   in Loop: Header=BB0_49 Depth=2
	cmp	w12, #8
	b.ne	LBB0_53
; %bb.51:                               ;   in Loop: Header=BB0_49 Depth=2
	ldr	w12, [x11]
	cmp	x8, x12
	b.ls	LBB0_53
; %bb.52:                               ;   in Loop: Header=BB0_49 Depth=2
	strb	w9, [x0, x12]
	b	LBB0_48
LBB0_53:
	bl	_free
	b	LBB0_10
LBB0_54:
	mov	w0, #1                          ; =0x1
	b	LBB0_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_reference_places_overlap ; -- Begin function nvm_reference_places_overlap
	.globl	_nvm_reference_places_overlap
	.p2align	2
_nvm_reference_places_overlap:          ; @nvm_reference_places_overlap
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_16
; %bb.1:
	mov	x8, x0
	ldr	x10, [x0]
	cbz	x10, LBB1_16
; %bb.2:
	ldrh	w9, [x8, #24]
	cbz	w9, LBB1_4
; %bb.3:
	ldr	x11, [x8, #16]
	cbz	x11, LBB1_16
LBB1_4:
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB1_17
; %bb.5:
	ldr	w11, [x8, #32]
	sub	w11, w11, #3
	cmn	w11, #2
	b.lo	LBB1_17
; %bb.6:
	ldr	x12, [x1]
	cbz	x12, LBB1_17
; %bb.7:
	ldrh	w11, [x1, #24]
	cbz	w11, LBB1_9
; %bb.8:
	ldr	x13, [x1, #16]
	cbz	x13, LBB1_17
LBB1_9:
	ldr	w13, [x1, #32]
	sub	w13, w13, #1
	cmp	w13, #1
	b.hi	LBB1_17
; %bb.10:
	cmp	x10, x12
	b.ne	LBB1_18
; %bb.11:
	ldrh	w10, [x8, #8]
	ldrh	w12, [x1, #8]
	cmp	w10, w12
	b.ne	LBB1_18
; %bb.12:
	cmp	w9, w11
	csel	w10, w9, w11, lo
	cbz	w10, LBB1_17
; %bb.13:
	ldr	x8, [x8, #16]
	ldr	x9, [x1, #16]
	sub	x10, x10, #1
LBB1_14:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w12, [x8], #2
	ldrh	w13, [x9], #2
	subs	x10, x10, #1
	cset	w11, hs
	cmp	w12, w13
	cset	w0, eq
	b.ne	LBB1_17
; %bb.15:                               ;   in Loop: Header=BB1_14 Depth=1
	tbnz	w11, #0, LBB1_14
	b	LBB1_17
LBB1_16:
	mov	w0, #1                          ; =0x1
LBB1_17:
	ret
LBB1_18:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_reference_holds_conflict ; -- Begin function nvm_reference_holds_conflict
	.globl	_nvm_reference_holds_conflict
	.p2align	2
_nvm_reference_holds_conflict:          ; @nvm_reference_holds_conflict
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_22
; %bb.1:
	ldr	x10, [x0]
	cbz	x10, LBB2_22
; %bb.2:
	ldrh	w9, [x0, #24]
	cbz	w9, LBB2_4
; %bb.3:
	ldr	x8, [x0, #16]
	cbz	x8, LBB2_22
LBB2_4:
	mov	w8, #1                          ; =0x1
	cbz	x1, LBB2_23
; %bb.5:
	ldr	w12, [x0, #32]
	sub	w11, w12, #3
	cmn	w11, #2
	b.lo	LBB2_23
; %bb.6:
	ldr	x11, [x1]
	cbz	x11, LBB2_23
; %bb.7:
	ldrh	w8, [x1, #24]
	cbz	w8, LBB2_9
; %bb.8:
	ldr	x13, [x1, #16]
	cbz	x13, LBB2_22
LBB2_9:
	ldr	w13, [x1, #32]
	sub	w14, w13, #1
	cmp	w14, #1
	b.hi	LBB2_22
; %bb.10:
	cmp	w12, #2
	b.eq	LBB2_12
; %bb.11:
	cmp	w13, #2
	b.ne	LBB2_24
LBB2_12:
	cbz	w9, LBB2_14
; %bb.13:
	ldr	x12, [x0, #16]
	cbz	x12, LBB2_22
LBB2_14:
	cbz	w8, LBB2_16
; %bb.15:
	ldr	x12, [x1, #16]
	cbz	x12, LBB2_22
LBB2_16:
	cmp	x10, x11
	b.ne	LBB2_24
; %bb.17:
	ldrh	w10, [x0, #8]
	ldrh	w11, [x1, #8]
	cmp	w10, w11
	b.ne	LBB2_24
; %bb.18:
	cmp	w9, w8
	csel	w8, w9, w8, lo
	cbz	w8, LBB2_22
; %bb.19:
	ldr	x9, [x0, #16]
	ldr	x10, [x1, #16]
	sub	x11, x8, #1
LBB2_20:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [x9], #2
	ldrh	w13, [x10], #2
	subs	x11, x11, #1
	cset	w12, hs
	cmp	w8, w13
	cset	w8, eq
	b.ne	LBB2_23
; %bb.21:                               ;   in Loop: Header=BB2_20 Depth=1
	tbnz	w12, #0, LBB2_20
	b	LBB2_23
LBB2_22:
	mov	w8, #1                          ; =0x1
LBB2_23:
	mov	x0, x8
	ret
LBB2_24:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_reference_owner_access_conflicts ; -- Begin function nvm_reference_owner_access_conflicts
	.globl	_nvm_reference_owner_access_conflicts
	.p2align	2
_nvm_reference_owner_access_conflicts:  ; @nvm_reference_owner_access_conflicts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_22
; %bb.1:
	ldr	x10, [x0]
	cbz	x10, LBB3_22
; %bb.2:
	ldrh	w9, [x0, #24]
	cbz	w9, LBB3_4
; %bb.3:
	ldr	x8, [x0, #16]
	cbz	x8, LBB3_22
LBB3_4:
	mov	w8, #1                          ; =0x1
	cbz	x1, LBB3_23
; %bb.5:
	ldr	w12, [x0, #32]
	sub	w11, w12, #3
	cmn	w11, #2
	b.lo	LBB3_23
; %bb.6:
	ldr	x11, [x1]
	cbz	x11, LBB3_23
; %bb.7:
	ldrh	w8, [x1, #24]
	cbz	w8, LBB3_9
; %bb.8:
	ldr	x13, [x1, #16]
	cbz	x13, LBB3_22
LBB3_9:
	ldr	w13, [x1, #32]
	sub	w13, w13, #1
	cmp	w13, #1
	b.hi	LBB3_22
; %bb.10:
	tbnz	w2, #0, LBB3_12
; %bb.11:
	cmp	w12, #2
	b.ne	LBB3_24
LBB3_12:
	cbz	w9, LBB3_14
; %bb.13:
	ldr	x12, [x0, #16]
	cbz	x12, LBB3_22
LBB3_14:
	cbz	w8, LBB3_16
; %bb.15:
	ldr	x12, [x1, #16]
	cbz	x12, LBB3_22
LBB3_16:
	cmp	x10, x11
	b.ne	LBB3_24
; %bb.17:
	ldrh	w10, [x0, #8]
	ldrh	w11, [x1, #8]
	cmp	w10, w11
	b.ne	LBB3_24
; %bb.18:
	cmp	w9, w8
	csel	w8, w9, w8, lo
	cbz	w8, LBB3_22
; %bb.19:
	ldr	x9, [x0, #16]
	ldr	x10, [x1, #16]
	sub	x11, x8, #1
LBB3_20:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [x9], #2
	ldrh	w13, [x10], #2
	subs	x11, x11, #1
	cset	w12, hs
	cmp	w8, w13
	cset	w8, eq
	b.ne	LBB3_23
; %bb.21:                               ;   in Loop: Header=BB3_20 Depth=1
	tbnz	w12, #0, LBB3_20
	b	LBB3_23
LBB3_22:
	mov	w8, #1                          ; =0x1
LBB3_23:
	mov	x0, x8
	ret
LBB3_24:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
