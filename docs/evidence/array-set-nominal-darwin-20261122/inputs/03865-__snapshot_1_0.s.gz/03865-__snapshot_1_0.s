	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_affine_value_call_graph ; -- Begin function nvm_affine_value_call_graph
	.globl	_nvm_affine_value_call_graph
	.p2align	2
_nvm_affine_value_call_graph:           ; @nvm_affine_value_call_graph
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cbz	x0, LBB0_29
; %bb.1:
	ldr	x8, [x0, #256]
	cbz	x8, LBB0_30
; %bb.2:
	ldr	w8, [x0, #272]
	sub	w8, w8, #9
	cmn	w8, #8
	b.lo	LBB0_29
; %bb.3:
	ldr	w8, [x0, #12]
	cbnz	w8, LBB0_29
; %bb.4:
	mov	w9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x29, #-128]
	mov	w23, #24                        ; =0x18
	stp	q0, q0, [x29, #-160]
	mov	w24, #1                         ; =0x1
	mov	w25, #22                        ; =0x16
	sub	x26, x29, #160
	mov	x27, #32768                     ; =0x8000
	movk	x27, #53256, lsl #48
LBB0_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_20 Depth 2
	ldr	x8, [x0, #256]
	umaddl	x22, w9, w23, x8
	cbnz	w9, LBB0_9
; %bb.6:                                ;   in Loop: Header=BB0_5 Depth=1
	ldrh	w8, [x22, #4]
	cbnz	w8, LBB0_29
; %bb.7:                                ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [x22, #21]
	cmp	w8, #1
	b.ne	LBB0_29
; %bb.8:                                ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [x22, #20]
	cmp	w8, #4
	lsl	w8, w24, w8
	and	w8, w8, w25
	ccmp	w8, #0, #4, ls
	b.eq	LBB0_29
LBB0_9:                                 ;   in Loop: Header=BB0_5 Depth=1
	ldrh	w8, [x22, #18]
	cbnz	w8, LBB0_29
; %bb.10:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrh	w2, [x22, #16]
	cmp	w2, #256
	b.hi	LBB0_29
; %bb.11:                               ;   in Loop: Header=BB0_5 Depth=1
	ldr	w8, [x22, #12]
	cmp	w8, #32, lsl #12                ; =131072
	b.hi	LBB0_29
; %bb.12:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w19, w9
	mov	x20, x0
	mov	x1, x19
	bl	_nvm_affine_state_create
	mov	x21, x0
	str	wzr, [sp, #36]
	sub	x1, x29, #224
	add	x3, sp, #38
	mov	w2, #8                          ; =0x8
	bl	_nvm_affine_value_parameters
	cbz	w0, LBB0_42
; %bb.13:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrh	w8, [sp, #38]
	ldrh	w9, [x22, #4]
	cmp	w8, w9
	b.ne	LBB0_42
; %bb.14:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x1, sp, #40
	add	x2, sp, #36
	mov	x0, x21
	bl	_nvm_affine_value_result
	mov	x22, x0
	mov	x0, x21
	bl	_nvm_affine_state_free
	cbz	w22, LBB0_29
; %bb.15:                               ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x2, sp
	add	x3, sp, #48
	mov	x0, x20
	mov	x1, x19
	bl	_vm_decode_function
	cbz	w0, LBB0_29
; %bb.16:                               ;   in Loop: Header=BB0_5 Depth=1
	ldr	w8, [sp, #8]
	sub	w9, w8, #1
	cmp	w9, #1, lsl #12                 ; =4096
	b.hs	LBB0_28
; %bb.17:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp]
	add	x10, x10, #48
	add	x11, x26, x19, lsl #3
	mov	x12, x20
	b	LBB0_20
LBB0_18:                                ;   in Loop: Header=BB0_20 Depth=2
	lsl	x13, x24, x13
	tst	x13, x27
	b.ne	LBB0_28
LBB0_19:                                ;   in Loop: Header=BB0_20 Depth=2
	add	x9, x9, #1
	add	x10, x10, #104
	cmp	x9, x8
	b.hs	LBB0_25
LBB0_20:                                ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w13, [x10, #-8]
	cmp	w13, #63
	b.hi	LBB0_19
; %bb.21:                               ;   in Loop: Header=BB0_20 Depth=2
	cmp	x13, #59
	b.ne	LBB0_18
; %bb.22:                               ;   in Loop: Header=BB0_20 Depth=2
	ldr	w13, [x10]
	cbz	w13, LBB0_28
; %bb.23:                               ;   in Loop: Header=BB0_20 Depth=2
	ldr	w14, [x12, #272]
	cmp	w13, w14
	b.hs	LBB0_28
; %bb.24:                               ;   in Loop: Header=BB0_20 Depth=2
	strb	w24, [x11, x13]
	b	LBB0_19
LBB0_25:                                ;   in Loop: Header=BB0_5 Depth=1
	mov	x0, sp
	bl	_vm_decoded_function_free
	mov	x0, x20
	add	w9, w19, #1
	ldr	w8, [x20, #272]
	cmp	w9, w8
	b.lo	LBB0_5
; %bb.26:
	cbz	w8, LBB0_47
; %bb.27:
	mov	x9, #0                          ; =0x0
	sub	x10, x29, #160
	sub	x11, x29, #160
	b	LBB0_33
LBB0_28:
	mov	x0, sp
	bl	_vm_decoded_function_free
LBB0_29:
	mov	w8, #0                          ; =0x0
LBB0_30:
	ldur	x9, [x29, #-88]
Lloh3:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB0_48
; %bb.31:
	and	w0, w8, #0x1
	add	sp, sp, #448
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_32:                                ;   in Loop: Header=BB0_33 Depth=1
	add	x9, x9, #1
	add	x11, x11, #8
	cmp	x9, x8
	b.eq	LBB0_43
LBB0_33:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_38 Depth 3
	mov	x12, #0                         ; =0x0
	sub	x13, x29, #160
	b	LBB0_35
LBB0_34:                                ;   in Loop: Header=BB0_35 Depth=2
	add	x12, x12, #1
	add	x13, x13, #8
	cmp	x12, x8
	b.eq	LBB0_32
LBB0_35:                                ;   Parent Loop BB0_33 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_38 Depth 3
	mov	x14, x8
	mov	x15, x11
	mov	x16, x13
	add	x17, x10, x12, lsl #3
	b	LBB0_38
LBB0_36:                                ;   in Loop: Header=BB0_38 Depth=3
	mov	w0, #1                          ; =0x1
LBB0_37:                                ;   in Loop: Header=BB0_38 Depth=3
	and	w0, w0, #0x1
	strb	w0, [x16], #1
	add	x15, x15, #1
	subs	x14, x14, #1
	b.eq	LBB0_34
LBB0_38:                                ;   Parent Loop BB0_33 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w0, [x16]
	tbnz	w0, #0, LBB0_36
; %bb.39:                               ;   in Loop: Header=BB0_38 Depth=3
	ldrb	w0, [x17, x9]
	cmp	w0, #1
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_38 Depth=3
	ldrb	w0, [x15]
	b	LBB0_37
LBB0_41:                                ;   in Loop: Header=BB0_38 Depth=3
	mov	w0, #0                          ; =0x0
	b	LBB0_37
LBB0_42:
	mov	x0, x21
	bl	_nvm_affine_state_free
	b	LBB0_29
LBB0_43:
	sub	x9, x8, #1
	sub	x8, x29, #160
LBB0_44:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #9
	tbnz	w11, #0, LBB0_46
; %bb.45:                               ;   in Loop: Header=BB0_44 Depth=1
	mov	x10, x9
	sub	x9, x9, #1
	cbnz	x10, LBB0_44
LBB0_46:
	eor	w8, w11, #0x1
	b	LBB0_30
LBB0_47:
	mov	w8, #1                          ; =0x1
	b	LBB0_30
LBB0_48:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_analyze_function ; -- Begin function nvm_affine_analyze_function
	.globl	_nvm_affine_analyze_function
	.p2align	2
_nvm_affine_analyze_function:           ; @nvm_affine_analyze_function
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	mov	w9, #16272                      ; =0x3f90
Lloh6:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh7:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #3984
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x1
	mov	x20, x0
	mov	x19, x8
Lloh8:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh9:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh10:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	add	x0, sp, #216
	mov	w1, #16048                      ; =0x3eb0
	bl	_bzero
	add	x0, sp, #216
	mov	x1, x20
	bl	_analysis_calls_init
	add	x8, sp, #8
	add	x4, sp, #216
	mov	x0, x20
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_analyze
	ldrb	w8, [sp, #8]
	cmp	w8, #1
	b.ne	LBB1_3
; %bb.1:
	ldrb	w8, [sp, #218]
	tbz	w8, #0, LBB1_3
; %bb.2:
	add	x1, sp, #216
	mov	x8, x19
	mov	x0, x20
	bl	_effect_global_proof
	ldrb	w8, [x19]
	cmp	w8, #1
	b.ne	LBB1_4
LBB1_3:
	ldur	q0, [sp, #168]
	ldur	q1, [sp, #184]
	stp	q0, q1, [x19, #160]
	ldur	q0, [sp, #200]
	str	q0, [x19, #192]
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #120]
	stp	q0, q1, [x19, #96]
	ldur	q0, [sp, #152]
	ldur	q1, [sp, #136]
	stp	q1, q0, [x19, #128]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #56]
	stp	q0, q1, [x19, #32]
	ldur	q0, [sp, #88]
	ldur	q1, [sp, #72]
	stp	q1, q0, [x19, #64]
	ldur	q0, [sp, #24]
	ldur	q1, [sp, #8]
	stp	q1, q0, [x19]
LBB1_4:
	ldur	x8, [x29, #-40]
Lloh11:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh12:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh13:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_6
; %bb.5:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #3984
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB1_6:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh8, Lloh9, Lloh10
	.loh AdrpLdrGotLdr	Lloh11, Lloh12, Lloh13
	.loh AdrpLdrGot	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function analysis_calls_init
_analysis_calls_init:                   ; @analysis_calls_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
Lloh14:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh15:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh16:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	add	x1, x0, #8
	add	x3, x0, #4
	mov	x0, x20
	mov	w2, #256                        ; =0x100
	bl	_nvm_ownership_globals
	cmp	w0, #0
	cset	w8, eq
	strb	w8, [x19, #1]
	cbz	w0, LBB2_2
; %bb.1:
	strb	wzr, [x19]
	b	LBB2_35
LBB2_2:
	mov	x0, x20
	bl	_nvm_affine_value_call_graph
	strb	w0, [x19]
	cbz	w0, LBB2_35
; %bb.3:
	ldur	w8, [x19, #4]
	cbz	w8, LBB2_35
; %bb.4:
	ldr	w8, [x20, #272]
	cbz	w8, LBB2_35
; %bb.5:
	mov	w21, #0                         ; =0x0
	mov	w22, #104                       ; =0x68
	mov	w23, #1                         ; =0x1
	b	LBB2_7
LBB2_6:                                 ;   in Loop: Header=BB2_7 Depth=1
	mov	x0, sp
	bl	_vm_decoded_function_free
	add	w21, w21, #1
	ldr	w8, [x20, #272]
	cmp	w21, w8
	b.hs	LBB2_35
LBB2_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_13 Depth 2
                                        ;     Child Loop BB2_32 Depth 2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x2, sp
	add	x3, sp, #40
	mov	x0, x20
	mov	x1, x21
	bl	_vm_decode_function
	cbz	w0, LBB2_34
; %bb.8:                                ;   in Loop: Header=BB2_7 Depth=1
	ldr	w8, [sp, #8]
	cbz	w8, LBB2_6
; %bb.9:                                ;   in Loop: Header=BB2_7 Depth=1
	ldr	x9, [sp]
	cmp	w8, #8
	b.hs	LBB2_11
; %bb.10:                               ;   in Loop: Header=BB2_7 Depth=1
	mov	x10, #0                         ; =0x0
	and	x8, x8, #0x7
	cbnz	x8, LBB2_30
	b	LBB2_6
LBB2_11:                                ;   in Loop: Header=BB2_7 Depth=1
	mov	x10, #0                         ; =0x0
	and	x11, x8, #0xfffffff8
	neg	x11, x11
	mov	x12, x9
	b	LBB2_13
LBB2_12:                                ;   in Loop: Header=BB2_13 Depth=2
	add	x12, x12, #832
	sub	x10, x10, #8
	cmp	x11, x10
	b.eq	LBB2_29
LBB2_13:                                ;   Parent Loop BB2_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w13, [x12, #40]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_15
; %bb.14:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_15:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #144]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_17
; %bb.16:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_17:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #248]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_19
; %bb.18:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_19:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #352]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_21
; %bb.20:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_21:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #456]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_23
; %bb.22:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_23:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #560]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_25
; %bb.24:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_25:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #664]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_27
; %bb.26:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
LBB2_27:                                ;   in Loop: Header=BB2_13 Depth=2
	ldrb	w13, [x12, #768]
	sub	w13, w13, #165
	cmp	w13, #3
	b.hi	LBB2_12
; %bb.28:                               ;   in Loop: Header=BB2_13 Depth=2
	strb	w23, [x19, #2]
	b	LBB2_12
LBB2_29:                                ;   in Loop: Header=BB2_7 Depth=1
	neg	x10, x10
	and	x8, x8, #0x7
	cbz	x8, LBB2_6
LBB2_30:                                ;   in Loop: Header=BB2_7 Depth=1
	madd	x9, x10, x22, x9
	add	x9, x9, #40
	b	LBB2_32
LBB2_31:                                ;   in Loop: Header=BB2_32 Depth=2
	subs	x8, x8, #1
	b.eq	LBB2_6
LBB2_32:                                ;   Parent Loop BB2_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x9], #104
	sub	w10, w10, #165
	cmp	w10, #3
	b.hi	LBB2_31
; %bb.33:                               ;   in Loop: Header=BB2_32 Depth=2
	strb	w23, [x19, #2]
	b	LBB2_31
LBB2_34:
	strb	wzr, [x19, #1]
LBB2_35:
	ldur	x8, [x29, #-56]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_37
; %bb.36:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB2_37:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh14, Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function analyze
_analyze:                               ; @analyze
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2816
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x4
	mov	x22, x2
	mov	x21, x1
	mov	x19, x8
Lloh20:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh21:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh22:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	add	x28, sp, #2576
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x28, #176]
	stp	q0, q0, [x28, #144]
	stp	q0, q0, [x28, #112]
	stp	q0, q0, [x28, #80]
	stp	q0, q0, [x28, #48]
	stp	q0, q0, [x28, #16]
Lloh23:
	adrp	x8, l_.str.2@PAGE
Lloh24:
	add	x8, x8, l_.str.2@PAGEOFF
	str	q0, [x28]
	str	x8, [sp, #248]
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	cbz	x0, LBB3_142
; %bb.1:
	ldr	x8, [x0, #256]
	cbz	x8, LBB3_141
; %bb.2:
	ldr	w9, [x0, #272]
	cmp	w21, w9
	b.hs	LBB3_141
; %bb.3:
	ldrb	w9, [x20, #1]
	cmp	w9, #1
	b.ne	LBB3_141
; %bb.4:
	ldr	w2, [x20, #4]
	ldrb	w9, [x20]
	cbz	w2, LBB3_7
; %bb.5:
	tbz	w9, #0, LBB3_15
; %bb.6:
	mov	w9, #0                          ; =0x0
	b	LBB3_8
LBB3_7:
	eor	w9, w9, #0x1
LBB3_8:
	cbnz	x22, LBB3_14
; %bb.9:
	cbnz	w9, LBB3_14
; %bb.10:
	mov	w8, #6168                       ; =0x1818
	add	x8, x20, x8
	mov	w24, w21
	ldrb	w9, [x8, x24]
	cmp	w9, #1
	b.eq	LBB3_16
; %bb.11:
	cmp	w9, #2
	b.ne	LBB3_17
; %bb.12:
	mov	w8, #208                        ; =0xd0
	umaddl	x8, w24, w8, x20
	ldr	q0, [x8, #6320]
	ldr	q1, [x8, #6336]
	ldr	q2, [x8, #6352]
	stp	q1, q2, [x19, #160]
	ldr	q1, [x8, #6368]
	str	q1, [x19, #192]
	ldr	q1, [x8, #6256]
	ldr	q2, [x8, #6272]
	ldr	q3, [x8, #6288]
	stp	q2, q3, [x19, #96]
	ldr	q2, [x8, #6304]
	stp	q2, q0, [x19, #128]
	ldr	q0, [x8, #6192]
	ldr	q2, [x8, #6208]
	ldr	q3, [x8, #6224]
	stp	q2, q3, [x19, #32]
	ldr	q2, [x8, #6240]
	stp	q2, q1, [x19, #64]
	ldr	q1, [x8, #6176]
	stp	q1, q0, [x19]
	ldur	x8, [x29, #-104]
Lloh25:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh26:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh27:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB3_149
LBB3_13:
	bl	___stack_chk_fail
LBB3_14:
	mov	w24, w21
	b	LBB3_18
LBB3_15:
	mov	x0, #0                          ; =0x0
Lloh28:
	adrp	x8, l_.str.3@PAGE
Lloh29:
	add	x8, x8, l_.str.3@PAGEOFF
	b	LBB3_21
LBB3_16:
	mov	x0, #0                          ; =0x0
Lloh30:
	adrp	x8, l_.str.4@PAGE
Lloh31:
	add	x8, x8, l_.str.4@PAGEOFF
	b	LBB3_21
LBB3_17:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, x24]
	add	x8, x20, x24, lsl #8
	mov	x23, x0
	add	x0, x8, #2056
	mov	w1, #3                          ; =0x3
	mov	x25, x3
	bl	_memset
	mov	x3, x25
	mov	x0, x23
	ldr	x8, [x23, #256]
LBB3_18:
	mov	w9, #24                         ; =0x18
	umaddl	x25, w24, w9, x8
	ldrh	w2, [x25, #16]
	cmp	w2, #256
	b.hi	LBB3_20
; %bb.19:
	ldr	w8, [x25, #12]
	cmp	w8, #32, lsl #12                ; =131072
	b.ls	LBB3_22
LBB3_20:
	mov	x0, #0                          ; =0x0
Lloh32:
	adrp	x8, l_.str.5@PAGE
Lloh33:
	add	x8, x8, l_.str.5@PAGEOFF
LBB3_21:
	str	x8, [sp, #248]
	b	LBB3_142
LBB3_22:
	mov	x23, x3
	str	x0, [sp, #152]                  ; 8-byte Folded Spill
	mov	x1, x21
	bl	_nvm_affine_state_create
	cbz	x0, LBB3_142
; %bb.23:
	mov	x26, x0
	cbz	x22, LBB3_25
; %bb.24:
	mov	x0, x26
	mov	x1, x22
	mov	x2, x23
	bl	_nvm_affine_bind_caller
	tbz	w0, #0, LBB3_29
LBB3_25:
	add	x2, sp, #208
	add	x3, sp, #2320
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	x1, x21
	bl	_vm_decode_function
	tbz	w0, #0, LBB3_28
; %bb.26:
	ldr	w9, [sp, #216]
	mov	w8, #-4097                      ; =0xffffefff
	add	w8, w9, w8
	cmn	w8, #1, lsl #12                 ; =4096
	b.hs	LBB3_30
; %bb.27:
	mov	x0, x26
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
Lloh34:
	adrp	x8, l_.str.8@PAGE
Lloh35:
	add	x8, x8, l_.str.8@PAGEOFF
	b	LBB3_21
LBB3_28:
	mov	x0, x26
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
Lloh36:
	adrp	x8, l_.str.7@PAGE
Lloh37:
	add	x8, x8, l_.str.7@PAGEOFF
	b	LBB3_21
LBB3_29:
	mov	x0, x26
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
Lloh38:
	adrp	x8, l_.str.6@PAGE
Lloh39:
	add	x8, x8, l_.str.6@PAGEOFF
	b	LBB3_21
LBB3_30:
	str	x26, [sp, #144]                 ; 8-byte Folded Spill
	str	x25, [sp, #104]                 ; 8-byte Folded Spill
	ldr	x23, [sp, #208]
	ldrb	w26, [x20]
	str	x9, [sp, #120]                  ; 8-byte Folded Spill
	mov	x25, x9
LBB3_31:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w27, [x23, #40]
	mov	x0, x27
	mov	x1, x26
	bl	_supported
	tbz	w0, #0, LBB3_49
; %bb.32:                               ;   in Loop: Header=BB3_31 Depth=1
	add	x23, x23, #104
	subs	x25, x25, #1
	b.ne	LBB3_31
; %bb.33:
	mov	x10, #0                         ; =0x0
	add	x8, sp, #256
	add	x8, x8, #20
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	mov	w11, #104                       ; =0x68
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x23, [sp, #120]                 ; 8-byte Folded Reload
	b	LBB3_35
LBB3_34:                                ;   in Loop: Header=BB3_35 Depth=1
	add	x10, x10, #1
	cmp	x10, x23
	b.eq	LBB3_53
LBB3_35:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_42 Depth 2
	ldr	x8, [sp, #208]
	madd	x25, x10, x11, x8
	ldrb	w8, [x25, #40]!
	orr	w9, w8, #0x2
	cmp	w9, #167
	b.ne	LBB3_46
; %bb.36:                               ;   in Loop: Header=BB3_35 Depth=1
	str	x10, [sp, #112]                 ; 8-byte Folded Spill
	cmp	w8, #165
	mov	w8, #8                          ; =0x8
	mov	w9, #24                         ; =0x18
	csel	x8, x9, x8, eq
	mov	x9, x25
	ldr	w1, [x9, #8]!
	ldrh	w23, [x9, x8]
	add	x2, sp, #256
	bl	_nvm_ownership_effect
	cbnz	w0, LBB3_51
; %bb.37:                               ;   in Loop: Header=BB3_35 Depth=1
	ldrh	w8, [sp, #260]
	cmp	w23, w8
	b.ne	LBB3_51
; %bb.38:                               ;   in Loop: Header=BB3_35 Depth=1
	str	x25, [sp, #128]                 ; 8-byte Folded Spill
	ldrb	w8, [x25]
	cmp	w8, #165
	b.ne	LBB3_45
; %bb.39:                               ;   in Loop: Header=BB3_35 Depth=1
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldrh	w9, [x8, #24]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	str	w9, [sp, #136]                  ; 4-byte Folded Spill
	add	w9, w9, w23
	cmp	w9, w8
	b.hi	LBB3_150
; %bb.40:                               ;   in Loop: Header=BB3_35 Depth=1
	cbz	w23, LBB3_45
; %bb.41:                               ;   in Loop: Header=BB3_35 Depth=1
	mov	x26, #0                         ; =0x0
	ldr	x27, [sp, #96]                  ; 8-byte Folded Reload
LBB3_42:                                ;   Parent Loop BB3_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	add	w8, w8, w26
	and	w1, w8, #0xffff
	add	x2, sp, #168
	ldr	x25, [sp, #144]                 ; 8-byte Folded Reload
	mov	x0, x25
	bl	_nvm_affine_local_type
	cbz	w0, LBB3_50
; %bb.43:                               ;   in Loop: Header=BB3_42 Depth=2
	ldurb	w8, [x27, #-4]
	ldr	x1, [sp, #168]
	ldr	w9, [x27], #8
	orr	x2, x8, x9, lsl #32
	mov	x0, x25
	bl	_nvm_affine_types_equal
	cbz	w0, LBB3_50
; %bb.44:                               ;   in Loop: Header=BB3_42 Depth=2
	add	x26, x26, #1
	cmp	x23, x26
	b.ne	LBB3_42
LBB3_45:                                ;   in Loop: Header=BB3_35 Depth=1
	ldp	x23, x25, [sp, #120]            ; 16-byte Folded Reload
	ldrb	w8, [x25]
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	mov	w11, #104                       ; =0x68
LBB3_46:                                ;   in Loop: Header=BB3_35 Depth=1
	and	w8, w8, #0xfe
	cmp	w8, #18
	b.ne	LBB3_34
; %bb.47:                               ;   in Loop: Header=BB3_35 Depth=1
	ldr	w8, [x25, #8]
	ldr	w9, [x20, #4]
	cmp	w8, w9
	b.lo	LBB3_34
; %bb.48:
	ldr	x8, [sp, #208]
	mov	w9, #104                        ; =0x68
	mul	x9, x10, x9
	ldr	w8, [x8, x9]
	str	w8, [x28, #4]
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
Lloh40:
	adrp	x8, l_.str.15@PAGE
Lloh41:
	add	x8, x8, l_.str.15@PAGEOFF
	b	LBB3_21
LBB3_49:
	ldr	w8, [x23]
	str	w8, [x28, #4]
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
	and	w8, w27, #0xfffffffb
Lloh42:
	adrp	x9, l_.str.11@PAGE
Lloh43:
	add	x9, x9, l_.str.11@PAGEOFF
Lloh44:
	adrp	x10, l_.str.10@PAGE
Lloh45:
	add	x10, x10, l_.str.10@PAGEOFF
	cmp	w8, #160
	csel	x8, x10, x9, eq
Lloh46:
	adrp	x9, l_.str.9@PAGE
Lloh47:
	add	x9, x9, l_.str.9@PAGEOFF
	cmp	w27, #4
	csel	x8, x9, x8, eq
	b	LBB3_21
LBB3_50:
	mov	x0, x25
	bl	_nvm_affine_state_free
Lloh48:
	adrp	x8, l_.str.14@PAGE
Lloh49:
	add	x8, x8, l_.str.14@PAGEOFF
	b	LBB3_52
LBB3_51:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
Lloh50:
	adrp	x8, l_.str.12@PAGE
Lloh51:
	add	x8, x8, l_.str.12@PAGEOFF
LBB3_52:
	str	x8, [sp, #248]
	mov	x0, #0                          ; =0x0
	b	LBB3_142
LBB3_53:
	cbnz	x22, LBB3_57
; %bb.54:
	ldr	x8, [x20, #6160]
	cbz	x8, LBB3_57
; %bb.55:
	ldr	w8, [x20, #6152]
	cmp	w21, w8
	b.ne	LBB3_57
; %bb.56:
	ldr	w8, [x20, #6156]
	cmp	w23, w8
	b.ne	LBB3_159
LBB3_57:
	mov	x0, x23
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x26, x0
	str	w23, [sp, #192]
	lsl	x0, x23, #2
	bl	_malloc
	mov	x25, x0
	str	x0, [sp, #176]
	mov	x0, x23
	mov	w1, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #184]
	str	x26, [sp, #136]                 ; 8-byte Folded Spill
	cbz	x26, LBB3_138
; %bb.58:
	cbz	x25, LBB3_138
; %bb.59:
	mov	x27, x0
	cbz	x0, LBB3_138
; %bb.60:
	mov	x26, x25
	mov	w23, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #800                        ; =0x320
	bl	_calloc
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	str	x0, [x8]
	cbz	x0, LBB3_151
; %bb.61:
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [x0]
	ldr	w25, [x20, #4]
	strh	w25, [x0, #20]
	add	x0, x0, #22
	mov	w1, #9                          ; =0x9
	mov	x2, x25
	mov	w3, #778                        ; =0x30a
	bl	___memset_chk
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	str	wzr, [x26]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	cmp	w9, #1
	cset	w9, ne
	stp	w9, w23, [sp, #200]
	strb	w23, [x27]
	cbz	w23, LBB3_160
; %bb.62:
	str	wzr, [sp, #128]                 ; 4-byte Folded Spill
	stp	wzr, wzr, [sp, #92]             ; 8-byte Folded Spill
	lsl	w9, w25, #2
	add	w8, w9, w8, lsl #1
	add	w8, w8, #16, lsl #12            ; =65536
	add	w9, w8, #257
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	mul	w8, w9, w8
	str	w8, [sp, #88]                   ; 4-byte Folded Spill
	add	x8, x20, x24, lsl #8
	mov	w9, #4104                       ; =0x1008
	add	x9, x8, x9
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	mov	w9, #4136                       ; =0x1028
	add	x8, x8, x9
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
Lloh52:
	adrp	x8, l_.str.32@PAGE
Lloh53:
	add	x8, x8, l_.str.32@PAGEOFF
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB3_64
LBB3_63:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_frame_free
	ldr	w23, [sp, #204]
	cbz	w23, LBB3_161
LBB3_64:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_124 Depth 2
                                        ;     Child Loop BB3_117 Depth 2
                                        ;     Child Loop BB3_121 Depth 2
                                        ;     Child Loop BB3_103 Depth 2
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #88]                   ; 4-byte Folded Reload
	cmp	w8, w9
	b.eq	LBB3_183
; %bb.65:                               ;   in Loop: Header=BB3_64 Depth=1
	ldp	w9, w8, [sp, #192]
	ldp	x10, x11, [sp, #176]
	ldr	w12, [x10, x8, lsl #2]
	add	w8, w8, #1
	udiv	w10, w8, w9
	msub	w8, w10, w9, w8
	sub	w9, w23, #1
	str	w8, [sp, #196]
	str	w9, [sp, #204]
	strb	wzr, [x11, x12]
	ldr	x8, [sp, #208]
	mov	w9, #104                        ; =0x68
	umaddl	x23, w12, w9, x8
	ldr	w8, [x23]
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	str	x12, [sp, #80]                  ; 8-byte Folded Spill
	ldr	x0, [x8, x12, lsl #3]
	ldrb	w8, [x0, #18]
	tbnz	w8, #0, LBB3_67
; %bb.66:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #18]
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #96]                   ; 4-byte Folded Spill
LBB3_67:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #128]                  ; 4-byte Folded Spill
	bl	_frame_clone
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	cbz	x0, LBB3_184
; %bb.68:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x1, x23
	ldrb	w8, [x1, #40]!
	str	w8, [sp, #112]                  ; 4-byte Folded Spill
	cmp	w8, #168
	b.eq	LBB3_80
; %bb.69:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w8, #163
	b.eq	LBB3_77
; %bb.70:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w8, #61
	b.ne	LBB3_85
; %bb.71:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	cbz	w8, LBB3_94
; %bb.72:                               ;   in Loop: Header=BB3_64 Depth=1
	cmp	w8, #1
	b.ne	LBB3_190
; %bb.73:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.eq	LBB3_190
; %bb.74:                               ;   in Loop: Header=BB3_64 Depth=1
	ldrb	w1, [x8]
	ldrb	w9, [x8, #4]
	tbnz	w9, #0, LBB3_76
; %bb.75:                               ;   in Loop: Header=BB3_64 Depth=1
	cmp	w1, #10
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w1
	mov	w10, #1408                      ; =0x580
	and	w9, w9, w10
	ccmp	w9, #0, #4, ls
	b.eq	LBB3_95
LBB3_76:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x0, [x9]
	ldr	w8, [x8, #8]
	orr	x1, x1, x8, lsl #32
	bl	_nvm_affine_can_exit_type
	cbnz	w0, LBB3_96
	b	LBB3_191
LBB3_77:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	cbnz	w8, LBB3_185
; %bb.78:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #284]
	cbnz	w8, LBB3_185
; %bb.79:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	tbnz	w0, #0, LBB3_63
	b	LBB3_185
LBB3_80:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #284]
	cbz	w8, LBB3_182
; %bb.81:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	cmp	w8, #1
	b.ne	LBB3_182
; %bb.82:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	ldrb	w8, [x9, #1]
	tbnz	w8, #0, LBB3_182
; %bb.83:                               ;   in Loop: Header=BB3_64 Depth=1
	ldrb	w8, [x9]
	cmp	w8, #10
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w8
	mov	w11, #1408                      ; =0x580
	and	w10, w10, w11
	ccmp	w10, #0, #4, ls
	b.eq	LBB3_113
; %bb.84:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w9, [x9, #8]
	lsl	x9, x9, #32
	b	LBB3_114
LBB3_85:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w2, [x8, #16]
	ldr	w5, [x23]
	ldp	x0, x3, [sp, #144]              ; 16-byte Folded Reload
	mov	x4, x21
	mov	x6, x20
	bl	_step
	str	x0, [sp, #248]
	cbnz	x0, LBB3_186
; %bb.86:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w8, #107
	b.eq	LBB3_104
; %bb.87:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w8, #165
	b.ne	LBB3_129
; %bb.88:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #278]
	cmp	x8, #64
	b.eq	LBB3_195
; %bb.89:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w27, [x23, #48]
	ldrh	w25, [x23, #64]
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	add	x9, x0, x8, lsl #3
	add	w8, w8, #1
	strh	w8, [x0, #278]
	str	w27, [x9, #288]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	w8, [x9, #292]
	bl	_frame_clone
	cbz	x0, LBB3_196
; %bb.90:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x26, x0
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	x1, x27
	mov	x2, x25
	bl	_nvm_affine_handler_enter
	cbz	x0, LBB3_198
; %bb.91:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x27, x0
	ldr	x0, [x26]
	bl	_nvm_affine_state_free
	str	x27, [x26]
	ldr	x0, [x26, #8]
	bl	_free
	str	xzr, [x26, #8]
	strh	wzr, [x26, #16]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	w8, w8, #1
	str	w8, [x26, #284]
	ldrh	w8, [x26, #278]
	strh	w8, [x26, #280]
	ldr	w8, [x23, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	sub	w1, w8, w9
	add	x0, sp, #208
	bl	_vm_decoded_function_at
	cbz	x0, LBB3_199
; %bb.92:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #208]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w1, w8, w9
	add	x3, sp, #176
	add	x4, sp, #248
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	mov	x2, x26
	bl	_propagate
	tbz	w0, #0, LBB3_200
; %bb.93:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x0, x26
	bl	_frame_free
	mov	w26, #1                         ; =0x1
	b	LBB3_133
LBB3_94:                                ;   in Loop: Header=BB3_64 Depth=1
	mov	w1, #0                          ; =0x0
LBB3_95:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x0, [x8]
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_affine_can_exit_scalar
	tbz	w0, #0, LBB3_191
LBB3_96:                                ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [x20, #4]
	cbz	w8, LBB3_63
; %bb.97:                               ;   in Loop: Header=BB3_64 Depth=1
	cmp	w8, #7
	b.ls	LBB3_101
; %bb.98:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x11, [sp, #144]                 ; 8-byte Folded Reload
	add	x9, x11, #22
	ldr	x12, [sp, #72]                  ; 8-byte Folded Reload
	add	x10, x12, x8
	add	x11, x11, x8
	add	x11, x11, #22
	cmp	x12, x11
	ccmp	x9, x10, #2, lo
	b.lo	LBB3_101
; %bb.99:                               ;   in Loop: Header=BB3_64 Depth=1
	cmp	w8, #64
	b.hs	LBB3_116
; %bb.100:                              ;   in Loop: Header=BB3_64 Depth=1
	mov	x9, #0                          ; =0x0
	b	LBB3_120
LBB3_101:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x9, #0                          ; =0x0
LBB3_102:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	add	x10, x10, x9
	add	x10, x10, #22
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	add	x11, x11, x9
	sub	x8, x8, x9
LBB3_103:                               ;   Parent Loop BB3_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x10], #1
	ldrb	w12, [x11]
	orr	w9, w12, w9
	strb	w9, [x11], #1
	subs	x8, x8, #1
	b.ne	LBB3_103
	b	LBB3_63
LBB3_104:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [x23, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	sub	w1, w8, w9
	add	x0, sp, #208
	bl	_vm_decoded_function_at
	cbz	x0, LBB3_194
; %bb.105:                              ;   in Loop: Header=BB3_64 Depth=1
	ldrh	w26, [x23, #48]
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
	ldrh	w9, [x9, #16]
	mov	w10, #48                        ; =0x30
	umaddl	x9, w9, w10, x8
	sub	x8, x9, #32
	lsr	x10, x26, #6
	stp	x9, x8, [sp, #56]               ; 16-byte Folded Spill
	ldr	x8, [x8, x10, lsl #3]
	ldurh	w25, [x9, #-36]
	mov	w9, #1                          ; =0x1
	lsl	x9, x9, x26
	stp	x9, x10, [sp, #16]              ; 16-byte Folded Spill
	and	x8, x8, x9
	cmp	x8, #0
	mov	w8, #65535                      ; =0xffff
	ccmp	w25, w8, #0, eq
	ccmp	w25, w26, #4, ne
	b.ne	LBB3_110
; %bb.106:                              ;   in Loop: Header=BB3_64 Depth=1
	mov	x27, x0
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_frame_clone
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	cbz	x0, LBB3_197
; %bb.107:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x1, x26
	bl	_match_refine
	cbz	w0, LBB3_197
; %bb.108:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #208]
	sub	x8, x27, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w1, w8, w9
	add	x3, sp, #176
	add	x4, sp, #248
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_propagate
	tbz	w0, #0, LBB3_202
; %bb.109:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_frame_free
LBB3_110:                               ;   in Loop: Header=BB3_64 Depth=1
	cmp	w25, w26
	b.eq	LBB3_63
; %bb.111:                              ;   in Loop: Header=BB3_64 Depth=1
	mov	w8, #65535                      ; =0xffff
	cmp	w25, w8
	b.eq	LBB3_123
; %bb.112:                              ;   in Loop: Header=BB3_64 Depth=1
	mov	w26, #1                         ; =0x1
	b	LBB3_133
LBB3_113:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x9, #-4294967296                ; =0xffffffff00000000
LBB3_114:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x0, [x10]
	orr	x1, x9, x8
	bl	_nvm_affine_can_resume
	cbz	w0, LBB3_182
; %bb.115:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldp	x0, x8, [x9]
	ldrb	w23, [x8, #4]
	ldrb	w9, [x8]
	ldr	w8, [x8, #8]
	orr	x1, x9, x8, lsl #32
	bl	_nvm_affine_type_is_owned
	cmp	w23, w0
	b.eq	LBB3_63
	b	LBB3_182
LBB3_116:                               ;   in Loop: Header=BB3_64 Depth=1
	and	x9, x8, #0xffffffc0
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	add	x10, x10, #70
	ldr	x11, [sp, #48]                  ; 8-byte Folded Reload
	mov	x12, x9
LBB3_117:                               ;   Parent Loop BB3_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x10, #-48]
	ldp	q2, q3, [x10, #-16]
	ldp	q4, q5, [x11, #-32]
	ldp	q6, q7, [x11]
	orr.16b	v0, v4, v0
	orr.16b	v1, v5, v1
	orr.16b	v2, v6, v2
	orr.16b	v3, v7, v3
	stp	q0, q1, [x11, #-32]
	stp	q2, q3, [x11], #64
	add	x10, x10, #64
	subs	x12, x12, #64
	b.ne	LBB3_117
; %bb.118:                              ;   in Loop: Header=BB3_64 Depth=1
	cmp	x9, x8
	b.eq	LBB3_63
; %bb.119:                              ;   in Loop: Header=BB3_64 Depth=1
	tst	x8, #0x38
	b.eq	LBB3_102
LBB3_120:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	x12, x9
	and	x9, x8, #0xfffffff8
	sub	x10, x12, x9
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	add	x11, x11, x12
	ldr	x13, [sp, #144]                 ; 8-byte Folded Reload
	add	x12, x13, x12
	add	x12, x12, #22
LBB3_121:                               ;   Parent Loop BB3_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	d0, [x12], #8
	ldr	d1, [x11]
	orr.8b	v0, v1, v0
	str	d0, [x11], #8
	adds	x10, x10, #8
	b.ne	LBB3_121
; %bb.122:                              ;   in Loop: Header=BB3_64 Depth=1
	cmp	x9, x8
	b.eq	LBB3_63
	b	LBB3_102
LBB3_123:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	w26, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldp	x11, x10, [sp, #16]             ; 16-byte Folded Reload
	ldr	x8, [x9, x10, lsl #3]
	orr	x8, x8, x11
	str	x8, [x9, x10, lsl #3]
LBB3_124:                               ;   Parent Loop BB3_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w1, [x8, #-40]
	add	x3, sp, #256
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	x2, x26
	bl	_union_fact_for_layout
	tbz	w0, #0, LBB3_126
; %bb.125:                              ;   in Loop: Header=BB3_124 Depth=2
	lsr	w8, w26, #6
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, w8, uxtw #3]
	lsr	x8, x8, x26
	tst	x8, #0x1
	cinc	w25, w25, eq
	csel	w27, w26, w27, eq
	add	w26, w26, #1
	cmp	w26, #256
	b.ne	LBB3_124
LBB3_126:                               ;   in Loop: Header=BB3_64 Depth=1
	ands	w8, w25, #0xffff
	b.eq	LBB3_137
; %bb.127:                              ;   in Loop: Header=BB3_64 Depth=1
	cmp	w8, #1
	b.ne	LBB3_129
; %bb.128:                              ;   in Loop: Header=BB3_64 Depth=1
	ldp	x9, x8, [sp, #56]               ; 16-byte Folded Reload
	sturh	w27, [x9, #-36]
	mov	w26, #1                         ; =0x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	b	LBB3_130
LBB3_129:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	w26, #1                         ; =0x1
LBB3_130:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	sub	w8, w8, #56
	cmp	w8, #2
	b.hi	LBB3_133
; %bb.131:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [x23, #8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	sub	w1, w8, w9
	add	x0, sp, #208
	bl	_vm_decoded_function_at
	cbz	x0, LBB3_193
; %bb.132:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #208]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w1, w8, w9
	add	x3, sp, #176
	add	x4, sp, #248
	ldp	x0, x2, [sp, #136]              ; 16-byte Folded Reload
	bl	_propagate
	cbz	w0, LBB3_186
LBB3_133:                               ;   in Loop: Header=BB3_64 Depth=1
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	cmp	w8, #56
	b.eq	LBB3_63
; %bb.134:                              ;   in Loop: Header=BB3_64 Depth=1
	cbz	w26, LBB3_63
; %bb.135:                              ;   in Loop: Header=BB3_64 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	w1, w8, #1
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	cmp	w1, w8
	b.eq	LBB3_192
; %bb.136:                              ;   in Loop: Header=BB3_64 Depth=1
	add	x3, sp, #176
	add	x4, sp, #248
	ldp	x0, x2, [sp, #136]              ; 16-byte Folded Reload
	bl	_propagate
	cbnz	w0, LBB3_63
	b	LBB3_186
LBB3_137:                               ;   in Loop: Header=BB3_64 Depth=1
	mov	w26, #0                         ; =0x0
	b	LBB3_130
LBB3_138:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
Lloh54:
	adrp	x8, l_.str.17@PAGE
Lloh55:
	add	x8, x8, l_.str.17@PAGEOFF
LBB3_139:
	str	x8, [sp, #248]
LBB3_140:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	cbnz	x8, LBB3_153
LBB3_141:
	mov	x0, #0                          ; =0x0
LBB3_142:
	bl	_free
	ldr	x0, [sp, #176]
	bl	_free
	ldr	x0, [sp, #184]
	bl	_free
	add	x0, sp, #208
	bl	_vm_decoded_function_free
	ldr	x8, [sp, #248]
	cbz	x8, LBB3_144
; %bb.143:
	add	x9, sp, #2576
	str	x8, [sp]
Lloh56:
	adrp	x2, l_.str.37@PAGE
Lloh57:
	add	x2, x2, l_.str.37@PAGEOFF
	add	x0, x9, #16
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB3_144:
	cmp	w21, #7
	b.hi	LBB3_148
; %bb.145:
	cbnz	x22, LBB3_148
; %bb.146:
	ldrb	w8, [x20]
	tbz	w8, #0, LBB3_148
; %bb.147:
	mov	w8, #208                        ; =0xd0
	ldp	q1, q0, [x28, #128]
	umaddl	x8, w21, w8, x20
	str	q0, [x8, #6320]
	ldp	q0, q2, [x28, #160]
	str	q0, [x8, #6336]
	str	q2, [x8, #6352]
	ldr	q0, [x28, #192]
	str	q0, [x8, #6368]
	ldp	q2, q0, [x28, #64]
	str	q0, [x8, #6256]
	ldp	q0, q3, [x28, #96]
	str	q0, [x8, #6272]
	str	q3, [x8, #6288]
	str	q1, [x8, #6304]
	ldp	q1, q0, [x28]
	str	q0, [x8, #6192]
	ldp	q0, q3, [x28, #32]
	str	q0, [x8, #6208]
	str	q3, [x8, #6224]
	str	q2, [x8, #6240]
	add	x9, x20, w21, uxtw
	mov	w10, #6168                      ; =0x1818
	str	q1, [x8, #6176]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, x10]
LBB3_148:
	ldp	q0, q1, [x28, #160]
	stp	q0, q1, [x19, #160]
	ldr	q0, [x28, #192]
	str	q0, [x19, #192]
	ldp	q0, q1, [x28, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x28, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x28, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x28, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x28]
	stp	q1, q0, [x19]
Lloh58:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh59:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh60:
	ldr	x8, [x8]
	ldur	x9, [x29, #-104]
	cmp	x8, x9
	b.ne	LBB3_13
LBB3_149:
	add	sp, sp, #2816
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB3_150:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
Lloh61:
	adrp	x8, l_.str.13@PAGE
Lloh62:
	add	x8, x8, l_.str.13@PAGEOFF
	b	LBB3_52
LBB3_151:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
Lloh63:
	adrp	x8, l_.str.18@PAGE
Lloh64:
	add	x8, x8, l_.str.18@PAGEOFF
LBB3_152:
	str	x8, [sp, #248]
LBB3_153:
	ldr	w8, [sp, #216]
	cbz	w8, LBB3_158
; %bb.154:
	mov	x23, #0                         ; =0x0
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	b	LBB3_156
LBB3_155:                               ;   in Loop: Header=BB3_156 Depth=1
	add	x23, x23, #1
	cmp	x23, x8
	b.hs	LBB3_142
LBB3_156:                               ; =>This Inner Loop Header: Depth=1
	ldr	x24, [x0, x23, lsl #3]
	cbz	x24, LBB3_155
; %bb.157:                              ;   in Loop: Header=BB3_156 Depth=1
	ldr	x0, [x24]
	bl	_nvm_affine_state_free
	ldr	x0, [x24, #8]
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #216]
	b	LBB3_155
LBB3_158:
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	b	LBB3_142
LBB3_159:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_nvm_affine_state_free
	mov	x0, #0                          ; =0x0
Lloh65:
	adrp	x8, l_.str.16@PAGE
Lloh66:
	add	x8, x8, l_.str.16@PAGEOFF
	b	LBB3_21
LBB3_160:
	stp	wzr, wzr, [sp, #92]             ; 8-byte Folded Spill
	str	wzr, [sp, #128]                 ; 4-byte Folded Spill
LBB3_161:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	ldr	w8, [x20, #4]
	cbz	w8, LBB3_166
; %bb.162:
	add	x9, x20, x24, lsl #8
	add	x9, x9, #2056
LBB3_163:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cbz	w10, LBB3_171
; %bb.164:                              ;   in Loop: Header=BB3_163 Depth=1
	cmp	w21, #0
	cset	w11, ne
	orr	w10, w11, w10
	tbz	w10, #0, LBB3_171
; %bb.165:                              ;   in Loop: Header=BB3_163 Depth=1
	subs	x8, x8, #1
	b.ne	LBB3_163
LBB3_166:
	cbnz	x22, LBB3_188
; %bb.167:
	ldr	x8, [x20, #6160]
	cbz	x8, LBB3_188
; %bb.168:
	ldr	w8, [x20, #6152]
	cmp	w21, w8
	b.ne	LBB3_188
; %bb.169:
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	mov	w1, #12                         ; =0xc
	bl	_calloc
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	cbz	x0, LBB3_189
; %bb.170:
	mov	x23, #0                         ; =0x0
	ldp	x8, x9, [sp, #136]              ; 16-byte Folded Reload
	add	x26, x9, #4
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	ldr	x24, [sp, #120]                 ; 8-byte Folded Reload
	b	LBB3_174
LBB3_171:
Lloh67:
	adrp	x8, l_.str.34@PAGE
Lloh68:
	add	x8, x8, l_.str.34@PAGEOFF
	b	LBB3_139
LBB3_172:                               ;   in Loop: Header=BB3_174 Depth=1
	ldrh	w8, [sp, #166]
	strh	w8, [x26]
LBB3_173:                               ;   in Loop: Header=BB3_174 Depth=1
	add	x26, x26, #12
	add	x23, x23, #104
	subs	x24, x24, #1
	b.eq	LBB3_187
LBB3_174:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #208]
	ldr	w9, [x8, x23]
	str	w9, [x26, #4]
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x27, [x9], #8
	str	x9, [sp, #152]                  ; 8-byte Folded Spill
	cbz	x27, LBB3_173
; %bb.175:                              ;   in Loop: Header=BB3_174 Depth=1
	ldrb	w9, [x27, #18]
	cmp	w9, #1
	b.ne	LBB3_173
; %bb.176:                              ;   in Loop: Header=BB3_174 Depth=1
	sturb	w9, [x26, #-4]
	ldrh	w9, [x27, #16]
	sturh	w9, [x26, #-2]
	cbz	x9, LBB3_178
; %bb.177:                              ;   in Loop: Header=BB3_174 Depth=1
	ldr	x10, [x27, #8]
	sub	w9, w9, #1
	mov	w11, #48                        ; =0x30
	umull	x9, w9, w11
	ldrb	w9, [x10, x9]
LBB3_178:                               ;   in Loop: Header=BB3_174 Depth=1
	sturb	w9, [x26, #-3]
	add	x8, x8, x23
	ldrb	w9, [x8, #40]
	cmp	w9, #14
	b.ne	LBB3_173
; %bb.179:                              ;   in Loop: Header=BB3_174 Depth=1
	strh	wzr, [sp, #166]
	ldrh	w25, [x8, #48]
	ldr	x0, [x27]
	add	x2, sp, #168
	mov	x1, x25
	bl	_nvm_affine_local_type
	cbz	w0, LBB3_181
; %bb.180:                              ;   in Loop: Header=BB3_174 Depth=1
	ldr	x0, [x27]
	add	x2, sp, #256
	add	x4, sp, #166
	mov	x1, x25
	mov	w3, #256                        ; =0x100
	bl	_nvm_affine_owned_local_fields
	cbnz	w0, LBB3_172
LBB3_181:
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_free
Lloh69:
	adrp	x8, l_.str.36@PAGE
Lloh70:
	add	x8, x8, l_.str.36@PAGEOFF
	b	LBB3_152
LBB3_182:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh71:
	adrp	x8, l_.str.24@PAGE
Lloh72:
	add	x8, x8, l_.str.24@PAGEOFF
	b	LBB3_205
LBB3_183:
	ldp	w9, w8, [sp, #88]               ; 8-byte Folded Reload
	str	w8, [x28, #4]
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	stp	w8, w9, [x28, #8]
Lloh73:
	adrp	x8, l_.str.20@PAGE
Lloh74:
	add	x8, x8, l_.str.20@PAGEOFF
	b	LBB3_139
LBB3_184:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh75:
	adrp	x8, l_.str.21@PAGE
Lloh76:
	add	x8, x8, l_.str.21@PAGEOFF
	b	LBB3_152
LBB3_185:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh77:
	adrp	x8, l_.str.25@PAGE
Lloh78:
	add	x8, x8, l_.str.25@PAGEOFF
	b	LBB3_205
LBB3_186:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	b	LBB3_206
LBB3_187:
	ldr	x0, [x20, #6160]
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	add	x8, x8, x8, lsl #1
	lsl	x2, x8, #2
	ldr	x23, [sp, #144]                 ; 8-byte Folded Reload
	mov	x1, x23
	bl	_memcpy
	mov	x0, x23
	bl	_free
LBB3_188:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #2576]
	str	wzr, [x28, #4]
	str	xzr, [sp, #248]
	b	LBB3_140
LBB3_189:
Lloh79:
	adrp	x8, l_.str.35@PAGE
Lloh80:
	add	x8, x8, l_.str.35@PAGEOFF
	b	LBB3_139
LBB3_190:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh81:
	adrp	x8, l_.str.22@PAGE
Lloh82:
	add	x8, x8, l_.str.22@PAGEOFF
	b	LBB3_205
LBB3_191:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh83:
	adrp	x8, l_.str.23@PAGE
Lloh84:
	add	x8, x8, l_.str.23@PAGEOFF
	b	LBB3_205
LBB3_192:
Lloh85:
	adrp	x8, l_.str.33@PAGE
Lloh86:
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
LBB3_193:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	b	LBB3_205
LBB3_194:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh87:
	adrp	x8, l_.str.30@PAGE
Lloh88:
	add	x8, x8, l_.str.30@PAGEOFF
	b	LBB3_205
LBB3_195:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh89:
	adrp	x8, l_.str.26@PAGE
Lloh90:
	add	x8, x8, l_.str.26@PAGEOFF
	b	LBB3_205
LBB3_196:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
Lloh91:
	adrp	x8, l_.str.27@PAGE
Lloh92:
	add	x8, x8, l_.str.27@PAGEOFF
	b	LBB3_205
LBB3_197:
	mov	x23, #0                         ; =0x0
	b	LBB3_203
LBB3_198:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	mov	x0, x26
	bl	_frame_free
Lloh93:
	adrp	x8, l_.str.28@PAGE
Lloh94:
	add	x8, x8, l_.str.28@PAGEOFF
	b	LBB3_205
LBB3_199:
	mov	x23, #0                         ; =0x0
	b	LBB3_201
LBB3_200:
	ldr	x23, [sp, #248]
LBB3_201:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	mov	x0, x26
	bl	_frame_free
Lloh95:
	adrp	x8, l_.str.29@PAGE
Lloh96:
	add	x8, x8, l_.str.29@PAGEOFF
	b	LBB3_204
LBB3_202:
	ldr	x23, [sp, #248]
LBB3_203:
	ldr	w9, [sp, #128]                  ; 4-byte Folded Reload
	ldp	w10, w8, [sp, #92]              ; 8-byte Folded Reload
	str	w10, [x28, #4]
	stp	w8, w9, [x28, #8]
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_frame_free
Lloh97:
	adrp	x8, l_.str.31@PAGE
Lloh98:
	add	x8, x8, l_.str.31@PAGEOFF
LBB3_204:
	cmp	x23, #0
	csel	x8, x8, x23, eq
LBB3_205:
	str	x8, [sp, #248]
LBB3_206:
	ldr	x23, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x0, [x23]
	bl	_nvm_affine_state_free
	ldr	x0, [x23, #8]
	bl	_free
	mov	x0, x23
	bl	_free
	b	LBB3_140
	.loh AdrpAdd	Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh20, Lloh21, Lloh22
	.loh AdrpLdrGotLdr	Lloh25, Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpLdrGotLdr	Lloh58, Lloh59, Lloh60
	.loh AdrpAdd	Lloh61, Lloh62
	.loh AdrpAdd	Lloh63, Lloh64
	.loh AdrpAdd	Lloh65, Lloh66
	.loh AdrpAdd	Lloh67, Lloh68
	.loh AdrpAdd	Lloh69, Lloh70
	.loh AdrpAdd	Lloh71, Lloh72
	.loh AdrpAdd	Lloh73, Lloh74
	.loh AdrpAdd	Lloh75, Lloh76
	.loh AdrpAdd	Lloh77, Lloh78
	.loh AdrpAdd	Lloh79, Lloh80
	.loh AdrpAdd	Lloh81, Lloh82
	.loh AdrpAdd	Lloh83, Lloh84
	.loh AdrpAdd	Lloh85, Lloh86
	.loh AdrpAdd	Lloh87, Lloh88
	.loh AdrpAdd	Lloh89, Lloh90
	.loh AdrpAdd	Lloh91, Lloh92
	.loh AdrpAdd	Lloh93, Lloh94
	.loh AdrpAdd	Lloh95, Lloh96
	.loh AdrpAdd	Lloh97, Lloh98
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_global_proof
_effect_global_proof:                   ; @effect_global_proof
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1248
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	x20, x8
Lloh99:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh100:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh101:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20, #176]
	stp	q0, q0, [x20, #144]
	stp	q0, q0, [x20, #112]
	stp	q0, q0, [x20, #80]
	stp	q0, q0, [x20, #48]
	stp	q0, q0, [x20, #16]
	str	q0, [x20]
	stp	q0, q0, [sp, #400]
	stp	q0, q0, [sp, #368]
	stp	q0, q0, [sp, #336]
	stp	q0, q0, [sp, #304]
	stp	q0, q0, [sp, #272]
	stp	q0, q0, [sp, #240]
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	add	x8, x1, #8
	stp	x0, x8, [sp, #64]
	ldr	w23, [x1, #4]
	str	w23, [sp, #80]
	movi.2d	v0, #0xffffffffffffffff
	str	d0, [sp, #416]
	mov	w0, #65536                      ; =0x10000
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x22, x0
	str	x0, [sp, #392]
	mov	w0, #65536                      ; =0x10000
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x21, x0
	str	x0, [sp, #400]
	mov	w0, #65536                      ; =0x10000
	mov	w1, #4                          ; =0x4
	bl	_calloc
	str	x0, [sp, #408]
	cbz	x22, LBB4_12
; %bb.1:
	cbz	x21, LBB4_12
; %bb.2:
	cbz	x0, LBB4_12
; %bb.3:
	ldr	w8, [x19, #272]
	cbz	w8, LBB4_8
; %bb.4:
	mov	x21, #0                         ; =0x0
	add	x8, sp, #64
	add	x22, x8, #24
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #436
	mov	x0, x19
	mov	x1, x21
	mov	x2, x22
	bl	_vm_decode_function
	cbz	w0, LBB4_13
; %bb.6:                                ;   in Loop: Header=BB4_5 Depth=1
	add	x21, x21, #1
	ldr	w8, [x19, #272]
	add	x22, x22, #32
	cmp	x21, x8
	b.lo	LBB4_5
; %bb.7:
	ldr	w23, [sp, #80]
LBB4_8:
	mov	w2, w23
	add	x0, sp, #976
	mov	w1, #1                          ; =0x1
	mov	w3, #256                        ; =0x100
	bl	___memset_chk
	add	x0, sp, #64
	mov	w1, #-1                         ; =0xffffffff
	mov	w2, #0                          ; =0x0
	mov	w3, #-1                         ; =0xffffffff
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #-1                         ; =0xffffffff
	bl	_eg_frame
	cmn	w0, #1
	b.eq	LBB4_15
; %bb.9:
	mov	x1, x0
	add	x0, sp, #64
	add	x4, sp, #976
	mov	w2, #0                          ; =0x0
	mov	w3, #-1                         ; =0xffffffff
	bl	_eg_queue
	cbz	w0, LBB4_15
; %bb.10:
	ldr	w21, [sp, #416]
	cmn	w21, #1
	b.ne	LBB4_22
LBB4_11:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20]
	ldr	w8, [sp, #376]
	stp	wzr, w8, [x20, #4]
	ldr	x8, [sp, #424]
	cbnz	x8, LBB4_16
	b	LBB4_17
LBB4_12:
Lloh102:
	adrp	x8, l_.str.145@PAGE
Lloh103:
	add	x8, x8, l_.str.145@PAGEOFF
	b	LBB4_14
LBB4_13:
Lloh104:
	adrp	x8, l_.str.146@PAGE
Lloh105:
	add	x8, x8, l_.str.146@PAGEOFF
LBB4_14:
	str	x8, [sp, #424]
LBB4_15:
	ldr	x8, [sp, #424]
	cbz	x8, LBB4_17
LBB4_16:
	str	x8, [sp]
Lloh106:
	adrp	x2, l_.str.37@PAGE
Lloh107:
	add	x2, x2, l_.str.37@PAGEOFF
	add	x0, x20, #16
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB4_17:
	ldr	w8, [x19, #272]
	cbz	w8, LBB4_20
; %bb.18:
	mov	x21, #0                         ; =0x0
	add	x8, sp, #64
	add	x20, x8, #24
LBB4_19:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	bl	_vm_decoded_function_free
	add	x21, x21, #1
	ldr	w8, [x19, #272]
	add	x20, x20, #32
	cmp	x21, x8
	b.lo	LBB4_19
LBB4_20:
	ldr	x0, [sp, #344]
	bl	_free
	ldr	x0, [sp, #352]
	bl	_free
	ldr	x0, [sp, #360]
	bl	_free
	ldr	x0, [sp, #392]
	bl	_free
	ldr	x0, [sp, #400]
	bl	_free
	ldr	x0, [sp, #408]
	bl	_free
	ldur	x8, [x29, #-96]
Lloh108:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh109:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh110:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_110
; %bb.21:
	add	sp, sp, #1248
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB4_22:
	mov	w28, #0                         ; =0x0
	add	x8, sp, #64
	add	x9, x8, #24
	add	x8, sp, #436
	add	x8, x8, #21
	stp	x9, x8, [sp, #16]               ; 16-byte Folded Spill
	mov	w24, #280                       ; =0x118
	b	LBB4_26
LBB4_23:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB4_106
LBB4_24:                                ;   in Loop: Header=BB4_26 Depth=1
	add	x0, sp, #64
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	w2, w8, #1
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x3, x22
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	bl	_eg_queue
	cbz	w0, LBB4_99
LBB4_25:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	w21, [sp, #416]
	cmn	w21, #1
	ldr	w28, [sp, #52]                  ; 4-byte Folded Reload
	mov	w24, #280                       ; =0x118
	b.eq	LBB4_101
LBB4_26:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_65 Depth 2
                                        ;     Child Loop BB4_85 Depth 2
                                        ;     Child Loop BB4_49 Depth 2
	ldr	x23, [sp, #360]
	madd	x8, x21, x24, x23
	ldp	w25, w22, [x8]
	ldr	x26, [x8, #8]
	ldr	w27, [x8, #16]
	add	x0, sp, #716
	add	x1, x8, #20
	mov	w2, #260                        ; =0x104
	bl	_memcpy
	str	w27, [sp, #416]
	cmn	w27, #1
	b.ne	LBB4_28
; %bb.27:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #420]
LBB4_28:                                ;   in Loop: Header=BB4_26 Depth=1
	madd	x8, x21, x24, x23
	strb	wzr, [x8, #20]
	ldr	x21, [sp, #344]
	add	x23, x21, x25, lsl #5
	mov	x10, x25
	ldr	w25, [x23, #4]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, x25, lsl #5
	stp	x8, x22, [sp, #32]              ; 16-byte Folded Spill
	ldr	x8, [x8]
	mov	w9, #104                        ; =0x68
	umaddl	x24, w22, w9, x8
	ldr	w8, [x24]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	add	w28, w28, #1
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
	str	w10, [sp, #436]
	str	w22, [sp, #440]
	add	x8, sp, #189
	stur	x26, [x8, #255]
	str	w27, [sp, #452]
	add	x8, sp, #436
	add	x0, x8, #20
	add	x1, sp, #716
	mov	w2, #260                        ; =0x104
	bl	_memcpy
	ldr	w9, [x23, #20]
	mov	x10, x24
	ldrb	w8, [x24, #40]
	cmp	w8, #106
	mov	x22, x26
	str	w28, [sp, #52]                  ; 4-byte Folded Spill
	b.gt	LBB4_36
; %bb.29:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #58
	mov	w27, #24                        ; =0x18
	b.gt	LBB4_68
; %bb.30:                               ;   in Loop: Header=BB4_26 Depth=1
	sub	w9, w8, #56
	cmp	w9, #3
	b.lo	LBB4_54
; %bb.31:                               ;   in Loop: Header=BB4_26 Depth=1
	sub	w9, w8, #18
	cmp	w9, #2
	b.hs	LBB4_24
; %bb.32:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w9, [x10, #48]
	ldr	w10, [sp, #80]
	cmp	w9, w10
	b.hs	LBB4_104
; %bb.33:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #18
	b.eq	LBB4_23
; %bb.34:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [sp, #72]
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	lsl	w8, w8, #1
	eor	w10, w8, #0x2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, x9]
	tst	w10, w8
	b.ne	LBB4_106
; %bb.35:                               ;   in Loop: Header=BB4_26 Depth=1
	orr	w8, w8, w8, lsl #1
	mov	w10, #10                        ; =0xa
	and	w8, w8, w10
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	strb	w8, [x10, x9]
	b	LBB4_24
LBB4_36:                                ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #165
	mov	w27, #24                        ; =0x18
	b.gt	LBB4_59
; %bb.37:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #107
	b.eq	LBB4_54
; %bb.38:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #163
	b.eq	LBB4_25
; %bb.39:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #165
	b.ne	LBB4_24
; %bb.40:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	x21, x10
	cmn	w22, #1
	b.eq	LBB4_42
; %bb.41:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [sp, #352]
	umaddl	x8, w22, w27, x8
	ldr	w8, [x8, #16]
	cmp	w8, #1024
	b.eq	LBB4_25
LBB4_42:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	w8, [x21, #8]
	ldr	x9, [sp, #64]
	ldr	x9, [x9, #256]
	umaddl	x9, w25, w27, x9
	ldr	w9, [x9, #8]
	subs	w1, w8, w9
	ldr	x23, [sp, #32]                  ; 8-byte Folded Reload
	b.lo	LBB4_107
; %bb.43:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	x0, x23
	bl	_vm_decoded_function_at
	cbz	x0, LBB4_107
; %bb.44:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [x23]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w24, w8, w9
	cmn	w24, #1
	b.eq	LBB4_99
; %bb.45:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w21, [x21, #48]
	mov	w8, #40389                      ; =0x9dc5
	movk	w8, #33052, lsl #16
	eor	w8, w22, w8
	mov	w9, #403                        ; =0x193
	movk	w9, #256, lsl #16
	mul	w8, w8, w9
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	eor	w8, w8, w9
	mov	w9, #403                        ; =0x193
	mul	w8, w8, w9
	eor	w8, w21, w8
	mul	w8, w8, w9
	eor	w8, w8, w24
	mov	w9, #31337                      ; =0x7a69
	mul	w8, w8, w9
	and	w25, w8, #0xffff
	ldr	x8, [sp, #400]
	ldr	x0, [sp, #352]
	ldr	w8, [x8, w25, uxtw #2]
	cbnz	w8, LBB4_49
LBB4_46:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	w8, [sp, #372]
	ldr	w9, [sp, #384]
	cmp	w8, w9
	b.hs	LBB4_91
; %bb.47:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w26, [sp, #52]                  ; 4-byte Folded Reload
	cbnz	x0, LBB4_94
	b	LBB4_109
LBB4_48:                                ;   in Loop: Header=BB4_49 Depth=2
	umaddl	x8, w8, w27, x0
	ldr	w8, [x8, #20]
	cbz	w8, LBB4_46
LBB4_49:                                ;   Parent Loop BB4_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	w8, w8, #1
	umaddl	x9, w8, w27, x0
	ldr	w10, [x9]
	cmp	w10, w22
	b.ne	LBB4_48
; %bb.50:                               ;   in Loop: Header=BB4_49 Depth=2
	ldr	w10, [x9, #4]
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	cmp	w10, w11
	b.ne	LBB4_48
; %bb.51:                               ;   in Loop: Header=BB4_49 Depth=2
	ldr	w10, [x9, #8]
	cmp	w10, w21
	b.ne	LBB4_48
; %bb.52:                               ;   in Loop: Header=BB4_49 Depth=2
	ldr	w9, [x9, #12]
	cmp	w9, w24
	b.ne	LBB4_48
; %bb.53:                               ;   in Loop: Header=BB4_26 Depth=1
	str	w8, [sp, #444]
	mov	x22, x8
	b	LBB4_24
LBB4_54:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	w8, [x10, #8]
	ldr	x9, [sp, #64]
	ldr	x9, [x9, #256]
	umaddl	x9, w25, w27, x9
	ldr	w9, [x9, #8]
	subs	w1, w8, w9
	ldr	x23, [sp, #32]                  ; 8-byte Folded Reload
	b.lo	LBB4_102
; %bb.55:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	x21, x10
	mov	x0, x23
	bl	_vm_decoded_function_at
	cbz	x0, LBB4_102
; %bb.56:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [x23]
	sub	x8, x0, x8
	lsr	x8, x8, #3
	mov	w9, #20165                      ; =0x4ec5
	movk	w9, #50412, lsl #16
	mul	w2, w8, w9
	cmn	w2, #1
	b.eq	LBB4_99
; %bb.57:                               ;   in Loop: Header=BB4_26 Depth=1
	add	x0, sp, #64
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x3, x22
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	bl	_eg_queue
	cbz	w0, LBB4_99
; %bb.58:                               ;   in Loop: Header=BB4_26 Depth=1
	ldrb	w8, [x21, #40]
	cmp	w8, #56
	b.ne	LBB4_24
	b	LBB4_25
LBB4_59:                                ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #168
	b.eq	LBB4_77
; %bb.60:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #167
	mov	x21, x10
	b.eq	LBB4_82
; %bb.61:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #166
	b.ne	LBB4_24
; %bb.62:                               ;   in Loop: Header=BB4_26 Depth=1
	ldrh	w8, [x21, #48]
	cbz	w8, LBB4_24
; %bb.63:                               ;   in Loop: Header=BB4_26 Depth=1
	cmn	w22, #1
	ldr	w13, [sp, #52]                  ; 4-byte Folded Reload
	ldr	x14, [sp, #56]                  ; 8-byte Folded Reload
	b.eq	LBB4_100
; %bb.64:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	w9, #0                          ; =0x0
	ldr	x10, [sp, #352]
LBB4_65:                                ;   Parent Loop BB4_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	umaddl	x11, w22, w27, x10
	ldr	w12, [x11, #4]
	cmp	w12, w14
	b.ne	LBB4_100
; %bb.66:                               ;   in Loop: Header=BB4_65 Depth=2
	ldr	w22, [x11]
	add	w9, w9, #1
	cmp	w9, w8
	b.hs	LBB4_98
; %bb.67:                               ;   in Loop: Header=BB4_65 Depth=2
	cmn	w22, #1
	b.ne	LBB4_65
	b	LBB4_100
LBB4_68:                                ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #59
	b.eq	LBB4_72
; %bb.69:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w8, #61
	b.ne	LBB4_24
; %bb.70:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w8, [x23, #16]
	add	x8, x21, x8, lsl #5
	ldr	w1, [x8]
	cmn	w1, #1
	b.eq	LBB4_25
; %bb.71:                               ;   in Loop: Header=BB4_26 Depth=1
	ldp	w2, w3, [x8, #8]
	b	LBB4_80
LBB4_72:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	w2, [x10, #48]
	cbz	w2, LBB4_105
; %bb.73:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #272]
	cmp	w2, w8
	b.hs	LBB4_105
; %bb.74:                               ;   in Loop: Header=BB4_26 Depth=1
	cmp	w9, #1024
	b.eq	LBB4_25
; %bb.75:                               ;   in Loop: Header=BB4_26 Depth=1
	add	x0, sp, #64
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	w3, w8, #1
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x4, x22
	mov	w5, #-1                         ; =0xffffffff
	bl	_eg_frame
	cmn	w0, #1
	b.eq	LBB4_99
; %bb.76:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	x1, x0
	add	x0, sp, #64
	mov	w2, #0                          ; =0x0
	mov	x3, x22
	b	LBB4_81
LBB4_77:                                ;   in Loop: Header=BB4_26 Depth=1
	ldrb	w8, [x23, #28]
	tbz	w8, #0, LBB4_108
; %bb.78:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w1, [x23]
	cmn	w1, #1
	b.eq	LBB4_25
; %bb.79:                               ;   in Loop: Header=BB4_26 Depth=1
	ldp	w2, w3, [x23, #8]
LBB4_80:                                ;   in Loop: Header=BB4_26 Depth=1
	add	x0, sp, #64
LBB4_81:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	bl	_eg_queue
	tbnz	w0, #0, LBB4_25
	b	LBB4_99
LBB4_82:                                ;   in Loop: Header=BB4_26 Depth=1
	str	w9, [sp, #32]                   ; 4-byte Folded Spill
	cmn	w22, #1
	b.eq	LBB4_25
; %bb.83:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	x8, [sp, #352]
	mov	x9, x22
	b	LBB4_85
LBB4_84:                                ;   in Loop: Header=BB4_85 Depth=2
	ldr	x8, [sp, #352]
	mov	w27, #24                        ; =0x18
	umull	x9, w23, w27
	ldr	w9, [x8, x9]
	cmn	w9, #1
	b.eq	LBB4_25
LBB4_85:                                ;   Parent Loop BB4_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x25, [sp, #64]
	ldr	w28, [x21, #48]
	mov	w23, w9
	umaddl	x8, w9, w27, x8
	ldr	w26, [x8, #8]
	mov	x0, x25
	mov	x1, x28
	bl	_nvm_get_string
	mov	x24, x0
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_get_string
	cmp	x24, #0
	ccmp	x0, #0, #4, ne
	b.eq	LBB4_84
; %bb.86:                               ;   in Loop: Header=BB4_85 Depth=2
	mov	x27, x0
	mov	x0, x25
	mov	x1, x28
	bl	_nvm_get_string_len
	mov	x28, x0
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_get_string_len
	cmp	w28, w0
	b.ne	LBB4_84
; %bb.87:                               ;   in Loop: Header=BB4_85 Depth=2
	mov	x0, x24
	mov	x1, x27
	bl	_strcmp
	cbnz	w0, LBB4_84
; %bb.88:                               ;   in Loop: Header=BB4_26 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	cmp	w8, #1024
	mov	w10, #24                        ; =0x18
	b.eq	LBB4_25
; %bb.89:                               ;   in Loop: Header=BB4_26 Depth=1
	ldp	x9, x8, [sp, #344]
	umaddl	x8, w23, w10, x8
	ldr	w10, [x8, #4]
	ldr	w24, [x8, #12]
	add	x8, x9, x10, lsl #5
	ldr	w2, [x8, #4]
	ldr	w5, [x8, #16]
	add	x0, sp, #64
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	w3, w8, #1
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x4, x22
	bl	_eg_frame
	cmn	w0, #1
	b.eq	LBB4_99
; %bb.90:                               ;   in Loop: Header=BB4_26 Depth=1
	mov	x1, x0
	add	x0, sp, #64
	mov	x2, x24
	mov	x3, x22
	b	LBB4_81
LBB4_91:                                ;   in Loop: Header=BB4_26 Depth=1
	lsr	w8, w8, #18
	ldr	w26, [sp, #52]                  ; 4-byte Folded Reload
	cbnz	w8, LBB4_109
; %bb.92:                               ;   in Loop: Header=BB4_26 Depth=1
	lsl	w8, w9, #1
	cmp	w8, #64, lsl #12                ; =262144
	mov	w10, #262144                    ; =0x40000
	csel	w8, w8, w10, lo
	cmp	w9, #0
	mov	w9, #32                         ; =0x20
	csel	w23, w9, w8, eq
	add	w8, w23, w23, lsl #1
	lsl	w1, w8, #3
	bl	_realloc
	cbz	x0, LBB4_109
; %bb.93:                               ;   in Loop: Header=BB4_26 Depth=1
	str	w23, [sp, #384]
	ldr	w8, [sp, #372]
LBB4_94:                                ;   in Loop: Header=BB4_26 Depth=1
	str	x0, [sp, #352]
	add	w9, w8, #1
	str	w9, [sp, #372]
	cmn	w22, #1
	b.eq	LBB4_96
; %bb.95:                               ;   in Loop: Header=BB4_26 Depth=1
	umaddl	x10, w22, w27, x0
	ldr	w10, [x10, #16]
	add	w10, w10, #1
	b	LBB4_97
LBB4_96:                                ;   in Loop: Header=BB4_26 Depth=1
	mov	w10, #1                         ; =0x1
LBB4_97:                                ;   in Loop: Header=BB4_26 Depth=1
	ldr	x11, [sp, #400]
	ldr	w12, [x11, w25, uxtw #2]
	umaddl	x13, w8, w27, x0
	ldr	x14, [sp, #56]                  ; 8-byte Folded Reload
	stp	w22, w14, [x13]
	stp	w21, w24, [x13, #8]
	stp	w10, w12, [x13, #16]
	str	w9, [x11, w25, uxtw #2]
	str	w8, [sp, #444]
	mov	x22, x8
	cmn	w8, #1
	b.ne	LBB4_24
	b	LBB4_99
LBB4_98:                                ;   in Loop: Header=BB4_26 Depth=1
	str	w22, [sp, #444]
	b	LBB4_24
LBB4_99:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [x20, #12]
	ldr	x8, [sp, #424]
	cbnz	x8, LBB4_16
	b	LBB4_17
LBB4_100:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	str	w13, [x20, #12]
Lloh111:
	adrp	x8, l_.str.154@PAGE
Lloh112:
	add	x8, x8, l_.str.154@PAGEOFF
	b	LBB4_14
LBB4_101:
	str	w28, [x20, #12]
	b	LBB4_11
LBB4_102:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	str	w28, [x20, #12]
LBB4_103:
Lloh113:
	adrp	x8, l_.str.155@PAGE
Lloh114:
	add	x8, x8, l_.str.155@PAGEOFF
	b	LBB4_14
LBB4_104:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	str	w28, [x20, #12]
Lloh115:
	adrp	x8, l_.str.151@PAGE
Lloh116:
	add	x8, x8, l_.str.151@PAGEOFF
	b	LBB4_14
LBB4_105:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [x20, #12]
Lloh117:
	adrp	x8, l_.str.153@PAGE
Lloh118:
	add	x8, x8, l_.str.153@PAGEOFF
	b	LBB4_14
LBB4_106:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [x20, #12]
Lloh119:
	adrp	x8, l_.str.152@PAGE
Lloh120:
	add	x8, x8, l_.str.152@PAGEOFF
	b	LBB4_14
LBB4_107:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [x20, #12]
	b	LBB4_103
LBB4_108:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	str	w28, [x20, #12]
Lloh121:
	adrp	x8, l_.str.150@PAGE
Lloh122:
	add	x8, x8, l_.str.150@PAGEOFF
	b	LBB4_14
LBB4_109:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x20, #4]
	str	w26, [x20, #12]
Lloh123:
	adrp	x8, l_.str.156@PAGE
Lloh124:
	add	x8, x8, l_.str.156@PAGEOFF
	b	LBB4_14
LBB4_110:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh99, Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpLdrGotLdr	Lloh108, Lloh109, Lloh110
	.loh AdrpAdd	Lloh111, Lloh112
	.loh AdrpAdd	Lloh113, Lloh114
	.loh AdrpAdd	Lloh115, Lloh116
	.loh AdrpAdd	Lloh117, Lloh118
	.loh AdrpAdd	Lloh119, Lloh120
	.loh AdrpAdd	Lloh121, Lloh122
	.loh AdrpAdd	Lloh123, Lloh124
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_analyze_instructions ; -- Begin function nvm_affine_analyze_instructions
	.globl	_nvm_affine_analyze_instructions
	.p2align	2
_nvm_affine_analyze_instructions:       ; @nvm_affine_analyze_instructions
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #16272                      ; =0x3f90
Lloh125:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh126:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #3984
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh127:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh128:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh129:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cbz	x2, LBB5_5
; %bb.1:
	mov	x23, x3
	mov	w8, #-4097                      ; =0xffffefff
	add	w8, w3, w8
	cmn	w8, #1, lsl #12                 ; =4096
	b.lo	LBB5_5
; %bb.2:
	mov	x20, x2
	mov	x22, x0
	mov	x26, x1
	add	x0, sp, #216
	mov	w1, #16048                      ; =0x3eb0
	bl	_bzero
	add	x0, sp, #216
	mov	x1, x22
	bl	_analysis_calls_init
	ldrb	w25, [sp, #218]
	add	w24, w23, w23, lsl #1
	cmp	w25, #1
	b.ne	LBB5_6
; %bb.3:
	lsl	w0, w24, #2
	bl	_malloc
	mov	x21, x0
	mov	x8, x0
	cbnz	x0, LBB5_7
; %bb.4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	str	q0, [x19, #64]
Lloh130:
	adrp	x8, l_.str.1@PAGE
Lloh131:
	add	x8, x8, l_.str.1@PAGEOFF
	ldp	q1, q2, [x8]
	stp	q0, q1, [x19]
	str	q2, [x19, #32]
	ldur	q0, [x8, #31]
	stur	q0, [x19, #47]
	b	LBB5_14
LBB5_5:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	str	q0, [x19, #64]
Lloh132:
	adrp	x8, l_.str@PAGE
Lloh133:
	add	x8, x8, l_.str@PAGEOFF
	ldp	q1, q2, [x8]
	stp	q0, q1, [x19]
	str	q2, [x19, #32]
	ldur	q0, [x8, #28]
	stur	q0, [x19, #44]
	b	LBB5_14
LBB5_6:
	mov	x21, #0                         ; =0x0
	mov	x8, x20
LBB5_7:
	mov	x1, x26
	str	w26, [sp, #6368]
	str	w23, [sp, #6372]
	str	x8, [sp, #6376]
	add	x4, sp, #216
	mov	x8, x19
	mov	x0, x22
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_analyze
	ldrb	w8, [x19]
	cmp	w8, #1
	b.ne	LBB5_11
; %bb.8:
	ldrb	w9, [sp, #218]
	tbz	w9, #0, LBB5_11
; %bb.9:
	add	x8, sp, #8
	add	x1, sp, #216
	mov	x0, x22
	bl	_effect_global_proof
	ldrb	w8, [sp, #8]
	tbz	w8, #0, LBB5_16
; %bb.10:
	mov	w8, #1                          ; =0x1
LBB5_11:
	tst	w25, w8
	b.eq	LBB5_13
LBB5_12:
	lsl	w2, w24, #2
	mov	x0, x20
	mov	x1, x21
	bl	_memcpy
LBB5_13:
	mov	x0, x21
	bl	_free
LBB5_14:
	ldur	x8, [x29, #-88]
Lloh134:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh135:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh136:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_17
; %bb.15:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #3984
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB5_16:
	ldur	q0, [sp, #168]
	ldur	q1, [sp, #184]
	stp	q0, q1, [x19, #160]
	ldur	q0, [sp, #200]
	str	q0, [x19, #192]
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #120]
	stp	q0, q1, [x19, #96]
	ldur	q0, [sp, #152]
	ldur	q1, [sp, #136]
	stp	q1, q0, [x19, #128]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #56]
	stp	q0, q1, [x19, #32]
	ldur	q0, [sp, #88]
	ldur	q1, [sp, #72]
	stp	q1, q0, [x19, #64]
	ldur	q0, [sp, #24]
	ldur	q1, [sp, #8]
	stp	q1, q0, [x19]
	ldrb	w8, [x19]
	tst	w25, w8
	b.ne	LBB5_12
	b	LBB5_13
LBB5_17:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh127, Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpLdrGotLdr	Lloh134, Lloh135, Lloh136
	.loh AdrpLdrGot	Lloh125, Lloh126
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function supported
_supported:                             ; @supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB6_4
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh137:
	adrp	x9, lJTI6_0@PAGE
Lloh138:
	add	x9, x9, lJTI6_0@PAGEOFF
	adr	x10, LBB6_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB6_2:
	ret
LBB6_3:
	mov	x0, x1
	ret
LBB6_4:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh137, Lloh138
	.cfi_endproc
	.section	__TEXT,__const
lJTI6_0:
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_3-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_3-LBB6_2)>>2
	.byte	(LBB6_3-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_3-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_3-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
	.byte	(LBB6_4-LBB6_2)>>2
	.byte	(LBB6_2-LBB6_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function frame_clone
_frame_clone:                           ; @frame_clone
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #800                        ; =0x320
	bl	_calloc
	mov	x19, x0
	cbz	x0, LBB7_8
; %bb.1:
	ldr	x0, [x20]
	bl	_nvm_affine_state_clone
	str	x0, [x19]
	cbz	x0, LBB7_5
; %bb.2:
	mov	x21, x0
	ldrh	w22, [x20, #16]
	strh	w22, [x19, #16]
	ldrh	w2, [x20, #20]
	strh	w2, [x19, #20]
	add	x0, x19, #22
	add	x1, x20, #22
	mov	w3, #778                        ; =0x30a
	bl	___memcpy_chk
	ldrh	w8, [x20, #278]
	strh	w8, [x19, #278]
	ldrh	w9, [x20, #280]
	strh	w9, [x19, #280]
	ldr	w9, [x20, #284]
	str	w9, [x19, #284]
	lsl	x2, x8, #3
	add	x0, x19, #288
	add	x1, x20, #288
	mov	w3, #512                        ; =0x200
	bl	___memcpy_chk
	cbz	x22, LBB7_8
; %bb.3:
	add	x8, x22, x22, lsl #1
	lsl	x22, x8, #4
	mov	x0, x22
	bl	_malloc
	str	x0, [x19, #8]
	cbz	x0, LBB7_6
; %bb.4:
	ldr	x1, [x20, #8]
	mov	x2, x22
	bl	_memcpy
	b	LBB7_8
LBB7_5:
	bl	_nvm_affine_state_free
	b	LBB7_7
LBB7_6:
	mov	x0, x21
	bl	_nvm_affine_state_free
	ldr	x0, [x19, #8]
	bl	_free
LBB7_7:
	mov	x0, x19
	bl	_free
	mov	x19, #0                         ; =0x0
LBB7_8:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function step
_step:                                  ; @step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh139:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh140:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh141:
	ldr	x9, [x9]
	stur	x9, [x29, #-104]
	ldrb	w22, [x1]
	strb	wzr, [sp, #159]
	cmp	w22, #255
	b.eq	LBB8_248
; %bb.1:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	sub	x23, x29, #176
	add	x24, sp, #160
Lloh142:
	adrp	x9, lJTI8_0@PAGE
Lloh143:
	add	x9, x9, lJTI8_0@PAGEOFF
	adr	x10, LBB8_2
	ldrh	w11, [x9, x22, lsl #1]
	add	x10, x10, x11, lsl #2
	br	x10
LBB8_2:
	mov	x19, x5
	mov	x25, x1
	mov	x26, x4
	mov	x20, x3
	mov	x21, x8
	ldr	x0, [x8]
	bl	_nvm_affine_has_array_types
	cbz	w0, LBB8_43
; %bb.3:
	mov	w24, #3                         ; =0x3
	cmp	w22, #85
	b.gt	LBB8_77
; %bb.4:
	cmp	w22, #80
	b.eq	LBB8_257
; %bb.5:
	mov	x8, x21
	cmp	w22, #84
	b.eq	LBB8_251
	b	LBB8_250
LBB8_6:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_14
; %bb.7:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_14
; %bb.8:
	ldrb	w12, [x11, #4]
	tbnz	w12, #0, LBB8_14
; %bb.9:
	ldrb	w11, [x11]
	cmp	w11, #3
	b.ne	LBB8_14
; %bb.10:
	sub	w11, w9, #1
	strh	w11, [x8, #16]
	tst	w11, #0xffff
	b.eq	LBB8_14
; %bb.11:
	and	w11, w11, #0xffff
	sub	w11, w11, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_14
; %bb.12:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_14
; %bb.13:
	ldrb	w10, [x10]
	cmp	w10, #3
	b.eq	LBB8_69
LBB8_14:
Lloh144:
	adrp	x0, l_.str.118@PAGE
Lloh145:
	add	x0, x0, l_.str.118@PAGEOFF
	b	LBB8_410
LBB8_15:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_36
; %bb.16:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_36
; %bb.17:
	ldrb	w12, [x11, #4]
	tbnz	w12, #0, LBB8_36
; %bb.18:
	ldrb	w11, [x11]
	cmp	w11, #1
	b.ne	LBB8_36
; %bb.19:
	sub	w11, w9, #1
	strh	w11, [x8, #16]
	cmp	w22, #37
	b.eq	LBB8_403
; %bb.20:
	tst	w11, #0xffff
	b.eq	LBB8_36
; %bb.21:
	and	w11, w11, #0xffff
	sub	w11, w11, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_36
; %bb.22:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_36
; %bb.23:
	ldrb	w10, [x10]
	cmp	w10, #1
	b.ne	LBB8_36
; %bb.24:
	sub	w9, w9, #2
	b	LBB8_402
LBB8_25:
	and	w10, w22, #0xfe
	ldrh	w9, [x8, #16]
	cmp	w10, #40
	b.ne	LBB8_47
; %bb.26:
	ldrb	w10, [x6]
	tbz	w10, #0, LBB8_47
; %bb.27:
	cbz	w9, LBB8_59
; %bb.28:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11]
	cmp	w12, #5
	b.ne	LBB8_48
; %bb.29:
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_35
; %bb.30:
	ldrb	w11, [x11, #4]
	tbnz	w11, #0, LBB8_35
; %bb.31:
	sub	w11, w9, #1
	strh	w11, [x8, #16]
	tst	w11, #0xffff
	b.eq	LBB8_35
; %bb.32:
	and	w11, w11, #0xffff
	sub	w11, w11, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_35
; %bb.33:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_35
; %bb.34:
	ldrb	w10, [x10]
	cmp	w10, #5
	b.eq	LBB8_69
LBB8_35:
Lloh146:
	adrp	x0, l_.str.119@PAGE
Lloh147:
	add	x0, x0, l_.str.119@PAGEOFF
	b	LBB8_410
LBB8_36:
Lloh148:
	adrp	x0, l_.str.116@PAGE
Lloh149:
	add	x0, x0, l_.str.116@PAGEOFF
	b	LBB8_410
LBB8_37:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_319
; %bb.38:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_319
; %bb.39:
	ldrb	w12, [x11, #4]
	tbnz	w12, #0, LBB8_319
; %bb.40:
	ldrb	w11, [x11]
	cmp	w11, #3
	b.ne	LBB8_319
; %bb.41:
	sub	w11, w9, #1
	strh	w11, [x8, #16]
	cmp	w22, #204
	b.ne	LBB8_314
LBB8_42:
	mov	w19, #3                         ; =0x3
	b	LBB8_404
LBB8_43:
Lloh150:
	adrp	x0, l_.str.122@PAGE
Lloh151:
	add	x0, x0, l_.str.122@PAGEOFF
	b	LBB8_410
LBB8_44:
	sturh	wzr, [x29, #-176]
	and	w9, w22, #0xfe
	cmp	w9, #28
	b.ne	LBB8_71
; %bb.45:
	ldr	w9, [x1, #24]
	add	x2, sp, #160
	sub	x4, x29, #176
	mov	x19, x8
	mov	x0, x3
	mov	x20, x1
	mov	x1, x9
	mov	w3, #32                         ; =0x20
	bl	_nvm_ownership_path
	mov	x1, x20
	mov	x8, x19
	cbz	w0, LBB8_71
; %bb.46:
Lloh152:
	adrp	x0, l_.str.60@PAGE
Lloh153:
	add	x0, x0, l_.str.60@PAGEOFF
	b	LBB8_410
LBB8_47:
	cbz	w9, LBB8_59
LBB8_48:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x12, w11, w12, x10
	ldrb	w11, [x12, #1]
	tbnz	w11, #0, LBB8_59
; %bb.49:
	ldrb	w11, [x12, #4]
	tbnz	w11, #0, LBB8_59
; %bb.50:
	ldrb	w11, [x12]
	sub	w11, w11, #1
	cmp	w11, #3
	b.hi	LBB8_59
; %bb.51:
	mov	w11, #48                        ; =0x30
	umaddl	x11, w9, w11, x10
	ldurb	w11, [x11, #-48]
	strb	w11, [sp, #159]
	ldrb	w13, [x12, #1]
	tbnz	w13, #0, LBB8_58
; %bb.52:
	ldrb	w13, [x12, #4]
	tbnz	w13, #0, LBB8_58
; %bb.53:
	ldrb	w12, [x12]
	cmp	w12, w11
	b.ne	LBB8_58
; %bb.54:
	sub	w12, w9, #1
	strh	w12, [x8, #16]
	tst	w12, #0xffff
	b.eq	LBB8_58
; %bb.55:
	and	w12, w12, #0xffff
	sub	w12, w12, #1
	mov	w13, #48                        ; =0x30
	umaddl	x10, w12, w13, x10
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB8_58
; %bb.56:
	ldrb	w12, [x10, #4]
	tbnz	w12, #0, LBB8_58
; %bb.57:
	ldrb	w10, [x10]
	cmp	w10, w11
	b.eq	LBB8_69
LBB8_58:
Lloh154:
	adrp	x0, l_.str.121@PAGE
Lloh155:
	add	x0, x0, l_.str.121@PAGEOFF
	b	LBB8_410
LBB8_59:
Lloh156:
	adrp	x0, l_.str.120@PAGE
Lloh157:
	add	x0, x0, l_.str.120@PAGEOFF
	b	LBB8_410
LBB8_60:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_70
; %bb.61:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_70
; %bb.62:
	ldrb	w12, [x11, #4]
	tbnz	w12, #0, LBB8_70
; %bb.63:
	ldrb	w11, [x11]
	cmp	w11, #4
	b.ne	LBB8_70
; %bb.64:
	sub	w11, w9, #1
	strh	w11, [x8, #16]
	cmp	w22, #50
	b.eq	LBB8_274
; %bb.65:
	tst	w11, #0xffff
	b.eq	LBB8_70
; %bb.66:
	and	w11, w11, #0xffff
	sub	w11, w11, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_70
; %bb.67:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_70
; %bb.68:
	ldrb	w10, [x10]
	cmp	w10, #4
	b.ne	LBB8_70
LBB8_69:
	sub	w9, w9, #2
	strh	w9, [x8, #16]
	b	LBB8_274
LBB8_70:
Lloh158:
	adrp	x0, l_.str.115@PAGE
Lloh159:
	add	x0, x0, l_.str.115@PAGEOFF
	b	LBB8_410
LBB8_71:
	and	w9, w22, #0xfffffffb
	ldrh	w2, [x1, #16]
	cmp	w9, #25
	b.ne	LBB8_105
; %bb.72:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_106
; %bb.73:
	ldr	x10, [x8, #8]
	add	x10, x10, #2
Lloh160:
	adrp	x0, l_.str.61@PAGE
Lloh161:
	add	x0, x0, l_.str.61@PAGEOFF
	b	LBB8_75
LBB8_74:                                ;   in Loop: Header=BB8_75 Depth=1
	add	x10, x10, #48
	subs	x9, x9, #1
	b.eq	LBB8_106
LBB8_75:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x10, #-1]
	cmp	w11, #1
	b.ne	LBB8_74
; %bb.76:                               ;   in Loop: Header=BB8_75 Depth=1
	ldrh	w11, [x10]
	cmp	w11, w2
	b.ne	LBB8_74
	b	LBB8_410
LBB8_77:
	cmp	w22, #86
	mov	x8, x21
	b.eq	LBB8_251
; %bb.78:
	cmp	w22, #88
	b.ne	LBB8_250
; %bb.79:
	ldrh	w22, [x25, #16]
	ldrh	w9, [x8, #16]
	cmp	w22, w9
	b.ls	LBB8_279
; %bb.80:
Lloh162:
	adrp	x0, l_.str.123@PAGE
Lloh163:
	add	x0, x0, l_.str.123@PAGEOFF
	b	LBB8_410
LBB8_81:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_85
; %bb.82:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_85
; %bb.83:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_85
; %bb.84:
	ldrb	w10, [x10]
	cmp	w10, #4
	b.eq	LBB8_335
LBB8_85:
Lloh164:
	adrp	x0, l_.str.114@PAGE
Lloh165:
	add	x0, x0, l_.str.114@PAGEOFF
	b	LBB8_410
LBB8_86:
	mov	x20, x8
	ldr	x0, [x8]
	ldrh	w8, [x1, #8]
	ldrh	w2, [x1, #16]
	cmp	w22, #27
	cset	w3, eq
	add	x4, sp, #159
	mov	x1, x8
	bl	_nvm_affine_reference_field
	cbz	w0, LBB8_246
; %bb.87:
	ldrb	w19, [sp, #159]
	cmp	w22, #27
	mov	x8, x20
	b.ne	LBB8_405
; %bb.88:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_92
; %bb.89:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_92
; %bb.90:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_92
; %bb.91:
	ldrb	w10, [x10]
	cmp	w10, w19
	b.eq	LBB8_335
LBB8_92:
Lloh166:
	adrp	x0, l_.str.64@PAGE
Lloh167:
	add	x0, x0, l_.str.64@PAGEOFF
	b	LBB8_410
LBB8_93:
	ldr	x0, [x8]
	ldrh	w8, [x1, #8]
	ldrh	w2, [x1, #16]
	cmp	w22, #30
	mov	w9, #1                          ; =0x1
	cinc	w3, w9, ne
	mov	x1, x8
	bl	_nvm_affine_reborrow
Lloh168:
	adrp	x8, l_.str.59@PAGE
Lloh169:
	add	x8, x8, l_.str.59@PAGEOFF
	b	LBB8_376
LBB8_94:
	ldrb	w9, [x6]
	cmp	w9, #1
	b.ne	LBB8_247
; %bb.95:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_99
; %bb.96:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_99
; %bb.97:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_99
; %bb.98:
	ldrb	w10, [x10]
	cmp	w10, #5
	b.eq	LBB8_335
LBB8_99:
Lloh170:
	adrp	x0, l_.str.112@PAGE
Lloh171:
	add	x0, x0, l_.str.112@PAGEOFF
	b	LBB8_410
LBB8_100:
	ldrb	w9, [x6]
	cmp	w9, #1
	b.ne	LBB8_104
; %bb.101:
	ldr	w19, [x1, #8]
	ldr	w9, [x6, #4]
	cmp	w19, w9
	b.hs	LBB8_104
; %bb.102:
	mov	x25, x4
	mov	x26, x6
	add	x9, x6, x19, lsl #3
	ldrb	w21, [x9, #8]
	ldrb	w23, [x9, #9]
	ldr	w20, [x9, #12]
	mov	x27, x8
	ldr	x0, [x8]
	orr	x1, x21, x20, lsl #32
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB8_302
; %bb.103:
Lloh172:
	adrp	x0, l_.str.84@PAGE
Lloh173:
	add	x0, x0, l_.str.84@PAGEOFF
	b	LBB8_410
LBB8_104:
Lloh174:
	adrp	x0, l_.str.15@PAGE
Lloh175:
	add	x0, x0, l_.str.15@PAGEOFF
	b	LBB8_410
LBB8_105:
	mov	w5, #1                          ; =0x1
	b	LBB8_107
LBB8_106:
	mov	w5, #2                          ; =0x2
LBB8_107:
	ldr	x0, [x8]
	ldrh	w1, [x1, #8]
	ldurh	w4, [x29, #-176]
	add	x3, sp, #160
	bl	_nvm_affine_borrow
Lloh176:
	adrp	x8, l_.str.62@PAGE
Lloh177:
	add	x8, x8, l_.str.62@PAGEOFF
	b	LBB8_376
LBB8_108:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_112
; %bb.109:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_112
; %bb.110:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_112
; %bb.111:
	ldrb	w10, [x10]
	cmp	w10, #4
	b.eq	LBB8_335
LBB8_112:
Lloh178:
	adrp	x0, l_.str.113@PAGE
Lloh179:
	add	x0, x0, l_.str.113@PAGEOFF
	b	LBB8_410
LBB8_113:
	mov	x20, x4
	mov	x21, x6
	mov	x19, x8
	mov	x24, x1
	ldr	w1, [x1, #8]
	add	x2, sp, #160
	mov	x22, x3
	mov	x0, x3
	bl	_nvm_ownership_effect
	cbnz	w0, LBB8_116
; %bb.114:
	ldrh	w25, [sp, #164]
	ldrh	w8, [x24, #16]
	cmp	w25, w8
	b.ne	LBB8_116
; %bb.115:
	ldrh	w26, [x19, #16]
	subs	w9, w26, w25
	b.hs	LBB8_377
LBB8_116:
Lloh180:
	adrp	x0, l_.str.50@PAGE
Lloh181:
	add	x0, x0, l_.str.50@PAGEOFF
	b	LBB8_410
LBB8_117:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_120
; %bb.118:
	ldr	x8, [x8, #8]
	sub	w10, w9, #1
	mov	w11, #48                        ; =0x30
	umaddl	x10, w10, w11, x8
	ldrb	w11, [x10]
	cmp	w11, #10
	b.ne	LBB8_120
; %bb.119:
	ldrb	w10, [x10, #1]
	tbz	w10, #0, LBB8_327
LBB8_120:
Lloh182:
	adrp	x0, l_.str.96@PAGE
Lloh183:
	add	x0, x0, l_.str.96@PAGEOFF
	b	LBB8_410
LBB8_121:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_125
; %bb.122:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10]
	cmp	w11, #10
	b.ne	LBB8_125
; %bb.123:
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_125
; %bb.124:
	ldrb	w10, [x10, #4]
	tbz	w10, #0, LBB8_401
LBB8_125:
Lloh184:
	adrp	x0, l_.str.98@PAGE
Lloh185:
	add	x0, x0, l_.str.98@PAGEOFF
	b	LBB8_410
LBB8_126:
	mov	w9, #65535                      ; =0xffff
	strh	w9, [sp, #88]
	ldrh	w9, [x1, #8]
	ldrh	w10, [x8, #16]
	cbz	x10, LBB8_260
; %bb.127:
	ldr	x11, [x8, #8]
	add	x11, x11, #2
Lloh186:
	adrp	x0, l_.str.65@PAGE
Lloh187:
	add	x0, x0, l_.str.65@PAGEOFF
	b	LBB8_129
LBB8_128:                               ;   in Loop: Header=BB8_129 Depth=1
	add	x11, x11, #48
	subs	x10, x10, #1
	b.eq	LBB8_260
LBB8_129:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x11, #-1]
	cmp	w12, #1
	b.ne	LBB8_128
; %bb.130:                              ;   in Loop: Header=BB8_129 Depth=1
	ldrh	w12, [x11]
	cmp	w12, w9
	b.ne	LBB8_128
	b	LBB8_410
LBB8_131:
	cbnz	w4, LBB8_249
; %bb.132:
	ldr	w9, [x3, #272]
	cmp	w9, #2
	b.ne	LBB8_249
; %bb.133:
	ldr	w9, [x1, #8]
	cmp	w9, #1
	b.ne	LBB8_249
; %bb.134:
	mov	x20, x8
	ldr	x2, [x8]
	ldrh	w9, [x1, #16]
	add	x8, sp, #160
	mov	x19, x3
	mov	x0, x3
	mov	w1, #1                          ; =0x1
	mov	x3, x9
	mov	x4, x6
	bl	_analyze
	ldrb	w8, [sp, #160]
	cmp	w8, #1
	b.ne	LBB8_421
; %bb.135:
	ldr	x8, [x19, #256]
	ldrb	w19, [x8, #44]
	strb	w19, [sp, #159]
	ldrb	w8, [x8, #45]
Lloh188:
	adrp	x0, l_.str.48@PAGE
Lloh189:
	add	x0, x0, l_.str.48@PAGEOFF
	cmp	w8, #1
	b.ne	LBB8_410
; %bb.136:
	cmp	w19, #4
	b.hi	LBB8_410
; %bb.137:
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w19
	mov	w9, #22                         ; =0x16
	tst	w8, w9
	b.eq	LBB8_410
; %bb.138:
	mov	x8, x20
	b	LBB8_405
LBB8_139:
	mov	w19, #0                         ; =0x0
	strb	wzr, [sp, #159]
	b	LBB8_405
LBB8_140:
	ldrb	w9, [x1, #8]
	cmp	w9, #1
	b.eq	LBB8_297
; %bb.141:
	cbnz	w9, LBB8_301
; %bb.142:
	ldr	w19, [x1, #16]
	strh	wzr, [sp, #88]
	ldrb	w9, [x6]
	cmp	w9, #1
	b.ne	LBB8_148
; %bb.143:
	ldrh	w9, [x1, #24]
	cbnz	w9, LBB8_148
; %bb.144:
	mov	x21, x1
	mov	x20, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_record_is_copyable
	cbz	w0, LBB8_148
; %bb.145:
	ldr	x0, [x20]
	add	x2, sp, #160
	add	x4, sp, #88
	mov	x1, x19
	mov	w3, #256                        ; =0x100
	bl	_nvm_affine_record_fields
	cbz	w0, LBB8_148
; %bb.146:
	ldrh	w8, [sp, #88]
	ldrh	w9, [x21, #32]
	cmp	w8, w9
	b.ne	LBB8_148
; %bb.147:
	ldrh	w9, [x20, #16]
	cmp	w9, w8
	b.hs	LBB8_475
LBB8_148:
Lloh190:
	adrp	x0, l_.str.76@PAGE
Lloh191:
	add	x0, x0, l_.str.76@PAGEOFF
	b	LBB8_410
LBB8_149:
	ldr	w19, [x1, #8]
	mov	x20, x8
	ldr	x0, [x8]
	mov	w8, #8                          ; =0x8
	orr	x1, x8, x19, lsl #32
	bl	_nvm_affine_type_is_owned
	cbz	w0, LBB8_152
; %bb.150:
	ldr	x0, [x20]
	add	x2, sp, #160
	add	x4, sp, #88
	mov	x1, x19
	mov	w3, #256                        ; =0x100
	bl	_nvm_affine_record_fields
	cbz	w0, LBB8_152
; %bb.151:
	ldrh	w9, [sp, #88]
	ldrh	w10, [x20, #16]
	cmp	w9, w10
	b.ls	LBB8_345
LBB8_152:
Lloh192:
	adrp	x0, l_.str.71@PAGE
Lloh193:
	add	x0, x0, l_.str.71@PAGEOFF
	b	LBB8_410
LBB8_153:
	ldrh	w9, [x8, #16]
	cbnz	w9, LBB8_309
	b	LBB8_311
LBB8_154:
	ldrb	w9, [x1, #8]
	cmp	w9, #1
	b.ls	LBB8_274
; %bb.155:
Lloh194:
	adrp	x0, l_.str.55@PAGE
Lloh195:
	add	x0, x0, l_.str.55@PAGEOFF
	b	LBB8_410
LBB8_156:
	ldrh	w19, [x1, #8]
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_263
; %bb.157:
	ldr	x10, [x8, #8]
	add	x10, x10, #2
Lloh196:
	adrp	x0, l_.str.73@PAGE
Lloh197:
	add	x0, x0, l_.str.73@PAGEOFF
	b	LBB8_159
LBB8_158:                               ;   in Loop: Header=BB8_159 Depth=1
	add	x10, x10, #48
	subs	x9, x9, #1
	b.eq	LBB8_263
LBB8_159:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x10, #-1]
	cmp	w11, #1
	b.ne	LBB8_158
; %bb.160:                              ;   in Loop: Header=BB8_159 Depth=1
	ldrh	w11, [x10]
	cmp	w11, w19
	b.ne	LBB8_158
	b	LBB8_410
LBB8_161:
	ldrh	w10, [x8, #16]
	cmp	x10, #2
	b.lo	LBB8_166
; %bb.162:
	ldr	x11, [x8, #8]
	mov	w9, #48                         ; =0x30
	umaddl	x9, w10, w9, x11
	ldurb	w12, [x9, #-47]
	tbnz	w12, #0, LBB8_166
; %bb.163:
	ldurb	w12, [x9, #-44]
	tbnz	w12, #0, LBB8_166
; %bb.164:
	sub	w10, w10, #2
	mov	w12, #48                        ; =0x30
	umaddl	x11, w10, w12, x11
	ldrb	w10, [x11, #1]
	tbnz	w10, #0, LBB8_166
; %bb.165:
	ldrb	w10, [x11, #4]
	tbz	w10, #0, LBB8_442
LBB8_166:
Lloh198:
	adrp	x0, l_.str.110@PAGE
Lloh199:
	add	x0, x0, l_.str.110@PAGEOFF
	b	LBB8_410
LBB8_167:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_273
; %bb.168:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w11, [x11, #4]
	cmp	w11, #1
	b.ne	LBB8_273
; %bb.169:
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldurb	w22, [x9, #-48]
	ldurh	w19, [x9, #-36]
	mov	x20, x8
	ldr	x0, [x8]
	mov	x21, x1
	ldrh	w1, [x1, #8]
	ldur	w8, [x9, #-40]
	orr	x2, x22, x8, lsl #32
	bl	_nvm_affine_put_local
	cbz	w0, LBB8_328
; %bb.170:
	cmp	w22, #10
	mov	w8, #65535                      ; =0xffff
	ccmp	w19, w8, #4, eq
	b.eq	LBB8_172
; %bb.171:
	ldr	x0, [x20]
	ldrh	w1, [x21, #8]
	mov	x2, x19
	bl	_nvm_affine_union_refine
	cbz	w0, LBB8_424
LBB8_172:
	mov	x0, #0                          ; =0x0
	ldrh	w8, [x20, #16]
	sub	w8, w8, #1
	strh	w8, [x20, #16]
	b	LBB8_410
LBB8_173:
	ldrb	w9, [x6]
	cmp	w9, #1
	b.ne	LBB8_276
; %bb.174:
	ldr	w9, [x1, #8]
	ldr	w10, [x3, #248]
	cmp	w9, w10
	b.hs	LBB8_179
; %bb.175:
	ldr	x11, [x3, #232]
	cbz	x11, LBB8_179
; %bb.176:
	ldr	x10, [x3, #240]
	cbz	x10, LBB8_179
; %bb.177:
	ldr	x0, [x11, x9, lsl #3]
	cbz	x0, LBB8_179
; %bb.178:
	mov	x20, x8
	ldr	w2, [x10, x9, lsl #2]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB8_446
LBB8_179:
Lloh200:
	adrp	x0, l_.str.56@PAGE
Lloh201:
	add	x0, x0, l_.str.56@PAGEOFF
	b	LBB8_410
LBB8_180:
	mov	w19, #2                         ; =0x2
	b	LBB8_404
LBB8_181:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_184
; %bb.182:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_184
; %bb.183:
	ldrb	w12, [x11, #4]
	tbz	w12, #0, LBB8_329
LBB8_184:
Lloh202:
	adrp	x0, l_.str.106@PAGE
Lloh203:
	add	x0, x0, l_.str.106@PAGEOFF
	b	LBB8_410
LBB8_185:
	ldrh	w19, [x1, #8]
	mov	x22, x8
	ldr	x0, [x8]
	add	x2, sp, #159
	add	x3, sp, #88
	mov	x1, x19
	bl	_nvm_affine_local_info
	cbz	w0, LBB8_277
; %bb.186:
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x29, #-176]
	ldrb	w8, [sp, #159]
	mov	w21, #-1                        ; =0xffffffff
	cmp	w8, #8
	cset	w20, eq
	b.ne	LBB8_353
; %bb.187:
	ldrb	w9, [sp, #88]
	mov	x0, x22
	cbnz	w9, LBB8_354
; %bb.188:
	ldr	x0, [x0]
	add	x2, sp, #160
	mov	x1, x19
	bl	_nvm_affine_local_type
	cbz	w0, LBB8_363
; %bb.189:
	ldr	w21, [sp, #164]
	ldr	x0, [x22]
	mov	x1, x21
	bl	_nvm_affine_record_is_copyable
	mov	x8, x0
	mov	x0, x22
	eor	w20, w8, #0x1
	ldrb	w8, [sp, #159]
	b	LBB8_354
LBB8_190:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_193
; %bb.191:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_193
; %bb.192:
	ldrb	w11, [x10, #4]
	tbz	w11, #0, LBB8_332
LBB8_193:
Lloh204:
	adrp	x0, l_.str.108@PAGE
Lloh205:
	add	x0, x0, l_.str.108@PAGEOFF
	b	LBB8_410
LBB8_194:
	ldr	x0, [x8]
	bl	_nvm_affine_region_end
Lloh206:
	adrp	x8, l_.str.58@PAGE
Lloh207:
	add	x8, x8, l_.str.58@PAGEOFF
	b	LBB8_376
LBB8_195:
	ldrh	w19, [x1, #8]
	cmp	w19, w2
	b.hs	LBB8_199
; %bb.196:
	ldrh	w9, [x8, #16]
	cbz	x9, LBB8_199
; %bb.197:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_199
; %bb.198:
	ldrb	w11, [x11, #4]
	tbz	w11, #0, LBB8_412
LBB8_199:
Lloh208:
	adrp	x0, l_.str.94@PAGE
Lloh209:
	add	x0, x0, l_.str.94@PAGEOFF
	b	LBB8_410
LBB8_200:
	ldr	x0, [x8]
	bl	_nvm_affine_region_begin
Lloh210:
	adrp	x8, l_.str.57@PAGE
Lloh211:
	add	x8, x8, l_.str.57@PAGEOFF
	b	LBB8_376
LBB8_201:
	ldr	w21, [x1, #8]
	ldrb	w9, [x6]
	cmp	w9, #1
	ccmp	w21, #0, #4, eq
	b.eq	LBB8_271
; %bb.202:
	ldr	w9, [x3, #272]
	cmp	w21, w9
	b.hs	LBB8_271
; %bb.203:
	str	w4, [sp, #12]                   ; 4-byte Folded Spill
	stp	x6, x8, [sp, #16]               ; 16-byte Folded Spill
	ldr	x8, [x3, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w21, w9, x8
	ldrh	w2, [x8, #16]
	mov	x23, x3
	mov	x0, x3
	mov	x1, x21
	bl	_nvm_affine_state_create
	mov	x24, x0
	str	wzr, [sp, #140]
	sub	x1, x29, #176
	add	x3, sp, #142
	mov	w2, #8                          ; =0x8
	bl	_nvm_affine_value_parameters
	cbz	w0, LBB8_364
; %bb.204:
	add	x1, sp, #144
	add	x2, sp, #140
	mov	x0, x24
	bl	_nvm_affine_value_result
	mov	x25, x0
	mov	x0, x24
	bl	_nvm_affine_state_free
	cbz	w25, LBB8_365
; %bb.205:
	ldrh	w10, [sp, #142]
	ldr	x8, [x23, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x8, w21, w11, x8
	ldrh	w8, [x8, #4]
	cmp	w10, w8
	b.ne	LBB8_365
; %bb.206:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w11, [x8, #16]
	cmp	w11, w10
	b.lo	LBB8_365
; %bb.207:
	mov	x9, x23
	cbz	w10, LBB8_216
; %bb.208:
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	sub	x9, x29, #176
	orr	x26, x9, #0x1
Lloh212:
	adrp	x0, l_.str.40@PAGE
Lloh213:
	add	x0, x0, l_.str.40@PAGEOFF
LBB8_209:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8, #8]
	ldrh	w11, [x8, #16]
	sub	x10, x11, w10, uxtw
	mov	w11, #48                        ; =0x30
	madd	x9, x10, x11, x9
	add	x10, x9, x24
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_410
; %bb.210:                              ;   in Loop: Header=BB8_209 Depth=1
	ldrb	w27, [x10]
	ldurb	w11, [x26, #-1]
	cmp	w27, w11
	b.ne	LBB8_410
; %bb.211:                              ;   in Loop: Header=BB8_209 Depth=1
	mov	x28, x0
	ldr	w20, [x10, #8]
	ldrb	w10, [x26, #6]
	ldrh	w11, [x26, #4]
	orr	w10, w11, w10, lsl #16
	ldr	w11, [x26]
	add	x9, x9, x24
	ldrb	w19, [x9, #4]
	ldr	x0, [x8]
	lsl	x8, x11, #8
	orr	x22, x8, x10, lsl #40
	orr	x1, x22, x27
	bl	_nvm_affine_type_is_owned
	and	w8, w19, #0x1
	cmp	w0, w8
	b.ne	LBB8_454
; %bb.212:                              ;   in Loop: Header=BB8_209 Depth=1
	tbnz	w19, #0, LBB8_214
; %bb.213:                              ;   in Loop: Header=BB8_209 Depth=1
	cmp	w27, #10
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w27
	mov	w9, #1408                       ; =0x580
	and	w8, w8, w9
	ccmp	w8, #0, #4, ls
	b.eq	LBB8_215
LBB8_214:                               ;   in Loop: Header=BB8_209 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	orr	x1, x27, x20, lsl #32
	orr	x2, x22, x27
	bl	_nvm_affine_types_equal
	cbz	w0, LBB8_454
LBB8_215:                               ;   in Loop: Header=BB8_209 Depth=1
	add	x25, x25, #1
	ldrh	w10, [sp, #142]
	add	x26, x26, #8
	add	x24, x24, #48
	cmp	x25, x10
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	x0, x28
	mov	x9, x23
	b.lo	LBB8_209
LBB8_216:
	add	x8, sp, #160
	mov	x0, x9
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	bl	_analyze
	ldrb	w8, [sp, #160]
	cmp	w8, #1
	b.ne	LBB8_473
; %bb.217:
	mov	w9, #7840                       ; =0x1ea0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x24, x8, x9
	ldrh	w9, [x24, x21, lsl #1]
	cbz	w9, LBB8_228
; %bb.218:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	cbz	w0, LBB8_484
; %bb.219:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #142]
	sub	w8, w8, w9
	cmp	w8, #1
	b.lt	LBB8_224
; %bb.220:
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x10, [x10, #8]
	mov	w11, #48                        ; =0x30
Lloh214:
	adrp	x0, l_.str.43@PAGE
Lloh215:
	add	x0, x0, l_.str.43@PAGEOFF
LBB8_221:                               ; =>This Inner Loop Header: Depth=1
	madd	x12, x9, x11, x10
	ldrb	w13, [x12, #4]
	tbnz	w13, #0, LBB8_410
; %bb.222:                              ;   in Loop: Header=BB8_221 Depth=1
	ldrb	w12, [x12, #1]
	tbnz	w12, #0, LBB8_410
; %bb.223:                              ;   in Loop: Header=BB8_221 Depth=1
	add	x9, x9, #1
	cmp	w8, w9, uxth
	b.hi	LBB8_221
LBB8_224:
	ldrh	w9, [x24, x21, lsl #1]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	w9, LBB8_228
; %bb.225:
	mov	x20, #0                         ; =0x0
	add	x9, x8, x21, lsl #10
	mov	w10, #7856                      ; =0x1eb0
	add	x22, x9, x10
Lloh216:
	adrp	x25, l_.str.44@PAGE
Lloh217:
	add	x25, x25, l_.str.44@PAGEOFF
LBB8_226:                               ; =>This Inner Loop Header: Depth=1
	ldr	w4, [x22, x20, lsl #2]
	mov	x0, x8
	mov	x1, x23
	ldr	w2, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	bl	_effect_escape
	tbz	w0, #0, LBB8_461
; %bb.227:                              ;   in Loop: Header=BB8_226 Depth=1
	add	x20, x20, #1
	ldrh	w8, [x24, x21, lsl #1]
	cmp	x20, x8
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	b.lo	LBB8_226
LBB8_228:
	ldrb	w9, [x8, #2]
	tbnz	w9, #0, LBB8_232
; %bb.229:
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	mov	w9, w9
	add	x21, x8, x21, lsl #8
	add	x22, x8, x9, lsl #8
	mov	w23, #2056                      ; =0x808
	mov	w24, #3                         ; =0x3
	mov	w25, #2                         ; =0x2
LBB8_230:                               ; =>This Inner Loop Header: Depth=1
	sub	x9, x23, #2056
	ldr	w8, [x8, #4]
	cmp	x9, x8
	b.hs	LBB8_232
; %bb.231:                              ;   in Loop: Header=BB8_230 Depth=1
	add	x9, x21, x23
	ldrb	w10, [x9]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, x23
	sub	x19, x8, #2034
	ldrb	w8, [x19]
	bic	w10, w24, w10
	tst	w10, w8
	cinc	w11, w25, eq
	tst	w10, w8, lsr #2
	csinc	w8, w24, wzr, eq
	ldrb	w10, [x22, x23]
	and	w10, w11, w10
	and	w8, w10, w8
	strb	w8, [x22, x23]
	ldrb	w0, [x19]
	ldrb	w1, [x9, #2048]
	bl	_nvm_affine_global_compose
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	strb	w0, [x19]
	ldrb	w9, [x8, #2]
	add	x23, x23, #1
	tbz	w9, #0, LBB8_230
LBB8_232:
	ldrh	w8, [sp, #142]
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w10, [x9, #16]
	sub	w8, w10, w8
	strh	w8, [x9, #16]
	ldrb	w20, [sp, #144]
	cbz	w20, LBB8_460
; %bb.233:
	strb	wzr, [sp, #95]
	sturh	wzr, [sp, #93]
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #102]
	stur	q0, [sp, #118]
	strh	wzr, [sp, #134]
	ldr	x19, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x0, [x19]
	ldr	x1, [sp, #144]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #148]
	strb	w20, [sp, #88]
	strb	wzr, [sp, #89]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [sp, #90]
	strb	w0, [sp, #92]
	str	w8, [sp, #96]
	strh	w9, [sp, #100]
	add	x1, sp, #88
	mov	x0, x19
	bl	_push
Lloh218:
	adrp	x8, l_.str.45@PAGE
Lloh219:
	add	x8, x8, l_.str.45@PAGEOFF
	b	LBB8_376
LBB8_234:
	ldrh	w9, [x1, #8]
	ldrh	w10, [x8, #278]
	ldrh	w11, [x8, #280]
	sub	w11, w10, w11
	cmp	w11, w9
	b.ge	LBB8_278
; %bb.235:
Lloh220:
	adrp	x0, l_.str.49@PAGE
Lloh221:
	add	x0, x0, l_.str.49@PAGEOFF
	b	LBB8_410
LBB8_236:
	ldrh	w9, [x8, #16]
	cbz	w9, LBB8_311
; %bb.237:
	ldr	x10, [x8, #8]
	sub	w11, w9, #1
	mov	w12, #48                        ; =0x30
	umaddl	x11, w11, w12, x10
	ldrb	w12, [x11]
	cmp	w12, #10
	b.eq	LBB8_307
; %bb.238:
	cmp	w12, #8
	b.ne	LBB8_309
; %bb.239:
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_309
; %bb.240:
	ldrb	w11, [x11, #4]
	tbnz	w11, #0, LBB8_309
; %bb.241:
	mov	x21, x1
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldur	w19, [x9, #-40]
	strh	wzr, [sp, #88]
	mov	x20, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_record_is_copyable
	cbz	w0, LBB8_423
; %bb.242:
	ldr	x0, [x20]
	add	x2, sp, #160
	add	x4, sp, #88
	mov	x1, x19
	mov	w3, #256                        ; =0x100
	bl	_nvm_affine_record_fields
	cbz	w0, LBB8_423
; %bb.243:
	ldrh	w8, [x21, #8]
	ldrh	w9, [sp, #88]
	cmp	w8, w9
	b.hs	LBB8_423
; %bb.244:
	add	x9, sp, #160
	add	x8, x9, x8, lsl #3
	ldrb	w19, [x8]
	ldrb	w9, [x8, #3]
	ldurh	w10, [x8, #1]
	ldr	w21, [x8, #4]
	ldr	x0, [x20]
	lsl	x8, x10, #8
	orr	x8, x8, x9, lsl #24
	orr	x8, x8, x19
	orr	x1, x8, x21, lsl #32
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB8_483
; %bb.245:
Lloh222:
	adrp	x0, l_.str.100@PAGE
Lloh223:
	add	x0, x0, l_.str.100@PAGEOFF
	b	LBB8_410
LBB8_246:
Lloh224:
	adrp	x0, l_.str.63@PAGE
Lloh225:
	add	x0, x0, l_.str.63@PAGEOFF
	b	LBB8_410
LBB8_247:
Lloh226:
	adrp	x0, l_.str.10@PAGE
Lloh227:
	add	x0, x0, l_.str.10@PAGEOFF
	b	LBB8_410
LBB8_248:
Lloh228:
	adrp	x0, l_.str.11@PAGE
Lloh229:
	add	x0, x0, l_.str.11@PAGEOFF
	b	LBB8_410
LBB8_249:
Lloh230:
	adrp	x0, l_.str.46@PAGE
Lloh231:
	add	x0, x0, l_.str.46@PAGEOFF
	b	LBB8_410
LBB8_250:
	and	w9, w22, #0xfffffffd
	cmp	w9, #81
	mov	w9, #87                         ; =0x57
	ccmp	w22, w9, #4, ne
	mov	w9, #1                          ; =0x1
	cinc	w24, w9, eq
LBB8_251:
	ldrh	w9, [x8, #16]
	subs	w9, w9, w24
	b.hs	LBB8_253
; %bb.252:
Lloh232:
	adrp	x0, l_.str.130@PAGE
Lloh233:
	add	x0, x0, l_.str.130@PAGEOFF
	b	LBB8_410
LBB8_253:
	mov	w10, #48                        ; =0x30
	ldp	x0, x11, [x8]
	umaddl	x8, w9, w10, x11
	ldrb	w9, [x8]
	ldrb	w25, [x8, #1]
	ldrh	w19, [x8, #2]
	ldrb	w20, [x8, #4]
	ldr	w8, [x8, #8]
	sturh	wzr, [x23, #1]
	sturb	wzr, [x29, #-173]
	sturb	w9, [x29, #-176]
	stur	w8, [x29, #-172]
	ldur	x1, [x29, #-176]
	add	x2, sp, #88
	bl	_nvm_affine_array_element
	cbz	w0, LBB8_275
; %bb.254:
	cmp	w22, #85
	b.ne	LBB8_295
; %bb.255:
	tbz	w20, #0, LBB8_320
LBB8_256:
Lloh234:
	adrp	x0, l_.str.132@PAGE
Lloh235:
	add	x0, x0, l_.str.132@PAGEOFF
	b	LBB8_410
LBB8_257:
	mov	x1, x26
	mov	x2, x19
	ldrb	w19, [x25, #8]
LBB8_258:
	add	x3, sp, #160
	mov	x0, x20
	bl	_nvm_ownership_array_constructor
	cbz	w0, LBB8_291
; %bb.259:
Lloh236:
	adrp	x0, l_.str.124@PAGE
Lloh237:
	add	x0, x0, l_.str.124@PAGEOFF
	b	LBB8_410
LBB8_260:
	ldr	x0, [x8]
	add	x2, sp, #88
	mov	x20, x8
	mov	x21, x1
	mov	x1, x9
	bl	_nvm_affine_union_variant
	mov	x19, x20
	ldr	x0, [x20]
	ldrh	w1, [x21, #8]
	sub	x2, x29, #176
	bl	_nvm_affine_take_local
	cbz	w0, LBB8_294
; %bb.261:
	strb	wzr, [sp, #167]
	sturh	wzr, [x24, #5]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #14]
	stur	q0, [x24, #30]
	strh	wzr, [sp, #206]
	ldurb	w8, [x29, #-176]
	ldur	w9, [x29, #-172]
	ldrh	w10, [sp, #88]
	strb	w8, [sp, #160]
	strb	wzr, [sp, #161]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #162]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #164]
	str	w9, [sp, #168]
	strh	w10, [sp, #172]
	add	x1, sp, #160
	mov	x0, x19
LBB8_262:
	bl	_push
Lloh238:
	adrp	x8, l_.str.67@PAGE
Lloh239:
	add	x8, x8, l_.str.67@PAGEOFF
	b	LBB8_376
LBB8_263:
	mov	x20, x8
	ldr	x0, [x8]
	add	x2, sp, #88
	mov	x1, x19
	bl	_nvm_affine_local_type
	cbz	w0, LBB8_272
; %bb.264:
	ldr	x0, [x20]
	add	x2, sp, #160
	add	x4, sp, #144
	mov	x1, x19
	mov	w3, #256                        ; =0x100
	bl	_nvm_affine_owned_local_fields
	cbz	w0, LBB8_272
; %bb.265:
	ldrh	w9, [x20, #16]
	ldrh	w10, [sp, #144]
	add	w9, w10, w9
	cmp	w9, #256
	b.hi	LBB8_272
; %bb.266:
	ldr	x0, [x20]
	add	x2, sp, #88
	mov	x1, x19
	bl	_nvm_affine_take_local
	cbz	w0, LBB8_272
; %bb.267:
	ldrh	w8, [sp, #144]
	cbz	w8, LBB8_460
; %bb.268:
	mov	x21, #0                         ; =0x0
	mov	w8, #5                          ; =0x5
	sub	x22, x29, #176
	orr	x23, x22, x8
	add	x24, sp, #160
	mov	w26, #65535                     ; =0xffff
Lloh240:
	adrp	x25, l_.str.75@PAGE
Lloh241:
	add	x25, x25, l_.str.75@PAGEOFF
LBB8_269:                               ; =>This Inner Loop Header: Depth=1
	strb	wzr, [x23, #2]
	strh	wzr, [x23]
	movi.2d	v0, #0000000000000000
	stur	q0, [x22, #14]
	stur	q0, [x22, #30]
	sturh	wzr, [x22, #46]
	ldrb	w27, [x24]
	ldr	x0, [x20]
	ldr	x1, [x24]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [x24, #4]
	sturb	w27, [x29, #-176]
	sturb	wzr, [x29, #-175]
	sturh	w26, [x29, #-174]
	sturb	w0, [x29, #-172]
	stur	w8, [x29, #-168]
	sturh	w26, [x29, #-164]
	sub	x1, x29, #176
	mov	x0, x20
	bl	_push
	tbz	w0, #0, LBB8_461
; %bb.270:                              ;   in Loop: Header=BB8_269 Depth=1
	mov	x0, #0                          ; =0x0
	add	x24, x24, #8
	add	x21, x21, #1
	ldrh	w8, [sp, #144]
	cmp	x21, x8
	b.lo	LBB8_269
	b	LBB8_410
LBB8_271:
Lloh242:
	adrp	x0, l_.str.38@PAGE
Lloh243:
	add	x0, x0, l_.str.38@PAGEOFF
	b	LBB8_410
LBB8_272:
Lloh244:
	adrp	x0, l_.str.74@PAGE
Lloh245:
	add	x0, x0, l_.str.74@PAGEOFF
	b	LBB8_410
LBB8_273:
Lloh246:
	adrp	x0, l_.str.68@PAGE
Lloh247:
	add	x0, x0, l_.str.68@PAGEOFF
	b	LBB8_410
LBB8_274:
	mov	w19, #4                         ; =0x4
	b	LBB8_404
LBB8_275:
Lloh248:
	adrp	x0, l_.str.131@PAGE
Lloh249:
	add	x0, x0, l_.str.131@PAGEOFF
	b	LBB8_410
LBB8_276:
Lloh250:
	adrp	x0, l_.str.9@PAGE
Lloh251:
	add	x0, x0, l_.str.9@PAGEOFF
	b	LBB8_410
LBB8_277:
Lloh252:
	adrp	x0, l_.str.88@PAGE
Lloh253:
	add	x0, x0, l_.str.88@PAGEOFF
	b	LBB8_410
LBB8_278:
	mov	x0, #0                          ; =0x0
	sub	w9, w10, w9
	strh	w9, [x8, #278]
	b	LBB8_410
LBB8_279:
	mov	x2, x19
	ldrb	w19, [x25, #8]
	cbz	w22, LBB8_326
; %bb.280:
	ldr	x10, [x8, #8]
	sub	w9, w9, w22
	mov	w11, #48                        ; =0x30
	smaddl	x9, w9, w11, x10
	ldrb	w10, [x9]
	ldr	w9, [x9, #8]
	sturh	wzr, [sp, #89]
	strb	wzr, [sp, #91]
	strb	w10, [sp, #88]
	str	w9, [sp, #92]
	cmp	w10, w19
	b.ne	LBB8_306
; %bb.281:
	ldr	x0, [x8]
	ldr	x1, [sp, #88]
	sub	x2, x29, #176
	bl	_nvm_affine_array_type
	cbz	w0, LBB8_306
; %bb.282:
	neg	w8, w22
	sxtw	x23, w8
	mov	w24, #48                        ; =0x30
Lloh254:
	adrp	x0, l_.str.128@PAGE
Lloh255:
	add	x0, x0, l_.str.128@PAGEOFF
	b	LBB8_284
LBB8_283:                               ;   in Loop: Header=BB8_284 Depth=1
	add	x23, x23, #1
	mov	x0, x27
	cbz	w23, LBB8_339
LBB8_284:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21, #8]
	ldrh	w10, [x21, #16]
	add	x10, x23, x10
	madd	x8, x10, x24, x8
	ldrb	w10, [x8, #1]
	tbnz	w10, #0, LBB8_410
; %bb.285:                              ;   in Loop: Header=BB8_284 Depth=1
	ldrb	w28, [sp, #88]
	ldrb	w10, [x8]
	cmp	w10, w28
	b.ne	LBB8_410
; %bb.286:                              ;   in Loop: Header=BB8_284 Depth=1
	mov	x27, x0
	ldr	x19, [x21]
	ldr	w25, [x8, #8]
	ldr	w9, [sp, #92]
	orr	x20, x28, x9, lsl #32
	ldrb	w26, [x8, #4]
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_affine_type_is_owned
	cmp	w26, w0
	b.ne	LBB8_290
; %bb.287:                              ;   in Loop: Header=BB8_284 Depth=1
	cmp	w28, #10
	b.hi	LBB8_283
; %bb.288:                              ;   in Loop: Header=BB8_284 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w28
	mov	w9, #1408                       ; =0x580
	tst	w8, w9
	b.eq	LBB8_283
; %bb.289:                              ;   in Loop: Header=BB8_284 Depth=1
	orr	x1, x28, x25, lsl #32
	mov	x0, x19
	mov	x2, x20
	bl	_nvm_affine_types_equal
	cbnz	w0, LBB8_283
LBB8_290:
	mov	x0, x27
	b	LBB8_410
LBB8_291:
	ldr	w8, [sp, #160]
	cmn	w8, #1
	b.eq	LBB8_337
; %bb.292:
	sturb	wzr, [x29, #-173]
	sturh	wzr, [x23, #1]
	mov	w9, #7                          ; =0x7
	sturb	w9, [x29, #-176]
	stur	w8, [x29, #-172]
	ldr	x0, [x21]
	ldur	x1, [x29, #-176]
	add	x2, sp, #88
	bl	_nvm_affine_array_element
	mov	x8, x0
Lloh256:
	adrp	x0, l_.str.125@PAGE
Lloh257:
	add	x0, x0, l_.str.125@PAGEOFF
	cbz	w8, LBB8_410
; %bb.293:
	ldrb	w8, [sp, #88]
	cmp	w8, w19
	b.eq	LBB8_338
	b	LBB8_410
LBB8_294:
Lloh258:
	adrp	x0, l_.str.66@PAGE
Lloh259:
	add	x0, x0, l_.str.66@PAGEOFF
	b	LBB8_410
LBB8_295:
	tbz	w25, #0, LBB8_323
; %bb.296:
Lloh260:
	adrp	x0, l_.str.134@PAGE
Lloh261:
	add	x0, x0, l_.str.134@PAGEOFF
	b	LBB8_410
LBB8_297:
	mov	x21, x8
	ldrh	w19, [x1, #24]
	ldrh	w20, [x1, #32]
	ldr	w1, [x1, #16]
	mov	x0, x3
	add	x3, sp, #88
	mov	x2, x19
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB8_300
; %bb.298:
	ldrh	w8, [sp, #98]
	cmp	w20, w8
	b.ne	LBB8_300
; %bb.299:
	ldrh	w9, [x21, #16]
	cmp	w20, w9
	b.ls	LBB8_431
LBB8_300:
Lloh262:
	adrp	x0, l_.str.80@PAGE
Lloh263:
	add	x0, x0, l_.str.80@PAGEOFF
	b	LBB8_410
LBB8_301:
Lloh264:
	adrp	x0, l_.str.79@PAGE
Lloh265:
	add	x0, x0, l_.str.79@PAGEOFF
	b	LBB8_410
LBB8_302:
	cmp	w22, #18
	b.ne	LBB8_366
; %bb.303:
	ldrb	w8, [x26, #2]
	mov	x0, x27
	tbnz	w8, #0, LBB8_305
; %bb.304:
	add	x8, x0, x19
	ldrb	w8, [x8, #22]
	tst	w8, #0x1
	mov	w9, #2                          ; =0x2
	cinc	w9, w9, eq
	tst	w8, #0x4
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
	mov	w10, w25
	add	x10, x26, x10, lsl #8
	add	x10, x10, x19
	ldrb	w11, [x10, #2056]
	and	w9, w9, w11
	and	w8, w9, w8
	strb	w8, [x10, #2056]
LBB8_305:
	strh	wzr, [sp, #206]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #30]
	stur	q0, [x24, #14]
	strb	w21, [sp, #160]
	strb	wzr, [sp, #161]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #162]
	stp	wzr, w20, [sp, #164]
	strh	w8, [sp, #172]
	add	x1, sp, #160
	bl	_push
Lloh266:
	adrp	x8, l_.str.85@PAGE
Lloh267:
	add	x8, x8, l_.str.85@PAGEOFF
	b	LBB8_376
LBB8_306:
Lloh268:
	adrp	x0, l_.str.127@PAGE
Lloh269:
	add	x0, x0, l_.str.127@PAGEOFF
	b	LBB8_410
LBB8_307:
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB8_309
; %bb.308:
	ldrb	w11, [x11, #4]
	tbz	w11, #0, LBB8_416
LBB8_309:
	ldr	x10, [x8, #8]
	sub	w9, w9, #1
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #1]
	cmp	w10, #1
	b.ne	LBB8_311
; %bb.310:
	ldrb	w10, [x9, #4]
	tbz	w10, #0, LBB8_312
LBB8_311:
Lloh270:
	adrp	x0, l_.str.105@PAGE
Lloh271:
	add	x0, x0, l_.str.105@PAGEOFF
	b	LBB8_410
LBB8_312:
	mov	x21, x6
	mov	x19, x8
	ldr	x0, [x8]
	ldrh	w8, [x9, #2]
	mov	x20, x1
	ldrh	w2, [x1, #8]
	add	x3, sp, #159
	mov	x1, x8
	bl	_nvm_affine_scalar_field
	tbz	w0, #0, LBB8_343
LBB8_313:
	mov	x8, x19
	ldrh	w9, [x19, #16]
	sub	w9, w9, #1
	strh	w9, [x19, #16]
	ldrb	w19, [sp, #159]
	b	LBB8_405
LBB8_314:
	tst	w11, #0xffff
	b.eq	LBB8_319
; %bb.315:
	and	w11, w11, #0xffff
	sub	w11, w11, #1
	mov	w12, #48                        ; =0x30
	umaddl	x10, w11, w12, x10
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB8_319
; %bb.316:
	ldrb	w11, [x10, #4]
	tbnz	w11, #0, LBB8_319
; %bb.317:
	ldrb	w10, [x10]
	cmp	w10, #3
	b.ne	LBB8_319
; %bb.318:
	sub	w9, w9, #2
	strh	w9, [x8, #16]
	b	LBB8_42
LBB8_319:
Lloh272:
	adrp	x0, l_.str.117@PAGE
Lloh273:
	add	x0, x0, l_.str.117@PAGEOFF
	b	LBB8_410
LBB8_320:
	mov	x0, x21
	tbz	w25, #0, LBB8_322
; %bb.321:
	ldr	x0, [x0]
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	mov	x8, x0
	mov	x0, x21
	cbz	w8, LBB8_256
LBB8_322:
	ldrh	w8, [x0, #16]
	sub	w8, w8, #1
	strh	w8, [x0, #16]
	mov	x1, #-4294967295                ; =0xffffffff00000001
	bl	_array_push_type
Lloh274:
	adrp	x8, l_.str.133@PAGE
Lloh275:
	add	x8, x8, l_.str.133@PAGEOFF
	b	LBB8_376
LBB8_323:
	mov	x8, x21
	subs	w9, w22, #81
	b.eq	LBB8_390
; %bb.324:
	tbz	w20, #0, LBB8_390
; %bb.325:
Lloh276:
	adrp	x0, l_.str.135@PAGE
Lloh277:
	add	x0, x0, l_.str.135@PAGEOFF
	b	LBB8_410
LBB8_326:
	mov	x1, x26
	b	LBB8_258
LBB8_327:
	mov	w10, #48                        ; =0x30
	umaddl	x8, w9, w10, x8
	ldur	w8, [x8, #-40]
	ldrh	w2, [x1, #8]
	mov	x0, x3
	add	x3, sp, #160
	mov	x1, x8
	bl	_union_fact_for_layout
Lloh278:
	adrp	x8, l_.str.97@PAGE
Lloh279:
	add	x8, x8, l_.str.97@PAGEOFF
	b	LBB8_376
LBB8_328:
Lloh280:
	adrp	x0, l_.str.69@PAGE
Lloh281:
	add	x0, x0, l_.str.69@PAGEOFF
	b	LBB8_410
LBB8_329:
	ldrb	w12, [x6]
	tbnz	w12, #0, LBB8_374
; %bb.330:
	ldrb	w11, [x11]
	cmp	w11, #5
	b.ne	LBB8_374
; %bb.331:
Lloh282:
	adrp	x0, l_.str.107@PAGE
Lloh283:
	add	x0, x0, l_.str.107@PAGEOFF
	b	LBB8_410
LBB8_332:
	ldrb	w11, [x6]
	tbnz	w11, #0, LBB8_335
; %bb.333:
	ldrb	w10, [x10]
	cmp	w10, #5
	b.ne	LBB8_335
; %bb.334:
Lloh284:
	adrp	x0, l_.str.109@PAGE
Lloh285:
	add	x0, x0, l_.str.109@PAGEOFF
	b	LBB8_410
LBB8_335:
	mov	x0, #0                          ; =0x0
LBB8_336:
	sub	w9, w9, #1
	strh	w9, [x8, #16]
	b	LBB8_410
LBB8_337:
	ldr	x0, [x21]
	sub	x2, x29, #176
	mov	x1, x19
	bl	_nvm_affine_array_tag_type
	tbz	w0, #0, LBB8_414
LBB8_338:
	mov	w22, #0                         ; =0x0
LBB8_339:
	ldrh	w9, [x21, #16]
	sub	w9, w9, w22
	strh	w9, [x21, #16]
	ldur	x19, [x29, #-176]
	ldr	x0, [x21]
	mov	x1, x19
	bl	_nvm_affine_type_is_owned
	ldrh	w8, [x21, #16]
	cmp	x8, #256
	b.eq	LBB8_342
; %bb.340:
	mov	x20, x0
	ldr	x0, [x21, #8]
	mov	w9, #48                         ; =0x30
	umull	x8, w8, w9
	add	x1, x8, #48
	bl	_realloc
	cbz	x0, LBB8_342
; %bb.341:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	ldrh	w9, [x21, #16]
	add	w10, w9, #1
	strh	w10, [x21, #16]
	lsr	x10, x19, #32
	str	x8, [x21, #8]
	mov	w11, #48                        ; =0x30
	umaddl	x8, w9, w11, x8
	strb	w19, [x8]
	strb	wzr, [x8, #1]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [x8, #2]
	strb	w20, [x8, #4]
	sturh	wzr, [x8, #5]
	strb	wzr, [x8, #7]
	str	w10, [x8, #8]
	b	LBB8_408
LBB8_342:
Lloh286:
	adrp	x0, l_.str.129@PAGE
Lloh287:
	add	x0, x0, l_.str.129@PAGEOFF
	b	LBB8_410
LBB8_343:
	ldrb	w8, [x21]
	cmp	w8, #1
	b.ne	LBB8_311
; %bb.344:
	ldp	x0, x9, [x19]
	ldrh	w8, [x19, #16]
	mov	w10, #48                        ; =0x30
	umaddl	x8, w8, w10, x9
	ldurh	w1, [x8, #-46]
	ldrh	w2, [x20, #8]
	add	x3, sp, #159
	bl	_nvm_affine_string_field
	cbnz	w0, LBB8_313
	b	LBB8_311
LBB8_345:
	mov	x8, x20
	cbz	w9, LBB8_466
; %bb.346:
	str	x19, [sp, #24]                  ; 8-byte Folded Spill
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	add	x24, sp, #160
Lloh288:
	adrp	x0, l_.str.72@PAGE
Lloh289:
	add	x0, x0, l_.str.72@PAGEOFF
	b	LBB8_348
LBB8_347:                               ;   in Loop: Header=BB8_348 Depth=1
	add	x24, x24, #8
	add	x22, x22, #1
	ldrh	w9, [sp, #88]
	add	x21, x21, #48
	cmp	x22, x9
	mov	x8, x20
	b.hs	LBB8_465
LBB8_348:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8, #8]
	ldrh	w11, [x8, #16]
	sub	x9, x11, w9, uxth
	mov	w11, #48                        ; =0x30
	smaddl	x10, w9, w11, x10
	add	x9, x10, x21
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB8_410
; %bb.349:                              ;   in Loop: Header=BB8_348 Depth=1
	ldrb	w26, [x24]
	ldrb	w10, [x10, x21]
	cmp	w10, w26
	b.ne	LBB8_410
; %bb.350:                              ;   in Loop: Header=BB8_348 Depth=1
	mov	x28, x0
	ldrb	w19, [x9, #4]
	ldr	w27, [x9, #8]
	ldrb	w9, [x24, #3]
	ldurh	w10, [x24, #1]
	orr	w9, w10, w9, lsl #16
	ldr	w25, [x24, #4]
	ldr	x0, [x8]
	lsl	w8, w9, #8
	orr	x8, x8, x26
	orr	x1, x8, x25, lsl #32
	bl	_nvm_affine_type_is_owned
	eor	w8, w0, w19
	tbnz	w8, #0, LBB8_454
; %bb.351:                              ;   in Loop: Header=BB8_348 Depth=1
	and	w8, w26, #0xfffffffd
	cmp	w8, #8
	mov	x0, x28
	b.ne	LBB8_347
; %bb.352:                              ;   in Loop: Header=BB8_348 Depth=1
	cmp	w27, w25
	b.eq	LBB8_347
	b	LBB8_410
LBB8_353:
	mov	x0, x22
LBB8_354:
	cmp	w8, #7
	b.ne	LBB8_357
; %bb.355:
	ldr	x0, [x0]
	add	x2, sp, #160
	mov	x1, x19
	bl	_nvm_affine_local_type
	cbz	w0, LBB8_389
; %bb.356:
	ldr	w21, [sp, #164]
	ldr	x0, [x22]
	ldr	x1, [sp, #160]
	bl	_nvm_affine_type_is_owned
	mov	x20, x0
	mov	x0, x22
	ldrb	w8, [sp, #159]
LBB8_357:
	cmp	w8, #10
	b.ne	LBB8_361
; %bb.358:
	ldr	x0, [x0]
	add	x2, sp, #160
	mov	x1, x19
	bl	_nvm_affine_local_type
	cbz	w0, LBB8_415
; %bb.359:
	ldr	x0, [x22]
	ldr	x1, [sp, #160]
	bl	_nvm_affine_type_is_owned
	cbz	w0, LBB8_430
; %bb.360:
Lloh290:
	adrp	x0, l_.str.92@PAGE
Lloh291:
	add	x0, x0, l_.str.92@PAGEOFF
	b	LBB8_410
LBB8_361:
	mov	w9, #65535                      ; =0xffff
LBB8_362:
	strh	wzr, [sp, #206]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #30]
	stur	q0, [x24, #14]
	strb	w8, [sp, #160]
	strb	w20, [sp, #161]
	strh	w19, [sp, #162]
	stp	wzr, w21, [sp, #164]
	strh	w9, [sp, #172]
	add	x1, sp, #160
	b	LBB8_375
LBB8_363:
Lloh292:
	adrp	x0, l_.str.89@PAGE
Lloh293:
	add	x0, x0, l_.str.89@PAGEOFF
	b	LBB8_410
LBB8_364:
	mov	x0, x24
	bl	_nvm_affine_state_free
LBB8_365:
Lloh294:
	adrp	x0, l_.str.39@PAGE
Lloh295:
	add	x0, x0, l_.str.39@PAGEOFF
	b	LBB8_410
LBB8_366:
	ldrh	w9, [x27, #16]
	cbz	x9, LBB8_422
; %bb.367:
	mov	x8, x27
	ldr	x12, [x27, #8]
	mov	w13, #48                        ; =0x30
	umaddl	x12, w9, w13, x12
	ldurb	w13, [x12, #-47]
Lloh296:
	adrp	x0, l_.str.87@PAGE
Lloh297:
	add	x0, x0, l_.str.87@PAGEOFF
	tbnz	w13, #0, LBB8_410
; %bb.368:
	ldurb	w13, [x12, #-44]
	tbnz	w13, #0, LBB8_410
; %bb.369:
	ldur	w13, [x12, #-40]
	ldurb	w12, [x12, #-48]
	cmp	w12, w21
	ccmp	w13, w20, #0, eq
	b.ne	LBB8_410
; %bb.370:
	tbnz	w23, #0, LBB8_373
; %bb.371:
	mov	x10, x26
	ldrb	w12, [x26, #2]
	tbnz	w12, #0, LBB8_373
; %bb.372:
	add	x9, x8, x19
	ldrb	w9, [x9, #22]
	tst	w9, #0x2
	mov	w12, #2                         ; =0x2
	cinc	w12, w12, eq
	tst	w9, #0x8
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, eq
	mov	w11, w25
	add	x10, x10, x11, lsl #8
	add	x10, x10, x19
	ldrb	w11, [x10, #2056]
	and	w11, w12, w11
	and	w9, w11, w9
	strb	w9, [x10, #2056]
	ldrh	w9, [x8, #16]
LBB8_373:
	mov	x0, #0                          ; =0x0
	add	x10, x8, x19
	ldrb	w11, [x10, #22]
	orr	w11, w11, w11, lsl #1
	mov	w12, #10                        ; =0xa
	and	w11, w11, w12
	strb	w11, [x10, #22]
	b	LBB8_336
LBB8_374:
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldur	q0, [x9, #-48]
	str	q0, [sp, #160]
	ldur	q0, [x9, #-32]
	str	q0, [sp, #176]
	ldur	q0, [x9, #-16]
	str	q0, [sp, #192]
	add	x1, sp, #160
	mov	x0, x8
LBB8_375:
	bl	_push
Lloh298:
	adrp	x8, l_.str.93@PAGE
Lloh299:
	add	x8, x8, l_.str.93@PAGEOFF
LBB8_376:
	cmp	w0, #0
	csel	x0, xzr, x8, ne
	b	LBB8_410
LBB8_377:
	mov	x8, x19
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	cbz	w25, LBB8_381
; %bb.378:
	mov	x27, #0                         ; =0x0
	ldr	x11, [sp, #24]                  ; 8-byte Folded Reload
	and	x9, x11, #0xffff
	add	x10, sp, #160
	add	x28, x10, #16
	add	x9, x9, w11, uxth #1
	lsl	x24, x9, #4
LBB8_379:                               ; =>This Inner Loop Header: Depth=1
	ldp	x0, x8, [x8]
	add	x8, x8, x24
	ldr	q0, [x8]
	stur	q0, [x29, #-176]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-160]
	ldr	q0, [x8, #32]
	stur	q0, [x29, #-144]
	ldr	x2, [x28, x27, lsl #3]
	sub	x1, x29, #176
	bl	_effect_value_matches
	tbz	w0, #0, LBB8_444
; %bb.380:                              ;   in Loop: Header=BB8_379 Depth=1
	add	x27, x27, #1
	ldrh	w8, [sp, #164]
	add	x24, x24, #48
	cmp	x27, x8
	mov	x8, x19
	b.lo	LBB8_379
LBB8_381:
	cmp	w26, w25
	ldr	x24, [sp, #24]                  ; 8-byte Folded Reload
	b.eq	LBB8_386
; %bb.382:
	ldr	x10, [x8, #8]
	and	x9, x24, #0xffff
	add	x10, x10, #4
Lloh300:
	adrp	x0, l_.str.52@PAGE
Lloh301:
	add	x0, x0, l_.str.52@PAGEOFF
LBB8_383:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10]
	tbnz	w11, #0, LBB8_410
; %bb.384:                              ;   in Loop: Header=BB8_383 Depth=1
	ldurb	w11, [x10, #-3]
	tbnz	w11, #0, LBB8_410
; %bb.385:                              ;   in Loop: Header=BB8_383 Depth=1
	add	x10, x10, #48
	subs	x9, x9, #1
	b.ne	LBB8_383
LBB8_386:
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	cbz	w0, LBB8_447
; %bb.387:
	ldr	w4, [sp, #160]
	mov	x0, x21
	mov	x1, x22
	mov	x2, x20
	mov	x3, x19
	bl	_effect_escape
	cbz	w0, LBB8_467
; %bb.388:
	strh	w24, [x19, #16]
	ldrb	w20, [sp, #168]
	ldr	w21, [sp, #172]
	sturb	wzr, [x29, #-169]
	sturh	wzr, [x23, #5]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #14]
	stur	q0, [x23, #30]
	sturh	wzr, [x29, #-130]
	ldr	x0, [x19]
	orr	x1, x20, x21, lsl #32
	bl	_nvm_affine_type_is_owned
	sturb	w20, [x29, #-176]
	sturb	wzr, [x29, #-175]
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x29, #-174]
	sturb	w0, [x29, #-172]
	stur	w21, [x29, #-168]
	sturh	w8, [x29, #-164]
	sub	x1, x29, #176
	mov	x0, x19
	bl	_push
Lloh302:
	adrp	x8, l_.str.54@PAGE
Lloh303:
	add	x8, x8, l_.str.54@PAGEOFF
	b	LBB8_376
LBB8_389:
Lloh304:
	adrp	x0, l_.str.90@PAGE
Lloh305:
	add	x0, x0, l_.str.90@PAGEOFF
	b	LBB8_410
LBB8_390:
	cmp	w9, #6
	b.hi	LBB8_451
; %bb.391:
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w9
	mov	w11, #108                       ; =0x6c
	tst	w10, w11
	b.eq	LBB8_448
; %bb.392:
	ldr	x9, [x8, #8]
	ldrh	w10, [x8, #16]
	sub	w11, w10, w24
	mov	w12, #48                        ; =0x30
	smaddl	x12, w11, w12, x9
	ldrb	w13, [x12, #48]
Lloh306:
	adrp	x0, l_.str.136@PAGE
Lloh307:
	add	x0, x0, l_.str.136@PAGEOFF
	cmp	w13, #1
	b.ne	LBB8_410
; %bb.393:
	ldrb	w13, [x12, #52]
	tbnz	w13, #0, LBB8_410
; %bb.394:
	ldrb	w12, [x12, #49]
	tbnz	w12, #0, LBB8_410
; %bb.395:
	cmp	w22, #84
	b.eq	LBB8_450
; %bb.396:
	cmp	w22, #86
	b.ne	LBB8_451
; %bb.397:
	mov	w8, #48                         ; =0x30
	umaddl	x8, w10, w8, x9
	ldurb	w9, [x8, #-48]
Lloh308:
	adrp	x0, l_.str.137@PAGE
Lloh309:
	add	x0, x0, l_.str.137@PAGEOFF
	cmp	w9, #1
	b.ne	LBB8_410
; %bb.398:
	ldurb	w9, [x8, #-44]
	tbnz	w9, #0, LBB8_410
; %bb.399:
	ldurb	w8, [x8, #-47]
	tbnz	w8, #0, LBB8_410
; %bb.400:
	mov	x8, x21
	strh	w11, [x21, #16]
	b	LBB8_453
LBB8_401:
	sub	w9, w9, #1
LBB8_402:
	strh	w9, [x8, #16]
LBB8_403:
	mov	w19, #1                         ; =0x1
LBB8_404:
	strb	w19, [sp, #159]
LBB8_405:
	ldrh	w9, [x8, #16]
	cmp	x9, #256
	b.eq	LBB8_409
; %bb.406:
	mov	x20, x8
	ldr	x0, [x8, #8]
	mov	w8, #48                         ; =0x30
	umull	x8, w9, w8
	add	x1, x8, #48
	bl	_realloc
	cbz	x0, LBB8_409
; %bb.407:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	ldrh	w9, [x20, #16]
	add	w10, w9, #1
	strh	w10, [x20, #16]
	str	x8, [x20, #8]
	mov	w10, #48                        ; =0x30
	umaddl	x8, w9, w10, x8
	strb	w19, [x8]
	strb	wzr, [x8, #1]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [x8, #2]
	movi	d0, #0xffffffff00000000
	stur	d0, [x8, #4]
LBB8_408:
	strh	w9, [x8, #12]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #14]
	stur	q0, [x8, #30]
	strh	wzr, [x8, #46]
	b	LBB8_410
LBB8_409:
Lloh310:
	adrp	x0, l_.str.93@PAGE
Lloh311:
	add	x0, x0, l_.str.93@PAGEOFF
LBB8_410:
	ldur	x8, [x29, #-104]
Lloh312:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh313:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh314:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB8_485
; %bb.411:
	add	sp, sp, #2320
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB8_412:
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldurb	w20, [x9, #-48]
	sub	w10, w20, #1
	cmp	w10, #3
	b.hi	LBB8_425
; %bb.413:
	mov	x21, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_scalar_define
	tbnz	w0, #0, LBB8_456
	b	LBB8_469
LBB8_414:
Lloh315:
	adrp	x0, l_.str.126@PAGE
Lloh316:
	add	x0, x0, l_.str.126@PAGEOFF
	b	LBB8_410
LBB8_415:
Lloh317:
	adrp	x0, l_.str.91@PAGE
Lloh318:
	add	x0, x0, l_.str.91@PAGEOFF
	b	LBB8_410
LBB8_416:
	mov	w11, #48                        ; =0x30
	umaddl	x9, w9, w11, x10
	ldurh	w2, [x9, #-36]
	mov	w10, #65535                     ; =0xffff
	cmp	w2, w10
	b.eq	LBB8_459
; %bb.417:
	mov	x19, x1
	ldur	w1, [x9, #-40]
	sturh	wzr, [x29, #-176]
	mov	x20, x8
	ldr	x0, [x8]
	add	x3, sp, #160
	sub	x5, x29, #176
	mov	w4, #256                        ; =0x100
	bl	_nvm_affine_union_fields
	cbz	w0, LBB8_445
; %bb.418:
	ldrh	w8, [x19, #8]
	ldurh	w9, [x29, #-176]
	cmp	w8, w9
	b.hs	LBB8_445
; %bb.419:
	lsl	x8, x8, #3
	add	x9, sp, #160
	ldrb	w19, [x9, x8]
	sub	w8, w19, #1
	cmp	w8, #5
	b.hs	LBB8_474
; %bb.420:
	strb	w19, [sp, #159]
	mov	x8, x20
	ldrh	w9, [x20, #16]
	sub	w9, w9, #1
	strh	w9, [x20, #16]
	b	LBB8_405
LBB8_421:
Lloh319:
	adrp	x0, l_.str.47@PAGE
Lloh320:
	add	x0, x0, l_.str.47@PAGEOFF
	b	LBB8_410
LBB8_422:
Lloh321:
	adrp	x0, l_.str.86@PAGE
Lloh322:
	add	x0, x0, l_.str.86@PAGEOFF
	b	LBB8_410
LBB8_423:
Lloh323:
	adrp	x0, l_.str.99@PAGE
Lloh324:
	add	x0, x0, l_.str.99@PAGEOFF
	b	LBB8_410
LBB8_424:
Lloh325:
	adrp	x0, l_.str.70@PAGE
Lloh326:
	add	x0, x0, l_.str.70@PAGEOFF
	b	LBB8_410
LBB8_425:
	ldrb	w10, [x6]
	cmp	w20, #5
	ccmp	w10, #0, #4, eq
	b.ne	LBB8_455
; %bb.426:
	ldur	w2, [x9, #-40]
	cmp	w20, #10
	ccmp	w10, #0, #4, eq
	b.ne	LBB8_468
; %bb.427:
	cmp	w20, #8
	ccmp	w10, #0, #4, eq
	b.ne	LBB8_472
; %bb.428:
	cmp	w20, #7
	ccmp	w10, #0, #4, eq
	b.eq	LBB8_469
; %bb.429:
	mov	x21, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_array_define
	cbz	w0, LBB8_469
	b	LBB8_456
LBB8_430:
	ldr	w21, [sp, #164]
	ldr	x0, [x22]
	sub	x2, x29, #176
	mov	x1, x19
	bl	_nvm_affine_union_variant
	mov	x0, x22
	ldrb	w8, [sp, #159]
	ldurh	w9, [x29, #-176]
	b	LBB8_362
LBB8_431:
	strh	wzr, [sp, #144]
	ldr	x0, [x21]
	ldr	w1, [sp, #88]
	add	x3, sp, #160
	add	x5, sp, #144
	mov	x2, x19
	mov	w4, #256                        ; =0x100
	bl	_nvm_affine_union_fields
	mov	x8, x0
Lloh327:
	adrp	x0, l_.str.81@PAGE
Lloh328:
	add	x0, x0, l_.str.81@PAGEOFF
	cbz	w8, LBB8_410
; %bb.432:
	ldrh	w8, [sp, #144]
	cmp	w8, w20
	b.ne	LBB8_410
; %bb.433:
	mov	x8, x21
	cbz	w20, LBB8_471
; %bb.434:
	lsl	x9, x20, #4
	sub	x24, x9, x20, lsl #6
	add	x25, sp, #160
	mov	x27, x20
	b	LBB8_436
LBB8_435:                               ;   in Loop: Header=BB8_436 Depth=1
	add	x25, x25, #8
	add	x24, x24, #48
	subs	x27, x27, #1
	mov	x8, x21
	b.eq	LBB8_471
LBB8_436:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8, #8]
	ldrh	w10, [x8, #16]
	mov	w11, #48                        ; =0x30
	umaddl	x10, w10, w11, x9
	add	x9, x10, x24
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB8_441
; %bb.437:                              ;   in Loop: Header=BB8_436 Depth=1
	ldrb	w22, [x10, x24]
	ldrb	w10, [x25]
	cmp	w22, w10
	b.ne	LBB8_441
; %bb.438:                              ;   in Loop: Header=BB8_436 Depth=1
	ldrb	w26, [x9, #4]
	ldr	w28, [x9, #8]
	ldr	x0, [x8]
	ldr	x1, [x25]
	bl	_nvm_affine_type_is_owned
	eor	w8, w0, w26
	tbnz	w8, #0, LBB8_441
; %bb.439:                              ;   in Loop: Header=BB8_436 Depth=1
	and	w8, w22, #0xfffffffd
	cmp	w8, #8
	b.ne	LBB8_435
; %bb.440:                              ;   in Loop: Header=BB8_436 Depth=1
	ldr	w8, [x25, #4]
	cmp	w28, w8
	b.eq	LBB8_435
LBB8_441:
Lloh329:
	adrp	x0, l_.str.82@PAGE
Lloh330:
	add	x0, x0, l_.str.82@PAGEOFF
	b	LBB8_410
LBB8_442:
	sub	x10, x9, #48
	ldrb	w12, [x6]
	tbz	w12, #0, LBB8_462
LBB8_443:
	mov	x0, #0                          ; =0x0
	ldp	q1, q0, [x10, #16]
	ldr	q2, [x10]
	ldp	q3, q4, [x9, #-96]
	stp	q3, q4, [x10]
	ldur	q3, [x9, #-64]
	str	q3, [x10, #32]
	ldr	x9, [x8, #8]
	ldrh	w8, [x8, #16]
	mov	w10, #48                        ; =0x30
	umaddl	x8, w8, w10, x9
	stp	q2, q1, [x8, #-96]
	stur	q0, [x8, #-64]
	b	LBB8_410
LBB8_444:
Lloh331:
	adrp	x0, l_.str.51@PAGE
Lloh332:
	add	x0, x0, l_.str.51@PAGEOFF
	b	LBB8_410
LBB8_445:
Lloh333:
	adrp	x0, l_.str.103@PAGE
Lloh334:
	add	x0, x0, l_.str.103@PAGEOFF
	b	LBB8_410
LBB8_446:
	mov	w19, #5                         ; =0x5
	strb	w19, [sp, #159]
	mov	x8, x20
	b	LBB8_405
LBB8_447:
Lloh335:
	adrp	x0, l_.str.53@PAGE
Lloh336:
	add	x0, x0, l_.str.53@PAGEOFF
	b	LBB8_410
LBB8_448:
	cbnz	w9, LBB8_451
; %bb.449:
	ldr	x9, [x8, #8]
	ldrh	w10, [x8, #16]
LBB8_450:
	ldr	x0, [x8]
	mov	w8, #48                         ; =0x30
	umaddl	x8, w10, w8, x9
	ldrb	w9, [sp, #88]
	ldr	w10, [sp, #92]
	ldur	q0, [x8, #-48]
	str	q0, [sp, #160]
	ldur	q0, [x8, #-32]
	str	q0, [sp, #176]
	ldur	q0, [x8, #-16]
	str	q0, [sp, #192]
	orr	x2, x9, x10, lsl #32
	add	x1, sp, #160
	bl	_effect_value_matches
	mov	x8, x21
	cbz	w0, LBB8_470
LBB8_451:
	ldrh	w9, [x8, #16]
	sub	w9, w9, w24
	strh	w9, [x8, #16]
	and	w9, w22, #0xfe
	cmp	w9, #82
	b.ne	LBB8_453
; %bb.452:
	ldr	x9, [sp, #88]
	stur	x9, [x29, #-176]
LBB8_453:
	ldur	x1, [x29, #-176]
	mov	x0, x8
	bl	_array_push_type
Lloh337:
	adrp	x8, l_.str.139@PAGE
Lloh338:
	add	x8, x8, l_.str.139@PAGEOFF
	b	LBB8_376
LBB8_454:
	mov	x0, x28
	b	LBB8_410
LBB8_455:
	mov	x21, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_string_define
	tbz	w0, #0, LBB8_469
LBB8_456:
	ldr	x0, [x21]
	add	x2, sp, #159
	add	x3, sp, #88
	mov	x1, x19
	bl	_nvm_affine_local_info
	mov	x8, x0
Lloh339:
	adrp	x0, l_.str.95@PAGE
Lloh340:
	add	x0, x0, l_.str.95@PAGEOFF
	cbz	w8, LBB8_410
; %bb.457:
	ldrb	w8, [sp, #159]
	cmp	w8, w20
	b.ne	LBB8_410
; %bb.458:
	mov	x0, #0                          ; =0x0
	ldrh	w8, [x21, #16]
	sub	w8, w8, #1
	strh	w8, [x21, #16]
	b	LBB8_410
LBB8_459:
Lloh341:
	adrp	x0, l_.str.102@PAGE
Lloh342:
	add	x0, x0, l_.str.102@PAGEOFF
	b	LBB8_410
LBB8_460:
	mov	x0, #0                          ; =0x0
	b	LBB8_410
LBB8_461:
	mov	x0, x25
	b	LBB8_410
LBB8_462:
	ldrb	w12, [x10]
	cmp	w12, #5
	b.eq	LBB8_464
; %bb.463:
	ldrb	w11, [x11]
	cmp	w11, #5
	b.ne	LBB8_443
LBB8_464:
Lloh343:
	adrp	x0, l_.str.111@PAGE
Lloh344:
	add	x0, x0, l_.str.111@PAGEOFF
	b	LBB8_410
LBB8_465:
	ldrh	w10, [x8, #16]
	ldr	x19, [sp, #24]                  ; 8-byte Folded Reload
LBB8_466:
	sub	w9, w10, w9
	strh	w9, [x8, #16]
	sturb	wzr, [x29, #-169]
	sturh	wzr, [x23, #5]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #14]
	stur	q0, [x23, #30]
	sturh	wzr, [x29, #-130]
	mov	w9, #-65528                     ; =0xffff0008
	stur	w9, [x29, #-176]
	mov	w9, #1                          ; =0x1
	sturb	w9, [x29, #-172]
	stur	w19, [x29, #-168]
	mov	w9, #65535                      ; =0xffff
	sturh	w9, [x29, #-164]
	sub	x1, x29, #176
	mov	x0, x8
	b	LBB8_262
LBB8_467:
Lloh345:
	adrp	x0, l_.str.44@PAGE
Lloh346:
	add	x0, x0, l_.str.44@PAGEOFF
	b	LBB8_410
LBB8_468:
	ldurh	w3, [x9, #-36]
	mov	x21, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_union_define
	tbnz	w0, #0, LBB8_456
LBB8_469:
Lloh347:
	adrp	x0, l_.str.95@PAGE
Lloh348:
	add	x0, x0, l_.str.95@PAGEOFF
	b	LBB8_410
LBB8_470:
Lloh349:
	adrp	x0, l_.str.138@PAGE
Lloh350:
	add	x0, x0, l_.str.138@PAGEOFF
	b	LBB8_410
LBB8_471:
	ldrh	w9, [x8, #16]
	sub	w9, w9, w20
	strh	w9, [x8, #16]
	sturb	wzr, [x29, #-169]
	sturh	wzr, [x23, #5]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #14]
	stur	q0, [x23, #30]
	sturh	wzr, [x29, #-130]
	ldr	x0, [x8]
	ldr	w9, [sp, #88]
	mov	w10, #10                        ; =0xa
	orr	x1, x10, x9, lsl #32
	mov	x20, x8
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #88]
	mov	w9, #-65526                     ; =0xffff000a
	stur	w9, [x29, #-176]
	sturb	w0, [x29, #-172]
	stur	w8, [x29, #-168]
	sturh	w19, [x29, #-164]
	sub	x1, x29, #176
	mov	x0, x20
	bl	_push
Lloh351:
	adrp	x8, l_.str.83@PAGE
Lloh352:
	add	x8, x8, l_.str.83@PAGEOFF
	b	LBB8_376
LBB8_472:
	mov	x21, x8
	ldr	x0, [x8]
	mov	x1, x19
	bl	_nvm_affine_record_define
	tbz	w0, #0, LBB8_469
	b	LBB8_456
LBB8_473:
Lloh353:
	adrp	x0, l_.str.41@PAGE
Lloh354:
	add	x0, x0, l_.str.41@PAGEOFF
	b	LBB8_410
LBB8_474:
Lloh355:
	adrp	x0, l_.str.104@PAGE
Lloh356:
	add	x0, x0, l_.str.104@PAGEOFF
	b	LBB8_410
LBB8_475:
	cbz	w8, LBB8_482
; %bb.476:
	ldr	x11, [x20, #8]
	add	x10, sp, #160
	add	x10, x10, #4
	mov	w12, #48                        ; =0x30
	umull	x13, w9, w12
	umsubl	x12, w8, w12, x13
	add	x11, x11, x12
	add	x11, x11, #4
Lloh357:
	adrp	x0, l_.str.77@PAGE
Lloh358:
	add	x0, x0, l_.str.77@PAGEOFF
	mov	x12, x8
LBB8_477:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-3]
	tbnz	w13, #0, LBB8_410
; %bb.478:                              ;   in Loop: Header=BB8_477 Depth=1
	ldrb	w13, [x11]
	tbnz	w13, #0, LBB8_410
; %bb.479:                              ;   in Loop: Header=BB8_477 Depth=1
	ldurb	w13, [x11, #-4]
	ldurb	w14, [x10, #-4]
	cmp	w13, w14
	b.ne	LBB8_410
; %bb.480:                              ;   in Loop: Header=BB8_477 Depth=1
	ldr	w13, [x11, #4]
	ldr	w14, [x10], #8
	cmp	w13, w14
	b.ne	LBB8_410
; %bb.481:                              ;   in Loop: Header=BB8_477 Depth=1
	add	x11, x11, #48
	subs	x12, x12, #1
	b.ne	LBB8_477
LBB8_482:
	sub	w8, w9, w8
	mov	x0, x20
	strh	w8, [x20, #16]
	sturh	wzr, [x29, #-130]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #30]
	stur	q0, [x23, #14]
	mov	w8, #-65528                     ; =0xffff0008
	stur	x8, [x29, #-176]
	stur	w19, [x29, #-168]
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x29, #-164]
	sub	x1, x29, #176
	bl	_push
Lloh359:
	adrp	x8, l_.str.78@PAGE
Lloh360:
	add	x8, x8, l_.str.78@PAGEOFF
	b	LBB8_376
LBB8_483:
	mov	x0, x20
	ldrh	w8, [x20, #16]
	sub	w8, w8, #1
	strh	w8, [x20, #16]
	sturh	wzr, [x29, #-130]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #30]
	stur	q0, [x23, #14]
	sturb	w19, [x29, #-176]
	sturb	wzr, [x29, #-175]
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x29, #-174]
	stp	wzr, w21, [x29, #-172]
	sturh	w8, [x29, #-164]
	sub	x1, x29, #176
	bl	_push
Lloh361:
	adrp	x8, l_.str.101@PAGE
Lloh362:
	add	x8, x8, l_.str.101@PAGEOFF
	b	LBB8_376
LBB8_484:
Lloh363:
	adrp	x0, l_.str.42@PAGE
Lloh364:
	add	x0, x0, l_.str.42@PAGEOFF
	b	LBB8_410
LBB8_485:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh139, Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpLdrGotLdr	Lloh312, Lloh313, Lloh314
	.loh AdrpAdd	Lloh315, Lloh316
	.loh AdrpAdd	Lloh317, Lloh318
	.loh AdrpAdd	Lloh319, Lloh320
	.loh AdrpAdd	Lloh321, Lloh322
	.loh AdrpAdd	Lloh323, Lloh324
	.loh AdrpAdd	Lloh325, Lloh326
	.loh AdrpAdd	Lloh327, Lloh328
	.loh AdrpAdd	Lloh329, Lloh330
	.loh AdrpAdd	Lloh331, Lloh332
	.loh AdrpAdd	Lloh333, Lloh334
	.loh AdrpAdd	Lloh335, Lloh336
	.loh AdrpAdd	Lloh337, Lloh338
	.loh AdrpAdd	Lloh339, Lloh340
	.loh AdrpAdd	Lloh341, Lloh342
	.loh AdrpAdd	Lloh343, Lloh344
	.loh AdrpAdd	Lloh345, Lloh346
	.loh AdrpAdd	Lloh347, Lloh348
	.loh AdrpAdd	Lloh349, Lloh350
	.loh AdrpAdd	Lloh351, Lloh352
	.loh AdrpAdd	Lloh353, Lloh354
	.loh AdrpAdd	Lloh355, Lloh356
	.loh AdrpAdd	Lloh357, Lloh358
	.loh AdrpAdd	Lloh359, Lloh360
	.loh AdrpAdd	Lloh361, Lloh362
	.loh AdrpAdd	Lloh363, Lloh364
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI8_0:
	.short	(LBB8_410-LBB8_2)>>2
	.short	(LBB8_403-LBB8_2)>>2
	.short	(LBB8_42-LBB8_2)>>2
	.short	(LBB8_154-LBB8_2)>>2
	.short	(LBB8_173-LBB8_2)>>2
	.short	(LBB8_139-LBB8_2)>>2
	.short	(LBB8_180-LBB8_2)>>2
	.short	(LBB8_181-LBB8_2)>>2
	.short	(LBB8_190-LBB8_2)>>2
	.short	(LBB8_161-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_126-LBB8_2)>>2
	.short	(LBB8_167-LBB8_2)>>2
	.short	(LBB8_149-LBB8_2)>>2
	.short	(LBB8_156-LBB8_2)>>2
	.short	(LBB8_131-LBB8_2)>>2
	.short	(LBB8_185-LBB8_2)>>2
	.short	(LBB8_195-LBB8_2)>>2
	.short	(LBB8_100-LBB8_2)>>2
	.short	(LBB8_100-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_200-LBB8_2)>>2
	.short	(LBB8_194-LBB8_2)>>2
	.short	(LBB8_44-LBB8_2)>>2
	.short	(LBB8_44-LBB8_2)>>2
	.short	(LBB8_86-LBB8_2)>>2
	.short	(LBB8_86-LBB8_2)>>2
	.short	(LBB8_44-LBB8_2)>>2
	.short	(LBB8_44-LBB8_2)>>2
	.short	(LBB8_93-LBB8_2)>>2
	.short	(LBB8_93-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_15-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_25-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_60-LBB8_2)>>2
	.short	(LBB8_60-LBB8_2)>>2
	.short	(LBB8_60-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_410-LBB8_2)>>2
	.short	(LBB8_81-LBB8_2)>>2
	.short	(LBB8_81-LBB8_2)>>2
	.short	(LBB8_201-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_2-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_153-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_117-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_94-LBB8_2)>>2
	.short	(LBB8_108-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_410-LBB8_2)>>2
	.short	(LBB8_94-LBB8_2)>>2
	.short	(LBB8_410-LBB8_2)>>2
	.short	(LBB8_234-LBB8_2)>>2
	.short	(LBB8_113-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_37-LBB8_2)>>2
	.short	(LBB8_37-LBB8_2)>>2
	.short	(LBB8_37-LBB8_2)>>2
	.short	(LBB8_37-LBB8_2)>>2
	.short	(LBB8_37-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_6-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_140-LBB8_2)>>2
	.short	(LBB8_236-LBB8_2)>>2
	.short	(LBB8_248-LBB8_2)>>2
	.short	(LBB8_121-LBB8_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function frame_free
_frame_free:                            ; @frame_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_affine_state_free
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB9_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function propagate
_propagate:                             ; @propagate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x28, x27, [sp, #144]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x21, x3
	mov	x20, x1
	mov	x22, x0
	ldr	x23, [x0, w1, uxtw #3]
	cbz	x23, LBB10_8
; %bb.1:
	ldrh	w8, [x23, #278]
	ldrh	w9, [x2, #278]
	cmp	w8, w9
	b.ne	LBB10_5
; %bb.2:
	ldrh	w9, [x23, #280]
	ldrh	w10, [x2, #280]
	cmp	w9, w10
	b.ne	LBB10_5
; %bb.3:
	ldr	w9, [x23, #284]
	ldr	w10, [x2, #284]
	cmp	w9, w10
	b.ne	LBB10_5
; %bb.4:
	lsl	x8, x8, #3
	add	x0, x23, #288
	add	x1, x2, #288
	stur	x2, [x29, #-96]                 ; 8-byte Folded Spill
	mov	x2, x8
	bl	_memcmp
	ldur	x8, [x29, #-96]                 ; 8-byte Folded Reload
	cbz	w0, LBB10_15
LBB10_5:
	mov	w0, #0                          ; =0x0
Lloh365:
	adrp	x8, l_.str.140@PAGE
Lloh366:
	add	x8, x8, l_.str.140@PAGEOFF
LBB10_6:
	str	x8, [x19]
LBB10_7:
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
LBB10_8:
	mov	x0, x2
	bl	_frame_clone
	str	x0, [x22, w20, uxtw #3]
	cbz	x0, LBB10_11
LBB10_9:
	ldr	x8, [x21, #8]
	ldrb	w9, [x8, w20, uxtw]
	tbz	w9, #0, LBB10_12
LBB10_10:
	mov	w0, #1                          ; =0x1
	b	LBB10_7
LBB10_11:
Lloh367:
	adrp	x8, l_.str.143@PAGE
Lloh368:
	add	x8, x8, l_.str.143@PAGEOFF
	b	LBB10_6
LBB10_12:
	ldr	w9, [x21, #28]
	ldr	w10, [x21, #16]
	cmp	w9, w10
	b.ne	LBB10_14
; %bb.13:
	mov	w0, #0                          ; =0x0
Lloh369:
	adrp	x8, l_.str.144@PAGE
Lloh370:
	add	x8, x8, l_.str.144@PAGEOFF
	b	LBB10_6
LBB10_14:
	ldr	x9, [x21]
	ldr	w10, [x21, #24]
	str	w20, [x9, x10, lsl #2]
	ldp	w9, w10, [x21, #24]
	add	w9, w9, #1
	ldr	w11, [x21, #16]
	udiv	w12, w9, w11
	msub	w9, w12, w11, w9
	add	w10, w10, #1
	stp	w9, w10, [x21, #24]
	mov	w0, #1                          ; =0x1
	strb	w0, [x8, w20, uxtw]
	b	LBB10_7
LBB10_15:
	sturb	wzr, [x29, #-81]
	ldrh	w9, [x23, #16]
	ldrh	w10, [x8, #16]
	cmp	w9, w10
	b.ne	LBB10_53
; %bb.16:
	cbz	w9, LBB10_44
; %bb.17:
	str	wzr, [sp, #20]                  ; 4-byte Folded Spill
	mov	x17, #0                         ; =0x0
	mov	w4, #40                         ; =0x28
	mov	w1, #65535                      ; =0xffff
Lloh371:
	adrp	x9, l_.str.141@PAGE
Lloh372:
	add	x9, x9, l_.str.141@PAGEOFF
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB10_19
LBB10_18:                               ;   in Loop: Header=BB10_19 Depth=1
	add	x17, x17, #1
	ldrh	w9, [x23, #16]
	add	x4, x4, #48
	cmp	x17, x9
	b.hs	LBB10_45
LBB10_19:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x23, #8]
	add	x11, x9, x4
	ldurb	w26, [x11, #-40]
	ldr	x9, [x8, #8]
	add	x9, x9, x4
	ldurb	w10, [x9, #-40]
	cmp	w26, w10
	b.ne	LBB10_55
; %bb.20:                               ;   in Loop: Header=BB10_19 Depth=1
	ldurb	w24, [x11, #-39]
	ldurb	w10, [x9, #-39]
	cmp	w24, w10
	b.ne	LBB10_55
; %bb.21:                               ;   in Loop: Header=BB10_19 Depth=1
	ldurb	w10, [x11, #-36]
	ldurb	w12, [x9, #-36]
	cmp	w10, w12
	b.ne	LBB10_55
; %bb.22:                               ;   in Loop: Header=BB10_19 Depth=1
	ldurh	w2, [x11, #-38]
	ldur	w12, [x11, #-32]
	ldurh	w5, [x11, #-28]
	ldp	x14, x16, [x11, #-24]
	ldp	x27, x6, [x11, #-8]
	ldurh	w3, [x9, #-38]
	ldur	w13, [x9, #-32]
	ldurh	w7, [x9, #-28]
	ldp	x15, x30, [x9, #-24]
	sub	w11, w26, #7
	ldp	x28, x25, [x9, #-8]
	cmp	w11, #2
	b.lo	LBB10_24
; %bb.23:                               ;   in Loop: Header=BB10_19 Depth=1
	tbz	w10, #0, LBB10_25
LBB10_24:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x0, [x23]
	orr	x1, x26, x12, lsl #32
	stur	w2, [x29, #-100]                ; 4-byte Folded Spill
	orr	x2, x26, x13, lsl #32
	stp	x17, x6, [sp, #96]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #72]             ; 16-byte Folded Spill
	str	w3, [sp, #68]                   ; 4-byte Folded Spill
	str	x4, [sp, #112]                  ; 8-byte Folded Spill
	mov	x27, x5
	str	x25, [sp, #88]                  ; 8-byte Folded Spill
	mov	x25, x7
	mov	x28, x16
	stp	x14, x30, [sp, #48]             ; 16-byte Folded Spill
	stp	x12, x15, [sp, #32]             ; 16-byte Folded Spill
	str	x13, [sp, #24]                  ; 8-byte Folded Spill
	bl	_nvm_affine_types_equal
	ldp	x13, x12, [sp, #24]             ; 16-byte Folded Reload
	ldp	x15, x14, [sp, #40]             ; 16-byte Folded Reload
	ldr	x30, [sp, #56]                  ; 8-byte Folded Reload
	mov	x16, x28
	mov	x7, x25
	ldp	x6, x4, [sp, #104]              ; 16-byte Folded Reload
	mov	x5, x27
	ldp	x27, x25, [sp, #80]             ; 16-byte Folded Reload
	ldr	w3, [sp, #68]                   ; 4-byte Folded Reload
	ldr	x28, [sp, #72]                  ; 8-byte Folded Reload
	ldur	w2, [x29, #-100]                ; 4-byte Folded Reload
	mov	w1, #65535                      ; =0xffff
	ldr	x17, [sp, #96]                  ; 8-byte Folded Reload
	ldur	x8, [x29, #-96]                 ; 8-byte Folded Reload
	cbz	w0, LBB10_55
LBB10_25:                               ;   in Loop: Header=BB10_19 Depth=1
	tbz	w24, #0, LBB10_27
; %bb.26:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w2, w3
	b.ne	LBB10_55
LBB10_27:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w26, #10
	b.ne	LBB10_18
; %bb.28:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w12, w13
	b.ne	LBB10_55
; %bb.29:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w5, w1
	b.eq	LBB10_31
; %bb.30:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w5, w7
	b.eq	LBB10_41
LBB10_31:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x9, [x23, #8]
	mov	w11, #1                         ; =0x1
	lsl	x10, x11, x5
	lsl	x11, x11, x7
	cmp	w5, #64
	mov	x13, #-1                        ; =0xffffffffffffffff
	csinv	x12, x13, x10, hs
	cmp	w5, w1
	csel	x12, x14, x12, eq
	cmp	w7, #64
	csinv	x13, x13, x11, hs
	cmp	w7, w1
	csel	x13, x15, x13, eq
	and	x12, x13, x12
	add	x14, x9, x4
	ldur	x13, [x14, #-24]
	cmp	x13, x12
	b.eq	LBB10_33
; %bb.32:                               ;   in Loop: Header=BB10_19 Depth=1
	stur	x12, [x14, #-24]
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #20]                  ; 4-byte Folded Spill
LBB10_33:                               ;   in Loop: Header=BB10_19 Depth=1
	lsr	w12, w5, #6
	mvn	x13, x10
	lsr	w10, w7, #6
	mvn	x11, x11
	cmp	w12, #1
	csinv	x15, x13, xzr, eq
	cmp	w5, w1
	csel	x15, x16, x15, eq
	cmp	w10, #1
	csinv	x16, x11, xzr, eq
	cmp	w7, w1
	csel	x16, x30, x16, eq
	and	x15, x16, x15
	ldur	x16, [x14, #-16]
	cmp	x16, x15
	b.eq	LBB10_35
; %bb.34:                               ;   in Loop: Header=BB10_19 Depth=1
	stur	x15, [x14, #-16]
	mov	w14, #1                         ; =0x1
	str	w14, [sp, #20]                  ; 4-byte Folded Spill
LBB10_35:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w12, #2
	csinv	x14, x13, xzr, eq
	cmp	w5, w1
	csel	x14, x27, x14, eq
	cmp	w10, #2
	csinv	x15, x11, xzr, eq
	cmp	w7, w1
	csel	x15, x28, x15, eq
	and	x14, x15, x14
	add	x15, x9, x4
	ldur	x16, [x15, #-8]
	cmp	x16, x14
	b.eq	LBB10_37
; %bb.36:                               ;   in Loop: Header=BB10_19 Depth=1
	stur	x14, [x15, #-8]
	mov	w14, #1                         ; =0x1
	str	w14, [sp, #20]                  ; 4-byte Folded Spill
LBB10_37:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w12, #3
	csinv	x12, x13, xzr, eq
	cmp	w5, w1
	csel	x12, x6, x12, eq
	cmp	w10, #3
	csinv	x10, x11, xzr, eq
	cmp	w7, w1
	csel	x10, x25, x10, eq
	and	x10, x10, x12
	ldr	x11, [x9, x4]
	cmp	x11, x10
	b.eq	LBB10_39
; %bb.38:                               ;   in Loop: Header=BB10_19 Depth=1
	str	x10, [x9, x4]
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #20]                  ; 4-byte Folded Spill
LBB10_39:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w5, w1
	b.eq	LBB10_41
; %bb.40:                               ;   in Loop: Header=BB10_19 Depth=1
	add	x9, x9, x4
	sturh	w1, [x9, #-28]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
LBB10_41:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w2, w1
	b.eq	LBB10_18
; %bb.42:                               ;   in Loop: Header=BB10_19 Depth=1
	cmp	w2, w3
	b.eq	LBB10_18
; %bb.43:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x9, [x23, #8]
	add	x9, x9, x4
	sturh	w1, [x9, #-38]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB10_18
LBB10_44:
	mov	w24, #0                         ; =0x0
	b	LBB10_46
LBB10_45:
	ldr	x23, [x22, w20, uxtw #3]
	ldr	w24, [sp, #20]                  ; 4-byte Folded Reload
LBB10_46:
	ldr	x0, [x23]
	ldr	x1, [x8]
	sub	x2, x29, #81
	bl	_nvm_affine_state_meet_initialization
	cbz	w0, LBB10_53
; %bb.47:
	ldr	x8, [x22, w20, uxtw #3]
	ldrh	w9, [x8, #20]
	ldur	x8, [x29, #-96]                 ; 8-byte Folded Reload
	ldrh	w10, [x8, #20]
	cmp	w9, w10
	b.ne	LBB10_56
; %bb.48:
	ldurb	w10, [x29, #-81]
	orr	w10, w24, w10
	cbz	w9, LBB10_57
; %bb.49:
	mov	w11, #22                        ; =0x16
	b	LBB10_51
LBB10_50:                               ;   in Loop: Header=BB10_51 Depth=1
	sub	x12, x11, #21
	add	x11, x11, #1
	cmp	x12, w9, uxtw
	b.hs	LBB10_57
LBB10_51:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x22, w20, uxtw #3]
	ldrb	w14, [x12, x11]
	ldrb	w13, [x8, x11]
	orr	w13, w13, w14
	and	w13, w13, #0xff
	cmp	w13, w14
	b.eq	LBB10_50
; %bb.52:                               ;   in Loop: Header=BB10_51 Depth=1
	strb	w13, [x12, x11]
	ldrh	w9, [x8, #20]
	mov	w10, #1                         ; =0x1
	b	LBB10_50
LBB10_53:
Lloh373:
	adrp	x8, l_.str.141@PAGE
Lloh374:
	add	x8, x8, l_.str.141@PAGEOFF
LBB10_54:
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB10_55:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	b	LBB10_6
LBB10_56:
Lloh375:
	adrp	x8, l_.str.142@PAGE
Lloh376:
	add	x8, x8, l_.str.142@PAGEOFF
	b	LBB10_54
LBB10_57:
	tbnz	w10, #0, LBB10_9
	b	LBB10_10
	.loh AdrpAdd	Lloh365, Lloh366
	.loh AdrpAdd	Lloh367, Lloh368
	.loh AdrpAdd	Lloh369, Lloh370
	.loh AdrpAdd	Lloh371, Lloh372
	.loh AdrpAdd	Lloh373, Lloh374
	.loh AdrpAdd	Lloh375, Lloh376
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function match_refine
_match_refine:                          ; @match_refine
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x0, #16]
	cbz	x8, LBB11_5
; %bb.1:
	ldr	x9, [x0, #8]
	sub	w8, w8, #1
	mov	w10, #48                        ; =0x30
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	cmp	w9, #10
	b.ne	LBB11_5
; %bb.2:
	ldrb	w9, [x8, #1]
	tbnz	w9, #0, LBB11_5
; %bb.3:
	ldrh	w9, [x8, #12]
	mov	w10, #65535                     ; =0xffff
	cmp	w9, w10
	ccmp	w9, w1, #4, ne
	b.ne	LBB11_5
; %bb.4:
	strh	w1, [x8, #12]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #16]
	mov	w0, #1                          ; =0x1
	ret
LBB11_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_fact_for_layout
_union_fact_for_layout:                 ; @union_fact_for_layout
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #476]
	cbz	w8, LBB12_6
; %bb.1:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	w23, #0                         ; =0x0
	b	LBB12_3
LBB12_2:                                ;   in Loop: Header=BB12_3 Depth=1
	add	w23, w23, #1
	ldr	w8, [x22, #476]
	cmp	w23, w8
	b.hs	LBB12_7
LBB12_3:                                ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #4
	mov	x0, x22
	mov	x1, x23
	mov	x2, x20
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB12_2
; %bb.4:                                ;   in Loop: Header=BB12_3 Depth=1
	ldr	w8, [sp, #4]
	cmp	w8, w21
	b.ne	LBB12_2
; %bb.5:
	ldur	x8, [sp, #4]
	str	x8, [x19]
	ldr	w8, [sp, #12]
	str	w8, [x19, #8]
	mov	w0, #1                          ; =0x1
	b	LBB12_8
LBB12_6:
	mov	w0, #0                          ; =0x0
	ret
LBB12_7:
	mov	w0, #0                          ; =0x0
LBB12_8:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_escape
_effect_escape:                         ; @effect_escape
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x21, x2
	mov	x20, x1
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	ldrh	w8, [x3, #278]
	cbz	w8, LBB13_7
; %bb.1:
	mov	x23, x3
	mov	x28, #0                         ; =0x0
	add	x22, x3, #288
	b	LBB13_3
LBB13_2:                                ;   in Loop: Header=BB13_3 Depth=1
	add	x28, x28, #1
	ldrh	w8, [x23, #278]
	cmp	x28, x8
	b.hs	LBB13_7
LBB13_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w25, [x22], #8
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_get_string
	mov	x24, x0
	mov	x0, x20
	mov	x1, x25
	bl	_nvm_get_string
	cbz	x24, LBB13_2
; %bb.4:                                ;   in Loop: Header=BB13_3 Depth=1
	mov	x26, x0
	cbz	x0, LBB13_2
; %bb.5:                                ;   in Loop: Header=BB13_3 Depth=1
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_get_string_len
	mov	x27, x0
	mov	x0, x20
	mov	x1, x25
	bl	_nvm_get_string_len
	cmp	w27, w0
	b.ne	LBB13_2
; %bb.6:                                ;   in Loop: Header=BB13_3 Depth=1
	mov	x0, x24
	mov	x1, x26
	bl	_strcmp
	cbnz	w0, LBB13_2
	b	LBB13_18
LBB13_7:
	cmp	w21, #7
	b.ls	LBB13_9
LBB13_8:
	mov	w0, #0                          ; =0x0
	b	LBB13_19
LBB13_9:
	mov	w8, #7840                       ; =0x1ea0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x25, x9, x8
	mov	w26, w21
	ldrh	w8, [x25, w21, uxtw #1]
	add	x10, x9, x26, lsl #10
	cbz	w8, LBB13_17
; %bb.10:
	mov	x28, #0                         ; =0x0
	mov	w8, #7856                       ; =0x1eb0
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	add	x27, x10, x8
	b	LBB13_12
LBB13_11:                               ;   in Loop: Header=BB13_12 Depth=1
	add	x28, x28, #1
	ldrh	w8, [x25, x26, lsl #1]
	cmp	x28, x8
	b.hs	LBB13_16
LBB13_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	w22, [x27, x28, lsl #2]
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_get_string
	mov	x21, x0
	mov	x0, x20
	mov	x1, x22
	bl	_nvm_get_string
	cbz	x21, LBB13_11
; %bb.13:                               ;   in Loop: Header=BB13_12 Depth=1
	mov	x23, x0
	cbz	x0, LBB13_11
; %bb.14:                               ;   in Loop: Header=BB13_12 Depth=1
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_get_string_len
	mov	x24, x0
	mov	x0, x20
	mov	x1, x22
	bl	_nvm_get_string_len
	cmp	w24, w0
	b.ne	LBB13_11
; %bb.15:                               ;   in Loop: Header=BB13_12 Depth=1
	mov	x0, x21
	mov	x1, x23
	bl	_strcmp
	cbnz	w0, LBB13_11
	b	LBB13_18
LBB13_16:
	cmp	w8, #256
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	b.eq	LBB13_8
LBB13_17:
	add	w9, w8, #1
	strh	w9, [x25, x26, lsl #1]
	add	x8, x10, w8, uxtw #2
	str	w19, [x8, #7856]
LBB13_18:
	mov	w0, #1                          ; =0x1
LBB13_19:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_affine_global_compose
_nvm_affine_global_compose:             ; @nvm_affine_global_compose
	.cfi_startproc
; %bb.0:
	sbfx	w8, w0, #0, #1
	and	w8, w1, w8
	lsl	w9, w0, #30
	lsr	w10, w1, #2
	and	w9, w10, w9, asr #31
	orr	w8, w8, w9
	lsl	w9, w0, #29
	lsl	w10, w1, #2
	and	w9, w10, w9, asr #31
	and	w9, w9, #0xc
	bfxil	w9, w8, #0, #2
	lsl	w8, w0, #28
	and	w8, w1, w8, asr #31
	and	w8, w8, #0xc
	orr	w0, w9, w8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function push
_push:                                  ; @push
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x0, #16]
	cmp	x8, #256
	b.ne	LBB15_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB15_2:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	ldr	x0, [x0, #8]
	mov	w9, #48                         ; =0x30
	umull	x8, w8, w9
	add	x1, x8, #48
	bl	_realloc
	cbz	x0, LBB15_4
; %bb.3:
	str	x0, [x20, #8]
	ldrh	w8, [x20, #16]
	add	w9, w8, #1
	strh	w9, [x20, #16]
	mov	w9, #48                         ; =0x30
	umaddl	x8, w8, w9, x0
	ldp	q0, q1, [x19]
	stp	q0, q1, [x8]
	ldr	q0, [x19, #32]
	str	q0, [x8, #32]
	mov	w0, #1                          ; =0x1
LBB15_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_value_matches
_effect_value_matches:                  ; @effect_value_matches
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB16_6
; %bb.1:
	ldrb	w8, [x1]
	and	w20, w2, #0xff
	cmp	w8, w20
	b.ne	LBB16_6
; %bb.2:
	mov	x21, x1
	ldrb	w23, [x1, #4]
	mov	x22, x2
	and	x1, x2, #0xffffffff000000ff
	mov	x19, x0
	bl	_nvm_affine_type_is_owned
	cmp	w23, w0
	b.ne	LBB16_6
; %bb.3:
	mov	w9, #253                        ; =0xfd
	mov	x8, x22
	and	w9, w8, w9
	cmp	w9, #8
	b.eq	LBB16_8
; %bb.4:
	cmp	w20, #7
	b.eq	LBB16_8
; %bb.5:
	mov	w0, #1                          ; =0x1
	b	LBB16_7
LBB16_6:
	mov	w0, #0                          ; =0x0
LBB16_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB16_8:
	ldrb	w9, [x21]
	ldr	w10, [x21, #8]
	orr	x1, x9, x10, lsl #32
	and	x2, x8, #0xffffffff000000ff
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	b	_nvm_affine_types_equal
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_push_type
_array_push_type:                       ; @array_push_type
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x21, x0
	ldr	x0, [x0]
	bl	_nvm_affine_type_is_owned
	ldrh	w8, [x21, #16]
	cmp	x8, #256
	b.ne	LBB17_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB17_4
LBB17_2:
	mov	x20, x0
	ldr	x0, [x21, #8]
	mov	w9, #48                         ; =0x30
	umull	x8, w8, w9
	add	x1, x8, #48
	bl	_realloc
	cbz	x0, LBB17_4
; %bb.3:
	lsr	x8, x19, #32
	str	x0, [x21, #8]
	ldrh	w9, [x21, #16]
	add	w10, w9, #1
	strh	w10, [x21, #16]
	mov	w10, #48                        ; =0x30
	umaddl	x9, w9, w10, x0
	strb	w19, [x9]
	strb	wzr, [x9, #1]
	mov	w10, #65535                     ; =0xffff
	strh	w10, [x9, #2]
	strb	w20, [x9, #4]
	sturh	wzr, [x9, #5]
	strb	wzr, [x9, #7]
	str	w8, [x9, #8]
	strh	w10, [x9, #12]
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #14]
	stur	q0, [x9, #30]
	strh	wzr, [x9, #46]
	mov	w0, #1                          ; =0x1
LBB17_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_frame
_eg_frame:                              ; @eg_frame
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	w8, #40389                      ; =0x9dc5
	movk	w8, #33052, lsl #16
	eor	w8, w1, w8
	mov	w9, #403                        ; =0x193
	movk	w9, #256, lsl #16
	mul	w8, w8, w9
	eor	w8, w8, w2
	mul	w8, w8, w9
	eor	w8, w8, w3
	mov	w9, #403                        ; =0x193
	mul	w8, w8, w9
	eor	w8, w8, w4
	mul	w8, w8, w9
	eor	w8, w8, w5
	mul	w8, w8, w9
	and	w19, w8, #0xffff
	ldr	x8, [x0, #328]
	ldr	w8, [x8, w19, uxtw #2]
	ldr	x9, [x0, #280]
	cbz	w8, LBB18_9
; %bb.1:
	cmn	w5, #1
	cset	w10, ne
	b	LBB18_3
LBB18_2:                                ;   in Loop: Header=BB18_3 Depth=1
	ldr	w8, [x11, #24]
	cbz	w8, LBB18_9
LBB18_3:                                ; =>This Inner Loop Header: Depth=1
	sub	w8, w8, #1
	add	x11, x9, x8, lsl #5
	ldr	w12, [x11]
	cmp	w12, w1
	b.ne	LBB18_2
; %bb.4:                                ;   in Loop: Header=BB18_3 Depth=1
	ldr	w12, [x11, #4]
	cmp	w12, w2
	b.ne	LBB18_2
; %bb.5:                                ;   in Loop: Header=BB18_3 Depth=1
	ldr	w12, [x11, #8]
	cmp	w12, w3
	b.ne	LBB18_2
; %bb.6:                                ;   in Loop: Header=BB18_3 Depth=1
	ldr	w12, [x11, #12]
	cmp	w12, w4
	b.ne	LBB18_2
; %bb.7:                                ;   in Loop: Header=BB18_3 Depth=1
	ldrb	w12, [x11, #28]
	cmp	w12, w10
	b.ne	LBB18_2
; %bb.8:                                ;   in Loop: Header=BB18_3 Depth=1
	ldr	w12, [x11, #16]
	cmn	w5, #1
	csel	w13, w8, w5, eq
	cmp	w12, w13
	b.ne	LBB18_2
	b	LBB18_19
LBB18_9:
	ldr	w8, [x0, #304]
	ldr	w10, [x0, #316]
	cmp	w8, w10
	b.hs	LBB18_11
; %bb.10:
	cbnz	x9, LBB18_14
	b	LBB18_16
LBB18_11:
	lsr	w8, w8, #18
	cbnz	w8, LBB18_16
; %bb.12:
	lsl	w8, w10, #1
	mov	w11, #262144                    ; =0x40000
	cmp	w8, #64, lsl #12                ; =262144
	csel	w8, w8, w11, lo
	mov	w11, #32                        ; =0x20
	cmp	w10, #0
	csel	w20, w11, w8, eq
	lsl	w8, w20, #5
	mov	x21, x0
	mov	x0, x9
	mov	x22, x1
	mov	x1, x8
	mov	x23, x4
	mov	x26, x3
	mov	x24, x2
	mov	x25, x5
	bl	_realloc
	mov	x9, x0
	mov	x0, x21
	cbz	x9, LBB18_16
; %bb.13:
	mov	x5, x25
	mov	x1, x22
	mov	x2, x24
	mov	x3, x26
	mov	x4, x23
	str	w20, [x0, #316]
	ldr	w8, [x0, #304]
LBB18_14:
	str	x9, [x0, #280]
	add	w10, w8, #1
	str	w10, [x0, #304]
	mov	w11, w8
	add	x11, x9, x11, lsl #5
	cmn	w5, #1
	csel	w12, w8, w5, eq
	cmn	w1, #1
	b.eq	LBB18_17
; %bb.15:
	mov	w13, w1
	add	x9, x9, x13, lsl #5
	ldr	w9, [x9, #20]
	add	w9, w9, #1
	b	LBB18_18
LBB18_16:
Lloh377:
	adrp	x8, l_.str.147@PAGE
Lloh378:
	add	x8, x8, l_.str.147@PAGEOFF
	str	x8, [x0, #360]
	mov	w8, #-1                         ; =0xffffffff
	b	LBB18_19
LBB18_17:
	mov	w9, #1                          ; =0x1
LBB18_18:
	ldr	x13, [x0, #328]
	ldr	w13, [x13, w19, uxtw #2]
	cmn	w5, #1
	cset	w14, ne
	strh	wzr, [sp, #12]
	strb	wzr, [sp, #14]
	stp	w1, w2, [x11]
	stp	w3, w4, [x11, #8]
	stp	w12, w9, [x11, #16]
	str	w13, [x11, #24]
	strb	w14, [x11, #28]
	sturh	wzr, [x11, #29]
	strb	wzr, [x11, #31]
	ldr	x9, [x0, #328]
	str	w10, [x9, w19, uxtw #2]
LBB18_19:
	mov	x0, x8
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh377, Lloh378
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_queue
_eg_queue:                              ; @eg_queue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x26, x25, [sp, #272]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh379:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh380:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh381:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	ldr	w8, [x0, #304]
	cmp	w1, w8
	b.hs	LBB19_9
; %bb.1:
	ldr	x8, [x0, #280]
	mov	w9, w1
	add	x8, x8, x9, lsl #5
	ldr	w8, [x8, #4]
	add	x8, x0, x8, lsl #5
	ldr	w8, [x8, #32]
	cmp	w2, w8
	b.hs	LBB19_9
; %bb.2:
	mov	w8, #40389                      ; =0x9dc5
	movk	w8, #33052, lsl #16
	eor	w8, w1, w8
	mov	w9, #403                        ; =0x193
	mul	w8, w8, w9
	eor	w8, w8, w2
	mul	w8, w8, w9
	eor	w8, w8, w3
	mov	w9, #45899                      ; =0xb34b
	mul	w8, w8, w9
	and	w20, w8, #0xffff
	ldr	x9, [x0, #344]
	ldr	w11, [x9, w20, uxtw #2]
	ldr	x8, [x0, #296]
	cbz	w11, LBB19_13
; %bb.3:
	mov	w10, #280                       ; =0x118
	b	LBB19_5
LBB19_4:                                ;   in Loop: Header=BB19_5 Depth=1
	umaddl	x11, w21, w10, x8
	ldr	w11, [x11, #12]
	cbz	w11, LBB19_13
LBB19_5:                                ; =>This Inner Loop Header: Depth=1
	sub	w21, w11, #1
	umaddl	x11, w21, w10, x8
	ldr	w12, [x11]
	cmp	w12, w1
	b.ne	LBB19_4
; %bb.6:                                ;   in Loop: Header=BB19_5 Depth=1
	ldr	w12, [x11, #4]
	cmp	w12, w2
	b.ne	LBB19_4
; %bb.7:                                ;   in Loop: Header=BB19_5 Depth=1
	ldr	w11, [x11, #8]
	cmp	w11, w3
	b.ne	LBB19_4
; %bb.8:
	mov	w9, #0                          ; =0x0
	mov	x19, x21
	b	LBB19_20
LBB19_9:
	mov	w8, #0                          ; =0x0
Lloh382:
	adrp	x9, l_.str.148@PAGE
Lloh383:
	add	x9, x9, l_.str.148@PAGEOFF
LBB19_10:
	str	x9, [x0, #360]
LBB19_11:
	ldur	x9, [x29, #-72]
Lloh384:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh385:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh386:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB19_33
; %bb.12:
	mov	x0, x8
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
LBB19_13:
	ldr	w19, [x0, #312]
	ldr	w10, [x0, #324]
	cmp	w19, w10
	b.hs	LBB19_16
; %bb.14:
	cbz	x8, LBB19_29
; %bb.15:
	mov	x22, x4
	b	LBB19_19
LBB19_16:
	lsr	w9, w19, #18
	cbnz	w9, LBB19_29
; %bb.17:
	lsl	w9, w10, #1
	mov	w11, #262144                    ; =0x40000
	cmp	w9, #64, lsl #12                ; =262144
	csel	w9, w9, w11, lo
	mov	w11, #32                        ; =0x20
	cmp	w10, #0
	csel	w19, w11, w9, eq
	mov	w9, #280                        ; =0x118
	mul	w9, w19, w9
	mov	x21, x0
	mov	x0, x8
	mov	x23, x1
	mov	x1, x9
	mov	x22, x4
	mov	x25, x3
	mov	x24, x2
	bl	_realloc
	mov	x8, x0
	mov	x0, x21
	cbz	x8, LBB19_29
; %bb.18:
	mov	x1, x23
	mov	x2, x24
	mov	x3, x25
	str	w19, [x0, #324]
	ldr	w19, [x0, #312]
	ldr	x9, [x0, #344]
LBB19_19:
	str	x8, [x0, #296]
	add	w24, w19, #1
	str	w24, [x0, #312]
	mov	w21, w19
	mov	w10, #280                       ; =0x118
	umaddl	x8, w19, w10, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #224]
	str	wzr, [sp, #256]
	ldr	w9, [x9, w20, uxtw #2]
	stp	w1, w2, [x8]
	stp	w3, w9, [x8, #8]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x8, #16]
	mov	x23, x0
	add	x0, x8, #20
	mov	x1, sp
	mov	w2, #260                        ; =0x104
	bl	_memcpy
	mov	x0, x23
	ldr	x8, [x23, #344]
	str	w24, [x8, w20, uxtw #2]
	ldr	x8, [x23, #296]
	mov	w9, #1                          ; =0x1
	mov	x4, x22
LBB19_20:
	mov	w10, #280                       ; =0x118
	umaddl	x10, w21, w10, x8
	ldr	w8, [x0, #16]
	cbz	w8, LBB19_25
; %bb.21:
	mov	x11, #0                         ; =0x0
	add	x12, x10, #21
	b	LBB19_23
LBB19_22:                               ;   in Loop: Header=BB19_23 Depth=1
	add	x11, x11, #1
	cmp	x11, x8
	b.hs	LBB19_25
LBB19_23:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w14, [x12, x11]
	ldrb	w13, [x4, x11]
	orr	w13, w13, w14
	and	w13, w13, #0xff
	cmp	w13, w14
	b.eq	LBB19_22
; %bb.24:                               ;   in Loop: Header=BB19_23 Depth=1
	strb	w13, [x12, x11]
	ldr	w8, [x0, #16]
	mov	w9, #1                          ; =0x1
	b	LBB19_22
LBB19_25:
	tbz	w9, #0, LBB19_32
; %bb.26:
	ldrb	w9, [x10, #20]
	mov	w8, #1                          ; =0x1
	tbnz	w9, #0, LBB19_11
; %bb.27:
	strb	w8, [x10, #20]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x10, #16]
	ldr	w8, [x0, #356]
	cmn	w8, #1
	b.eq	LBB19_30
; %bb.28:
	ldr	x9, [x0, #296]
	mov	w10, #280                       ; =0x118
	umaddl	x8, w8, w10, x9
	str	w19, [x8, #16]
	b	LBB19_31
LBB19_29:
	mov	w8, #0                          ; =0x0
Lloh387:
	adrp	x9, l_.str.149@PAGE
Lloh388:
	add	x9, x9, l_.str.149@PAGEOFF
	b	LBB19_10
LBB19_30:
	str	w19, [x0, #352]
LBB19_31:
	str	w19, [x0, #356]
LBB19_32:
	mov	w8, #1                          ; =0x1
	b	LBB19_11
LBB19_33:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh379, Lloh380, Lloh381
	.loh AdrpAdd	Lloh382, Lloh383
	.loh AdrpLdrGotLdr	Lloh384, Lloh385, Lloh386
	.loh AdrpAdd	Lloh387, Lloh388
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require a bounded instruction fact buffer"

l_.str.1:                               ; @.str.1
	.asciz	"I cannot stage effect/global instruction facts"

l_.str.2:                               ; @.str.2
	.asciz	"I require checked ownership declarations"

l_.str.3:                               ; @.str.3
	.asciz	"I require a bounded acyclic value graph for global flow"

l_.str.4:                               ; @.str.4
	.asciz	"I refuse recursive owned value analysis"

l_.str.5:                               ; @.str.5
	.asciz	"I exceeded my bounded affine analysis size"

l_.str.6:                               ; @.str.6
	.asciz	"I require exact caller-origin parameter authority"

l_.str.7:                               ; @.str.7
	.asciz	"I require decodable function control flow"

l_.str.8:                               ; @.str.8
	.asciz	"I exceeded my bounded affine instruction count"

l_.str.9:                               ; @.str.9
	.asciz	"I require string literals inside an owned value-call graph"

l_.str.10:                              ; @.str.10
	.asciz	"I require string output inside an owned value-call graph"

l_.str.11:                              ; @.str.11
	.asciz	"I require a connected affine instruction contract"

l_.str.12:                              ; @.str.12
	.asciz	"I require a retained exact effect signature at every operation"

l_.str.13:                              ; @.str.13
	.asciz	"I require bounded handler parameter slots"

l_.str.14:                              ; @.str.14
	.asciz	"I require exact declared handler parameter types"

l_.str.15:                              ; @.str.15
	.asciz	"I require an exact declared global slot"

l_.str.16:                              ; @.str.16
	.asciz	"I require exact instruction fact capacity"

l_.str.17:                              ; @.str.17
	.asciz	"I cannot allocate analysis state"

l_.str.18:                              ; @.str.18
	.asciz	"I cannot allocate entry state"

l_.str.20:                              ; @.str.20
	.asciz	"I exceeded my bounded affine visit count"

l_.str.21:                              ; @.str.21
	.asciz	"I cannot allocate an instruction state"

l_.str.22:                              ; @.str.22
	.asciz	"I refuse an observation escape or extra return operands"

l_.str.23:                              ; @.str.23
	.asciz	"I require an exact declared result and no live owned obligations"

l_.str.24:                              ; @.str.24
	.asciz	"I require the active operation result and resolved arm ownership at resumption"

l_.str.25:                              ; @.str.25
	.asciz	"I require an empty stack and resolved owners at my terminal invariant"

l_.str.26:                              ; @.str.26
	.asciz	"I exceeded my bounded affine handler depth"

l_.str.27:                              ; @.str.27
	.asciz	"I cannot allocate handler control-flow state"

l_.str.28:                              ; @.str.28
	.asciz	"I require a fresh exact handler activation"

l_.str.29:                              ; @.str.29
	.asciz	"I require a valid handler entry edge"

l_.str.30:                              ; @.str.30
	.asciz	"I require an instruction at my match target"

l_.str.31:                              ; @.str.31
	.asciz	"I require a checked scalar-union match edge"

l_.str.32:                              ; @.str.32
	.asciz	"I require an instruction at my branch target"

l_.str.33:                              ; @.str.33
	.asciz	"I require an explicit return rather than fallthrough"

l_.str.34:                              ; @.str.34
	.asciz	"I require global initialization before reads and no repeated immutable store"

l_.str.35:                              ; @.str.35
	.asciz	"I cannot allocate converged instruction facts"

l_.str.36:                              ; @.str.36
	.asciz	"I require exact destructive-unpack facts"

l_.str.37:                              ; @.str.37
	.asciz	"%s"

l_.str.38:                              ; @.str.38
	.asciz	"I require a checked acyclic owned value call"

l_.str.39:                              ; @.str.39
	.asciz	"I require a complete consuming argument list"

l_.str.40:                              ; @.str.40
	.asciz	"I require exact positional consuming argument types"

l_.str.41:                              ; @.str.41
	.asciz	"I require complete consuming-helper owner resolution"

l_.str.42:                              ; @.str.42
	.asciz	"I cannot suspend live local owners across an escaping effect call"

l_.str.43:                              ; @.str.43
	.asciz	"I cannot suspend staged owners across an escaping effect call"

l_.str.44:                              ; @.str.44
	.asciz	"I cannot retain escaping operation identities"

l_.str.45:                              ; @.str.45
	.asciz	"I cannot retain a checked value-call result"

l_.str.46:                              ; @.str.46
	.asciz	"I require entry-to-helper reference calls without recursion"

l_.str.47:                              ; @.str.47
	.asciz	"I require checked caller authority and a non-escaping helper"

l_.str.48:                              ; @.str.48
	.asciz	"I require a single scalar reference-call result"

l_.str.49:                              ; @.str.49
	.asciz	"I cannot pop absent or inherited handlers"

l_.str.50:                              ; @.str.50
	.asciz	"I require the exact retained performed signature"

l_.str.51:                              ; @.str.51
	.asciz	"I require exact positional effect argument ownership"

l_.str.52:                              ; @.str.52
	.asciz	"I cannot abandon a staged owner across an effect"

l_.str.53:                              ; @.str.53
	.asciz	"I cannot abandon a local owner or borrow across an effect"

l_.str.54:                              ; @.str.54
	.asciz	"I cannot retain a resumed effect value"

l_.str.55:                              ; @.str.55
	.asciz	"I require a Boolean literal"

l_.str.56:                              ; @.str.56
	.asciz	"I require an instantiated string literal without embedded NUL"

l_.str.57:                              ; @.str.57
	.asciz	"I cannot begin another reference region"

l_.str.58:                              ; @.str.58
	.asciz	"I need a live reference region to end"

l_.str.59:                              ; @.str.59
	.asciz	"I require permitted parent authority and a fresh reborrow in a deeper region"

l_.str.60:                              ; @.str.60
	.asciz	"I require a retained bounded ownership path"

l_.str.61:                              ; @.str.61
	.asciz	"I cannot borrow exclusively while an owner observation is on my stack"

l_.str.62:                              ; @.str.62
	.asciz	"I require an available scalar-leaf resource owner and reference slot in a live region"

l_.str.63:                              ; @.str.63
	.asciz	"I require a live permitted scalar reference field"

l_.str.64:                              ; @.str.64
	.asciz	"I require the exact scalar reference field type"

l_.str.65:                              ; @.str.65
	.asciz	"I cannot move while an owner observation is on my stack"

l_.str.66:                              ; @.str.66
	.asciz	"I require a live unheld owner for an explicit move"

l_.str.67:                              ; @.str.67
	.asciz	"I cannot extend my owned analysis stack"

l_.str.68:                              ; @.str.68
	.asciz	"I require an owned token for an explicit store"

l_.str.69:                              ; @.str.69
	.asciz	"I require an exact available owner destination"

l_.str.70:                              ; @.str.70
	.asciz	"I require the stored union's exact selected arm"

l_.str.71:                              ; @.str.71
	.asciz	"I require every declared field for owned construction"

l_.str.72:                              ; @.str.72
	.asciz	"I require exact scalar or owned fields in declaration order"

l_.str.73:                              ; @.str.73
	.asciz	"I cannot unpack while an owner observation is on my stack"

l_.str.74:                              ; @.str.74
	.asciz	"I require an intact owner and space for all unpacked fields"

l_.str.75:                              ; @.str.75
	.asciz	"I cannot extend my unpacked analysis stack"

l_.str.76:                              ; @.str.76
	.asciz	"I require an exact complete copyable record constructor"

l_.str.77:                              ; @.str.77
	.asciz	"I require exact copyable record fields without owned authority"

l_.str.78:                              ; @.str.78
	.asciz	"I cannot retain a copyable record"

l_.str.79:                              ; @.str.79
	.asciz	"I require explicit owned construction for records"

l_.str.80:                              ; @.str.80
	.asciz	"I require an exact retained scalar-union constructor shape"

l_.str.81:                              ; @.str.81
	.asciz	"I require exact scalar-union payload facts"

l_.str.82:                              ; @.str.82
	.asciz	"I require exact scalar-union fields in declaration order"

l_.str.83:                              ; @.str.83
	.asciz	"I cannot retain a checked scalar-union value"

l_.str.84:                              ; @.str.84
	.asciz	"I require explicit global owner transfers and lifetime before resource storage"

l_.str.85:                              ; @.str.85
	.asciz	"I cannot retain a checked global load"

l_.str.86:                              ; @.str.86
	.asciz	"I require a value for a global store"

l_.str.87:                              ; @.str.87
	.asciz	"I require the exact global type without an owner or observation escape"

l_.str.88:                              ; @.str.88
	.asciz	"I require a live checked local"

l_.str.89:                              ; @.str.89
	.asciz	"I require an exact record local"

l_.str.90:                              ; @.str.90
	.asciz	"I require an exact array local"

l_.str.91:                              ; @.str.91
	.asciz	"I require an exact scalar-union local"

l_.str.92:                              ; @.str.92
	.asciz	"I require an explicit move of a resource union"

l_.str.93:                              ; @.str.93
	.asciz	"I cannot extend my analysis stack"

l_.str.94:                              ; @.str.94
	.asciz	"I refuse an observation escape or missing scalar store"

l_.str.95:                              ; @.str.95
	.asciz	"I require the exact scalar local type"

l_.str.96:                              ; @.str.96
	.asciz	"I require an exact scalar-union match source"

l_.str.97:                              ; @.str.97
	.asciz	"I require a match variant within the concrete union"

l_.str.98:                              ; @.str.98
	.asciz	"I require an exact scalar-union tag source"

l_.str.99:                              ; @.str.99
	.asciz	"I require an exact ordinary record projection"

l_.str.100:                             ; @.str.100
	.asciz	"I refuse an owned ordinary projection"

l_.str.101:                             ; @.str.101
	.asciz	"I cannot retain an ordinary projection"

l_.str.102:                             ; @.str.102
	.asciz	"I require a proven scalar-union variant before projection"

l_.str.103:                             ; @.str.103
	.asciz	"I require an exact scalar-union payload field"

l_.str.104:                             ; @.str.104
	.asciz	"I require destructive unpack for aggregate payloads"

l_.str.105:                             ; @.str.105
	.asciz	"I require a checked scalar field observation"

l_.str.106:                             ; @.str.106
	.asciz	"I refuse to duplicate reference authority"

l_.str.107:                             ; @.str.107
	.asciz	"I refuse unsupported string duplication"

l_.str.108:                             ; @.str.108
	.asciz	"I require a scalar discard; an observation is not an owned consume"

l_.str.109:                             ; @.str.109
	.asciz	"I require PRINT or PRINTLN to consume a string"

l_.str.110:                             ; @.str.110
	.asciz	"I require scalar stack permutation"

l_.str.111:                             ; @.str.111
	.asciz	"I refuse unsupported string permutation"

l_.str.112:                             ; @.str.112
	.asciz	"I require one exact immutable string print operand"

l_.str.113:                             ; @.str.113
	.asciz	"I require an exact Boolean assertion condition"

l_.str.114:                             ; @.str.114
	.asciz	"I require an exact Boolean branch condition"

l_.str.115:                             ; @.str.115
	.asciz	"I require Boolean operands"

l_.str.116:                             ; @.str.116
	.asciz	"I require integer arithmetic operands"

l_.str.117:                             ; @.str.117
	.asciz	"I require float arithmetic operands"

l_.str.118:                             ; @.str.118
	.asciz	"I require float comparison operands"

l_.str.119:                             ; @.str.119
	.asciz	"I require exact STRING equality operands"

l_.str.120:                             ; @.str.120
	.asciz	"I require scalar comparison operands"

l_.str.121:                             ; @.str.121
	.asciz	"I require matching comparison tags"

l_.str.122:                             ; @.str.122
	.asciz	"I require retained element types for array flow"

l_.str.123:                             ; @.str.123
	.asciz	"I require all declared array literal elements"

l_.str.124:                             ; @.str.124
	.asciz	"I require checked empty-array constructor declarations"

l_.str.125:                             ; @.str.125
	.asciz	"I require the exact declared empty-array element tag"

l_.str.126:                             ; @.str.126
	.asciz	"I require an unambiguous retained element type for empty array construction"

l_.str.127:                             ; @.str.127
	.asciz	"I require an exact retained array literal element type"

l_.str.128:                             ; @.str.128
	.asciz	"I require exact array literal element ownership in source order"

l_.str.129:                             ; @.str.129
	.asciz	"I cannot retain an array construction result"

l_.str.130:                             ; @.str.130
	.asciz	"I require every array operation operand"

l_.str.131:                             ; @.str.131
	.asciz	"I require an exact array operand"

l_.str.132:                             ; @.str.132
	.asciz	"I require a live owner observation for resource-array length"

l_.str.133:                             ; @.str.133
	.asciz	"I cannot retain array length"

l_.str.134:                             ; @.str.134
	.asciz	"I cannot mutate or extract through an array owner observation"

l_.str.135:                             ; @.str.135
	.asciz	"I require explicit resource-element extraction and disposal contracts"

l_.str.136:                             ; @.str.136
	.asciz	"I require an integer array index"

l_.str.137:                             ; @.str.137
	.asciz	"I require an integer slice end"

l_.str.138:                             ; @.str.138
	.asciz	"I require the exact array element type and ownership"

l_.str.139:                             ; @.str.139
	.asciz	"I cannot retain an array operation result"

l_.str.140:                             ; @.str.140
	.asciz	"I require identical handler context at every control-flow join"

l_.str.141:                             ; @.str.141
	.asciz	"I require exact ownership and stack provenance at every join"

l_.str.142:                             ; @.str.142
	.asciz	"I require one global declaration domain at every join"

l_.str.143:                             ; @.str.143
	.asciz	"I cannot allocate an analysis branch"

l_.str.144:                             ; @.str.144
	.asciz	"I exceeded my bounded affine worklist"

l_.str.145:                             ; @.str.145
	.asciz	"I cannot allocate effect/global control indexes"

l_.str.146:                             ; @.str.146
	.asciz	"I require decodable effect/global control flow"

l_.str.147:                             ; @.str.147
	.asciz	"I cannot retain bounded effect/global activation states"

l_.str.148:                             ; @.str.148
	.asciz	"I require an exact effect/global continuation"

l_.str.149:                             ; @.str.149
	.asciz	"I exceeded my effect/global control-state storage budget"

l_.str.150:                             ; @.str.150
	.asciz	"I require an active effect/global resumption"

l_.str.151:                             ; @.str.151
	.asciz	"I require a declared effect/global slot"

l_.str.152:                             ; @.str.152
	.asciz	"I require global initialization before reads and no repeated immutable store across effects"

l_.str.153:                             ; @.str.153
	.asciz	"I require a declared effect/global callee"

l_.str.154:                             ; @.str.154
	.asciz	"I cannot pop an absent or inherited effect/global handler"

l_.str.155:                             ; @.str.155
	.asciz	"I require an exact effect/global branch target"

l_.str.156:                             ; @.str.156
	.asciz	"I cannot retain bounded effect/global handler states"

.subsections_via_symbols
