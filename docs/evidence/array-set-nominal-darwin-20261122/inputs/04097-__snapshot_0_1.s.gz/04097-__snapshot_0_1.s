	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_file_source_snapshots_new   ; -- Begin function nl_file_source_snapshots_new
	.p2align	2
_nl_file_source_snapshots_new:          ; @nl_file_source_snapshots_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_5
LBB0_2:
	mov	x0, #1                          ; =0x1
	mov	x1, #792                        ; =0x318
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB0_5
LBB0_4:
	ldr	x9, [sp, #8]
	mov	x8, #792                        ; =0x318
	str	x8, [x9, #16]
	ldr	x9, [sp, #8]
	str	x8, [x9, #8]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB0_5
LBB0_5:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshots_free  ; -- Begin function nl_file_source_snapshots_free
	.p2align	2
_nl_file_source_snapshots_free:         ; @nl_file_source_snapshots_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_7
LBB1_2:
	str	xzr, [sp]
	b	LBB1_3
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	LBB1_6
	b	LBB1_4
LBB1_4:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #24
	ldr	x9, [sp]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x0, x8, x9
	bl	_snapshot_dispose
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB1_3
LBB1_6:
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB1_7
LBB1_7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function snapshot_dispose
_snapshot_dispose:                      ; @snapshot_dispose
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	subs	x8, x8, #1
	b.ne	LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	bl	_nl_file_binding_free
	b	LBB2_8
LBB2_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	bl	_nl_socket_binding_free
	b	LBB2_7
LBB2_4:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #32]
	subs	x8, x8, #3
	b.ne	LBB2_6
	b	LBB2_5
LBB2_5:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	bl	_nl_websocket_binding_free
	b	LBB2_6
LBB2_6:
	b	LBB2_7
LBB2_7:
	b	LBB2_8
LBB2_8:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_snapshot_open ; -- Begin function nl_service_source_snapshot_open
	.p2align	2
_nl_service_source_snapshot_open:       ; @nl_service_source_snapshot_open
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #448
	stp	x28, x27, [sp, #416]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #432]            ; 16-byte Folded Spill
	add	x29, sp, #432
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	stur	x4, [x29, #-64]
	stur	x5, [x29, #-72]
	stur	x6, [x29, #-80]
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.eq	LBB3_3
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.eq	LBB3_3
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #3
	b.ne	LBB3_10
	b	LBB3_3
LBB3_3:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_10
	b	LBB3_4
LBB3_4:
	ldur	x8, [x29, #-80]
	cbz	x8, LBB3_10
	b	LBB3_5
LBB3_5:
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-56]
	bl	_snapshot_span
	tbz	w0, #0, LBB3_10
	b	LBB3_6
LBB3_6:
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-72]
	bl	_snapshot_span
	tbz	w0, #0, LBB3_10
	b	LBB3_7
LBB3_7:
	ldur	x8, [x29, #-48]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB3_10
	b	LBB3_8
LBB3_8:
	ldur	x8, [x29, #-64]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.eq	LBB3_10
	b	LBB3_9
LBB3_9:
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-56]
	subs	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.ne	LBB3_11
	b	LBB3_10
LBB3_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_11:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	subs	x8, x8, #16
	b.ne	LBB3_13
	b	LBB3_12
LBB3_12:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_13:
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-88]
	b	LBB3_14
LBB3_14:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-88]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #68]                   ; 4-byte Folded Spill
	cbz	x8, LBB3_16
	b	LBB3_15
LBB3_15:                                ;   in Loop: Header=BB3_14 Depth=1
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-88]
	subs	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	cset	w8, ne
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b	LBB3_16
LBB3_16:                                ;   in Loop: Header=BB3_14 Depth=1
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB3_18
	b	LBB3_17
LBB3_17:                                ;   in Loop: Header=BB3_14 Depth=1
	ldur	x8, [x29, #-88]
	subs	x8, x8, #1
	stur	x8, [x29, #-88]
	b	LBB3_14
LBB3_18:
	ldur	x8, [x29, #-72]
	ldur	x10, [x29, #-88]
	mov	x9, #1048576                    ; =0x100000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB3_20
	b	LBB3_19
LBB3_19:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_20:
	ldur	x8, [x29, #-88]
	ldur	x9, [x29, #-72]
	add	x8, x8, x9
	stur	x8, [x29, #-96]
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.ne	LBB3_22
	b	LBB3_21
LBB3_21:
	sub	x0, x29, #104
	bl	_nl_file_binding_allocation_bound
	str	w0, [sp, #64]                   ; 4-byte Folded Spill
	b	LBB3_26
LBB3_22:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ne	LBB3_24
	b	LBB3_23
LBB3_23:
	sub	x0, x29, #104
	bl	_nl_socket_binding_allocation_bound
	str	w0, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB3_25
LBB3_24:
	sub	x0, x29, #104
	bl	_nl_websocket_binding_allocation_bound
	str	w0, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB3_25
LBB3_25:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	str	w8, [sp, #64]                   ; 4-byte Folded Spill
	b	LBB3_26
LBB3_26:
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-105]
	ldurb	w8, [x29, #-105]
	tbnz	w8, #0, LBB3_28
	b	LBB3_27
LBB3_27:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_28:
	ldur	x8, [x29, #-96]
	add	x8, x8, #1
	add	x8, x8, #256, lsl #12           ; =1048576
	add	x8, x8, #1
	stur	x8, [x29, #-120]
	ldur	x8, [x29, #-120]
	mov	x9, #67108864                   ; =0x4000000
	subs	x8, x8, x9
	b.hi	LBB3_31
	b	LBB3_29
LBB3_29:
	ldur	x8, [x29, #-104]
	ldur	x10, [x29, #-120]
	mov	x9, #67108864                   ; =0x4000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB3_31
	b	LBB3_30
LBB3_30:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	ldur	x10, [x29, #-120]
	mov	x9, #67108864                   ; =0x4000000
	subs	x9, x9, x10
	ldur	x10, [x29, #-104]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB3_32
	b	LBB3_31
LBB3_31:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_32:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-120]
	add	x8, x8, x9
	ldur	x9, [x29, #-104]
	add	x8, x8, x9
	stur	x8, [x29, #-128]
	ldur	x8, [x29, #-128]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #16]
	subs	x8, x8, x9
	b.ls	LBB3_34
	b	LBB3_33
LBB3_33:
	ldur	x8, [x29, #-128]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #16]
	b	LBB3_34
LBB3_34:
	sub	x0, x29, #176
	mov	x2, #48                         ; =0x30
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-144]
	ldur	x8, [x29, #-96]
	stur	x8, [x29, #-160]
	ldur	x8, [x29, #-96]
	add	x0, x8, #1
	bl	_malloc
	stur	x0, [x29, #-176]
	ldur	x8, [x29, #-176]
	cbnz	x8, LBB3_36
	b	LBB3_35
LBB3_35:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_36:
	ldur	x0, [x29, #-176]
	ldur	x1, [x29, #-48]
	ldur	x2, [x29, #-88]
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #48]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-176]
	ldur	x9, [x29, #-88]
	add	x0, x8, x9
	ldur	x1, [x29, #-64]
	ldur	x2, [x29, #-72]
	bl	___memcpy_chk
	ldur	x8, [x29, #-176]
	ldur	x9, [x29, #-96]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x0, [x29, #-176]
	mov	w1, #260                        ; =0x104
	movk	w1, #256, lsl #16
	bl	_open
	stur	w0, [x29, #-180]
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-184]
	ldur	w8, [x29, #-180]
	tbz	w8, #31, LBB3_38
	b	LBB3_37
LBB3_37:
	b	LBB3_82
LBB3_38:
	ldur	w0, [x29, #-180]
	add	x1, sp, #104
	bl	_fstat
	cbnz	w0, LBB3_41
	b	LBB3_39
LBB3_39:
	ldrh	w8, [sp, #108]
	and	w8, w8, #0xf000
	subs	w8, w8, #8, lsl #12             ; =32768
	b.ne	LBB3_41
	b	LBB3_40
LBB3_40:
	ldr	x8, [sp, #200]
	tbz	x8, #63, LBB3_42
	b	LBB3_41
LBB3_41:
	b	LBB3_62
LBB3_42:
	ldr	x8, [sp, #200]
	subs	x8, x8, #256, lsl #12           ; =1048576
	b.ls	LBB3_44
	b	LBB3_43
LBB3_43:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-184]
	b	LBB3_62
LBB3_44:
	ldr	x8, [sp, #200]
	stur	x8, [x29, #-152]
	ldur	x8, [x29, #-152]
	add	x0, x8, #1
	bl	_malloc
	stur	x0, [x29, #-168]
	ldur	x8, [x29, #-168]
	cbnz	x8, LBB3_46
	b	LBB3_45
LBB3_45:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-184]
	b	LBB3_62
LBB3_46:
	str	xzr, [sp, #96]
	b	LBB3_47
LBB3_47:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #96]
	ldur	x9, [x29, #-152]
	subs	x8, x8, x9
	b.hs	LBB3_54
	b	LBB3_48
LBB3_48:                                ;   in Loop: Header=BB3_47 Depth=1
	ldur	w0, [x29, #-180]
	ldur	x8, [x29, #-168]
	ldr	x9, [sp, #96]
	add	x1, x8, x9
	ldur	x8, [x29, #-152]
	ldr	x9, [sp, #96]
	subs	x2, x8, x9
	bl	_read
	str	x0, [sp, #88]
	ldr	x8, [sp, #88]
	tbz	x8, #63, LBB3_51
	b	LBB3_49
LBB3_49:                                ;   in Loop: Header=BB3_47 Depth=1
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #4
	b.ne	LBB3_51
	b	LBB3_50
LBB3_50:                                ;   in Loop: Header=BB3_47 Depth=1
	b	LBB3_47
LBB3_51:                                ;   in Loop: Header=BB3_47 Depth=1
	ldr	x8, [sp, #88]
	subs	x8, x8, #0
	b.gt	LBB3_53
	b	LBB3_52
LBB3_52:
	b	LBB3_62
LBB3_53:                                ;   in Loop: Header=BB3_47 Depth=1
	ldr	x9, [sp, #88]
	ldr	x8, [sp, #96]
	add	x8, x8, x9
	str	x8, [sp, #96]
	b	LBB3_47
LBB3_54:
	b	LBB3_55
LBB3_55:                                ; =>This Inner Loop Header: Depth=1
	ldur	w0, [x29, #-180]
	add	x1, sp, #87
	mov	x2, #1                          ; =0x1
	bl	_read
	str	x0, [sp, #72]
	b	LBB3_56
LBB3_56:                                ;   in Loop: Header=BB3_55 Depth=1
	ldr	x8, [sp, #72]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
	tbz	x8, #63, LBB3_58
	b	LBB3_57
LBB3_57:                                ;   in Loop: Header=BB3_55 Depth=1
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB3_58
LBB3_58:                                ;   in Loop: Header=BB3_55 Depth=1
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB3_55
	b	LBB3_59
LBB3_59:
	ldr	x8, [sp, #72]
	cbz	x8, LBB3_61
	b	LBB3_60
LBB3_60:
	b	LBB3_62
LBB3_61:
	ldur	x8, [x29, #-168]
	ldur	x9, [x29, #-152]
	add	x8, x8, x9
	strb	wzr, [x8]
	stur	wzr, [x29, #-184]
	b	LBB3_62
LBB3_62:
	ldur	w0, [x29, #-180]
	bl	_close
	cbz	w0, LBB3_65
	b	LBB3_63
LBB3_63:
	ldur	w8, [x29, #-184]
	cbnz	w8, LBB3_65
	b	LBB3_64
LBB3_64:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-184]
	b	LBB3_65
LBB3_65:
	ldur	w8, [x29, #-184]
	cbz	w8, LBB3_67
	b	LBB3_66
LBB3_66:
	b	LBB3_82
LBB3_67:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.ne	LBB3_69
	b	LBB3_68
LBB3_68:
	sub	x8, x29, #176
	ldur	x0, [x29, #-168]
	ldur	x1, [x29, #-152]
	add	x2, x8, #40
	bl	_nl_file_binding_prepare
	str	w0, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB3_73
LBB3_69:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ne	LBB3_71
	b	LBB3_70
LBB3_70:
	sub	x8, x29, #176
	ldur	x0, [x29, #-168]
	ldur	x1, [x29, #-152]
	add	x2, x8, #40
	bl	_nl_socket_binding_prepare
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB3_72
LBB3_71:
	sub	x8, x29, #176
	ldur	x0, [x29, #-168]
	ldur	x1, [x29, #-152]
	add	x2, x8, #40
	bl	_nl_websocket_binding_prepare
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB3_72
LBB3_72:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB3_73
LBB3_73:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-184]
	ldur	w8, [x29, #-184]
	cbz	w8, LBB3_75
	b	LBB3_74
LBB3_74:
	b	LBB3_82
LBB3_75:
	ldur	x8, [x29, #-96]
	add	x8, x8, #1
	ldur	x9, [x29, #-152]
	add	x8, x8, x9
	add	x8, x8, #1
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	subs	x8, x8, #1
	b.ne	LBB3_77
	b	LBB3_76
LBB3_76:
	ldur	x0, [x29, #-136]
	bl	_nl_file_binding_storage_size
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_81
LBB3_77:
	ldur	x8, [x29, #-40]
	subs	x8, x8, #2
	b.ne	LBB3_79
	b	LBB3_78
LBB3_78:
	ldur	x0, [x29, #-136]
	bl	_nl_socket_binding_storage_size
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_80
LBB3_79:
	ldur	x0, [x29, #-136]
	bl	_nl_websocket_binding_storage_size
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_80
LBB3_80:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_81
LBB3_81:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	add	x10, x8, x9
	ldur	x9, [x29, #-32]
	ldr	x8, [x9, #8]
	add	x8, x8, x10
	str	x8, [x9, #8]
	ldur	x8, [x29, #-32]
	add	x8, x8, #24
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x0, x8, x9
	sub	x1, x29, #176
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldur	x10, [x29, #-32]
	ldr	x8, [x10]
	add	x9, x8, #1
	str	x9, [x10]
	ldur	x9, [x29, #-80]
	str	x8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB3_83
LBB3_82:
	sub	x0, x29, #176
	bl	_snapshot_dispose
	ldur	w8, [x29, #-184]
	stur	w8, [x29, #-20]
	b	LBB3_83
LBB3_83:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #432]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #416]            ; 16-byte Folded Reload
	add	sp, sp, #448
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function snapshot_span
_snapshot_span:                         ; @snapshot_span
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB4_5
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB4_5
	b	LBB4_2
LBB4_2:
	ldr	x8, [sp, #16]
	mov	w0, #0                          ; =0x0
	subs	x8, x8, #256, lsl #12           ; =1048576
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.hi	LBB4_5
	b	LBB4_3
LBB4_3:
	ldur	x0, [x29, #-8]
	ldr	x2, [sp, #16]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	x0, LBB4_5
	b	LBB4_4
LBB4_4:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	mov	x2, #0                          ; =0x0
	bl	_nl_utf8_validate
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB4_5
LBB4_5:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshot_count  ; -- Begin function nl_file_source_snapshot_count
	.p2align	2
_nl_file_source_snapshot_count:         ; @nl_file_source_snapshot_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshot_storage ; -- Begin function nl_file_source_snapshot_storage
	.p2align	2
_nl_file_source_snapshot_storage:       ; @nl_file_source_snapshot_storage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshot_peak_bound ; -- Begin function nl_file_source_snapshot_peak_bound
	.p2align	2
_nl_file_source_snapshot_peak_bound:    ; @nl_file_source_snapshot_peak_bound
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_3
LBB7_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_3
LBB7_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshot_bytes  ; -- Begin function nl_file_source_snapshot_bytes
	.p2align	2
_nl_file_source_snapshot_bytes:         ; @nl_file_source_snapshot_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #40]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #40]
	cbz	x8, LBB8_3
	b	LBB8_2
LBB8_2:
	ldur	x8, [x29, #-24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.lo	LBB8_4
	b	LBB8_3
LBB8_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB8_25
LBB8_4:
	ldur	x8, [x29, #-16]
	add	x8, x8, #24
	ldur	x9, [x29, #-24]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldur	w8, [x29, #-28]
	cbnz	w8, LBB8_6
	b	LBB8_5
LBB8_5:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	b	LBB8_25
LBB8_6:
	ldur	w8, [x29, #-28]
	subs	w8, w8, #1
	b.ne	LBB8_8
	b	LBB8_7
LBB8_7:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #40]
	str	x8, [x9]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-8]
	b	LBB8_25
LBB8_8:
	ldur	w8, [x29, #-28]
	subs	w8, w8, #2
	b.ne	LBB8_16
	b	LBB8_9
LBB8_9:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	subs	x8, x8, #1
	b.ne	LBB8_11
	b	LBB8_10
LBB8_10:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_file_binding_interface_bytes
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB8_15
LBB8_11:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB8_13
	b	LBB8_12
LBB8_12:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_socket_binding_interface_bytes
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB8_14
LBB8_13:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_websocket_binding_interface_bytes
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB8_14
LBB8_14:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB8_15
LBB8_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-8]
	b	LBB8_25
LBB8_16:
	ldur	w8, [x29, #-28]
	subs	w8, w8, #3
	b.ne	LBB8_24
	b	LBB8_17
LBB8_17:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	subs	x8, x8, #1
	b.ne	LBB8_19
	b	LBB8_18
LBB8_18:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_file_binding_source_bytes
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_23
LBB8_19:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB8_21
	b	LBB8_20
LBB8_20:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_socket_binding_source_bytes
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB8_22
LBB8_21:
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #40]
	ldr	x1, [sp, #40]
	bl	_nl_websocket_binding_source_bytes
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB8_22
LBB8_22:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_23
LBB8_23:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-8]
	b	LBB8_25
LBB8_24:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB8_25
LBB8_25:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_source_snapshot_open   ; -- Begin function nl_file_source_snapshot_open
	.p2align	2
_nl_file_source_snapshot_open:          ; @nl_file_source_snapshot_open
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
	str	x3, [sp, #16]
	str	x4, [sp, #8]
	str	x5, [sp]
	ldur	x0, [x29, #-8]
	ldur	x2, [x29, #-16]
	ldr	x3, [sp, #24]
	ldr	x4, [sp, #16]
	ldr	x5, [sp, #8]
	ldr	x6, [sp]
	mov	x1, #1                          ; =0x1
	bl	_nl_service_source_snapshot_open
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_service_source_snapshot_catalog ; -- Begin function nl_service_source_snapshot_catalog
	.p2align	2
_nl_service_source_snapshot_catalog:    ; @nl_service_source_snapshot_catalog
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB10_3
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	LBB10_3
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #24]
	add	x8, x8, #24
	ldr	x9, [sp, #16]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x8, [x8, #32]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB10_4
LBB10_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB10_4
LBB10_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
