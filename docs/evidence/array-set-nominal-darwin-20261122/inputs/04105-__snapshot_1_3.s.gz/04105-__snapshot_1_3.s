	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nl_socket_plan_build   ; -- Begin function nl_socket_plan_build
	.globl	_nl_socket_plan_build
	.p2align	2
_nl_socket_plan_build:                  ; @nl_socket_plan_build
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x0, [sp, #16]
	adrp	x1, _catalog@PAGE
	add	x1, x1, _catalog@PAGEOFF
	bl	_nl_service_catalog_document_equal
	tbnz	w0, #0, LBB0_3
	b	LBB0_2
LBB0_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_3:
	mov	x0, #8                          ; =0x8
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB0_5
	b	LBB0_4
LBB0_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_5:
	ldr	x9, [sp]
	adrp	x8, _catalog@PAGE
	add	x8, x8, _catalog@PAGEOFF
	str	x8, [x9]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB0_6
LBB0_6:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_document_equal
_nl_service_catalog_document_equal:     ; @nl_service_catalog_document_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB1_12
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	cbnz	w8, LBB1_12
	b	LBB1_2
LBB1_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_12
	b	LBB1_3
LBB1_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_12
	b	LBB1_4
LBB1_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_5
LBB1_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_6
LBB1_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #64]
	subs	x8, x8, #1
	b.ne	LBB1_12
	b	LBB1_7
LBB1_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #80]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_8
LBB1_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_12
	b	LBB1_9
LBB1_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	cbz	x8, LBB1_12
	b	LBB1_10
LBB1_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB1_12
	b	LBB1_11
LBB1_11:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	cbnz	x8, LBB1_13
	b	LBB1_12
LBB1_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_13:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_16
	b	LBB1_14
LBB1_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_16
	b	LBB1_15
LBB1_15:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_17
	b	LBB1_16
LBB1_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_17:
	stur	xzr, [x29, #-32]
	b	LBB1_18
LBB1_18:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB1_24
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x1, [x8, x9]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_21
	b	LBB1_20
LBB1_20:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_22
	b	LBB1_21
LBB1_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_22:                                ;   in Loop: Header=BB1_18 Depth=1
	b	LBB1_23
LBB1_23:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB1_18
LBB1_24:
	stur	xzr, [x29, #-40]
	b	LBB1_25
LBB1_25:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_33 Depth 2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB1_48
	b	LBB1_26
LBB1_26:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-40]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-40]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-48]
	ldr	x0, [x8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_31
	b	LBB1_27
LBB1_27:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_31
	b	LBB1_28
LBB1_28:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	cbnz	w8, LBB1_31
	b	LBB1_29
LBB1_29:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB1_31
	b	LBB1_30
LBB1_30:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB1_32
	b	LBB1_31
LBB1_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_32:                                ;   in Loop: Header=BB1_25 Depth=1
	str	xzr, [sp, #64]
	b	LBB1_33
LBB1_33:                                ;   Parent Loop BB1_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB1_46
	b	LBB1_34
LBB1_34:                                ;   in Loop: Header=BB1_33 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #64]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #56]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #64]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	x0, [x8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_35
LBB1_35:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_36
LBB1_36:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_37
LBB1_37:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_38
LBB1_38:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #28]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_39
LBB1_39:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #32]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_40
LBB1_40:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #36]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_41
LBB1_41:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #40]
	cbnz	w8, LBB1_43
	b	LBB1_42
LBB1_42:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #44]
	cbz	w8, LBB1_44
	b	LBB1_43
LBB1_43:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_44:                                ;   in Loop: Header=BB1_33 Depth=2
	b	LBB1_45
LBB1_45:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB1_33
LBB1_46:                                ;   in Loop: Header=BB1_25 Depth=1
	b	LBB1_47
LBB1_47:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB1_25
LBB1_48:
	str	xzr, [sp, #40]
	b	LBB1_49
LBB1_49:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_63 Depth 2
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB1_72
	b	LBB1_50
LBB1_50:                                ;   in Loop: Header=BB1_49 Depth=1
	ldur	x8, [x29, #-16]
	mov	x10, #40                        ; =0x28
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #40]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_61
	b	LBB1_51
LBB1_51:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_61
	b	LBB1_52
LBB1_52:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB1_61
	b	LBB1_53
LBB1_53:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB1_61
	b	LBB1_54
LBB1_54:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #40]
	cbnz	x8, LBB1_61
	b	LBB1_55
LBB1_55:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB1_61
	b	LBB1_56
LBB1_56:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB1_61
	b	LBB1_57
LBB1_57:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB1_59
	b	LBB1_58
LBB1_58:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_61
	b	LBB1_59
LBB1_59:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB1_62
	b	LBB1_60
LBB1_60:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_62
	b	LBB1_61
LBB1_61:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_62:                                ;   in Loop: Header=BB1_49 Depth=1
	str	xzr, [sp, #16]
	b	LBB1_63
LBB1_63:                                ;   Parent Loop BB1_49 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB1_70
	b	LBB1_64
LBB1_64:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #32]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	add	x8, x8, x9, lsl #5
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	ldr	x8, [sp]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_67
	b	LBB1_65
LBB1_65:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_67
	b	LBB1_66
LBB1_66:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	ldr	x8, [sp]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_68
	b	LBB1_67
LBB1_67:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_68:                                ;   in Loop: Header=BB1_63 Depth=2
	b	LBB1_69
LBB1_69:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB1_63
LBB1_70:                                ;   in Loop: Header=BB1_49 Depth=1
	b	LBB1_71
LBB1_71:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #1
	str	x8, [sp, #40]
	b	LBB1_49
LBB1_72:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_73:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_free    ; -- Begin function nl_socket_plan_free
	.globl	_nl_socket_plan_free
	.p2align	2
_nl_socket_plan_free:                   ; @nl_socket_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_storage_size ; -- Begin function nl_socket_plan_storage_size
	.globl	_nl_socket_plan_storage_size
	.p2align	2
_nl_socket_plan_storage_size:           ; @nl_socket_plan_storage_size
	.cfi_startproc
; %bb.0:
	mov	x0, #8                          ; =0x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_interface ; -- Begin function nl_socket_plan_interface
	.globl	_nl_socket_plan_interface
	.p2align	2
_nl_socket_plan_interface:              ; @nl_socket_plan_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB4_3
LBB4_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB4_3
LBB4_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_method_count ; -- Begin function nl_socket_plan_method_count
	.globl	_nl_socket_plan_method_count
	.p2align	2
_nl_socket_plan_method_count:           ; @nl_socket_plan_method_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #64]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_type_count ; -- Begin function nl_socket_plan_type_count
	.globl	_nl_socket_plan_type_count
	.p2align	2
_nl_socket_plan_type_count:             ; @nl_socket_plan_type_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #80]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_method  ; -- Begin function nl_socket_plan_method
	.globl	_nl_socket_plan_method
	.p2align	2
_nl_socket_plan_method:                 ; @nl_socket_plan_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB7_3
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB7_3
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #56]
	ldr	x9, [sp, #16]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB7_4
LBB7_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB7_4
LBB7_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_plan_type    ; -- Begin function nl_socket_plan_type
	.globl	_nl_socket_plan_type
	.p2align	2
_nl_socket_plan_type:                   ; @nl_socket_plan_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #16]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_catalog_interface ; -- Begin function nl_socket_catalog_interface
	.globl	_nl_socket_catalog_interface
	.p2align	2
_nl_socket_catalog_interface:           ; @nl_socket_catalog_interface
	.cfi_startproc
; %bb.0:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_catalog_method ; -- Begin function nl_socket_catalog_method
	.globl	_nl_socket_catalog_method
	.p2align	2
_nl_socket_catalog_method:              ; @nl_socket_catalog_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #5
	b.hs	LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #8]
	mov	x9, #96                         ; =0x60
	mul	x9, x8, x9
	adrp	x8, _methods@PAGE
	add	x8, x8, _methods@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB10_3
LBB10_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_socket_catalog_type ; -- Begin function nl_socket_catalog_type
	.globl	_nl_socket_catalog_type
	.p2align	2
_nl_socket_catalog_type:                ; @nl_socket_catalog_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #9
	b.hs	LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #8]
	mov	x9, #40                         ; =0x28
	mul	x9, x8, x9
	adrp	x8, _types@PAGE
	add	x8, x8, _types@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB11_3
LBB11_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_text_equal
_nl_service_catalog_text_equal:         ; @nl_service_catalog_text_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB12_3
	b	LBB12_2
LBB12_2:
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB12_4
LBB12_3:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB12_4
LBB12_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w0, ne
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__const
	.p2align	3, 0x0                          ; @catalog
_catalog:
	.quad	l_.str
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	_capabilities
	.quad	1                               ; 0x1
	.quad	_methods
	.quad	5                               ; 0x5
	.quad	_types
	.quad	9                               ; 0x9

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/net"

l_.str.1:                               ; @.str.1
	.asciz	"net"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/net#io"

l_.str.3:                               ; @.str.3
	.asciz	"io"

l_.str.4:                               ; @.str.4
	.asciz	"1"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @capabilities
_capabilities:
	.quad	l_.str.5
	.quad	l_.str.6

	.section	__TEXT,__cstring,cstring_literals
l_.str.5:                               ; @.str.5
	.asciz	"cap:nanolang/net.connect"

l_.str.6:                               ; @.str.6
	.asciz	"connect"

l_.str.7:                               ; @.str.7
	.asciz	"nsi:nanolang/net#begin_connect"

l_.str.8:                               ; @.str.8
	.asciz	"begin_connect"

l_.str.9:                               ; @.str.9
	.asciz	"nsi_nanolang_net_begin_connect"

l_.str.10:                              ; @.str.10
	.asciz	"nsi.tcp.v1.begin_connect"

l_.str.11:                              ; @.str.11
	.asciz	"nsi:nanolang/net#Conn"

l_.str.12:                              ; @.str.12
	.asciz	"nsi:nanolang/net#send_byte"

l_.str.13:                              ; @.str.13
	.asciz	"send_byte"

l_.str.14:                              ; @.str.14
	.asciz	"nsi_nanolang_net_send_byte"

l_.str.15:                              ; @.str.15
	.asciz	"nsi.tcp.v1.send_byte"

l_.str.16:                              ; @.str.16
	.asciz	"nsi:nanolang/net#finish_connect"

l_.str.17:                              ; @.str.17
	.asciz	"finish_connect"

l_.str.18:                              ; @.str.18
	.asciz	"nsi_nanolang_net_finish_connect"

l_.str.19:                              ; @.str.19
	.asciz	"nsi.tcp.v1.finish_connect"

l_.str.20:                              ; @.str.20
	.asciz	"nsi:nanolang/net#receive_byte"

l_.str.21:                              ; @.str.21
	.asciz	"receive_byte"

l_.str.22:                              ; @.str.22
	.asciz	"nsi_nanolang_net_receive_byte"

l_.str.23:                              ; @.str.23
	.asciz	"nsi.tcp.v1.receive_byte"

l_.str.24:                              ; @.str.24
	.asciz	"nsi:nanolang/net#close"

l_.str.25:                              ; @.str.25
	.asciz	"close"

l_.str.26:                              ; @.str.26
	.asciz	"nsi_nanolang_net_close"

l_.str.27:                              ; @.str.27
	.asciz	"nsi.tcp.v1.close"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @methods
_methods:
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.9
	.quad	l_.str.10
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	19                              ; 0x13
	.long	0                               ; 0x0
	.quad	_begin_params
	.quad	2                               ; 0x2
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.11
	.space	16
	.quad	l_.str.12
	.quad	l_.str.13
	.quad	l_.str.14
	.quad	l_.str.15
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_send_params
	.quad	3                               ; 0x3
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.16
	.quad	l_.str.17
	.quad	l_.str.18
	.quad	l_.str.19
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_finish_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.20
	.quad	l_.str.21
	.quad	l_.str.22
	.quad	l_.str.23
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_receive_params
	.quad	2                               ; 0x2
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.24
	.quad	l_.str.25
	.quad	l_.str.26
	.quad	l_.str.27
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.quad	_close_params
	.quad	2                               ; 0x2
	.long	2                               ; 0x2
	.space	4
	.quad	0
	.long	2                               ; 0x2
	.space	4
	.quad	0

	.section	__TEXT,__cstring,cstring_literals
l_.str.29:                              ; @.str.29
	.asciz	"nsi:nanolang/net#begin_connect.endpoint"

l_.str.30:                              ; @.str.30
	.asciz	"endpoint"

l_.str.31:                              ; @.str.31
	.asciz	"nsi:nanolang/net#Endpoint"

l_.str.32:                              ; @.str.32
	.asciz	"nsi:nanolang/net#begin_connect.result"

l_.str.33:                              ; @.str.33
	.asciz	"result"

l_.str.34:                              ; @.str.34
	.asciz	"nsi:nanolang/net#ConnectResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @begin_params
_begin_params:
	.quad	l_.str.29
	.quad	l_.str.30
	.quad	l_.str.31
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.32
	.quad	l_.str.33
	.quad	l_.str.34
	.long	3                               ; 0x3
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.36:                              ; @.str.36
	.asciz	"nsi:nanolang/net#send_byte.connection"

l_.str.37:                              ; @.str.37
	.asciz	"connection"

l_.str.38:                              ; @.str.38
	.asciz	"nsi:nanolang/net#send_byte.value"

l_.str.39:                              ; @.str.39
	.asciz	"value"

l_.str.40:                              ; @.str.40
	.asciz	"nsi:core/int"

l_.str.41:                              ; @.str.41
	.asciz	"nsi:nanolang/net#send_byte.result"

l_.str.42:                              ; @.str.42
	.asciz	"nsi:nanolang/net#SendResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @send_params
_send_params:
	.quad	l_.str.36
	.quad	l_.str.37
	.quad	l_.str.11
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.38
	.quad	l_.str.39
	.quad	l_.str.40
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.41
	.quad	l_.str.33
	.quad	l_.str.42
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.44:                              ; @.str.44
	.asciz	"nsi:nanolang/net#finish_connect.connection"

l_.str.45:                              ; @.str.45
	.asciz	"nsi:nanolang/net#finish_connect.result"

l_.str.46:                              ; @.str.46
	.asciz	"nsi:nanolang/net#ConnectStatus"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @finish_params
_finish_params:
	.quad	l_.str.44
	.quad	l_.str.37
	.quad	l_.str.11
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.45
	.quad	l_.str.33
	.quad	l_.str.46
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.48:                              ; @.str.48
	.asciz	"nsi:nanolang/net#receive_byte.connection"

l_.str.49:                              ; @.str.49
	.asciz	"nsi:nanolang/net#receive_byte.result"

l_.str.50:                              ; @.str.50
	.asciz	"nsi:nanolang/net#ReceiveResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @receive_params
_receive_params:
	.quad	l_.str.48
	.quad	l_.str.37
	.quad	l_.str.11
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.49
	.quad	l_.str.33
	.quad	l_.str.50
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.52:                              ; @.str.52
	.asciz	"nsi:nanolang/net#close.connection"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:nanolang/net#close.result"

l_.str.54:                              ; @.str.54
	.asciz	"nsi:nanolang/net#CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @close_params
_close_params:
	.quad	l_.str.52
	.quad	l_.str.37
	.quad	l_.str.11
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.53
	.quad	l_.str.33
	.quad	l_.str.54
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.56:                              ; @.str.56
	.asciz	"Conn"

l_.str.57:                              ; @.str.57
	.asciz	"nsi:nanolang/net#SocketError"

l_.str.58:                              ; @.str.58
	.asciz	"SocketError"

l_.str.59:                              ; @.str.59
	.asciz	"nsi:nanolang/net#ReadByte"

l_.str.60:                              ; @.str.60
	.asciz	"ReadByte"

l_.str.61:                              ; @.str.61
	.asciz	"ConnectResult"

l_.str.62:                              ; @.str.62
	.asciz	"SendResult"

l_.str.63:                              ; @.str.63
	.asciz	"ConnectStatus"

l_.str.64:                              ; @.str.64
	.asciz	"ReceiveResult"

l_.str.65:                              ; @.str.65
	.asciz	"CloseResult"

l_.str.66:                              ; @.str.66
	.asciz	"Endpoint"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @types
_types:
	.quad	l_.str.11
	.quad	l_.str.56
	.long	6                               ; 0x6
	.space	4
	.quad	0
	.quad	0                               ; 0x0
	.quad	l_.str.57
	.quad	l_.str.58
	.long	1                               ; 0x1
	.space	4
	.quad	_error_fields
	.quad	11                              ; 0xb
	.quad	l_.str.59
	.quad	l_.str.60
	.long	1                               ; 0x1
	.space	4
	.quad	_byte_fields
	.quad	2                               ; 0x2
	.quad	l_.str.34
	.quad	l_.str.61
	.long	2                               ; 0x2
	.space	4
	.quad	_ConnectResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.42
	.quad	l_.str.62
	.long	2                               ; 0x2
	.space	4
	.quad	_SendResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.46
	.quad	l_.str.63
	.long	2                               ; 0x2
	.space	4
	.quad	_ConnectStatus_cases
	.quad	2                               ; 0x2
	.quad	l_.str.50
	.quad	l_.str.64
	.long	2                               ; 0x2
	.space	4
	.quad	_ReceiveResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.54
	.quad	l_.str.65
	.long	2                               ; 0x2
	.space	4
	.quad	_CloseResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.31
	.quad	l_.str.66
	.long	1                               ; 0x1
	.space	4
	.quad	_endpoint_fields
	.quad	7                               ; 0x7

	.section	__TEXT,__cstring,cstring_literals
l_.str.68:                              ; @.str.68
	.asciz	"nsi:nanolang/net#SocketError.status"

l_.str.69:                              ; @.str.69
	.asciz	"status"

l_.str.70:                              ; @.str.70
	.asciz	"nsi:nanolang/net#SocketError.host_errno"

l_.str.71:                              ; @.str.71
	.asciz	"host_errno"

l_.str.72:                              ; @.str.72
	.asciz	"nsi:nanolang/net#SocketError.cleanup_errno"

l_.str.73:                              ; @.str.73
	.asciz	"cleanup_errno"

l_.str.74:                              ; @.str.74
	.asciz	"nsi:nanolang/net#SocketError.bytes"

l_.str.75:                              ; @.str.75
	.asciz	"bytes"

l_.str.76:                              ; @.str.76
	.asciz	"nsi:nanolang/net#SocketError.close_attempts"

l_.str.77:                              ; @.str.77
	.asciz	"close_attempts"

l_.str.78:                              ; @.str.78
	.asciz	"nsi:nanolang/net#SocketError.closed_count"

l_.str.79:                              ; @.str.79
	.asciz	"closed_count"

l_.str.80:                              ; @.str.80
	.asciz	"nsi:nanolang/net#SocketError.eof"

l_.str.81:                              ; @.str.81
	.asciz	"eof"

l_.str.82:                              ; @.str.82
	.asciz	"nsi:core/bool"

l_.str.83:                              ; @.str.83
	.asciz	"nsi:nanolang/net#SocketError.consumed"

l_.str.84:                              ; @.str.84
	.asciz	"consumed"

l_.str.85:                              ; @.str.85
	.asciz	"nsi:nanolang/net#SocketError.cleanup_failed"

l_.str.86:                              ; @.str.86
	.asciz	"cleanup_failed"

l_.str.87:                              ; @.str.87
	.asciz	"nsi:nanolang/net#SocketError.closure_unknown"

l_.str.88:                              ; @.str.88
	.asciz	"closure_unknown"

l_.str.89:                              ; @.str.89
	.asciz	"nsi:nanolang/net#SocketError.connect_pending"

l_.str.90:                              ; @.str.90
	.asciz	"connect_pending"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @error_fields
_error_fields:
	.quad	l_.str.68
	.quad	l_.str.69
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.70
	.quad	l_.str.71
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.72
	.quad	l_.str.73
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.74
	.quad	l_.str.75
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.76
	.quad	l_.str.77
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.78
	.quad	l_.str.79
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.80
	.quad	l_.str.81
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.83
	.quad	l_.str.84
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.85
	.quad	l_.str.86
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.87
	.quad	l_.str.88
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.89
	.quad	l_.str.90
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.92:                              ; @.str.92
	.asciz	"nsi:nanolang/net#ReadByte.value"

l_.str.93:                              ; @.str.93
	.asciz	"nsi:nanolang/net#ReadByte.eof"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @byte_fields
_byte_fields:
	.quad	l_.str.92
	.quad	l_.str.39
	.quad	l_.str.40
	.long	1                               ; 0x1
	.space	4
	.quad	l_.str.93
	.quad	l_.str.81
	.quad	l_.str.82
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.95:                              ; @.str.95
	.asciz	"nsi:nanolang/net#ConnectResult.Ok"

l_.str.96:                              ; @.str.96
	.asciz	"Ok"

l_.str.97:                              ; @.str.97
	.asciz	"nsi:nanolang/net#ConnectResult.Error"

l_.str.98:                              ; @.str.98
	.asciz	"Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ConnectResult_cases
_ConnectResult_cases:
	.quad	l_.str.95
	.quad	l_.str.96
	.quad	l_.str.11
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.97
	.quad	l_.str.98
	.quad	l_.str.57
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.100:                             ; @.str.100
	.asciz	"nsi:nanolang/net#SendResult.Ok"

l_.str.101:                             ; @.str.101
	.asciz	"nsi:nanolang/net#SendResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @SendResult_cases
_SendResult_cases:
	.quad	l_.str.100
	.quad	l_.str.96
	.quad	l_.str.40
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.101
	.quad	l_.str.98
	.quad	l_.str.57
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.103:                             ; @.str.103
	.asciz	"nsi:nanolang/net#ConnectStatus.Ok"

l_.str.104:                             ; @.str.104
	.asciz	"nsi:nanolang/net#ConnectStatus.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ConnectStatus_cases
_ConnectStatus_cases:
	.quad	l_.str.103
	.quad	l_.str.96
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.104
	.quad	l_.str.98
	.quad	l_.str.57
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.106:                             ; @.str.106
	.asciz	"nsi:nanolang/net#ReceiveResult.Ok"

l_.str.107:                             ; @.str.107
	.asciz	"nsi:nanolang/net#ReceiveResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ReceiveResult_cases
_ReceiveResult_cases:
	.quad	l_.str.106
	.quad	l_.str.96
	.quad	l_.str.59
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.107
	.quad	l_.str.98
	.quad	l_.str.57
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.109:                             ; @.str.109
	.asciz	"nsi:nanolang/net#CloseResult.Ok"

l_.str.110:                             ; @.str.110
	.asciz	"nsi:nanolang/net#CloseResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @CloseResult_cases
_CloseResult_cases:
	.quad	l_.str.109
	.quad	l_.str.96
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.110
	.quad	l_.str.98
	.quad	l_.str.57
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.112:                             ; @.str.112
	.asciz	"nsi:nanolang/net#Endpoint.family"

l_.str.113:                             ; @.str.113
	.asciz	"family"

l_.str.114:                             ; @.str.114
	.asciz	"nsi:nanolang/net#Endpoint.address0"

l_.str.115:                             ; @.str.115
	.asciz	"address0"

l_.str.116:                             ; @.str.116
	.asciz	"nsi:nanolang/net#Endpoint.address1"

l_.str.117:                             ; @.str.117
	.asciz	"address1"

l_.str.118:                             ; @.str.118
	.asciz	"nsi:nanolang/net#Endpoint.address2"

l_.str.119:                             ; @.str.119
	.asciz	"address2"

l_.str.120:                             ; @.str.120
	.asciz	"nsi:nanolang/net#Endpoint.address3"

l_.str.121:                             ; @.str.121
	.asciz	"address3"

l_.str.122:                             ; @.str.122
	.asciz	"nsi:nanolang/net#Endpoint.port"

l_.str.123:                             ; @.str.123
	.asciz	"port"

l_.str.124:                             ; @.str.124
	.asciz	"nsi:nanolang/net#Endpoint.scope_id"

l_.str.125:                             ; @.str.125
	.asciz	"scope_id"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @endpoint_fields
_endpoint_fields:
	.quad	l_.str.112
	.quad	l_.str.113
	.quad	l_.str.40
	.long	4                               ; 0x4
	.space	4
	.quad	l_.str.114
	.quad	l_.str.115
	.quad	l_.str.40
	.long	2                               ; 0x2
	.space	4
	.quad	l_.str.116
	.quad	l_.str.117
	.quad	l_.str.40
	.long	2                               ; 0x2
	.space	4
	.quad	l_.str.118
	.quad	l_.str.119
	.quad	l_.str.40
	.long	2                               ; 0x2
	.space	4
	.quad	l_.str.120
	.quad	l_.str.121
	.quad	l_.str.40
	.long	2                               ; 0x2
	.space	4
	.quad	l_.str.122
	.quad	l_.str.123
	.quad	l_.str.40
	.long	3                               ; 0x3
	.space	4
	.quad	l_.str.124
	.quad	l_.str.125
	.quad	l_.str.40
	.long	2                               ; 0x2
	.space	4

.subsections_via_symbols
