	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_constants_decode        ; -- Begin function nvm_v2_constants_decode
	.p2align	2
_nvm_v2_constants_decode:               ; @nvm_v2_constants_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-32]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #8]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-24]
	add	x0, sp, #56
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, sp, #52
	bl	_nvm_v2_u32
	str	w0, [sp, #48]
	ldr	w8, [sp, #48]
	cbz	w8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB0_34
LBB0_2:
	ldr	w8, [sp, #52]
	cbnz	w8, LBB0_4
	b	LBB0_3
LBB0_3:
	stur	wzr, [x29, #-4]
	b	LBB0_34
LBB0_4:
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #72]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB0_6
	b	LBB0_5
LBB0_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_34
LBB0_6:
	ldr	w8, [sp, #52]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB0_8
	b	LBB0_7
LBB0_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_34
LBB0_8:
	str	wzr, [sp, #36]
	b	LBB0_9
LBB0_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #52]
	subs	w8, w8, w9
	b.hs	LBB0_32
	b	LBB0_10
LBB0_10:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #35
	bl	_nvm_v2_u8
	str	w0, [sp, #48]
	cbz	w0, LBB0_12
	b	LBB0_11
LBB0_11:
	b	LBB0_33
LBB0_12:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #34
	bl	_nvm_v2_u8
	str	w0, [sp, #48]
	cbz	w0, LBB0_14
	b	LBB0_13
LBB0_13:
	b	LBB0_33
LBB0_14:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #33
	bl	_nvm_v2_u8
	str	w0, [sp, #48]
	cbz	w0, LBB0_16
	b	LBB0_15
LBB0_15:
	b	LBB0_33
LBB0_16:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #32
	bl	_nvm_v2_u8
	str	w0, [sp, #48]
	cbz	w0, LBB0_18
	b	LBB0_17
LBB0_17:
	b	LBB0_33
LBB0_18:                                ;   in Loop: Header=BB0_9 Depth=1
	ldrb	w8, [sp, #34]
	cbnz	w8, LBB0_21
	b	LBB0_19
LBB0_19:                                ;   in Loop: Header=BB0_9 Depth=1
	ldrb	w8, [sp, #33]
	cbnz	w8, LBB0_21
	b	LBB0_20
LBB0_20:                                ;   in Loop: Header=BB0_9 Depth=1
	ldrb	w8, [sp, #32]
	cbz	w8, LBB0_22
	b	LBB0_21
LBB0_21:
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #48]
	b	LBB0_33
LBB0_22:                                ;   in Loop: Header=BB0_9 Depth=1
	ldrb	w8, [sp, #35]
	subs	w8, w8, #16
	b.lt	LBB0_24
	b	LBB0_23
LBB0_23:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #48]
	b	LBB0_33
LBB0_24:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #28
	bl	_nvm_v2_u32
	str	w0, [sp, #48]
	cbz	w0, LBB0_26
	b	LBB0_25
LBB0_25:
	b	LBB0_33
LBB0_26:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x2, sp, #16
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	ldr	w8, [sp, #28]
	mov	x1, x8
	add	x0, sp, #56
	bl	_nvm_v2_take
	str	w0, [sp, #48]
	cbz	w0, LBB0_28
	b	LBB0_27
LBB0_27:
	b	LBB0_33
LBB0_28:                                ;   in Loop: Header=BB0_9 Depth=1
	add	x0, sp, #56
	bl	_nvm_v2_align4
	str	w0, [sp, #48]
	cbz	w0, LBB0_30
	b	LBB0_29
LBB0_29:
	b	LBB0_33
LBB0_30:                                ;   in Loop: Header=BB0_9 Depth=1
	ldrb	w8, [sp, #35]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	strb	w8, [x9]
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #4]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x8, [x9, #8]
	b	LBB0_31
LBB0_31:                                ;   in Loop: Header=BB0_9 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB0_9
LBB0_32:
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #8]
	stur	wzr, [x29, #-4]
	b	LBB0_34
LBB0_33:
	ldr	x0, [sp, #40]
	bl	_free
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB0_34
LBB0_34:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_constants_free          ; -- Begin function nvm_v2_constants_free
	.p2align	2
_nvm_v2_constants_free:                 ; @nvm_v2_constants_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #8]
	b	LBB1_3
LBB1_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_constants_encoded_size  ; -- Begin function nvm_v2_constants_encoded_size
	.p2align	2
_nvm_v2_constants_encoded_size:         ; @nvm_v2_constants_encoded_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB2_1
LBB2_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB2_4
	b	LBB2_2
LBB2_2:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #4]
	mov	x0, x8
	bl	_padded
	add	x9, x0, #8
	ldr	x8, [sp, #16]
	add	x8, x8, x9
	str	x8, [sp, #16]
	b	LBB2_3
LBB2_3:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB2_1
LBB2_4:
	ldr	x0, [sp, #16]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function padded
_padded:                                ; @padded
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	add	x8, x8, #3
	and	x0, x8, #0xfffffffffffffffc
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_constants_encode        ; -- Begin function nvm_v2_constants_encode
	.p2align	2
_nvm_v2_constants_encode:               ; @nvm_v2_constants_encode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_constants_encoded_size
	str	x0, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB4_2
	b	LBB4_1
LBB4_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_9
LBB4_2:
	ldur	x0, [x29, #-24]
	ldr	x2, [sp, #24]
	mov	w1, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	str	xzr, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #16
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	lsr	w8, w8, #24
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	str	wzr, [sp, #12]
	b	LBB4_3
LBB4_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB4_8
	b	LBB4_4
LBB4_4:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #4]
	str	w8, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x9, x9, x10
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	add	x8, x8, #4
	str	x8, [sp, #16]
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldr	w8, [sp, #8]
	lsr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldr	w8, [sp, #8]
	lsr	w8, w8, #16
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldr	w8, [sp, #8]
	lsr	w8, w8, #24
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #16]
	add	x11, x10, #1
	str	x11, [sp, #16]
	strb	w8, [x9, x10]
	ldr	w8, [sp, #8]
	cbz	w8, LBB4_6
	b	LBB4_5
LBB4_5:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #16]
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8, #8]
	ldr	w8, [sp, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB4_6
LBB4_6:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #8]
	mov	x0, x8
	bl	_padded
	ldr	x8, [sp, #16]
	add	x8, x8, x0
	str	x8, [sp, #16]
	b	LBB4_7
LBB4_7:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB4_3
LBB4_8:
	stur	wzr, [x29, #-4]
	b	LBB4_9
LBB4_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
