import pathlib,tempfile,unittest,json,time
from tests import test_nominal_record_array_mutation as tests
original=tempfile.TemporaryDirectory
def retained(*args,**kwargs):
 kwargs['delete']=False
 return original(*args,**kwargs)
tempfile.TemporaryDirectory=retained
tests.NominalRecordArrayMutation.routes=lambda self:[('c',pathlib.Path('/Users/jkh/.worktrees/nanolang/array-set-nominal-20261122/bin/nanoc_c_nominal_asan'),[])]
suite=unittest.defaultTestLoader.loadTestsFromModule(tests);assert suite.countTestCases()==4
started=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(suite)
pathlib.Path('/Users/jkh/.worktrees/nanolang/array-set-nominal-20261122-control/compiler-sanitizers/result.json').write_text(json.dumps(dict(discovered=4,ran=r.testsRun,failures=r.failures,errors=r.errors,skipped=r.skipped,successful=r.wasSuccessful(),seconds=time.monotonic()-started),indent=2)+'\n')
raise SystemExit(0 if r.wasSuccessful() and r.testsRun==4 and not r.skipped else 1)
