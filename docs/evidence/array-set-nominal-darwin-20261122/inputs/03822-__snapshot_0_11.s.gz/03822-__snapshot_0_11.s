	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_cap_private_storage_bound   ; -- Begin function nl_cap_private_storage_bound
	.p2align	2
_nl_cap_private_storage_bound:          ; @nl_cap_private_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	mov	w8, #40464                      ; =0x9e10
	str	x8, [x0]
LBB0_2:
	cmp	x0, #0
	cset	w0, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_table_create            ; -- Begin function nl_cap_table_create
	.p2align	2
_nl_cap_table_create:                   ; @nl_cap_table_create
	.cfi_startproc
; %bb.0:
	mov	w0, #1                          ; =0x1
	mov	w1, #40464                      ; =0x9e10
	b	_calloc
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_table_destroy           ; -- Begin function nl_cap_table_destroy
	.p2align	2
_nl_cap_table_destroy:                  ; @nl_cap_table_destroy
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_mint                    ; -- Begin function nl_cap_mint
	.p2align	2
_nl_cap_mint:                           ; @nl_cap_mint
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	add	x20, x0, #9, lsl #12            ; =36864
	bl	_mint_slot
	cbz	w0, LBB3_4
; %bb.1:
	cbz	x19, LBB3_8
; %bb.2:
	ldr	w8, [x20, #3592]
	cmp	w8, #127
	b.gt	LBB3_8
; %bb.3:
	mov	x21, x0
	add	w9, w8, #1
	str	w9, [x20, #3592]
	mov	w9, #4                          ; =0x4
	b	LBB3_7
LBB3_4:
	cbz	x19, LBB3_8
; %bb.5:
	ldr	w8, [x20, #3592]
	cmp	w8, #127
	b.gt	LBB3_8
; %bb.6:
	mov	x21, x0
	mov	w9, #0                          ; =0x0
	add	w10, w8, #1
	str	w10, [x20, #3592]
LBB3_7:
	mov	w10, #36                        ; =0x24
	smaddl	x8, w8, w10, x19
	mov	w10, #35848                     ; =0x8c08
	str	w9, [x8, x10]
	ldr	w9, [x20, #3596]
	add	w9, w9, #1
	str	w9, [x20, #3596]
	mov	w10, #35852                     ; =0x8c0c
	str	x9, [sp]
Lloh0:
	adrp	x2, l_.str.1@PAGE
Lloh1:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x8, x10
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x21
LBB3_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function mint_slot
lCPI4_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_mint_slot:                             ; @mint_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x8, x0
	str	xzr, [sp, #8]
	mov	w0, #7                          ; =0x7
	cbz	x8, LBB4_13
; %bb.1:
	cbz	x1, LBB4_13
; %bb.2:
	cbz	x2, LBB4_13
; %bb.3:
	cbz	x6, LBB4_13
; %bb.4:
	ldrb	w9, [x1]
	cbz	w9, LBB4_13
; %bb.5:
	ldrb	w9, [x2]
	cbz	w9, LBB4_13
; %bb.6:
	mov	x22, #0                         ; =0x0
	mov	x19, x8
LBB4_7:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x19]
	cbz	w9, LBB4_9
; %bb.8:                                ;   in Loop: Header=BB4_7 Depth=1
	add	x22, x22, #1
	add	x19, x19, #544
	cmp	x22, #64
	b.ne	LBB4_7
	b	LBB4_10
LBB4_9:
	cmp	x22, #64
	b.ne	LBB4_11
LBB4_10:
	mov	w0, #6                          ; =0x6
	b	LBB4_13
LBB4_11:
	mov	x27, x4
	mov	x28, x8
	mov	x21, x3
	mov	x20, x1
	mov	x25, x2
	mov	x24, x5
	str	x6, [sp]                        ; 8-byte Folded Spill
	add	x0, sp, #8
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbz	w0, LBB4_14
LBB4_12:
	mov	w0, #9                          ; =0x9
LBB4_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB4_14:
	ldr	x26, [sp, #8]
	cbz	x26, LBB4_19
LBB4_15:
	cbz	x26, LBB4_12
; %bb.16:
	mov	w23, #34816                     ; =0x8800
	ldr	w8, [x28, x23]
	add	w8, w8, #1
	str	w8, [x28, x23]
	mov	x0, x19
	mov	w1, #544                        ; =0x220
	bl	_bzero
Lloh2:
	adrp	x8, lCPI4_0@PAGE
Lloh3:
	ldr	d0, [x8, lCPI4_0@PAGEOFF]
	str	d0, [x19]
	cmp	w27, #0
	cset	w8, ne
	stp	w8, w21, [x19, #8]
	ldr	w27, [x28, x23]
	str	w27, [x19, #16]
	str	x26, [x19, #24]
	mov	x0, x20
	bl	_strlen
	mov	w23, #127                       ; =0x7f
	cmp	x0, #127
	csel	x21, x0, x23, lo
	add	x0, x19, #32
	mov	x1, x20
	mov	x2, x21
	bl	_memcpy
	add	x8, x19, x21
	strb	wzr, [x8, #32]
	mov	x0, x25
	bl	_strlen
	cmp	x0, #127
	csel	x21, x0, x23, lo
	add	x0, x19, #160
	mov	x1, x25
	mov	x2, x21
	bl	_memcpy
	add	x8, x19, x21
	strb	wzr, [x8, #160]
	cbz	x24, LBB4_18
; %bb.17:
	mov	x0, x24
	bl	_strlen
	mov	w8, #255                        ; =0xff
	cmp	x0, #255
	csel	x21, x0, x8, lo
	add	x0, x19, #288
	mov	x1, x24
	mov	x2, x21
	bl	_memcpy
	add	x8, x19, x21
	strb	wzr, [x8, #288]
LBB4_18:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x26, [x8]
	stp	w22, w27, [x8, #8]
	b	LBB4_13
LBB4_19:
	add	x0, sp, #8
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB4_12
; %bb.20:
	ldr	x26, [sp, #8]
	cbnz	x26, LBB4_15
; %bb.21:
	add	x0, sp, #8
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB4_12
; %bb.22:
	ldr	x26, [sp, #8]
	cbnz	x26, LBB4_15
; %bb.23:
	add	x0, sp, #8
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB4_12
; %bb.24:
	ldr	x26, [sp, #8]
	b	LBB4_15
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function audit
_audit:                                 ; @audit
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_3
; %bb.1:
	add	x8, x0, #9, lsl #12             ; =36864
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB5_3
; %bb.2:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	str	w1, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh4:
	adrp	x2, l_.str.1@PAGE
Lloh5:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
LBB5_3:
	ret
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_check                   ; -- Begin function nl_cap_check
	.p2align	2
_nl_cap_check:                          ; @nl_cap_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x2
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbz	w0, LBB6_2
LBB6_1:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB6_2:
	add	x8, x19, #9, lsl #12            ; =36864
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #12]
	bics	wzr, w20, w9
	b.ne	LBB6_6
; %bb.3:
	cbz	x19, LBB6_5
; %bb.4:
	ldr	w9, [x8, #3592]
	cmp	w9, #127
	b.le	LBB6_9
LBB6_5:
	mov	w0, #0                          ; =0x0
	b	LBB6_1
LBB6_6:
	cbz	x19, LBB6_8
; %bb.7:
	ldr	w9, [x8, #3592]
	cmp	w9, #127
	b.le	LBB6_10
LBB6_8:
	mov	w0, #4                          ; =0x4
	b	LBB6_1
LBB6_9:
	mov	w20, #0                         ; =0x0
	add	w10, w9, #1
	str	w10, [x8, #3592]
	mov	w10, #2                         ; =0x2
	b	LBB6_11
LBB6_10:
	add	w10, w9, #1
	str	w10, [x8, #3592]
	mov	w10, #4                         ; =0x4
	mov	w20, #4                         ; =0x4
LBB6_11:
	mov	w11, #36                        ; =0x24
	smaddl	x9, w9, w11, x19
	mov	w11, #35848                     ; =0x8c08
	str	w10, [x9, x11]
	ldr	w10, [x8, #3596]
	add	w10, w10, #1
	str	w10, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x10, [sp]
Lloh6:
	adrp	x2, l_.str.1@PAGE
Lloh7:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x9, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x20
	b	LBB6_1
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_live
_find_live:                             ; @find_live
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x8, x0, #9, lsl #12             ; =36864
	cbz	x0, LBB7_10
; %bb.1:
	cbz	x1, LBB7_10
; %bb.2:
	ldr	w9, [x1, #8]
	cmp	w9, #64
	b.hs	LBB7_14
; %bb.3:
	mov	w10, #544                       ; =0x220
	umaddl	x9, w9, w10, x0
	ldr	w10, [x9]
	cbz	w10, LBB7_14
; %bb.4:
	ldr	x10, [x9, #24]
	ldr	x11, [x1]
	cmp	x10, x11
	b.ne	LBB7_14
; %bb.5:
	ldr	w10, [x9, #16]
	ldr	w11, [x1, #12]
	cmp	w10, w11
	b.ne	LBB7_18
; %bb.6:
	ldr	w10, [x9, #4]
	cbz	w10, LBB7_21
; %bb.7:
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB7_9
; %bb.8:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh8:
	adrp	x2, l_.str.1@PAGE
Lloh9:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB7_9:
	mov	w0, #2                          ; =0x2
	b	LBB7_17
LBB7_10:
	cbz	x0, LBB7_13
; %bb.11:
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB7_13
; %bb.12:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh10:
	adrp	x2, l_.str.1@PAGE
Lloh11:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB7_13:
	mov	w0, #7                          ; =0x7
	b	LBB7_17
LBB7_14:
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB7_16
; %bb.15:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh12:
	adrp	x2, l_.str.1@PAGE
Lloh13:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB7_16:
	mov	w0, #1                          ; =0x1
LBB7_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB7_18:
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.le	LBB7_20
; %bb.19:
	mov	w0, #3                          ; =0x3
	b	LBB7_17
LBB7_20:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh14:
	adrp	x2, l_.str.1@PAGE
Lloh15:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	w0, #3                          ; =0x3
	b	LBB7_17
LBB7_21:
	mov	w0, #0                          ; =0x0
	str	x9, [x2]
	b	LBB7_17
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_attenuate               ; -- Begin function nl_cap_attenuate
	.p2align	2
_nl_cap_attenuate:                      ; @nl_cap_attenuate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x21, x2
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbnz	w0, LBB8_12
; %bb.1:
	add	x22, x19, #9, lsl #12           ; =36864
	ldr	x8, [sp, #8]
	ldr	w9, [x8, #12]
	tbz	w9, #8, LBB8_7
; %bb.2:
	bics	wzr, w21, w9
	b.ne	LBB8_7
; %bb.3:
	ldr	w4, [x8, #8]
	add	x1, x8, #32
	add	x2, x8, #160
	add	x5, x8, #288
	mov	x0, x19
	mov	x3, x21
	mov	x6, x20
	bl	_mint_slot
	cbz	w0, LBB8_13
; %bb.4:
	cbz	x19, LBB8_12
; %bb.5:
	ldr	w8, [x22, #3592]
	cmp	w8, #127
	b.gt	LBB8_12
; %bb.6:
	mov	x20, x0
	add	w9, w8, #1
	str	w9, [x22, #3592]
	mov	w9, #4                          ; =0x4
	b	LBB8_11
LBB8_7:
	cbz	x19, LBB8_9
; %bb.8:
	ldr	w8, [x22, #3592]
	cmp	w8, #127
	b.le	LBB8_10
LBB8_9:
	mov	w0, #4                          ; =0x4
	b	LBB8_12
LBB8_10:
	add	w9, w8, #1
	str	w9, [x22, #3592]
	mov	w9, #4                          ; =0x4
	mov	w20, #4                         ; =0x4
LBB8_11:
	mov	w10, #36                        ; =0x24
	smaddl	x8, w8, w10, x19
	mov	w10, #35848                     ; =0x8c08
	str	w9, [x8, x10]
	ldr	w9, [x22, #3596]
	add	w9, w9, #1
	str	w9, [x22, #3596]
	mov	w10, #35852                     ; =0x8c0c
	str	x9, [sp]
Lloh16:
	adrp	x2, l_.str.1@PAGE
Lloh17:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x8, x10
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x20
LBB8_12:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB8_13:
	cbz	x19, LBB8_15
; %bb.14:
	ldr	w8, [x22, #3592]
	cmp	w8, #127
	b.le	LBB8_16
LBB8_15:
	mov	w0, #0                          ; =0x0
	b	LBB8_12
LBB8_16:
	mov	w20, #0                         ; =0x0
	add	w9, w8, #1
	str	w9, [x22, #3592]
	mov	w9, #1                          ; =0x1
	b	LBB8_11
	.loh AdrpAdd	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_transfer                ; -- Begin function nl_cap_transfer
	.p2align	2
_nl_cap_transfer:                       ; @nl_cap_transfer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x2
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbnz	w0, LBB9_16
; %bb.1:
	add	x21, x19, #9, lsl #12           ; =36864
	ldr	x22, [sp, #8]
	ldr	w8, [x22, #8]
	cbz	w8, LBB9_3
; %bb.2:
	ldr	w3, [x22, #12]
	tbnz	w3, #4, LBB9_6
LBB9_3:
	cbz	x19, LBB9_5
; %bb.4:
	ldr	w8, [x21, #3592]
	cmp	w8, #127
	b.le	LBB9_10
LBB9_5:
	mov	w0, #5                          ; =0x5
	b	LBB9_16
LBB9_6:
	mov	w23, #1                         ; =0x1
	add	x1, x22, #32
	add	x2, x22, #160
	add	x5, x22, #288
	mov	x0, x19
	mov	w4, #1                          ; =0x1
	mov	x6, x20
	bl	_mint_slot
	cbz	w0, LBB9_13
; %bb.7:
	cbz	x19, LBB9_16
; %bb.8:
	ldr	w8, [x21, #3592]
	cmp	w8, #127
	b.gt	LBB9_16
; %bb.9:
	mov	x20, x0
	add	w9, w8, #1
	str	w9, [x21, #3592]
	b	LBB9_11
LBB9_10:
	add	w9, w8, #1
	str	w9, [x21, #3592]
	mov	w20, #5                         ; =0x5
LBB9_11:
	mov	w9, #4                          ; =0x4
LBB9_12:
	mov	w10, #36                        ; =0x24
	smaddl	x8, w8, w10, x19
	mov	w10, #35848                     ; =0x8c08
	str	w9, [x8, x10]
	ldr	w9, [x21, #3596]
	add	w9, w9, #1
	str	w9, [x21, #3596]
	mov	w10, #35852                     ; =0x8c0c
	str	x9, [sp]
Lloh18:
	adrp	x2, l_.str.1@PAGE
Lloh19:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x8, x10
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x20
	b	LBB9_16
LBB9_13:
	str	w23, [x22, #4]
	cbz	x19, LBB9_15
; %bb.14:
	ldr	w8, [x21, #3592]
	cmp	w8, #127
	b.le	LBB9_17
LBB9_15:
	mov	w0, #0                          ; =0x0
LBB9_16:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB9_17:
	mov	w20, #0                         ; =0x0
	add	w9, w8, #1
	str	w9, [x21, #3592]
	mov	w9, #5                          ; =0x5
	b	LBB9_12
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_revoke                  ; -- Begin function nl_cap_revoke
	.p2align	2
_nl_cap_revoke:                         ; @nl_cap_revoke
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbnz	w0, LBB10_11
; %bb.1:
	add	x8, x19, #9, lsl #12            ; =36864
	ldr	x9, [sp, #8]
	ldrh	w10, [x9, #12]
	tst	w10, #0x180
	b.eq	LBB10_5
; %bb.2:
	mov	w10, #1                         ; =0x1
	str	w10, [x9, #4]
	cbz	x19, LBB10_4
; %bb.3:
	ldr	w9, [x8, #3592]
	cmp	w9, #127
	b.le	LBB10_8
LBB10_4:
	mov	w0, #0                          ; =0x0
	b	LBB10_11
LBB10_5:
	cbz	x19, LBB10_7
; %bb.6:
	ldr	w9, [x8, #3592]
	cmp	w9, #127
	b.le	LBB10_9
LBB10_7:
	mov	w0, #4                          ; =0x4
	b	LBB10_11
LBB10_8:
	mov	w20, #0                         ; =0x0
	add	w10, w9, #1
	str	w10, [x8, #3592]
	mov	w10, #3                         ; =0x3
	b	LBB10_10
LBB10_9:
	add	w10, w9, #1
	str	w10, [x8, #3592]
	mov	w10, #4                         ; =0x4
	mov	w20, #4                         ; =0x4
LBB10_10:
	mov	w11, #36                        ; =0x24
	smaddl	x9, w9, w11, x19
	mov	w11, #35848                     ; =0x8c08
	str	w10, [x9, x11]
	ldr	w10, [x8, #3596]
	add	w10, w10, #1
	str	w10, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x10, [sp]
Lloh20:
	adrp	x2, l_.str.1@PAGE
Lloh21:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x9, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x20
LBB10_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_cap_restart
lCPI11_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_cap_restart
	.p2align	2
_nl_cap_restart:                        ; @nl_cap_restart
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_8
; %bb.1:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #40456                      ; =0x9e08
	add	x8, x0, x8
	mov	w9, #34816                      ; =0x8800
	mov	w10, #64                        ; =0x40
Lloh22:
	adrp	x11, lCPI11_0@PAGE
Lloh23:
	ldr	d0, [x11, lCPI11_0@PAGEOFF]
	mov	x11, x0
	b	LBB11_3
LBB11_2:                                ;   in Loop: Header=BB11_3 Depth=1
	add	x11, x11, #544
	subs	x10, x10, #1
	b.eq	LBB11_5
LBB11_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x11]
	cbz	w12, LBB11_2
; %bb.4:                                ;   in Loop: Header=BB11_3 Depth=1
	str	wzr, [x11, #16]
	str	xzr, [x11, #24]
	str	d0, [x11]
	b	LBB11_2
LBB11_5:
	mov	w10, #35592                     ; =0x8b08
	add	x10, x0, x10
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #224]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #32]
	ldr	w11, [x0, x9]
	stp	q0, q0, [x10]
	add	w10, w11, #1
	str	w10, [x0, x9]
	ldrsw	x9, [x8]
	cmp	w9, #127
	b.gt	LBB11_7
; %bb.6:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	mov	w11, #35848                     ; =0x8c08
	mov	w12, #6                         ; =0x6
	str	w12, [x10, x11]
	add	w9, w9, #1
	ldr	w11, [x8, #4]
	add	w11, w11, #1
	stp	w9, w11, [x8]
	mov	w8, #35852                      ; =0x8c0c
	str	x11, [sp]
Lloh24:
	adrp	x2, l_.str.1@PAGE
Lloh25:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB11_7:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB11_8:
	mov	w0, #7                          ; =0x7
	ret
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_cap_invalidate_service
lCPI12_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_cap_invalidate_service
	.p2align	2
_nl_cap_invalidate_service:             ; @nl_cap_invalidate_service
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x19, x0
	mov	w0, #7                          ; =0x7
	cbz	x19, LBB12_17
; %bb.1:
	mov	x20, x1
	cbz	x1, LBB12_17
; %bb.2:
	ldrb	w8, [x20]
	cbz	w8, LBB12_17
; %bb.3:
	mov	w8, #40456                      ; =0x9e08
	add	x22, x19, x8
	mov	w8, #34816                      ; =0x8800
	add	x23, x19, x8
	add	x21, x19, #160
	mov	w24, #64                        ; =0x40
Lloh26:
	adrp	x8, lCPI12_0@PAGE
Lloh27:
	ldr	d8, [x8, lCPI12_0@PAGEOFF]
	b	LBB12_5
LBB12_4:                                ;   in Loop: Header=BB12_5 Depth=1
	add	x21, x21, #544
	subs	x24, x24, #1
	b.eq	LBB12_8
LBB12_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x21, #-160]
	cbz	w8, LBB12_4
; %bb.6:                                ;   in Loop: Header=BB12_5 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_strcmp
	cbnz	w0, LBB12_4
; %bb.7:                                ;   in Loop: Header=BB12_5 Depth=1
	stur	wzr, [x21, #-144]
	stur	xzr, [x21, #-136]
	stur	d8, [x21, #-160]
	b	LBB12_4
LBB12_8:
	add	x8, x23, #776
	mov	w9, #64                         ; =0x40
	mov	w10, #544                       ; =0x220
	b	LBB12_10
LBB12_9:                                ;   in Loop: Header=BB12_10 Depth=1
	add	x8, x8, #4
	subs	x9, x9, #1
	b.eq	LBB12_14
LBB12_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x8]
	cbz	w11, LBB12_9
; %bb.11:                               ;   in Loop: Header=BB12_10 Depth=1
	ldur	w11, [x8, #-256]
	cmp	w11, #63
	b.hi	LBB12_9
; %bb.12:                               ;   in Loop: Header=BB12_10 Depth=1
	umull	x11, w11, w10
	ldr	w11, [x19, x11]
	cbnz	w11, LBB12_9
; %bb.13:                               ;   in Loop: Header=BB12_10 Depth=1
	str	wzr, [x8]
	b	LBB12_9
LBB12_14:
	ldr	w8, [x23]
	add	w8, w8, #1
	str	w8, [x23]
	ldrsw	x8, [x22]
	cmp	w8, #127
	b.gt	LBB12_16
; %bb.15:
	mov	w9, #36                         ; =0x24
	smaddl	x9, w8, w9, x19
	mov	w10, #35848                     ; =0x8c08
	mov	w11, #6                         ; =0x6
	str	w11, [x9, x10]
	add	w8, w8, #1
	ldr	w10, [x22, #4]
	add	w10, w10, #1
	stp	w8, w10, [x22]
	mov	w8, #35852                      ; =0x8c0c
	str	x10, [sp]
Lloh28:
	adrp	x2, l_.str.1@PAGE
Lloh29:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x9, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB12_16:
	mov	w0, #0                          ; =0x0
LBB12_17:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_from_integer            ; -- Begin function nl_cap_from_integer
	.p2align	2
_nl_cap_from_integer:                   ; @nl_cap_from_integer
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB13_2
; %bb.1:
	stp	xzr, xzr, [x2]
LBB13_2:
	cbz	x0, LBB13_5
; %bb.3:
	add	x8, x0, #9, lsl #12             ; =36864
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB13_5
; %bb.4:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh30:
	adrp	x2, l_.str.1@PAGE
Lloh31:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
LBB13_5:
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_from_pointer            ; -- Begin function nl_cap_from_pointer
	.p2align	2
_nl_cap_from_pointer:                   ; @nl_cap_from_pointer
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB14_2
; %bb.1:
	stp	xzr, xzr, [x2]
LBB14_2:
	cbz	x0, LBB14_5
; %bb.3:
	add	x8, x0, #9, lsl #12             ; =36864
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB14_5
; %bb.4:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh32:
	adrp	x2, l_.str.1@PAGE
Lloh33:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
LBB14_5:
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_resource_own            ; -- Begin function nl_cap_resource_own
	.p2align	2
_nl_cap_resource_own:                   ; @nl_cap_resource_own
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x6, x4
	mov	x19, x0
	add	x20, x0, #9, lsl #12            ; =36864
	orr	w3, w3, #0x10
	mov	w4, #1                          ; =0x1
	mov	x5, #0                          ; =0x0
	bl	_mint_slot
	cbz	w0, LBB15_4
; %bb.1:
	cbz	x19, LBB15_8
; %bb.2:
	ldr	w8, [x20, #3592]
	cmp	w8, #127
	b.gt	LBB15_8
; %bb.3:
	mov	x21, x0
	add	w9, w8, #1
	str	w9, [x20, #3592]
	mov	w9, #4                          ; =0x4
	b	LBB15_7
LBB15_4:
	cbz	x19, LBB15_8
; %bb.5:
	ldr	w8, [x20, #3592]
	cmp	w8, #127
	b.gt	LBB15_8
; %bb.6:
	mov	x21, x0
	mov	w9, #0                          ; =0x0
	add	w10, w8, #1
	str	w10, [x20, #3592]
LBB15_7:
	mov	w10, #36                        ; =0x24
	smaddl	x8, w8, w10, x19
	mov	w10, #35848                     ; =0x8c08
	str	w9, [x8, x10]
	ldr	w9, [x20, #3596]
	add	w9, w9, #1
	str	w9, [x20, #3596]
	mov	w10, #35852                     ; =0x8c0c
	str	x9, [sp]
Lloh34:
	adrp	x2, l_.str.1@PAGE
Lloh35:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x8, x10
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x21
LBB15_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_resource_consume        ; -- Begin function nl_cap_resource_consume
	.p2align	2
_nl_cap_resource_consume:               ; @nl_cap_resource_consume
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbz	w0, LBB16_2
LBB16_1:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB16_2:
	ldr	x8, [sp, #8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #4]
	cbz	x19, LBB16_1
; %bb.3:
	add	x8, x19, #9, lsl #12            ; =36864
	ldrsw	x9, [x8, #3592]
	cmp	w9, #127
	b.gt	LBB16_1
; %bb.4:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x19
	add	w9, w9, #1
	str	w9, [x8, #3592]
	mov	w9, #35848                      ; =0x8c08
	mov	w11, #3                         ; =0x3
	str	w11, [x10, x9]
	ldr	w9, [x8, #3596]
	add	w9, w9, #1
	str	w9, [x8, #3596]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh36:
	adrp	x2, l_.str.1@PAGE
Lloh37:
	add	x2, x2, l_.str.1@PAGEOFF
	mov	x19, x0
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x19
	b	LBB16_1
	.loh AdrpAdd	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_forth_bind              ; -- Begin function nl_cap_forth_bind
	.p2align	2
_nl_cap_forth_bind:                     ; @nl_cap_forth_bind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	str	xzr, [sp, #16]
	add	x2, sp, #24
	bl	_find_live
	cbnz	w0, LBB17_40
; %bb.1:
	cbz	x20, LBB17_5
; %bb.2:
	mov	x23, #0                         ; =0x0
	mov	w8, #40456                      ; =0x9e08
	add	x22, x19, x8
	mov	w8, #35592                      ; =0x8b08
	add	x25, x19, x8
	mov	x24, x25
LBB17_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24]
	cbz	w8, LBB17_6
; %bb.4:                                ;   in Loop: Header=BB17_3 Depth=1
	add	x24, x24, #4
	add	x23, x23, #8
	cmp	x23, #512
	b.ne	LBB17_3
	b	LBB17_7
LBB17_5:
	mov	w0, #7                          ; =0x7
	b	LBB17_40
LBB17_6:
	cmp	x23, #512
	b.ne	LBB17_8
LBB17_7:
	mov	w0, #6                          ; =0x6
	b	LBB17_40
LBB17_8:
	add	x0, sp, #16
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB17_37
; %bb.9:
	mov	w8, #34824                      ; =0x8808
	add	x26, x19, x8
	ldr	x8, [sp, #16]
	cmp	x8, #16, lsl #12                ; =65536
	b.lo	LBB17_15
; %bb.10:
	mov	x10, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB17_12
LBB17_11:                               ;   in Loop: Header=BB17_12 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.eq	LBB17_14
LBB17_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x25, x10, lsl #2]
	cbz	w11, LBB17_11
; %bb.13:                               ;   in Loop: Header=BB17_12 Depth=1
	ldr	x11, [x26, x10, lsl #3]
	cmp	x11, x8
	cset	w11, ne
	and	w9, w11, w9
	b	LBB17_11
LBB17_14:
	tbnz	w9, #0, LBB17_36
LBB17_15:
	add	x0, sp, #16
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB17_37
; %bb.16:
	ldr	x8, [sp, #16]
	cmp	x8, #16, lsl #12                ; =65536
	b.lo	LBB17_22
; %bb.17:
	mov	x10, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB17_19
LBB17_18:                               ;   in Loop: Header=BB17_19 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.eq	LBB17_21
LBB17_19:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x25, x10, lsl #2]
	cbz	w11, LBB17_18
; %bb.20:                               ;   in Loop: Header=BB17_19 Depth=1
	ldr	x11, [x26, x10, lsl #3]
	cmp	x11, x8
	cset	w11, ne
	and	w9, w11, w9
	b	LBB17_18
LBB17_21:
	tbnz	w9, #0, LBB17_36
LBB17_22:
	add	x0, sp, #16
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB17_37
; %bb.23:
	ldr	x8, [sp, #16]
	cmp	x8, #16, lsl #12                ; =65536
	b.lo	LBB17_29
; %bb.24:
	mov	x10, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB17_26
LBB17_25:                               ;   in Loop: Header=BB17_26 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.eq	LBB17_28
LBB17_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x25, x10, lsl #2]
	cbz	w11, LBB17_25
; %bb.27:                               ;   in Loop: Header=BB17_26 Depth=1
	ldr	x11, [x26, x10, lsl #3]
	cmp	x11, x8
	cset	w11, ne
	and	w9, w11, w9
	b	LBB17_25
LBB17_28:
	tbnz	w9, #0, LBB17_36
LBB17_29:
	add	x0, sp, #16
	mov	w1, #8                          ; =0x8
	bl	_getentropy
	cbnz	w0, LBB17_37
; %bb.30:
	ldr	x8, [sp, #16]
	cmp	x8, #16, lsl #12                ; =65536
	b.lo	LBB17_37
; %bb.31:
	mov	x10, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB17_33
LBB17_32:                               ;   in Loop: Header=BB17_33 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.eq	LBB17_35
LBB17_33:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x25, x10, lsl #2]
	cbz	w11, LBB17_32
; %bb.34:                               ;   in Loop: Header=BB17_33 Depth=1
	ldr	x11, [x26, x10, lsl #3]
	cmp	x11, x8
	cset	w11, ne
	and	w9, w11, w9
	b	LBB17_32
LBB17_35:
	tbz	w9, #0, LBB17_37
LBB17_36:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x24]
	str	x8, [x26, x23]
	ldr	w9, [x21, #8]
	stur	w9, [x24, #-256]
	str	x8, [x20]
	b	LBB17_40
LBB17_37:
	ldrsw	x8, [x22]
	cmp	w8, #127
	b.gt	LBB17_39
; %bb.38:
	mov	w9, #36                         ; =0x24
	smaddl	x9, w8, w9, x19
	mov	w10, #35848                     ; =0x8c08
	mov	w11, #4                         ; =0x4
	str	w11, [x9, x10]
	add	w8, w8, #1
	ldr	w10, [x22, #4]
	add	w10, w10, #1
	stp	w8, w10, [x22]
	mov	w8, #35852                      ; =0x8c0c
	str	x10, [sp]
Lloh38:
	adrp	x2, l_.str.1@PAGE
Lloh39:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x9, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB17_39:
	mov	w0, #9                          ; =0x9
LBB17_40:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpAdd	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_forth_lookup            ; -- Begin function nl_cap_forth_lookup
	.p2align	2
_nl_cap_forth_lookup:                   ; @nl_cap_forth_lookup
	.cfi_startproc
; %bb.0:
	mov	w8, #7                          ; =0x7
	cbz	x0, LBB18_15
; %bb.1:
	cbz	x2, LBB18_15
; %bb.2:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, #0                          ; =0x0
	mov	w8, #40456                      ; =0x9e08
	add	x8, x0, x8
	mov	w10, #35592                     ; =0x8b08
	add	x10, x0, x10
	mov	w11, #34824                     ; =0x8808
	add	x11, x0, x11
	b	LBB18_4
LBB18_3:                                ;   in Loop: Header=BB18_4 Depth=1
	add	x10, x10, #4
	add	x9, x9, #8
	cmp	x9, #512
	b.eq	LBB18_11
LBB18_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x10]
	cbz	w12, LBB18_3
; %bb.5:                                ;   in Loop: Header=BB18_4 Depth=1
	ldr	x12, [x11, x9]
	cmp	x12, x1
	b.ne	LBB18_3
; %bb.6:
	ldur	w9, [x10, #-256]
	mov	w10, #544                       ; =0x220
	umaddl	x10, w9, w10, x0
	ldr	w11, [x10]
	cbz	w11, LBB18_8
; %bb.7:
	ldr	w11, [x10, #4]
	cbz	w11, LBB18_16
LBB18_8:
	ldrsw	x9, [x8]
	cmp	w9, #127
	b.gt	LBB18_10
; %bb.9:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	mov	w11, #35848                     ; =0x8c08
	mov	w12, #4                         ; =0x4
	str	w12, [x10, x11]
	add	w9, w9, #1
	ldr	w11, [x8, #4]
	add	w11, w11, #1
	stp	w9, w11, [x8]
	mov	w8, #35852                      ; =0x8c0c
	str	x11, [sp]
Lloh40:
	adrp	x2, l_.str.1@PAGE
Lloh41:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB18_10:
	mov	w8, #2                          ; =0x2
	b	LBB18_14
LBB18_11:
	ldrsw	x9, [x8]
	cmp	w9, #127
	b.gt	LBB18_13
; %bb.12:
	mov	w10, #36                        ; =0x24
	smaddl	x10, w9, w10, x0
	mov	w11, #35848                     ; =0x8c08
	mov	w12, #4                         ; =0x4
	str	w12, [x10, x11]
	add	w9, w9, #1
	ldr	w11, [x8, #4]
	add	w11, w11, #1
	stp	w9, w11, [x8]
	mov	w8, #35852                      ; =0x8c0c
	str	x11, [sp]
Lloh42:
	adrp	x2, l_.str.1@PAGE
Lloh43:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB18_13:
	mov	w8, #1                          ; =0x1
LBB18_14:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
LBB18_15:
	mov	x0, x8
	ret
LBB18_16:
	mov	w8, #0                          ; =0x0
	ldr	x11, [x10, #24]
	str	x11, [x2]
	ldr	w10, [x10, #16]
	stp	w9, w10, [x2, #8]
	b	LBB18_14
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_rights                  ; -- Begin function nl_cap_rights
	.p2align	2
_nl_cap_rights:                         ; @nl_cap_rights
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbz	w0, LBB19_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB19_3
LBB19_2:
	ldr	x8, [sp, #8]
	ldr	w0, [x8, #12]
LBB19_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_generation              ; -- Begin function nl_cap_generation
	.p2align	2
_nl_cap_generation:                     ; @nl_cap_generation
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbz	w0, LBB20_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB20_3
LBB20_2:
	ldr	x8, [sp, #8]
	ldr	w0, [x8, #16]
LBB20_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_type_id                 ; -- Begin function nl_cap_type_id
	.p2align	2
_nl_cap_type_id:                        ; @nl_cap_type_id
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	ldr	x8, [sp, #8]
	add	x8, x8, #32
Lloh44:
	adrp	x9, l_.str@PAGE
Lloh45:
	add	x9, x9, l_.str@PAGEOFF
	cmp	w0, #0
	csel	x0, x8, x9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_service_id              ; -- Begin function nl_cap_service_id
	.p2align	2
_nl_cap_service_id:                     ; @nl_cap_service_id
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	ldr	x8, [sp, #8]
	add	x8, x8, #160
Lloh46:
	adrp	x9, l_.str@PAGE
Lloh47:
	add	x9, x9, l_.str@PAGEOFF
	cmp	w0, #0
	csel	x0, x8, x9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_scope                   ; -- Begin function nl_cap_scope
	.p2align	2
_nl_cap_scope:                          ; @nl_cap_scope
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	ldr	x8, [sp, #8]
	add	x8, x8, #288
Lloh48:
	adrp	x9, l_.str@PAGE
Lloh49:
	add	x9, x9, l_.str@PAGEOFF
	cmp	w0, #0
	csel	x0, x8, x9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_revoked                 ; -- Begin function nl_cap_revoked
	.p2align	2
_nl_cap_revoked:                        ; @nl_cap_revoked
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB24_6
; %bb.1:
	cbz	x1, LBB24_6
; %bb.2:
	ldr	w9, [x1, #8]
	cmp	w9, #63
	b.hi	LBB24_6
; %bb.3:
	mov	w10, #544                       ; =0x220
	umaddl	x8, w9, w10, x8
	ldr	w9, [x8]
	cbz	w9, LBB24_6
; %bb.4:
	ldr	x9, [x8, #24]
	ldr	x10, [x1]
	cmp	x9, x10
	b.ne	LBB24_6
; %bb.5:
	ldr	w0, [x8, #4]
LBB24_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_transferable            ; -- Begin function nl_cap_transferable
	.p2align	2
_nl_cap_transferable:                   ; @nl_cap_transferable
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbz	w0, LBB25_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB25_3
LBB25_2:
	ldr	x8, [sp, #8]
	ldr	w0, [x8, #8]
LBB25_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_audit_count             ; -- Begin function nl_cap_audit_count
	.p2align	2
_nl_cap_audit_count:                    ; @nl_cap_audit_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB26_2
; %bb.1:
	mov	w8, #40456                      ; =0x9e08
	ldr	w0, [x0, x8]
LBB26_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_audit_kind              ; -- Begin function nl_cap_audit_kind
	.p2align	2
_nl_cap_audit_kind:                     ; @nl_cap_audit_kind
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #-1                         ; =0xffffffff
	cbz	x8, LBB27_4
; %bb.1:
	tbnz	w1, #31, LBB27_4
; %bb.2:
	mov	w9, #40456                      ; =0x9e08
	ldr	w9, [x8, x9]
	cmp	w1, w9
	b.ge	LBB27_4
; %bb.3:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	mov	w9, #35848                      ; =0x8c08
	ldr	w0, [x8, x9]
LBB27_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_audit_id                ; -- Begin function nl_cap_audit_id
	.p2align	2
_nl_cap_audit_id:                       ; @nl_cap_audit_id
	.cfi_startproc
; %bb.0:
Lloh50:
	adrp	x8, l_.str@PAGE
Lloh51:
	add	x8, x8, l_.str@PAGEOFF
	cbz	x0, LBB28_3
; %bb.1:
	tbnz	w1, #31, LBB28_3
; %bb.2:
	mov	w8, #40456                      ; =0x9e08
	ldr	w8, [x0, x8]
Lloh52:
	adrp	x9, l_.str@PAGE
Lloh53:
	add	x9, x9, l_.str@PAGEOFF
	cmp	w1, w8
	mov	w8, #36                         ; =0x24
	umaddl	x8, w1, w8, x0
	mov	w10, #35852                     ; =0x8c0c
	add	x8, x8, x10
	csel	x8, x9, x8, ge
LBB28_3:
	mov	x0, x8
	ret
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_private_mint            ; -- Begin function nl_cap_private_mint
	.p2align	2
_nl_cap_private_mint:                   ; @nl_cap_private_mint
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #7                          ; =0x7
	cbz	x1, LBB29_10
; %bb.1:
	cbz	x19, LBB29_10
; %bb.2:
	mov	x6, x4
	cbz	x4, LBB29_10
; %bb.3:
	cbz	x2, LBB29_10
; %bb.4:
	ldrb	w8, [x1]
	cbz	w8, LBB29_10
; %bb.5:
	ldrb	w8, [x2]
	cbz	w8, LBB29_10
; %bb.6:
	mov	w8, #34816                      ; =0x8800
	ldr	w8, [x19, x8]
	cmn	w8, #1
	b.eq	LBB29_9
; %bb.7:
	mov	w8, #40456                      ; =0x9e08
	add	x20, x19, x8
	ubfx	w4, w3, #4, #1
	mov	x0, x19
	mov	x5, #0                          ; =0x0
	bl	_mint_slot
	ldrsw	x8, [x20]
	cmp	w8, #127
	b.gt	LBB29_10
; %bb.8:
	mov	w9, #4                          ; =0x4
	cmp	w0, #0
	csel	w9, wzr, w9, eq
	mov	w10, #36                        ; =0x24
	smaddl	x10, w8, w10, x19
	mov	w11, #35848                     ; =0x8c08
	str	w9, [x10, x11]
	add	w8, w8, #1
	ldr	w9, [x20, #4]
	add	w9, w9, #1
	stp	w8, w9, [x20]
	mov	w8, #35852                      ; =0x8c0c
	str	x9, [sp]
Lloh54:
	adrp	x2, l_.str.1@PAGE
Lloh55:
	add	x2, x2, l_.str.1@PAGEOFF
	mov	x19, x0
	add	x0, x10, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
	mov	x0, x19
	b	LBB29_10
LBB29_9:
	mov	w0, #8                          ; =0x8
LBB29_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh54, Lloh55
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_private_transfer        ; -- Begin function nl_cap_private_transfer
	.p2align	2
_nl_cap_private_transfer:               ; @nl_cap_private_transfer
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #7                          ; =0x7
	cbz	x8, LBB30_8
; %bb.1:
	cbz	x1, LBB30_8
; %bb.2:
	cbz	x2, LBB30_8
; %bb.3:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	ldr	q0, [x1]
	str	q0, [sp, #32]
	str	xzr, [sp, #8]
	add	x1, sp, #32
	add	x2, sp, #8
	mov	x19, x8
	mov	x0, x8
	bl	_find_live
	cbnz	w0, LBB30_7
; %bb.4:
	ldr	x21, [sp, #8]
	ldr	w8, [x21, #8]
	cbz	w8, LBB30_6
; %bb.5:
	ldr	w3, [x21, #12]
	tbnz	w3, #4, LBB30_9
LBB30_6:
	mov	w0, #5                          ; =0x5
LBB30_7:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
LBB30_8:
	ret
LBB30_9:
	mov	w8, #34816                      ; =0x8800
	ldr	w8, [x19, x8]
	cmn	w8, #1
	b.eq	LBB30_16
; %bb.10:
	mov	x0, x19
	mov	w22, #1                         ; =0x1
	add	x1, x21, #32
	add	x2, x21, #160
	add	x5, x21, #288
	add	x6, sp, #16
	mov	w4, #1                          ; =0x1
	bl	_mint_slot
	cbnz	w0, LBB30_7
; %bb.11:
	mov	x9, #0                          ; =0x0
	str	w22, [x21, #4]
	ldr	w8, [sp, #40]
	mov	w10, #34824                     ; =0x8808
	add	x10, x19, x10
	b	LBB30_13
LBB30_12:                               ;   in Loop: Header=BB30_13 Depth=1
	add	x9, x9, #1
	cmp	x9, #64
	b.eq	LBB30_17
LBB30_13:                               ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9, lsl #2
	ldr	w12, [x11, #768]
	cbz	w12, LBB30_12
; %bb.14:                               ;   in Loop: Header=BB30_13 Depth=1
	ldr	w12, [x11, #512]
	cmp	w12, w8
	b.ne	LBB30_12
; %bb.15:                               ;   in Loop: Header=BB30_13 Depth=1
	str	wzr, [x11, #768]
	str	xzr, [x10, x9, lsl #3]
	str	wzr, [x11, #512]
	b	LBB30_12
LBB30_16:
	mov	w0, #8                          ; =0x8
	b	LBB30_7
LBB30_17:
	mov	w9, #544                        ; =0x220
	umaddl	x0, w8, w9, x19
	mov	w1, #544                        ; =0x220
	bl	_bzero
	mov	x0, x19
	mov	w1, #5                          ; =0x5
	bl	_audit
	mov	w0, #0                          ; =0x0
	ldr	q0, [sp, #16]
	str	q0, [x20]
	b	LBB30_7
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_cap_private_consume         ; -- Begin function nl_cap_private_consume
	.p2align	2
_nl_cap_private_consume:                ; @nl_cap_private_consume
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	bl	_find_live
	cbnz	w0, LBB31_9
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	w9, #40456                      ; =0x9e08
	add	x21, x19, x9
	mov	w9, #35592                      ; =0x8b08
	add	x10, x19, x9
	ldr	w9, [x20, #8]
	ldr	x11, [sp, #8]
	mov	w12, #1                         ; =0x1
	str	w12, [x11, #4]
	mov	w11, #34824                     ; =0x8808
	add	x11, x19, x11
	b	LBB31_3
LBB31_2:                                ;   in Loop: Header=BB31_3 Depth=1
	add	x8, x8, #8
	add	x10, x10, #4
	cmp	x8, #512
	b.eq	LBB31_6
LBB31_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x10]
	cbz	w12, LBB31_2
; %bb.4:                                ;   in Loop: Header=BB31_3 Depth=1
	ldur	w12, [x10, #-256]
	cmp	w12, w9
	b.ne	LBB31_2
; %bb.5:                                ;   in Loop: Header=BB31_3 Depth=1
	str	wzr, [x10]
	str	xzr, [x11, x8]
	stur	wzr, [x10, #-256]
	b	LBB31_2
LBB31_6:
	mov	w8, #544                        ; =0x220
	umaddl	x0, w9, w8, x19
	mov	w1, #544                        ; =0x220
	bl	_bzero
	ldrsw	x8, [x21]
	cmp	w8, #127
	b.gt	LBB31_8
; %bb.7:
	mov	w9, #36                         ; =0x24
	smaddl	x9, w8, w9, x19
	mov	w10, #35848                     ; =0x8c08
	mov	w11, #3                         ; =0x3
	str	w11, [x9, x10]
	add	w8, w8, #1
	ldr	w10, [x21, #4]
	add	w10, w10, #1
	stp	w8, w10, [x21]
	mov	w8, #35852                      ; =0x8c0c
	str	x10, [sp]
Lloh56:
	adrp	x2, l_.str.1@PAGE
Lloh57:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x0, x9, x8
	mov	w1, #32                         ; =0x20
	bl	_snprintf
LBB31_8:
	mov	w0, #0                          ; =0x0
LBB31_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh56, Lloh57
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

l_.str.1:                               ; @.str.1
	.asciz	"CAP%02u"

.subsections_via_symbols
