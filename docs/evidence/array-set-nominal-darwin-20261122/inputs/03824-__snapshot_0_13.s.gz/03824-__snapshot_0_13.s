	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_file_values_storage_bound   ; -- Begin function nl_file_values_storage_bound
	.p2align	2
_nl_file_values_storage_bound:          ; @nl_file_values_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, sp, #8
	bl	_nl_file_service_storage_bound
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB0_4
; %bb.2:
	ldr	x8, [sp, #8]
	mov	x9, #-5225                      ; =0xffffffffffffeb97
	cmp	x8, x9
	b.hi	LBB0_4
; %bb.3:
	mov	w9, #5224                       ; =0x1468
	add	x8, x8, x9
	str	x8, [x19]
	mov	w0, #1                          ; =0x1
LBB0_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB0_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_create          ; -- Begin function nl_file_values_create
	.p2align	2
_nl_file_values_create:                 ; @nl_file_values_create
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB1_3
LBB1_2:
	mov	w0, #1                          ; =0x1
	ret
LBB1_3:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	adrp	x20, _fv_identity@PAGE
	ldr	x8, [x20, _fv_identity@PAGEOFF]
	cmn	x8, #1
	b.eq	LBB1_7
; %bb.4:
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #5224                       ; =0x1468
	bl	_calloc
	cbz	x0, LBB1_8
; %bb.5:
	mov	x19, x0
	mov	x8, sp
	add	x0, x0, #8
	bl	_nl_file_service_create
	ldr	w22, [sp]
	cbz	w22, LBB1_9
; %bb.6:
	mov	x0, x19
	bl	_free
	mov	w8, #8                          ; =0x8
	mov	w9, #6                          ; =0x6
	cmp	w22, #7
	csel	w8, w9, w8, eq
	mov	w9, #5                          ; =0x5
	cmp	w22, #6
	csel	w0, w9, w8, eq
	b	LBB1_10
LBB1_7:
	mov	w0, #5                          ; =0x5
	b	LBB1_10
LBB1_8:
	mov	w0, #6                          ; =0x6
	b	LBB1_10
LBB1_9:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20, _fv_identity@PAGEOFF]
	add	x8, x8, #1
	str	x8, [x20, _fv_identity@PAGEOFF]
	str	x8, [x19]
	str	x19, [x21]
LBB1_10:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_temp            ; -- Begin function nl_file_values_temp
	.p2align	2
_nl_file_values_temp:                   ; @nl_file_values_temp
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_18
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB2_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB2_3:
	cbz	x1, LBB2_18
; %bb.4:
	ldr	x9, [x1]
	mov	w8, #1                          ; =0x1
	cbnz	x9, LBB2_19
; %bb.5:
	ldr	x9, [x1, #8]
	cbnz	x9, LBB2_19
; %bb.6:
	ldr	w9, [x1, #16]
	cbnz	w9, LBB2_19
; %bb.7:
	sub	sp, sp, #112
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, #0                         ; =0x0
	add	x20, x0, #104
	b	LBB2_9
LBB2_8:                                 ;   in Loop: Header=BB2_9 Depth=1
	add	x19, x19, #1
	add	x20, x20, #80
	cmp	x19, #64
	b.eq	LBB2_20
LBB2_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #16]
	cbnz	w8, LBB2_8
; %bb.10:                               ;   in Loop: Header=BB2_9 Depth=1
	ldr	x8, [x20]
	cmn	x8, #1
	b.eq	LBB2_8
; %bb.11:                               ;   in Loop: Header=BB2_9 Depth=1
	ldr	x8, [x20, #8]
	cmn	x8, #1
	b.eq	LBB2_8
; %bb.12:
	mov	x21, x1
	stp	xzr, xzr, [sp, #40]
	str	xzr, [sp, #56]
	mov	x22, x0
	ldr	x0, [x0, #8]
	add	x8, sp, #8
	add	x2, sp, #40
	mov	w1, #19                         ; =0x13
	bl	_nl_file_acquire_temp
	ldr	x8, [x20]
	add	x10, x8, #1
	str	x10, [x20]
	ldr	w12, [sp, #8]
	cbz	w12, LBB2_22
; %bb.13:
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #16]
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x20, #48]
	ldrb	w8, [sp, #34]
	cmp	w8, #1
	mov	x9, x21
	b.ne	LBB2_23
; %bb.14:
	mov	x11, x22
	ldr	x8, [x22, #32]
	cmn	x8, #1
	b.eq	LBB2_27
; %bb.15:
	cbz	x8, LBB2_24
; %bb.16:
	cmp	x8, #1
	b.ne	LBB2_26
; %bb.17:
	mov	w10, #72                        ; =0x48
	b	LBB2_25
LBB2_18:
	mov	w8, #1                          ; =0x1
LBB2_19:
	mov	x0, x8
	ret
LBB2_20:
	mov	w8, #5                          ; =0x5
LBB2_21:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #112
	mov	x0, x8
	ret
LBB2_22:
	mov	w8, #2                          ; =0x2
	str	w8, [x20, #16]
	ldur	q0, [sp, #40]
	stur	q0, [x20, #24]
	ldr	x8, [sp, #56]
	str	x8, [x20, #40]
	mov	x9, x21
LBB2_23:
	mov	x11, x22
	b	LBB2_27
LBB2_24:
	mov	w10, #40                        ; =0x28
LBB2_25:
	add	x13, sp, #8
	orr	x14, x13, #0x4
	add	x10, x11, x10
	str	w12, [x10]
	ldr	q0, [x14]
	stur	q0, [x10, #4]
	ldur	x12, [x14, #14]
	stur	x12, [x10, #18]
	mov	w12, #1                         ; =0x1
	strb	w12, [x10, #26]
	ldur	w12, [x13, #27]
	stur	w12, [x10, #27]
	ldurb	w12, [x13, #31]
	strb	w12, [x10, #31]
	ldr	x10, [x20]
LBB2_26:
	add	x8, x8, #1
	str	x8, [x11, #32]
LBB2_27:
	mov	w8, #0                          ; =0x0
	ldr	x11, [x11]
	stp	x11, x10, [x9]
	stp	w19, wzr, [x9, #16]
	b	LBB2_21
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_move             ; -- Begin function nl_file_value_move
	.p2align	2
_nl_file_value_move:                    ; @nl_file_value_move
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB3_19
; %bb.1:
	cbz	x2, LBB3_19
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB3_19
; %bb.3:
	cbz	x8, LBB3_19
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB3_19
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB3_19
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB3_19
; %bb.7:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB3_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB3_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB3_16
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB3_16
; %bb.11:
	ldr	x10, [x1, #8]
	cbz	x10, LBB3_16
; %bb.12:
	mov	w11, #80                        ; =0x50
	umaddl	x11, w9, w11, x8
	ldr	w12, [x11, #120]
	cbz	w12, LBB3_16
; %bb.13:
	ldur	x12, [x11, #104]
	cmp	x12, x10
	b.ne	LBB3_16
; %bb.14:
	ldurb	w12, [x11, #124]
	tbz	w12, #0, LBB3_17
; %bb.15:
	mov	w0, #4                          ; =0x4
	ret
LBB3_16:
	mov	w0, #2                          ; =0x2
	ret
LBB3_17:
	cmn	x10, #1
	b.eq	LBB3_20
; %bb.18:
	mov	w0, #0                          ; =0x0
	add	x10, x10, #1
	stur	x10, [x11, #104]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldur	x10, [x11, #104]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB3_19:
	ret
LBB3_20:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_open_view              ; -- Begin function nl_file_open_view
	.p2align	2
_nl_file_open_view:                     ; @nl_file_open_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh0:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x9, [x9]
	stur	x9, [x29, #-8]
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB4_15
; %bb.1:
	cbz	x2, LBB4_15
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB4_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	b	LBB4_15
LBB4_4:
	cbz	x1, LBB4_15
; %bb.5:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB4_14
; %bb.6:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB4_14
; %bb.7:
	ldr	x10, [x1, #8]
	cbz	x10, LBB4_14
; %bb.8:
	mov	w11, #80                        ; =0x50
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #120]
	cbz	w9, LBB4_14
; %bb.9:
	ldur	x11, [x8, #104]
	cmp	x11, x10
	b.ne	LBB4_14
; %bb.10:
	and	w10, w9, #0xfffffffe
	cmp	w10, #2
	b.ne	LBB4_17
; %bb.11:
	stur	xzr, [sp, #31]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	cmp	w9, #2
	cset	w9, eq
	b.eq	LBB4_13
; %bb.12:
	ldur	q0, [x8, #152]
	stur	q0, [sp, #7]
	ldur	q0, [x8, #168]
	stur	q0, [sp, #23]
LBB4_13:
	mov	w0, #0                          ; =0x0
	strb	w9, [x2]
	ldp	q0, q1, [sp]
	stur	q0, [x2, #1]
	stur	q1, [x2, #17]
	ldur	x8, [sp, #31]
	str	x8, [x2, #32]
	b	LBB4_15
LBB4_14:
	mov	w0, #2                          ; =0x2
LBB4_15:
	ldur	x8, [x29, #-8]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_18
; %bb.16:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB4_17:
	mov	w0, #3                          ; =0x3
	b	LBB4_15
LBB4_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_open_take_ok           ; -- Begin function nl_file_open_take_ok
	.p2align	2
_nl_file_open_take_ok:                  ; @nl_file_open_take_ok
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB5_21
; %bb.1:
	cbz	x2, LBB5_21
; %bb.2:
	sub	x9, x2, x1
	subs	x10, x1, x2
	csel	x9, x10, x9, hi
	cmp	x9, #24
	b.lo	LBB5_21
; %bb.3:
	cbz	x8, LBB5_21
; %bb.4:
	ldr	x9, [x2]
	cbnz	x9, LBB5_21
; %bb.5:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB5_21
; %bb.6:
	ldr	w9, [x2, #16]
	cbnz	w9, LBB5_21
; %bb.7:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB5_9
; %bb.8:
	mov	w0, #7                          ; =0x7
	ret
LBB5_9:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB5_17
; %bb.10:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB5_17
; %bb.11:
	ldr	x11, [x1, #8]
	cbz	x11, LBB5_17
; %bb.12:
	mov	w10, #80                        ; =0x50
	umaddl	x10, w9, w10, x8
	ldr	w12, [x10, #120]
	cbz	w12, LBB5_17
; %bb.13:
	ldur	x13, [x10, #104]
	cmp	x13, x11
	b.ne	LBB5_17
; %bb.14:
	cmp	w12, #2
	b.ne	LBB5_18
; %bb.15:
	ldurb	w12, [x10, #124]
	tbz	w12, #0, LBB5_19
; %bb.16:
	mov	w0, #4                          ; =0x4
	ret
LBB5_17:
	mov	w0, #2                          ; =0x2
	ret
LBB5_18:
	mov	w0, #3                          ; =0x3
	ret
LBB5_19:
	cmn	x11, #1
	b.eq	LBB5_22
; %bb.20:
	mov	w0, #0                          ; =0x0
	add	x11, x11, #1
	stur	x11, [x10, #104]
	mov	w11, #1                         ; =0x1
	stur	w11, [x10, #120]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	ldr	x8, [x8]
	ldur	x10, [x10, #104]
	stp	x8, x10, [x2]
	stp	w9, wzr, [x2, #16]
LBB5_21:
	ret
LBB5_22:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_open_take_error        ; -- Begin function nl_file_open_take_error
	.p2align	2
_nl_file_open_take_error:               ; @nl_file_open_take_error
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB6_12
; %bb.1:
	cbz	x2, LBB6_12
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB6_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	add	sp, sp, #32
	ret
LBB6_4:
	cbz	x1, LBB6_12
; %bb.5:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB6_13
; %bb.6:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB6_13
; %bb.7:
	ldr	x9, [x1, #8]
	cbz	x9, LBB6_13
; %bb.8:
	mov	w11, #80                        ; =0x50
	umaddl	x8, w10, w11, x8
	ldr	w10, [x8, #120]
	cbz	w10, LBB6_13
; %bb.9:
	ldur	x11, [x8, #104]
	cmp	x11, x9
	b.ne	LBB6_13
; %bb.10:
	cmp	w10, #3
	b.ne	LBB6_14
; %bb.11:
	mov	w0, #0                          ; =0x0
	ldur	q0, [x8, #152]
	ldur	q1, [x8, #168]
	ldur	x10, [x8, #112]
	movi.2d	v2, #0000000000000000
	stur	q2, [x8, #104]
	stur	q2, [x8, #120]
	stur	q2, [x8, #136]
	stur	q2, [x8, #152]
	stur	q2, [x8, #168]
	stp	x9, x10, [x8, #104]
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
	stp	q0, q1, [x2]
LBB6_12:
	add	sp, sp, #32
	ret
LBB6_13:
	mov	w0, #2                          ; =0x2
	add	sp, sp, #32
	ret
LBB6_14:
	mov	w0, #3                          ; =0x3
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_borrow           ; -- Begin function nl_file_value_borrow
	.p2align	2
_nl_file_value_borrow:                  ; @nl_file_value_borrow
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB7_2
; %bb.1:
	ldp	x9, x10, [x2]
	ldr	w11, [x2, #16]
	cmp	x9, #0
	ccmp	x10, #0, #0, eq
	ccmp	w11, #0, #0, eq
	b.eq	LBB7_3
LBB7_2:
	mov	w0, #1                          ; =0x1
	ret
LBB7_3:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB7_20
; %bb.4:
	ldr	x9, [x2, #24]
	cbnz	x9, LBB7_20
; %bb.5:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB7_7
; %bb.6:
	mov	w0, #7                          ; =0x7
	ret
LBB7_7:
	cbz	x1, LBB7_20
; %bb.8:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB7_16
; %bb.9:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB7_16
; %bb.10:
	ldr	x10, [x1, #8]
	cbz	x10, LBB7_16
; %bb.11:
	mov	w11, #80                        ; =0x50
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #120]
	cbz	w9, LBB7_16
; %bb.12:
	ldur	x11, [x8, #104]
	cmp	x11, x10
	b.ne	LBB7_16
; %bb.13:
	cmp	w9, #1
	b.ne	LBB7_17
; %bb.14:
	ldurb	w9, [x8, #124]
	tbz	w9, #0, LBB7_18
; %bb.15:
	mov	w0, #4                          ; =0x4
	ret
LBB7_16:
	mov	w0, #2                          ; =0x2
	ret
LBB7_17:
	mov	w0, #3                          ; =0x3
	ret
LBB7_18:
	ldur	x9, [x8, #112]
	cmn	x9, #1
	b.eq	LBB7_21
; %bb.19:
	mov	w0, #0                          ; =0x0
	add	x9, x9, #1
	stur	x9, [x8, #112]
	mov	w10, #1                         ; =0x1
	sturb	w10, [x8, #124]
	ldr	q0, [x1]
	ldr	x8, [x1, #16]
	str	q0, [x2]
	stp	x8, x9, [x2, #16]
LBB7_20:
	ret
LBB7_21:
	mov	w0, #5                          ; =0x5
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_live_slots      ; -- Begin function nl_file_values_live_slots
	.p2align	2
_nl_file_values_live_slots:             ; @nl_file_values_live_slots
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_3
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB8_4
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB8_3:
	mov	w0, #1                          ; =0x1
	ret
LBB8_4:
	mov	x17, x0
	mov	w0, #1                          ; =0x1
	cbz	x1, LBB8_10
; %bb.5:
	cbz	x2, LBB8_10
; %bb.6:
	sub	x8, x2, x1
	subs	x9, x1, x2
	csel	x8, x9, x8, hi
	cmp	x8, #8
	b.lo	LBB8_10
; %bb.7:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	mov	x12, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	add	x17, x17, #200
	mov	w0, #1                          ; =0x1
	mov	w3, #2                          ; =0x2
	mov	w4, #4                          ; =0x4
	mov	w5, #8                          ; =0x8
LBB8_8:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w6, [x17, #-80]
	ldr	w7, [x17]
	ldr	w19, [x17, #80]
	ldr	w20, [x17, #160]
	lsl	x21, x0, x12
	lsl	x22, x3, x12
	lsl	x23, x4, x12
	lsl	x24, x5, x12
	cmp	w6, #0
	csel	x6, xzr, x21, eq
	cmp	w7, #0
	csel	x7, xzr, x22, eq
	cmp	w19, #0
	csel	x19, xzr, x23, eq
	cmp	w20, #0
	csel	x20, xzr, x24, eq
	orr	x11, x6, x11
	orr	x14, x7, x14
	orr	x15, x19, x15
	orr	x16, x20, x16
	ldurb	w6, [x17, #-76]
	ldrb	w7, [x17, #4]
	ldrb	w19, [x17, #84]
	ldrb	w20, [x17, #164]
	cmp	w6, #0
	csel	x6, x21, xzr, ne
	cmp	w7, #0
	csel	x7, x22, xzr, ne
	cmp	w19, #0
	csel	x19, x23, xzr, ne
	cmp	w20, #0
	csel	x20, x24, xzr, ne
	orr	x8, x6, x8
	orr	x9, x7, x9
	orr	x10, x19, x10
	orr	x13, x20, x13
	add	x12, x12, #4
	add	x17, x17, #320
	cmp	x12, #64
	b.ne	LBB8_8
; %bb.9:
	mov	w0, #0                          ; =0x0
	orr	x8, x9, x8
	orr	x9, x13, x10
	orr	x8, x9, x8
	orr	x9, x14, x11
	orr	x10, x16, x15
	orr	x9, x10, x9
	str	x9, [x1]
	str	x8, [x2]
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
LBB8_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_validate         ; -- Begin function nl_file_value_validate
	.p2align	2
_nl_file_value_validate:                ; @nl_file_value_validate
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_10
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB9_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB9_3:
	cbz	x1, LBB9_10
; %bb.4:
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB9_11
; %bb.5:
	ldr	w8, [x1, #16]
	cmp	w8, #63
	b.hi	LBB9_11
; %bb.6:
	ldr	x9, [x1, #8]
	cbz	x9, LBB9_11
; %bb.7:
	mov	w10, #80                        ; =0x50
	umaddl	x10, w8, w10, x0
	ldr	w8, [x10, #120]
	cbz	w8, LBB9_11
; %bb.8:
	ldur	x10, [x10, #104]
	cmp	x10, x9
	b.ne	LBB9_11
; %bb.9:
	sub	w9, w8, #4
	cmn	w9, #2
	cset	w9, lo
	cmp	w8, #1
	cset	w8, ne
	cmp	w2, #0
	csel	w8, w9, w8, ne
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w0, w9, wzr, ne
	ret
LBB9_10:
	mov	w0, #1                          ; =0x1
	ret
LBB9_11:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_borrow_validate  ; -- Begin function nl_file_value_borrow_validate
	.p2align	2
_nl_file_value_borrow_validate:         ; @nl_file_value_borrow_validate
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB10_12
; %bb.1:
	cbz	x1, LBB10_12
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB10_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB10_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB10_13
; %bb.5:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB10_13
; %bb.6:
	ldr	x10, [x1, #8]
	cbz	x10, LBB10_13
; %bb.7:
	mov	w11, #80                        ; =0x50
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #120]
	cbz	w9, LBB10_13
; %bb.8:
	ldur	x11, [x8, #104]
	cmp	w9, #1
	ccmp	x11, x10, #0, eq
	b.ne	LBB10_13
; %bb.9:
	ldurb	w9, [x8, #124]
	cmp	w9, #1
	b.ne	LBB10_13
; %bb.10:
	ldr	x9, [x1, #24]
	mov	w0, #2                          ; =0x2
	cbz	x9, LBB10_12
; %bb.11:
	ldur	x8, [x8, #112]
	cmp	x9, x8
	csel	w0, wzr, w0, eq
LBB10_12:
	ret
LBB10_13:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_end_borrow       ; -- Begin function nl_file_value_end_borrow
	.p2align	2
_nl_file_value_end_borrow:              ; @nl_file_value_end_borrow
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB11_13
; %bb.1:
	cbz	x1, LBB11_13
; %bb.2:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB11_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	ret
LBB11_4:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB11_14
; %bb.5:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB11_14
; %bb.6:
	ldr	x10, [x1, #8]
	cbz	x10, LBB11_14
; %bb.7:
	mov	w11, #80                        ; =0x50
	umaddl	x8, w9, w11, x8
	ldr	w9, [x8, #120]
	cbz	w9, LBB11_14
; %bb.8:
	ldur	x11, [x8, #104]
	cmp	w9, #1
	ccmp	x11, x10, #0, eq
	b.ne	LBB11_14
; %bb.9:
	ldurb	w9, [x8, #124]
	cmp	w9, #1
	b.ne	LBB11_14
; %bb.10:
	ldr	x9, [x1, #24]
	cbz	x9, LBB11_14
; %bb.11:
	ldur	x10, [x8, #112]
	cmp	x9, x10
	b.ne	LBB11_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	sturb	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x1]
LBB11_13:
	ret
LBB11_14:
	mov	w0, #2                          ; =0x2
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_write_byte       ; -- Begin function nl_file_value_write_byte
	.p2align	2
_nl_file_value_write_byte:              ; @nl_file_value_write_byte
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh6:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	cbz	x3, LBB12_5
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB12_17
; %bb.2:
	cbz	x1, LBB12_17
; %bb.3:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB12_6
; %bb.4:
	mov	w0, #7                          ; =0x7
	b	LBB12_17
LBB12_5:
	mov	w0, #1                          ; =0x1
	b	LBB12_17
LBB12_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB12_16
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB12_16
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB12_16
; %bb.9:
	mov	w11, #80                        ; =0x50
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #120]
	cbz	w11, LBB12_16
; %bb.10:
	ldr	x12, [x9, #104]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB12_16
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB12_16
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB12_16
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB12_16
; %bb.14:
	cmp	x2, #256
	b.lo	LBB12_19
; %bb.15:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	str	wzr, [sp, #48]
	str	xzr, [sp, #40]
	mov	w10, #1                         ; =0x1
	b	LBB12_20
LBB12_16:
	mov	w0, #2                          ; =0x2
LBB12_17:
	ldur	x8, [x29, #-24]
Lloh9:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB12_21
; %bb.18:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB12_19:
	strb	w2, [sp, #39]
	ldr	x0, [x8, #8]
	mov	x8, sp
	add	x1, x9, #24
	add	x2, sp, #39
	mov	x19, x3
	mov	w3, #1                          ; =0x1
	bl	_nl_file_write
	mov	x3, x19
	ldr	w10, [sp]
	ldur	x8, [sp, #4]
	str	x8, [sp, #40]
	ldr	w8, [sp, #12]
	str	w8, [sp, #48]
	ldp	x9, x8, [sp, #16]
LBB12_20:
	mov	w0, #0                          ; =0x0
	str	wzr, [x3]
	cmp	w10, #0
	cset	w11, eq
	strb	w11, [x3, #4]
	csel	x11, x9, xzr, eq
	sturh	wzr, [x3, #5]
	strb	wzr, [x3, #7]
	str	w10, [x3, #8]
	ldr	x10, [sp, #40]
	stur	x10, [x3, #12]
	ldr	w10, [sp, #48]
	str	w10, [x3, #20]
	stp	x9, x8, [x3, #24]
	stp	x11, xzr, [x3, #40]
	b	LBB12_17
LBB12_21:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_rewind           ; -- Begin function nl_file_value_rewind
	.p2align	2
_nl_file_value_rewind:                  ; @nl_file_value_rewind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh12:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	cbz	x2, LBB13_5
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB13_16
; %bb.2:
	cbz	x1, LBB13_16
; %bb.3:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB13_6
; %bb.4:
	mov	w0, #7                          ; =0x7
	b	LBB13_16
LBB13_5:
	mov	w0, #1                          ; =0x1
	b	LBB13_16
LBB13_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB13_15
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB13_15
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB13_15
; %bb.9:
	mov	w11, #80                        ; =0x50
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #120]
	cbz	w11, LBB13_15
; %bb.10:
	ldr	x12, [x9, #104]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB13_15
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB13_15
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB13_15
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB13_15
; %bb.14:
	ldr	x0, [x8, #8]
	mov	x8, sp
	add	x1, x9, #24
	mov	x19, x2
	bl	_nl_file_rewind
	mov	w0, #0                          ; =0x0
	strb	wzr, [sp, #38]
	strh	wzr, [sp, #36]
	ldp	q1, q0, [sp]
	stur	q0, [sp, #55]
	stur	q1, [sp, #39]
	ldur	q0, [sp, #36]
	ldur	q1, [sp, #52]
	stur	q0, [x19, #5]
	ldr	w8, [sp]
	cmp	w8, #0
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	cset	w8, eq
	strb	w8, [x19, #4]
	stur	q1, [x19, #21]
	ldur	w8, [sp, #67]
	str	w8, [x19, #36]
	stp	xzr, xzr, [x19, #40]
	b	LBB13_16
LBB13_15:
	mov	w0, #2                          ; =0x2
LBB13_16:
	ldur	x8, [x29, #-24]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB13_18
; %bb.17:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB13_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_read_byte        ; -- Begin function nl_file_value_read_byte
	.p2align	2
_nl_file_value_read_byte:               ; @nl_file_value_read_byte
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB14_5
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB14_19
; %bb.2:
	cbz	x1, LBB14_19
; %bb.3:
	ldrb	w9, [x8, #16]
	tbz	w9, #0, LBB14_6
; %bb.4:
	mov	w0, #7                          ; =0x7
	ret
LBB14_5:
	mov	w0, #1                          ; =0x1
	ret
LBB14_6:
	ldr	x9, [x1]
	ldr	x10, [x8]
	cmp	x9, x10
	b.ne	LBB14_16
; %bb.7:
	ldr	w9, [x1, #16]
	cmp	w9, #63
	b.hi	LBB14_16
; %bb.8:
	ldr	x10, [x1, #8]
	cbz	x10, LBB14_16
; %bb.9:
	mov	w11, #80                        ; =0x50
	umaddl	x9, w9, w11, x8
	ldr	w11, [x9, #120]
	cbz	w11, LBB14_16
; %bb.10:
	ldr	x12, [x9, #104]!
	cmp	w11, #1
	ccmp	x12, x10, #0, eq
	b.ne	LBB14_16
; %bb.11:
	ldrb	w10, [x9, #20]
	cmp	w10, #1
	b.ne	LBB14_16
; %bb.12:
	ldr	x10, [x1, #24]
	cbz	x10, LBB14_16
; %bb.13:
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.ne	LBB14_16
; %bb.14:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x2
	sturb	wzr, [x29, #-17]
	ldr	x0, [x8, #8]
	add	x20, sp, #8
	add	x8, sp, #8
	add	x1, x9, #24
	sub	x2, x29, #17
	mov	w3, #1                          ; =0x1
	bl	_nl_file_read
	ldr	w9, [sp, #8]
	orr	x8, x20, #0x4
	cmp	w9, #0
	cset	w10, eq
	cbz	w9, LBB14_17
; %bb.15:
	mov	x11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	b	LBB14_18
LBB14_16:
	mov	w0, #2                          ; =0x2
	ret
LBB14_17:
	ldr	x11, [sp, #24]
	ldurb	w12, [x29, #-17]
	cmp	x11, #0
	csel	x11, xzr, x12, eq
	ldrb	w12, [sp, #32]
LBB14_18:
	mov	w0, #0                          ; =0x0
	mov	w13, #2                         ; =0x2
	str	w13, [x19]
	strb	w10, [x19, #4]
	sturh	wzr, [x19, #5]
	strb	wzr, [x19, #7]
	str	w9, [x19, #8]
	ldr	q0, [x8]
	stur	q0, [x19, #12]
	ldur	q0, [x8, #12]
	stur	q0, [x19, #24]
	str	x11, [x19, #40]
	strb	w12, [x19, #48]
	stur	wzr, [x19, #49]
	str	wzr, [x19, #52]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
LBB14_19:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_close            ; -- Begin function nl_file_value_close
	.p2align	2
_nl_file_value_close:                   ; @nl_file_value_close
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x9, x0
Lloh18:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh19:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh20:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #1                          ; =0x1
	cbz	x9, LBB15_14
; %bb.1:
	cbz	x2, LBB15_14
; %bb.2:
	ldrb	w8, [x9, #16]
	tbz	w8, #0, LBB15_4
; %bb.3:
	mov	w0, #7                          ; =0x7
	b	LBB15_14
LBB15_4:
	cbz	x1, LBB15_14
; %bb.5:
	ldr	x8, [x1]
	ldr	x10, [x9]
	cmp	x8, x10
	b.ne	LBB15_13
; %bb.6:
	ldr	w10, [x1, #16]
	cmp	w10, #63
	b.hi	LBB15_13
; %bb.7:
	ldr	x8, [x1, #8]
	cbz	x8, LBB15_13
; %bb.8:
	mov	w11, #80                        ; =0x50
	umaddl	x11, w10, w11, x9
	ldr	w10, [x11, #120]
	cbz	w10, LBB15_13
; %bb.9:
	add	x19, x11, #104
	ldr	x11, [x19]
	cmp	x11, x8
	b.ne	LBB15_13
; %bb.10:
	cmp	w10, #1
	b.ne	LBB15_16
; %bb.11:
	ldrb	w8, [x19, #20]
	tbz	w8, #0, LBB15_17
; %bb.12:
	mov	w0, #4                          ; =0x4
	b	LBB15_14
LBB15_13:
	mov	w0, #2                          ; =0x2
LBB15_14:
	ldur	x8, [x29, #-56]
Lloh21:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh22:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh23:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB15_29
; %bb.15:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB15_16:
	mov	w0, #3                          ; =0x3
	b	LBB15_14
LBB15_17:
	ldr	x0, [x9, #8]
	mov	x20, sp
	mov	x8, sp
	mov	x21, x1
	add	x1, x19, #24
	mov	x22, x9
	mov	x23, x2
	bl	_nl_file_consume_close
	mov	x12, x22
	mov	x10, x21
	mov	x8, x23
	ldr	w9, [sp]
	orr	x11, x20, #0x4
	ldrb	w13, [sp, #26]
	cbnz	w9, LBB15_19
; %bb.18:
	tbz	w13, #0, LBB15_26
LBB15_19:
	ldr	x14, [x12, #32]
	cmn	x14, #1
	b.eq	LBB15_26
; %bb.20:
	cbz	x14, LBB15_23
; %bb.21:
	cmp	x14, #1
	b.ne	LBB15_25
; %bb.22:
	mov	w15, #72                        ; =0x48
	b	LBB15_24
LBB15_23:
	mov	w15, #40                        ; =0x28
LBB15_24:
	add	x15, x12, x15
	str	w9, [x15]
	ldr	q0, [x11]
	stur	q0, [x15, #4]
	ldur	x16, [x11, #14]
	stur	x16, [x15, #18]
	strb	w13, [x15, #26]
	ldur	w13, [x20, #27]
	stur	w13, [x15, #27]
	ldurb	w13, [x20, #31]
	strb	w13, [x15, #31]
LBB15_25:
	add	x13, x14, #1
	str	x13, [x12, #32]
LBB15_26:
	ldrb	w12, [sp, #25]
	tbz	w12, #0, LBB15_28
; %bb.27:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #16]
	stp	q0, q0, [x19, #48]
	ldr	q0, [x11]
	str	q0, [sp, #32]
	ldur	q0, [x11, #12]
	stur	q0, [sp, #44]
	stp	xzr, xzr, [x10]
	str	xzr, [x10, #16]
	cmp	w9, #0
	cset	w10, eq
	mov	w11, #3                         ; =0x3
	str	w11, [x8]
	strb	w10, [x8, #4]
	sturh	wzr, [x8, #5]
	strb	wzr, [x8, #7]
	str	w9, [x8, #8]
	ldr	q0, [sp, #32]
	stur	q0, [x8, #12]
	ldur	q0, [sp, #44]
	stur	q0, [x8, #24]
	stp	xzr, xzr, [x8, #40]
	b	LBB15_14
LBB15_28:
	mov	w0, #8                          ; =0x8
	b	LBB15_14
LBB15_29:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh18, Lloh19, Lloh20
	.loh AdrpLdrGotLdr	Lloh21, Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fv_close_slot
_fv_close_slot:                         ; @fv_close_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	ldr	x0, [x0, #8]
	mov	x22, sp
	mov	x8, sp
	add	x1, x1, #24
	bl	_nl_file_consume_close
	ldr	w10, [sp]
	ldrb	w8, [sp, #26]
	cbnz	w10, LBB16_2
; %bb.1:
	tbz	w8, #0, LBB16_9
LBB16_2:
	ldr	x9, [x21, #32]
	cmn	x9, #1
	b.eq	LBB16_9
; %bb.3:
	cbz	x9, LBB16_6
; %bb.4:
	cmp	x9, #1
	b.ne	LBB16_8
; %bb.5:
	mov	w11, #72                        ; =0x48
	b	LBB16_7
LBB16_6:
	mov	w11, #40                        ; =0x28
LBB16_7:
	orr	x12, x22, #0x4
	add	x11, x21, x11
	str	w10, [x11]
	ldr	q0, [x12]
	stur	q0, [x11, #4]
	ldur	x10, [x12, #14]
	stur	x10, [x11, #18]
	strb	w8, [x11, #26]
	ldur	w8, [x22, #27]
	stur	w8, [x11, #27]
	ldurb	w8, [x22, #31]
	strb	w8, [x11, #31]
LBB16_8:
	add	x8, x9, #1
	str	x8, [x21, #32]
LBB16_9:
	ldrb	w8, [sp, #25]
	cmp	w8, #1
	b.ne	LBB16_11
; %bb.10:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20, #16]
	stp	q0, q0, [x20, #48]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	b	LBB16_12
LBB16_11:
	mov	w0, #8                          ; =0x8
LBB16_12:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_value_drop             ; -- Begin function nl_file_value_drop
	.p2align	2
_nl_file_value_drop:                    ; @nl_file_value_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_8
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB17_3
; %bb.2:
	mov	w0, #7                          ; =0x7
	ret
LBB17_3:
	cbz	x1, LBB17_8
; %bb.4:
	ldp	x11, x9, [x1]
	ldr	w10, [x1, #16]
	cbnz	x11, LBB17_9
; %bb.5:
	cbnz	x9, LBB17_9
; %bb.6:
	cbnz	w10, LBB17_9
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB17_8:
	mov	w0, #1                          ; =0x1
	ret
LBB17_9:
	ldr	x12, [x0]
	mov	w8, #2                          ; =0x2
	cmp	x11, x12
	b.ne	LBB17_20
; %bb.10:
	cmp	w10, #63
	ccmp	x9, #0, #4, ls
	b.eq	LBB17_20
; %bb.11:
	mov	w8, #80                         ; =0x50
	umaddl	x8, w10, w8, x0
	ldr	w10, [x8, #120]
	cbz	w10, LBB17_15
; %bb.12:
	ldur	x11, [x8, #104]
	cmp	x11, x9
	b.ne	LBB17_15
; %bb.13:
	ldurb	w11, [x8, #124]
	tbz	w11, #0, LBB17_16
; %bb.14:
	mov	w0, #4                          ; =0x4
	ret
LBB17_15:
	mov	w0, #2                          ; =0x2
	ret
LBB17_16:
	cmp	w10, #3
	b.ne	LBB17_18
; %bb.17:
	ldur	x10, [x8, #112]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #104]
	stur	q0, [x8, #120]
	stur	q0, [x8, #136]
	stur	q0, [x8, #152]
	stur	q0, [x8, #168]
	stp	x9, x10, [x8, #104]
	b	LBB17_19
LBB17_18:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	add	x1, x8, #104
	mov	x2, sp
	bl	_fv_close_slot
	mov	x1, x19
	mov	x8, x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	cbnz	w0, LBB17_20
LBB17_19:
	mov	w8, #0                          ; =0x0
	stp	xzr, xzr, [x1]
	str	xzr, [x1, #16]
LBB17_20:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_report          ; -- Begin function nl_file_values_report
	.p2align	2
_nl_file_values_report:                 ; @nl_file_values_report
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB18_2
; %bb.1:
	ldur	q0, [x8, #24]
	str	q0, [x1]
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #56]
	ldur	q2, [x8, #72]
	ldur	q3, [x8, #88]
	stp	q2, q3, [x1, #48]
	stp	q0, q1, [x1, #16]
LBB18_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_finish          ; -- Begin function nl_file_values_finish
	.p2align	2
_nl_file_values_finish:                 ; @nl_file_values_finish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	cbz	x0, LBB19_4
; %bb.1:
	mov	x20, x0
	ldrb	w8, [x0, #16]
	cmp	w8, #1
	b.ne	LBB19_3
; %bb.2:
	ldur	q0, [x20, #40]
	ldur	q1, [x20, #56]
	ldur	q2, [x20, #72]
	stp	q1, q2, [x19, #32]
	ldur	q1, [x20, #88]
	str	q1, [x19, #64]
	ldur	q1, [x20, #24]
	b	LBB19_40
LBB19_3:
	cmp	w1, #9
	b.lo	LBB19_5
LBB19_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	b	LBB19_41
LBB19_5:
	mov	x22, x20
	str	w1, [x22, #24]!
	mov	x23, sp
	orr	x24, x23, #0x4
	add	x21, x22, #104
	mov	w25, #64                        ; =0x40
	movi.2d	v1, #0000000000000000
	mov	w26, #8                         ; =0x8
	b	LBB19_8
LBB19_6:                                ;   in Loop: Header=BB19_8 Depth=1
	stp	q1, q1, [x27, #16]
	stp	q1, q1, [x27, #48]
LBB19_7:                                ;   in Loop: Header=BB19_8 Depth=1
	ldur	q0, [x21, #-24]
	stp	q1, q1, [x27, #48]
	stp	q1, q1, [x27, #16]
	str	q1, [x27]
	stur	q0, [x21, #-24]
	add	x21, x21, #80
	subs	x25, x25, #1
	b.eq	LBB19_21
LBB19_8:                                ; =>This Inner Loop Header: Depth=1
	sub	x27, x21, #24
	ldur	w8, [x21, #-8]
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB19_7
; %bb.9:                                ;   in Loop: Header=BB19_8 Depth=1
	ldr	x0, [x20, #8]
	mov	x8, sp
	mov	x1, x21
	bl	_nl_file_consume_close
	ldr	w10, [sp]
	ldrb	w8, [sp, #26]
	cbnz	w10, LBB19_11
; %bb.10:                               ;   in Loop: Header=BB19_8 Depth=1
	tbz	w8, #0, LBB19_18
LBB19_11:                               ;   in Loop: Header=BB19_8 Depth=1
	ldr	x9, [x20, #32]
	cmn	x9, #1
	b.eq	LBB19_18
; %bb.12:                               ;   in Loop: Header=BB19_8 Depth=1
	cbz	x9, LBB19_15
; %bb.13:                               ;   in Loop: Header=BB19_8 Depth=1
	cmp	x9, #1
	b.ne	LBB19_17
; %bb.14:                               ;   in Loop: Header=BB19_8 Depth=1
	mov	w11, #72                        ; =0x48
	b	LBB19_16
LBB19_15:                               ;   in Loop: Header=BB19_8 Depth=1
	mov	w11, #40                        ; =0x28
LBB19_16:                               ;   in Loop: Header=BB19_8 Depth=1
	add	x11, x20, x11
	str	w10, [x11]
	ldr	q0, [x24]
	stur	q0, [x11, #4]
	ldur	x10, [x24, #14]
	stur	x10, [x11, #18]
	strb	w8, [x11, #26]
	ldur	w8, [x23, #27]
	stur	w8, [x11, #27]
	ldurb	w8, [x23, #31]
	strb	w8, [x11, #31]
LBB19_17:                               ;   in Loop: Header=BB19_8 Depth=1
	add	x8, x9, #1
	str	x8, [x20, #32]
LBB19_18:                               ;   in Loop: Header=BB19_8 Depth=1
	ldrb	w8, [sp, #25]
	cmp	w8, #1
	movi.2d	v1, #0000000000000000
	b.eq	LBB19_6
; %bb.19:                               ;   in Loop: Header=BB19_8 Depth=1
	ldr	w8, [x22]
	cbnz	w8, LBB19_7
; %bb.20:                               ;   in Loop: Header=BB19_8 Depth=1
	str	w26, [x22]
	b	LBB19_7
LBB19_21:
	ldr	x0, [x20, #8]
	mov	x8, sp
	bl	_nl_file_service_dispose
	ldr	w8, [sp]
	cbnz	w8, LBB19_23
; %bb.22:
	ldrb	w8, [sp, #26]
	tbz	w8, #0, LBB19_30
LBB19_23:
	ldr	x8, [x20, #32]
	cmn	x8, #1
	b.eq	LBB19_30
; %bb.24:
	cbz	x8, LBB19_27
; %bb.25:
	cmp	x8, #1
	b.ne	LBB19_29
; %bb.26:
	mov	w9, #72                         ; =0x48
	b	LBB19_28
LBB19_27:
	mov	w9, #40                         ; =0x28
LBB19_28:
	add	x9, x20, x9
	ldp	q0, q1, [sp]
	stp	q0, q1, [x9]
LBB19_29:
	add	x8, x8, #1
	str	x8, [x20, #32]
LBB19_30:
	ldr	x0, [x20, #8]
	mov	x8, sp
	bl	_nl_file_service_destroy
	ldr	w8, [sp]
	cbnz	w8, LBB19_32
; %bb.31:
	ldrb	w8, [sp, #26]
	tbz	w8, #0, LBB19_39
LBB19_32:
	ldr	x8, [x20, #32]
	cmn	x8, #1
	b.eq	LBB19_39
; %bb.33:
	cbz	x8, LBB19_36
; %bb.34:
	cmp	x8, #1
	b.ne	LBB19_38
; %bb.35:
	mov	w9, #72                         ; =0x48
	b	LBB19_37
LBB19_36:
	mov	w9, #40                         ; =0x28
LBB19_37:
	add	x9, x20, x9
	ldp	q0, q1, [sp]
	stp	q0, q1, [x9]
LBB19_38:
	add	x8, x8, #1
	str	x8, [x20, #32]
LBB19_39:
	str	xzr, [x20, #8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #16]
	ldp	q0, q1, [x22, #32]
	stp	q0, q1, [x19, #32]
	ldr	q0, [x22, #64]
	str	q0, [x19, #64]
	ldp	q1, q0, [x22]
LBB19_40:
	stp	q1, q0, [x19]
LBB19_41:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_values_destroy         ; -- Begin function nl_file_values_destroy
	.p2align	2
_nl_file_values_destroy:                ; @nl_file_values_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nl_file_values_finish
	cbz	x19, LBB20_3
; %bb.1:
	ldrb	w8, [x19, #16]
	cmp	w8, #1
	b.ne	LBB20_3
; %bb.2:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB20_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_fv_identity,8,3 ; @fv_identity
.subsections_via_symbols
