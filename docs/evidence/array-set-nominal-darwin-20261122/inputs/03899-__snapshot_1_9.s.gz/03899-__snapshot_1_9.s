	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_private_from_module ; -- Begin function nvm_private_from_module
	.globl	_nvm_private_from_module
	.p2align	2
_nvm_private_from_module:               ; @nvm_private_from_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	mov	x21, x0
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB0_4
; %bb.1:
	cbz	x19, LBB0_5
; %bb.2:
	str	xzr, [sp, #240]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	mov	x1, sp
	mov	x0, x21
	mov	x2, x20
	bl	_nvm_from_module_core
	cbz	w0, LBB0_6
; %bb.3:
	mov	x19, x0
	mov	x0, sp
	bl	_nvm_v2_module_free
	mov	x0, x19
	b	LBB0_7
LBB0_4:
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	b	_nvm_from_module_core
LBB0_5:
	mov	w0, #13                         ; =0xd
	b	LBB0_7
LBB0_6:
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x19, #192]
	ldr	q0, [sp, #224]
	str	q0, [x19, #224]
	ldr	x8, [sp, #240]
	str	x8, [x19, #240]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x19, #128]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x19, #160]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x19, #96]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x19, #32]
LBB0_7:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_from_module_core
_nvm_from_module_core:                  ; @nvm_from_module_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1872
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w0, #13                         ; =0xd
	cbz	x19, LBB1_37
; %bb.1:
	cbz	x1, LBB1_37
; %bb.2:
	movi.2d	v0, #0000000000000000
	str	xzr, [x1, #240]
	stp	q0, q0, [x1, #208]
	stp	q0, q0, [x1, #176]
	stp	q0, q0, [x1, #144]
	stp	q0, q0, [x1, #112]
	stp	q0, q0, [x1, #80]
	stp	q0, q0, [x1, #48]
	stp	q0, q0, [x1, #16]
	str	q0, [x1]
	mov	w8, #2                          ; =0x2
	strh	w8, [x1]
	cbz	x2, LBB1_8
; %bb.3:
	ldr	x8, [x2]
	cbz	x8, LBB1_7
; %bb.4:
	ldr	x9, [x2, #8]
	cbz	x9, LBB1_7
; %bb.5:
	ldr	w9, [x2, #16]
	cbz	w9, LBB1_7
; %bb.6:
	mov	x20, x2
	mov	x21, x1
	mov	x0, x19
	blr	x8
	cbnz	w0, LBB1_37
	b	LBB1_9
LBB1_7:
	mov	w0, #8                          ; =0x8
	b	LBB1_37
LBB1_8:
	mov	x20, x2
	mov	x21, x1
	mov	x0, x19
	bl	_nvm_service_bindings_validate
	cbnz	w0, LBB1_37
LBB1_9:
	mov	x8, x21
	mov	x21, x20
	ldr	x9, [x19, #328]
	str	x9, [x8, #216]
	ldr	w9, [x19, #336]
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	str	w9, [x8, #224]
	mov	x0, x19
	bl	_nvm_record_map_route
	mov	x22, x0
	mov	x0, x19
	bl	_nvm_metadata_valid
	cbz	w0, LBB1_36
; %bb.10:
	mov	x0, x19
	bl	_nvm_callback_contracts_valid
	cbz	w0, LBB1_36
; %bb.11:
	mov	x0, x19
	bl	_nvm_passive_valid
	cbz	w0, LBB1_36
; %bb.12:
	sub	w25, w22, #1
	cmp	w25, #3
	b.lo	LBB1_15
; %bb.13:
	mov	x0, x19
	bl	_nvm_record_array_candidate
	tbnz	w0, #0, LBB1_15
; %bb.14:
	mov	x0, x19
	bl	_nvm_retained_layouts_valid
	cbz	w0, LBB1_36
LBB1_15:
	add	x22, sp, #1328
	strb	wzr, [sp, #135]
	mov	x0, x19
	bl	_nvm_owned_array_route
	mov	x27, x0
	cmp	w25, #3
	b.lo	LBB1_18
; %bb.16:
	cbnz	w27, LBB1_18
; %bb.17:
	mov	x0, x19
	bl	_nvm_mixed_samples_candidate
	cbz	w0, LBB1_19
LBB1_18:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #480]
	stp	q0, q0, [x22, #448]
	stp	q0, q0, [x22, #416]
	stp	q0, q0, [x22, #384]
	stp	q0, q0, [x22, #352]
	stp	q0, q0, [x22, #320]
	stp	q0, q0, [x22, #288]
	stp	q0, q0, [x22, #256]
	stp	q0, q0, [x22, #224]
	stp	q0, q0, [x22, #192]
	stp	q0, q0, [x22, #160]
	stp	q0, q0, [x22, #128]
	stp	q0, q0, [x22, #96]
	stp	q0, q0, [x22, #64]
	stp	q0, q0, [x22, #32]
	stp	q0, q0, [x22]
	add	x0, sp, #400
	mov	w1, #928                        ; =0x3a0
	bl	_bzero
	add	x2, sp, #1328
	mov	w28, #1                         ; =0x1
	b	LBB1_20
LBB1_19:
	mov	x0, x19
	bl	_nvm_record_array_candidate
	mov	x28, x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #480]
	stp	q0, q0, [x22, #448]
	stp	q0, q0, [x22, #416]
	stp	q0, q0, [x22, #384]
	stp	q0, q0, [x22, #352]
	stp	q0, q0, [x22, #320]
	stp	q0, q0, [x22, #288]
	stp	q0, q0, [x22, #256]
	stp	q0, q0, [x22, #224]
	stp	q0, q0, [x22, #192]
	stp	q0, q0, [x22, #160]
	stp	q0, q0, [x22, #128]
	stp	q0, q0, [x22, #96]
	stp	q0, q0, [x22, #64]
	stp	q0, q0, [x22, #32]
	stp	q0, q0, [x22]
	add	x0, sp, #400
	mov	w1, #928                        ; =0x3a0
	bl	_bzero
	tst	w28, #0x1
	add	x8, sp, #1328
	csel	x2, x8, xzr, ne
LBB1_20:
	cmp	w27, #0
	add	x8, sp, #400
	csel	x3, x8, xzr, ne
	add	x1, sp, #135
	mov	x0, x19
	mov	x4, x21
	bl	_conversion_ownership
	cbnz	w0, LBB1_37
; %bb.21:
	ldr	x9, [x19, #296]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x9, [x8, #184]
	ldr	w9, [x19, #304]
	str	w9, [x8, #192]
	ldr	x9, [x19, #344]
	str	x9, [x8, #200]
	ldr	w9, [x19, #352]
	str	w9, [x8, #208]
	ldr	w9, [x19, #392]
	cbz	w9, LBB1_23
; %bb.22:
	ldr	w10, [x19, #248]
	cmp	w9, w10
	cset	w21, lo
	b	LBB1_24
LBB1_23:
	mov	w21, #0                         ; =0x0
LBB1_24:
	ldr	w26, [x19, #272]
	ldr	w9, [x19, #432]
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w9, [x19, #424]
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w9, [x19, #448]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w9, [x19, #384]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	ldr	w9, [x19, #368]
	cbz	w9, LBB1_28
; %bb.25:
	mov	x20, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
LBB1_26:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #360]
	ldr	w1, [x8, x20]
	mov	x0, x19
	bl	_nvm_metadata_source_key
	orr	w22, w0, w22
	add	x23, x23, #1
	ldr	w8, [x19, #368]
	add	x20, x20, #8
	cmp	x23, x8
	b.lo	LBB1_26
; %bb.27:
	eor	w9, w22, #0x1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	b	LBB1_29
LBB1_28:
	mov	w9, #1                          ; =0x1
LBB1_29:
	and	w20, w21, w9
	cmp	w20, #1
	str	w20, [sp, #4]                   ; 4-byte Folded Spill
	b.ne	LBB1_39
; %bb.30:
	ldr	w9, [x19, #248]
	cbz	w9, LBB1_40
; %bb.31:
	mov	w21, #0                         ; =0x0
LBB1_32:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x21
	bl	_nvm_metadata_source_key
	tbnz	w0, #0, LBB1_41
; %bb.33:                               ;   in Loop: Header=BB1_32 Depth=1
	add	w21, w21, #1
	ldr	w23, [x19, #248]
	cmp	w21, w23
	b.lo	LBB1_32
; %bb.34:
	cmn	w23, #1
	b.eq	LBB1_36
; %bb.35:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	w24, #1                         ; =0x1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	b	LBB1_43
LBB1_36:
	mov	w0, #13                         ; =0xd
LBB1_37:
	ldur	x8, [x29, #-104]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_227
; %bb.38:
	add	sp, sp, #1872
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_39:
	mov	w21, #-1                        ; =0xffffffff
	b	LBB1_42
LBB1_40:
	mov	w23, #0                         ; =0x0
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	mov	w24, #1                         ; =0x1
	b	LBB1_43
LBB1_41:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
LBB1_42:
	str	w21, [sp, #28]                  ; 4-byte Folded Spill
	cmn	w21, #1
	csel	w24, wzr, w20, ne
	ldr	w23, [x19, #248]
LBB1_43:
	adds	w21, w23, w24
	b.eq	LBB1_45
; %bb.44:
	mov	x0, x21
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbnz	x0, LBB1_46
	b	LBB1_84
LBB1_45:
	mov	x0, #0                          ; =0x0
LBB1_46:
	cbz	w23, LBB1_52
; %bb.47:
	ldp	x10, x9, [x19, #232]
	mov	w11, w23
	add	x12, x0, #8
	mov	w13, #5                         ; =0x5
	mov	x14, x9
	b	LBB1_50
LBB1_48:                                ;   in Loop: Header=BB1_50 Depth=1
	ldr	w15, [x14]
LBB1_49:                                ;   in Loop: Header=BB1_50 Depth=1
	stur	w15, [x12, #-4]
	ldr	x15, [x10], #8
	str	x15, [x12], #16
	add	x14, x14, #4
	subs	x11, x11, #1
	b.eq	LBB1_52
LBB1_50:                                ; =>This Inner Loop Header: Depth=1
	sturb	w13, [x12, #-8]
	cbnz	x9, LBB1_48
; %bb.51:                               ;   in Loop: Header=BB1_50 Depth=1
	mov	w15, #0                         ; =0x0
	b	LBB1_49
LBB1_52:
	tbz	w24, #0, LBB1_54
; %bb.53:
	add	x9, x0, w23, uxtw #4
	mov	w10, #5                         ; =0x5
	strb	w10, [x9]
	mov	w10, #16                        ; =0x10
	str	w10, [x9, #4]
Lloh6:
	adrp	x10, _SOURCE_FILE_KEY@PAGE
Lloh7:
	add	x10, x10, _SOURCE_FILE_KEY@PAGEOFF
	str	x10, [x9, #8]
	str	w23, [sp, #28]                  ; 4-byte Folded Spill
LBB1_54:
	str	x0, [x8, #24]
	str	w21, [x8, #32]
	cbz	w26, LBB1_57
; %bb.55:
	ldr	x9, [x19, #256]
	cmp	w26, #4
	ldp	x20, x21, [sp, #32]             ; 16-byte Folded Reload
	b.hs	LBB1_58
; %bb.56:
	mov	x10, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	b	LBB1_61
LBB1_57:
	mov	x0, #0                          ; =0x0
	ldp	x20, x21, [sp, #32]             ; 16-byte Folded Reload
	b	LBB1_63
LBB1_58:
	mov	x13, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x26, #0xfffffffc
	add	x15, x9, #52
	mov	x16, x10
LBB1_59:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w17, [x15, #-48]
	ldurh	w0, [x15, #-24]
	ldrh	w1, [x15]
	ldrh	w2, [x15, #24]
	ldurb	w3, [x15, #-31]
	ldurb	w4, [x15, #-7]
	ldrb	w5, [x15, #17]
	add	x13, x13, x17
	add	x13, x13, x3
	add	x11, x11, x0
	add	x11, x11, x4
	add	x12, x12, x1
	add	x12, x12, x5
	ldrb	w17, [x15, #41]
	add	x14, x14, x2
	add	x14, x14, x17
	add	x15, x15, #96
	subs	x16, x16, #4
	b.ne	LBB1_59
; %bb.60:
	add	x11, x11, x13
	add	x12, x14, x12
	add	x0, x12, x11
	cmp	x10, x26
	b.eq	LBB1_63
LBB1_61:
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	add	x9, x9, #21
	sub	x10, x26, x10
LBB1_62:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w11, [x9, #-17]
	ldrb	w12, [x9], #24
	add	x11, x0, x11
	add	x0, x11, x12
	subs	x10, x10, #1
	b.ne	LBB1_62
LBB1_63:
	cbz	w21, LBB1_71
; %bb.64:
	ldr	x9, [x19, #400]
	cmp	w21, #4
	b.hs	LBB1_66
; %bb.65:
	mov	x10, #0                         ; =0x0
	b	LBB1_69
LBB1_66:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x21, #0xfffffffc
	add	x13, x9, #32
	mov	x15, x10
LBB1_67:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w16, [x13, #-24]
	ldurh	w17, [x13, #-12]
	ldrh	w1, [x13]
	add	x16, x0, x16
	add	x11, x11, x17
	ldrh	w17, [x13, #12]
	add	x12, x12, x1
	add	x14, x14, x17
	add	x0, x16, #1
	add	x11, x11, #1
	add	x12, x12, #1
	add	x14, x14, #1
	add	x13, x13, #48
	subs	x15, x15, #4
	b.ne	LBB1_67
; %bb.68:
	add	x11, x11, x0
	add	x11, x12, x11
	add	x0, x14, x11
	cmp	x10, x21
	b.eq	LBB1_71
LBB1_69:
	mov	w11, #12                        ; =0xc
	umaddl	x9, w10, w11, x9
	add	x9, x9, #8
	sub	x10, x21, x10
LBB1_70:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w11, [x9], #12
	add	x11, x0, x11
	add	x0, x11, #1
	subs	x10, x10, #1
	b.ne	LBB1_70
LBB1_71:
	cbz	w20, LBB1_79
; %bb.72:
	ldr	x9, [x19, #416]
	cmp	w20, #4
	b.hs	LBB1_74
; %bb.73:
	mov	x10, #0                         ; =0x0
	b	LBB1_77
LBB1_74:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x20, #0xfffffffc
	add	x13, x9, #76
	mov	x15, x10
LBB1_75:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w16, [x13, #-64]
	ldurh	w17, [x13, #-32]
	ldrh	w1, [x13]
	add	x16, x0, x16
	add	x11, x11, x17
	ldrh	w17, [x13, #32]
	add	x12, x12, x1
	add	x14, x14, x17
	add	x0, x16, #1
	add	x11, x11, #1
	add	x12, x12, #1
	add	x14, x14, #1
	add	x13, x13, #128
	subs	x15, x15, #4
	b.ne	LBB1_75
; %bb.76:
	add	x11, x11, x0
	add	x11, x12, x11
	add	x0, x14, x11
	cmp	x10, x20
	b.eq	LBB1_79
LBB1_77:
	add	x9, x9, x10, lsl #5
	add	x9, x9, #12
	sub	x10, x20, x10
LBB1_78:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w11, [x9], #32
	add	x11, x0, x11
	add	x0, x11, #1
	subs	x10, x10, #1
	b.ne	LBB1_78
LBB1_79:
	cbz	x0, LBB1_81
; %bb.80:
	mov	w1, #1                          ; =0x1
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	mov	x23, x0
	cbnz	x0, LBB1_82
	b	LBB1_83
LBB1_81:
	mov	x23, #0                         ; =0x0
LBB1_82:
	str	x23, [x8, #232]
	str	xzr, [sp, #120]
	add	x9, x21, x26
	add	x9, x9, x20
	lsr	x9, x9, #32
	cbz	x9, LBB1_85
LBB1_83:
	mov	x0, x8
	bl	_nvm_v2_module_free
LBB1_84:
	mov	w0, #1                          ; =0x1
	b	LBB1_37
LBB1_85:
	add	w9, w21, w26
	adds	w0, w9, w20
	b.eq	LBB1_87
; %bb.86:
	mov	w1, #24                         ; =0x18
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbnz	x0, LBB1_88
	b	LBB1_83
LBB1_87:
	mov	x0, #0                          ; =0x0
LBB1_88:
	mov	x9, x8
	str	x0, [x9, #40]!
	stp	x26, x9, [sp, #64]              ; 16-byte Folded Spill
	str	wzr, [x9, #8]
	str	w25, [sp]                       ; 4-byte Folded Spill
	cbz	w26, LBB1_109
; %bb.89:
	mov	x0, x26
	mov	w1, #32                         ; =0x20
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.90:
	mov	x25, #0                         ; =0x0
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	str	x0, [x8, #72]
	str	w26, [x8, #80]
	add	x8, sp, #400
	add	x26, x8, #20
	str	w28, [sp, #60]                  ; 4-byte Folded Spill
	b	LBB1_93
LBB1_91:                                ;   in Loop: Header=BB1_93 Depth=1
	add	x8, sp, #1328
	ldrh	w8, [x8, x25, lsl #1]
	strh	w8, [x20, #28]
	ldr	x21, [sp, #64]                  ; 8-byte Folded Reload
	mov	x27, x22
LBB1_92:                                ;   in Loop: Header=BB1_93 Depth=1
	add	x25, x25, #1
	add	x26, x26, #116
	cmp	x25, x21
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	b.eq	LBB1_110
LBB1_93:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_96 Depth 2
	ldr	x8, [x19, #256]
	mov	w9, #24                         ; =0x18
	madd	x24, x25, x9, x8
	ldr	x28, [sp, #120]
	ldrh	w2, [x24, #4]
	add	x0, x23, x28
	cmp	w2, #0
	csel	x21, xzr, x0, eq
	cbz	w27, LBB1_97
; %bb.94:                               ;   in Loop: Header=BB1_93 Depth=1
	cbz	w2, LBB1_102
; %bb.95:                               ;   in Loop: Header=BB1_93 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, x26
LBB1_96:                                ;   Parent Loop BB1_93 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x9], #12
	strb	w10, [x0, x8]
	add	x8, x8, #1
	ldrh	w10, [x24, #4]
	cmp	x8, x10
	b.lo	LBB1_96
	b	LBB1_102
LBB1_97:                                ;   in Loop: Header=BB1_93 Depth=1
	cbz	w2, LBB1_102
; %bb.98:                               ;   in Loop: Header=BB1_93 Depth=1
	ldr	x8, [x19, #264]
	cbz	x8, LBB1_101
; %bb.99:                               ;   in Loop: Header=BB1_93 Depth=1
	ldr	x1, [x8, x25, lsl #3]
	cbz	x1, LBB1_101
; %bb.100:                              ;   in Loop: Header=BB1_93 Depth=1
	bl	_memcpy
	b	LBB1_102
LBB1_101:                               ;   in Loop: Header=BB1_93 Depth=1
	mov	x1, x2
	bl	_bzero
LBB1_102:                               ;   in Loop: Header=BB1_93 Depth=1
	mov	x22, x27
	ldrh	w8, [x24, #4]
	add	x20, x28, x8
	str	x20, [sp, #120]
	ldrb	w2, [x24, #21]
	cbz	x2, LBB1_104
; %bb.103:                              ;   in Loop: Header=BB1_93 Depth=1
	add	x27, x23, x20
	ldrb	w1, [x24, #20]
	mov	x0, x27
	bl	_memset
	ldrb	w9, [x24, #21]
	add	x8, x20, x9
	str	x8, [sp, #120]
	ldrh	w8, [x24, #4]
	b	LBB1_105
LBB1_104:                               ;   in Loop: Header=BB1_93 Depth=1
	mov	w9, #0                          ; =0x0
	mov	x27, #0                         ; =0x0
LBB1_105:                               ;   in Loop: Header=BB1_93 Depth=1
	strh	w8, [sp, #96]
	strh	w9, [sp, #98]
	str	wzr, [sp, #100]
	stp	x21, x27, [sp, #104]
	add	x1, sp, #96
	add	x2, sp, #120
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	mov	x3, x28
	bl	_intern_signature
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	add	x20, x8, x25, lsl #5
	str	w0, [x20, #4]
	ldr	w8, [x24]
	str	w8, [x20]
	ldr	d0, [x24, #8]
	ushll.2d	v0, v0, #0
	stur	q0, [x20, #8]
	ldr	w8, [x24, #16]
	str	w8, [x20, #24]
	strh	wzr, [sp, #94]
	ldr	w28, [sp, #60]                  ; 4-byte Folded Reload
	tbnz	w28, #0, LBB1_91
; %bb.106:                              ;   in Loop: Header=BB1_93 Depth=1
	mov	x0, x19
	bl	_nvm_service_bindings_present
	ldr	x21, [sp, #64]                  ; 8-byte Folded Reload
	mov	x27, x22
	tbnz	w0, #0, LBB1_92
; %bb.107:                              ;   in Loop: Header=BB1_93 Depth=1
	add	x8, sp, #136
	add	x2, sp, #94
	mov	x0, x19
	mov	x1, x25
	bl	_nvm_verify_function_max_stack
	ldrb	w8, [sp, #136]
	cmp	w8, #1
	b.ne	LBB1_92
; %bb.108:                              ;   in Loop: Header=BB1_93 Depth=1
	ldrh	w8, [sp, #94]
	strh	w8, [x20, #28]
	b	LBB1_92
LBB1_109:
	str	xzr, [x8, #72]
	str	w26, [x8, #80]
LBB1_110:
	ldr	x20, [sp, #40]                  ; 8-byte Folded Reload
	cbz	w20, LBB1_124
; %bb.111:
	mov	x0, x20
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.112:
	mov	x26, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	str	x0, [x8, #104]
	str	w20, [x8, #112]
	ldr	x9, [x19, #400]
	add	x28, x0, #12
	add	x8, x20, x20, lsl #1
	lsl	x20, x8, #2
	b	LBB1_115
LBB1_113:                               ;   in Loop: Header=BB1_115 Depth=1
	add	x11, x23, x10
	add	x8, x10, #1
	str	x8, [sp, #120]
	strb	w12, [x11]
	ldrh	w8, [x24, #8]
LBB1_114:                               ;   in Loop: Header=BB1_115 Depth=1
	strh	w8, [sp, #136]
	strh	w9, [sp, #138]
	str	wzr, [sp, #140]
	stp	x25, x11, [sp, #144]
	add	x1, sp, #136
	add	x2, sp, #120
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	mov	x3, x21
	bl	_intern_signature
	stur	w0, [x28, #-4]
	ldr	d0, [x24]
	stur	d0, [x28, #-12]
	ldr	x9, [x19, #400]
	add	x8, x9, x27
	ldrb	w8, [x8, #11]
	strb	w8, [x28], #16
	add	x27, x27, #12
	add	x26, x26, #8
	cmp	x20, x27
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	b.eq	LBB1_125
LBB1_115:                               ; =>This Inner Loop Header: Depth=1
	add	x24, x9, x27
	ldr	x21, [sp, #120]
	ldrh	w2, [x24, #8]
	cbz	x2, LBB1_121
; %bb.116:                              ;   in Loop: Header=BB1_115 Depth=1
	add	x25, x23, x21
	ldr	x8, [x19, #408]
	cbz	x8, LBB1_119
; %bb.117:                              ;   in Loop: Header=BB1_115 Depth=1
	ldr	x1, [x8, x26]
	cbz	x1, LBB1_119
; %bb.118:                              ;   in Loop: Header=BB1_115 Depth=1
	mov	x0, x25
	bl	_memcpy
	b	LBB1_120
LBB1_119:                               ;   in Loop: Header=BB1_115 Depth=1
	mov	x0, x25
	mov	x1, x2
	bl	_bzero
LBB1_120:                               ;   in Loop: Header=BB1_115 Depth=1
	ldrh	w8, [x24, #8]
	add	x10, x21, x8
	str	x10, [sp, #120]
	b	LBB1_122
LBB1_121:                               ;   in Loop: Header=BB1_115 Depth=1
	mov	w8, #0                          ; =0x0
	mov	x25, #0                         ; =0x0
	mov	x10, x21
LBB1_122:                               ;   in Loop: Header=BB1_115 Depth=1
	ldrb	w12, [x24, #10]
	cmp	w12, #0
	cset	w9, ne
	cbnz	w12, LBB1_113
; %bb.123:                              ;   in Loop: Header=BB1_115 Depth=1
	mov	x11, #0                         ; =0x0
	b	LBB1_114
LBB1_124:
	str	xzr, [x8, #104]
	str	w20, [x8, #112]
LBB1_125:
	ldr	x20, [sp, #32]                  ; 8-byte Folded Reload
	cbz	w20, LBB1_136
; %bb.126:
	mov	x0, x20
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #120]
	cbz	x0, LBB1_83
; %bb.127:
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	str	w20, [x8, #128]
	lsl	x22, x20, #5
	b	LBB1_130
LBB1_128:                               ;   in Loop: Header=BB1_130 Depth=1
	strh	w8, [sp, #136]
	strh	w10, [sp, #138]
	str	wzr, [sp, #140]
	stp	x26, x9, [sp, #144]
	add	x1, sp, #136
	add	x2, sp, #120
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	mov	x3, x21
	bl	_intern_signature
	str	w0, [x27, #8]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
LBB1_129:                               ;   in Loop: Header=BB1_130 Depth=1
	add	x25, x25, #32
	add	x24, x24, #16
	cmp	x22, x25
	b.eq	LBB1_137
LBB1_130:                               ; =>This Inner Loop Header: Depth=1
	ldr	x20, [x19, #416]
	add	x28, x20, x25
	ldr	x9, [x8, #120]
	add	x27, x9, x24
	ldr	w9, [x28]
	str	w9, [x27]
	ldr	w9, [x28, #4]
	str	w9, [x27, #12]
	ldrh	w9, [x28, #8]
	strh	w9, [x27, #4]
	ldrh	w10, [x28, #10]
	strh	w10, [x27, #6]
	mov	w10, #-1                        ; =0xffffffff
	str	w10, [x27, #8]
	mov	w10, #65535                     ; =0xffff
	cmp	w9, w10
	b.eq	LBB1_129
; %bb.131:                              ;   in Loop: Header=BB1_130 Depth=1
	ldr	x21, [sp, #120]
	ldrh	w2, [x28, #12]
	add	x0, x23, x21
	cmp	w2, #0
	csel	x26, xzr, x0, eq
	cbz	x2, LBB1_133
; %bb.132:                              ;   in Loop: Header=BB1_130 Depth=1
	add	x8, x20, x25
	add	x1, x8, #15
	bl	_memcpy
	ldrh	w8, [x28, #12]
	b	LBB1_134
LBB1_133:                               ;   in Loop: Header=BB1_130 Depth=1
	mov	x8, #0                          ; =0x0
LBB1_134:                               ;   in Loop: Header=BB1_130 Depth=1
	add	x11, x21, x8
	add	x12, x23, x11
	str	x11, [sp, #120]
	add	x9, x20, x25
	ldrb	w13, [x9, #14]
	cmp	w13, #0
	cset	w10, ne
	csel	x9, x12, xzr, ne
	cbz	w13, LBB1_128
; %bb.135:                              ;   in Loop: Header=BB1_130 Depth=1
	add	x8, x11, #1
	str	x8, [sp, #120]
	strb	w13, [x12]
	ldrh	w8, [x28, #12]
	b	LBB1_128
LBB1_136:
	str	xzr, [x8, #120]
	str	w20, [x8, #128]
LBB1_137:
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	cbz	w13, LBB1_141
; %bb.138:
	mov	x0, x13
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.139:
	ldr	x8, [x19, #440]
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	cmp	w13, #3
	b.hi	LBB1_142
; %bb.140:
	mov	x9, #0                          ; =0x0
	b	LBB1_152
LBB1_141:
	mov	x0, #0                          ; =0x0
	b	LBB1_155
LBB1_142:
	cmp	w13, #16
	b.hs	LBB1_144
; %bb.143:
	mov	x9, #0                          ; =0x0
	b	LBB1_149
LBB1_144:
	and	x9, x13, #0xfffffff0
	add	x12, x0, #128
	add	x10, x8, #32
	movi.2d	v1, #0xffffffffffffffff
	movi.2d	v3, #0000000000000000
	mov	x11, x9
LBB1_145:                               ; =>This Inner Loop Header: Depth=1
	ldp	q0, q4, [x10, #-32]
	mov.16b	v2, v1
	mov.16b	v5, v1
	mov.16b	v6, v1
	mov.16b	v7, v3
	ldp	q16, q20, [x10], #64
	mov.16b	v17, v1
	mov.16b	v18, v1
	sub	x13, x12, #128
	sub	x14, x12, #64
	st4.4s	{ v0, v1, v2, v3 }, [x13]
	st4.4s	{ v4, v5, v6, v7 }, [x14]
	mov.16b	v19, v3
	mov.16b	v21, v1
	mov.16b	v22, v1
	mov.16b	v23, v3
	add	x13, x12, #256
	st4.4s	{ v16, v17, v18, v19 }, [x12], #64
	st4.4s	{ v20, v21, v22, v23 }, [x12]
	mov	x12, x13
	subs	x11, x11, #16
	b.ne	LBB1_145
; %bb.146:
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x9, x10
	b.ne	LBB1_148
; %bb.147:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w10, [sp]                       ; 4-byte Folded Reload
	ldp	x9, x13, [sp, #8]               ; 16-byte Folded Reload
	b	LBB1_156
LBB1_148:
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	tst	x13, #0xc
	b.eq	LBB1_152
LBB1_149:
	mov	x12, x9
	and	x9, x13, #0xfffffffc
	sub	x10, x12, x9
	add	x11, x0, x12, lsl #4
	add	x12, x8, x12, lsl #2
	movi.2d	v1, #0xffffffffffffffff
	movi.2d	v3, #0000000000000000
LBB1_150:                               ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x12], #16
	mov.16b	v2, v1
	st4.4s	{ v0, v1, v2, v3 }, [x11], #64
	adds	x10, x10, #4
	b.ne	LBB1_150
; %bb.151:
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x9, x13
	b.eq	LBB1_154
LBB1_152:
	add	x8, x8, x9, lsl #2
	sub	x10, x13, x9
	movi.2d	v0, #0xffffffffffffffff
	add	x9, x0, x9, lsl #4
LBB1_153:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x8], #4
	str	w11, [x9]
	stur	d0, [x9, #4]
	str	wzr, [x9, #12]
	add	x9, x9, #16
	subs	x10, x10, #1
	b.ne	LBB1_153
LBB1_154:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
LBB1_155:
	ldr	w10, [sp]                       ; 4-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
LBB1_156:
	str	x0, [x8, #136]
	str	w13, [x8, #144]
	cbz	w9, LBB1_160
; %bb.157:
	mov	x0, x9
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.158:
	ldr	x8, [x19, #376]
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	cmp	w12, #4
	b.hs	LBB1_161
; %bb.159:
	mov	x9, #0                          ; =0x0
	b	LBB1_164
LBB1_160:
	str	xzr, [x8, #152]
	str	w9, [x8, #160]
	ldrb	w9, [x19, #8]
	ubfx	w9, w9, #2, #1
	b	LBB1_167
LBB1_161:
	and	x9, x12, #0xfffffffc
	add	x10, x0, #32
	mov	x11, x8
	mov	x12, x9
LBB1_162:                               ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x11]
	ldr	q2, [x11, #32]
	ext.16b	v3, v2, v2, #8
	ext.16b	v4, v1, v2, #12
	mov.s	v2[0], v1[2]
	ext.16b	v5, v0, v0, #8
	ext.16b	v6, v0, v0, #4
	mov.s	v0[1], v5[1]
	ushll.2d	v0, v0, #0
	mov.d	x13, v0[1]
	fmov	d5, x13
	mov.d	v5[1], v1[0]
	ushll.2d	v1, v2, #0
	mov.d	x13, v1[1]
	stur	q5, [x10, #-16]
	fmov	d2, x13
	mov.d	v2[1], v3[0]
	str	q2, [x10, #16]
	stp	d0, d6, [x10, #-32]
	stp	d1, d4, [x10], #64
	add	x11, x11, #48
	subs	x12, x12, #4
	b.ne	LBB1_162
; %bb.163:
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	cmp	x9, x12
	b.eq	LBB1_166
LBB1_164:
	mov	w10, #12                        ; =0xc
	umaddl	x8, w9, w10, x8
	add	x8, x8, #4
	add	x10, x0, x9, lsl #4
	add	x10, x10, #8
	sub	x9, x12, x9
LBB1_165:                               ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x8, #-4]
	stur	x11, [x10, #-8]
	ldr	d0, [x8], #12
	str	d0, [x10], #16
	subs	x9, x9, #1
	b.ne	LBB1_165
LBB1_166:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #152]
	str	w12, [x8, #160]
	mov	w9, #1                          ; =0x1
	ldr	w10, [sp]                       ; 4-byte Folded Reload
LBB1_167:
	ldr	w11, [sp, #4]                   ; 4-byte Folded Reload
	strb	w9, [x8, #228]
	ldr	w23, [x19, #368]
	cmn	w23, #1
	csel	w9, wzr, w11, ne
	tbnz	w9, #0, LBB1_83
; %bb.168:
	mov	x20, x11
	adds	w21, w23, w11
	b.eq	LBB1_182
; %bb.169:
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.170:
	cbz	w23, LBB1_179
; %bb.171:
	ldr	x8, [x19, #360]
	cmp	w23, #8
	b.lo	LBB1_176
; %bb.172:
	lsl	x9, x23, #3
	add	x10, x0, x9
	add	x9, x8, x9
	cmp	x0, x9
	ccmp	x8, x10, #2, lo
	b.lo	LBB1_176
; %bb.173:
	and	x9, x23, #0xfffffff8
	add	x10, x0, #32
	add	x11, x8, #32
	mov	x12, x9
LBB1_174:                               ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x11, #-32]
	ldp	q2, q3, [x11], #64
	stp	q0, q1, [x10, #-32]
	stp	q2, q3, [x10], #64
	subs	x12, x12, #8
	b.ne	LBB1_174
; %bb.175:
	cmp	x9, x23
	b.ne	LBB1_177
	b	LBB1_179
LBB1_176:
	mov	x9, #0                          ; =0x0
LBB1_177:
	lsl	x11, x9, #3
	add	x10, x0, x11
	add	x8, x8, x11
	sub	x9, x23, x9
LBB1_178:                               ; =>This Inner Loop Header: Depth=1
	ldr	d0, [x8], #8
	str	d0, [x10], #8
	subs	x9, x9, #1
	b.ne	LBB1_178
LBB1_179:
	tbz	w20, #0, LBB1_181
; %bb.180:
	ldr	w8, [x19, #392]
	add	x9, x0, x23, lsl #3
	ldr	w10, [sp, #28]                  ; 4-byte Folded Reload
	stp	w10, w8, [x9]
LBB1_181:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #8]
	str	w21, [x8, #16]
	ldr	w10, [sp]                       ; 4-byte Folded Reload
LBB1_182:
	ldr	w1, [x19, #320]
	cbz	w1, LBB1_185
; %bb.183:
	cmp	w10, #2
	b.hi	LBB1_190
; %bb.184:
	ldr	x0, [x19, #312]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x2, x8, #56
	mov	x3, #0                          ; =0x0
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	b	LBB1_193
LBB1_185:
	ldr	w23, [x19, #468]
	ldr	w25, [x19, #472]
	ldr	w21, [x19, #476]
	add	w24, w25, w23
	add	w22, w24, w21
	cbz	w22, LBB1_221
; %bb.186:
	mov	x0, x22
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cbz	x0, LBB1_83
; %bb.187:
	cbz	w23, LBB1_201
; %bb.188:
	cmp	w23, #4
	b.hs	LBB1_196
; %bb.189:
	mov	x8, #0                          ; =0x0
	b	LBB1_199
LBB1_190:
	mov	x0, x19
	bl	_nvm_record_array_candidate
	mov	x8, x0
	ldr	x0, [x19, #312]
	ldr	w1, [x19, #320]
	cbz	w8, LBB1_192
; %bb.191:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x2, x8, #56
	bl	_nvm_ownership_layouts_private_decode
	b	LBB1_193
LBB1_192:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x2, x8, #56
	bl	_nvm_v2_layouts_decode
LBB1_193:
	mov	x21, x0
	cbz	w0, LBB1_195
; %bb.194:
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_nvm_v2_module_free
	mov	x0, x21
	b	LBB1_37
LBB1_195:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #240]
	orr	w9, w9, #0x80
	str	w9, [x8, #240]
	b	LBB1_221
LBB1_196:
	and	x8, x23, #0xfffffffc
	add	x9, x0, #32
	mov	w10, #-1                        ; =0xffffffff
	mov	x11, x8
LBB1_197:                               ; =>This Inner Loop Header: Depth=1
	sturb	wzr, [x9, #-32]
	sturb	wzr, [x9, #-16]
	strb	wzr, [x9]
	strb	wzr, [x9, #16]
	stur	w10, [x9, #-28]
	stur	w10, [x9, #-12]
	str	w10, [x9, #4]
	str	w10, [x9, #20]
	add	x9, x9, #64
	subs	x11, x11, #4
	b.ne	LBB1_197
; %bb.198:
	cmp	x8, x23
	b.eq	LBB1_201
LBB1_199:
	add	x9, x0, x8, lsl #4
	add	x9, x9, #4
	sub	x8, x23, x8
	mov	w10, #-1                        ; =0xffffffff
LBB1_200:                               ; =>This Inner Loop Header: Depth=1
	sturb	wzr, [x9, #-4]
	str	w10, [x9], #16
	subs	x8, x8, #1
	b.ne	LBB1_200
LBB1_201:
	cbz	w25, LBB1_211
; %bb.202:
	cmp	w25, #4
	b.lo	LBB1_207
; %bb.203:
	neg	w8, w25
	cmp	w23, w8
	b.hi	LBB1_207
; %bb.204:
	and	w9, w25, #0xfffffffc
	add	w8, w23, w9
	mov	w10, #3                         ; =0x3
	mov	w11, #-1                        ; =0xffffffff
	mov	x12, x9
LBB1_205:                               ; =>This Inner Loop Header: Depth=1
	add	w13, w23, #1
	add	w14, w23, #2
	add	x15, x0, w23, uxtw #4
	add	x13, x0, w13, uxtw #4
	strb	w10, [x15]
	strb	w10, [x13]
	add	w16, w23, #3
	add	x14, x0, w14, uxtw #4
	strb	w10, [x14]
	add	x16, x0, w16, uxtw #4
	strb	w10, [x16]
	str	w11, [x15, #4]
	str	w11, [x13, #4]
	str	w11, [x14, #4]
	str	w11, [x16, #4]
	add	w23, w23, #4
	subs	w12, w12, #4
	b.ne	LBB1_205
; %bb.206:
	cmp	w25, w9
	b.ne	LBB1_208
	b	LBB1_210
LBB1_207:
	mov	x8, x23
LBB1_208:
	mov	w9, #3                          ; =0x3
	mov	w10, #-1                        ; =0xffffffff
LBB1_209:                               ; =>This Inner Loop Header: Depth=1
	add	x11, x0, w8, uxtw #4
	strb	w9, [x11]
	str	w10, [x11, #4]
	add	w8, w8, #1
	cmp	w24, w8
	b.ne	LBB1_209
LBB1_210:
	mov	x23, x24
LBB1_211:
	cbz	w21, LBB1_220
; %bb.212:
	cmp	w21, #4
	b.lo	LBB1_217
; %bb.213:
	neg	w8, w21
	cmp	w23, w8
	b.hi	LBB1_217
; %bb.214:
	and	w9, w21, #0xfffffffc
	add	w8, w23, w9
	mov	w10, #2                         ; =0x2
	mov	w11, #-1                        ; =0xffffffff
	mov	x12, x9
LBB1_215:                               ; =>This Inner Loop Header: Depth=1
	add	w13, w23, #1
	add	w14, w23, #2
	add	x15, x0, w23, uxtw #4
	add	x13, x0, w13, uxtw #4
	strb	w10, [x15]
	strb	w10, [x13]
	add	w16, w23, #3
	add	x14, x0, w14, uxtw #4
	strb	w10, [x14]
	add	x16, x0, w16, uxtw #4
	strb	w10, [x16]
	str	w11, [x15, #4]
	str	w11, [x13, #4]
	str	w11, [x14, #4]
	str	w11, [x16, #4]
	add	w23, w23, #4
	subs	w12, w12, #4
	b.ne	LBB1_215
; %bb.216:
	cmp	w21, w9
	b.ne	LBB1_218
	b	LBB1_220
LBB1_217:
	mov	w9, #0                          ; =0x0
	mov	x8, x23
LBB1_218:
	sub	w9, w21, w9
	mov	w10, #2                         ; =0x2
	mov	w11, #-1                        ; =0xffffffff
LBB1_219:                               ; =>This Inner Loop Header: Depth=1
	add	x12, x0, w8, uxtw #4
	strb	w10, [x12]
	str	w11, [x12, #4]
	add	w8, w8, #1
	subs	w9, w9, #1
	b.ne	LBB1_219
LBB1_220:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #56]
	str	w22, [x8, #64]
LBB1_221:
	ldr	w8, [x19, #8]
	tbz	w8, #1, LBB1_223
; %bb.222:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w10, [x9, #240]
	orr	w10, w10, #0x2
	str	w10, [x9, #240]
LBB1_223:
	ldr	x9, [x19, #280]
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	str	x9, [x10, #168]
	ldr	w9, [x19, #288]
	str	x9, [x10, #176]
	tbnz	w8, #0, LBB1_225
; %bb.224:
	mov	w8, #-1                         ; =0xffffffff
	b	LBB1_226
LBB1_225:
	ldr	w8, [x19, #12]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	cmp	w8, w9
	csinv	w8, w8, wzr, lo
LBB1_226:
	mov	w0, #0                          ; =0x0
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	str	w8, [x9, #4]
	b	LBB1_37
LBB1_227:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_private_to_module  ; -- Begin function nvm_private_to_module
	.globl	_nvm_private_to_module
	.p2align	2
_nvm_private_to_module:                 ; @nvm_private_to_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	mov	x21, x0
	bl	_nvm_record_map_wire_selected
	cbz	w0, LBB2_4
; %bb.1:
	cbz	x19, LBB2_5
; %bb.2:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x0, x21
	mov	x2, x20
	bl	_nvm_to_module_core
	ldr	x8, [sp, #8]
	cbz	w0, LBB2_6
; %bb.3:
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_module_free
	mov	x0, x19
	b	LBB2_7
LBB2_4:
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	b	_nvm_to_module_core
LBB2_5:
	mov	w0, #13                         ; =0xd
	b	LBB2_7
LBB2_6:
	str	x8, [x19]
LBB2_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_to_module_core
_nvm_to_module_core:                    ; @nvm_to_module_core
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #544
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
Lloh8:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh9:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh10:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	mov	w0, #13                         ; =0xd
	cbz	x20, LBB3_70
; %bb.1:
	cbz	x1, LBB3_70
; %bb.2:
	str	xzr, [x1]
	cbz	x2, LBB3_7
; %bb.3:
	ldr	x8, [x2]
	cbz	x8, LBB3_69
; %bb.4:
	ldr	x8, [x2, #8]
	cbz	x8, LBB3_69
; %bb.5:
	ldr	w9, [x2, #16]
	cbz	w9, LBB3_69
; %bb.6:
	mov	x19, x2
	mov	x21, x1
	mov	x0, x20
	blr	x8
	cbnz	w0, LBB3_70
	b	LBB3_8
LBB3_7:
	mov	x19, x2
	mov	x21, x1
	mov	x0, x20
	bl	_nvm_v2_service_bindings_validate
	cbnz	w0, LBB3_70
LBB3_8:
	mov	x25, x21
	mov	x21, x19
	bl	_nvm_module_new
	cbz	x0, LBB3_67
; %bb.9:
	mov	x19, x0
	ldr	w8, [x20, #32]
	cbz	w8, LBB3_14
; %bb.10:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
LBB3_11:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #24]
	ldrb	w9, [x8, x22]
	cmp	w9, #5
	b.ne	LBB3_68
; %bb.12:                               ;   in Loop: Header=BB3_11 Depth=1
	add	x8, x8, x22
	ldr	x1, [x8, #8]
	ldr	w2, [x8, #4]
	mov	x0, x19
	bl	_nvm_add_string
	cmp	x23, w0, uxtw
	b.ne	LBB3_116
; %bb.13:                               ;   in Loop: Header=BB3_11 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #32]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB3_11
LBB3_14:
	ldr	w8, [x20, #16]
	cbz	w8, LBB3_18
; %bb.15:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
LBB3_16:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #8]
	add	x8, x8, x22
	ldp	w1, w2, [x8]
	mov	x0, x19
	bl	_nvm_add_metadata
	tbz	w0, #0, LBB3_116
; %bb.17:                               ;   in Loop: Header=BB3_16 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #16]
	add	x22, x22, #8
	cmp	x23, x8
	b.lo	LBB3_16
LBB3_18:
	ldr	x22, [x20, #176]
	cbz	x22, LBB3_25
; %bb.19:
	lsr	x8, x22, #32
	cbnz	x8, LBB3_116
; %bb.20:
	ldr	x1, [x20, #168]
	cbz	x1, LBB3_116
; %bb.21:
	ldr	w8, [x19, #292]
	ldr	x0, [x19, #280]
	cmp	w8, w22
	b.hs	LBB3_24
; %bb.22:
	mov	x1, x22
	bl	_realloc
	cbz	x0, LBB3_117
; %bb.23:
	str	x0, [x19, #280]
	str	w22, [x19, #292]
	ldr	x1, [x20, #168]
LBB3_24:
	mov	x2, x22
	bl	_memcpy
	str	w22, [x19, #288]
LBB3_25:
	ldr	w8, [x20, #80]
	cbz	w8, LBB3_35
; %bb.26:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w24, #24                        ; =0x18
LBB3_27:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20, #72]
	add	x8, x9, x22
	ldr	w10, [x8, #12]
	cbnz	w10, LBB3_116
; %bb.28:                               ;   in Loop: Header=BB3_27 Depth=1
	ldr	w10, [x8, #20]
	cbnz	w10, LBB3_116
; %bb.29:                               ;   in Loop: Header=BB3_27 Depth=1
	ldr	x10, [x20, #40]
	ldr	w11, [x8, #4]
	umaddl	x26, w11, w24, x10
	ldrh	w10, [x26, #2]
	cmp	w10, #256
	b.hs	LBB3_116
; %bb.30:                               ;   in Loop: Header=BB3_27 Depth=1
	stp	xzr, xzr, [sp, #24]
	str	xzr, [sp, #16]
	add	x9, x9, x22
	ldr	w10, [x9]
	str	w10, [sp, #16]
	ldrh	w10, [x26]
	strh	w10, [sp, #20]
	ldur	q0, [x8, #8]
	xtn.2s	v0, v0
	str	d0, [sp, #24]
	ldr	w8, [x9, #24]
	str	w8, [sp, #32]
	ldrh	w8, [x26, #2]
	strb	w8, [sp, #37]
	cbz	w8, LBB3_32
; %bb.31:                               ;   in Loop: Header=BB3_27 Depth=1
	ldr	x8, [x26, #16]
	ldrb	w8, [x8]
LBB3_32:                                ;   in Loop: Header=BB3_27 Depth=1
	strb	w8, [sp, #36]
	add	x1, sp, #16
	mov	x0, x19
	bl	_nvm_add_function
	cmn	w0, #1
	b.eq	LBB3_117
; %bb.33:                               ;   in Loop: Header=BB3_27 Depth=1
	mov	x1, x0
	ldr	x2, [x26, #8]
	ldrh	w3, [x26]
	mov	x0, x19
	bl	_nvm_set_function_param_types
	tbz	w0, #0, LBB3_117
; %bb.34:                               ;   in Loop: Header=BB3_27 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #80]
	add	x22, x22, #32
	cmp	x23, x8
	b.lo	LBB3_27
LBB3_35:
	ldr	w8, [x20, #112]
	cbz	w8, LBB3_42
; %bb.36:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w24, #24                        ; =0x18
	mov	w26, #12                        ; =0xc
LBB3_37:                                ; =>This Inner Loop Header: Depth=1
	ldr	x27, [x20, #104]
	ldr	x9, [x20, #40]
	add	x8, x27, x22
	ldr	w10, [x8, #8]
	umaddl	x9, w10, w24, x9
	ldrh	w10, [x9, #2]
	cbz	w10, LBB3_39
; %bb.38:                               ;   in Loop: Header=BB3_37 Depth=1
	ldr	x10, [x9, #16]
	ldrb	w4, [x10]
	b	LBB3_40
LBB3_39:                                ;   in Loop: Header=BB3_37 Depth=1
	mov	w4, #0                          ; =0x0
LBB3_40:                                ;   in Loop: Header=BB3_37 Depth=1
	ldp	w1, w2, [x8]
	ldrh	w3, [x9]
	ldr	x5, [x9, #8]
	mov	x0, x19
	bl	_nvm_add_import
	cmn	w0, #1
	b.eq	LBB3_117
; %bb.41:                               ;   in Loop: Header=BB3_37 Depth=1
	add	x8, x27, x22
	ldrb	w8, [x8, #12]
	ldr	x9, [x19, #400]
	umaddl	x9, w0, w26, x9
	strb	w8, [x9, #11]
	add	x23, x23, #1
	ldr	w8, [x20, #112]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB3_37
LBB3_42:
	ldr	w8, [x20, #128]
	cbz	w8, LBB3_55
; %bb.43:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	add	x24, sp, #16
	mov	w26, #65535                     ; =0xffff
	mov	w27, #24                        ; =0x18
LBB3_44:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #120]
	add	x8, x8, x22
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	ldr	w9, [x8]
	str	w9, [sp, #16]
	ldr	w9, [x8, #12]
	str	w9, [sp, #20]
	ldrh	w9, [x8, #4]
	strh	w9, [sp, #24]
	ldrh	w10, [x8, #6]
	strh	w10, [sp, #26]
	ldr	w8, [x8, #8]
	cmp	w9, w26
	b.eq	LBB3_52
; %bb.45:                               ;   in Loop: Header=BB3_44 Depth=1
	ldr	w9, [x20, #48]
	cmp	w8, w9
	b.hs	LBB3_116
; %bb.46:                               ;   in Loop: Header=BB3_44 Depth=1
	ldr	x9, [x20, #40]
	umaddl	x8, w8, w27, x9
	ldrh	w2, [x8]
	cmp	w2, #16
	b.hi	LBB3_116
; %bb.47:                               ;   in Loop: Header=BB3_44 Depth=1
	ldrh	w9, [x8, #2]
	cmp	w9, #1
	b.hi	LBB3_116
; %bb.48:                               ;   in Loop: Header=BB3_44 Depth=1
	strh	w2, [sp, #28]
	cbz	w9, LBB3_50
; %bb.49:                               ;   in Loop: Header=BB3_44 Depth=1
	ldr	x9, [x8, #16]
	ldrb	w9, [x9]
LBB3_50:                                ;   in Loop: Header=BB3_44 Depth=1
	strb	w9, [sp, #30]
	cbz	w2, LBB3_53
; %bb.51:                               ;   in Loop: Header=BB3_44 Depth=1
	ldr	x1, [x8, #8]
	add	x0, x24, #15
	mov	w3, #17                         ; =0x11
	bl	___memcpy_chk
	b	LBB3_53
LBB3_52:                                ;   in Loop: Header=BB3_44 Depth=1
	cmn	w8, #1
	b.ne	LBB3_116
LBB3_53:                                ;   in Loop: Header=BB3_44 Depth=1
	add	x1, sp, #16
	mov	x0, x19
	bl	_nvm_add_callback_contract
	tbz	w0, #0, LBB3_116
; %bb.54:                               ;   in Loop: Header=BB3_44 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #128]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB3_44
LBB3_55:
	mov	x0, x19
	bl	_nvm_callback_contracts_valid
	cbz	w0, LBB3_116
; %bb.56:
	ldr	w8, [x20, #144]
	cbz	w8, LBB3_59
; %bb.57:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
LBB3_58:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #136]
	ldr	w1, [x8, x22]
	mov	x0, x19
	bl	_nvm_add_module_ref
	add	x23, x23, #1
	ldr	w8, [x20, #144]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB3_58
LBB3_59:
	ldr	w8, [x20, #160]
	cbz	w8, LBB3_64
; %bb.60:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
LBB3_61:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #152]
	ldr	x1, [x8, x22]
	lsr	x9, x1, #32
	cbnz	x9, LBB3_116
; %bb.62:                               ;   in Loop: Header=BB3_61 Depth=1
	add	x8, x8, x22
	ldp	w2, w3, [x8, #8]
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_add_debug_entry
	tbz	w0, #0, LBB3_116
; %bb.63:                               ;   in Loop: Header=BB3_61 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #160]
	add	x22, x22, #16
	cmp	x23, x8
	b.lo	LBB3_61
LBB3_64:
	ldr	w8, [x20, #64]
	cbz	w8, LBB3_79
; %bb.65:
	ldur	x9, [x20, #56]
	cbz	x9, LBB3_116
; %bb.66:
	mov	x10, x8
	b	LBB3_74
LBB3_67:
	mov	w0, #1                          ; =0x1
	b	LBB3_70
LBB3_68:
	mov	x0, x19
	bl	_nvm_module_free
LBB3_69:
	mov	w0, #8                          ; =0x8
LBB3_70:
	ldur	x8, [x29, #-88]
Lloh11:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh12:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh13:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_129
; %bb.71:
	add	sp, sp, #544
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB3_72:                                ;   in Loop: Header=BB3_74 Depth=1
	ldr	w11, [x19, #476]
	add	w11, w11, #1
	str	w11, [x19, #476]
LBB3_73:                                ;   in Loop: Header=BB3_74 Depth=1
	subs	x10, x10, #1
	b.eq	LBB3_79
LBB3_74:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9], #16
	cmp	w11, #3
	b.eq	LBB3_78
; %bb.75:                               ;   in Loop: Header=BB3_74 Depth=1
	cmp	w11, #2
	b.eq	LBB3_72
; %bb.76:                               ;   in Loop: Header=BB3_74 Depth=1
	cbnz	w11, LBB3_73
; %bb.77:                               ;   in Loop: Header=BB3_74 Depth=1
	ldr	w11, [x19, #468]
	add	w11, w11, #1
	str	w11, [x19, #468]
	b	LBB3_73
LBB3_78:                                ;   in Loop: Header=BB3_74 Depth=1
	ldr	w11, [x19, #472]
	add	w11, w11, #1
	str	w11, [x19, #472]
	b	LBB3_73
LBB3_79:
	add	x26, sp, #16
	ldrb	w9, [x20, #240]
	tbnz	w9, #7, LBB3_82
; %bb.80:
	add	x0, x20, #56
	bl	_nvm_layouts_have_facts
	cbz	w0, LBB3_96
; %bb.81:
	ldr	w8, [x20, #64]
LBB3_82:
	cbz	w8, LBB3_88
; %bb.83:
	mov	w8, w8
	ldur	x9, [x20, #56]
	add	x9, x9, #8
	mov	w22, #4                         ; =0x4
	mov	w10, #12                        ; =0xc
	mov	w11, #-1                        ; =0xffffffff
	b	LBB3_86
LBB3_84:                                ;   in Loop: Header=BB3_86 Depth=1
	sub	x13, x11, x22
	cmp	x12, x13
	b.hi	LBB3_116
LBB3_85:                                ;   in Loop: Header=BB3_86 Depth=1
	add	x22, x12, x22
	add	x9, x9, #16
	subs	x8, x8, #1
	b.eq	LBB3_89
LBB3_86:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w13, [x9, #-6]
	umull	x12, w13, w10
	add	x12, x12, #8
	cbz	x13, LBB3_84
; %bb.87:                               ;   in Loop: Header=BB3_86 Depth=1
	ldr	x13, [x9]
	sub	x14, x11, x22
	cmp	x13, #0
	ccmp	x12, x14, #2, ne
	b.ls	LBB3_85
	b	LBB3_116
LBB3_88:
	mov	w22, #4                         ; =0x4
LBB3_89:
	mov	x0, x22
	bl	_malloc
	cbz	x0, LBB3_117
; %bb.90:
	mov	x23, x0
	add	x0, x20, #56
	mov	x1, x23
	mov	x2, x22
	bl	_nvm_v2_layouts_encode
	mov	x24, x0
	add	x0, sp, #16
	mov	x1, x19
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	str	x23, [x26, #312]
	str	w22, [x26, #320]
	ldr	x8, [x20, #184]
	str	x8, [x26, #296]
	ldr	w8, [x20, #192]
	str	w8, [x26, #304]
	ldr	x8, [x20, #216]
	str	x8, [x26, #328]
	ldr	w8, [x20, #224]
	str	w8, [x26, #336]
	add	x0, sp, #16
	bl	_nvm_record_map_route
	cbz	w24, LBB3_93
; %bb.91:
	mov	x27, x24
	mov	x0, x23
	bl	_free
LBB3_92:
	mov	x0, x19
	bl	_nvm_module_free
	mov	x0, x27
	b	LBB3_70
LBB3_93:
	sub	w8, w0, #1
	cmp	w8, #3
	b.lo	LBB3_95
; %bb.94:
	add	x0, sp, #16
	bl	_nvm_record_array_candidate
	cbz	w0, LBB3_126
LBB3_95:
	str	x23, [x19, #312]
	str	w22, [x19, #320]
LBB3_96:
	str	wzr, [x19, #8]
	ldr	w9, [x20, #4]
	cmn	w9, #1
	cset	w8, ne
	csel	w9, w9, wzr, ne
	stp	w8, w9, [x19, #8]
	ldr	w9, [x20, #112]
	cbnz	w9, LBB3_98
; %bb.97:
	ldrb	w9, [x20, #240]
	tbz	w9, #1, LBB3_99
LBB3_98:
	orr	w8, w8, #0x2
	str	w8, [x19, #8]
LBB3_99:
	ldrb	w9, [x20, #228]
	cmp	w9, #1
	b.ne	LBB3_101
; %bb.100:
	orr	w8, w8, #0x4
	str	w8, [x19, #8]
LBB3_101:
	ldr	w22, [x20, #224]
	cbz	w22, LBB3_104
; %bb.102:
	mov	x0, x22
	bl	_malloc
	str	x0, [x19, #328]
	cbz	x0, LBB3_117
; %bb.103:
	ldr	x1, [x20, #216]
	mov	x2, x22
	bl	_memcpy
	str	w22, [x19, #336]
LBB3_104:
	ldr	w22, [x20, #208]
	cbz	w22, LBB3_108
; %bb.105:
	ldr	x23, [x20, #200]
	cbz	x23, LBB3_116
; %bb.106:
	mov	x0, x22
	bl	_malloc
	str	x0, [x19, #344]
	cbz	x0, LBB3_117
; %bb.107:
	mov	x1, x23
	mov	x2, x22
	bl	_memcpy
	str	w22, [x19, #352]
LBB3_108:
	ldr	w22, [x20, #192]
	cbz	w22, LBB3_112
; %bb.109:
	ldr	x23, [x20, #184]
	cbz	x23, LBB3_116
; %bb.110:
	mov	x0, x22
	bl	_malloc
	str	x0, [x19, #296]
	cbz	x0, LBB3_117
; %bb.111:
	mov	x1, x23
	mov	x2, x22
	bl	_memcpy
	str	w22, [x19, #304]
LBB3_112:
	strb	wzr, [sp, #15]
	mov	x0, x19
	bl	_nvm_owned_array_route
	mov	x22, x0
	mov	x0, x19
	bl	_nvm_record_array_candidate
	mov	w23, #0                         ; =0x0
	cbz	w0, LBB3_114
; %bb.113:
	mov	x0, x19
	bl	_nvm_mixed_samples_candidate
	eor	w23, w0, #0x1
LBB3_114:
	mov	x0, x19
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #480]
	cmp	w8, #3
	stp	q0, q0, [x26, #448]
	stp	q0, q0, [x26, #416]
	stp	q0, q0, [x26, #384]
	stp	q0, q0, [x26, #352]
	stp	q0, q0, [x26, #320]
	stp	q0, q0, [x26, #288]
	stp	q0, q0, [x26, #256]
	stp	q0, q0, [x26, #224]
	stp	q0, q0, [x26, #192]
	stp	q0, q0, [x26, #160]
	stp	q0, q0, [x26, #128]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	ccmp	w22, #0, #0, hs
	stp	q0, q0, [sp, #48]
	cset	w8, ne
	orr	w22, w8, w23
	tst	w22, #0x1
	add	x8, sp, #16
	csel	x2, x8, xzr, ne
	stp	q0, q0, [sp, #16]
	add	x1, sp, #15
	mov	x0, x19
	mov	x3, #0                          ; =0x0
	mov	x4, x21
	bl	_conversion_ownership
	cbz	w0, LBB3_118
; %bb.115:
	mov	x21, x0
	mov	x0, x19
	bl	_nvm_module_free
	b	LBB3_128
LBB3_116:
	mov	x0, x19
	bl	_nvm_module_free
	mov	w0, #13                         ; =0xd
	b	LBB3_70
LBB3_117:
	mov	x0, x19
	bl	_nvm_module_free
	mov	w0, #1                          ; =0x1
	b	LBB3_70
LBB3_118:
	tbz	w22, #0, LBB3_124
; %bb.119:
	ldr	w8, [x19, #272]
	cbz	w8, LBB3_124
; %bb.120:
	ldr	x9, [x20, #72]
	add	x9, x9, #28
	add	x10, sp, #16
	b	LBB3_122
LBB3_121:                               ;   in Loop: Header=BB3_122 Depth=1
	add	x10, x10, #2
	subs	x8, x8, #1
	b.eq	LBB3_124
LBB3_122:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w11, [x9], #32
	cbz	w11, LBB3_121
; %bb.123:                              ;   in Loop: Header=BB3_122 Depth=1
	ldrh	w12, [x10]
	cmp	w11, w12
	b.hs	LBB3_121
	b	LBB3_127
LBB3_124:
	mov	x0, x19
	bl	_nvm_passive_valid
	tbz	w0, #0, LBB3_127
; %bb.125:
	mov	w21, #0                         ; =0x0
	str	x19, [x25]
	b	LBB3_128
LBB3_126:
	add	x1, x20, #56
	mov	x0, x19
	bl	_nvm_retain_layouts
	mov	x22, x0
	mov	x0, x23
	bl	_free
	mov	x27, x22
	cbnz	w22, LBB3_92
	b	LBB3_96
LBB3_127:
	mov	x0, x19
	bl	_nvm_module_free
	mov	w21, #13                        ; =0xd
LBB3_128:
	mov	x0, x21
	b	LBB3_70
LBB3_129:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh8, Lloh9, Lloh10
	.loh AdrpLdrGotLdr	Lloh11, Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_from_nvm_module ; -- Begin function nvm_v2_from_nvm_module
	.globl	_nvm_v2_from_nvm_module
	.p2align	2
_nvm_v2_from_nvm_module:                ; @nvm_v2_from_nvm_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x1
	mov	x20, x0
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB4_4
; %bb.1:
	cbz	x19, LBB4_5
; %bb.2:
	str	xzr, [sp, #240]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #208]
	stp	q0, q0, [sp, #176]
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	mov	x1, sp
	mov	x0, x20
	mov	x2, #0                          ; =0x0
	bl	_nvm_from_module_core
	cbz	w0, LBB4_6
; %bb.3:
	mov	x19, x0
	mov	x0, sp
	bl	_nvm_v2_module_free
	mov	x0, x19
	b	LBB4_7
LBB4_4:
	mov	x0, x20
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	b	_nvm_from_module_core
LBB4_5:
	mov	w0, #13                         ; =0xd
	b	LBB4_7
LBB4_6:
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x19, #192]
	ldr	q0, [sp, #224]
	str	q0, [x19, #224]
	ldr	x8, [sp, #240]
	str	x8, [x19, #240]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x19, #128]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x19, #160]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x19, #64]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x19, #96]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x19, #32]
LBB4_7:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_to_nvm_module   ; -- Begin function nvm_v2_to_nvm_module
	.globl	_nvm_v2_to_nvm_module
	.p2align	2
_nvm_v2_to_nvm_module:                  ; @nvm_v2_to_nvm_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	bl	_nvm_record_map_wire_selected
	cbz	w0, LBB5_4
; %bb.1:
	cbz	x19, LBB5_5
; %bb.2:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x0, x20
	mov	x2, #0                          ; =0x0
	bl	_nvm_to_module_core
	ldr	x8, [sp, #8]
	cbz	w0, LBB5_6
; %bb.3:
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_module_free
	mov	x0, x19
	b	LBB5_7
LBB5_4:
	mov	x0, x20
	mov	x1, x19
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	b	_nvm_to_module_core
LBB5_5:
	mov	w0, #13                         ; =0xd
	b	LBB5_7
LBB5_6:
	str	x8, [x19]
LBB5_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function conversion_ownership
_conversion_ownership:                  ; @conversion_ownership
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #3984
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x4
	mov	x22, x3
	mov	x21, x2
	mov	x19, x1
	mov	x20, x0
Lloh14:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh15:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh16:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	bl	_nvm_record_map_route
	sub	w8, w0, #1
	cmp	w8, #2
	b.hi	LBB6_9
; %bb.1:
	stur	xzr, [x29, #-144]
	add	x8, sp, #76
	sub	x1, x29, #144
	mov	x0, x20
	bl	_nvm_record_map_admit
	ldr	w8, [sp, #76]
	cbnz	w8, LBB6_17
; %bb.2:
	cbz	x21, LBB6_7
; %bb.3:
	ldr	w8, [x20, #272]
	cbz	w8, LBB6_7
; %bb.4:
	mov	x22, #0                         ; =0x0
LBB6_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-144]
	add	x2, sp, #16
	mov	x1, x22
	bl	_nvm_record_map_execution_function
	cbz	w0, LBB6_44
; %bb.6:                                ;   in Loop: Header=BB6_5 Depth=1
	ldrh	w8, [sp, #48]
	strh	w8, [x21, x22, lsl #1]
	add	x22, x22, #1
	ldr	w8, [x20, #272]
	cmp	x22, x8
	b.lo	LBB6_5
LBB6_7:
	ldur	x0, [x29, #-144]
	bl	_nvm_record_map_execution_free
LBB6_8:
	mov	w0, #0                          ; =0x0
	strb	wzr, [x19]
	b	LBB6_55
LBB6_9:
	mov	x0, x20
	bl	_nvm_service_bindings_present
	cbz	w0, LBB6_15
; %bb.10:
	cbz	x23, LBB6_19
; %bb.11:
	ldr	x8, [x23]
	cbz	x8, LBB6_18
; %bb.12:
	ldr	x9, [x23, #8]
	cbz	x9, LBB6_18
; %bb.13:
	ldr	w9, [x23, #16]
	cbz	w9, LBB6_18
; %bb.14:
	mov	x0, x20
	blr	x8
	cbnz	w0, LBB6_55
	b	LBB6_43
LBB6_15:
	sub	x24, x29, #144
	mov	x0, x20
	bl	_nvm_owned_array_route
	cbz	w0, LBB6_24
; %bb.16:
	str	xzr, [sp, #8]
	add	x8, sp, #16
	add	x1, sp, #8
	mov	x0, x20
	bl	_nvm_owned_array_admit
	ldr	w8, [sp, #16]
	cbz	w8, LBB6_34
LBB6_17:
	cmp	w8, #4
	mov	w8, #13                         ; =0xd
	csinc	w0, w8, wzr, ne
	b	LBB6_55
LBB6_18:
	mov	w0, #8                          ; =0x8
	b	LBB6_55
LBB6_19:
	mov	x0, x20
	bl	_nvm_service_bindings_validate
	cbnz	w0, LBB6_55
; %bb.20:
	ldr	x0, [x20, #328]
	ldr	w1, [x20, #336]
	sub	x2, x29, #144
	bl	_nvm_file_nominal_decode
	cbz	w0, LBB6_42
; %bb.21:
	ldr	x0, [x20, #328]
	ldr	w1, [x20, #336]
	add	x2, sp, #16
	bl	_nvm_socket_nominal_decode
	cbz	w0, LBB6_42
; %bb.22:
	ldr	x0, [x20, #328]
	ldr	w1, [x20, #336]
	add	x2, sp, #76
	bl	_nvm_multi_nominal_decode
	cbz	w0, LBB6_42
; %bb.23:
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_ownership_contracts_validate
	b	LBB6_55
LBB6_24:
	mov	x0, x20
	bl	_nvm_record_array_candidate
	cbz	w0, LBB6_26
; %bb.25:
	mov	x0, x20
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB6_47
LBB6_26:
	mov	x0, x20
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB6_45
; %bb.27:
	str	xzr, [sp, #8]
	add	x8, sp, #16
	add	x1, sp, #8
	mov	x0, x20
	bl	_nvm_mixed_samples_admit
	ldr	w8, [sp, #16]
	cbnz	w8, LBB6_17
; %bb.28:
	stp	xzr, xzr, [x29, #-144]
	cbz	x21, LBB6_57
; %bb.29:
	ldr	w8, [x20, #272]
	cbz	w8, LBB6_33
; %bb.30:
	mov	x22, #0                         ; =0x0
	sub	x23, x29, #144
LBB6_31:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #8]
	add	x2, sp, #76
	mov	x1, x22
	bl	_nvm_mixed_samples_signature
	cbz	w0, LBB6_58
; %bb.32:                               ;   in Loop: Header=BB6_31 Depth=1
	ldrh	w8, [sp, #80]
	strh	w8, [x23, x22, lsl #1]
	add	x22, x22, #1
	ldr	w8, [x20, #272]
	cmp	x22, x8
	b.lo	LBB6_31
LBB6_33:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_plan_free
	b	LBB6_41
LBB6_34:
	stp	xzr, xzr, [x29, #-144]
	ldr	w8, [x20, #272]
	cbz	w8, LBB6_40
; %bb.35:
	mov	x23, #0                         ; =0x0
	add	x25, sp, #76
	sub	x26, x29, #144
	mov	x27, x22
	b	LBB6_37
LBB6_36:                                ;   in Loop: Header=BB6_37 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20, #272]
	add	x27, x27, #116
	cmp	x23, x8
	b.hs	LBB6_40
LBB6_37:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #8]
	add	x2, sp, #76
	mov	x1, x23
	bl	_nvm_owned_array_plan_signature
	cbz	w0, LBB6_54
; %bb.38:                               ;   in Loop: Header=BB6_37 Depth=1
	ldrh	w8, [sp, #80]
	strh	w8, [x26, x23, lsl #1]
	cbz	x22, LBB6_36
; %bb.39:                               ;   in Loop: Header=BB6_37 Depth=1
	ldp	q0, q1, [x25, #64]
	stp	q0, q1, [x27, #64]
	ldr	q0, [x25, #96]
	str	q0, [x27, #96]
	ldr	w8, [sp, #188]
	str	w8, [x27, #112]
	ldur	q0, [sp, #76]
	ldur	q1, [sp, #92]
	stp	q0, q1, [x27]
	ldur	q0, [sp, #108]
	ldur	q1, [sp, #124]
	stp	q0, q1, [x27, #32]
	b	LBB6_36
LBB6_40:
	ldr	x0, [sp, #8]
	bl	_nvm_owned_array_plan_free
	cbz	x21, LBB6_42
LBB6_41:
	ldr	q0, [x24]
	str	q0, [x21]
LBB6_42:
	mov	w0, #0                          ; =0x0
LBB6_43:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19]
	b	LBB6_55
LBB6_44:
	ldur	x0, [x29, #-144]
	bl	_nvm_record_map_execution_free
	mov	w0, #13                         ; =0xd
	b	LBB6_55
LBB6_45:
	ldur	x8, [x29, #-88]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_60
; %bb.46:
	mov	x0, x20
	mov	x1, x19
	add	sp, sp, #3984
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_nvm_ownership_contracts_validate
LBB6_47:
	stur	xzr, [x29, #-144]
	add	x8, sp, #76
	sub	x1, x29, #144
	mov	x0, x20
	bl	_nvm_record_array_admit
	ldr	w8, [sp, #76]
	cbnz	w8, LBB6_17
; %bb.48:
	cbz	x21, LBB6_53
; %bb.49:
	ldr	w8, [x20, #272]
	cbz	w8, LBB6_53
; %bb.50:
	mov	x22, #0                         ; =0x0
LBB6_51:                                ; =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-144]
	add	x2, sp, #16
	mov	x1, x22
	bl	_nvm_record_array_execution_function
	cbz	w0, LBB6_59
; %bb.52:                               ;   in Loop: Header=BB6_51 Depth=1
	ldrh	w8, [sp, #48]
	strh	w8, [x21, x22, lsl #1]
	add	x22, x22, #1
	ldr	w8, [x20, #272]
	cmp	x22, x8
	b.lo	LBB6_51
LBB6_53:
	ldur	x0, [x29, #-144]
	bl	_nvm_record_array_execution_free
	b	LBB6_8
LBB6_54:
	ldr	x0, [sp, #8]
	bl	_nvm_owned_array_plan_free
	mov	w0, #13                         ; =0xd
LBB6_55:
	ldur	x8, [x29, #-88]
Lloh20:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh21:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh22:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_60
; %bb.56:
	add	sp, sp, #3984
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB6_57:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_plan_free
	b	LBB6_42
LBB6_58:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_plan_free
	mov	w0, #13                         ; =0xd
	b	LBB6_55
LBB6_59:
	ldur	x0, [x29, #-144]
	bl	_nvm_record_array_execution_free
	mov	w0, #13                         ; =0xd
	b	LBB6_55
LBB6_60:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh14, Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.loh AdrpLdrGotLdr	Lloh20, Lloh21, Lloh22
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function intern_signature
_intern_signature:                      ; @intern_signature
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB7_4
; %bb.1:
	mov	x22, x3
	mov	x23, x2
	mov	x24, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
LBB7_2:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19]
	add	x0, x8, x24
	mov	x1, x20
	bl	_nvm_v2_signature_equal
	tbnz	w0, #0, LBB7_6
; %bb.3:                                ;   in Loop: Header=BB7_2 Depth=1
	add	x21, x21, #1
	ldr	w8, [x19, #8]
	add	x24, x24, #24
	cmp	x21, x8
	b.lo	LBB7_2
	b	LBB7_5
LBB7_4:
	mov	x8, #0                          ; =0x0
LBB7_5:
	ldr	x9, [x19]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w8, w10, x9
	ldr	q0, [x20]
	ldr	x9, [x20, #16]
	str	x9, [x8, #16]
	str	q0, [x8]
	ldr	w21, [x19, #8]
	add	w8, w21, #1
	str	w8, [x19, #8]
	b	LBB7_7
LBB7_6:
	str	x22, [x23]
LBB7_7:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
_SOURCE_FILE_KEY:                       ; @SOURCE_FILE_KEY
	.asciz	"nano.source_file"

.subsections_via_symbols
