	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_affine_has_complete_unions ; -- Begin function nvm_affine_has_complete_unions
	.p2align	2
_nvm_affine_has_complete_unions:        ; @nvm_affine_has_complete_unions
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_10
LBB0_2:
	str	wzr, [sp, #12]
	b	LBB0_3
LBB0_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB0_9
	b	LBB0_4
LBB0_4:                                 ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB0_7
	b	LBB0_5
LBB0_5:                                 ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB0_7
	b	LBB0_6
LBB0_6:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_10
LBB0_7:                                 ;   in Loop: Header=BB0_3 Depth=1
	b	LBB0_8
LBB0_8:                                 ;   in Loop: Header=BB0_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB0_3
LBB0_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_10
LBB0_10:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_state_free          ; -- Begin function nvm_affine_state_free
	.p2align	2
_nvm_affine_state_free:                 ; @nvm_affine_state_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_9
LBB1_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_8
	b	LBB1_3
LBB1_3:
	str	wzr, [sp, #4]
	b	LBB1_4
LBB1_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB1_7
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #32]
	bl	_free
	b	LBB1_6
LBB1_6:                                 ;   in Loop: Header=BB1_4 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB1_4
LBB1_7:
	b	LBB1_8
LBB1_8:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_facts_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB1_9
LBB1_9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function facts_free
_facts_free:                            ; @facts_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	cbz	w8, LBB2_3
	b	LBB2_2
LBB2_2:
	b	LBB2_4
LBB2_3:
	ldr	x8, [sp, #8]
	add	x0, x8, #8
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #40]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #48]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB2_4
LBB2_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_state_create        ; -- Begin function nvm_affine_state_create
	.p2align	2
_nvm_affine_state_create:               ; @nvm_affine_state_create
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_4
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	cbz	w8, LBB3_4
	b	LBB3_2
LBB3_2:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB3_4
	b	LBB3_3
LBB3_3:
	ldur	x0, [x29, #-32]
	sub	x1, x29, #41
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB3_5
	b	LBB3_4
LBB3_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_86
LBB3_5:
	mov	x0, #1                          ; =0x1
	mov	x1, #200                        ; =0xc8
	bl	_calloc
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB3_7
	b	LBB3_6
LBB3_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_86
LBB3_7:
	mov	x0, #1                          ; =0x1
	mov	x1, #80                         ; =0x50
	bl	_calloc
	ldur	x8, [x29, #-56]
	str	x0, [x8]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8]
	cbnz	x8, LBB3_9
	b	LBB3_8
LBB3_8:
	ldur	x0, [x29, #-56]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_86
LBB3_9:
	ldur	x8, [x29, #-56]
	ldr	x8, [x8]
	stur	x8, [x29, #-64]
	ldur	x9, [x29, #-64]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-64]
	str	x8, [x9, #64]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-64]
	str	w8, [x9, #72]
	ldur	x9, [x29, #-56]
	mov	x8, #1                          ; =0x1
	str	x8, [x9, #56]
	ldur	x0, [x29, #-32]
	add	x1, sp, #188
	bl	_nvm_ownership_effect_types
	str	w0, [sp, #184]
	ldr	w8, [sp, #184]
	cbz	w8, LBB3_12
	b	LBB3_10
LBB3_10:
	ldr	w8, [sp, #184]
	subs	w8, w8, #13
	b.eq	LBB3_12
	b	LBB3_11
LBB3_11:
	b	LBB3_85
LBB3_12:
	ldr	w8, [sp, #184]
	cbnz	w8, LBB3_17
	b	LBB3_13
LBB3_13:
	ldr	w8, [sp, #188]
	cbz	w8, LBB3_17
	b	LBB3_14
LBB3_14:
	mov	x0, #2052                       ; =0x804
	bl	_malloc
	ldur	x8, [x29, #-64]
	str	x0, [x8, #48]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB3_16
	b	LBB3_15
LBB3_15:
	b	LBB3_85
LBB3_16:
	ldur	x8, [x29, #-64]
	ldr	x0, [x8, #48]
	add	x1, sp, #188
	mov	x2, #2052                       ; =0x804
	bl	_memcpy
	b	LBB3_17
LBB3_17:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldur	x8, [x29, #-64]
	add	x2, x8, #8
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB3_19
	b	LBB3_18
LBB3_18:
	b	LBB3_85
LBB3_19:
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #160
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #156
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_22
	b	LBB3_20
LBB3_20:
	add	x0, sp, #160
	add	x1, sp, #152
	bl	_nvm_v2_u32
	cbnz	w0, LBB3_22
	b	LBB3_21
LBB3_21:
	ldr	w8, [sp, #152]
	mov	x1, x8
	add	x0, sp, #160
	add	x2, sp, #144
	bl	_nvm_v2_take
	cbz	w0, LBB3_23
	b	LBB3_22
LBB3_22:
	b	LBB3_85
LBB3_23:
	ldr	w8, [sp, #152]
	cbz	w8, LBB3_25
	b	LBB3_24
LBB3_24:
	ldr	w8, [sp, #152]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB3_26
LBB3_25:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB3_26
LBB3_26:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	bl	_malloc
	ldur	x8, [x29, #-64]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB3_28
	b	LBB3_27
LBB3_27:
	b	LBB3_85
LBB3_28:
	ldur	x8, [x29, #-64]
	ldr	x0, [x8, #24]
	ldr	x1, [sp, #144]
	ldr	w8, [sp, #152]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	add	x0, sp, #160
	bl	_nvm_v2_align4
	cbnz	w0, LBB3_30
	b	LBB3_29
LBB3_29:
	add	x0, sp, #160
	add	x1, sp, #156
	bl	_nvm_v2_u32
	cbz	w0, LBB3_31
	b	LBB3_30
LBB3_30:
	b	LBB3_85
LBB3_31:
	strh	wzr, [sp, #142]
	str	wzr, [sp, #136]
	b	LBB3_32
LBB3_32:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_48 Depth 2
	ldr	w8, [sp, #136]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.hi	LBB3_59
	b	LBB3_33
LBB3_33:                                ;   in Loop: Header=BB3_32 Depth=1
	add	x0, sp, #160
	add	x1, sp, #134
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_36
	b	LBB3_34
LBB3_34:                                ;   in Loop: Header=BB3_32 Depth=1
	add	x0, sp, #160
	add	x1, sp, #142
	bl	_nvm_v2_u16
	cbnz	w0, LBB3_36
	b	LBB3_35
LBB3_35:                                ;   in Loop: Header=BB3_32 Depth=1
	add	x0, sp, #160
	add	x1, sp, #124
	bl	_slot_read
	tbnz	w0, #0, LBB3_37
	b	LBB3_36
LBB3_36:
	b	LBB3_85
LBB3_37:                                ;   in Loop: Header=BB3_32 Depth=1
	ldr	w8, [sp, #136]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB3_47
	b	LBB3_38
LBB3_38:                                ;   in Loop: Header=BB3_32 Depth=1
	ldrb	w8, [sp, #124]
	cbz	w8, LBB3_41
	b	LBB3_39
LBB3_39:                                ;   in Loop: Header=BB3_32 Depth=1
	ldur	x0, [x29, #-64]
	ldur	x1, [sp, #124]
	bl	_supported
	tbnz	w0, #0, LBB3_41
	b	LBB3_40
LBB3_40:
	b	LBB3_85
LBB3_41:                                ;   in Loop: Header=BB3_32 Depth=1
	ldrh	w8, [sp, #134]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #56]
	ldrh	w8, [sp, #142]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #58]
	ldur	x9, [x29, #-64]
	ldur	x8, [sp, #124]
	str	x8, [x9, #32]
	ldrh	w8, [sp, #134]
	cbz	w8, LBB3_43
	b	LBB3_42
LBB3_42:                                ;   in Loop: Header=BB3_32 Depth=1
	ldrh	w8, [sp, #134]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB3_44
LBB3_43:                                ;   in Loop: Header=BB3_32 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB3_44
LBB3_44:                                ;   in Loop: Header=BB3_32 Depth=1
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldur	x8, [x29, #-64]
	str	x0, [x8, #40]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #40]
	cbnz	x8, LBB3_46
	b	LBB3_45
LBB3_45:
	b	LBB3_85
LBB3_46:                                ;   in Loop: Header=BB3_32 Depth=1
	b	LBB3_47
LBB3_47:                                ;   in Loop: Header=BB3_32 Depth=1
	strh	wzr, [sp, #122]
	b	LBB3_48
LBB3_48:                                ;   Parent Loop BB3_32 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #122]
	ldrh	w9, [sp, #134]
	subs	w8, w8, w9
	b.ge	LBB3_57
	b	LBB3_49
LBB3_49:                                ;   in Loop: Header=BB3_48 Depth=2
	add	x0, sp, #160
	add	x1, sp, #112
	bl	_slot_read
	tbnz	w0, #0, LBB3_51
	b	LBB3_50
LBB3_50:
	b	LBB3_85
LBB3_51:                                ;   in Loop: Header=BB3_48 Depth=2
	ldr	w8, [sp, #136]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB3_55
	b	LBB3_52
LBB3_52:                                ;   in Loop: Header=BB3_48 Depth=2
	ldur	x0, [x29, #-64]
	ldr	x1, [sp, #112]
	bl	_supported
	tbnz	w0, #0, LBB3_54
	b	LBB3_53
LBB3_53:
	b	LBB3_85
LBB3_54:                                ;   in Loop: Header=BB3_48 Depth=2
	ldur	x8, [x29, #-64]
	ldr	x9, [x8, #40]
	ldrh	w8, [sp, #122]
	mov	x10, x8
	ldr	x8, [sp, #112]
	str	x8, [x9, x10, lsl #3]
	b	LBB3_55
LBB3_55:                                ;   in Loop: Header=BB3_48 Depth=2
	b	LBB3_56
LBB3_56:                                ;   in Loop: Header=BB3_48 Depth=2
	ldrh	w8, [sp, #122]
	add	w8, w8, #1
	strh	w8, [sp, #122]
	b	LBB3_48
LBB3_57:                                ;   in Loop: Header=BB3_32 Depth=1
	b	LBB3_58
LBB3_58:                                ;   in Loop: Header=BB3_32 Depth=1
	ldr	w8, [sp, #136]
	add	w8, w8, #1
	str	w8, [sp, #136]
	b	LBB3_32
LBB3_59:
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-56]
	str	w8, [x9, #32]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #56]
	cbz	w8, LBB3_61
	b	LBB3_60
LBB3_60:
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #56]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB3_62
LBB3_61:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB3_62
LBB3_62:
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	ldur	x8, [x29, #-56]
	str	x0, [x8, #8]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #56]
	cbz	w8, LBB3_64
	b	LBB3_63
LBB3_63:
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #56]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB3_65
LBB3_64:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB3_65
LBB3_65:
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsl	x0, x8, #1
	bl	_malloc
	ldur	x8, [x29, #-56]
	str	x0, [x8, #16]
	ldur	w8, [x29, #-40]
	cbz	w8, LBB3_67
	b	LBB3_66
LBB3_66:
	ldur	w8, [x29, #-40]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB3_68
LBB3_67:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB3_68
LBB3_68:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	mov	x1, #56                         ; =0x38
	bl	_calloc
	ldur	x8, [x29, #-56]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #8]
	cbz	x8, LBB3_71
	b	LBB3_69
LBB3_69:
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #16]
	cbz	x8, LBB3_71
	b	LBB3_70
LBB3_70:
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB3_72
	b	LBB3_71
LBB3_71:
	b	LBB3_85
LBB3_72:
	strh	wzr, [sp, #110]
	b	LBB3_73
LBB3_73:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #110]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB3_76
	b	LBB3_74
LBB3_74:                                ;   in Loop: Header=BB3_73 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #110]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB3_75
LBB3_75:                                ;   in Loop: Header=BB3_73 Depth=1
	ldrh	w8, [sp, #110]
	add	w8, w8, #1
	strh	w8, [sp, #110]
	b	LBB3_73
LBB3_76:
	strh	wzr, [sp, #108]
	b	LBB3_77
LBB3_77:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #108]
	ldrh	w9, [sp, #142]
	subs	w8, w8, w9
	b.ge	LBB3_84
	b	LBB3_78
LBB3_78:                                ;   in Loop: Header=BB3_77 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #96]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldrb	w8, [sp, #97]
	cbz	w8, LBB3_82
	b	LBB3_79
LBB3_79:                                ;   in Loop: Header=BB3_77 Depth=1
	ldrh	w8, [sp, #108]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	b.lo	LBB3_81
	b	LBB3_80
LBB3_80:
	b	LBB3_85
LBB3_81:                                ;   in Loop: Header=BB3_77 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x10, [x8, #24]
	ldrh	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #40
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #40]
	add	x8, x1, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #43]
	str	wzr, [sp, #44]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #48]
	str	wzr, [sp, #52]
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #56]
	ldrh	w8, [sp, #108]
	strh	w8, [sp, #64]
	strh	wzr, [sp, #66]
	ldr	w8, [sp, #100]
	str	w8, [sp, #68]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #72]
	strh	wzr, [sp, #80]
	strh	wzr, [sp, #82]
	ldr	w8, [sp, #100]
	str	w8, [sp, #84]
	ldrb	w8, [sp, #97]
	str	w8, [sp, #88]
	str	wzr, [sp, #92]
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	b	LBB3_82
LBB3_82:                                ;   in Loop: Header=BB3_77 Depth=1
	b	LBB3_83
LBB3_83:                                ;   in Loop: Header=BB3_77 Depth=1
	ldrh	w8, [sp, #108]
	add	w8, w8, #1
	strh	w8, [sp, #108]
	b	LBB3_77
LBB3_84:
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-24]
	b	LBB3_86
LBB3_85:
	ldur	x0, [x29, #-56]
	bl	_nvm_affine_state_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	b	LBB3_86
LBB3_86:
	ldur	x0, [x29, #-24]
	add	sp, sp, #2288
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function slot_read
_slot_read:                             ; @slot_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_nvm_v2_u8
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w0, LBB4_4
	b	LBB4_1
LBB4_1:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	add	x1, x8, #1
	bl	_nvm_v2_u8
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w0, LBB4_4
	b	LBB4_2
LBB4_2:
	ldur	x0, [x29, #-8]
	add	x1, sp, #14
	bl	_nvm_v2_u16
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w0, LBB4_4
	b	LBB4_3
LBB4_3:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	add	x1, x8, #4
	bl	_nvm_v2_u32
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_4
LBB4_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function supported
_supported:                             ; @supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-8]
	str	x0, [sp, #16]
	ldurb	w8, [x29, #-8]
	subs	w8, w8, #7
	b.ne	LBB5_4
	b	LBB5_1
LBB5_1:
	ldurb	w8, [x29, #-7]
	cbnz	w8, LBB5_4
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #48]
	cbz	x8, LBB5_4
	b	LBB5_3
LBB5_3:
	ldur	w9, [x29, #-4]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #48]
	ldr	w10, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.lo	LBB5_10
	b	LBB5_4
LBB5_4:
	ldurb	w0, [x29, #-8]
	bl	_scalar
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB5_10
	b	LBB5_5
LBB5_5:
	ldurb	w8, [x29, #-8]
	subs	w8, w8, #5
	b.ne	LBB5_7
	b	LBB5_6
LBB5_6:
	ldur	w8, [x29, #-4]
	mov	w0, #1                          ; =0x1
	adds	w8, w8, #1
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB5_10
	b	LBB5_7
LBB5_7:
	ldurb	w8, [x29, #-8]
	subs	w8, w8, #8
	b.ne	LBB5_9
	b	LBB5_8
LBB5_8:
	ldur	w8, [x29, #-4]
	mov	w0, #1                          ; =0x1
	adds	w8, w8, #1
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB5_10
	b	LBB5_9
LBB5_9:
	ldr	x0, [sp, #16]
	ldur	x1, [x29, #-8]
	bl	_union_value
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB5_10
LBB5_10:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_state_clone         ; -- Begin function nvm_affine_state_clone
	.p2align	2
_nvm_affine_state_clone:                ; @nvm_affine_state_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB6_3
	b	LBB6_2
LBB6_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_28
LBB6_3:
	mov	x0, #1                          ; =0x1
	mov	x1, #200                        ; =0xc8
	bl	_calloc
	stur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB6_5
	b	LBB6_4
LBB6_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_28
LBB6_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	ldur	x8, [x29, #-24]
	ldr	x9, [x8]
	ldr	w8, [x9]
	mov	w10, #1                         ; =0x1
	add	w8, w8, #1
	str	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #32]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #32]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #36]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #36]
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	ldur	x9, [x29, #-24]
	and	w8, w8, w10
	strb	w8, [x9, #40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #56]
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #41]
	ldur	x9, [x29, #-24]
	and	w8, w8, w10
	strb	w8, [x9, #41]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #42]
	ldur	x9, [x29, #-24]
	strh	w8, [x9, #42]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #44]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #44]
	ldur	x9, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	str	x8, [x9, #48]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #64]
	ldur	x9, [x29, #-24]
	strh	w8, [x9, #64]
	ldur	x8, [x29, #-24]
	add	x0, x8, #72
	ldur	x8, [x29, #-16]
	add	x1, x8, #72
	mov	x2, #128                        ; =0x80
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	cbz	w8, LBB6_7
	b	LBB6_6
LBB6_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB6_8
LBB6_7:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB6_8
LBB6_8:
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsr	x0, x8, #0
	bl	_malloc
	ldur	x8, [x29, #-24]
	str	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	cbz	w8, LBB6_10
	b	LBB6_9
LBB6_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB6_11
LBB6_10:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB6_11
LBB6_11:
	ldr	w9, [sp, #32]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsl	x0, x8, #1
	bl	_malloc
	ldur	x8, [x29, #-24]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #32]
	cbz	w8, LBB6_13
	b	LBB6_12
LBB6_12:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #32]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB6_14
LBB6_13:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB6_14
LBB6_14:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	mov	x1, #56                         ; =0x38
	bl	_calloc
	ldur	x8, [x29, #-24]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #8]
	cbz	x8, LBB6_17
	b	LBB6_15
LBB6_15:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	cbz	x8, LBB6_17
	b	LBB6_16
LBB6_16:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB6_18
	b	LBB6_17
LBB6_17:
	b	LBB6_27
LBB6_18:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
                                        ; kill: def $x8 killed $w8
	lsr	x2, x8, #0
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	bl	___memcpy_chk
	stur	wzr, [x29, #-28]
	b	LBB6_19
LBB6_19:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB6_26
	b	LBB6_20
LBB6_20:                                ;   in Loop: Header=BB6_19 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x11, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-24]
	ldr	x11, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
                                        ; kill: def $x10 killed $xzr
	str	xzr, [x8, #32]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #40]
	sturh	w8, [x29, #-30]
	ldurh	w8, [x29, #-30]
	cbz	w8, LBB6_24
	b	LBB6_21
LBB6_21:                                ;   in Loop: Header=BB6_19 Depth=1
	ldurh	w8, [x29, #-30]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #1
	bl	_malloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB6_23
	b	LBB6_22
LBB6_22:
	b	LBB6_27
LBB6_23:                                ;   in Loop: Header=BB6_19 Depth=1
	ldr	x0, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	str	x9, [sp]                        ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #32]
	ldurh	w8, [x29, #-30]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x11, [x9, #24]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x8, [x9, #32]
	b	LBB6_24
LBB6_24:                                ;   in Loop: Header=BB6_19 Depth=1
	b	LBB6_25
LBB6_25:                                ;   in Loop: Header=BB6_19 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB6_19
LBB6_26:
	ldur	x8, [x29, #-24]
	stur	x8, [x29, #-8]
	b	LBB6_28
LBB6_27:
	ldur	x0, [x29, #-24]
	bl	_nvm_affine_state_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB6_28
LBB6_28:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_handler_enter       ; -- Begin function nvm_affine_handler_enter
	.p2align	2
_nvm_affine_handler_enter:              ; @nvm_affine_handler_enter
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #44
	str	x8, [sp]                        ; 8-byte Folded Spill
	stur	x0, [x8, #12]
	str	w1, [x8, #8]
	sturh	w2, [x29, #-38]
	ldur	x8, [x8, #12]
	cbz	x8, LBB7_6
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x8, #12]
	ldr	w8, [x8, #36]
	cbnz	w8, LBB7_6
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x8, #12]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB7_6
	b	LBB7_3
LBB7_3:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldurh	w8, [x29, #-38]
	ldur	x9, [x9, #12]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.gt	LBB7_6
	b	LBB7_4
LBB7_4:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x8, #12]
	ldrb	w8, [x8, #41]
	tbz	w8, #0, LBB7_7
	b	LBB7_5
LBB7_5:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldurh	w8, [x29, #-38]
	ldur	x9, [x9, #12]
	ldrh	w9, [x9, #42]
	subs	w8, w8, w9
	b.ge	LBB7_7
	b	LBB7_6
LBB7_6:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #20]
	b	LBB7_37
LBB7_7:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	wzr, [x8]
	b	LBB7_8
LBB7_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [x9]
	ldur	x9, [x9, #12]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB7_13
	b	LBB7_9
LBB7_9:                                 ;   in Loop: Header=BB7_8 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x9, [x8, #12]
	ldr	x10, [x9, #24]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB7_11
	b	LBB7_10
LBB7_10:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #20]
	b	LBB7_37
LBB7_11:                                ;   in Loop: Header=BB7_8 Depth=1
	b	LBB7_12
LBB7_12:                                ;   in Loop: Header=BB7_8 Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB7_8
LBB7_13:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x9, [x8, #12]
	ldr	x9, [x9]
	ldr	x0, [x9, #64]
	ldr	w1, [x8, #8]
	add	x2, sp, #68
	bl	_nvm_ownership_effect
	cbnz	w0, LBB7_15
	b	LBB7_14
LBB7_14:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldrh	w8, [sp, #72]
	ldur	x9, [x9, #12]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	ldurh	w10, [x29, #-38]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.le	LBB7_16
	b	LBB7_15
LBB7_15:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #20]
	b	LBB7_37
LBB7_16:
	strh	wzr, [sp, #66]
	b	LBB7_17
LBB7_17:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #66]
	ldrh	w9, [sp, #72]
	subs	w8, w8, w9
	b.ge	LBB7_22
	b	LBB7_18
LBB7_18:                                ;   in Loop: Header=BB7_17 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	add	x9, sp, #68
	add	x9, x9, #16
	ldrh	w10, [sp, #66]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	str	x9, [sp, #56]
	ldur	x9, [x8, #12]
	ldr	x0, [x9]
	ldur	x8, [x8, #12]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-38]
	ldrh	w10, [sp, #66]
	add	w9, w9, w10
	ldrb	w10, [sp, #56]
	strb	w10, [sp, #48]
	strb	wzr, [sp, #49]
	strh	wzr, [sp, #50]
	ldr	w10, [sp, #60]
	str	w10, [sp, #52]
	ldr	x1, [x8, w9, sxtw #3]
	ldr	x2, [sp, #48]
	bl	_same
	tbnz	w0, #0, LBB7_20
	b	LBB7_19
LBB7_19:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #20]
	b	LBB7_37
LBB7_20:                                ;   in Loop: Header=BB7_17 Depth=1
	b	LBB7_21
LBB7_21:                                ;   in Loop: Header=BB7_17 Depth=1
	ldrh	w8, [sp, #66]
	add	w8, w8, #1
	strh	w8, [sp, #66]
	b	LBB7_17
LBB7_22:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x0, [x8, #12]
	bl	_nvm_affine_state_clone
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB7_24
	b	LBB7_23
LBB7_23:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #20]
	b	LBB7_37
LBB7_24:
	ldr	x9, [sp, #40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #41]
	ldurh	w8, [x29, #-38]
	ldr	x9, [sp, #40]
	strh	w8, [x9, #42]
	ldr	w8, [sp, #68]
	ldr	x9, [sp, #40]
	str	w8, [x9, #44]
	ldr	x9, [sp, #40]
	ldrb	w10, [sp, #76]
	add	x8, sp, #32
	strb	w10, [sp, #32]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #35]
	ldr	w8, [sp, #80]
	str	w8, [sp, #36]
	ldr	x8, [sp, #32]
	str	x8, [x9, #48]
	strh	wzr, [sp, #30]
	b	LBB7_25
LBB7_25:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #40]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB7_32
	b	LBB7_26
LBB7_26:                                ;   in Loop: Header=BB7_25 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldrh	w8, [sp, #30]
	ldurh	w9, [x29, #-38]
	subs	w8, w8, w9
	b.ge	LBB7_29
	b	LBB7_27
LBB7_27:                                ;   in Loop: Header=BB7_25 Depth=1
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB7_29
	b	LBB7_28
LBB7_28:                                ;   in Loop: Header=BB7_25 Depth=1
	ldr	x8, [sp, #40]
	ldr	x0, [x8]
	ldr	x1, [sp, #16]
	bl	_resource
	tbz	w0, #0, LBB7_30
	b	LBB7_29
LBB7_29:                                ;   in Loop: Header=BB7_25 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB7_30
LBB7_30:                                ;   in Loop: Header=BB7_25 Depth=1
	b	LBB7_31
LBB7_31:                                ;   in Loop: Header=BB7_25 Depth=1
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB7_25
LBB7_32:
	strh	wzr, [sp, #14]
	b	LBB7_33
LBB7_33:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #72]
	subs	w8, w8, w9
	b.ge	LBB7_36
	b	LBB7_34
LBB7_34:                                ;   in Loop: Header=BB7_33 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-38]
	ldrh	w10, [sp, #14]
	add	w9, w9, w10
	add	x9, x8, w9, sxtw
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB7_35
LBB7_35:                                ;   in Loop: Header=BB7_33 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB7_33
LBB7_36:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	stur	x8, [x9, #20]
	b	LBB7_37
LBB7_37:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x0, [x8, #20]
	add	sp, sp, #2160
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same
_same:                                  ; @same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x1, [sp, #64]
	str	x2, [sp, #56]
	str	x0, [sp, #48]
	ldrb	w8, [sp, #65]
	ldrb	w9, [sp, #57]
	subs	w8, w8, w9
	b.eq	LBB8_2
	b	LBB8_1
LBB8_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB8_15
LBB8_2:
	str	wzr, [sp, #44]
	b	LBB8_3
LBB8_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	subs	w8, w8, #256
	b.hi	LBB8_14
	b	LBB8_4
LBB8_4:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldrb	w8, [sp, #64]
	ldrb	w9, [sp, #56]
	subs	w8, w8, w9
	b.eq	LBB8_6
	b	LBB8_5
LBB8_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB8_15
LBB8_6:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldrb	w8, [sp, #64]
	subs	w8, w8, #7
	b.eq	LBB8_8
	b	LBB8_7
LBB8_7:
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB8_15
LBB8_8:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #48]
	cbz	x8, LBB8_11
	b	LBB8_9
LBB8_9:                                 ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #68]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB8_11
	b	LBB8_10
LBB8_10:                                ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB8_12
	b	LBB8_11
LBB8_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB8_15
LBB8_12:                                ;   in Loop: Header=BB8_3 Depth=1
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #32]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	ldrb	w8, [sp, #32]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldr	w8, [sp, #36]
	str	w8, [sp, #20]
	ldr	x8, [sp, #16]
	str	x8, [sp, #64]
	ldrb	w8, [sp, #24]
	strb	w8, [sp, #8]
	strb	wzr, [sp, #9]
	strh	wzr, [sp, #10]
	ldr	w8, [sp, #28]
	str	w8, [sp, #12]
	ldr	x8, [sp, #8]
	str	x8, [sp, #56]
	b	LBB8_13
LBB8_13:                                ;   in Loop: Header=BB8_3 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB8_3
LBB8_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB8_15
LBB8_15:
	ldrb	w8, [sp, #79]
	and	w0, w8, #0x1
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function resource
_resource:                              ; @resource
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x2, x29, #12
	stur	x1, [x29, #-12]
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	ldur	x1, [x29, #-12]
	bl	_array_leaf
	tbnz	w0, #0, LBB9_2
	b	LBB9_1
LBB9_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_7
LBB9_2:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.eq	LBB9_4
	b	LBB9_3
LBB9_3:
	ldurb	w9, [x29, #-12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB9_6
	b	LBB9_4
LBB9_4:
	ldur	w9, [x29, #-8]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB9_6
	b	LBB9_5
LBB9_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-8]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB9_6
LBB9_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_7
LBB9_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_can_suspend         ; -- Begin function nvm_affine_can_suspend
	.p2align	2
_nvm_affine_can_suspend:                ; @nvm_affine_can_suspend
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #36]
	cbz	w8, LBB10_3
	b	LBB10_2
LBB10_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_3:
	str	wzr, [sp, #12]
	b	LBB10_4
LBB10_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB10_9
	b	LBB10_5
LBB10_5:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB10_7
	b	LBB10_6
LBB10_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_7:                                ;   in Loop: Header=BB10_4 Depth=1
	b	LBB10_8
LBB10_8:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB10_4
LBB10_9:
	strh	wzr, [sp, #10]
	b	LBB10_10
LBB10_10:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB10_16
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_10 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #10]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB10_14
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_10 Depth=1
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #10]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB10_14
	b	LBB10_13
LBB10_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_14:                               ;   in Loop: Header=BB10_10 Depth=1
	b	LBB10_15
LBB10_15:                               ;   in Loop: Header=BB10_10 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB10_10
LBB10_16:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_17
LBB10_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_can_resume          ; -- Begin function nvm_affine_can_resume
	.p2align	2
_nvm_affine_can_resume:                 ; @nvm_affine_can_resume
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-8]
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB11_4
	b	LBB11_1
LBB11_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #41]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_4
	b	LBB11_2
LBB11_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #48]
	strb	w8, [sp, #24]
	strb	wzr, [sp, #25]
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	strh	wzr, [sp, #26]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #52]
	str	w8, [sp, #28]
	ldurb	w8, [x29, #-8]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldur	w8, [x29, #-4]
	str	w8, [sp, #20]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #16]
	bl	_same
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB11_4
	b	LBB11_3
LBB11_3:
	ldur	x0, [x29, #-16]
	bl	_nvm_affine_can_suspend
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB11_4
LBB11_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_state_equal         ; -- Begin function nvm_affine_state_equal
	.p2align	2
_nvm_affine_state_equal:                ; @nvm_affine_state_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_state_equal
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function state_equal
_state_equal:                           ; @state_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_13
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB13_13
	b	LBB13_2
LBB13_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB13_13
	b	LBB13_3
LBB13_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_4
LBB13_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #32]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_5
LBB13_5:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	and	w8, w8, #0x1
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #40]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_6
LBB13_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB13_13
	b	LBB13_7
LBB13_7:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #64]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #64]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_8
LBB13_8:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #41]
	and	w8, w8, #0x1
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #41]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_9
LBB13_9:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #42]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #42]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_10
LBB13_10:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #44]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #44]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_11
LBB13_11:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #48]
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #48]
	subs	w8, w8, w9
	b.ne	LBB13_13
	b	LBB13_12
LBB13_12:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #52]
	subs	w8, w8, w9
	b.eq	LBB13_14
	b	LBB13_13
LBB13_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_14:
	sturh	wzr, [x29, #-28]
	b	LBB13_15
LBB13_15:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB13_34
	b	LBB13_16
LBB13_16:                               ;   in Loop: Header=BB13_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #40]
	ldurb	w8, [x29, #-25]
	tbz	w8, #0, LBB13_25
	b	LBB13_17
LBB13_17:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #41]
	cbnz	w8, LBB13_25
	b	LBB13_18
LBB13_18:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w0, [sp, #40]
	bl	_scalar
	tbnz	w0, #0, LBB13_24
	b	LBB13_19
LBB13_19:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #5
	b.eq	LBB13_24
	b	LBB13_20
LBB13_20:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #10
	b.eq	LBB13_23
	b	LBB13_21
LBB13_21:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #8
	b.eq	LBB13_23
	b	LBB13_22
LBB13_22:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #7
	b.ne	LBB13_25
	b	LBB13_23
LBB13_23:                               ;   in Loop: Header=BB13_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	x1, [sp, #40]
	bl	_resource
	tbnz	w0, #0, LBB13_25
	b	LBB13_24
LBB13_24:                               ;   in Loop: Header=BB13_15 Depth=1
	b	LBB13_33
LBB13_25:                               ;   in Loop: Header=BB13_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	and	w8, w8, #0x1
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #8]
	ldurh	w10, [x29, #-28]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	ldrb	w9, [x9]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.eq	LBB13_27
	b	LBB13_26
LBB13_26:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_27:                               ;   in Loop: Header=BB13_15 Depth=1
	ldurb	w8, [x29, #-25]
	tbnz	w8, #0, LBB13_32
	b	LBB13_28
LBB13_28:                               ;   in Loop: Header=BB13_15 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #10
	b.ne	LBB13_32
	b	LBB13_29
LBB13_29:                               ;   in Loop: Header=BB13_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB13_32
	b	LBB13_30
LBB13_30:                               ;   in Loop: Header=BB13_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldurh	w10, [x29, #-28]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.eq	LBB13_32
	b	LBB13_31
LBB13_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_32:                               ;   in Loop: Header=BB13_15 Depth=1
	b	LBB13_33
LBB13_33:                               ;   in Loop: Header=BB13_15 Depth=1
	ldurh	w8, [x29, #-28]
	add	w8, w8, #1
	sturh	w8, [x29, #-28]
	b	LBB13_15
LBB13_34:
	strh	wzr, [sp, #38]
	b	LBB13_35
LBB13_35:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #38]
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #64]
	subs	w8, w8, w9
	b.ge	LBB13_42
	b	LBB13_36
LBB13_36:                               ;   in Loop: Header=BB13_35 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #72
	ldrh	w9, [sp, #38]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	x8, [x8, x9]
	ldur	x9, [x29, #-24]
	add	x9, x9, #72
	ldrh	w10, [sp, #38]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #4
	ldr	x9, [x9, x10]
	subs	x8, x8, x9
	b.ne	LBB13_39
	b	LBB13_37
LBB13_37:                               ;   in Loop: Header=BB13_35 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #72
	ldrh	w9, [sp, #38]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	add	x9, x9, #72
	ldrh	w10, [sp, #38]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB13_39
	b	LBB13_38
LBB13_38:                               ;   in Loop: Header=BB13_35 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #72
	ldrh	w9, [sp, #38]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	add	x9, x9, #72
	ldrh	w10, [sp, #38]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.eq	LBB13_40
	b	LBB13_39
LBB13_39:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_40:                               ;   in Loop: Header=BB13_35 Depth=1
	b	LBB13_41
LBB13_41:                               ;   in Loop: Header=BB13_35 Depth=1
	ldrh	w8, [sp, #38]
	add	w8, w8, #1
	strh	w8, [sp, #38]
	b	LBB13_35
LBB13_42:
	str	wzr, [sp, #32]
	b	LBB13_43
LBB13_43:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB13_61
	b	LBB13_44
LBB13_44:                               ;   in Loop: Header=BB13_43 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x11, [x8, #24]
	ldr	w8, [sp, #32]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #32]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	and	w8, w8, #0x1
	ldr	x9, [sp, #16]
	ldrb	w9, [x9]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.eq	LBB13_46
	b	LBB13_45
LBB13_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_46:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB13_48
	b	LBB13_47
LBB13_47:                               ;   in Loop: Header=BB13_43 Depth=1
	b	LBB13_60
LBB13_48:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #16
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	add	x8, x8, #16
	str	x8, [sp]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_49
LBB13_49:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_50
LBB13_50:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB13_58
	b	LBB13_51
LBB13_51:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_52
LBB13_52:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [sp]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_53
LBB13_53:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #24]
	ldr	x9, [sp]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_54
LBB13_54:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #28]
	ldr	x9, [sp]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_55
LBB13_55:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #32]
	ldr	x9, [sp]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB13_58
	b	LBB13_56
LBB13_56:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #24]
	cbz	w8, LBB13_59
	b	LBB13_57
LBB13_57:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	ldr	x8, [sp]
	ldr	x1, [x8, #16]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	bl	_memcmp
	cbz	w0, LBB13_59
	b	LBB13_58
LBB13_58:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_59:                               ;   in Loop: Header=BB13_43 Depth=1
	b	LBB13_60
LBB13_60:                               ;   in Loop: Header=BB13_43 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB13_43
LBB13_61:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_62
LBB13_62:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_state_meet_initialization ; -- Begin function nvm_affine_state_meet_initialization
	.p2align	2
_nvm_affine_state_meet_initialization:  ; @nvm_affine_state_meet_initialization
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_28
LBB14_2:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_state_equal
	tbnz	w0, #0, LBB14_4
	b	LBB14_3
LBB14_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_28
LBB14_4:
	strh	wzr, [sp, #14]
	b	LBB14_5
LBB14_5:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB14_27
	b	LBB14_6
LBB14_6:                                ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp]
	ldrb	w8, [sp, #1]
	cbnz	w8, LBB14_18
	b	LBB14_7
LBB14_7:                                ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w0, [sp]
	bl	_scalar
	tbnz	w0, #0, LBB14_13
	b	LBB14_8
LBB14_8:                                ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp]
	subs	w8, w8, #5
	b.eq	LBB14_13
	b	LBB14_9
LBB14_9:                                ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp]
	subs	w8, w8, #10
	b.eq	LBB14_12
	b	LBB14_10
LBB14_10:                               ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp]
	subs	w8, w8, #8
	b.eq	LBB14_12
	b	LBB14_11
LBB14_11:                               ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp]
	subs	w8, w8, #7
	b.ne	LBB14_18
	b	LBB14_12
LBB14_12:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	x1, [sp]
	bl	_resource
	tbnz	w0, #0, LBB14_18
	b	LBB14_13
LBB14_13:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB14_18
	b	LBB14_14
LBB14_14:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB14_18
	b	LBB14_15
LBB14_15:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldrb	w8, [sp]
	subs	w8, w8, #10
	b.ne	LBB14_17
	b	LBB14_16
LBB14_16:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB14_17
LBB14_17:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB14_18
LBB14_18:                               ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp, #1]
	cbnz	w8, LBB14_25
	b	LBB14_19
LBB14_19:                               ;   in Loop: Header=BB14_5 Depth=1
	ldrb	w8, [sp]
	subs	w8, w8, #10
	b.ne	LBB14_25
	b	LBB14_20
LBB14_20:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB14_25
	b	LBB14_21
LBB14_21:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB14_25
	b	LBB14_22
LBB14_22:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #16]
	ldrh	w10, [sp, #14]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.eq	LBB14_25
	b	LBB14_23
LBB14_23:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB14_25
	b	LBB14_24
LBB14_24:                               ;   in Loop: Header=BB14_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB14_25
LBB14_25:                               ;   in Loop: Header=BB14_5 Depth=1
	b	LBB14_26
LBB14_26:                               ;   in Loop: Header=BB14_5 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB14_5
LBB14_27:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_28
LBB14_28:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_4
	b	LBB15_1
LBB15_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_4
	b	LBB15_2
LBB15_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_4
	b	LBB15_3
LBB15_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB15_4
LBB15_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_owner_access        ; -- Begin function nvm_affine_owner_access
	.p2align	2
_nvm_affine_owner_access:               ; @nvm_affine_owner_access
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	sturb	w4, [x29, #-35]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_value_local
	tbz	w0, #0, LBB16_3
	b	LBB16_1
LBB16_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB16_3
	b	LBB16_2
LBB16_2:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldur	x2, [x29, #-32]
	ldurh	w3, [x29, #-34]
	sub	x4, x29, #44
	bl	_resolve
	tbnz	w0, #0, LBB16_4
	b	LBB16_3
LBB16_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_12
LBB16_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	str	x8, [sp, #8]
	ldurh	w8, [x29, #-18]
	strh	w8, [sp, #16]
	strh	wzr, [sp, #18]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #20]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]
	ldurh	w8, [x29, #-34]
	strh	w8, [sp, #32]
	strh	wzr, [sp, #34]
	ldur	w8, [x29, #-40]
	str	w8, [sp, #36]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #40]
	str	wzr, [sp, #44]
	str	wzr, [sp, #4]
	b	LBB16_5
LBB16_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB16_11
	b	LBB16_6
LBB16_6:                                ;   in Loop: Header=BB16_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB16_9
	b	LBB16_7
LBB16_7:                                ;   in Loop: Header=BB16_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x0, x8, #16
	ldurb	w8, [x29, #-35]
	add	x1, sp, #8
	and	w2, w8, #0x1
	bl	_nvm_reference_owner_access_conflicts
	tbz	w0, #0, LBB16_9
	b	LBB16_8
LBB16_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_12
LBB16_9:                                ;   in Loop: Header=BB16_5 Depth=1
	b	LBB16_10
LBB16_10:                               ;   in Loop: Header=BB16_5 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB16_5
LBB16_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_12
LBB16_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function value_local
_value_local:                           ; @value_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	sturh	w1, [x29, #-10]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	x8, LBB17_7
	b	LBB17_1
LBB17_1:
	ldurh	w9, [x29, #-10]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldrh	w10, [x8, #56]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ge	LBB17_7
	b	LBB17_2
LBB17_2:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-10]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB17_7
	b	LBB17_3
LBB17_3:
	ldur	x8, [x29, #-8]
	ldrb	w8, [x8, #41]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB17_6
	b	LBB17_4
LBB17_4:
	ldurh	w8, [x29, #-10]
	ldur	x9, [x29, #-8]
	ldrh	w9, [x9, #42]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.ge	LBB17_6
	b	LBB17_5
LBB17_5:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-10]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB17_6
LBB17_6:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB17_7
LBB17_7:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function resolve
_resolve:                               ; @resolve
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB18_4
	b	LBB18_1
LBB18_1:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB18_4
	b	LBB18_2
LBB18_2:
	ldurh	w8, [x29, #-34]
	cbz	w8, LBB18_5
	b	LBB18_3
LBB18_3:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB18_5
	b	LBB18_4
LBB18_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_20
LBB18_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #56]
	strh	wzr, [sp, #54]
	b	LBB18_6
LBB18_6:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #54]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.ge	LBB18_15
	b	LBB18_7
LBB18_7:                                ;   in Loop: Header=BB18_6 Depth=1
	ldrb	w8, [sp, #56]
	subs	w8, w8, #8
	b.ne	LBB18_9
	b	LBB18_8
LBB18_8:                                ;   in Loop: Header=BB18_6 Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB18_10
	b	LBB18_9
LBB18_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_20
LBB18_10:                               ;   in Loop: Header=BB18_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	cbnz	w8, LBB18_12
	b	LBB18_11
LBB18_11:                               ;   in Loop: Header=BB18_6 Depth=1
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldr	x9, [sp, #40]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB18_13
	b	LBB18_12
LBB18_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_20
LBB18_13:                               ;   in Loop: Header=BB18_6 Depth=1
	ldr	x8, [sp, #40]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #24]
	ldr	w8, [x8, #8]
	str	w8, [sp, #32]
	ldrb	w8, [sp, #24]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldr	w8, [sp, #28]
	str	w8, [sp, #20]
	ldr	x8, [sp, #16]
	str	x8, [sp, #56]
	b	LBB18_14
LBB18_14:                               ;   in Loop: Header=BB18_6 Depth=1
	ldrh	w8, [sp, #54]
	add	w8, w8, #1
	strh	w8, [sp, #54]
	b	LBB18_6
LBB18_15:
	ldur	x9, [x29, #-48]
	ldr	x8, [sp, #56]
	str	x8, [x9]
	ldrb	w0, [sp, #56]
	bl	_scalar
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB18_19
	b	LBB18_16
LBB18_16:
	ldrb	w8, [sp, #56]
	subs	w8, w8, #5
	b.ne	LBB18_18
	b	LBB18_17
LBB18_17:
	ldr	w9, [sp, #60]
	mov	w8, #1                          ; =0x1
	adds	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB18_19
	b	LBB18_18
LBB18_18:
	ldr	w8, [sp, #60]
	adds	w8, w8, #1
	cset	w8, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB18_19
LBB18_19:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_20
LBB18_20:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_scalar_define       ; -- Begin function nvm_affine_scalar_define
	.p2align	2
_nvm_affine_scalar_define:              ; @nvm_affine_scalar_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_destination
	tbz	w0, #0, LBB19_2
	b	LBB19_1
LBB19_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w0, [x8, x9]
	bl	_scalar
	tbnz	w0, #0, LBB19_3
	b	LBB19_2
LBB19_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_4
LBB19_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB19_4
LBB19_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function destination
_destination:                           ; @destination
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_value_local
	tbnz	w0, #0, LBB20_2
	b	LBB20_1
LBB20_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_9
LBB20_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB20_4
	b	LBB20_3
LBB20_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_9
LBB20_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB20_6
	b	LBB20_5
LBB20_5:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	mov	w9, #1                          ; =0x1
	eor	w8, w0, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB20_9
LBB20_6:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	tbnz	w0, #0, LBB20_8
	b	LBB20_7
LBB20_7:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB20_8
LBB20_8:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_9
LBB20_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_string_define       ; -- Begin function nvm_affine_string_define
	.p2align	2
_nvm_affine_string_define:              ; @nvm_affine_string_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_destination
	tbz	w0, #0, LBB21_3
	b	LBB21_1
LBB21_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB21_3
	b	LBB21_2
LBB21_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB21_4
	b	LBB21_3
LBB21_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_5
LBB21_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_5
LBB21_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_define        ; -- Begin function nvm_affine_union_define
	.p2align	2
_nvm_affine_union_define:               ; @nvm_affine_union_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	w2, [sp, #24]
	strh	w3, [sp, #22]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_destination
	tbz	w0, #0, LBB22_5
	b	LBB22_1
LBB22_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.ne	LBB22_5
	b	LBB22_2
LBB22_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_union_value
	tbz	w0, #0, LBB22_5
	b	LBB22_3
LBB22_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbnz	w0, #0, LBB22_5
	b	LBB22_4
LBB22_4:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	w1, [sp, #24]
	add	x2, sp, #16
	bl	_union_ordinal
	tbnz	w0, #0, LBB22_6
	b	LBB22_5
LBB22_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_11
LBB22_6:
	ldrh	w8, [sp, #22]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB22_10
	b	LBB22_7
LBB22_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #64]
	ldr	w1, [sp, #16]
	ldrh	w2, [sp, #22]
	add	x3, sp, #4
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB22_9
	b	LBB22_8
LBB22_8:
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.eq	LBB22_10
	b	LBB22_9
LBB22_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_11
LBB22_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldrh	w8, [sp, #22]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldurh	w10, [x29, #-18]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB22_11
LBB22_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_value
_union_value:                           ; @union_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-8]
	stur	x0, [x29, #-16]
	ldurb	w9, [x29, #-8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB23_5
	b	LBB23_1
LBB23_1:
	ldurb	w8, [x29, #-7]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB23_5
	b	LBB23_2
LBB23_2:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-4]
	sub	x2, x29, #20
	bl	_union_ordinal
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB23_5
	b	LBB23_3
LBB23_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #64]
	ldur	w1, [x29, #-20]
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	mov	w2, #0                          ; =0x0
	add	x3, sp, #16
	bl	_nvm_ownership_union_variant
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w0, LBB23_5
	b	LBB23_4
LBB23_4:
	ldr	w8, [sp, #16]
	ldur	w9, [x29, #-4]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB23_5
LBB23_5:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_ordinal
_union_ordinal:                         ; @union_ordinal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	str	x2, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB24_4
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB24_4
	b	LBB24_2
LBB24_2:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB24_4
	b	LBB24_3
LBB24_3:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.eq	LBB24_5
	b	LBB24_4
LBB24_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB24_12
LBB24_5:
	str	wzr, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB24_6
LBB24_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.hs	LBB24_11
	b	LBB24_7
LBB24_7:                                ;   in Loop: Header=BB24_6 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB24_9
	b	LBB24_8
LBB24_8:                                ;   in Loop: Header=BB24_6 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB24_9
LBB24_9:                                ;   in Loop: Header=BB24_6 Depth=1
	b	LBB24_10
LBB24_10:                               ;   in Loop: Header=BB24_6 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB24_6
LBB24_11:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB24_12
LBB24_12:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_refine        ; -- Begin function nvm_affine_union_refine
	.p2align	2
_nvm_affine_union_refine:               ; @nvm_affine_union_refine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_value_local
	tbz	w0, #0, LBB25_7
	b	LBB25_1
LBB25_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB25_7
	b	LBB25_2
LBB25_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_union_value
	tbz	w0, #0, LBB25_7
	b	LBB25_3
LBB25_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB25_5
	b	LBB25_4
LBB25_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB25_7
	b	LBB25_5
LBB25_5:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w1, [x8, #4]
	add	x2, sp, #24
	bl	_union_ordinal
	tbz	w0, #0, LBB25_7
	b	LBB25_6
LBB25_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #64]
	ldr	w1, [sp, #24]
	ldurh	w2, [x29, #-20]
	add	x3, sp, #12
	bl	_nvm_ownership_union_variant
	cbz	w0, LBB25_8
	b	LBB25_7
LBB25_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB25_9
LBB25_8:
	ldurh	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldurh	w10, [x29, #-18]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB25_9
LBB25_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_variant       ; -- Begin function nvm_affine_union_variant
	.p2align	2
_nvm_affine_union_variant:              ; @nvm_affine_union_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	x2, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB26_5
	b	LBB26_1
LBB26_1:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_value_local
	tbz	w0, #0, LBB26_5
	b	LBB26_2
LBB26_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB26_5
	b	LBB26_3
LBB26_3:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_union_value
	tbz	w0, #0, LBB26_5
	b	LBB26_4
LBB26_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB26_6
	b	LBB26_5
LBB26_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_7
LBB26_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_7
LBB26_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_move                ; -- Begin function nvm_affine_move
	.p2align	2
_nvm_affine_move:                       ; @nvm_affine_move
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	strh	w2, [sp, #12]
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #12]
	subs	w8, w8, w9
	b.eq	LBB27_4
	b	LBB27_1
LBB27_1:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #12]
	bl	_destination
	tbz	w0, #0, LBB27_4
	b	LBB27_2
LBB27_2:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbz	w0, #0, LBB27_4
	b	LBB27_3
LBB27_3:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x10, [x8, #40]
	ldrh	w8, [sp, #14]
	mov	x11, x8
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x10, x11, lsl #3]
	ldr	x2, [x8, x9, lsl #3]
	bl	_same
	tbnz	w0, #0, LBB27_5
	b	LBB27_4
LBB27_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_8
LBB27_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB27_7
	b	LBB27_6
LBB27_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB27_7
LBB27_7:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_8
LBB27_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_pack                ; -- Begin function nvm_affine_pack
	.p2align	2
_nvm_affine_pack:                       ; @nvm_affine_pack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	x2, [sp, #16]
	strh	w3, [sp, #14]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldr	x2, [sp, #16]
	ldrh	w3, [sp, #14]
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fields_check
	tbnz	w0, #0, LBB28_2
	b	LBB28_1
LBB28_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_9
LBB28_2:
	strh	wzr, [sp, #12]
	b	LBB28_3
LBB28_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB28_8
	b	LBB28_4
LBB28_4:                                ;   in Loop: Header=BB28_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB28_6
	b	LBB28_5
LBB28_5:                                ;   in Loop: Header=BB28_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB28_6
LBB28_6:                                ;   in Loop: Header=BB28_3 Depth=1
	b	LBB28_7
LBB28_7:                                ;   in Loop: Header=BB28_3 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB28_3
LBB28_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB28_9
LBB28_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fields_check
_fields_check:                          ; @fields_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	sturb	w4, [x29, #-35]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_value_local
	tbz	w0, #0, LBB29_3
	b	LBB29_1
LBB29_1:
	ldurh	w8, [x29, #-34]
	cbz	w8, LBB29_4
	b	LBB29_2
LBB29_2:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB29_4
	b	LBB29_3
LBB29_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-48]
	ldurb	w8, [x29, #-48]
	subs	w8, w8, #8
	b.ne	LBB29_6
	b	LBB29_5
LBB29_5:
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB29_7
	b	LBB29_6
LBB29_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	cbnz	w8, LBB29_9
	b	LBB29_8
LBB29_8:
	ldurh	w8, [x29, #-34]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.eq	LBB29_10
	b	LBB29_9
LBB29_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_10:
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB29_12
	b	LBB29_11
LBB29_11:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB29_14
	b	LBB29_13
LBB29_12:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_destination
	tbnz	w0, #0, LBB29_14
	b	LBB29_13
LBB29_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_14:
	strh	wzr, [sp, #54]
	b	LBB29_15
LBB29_15:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_21 Depth 2
	ldrh	w8, [sp, #54]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.ge	LBB29_34
	b	LBB29_16
LBB29_16:                               ;   in Loop: Header=BB29_15 Depth=1
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	strh	w8, [sp, #52]
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #54]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #40]
	ldr	w8, [x8, #8]
	str	w8, [sp, #48]
	ldrh	w8, [sp, #52]
	ldurh	w9, [x29, #-18]
	subs	w8, w8, w9
	b.eq	LBB29_19
	b	LBB29_17
LBB29_17:                               ;   in Loop: Header=BB29_15 Depth=1
	ldur	x0, [x29, #-16]
	ldrh	w1, [sp, #52]
	bl	_value_local
	tbz	w0, #0, LBB29_19
	b	LBB29_18
LBB29_18:                               ;   in Loop: Header=BB29_15 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldrb	w10, [sp, #40]
	strb	w10, [sp, #32]
	strb	wzr, [sp, #33]
	strh	wzr, [sp, #34]
	ldr	w10, [sp, #44]
	str	w10, [sp, #36]
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp, #32]
	bl	_same
	tbnz	w0, #0, LBB29_20
	b	LBB29_19
LBB29_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_20:                               ;   in Loop: Header=BB29_15 Depth=1
	strh	wzr, [sp, #30]
	b	LBB29_21
LBB29_21:                               ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #30]
	ldrh	w9, [sp, #54]
	subs	w8, w8, w9
	b.ge	LBB29_28
	b	LBB29_22
LBB29_22:                               ;   in Loop: Header=BB29_21 Depth=2
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #52]
	subs	w8, w8, w9
	b.ne	LBB29_26
	b	LBB29_23
LBB29_23:                               ;   in Loop: Header=BB29_21 Depth=2
	ldurb	w8, [x29, #-35]
	tbnz	w8, #0, LBB29_25
	b	LBB29_24
LBB29_24:                               ;   in Loop: Header=BB29_21 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB29_26
	b	LBB29_25
LBB29_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_26:                               ;   in Loop: Header=BB29_21 Depth=2
	b	LBB29_27
LBB29_27:                               ;   in Loop: Header=BB29_21 Depth=2
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB29_21
LBB29_28:                               ;   in Loop: Header=BB29_15 Depth=1
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB29_30
	b	LBB29_29
LBB29_29:                               ;   in Loop: Header=BB29_15 Depth=1
	ldur	x0, [x29, #-16]
	ldrh	w1, [sp, #52]
	bl	_destination
	tbnz	w0, #0, LBB29_32
	b	LBB29_31
LBB29_30:                               ;   in Loop: Header=BB29_15 Depth=1
	ldur	x8, [x29, #-16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldrh	w8, [sp, #52]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	mov	x4, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB29_32
	b	LBB29_31
LBB29_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_32:                               ;   in Loop: Header=BB29_15 Depth=1
	b	LBB29_33
LBB29_33:                               ;   in Loop: Header=BB29_15 Depth=1
	ldrh	w8, [sp, #54]
	add	w8, w8, #1
	strh	w8, [sp, #54]
	b	LBB29_15
LBB29_34:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB29_35
LBB29_35:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_unpack              ; -- Begin function nvm_affine_unpack
	.p2align	2
_nvm_affine_unpack:                     ; @nvm_affine_unpack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	x2, [sp, #16]
	strh	w3, [sp, #14]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldr	x2, [sp, #16]
	ldrh	w3, [sp, #14]
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_fields_check
	tbnz	w0, #0, LBB30_2
	b	LBB30_1
LBB30_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_7
LBB30_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	strh	wzr, [sp, #12]
	b	LBB30_3
LBB30_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB30_6
	b	LBB30_4
LBB30_4:                                ;   in Loop: Header=BB30_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB30_5
LBB30_5:                                ;   in Loop: Header=BB30_3 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB30_3
LBB30_6:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_7
LBB30_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_pack          ; -- Begin function nvm_affine_union_pack
	.p2align	2
_nvm_affine_union_pack:                 ; @nvm_affine_union_pack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	str	x3, [sp, #16]
	strh	w4, [sp, #14]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldurh	w2, [x29, #-20]
	ldr	x3, [sp, #16]
	ldrh	w4, [sp, #14]
	mov	w8, #0                          ; =0x0
	and	w5, w8, #0x1
	bl	_union_fields_check
	tbnz	w0, #0, LBB31_2
	b	LBB31_1
LBB31_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_9
LBB31_2:
	strh	wzr, [sp, #12]
	b	LBB31_3
LBB31_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB31_8
	b	LBB31_4
LBB31_4:                                ;   in Loop: Header=BB31_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB31_6
	b	LBB31_5
LBB31_5:                                ;   in Loop: Header=BB31_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB31_6
LBB31_6:                                ;   in Loop: Header=BB31_3 Depth=1
	b	LBB31_7
LBB31_7:                                ;   in Loop: Header=BB31_3 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB31_3
LBB31_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldurh	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #16]
	ldurh	w10, [x29, #-18]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB31_9
LBB31_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_fields_check
_union_fields_check:                    ; @union_fields_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	stur	x3, [x29, #-32]
	sturh	w4, [x29, #-34]
	sturb	w5, [x29, #-35]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_value_local
	tbz	w0, #0, LBB32_7
	b	LBB32_1
LBB32_1:
	ldurh	w8, [x29, #-34]
	cbz	w8, LBB32_3
	b	LBB32_2
LBB32_2:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB32_7
	b	LBB32_3
LBB32_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_union_value
	tbz	w0, #0, LBB32_7
	b	LBB32_4
LBB32_4:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w1, [x8, #4]
	sub	x2, x29, #40
	bl	_union_ordinal
	tbz	w0, #0, LBB32_7
	b	LBB32_5
LBB32_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #64]
	ldur	w1, [x29, #-40]
	ldurh	w2, [x29, #-20]
	sub	x3, x29, #52
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB32_7
	b	LBB32_6
LBB32_6:
	ldurh	w8, [x29, #-42]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.eq	LBB32_8
	b	LBB32_7
LBB32_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_8:
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB32_14
	b	LBB32_9
LBB32_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB32_12
	b	LBB32_10
LBB32_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB32_12
	b	LBB32_11
LBB32_11:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB32_13
	b	LBB32_12
LBB32_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_13:
	b	LBB32_17
LBB32_14:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_destination
	tbnz	w0, #0, LBB32_16
	b	LBB32_15
LBB32_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_16:
	b	LBB32_17
LBB32_17:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #48]
	strh	wzr, [sp, #46]
	b	LBB32_18
LBB32_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_24 Depth 2
	ldrh	w8, [sp, #46]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.ge	LBB32_37
	b	LBB32_19
LBB32_19:                               ;   in Loop: Header=BB32_18 Depth=1
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	strh	w8, [sp, #44]
	ldr	x8, [sp, #48]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-44]
	ldrh	w9, [sp, #46]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #32]
	ldr	w8, [x8, #8]
	str	w8, [sp, #40]
	ldrh	w8, [sp, #44]
	ldurh	w9, [x29, #-18]
	subs	w8, w8, w9
	b.eq	LBB32_22
	b	LBB32_20
LBB32_20:                               ;   in Loop: Header=BB32_18 Depth=1
	ldur	x0, [x29, #-16]
	ldrh	w1, [sp, #44]
	bl	_value_local
	tbz	w0, #0, LBB32_22
	b	LBB32_21
LBB32_21:                               ;   in Loop: Header=BB32_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldrb	w10, [sp, #32]
	strb	w10, [sp, #24]
	strb	wzr, [sp, #25]
	strh	wzr, [sp, #26]
	ldr	w10, [sp, #36]
	str	w10, [sp, #28]
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp, #24]
	bl	_same
	tbnz	w0, #0, LBB32_23
	b	LBB32_22
LBB32_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_23:                               ;   in Loop: Header=BB32_18 Depth=1
	strh	wzr, [sp, #22]
	b	LBB32_24
LBB32_24:                               ;   Parent Loop BB32_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.ge	LBB32_31
	b	LBB32_25
LBB32_25:                               ;   in Loop: Header=BB32_24 Depth=2
	ldur	x8, [x29, #-32]
	ldrh	w9, [sp, #22]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #44]
	subs	w8, w8, w9
	b.ne	LBB32_29
	b	LBB32_26
LBB32_26:                               ;   in Loop: Header=BB32_24 Depth=2
	ldurb	w8, [x29, #-35]
	tbnz	w8, #0, LBB32_28
	b	LBB32_27
LBB32_27:                               ;   in Loop: Header=BB32_24 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB32_29
	b	LBB32_28
LBB32_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_29:                               ;   in Loop: Header=BB32_24 Depth=2
	b	LBB32_30
LBB32_30:                               ;   in Loop: Header=BB32_24 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB32_24
LBB32_31:                               ;   in Loop: Header=BB32_18 Depth=1
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB32_33
	b	LBB32_32
LBB32_32:                               ;   in Loop: Header=BB32_18 Depth=1
	ldur	x0, [x29, #-16]
	ldrh	w1, [sp, #44]
	bl	_destination
	tbnz	w0, #0, LBB32_35
	b	LBB32_34
LBB32_33:                               ;   in Loop: Header=BB32_18 Depth=1
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldrh	w8, [sp, #44]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	ldr	w1, [sp, #4]                    ; 4-byte Folded Reload
	mov	x4, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB32_35
	b	LBB32_34
LBB32_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_35:                               ;   in Loop: Header=BB32_18 Depth=1
	b	LBB32_36
LBB32_36:                               ;   in Loop: Header=BB32_18 Depth=1
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB32_18
LBB32_37:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB32_38
LBB32_38:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_unpack        ; -- Begin function nvm_affine_union_unpack
	.p2align	2
_nvm_affine_union_unpack:               ; @nvm_affine_union_unpack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	str	x3, [sp, #16]
	strh	w4, [sp, #14]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldurh	w2, [x29, #-20]
	ldr	x3, [sp, #16]
	ldrh	w4, [sp, #14]
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_union_fields_check
	tbnz	w0, #0, LBB33_2
	b	LBB33_1
LBB33_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_7
LBB33_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	strh	wzr, [sp, #12]
	b	LBB33_3
LBB33_3:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB33_6
	b	LBB33_4
LBB33_4:                                ;   in Loop: Header=BB33_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #16]
	ldrh	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB33_5
LBB33_5:                                ;   in Loop: Header=BB33_3 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB33_3
LBB33_6:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_7
LBB33_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_region_begin        ; -- Begin function nvm_affine_region_begin
	.p2align	2
_nvm_affine_region_begin:               ; @nvm_affine_region_begin
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB34_2
	b	LBB34_1
LBB34_1:
	ldr	x8, [sp]
	ldr	w8, [x8, #36]
	adds	w8, w8, #1
	b.ne	LBB34_3
	b	LBB34_2
LBB34_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB34_4
LBB34_3:
	ldr	x10, [sp]
	ldr	w8, [x10, #36]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	str	w8, [x10, #36]
	and	w8, w9, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #15]
	b	LBB34_4
LBB34_4:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_region_end          ; -- Begin function nvm_affine_region_end
	.p2align	2
_nvm_affine_region_end:                 ; @nvm_affine_region_end
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB35_2
	b	LBB35_1
LBB35_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #36]
	cbnz	w8, LBB35_3
	b	LBB35_2
LBB35_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_11
LBB35_3:
	str	wzr, [sp, #12]
	b	LBB35_4
LBB35_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB35_10
	b	LBB35_5
LBB35_5:                                ;   in Loop: Header=BB35_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB35_8
	b	LBB35_6
LBB35_6:                                ;   in Loop: Header=BB35_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.ne	LBB35_8
	b	LBB35_7
LBB35_7:                                ;   in Loop: Header=BB35_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	str	x9, [sp]                        ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	mov	w1, #0                          ; =0x0
	mov	x2, #56                         ; =0x38
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB35_8
LBB35_8:                                ;   in Loop: Header=BB35_4 Depth=1
	b	LBB35_9
LBB35_9:                                ;   in Loop: Header=BB35_4 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB35_4
LBB35_10:
	ldr	x9, [sp, #16]
	ldr	w8, [x9, #36]
	subs	w8, w8, #1
	str	w8, [x9, #36]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_11
LBB35_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_borrow              ; -- Begin function nvm_affine_borrow
	.p2align	2
_nvm_affine_borrow:                     ; @nvm_affine_borrow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	stur	x3, [x29, #-32]
	sturh	w4, [x29, #-34]
	stur	w5, [x29, #-40]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-22]
	bl	_value_local
	tbz	w0, #0, LBB36_4
	b	LBB36_1
LBB36_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-22]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB36_4
	b	LBB36_2
LBB36_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-22]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #7
	b.eq	LBB36_4
	b	LBB36_3
LBB36_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-22]
	ldur	x2, [x29, #-32]
	ldurh	w3, [x29, #-34]
	sub	x4, x29, #48
	bl	_resolve
	tbnz	w0, #0, LBB36_5
	b	LBB36_4
LBB36_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_6
LBB36_5:
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	w8, [x29, #-20]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	add	x1, sp, #72
	str	x8, [sp, #72]
	ldurh	w8, [x29, #-22]
	strh	w8, [sp, #80]
	strh	wzr, [sp, #82]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-22]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #84]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #88]
	ldurh	w8, [x29, #-34]
	strh	w8, [sp, #96]
	strh	wzr, [sp, #98]
	ldur	w8, [x29, #-44]
	str	w8, [sp, #100]
	ldur	w8, [x29, #-40]
	str	w8, [sp, #104]
	str	wzr, [sp, #108]
	add	x0, sp, #32
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	mov	w3, #-1                         ; =0xffffffff
	bl	_borrow_install
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB36_6
LBB36_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_install
_borrow_install:                        ; @borrow_install
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	w3, [x29, #-36]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB37_6
	b	LBB37_1
LBB37_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #36]
	cbz	w8, LBB37_6
	b	LBB37_2
LBB37_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB37_6
	b	LBB37_3
LBB37_3:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB37_6
	b	LBB37_4
LBB37_4:
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-16]
	bl	_authoritative_root
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	mov	x1, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_nvm_reference_place_valid
	tbz	w0, #0, LBB37_6
	b	LBB37_5
LBB37_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	ldr	x0, [x9]
	mov	w9, #8                          ; =0x8
	sturb	w9, [x29, #-44]
	sturb	wzr, [x29, #-43]
	sturh	wzr, [x29, #-42]
	ldr	w8, [x8, #28]
	stur	w8, [x29, #-40]
	ldur	x1, [x29, #-44]
	bl	_resource
	tbnz	w0, #0, LBB37_7
	b	LBB37_6
LBB37_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_20
LBB37_7:
	stur	wzr, [x29, #-48]
	b	LBB37_8
LBB37_8:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-48]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB37_15
	b	LBB37_9
LBB37_9:                                ;   in Loop: Header=BB37_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB37_13
	b	LBB37_10
LBB37_10:                               ;   in Loop: Header=BB37_8 Depth=1
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-48]
	ldur	w2, [x29, #-36]
	bl	_ancestor
	tbnz	w0, #0, LBB37_13
	b	LBB37_11
LBB37_11:                               ;   in Loop: Header=BB37_8 Depth=1
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x0, x8, #16
	bl	_nvm_reference_holds_conflict
	tbz	w0, #0, LBB37_13
	b	LBB37_12
LBB37_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_20
LBB37_13:                               ;   in Loop: Header=BB37_8 Depth=1
	b	LBB37_14
LBB37_14:                               ;   in Loop: Header=BB37_8 Depth=1
	ldur	w8, [x29, #-48]
	add	w8, w8, #1
	stur	w8, [x29, #-48]
	b	LBB37_8
LBB37_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-56]
	ldrh	w8, [x8, #24]
	cbz	w8, LBB37_19
	b	LBB37_16
LBB37_16:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #1
	bl	_malloc
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB37_18
	b	LBB37_17
LBB37_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_20
LBB37_18:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-56]
	ldr	x1, [x8, #16]
	ldrh	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB37_19
LBB37_19:
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-56]
	str	x8, [x1, #16]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	add	x8, sp, #32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #32]
	add	x9, x8, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #35]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #36]
	str	w9, [sp, #36]
	ldur	w9, [x29, #-36]
	str	w9, [sp, #40]
	str	wzr, [sp, #44]
	add	x0, x8, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB37_20
LBB37_20:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_reborrow            ; -- Begin function nvm_affine_reborrow
	.p2align	2
_nvm_affine_reborrow:                   ; @nvm_affine_reborrow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	stur	w3, [x29, #-28]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB38_6
	b	LBB38_1
LBB38_1:
	ldur	w8, [x29, #-24]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB38_6
	b	LBB38_2
LBB38_2:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB38_6
	b	LBB38_3
LBB38_3:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.hs	LBB38_6
	b	LBB38_4
LBB38_4:
	ldur	w8, [x29, #-28]
	subs	w8, w8, #2
	b.ne	LBB38_7
	b	LBB38_5
LBB38_5:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #48]
	subs	w8, w8, #2
	b.eq	LBB38_7
	b	LBB38_6
LBB38_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_8
LBB38_7:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x1, x8, #16
	sub	x0, x29, #72
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w8, [x29, #-28]
	stur	w8, [x29, #-40]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	w8, [x29, #-20]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	w8, [x29, #-24]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	add	x0, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w3, [sp, #44]                   ; 4-byte Folded Reload
	bl	_borrow_install
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_8
LBB38_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_reference_access    ; -- Begin function nvm_affine_reference_access
	.p2align	2
_nvm_affine_reference_access:           ; @nvm_affine_reference_access
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB39_3
	b	LBB39_1
LBB39_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB39_3
	b	LBB39_2
LBB39_2:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB39_4
	b	LBB39_3
LBB39_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_20
LBB39_4:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]
	ldurh	w8, [x29, #-22]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB39_8
	b	LBB39_5
LBB39_5:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-22]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w0, [x8, x9]
	bl	_scalar
	tbz	w0, #0, LBB39_8
	b	LBB39_6
LBB39_6:
	ldurb	w8, [x29, #-23]
	tbz	w8, #0, LBB39_9
	b	LBB39_7
LBB39_7:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #48]
	subs	w8, w8, #2
	b.eq	LBB39_9
	b	LBB39_8
LBB39_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_20
LBB39_9:
	str	wzr, [sp, #4]
	b	LBB39_10
LBB39_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB39_19
	b	LBB39_11
LBB39_11:                               ;   in Loop: Header=BB39_10 Depth=1
	ldr	w8, [sp, #4]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB39_17
	b	LBB39_12
LBB39_12:                               ;   in Loop: Header=BB39_10 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB39_17
	b	LBB39_13
LBB39_13:                               ;   in Loop: Header=BB39_10 Depth=1
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldr	w2, [sp, #4]
	bl	_ancestor
	tbz	w0, #0, LBB39_17
	b	LBB39_14
LBB39_14:                               ;   in Loop: Header=BB39_10 Depth=1
	ldurb	w8, [x29, #-23]
	tbnz	w8, #0, LBB39_16
	b	LBB39_15
LBB39_15:                               ;   in Loop: Header=BB39_10 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #48]
	subs	w8, w8, #2
	b.ne	LBB39_17
	b	LBB39_16
LBB39_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_20
LBB39_17:                               ;   in Loop: Header=BB39_10 Depth=1
	b	LBB39_18
LBB39_18:                               ;   in Loop: Header=BB39_10 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB39_10
LBB39_19:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_20
LBB39_20:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ancestor
_ancestor:                              ; @ancestor
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB40_1
LBB40_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w9, [sp, #4]
	ldr	x8, [sp, #16]
	ldr	w10, [x8, #32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hs	LBB40_3
	b	LBB40_2
LBB40_2:                                ;   in Loop: Header=BB40_1 Depth=1
	ldr	w8, [sp, #8]
	adds	w8, w8, #1
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB40_3
LBB40_3:                                ;   in Loop: Header=BB40_1 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	tbz	w8, #0, LBB40_8
	b	LBB40_4
LBB40_4:                                ;   in Loop: Header=BB40_1 Depth=1
	ldr	w8, [sp, #8]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB40_6
	b	LBB40_5
LBB40_5:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_9
LBB40_6:                                ;   in Loop: Header=BB40_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	str	w8, [sp, #8]
	b	LBB40_7
LBB40_7:                                ;   in Loop: Header=BB40_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB40_1
LBB40_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB40_9
LBB40_9:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_reference_field     ; -- Begin function nvm_affine_reference_field
	.p2align	2
_nvm_affine_reference_field:            ; @nvm_affine_reference_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	strb	w3, [sp, #9]
	str	x4, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB41_2
	b	LBB41_1
LBB41_1:
	ldr	x0, [sp, #16]
	ldr	w1, [sp, #12]
	ldrh	w2, [sp, #10]
	ldrb	w8, [sp, #9]
	and	w3, w8, #0x1
	bl	_nvm_affine_reference_access
	tbnz	w0, #0, LBB41_3
	b	LBB41_2
LBB41_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_4
LBB41_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #56                        ; =0x38
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	ldr	x9, [sp]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB41_4
LBB41_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_can_exit            ; -- Begin function nvm_affine_can_exit
	.p2align	2
_nvm_affine_can_exit:                   ; @nvm_affine_can_exit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x8, [sp, #16]
	cbz	x8, LBB42_2
	b	LBB42_1
LBB42_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #36]
	cbz	w8, LBB42_3
	b	LBB42_2
LBB42_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_22
LBB42_3:
	ldrh	w8, [sp, #14]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB42_7
	b	LBB42_4
LBB42_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldrb	w8, [x8, #32]
	cbz	w8, LBB42_6
	b	LBB42_5
LBB42_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_22
LBB42_6:
	b	LBB42_12
LBB42_7:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_value_local
	tbz	w0, #0, LBB42_10
	b	LBB42_8
LBB42_8:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB42_10
	b	LBB42_9
LBB42_9:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [x8, #40]
	ldrh	w8, [sp, #14]
	mov	x10, x8
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x1, [x9, x10, lsl #3]
	ldr	x2, [x8, #32]
	bl	_same
	tbnz	w0, #0, LBB42_11
	b	LBB42_10
LBB42_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_22
LBB42_11:
	b	LBB42_12
LBB42_12:
	strh	wzr, [sp, #12]
	b	LBB42_13
LBB42_13:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB42_21
	b	LBB42_14
LBB42_14:                               ;   in Loop: Header=BB42_13 Depth=1
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.eq	LBB42_19
	b	LBB42_15
LBB42_15:                               ;   in Loop: Header=BB42_13 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB42_19
	b	LBB42_16
LBB42_16:                               ;   in Loop: Header=BB42_13 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB42_19
	b	LBB42_17
LBB42_17:                               ;   in Loop: Header=BB42_13 Depth=1
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB42_19
	b	LBB42_18
LBB42_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_22
LBB42_19:                               ;   in Loop: Header=BB42_13 Depth=1
	b	LBB42_20
LBB42_20:                               ;   in Loop: Header=BB42_13 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB42_13
LBB42_21:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_22
LBB42_22:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_local_info          ; -- Begin function nvm_affine_local_info
	.p2align	2
_nvm_affine_local_info:                 ; @nvm_affine_local_info
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB43_5
	b	LBB43_1
LBB43_1:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB43_5
	b	LBB43_2
LBB43_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB43_5
	b	LBB43_3
LBB43_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB43_5
	b	LBB43_4
LBB43_4:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB43_6
	b	LBB43_5
LBB43_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_14
LBB43_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp]
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbz	w8, #0, LBB43_9
	b	LBB43_7
LBB43_7:
	ldrb	w8, [sp, #1]
	cbz	w8, LBB43_9
	b	LBB43_8
LBB43_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_14
LBB43_9:
	ldrb	w8, [sp, #1]
	cbnz	w8, LBB43_13
	b	LBB43_10
LBB43_10:
	ldrb	w8, [sp]
	subs	w8, w8, #10
	b.eq	LBB43_13
	b	LBB43_11
LBB43_11:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	mov	x2, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x3, x8
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB43_13
	b	LBB43_12
LBB43_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_14
LBB43_13:
	ldrb	w8, [sp]
	ldr	x9, [sp, #16]
	strb	w8, [x9]
	ldrb	w8, [sp, #1]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_14
LBB43_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_scalar_field        ; -- Begin function nvm_affine_scalar_field
	.p2align	2
_nvm_affine_scalar_field:               ; @nvm_affine_scalar_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	str	x3, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB44_4
	b	LBB44_1
LBB44_1:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB44_4
	b	LBB44_2
LBB44_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB44_4
	b	LBB44_3
LBB44_3:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB44_5
	b	LBB44_4
LBB44_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_17
LBB44_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	ldrb	w8, [sp, #24]
	subs	w8, w8, #8
	b.ne	LBB44_7
	b	LBB44_6
LBB44_6:
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB44_8
	b	LBB44_7
LBB44_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_17
LBB44_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #16]
	ldurh	w8, [x29, #-20]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB44_10
	b	LBB44_9
LBB44_9:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w0, [x8, x9]
	bl	_scalar
	tbnz	w0, #0, LBB44_11
	b	LBB44_10
LBB44_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_17
LBB44_11:
	ldrb	w8, [sp, #25]
	cbz	w8, LBB44_13
	b	LBB44_12
LBB44_12:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	ldurh	w2, [x29, #-20]
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	bl	_nvm_affine_reference_access
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB44_14
LBB44_13:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	sub	x2, x29, #20
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB44_14
LBB44_14:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #15]
	ldrb	w8, [sp, #15]
	tbnz	w8, #0, LBB44_16
	b	LBB44_15
LBB44_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_17
LBB44_16:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	ldr	x9, [sp, #32]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_17
LBB44_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_string_field        ; -- Begin function nvm_affine_string_field
	.p2align	2
_nvm_affine_string_field:               ; @nvm_affine_string_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	str	x3, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB45_4
	b	LBB45_1
LBB45_1:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB45_4
	b	LBB45_2
LBB45_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB45_4
	b	LBB45_3
LBB45_3:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB45_5
	b	LBB45_4
LBB45_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_15
LBB45_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]
	ldrb	w8, [sp, #9]
	cbnz	w8, LBB45_8
	b	LBB45_6
LBB45_6:
	ldrb	w8, [sp, #8]
	subs	w8, w8, #8
	b.ne	LBB45_8
	b	LBB45_7
LBB45_7:
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB45_9
	b	LBB45_8
LBB45_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_15
LBB45_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp]
	ldurh	w8, [x29, #-20]
	ldr	x9, [sp]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB45_13
	b	LBB45_10
LBB45_10:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB45_13
	b	LBB45_11
LBB45_11:
	ldr	x8, [sp]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.ne	LBB45_13
	b	LBB45_12
LBB45_12:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	sub	x2, x29, #20
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB45_14
	b	LBB45_13
LBB45_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_15
LBB45_14:
	ldr	x9, [sp, #16]
	mov	w8, #5                          ; =0x5
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_15
LBB45_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_can_exit_scalar     ; -- Begin function nvm_affine_can_exit_scalar
	.p2align	2
_nvm_affine_can_exit_scalar:            ; @nvm_affine_can_exit_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strb	w1, [sp, #15]
	ldr	x8, [sp, #16]
	cbz	x8, LBB46_5
	b	LBB46_1
LBB46_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #36]
	cbnz	w8, LBB46_5
	b	LBB46_2
LBB46_2:
	ldrb	w8, [sp, #15]
	cbz	w8, LBB46_4
	b	LBB46_3
LBB46_3:
	ldrb	w0, [sp, #15]
	bl	_scalar
	tbz	w0, #0, LBB46_5
	b	LBB46_4
LBB46_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldrb	w8, [x8, #32]
	ldrb	w9, [sp, #15]
	subs	w8, w8, w9
	b.eq	LBB46_6
	b	LBB46_5
LBB46_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_15
LBB46_6:
	strh	wzr, [sp, #12]
	b	LBB46_7
LBB46_7:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB46_14
	b	LBB46_8
LBB46_8:                                ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB46_12
	b	LBB46_9
LBB46_9:                                ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB46_12
	b	LBB46_10
LBB46_10:                               ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB46_12
	b	LBB46_11
LBB46_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_15
LBB46_12:                               ;   in Loop: Header=BB46_7 Depth=1
	b	LBB46_13
LBB46_13:                               ;   in Loop: Header=BB46_7 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB46_7
LBB46_14:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB46_15
LBB46_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_local_type          ; -- Begin function nvm_affine_local_type
	.p2align	2
_nvm_affine_local_type:                 ; @nvm_affine_local_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	strh	w1, [sp, #30]
	str	x2, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB47_3
	b	LBB47_1
LBB47_1:
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB47_3
	b	LBB47_2
LBB47_2:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB47_4
	b	LBB47_3
LBB47_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB47_7
LBB47_4:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]
	ldrb	w8, [sp, #9]
	cbz	w8, LBB47_6
	b	LBB47_5
LBB47_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB47_7
LBB47_6:
	ldr	x9, [sp, #16]
	ldrb	w10, [sp, #8]
	mov	x8, sp
	strb	w10, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	w8, [sp, #12]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB47_7
LBB47_7:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_type_is_owned       ; -- Begin function nvm_affine_type_is_owned
	.p2align	2
_nvm_affine_type_is_owned:              ; @nvm_affine_type_is_owned
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	stur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB48_5
	b	LBB48_1
LBB48_1:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #7
	b.ne	LBB48_5
	b	LBB48_2
LBB48_2:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	ldurb	w8, [x29, #-12]
	strb	w8, [sp, #32]
	strb	wzr, [sp, #33]
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	strh	wzr, [sp, #34]
	ldur	w8, [x29, #-8]
	str	w8, [sp, #36]
	ldr	x1, [sp, #32]
	bl	_supported
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB48_4
	b	LBB48_3
LBB48_3:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	ldurb	w8, [x29, #-12]
	strb	w8, [sp, #24]
	strb	wzr, [sp, #25]
	strh	wzr, [sp, #26]
	ldur	w8, [x29, #-8]
	str	w8, [sp, #28]
	ldr	x1, [sp, #24]
	bl	_resource
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB48_4
LBB48_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_15
LBB48_5:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB48_8
	b	LBB48_6
LBB48_6:
	ldur	w8, [x29, #-8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB48_8
	b	LBB48_7
LBB48_7:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-8]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB48_9
	b	LBB48_8
LBB48_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_15
LBB48_9:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8]
	strb	w8, [sp, #23]
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB48_11
	b	LBB48_10
LBB48_10:
	ldrb	w8, [sp, #23]
	cbz	w8, LBB48_13
	b	LBB48_11
LBB48_11:
	ldurb	w8, [x29, #-12]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #10
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB48_14
	b	LBB48_12
LBB48_12:
	ldrb	w8, [sp, #23]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #2
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB48_14
	b	LBB48_13
LBB48_13:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	ldurb	w8, [x29, #-12]
	strb	w8, [sp, #12]
	strb	wzr, [sp, #13]
	strh	wzr, [sp, #14]
	ldur	w8, [x29, #-8]
	str	w8, [sp, #16]
	ldur	x1, [sp, #12]
	bl	_resource
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB48_14
LBB48_14:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_15
LBB48_15:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_has_array_types     ; -- Begin function nvm_affine_has_array_types
	.p2align	2
_nvm_affine_has_array_types:            ; @nvm_affine_has_array_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB49_2
	b	LBB49_1
LBB49_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB49_2
LBB49_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_types_equal         ; -- Begin function nvm_affine_types_equal
	.p2align	2
_nvm_affine_types_equal:                ; @nvm_affine_types_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-8]
	stur	x2, [x29, #-16]
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB50_2
	b	LBB50_1
LBB50_1:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldurb	w8, [x29, #-8]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldur	w8, [x29, #-4]
	str	w8, [sp, #20]
	ldurb	w8, [x29, #-16]
	strb	w8, [sp, #8]
	strb	wzr, [sp, #9]
	strh	wzr, [sp, #10]
	ldur	w8, [x29, #-12]
	str	w8, [sp, #12]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	bl	_same
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB50_2
LBB50_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_array_define        ; -- Begin function nvm_affine_array_define
	.p2align	2
_nvm_affine_array_define:               ; @nvm_affine_array_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	w2, [sp, #8]
	mov	w8, #7                          ; =0x7
	strb	w8, [sp]
	strb	wzr, [sp, #1]
	strh	wzr, [sp, #2]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]
	ldr	x8, [sp, #16]
	cbz	x8, LBB51_5
	b	LBB51_1
LBB51_1:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x1, [sp]
	bl	_supported
	tbz	w0, #0, LBB51_5
	b	LBB51_2
LBB51_2:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x1, [sp]
	bl	_resource
	tbnz	w0, #0, LBB51_5
	b	LBB51_3
LBB51_3:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_destination
	tbz	w0, #0, LBB51_5
	b	LBB51_4
LBB51_4:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp]
	bl	_same
	tbnz	w0, #0, LBB51_6
	b	LBB51_5
LBB51_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB51_7
LBB51_6:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB51_7
LBB51_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_array_element       ; -- Begin function nvm_affine_array_element
	.p2align	2
_nvm_affine_array_element:              ; @nvm_affine_array_element
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stur	x1, [sp, #36]
	str	x0, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB52_5
	b	LBB52_1
LBB52_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB52_5
	b	LBB52_2
LBB52_2:
	ldrb	w8, [sp, #36]
	subs	w8, w8, #7
	b.ne	LBB52_5
	b	LBB52_3
LBB52_3:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	cbz	x8, LBB52_5
	b	LBB52_4
LBB52_4:
	ldr	w8, [sp, #40]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB52_6
	b	LBB52_5
LBB52_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB52_7
LBB52_6:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldrb	w10, [sp, #8]
	mov	x8, sp
	strb	w10, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	w8, [sp, #12]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB52_7
LBB52_7:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_array_type          ; -- Begin function nvm_affine_array_type
	.p2align	2
_nvm_affine_array_type:                 ; @nvm_affine_array_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	stur	x0, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-24]
	cbz	x8, LBB53_3
	b	LBB53_1
LBB53_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB53_3
	b	LBB53_2
LBB53_2:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB53_4
	b	LBB53_3
LBB53_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_11
LBB53_4:
	stur	wzr, [x29, #-36]
	b	LBB53_5
LBB53_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB53_10
	b	LBB53_6
LBB53_6:                                ;   in Loop: Header=BB53_5 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	ldrb	w8, [sp, #32]
	strb	w8, [sp, #24]
	strb	wzr, [sp, #25]
	strh	wzr, [sp, #26]
	ldr	w8, [sp, #36]
	str	w8, [sp, #28]
	ldurb	w8, [x29, #-12]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldur	w8, [x29, #-8]
	str	w8, [sp, #20]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #16]
	bl	_same
	tbz	w0, #0, LBB53_8
	b	LBB53_7
LBB53_7:
	ldur	x9, [x29, #-32]
	add	x8, sp, #8
	mov	w10, #7                         ; =0x7
	strb	w10, [sp, #8]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #11]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #12]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_11
LBB53_8:                                ;   in Loop: Header=BB53_5 Depth=1
	b	LBB53_9
LBB53_9:                                ;   in Loop: Header=BB53_5 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB53_5
LBB53_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_11
LBB53_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_array_tag_type      ; -- Begin function nvm_affine_array_tag_type
	.p2align	2
_nvm_affine_array_tag_type:             ; @nvm_affine_array_tag_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB54_3
	b	LBB54_1
LBB54_1:
	ldr	x8, [sp, #32]
	cbz	x8, LBB54_3
	b	LBB54_2
LBB54_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB54_4
	b	LBB54_3
LBB54_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_16
LBB54_4:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	str	wzr, [sp, #24]
	b	LBB54_5
LBB54_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB54_13
	b	LBB54_6
LBB54_6:                                ;   in Loop: Header=BB54_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	ldurb	w9, [x29, #-17]
	subs	w8, w8, w9
	b.eq	LBB54_8
	b	LBB54_7
LBB54_7:                                ;   in Loop: Header=BB54_5 Depth=1
	b	LBB54_12
LBB54_8:                                ;   in Loop: Header=BB54_5 Depth=1
	ldr	w8, [sp, #28]
	adds	w8, w8, #1
	b.eq	LBB54_11
	b	LBB54_9
LBB54_9:                                ;   in Loop: Header=BB54_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	mov	w8, #7                          ; =0x7
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldr	w9, [sp, #28]
	str	w9, [sp, #20]
	strb	w8, [sp, #8]
	strb	wzr, [sp, #9]
	strh	wzr, [sp, #10]
	ldr	w8, [sp, #24]
	str	w8, [sp, #12]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	bl	_same
	tbnz	w0, #0, LBB54_11
	b	LBB54_10
LBB54_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_16
LBB54_11:                               ;   in Loop: Header=BB54_5 Depth=1
	ldr	w8, [sp, #24]
	str	w8, [sp, #28]
	b	LBB54_12
LBB54_12:                               ;   in Loop: Header=BB54_5 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB54_5
LBB54_13:
	ldr	w8, [sp, #28]
	adds	w8, w8, #1
	b.ne	LBB54_15
	b	LBB54_14
LBB54_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_16
LBB54_15:
	ldr	x9, [sp, #32]
	mov	x8, sp
	mov	w10, #7                         ; =0x7
	strb	w10, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	w8, [sp, #28]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_16
LBB54_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_record_is_copyable  ; -- Begin function nvm_affine_record_is_copyable
	.p2align	2
_nvm_affine_record_is_copyable:         ; @nvm_affine_record_is_copyable
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB55_4
	b	LBB55_1
LBB55_1:
	ldr	w9, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hs	LBB55_4
	b	LBB55_2
LBB55_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbnz	w8, LBB55_4
	b	LBB55_3
LBB55_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w8, w8, #0x3
	subs	w8, w8, #1
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB55_4
LBB55_4:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_record_define       ; -- Begin function nvm_affine_record_define
	.p2align	2
_nvm_affine_record_define:              ; @nvm_affine_record_define
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	w2, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	w1, [sp, #8]
	bl	_nvm_affine_record_is_copyable
	tbz	w0, #0, LBB56_4
	b	LBB56_1
LBB56_1:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_destination
	tbz	w0, #0, LBB56_4
	b	LBB56_2
LBB56_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.ne	LBB56_4
	b	LBB56_3
LBB56_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #8]
	subs	w8, w8, w9
	b.eq	LBB56_5
	b	LBB56_4
LBB56_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_6
LBB56_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB56_6
LBB56_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_owned_local_fields  ; -- Begin function nvm_affine_owned_local_fields
	.p2align	2
_nvm_affine_owned_local_fields:         ; @nvm_affine_owned_local_fields
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	str	x4, [sp, #32]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	add	x2, sp, #24
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB57_2
	b	LBB57_1
LBB57_1:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	bl	_nvm_affine_type_is_owned
	tbnz	w0, #0, LBB57_3
	b	LBB57_2
LBB57_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_10
LBB57_3:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #10
	b.ne	LBB57_7
	b	LBB57_4
LBB57_4:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	add	x2, sp, #22
	bl	_nvm_affine_union_variant
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB57_6
	b	LBB57_5
LBB57_5:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #28]
	ldrh	w2, [sp, #22]
	ldur	x3, [x29, #-32]
	ldurh	w4, [x29, #-34]
	ldr	x5, [sp, #32]
	bl	_nvm_affine_union_fields
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB57_6
LBB57_6:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_10
LBB57_7:
	ldrb	w8, [sp, #24]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB57_9
	b	LBB57_8
LBB57_8:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #28]
	ldur	x2, [x29, #-32]
	ldurh	w3, [x29, #-34]
	ldr	x4, [sp, #32]
	bl	_nvm_affine_record_fields
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB57_9
LBB57_9:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB57_10
LBB57_10:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_union_fields        ; -- Begin function nvm_affine_union_fields
	.p2align	2
_nvm_affine_union_fields:               ; @nvm_affine_union_fields
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	stur	x3, [x29, #-32]
	sturh	w4, [x29, #-34]
	str	x5, [sp, #48]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB58_8
	b	LBB58_1
LBB58_1:
	ldr	x8, [sp, #48]
	cbz	x8, LBB58_8
	b	LBB58_2
LBB58_2:
	ldurh	w8, [x29, #-34]
	cbz	w8, LBB58_4
	b	LBB58_3
LBB58_3:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB58_8
	b	LBB58_4
LBB58_4:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	w1, [x29, #-20]
	add	x2, sp, #44
	bl	_union_ordinal
	tbz	w0, #0, LBB58_8
	b	LBB58_5
LBB58_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #64]
	ldr	w1, [sp, #44]
	ldurh	w2, [x29, #-22]
	add	x3, sp, #32
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB58_8
	b	LBB58_6
LBB58_6:
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB58_8
	b	LBB58_7
LBB58_7:
	ldrh	w8, [sp, #42]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.le	LBB58_9
	b	LBB58_8
LBB58_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_14
LBB58_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	strh	wzr, [sp, #22]
	b	LBB58_10
LBB58_10:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #42]
	subs	w8, w8, w9
	b.ge	LBB58_13
	b	LBB58_11
LBB58_11:                               ;   in Loop: Header=BB58_10 Depth=1
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #40]
	ldrh	w9, [sp, #22]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldur	x9, [x29, #-32]
	ldrh	w8, [sp, #22]
	mov	x10, x8
	ldr	x8, [sp, #8]
	ldrb	w11, [x8]
	mov	x8, sp
	strb	w11, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9, x10, lsl #3]
	b	LBB58_12
LBB58_12:                               ;   in Loop: Header=BB58_10 Depth=1
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB58_10
LBB58_13:
	ldrh	w8, [sp, #42]
	ldr	x9, [sp, #48]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_14
LBB58_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_record_fields       ; -- Begin function nvm_affine_record_fields
	.p2align	2
_nvm_affine_record_fields:              ; @nvm_affine_record_fields
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x0, [sp, #64]
	str	w1, [sp, #60]
	str	x2, [sp, #48]
	strh	w3, [sp, #46]
	str	x4, [sp, #32]
	ldr	x8, [sp, #64]
	cbz	x8, LBB59_4
	b	LBB59_1
LBB59_1:
	ldr	x8, [sp, #32]
	cbz	x8, LBB59_4
	b	LBB59_2
LBB59_2:
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB59_4
	b	LBB59_3
LBB59_3:
	ldr	x8, [sp, #64]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB59_5
	b	LBB59_4
LBB59_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB59_15
LBB59_5:
	ldr	x8, [sp, #64]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbnz	w8, LBB59_9
	b	LBB59_6
LBB59_6:
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #2]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.gt	LBB59_9
	b	LBB59_7
LBB59_7:
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB59_10
	b	LBB59_8
LBB59_8:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB59_10
	b	LBB59_9
LBB59_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB59_15
LBB59_10:
	strh	wzr, [sp, #22]
	b	LBB59_11
LBB59_11:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB59_14
	b	LBB59_12
LBB59_12:                               ;   in Loop: Header=BB59_11 Depth=1
	ldr	x9, [sp, #48]
	ldrh	w8, [sp, #22]
	mov	x10, x8
	ldr	x8, [sp, #24]
	ldr	x13, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x11, #12                        ; =0xc
	mov	x12, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w12, x13
	ldrb	w12, [x8]
	add	x8, sp, #12
	strb	w12, [sp, #12]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #15]
	ldr	x8, [sp, #24]
	ldr	x12, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	ldr	w8, [x8, #4]
	str	w8, [sp, #16]
	ldur	x8, [sp, #12]
	str	x8, [x9, x10, lsl #3]
	b	LBB59_13
LBB59_13:                               ;   in Loop: Header=BB59_11 Depth=1
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB59_11
LBB59_14:
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #32]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB59_15
LBB59_15:
	ldrb	w8, [sp, #79]
	and	w0, w8, #0x1
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_take_local          ; -- Begin function nvm_affine_take_local
	.p2align	2
_nvm_affine_take_local:                 ; @nvm_affine_take_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	str	x2, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB60_5
	b	LBB60_1
LBB60_1:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	add	x2, sp, #8
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB60_5
	b	LBB60_2
LBB60_2:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #8]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB60_5
	b	LBB60_3
LBB60_3:
	ldr	w8, [sp, #12]
	adds	w8, w8, #1
	b.eq	LBB60_5
	b	LBB60_4
LBB60_4:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB60_6
	b	LBB60_5
LBB60_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_7
LBB60_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB60_7
LBB60_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_put_local           ; -- Begin function nvm_affine_put_local
	.p2align	2
_nvm_affine_put_local:                  ; @nvm_affine_put_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x2, [x29, #-12]
	stur	x0, [x29, #-24]
	sturh	w1, [x29, #-26]
	ldur	x0, [x29, #-24]
	ldurh	w1, [x29, #-26]
	add	x2, sp, #28
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB61_5
	b	LBB61_1
LBB61_1:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-12]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB61_5
	b	LBB61_2
LBB61_2:
	ldur	w8, [x29, #-8]
	adds	w8, w8, #1
	b.eq	LBB61_5
	b	LBB61_3
LBB61_3:
	ldur	x8, [x29, #-24]
	ldr	x0, [x8]
	ldrb	w8, [sp, #28]
	strb	w8, [sp, #20]
	strb	wzr, [sp, #21]
	strh	wzr, [sp, #22]
	ldr	w8, [sp, #32]
	str	w8, [sp, #24]
	ldurb	w8, [x29, #-12]
	strb	w8, [sp, #12]
	strb	wzr, [sp, #13]
	strh	wzr, [sp, #14]
	ldur	w8, [x29, #-8]
	str	w8, [sp, #16]
	ldur	x1, [sp, #20]
	ldur	x2, [sp, #12]
	bl	_same
	tbz	w0, #0, LBB61_5
	b	LBB61_4
LBB61_4:
	ldur	x0, [x29, #-24]
	ldurh	w1, [x29, #-26]
	bl	_destination
	tbnz	w0, #0, LBB61_6
	b	LBB61_5
LBB61_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB61_7
LBB61_6:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #8]
	ldurh	w9, [x29, #-26]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	ldurh	w9, [x29, #-26]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB61_7
LBB61_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_can_exit_type       ; -- Begin function nvm_affine_can_exit_type
	.p2align	2
_nvm_affine_can_exit_type:              ; @nvm_affine_can_exit_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbz	x8, LBB62_3
	b	LBB62_1
LBB62_1:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #36]
	cbnz	w8, LBB62_3
	b	LBB62_2
LBB62_2:
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldurb	w9, [x29, #-12]
	strb	w9, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	ldur	w9, [x29, #-8]
	str	w9, [sp, #20]
	ldr	x1, [x8, #32]
	ldr	x2, [sp, #16]
	bl	_same
	tbnz	w0, #0, LBB62_4
	b	LBB62_3
LBB62_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB62_13
LBB62_4:
	strh	wzr, [sp, #14]
	b	LBB62_5
LBB62_5:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB62_12
	b	LBB62_6
LBB62_6:                                ;   in Loop: Header=BB62_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB62_10
	b	LBB62_7
LBB62_7:                                ;   in Loop: Header=BB62_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB62_10
	b	LBB62_8
LBB62_8:                                ;   in Loop: Header=BB62_5 Depth=1
	ldr	x8, [sp, #24]
	ldr	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_resource
	tbz	w0, #0, LBB62_10
	b	LBB62_9
LBB62_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB62_13
LBB62_10:                               ;   in Loop: Header=BB62_5 Depth=1
	b	LBB62_11
LBB62_11:                               ;   in Loop: Header=BB62_5 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB62_5
LBB62_12:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB62_13
LBB62_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_bind_caller         ; -- Begin function nvm_affine_bind_caller
	.p2align	2
_nvm_affine_bind_caller:                ; @nvm_affine_bind_caller
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #216]
	str	x1, [sp, #208]
	str	w2, [sp, #204]
	ldr	x8, [sp, #216]
	cbz	x8, LBB63_8
	b	LBB63_1
LBB63_1:
	ldr	x8, [sp, #208]
	cbz	x8, LBB63_8
	b	LBB63_2
LBB63_2:
	ldr	x8, [sp, #216]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB63_8
	b	LBB63_3
LBB63_3:
	ldr	x8, [sp, #208]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB63_8
	b	LBB63_4
LBB63_4:
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldr	x8, [x8, #64]
	ldr	x9, [sp, #208]
	ldr	x9, [x9]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ne	LBB63_8
	b	LBB63_5
LBB63_5:
	ldr	x8, [sp, #208]
	ldr	x8, [x8]
	ldr	w8, [x8, #72]
	cbnz	w8, LBB63_8
	b	LBB63_6
LBB63_6:
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldr	w8, [x8, #72]
	subs	w8, w8, #1
	b.ne	LBB63_8
	b	LBB63_7
LBB63_7:
	ldr	x8, [sp, #216]
	ldr	w8, [x8, #36]
	cbz	w8, LBB63_9
	b	LBB63_8
LBB63_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_9:
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	strh	w8, [sp, #202]
	ldrh	w8, [sp, #202]
	cbz	w8, LBB63_14
	b	LBB63_10
LBB63_10:
	ldrh	w8, [sp, #202]
	subs	w8, w8, #8
	b.hi	LBB63_14
	b	LBB63_11
LBB63_11:
	ldrh	w8, [sp, #202]
	ldr	x9, [sp, #216]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hi	LBB63_14
	b	LBB63_12
LBB63_12:
	ldr	w8, [sp, #204]
	ldr	x9, [sp, #208]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hi	LBB63_14
	b	LBB63_13
LBB63_13:
	ldrh	w8, [sp, #202]
	ldr	x9, [sp, #208]
	ldr	w9, [x9, #32]
	ldr	w10, [sp, #204]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB63_15
	b	LBB63_14
LBB63_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_15:
	ldrh	w8, [sp, #202]
	str	w8, [sp, #196]
	b	LBB63_16
LBB63_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #196]
	ldr	x9, [sp, #216]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB63_21
	b	LBB63_17
LBB63_17:                               ;   in Loop: Header=BB63_16 Depth=1
	ldr	x8, [sp, #216]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #196]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB63_19
	b	LBB63_18
LBB63_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_19:                               ;   in Loop: Header=BB63_16 Depth=1
	b	LBB63_20
LBB63_20:                               ;   in Loop: Header=BB63_16 Depth=1
	ldr	w8, [sp, #196]
	add	w8, w8, #1
	str	w8, [sp, #196]
	b	LBB63_16
LBB63_21:
	ldrh	w8, [sp, #202]
	strh	w8, [sp, #194]
	b	LBB63_22
LBB63_22:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #194]
	ldr	x9, [sp, #216]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB63_27
	b	LBB63_23
LBB63_23:                               ;   in Loop: Header=BB63_22 Depth=1
	ldr	x8, [sp, #216]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #194]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB63_25
	b	LBB63_24
LBB63_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_25:                               ;   in Loop: Header=BB63_22 Depth=1
	b	LBB63_26
LBB63_26:                               ;   in Loop: Header=BB63_22 Depth=1
	ldrh	w8, [sp, #194]
	add	w8, w8, #1
	strh	w8, [sp, #194]
	b	LBB63_22
LBB63_27:
	strh	wzr, [sp, #192]
	b	LBB63_28
LBB63_28:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB63_38 Depth 2
                                        ;     Child Loop BB63_50 Depth 2
	ldrh	w8, [sp, #192]
	ldrh	w9, [sp, #202]
	subs	w8, w8, w9
	b.ge	LBB63_57
	b	LBB63_29
LBB63_29:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	w8, [sp, #204]
	ldrh	w9, [sp, #192]
	add	w8, w8, w9
	str	w8, [sp, #188]
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #192]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #176]
	ldr	x8, [sp, #208]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #188]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB63_31
	b	LBB63_30
LBB63_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_31:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	x8, [sp, #208]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #188]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x1, x8, #16
	add	x0, sp, #136
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #176]
	subs	w8, w8, #8
	b.ne	LBB63_36
	b	LBB63_32
LBB63_32:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrb	w8, [sp, #177]
	cbz	w8, LBB63_36
	b	LBB63_33
LBB63_33:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	w8, [sp, #180]
	ldr	w9, [sp, #164]
	subs	w8, w8, w9
	b.ne	LBB63_36
	b	LBB63_34
LBB63_34:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrb	w8, [sp, #177]
	subs	w8, w8, #2
	b.ne	LBB63_37
	b	LBB63_35
LBB63_35:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	w8, [sp, #168]
	subs	w8, w8, #2
	b.eq	LBB63_37
	b	LBB63_36
LBB63_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_37:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrb	w8, [sp, #177]
	str	w8, [sp, #168]
	str	wzr, [sp, #132]
	b	LBB63_38
LBB63_38:                               ;   Parent Loop BB63_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #132]
	ldr	x9, [sp, #208]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB63_45
	b	LBB63_39
LBB63_39:                               ;   in Loop: Header=BB63_38 Depth=2
	ldr	x8, [sp, #208]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #132]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB63_43
	b	LBB63_40
LBB63_40:                               ;   in Loop: Header=BB63_38 Depth=2
	ldr	x0, [sp, #208]
	ldr	w1, [sp, #132]
	ldr	w2, [sp, #188]
	bl	_ancestor
	tbnz	w0, #0, LBB63_43
	b	LBB63_41
LBB63_41:                               ;   in Loop: Header=BB63_38 Depth=2
	ldr	x8, [sp, #208]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #132]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x0, x8, #16
	add	x1, sp, #136
	bl	_nvm_reference_holds_conflict
	tbz	w0, #0, LBB63_43
	b	LBB63_42
LBB63_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_43:                               ;   in Loop: Header=BB63_38 Depth=2
	b	LBB63_44
LBB63_44:                               ;   in Loop: Header=BB63_38 Depth=2
	ldr	w8, [sp, #132]
	add	w8, w8, #1
	str	w8, [sp, #132]
	b	LBB63_38
LBB63_45:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	x8, [sp, #136]
	ldr	x9, [sp, #208]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB63_48
	b	LBB63_46
LBB63_46:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrh	w8, [sp, #144]
	ldr	x9, [sp, #208]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB63_48
	b	LBB63_47
LBB63_47:                               ;   in Loop: Header=BB63_28 Depth=1
	ldr	x8, [sp, #208]
	ldr	x8, [x8]
	add	x0, x8, #8
	ldr	x8, [sp, #208]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	add	x2, sp, #136
	ldrh	w9, [sp, #144]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w1, [x8, #4]
	bl	_nvm_reference_place_valid
	tbnz	w0, #0, LBB63_49
	b	LBB63_48
LBB63_48:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_49:                               ;   in Loop: Header=BB63_28 Depth=1
	strh	wzr, [sp, #130]
	b	LBB63_50
LBB63_50:                               ;   Parent Loop BB63_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #130]
	ldrh	w9, [sp, #192]
	subs	w8, w8, w9
	b.ge	LBB63_55
	b	LBB63_51
LBB63_51:                               ;   in Loop: Header=BB63_50 Depth=2
	ldrh	w8, [sp, #130]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	add	x10, sp, #296
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #136
	bl	_nvm_reference_holds_conflict
	tbz	w0, #0, LBB63_53
	b	LBB63_52
LBB63_52:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_53:                               ;   in Loop: Header=BB63_50 Depth=2
	b	LBB63_54
LBB63_54:                               ;   in Loop: Header=BB63_50 Depth=2
	ldrh	w8, [sp, #130]
	add	w8, w8, #1
	strh	w8, [sp, #130]
	b	LBB63_50
LBB63_55:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrh	w8, [sp, #192]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	add	x10, sp, #296
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #136
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB63_56
LBB63_56:                               ;   in Loop: Header=BB63_28 Depth=1
	ldrh	w8, [sp, #192]
	add	w8, w8, #1
	strh	w8, [sp, #192]
	b	LBB63_28
LBB63_57:
	add	x0, sp, #232
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	strh	wzr, [sp, #128]
	b	LBB63_58
LBB63_58:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #128]
	ldrh	w9, [sp, #202]
	subs	w8, w8, w9
	b.ge	LBB63_69
	b	LBB63_59
LBB63_59:                               ;   in Loop: Header=BB63_58 Depth=1
	ldrh	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	add	x10, sp, #296
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #24]
	cbz	w8, LBB63_67
	b	LBB63_60
LBB63_60:                               ;   in Loop: Header=BB63_58 Depth=1
	ldrh	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	add	x10, sp, #296
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #1
	bl	_malloc
	ldrh	w8, [sp, #128]
	mov	x9, x8
	add	x8, sp, #232
	str	x0, [x8, x9, lsl #3]
	ldrh	w9, [sp, #128]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB63_66
	b	LBB63_61
LBB63_61:
	strh	wzr, [sp, #126]
	b	LBB63_62
LBB63_62:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #126]
	ldrh	w9, [sp, #128]
	subs	w8, w8, w9
	b.ge	LBB63_65
	b	LBB63_63
LBB63_63:                               ;   in Loop: Header=BB63_62 Depth=1
	ldrh	w8, [sp, #126]
	mov	x9, x8
	add	x8, sp, #232
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB63_64
LBB63_64:                               ;   in Loop: Header=BB63_62 Depth=1
	ldrh	w8, [sp, #126]
	add	w8, w8, #1
	strh	w8, [sp, #126]
	b	LBB63_62
LBB63_65:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_66:                               ;   in Loop: Header=BB63_58 Depth=1
	ldrh	w8, [sp, #128]
	mov	x9, x8
	add	x8, sp, #232
	ldr	x0, [x8, x9, lsl #3]
	ldrh	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	add	x10, sp, #296
	mov	x12, x10
	mov	x11, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	ldr	x1, [x8, #16]
	ldrh	w8, [sp, #128]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #24]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB63_67
LBB63_67:                               ;   in Loop: Header=BB63_58 Depth=1
	b	LBB63_68
LBB63_68:                               ;   in Loop: Header=BB63_58 Depth=1
	ldrh	w8, [sp, #128]
	add	w8, w8, #1
	strh	w8, [sp, #128]
	b	LBB63_58
LBB63_69:
	strh	wzr, [sp, #124]
	b	LBB63_70
LBB63_70:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #124]
	ldrh	w9, [sp, #202]
	subs	w8, w8, w9
	b.ge	LBB63_73
	b	LBB63_71
LBB63_71:                               ;   in Loop: Header=BB63_70 Depth=1
	ldr	x8, [sp, #216]
	ldr	x10, [x8, #24]
	ldrh	w8, [sp, #124]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #124]
	mov	x9, x8
	add	x8, sp, #232
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #124]
	mov	x12, x9
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	add	x10, sp, #296
	str	x10, [sp, #32]                  ; 8-byte Folded Spill
	mov	x14, x10
	mov	x13, x9
                                        ; kill: def $w12 killed $w12 killed $x12
	umaddl	x12, w12, w13, x14
	str	x8, [x12, #16]
	ldr	x8, [sp, #216]
	ldr	x12, [x8, #24]
	ldrh	w8, [sp, #124]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x8, sp, #64
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w11, #1                         ; =0x1
	strb	w11, [sp, #64]
	add	x11, x8, #1
	strh	wzr, [x11]
	strb	wzr, [sp, #67]
	str	wzr, [sp, #68]
	mov	w11, #-1                        ; =0xffffffff
	str	w11, [sp, #72]
	str	wzr, [sp, #76]
	add	x0, x8, #16
	ldrh	w8, [sp, #124]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x13, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x12, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #216]
	add	x8, x8, #72
	ldrh	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	ldrh	w10, [sp, #124]
                                        ; kill: def $x10 killed $w10
	mov	x11, x12
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	x10, [x13, x10]
	str	x10, [sp, #48]
	ldrh	w10, [sp, #124]
                                        ; kill: def $x10 killed $w10
	mov	x14, x13
	mov	x11, x12
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x14
	ldrh	w10, [x10, #8]
	strh	w10, [sp, #56]
	strh	wzr, [sp, #58]
	ldr	x10, [sp, #208]
	ldr	x10, [x10]
	ldr	x10, [x10, #40]
	ldrh	w11, [sp, #124]
                                        ; kill: def $x11 killed $w11
                                        ; kill: def $w12 killed $w12 killed $x12
                                        ; kill: def $w11 killed $w11 killed $x11
	umaddl	x11, w11, w12, x13
	ldrh	w11, [x11, #8]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11, lsl #3
	ldr	w10, [x10, #4]
	str	w10, [sp, #60]
	ldr	q0, [sp, #48]
	str	q0, [x8, x9, lsl #4]
	b	LBB63_72
LBB63_72:                               ;   in Loop: Header=BB63_70 Depth=1
	ldrh	w8, [sp, #124]
	add	w8, w8, #1
	strh	w8, [sp, #124]
	b	LBB63_70
LBB63_73:
	ldrh	w8, [sp, #202]
	ldr	x9, [sp, #216]
	strh	w8, [x9, #64]
	ldr	x9, [sp, #216]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #40]
	ldr	x9, [sp, #216]
	mov	x8, #2                          ; =0x2
	str	x8, [x9, #56]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB63_74
LBB63_74:
	ldrb	w8, [sp, #231]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB63_76
	b	LBB63_75
LBB63_75:
	bl	___stack_chk_fail
LBB63_76:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #624
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_parameter_at        ; -- Begin function nvm_affine_parameter_at
	.p2align	2
_nvm_affine_parameter_at:               ; @nvm_affine_parameter_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB64_9
	b	LBB64_1
LBB64_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB64_9
	b	LBB64_2
LBB64_2:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB64_9
	b	LBB64_3
LBB64_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	cbz	w8, LBB64_9
	b	LBB64_4
LBB64_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	subs	w8, w8, #8
	b.hi	LBB64_9
	b	LBB64_5
LBB64_5:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB64_9
	b	LBB64_6
LBB64_6:
	ldurh	w8, [x29, #-18]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB64_9
	b	LBB64_7
LBB64_7:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #24]
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB64_9
	b	LBB64_8
LBB64_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB64_10
	b	LBB64_9
LBB64_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB64_14
LBB64_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #48]
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #8]
	ldurh	w8, [x29, #-18]
	strh	w8, [sp, #16]
	strh	wzr, [sp, #18]
	ldr	w8, [sp, #52]
	str	w8, [sp, #20]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	strh	wzr, [sp, #32]
	strh	wzr, [sp, #34]
	ldr	w8, [sp, #52]
	str	w8, [sp, #36]
	ldrb	w8, [sp, #49]
	str	w8, [sp, #40]
	str	wzr, [sp, #44]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	x1, [sp, #48]
	bl	_resource
	tbz	w0, #0, LBB64_12
	b	LBB64_11
LBB64_11:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x0, x8, #8
	ldr	w1, [sp, #52]
	add	x2, sp, #8
	bl	_nvm_reference_place_valid
	tbnz	w0, #0, LBB64_13
	b	LBB64_12
LBB64_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB64_14
LBB64_13:
	ldur	x9, [x29, #-32]
	ldrb	w10, [sp, #48]
	mov	x8, sp
	strb	w10, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	w8, [sp, #52]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	ldrb	w8, [sp, #49]
	ldur	x9, [x29, #-40]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB64_14
LBB64_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_value_result        ; -- Begin function nvm_affine_value_result
	.p2align	2
_nvm_affine_value_result:               ; @nvm_affine_value_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB65_3
	b	LBB65_1
LBB65_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB65_3
	b	LBB65_2
LBB65_2:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB65_4
	b	LBB65_3
LBB65_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #32]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #64]
	ldr	x10, [x8, #256]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w8, [x8, #72]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldurb	w8, [x29, #-39]
	cbnz	w8, LBB65_7
	b	LBB65_5
LBB65_5:
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #20]
	ldurb	w9, [x29, #-40]
	subs	w8, w8, w9
	b.ne	LBB65_7
	b	LBB65_6
LBB65_6:
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #21]
	ldurb	w9, [x29, #-40]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB65_8
	b	LBB65_7
LBB65_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_8:
	strh	wzr, [sp, #46]
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #8
	b.ne	LBB65_32
	b	LBB65_9
LBB65_9:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB65_11
	b	LBB65_10
LBB65_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB65_12
	b	LBB65_11
LBB65_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_12:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	cbz	w8, LBB65_14
	b	LBB65_13
LBB65_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_14:
	strb	wzr, [sp, #31]
	strh	wzr, [sp, #28]
	b	LBB65_15
LBB65_15:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB65_28
	b	LBB65_16
LBB65_16:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #32]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.eq	LBB65_18
	b	LBB65_17
LBB65_17:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB65_19
	b	LBB65_18
LBB65_18:                               ;   in Loop: Header=BB65_15 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #31]
	b	LBB65_26
LBB65_19:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.eq	LBB65_23
	b	LBB65_20
LBB65_20:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	b.eq	LBB65_23
	b	LBB65_21
LBB65_21:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB65_23
	b	LBB65_22
LBB65_22:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB65_24
	b	LBB65_23
LBB65_23:                               ;   in Loop: Header=BB65_15 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB65_25
	b	LBB65_24
LBB65_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_25:                               ;   in Loop: Header=BB65_15 Depth=1
	b	LBB65_26
LBB65_26:                               ;   in Loop: Header=BB65_15 Depth=1
	b	LBB65_27
LBB65_27:                               ;   in Loop: Header=BB65_15 Depth=1
	ldrh	w8, [sp, #28]
	add	w8, w8, #1
	strh	w8, [sp, #28]
	b	LBB65_15
LBB65_28:
	ldrb	w8, [sp, #31]
	tbz	w8, #0, LBB65_31
	b	LBB65_29
LBB65_29:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	w1, [x29, #-36]
	bl	_nested_result_tree
	tbnz	w0, #0, LBB65_31
	b	LBB65_30
LBB65_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_31:
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	strh	w8, [sp, #46]
	b	LBB65_49
LBB65_32:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #10
	b.ne	LBB65_36
	b	LBB65_33
LBB65_33:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x1, [x29, #-40]
	bl	_union_value
	tbnz	w0, #0, LBB65_35
	b	LBB65_34
LBB65_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_35:
	b	LBB65_48
LBB65_36:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #7
	b.ne	LBB65_40
	b	LBB65_37
LBB65_37:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x1, [x29, #-40]
	bl	_supported
	tbnz	w0, #0, LBB65_39
	b	LBB65_38
LBB65_38:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_39:
	b	LBB65_47
LBB65_40:
	ldurb	w8, [x29, #-40]
	cbz	w8, LBB65_44
	b	LBB65_41
LBB65_41:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #1
	b.eq	LBB65_44
	b	LBB65_42
LBB65_42:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #4
	b.eq	LBB65_44
	b	LBB65_43
LBB65_43:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #2
	b.ne	LBB65_45
	b	LBB65_44
LBB65_44:
	ldur	w8, [x29, #-36]
	adds	w8, w8, #1
	b.eq	LBB65_46
	b	LBB65_45
LBB65_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_46:
	b	LBB65_47
LBB65_47:
	b	LBB65_48
LBB65_48:
	b	LBB65_49
LBB65_49:
	ldur	x9, [x29, #-24]
	ldurb	w10, [x29, #-40]
	add	x8, sp, #8
	strb	w10, [sp, #8]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #11]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #12]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	ldrh	w8, [sp, #46]
	ldur	x9, [x29, #-32]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB65_50
LBB65_50:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nested_result_tree
_nested_result_tree:                    ; @nested_result_tree
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x1, #1                          ; =0x1
	add	x0, x8, #1
	bl	_calloc
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB66_2
	b	LBB66_1
LBB66_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB66_34
LBB66_2:
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w8, ne
	sturb	w8, [x29, #-33]
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB66_3
LBB66_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_13 Depth 2
	ldr	w8, [sp, #40]
	subs	w8, w8, #0
	b.ls	LBB66_32
	b	LBB66_4
LBB66_4:                                ;   in Loop: Header=BB66_3 Depth=1
	ldr	w8, [sp, #40]
	subs	w8, w8, #1
	str	w8, [sp, #40]
	str	w8, [sp, #36]
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbnz	w8, LBB66_6
	b	LBB66_5
LBB66_5:                                ;   in Loop: Header=BB66_3 Depth=1
	b	LBB66_3
LBB66_6:                                ;   in Loop: Header=BB66_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB66_11
	b	LBB66_7
LBB66_7:                                ;   in Loop: Header=BB66_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w8, ne
	ldurb	w9, [x29, #-33]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB66_11
	b	LBB66_8
LBB66_8:                                ;   in Loop: Header=BB66_3 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbz	w8, LBB66_10
	b	LBB66_9
LBB66_9:                                ;   in Loop: Header=BB66_3 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB66_11
	b	LBB66_10
LBB66_10:                               ;   in Loop: Header=BB66_3 Depth=1
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.ls	LBB66_12
	b	LBB66_11
LBB66_11:
	b	LBB66_33
LBB66_12:                               ;   in Loop: Header=BB66_3 Depth=1
	strh	wzr, [sp, #22]
	b	LBB66_13
LBB66_13:                               ;   Parent Loop BB66_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB66_31
	b	LBB66_14
LBB66_14:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.eq	LBB66_16
	b	LBB66_15
LBB66_15:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB66_22
	b	LBB66_16
LBB66_16:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	str	w8, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #36]
	subs	w8, w8, w9
	b.hs	LBB66_18
	b	LBB66_17
LBB66_17:                               ;   in Loop: Header=BB66_13 Depth=2
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #32
	b.lo	LBB66_19
	b	LBB66_18
LBB66_18:
	b	LBB66_33
LBB66_19:                               ;   in Loop: Header=BB66_13 Depth=2
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	add	w8, w8, #1
	strb	w8, [sp, #3]
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldrb	w9, [sp, #3]
	subs	w8, w8, w9
	b.ge	LBB66_21
	b	LBB66_20
LBB66_20:                               ;   in Loop: Header=BB66_13 Depth=2
	ldrb	w8, [sp, #3]
	ldur	x9, [x29, #-32]
	ldr	w10, [sp, #4]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB66_21
LBB66_21:                               ;   in Loop: Header=BB66_13 Depth=2
	b	LBB66_29
LBB66_22:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.eq	LBB66_26
	b	LBB66_23
LBB66_23:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	b.eq	LBB66_26
	b	LBB66_24
LBB66_24:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB66_26
	b	LBB66_25
LBB66_25:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB66_27
	b	LBB66_26
LBB66_26:                               ;   in Loop: Header=BB66_13 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB66_28
	b	LBB66_27
LBB66_27:
	b	LBB66_33
LBB66_28:                               ;   in Loop: Header=BB66_13 Depth=2
	b	LBB66_29
LBB66_29:                               ;   in Loop: Header=BB66_13 Depth=2
	b	LBB66_30
LBB66_30:                               ;   in Loop: Header=BB66_13 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB66_13
LBB66_31:                               ;   in Loop: Header=BB66_3 Depth=1
	b	LBB66_3
LBB66_32:
	ldur	x0, [x29, #-32]
	bl	_free
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB66_34
LBB66_33:
	ldur	x0, [x29, #-32]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB66_34
LBB66_34:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_value_parameters    ; -- Begin function nvm_affine_value_parameters
	.p2align	2
_nvm_affine_value_parameters:           ; @nvm_affine_value_parameters
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturh	w2, [x29, #-26]
	str	x3, [sp, #40]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB67_6
	b	LBB67_1
LBB67_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB67_6
	b	LBB67_2
LBB67_2:
	ldr	x8, [sp, #40]
	cbz	x8, LBB67_6
	b	LBB67_3
LBB67_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	subs	w8, w8, #8
	b.hi	LBB67_6
	b	LBB67_4
LBB67_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	ldurh	w9, [x29, #-26]
	subs	w8, w8, w9
	b.gt	LBB67_6
	b	LBB67_5
LBB67_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.le	LBB67_7
	b	LBB67_6
LBB67_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_7:
	strh	wzr, [sp, #38]
	b	LBB67_8
LBB67_8:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #38]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB67_39
	b	LBB67_9
LBB67_9:                                ;   in Loop: Header=BB67_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #38]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	ldrb	w8, [sp, #25]
	cbz	w8, LBB67_11
	b	LBB67_10
LBB67_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_11:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #8
	b.ne	LBB67_17
	b	LBB67_12
LBB67_12:                               ;   in Loop: Header=BB67_8 Depth=1
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB67_15
	b	LBB67_13
LBB67_13:                               ;   in Loop: Header=BB67_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB67_15
	b	LBB67_14
LBB67_14:                               ;   in Loop: Header=BB67_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB67_16
	b	LBB67_15
LBB67_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_16:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_37
LBB67_17:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #5
	b.ne	LBB67_21
	b	LBB67_18
LBB67_18:                               ;   in Loop: Header=BB67_8 Depth=1
	ldr	w8, [sp, #28]
	adds	w8, w8, #1
	b.eq	LBB67_20
	b	LBB67_19
LBB67_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_20:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_36
LBB67_21:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #10
	b.ne	LBB67_25
	b	LBB67_22
LBB67_22:                               ;   in Loop: Header=BB67_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	x1, [sp, #24]
	bl	_union_value
	tbnz	w0, #0, LBB67_24
	b	LBB67_23
LBB67_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_24:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_35
LBB67_25:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #7
	b.ne	LBB67_29
	b	LBB67_26
LBB67_26:                               ;   in Loop: Header=BB67_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	x1, [sp, #24]
	bl	_supported
	tbnz	w0, #0, LBB67_28
	b	LBB67_27
LBB67_27:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_28:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_34
LBB67_29:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #1
	b.eq	LBB67_33
	b	LBB67_30
LBB67_30:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #4
	b.eq	LBB67_33
	b	LBB67_31
LBB67_31:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #2
	b.eq	LBB67_33
	b	LBB67_32
LBB67_32:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_33:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_34
LBB67_34:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_35
LBB67_35:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_36
LBB67_36:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_37
LBB67_37:                               ;   in Loop: Header=BB67_8 Depth=1
	b	LBB67_38
LBB67_38:                               ;   in Loop: Header=BB67_8 Depth=1
	ldrh	w8, [sp, #38]
	add	w8, w8, #1
	strh	w8, [sp, #38]
	b	LBB67_8
LBB67_39:
	strh	wzr, [sp, #22]
	b	LBB67_40
LBB67_40:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #22]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB67_43
	b	LBB67_41
LBB67_41:                               ;   in Loop: Header=BB67_40 Depth=1
	ldur	x9, [x29, #-24]
	ldrh	w8, [sp, #22]
	mov	x10, x8
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w11, [sp, #22]
                                        ; kill: def $x11 killed $w11
	add	x8, x8, x11, lsl #3
	ldrb	w11, [x8]
	add	x8, sp, #12
	strb	w11, [sp, #12]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #15]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w11, [sp, #22]
                                        ; kill: def $x11 killed $w11
	add	x8, x8, x11, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #16]
	ldur	x8, [sp, #12]
	str	x8, [x9, x10, lsl #3]
	b	LBB67_42
LBB67_42:                               ;   in Loop: Header=BB67_40 Depth=1
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB67_40
LBB67_43:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	ldr	x9, [sp, #40]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_44
LBB67_44:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_consuming_parameters ; -- Begin function nvm_affine_consuming_parameters
	.p2align	2
_nvm_affine_consuming_parameters:       ; @nvm_affine_consuming_parameters
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	strh	w2, [sp, #30]
	str	x3, [sp, #16]
	strh	wzr, [sp, #14]
	ldr	x8, [sp, #32]
	cbz	x8, LBB68_4
	b	LBB68_1
LBB68_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB68_4
	b	LBB68_2
LBB68_2:
	ldr	x0, [sp, #40]
	add	x1, sp, #56
	mov	w2, #8                          ; =0x8
	add	x3, sp, #14
	bl	_nvm_affine_value_parameters
	tbz	w0, #0, LBB68_4
	b	LBB68_3
LBB68_3:
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.le	LBB68_5
	b	LBB68_4
LBB68_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #55]
	b	LBB68_14
LBB68_5:
	strb	wzr, [sp, #13]
	strh	wzr, [sp, #10]
	b	LBB68_6
LBB68_6:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ge	LBB68_11
	b	LBB68_7
LBB68_7:                                ;   in Loop: Header=BB68_6 Depth=1
	ldr	x0, [sp, #40]
	ldrh	w8, [sp, #10]
	mov	x9, x8
	add	x8, sp, #56
	ldr	x1, [x8, x9, lsl #3]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB68_9
	b	LBB68_8
LBB68_8:                                ;   in Loop: Header=BB68_6 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #13]
	b	LBB68_9
LBB68_9:                                ;   in Loop: Header=BB68_6 Depth=1
	b	LBB68_10
LBB68_10:                               ;   in Loop: Header=BB68_6 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB68_6
LBB68_11:
	ldrb	w8, [sp, #13]
	tbnz	w8, #0, LBB68_13
	b	LBB68_12
LBB68_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #55]
	b	LBB68_14
LBB68_13:
	ldr	x0, [sp, #32]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	add	x1, sp, #56
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #55]
	b	LBB68_14
LBB68_14:
	ldrb	w8, [sp, #55]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB68_16
	b	LBB68_15
LBB68_15:
	bl	___stack_chk_fail
LBB68_16:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_owned_parameter_type ; -- Begin function nvm_affine_owned_parameter_type
	.p2align	2
_nvm_affine_owned_parameter_type:       ; @nvm_affine_owned_parameter_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB69_8
	b	LBB69_1
LBB69_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB69_8
	b	LBB69_2
LBB69_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	subs	w8, w8, #1
	b.ne	LBB69_8
	b	LBB69_3
LBB69_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	cbz	w8, LBB69_8
	b	LBB69_4
LBB69_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB69_8
	b	LBB69_5
LBB69_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB69_8
	b	LBB69_6
LBB69_6:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x1, [x8]
	bl	_resource
	tbz	w0, #0, LBB69_8
	b	LBB69_7
LBB69_7:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB69_9
	b	LBB69_8
LBB69_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB69_10
LBB69_9:
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrb	w10, [x8]
	mov	x8, sp
	strb	w10, [sp]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #3]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #4]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB69_10
LBB69_10:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_parameter_type      ; -- Begin function nvm_affine_parameter_type
	.p2align	2
_nvm_affine_parameter_type:             ; @nvm_affine_parameter_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB70_3
	b	LBB70_1
LBB70_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #1
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB70_3
	b	LBB70_2
LBB70_2:
	ldur	x0, [x29, #-8]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #8]
	mov	w1, #0                          ; =0x0
	bl	_nvm_affine_parameter_at
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB70_3
LBB70_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_proof_free   ; -- Begin function nvm_mixed_samples_proof_free
	.p2align	2
_nvm_mixed_samples_proof_free:          ; @nvm_mixed_samples_proof_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB71_2
	b	LBB71_1
LBB71_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_mixed_float_proof_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB71_2
LBB71_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_analyze_mixed_samples      ; -- Begin function nvm_analyze_mixed_samples
	.p2align	2
_nvm_analyze_mixed_samples:             ; @nvm_analyze_mixed_samples
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #12640                      ; =0x3160
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #336]
	str	x1, [sp, #328]
	adrp	x8, l___const.nvm_analyze_mixed_samples.error@PAGE
	add	x8, x8, l___const.nvm_analyze_mixed_samples.error@PAGEOFF
	ldr	q0, [x8]
	str	q0, [sp, #304]
	ldr	x8, [x8, #16]
	str	x8, [sp, #320]
	ldr	x8, [sp, #328]
	cbnz	x8, LBB72_2
	b	LBB72_1
LBB72_1:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #304]
	str	q0, [x9]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB72_72
LBB72_2:
	add	x1, sp, #296
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	ldr	x0, [sp, #336]
	add	x8, sp, #272
	bl	_nvm_analyze_mixed_float_origins
	ldr	q0, [sp, #272]
	str	q0, [sp, #304]
	ldr	x8, [sp, #288]
	str	x8, [sp, #320]
	ldr	w8, [sp, #304]
	cbz	w8, LBB72_4
	b	LBB72_3
LBB72_3:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #304]
	str	q0, [x9]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB72_72
LBB72_4:
	mov	x0, #1                          ; =0x1
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x1, #49408                      ; =0xc100
	movk	x1, #6, lsl #16
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #264]
	mov	x1, #34864                      ; =0x8830
	movk	x1, #2, lsl #16
	bl	_calloc
	str	x0, [sp, #256]
	ldr	x8, [sp, #264]
	cbz	x8, LBB72_6
	b	LBB72_5
LBB72_5:
	ldr	x8, [sp, #256]
	cbnz	x8, LBB72_7
	b	LBB72_6
LBB72_6:
	ldr	x0, [sp, #264]
	bl	_free
	ldr	x0, [sp, #256]
	bl	_free
	ldr	x0, [sp, #296]
	bl	_nvm_mixed_float_proof_free
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.1@PAGE
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [x9, #16]
	b	LBB72_72
LBB72_7:
	ldr	x8, [sp, #336]
	ldr	x9, [sp, #264]
	str	x8, [x9]
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #264]
	str	x8, [x9, #8]
	ldr	x8, [sp, #296]
	ldr	x9, [sp, #256]
	str	x8, [x9]
	ldr	x8, [sp, #264]
	mov	x9, #49384                      ; =0xc0e8
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #232]
	str	wzr, [sp, #236]
	str	wzr, [sp, #240]
	str	wzr, [sp, #244]
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	str	x8, [sp, #248]
	ldur	q0, [sp, #232]
	str	q0, [x9]
	ldr	x8, [sp, #248]
	str	x8, [x9, #16]
	str	wzr, [sp, #228]
	b	LBB72_8
LBB72_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #228]
	subs	w8, w8, #256
	b.hs	LBB72_11
	b	LBB72_9
LBB72_9:                                ;   in Loop: Header=BB72_8 Depth=1
	ldr	x8, [sp, #256]
	add	x9, x8, #1068
	ldr	w8, [sp, #228]
	mov	x10, x8
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, x10, lsl #2]
	ldr	x9, [sp, #256]
	add	x9, x9, #44
	ldr	w10, [sp, #228]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	b	LBB72_10
LBB72_10:                               ;   in Loop: Header=BB72_8 Depth=1
	ldr	w8, [sp, #228]
	add	w8, w8, #1
	str	w8, [sp, #228]
	b	LBB72_8
LBB72_11:
	ldr	x0, [sp, #264]
	bl	_mc_preflight
	tbnz	w0, #0, LBB72_13
	b	LBB72_12
LBB72_12:
	b	LBB72_60
LBB72_13:
	str	wzr, [sp, #224]
	b	LBB72_14
LBB72_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB72_16 Depth 2
                                        ;     Child Loop BB72_20 Depth 2
	ldr	w8, [sp, #224]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB72_29
	b	LBB72_15
LBB72_15:                               ;   in Loop: Header=BB72_14 Depth=1
	ldr	x8, [sp, #336]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #224]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #222]
	add	x0, sp, #344
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x1, #12288                      ; =0x3000
	bl	_bzero
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #264]
	add	x11, x8, #16
	ldr	w8, [sp, #224]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8, #8]
	add	x8, sp, #192
	str	x10, [sp, #192]
	str	x9, [sp, #200]
	strh	wzr, [sp, #208]
	stur	wzr, [x8, #18]
	strh	wzr, [sp, #214]
	strh	wzr, [sp, #190]
	b	LBB72_16
LBB72_16:                               ;   Parent Loop BB72_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #190]
	ldrh	w9, [sp, #222]
	subs	w8, w8, w9
	b.ge	LBB72_19
	b	LBB72_17
LBB72_17:                               ;   in Loop: Header=BB72_16 Depth=2
	ldrh	w8, [sp, #190]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	add	x10, sp, #344
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x8, sp, #160
	mov	w0, #0                          ; =0x0
	bl	_mc_tag
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	q0, [sp, #160]
	str	q0, [x9]
	ldr	x8, [sp, #176]
	str	x8, [x9, #16]
	b	LBB72_18
LBB72_18:                               ;   in Loop: Header=BB72_16 Depth=2
	ldrh	w8, [sp, #190]
	add	w8, w8, #1
	strh	w8, [sp, #190]
	b	LBB72_16
LBB72_19:                               ;   in Loop: Header=BB72_14 Depth=1
	strh	wzr, [sp, #158]
	b	LBB72_20
LBB72_20:                               ;   Parent Loop BB72_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #158]
	ldr	x9, [sp, #336]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #224]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB72_25
	b	LBB72_21
LBB72_21:                               ;   in Loop: Header=BB72_20 Depth=2
	ldr	x0, [sp, #264]
	ldr	x1, [sp, #192]
	ldrh	w2, [sp, #158]
	bl	_mc_owned_local
	tbnz	w0, #0, LBB72_23
	b	LBB72_22
LBB72_22:                               ;   in Loop: Header=BB72_20 Depth=2
	ldrh	w8, [sp, #158]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	add	x10, sp, #344
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [sp, #192]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #158]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w0, [x8, x9]
	add	x8, sp, #128
	bl	_mc_tag
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	q0, [sp, #128]
	str	q0, [x9]
	ldr	x8, [sp, #144]
	str	x8, [x9, #16]
	b	LBB72_23
LBB72_23:                               ;   in Loop: Header=BB72_20 Depth=2
	b	LBB72_24
LBB72_24:                               ;   in Loop: Header=BB72_20 Depth=2
	ldrh	w8, [sp, #158]
	add	w8, w8, #1
	strh	w8, [sp, #158]
	b	LBB72_20
LBB72_25:                               ;   in Loop: Header=BB72_14 Depth=1
	ldr	x0, [sp, #264]
	ldr	x8, [sp, #264]
	add	x8, x8, #16
	ldr	w9, [sp, #224]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	add	x2, sp, #192
	bl	_mc_join
	tbnz	w0, #0, LBB72_27
	b	LBB72_26
LBB72_26:
	b	LBB72_60
LBB72_27:                               ;   in Loop: Header=BB72_14 Depth=1
	b	LBB72_28
LBB72_28:                               ;   in Loop: Header=BB72_14 Depth=1
	ldr	w8, [sp, #224]
	add	w8, w8, #1
	str	w8, [sp, #224]
	b	LBB72_14
LBB72_29:
	b	LBB72_30
LBB72_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #264]
	mov	x9, #49380                      ; =0xc0e4
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	cbz	w8, LBB72_38
	b	LBB72_31
LBB72_31:                               ;   in Loop: Header=BB72_30 Depth=1
	ldr	x8, [sp, #264]
	mov	x9, #32984                      ; =0x80d8
	movk	x9, #6, lsl #16
	add	x10, x8, x9
	ldr	w8, [x10]
	add	w9, w8, #1
	str	w9, [x10]
	subs	w8, w8, #64, lsl #12            ; =262144
	b.ne	LBB72_33
	b	LBB72_32
LBB72_32:
	ldr	x0, [sp, #264]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.3@PAGE
	add	x4, x4, l_.str.3@PAGEOFF
	bl	_mc_stop
	b	LBB72_60
LBB72_33:                               ;   in Loop: Header=BB72_30 Depth=1
	ldr	x8, [sp, #264]
	mov	x9, #32988                      ; =0x80dc
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	x9, [sp, #264]
	mov	x10, #49372                     ; =0xc0dc
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #124]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #264]
	str	w8, [x9, x10]
	ldr	x8, [sp, #264]
	mov	x9, #49380                      ; =0xc0e4
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #264]
	add	x10, x8, #208
	ldr	w8, [sp, #124]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #112]
	ldr	x8, [sp, #112]
	strb	wzr, [x8, #96]
	ldr	x8, [sp, #112]
	ldr	x0, [x8, #88]
	ldr	x8, [sp, #336]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #112]
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w1, [x8, #16]
	bl	_mc_frame_clone
	str	x0, [sp, #104]
	ldr	x8, [sp, #104]
	cbnz	x8, LBB72_35
	b	LBB72_34
LBB72_34:
	ldr	x0, [sp, #264]
	ldr	x8, [sp, #112]
	ldr	w2, [x8, #64]
	ldr	x8, [sp, #112]
	ldr	w3, [x8, #68]
	mov	w1, #4                          ; =0x4
	adrp	x4, l_.str.4@PAGE
	add	x4, x4, l_.str.4@PAGEOFF
	bl	_mc_stop
	b	LBB72_60
LBB72_35:                               ;   in Loop: Header=BB72_30 Depth=1
	ldr	x0, [sp, #264]
	ldr	w1, [sp, #124]
	ldr	x2, [sp, #104]
	bl	_mc_transfer
	strb	w0, [sp, #103]
	ldr	x0, [sp, #104]
	bl	_mc_frame_free
	ldrb	w8, [sp, #103]
	tbnz	w8, #0, LBB72_37
	b	LBB72_36
LBB72_36:
	b	LBB72_60
LBB72_37:                               ;   in Loop: Header=BB72_30 Depth=1
	b	LBB72_30
LBB72_38:
	str	wzr, [sp, #96]
	b	LBB72_39
LBB72_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #96]
	ldr	x9, [sp, #264]
	mov	x10, #32976                     ; =0x80d0
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB72_44
	b	LBB72_40
LBB72_40:                               ;   in Loop: Header=BB72_39 Depth=1
	ldr	x8, [sp, #264]
	add	x10, x8, #208
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #88]
	cbnz	x8, LBB72_42
	b	LBB72_41
LBB72_41:
	ldr	x0, [sp, #264]
	ldr	x8, [sp, #264]
	add	x11, x8, #208
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w2, [x8, #64]
	ldr	x8, [sp, #264]
	add	x10, x8, #208
	ldr	w8, [sp, #96]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	_mc_stop
	b	LBB72_60
LBB72_42:                               ;   in Loop: Header=BB72_39 Depth=1
	b	LBB72_43
LBB72_43:                               ;   in Loop: Header=BB72_39 Depth=1
	ldr	w8, [sp, #96]
	add	w8, w8, #1
	str	w8, [sp, #96]
	b	LBB72_39
LBB72_44:
	str	wzr, [sp, #92]
	b	LBB72_45
LBB72_45:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB72_48 Depth 2
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #296]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB72_59
	b	LBB72_46
LBB72_46:                               ;   in Loop: Header=BB72_45 Depth=1
	ldr	x8, [sp, #296]
	ldr	x8, [x8]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	subs	w8, w8, #2
	cset	w8, eq
	strb	w8, [sp, #91]
	ldr	x8, [sp, #296]
	ldr	x8, [x8]
	add	x8, x8, x9
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #3
	b.ne	LBB72_55
	b	LBB72_47
LBB72_47:                               ;   in Loop: Header=BB72_45 Depth=1
	str	wzr, [sp, #84]
	b	LBB72_48
LBB72_48:                               ;   Parent Loop BB72_45 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #84]
	ldr	x9, [sp, #296]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB72_54
	b	LBB72_49
LBB72_49:                               ;   in Loop: Header=BB72_48 Depth=2
	ldr	x8, [sp, #296]
	add	x10, x8, #28
	ldr	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #22]
	subs	w8, w8, #8
	b.ne	LBB72_52
	b	LBB72_50
LBB72_50:                               ;   in Loop: Header=BB72_48 Depth=2
	ldr	x8, [sp, #296]
	add	x10, x8, #28
	ldr	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.ne	LBB72_52
	b	LBB72_51
LBB72_51:                               ;   in Loop: Header=BB72_48 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #91]
	b	LBB72_52
LBB72_52:                               ;   in Loop: Header=BB72_48 Depth=2
	b	LBB72_53
LBB72_53:                               ;   in Loop: Header=BB72_48 Depth=2
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB72_48
LBB72_54:                               ;   in Loop: Header=BB72_45 Depth=1
	b	LBB72_55
LBB72_55:                               ;   in Loop: Header=BB72_45 Depth=1
	ldrb	w8, [sp, #91]
	tbz	w8, #0, LBB72_57
	b	LBB72_56
LBB72_56:                               ;   in Loop: Header=BB72_45 Depth=1
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #40]
	ldr	x9, [sp, #256]
	add	x9, x9, #44
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #256]
	add	x9, x9, #1068
	ldr	x12, [sp, #256]
	ldr	w10, [x12, #40]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #40]
	str	w8, [x9, x10, lsl #2]
	b	LBB72_57
LBB72_57:                               ;   in Loop: Header=BB72_45 Depth=1
	b	LBB72_58
LBB72_58:                               ;   in Loop: Header=BB72_45 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB72_45
LBB72_59:
	ldr	x8, [sp, #336]
	ldr	w8, [x8, #272]
	ldr	x9, [sp, #256]
	str	w8, [x9, #8]
	ldr	x8, [sp, #264]
	mov	x9, #32976                      ; =0x80d0
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldr	x9, [sp, #256]
	str	w8, [x9, #12]
	ldr	x8, [sp, #264]
	mov	x9, #32984                      ; =0x80d8
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldr	x9, [sp, #256]
	str	w8, [x9, #16]
	ldr	x8, [sp, #256]
	mov	x9, #34860                      ; =0x882c
	movk	x9, #2, lsl #16
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x8, [sp, #264]
	mov	x9, #49384                      ; =0xc0e8
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	str	wzr, [sp, #56]
	str	wzr, [sp, #60]
	str	wzr, [sp, #64]
	str	wzr, [sp, #68]
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	str	x8, [sp, #72]
	ldur	q0, [sp, #56]
	str	q0, [x9]
	ldr	x8, [sp, #72]
	str	x8, [x9, #16]
	b	LBB72_60
LBB72_60:
	str	wzr, [sp, #52]
	b	LBB72_61
LBB72_61:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldr	x9, [sp, #264]
	mov	x10, #32976                     ; =0x80d0
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB72_64
	b	LBB72_62
LBB72_62:                               ;   in Loop: Header=BB72_61 Depth=1
	ldr	x8, [sp, #264]
	add	x10, x8, #208
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #88]
	bl	_mc_frame_free
	b	LBB72_63
LBB72_63:                               ;   in Loop: Header=BB72_61 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB72_61
LBB72_64:
	str	wzr, [sp, #48]
	b	LBB72_65
LBB72_65:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #48]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB72_68
	b	LBB72_66
LBB72_66:                               ;   in Loop: Header=BB72_65 Depth=1
	ldr	x8, [sp, #264]
	add	x10, x8, #16
	ldr	w8, [sp, #48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #8]
	bl	_nvm_affine_state_free
	b	LBB72_67
LBB72_67:                               ;   in Loop: Header=BB72_65 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB72_65
LBB72_68:
	ldr	x8, [sp, #264]
	mov	x9, #49384                      ; =0xc0e8
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	q0, [x8]
	str	q0, [sp, #304]
	ldr	x8, [x8, #16]
	str	x8, [sp, #320]
	ldr	x0, [sp, #264]
	bl	_free
	ldr	w8, [sp, #304]
	cbnz	w8, LBB72_70
	b	LBB72_69
LBB72_69:
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #328]
	str	x8, [x9]
	b	LBB72_71
LBB72_70:
	ldr	x0, [sp, #256]
	bl	_nvm_mixed_samples_proof_free
	b	LBB72_71
LBB72_71:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #304]
	str	q0, [x9]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB72_72
LBB72_72:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB72_74
	b	LBB72_73
LBB72_73:
	bl	___stack_chk_fail
LBB72_74:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #352
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_preflight
_mc_preflight:                          ; @mc_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x9, x29, #32
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x9, #16]
	ldr	x8, [x9, #16]
	ldr	x8, [x8]
	str	x8, [x9, #8]
	ldr	x8, [x9, #16]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [x9]
	stur	wzr, [x29, #-36]
	b	LBB73_1
LBB73_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_10 Depth 2
                                        ;     Child Loop BB73_17 Depth 2
                                        ;       Child Loop BB73_46 Depth 3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-36]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB73_69
	b	LBB73_2
LBB73_2:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	ldr	x12, [x9, #256]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	stur	x9, [x29, #-48]
	ldr	x9, [x8, #16]
	add	x11, x9, #16
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	stur	x9, [x29, #-56]
	ldr	x8, [x8, #16]
	mov	x9, #32976                      ; =0x80d0
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-56]
	str	w8, [x9]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	cbz	w8, LBB73_8
	b	LBB73_3
LBB73_3:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB73_8
	b	LBB73_4
LBB73_4:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-48]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB73_8
	b	LBB73_5
LBB73_5:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB73_8
	b	LBB73_6
LBB73_6:                                ;   in Loop: Header=BB73_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #16
	b.ge	LBB73_8
	b	LBB73_7
LBB73_7:                                ;   in Loop: Header=BB73_1 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-36]
	bl	_mc_declarations
	tbnz	w0, #0, LBB73_9
	b	LBB73_8
LBB73_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_9:                                ;   in Loop: Header=BB73_1 Depth=1
	stur	wzr, [x29, #-60]
	b	LBB73_10
LBB73_10:                               ;   Parent Loop BB73_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.hs	LBB73_16
	b	LBB73_11
LBB73_11:                               ;   in Loop: Header=BB73_10 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-72]
	ldr	w10, [x10, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	subs	x8, x8, x9
	b.hs	LBB73_14
	b	LBB73_12
LBB73_12:                               ;   in Loop: Header=BB73_10 Depth=2
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-48]
	ldr	w10, [x10, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	subs	x8, x8, x9
	b.hs	LBB73_14
	b	LBB73_13
LBB73_13:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.14@PAGE
	add	x4, x4, l_.str.14@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_14:                               ;   in Loop: Header=BB73_10 Depth=2
	b	LBB73_15
LBB73_15:                               ;   in Loop: Header=BB73_10 Depth=2
	ldur	w8, [x29, #-60]
	add	w8, w8, #1
	stur	w8, [x29, #-60]
	b	LBB73_10
LBB73_16:                               ;   in Loop: Header=BB73_1 Depth=1
	stur	wzr, [x29, #-76]
	b	LBB73_17
LBB73_17:                               ;   Parent Loop BB73_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB73_46 Depth 3
	ldur	w8, [x29, #-76]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB73_67
	b	LBB73_18
LBB73_18:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #32976                      ; =0x80d0
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ne	LBB73_20
	b	LBB73_19
LBB73_19:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.15@PAGE
	add	x4, x4, l_.str.15@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_20:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	add	x11, x9, #208
	ldr	x9, [x8, #16]
	mov	x10, #32976                     ; =0x80d0
	movk	x10, #6, lsl #16
	add	x12, x9, x10
	ldr	w9, [x12]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [x12]
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	stur	x9, [x29, #-88]
	ldur	w9, [x29, #-36]
	ldur	x10, [x29, #-88]
	str	w9, [x10, #64]
	ldur	w9, [x29, #-76]
	ldur	x10, [x29, #-88]
	str	w9, [x10, #68]
	ldur	x10, [x29, #-88]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [x10, #80]
	ldur	x10, [x29, #-88]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x10, #76]
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-76]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-76]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldur	x2, [x29, #-88]
	bl	_isa_decode
	stur	w0, [x29, #-92]
	ldur	w8, [x29, #-92]
	cbnz	w8, LBB73_22
	b	LBB73_21
LBB73_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.16@PAGE
	add	x4, x4, l_.str.16@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_22:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8]
	sturb	w8, [x29, #-93]
	ldurb	w0, [x29, #-93]
	bl	_mc_supported
	tbnz	w0, #0, LBB73_24
	b	LBB73_23
LBB73_23:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.17@PAGE
	add	x4, x4, l_.str.17@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_24:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #3
	b.ne	LBB73_27
	b	LBB73_25
LBB73_25:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.le	LBB73_27
	b	LBB73_26
LBB73_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.18@PAGE
	add	x4, x4, l_.str.18@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_27:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #16
	b.eq	LBB73_32
	b	LBB73_28
LBB73_28:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #17
	b.eq	LBB73_32
	b	LBB73_29
LBB73_29:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #11
	b.eq	LBB73_32
	b	LBB73_30
LBB73_30:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #12
	b.eq	LBB73_32
	b	LBB73_31
LBB73_31:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #14
	b.ne	LBB73_34
	b	LBB73_32
LBB73_32:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.lt	LBB73_34
	b	LBB73_33
LBB73_33:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.19@PAGE
	add	x4, x4, l_.str.19@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_34:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #59
	b.ne	LBB73_39
	b	LBB73_35
LBB73_35:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-100]
	ldur	w8, [x29, #-100]
	cbz	w8, LBB73_37
	b	LBB73_36
LBB73_36:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-100]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB73_38
	b	LBB73_37
LBB73_37:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.20@PAGE
	add	x4, x4, l_.str.20@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_38:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	w9, [x29, #-100]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	and	w10, w8, #0xff
	ldur	x9, [x29, #-56]
	ldrb	w8, [x9, #16]
	orr	w8, w8, w10
	strb	w8, [x9, #16]
	b	LBB73_39
LBB73_39:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #13
	b.ne	LBB73_42
	b	LBB73_40
LBB73_40:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-88]
	ldr	w1, [x8, #8]
	bl	_mc_owned_layout
	tbnz	w0, #0, LBB73_42
	b	LBB73_41
LBB73_41:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.21@PAGE
	add	x4, x4, l_.str.21@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_42:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #251
	b.eq	LBB73_45
	b	LBB73_43
LBB73_43:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #80
	b.eq	LBB73_45
	b	LBB73_44
LBB73_44:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #88
	b.ne	LBB73_66
	b	LBB73_45
LBB73_45:                               ;   in Loop: Header=BB73_17 Depth=2
	str	wzr, [sp, #104]
	b	LBB73_46
LBB73_46:                               ;   Parent Loop BB73_1 Depth=1
                                        ;     Parent Loop BB73_17 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #104]
	ldr	x9, [x9, #16]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB73_52
	b	LBB73_47
LBB73_47:                               ;   in Loop: Header=BB73_46 Depth=3
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x10, x8, #28
	ldr	w8, [sp, #104]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #96]
	ldr	x8, [sp, #96]
	ldr	w8, [x8]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB73_50
	b	LBB73_48
LBB73_48:                               ;   in Loop: Header=BB73_46 Depth=3
	ldr	x8, [sp, #96]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-76]
	subs	w8, w8, w9
	b.ne	LBB73_50
	b	LBB73_49
LBB73_49:                               ;   in Loop: Header=BB73_46 Depth=3
	ldr	w8, [sp, #104]
	ldur	x9, [x29, #-88]
	strh	w8, [x9, #80]
	b	LBB73_50
LBB73_50:                               ;   in Loop: Header=BB73_46 Depth=3
	b	LBB73_51
LBB73_51:                               ;   in Loop: Header=BB73_46 Depth=3
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB73_46
LBB73_52:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrsh	w8, [x8, #80]
	tbz	w8, #31, LBB73_54
	b	LBB73_53
LBB73_53:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.22@PAGE
	add	x4, x4, l_.str.22@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_54:                               ;   in Loop: Header=BB73_17 Depth=2
	ldurb	w8, [x29, #-93]
	subs	w8, w8, #251
	b.ne	LBB73_62
	b	LBB73_55
LBB73_55:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #16]
	str	w8, [sp, #92]
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB73_60
	b	LBB73_56
LBB73_56:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrh	w8, [x8, #24]
	cbnz	w8, LBB73_60
	b	LBB73_57
LBB73_57:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #92]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB73_60
	b	LBB73_58
LBB73_58:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9]
	mov	x11, #24                        ; =0x18
	add	x8, x8, #24
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	ldr	x9, [x9, #16]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	add	x9, x9, #28
	ldur	x10, [x29, #-88]
	ldrsh	x10, [x10, #80]
	mul	x10, x10, x11
	add	x9, x9, x10
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB73_60
	b	LBB73_59
LBB73_59:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-88]
	mov	x11, #24                        ; =0x18
	ldrh	w8, [x8, #32]
	ldr	x9, [x9, #16]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	add	x9, x9, #28
	ldur	x10, [x29, #-88]
	ldrsh	x10, [x10, #80]
	mul	x10, x10, x11
	add	x9, x9, x10
	ldrh	w9, [x9, #20]
	subs	w8, w8, w9
	b.eq	LBB73_61
	b	LBB73_60
LBB73_60:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.23@PAGE
	add	x4, x4, l_.str.23@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_61:                               ;   in Loop: Header=BB73_17 Depth=2
	b	LBB73_65
LBB73_62:                               ;   in Loop: Header=BB73_17 Depth=2
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #3
	b.eq	LBB73_64
	b	LBB73_63
LBB73_63:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldur	w2, [x29, #-36]
	ldur	w3, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.24@PAGE
	add	x4, x4, l_.str.24@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_64:                               ;   in Loop: Header=BB73_17 Depth=2
	b	LBB73_65
LBB73_65:                               ;   in Loop: Header=BB73_17 Depth=2
	b	LBB73_66
LBB73_66:                               ;   in Loop: Header=BB73_17 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w10, [x29, #-92]
	ldur	w9, [x29, #-76]
	add	w9, w9, w10
	stur	w9, [x29, #-76]
	ldr	x8, [x8, #16]
	mov	x9, #32976                      ; =0x80d0
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-88]
	str	w8, [x9, #72]
	b	LBB73_17
LBB73_67:                               ;   in Loop: Header=BB73_1 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #32976                      ; =0x80d0
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-56]
	str	w8, [x9, #4]
	b	LBB73_68
LBB73_68:                               ;   in Loop: Header=BB73_1 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB73_1
LBB73_69:
	str	wzr, [sp, #88]
	b	LBB73_70
LBB73_70:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_72 Depth 2
                                        ;       Child Loop BB73_77 Depth 3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #88]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB73_95
	b	LBB73_71
LBB73_71:                               ;   in Loop: Header=BB73_70 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x10, x8, #16
	ldr	w8, [sp, #88]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	w8, [x8]
	str	w8, [sp, #76]
	b	LBB73_72
LBB73_72:                               ;   Parent Loop BB73_70 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB73_77 Depth 3
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB73_91
	b	LBB73_73
LBB73_73:                               ;   in Loop: Header=BB73_72 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x10, x8, #208
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	strb	w8, [sp, #63]
	ldrb	w8, [sp, #63]
	subs	w8, w8, #56
	b.eq	LBB73_76
	b	LBB73_74
LBB73_74:                               ;   in Loop: Header=BB73_72 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #57
	b.eq	LBB73_76
	b	LBB73_75
LBB73_75:                               ;   in Loop: Header=BB73_72 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #58
	b.ne	LBB73_85
	b	LBB73_76
LBB73_76:                               ;   in Loop: Header=BB73_72 Depth=2
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #68]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #64]
	ldrsw	x9, [x9, #8]
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #80]
	ldr	w8, [x8]
	str	w8, [sp, #44]
	b	LBB73_77
LBB73_77:                               ;   Parent Loop BB73_70 Depth=1
                                        ;     Parent Loop BB73_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB73_82
	b	LBB73_78
LBB73_78:                               ;   in Loop: Header=BB73_77 Depth=3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]
	ldr	x9, [x9, #16]
	add	x11, x9, #208
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #68]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB73_80
	b	LBB73_79
LBB73_79:                               ;   in Loop: Header=BB73_77 Depth=3
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #64]
	str	w8, [x9, #76]
	b	LBB73_80
LBB73_80:                               ;   in Loop: Header=BB73_77 Depth=3
	b	LBB73_81
LBB73_81:                               ;   in Loop: Header=BB73_77 Depth=3
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB73_77
LBB73_82:                               ;   in Loop: Header=BB73_72 Depth=2
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #76]
	adds	w8, w8, #1
	b.ne	LBB73_84
	b	LBB73_83
LBB73_83:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w2, [sp, #88]
	ldr	x8, [sp, #64]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.25@PAGE
	add	x4, x4, l_.str.25@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_84:                               ;   in Loop: Header=BB73_72 Depth=2
	b	LBB73_85
LBB73_85:                               ;   in Loop: Header=BB73_72 Depth=2
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #72]
	ldr	x9, [sp, #80]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB73_89
	b	LBB73_86
LBB73_86:                               ;   in Loop: Header=BB73_72 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #61
	b.eq	LBB73_89
	b	LBB73_87
LBB73_87:                               ;   in Loop: Header=BB73_72 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #56
	b.eq	LBB73_89
	b	LBB73_88
LBB73_88:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w2, [sp, #88]
	ldr	x8, [sp, #64]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.26@PAGE
	add	x4, x4, l_.str.26@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_89:                               ;   in Loop: Header=BB73_72 Depth=2
	b	LBB73_90
LBB73_90:                               ;   in Loop: Header=BB73_72 Depth=2
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB73_72
LBB73_91:                               ;   in Loop: Header=BB73_70 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	w1, [sp, #88]
	bl	_mc_graph
	tbnz	w0, #0, LBB73_93
	b	LBB73_92
LBB73_92:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_93:                               ;   in Loop: Header=BB73_70 Depth=1
	b	LBB73_94
LBB73_94:                               ;   in Loop: Header=BB73_70 Depth=1
	ldr	w8, [sp, #88]
	add	w8, w8, #1
	str	w8, [sp, #88]
	b	LBB73_70
LBB73_95:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB73_96
LBB73_96:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_tag
_mc_tag:                                ; @mc_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	mov	x9, x8
	strb	w0, [sp, #15]
	str	xzr, [x9]
	str	xzr, [x9, #8]
	str	xzr, [x9, #16]
	ldrb	w10, [sp, #15]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w10
	strh	w8, [x9]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_owned_local
_mc_owned_local:                        ; @mc_owned_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strh	w2, [sp, #14]
	ldrh	w9, [sp, #14]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldrh	w10, [x8, #56]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ge	LBB75_4
	b	LBB75_1
LBB75_1:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w8, [x8, #1]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w8, LBB75_4
	b	LBB75_2
LBB75_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #8
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB75_4
	b	LBB75_3
LBB75_3:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #14]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w1, [x8, #4]
	bl	_mc_owned_layout
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB75_4
LBB75_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_join
_mc_join:                               ; @mc_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x10, [x29, #-16]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	add	x10, x10, #208
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	sturh	w8, [x29, #-42]
	sturb	wzr, [x29, #-43]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #88]
	cbnz	x8, LBB76_6
	b	LBB76_1
LBB76_1:
	ldurh	w8, [x29, #-42]
	add	w8, w8, #256
	stur	w8, [x29, #-48]
	ldur	w8, [x29, #-48]
	ldur	x9, [x29, #-16]
	mov	x10, #32980                     ; =0x80d4
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB76_3
	b	LBB76_2
LBB76_2:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.31@PAGE
	add	x4, x4, l_.str.31@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_3:
	ldur	x0, [x29, #-32]
	ldurh	w1, [x29, #-42]
	bl	_mc_frame_clone
	ldur	x8, [x29, #-40]
	str	x0, [x8, #88]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #88]
	cbnz	x8, LBB76_5
	b	LBB76_4
LBB76_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #4                          ; =0x4
	adrp	x4, l_.str.32@PAGE
	add	x4, x4, l_.str.32@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_5:
	ldur	w10, [x29, #-48]
	ldur	x8, [x29, #-16]
	mov	x9, #32980                      ; =0x80d4
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-43]
	b	LBB76_28
LBB76_6:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #88]
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB76_8
	b	LBB76_7
LBB76_7:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.33@PAGE
	add	x4, x4, l_.str.33@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_8:
	stur	wzr, [x29, #-60]
	b	LBB76_9
LBB76_9:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-60]
	ldurh	w9, [x29, #-42]
	ldur	x10, [x29, #-56]
	ldrh	w10, [x10, #16]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB76_19
	b	LBB76_10
LBB76_10:                               ;   in Loop: Header=BB76_9 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x11, [x8, #8]
	ldur	w8, [x29, #-60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	stur	q0, [x29, #-96]
	ldr	x8, [x8, #16]
	stur	x8, [x29, #-80]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	w8, [x29, #-60]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #80]
	ldr	x8, [x8, #16]
	str	x8, [sp, #96]
	ldurb	w8, [x29, #-76]
	cbnz	w8, LBB76_12
	b	LBB76_11
LBB76_11:                               ;   in Loop: Header=BB76_9 Depth=1
	ldrb	w8, [sp, #100]
	cbz	w8, LBB76_17
	b	LBB76_12
LBB76_12:                               ;   in Loop: Header=BB76_9 Depth=1
	ldurb	w8, [x29, #-76]
	ldrb	w9, [sp, #100]
	subs	w8, w8, w9
	b.ne	LBB76_16
	b	LBB76_13
LBB76_13:                               ;   in Loop: Header=BB76_9 Depth=1
	ldurh	w8, [x29, #-96]
	ldrh	w9, [sp, #80]
	subs	w8, w8, w9
	b.ne	LBB76_16
	b	LBB76_14
LBB76_14:                               ;   in Loop: Header=BB76_9 Depth=1
	ldur	w8, [x29, #-80]
	ldr	w9, [sp, #96]
	subs	w8, w8, w9
	b.ne	LBB76_16
	b	LBB76_15
LBB76_15:                               ;   in Loop: Header=BB76_9 Depth=1
	ldurh	w8, [x29, #-94]
	ldrh	w9, [sp, #82]
	subs	w8, w8, w9
	b.eq	LBB76_17
	b	LBB76_16
LBB76_16:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.34@PAGE
	add	x4, x4, l_.str.34@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_17:                               ;   in Loop: Header=BB76_9 Depth=1
	b	LBB76_18
LBB76_18:                               ;   in Loop: Header=BB76_9 Depth=1
	ldur	w8, [x29, #-60]
	add	w8, w8, #1
	stur	w8, [x29, #-60]
	b	LBB76_9
LBB76_19:
	ldur	x8, [x29, #-56]
	ldr	x0, [x8]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8]
	sub	x2, x29, #43
	bl	_nvm_affine_state_meet_initialization
	tbnz	w0, #0, LBB76_21
	b	LBB76_20
LBB76_20:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.35@PAGE
	add	x4, x4, l_.str.35@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_21:
	str	wzr, [sp, #76]
	b	LBB76_22
LBB76_22:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldurh	w9, [x29, #-42]
	ldur	x10, [x29, #-56]
	ldrh	w10, [x10, #16]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB76_27
	b	LBB76_23
LBB76_23:                               ;   in Loop: Header=BB76_22 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x11, [x8, #8]
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #64]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #32]
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]
	ldr	x8, [sp, #64]
	ldrh	w8, [x8]
	strh	w8, [sp, #30]
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #8]
	str	x8, [sp, #16]
	ldrh	w10, [sp, #32]
	ldr	x9, [sp, #64]
	ldrh	w8, [x9]
	orr	w8, w8, w10
	strh	w8, [x9]
	ldr	x10, [sp, #40]
	ldr	x9, [sp, #64]
	ldr	x8, [x9, #8]
	orr	x8, x8, x10
	str	x8, [x9, #8]
	ldrh	w9, [sp, #30]
	ldr	x8, [sp, #64]
	ldrh	w10, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB76_25
	b	LBB76_24
LBB76_24:                               ;   in Loop: Header=BB76_22 Depth=1
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #64]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB76_25
LBB76_25:                               ;   in Loop: Header=BB76_22 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldurb	w8, [x29, #-43]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-43]
	b	LBB76_26
LBB76_26:                               ;   in Loop: Header=BB76_22 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB76_22
LBB76_27:
	b	LBB76_28
LBB76_28:
	ldurb	w8, [x29, #-43]
	tbz	w8, #0, LBB76_30
	b	LBB76_29
LBB76_29:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_mc_enqueue
	b	LBB76_30
LBB76_30:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB76_31
LBB76_31:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_stop
_mc_stop:                               ; @mc_stop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	w1, [sp, #52]
	str	w2, [sp, #48]
	str	w3, [sp, #44]
	str	x4, [sp, #32]
	ldr	x9, [sp, #56]
	ldr	w8, [sp, #52]
	str	w8, [sp, #8]
	ldr	w8, [sp, #48]
	str	w8, [sp, #12]
	ldr	w8, [sp, #44]
	str	w8, [sp, #16]
	mov	w8, #0                          ; =0x0
	str	wzr, [sp, #20]
	ldr	x10, [sp, #32]
	str	x10, [sp, #24]
	ldur	q0, [sp, #8]
	mov	x10, #49384                     ; =0xc0e8
	movk	x10, #6, lsl #16
	add	x10, x9, x10
	str	q0, [x10]
	ldr	x9, [sp, #24]
	str	x9, [x10, #16]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_frame_clone
_mc_frame_clone:                        ; @mc_frame_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	mov	x0, #1                          ; =0x1
	mov	x1, #24                         ; =0x18
	bl	_calloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB78_2
	b	LBB78_1
LBB78_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB78_6
LBB78_2:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	bl	_nvm_affine_state_clone
	ldr	x8, [sp]
	str	x0, [x8]
	ldrh	w8, [sp, #14]
	add	w8, w8, #256
	mov	w8, w8
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	ldr	x8, [sp]
	str	x0, [x8, #8]
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB78_4
	b	LBB78_3
LBB78_3:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB78_5
	b	LBB78_4
LBB78_4:
	ldr	x0, [sp]
	bl	_mc_frame_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB78_6
LBB78_5:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp]
	strh	w8, [x9, #16]
	ldr	x8, [sp]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #8]
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB78_6
LBB78_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_transfer
_mc_transfer:                           ; @mc_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3552
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #328
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #1480]
	str	w1, [sp, #1476]
	str	x2, [sp, #1464]
	ldr	x10, [sp, #1480]
	ldr	w8, [sp, #1476]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	add	x10, x10, #208
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #1456]
	ldr	x8, [sp, #1456]
	ldr	w8, [x8, #64]
	str	w8, [sp, #1452]
	ldr	x8, [sp, #1480]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #1452]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #1450]
	ldr	x8, [sp, #1464]
	ldr	x8, [x8]
	str	x8, [sp, #1440]
	ldr	x8, [sp, #1464]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #1450]
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	str	x8, [sp, #1432]
	ldr	x8, [sp, #1456]
	str	x8, [sp, #1424]
	ldr	x8, [sp, #1424]
	ldrb	w8, [x8]
	strb	w8, [sp, #1423]
	ldrb	w0, [sp, #1423]
	bl	_isa_get_info
	str	x0, [sp, #1408]
	ldr	x8, [sp, #1408]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #1404]
	ldr	x8, [sp, #1408]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #1400]
	strh	wzr, [sp, #1398]
	ldr	x8, [sp, #1424]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #1396]
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #88
	b.ne	LBB79_2
	b	LBB79_1
LBB79_1:
	ldr	x8, [sp, #1424]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #1404]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1400]
	b	LBB79_2
LBB79_2:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #251
	b.ne	LBB79_4
	b	LBB79_3
LBB79_3:
	ldr	x8, [sp, #1424]
	ldrh	w8, [x8, #32]
	str	w8, [sp, #1404]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1400]
	b	LBB79_4
LBB79_4:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #13
	b.eq	LBB79_6
	b	LBB79_5
LBB79_5:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #14
	b.ne	LBB79_19
	b	LBB79_6
LBB79_6:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #13
	b.ne	LBB79_8
	b	LBB79_7
LBB79_7:
	ldr	x8, [sp, #1424]
	ldr	w8, [x8, #8]
	str	w8, [sp, #164]                  ; 4-byte Folded Spill
	b	LBB79_9
LBB79_8:
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #1396]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #164]                  ; 4-byte Folded Spill
	b	LBB79_9
LBB79_9:
	ldr	w8, [sp, #164]                  ; 4-byte Folded Reload
	str	w8, [sp, #1392]
	ldr	x0, [sp, #1480]
	ldr	w1, [sp, #1392]
	bl	_mc_owned_layout
	tbz	w0, #0, LBB79_11
	b	LBB79_10
LBB79_10:
	ldr	x0, [sp, #1440]
	ldr	w1, [sp, #1392]
	add	x2, sp, #1496
	mov	w3, #256                        ; =0x100
	add	x4, sp, #1398
	bl	_nvm_affine_record_fields
	tbnz	w0, #0, LBB79_12
	b	LBB79_11
LBB79_11:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #160]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.36@PAGE
	add	x4, x4, l_.str.36@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #160]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_12:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #13
	b.ne	LBB79_14
	b	LBB79_13
LBB79_13:
	ldrh	w8, [sp, #1398]
	str	w8, [sp, #156]                  ; 4-byte Folded Spill
	b	LBB79_15
LBB79_14:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #156]                  ; 4-byte Folded Spill
	b	LBB79_15
LBB79_15:
	ldr	w8, [sp, #156]                  ; 4-byte Folded Reload
	str	w8, [sp, #1404]
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #13
	b.ne	LBB79_17
	b	LBB79_16
LBB79_16:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #152]                  ; 4-byte Folded Spill
	b	LBB79_18
LBB79_17:
	ldrh	w8, [sp, #1398]
	str	w8, [sp, #152]                  ; 4-byte Folded Spill
	b	LBB79_18
LBB79_18:
	ldr	w8, [sp, #152]                  ; 4-byte Folded Reload
	str	w8, [sp, #1400]
	b	LBB79_19
LBB79_19:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #59
	b.ne	LBB79_21
	b	LBB79_20
LBB79_20:
	ldr	x8, [sp, #1480]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #1424]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #1384]
	ldr	x8, [sp, #1384]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #1404]
	ldr	x8, [sp, #1384]
	ldrb	w8, [x8, #21]
	str	w8, [sp, #1400]
	b	LBB79_21
LBB79_21:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #61
	b.ne	LBB79_28
	b	LBB79_22
LBB79_22:
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #32]
	str	x8, [sp, #1376]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #1480]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #1452]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.ne	LBB79_26
	b	LBB79_23
LBB79_23:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB79_25
	b	LBB79_24
LBB79_24:
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #1432]
	ldr	q0, [x8]
	add	x1, sp, #1344
	str	q0, [sp, #1344]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1360]
	ldr	x2, [sp, #1376]
	bl	_mc_type
	tbz	w0, #0, LBB79_26
	b	LBB79_25
LBB79_25:
	ldr	x0, [sp, #1440]
	ldrb	w9, [sp, #1376]
	add	x8, sp, #1336
	strb	w9, [sp, #1336]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #1339]
	ldr	w8, [sp, #1380]
	str	w8, [sp, #1340]
	ldr	x1, [sp, #1336]
	bl	_nvm_affine_can_exit_type
	tbnz	w0, #0, LBB79_27
	b	LBB79_26
LBB79_26:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #148]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.37@PAGE
	add	x4, x4, l_.str.37@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #148]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_27:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_28:
	ldr	w8, [sp, #1404]
	tbnz	w8, #31, LBB79_31
	b	LBB79_29
LBB79_29:
	ldr	w8, [sp, #1400]
	tbnz	w8, #31, LBB79_31
	b	LBB79_30
LBB79_30:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #1404]
	subs	w8, w8, w9
	b.ge	LBB79_32
	b	LBB79_31
LBB79_31:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.38@PAGE
	add	x4, x4, l_.str.38@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_32:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #1404]
	subs	w8, w8, w9
	ldr	w9, [sp, #1400]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.ls	LBB79_34
	b	LBB79_33
LBB79_33:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.39@PAGE
	add	x4, x4, l_.str.39@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_34:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #1404]
	subs	w8, w8, w9
	strh	w8, [sp, #1334]
	str	xzr, [sp, #1296]
	str	xzr, [sp, #1304]
	str	xzr, [sp, #1312]
	ldrb	w0, [sp, #1423]
	add	x1, sp, #1295
	bl	_mc_scalar_op
	str	w0, [sp, #1288]
	ldr	w8, [sp, #1288]
	tbnz	w8, #31, LBB79_50
	b	LBB79_35
LBB79_35:
	ldrh	w8, [sp, #1334]
	strh	w8, [sp, #1286]
	b	LBB79_36
LBB79_36:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1286]
	ldr	x9, [sp, #1464]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB79_49
	b	LBB79_37
LBB79_37:                               ;   in Loop: Header=BB79_36 Depth=1
	ldrb	w8, [sp, #1295]
	subs	w8, w8, #16
	b.eq	LBB79_39
	b	LBB79_38
LBB79_38:                               ;   in Loop: Header=BB79_36 Depth=1
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1286]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x0, sp, #1248
	str	q0, [sp, #1248]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1264]
	bl	_mc_plain
	tbnz	w0, #0, LBB79_40
	b	LBB79_39
LBB79_39:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #144]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.40@PAGE
	add	x4, x4, l_.str.40@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #144]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_40:                               ;   in Loop: Header=BB79_36 Depth=1
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1286]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w1, [sp, #1295]
	ldr	q0, [x8]
	add	x0, sp, #1216
	str	q0, [sp, #1216]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1232]
	bl	_mc_exact
	tbnz	w0, #0, LBB79_47
	b	LBB79_41
LBB79_41:                               ;   in Loop: Header=BB79_36 Depth=1
	ldrb	w8, [sp, #1295]
	subs	w8, w8, #3
	b.ne	LBB79_43
	b	LBB79_42
LBB79_42:                               ;   in Loop: Header=BB79_36 Depth=1
	ldr	x8, [sp, #1432]
	ldrh	w9, [sp, #1286]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrh	w8, [x8, x9]
	subs	w8, w8, #9
	b.eq	LBB79_44
	b	LBB79_43
LBB79_43:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #140]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.41@PAGE
	add	x4, x4, l_.str.41@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_44:                               ;   in Loop: Header=BB79_36 Depth=1
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1456]
	ldrh	w8, [sp, #1286]
	ldrh	w9, [sp, #1334]
	subs	w8, w8, w9
	ldr	x9, [sp, #1432]
	ldrh	w10, [sp, #1286]
                                        ; kill: def $x10 killed $w10
	mov	x11, #24                        ; =0x18
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w3, [x9, x10]
	and	w2, w8, #0xffff
	mov	w4, #8                          ; =0x8
	mov	w5, #0                          ; =0x0
	bl	_mc_check
	tbnz	w0, #0, LBB79_46
	b	LBB79_45
LBB79_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_46:                               ;   in Loop: Header=BB79_36 Depth=1
	b	LBB79_47
LBB79_47:                               ;   in Loop: Header=BB79_36 Depth=1
	b	LBB79_48
LBB79_48:                               ;   in Loop: Header=BB79_36 Depth=1
	ldrh	w8, [sp, #1286]
	add	w8, w8, #1
	strh	w8, [sp, #1286]
	b	LBB79_36
LBB79_49:
	ldr	w9, [sp, #1288]
	add	x8, sp, #1192
	and	w0, w9, #0xff
	bl	_mc_tag
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8, #864]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #1208]
	str	x8, [sp, #1312]
	b	LBB79_195
LBB79_50:
	ldrb	w8, [sp, #1423]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB79_193
; %bb.51:
	ldr	x11, [sp, #128]                 ; 8-byte Folded Reload
	adrp	x10, lJTI79_0@PAGE
	add	x10, x10, lJTI79_0@PAGEOFF
Ltmp13:
	adr	x8, Ltmp13
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB79_52:
	b	LBB79_194
LBB79_53:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1168]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1184]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
	add	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1136]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1152]
	ldr	q0, [sp, #1168]
	add	x0, sp, #1104
	str	q0, [sp, #1104]
	ldr	x8, [sp, #1184]
	str	x8, [sp, #1120]
	bl	_mc_plain
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB79_57
	b	LBB79_54
LBB79_54:
	ldr	q0, [sp, #1136]
	add	x0, sp, #1072
	str	q0, [sp, #1072]
	ldr	x8, [sp, #1152]
	str	x8, [sp, #1088]
	bl	_mc_plain
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB79_57
	b	LBB79_55
LBB79_55:
	ldrh	w9, [sp, #1168]
	ldrh	w10, [sp, #1136]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b.ne	LBB79_57
	b	LBB79_56
LBB79_56:
	ldrh	w8, [sp, #1168]
	ldrh	w9, [sp, #1168]
	subs	w9, w9, #1
	ands	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB79_57
LBB79_57:
	ldr	w8, [sp, #124]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #1135]
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #40
	b.eq	LBB79_59
	b	LBB79_58
LBB79_58:
	ldrb	w9, [sp, #1423]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #41
	str	w8, [sp, #120]                  ; 4-byte Folded Spill
	b.ne	LBB79_63
	b	LBB79_59
LBB79_59:
	ldr	q0, [sp, #1168]
	add	x0, sp, #1040
	str	q0, [sp, #1040]
	ldr	x8, [sp, #1184]
	str	x8, [sp, #1056]
	bl	_mc_plain
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #120]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB79_63
	b	LBB79_60
LBB79_60:
	ldr	q0, [sp, #1136]
	add	x0, sp, #1008
	str	q0, [sp, #1008]
	ldr	x8, [sp, #1152]
	str	x8, [sp, #1024]
	bl	_mc_plain
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #120]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB79_63
	b	LBB79_61
LBB79_61:
	ldrh	w8, [sp, #1168]
	mov	w9, #-10                        ; =0xfffffff6
	and	w8, w8, w9
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #120]                  ; 4-byte Folded Spill
	cbnz	w8, LBB79_63
	b	LBB79_62
LBB79_62:
	ldrh	w8, [sp, #1136]
	mov	w9, #-10                        ; =0xfffffff6
	ands	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #120]                  ; 4-byte Folded Spill
	b	LBB79_63
LBB79_63:
	ldr	w8, [sp, #120]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #1071]
	ldrb	w8, [sp, #1135]
	tbnz	w8, #0, LBB79_66
	b	LBB79_64
LBB79_64:
	ldrb	w8, [sp, #1071]
	tbnz	w8, #0, LBB79_66
	b	LBB79_65
LBB79_65:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #116]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.42@PAGE
	add	x4, x4, l_.str.42@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_66:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #40
	b.eq	LBB79_70
	b	LBB79_67
LBB79_67:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #41
	b.eq	LBB79_70
	b	LBB79_68
LBB79_68:
	ldrh	w8, [sp, #1168]
	tbz	w8, #0, LBB79_70
	b	LBB79_69
LBB79_69:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #112]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.43@PAGE
	add	x4, x4, l_.str.43@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_70:
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1456]
	ldrh	w3, [sp, #1168]
	mov	w4, #0                          ; =0x0
	mov	x2, x4
	mov	w5, #1                          ; =0x1
	bl	_mc_check
	tbz	w0, #0, LBB79_72
	b	LBB79_71
LBB79_71:
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1456]
	ldrh	w3, [sp, #1136]
	mov	w5, #1                          ; =0x1
	mov	x2, x5
	mov	w4, #0                          ; =0x0
	bl	_mc_check
	tbnz	w0, #0, LBB79_73
	b	LBB79_72
LBB79_72:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_73:
	add	x8, sp, #984
	mov	w0, #4                          ; =0x4
	bl	_mc_tag
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8, #656]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #1000]
	str	x8, [sp, #1312]
	b	LBB79_194
LBB79_74:
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #20]
	cbz	w8, LBB79_76
	b	LBB79_75
LBB79_75:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #108]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.44@PAGE
	add	x4, x4, l_.str.44@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_76:
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x11, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w10, #24                        ; =0x18
	smaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x9, [sp, #1464]
	ldrh	w8, [x9, #16]
	add	w8, w8, #1
	strh	w8, [x9, #16]
	b	LBB79_198
LBB79_77:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #20]
	cbz	w8, LBB79_79
	b	LBB79_78
LBB79_78:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #104]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.45@PAGE
	add	x4, x4, l_.str.45@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #104]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_79:
	b	LBB79_194
LBB79_80:
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1296]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1312]
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w10, #24                        ; =0x18
	smaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #24                         ; =0x18
	smaddl	x9, w8, w9, x10
	ldr	q0, [sp, #1296]
	str	q0, [x9]
	ldr	x8, [sp, #1312]
	str	x8, [x9, #16]
	b	LBB79_198
LBB79_81:
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1296]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1312]
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w10, #24                        ; =0x18
	smaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #24                         ; =0x18
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #3
	mov	w10, #24                        ; =0x18
	smaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #3
	mov	w9, #24                         ; =0x18
	smaddl	x9, w8, w9, x10
	ldr	q0, [sp, #1296]
	str	q0, [x9]
	ldr	x8, [sp, #1312]
	str	x8, [x9, #16]
	b	LBB79_198
LBB79_82:
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #1396]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #976]
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1440]
	ldrh	w2, [sp, #1396]
	bl	_mc_owned_local
	tbz	w0, #0, LBB79_88
	b	LBB79_83
LBB79_83:
	ldr	x0, [sp, #1440]
	ldrh	w1, [sp, #1396]
	add	x2, sp, #975
	add	x3, sp, #974
	bl	_nvm_affine_local_info
	tbz	w0, #0, LBB79_86
	b	LBB79_84
LBB79_84:
	ldrb	w8, [sp, #975]
	subs	w8, w8, #8
	b.ne	LBB79_86
	b	LBB79_85
LBB79_85:
	ldrb	w8, [sp, #974]
	cbz	w8, LBB79_87
	b	LBB79_86
LBB79_86:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #100]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.46@PAGE
	add	x4, x4, l_.str.46@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_87:
	ldr	w0, [sp, #980]
	add	x8, sp, #944
	bl	_mc_owner
	ldr	q0, [sp, #944]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #960]
	str	x8, [sp, #1312]
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #1316]
	ldrh	w8, [sp, #1396]
	strh	w8, [sp, #1298]
	b	LBB79_91
LBB79_88:
	ldr	x8, [sp, #1464]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #1396]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1296]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1312]
	ldr	x0, [sp, #1480]
	ldrb	w2, [sp, #976]
	ldr	w3, [sp, #980]
	ldr	q0, [sp, #1296]
	add	x1, sp, #912
	str	q0, [sp, #912]
	ldr	x8, [sp, #1312]
	str	x8, [sp, #928]
	bl	_mc_field
	tbnz	w0, #0, LBB79_90
	b	LBB79_89
LBB79_89:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #96]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.47@PAGE
	add	x4, x4, l_.str.47@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_90:
	b	LBB79_91
LBB79_91:
	b	LBB79_194
LBB79_92:
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #1396]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #904]
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1440]
	ldrh	w2, [sp, #1396]
	bl	_mc_owned_local
	tbnz	w0, #0, LBB79_94
	b	LBB79_93
LBB79_93:
	ldr	x0, [sp, #1480]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w2, [sp, #904]
	ldr	w3, [sp, #908]
	ldr	q0, [x8]
	add	x1, sp, #880
	str	q0, [sp, #880]
	ldr	x8, [x8, #16]
	str	x8, [sp, #896]
	bl	_mc_field
	tbnz	w0, #0, LBB79_95
	b	LBB79_94
LBB79_94:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #92]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.48@PAGE
	add	x4, x4, l_.str.48@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #92]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_95:
	ldrb	w0, [sp, #904]
	bl	_scalar
	tbz	w0, #0, LBB79_98
	b	LBB79_96
LBB79_96:
	ldr	x0, [sp, #1440]
	ldrh	w1, [sp, #1396]
	bl	_nvm_affine_scalar_define
	tbnz	w0, #0, LBB79_98
	b	LBB79_97
LBB79_97:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #88]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.49@PAGE
	add	x4, x4, l_.str.49@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_98:
	ldr	x8, [sp, #1464]
	ldr	x11, [x8, #8]
	ldrh	w8, [sp, #1396]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x11
	ldr	x11, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	b	LBB79_194
LBB79_99:
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1440]
	ldrh	w2, [sp, #1396]
	bl	_mc_owned_local
	tbz	w0, #0, LBB79_102
	b	LBB79_100
LBB79_100:
	ldr	x0, [sp, #1464]
	ldrh	w1, [sp, #1450]
	ldrh	w2, [sp, #1396]
	bl	_mc_observed
	tbnz	w0, #0, LBB79_102
	b	LBB79_101
LBB79_101:
	ldr	x0, [sp, #1440]
	ldrh	w1, [sp, #1396]
	add	x2, sp, #872
	bl	_nvm_affine_take_local
	tbnz	w0, #0, LBB79_103
	b	LBB79_102
LBB79_102:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #84]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.50@PAGE
	add	x4, x4, l_.str.50@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_103:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #11
	b.ne	LBB79_105
	b	LBB79_104
LBB79_104:
	ldr	w0, [sp, #876]
	add	x8, sp, #848
	bl	_mc_owner
	ldr	q0, [sp, #848]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #864]
	str	x8, [sp, #1312]
	b	LBB79_110
LBB79_105:
	strh	wzr, [sp, #846]
	b	LBB79_106
LBB79_106:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #846]
	ldrh	w9, [sp, #1398]
	subs	w8, w8, w9
	b.ge	LBB79_109
	b	LBB79_107
LBB79_107:                              ;   in Loop: Header=BB79_106 Depth=1
	ldr	x10, [sp, #1432]
	ldr	x11, [sp, #1464]
	ldrh	w8, [x11, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x11, #16]
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldrh	w8, [sp, #846]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #1496
	ldrb	w0, [x8, x9]
	add	x8, sp, #816
	bl	_mc_tag
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #816]
	str	q0, [x9]
	ldr	x8, [sp, #832]
	str	x8, [x9, #16]
	b	LBB79_108
LBB79_108:                              ;   in Loop: Header=BB79_106 Depth=1
	ldrh	w8, [sp, #846]
	add	w8, w8, #1
	strh	w8, [sp, #846]
	b	LBB79_106
LBB79_109:
	b	LBB79_198
LBB79_110:
	b	LBB79_194
LBB79_111:
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1440]
	ldrh	w2, [sp, #1396]
	bl	_mc_owned_local
	tbz	w0, #0, LBB79_114
	b	LBB79_112
LBB79_112:
	ldr	x0, [sp, #1480]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #1396]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [x10]
	add	x1, sp, #784
	str	q0, [sp, #784]
	ldr	x10, [x10, #16]
	str	x10, [sp, #800]
	ldr	x2, [x8, x9, lsl #3]
	bl	_mc_type
	tbz	w0, #0, LBB79_114
	b	LBB79_113
LBB79_113:
	ldr	x0, [sp, #1440]
	ldrh	w1, [sp, #1396]
	add	x8, sp, #776
	mov	w9, #8                          ; =0x8
	strb	w9, [sp, #776]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #779]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #16]
	str	w8, [sp, #780]
	ldr	x2, [sp, #776]
	bl	_nvm_affine_put_local
	tbnz	w0, #0, LBB79_115
	b	LBB79_114
LBB79_114:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #68]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.51@PAGE
	add	x4, x4, l_.str.51@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_115:
	b	LBB79_194
LBB79_116:
	strh	wzr, [sp, #774]
	b	LBB79_117
LBB79_117:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #774]
	ldrh	w9, [sp, #1398]
	subs	w8, w8, w9
	b.ge	LBB79_122
	b	LBB79_118
LBB79_118:                              ;   in Loop: Header=BB79_117 Depth=1
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
	ldrh	w9, [sp, #774]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldrh	w9, [sp, #774]
                                        ; kill: def $x9 killed $w9
	lsl	x10, x9, #3
	add	x9, sp, #1496
	ldrb	w1, [x9, x10]
	ldr	q0, [x8]
	add	x0, sp, #736
	str	q0, [sp, #736]
	ldr	x8, [x8, #16]
	str	x8, [sp, #752]
	bl	_mc_exact
	tbnz	w0, #0, LBB79_120
	b	LBB79_119
LBB79_119:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #64]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.52@PAGE
	add	x4, x4, l_.str.52@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_120:                              ;   in Loop: Header=BB79_117 Depth=1
	b	LBB79_121
LBB79_121:                              ;   in Loop: Header=BB79_117 Depth=1
	ldrh	w8, [sp, #774]
	add	w8, w8, #1
	strh	w8, [sp, #774]
	b	LBB79_117
LBB79_122:
	ldr	x8, [sp, #1424]
	ldr	w0, [x8, #8]
	add	x8, sp, #712
	bl	_mc_owner
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8, #384]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #728]
	str	x8, [sp, #1312]
	b	LBB79_194
LBB79_123:
	ldr	x8, [sp, #1480]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x8, x8, #28
	ldr	x9, [sp, #1456]
	ldrsh	x9, [x9, #80]
	mov	x10, #24                        ; =0x18
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #704]
	ldr	x8, [sp, #1480]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x9, [sp, #704]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #696]
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #704]
	ldr	w1, [x8, #8]
	bl	_mc_owned_layout
	tbz	w0, #0, LBB79_125
	b	LBB79_124
LBB79_124:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #60]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.53@PAGE
	add	x4, x4, l_.str.53@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_125:
	strh	wzr, [sp, #694]
	b	LBB79_126
LBB79_126:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #694]
	ldr	x9, [sp, #704]
	ldrh	w9, [x9, #20]
	subs	w8, w8, w9
	b.ge	LBB79_133
	b	LBB79_127
LBB79_127:                              ;   in Loop: Header=BB79_126 Depth=1
	ldr	x8, [sp, #1480]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #1568]
	ldr	x9, [sp, #704]
	ldr	w9, [x9, #16]
	ldrh	w10, [sp, #694]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #4
	str	x8, [sp, #680]
	ldr	x8, [sp, #696]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #694]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #672]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
	ldrh	w9, [sp, #694]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #640]
	ldr	x8, [x8, #16]
	str	x8, [sp, #656]
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #672]
	ldrb	w2, [x8]
	ldr	x8, [sp, #672]
	ldr	w3, [x8, #4]
	ldr	q0, [sp, #640]
	add	x1, sp, #608
	str	q0, [sp, #608]
	ldr	x8, [sp, #656]
	str	x8, [sp, #624]
	bl	_mc_field
	tbz	w0, #0, LBB79_130
	b	LBB79_128
LBB79_128:                              ;   in Loop: Header=BB79_126 Depth=1
	ldrh	w8, [sp, #640]
	ldr	x9, [sp, #680]
	ldrh	w9, [x9]
	bic	w8, w8, w9
	cbnz	w8, LBB79_130
	b	LBB79_129
LBB79_129:                              ;   in Loop: Header=BB79_126 Depth=1
	ldr	x8, [sp, #648]
	ldr	x9, [sp, #680]
	ldr	x9, [x9, #8]
	bic	x8, x8, x9
	cbz	x8, LBB79_131
	b	LBB79_130
LBB79_130:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #56]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.54@PAGE
	add	x4, x4, l_.str.54@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_131:                              ;   in Loop: Header=BB79_126 Depth=1
	b	LBB79_132
LBB79_132:                              ;   in Loop: Header=BB79_126 Depth=1
	ldrh	w8, [sp, #694]
	add	w8, w8, #1
	strh	w8, [sp, #694]
	b	LBB79_126
LBB79_133:
	add	x8, sp, #584
	mov	w0, #8                          ; =0x8
	bl	_mc_tag
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8, #256]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #600]
	str	x8, [sp, #1312]
	ldr	x8, [sp, #1456]
	ldrsh	w9, [x8, #80]
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #1304]
	b	LBB79_194
LBB79_134:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #560]
	ldr	x8, [x8, #16]
	str	x8, [sp, #576]
	ldrb	w8, [sp, #580]
	cbz	w8, LBB79_141
	b	LBB79_135
LBB79_135:
	ldrb	w8, [sp, #580]
	subs	w8, w8, #2
	b.ne	LBB79_139
	b	LBB79_136
LBB79_136:
	ldr	x0, [sp, #1480]
	ldr	x1, [sp, #1440]
	ldrh	w2, [sp, #562]
	bl	_mc_owned_local
	tbz	w0, #0, LBB79_139
	b	LBB79_137
LBB79_137:
	ldr	x8, [sp, #1440]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #562]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #576]
	subs	w8, w8, w9
	b.ne	LBB79_139
	b	LBB79_138
LBB79_138:
	ldr	x0, [sp, #1440]
	ldrh	w1, [sp, #562]
	ldrh	w2, [sp, #1396]
	add	x3, sp, #559
	bl	_nvm_affine_scalar_field
	tbnz	w0, #0, LBB79_140
	b	LBB79_139
LBB79_139:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.55@PAGE
	add	x4, x4, l_.str.55@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_140:
	ldrb	w0, [sp, #559]
	add	x8, sp, #528
	bl	_mc_tag
	ldr	q0, [sp, #528]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #544]
	str	x8, [sp, #1312]
	b	LBB79_155
LBB79_141:
	ldrh	w8, [sp, #560]
	subs	w8, w8, #256
	b.ne	LBB79_143
	b	LBB79_142
LBB79_142:
	ldr	x8, [sp, #568]
	cbnz	x8, LBB79_144
	b	LBB79_143
LBB79_143:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #48]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.56@PAGE
	add	x4, x4, l_.str.56@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_144:
	str	wzr, [sp, #524]
	b	LBB79_145
LBB79_145:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #524]
	ldr	x9, [sp, #1480]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB79_154
	b	LBB79_146
LBB79_146:                              ;   in Loop: Header=BB79_145 Depth=1
	ldr	x8, [sp, #568]
	ldr	w9, [sp, #524]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB79_152
	b	LBB79_147
LBB79_147:                              ;   in Loop: Header=BB79_145 Depth=1
	ldr	x8, [sp, #1480]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x10, x8, #28
	ldr	w8, [sp, #524]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #512]
	ldr	x8, [sp, #512]
	ldrb	w8, [x8, #22]
	subs	w8, w8, #8
	b.ne	LBB79_150
	b	LBB79_148
LBB79_148:                              ;   in Loop: Header=BB79_145 Depth=1
	ldrh	w8, [sp, #1396]
	ldr	x9, [sp, #512]
	ldrh	w9, [x9, #20]
	subs	w8, w8, w9
	b.ge	LBB79_150
	b	LBB79_149
LBB79_149:                              ;   in Loop: Header=BB79_145 Depth=1
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #512]
	ldr	w1, [x8, #8]
	bl	_mc_owned_layout
	tbz	w0, #0, LBB79_151
	b	LBB79_150
LBB79_150:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #44]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.57@PAGE
	add	x4, x4, l_.str.57@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_151:                              ;   in Loop: Header=BB79_145 Depth=1
	ldr	x8, [sp, #1480]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #1568]
	ldr	x9, [sp, #512]
	ldr	w9, [x9, #16]
	ldrh	w10, [sp, #1396]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #4
	str	x8, [sp, #504]
	ldr	x8, [sp, #504]
	ldrh	w9, [x8]
	ldrh	w8, [sp, #1296]
	orr	w8, w8, w9
	strh	w8, [sp, #1296]
	ldr	x8, [sp, #504]
	ldr	x9, [x8, #8]
	ldr	x8, [sp, #1304]
	orr	x8, x8, x9
	str	x8, [sp, #1304]
	b	LBB79_152
LBB79_152:                              ;   in Loop: Header=BB79_145 Depth=1
	b	LBB79_153
LBB79_153:                              ;   in Loop: Header=BB79_145 Depth=1
	ldr	w8, [sp, #524]
	add	w8, w8, #1
	str	w8, [sp, #524]
	b	LBB79_145
LBB79_154:
	b	LBB79_155
LBB79_155:
	b	LBB79_194
LBB79_156:
	ldrh	w8, [sp, #1334]
	strh	w8, [sp, #502]
	b	LBB79_157
LBB79_157:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #502]
	ldr	x9, [sp, #1464]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB79_162
	b	LBB79_158
LBB79_158:                              ;   in Loop: Header=BB79_157 Depth=1
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #502]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x0, sp, #464
	str	q0, [sp, #464]
	ldr	x8, [x8, #16]
	str	x8, [sp, #480]
	mov	w1, #3                          ; =0x3
	bl	_mc_exact
	tbnz	w0, #0, LBB79_160
	b	LBB79_159
LBB79_159:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.58@PAGE
	add	x4, x4, l_.str.58@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_160:                              ;   in Loop: Header=BB79_157 Depth=1
	b	LBB79_161
LBB79_161:                              ;   in Loop: Header=BB79_157 Depth=1
	ldrh	w8, [sp, #502]
	add	w8, w8, #1
	strh	w8, [sp, #502]
	b	LBB79_157
LBB79_162:
	add	x8, sp, #440
	mov	w0, #7                          ; =0x7
	bl	_mc_tag
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8, #112]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #456]
	str	x8, [sp, #1312]
	ldr	x8, [sp, #1456]
	ldrsh	w9, [x8, #80]
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #1304]
	b	LBB79_194
LBB79_163:
	ldr	x0, [sp, #1480]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x1, sp, #416
	str	q0, [sp, #416]
	ldr	x8, [x8, #16]
	str	x8, [sp, #432]
	bl	_mc_array
	tbnz	w0, #0, LBB79_165
	b	LBB79_164
LBB79_164:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.59@PAGE
	add	x4, x4, l_.str.59@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_165:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #84
	b.eq	LBB79_167
	b	LBB79_166
LBB79_166:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #83
	b.ne	LBB79_169
	b	LBB79_167
LBB79_167:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
	mov	w1, #1                          ; =0x1
	add	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x0, sp, #384
	str	q0, [sp, #384]
	ldr	x8, [x8, #16]
	str	x8, [sp, #400]
	bl	_mc_exact
	tbnz	w0, #0, LBB79_169
	b	LBB79_168
LBB79_168:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #32]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.60@PAGE
	add	x4, x4, l_.str.60@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_169:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #81
	b.eq	LBB79_171
	b	LBB79_170
LBB79_170:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #84
	b.ne	LBB79_173
	b	LBB79_171
LBB79_171:
	ldr	x10, [sp, #1432]
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x0, sp, #352
	str	q0, [sp, #352]
	ldr	x8, [x8, #16]
	str	x8, [sp, #368]
	mov	w1, #3                          ; =0x3
	bl	_mc_exact
	tbnz	w0, #0, LBB79_173
	b	LBB79_172
LBB79_172:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.61@PAGE
	add	x4, x4, l_.str.61@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_173:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #83
	b.ne	LBB79_175
	b	LBB79_174
LBB79_174:
	add	x8, sp, #328
	mov	w0, #3                          ; =0x3
	bl	_mc_tag
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	q0, [x8]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #344]
	str	x8, [sp, #1312]
	ldrh	w8, [sp, #1296]
	orr	w8, w8, #0x1
	strh	w8, [sp, #1296]
	b	LBB79_179
LBB79_175:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #85
	b.ne	LBB79_177
	b	LBB79_176
LBB79_176:
	add	x8, sp, #304
	mov	w0, #1                          ; =0x1
	bl	_mc_tag
	ldr	q0, [sp, #304]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #320]
	str	x8, [sp, #1312]
	b	LBB79_178
LBB79_177:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	str	q0, [sp, #1296]
	ldr	x8, [x8, #16]
	str	x8, [sp, #1312]
	b	LBB79_178
LBB79_178:
	b	LBB79_179
LBB79_179:
	b	LBB79_194
LBB79_180:
	ldr	x8, [sp, #1480]
	add	x10, x8, #16
	ldr	x8, [sp, #1424]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #8]
	str	x8, [sp, #296]
	strh	wzr, [sp, #294]
	b	LBB79_181
LBB79_181:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #294]
	ldr	x9, [sp, #296]
	ldr	x9, [x9]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB79_186
	b	LBB79_182
LBB79_182:                              ;   in Loop: Header=BB79_181 Depth=1
	ldr	x0, [sp, #1480]
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
	ldrh	w9, [sp, #294]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	smaddl	x10, w8, w9, x10
	ldr	x8, [sp, #296]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #294]
                                        ; kill: def $x9 killed $w9
	ldr	q0, [x10]
	add	x1, sp, #256
	str	q0, [sp, #256]
	ldr	x10, [x10, #16]
	str	x10, [sp, #272]
	ldr	x2, [x8, x9, lsl #3]
	bl	_mc_type
	tbnz	w0, #0, LBB79_184
	b	LBB79_183
LBB79_183:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.62@PAGE
	add	x4, x4, l_.str.62@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_184:                              ;   in Loop: Header=BB79_181 Depth=1
	b	LBB79_185
LBB79_185:                              ;   in Loop: Header=BB79_181 Depth=1
	ldrh	w8, [sp, #294]
	add	w8, w8, #1
	strh	w8, [sp, #294]
	b	LBB79_181
LBB79_186:
	ldr	x8, [sp, #296]
	ldr	x8, [x8]
	ldr	x8, [x8, #32]
	str	x8, [sp, #248]
	ldrb	w8, [sp, #248]
	subs	w8, w8, #8
	b.ne	LBB79_188
	b	LBB79_187
LBB79_187:
	ldr	w0, [sp, #252]
	add	x8, sp, #224
	bl	_mc_owner
	ldr	q0, [sp, #224]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #240]
	str	x8, [sp, #1312]
	b	LBB79_189
LBB79_188:
	ldrb	w0, [sp, #248]
	add	x8, sp, #200
	bl	_mc_tag
	ldur	q0, [sp, #200]
	str	q0, [sp, #1296]
	ldr	x8, [sp, #216]
	str	x8, [sp, #1312]
	b	LBB79_189
LBB79_189:
	b	LBB79_194
LBB79_190:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	q0, [x8]
	add	x0, sp, #176
	str	q0, [sp, #176]
	ldr	x8, [x8, #16]
	str	x8, [sp, #192]
	mov	w1, #4                          ; =0x4
	bl	_mc_exact
	tbnz	w0, #0, LBB79_192
	b	LBB79_191
LBB79_191:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.63@PAGE
	add	x4, x4, l_.str.63@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_192:
	b	LBB79_194
LBB79_193:
	ldr	x0, [sp, #1480]
	ldr	w2, [sp, #1452]
	ldr	x8, [sp, #1456]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.64@PAGE
	add	x4, x4, l_.str.64@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_194:
	b	LBB79_195
LBB79_195:
	ldrh	w8, [sp, #1334]
	ldr	w9, [sp, #1400]
	add	w8, w8, w9
	ldr	x9, [sp, #1464]
	strh	w8, [x9, #16]
	ldr	w8, [sp, #1400]
	cbz	w8, LBB79_197
	b	LBB79_196
LBB79_196:
	ldr	x10, [sp, #1432]
	ldrh	w8, [sp, #1334]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	q0, [sp, #1296]
	str	q0, [x9]
	ldr	x8, [sp, #1312]
	str	x8, [x9, #16]
	b	LBB79_197
LBB79_197:
	b	LBB79_198
LBB79_198:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #1480]
	ldr	x9, [x9, #8]
	add	x9, x9, #24
	ldr	w10, [sp, #1452]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.le	LBB79_200
	b	LBB79_199
LBB79_199:
	ldr	x8, [sp, #1464]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #1480]
	ldr	x9, [x9, #8]
	add	x9, x9, #24
	ldr	w10, [sp, #1452]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB79_200
LBB79_200:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #56
	b.eq	LBB79_203
	b	LBB79_201
LBB79_201:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #57
	b.eq	LBB79_203
	b	LBB79_202
LBB79_202:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #58
	b.ne	LBB79_208
	b	LBB79_203
LBB79_203:
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #1456]
	ldr	w1, [x8, #76]
	ldr	x2, [sp, #1464]
	bl	_mc_join
	tbnz	w0, #0, LBB79_205
	b	LBB79_204
LBB79_204:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_205:
	ldrb	w8, [sp, #1423]
	subs	w8, w8, #56
	b.ne	LBB79_207
	b	LBB79_206
LBB79_206:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_207:
	b	LBB79_208
LBB79_208:
	ldr	x0, [sp, #1480]
	ldr	x8, [sp, #1456]
	ldr	w1, [x8, #72]
	ldr	x2, [sp, #1464]
	bl	_mc_join
	and	w8, w0, #0x1
	strb	w8, [sp, #1495]
	b	LBB79_209
LBB79_209:
	ldrb	w8, [sp, #1495]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB79_211
	b	LBB79_210
LBB79_210:
	bl	___stack_chk_fail
LBB79_211:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #3552
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI79_0:
	.long	LBB79_52-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_74-Ltmp13
	.long	LBB79_77-Ltmp13
	.long	LBB79_80-Ltmp13
	.long	LBB79_81-Ltmp13
	.long	LBB79_99-Ltmp13
	.long	LBB79_111-Ltmp13
	.long	LBB79_116-Ltmp13
	.long	LBB79_99-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_82-Ltmp13
	.long	LBB79_92-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_53-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_52-Ltmp13
	.long	LBB79_190-Ltmp13
	.long	LBB79_190-Ltmp13
	.long	LBB79_180-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_156-Ltmp13
	.long	LBB79_163-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_163-Ltmp13
	.long	LBB79_163-Ltmp13
	.long	LBB79_163-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_156-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_190-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_193-Ltmp13
	.long	LBB79_123-Ltmp13
	.long	LBB79_134-Ltmp13
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_frame_free
_mc_frame_free:                         ; @mc_frame_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB80_2
	b	LBB80_1
LBB80_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB80_2
LBB80_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_lifetime_facts_free ; -- Begin function nvm_owned_array_lifetime_facts_free
	.p2align	2
_nvm_owned_array_lifetime_facts_free:   ; @nvm_owned_array_lifetime_facts_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB81_2
	b	LBB81_1
LBB81_1:
	b	LBB81_3
LBB81_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_owned_array_origins_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_nvm_owned_array_layouts_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB81_3
LBB81_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_analyze_owned_array_lifetimes ; -- Begin function nvm_analyze_owned_array_lifetimes
	.p2align	2
_nvm_analyze_owned_array_lifetimes:     ; @nvm_analyze_owned_array_lifetimes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #6560                       ; =0x19a0
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2464
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #368]
	str	x1, [sp, #360]
	adrp	x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGE
	add	x8, x8, l___const.nvm_analyze_owned_array_lifetimes.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [sp, #336]
	ldr	x8, [x8, #16]
	str	x8, [sp, #352]
	ldr	x8, [sp, #360]
	cbnz	x8, LBB82_2
	b	LBB82_1
LBB82_1:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #336]
	str	q0, [x9]
	ldr	x8, [sp, #352]
	str	x8, [x9, #16]
	b	LBB82_76
LBB82_2:
	add	x1, sp, #328
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #328]
	ldr	x0, [sp, #368]
	add	x8, sp, #304
	bl	_nvm_analyze_owned_array_origins
	ldr	w8, [sp, #304]
	cbz	w8, LBB82_4
	b	LBB82_3
LBB82_3:
	ldr	w0, [sp, #304]
	bl	_la_origin_status
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	str	w0, [x9]
	ldr	w8, [sp, #308]
	str	w8, [x9, #4]
	ldr	w8, [sp, #312]
	str	w8, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB82_76
LBB82_4:
	add	x1, sp, #296
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #296]
	ldr	x0, [sp, #368]
	add	x8, sp, #272
	bl	_nvm_describe_owned_array_layouts
	ldr	w8, [sp, #272]
	cbz	w8, LBB82_12
	b	LBB82_5
LBB82_5:
	ldr	x0, [sp, #328]
	bl	_nvm_owned_array_origins_free
	ldr	w8, [sp, #272]
	subs	w8, w8, #4
	b.ne	LBB82_7
	b	LBB82_6
LBB82_6:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB82_11
LBB82_7:
	ldr	w8, [sp, #272]
	subs	w8, w8, #3
	b.ne	LBB82_9
	b	LBB82_8
LBB82_8:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB82_10
LBB82_9:
	ldr	w9, [sp, #272]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #2
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB82_10
LBB82_10:
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB82_11
LBB82_11:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [sp, #268]
	ldr	w8, [sp, #268]
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #288]
	str	x8, [x9, #16]
	b	LBB82_76
LBB82_12:
	mov	x0, #1                          ; =0x1
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x1, #49352                      ; =0xc0c8
	movk	x1, #6, lsl #16
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	str	x8, [sp, #256]
	mov	x1, #9160                       ; =0x23c8
	movk	x1, #2, lsl #16
	bl	_calloc
	str	x0, [sp, #248]
	ldr	x8, [sp, #256]
	cbz	x8, LBB82_14
	b	LBB82_13
LBB82_13:
	ldr	x8, [sp, #248]
	cbnz	x8, LBB82_15
	b	LBB82_14
LBB82_14:
	ldr	x0, [sp, #256]
	bl	_free
	ldr	x0, [sp, #248]
	bl	_free
	ldr	x0, [sp, #328]
	bl	_nvm_owned_array_origins_free
	ldr	x0, [sp, #296]
	bl	_nvm_owned_array_layouts_free
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.8@PAGE
	add	x8, x8, l_.str.8@PAGEOFF
	str	x8, [x9, #16]
	b	LBB82_76
LBB82_15:
	ldr	x8, [sp, #328]
	ldr	x9, [sp, #248]
	str	x8, [x9]
	ldr	x8, [sp, #296]
	ldr	x9, [sp, #248]
	str	x8, [x9, #8]
	ldr	x8, [sp, #248]
	ldr	x9, [sp, #256]
	str	x8, [x9, #8]
	ldr	x8, [sp, #368]
	ldr	x9, [sp, #256]
	str	x8, [x9]
	ldr	x8, [sp, #256]
	mov	x9, #49328                      ; =0xc0b0
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	q0, [sp, #336]
	str	q0, [x9]
	ldr	x8, [sp, #352]
	str	x8, [x9, #16]
	ldr	x0, [sp, #256]
	bl	_la_decode
	tbnz	w0, #0, LBB82_17
	b	LBB82_16
LBB82_16:
	b	LBB82_64
LBB82_17:
	str	wzr, [sp, #244]
	b	LBB82_18
LBB82_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB82_20 Depth 2
                                        ;     Child Loop BB82_24 Depth 2
	ldr	w8, [sp, #244]
	ldr	x9, [sp, #368]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB82_33
	b	LBB82_19
LBB82_19:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x8, [sp, #368]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #244]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #242]
	add	x0, sp, #408
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x1, #6144                       ; =0x1800
	bl	_bzero
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #256]
	add	x8, x8, #16
	ldr	w10, [sp, #244]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #4
	ldr	x10, [x8, #8]
	add	x8, sp, #216
	str	x10, [sp, #216]
	str	x9, [sp, #224]
	strh	wzr, [sp, #232]
	stur	wzr, [x8, #18]
	strh	wzr, [sp, #238]
	strh	wzr, [sp, #214]
	b	LBB82_20
LBB82_20:                               ;   Parent Loop BB82_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #214]
	ldrh	w9, [sp, #242]
	subs	w8, w8, w9
	b.ge	LBB82_23
	b	LBB82_21
LBB82_21:                               ;   in Loop: Header=BB82_20 Depth=2
	ldrh	w8, [sp, #214]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	add	x10, sp, #408
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_la_tag
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	str	x0, [sp, #392]
	str	x1, [sp, #400]
	ldr	x8, [sp, #392]
	str	x8, [sp, #200]
	ldr	w8, [sp, #400]
	str	w8, [sp, #208]
	ldr	x8, [sp, #200]
	str	x8, [x11]
	ldr	w8, [sp, #208]
	str	w8, [x11, #8]
	ldrh	w8, [sp, #214]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #9]
	b	LBB82_22
LBB82_22:                               ;   in Loop: Header=BB82_20 Depth=2
	ldrh	w8, [sp, #214]
	add	w8, w8, #1
	strh	w8, [sp, #214]
	b	LBB82_20
LBB82_23:                               ;   in Loop: Header=BB82_18 Depth=1
	strh	wzr, [sp, #198]
	b	LBB82_24
LBB82_24:                               ;   Parent Loop BB82_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #198]
	ldr	x9, [sp, #368]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB82_29
	b	LBB82_25
LBB82_25:                               ;   in Loop: Header=BB82_24 Depth=2
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #198]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.eq	LBB82_27
	b	LBB82_26
LBB82_26:                               ;   in Loop: Header=BB82_24 Depth=2
	ldrh	w8, [sp, #198]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	add	x10, sp, #408
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [sp, #216]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #198]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w0, [x8, x9]
	bl	_la_tag
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #376]
	str	x1, [sp, #384]
	ldr	x8, [sp, #376]
	str	x8, [sp, #184]
	ldr	w8, [sp, #384]
	str	w8, [sp, #192]
	ldr	x8, [sp, #184]
	str	x8, [x9]
	ldr	w8, [sp, #192]
	str	w8, [x9, #8]
	b	LBB82_27
LBB82_27:                               ;   in Loop: Header=BB82_24 Depth=2
	b	LBB82_28
LBB82_28:                               ;   in Loop: Header=BB82_24 Depth=2
	ldrh	w8, [sp, #198]
	add	w8, w8, #1
	strh	w8, [sp, #198]
	b	LBB82_24
LBB82_29:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #256]
	add	x8, x8, #16
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w1, [x8, x9]
	add	x2, sp, #216
	bl	_la_join
	tbnz	w0, #0, LBB82_31
	b	LBB82_30
LBB82_30:
	b	LBB82_64
LBB82_31:                               ;   in Loop: Header=BB82_18 Depth=1
	b	LBB82_32
LBB82_32:                               ;   in Loop: Header=BB82_18 Depth=1
	ldr	w8, [sp, #244]
	add	w8, w8, #1
	str	w8, [sp, #244]
	b	LBB82_18
LBB82_33:
	b	LBB82_34
LBB82_34:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #256]
	mov	x9, #49320                      ; =0xc0a8
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	cbz	w8, LBB82_44
	b	LBB82_35
LBB82_35:                               ;   in Loop: Header=BB82_34 Depth=1
	ldr	x8, [sp, #256]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #6, lsl #16
	add	x10, x8, x9
	ldr	w8, [x10]
	add	w9, w8, #1
	str	w9, [x10]
	subs	w8, w8, #64, lsl #12            ; =262144
	b.ne	LBB82_37
	b	LBB82_36
LBB82_36:
	ldr	x0, [sp, #256]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.9@PAGE
	add	x4, x4, l_.str.9@PAGEOFF
	bl	_la_stop
	b	LBB82_64
LBB82_37:                               ;   in Loop: Header=BB82_34 Depth=1
	ldr	x8, [sp, #256]
	mov	x9, #32928                      ; =0x80a0
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	x9, [sp, #256]
	mov	x10, #49312                     ; =0xc0a0
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #180]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #256]
	str	w8, [x9, x10]
	ldr	x8, [sp, #256]
	mov	x9, #49320                      ; =0xc0a8
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #256]
	add	x10, x8, #144
	ldr	w8, [sp, #180]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #168]
	ldr	x8, [sp, #168]
	strb	wzr, [x8, #98]
	ldr	x8, [sp, #368]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #168]
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #166]
	ldr	x0, [sp, #256]
	ldrh	w9, [sp, #166]
	ldr	x8, [sp, #168]
	ldr	x8, [x8, #80]
	ldrh	w8, [x8, #16]
	add	w1, w8, w9, lsl #1
	bl	_la_work
	tbnz	w0, #0, LBB82_39
	b	LBB82_38
LBB82_38:
	b	LBB82_64
LBB82_39:                               ;   in Loop: Header=BB82_34 Depth=1
	ldr	x8, [sp, #168]
	ldr	x0, [x8, #80]
	ldrh	w1, [sp, #166]
	bl	_la_clone
	str	x0, [sp, #152]
	ldr	x8, [sp, #152]
	cbnz	x8, LBB82_41
	b	LBB82_40
LBB82_40:
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #168]
	ldr	w2, [x8, #64]
	ldr	x8, [sp, #168]
	ldr	w3, [x8, #68]
	mov	w1, #4                          ; =0x4
	adrp	x4, l_.str.10@PAGE
	add	x4, x4, l_.str.10@PAGEOFF
	bl	_la_stop
	b	LBB82_64
LBB82_41:                               ;   in Loop: Header=BB82_34 Depth=1
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #180]
	ldr	x2, [sp, #152]
	bl	_la_transfer
	strb	w0, [sp, #151]
	ldr	x0, [sp, #152]
	bl	_la_frame_free
	ldrb	w8, [sp, #151]
	tbnz	w8, #0, LBB82_43
	b	LBB82_42
LBB82_42:
	b	LBB82_64
LBB82_43:                               ;   in Loop: Header=BB82_34 Depth=1
	b	LBB82_34
LBB82_44:
	str	wzr, [sp, #144]
	b	LBB82_45
LBB82_45:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #144]
	ldr	x9, [sp, #256]
	mov	x10, #32912                     ; =0x8090
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB82_50
	b	LBB82_46
LBB82_46:                               ;   in Loop: Header=BB82_45 Depth=1
	ldr	x8, [sp, #256]
	add	x10, x8, #144
	ldr	w8, [sp, #144]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #80]
	cbnz	x8, LBB82_48
	b	LBB82_47
LBB82_47:
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #256]
	add	x11, x8, #144
	ldr	w8, [sp, #144]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w2, [x8, #64]
	ldr	x8, [sp, #256]
	add	x10, x8, #144
	ldr	w8, [sp, #144]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	adrp	x4, l_.str.11@PAGE
	add	x4, x4, l_.str.11@PAGEOFF
	bl	_la_stop
	b	LBB82_64
LBB82_48:                               ;   in Loop: Header=BB82_45 Depth=1
	b	LBB82_49
LBB82_49:                               ;   in Loop: Header=BB82_45 Depth=1
	ldr	w8, [sp, #144]
	add	w8, w8, #1
	str	w8, [sp, #144]
	b	LBB82_45
LBB82_50:
	str	wzr, [sp, #140]
	b	LBB82_51
LBB82_51:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #140]
	ldr	x9, [sp, #256]
	mov	x10, #32912                     ; =0x8090
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB82_63
	b	LBB82_52
LBB82_52:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #256]
	add	x10, x8, #144
	ldr	w8, [sp, #140]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #128]
	ldr	x8, [sp, #248]
	mov	x9, #25540                      ; =0x63c4
	add	x10, x8, x9
	ldr	w8, [sp, #140]
                                        ; kill: def $x8 killed $w8
	mov	x9, #28                         ; =0x1c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #120]
	ldr	x0, [sp, #256]
	mov	w1, #2                          ; =0x2
	bl	_la_work
	tbnz	w0, #0, LBB82_54
	b	LBB82_53
LBB82_53:
	b	LBB82_64
LBB82_54:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #23]
	ldr	x9, [sp, #128]
	ldrb	w9, [x9, #96]
	subs	w8, w8, w9
	b.ne	LBB82_60
	b	LBB82_55
LBB82_55:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #24]
	ldr	x9, [sp, #128]
	ldrb	w9, [x9, #97]
	subs	w8, w8, w9
	b.ne	LBB82_60
	b	LBB82_56
LBB82_56:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #14]
	ldr	x9, [sp, #128]
	ldrh	w9, [x9, #88]
	subs	w8, w8, w9
	b.ne	LBB82_60
	b	LBB82_57
LBB82_57:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #128]
	ldrh	w9, [x9, #90]
	subs	w8, w8, w9
	b.ne	LBB82_60
	b	LBB82_58
LBB82_58:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #18]
	ldr	x9, [sp, #128]
	ldrh	w9, [x9, #92]
	subs	w8, w8, w9
	b.ne	LBB82_60
	b	LBB82_59
LBB82_59:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #20]
	ldr	x9, [sp, #128]
	ldrh	w9, [x9, #94]
	subs	w8, w8, w9
	b.eq	LBB82_61
	b	LBB82_60
LBB82_60:
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #128]
	ldr	w2, [x8, #64]
	ldr	x8, [sp, #128]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	adrp	x4, l_.str.12@PAGE
	add	x4, x4, l_.str.12@PAGEOFF
	bl	_la_stop
	b	LBB82_64
LBB82_61:                               ;   in Loop: Header=BB82_51 Depth=1
	b	LBB82_62
LBB82_62:                               ;   in Loop: Header=BB82_51 Depth=1
	ldr	w8, [sp, #140]
	add	w8, w8, #1
	str	w8, [sp, #140]
	b	LBB82_51
LBB82_63:
	ldr	x9, [sp, #248]
	ldr	x8, [sp, #368]
	ldr	w8, [x8, #272]
	str	w8, [sp, #100]
	ldr	x8, [sp, #256]
	mov	x10, #32912                     ; =0x8090
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	str	w8, [sp, #104]
	ldr	x8, [sp, #256]
	mov	x10, #32916                     ; =0x8094
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	str	w8, [sp, #108]
	ldr	x8, [sp, #256]
	mov	x10, #32920                     ; =0x8098
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	str	w8, [sp, #112]
	ldr	x8, [sp, #256]
	mov	x10, #32924                     ; =0x809c
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	str	w8, [sp, #116]
	ldur	q0, [sp, #100]
	str	q0, [x9, #16]
	ldr	w8, [sp, #116]
	str	w8, [x9, #32]
	ldr	x8, [sp, #256]
	mov	x9, #49328                      ; =0xc0b0
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	str	wzr, [sp, #72]
	str	wzr, [sp, #76]
	str	wzr, [sp, #80]
	str	wzr, [sp, #84]
	adrp	x8, l_.str.13@PAGE
	add	x8, x8, l_.str.13@PAGEOFF
	str	x8, [sp, #88]
	ldur	q0, [sp, #72]
	str	q0, [x9]
	ldr	x8, [sp, #88]
	str	x8, [x9, #16]
	b	LBB82_64
LBB82_64:
	str	wzr, [sp, #68]
	b	LBB82_65
LBB82_65:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #68]
	ldr	x9, [sp, #256]
	mov	x10, #32912                     ; =0x8090
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB82_68
	b	LBB82_66
LBB82_66:                               ;   in Loop: Header=BB82_65 Depth=1
	ldr	x8, [sp, #256]
	add	x10, x8, #144
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #80]
	bl	_la_frame_free
	b	LBB82_67
LBB82_67:                               ;   in Loop: Header=BB82_65 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB82_65
LBB82_68:
	str	wzr, [sp, #64]
	b	LBB82_69
LBB82_69:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #64]
	ldr	x9, [sp, #368]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB82_72
	b	LBB82_70
LBB82_70:                               ;   in Loop: Header=BB82_69 Depth=1
	ldr	x8, [sp, #256]
	add	x8, x8, #16
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	bl	_nvm_affine_state_free
	b	LBB82_71
LBB82_71:                               ;   in Loop: Header=BB82_69 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB82_69
LBB82_72:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #256]
	mov	x10, #49328                     ; =0xc0b0
	movk	x10, #6, lsl #16
	add	x8, x8, x10
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x0, [sp, #256]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cbnz	w8, LBB82_74
	b	LBB82_73
LBB82_73:
	ldr	x8, [sp, #248]
	ldr	x9, [sp, #360]
	str	x8, [x9]
	b	LBB82_75
LBB82_74:
	ldr	x0, [sp, #248]
	bl	_nvm_owned_array_lifetime_facts_free
	b	LBB82_75
LBB82_75:
	b	LBB82_76
LBB82_76:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB82_78
	b	LBB82_77
LBB82_77:
	bl	___stack_chk_fail
LBB82_78:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2464
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_origin_status
_la_origin_status:                      ; @la_origin_status
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #2
	b.eq	LBB83_5
	b	LBB83_1
LBB83_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB83_4
	b	LBB83_2
LBB83_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.ne	LBB83_6
	b	LBB83_3
LBB83_3:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB83_7
LBB83_4:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #12]
	b	LBB83_7
LBB83_5:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #12]
	b	LBB83_7
LBB83_6:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB83_7
LBB83_7:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_decode
_la_decode:                             ; @la_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	sub	x1, x29, #28
	bl	_nvm_owned_array_origin_counts
	stur	wzr, [x29, #-32]
	b	LBB84_1
LBB84_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB84_5 Depth 2
	ldur	w8, [x29, #-32]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB84_19
	b	LBB84_2
LBB84_2:                                ;   in Loop: Header=BB84_1 Depth=1
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-32]
	bl	_la_facts
	tbnz	w0, #0, LBB84_4
	b	LBB84_3
LBB84_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_4:                                ;   in Loop: Header=BB84_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-32]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-16]
	add	x8, x8, #16
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-48]
	str	w8, [x9]
	stur	wzr, [x29, #-52]
	b	LBB84_5
LBB84_5:                                ;   Parent Loop BB84_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB84_17
	b	LBB84_6
LBB84_6:                                ;   in Loop: Header=BB84_5 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ne	LBB84_8
	b	LBB84_7
LBB84_7:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-32]
	ldur	w3, [x29, #-52]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.66@PAGE
	add	x4, x4, l_.str.66@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_8:                                ;   in Loop: Header=BB84_5 Depth=2
	ldur	x8, [x29, #-16]
	add	x10, x8, #144
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]
	ldur	w8, [x29, #-32]
	ldr	x9, [sp, #64]
	str	w8, [x9, #64]
	ldur	w8, [x29, #-52]
	ldr	x9, [sp, #64]
	str	w8, [x9, #68]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldr	x2, [sp, #64]
	bl	_isa_decode
	str	w0, [sp, #60]
	ldr	w8, [sp, #60]
	cbz	w8, LBB84_10
	b	LBB84_9
LBB84_9:                                ;   in Loop: Header=BB84_5 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w0, [x8]
	bl	_la_supported
	tbnz	w0, #0, LBB84_11
	b	LBB84_10
LBB84_10:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-32]
	ldur	w3, [x29, #-52]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.67@PAGE
	add	x4, x4, l_.str.67@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_11:                               ;   in Loop: Header=BB84_5 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	mov	x9, #25540                      ; =0x63c4
	add	x11, x8, x9
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	mov	x10, #28                        ; =0x1c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #48]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	x8, [x29, #-16]
	ldr	w1, [x8, x9]
	ldr	x2, [sp, #48]
	bl	_nvm_owned_array_origin_obligation
	tbz	w0, #0, LBB84_15
	b	LBB84_12
LBB84_12:                               ;   in Loop: Header=BB84_5 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.ne	LBB84_15
	b	LBB84_13
LBB84_13:                               ;   in Loop: Header=BB84_5 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.ne	LBB84_15
	b	LBB84_14
LBB84_14:                               ;   in Loop: Header=BB84_5 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #22]
	ldr	x9, [sp, #64]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB84_16
	b	LBB84_15
LBB84_15:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-32]
	ldur	w3, [x29, #-52]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.68@PAGE
	add	x4, x4, l_.str.68@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_16:                               ;   in Loop: Header=BB84_5 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	add	x10, x8, x9
	ldr	w8, [x10]
	add	w8, w8, #1
	str	w8, [x10]
	ldr	w10, [sp, #60]
	ldur	w8, [x29, #-52]
	add	w8, w8, w10
	stur	w8, [x29, #-52]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, x9]
	ldr	x9, [sp, #64]
	str	w8, [x9, #72]
	ldr	x9, [sp, #64]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #76]
	b	LBB84_5
LBB84_17:                               ;   in Loop: Header=BB84_1 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #4]
	b	LBB84_18
LBB84_18:                               ;   in Loop: Header=BB84_1 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB84_1
LBB84_19:
	ldur	x8, [x29, #-16]
	mov	x9, #32912                      ; =0x8090
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB84_21
	b	LBB84_20
LBB84_20:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.69@PAGE
	add	x4, x4, l_.str.69@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_21:
	str	wzr, [sp, #44]
	b	LBB84_22
LBB84_22:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB84_24 Depth 2
                                        ;       Child Loop BB84_29 Depth 3
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB84_41
	b	LBB84_23
LBB84_23:                               ;   in Loop: Header=BB84_22 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #16
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
	str	w8, [sp, #40]
	b	LBB84_24
LBB84_24:                               ;   Parent Loop BB84_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB84_29 Depth 3
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	add	x9, x9, #16
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB84_39
	b	LBB84_25
LBB84_25:                               ;   in Loop: Header=BB84_24 Depth=2
	ldur	x8, [x29, #-16]
	add	x10, x8, #144
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	strb	w8, [sp, #31]
	ldrb	w8, [sp, #31]
	subs	w8, w8, #56
	b.eq	LBB84_28
	b	LBB84_26
LBB84_26:                               ;   in Loop: Header=BB84_24 Depth=2
	ldrb	w8, [sp, #31]
	subs	w8, w8, #57
	b.eq	LBB84_28
	b	LBB84_27
LBB84_27:                               ;   in Loop: Header=BB84_24 Depth=2
	ldrb	w8, [sp, #31]
	subs	w8, w8, #58
	b.ne	LBB84_37
	b	LBB84_28
LBB84_28:                               ;   in Loop: Header=BB84_24 Depth=2
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #68]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #32]
	ldrsw	x9, [x9, #8]
	add	x8, x8, x9
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	add	x8, x8, #16
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	w8, [x8, x9]
	str	w8, [sp, #12]
	b	LBB84_29
LBB84_29:                               ;   Parent Loop BB84_22 Depth=1
                                        ;     Parent Loop BB84_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	add	x9, x9, #16
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB84_34
	b	LBB84_30
LBB84_30:                               ;   in Loop: Header=BB84_29 Depth=3
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	add	x11, x9, #144
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #68]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB84_32
	b	LBB84_31
LBB84_31:                               ;   in Loop: Header=BB84_29 Depth=3
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #32]
	str	w8, [x9, #76]
	b	LBB84_32
LBB84_32:                               ;   in Loop: Header=BB84_29 Depth=3
	b	LBB84_33
LBB84_33:                               ;   in Loop: Header=BB84_29 Depth=3
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB84_29
LBB84_34:                               ;   in Loop: Header=BB84_24 Depth=2
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #76]
	adds	w8, w8, #1
	b.ne	LBB84_36
	b	LBB84_35
LBB84_35:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #44]
	ldr	x8, [sp, #32]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.70@PAGE
	add	x4, x4, l_.str.70@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_36:                               ;   in Loop: Header=BB84_24 Depth=2
	b	LBB84_37
LBB84_37:                               ;   in Loop: Header=BB84_24 Depth=2
	b	LBB84_38
LBB84_38:                               ;   in Loop: Header=BB84_24 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB84_24
LBB84_39:                               ;   in Loop: Header=BB84_22 Depth=1
	b	LBB84_40
LBB84_40:                               ;   in Loop: Header=BB84_22 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB84_22
LBB84_41:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB84_42
LBB84_42:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_tag
_la_tag:                                ; @la_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	strb	w0, [sp, #23]
	str	xzr, [sp, #24]
	str	wzr, [sp, #32]
	ldrb	w9, [sp, #23]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	strh	w8, [sp, #24]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	ldr	x8, [sp, #24]
	stur	x8, [x29, #-24]
	ldr	w8, [sp, #32]
	stur	w8, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB85_2
	b	LBB85_1
LBB85_1:
	bl	___stack_chk_fail
LBB85_2:
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_join
_la_join:                               ; @la_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	mov	x10, #32912                     ; =0x8090
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB86_2
	b	LBB86_1
LBB86_1:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.78@PAGE
	add	x4, x4, l_.str.78@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_2:
	ldur	x8, [x29, #-16]
	add	x10, x8, #144
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	sturh	w8, [x29, #-42]
	ldur	x0, [x29, #-16]
	ldurh	w9, [x29, #-42]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	add	w1, w8, w9, lsl #1
	bl	_la_work
	tbnz	w0, #0, LBB86_4
	b	LBB86_3
LBB86_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_4:
	sturb	wzr, [x29, #-43]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #80]
	cbnz	x8, LBB86_10
	b	LBB86_5
LBB86_5:
	ldurh	w8, [x29, #-42]
	add	w8, w8, #256
	stur	w8, [x29, #-48]
	ldur	w8, [x29, #-48]
	ldur	x9, [x29, #-16]
	mov	x10, #32916                     ; =0x8094
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB86_7
	b	LBB86_6
LBB86_6:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.79@PAGE
	add	x4, x4, l_.str.79@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_7:
	ldur	x0, [x29, #-32]
	ldurh	w1, [x29, #-42]
	bl	_la_clone
	ldur	x8, [x29, #-40]
	str	x0, [x8, #80]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #80]
	cbnz	x8, LBB86_9
	b	LBB86_8
LBB86_8:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #4                          ; =0x4
	adrp	x4, l_.str.80@PAGE
	add	x4, x4, l_.str.80@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_9:
	ldur	w10, [x29, #-48]
	ldur	x8, [x29, #-16]
	mov	x9, #32916                      ; =0x8094
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-43]
	b	LBB86_33
LBB86_10:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #80]
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB86_12
	b	LBB86_11
LBB86_11:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.81@PAGE
	add	x4, x4, l_.str.81@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_12:
	str	wzr, [sp, #52]
	b	LBB86_13
LBB86_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldurh	w9, [x29, #-42]
	ldr	x10, [sp, #56]
	ldrh	w10, [x10, #16]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB86_24
	b	LBB86_14
LBB86_14:                               ;   in Loop: Header=BB86_13 Depth=1
	ldr	x8, [sp, #56]
	ldr	x11, [x8, #8]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [sp, #40]
	ldr	w8, [x8, #8]
	str	w8, [sp, #48]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #24]
	ldr	w8, [x8, #8]
	str	w8, [sp, #32]
	ldrb	w8, [sp, #48]
	cbnz	w8, LBB86_16
	b	LBB86_15
LBB86_15:                               ;   in Loop: Header=BB86_13 Depth=1
	ldrb	w8, [sp, #32]
	cbz	w8, LBB86_22
	b	LBB86_16
LBB86_16:                               ;   in Loop: Header=BB86_13 Depth=1
	ldrb	w8, [sp, #48]
	ldrb	w9, [sp, #32]
	subs	w8, w8, w9
	b.ne	LBB86_21
	b	LBB86_17
LBB86_17:                               ;   in Loop: Header=BB86_13 Depth=1
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.ne	LBB86_21
	b	LBB86_18
LBB86_18:                               ;   in Loop: Header=BB86_13 Depth=1
	ldrh	w8, [sp, #42]
	ldrh	w9, [sp, #26]
	subs	w8, w8, w9
	b.ne	LBB86_21
	b	LBB86_19
LBB86_19:                               ;   in Loop: Header=BB86_13 Depth=1
	ldrh	w8, [sp, #40]
	ldrh	w9, [sp, #24]
	subs	w8, w8, w9
	b.ne	LBB86_21
	b	LBB86_20
LBB86_20:                               ;   in Loop: Header=BB86_13 Depth=1
	ldrb	w8, [sp, #49]
	ldrb	w9, [sp, #33]
	subs	w8, w8, w9
	b.eq	LBB86_22
	b	LBB86_21
LBB86_21:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.82@PAGE
	add	x4, x4, l_.str.82@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_22:                               ;   in Loop: Header=BB86_13 Depth=1
	b	LBB86_23
LBB86_23:                               ;   in Loop: Header=BB86_13 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB86_13
LBB86_24:
	add	x2, sp, #23
	strb	wzr, [sp, #23]
	ldr	x8, [sp, #56]
	ldr	x0, [x8]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8]
	bl	_nvm_affine_state_meet_initialization
	tbnz	w0, #0, LBB86_26
	b	LBB86_25
LBB86_25:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-40]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.83@PAGE
	add	x4, x4, l_.str.83@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_26:
	ldrb	w8, [sp, #23]
	and	w9, w8, #0x1
	ldurb	w8, [x29, #-43]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-43]
	str	wzr, [sp, #16]
	b	LBB86_27
LBB86_27:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #16]
	ldurh	w9, [x29, #-42]
	ldr	x10, [sp, #56]
	ldrh	w10, [x10, #16]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB86_32
	b	LBB86_28
LBB86_28:                               ;   in Loop: Header=BB86_27 Depth=1
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x11, #12                        ; =0xc
	mov	x9, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8]
	strh	w8, [sp, #14]
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #9]
	strb	w8, [sp, #13]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	mov	x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrh	w10, [x8, x9]
	ldr	x8, [sp, #56]
	ldr	x12, [x8, #8]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x12
	ldrh	w8, [x9]
	orr	w8, w8, w10
	strh	w8, [x9]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w10, [x8, #9]
	ldr	x8, [sp, #56]
	ldr	x12, [x8, #8]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x12
	ldrb	w8, [x9, #9]
	orr	w8, w8, w10
	strb	w8, [x9, #9]
	ldrh	w9, [sp, #14]
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldr	w10, [sp, #16]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w10, [x8, x10]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB86_30
	b	LBB86_29
LBB86_29:                               ;   in Loop: Header=BB86_27 Depth=1
	ldrb	w8, [sp, #13]
	ldr	x9, [sp, #56]
	ldr	x11, [x9, #8]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #9]
	subs	w8, w8, w9
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB86_30
LBB86_30:                               ;   in Loop: Header=BB86_27 Depth=1
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldurb	w8, [x29, #-43]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-43]
	b	LBB86_31
LBB86_31:                               ;   in Loop: Header=BB86_27 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB86_27
LBB86_32:
	b	LBB86_33
LBB86_33:
	ldurb	w8, [x29, #-43]
	tbz	w8, #0, LBB86_35
	b	LBB86_34
LBB86_34:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_la_enqueue
	b	LBB86_35
LBB86_35:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB86_36
LBB86_36:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_stop
_la_stop:                               ; @la_stop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	w1, [sp, #52]
	str	w2, [sp, #48]
	str	w3, [sp, #44]
	str	x4, [sp, #32]
	ldr	x9, [sp, #56]
	ldr	w8, [sp, #52]
	str	w8, [sp, #8]
	ldr	w8, [sp, #48]
	str	w8, [sp, #12]
	ldr	w8, [sp, #44]
	str	w8, [sp, #16]
	mov	w8, #0                          ; =0x0
	str	wzr, [sp, #20]
	ldr	x10, [sp, #32]
	str	x10, [sp, #24]
	ldur	q0, [sp, #8]
	mov	x10, #49328                     ; =0xc0b0
	movk	x10, #6, lsl #16
	add	x10, x9, x10
	str	q0, [x10]
	ldr	x9, [sp, #24]
	str	x9, [x10, #16]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_work
_la_work:                               ; @la_work
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #32924                     ; =0x809c
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #4194304                    ; =0x400000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB88_2
	b	LBB88_1
LBB88_1:
	ldr	x0, [sp, #16]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.84@PAGE
	add	x4, x4, l_.str.84@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB88_3
LBB88_2:
	ldr	w10, [sp, #12]
	ldr	x8, [sp, #16]
	mov	x9, #32924                      ; =0x809c
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB88_3
LBB88_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_clone
_la_clone:                              ; @la_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	mov	x0, #1                          ; =0x1
	mov	x1, #24                         ; =0x18
	bl	_calloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB89_2
	b	LBB89_1
LBB89_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB89_6
LBB89_2:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	bl	_nvm_affine_state_clone
	ldr	x8, [sp]
	str	x0, [x8]
	ldrh	w8, [sp, #14]
	add	w8, w8, #256
	mov	w8, w8
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	bl	_calloc
	ldr	x8, [sp]
	str	x0, [x8, #8]
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB89_4
	b	LBB89_3
LBB89_3:
	ldr	x8, [sp]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB89_5
	b	LBB89_4
LBB89_4:
	ldr	x0, [sp]
	bl	_la_frame_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB89_6
LBB89_5:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp]
	strh	w8, [x9, #16]
	ldr	x8, [sp]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #8]
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp]
	stur	x8, [x29, #-8]
	b	LBB89_6
LBB89_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_transfer
_la_transfer:                           ; @la_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3104
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #616]
	str	w1, [sp, #612]
	str	x2, [sp, #600]
	ldr	x10, [sp, #616]
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	add	x10, x10, #144
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #592]
	ldr	x8, [sp, #592]
	ldr	w8, [x8, #64]
	str	w8, [sp, #588]
	ldr	x8, [sp, #600]
	ldr	x8, [x8]
	str	x8, [sp, #576]
	ldr	x8, [sp, #576]
	ldr	x8, [x8]
	str	x8, [sp, #568]
	ldr	x8, [sp, #568]
	ldrh	w8, [x8, #56]
	strh	w8, [sp, #566]
	ldr	x8, [sp, #600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #566]
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	str	x8, [sp, #552]
	ldr	x8, [sp, #592]
	str	x8, [sp, #544]
	ldr	x8, [sp, #544]
	ldrb	w8, [x8]
	strb	w8, [sp, #543]
	ldrb	w0, [sp, #543]
	bl	_isa_get_info
	str	x0, [sp, #528]
	ldr	x8, [sp, #528]
	cbnz	x8, LBB90_2
	b	LBB90_1
LBB90_1:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.85@PAGE
	add	x4, x4, l_.str.85@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_2:
	ldr	x8, [sp, #528]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #524]
	ldr	x8, [sp, #528]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #520]
	strh	wzr, [sp, #518]
	ldr	x8, [sp, #544]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #516]
	ldrb	w8, [sp, #543]
	subs	w8, w8, #88
	b.ne	LBB90_4
	b	LBB90_3
LBB90_3:
	ldr	x8, [sp, #544]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #524]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #520]
	b	LBB90_4
LBB90_4:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #13
	b.eq	LBB90_6
	b	LBB90_5
LBB90_5:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #14
	b.ne	LBB90_21
	b	LBB90_6
LBB90_6:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #13
	b.ne	LBB90_8
	b	LBB90_7
LBB90_7:
	ldr	x8, [sp, #544]
	ldr	w8, [x8, #8]
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB90_9
LBB90_8:
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB90_9
LBB90_9:
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	str	w8, [sp, #512]
	ldr	x0, [sp, #568]
	ldr	w1, [sp, #512]
	bl	_la_owner_layout
	tbz	w0, #0, LBB90_11
	b	LBB90_10
LBB90_10:
	ldr	x0, [sp, #576]
	ldr	w1, [sp, #512]
	add	x2, sp, #1048
	mov	w3, #256                        ; =0x100
	add	x4, sp, #518
	bl	_nvm_affine_record_fields
	tbnz	w0, #0, LBB90_12
	b	LBB90_11
LBB90_11:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #136]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.86@PAGE
	add	x4, x4, l_.str.86@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_12:
	ldr	x0, [sp, #616]
	ldrh	w1, [sp, #518]
	bl	_la_work
	tbnz	w0, #0, LBB90_14
	b	LBB90_13
LBB90_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_14:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #13
	b.ne	LBB90_16
	b	LBB90_15
LBB90_15:
	ldrh	w8, [sp, #518]
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	b	LBB90_17
LBB90_16:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	b	LBB90_17
LBB90_17:
	ldr	w8, [sp, #132]                  ; 4-byte Folded Reload
	str	w8, [sp, #524]
	ldrb	w8, [sp, #543]
	subs	w8, w8, #13
	b.ne	LBB90_19
	b	LBB90_18
LBB90_18:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #128]                  ; 4-byte Folded Spill
	b	LBB90_20
LBB90_19:
	ldrh	w8, [sp, #518]
	str	w8, [sp, #128]                  ; 4-byte Folded Spill
	b	LBB90_20
LBB90_20:
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	str	w8, [sp, #520]
	b	LBB90_21
LBB90_21:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #59
	b.ne	LBB90_23
	b	LBB90_22
LBB90_22:
	ldr	x8, [sp, #616]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #544]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #504]
	ldr	x8, [sp, #504]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #524]
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #21]
	str	w8, [sp, #520]
	b	LBB90_23
LBB90_23:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #61
	b.ne	LBB90_32
	b	LBB90_24
LBB90_24:
	ldr	x0, [sp, #616]
	ldrh	w1, [sp, #566]
	bl	_la_work
	tbnz	w0, #0, LBB90_26
	b	LBB90_25
LBB90_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_26:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #616]
	ldr	x9, [x9]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.ne	LBB90_30
	b	LBB90_27
LBB90_27:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB90_29
	b	LBB90_28
LBB90_28:
	ldr	x0, [sp, #568]
	ldr	x9, [sp, #552]
	ldr	x8, [sp, #568]
	ldr	x10, [x9]
	str	x10, [sp, #1032]
	ldr	w9, [x9, #8]
	str	w9, [sp, #1040]
	ldr	x1, [sp, #1032]
	ldr	x2, [sp, #1040]
	ldr	x3, [x8, #32]
	bl	_la_type
	tbz	w0, #0, LBB90_30
	b	LBB90_29
LBB90_29:
	ldr	x0, [sp, #576]
	ldr	x8, [sp, #568]
	ldrb	w9, [x8, #32]
	add	x8, sp, #496
	strb	w9, [sp, #496]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #499]
	ldr	x8, [sp, #568]
	ldr	w8, [x8, #36]
	str	w8, [sp, #500]
	ldr	x1, [sp, #496]
	bl	_nvm_affine_can_exit_type
	tbnz	w0, #0, LBB90_31
	b	LBB90_30
LBB90_30:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #124]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.87@PAGE
	add	x4, x4, l_.str.87@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #124]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_31:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_32:
	ldr	w8, [sp, #524]
	tbnz	w8, #31, LBB90_35
	b	LBB90_33
LBB90_33:
	ldr	w8, [sp, #520]
	tbnz	w8, #31, LBB90_35
	b	LBB90_34
LBB90_34:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #524]
	subs	w8, w8, w9
	b.ge	LBB90_36
	b	LBB90_35
LBB90_35:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.88@PAGE
	add	x4, x4, l_.str.88@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_36:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #524]
	subs	w8, w8, w9
	ldr	w9, [sp, #520]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.ls	LBB90_38
	b	LBB90_37
LBB90_37:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.89@PAGE
	add	x4, x4, l_.str.89@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_38:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	w9, [sp, #524]
	subs	w8, w8, w9
	strh	w8, [sp, #494]
	str	xzr, [sp, #480]
	str	wzr, [sp, #488]
	ldrb	w0, [sp, #543]
	add	x1, sp, #478
	bl	_la_scalar
	str	w0, [sp, #472]
	ldr	w8, [sp, #472]
	tbnz	w8, #31, LBB90_58
	b	LBB90_39
LBB90_39:
	ldr	w8, [sp, #472]
	and	w0, w8, #0xff
	bl	_la_tag
	str	x0, [sp, #1016]
	str	x1, [sp, #1024]
	ldr	x8, [sp, #1016]
	str	x8, [sp, #456]
	ldr	w8, [sp, #1024]
	str	w8, [sp, #464]
	ldr	x8, [sp, #456]
	str	x8, [sp, #480]
	ldr	w8, [sp, #464]
	str	w8, [sp, #488]
	ldr	w8, [sp, #524]
	subs	w8, w8, #2
	b.le	LBB90_41
	b	LBB90_40
LBB90_40:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.90@PAGE
	add	x4, x4, l_.str.90@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_41:
	ldr	w8, [sp, #524]
	ldr	x9, [sp, #592]
	strb	w8, [x9, #96]
	ldrh	w8, [sp, #494]
	strh	w8, [sp, #454]
	b	LBB90_42
LBB90_42:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #454]
	ldr	x9, [sp, #600]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB90_57
	b	LBB90_43
LBB90_43:                               ;   in Loop: Header=BB90_42 Depth=1
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #454]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #440]
	ldr	w8, [x8, #8]
	str	w8, [sp, #448]
	ldrb	w8, [sp, #448]
	cbnz	w8, LBB90_47
	b	LBB90_44
LBB90_44:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrb	w8, [sp, #449]
	cbnz	w8, LBB90_47
	b	LBB90_45
LBB90_45:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #440]
	cbz	w8, LBB90_47
	b	LBB90_46
LBB90_46:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #440]
	and	w8, w8, #0xffffffe0
	cbz	w8, LBB90_48
	b	LBB90_47
LBB90_47:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #120]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.91@PAGE
	add	x4, x4, l_.str.91@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #120]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_48:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #454]
	ldrh	w9, [sp, #494]
	subs	w8, w8, w9
	strh	w8, [sp, #438]
	ldrh	w11, [sp, #440]
	ldr	x8, [sp, #592]
	add	x9, x8, #88
	ldrh	w8, [sp, #438]
	mov	x10, x8
	ldrh	w8, [x9, x10, lsl #1]
	orr	w8, w8, w11
	strh	w8, [x9, x10, lsl #1]
	ldrh	w8, [sp, #478]
	ldr	x9, [sp, #592]
	add	x9, x9, #92
	ldrh	w10, [sp, #438]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	ldrh	w8, [sp, #478]
	cbz	w8, LBB90_55
	b	LBB90_49
LBB90_49:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #440]
	ldrh	w9, [sp, #478]
	subs	w8, w8, w9
	b.eq	LBB90_55
	b	LBB90_50
LBB90_50:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrb	w0, [sp, #543]
	bl	_la_optional_comparison
	tbz	w0, #0, LBB90_53
	b	LBB90_51
LBB90_51:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #440]
	tbz	w8, #3, LBB90_53
	b	LBB90_52
LBB90_52:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #440]
	mov	w9, #-10                        ; =0xfffffff6
	and	w8, w8, w9
	cbz	w8, LBB90_54
	b	LBB90_53
LBB90_53:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #116]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.92@PAGE
	add	x4, x4, l_.str.92@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_54:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w9, [sp, #438]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	and	w10, w8, #0xff
	ldr	x9, [sp, #592]
	ldrb	w8, [x9, #97]
	orr	w8, w8, w10
	strb	w8, [x9, #97]
	b	LBB90_55
LBB90_55:                               ;   in Loop: Header=BB90_42 Depth=1
	b	LBB90_56
LBB90_56:                               ;   in Loop: Header=BB90_42 Depth=1
	ldrh	w8, [sp, #454]
	add	w8, w8, #1
	strh	w8, [sp, #454]
	b	LBB90_42
LBB90_57:
	b	LBB90_176
LBB90_58:
	ldrb	w8, [sp, #543]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB90_174
; %bb.59:
	ldr	x11, [sp, #104]                 ; 8-byte Folded Reload
	adrp	x10, lJTI90_0@PAGE
	add	x10, x10, lJTI90_0@PAGEOFF
Ltmp16:
	adr	x8, Ltmp16
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB90_60:
	b	LBB90_175
LBB90_61:
	mov	w0, #5                          ; =0x5
	bl	_la_tag
	str	x0, [sp, #1000]
	str	x1, [sp, #1008]
	ldr	x8, [sp, #1000]
	str	x8, [sp, #424]
	ldr	w8, [sp, #1008]
	str	w8, [sp, #432]
	ldr	x8, [sp, #424]
	str	x8, [sp, #480]
	ldr	w8, [sp, #432]
	str	w8, [sp, #488]
	b	LBB90_175
LBB90_62:
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #8]
	cbz	w8, LBB90_64
	b	LBB90_63
LBB90_63:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #100]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.93@PAGE
	add	x4, x4, l_.str.93@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_64:
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x11, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w10, #12                        ; =0xc
	smaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	ldr	x9, [sp, #600]
	ldrh	w8, [x9, #16]
	add	w8, w8, #1
	strh	w8, [x9, #16]
	b	LBB90_179
LBB90_65:
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #480]
	ldr	w8, [x8, #8]
	str	w8, [sp, #488]
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w10, #12                        ; =0xc
	smaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #12                         ; =0xc
	smaddl	x9, w8, w9, x10
	ldr	x8, [sp, #480]
	str	x8, [x9]
	ldr	w8, [sp, #488]
	str	w8, [x9, #8]
	b	LBB90_179
LBB90_66:
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #480]
	ldr	w8, [x8, #8]
	str	w8, [sp, #488]
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w10, #12                        ; =0xc
	smaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #12                         ; =0xc
	smaddl	x9, w8, w9, x10
	ldr	x11, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #3
	mov	w10, #12                        ; =0xc
	smaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #3
	mov	w9, #12                         ; =0xc
	smaddl	x9, w8, w9, x10
	ldr	x8, [sp, #480]
	str	x8, [x9]
	ldr	w8, [sp, #488]
	str	w8, [x9, #8]
	b	LBB90_179
LBB90_67:
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #8]
	cbz	w8, LBB90_69
	b	LBB90_68
LBB90_68:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #96]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.94@PAGE
	add	x4, x4, l_.str.94@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_69:
	b	LBB90_175
LBB90_70:
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #416]
	ldrb	w8, [sp, #416]
	subs	w8, w8, #8
	b.ne	LBB90_75
	b	LBB90_71
LBB90_71:
	ldr	x0, [sp, #568]
	ldr	w1, [sp, #420]
	bl	_la_owner_layout
	tbz	w0, #0, LBB90_73
	b	LBB90_72
LBB90_72:
	ldr	x0, [sp, #576]
	ldrh	w1, [sp, #516]
	mov	x2, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x3, x8
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB90_74
	b	LBB90_73
LBB90_73:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #92]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.95@PAGE
	add	x4, x4, l_.str.95@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #92]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_74:
	ldr	w0, [sp, #420]
	bl	_la_owner
	str	x0, [sp, #984]
	str	x1, [sp, #992]
	ldr	x8, [sp, #984]
	str	x8, [sp, #400]
	ldr	w8, [sp, #992]
	str	w8, [sp, #408]
	ldr	x8, [sp, #400]
	str	x8, [sp, #480]
	ldr	w8, [sp, #408]
	str	w8, [sp, #488]
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #488]
	ldrh	w8, [sp, #516]
	strh	w8, [sp, #482]
	b	LBB90_81
LBB90_75:
	ldr	x8, [sp, #600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #516]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #480]
	ldr	w8, [x8, #8]
	str	w8, [sp, #488]
	ldr	x0, [sp, #568]
	ldr	x8, [sp, #480]
	str	x8, [sp, #968]
	ldr	w8, [sp, #488]
	str	w8, [sp, #976]
	ldr	x1, [sp, #968]
	ldr	x2, [sp, #976]
	ldr	x3, [sp, #416]
	bl	_la_type
	tbz	w0, #0, LBB90_79
	b	LBB90_76
LBB90_76:
	ldrb	w0, [sp, #416]
	bl	_scalar
	tbnz	w0, #0, LBB90_78
	b	LBB90_77
LBB90_77:
	ldrb	w8, [sp, #416]
	subs	w8, w8, #5
	b.ne	LBB90_80
	b	LBB90_78
LBB90_78:
	ldr	x8, [sp, #576]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB90_80
	b	LBB90_79
LBB90_79:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #88]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.96@PAGE
	add	x4, x4, l_.str.96@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #88]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_80:
	b	LBB90_81
LBB90_81:
	b	LBB90_175
LBB90_82:
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #392]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #480]
	ldr	w8, [x8, #8]
	str	w8, [sp, #488]
	ldrb	w8, [sp, #392]
	subs	w8, w8, #8
	b.eq	LBB90_85
	b	LBB90_83
LBB90_83:
	ldrb	w8, [sp, #488]
	cbnz	w8, LBB90_85
	b	LBB90_84
LBB90_84:
	ldr	x0, [sp, #568]
	ldr	x8, [sp, #480]
	str	x8, [sp, #952]
	ldr	w8, [sp, #488]
	str	w8, [sp, #960]
	ldr	x1, [sp, #952]
	ldr	x2, [sp, #960]
	ldr	x3, [sp, #392]
	bl	_la_type
	tbnz	w0, #0, LBB90_86
	b	LBB90_85
LBB90_85:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #84]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.97@PAGE
	add	x4, x4, l_.str.97@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_86:
	ldrb	w0, [sp, #392]
	bl	_scalar
	tbz	w0, #0, LBB90_89
	b	LBB90_87
LBB90_87:
	ldr	x0, [sp, #576]
	ldrh	w1, [sp, #516]
	bl	_nvm_affine_scalar_define
	tbnz	w0, #0, LBB90_89
	b	LBB90_88
LBB90_88:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #80]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.98@PAGE
	add	x4, x4, l_.str.98@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #80]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_89:
	ldrb	w8, [sp, #392]
	subs	w8, w8, #5
	b.ne	LBB90_92
	b	LBB90_90
LBB90_90:
	ldr	x0, [sp, #576]
	ldrh	w1, [sp, #516]
	bl	_nvm_affine_string_define
	tbnz	w0, #0, LBB90_92
	b	LBB90_91
LBB90_91:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #76]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.99@PAGE
	add	x4, x4, l_.str.99@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #76]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_92:
	ldr	x8, [sp, #600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #516]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x8, [sp, #480]
	str	x8, [x9]
	ldr	w8, [sp, #488]
	str	w8, [x9, #8]
	b	LBB90_175
LBB90_93:
	ldr	x0, [sp, #616]
	ldr	x8, [sp, #600]
	ldrh	w1, [x8, #16]
	bl	_la_work
	tbnz	w0, #0, LBB90_95
	b	LBB90_94
LBB90_94:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_95:
	ldr	x0, [sp, #568]
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w1, [x8, #4]
	bl	_la_owner_layout
	tbz	w0, #0, LBB90_98
	b	LBB90_96
LBB90_96:
	ldr	x0, [sp, #600]
	ldrh	w1, [sp, #566]
	ldrh	w2, [sp, #516]
	bl	_la_observed
	tbnz	w0, #0, LBB90_98
	b	LBB90_97
LBB90_97:
	ldr	x0, [sp, #576]
	ldrh	w1, [sp, #516]
	add	x2, sp, #384
	bl	_nvm_affine_take_local
	tbnz	w0, #0, LBB90_99
	b	LBB90_98
LBB90_98:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #72]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.100@PAGE
	add	x4, x4, l_.str.100@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_99:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #11
	b.ne	LBB90_101
	b	LBB90_100
LBB90_100:
	ldr	w0, [sp, #388]
	bl	_la_owner
	str	x0, [sp, #936]
	str	x1, [sp, #944]
	ldr	x8, [sp, #936]
	str	x8, [sp, #368]
	ldr	w8, [sp, #944]
	str	w8, [sp, #376]
	ldr	x8, [sp, #368]
	str	x8, [sp, #480]
	ldr	w8, [sp, #376]
	str	w8, [sp, #488]
	b	LBB90_109
LBB90_101:
	strh	wzr, [sp, #366]
	b	LBB90_102
LBB90_102:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #366]
	ldrh	w9, [sp, #518]
	subs	w8, w8, w9
	b.ge	LBB90_108
	b	LBB90_103
LBB90_103:                              ;   in Loop: Header=BB90_102 Depth=1
	ldr	x10, [sp, #552]
	ldr	x11, [sp, #600]
	ldrh	w8, [x11, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x11, #16]
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldrh	w8, [sp, #366]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #1048
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.ne	LBB90_105
	b	LBB90_104
LBB90_104:                              ;   in Loop: Header=BB90_102 Depth=1
	ldrh	w8, [sp, #366]
	mov	x9, x8
	add	x8, sp, #1048
	add	x8, x8, x9, lsl #3
	ldr	w0, [x8, #4]
	bl	_la_owner
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [sp, #920]
	str	x1, [sp, #928]
	ldr	x8, [sp, #920]
	str	x8, [sp, #352]
	ldr	w8, [sp, #928]
	str	w8, [sp, #360]
	ldr	x8, [sp, #352]
	str	x8, [x9]
	ldr	w8, [sp, #360]
	str	w8, [x9, #8]
	b	LBB90_106
LBB90_105:                              ;   in Loop: Header=BB90_102 Depth=1
	ldrh	w8, [sp, #366]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #1048
	ldrb	w0, [x8, x9]
	bl	_la_tag
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [sp, #904]
	str	x1, [sp, #912]
	ldr	x8, [sp, #904]
	str	x8, [sp, #336]
	ldr	w8, [sp, #912]
	str	w8, [sp, #344]
	ldr	x8, [sp, #336]
	str	x8, [x9]
	ldr	w8, [sp, #344]
	str	w8, [x9, #8]
	b	LBB90_106
LBB90_106:                              ;   in Loop: Header=BB90_102 Depth=1
	b	LBB90_107
LBB90_107:                              ;   in Loop: Header=BB90_102 Depth=1
	ldrh	w8, [sp, #366]
	add	w8, w8, #1
	strh	w8, [sp, #366]
	b	LBB90_102
LBB90_108:
	b	LBB90_179
LBB90_109:
	b	LBB90_175
LBB90_110:
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.ne	LBB90_113
	b	LBB90_111
LBB90_111:
	ldr	x0, [sp, #568]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #516]
                                        ; kill: def $x9 killed $w9
	ldr	x11, [x10]
	str	x11, [sp, #888]
	ldr	w10, [x10, #8]
	str	w10, [sp, #896]
	ldr	x1, [sp, #888]
	ldr	x2, [sp, #896]
	ldr	x3, [x8, x9, lsl #3]
	bl	_la_type
	tbz	w0, #0, LBB90_113
	b	LBB90_112
LBB90_112:
	ldr	x0, [sp, #576]
	ldrh	w1, [sp, #516]
	add	x8, sp, #328
	mov	w9, #8                          ; =0x8
	strb	w9, [sp, #328]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #331]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	str	w8, [sp, #332]
	ldr	x2, [sp, #328]
	bl	_nvm_affine_put_local
	tbnz	w0, #0, LBB90_114
	b	LBB90_113
LBB90_113:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #60]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.101@PAGE
	add	x4, x4, l_.str.101@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_114:
	b	LBB90_175
LBB90_115:
	strh	wzr, [sp, #326]
	b	LBB90_116
LBB90_116:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #326]
	ldrh	w9, [sp, #518]
	subs	w8, w8, w9
	b.ge	LBB90_121
	b	LBB90_117
LBB90_117:                              ;   in Loop: Header=BB90_116 Depth=1
	ldr	x0, [sp, #568]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
	ldrh	w9, [sp, #326]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldrh	w9, [sp, #326]
	mov	x11, x9
	add	x9, sp, #1048
	mov	x10, x9
	add	x10, x10, x11, lsl #3
	ldrb	w10, [x10]
	strb	w10, [sp, #316]
	strb	wzr, [sp, #317]
	strh	wzr, [sp, #318]
	ldrh	w10, [sp, #326]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	str	w9, [sp, #320]
	ldr	x9, [x8]
	str	x9, [sp, #872]
	ldr	w8, [x8, #8]
	str	w8, [sp, #880]
	ldr	x1, [sp, #872]
	ldr	x2, [sp, #880]
	add	x8, sp, #61
	ldur	x3, [x8, #255]
	bl	_la_type
	tbnz	w0, #0, LBB90_119
	b	LBB90_118
LBB90_118:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #56]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.102@PAGE
	add	x4, x4, l_.str.102@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_119:                              ;   in Loop: Header=BB90_116 Depth=1
	b	LBB90_120
LBB90_120:                              ;   in Loop: Header=BB90_116 Depth=1
	ldrh	w8, [sp, #326]
	add	w8, w8, #1
	strh	w8, [sp, #326]
	b	LBB90_116
LBB90_121:
	ldr	x8, [sp, #544]
	ldr	w0, [x8, #8]
	bl	_la_owner
	str	x0, [sp, #856]
	str	x1, [sp, #864]
	ldr	x8, [sp, #856]
	str	x8, [sp, #304]
	ldr	w8, [sp, #864]
	str	w8, [sp, #312]
	ldr	x8, [sp, #304]
	str	x8, [sp, #480]
	ldr	w8, [sp, #312]
	str	w8, [sp, #488]
	b	LBB90_175
LBB90_122:
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #288]
	ldr	w8, [x8, #8]
	str	w8, [sp, #296]
	ldr	x8, [sp, #544]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #286]
	ldrb	w8, [sp, #296]
	subs	w8, w8, #2
	b.ne	LBB90_128
	b	LBB90_123
LBB90_123:
	ldrb	w8, [sp, #297]
	cbnz	w8, LBB90_128
	b	LBB90_124
LBB90_124:
	ldrh	w8, [sp, #290]
	ldrh	w9, [sp, #566]
	subs	w8, w8, w9
	b.ge	LBB90_128
	b	LBB90_125
LBB90_125:
	ldr	x8, [sp, #576]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #290]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB90_128
	b	LBB90_126
LBB90_126:
	ldr	x0, [sp, #568]
	ldr	w1, [sp, #292]
	bl	_la_owner_layout
	tbz	w0, #0, LBB90_128
	b	LBB90_127
LBB90_127:
	ldrh	w8, [sp, #286]
	ldr	x9, [sp, #568]
	ldr	x9, [x9, #8]
	ldr	w10, [sp, #292]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB90_129
	b	LBB90_128
LBB90_128:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.103@PAGE
	add	x4, x4, l_.str.103@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_129:
	ldr	x8, [sp, #568]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #292]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #286]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #272]
	ldr	w8, [x8, #8]
	str	w8, [sp, #280]
	ldrb	w8, [sp, #272]
	subs	w8, w8, #8
	b.ne	LBB90_131
	b	LBB90_130
LBB90_130:
	ldr	w0, [sp, #276]
	bl	_la_owner
	str	x0, [sp, #840]
	str	x1, [sp, #848]
	ldr	x8, [sp, #840]
	str	x8, [sp, #256]
	ldr	w8, [sp, #848]
	str	w8, [sp, #264]
	ldr	x8, [sp, #256]
	str	x8, [sp, #480]
	ldr	w8, [sp, #264]
	str	w8, [sp, #488]
	b	LBB90_132
LBB90_131:
	ldrb	w0, [sp, #272]
	bl	_la_tag
	str	x0, [sp, #824]
	str	x1, [sp, #832]
	ldr	x8, [sp, #824]
	str	x8, [sp, #240]
	ldr	w8, [sp, #832]
	str	w8, [sp, #248]
	ldr	x8, [sp, #240]
	str	x8, [sp, #480]
	ldr	w8, [sp, #248]
	str	w8, [sp, #488]
	b	LBB90_132
LBB90_132:
	ldrb	w8, [sp, #488]
	cbz	w8, LBB90_134
	b	LBB90_133
LBB90_133:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #488]
	ldrh	w8, [sp, #290]
	strh	w8, [sp, #482]
	b	LBB90_134
LBB90_134:
	b	LBB90_175
LBB90_135:
	ldr	x8, [sp, #544]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #3
	b.eq	LBB90_137
	b	LBB90_136
LBB90_136:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #48]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.104@PAGE
	add	x4, x4, l_.str.104@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_137:
	ldrh	w8, [sp, #494]
	strh	w8, [sp, #238]
	b	LBB90_138
LBB90_138:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #238]
	ldr	x9, [sp, #600]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB90_143
	b	LBB90_139
LBB90_139:                              ;   in Loop: Header=BB90_138 Depth=1
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #238]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #808]
	ldr	w8, [x8, #8]
	str	w8, [sp, #816]
	ldr	x0, [sp, #808]
	ldr	x1, [sp, #816]
	mov	w2, #3                          ; =0x3
	bl	_la_exact
	tbnz	w0, #0, LBB90_141
	b	LBB90_140
LBB90_140:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #44]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.105@PAGE
	add	x4, x4, l_.str.105@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_141:                              ;   in Loop: Header=BB90_138 Depth=1
	b	LBB90_142
LBB90_142:                              ;   in Loop: Header=BB90_138 Depth=1
	ldrh	w8, [sp, #238]
	add	w8, w8, #1
	strh	w8, [sp, #238]
	b	LBB90_138
LBB90_143:
	mov	w0, #7                          ; =0x7
	bl	_la_tag
	str	x0, [sp, #792]
	str	x1, [sp, #800]
	ldr	x8, [sp, #792]
	str	x8, [sp, #224]
	ldr	w8, [sp, #800]
	str	w8, [sp, #232]
	ldr	x8, [sp, #224]
	str	x8, [sp, #480]
	ldr	w8, [sp, #232]
	str	w8, [sp, #488]
	b	LBB90_175
LBB90_144:
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #776]
	ldr	w8, [x8, #8]
	str	w8, [sp, #784]
	ldr	x0, [sp, #776]
	ldr	x1, [sp, #784]
	mov	w2, #7                          ; =0x7
	bl	_la_exact
	tbnz	w0, #0, LBB90_146
	b	LBB90_145
LBB90_145:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #40]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.106@PAGE
	add	x4, x4, l_.str.106@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_146:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #83
	b.eq	LBB90_148
	b	LBB90_147
LBB90_147:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #84
	b.ne	LBB90_150
	b	LBB90_148
LBB90_148:
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
	mov	w2, #1                          ; =0x1
	add	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #760]
	ldr	w8, [x8, #8]
	str	w8, [sp, #768]
	ldr	x0, [sp, #760]
	ldr	x1, [sp, #768]
	bl	_la_exact
	tbnz	w0, #0, LBB90_150
	b	LBB90_149
LBB90_149:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.107@PAGE
	add	x4, x4, l_.str.107@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_150:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #81
	b.eq	LBB90_152
	b	LBB90_151
LBB90_151:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #84
	b.ne	LBB90_154
	b	LBB90_152
LBB90_152:
	ldr	x10, [sp, #552]
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #744]
	ldr	w8, [x8, #8]
	str	w8, [sp, #752]
	ldr	x0, [sp, #744]
	ldr	x1, [sp, #752]
	mov	w2, #3                          ; =0x3
	bl	_la_exact
	tbnz	w0, #0, LBB90_154
	b	LBB90_153
LBB90_153:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #32]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.108@PAGE
	add	x4, x4, l_.str.108@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_154:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #83
	b.ne	LBB90_156
	b	LBB90_155
LBB90_155:
	mov	w0, #3                          ; =0x3
	bl	_la_tag
	str	x0, [sp, #728]
	str	x1, [sp, #736]
	ldr	x8, [sp, #728]
	str	x8, [sp, #208]
	ldr	w8, [sp, #736]
	str	w8, [sp, #216]
	ldr	x8, [sp, #208]
	str	x8, [sp, #480]
	ldr	w8, [sp, #216]
	str	w8, [sp, #488]
	ldrh	w8, [sp, #480]
	orr	w8, w8, #0x1
	strh	w8, [sp, #480]
	b	LBB90_157
LBB90_156:
	ldrb	w9, [sp, #543]
	mov	w8, #7                          ; =0x7
	subs	w9, w9, #85
	csinc	w0, w8, wzr, ne
	bl	_la_tag
	str	x0, [sp, #712]
	str	x1, [sp, #720]
	ldr	x8, [sp, #712]
	str	x8, [sp, #192]
	ldr	w8, [sp, #720]
	str	w8, [sp, #200]
	ldr	x8, [sp, #192]
	str	x8, [sp, #480]
	ldr	w8, [sp, #200]
	str	w8, [sp, #488]
	b	LBB90_157
LBB90_157:
	b	LBB90_175
LBB90_158:
	ldr	x8, [sp, #544]
	ldr	w8, [x8, #8]
	str	w8, [sp, #188]
	ldr	x8, [sp, #616]
	add	x8, x8, #16
	ldr	w9, [sp, #188]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	str	x8, [sp, #176]
	strh	wzr, [sp, #174]
	b	LBB90_159
LBB90_159:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #174]
	ldr	x9, [sp, #176]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB90_164
	b	LBB90_160
LBB90_160:                              ;   in Loop: Header=BB90_159 Depth=1
	ldr	x0, [sp, #568]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
	ldrh	w9, [sp, #174]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x10, w8, w9, x10
	ldr	x8, [sp, #176]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #174]
                                        ; kill: def $x9 killed $w9
	ldr	x11, [x10]
	str	x11, [sp, #696]
	ldr	w10, [x10, #8]
	str	w10, [sp, #704]
	ldr	x1, [sp, #696]
	ldr	x2, [sp, #704]
	ldr	x3, [x8, x9, lsl #3]
	bl	_la_type
	tbnz	w0, #0, LBB90_162
	b	LBB90_161
LBB90_161:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.109@PAGE
	add	x4, x4, l_.str.109@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_162:                              ;   in Loop: Header=BB90_159 Depth=1
	b	LBB90_163
LBB90_163:                              ;   in Loop: Header=BB90_159 Depth=1
	ldrh	w8, [sp, #174]
	add	w8, w8, #1
	strh	w8, [sp, #174]
	b	LBB90_159
LBB90_164:
	ldr	x8, [sp, #176]
	ldrb	w8, [x8, #32]
	subs	w8, w8, #8
	b.ne	LBB90_166
	b	LBB90_165
LBB90_165:
	ldr	x8, [sp, #176]
	ldr	w0, [x8, #36]
	bl	_la_owner
	str	x0, [sp, #680]
	str	x1, [sp, #688]
	ldr	x8, [sp, #680]
	str	x8, [sp, #160]
	ldr	w8, [sp, #688]
	str	w8, [sp, #168]
	ldr	x8, [sp, #160]
	str	x8, [sp, #480]
	ldr	w8, [sp, #168]
	str	w8, [sp, #488]
	b	LBB90_167
LBB90_166:
	ldr	x8, [sp, #176]
	ldrb	w0, [x8, #32]
	bl	_la_tag
	str	x0, [sp, #664]
	str	x1, [sp, #672]
	ldr	x8, [sp, #664]
	str	x8, [sp, #144]
	ldr	w8, [sp, #672]
	str	w8, [sp, #152]
	ldr	x8, [sp, #144]
	str	x8, [sp, #480]
	ldr	w8, [sp, #152]
	str	w8, [sp, #488]
	b	LBB90_167
LBB90_167:
	b	LBB90_175
LBB90_168:
	ldr	x9, [sp, #592]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #96]
	ldr	x8, [sp, #552]
	ldrh	w9, [sp, #494]
	mov	x10, x9
	mov	x9, #12                         ; =0xc
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w11, [x8, x10]
	ldr	x10, [sp, #592]
	ldrh	w8, [x10, #88]
	orr	w8, w8, w11
	strh	w8, [x10, #88]
	ldr	x10, [sp, #592]
	mov	w8, #2                          ; =0x2
	strh	w8, [x10, #92]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #648]
	ldr	w8, [x8, #8]
	str	w8, [sp, #656]
	ldr	x0, [sp, #648]
	ldr	x1, [sp, #656]
	mov	w2, #1                          ; =0x1
	bl	_la_exact
	tbnz	w0, #0, LBB90_170
	b	LBB90_169
LBB90_169:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.110@PAGE
	add	x4, x4, l_.str.110@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_170:
	b	LBB90_175
LBB90_171:
	ldr	x9, [sp, #592]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #96]
	ldr	x8, [sp, #552]
	ldrh	w9, [sp, #494]
	mov	x10, x9
	mov	x9, #12                         ; =0xc
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w11, [x8, x10]
	ldr	x10, [sp, #592]
	ldrh	w8, [x10, #88]
	orr	w8, w8, w11
	strh	w8, [x10, #88]
	ldr	x10, [sp, #592]
	mov	w8, #16                         ; =0x10
	strh	w8, [x10, #92]
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #632]
	ldr	w8, [x8, #8]
	str	w8, [sp, #640]
	ldr	x0, [sp, #632]
	ldr	x1, [sp, #640]
	mov	w2, #4                          ; =0x4
	bl	_la_exact
	tbnz	w0, #0, LBB90_173
	b	LBB90_172
LBB90_172:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.111@PAGE
	add	x4, x4, l_.str.111@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_173:
	b	LBB90_175
LBB90_174:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #588]
	ldr	x8, [sp, #592]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.112@PAGE
	add	x4, x4, l_.str.112@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_175:
	b	LBB90_176
LBB90_176:
	ldrh	w8, [sp, #494]
	ldr	w9, [sp, #520]
	add	w8, w8, w9
	ldr	x9, [sp, #600]
	strh	w8, [x9, #16]
	ldr	w8, [sp, #520]
	cbz	w8, LBB90_178
	b	LBB90_177
LBB90_177:
	ldr	x10, [sp, #552]
	ldrh	w8, [sp, #494]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x8, [sp, #480]
	str	x8, [x9]
	ldr	w8, [sp, #488]
	str	w8, [x9, #8]
	b	LBB90_178
LBB90_178:
	b	LBB90_179
LBB90_179:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #616]
	ldr	x9, [x9, #8]
	add	x11, x9, #36
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	mov	x10, #116                       ; =0x74
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.le	LBB90_181
	b	LBB90_180
LBB90_180:
	ldr	x8, [sp, #600]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #616]
	ldr	x9, [x9, #8]
	add	x11, x9, #36
	ldr	w9, [sp, #588]
                                        ; kill: def $x9 killed $w9
	mov	x10, #116                       ; =0x74
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	strh	w8, [x9, #4]
	b	LBB90_181
LBB90_181:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #56
	b.eq	LBB90_184
	b	LBB90_182
LBB90_182:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #57
	b.eq	LBB90_184
	b	LBB90_183
LBB90_183:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #58
	b.ne	LBB90_189
	b	LBB90_184
LBB90_184:
	ldr	x0, [sp, #616]
	ldr	x8, [sp, #592]
	ldr	w1, [x8, #76]
	ldr	x2, [sp, #600]
	bl	_la_join
	tbnz	w0, #0, LBB90_186
	b	LBB90_185
LBB90_185:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_186:
	ldrb	w8, [sp, #543]
	subs	w8, w8, #56
	b.ne	LBB90_188
	b	LBB90_187
LBB90_187:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_188:
	b	LBB90_189
LBB90_189:
	ldr	x0, [sp, #616]
	ldr	x8, [sp, #592]
	ldr	w1, [x8, #72]
	ldr	x2, [sp, #600]
	bl	_la_join
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB90_190
LBB90_190:
	ldrb	w8, [sp, #631]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB90_192
	b	LBB90_191
LBB90_191:
	bl	___stack_chk_fail
LBB90_192:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #3104
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI90_0:
	.long	LBB90_60-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_61-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_62-Ltmp16
	.long	LBB90_67-Ltmp16
	.long	LBB90_65-Ltmp16
	.long	LBB90_66-Ltmp16
	.long	LBB90_93-Ltmp16
	.long	LBB90_110-Ltmp16
	.long	LBB90_115-Ltmp16
	.long	LBB90_93-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_70-Ltmp16
	.long	LBB90_82-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_60-Ltmp16
	.long	LBB90_171-Ltmp16
	.long	LBB90_171-Ltmp16
	.long	LBB90_158-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_135-Ltmp16
	.long	LBB90_144-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_144-Ltmp16
	.long	LBB90_144-Ltmp16
	.long	LBB90_144-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_135-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_168-Ltmp16
	.long	LBB90_171-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_168-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_174-Ltmp16
	.long	LBB90_122-Ltmp16
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_frame_free
_la_frame_free:                         ; @la_frame_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB91_2
	b	LBB91_1
LBB91_1:
	b	LBB91_3
LBB91_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB91_3
LBB91_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_leaf
_array_leaf:                            ; @array_leaf
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x1, [sp, #48]
	str	x0, [sp, #40]
	str	x2, [sp, #32]
	str	wzr, [sp, #28]
	b	LBB92_1
LBB92_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #256
	b.hi	LBB92_10
	b	LBB92_2
LBB92_2:                                ;   in Loop: Header=BB92_1 Depth=1
	ldrb	w8, [sp, #48]
	subs	w8, w8, #7
	b.eq	LBB92_4
	b	LBB92_3
LBB92_3:
	ldr	x9, [sp, #32]
	ldr	x8, [sp, #48]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB92_11
LBB92_4:                                ;   in Loop: Header=BB92_1 Depth=1
	ldrb	w8, [sp, #49]
	cbnz	w8, LBB92_7
	b	LBB92_5
LBB92_5:                                ;   in Loop: Header=BB92_1 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #48]
	cbz	x8, LBB92_7
	b	LBB92_6
LBB92_6:                                ;   in Loop: Header=BB92_1 Depth=1
	ldr	w8, [sp, #52]
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #48]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB92_8
	b	LBB92_7
LBB92_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB92_11
LBB92_8:                                ;   in Loop: Header=BB92_1 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #48]
	add	x8, x8, #4
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldrb	w8, [sp, #16]
	strb	w8, [sp, #8]
	strb	wzr, [sp, #9]
	strh	wzr, [sp, #10]
	ldr	w8, [sp, #20]
	str	w8, [sp, #12]
	ldr	x8, [sp, #8]
	str	x8, [sp, #48]
	b	LBB92_9
LBB92_9:                                ;   in Loop: Header=BB92_1 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB92_1
LBB92_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB92_11
LBB92_11:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function authoritative_root
_authoritative_root:                    ; @authoritative_root
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB93_3
	b	LBB93_1
LBB93_1:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB93_3
	b	LBB93_2
LBB93_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #28]
	b	LBB93_11
LBB93_3:
	strh	wzr, [sp, #6]
	b	LBB93_4
LBB93_4:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #64]
	subs	w8, w8, w9
	b.ge	LBB93_10
	b	LBB93_5
LBB93_5:                                ;   in Loop: Header=BB93_4 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #72
	ldrh	w9, [sp, #6]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB93_8
	b	LBB93_6
LBB93_6:                                ;   in Loop: Header=BB93_4 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #72
	ldrh	w9, [sp, #6]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB93_8
	b	LBB93_7
LBB93_7:
	ldr	x8, [sp, #16]
	add	x8, x8, #72
	ldrh	w9, [sp, #6]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #12]
	str	w8, [sp, #28]
	b	LBB93_11
LBB93_8:                                ;   in Loop: Header=BB93_4 Depth=1
	b	LBB93_9
LBB93_9:                                ;   in Loop: Header=BB93_4 Depth=1
	ldrh	w8, [sp, #6]
	add	w8, w8, #1
	strh	w8, [sp, #6]
	b	LBB93_4
LBB93_10:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB93_11
LBB93_11:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_declarations
_mc_declarations:                       ; @mc_declarations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-32]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_mc_checked_state
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB94_2
	b	LBB94_1
LBB94_1:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-20]
	mov	w1, #4                          ; =0x4
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.27@PAGE
	add	x4, x4, l_.str.27@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB94_32
LBB94_2:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-16]
	add	x11, x9, #16
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x8, [x9, #8]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldrh	w8, [x8, #56]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB94_7
	b	LBB94_3
LBB94_3:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldrh	w8, [x8, #58]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB94_7
	b	LBB94_4
LBB94_4:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldr	x1, [x8, #32]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_mc_signature
	tbz	w0, #0, LBB94_7
	b	LBB94_5
LBB94_5:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldrb	w8, [x8, #32]
	ldur	x9, [x29, #-32]
	ldrb	w9, [x9, #20]
	subs	w8, w8, w9
	b.ne	LBB94_7
	b	LBB94_6
LBB94_6:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #21]
	ldur	x9, [x29, #-40]
	ldr	x9, [x9]
	ldrb	w9, [x9, #32]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB94_8
	b	LBB94_7
LBB94_7:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-20]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.28@PAGE
	add	x4, x4, l_.str.28@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB94_32
LBB94_8:
	sturh	wzr, [x29, #-42]
	b	LBB94_9
LBB94_9:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-42]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB94_31
	b	LBB94_10
LBB94_10:                               ;   in Loop: Header=BB94_9 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldurh	w9, [x29, #-42]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #40]
	strb	wzr, [sp, #39]
	ldurh	w8, [x29, #-42]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB94_12
	b	LBB94_11
LBB94_11:                               ;   in Loop: Header=BB94_9 Depth=1
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #40]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_mc_signature
	strb	w0, [sp, #39]
	b	LBB94_27
LBB94_12:                               ;   in Loop: Header=BB94_9 Depth=1
	ldrb	w8, [sp, #41]
	cbnz	w8, LBB94_26
	b	LBB94_13
LBB94_13:                               ;   in Loop: Header=BB94_9 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #8
	b.ne	LBB94_20
	b	LBB94_14
LBB94_14:                               ;   in Loop: Header=BB94_9 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ldr	w9, [sp, #44]
	ldr	x8, [sp, #24]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.hs	LBB94_19
	b	LBB94_15
LBB94_15:                               ;   in Loop: Header=BB94_9 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #44]
	bl	_mc_owned_layout
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB94_18
	b	LBB94_16
LBB94_16:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	x8, [sp, #24]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	w9, [x8, x9, lsl #2]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB94_18
	b	LBB94_17
LBB94_17:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	x8, [sp, #24]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB94_18
LBB94_18:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB94_19
LBB94_19:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB94_25
LBB94_20:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	w9, [sp, #44]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB94_24
	b	LBB94_21
LBB94_21:                               ;   in Loop: Header=BB94_9 Depth=1
	ldrb	w0, [sp, #40]
	bl	_scalar
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbnz	w0, #0, LBB94_23
	b	LBB94_22
LBB94_22:                               ;   in Loop: Header=BB94_9 Depth=1
	ldrb	w8, [sp, #40]
	subs	w8, w8, #7
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB94_23
LBB94_23:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB94_24
LBB94_24:                               ;   in Loop: Header=BB94_9 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #39]
	b	LBB94_25
LBB94_25:                               ;   in Loop: Header=BB94_9 Depth=1
	b	LBB94_26
LBB94_26:                               ;   in Loop: Header=BB94_9 Depth=1
	b	LBB94_27
LBB94_27:                               ;   in Loop: Header=BB94_9 Depth=1
	ldrb	w8, [sp, #39]
	tbnz	w8, #0, LBB94_29
	b	LBB94_28
LBB94_28:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-20]
	mov	w1, #1                          ; =0x1
	str	w1, [sp]                        ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.29@PAGE
	add	x4, x4, l_.str.29@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB94_32
LBB94_29:                               ;   in Loop: Header=BB94_9 Depth=1
	b	LBB94_30
LBB94_30:                               ;   in Loop: Header=BB94_9 Depth=1
	ldurh	w8, [x29, #-42]
	add	w8, w8, #1
	sturh	w8, [x29, #-42]
	b	LBB94_9
LBB94_31:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB94_32
LBB94_32:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_supported
_mc_supported:                          ; @mc_supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-2]
	ldurb	w0, [x29, #-2]
	sub	x1, x29, #3
	bl	_mc_scalar_op
	tbnz	w0, #31, LBB95_2
	b	LBB95_1
LBB95_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB95_6
LBB95_2:
	ldurb	w8, [x29, #-2]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB95_5
; %bb.3:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI95_0@PAGE
	add	x10, x10, lJTI95_0@PAGEOFF
Ltmp19:
	adr	x8, Ltmp19
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB95_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB95_6
LBB95_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB95_6
LBB95_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI95_0:
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_5-Ltmp19
	.long	LBB95_4-Ltmp19
	.long	LBB95_4-Ltmp19
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_owned_layout
_mc_owned_layout:                       ; @mc_owned_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	w1, [sp, #44]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB96_2
	b	LBB96_1
LBB96_1:
	ldr	x8, [sp, #32]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #1
	b.eq	LBB96_3
	b	LBB96_2
LBB96_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB96_16
LBB96_3:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbnz	w8, LBB96_5
	b	LBB96_4
LBB96_4:
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.ls	LBB96_6
	b	LBB96_5
LBB96_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB96_16
LBB96_6:
	strh	wzr, [sp, #22]
	b	LBB96_7
LBB96_7:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB96_15
	b	LBB96_8
LBB96_8:                                ;   in Loop: Header=BB96_7 Depth=1
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.eq	LBB96_11
	b	LBB96_9
LBB96_9:                                ;   in Loop: Header=BB96_7 Depth=1
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	b.eq	LBB96_11
	b	LBB96_10
LBB96_10:                               ;   in Loop: Header=BB96_7 Depth=1
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB96_12
	b	LBB96_11
LBB96_11:                               ;   in Loop: Header=BB96_7 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB96_13
	b	LBB96_12
LBB96_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB96_16
LBB96_13:                               ;   in Loop: Header=BB96_7 Depth=1
	b	LBB96_14
LBB96_14:                               ;   in Loop: Header=BB96_7 Depth=1
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB96_7
LBB96_15:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB96_16
LBB96_16:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_graph
_mc_graph:                              ; @mc_graph
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x10, [x29, #-16]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
	add	x10, x10, #16
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #17]
	subs	w8, w8, #2
	b.ne	LBB97_2
	b	LBB97_1
LBB97_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB97_12
LBB97_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #17]
	subs	w8, w8, #1
	b.ne	LBB97_4
	b	LBB97_3
LBB97_3:
	ldur	x0, [x29, #-16]
	ldur	w2, [x29, #-20]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.30@PAGE
	add	x4, x4, l_.str.30@PAGEOFF
	bl	_mc_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB97_12
LBB97_4:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #17]
	str	wzr, [sp, #12]
	b	LBB97_5
LBB97_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB97_11
	b	LBB97_6
LBB97_6:                                ;   in Loop: Header=BB97_5 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #16]
	ldr	w10, [sp, #12]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB97_9
	b	LBB97_7
LBB97_7:                                ;   in Loop: Header=BB97_5 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #12]
	bl	_mc_graph
	tbnz	w0, #0, LBB97_9
	b	LBB97_8
LBB97_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB97_12
LBB97_9:                                ;   in Loop: Header=BB97_5 Depth=1
	b	LBB97_10
LBB97_10:                               ;   in Loop: Header=BB97_5 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB97_5
LBB97_11:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #17]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB97_12
LBB97_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_checked_state
_mc_checked_state:                      ; @mc_checked_state
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	stur	x8, [x29, #-32]
	mov	x0, #1                          ; =0x1
	mov	x1, #200                        ; =0xc8
	bl	_calloc
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB98_2
	b	LBB98_1
LBB98_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB98_55
LBB98_2:
	mov	x0, #1                          ; =0x1
	mov	x1, #80                         ; =0x50
	bl	_calloc
	ldur	x8, [x29, #-40]
	str	x0, [x8]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	cbnz	x8, LBB98_4
	b	LBB98_3
LBB98_3:
	ldur	x0, [x29, #-40]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB98_55
LBB98_4:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-48]
	str	x8, [x9, #64]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #72]
	ldur	x9, [x29, #-40]
	mov	x8, #1                          ; =0x1
	str	x8, [x9, #56]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldur	x8, [x29, #-48]
	add	x2, x8, #8
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB98_6
	b	LBB98_5
LBB98_5:
	b	LBB98_54
LBB98_6:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	cbz	w8, LBB98_8
	b	LBB98_7
LBB98_7:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB98_9
LBB98_8:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB98_9
LBB98_9:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	bl	_malloc
	ldur	x8, [x29, #-48]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB98_11
	b	LBB98_10
LBB98_10:
	b	LBB98_54
LBB98_11:
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #5144]
	add	x1, x8, #8
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #5144]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #5152]
	mov	x2, x8
	add	x0, sp, #72
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #68
	bl	_nvm_v2_u32
	cbnz	w0, LBB98_16
	b	LBB98_12
LBB98_12:
	add	x0, sp, #72
	add	x1, sp, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB98_16
	b	LBB98_13
LBB98_13:
	ldr	w8, [sp, #64]
	mov	x1, x8
	add	x0, sp, #72
	add	x2, sp, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB98_16
	b	LBB98_14
LBB98_14:
	add	x0, sp, #72
	bl	_nvm_v2_align4
	cbnz	w0, LBB98_16
	b	LBB98_15
LBB98_15:
	add	x0, sp, #72
	add	x1, sp, #68
	bl	_nvm_v2_u32
	cbz	w0, LBB98_17
	b	LBB98_16
LBB98_16:
	b	LBB98_54
LBB98_17:
	str	wzr, [sp, #52]
	b	LBB98_18
LBB98_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB98_39 Depth 2
                                        ;     Child Loop BB98_44 Depth 2
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hi	LBB98_53
	b	LBB98_19
LBB98_19:                               ;   in Loop: Header=BB98_18 Depth=1
	add	x0, sp, #72
	add	x1, sp, #50
	bl	_nvm_v2_u16
	cbnz	w0, LBB98_22
	b	LBB98_20
LBB98_20:                               ;   in Loop: Header=BB98_18 Depth=1
	add	x0, sp, #72
	add	x1, sp, #48
	bl	_nvm_v2_u16
	cbnz	w0, LBB98_22
	b	LBB98_21
LBB98_21:                               ;   in Loop: Header=BB98_18 Depth=1
	add	x0, sp, #72
	add	x1, sp, #40
	bl	_slot_read
	tbnz	w0, #0, LBB98_23
	b	LBB98_22
LBB98_22:
	b	LBB98_54
LBB98_23:                               ;   in Loop: Header=BB98_18 Depth=1
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB98_43
	b	LBB98_24
LBB98_24:                               ;   in Loop: Header=BB98_18 Depth=1
	ldrh	w8, [sp, #50]
	ldur	x9, [x29, #-48]
	strh	w8, [x9, #56]
	ldrh	w8, [sp, #48]
	ldur	x9, [x29, #-48]
	strh	w8, [x9, #58]
	ldur	x9, [x29, #-48]
	ldr	x8, [sp, #40]
	str	x8, [x9, #32]
	ldrh	w8, [sp, #50]
	cbz	w8, LBB98_26
	b	LBB98_25
LBB98_25:                               ;   in Loop: Header=BB98_18 Depth=1
	ldrh	w8, [sp, #50]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB98_27
LBB98_26:                               ;   in Loop: Header=BB98_18 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB98_27
LBB98_27:                               ;   in Loop: Header=BB98_18 Depth=1
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldur	x8, [x29, #-48]
	str	x0, [x8, #40]
	ldrh	w8, [sp, #50]
	cbz	w8, LBB98_29
	b	LBB98_28
LBB98_28:                               ;   in Loop: Header=BB98_18 Depth=1
	ldrh	w8, [sp, #50]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB98_30
LBB98_29:                               ;   in Loop: Header=BB98_18 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB98_30
LBB98_30:                               ;   in Loop: Header=BB98_18 Depth=1
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	ldur	x8, [x29, #-40]
	str	x0, [x8, #8]
	ldrh	w8, [sp, #50]
	cbz	w8, LBB98_32
	b	LBB98_31
LBB98_31:                               ;   in Loop: Header=BB98_18 Depth=1
	ldrh	w8, [sp, #50]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB98_33
LBB98_32:                               ;   in Loop: Header=BB98_18 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB98_33
LBB98_33:                               ;   in Loop: Header=BB98_18 Depth=1
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsl	x0, x8, #1
	bl	_malloc
	ldur	x8, [x29, #-40]
	str	x0, [x8, #16]
	mov	x0, #1                          ; =0x1
	mov	x1, #56                         ; =0x38
	bl	_calloc
	ldur	x8, [x29, #-40]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #40]
	cbz	x8, LBB98_37
	b	LBB98_34
LBB98_34:                               ;   in Loop: Header=BB98_18 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #8]
	cbz	x8, LBB98_37
	b	LBB98_35
LBB98_35:                               ;   in Loop: Header=BB98_18 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #16]
	cbz	x8, LBB98_37
	b	LBB98_36
LBB98_36:                               ;   in Loop: Header=BB98_18 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB98_38
	b	LBB98_37
LBB98_37:
	b	LBB98_54
LBB98_38:                               ;   in Loop: Header=BB98_18 Depth=1
	strh	wzr, [sp, #38]
	b	LBB98_39
LBB98_39:                               ;   Parent Loop BB98_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #38]
	ldrh	w9, [sp, #50]
	subs	w8, w8, w9
	b.ge	LBB98_42
	b	LBB98_40
LBB98_40:                               ;   in Loop: Header=BB98_39 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #38]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB98_41
LBB98_41:                               ;   in Loop: Header=BB98_39 Depth=2
	ldrh	w8, [sp, #38]
	add	w8, w8, #1
	strh	w8, [sp, #38]
	b	LBB98_39
LBB98_42:                               ;   in Loop: Header=BB98_18 Depth=1
	b	LBB98_43
LBB98_43:                               ;   in Loop: Header=BB98_18 Depth=1
	strh	wzr, [sp, #36]
	b	LBB98_44
LBB98_44:                               ;   Parent Loop BB98_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #36]
	ldrh	w9, [sp, #50]
	subs	w8, w8, w9
	b.ge	LBB98_51
	b	LBB98_45
LBB98_45:                               ;   in Loop: Header=BB98_44 Depth=2
	add	x0, sp, #72
	add	x1, sp, #28
	bl	_slot_read
	tbnz	w0, #0, LBB98_47
	b	LBB98_46
LBB98_46:
	b	LBB98_54
LBB98_47:                               ;   in Loop: Header=BB98_44 Depth=2
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB98_49
	b	LBB98_48
LBB98_48:                               ;   in Loop: Header=BB98_44 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x9, [x8, #40]
	ldrh	w8, [sp, #36]
	mov	x10, x8
	ldur	x8, [sp, #28]
	str	x8, [x9, x10, lsl #3]
	ldrh	w8, [sp, #36]
	ldrh	w9, [sp, #48]
	subs	w8, w8, w9
	cset	w8, lt
	ldur	x9, [x29, #-40]
	ldr	x9, [x9, #8]
	ldrh	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB98_49
LBB98_49:                               ;   in Loop: Header=BB98_44 Depth=2
	b	LBB98_50
LBB98_50:                               ;   in Loop: Header=BB98_44 Depth=2
	ldrh	w8, [sp, #36]
	add	w8, w8, #1
	strh	w8, [sp, #36]
	b	LBB98_44
LBB98_51:                               ;   in Loop: Header=BB98_18 Depth=1
	b	LBB98_52
LBB98_52:                               ;   in Loop: Header=BB98_18 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB98_18
LBB98_53:
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-8]
	b	LBB98_55
LBB98_54:
	ldur	x0, [x29, #-40]
	bl	_nvm_affine_state_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB98_55
LBB98_55:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_signature
_mc_signature:                          ; @mc_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	str	x0, [sp, #24]
	strb	w2, [sp, #23]
	ldurb	w8, [x29, #-11]
	cbz	w8, LBB99_2
	b	LBB99_1
LBB99_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB99_13
LBB99_2:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB99_4
	b	LBB99_3
LBB99_3:
	ldr	x0, [sp, #24]
	ldur	w1, [x29, #-8]
	bl	_mc_owned_layout
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB99_13
LBB99_4:
	ldur	w9, [x29, #-8]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB99_12
	b	LBB99_5
LBB99_5:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB99_11
	b	LBB99_6
LBB99_6:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB99_11
	b	LBB99_7
LBB99_7:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB99_11
	b	LBB99_8
LBB99_8:
	ldrb	w8, [sp, #23]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB99_10
	b	LBB99_9
LBB99_9:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB99_10
LBB99_10:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB99_11
LBB99_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB99_12
LBB99_12:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB99_13
LBB99_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_scalar_op
_mc_scalar_op:                          ; @mc_scalar_op
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #27]
	str	x1, [sp, #16]
	ldr	x9, [sp, #16]
	mov	w8, #16                         ; =0x10
	strb	w8, [x9]
	ldrb	w8, [sp, #27]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	subs	x8, x8, #225
	b.hi	LBB100_12
; %bb.1:
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	adrp	x10, lJTI100_0@PAGE
	add	x10, x10, lJTI100_0@PAGEOFF
Ltmp22:
	adr	x8, Ltmp22
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB100_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_3:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_4:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_5:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_6:
	str	wzr, [sp, #28]
	b	LBB100_13
LBB100_7:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_8:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_9:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	strb	w8, [x9]
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_10:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	strb	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_11:
	ldr	x9, [sp, #16]
	mov	w8, #4                          ; =0x4
	strb	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_12:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB100_13
LBB100_13:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI100_0:
	.long	LBB100_2-Ltmp22
	.long	LBB100_3-Ltmp22
	.long	LBB100_5-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_6-Ltmp22
	.long	LBB100_4-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_7-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_9-Ltmp22
	.long	LBB100_9-Ltmp22
	.long	LBB100_9-Ltmp22
	.long	LBB100_9-Ltmp22
	.long	LBB100_9-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_8-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_10-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_12-Ltmp22
	.long	LBB100_11-Ltmp22
	.long	LBB100_11-Ltmp22
	.long	LBB100_11-Ltmp22
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_enqueue
_mc_enqueue:                            ; @mc_enqueue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	w1, [sp, #20]
	ldr	x10, [sp, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	add	x10, x10, #208
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #96]
	tbz	w8, #0, LBB101_2
	b	LBB101_1
LBB101_1:
	b	LBB101_3
LBB101_2:
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #96]
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #24]
	mov	x10, #32988                     ; =0x80dc
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	x11, [sp, #24]
	mov	x10, #49376                     ; =0xc0e0
	movk	x10, #6, lsl #16
	ldr	w11, [x11, x10]
                                        ; kill: def $x11 killed $w11
	str	w8, [x9, x11, lsl #2]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #24]
	str	w8, [x9, x10]
	ldr	x8, [sp, #24]
	mov	x9, #49380                      ; =0xc0e4
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB101_3
LBB101_3:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_type
_mc_type:                               ; @mc_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	stur	x2, [x29, #-12]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	ldurb	w8, [x29, #-11]
	cbz	w8, LBB102_2
	b	LBB102_1
LBB102_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB102_12
LBB102_2:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB102_9
	b	LBB102_3
LBB102_3:
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-8]
	bl	_mc_owned_layout
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB102_8
	b	LBB102_4
LBB102_4:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB102_8
	b	LBB102_5
LBB102_5:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #256
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB102_8
	b	LBB102_6
LBB102_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	x8, LBB102_8
	b	LBB102_7
LBB102_7:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #16]
	ldur	w9, [x29, #-8]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB102_8
LBB102_8:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB102_12
LBB102_9:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldurb	w1, [x29, #-12]
	ldr	q0, [x8]
	add	x0, sp, #16
	str	q0, [sp, #16]
	ldr	x8, [x8, #16]
	str	x8, [sp, #32]
	bl	_mc_exact
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbz	w0, #0, LBB102_11
	b	LBB102_10
LBB102_10:
	ldur	w8, [x29, #-8]
	adds	w8, w8, #1
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB102_11
LBB102_11:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB102_12
LBB102_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_plain
_mc_plain:                              ; @mc_plain
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	str	x8, [sp, #24]
	mov	w8, #31                         ; =0x1f
	strh	w8, [sp, #22]
	ldrb	w8, [x0, #20]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB103_4
	b	LBB103_1
LBB103_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	x8, LBB103_4
	b	LBB103_2
LBB103_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	w8, LBB103_4
	b	LBB103_3
LBB103_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	mov	w9, #-32                        ; =0xffffffe0
	ands	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB103_4
LBB103_4:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_exact
_mc_exact:                              ; @mc_exact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	str	x8, [sp, #24]
	strb	w1, [sp, #23]
	ldrb	w8, [x0, #20]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB104_3
	b	LBB104_1
LBB104_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	x8, LBB104_3
	b	LBB104_2
LBB104_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	ldrb	w10, [sp, #23]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	subs	w8, w8, w9, uxth
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB104_3
LBB104_3:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_check
_mc_check:                              ; @mc_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturh	w2, [x29, #-26]
	sturh	w3, [x29, #-28]
	sturh	w4, [x29, #-30]
	stur	w5, [x29, #-36]
	str	wzr, [sp, #40]
	b	LBB105_1
LBB105_1:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB105_9
	b	LBB105_2
LBB105_2:                               ;   in Loop: Header=BB105_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	add	x10, x8, #2092
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #20                         ; =0x14
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.ne	LBB105_7
	b	LBB105_3
LBB105_3:                               ;   in Loop: Header=BB105_1 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #68]
	subs	w8, w8, w9
	b.ne	LBB105_7
	b	LBB105_4
LBB105_4:                               ;   in Loop: Header=BB105_1 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #8]
	ldurh	w9, [x29, #-26]
	subs	w8, w8, w9
	b.ne	LBB105_7
	b	LBB105_5
LBB105_5:                               ;   in Loop: Header=BB105_1 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB105_7
	b	LBB105_6
LBB105_6:
	ldurh	w10, [x29, #-28]
	ldr	x9, [sp, #32]
	ldrh	w8, [x9, #10]
	orr	w8, w8, w10
	strh	w8, [x9, #10]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-30]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB105_12
LBB105_7:                               ;   in Loop: Header=BB105_1 Depth=1
	b	LBB105_8
LBB105_8:                               ;   in Loop: Header=BB105_1 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB105_1
LBB105_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #20]
	subs	w8, w8, #2, lsl #12             ; =8192
	b.ne	LBB105_11
	b	LBB105_10
LBB105_10:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-24]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-24]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.65@PAGE
	add	x4, x4, l_.str.65@PAGEOFF
	bl	_mc_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB105_12
LBB105_11:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	add	x11, x8, #2092
	ldur	x8, [x29, #-16]
	ldr	x13, [x8, #8]
	mov	x10, #20                        ; =0x14
	ldr	w8, [x13, #20]
                                        ; kill: def $x8 killed $w8
	mov	x12, x8
	mov	w9, #1                          ; =0x1
	add	w12, w12, #1
	str	w12, [x13, #20]
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w10, x11
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #64]
	str	w8, [sp, #12]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #68]
	str	w8, [sp, #16]
	ldurh	w8, [x29, #-26]
	strh	w8, [sp, #20]
	ldurh	w8, [x29, #-28]
	strh	w8, [sp, #22]
	ldurh	w8, [x29, #-30]
	strh	w8, [sp, #24]
	strh	wzr, [sp, #26]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #28]
	ldur	q0, [sp, #12]
	str	q0, [x10]
	ldr	w8, [sp, #28]
	str	w8, [x10, #16]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB105_12
LBB105_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_owner
_mc_owner:                              ; @mc_owner
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp]                        ; 8-byte Folded Spill
	stur	w0, [x29, #-4]
	mov	w0, #8                          ; =0x8
	bl	_mc_tag
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #20]
	ldur	w8, [x29, #-4]
	str	w8, [x9, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_field
_mc_field:                              ; @mc_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	sturb	w2, [x29, #-25]
	stur	w3, [x29, #-32]
	ldrb	w8, [x1, #20]
	cbnz	w8, LBB107_2
	b	LBB107_1
LBB107_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	ldurb	w10, [x29, #-25]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	subs	w8, w8, w9, uxth
	b.eq	LBB107_3
	b	LBB107_2
LBB107_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_3:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #7
	b.ne	LBB107_7
	b	LBB107_4
LBB107_4:
	ldur	w8, [x29, #-32]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB107_6
	b	LBB107_5
LBB107_5:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	q0, [x8]
	add	x1, sp, #64
	str	q0, [sp, #64]
	ldr	x8, [x8, #16]
	str	x8, [sp, #80]
	bl	_mc_array
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB107_6
LBB107_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_7:
	ldurb	w8, [x29, #-25]
	subs	w8, w8, #8
	b.eq	LBB107_11
	b	LBB107_8
LBB107_8:
	ldur	w8, [x29, #-32]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB107_10
	b	LBB107_9
LBB107_9:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	q0, [x8]
	add	x0, sp, #32
	str	q0, [sp, #32]
	ldr	x8, [x8, #16]
	str	x8, [sp, #48]
	bl	_mc_plain
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB107_10
LBB107_10:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_11:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbnz	x8, LBB107_13
	b	LBB107_12
LBB107_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_13:
	str	wzr, [sp, #28]
	b	LBB107_14
LBB107_14:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB107_22
	b	LBB107_15
LBB107_15:                              ;   in Loop: Header=BB107_14 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #28]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB107_20
	b	LBB107_16
LBB107_16:                              ;   in Loop: Header=BB107_14 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x10, x8, #28
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #22]
	subs	w8, w8, #8
	b.ne	LBB107_18
	b	LBB107_17
LBB107_17:                              ;   in Loop: Header=BB107_14 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.eq	LBB107_19
	b	LBB107_18
LBB107_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_19:                              ;   in Loop: Header=BB107_14 Depth=1
	b	LBB107_20
LBB107_20:                              ;   in Loop: Header=BB107_14 Depth=1
	b	LBB107_21
LBB107_21:                              ;   in Loop: Header=BB107_14 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB107_14
LBB107_22:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB107_23
LBB107_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_observed
_mc_observed:                           ; @mc_observed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	strh	w2, [sp, #12]
	strh	wzr, [sp, #10]
	b	LBB108_1
LBB108_1:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB108_7
	b	LBB108_2
LBB108_2:                               ;   in Loop: Header=BB108_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #20]
	subs	w8, w8, #2
	b.ne	LBB108_5
	b	LBB108_3
LBB108_3:                               ;   in Loop: Header=BB108_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #24                         ; =0x18
	smaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	ldrh	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB108_5
	b	LBB108_4
LBB108_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB108_8
LBB108_5:                               ;   in Loop: Header=BB108_1 Depth=1
	b	LBB108_6
LBB108_6:                               ;   in Loop: Header=BB108_1 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB108_1
LBB108_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB108_8
LBB108_8:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mc_array
_mc_array:                              ; @mc_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [sp, #32]
	mov	x8, x1
	str	x8, [sp, #24]
	ldrb	w8, [x1, #20]
	cbnz	w8, LBB109_3
	b	LBB109_1
LBB109_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	subs	w8, w8, #128
	b.ne	LBB109_3
	b	LBB109_2
LBB109_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbnz	x8, LBB109_4
	b	LBB109_3
LBB109_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB109_12
LBB109_4:
	str	wzr, [sp, #20]
	b	LBB109_5
LBB109_5:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #32]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB109_11
	b	LBB109_6
LBB109_6:                               ;   in Loop: Header=BB109_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #20]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB109_9
	b	LBB109_7
LBB109_7:                               ;   in Loop: Header=BB109_5 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x10, x8, #28
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #22]
	subs	w8, w8, #7
	b.eq	LBB109_9
	b	LBB109_8
LBB109_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB109_12
LBB109_9:                               ;   in Loop: Header=BB109_5 Depth=1
	b	LBB109_10
LBB109_10:                              ;   in Loop: Header=BB109_5 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB109_5
LBB109_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB109_12
LBB109_12:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_facts
_la_facts:                              ; @la_facts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-72]
	stur	w1, [x29, #-76]
	ldur	x8, [x29, #-72]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-88]
	ldur	x0, [x29, #-72]
	ldur	w1, [x29, #-76]
	bl	_la_checked_state
	stur	x0, [x29, #-96]
	ldur	x8, [x29, #-96]
	cbnz	x8, LBB110_2
	b	LBB110_1
LBB110_1:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #4                          ; =0x4
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.71@PAGE
	add	x4, x4, l_.str.71@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_2:
	ldur	x8, [x29, #-96]
	ldur	x9, [x29, #-72]
	add	x9, x9, #16
	ldur	w10, [x29, #-76]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x8, [x9, #8]
	ldur	x8, [x29, #-96]
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #8]
	add	x10, x8, #36
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #116                        ; =0x74
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-112]
	ldur	x8, [x29, #-104]
	ldrh	w8, [x8, #56]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB110_7
	b	LBB110_3
LBB110_3:
	ldur	x8, [x29, #-104]
	ldrh	w8, [x8, #58]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB110_7
	b	LBB110_4
LBB110_4:
	ldur	x0, [x29, #-104]
	ldur	x8, [x29, #-104]
	ldr	x1, [x8, #32]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_la_signature
	tbz	w0, #0, LBB110_7
	b	LBB110_5
LBB110_5:
	ldur	x8, [x29, #-104]
	ldrb	w8, [x8, #32]
	ldur	x9, [x29, #-88]
	ldrb	w9, [x9, #20]
	subs	w8, w8, w9
	b.ne	LBB110_7
	b	LBB110_6
LBB110_6:
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #21]
	ldur	x9, [x29, #-104]
	ldrb	w9, [x9, #32]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB110_8
	b	LBB110_7
LBB110_7:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #60]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.72@PAGE
	add	x4, x4, l_.str.72@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_8:
	stur	wzr, [x29, #-116]
	b	LBB110_9
LBB110_9:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB110_19 Depth 2
	ldur	w8, [x29, #-116]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB110_38
	b	LBB110_10
LBB110_10:                              ;   in Loop: Header=BB110_9 Depth=1
	ldur	x0, [x29, #-104]
	ldur	w1, [x29, #-116]
	bl	_la_owner_layout
	tbz	w0, #0, LBB110_36
	b	LBB110_11
LBB110_11:                              ;   in Loop: Header=BB110_9 Depth=1
	ldur	x8, [x29, #-104]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-128]
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-116]
	add	x2, sp, #128
	bl	_nvm_owned_array_layout_fact
	tbnz	w0, #0, LBB110_13
	b	LBB110_12
LBB110_12:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.73@PAGE
	add	x4, x4, l_.str.73@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_13:                              ;   in Loop: Header=BB110_9 Depth=1
	ldrb	w8, [sp, #153]
	subs	w8, w8, #32
	b.hs	LBB110_15
	b	LBB110_14
LBB110_14:                              ;   in Loop: Header=BB110_9 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.ls	LBB110_16
	b	LBB110_15
LBB110_15:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.74@PAGE
	add	x4, x4, l_.str.74@PAGEOFF
	bl	_la_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_16:                              ;   in Loop: Header=BB110_9 Depth=1
	ldur	x0, [x29, #-72]
	ldur	x8, [x29, #-128]
	ldrh	w1, [x8, #2]
	bl	_la_work
	tbnz	w0, #0, LBB110_18
	b	LBB110_17
LBB110_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_18:                              ;   in Loop: Header=BB110_9 Depth=1
	strh	wzr, [sp, #126]
	b	LBB110_19
LBB110_19:                              ;   Parent Loop BB110_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #126]
	ldur	x9, [x29, #-128]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB110_35
	b	LBB110_20
LBB110_20:                              ;   in Loop: Header=BB110_19 Depth=2
	ldur	x8, [x29, #-128]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #126]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	str	x9, [sp, #112]
	ldr	w8, [x8, #8]
	str	w8, [sp, #120]
	ldrb	w8, [sp, #112]
	subs	w8, w8, #8
	b.ne	LBB110_25
	b	LBB110_21
LBB110_21:                              ;   in Loop: Header=BB110_19 Depth=2
	ldr	w8, [sp, #116]
	ldur	w9, [x29, #-116]
	subs	w8, w8, w9
	b.hs	LBB110_23
	b	LBB110_22
LBB110_22:                              ;   in Loop: Header=BB110_19 Depth=2
	ldur	x0, [x29, #-104]
	ldr	w1, [sp, #116]
	bl	_la_owner_layout
	tbnz	w0, #0, LBB110_24
	b	LBB110_23
LBB110_23:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #56]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.75@PAGE
	add	x4, x4, l_.str.75@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_24:                              ;   in Loop: Header=BB110_19 Depth=2
	b	LBB110_33
LBB110_25:                              ;   in Loop: Header=BB110_19 Depth=2
	ldr	w8, [sp, #116]
	adds	w8, w8, #1
	b.ne	LBB110_31
	b	LBB110_26
LBB110_26:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrb	w8, [sp, #112]
	subs	w8, w8, #1
	b.eq	LBB110_32
	b	LBB110_27
LBB110_27:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrb	w8, [sp, #112]
	subs	w8, w8, #4
	b.eq	LBB110_32
	b	LBB110_28
LBB110_28:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrb	w8, [sp, #112]
	subs	w8, w8, #2
	b.eq	LBB110_32
	b	LBB110_29
LBB110_29:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrb	w8, [sp, #112]
	subs	w8, w8, #5
	b.eq	LBB110_32
	b	LBB110_30
LBB110_30:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrb	w8, [sp, #112]
	subs	w8, w8, #7
	b.eq	LBB110_32
	b	LBB110_31
LBB110_31:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.76@PAGE
	add	x4, x4, l_.str.76@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_32:                              ;   in Loop: Header=BB110_19 Depth=2
	b	LBB110_33
LBB110_33:                              ;   in Loop: Header=BB110_19 Depth=2
	b	LBB110_34
LBB110_34:                              ;   in Loop: Header=BB110_19 Depth=2
	ldrh	w8, [sp, #126]
	add	w8, w8, #1
	strh	w8, [sp, #126]
	b	LBB110_19
LBB110_35:                              ;   in Loop: Header=BB110_9 Depth=1
	b	LBB110_36
LBB110_36:                              ;   in Loop: Header=BB110_9 Depth=1
	b	LBB110_37
LBB110_37:                              ;   in Loop: Header=BB110_9 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB110_9
LBB110_38:
	ldur	x8, [x29, #-104]
	ldrh	w8, [x8, #56]
	ldur	x9, [x29, #-112]
	strh	w8, [x9]
	ldur	x8, [x29, #-104]
	ldrh	w8, [x8, #58]
	ldur	x9, [x29, #-112]
	strh	w8, [x9, #2]
	ldur	x8, [x29, #-112]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-104]
	ldur	x8, [x29, #-104]
	ldr	x1, [x8, #32]
	bl	_la_declaration
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-40]
	stur	x1, [x29, #-32]
	ldur	x8, [x29, #-40]
	str	x8, [sp, #96]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #104]
	ldr	x8, [sp, #96]
	str	x8, [x9, #8]
	ldr	w8, [sp, #104]
	str	w8, [x9, #16]
	ldur	x8, [x29, #-112]
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB110_40
	b	LBB110_39
LBB110_39:
	ldur	x8, [x29, #-104]
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-104]
	ldr	w9, [x9, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-112]
	strh	w8, [x9, #6]
	b	LBB110_40
LBB110_40:
	strh	wzr, [sp, #94]
	b	LBB110_41
LBB110_41:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #94]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.ge	LBB110_61
	b	LBB110_42
LBB110_42:                              ;   in Loop: Header=BB110_41 Depth=1
	ldur	x8, [x29, #-104]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #94]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #80]
	ldrh	w8, [sp, #94]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB110_44
	b	LBB110_43
LBB110_43:                              ;   in Loop: Header=BB110_41 Depth=1
	ldur	x0, [x29, #-104]
	ldr	x1, [sp, #80]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_la_signature
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB110_55
LBB110_44:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrb	w8, [sp, #81]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #32]                   ; 4-byte Folded Spill
	cbnz	w8, LBB110_54
	b	LBB110_45
LBB110_45:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrb	w8, [sp, #80]
	subs	w8, w8, #8
	b.ne	LBB110_47
	b	LBB110_46
LBB110_46:                              ;   in Loop: Header=BB110_41 Depth=1
	ldur	x0, [x29, #-104]
	ldr	w1, [sp, #84]
	bl	_la_owner_layout
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB110_53
LBB110_47:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w9, [sp, #84]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b.ne	LBB110_52
	b	LBB110_48
LBB110_48:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrb	w0, [sp, #80]
	bl	_scalar
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB110_51
	b	LBB110_49
LBB110_49:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrb	w9, [sp, #80]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #5
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB110_51
	b	LBB110_50
LBB110_50:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrb	w8, [sp, #80]
	subs	w8, w8, #7
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB110_51
LBB110_51:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB110_52
LBB110_52:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB110_53
LBB110_53:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB110_54
LBB110_54:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB110_55
LBB110_55:                              ;   in Loop: Header=BB110_41 Depth=1
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #79]
	ldrb	w8, [sp, #79]
	tbnz	w8, #0, LBB110_57
	b	LBB110_56
LBB110_56:
	ldur	x0, [x29, #-72]
	ldur	w2, [x29, #-76]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.77@PAGE
	add	x4, x4, l_.str.77@PAGEOFF
	bl	_la_stop
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_57:                              ;   in Loop: Header=BB110_41 Depth=1
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #8]
	add	x10, x8, #964
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #3072                       ; =0xc00
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x0, [x29, #-104]
	ldr	x1, [sp, #80]
	bl	_la_declaration
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stur	x0, [x29, #-56]
	stur	x1, [x29, #-48]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #64]
	ldur	w8, [x29, #-48]
	str	w8, [sp, #72]
	ldr	x8, [sp, #64]
	str	x8, [x9]
	ldr	w8, [sp, #72]
	str	w8, [x9, #8]
	ldrh	w8, [sp, #94]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ge	LBB110_59
	b	LBB110_58
LBB110_58:                              ;   in Loop: Header=BB110_41 Depth=1
	ldur	x8, [x29, #-112]
	add	x11, x8, #20
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x11
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #8]
	add	x12, x8, #964
	ldur	w8, [x29, #-76]
                                        ; kill: def $x8 killed $w8
	mov	x11, #3072                      ; =0xc00
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x11, w8, w11, x12
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	b	LBB110_59
LBB110_59:                              ;   in Loop: Header=BB110_41 Depth=1
	b	LBB110_60
LBB110_60:                              ;   in Loop: Header=BB110_41 Depth=1
	ldrh	w8, [sp, #94]
	add	w8, w8, #1
	strh	w8, [sp, #94]
	b	LBB110_41
LBB110_61:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-57]
	b	LBB110_62
LBB110_62:
	ldurb	w8, [x29, #-57]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB110_64
	b	LBB110_63
LBB110_63:
	bl	___stack_chk_fail
LBB110_64:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_supported
_la_supported:                          ; @la_supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-2]
	ldurb	w0, [x29, #-2]
	sub	x1, x29, #4
	bl	_la_scalar
	tbnz	w0, #31, LBB111_2
	b	LBB111_1
LBB111_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB111_6
LBB111_2:
	ldurb	w8, [x29, #-2]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB111_5
; %bb.3:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI111_0@PAGE
	add	x10, x10, lJTI111_0@PAGEOFF
Ltmp28:
	adr	x8, Ltmp28
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB111_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB111_6
LBB111_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB111_6
LBB111_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI111_0:
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_5-Ltmp28
	.long	LBB111_4-Ltmp28
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_checked_state
_la_checked_state:                      ; @la_checked_state
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	mov	x0, #1                          ; =0x1
	mov	x1, #200                        ; =0xc8
	bl	_calloc
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB112_2
	b	LBB112_1
LBB112_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB112_57
LBB112_2:
	mov	x0, #1                          ; =0x1
	mov	x1, #80                         ; =0x50
	bl	_calloc
	ldur	x8, [x29, #-32]
	str	x0, [x8]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	cbnz	x8, LBB112_4
	b	LBB112_3
LBB112_3:
	ldur	x0, [x29, #-32]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB112_57
LBB112_4:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	ldur	x9, [x29, #-40]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-40]
	str	x8, [x9, #64]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #72]
	ldur	x9, [x29, #-32]
	mov	x8, #1                          ; =0x1
	str	x8, [x9, #56]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8, #8]
	sub	x1, x29, #64
	bl	_nvm_owned_array_transport
	ldur	x0, [x29, #-64]
	ldur	w8, [x29, #-48]
	mov	x1, x8
	ldur	x8, [x29, #-40]
	add	x2, x8, #8
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB112_6
	b	LBB112_5
LBB112_5:
	b	LBB112_56
LBB112_6:
	ldur	x1, [x29, #-56]
	ldur	w8, [x29, #-44]
	mov	x2, x8
	add	x0, sp, #88
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB112_10
	b	LBB112_7
LBB112_7:
	add	x0, sp, #88
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB112_10
	b	LBB112_8
LBB112_8:
	ldr	w8, [sp, #84]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB112_10
	b	LBB112_9
LBB112_9:
	ldr	w8, [sp, #84]
	mov	x1, x8
	add	x0, sp, #88
	add	x2, sp, #72
	bl	_nvm_v2_take
	cbz	w0, LBB112_11
	b	LBB112_10
LBB112_10:
	b	LBB112_56
LBB112_11:
	ldr	w8, [sp, #84]
	cbz	w8, LBB112_13
	b	LBB112_12
LBB112_12:
	ldr	w8, [sp, #84]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB112_14
LBB112_13:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB112_14
LBB112_14:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	mov	w8, w8
	mov	x0, x8
	bl	_malloc
	ldur	x8, [x29, #-40]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB112_16
	b	LBB112_15
LBB112_15:
	b	LBB112_56
LBB112_16:
	ldur	x8, [x29, #-40]
	ldr	x0, [x8, #24]
	ldr	x1, [sp, #72]
	ldr	w8, [sp, #84]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	add	x0, sp, #88
	bl	_nvm_v2_align4
	cbnz	w0, LBB112_18
	b	LBB112_17
LBB112_17:
	add	x0, sp, #88
	add	x1, sp, #80
	bl	_nvm_v2_u32
	cbz	w0, LBB112_19
	b	LBB112_18
LBB112_18:
	b	LBB112_56
LBB112_19:
	str	wzr, [sp, #68]
	b	LBB112_20
LBB112_20:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB112_41 Depth 2
                                        ;     Child Loop BB112_46 Depth 2
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hi	LBB112_55
	b	LBB112_21
LBB112_21:                              ;   in Loop: Header=BB112_20 Depth=1
	add	x0, sp, #88
	add	x1, sp, #66
	bl	_nvm_v2_u16
	cbnz	w0, LBB112_24
	b	LBB112_22
LBB112_22:                              ;   in Loop: Header=BB112_20 Depth=1
	add	x0, sp, #88
	add	x1, sp, #64
	bl	_nvm_v2_u16
	cbnz	w0, LBB112_24
	b	LBB112_23
LBB112_23:                              ;   in Loop: Header=BB112_20 Depth=1
	add	x0, sp, #88
	add	x1, sp, #56
	bl	_slot_read
	tbnz	w0, #0, LBB112_25
	b	LBB112_24
LBB112_24:
	b	LBB112_56
LBB112_25:                              ;   in Loop: Header=BB112_20 Depth=1
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB112_45
	b	LBB112_26
LBB112_26:                              ;   in Loop: Header=BB112_20 Depth=1
	ldrh	w8, [sp, #66]
	ldur	x9, [x29, #-40]
	strh	w8, [x9, #56]
	ldrh	w8, [sp, #64]
	ldur	x9, [x29, #-40]
	strh	w8, [x9, #58]
	ldur	x9, [x29, #-40]
	ldr	x8, [sp, #56]
	str	x8, [x9, #32]
	ldrh	w8, [sp, #66]
	cbz	w8, LBB112_28
	b	LBB112_27
LBB112_27:                              ;   in Loop: Header=BB112_20 Depth=1
	ldrh	w8, [sp, #66]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB112_29
LBB112_28:                              ;   in Loop: Header=BB112_20 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB112_29
LBB112_29:                              ;   in Loop: Header=BB112_20 Depth=1
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldur	x8, [x29, #-40]
	str	x0, [x8, #40]
	ldrh	w8, [sp, #66]
	cbz	w8, LBB112_31
	b	LBB112_30
LBB112_30:                              ;   in Loop: Header=BB112_20 Depth=1
	ldrh	w8, [sp, #66]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB112_32
LBB112_31:                              ;   in Loop: Header=BB112_20 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB112_32
LBB112_32:                              ;   in Loop: Header=BB112_20 Depth=1
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x0, w8
	mov	x1, #1                          ; =0x1
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	str	x8, [x9, #8]
	mov	x1, #56                         ; =0x38
	bl	_calloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #24]
	ldrh	w8, [sp, #66]
	cbz	w8, LBB112_34
	b	LBB112_33
LBB112_33:                              ;   in Loop: Header=BB112_20 Depth=1
	ldrh	w8, [sp, #66]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB112_35
LBB112_34:                              ;   in Loop: Header=BB112_20 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB112_35
LBB112_35:                              ;   in Loop: Header=BB112_20 Depth=1
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsl	x0, x8, #1
	bl	_malloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #40]
	cbz	x8, LBB112_39
	b	LBB112_36
LBB112_36:                              ;   in Loop: Header=BB112_20 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	cbz	x8, LBB112_39
	b	LBB112_37
LBB112_37:                              ;   in Loop: Header=BB112_20 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	cbz	x8, LBB112_39
	b	LBB112_38
LBB112_38:                              ;   in Loop: Header=BB112_20 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB112_40
	b	LBB112_39
LBB112_39:
	b	LBB112_56
LBB112_40:                              ;   in Loop: Header=BB112_20 Depth=1
	strh	wzr, [sp, #54]
	b	LBB112_41
LBB112_41:                              ;   Parent Loop BB112_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #54]
	ldrh	w9, [sp, #66]
	subs	w8, w8, w9
	b.ge	LBB112_44
	b	LBB112_42
LBB112_42:                              ;   in Loop: Header=BB112_41 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #1
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9]
	b	LBB112_43
LBB112_43:                              ;   in Loop: Header=BB112_41 Depth=2
	ldrh	w8, [sp, #54]
	add	w8, w8, #1
	strh	w8, [sp, #54]
	b	LBB112_41
LBB112_44:                              ;   in Loop: Header=BB112_20 Depth=1
	b	LBB112_45
LBB112_45:                              ;   in Loop: Header=BB112_20 Depth=1
	strh	wzr, [sp, #52]
	b	LBB112_46
LBB112_46:                              ;   Parent Loop BB112_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #52]
	ldrh	w9, [sp, #66]
	subs	w8, w8, w9
	b.ge	LBB112_53
	b	LBB112_47
LBB112_47:                              ;   in Loop: Header=BB112_46 Depth=2
	add	x0, sp, #88
	add	x1, sp, #44
	bl	_slot_read
	tbnz	w0, #0, LBB112_49
	b	LBB112_48
LBB112_48:
	b	LBB112_56
LBB112_49:                              ;   in Loop: Header=BB112_46 Depth=2
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB112_51
	b	LBB112_50
LBB112_50:                              ;   in Loop: Header=BB112_46 Depth=2
	ldur	x8, [x29, #-40]
	ldr	x9, [x8, #40]
	ldrh	w8, [sp, #52]
	mov	x10, x8
	ldur	x8, [sp, #44]
	str	x8, [x9, x10, lsl #3]
	ldrh	w8, [sp, #52]
	ldrh	w9, [sp, #64]
	subs	w8, w8, w9
	cset	w8, lt
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	ldrh	w10, [sp, #52]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB112_51
LBB112_51:                              ;   in Loop: Header=BB112_46 Depth=2
	b	LBB112_52
LBB112_52:                              ;   in Loop: Header=BB112_46 Depth=2
	ldrh	w8, [sp, #52]
	add	w8, w8, #1
	strh	w8, [sp, #52]
	b	LBB112_46
LBB112_53:                              ;   in Loop: Header=BB112_20 Depth=1
	b	LBB112_54
LBB112_54:                              ;   in Loop: Header=BB112_20 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB112_20
LBB112_55:
	ldur	x8, [x29, #-32]
	stur	x8, [x29, #-8]
	b	LBB112_57
LBB112_56:
	ldur	x0, [x29, #-32]
	bl	_nvm_affine_state_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB112_57
LBB112_57:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_signature
_la_signature:                          ; @la_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	str	x0, [sp, #24]
	strb	w2, [sp, #23]
	ldurb	w8, [x29, #-11]
	cbz	w8, LBB113_2
	b	LBB113_1
LBB113_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB113_14
LBB113_2:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB113_4
	b	LBB113_3
LBB113_3:
	ldr	x0, [sp, #24]
	ldur	w1, [x29, #-8]
	bl	_la_owner_layout
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB113_14
LBB113_4:
	ldur	w9, [x29, #-8]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB113_13
	b	LBB113_5
LBB113_5:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB113_12
	b	LBB113_6
LBB113_6:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB113_12
	b	LBB113_7
LBB113_7:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB113_12
	b	LBB113_8
LBB113_8:
	ldrb	w8, [sp, #23]
	tbz	w8, #0, LBB113_10
	b	LBB113_9
LBB113_9:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB113_11
LBB113_10:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB113_11
LBB113_11:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB113_12
LBB113_12:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB113_13
LBB113_13:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB113_14
LBB113_14:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_owner_layout
_la_owner_layout:                       ; @la_owner_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w9, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hs	LBB114_3
	b	LBB114_1
LBB114_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w9, w8, #0x3
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB114_3
	b	LBB114_2
LBB114_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB114_3
LBB114_3:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_declaration
_la_declaration:                        ; @la_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x1, [sp, #36]
	str	x0, [sp, #24]
	ldrb	w8, [sp, #36]
	sturb	w8, [x29, #-36]
	ldrb	w8, [sp, #37]
	sturb	w8, [x29, #-35]
	mov	w0, #0                          ; =0x0
	sturh	wzr, [x29, #-34]
	ldr	w8, [sp, #40]
	stur	w8, [x29, #-32]
	ldrb	w8, [sp, #36]
	subs	w8, w8, #8
	str	w0, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB115_2
	b	LBB115_1
LBB115_1:
	ldr	x0, [sp, #24]
	ldr	w1, [sp, #40]
	bl	_la_owner_layout
	str	w0, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB115_2
LBB115_2:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	sub	x8, x29, #36
	sturb	w9, [x29, #-28]
	add	x8, x8, #9
	strh	wzr, [x8]
	sturb	wzr, [x29, #-25]
	ldur	x8, [x29, #-36]
	stur	x8, [x29, #-24]
	ldur	w8, [x29, #-28]
	stur	w8, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x8, [x29, #-16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB115_4
	b	LBB115_3
LBB115_3:
	bl	___stack_chk_fail
LBB115_4:
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_scalar
_la_scalar:                             ; @la_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #27]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	strh	wzr, [x8]
	ldrb	w8, [sp, #27]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	subs	x8, x8, #225
	b.hi	LBB116_13
; %bb.1:
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	adrp	x10, lJTI116_0@PAGE
	add	x10, x10, lJTI116_0@PAGEOFF
Ltmp31:
	adr	x8, Ltmp31
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB116_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_3:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_4:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_5:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_6:
	str	wzr, [sp, #28]
	b	LBB116_14
LBB116_7:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_8:
	ldr	x9, [sp, #16]
	mov	w8, #8                          ; =0x8
	strh	w8, [x9]
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_9:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_10:
	ldr	x9, [sp, #16]
	mov	w8, #8                          ; =0x8
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_11:
	ldr	x9, [sp, #16]
	mov	w8, #16                         ; =0x10
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_12:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB116_14
LBB116_14:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI116_0:
	.long	LBB116_2-Ltmp31
	.long	LBB116_3-Ltmp31
	.long	LBB116_5-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_6-Ltmp31
	.long	LBB116_4-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_12-Ltmp31
	.long	LBB116_12-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_7-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_8-Ltmp31
	.long	LBB116_8-Ltmp31
	.long	LBB116_8-Ltmp31
	.long	LBB116_8-Ltmp31
	.long	LBB116_8-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_9-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_10-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_13-Ltmp31
	.long	LBB116_11-Ltmp31
	.long	LBB116_11-Ltmp31
	.long	LBB116_11-Ltmp31
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_enqueue
_la_enqueue:                            ; @la_enqueue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x10, [sp, #8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
	add	x10, x10, #144
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #98]
	tbz	w8, #0, LBB117_2
	b	LBB117_1
LBB117_1:
	b	LBB117_3
LBB117_2:
	ldr	x8, [sp, #8]
	add	x10, x8, #144
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #98]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	mov	x10, #32928                     ; =0x80a0
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	x11, [sp, #8]
	mov	x10, #49316                     ; =0xc0a4
	movk	x10, #6, lsl #16
	ldr	w11, [x11, x10]
                                        ; kill: def $x11 killed $w11
	str	w8, [x9, x11, lsl #2]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #8]
	str	w8, [x9, x10]
	ldr	x8, [sp, #8]
	mov	x9, #49320                      ; =0xc0a8
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB117_3
LBB117_3:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_type
_la_type:                               ; @la_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #40]
	ldur	w8, [x29, #-16]
	str	w8, [sp, #48]
	str	x3, [sp, #32]
	str	x0, [sp, #24]
	ldrb	w8, [sp, #33]
	cbz	w8, LBB118_2
	b	LBB118_1
LBB118_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB118_12
LBB118_2:
	ldrb	w8, [sp, #32]
	subs	w8, w8, #8
	b.ne	LBB118_9
	b	LBB118_3
LBB118_3:
	ldr	x0, [sp, #24]
	ldr	w1, [sp, #36]
	bl	_la_owner_layout
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB118_8
	b	LBB118_4
LBB118_4:
	ldrb	w8, [sp, #49]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbnz	w8, LBB118_8
	b	LBB118_5
LBB118_5:
	ldrb	w9, [sp, #48]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB118_8
	b	LBB118_6
LBB118_6:
	ldrh	w9, [sp, #40]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #256
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB118_8
	b	LBB118_7
LBB118_7:
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #36]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB118_8
LBB118_8:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB118_12
LBB118_9:
	ldr	w8, [sp, #36]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB118_11
	b	LBB118_10
LBB118_10:
	ldrb	w2, [sp, #32]
	ldr	x8, [sp, #40]
	stur	x8, [x29, #-40]
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-32]
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-32]
	bl	_la_exact
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB118_11
LBB118_11:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB118_12
LBB118_12:
	ldurb	w8, [x29, #-41]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB118_14
	b	LBB118_13
LBB118_13:
	bl	___stack_chk_fail
LBB118_14:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_optional_comparison
_la_optional_comparison:                ; @la_optional_comparison
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	ldrb	w8, [sp, #14]
	subs	w8, w8, #216
	subs	w8, w8, #5
	b.hi	LBB119_2
	b	LBB119_1
LBB119_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB119_3
LBB119_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB119_3
LBB119_3:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_owner
_la_owner:                              ; @la_owner
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	w0, [sp, #20]
	mov	w0, #8                          ; =0x8
	bl	_la_tag
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]
	ldur	w8, [x29, #-16]
	str	w8, [sp, #32]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #32]
	ldr	w8, [sp, #20]
	str	w8, [sp, #28]
	ldr	x8, [sp, #24]
	str	x8, [sp, #40]
	ldr	w8, [sp, #32]
	str	w8, [sp, #48]
	ldr	x8, [sp, #40]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x8, [sp, #48]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB120_2
	b	LBB120_1
LBB120_1:
	bl	___stack_chk_fail
LBB120_2:
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_observed
_la_observed:                           ; @la_observed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	strh	w2, [sp, #12]
	strh	wzr, [sp, #10]
	b	LBB121_1
LBB121_1:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB121_7
	b	LBB121_2
LBB121_2:                               ;   in Loop: Header=BB121_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #8]
	subs	w8, w8, #2
	b.ne	LBB121_5
	b	LBB121_3
LBB121_3:                               ;   in Loop: Header=BB121_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	ldrh	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB121_5
	b	LBB121_4
LBB121_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB121_8
LBB121_5:                               ;   in Loop: Header=BB121_1 Depth=1
	b	LBB121_6
LBB121_6:                               ;   in Loop: Header=BB121_1 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB121_1
LBB121_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB121_8
LBB121_8:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function la_exact
_la_exact:                              ; @la_exact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]
	ldur	w8, [x29, #-16]
	str	w8, [sp, #32]
	strb	w2, [sp, #23]
	ldrb	w8, [sp, #32]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB122_3
	b	LBB122_1
LBB122_1:
	ldrb	w8, [sp, #33]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	w8, LBB122_3
	b	LBB122_2
LBB122_2:
	ldrh	w8, [sp, #24]
	ldrb	w10, [sp, #23]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	subs	w8, w8, w9, uxth
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB122_3
LBB122_3:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB122_5
	b	LBB122_4
LBB122_4:
	bl	___stack_chk_fail
LBB122_5:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an immutable module and output for private composition."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_mixed_samples.error
l___const.nvm_analyze_mixed_samples.error:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"I could not allocate private composition."

l_.str.2:                               ; @.str.2
	.asciz	"I require complete independent mixed structure."

l_.str.3:                               ; @.str.3
	.asciz	"I reached my composed worklist bound."

l_.str.4:                               ; @.str.4
	.asciz	"I could not copy composed transfer state."

l_.str.5:                               ; @.str.5
	.asciz	"I require checked state for every declared mixed instruction."

l_.str.6:                               ; @.str.6
	.asciz	"I checked private mixed composition; runtime obligations and admission remain separate."

l_.str.7:                               ; @.str.7
	.asciz	"I require a complete immutable module and private output."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_owned_array_lifetimes.invalid
l___const.nvm_analyze_owned_array_lifetimes.invalid:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.7

	.section	__TEXT,__cstring,cstring_literals
l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate independent owner analysis."

l_.str.9:                               ; @.str.9
	.asciz	"I reached my independent transfer visit budget."

l_.str.10:                              ; @.str.10
	.asciz	"I could not copy independent transfer state."

l_.str.11:                              ; @.str.11
	.asciz	"I require independent state for every declared instruction."

l_.str.12:                              ; @.str.12
	.asciz	"I require independently matching per-operand obligations."

l_.str.13:                              ; @.str.13
	.asciz	"I checked origin, lifetime and scalar transfers; common structure and runtime admission remain separate."

l_.str.14:                              ; @.str.14
	.asciz	"I require distinct composed function ranges."

l_.str.15:                              ; @.str.15
	.asciz	"I reached my composed instruction bound."

l_.str.16:                              ; @.str.16
	.asciz	"I require a complete composed instruction."

l_.str.17:                              ; @.str.17
	.asciz	"I require an explicit independent composed transfer."

l_.str.18:                              ; @.str.18
	.asciz	"I require a Boolean literal."

l_.str.19:                              ; @.str.19
	.asciz	"I require an existing composed local."

l_.str.20:                              ; @.str.20
	.asciz	"I require an existing nonentry callee."

l_.str.21:                              ; @.str.21
	.asciz	"I refuse ordinary or unavailable owner construction."

l_.str.22:                              ; @.str.22
	.asciz	"I require this exact closed allocation origin."

l_.str.23:                              ; @.str.23
	.asciz	"I preserve constructor source and global identities."

l_.str.24:                              ; @.str.24
	.asciz	"I require packed FLOAT array origins."

l_.str.25:                              ; @.str.25
	.asciz	"I require an explicit instruction-boundary branch."

l_.str.26:                              ; @.str.26
	.asciz	"I require explicit composed termination."

l_.str.27:                              ; @.str.27
	.asciz	"I could not materialize checked mixed facts."

l_.str.28:                              ; @.str.28
	.asciz	"I require exact mixed value signatures."

l_.str.29:                              ; @.str.29
	.asciz	"I keep unavailable mixed local categories explicit."

l_.str.30:                              ; @.str.30
	.asciz	"I require acyclic composed calls."

l_.str.31:                              ; @.str.31
	.asciz	"I reached my composed state budget."

l_.str.32:                              ; @.str.32
	.asciz	"I could not allocate a composed edge."

l_.str.33:                              ; @.str.33
	.asciz	"I require equal composed stack heights."

l_.str.34:                              ; @.str.34
	.asciz	"I require exact owner stack and observation joins."

l_.str.35:                              ; @.str.35
	.asciz	"I require exact owner state at composed joins."

l_.str.36:                              ; @.str.36
	.asciz	"I require RESOURCE authority before owner field transfer."

l_.str.37:                              ; @.str.37
	.asciz	"I require an exact return and complete independent owner consumption."

l_.str.38:                              ; @.str.38
	.asciz	"I require a complete independent operand stack."

l_.str.39:                              ; @.str.39
	.asciz	"I reached my independent operand stack budget."

l_.str.40:                              ; @.str.40
	.asciz	"I refuse heap or owner scalar operands."

l_.str.41:                              ; @.str.41
	.asciz	"I require exact scalar inputs or an explicit FLOAT-or-VOID check."

l_.str.42:                              ; @.str.42
	.asciz	"I require supported scalar value comparisons, never owner or ordinary heap equality."

l_.str.43:                              ; @.str.43
	.asciz	"I keep VOID ordering outside my first composition."

l_.str.44:                              ; @.str.44
	.asciz	"I cannot duplicate an owner or observation."

l_.str.45:                              ; @.str.45
	.asciz	"I require explicit owner consumption rather than POP."

l_.str.46:                              ; @.str.46
	.asciz	"I require a live exact owner observation."

l_.str.47:                              ; @.str.47
	.asciz	"I require initialized exact ordinary local alternatives."

l_.str.48:                              ; @.str.48
	.asciz	"I refuse owner or mismatched ordinary local stores."

l_.str.49:                              ; @.str.49
	.asciz	"I require a checked scalar destination."

l_.str.50:                              ; @.str.50
	.asciz	"I require a live unobserved RESOURCE for move or unpack."

l_.str.51:                              ; @.str.51
	.asciz	"I require an available exact RESOURCE destination."

l_.str.52:                              ; @.str.52
	.asciz	"I require exact scalar fields before producing an owner token."

l_.str.53:                              ; @.str.53
	.asciz	"I never construct an owner through ordinary packing."

l_.str.54:                              ; @.str.54
	.asciz	"I require every independent ordinary field alternative in the closed proof."

l_.str.55:                              ; @.str.55
	.asciz	"I require an intact independent owner observation."

l_.str.56:                              ; @.str.56
	.asciz	"I require exact ordinary receiver alternatives."

l_.str.57:                              ; @.str.57
	.asciz	"I require a proved field on every ordinary receiver."

l_.str.58:                              ; @.str.58
	.asciz	"I require exact FLOAT elements for array construction."

l_.str.59:                              ; @.str.59
	.asciz	"I require closed FLOAT-array receiver alternatives."

l_.str.60:                              ; @.str.60
	.asciz	"I require exact integer array indices."

l_.str.61:                              ; @.str.61
	.asciz	"I require exact FLOAT alias writes."

l_.str.62:                              ; @.str.62
	.asciz	"I require exact positional call values before owner transfer."

l_.str.63:                              ; @.str.63
	.asciz	"I require an exact Boolean control operand."

l_.str.64:                              ; @.str.64
	.asciz	"I require an independent transfer for every mixed instruction."

l_.str.65:                              ; @.str.65
	.asciz	"I reached my scalar obligation budget."

l_.str.66:                              ; @.str.66
	.asciz	"I reached my independent instruction budget."

l_.str.67:                              ; @.str.67
	.asciz	"I require an explicit independent instruction transfer."

l_.str.68:                              ; @.str.68
	.asciz	"I require identical independent and origin instruction locations."

l_.str.69:                              ; @.str.69
	.asciz	"I require complete independent instruction coverage."

l_.str.70:                              ; @.str.70
	.asciz	"I require exact independent branch destinations."

l_.str.71:                              ; @.str.71
	.asciz	"I could not materialize checked owner Facts."

l_.str.72:                              ; @.str.72
	.asciz	"I retain exact existing owner value signatures."

l_.str.73:                              ; @.str.73
	.asciz	"I require the exact independently retained layout row."

l_.str.74:                              ; @.str.74
	.asciz	"I reached my owner depth or direct-field limit."

l_.str.75:                              ; @.str.75
	.asciz	"I require prior exact nested owners."

l_.str.76:                              ; @.str.76
	.asciz	"I keep unsupported owner fields outside authority."

l_.str.77:                              ; @.str.77
	.asciz	"I require modeled exact local declarations."

l_.str.78:                              ; @.str.78
	.asciz	"I require an existing independent state destination."

l_.str.79:                              ; @.str.79
	.asciz	"I reached my independent state-cell budget."

l_.str.80:                              ; @.str.80
	.asciz	"I could not allocate an independent join frame."

l_.str.81:                              ; @.str.81
	.asciz	"I require equal independent join heights."

l_.str.82:                              ; @.str.82
	.asciz	"I require compatible unique stack owners and observations."

l_.str.83:                              ; @.str.83
	.asciz	"I require compatible independent owner lifetimes at joins."

l_.str.84:                              ; @.str.84
	.asciz	"I reached my independent owner work budget."

l_.str.85:                              ; @.str.85
	.asciz	"I require complete instruction metadata."

l_.str.86:                              ; @.str.86
	.asciz	"I require exact owner authority before field transfer."

l_.str.87:                              ; @.str.87
	.asciz	"I require the exact return and complete independent owner consumption."

l_.str.88:                              ; @.str.88
	.asciz	"I require complete independent operand stacks."

l_.str.89:                              ; @.str.89
	.asciz	"I reached my independent stack budget."

l_.str.90:                              ; @.str.90
	.asciz	"I require bounded independent scalar operand rows."

l_.str.91:                              ; @.str.91
	.asciz	"I require independently modeled scalar operands."

l_.str.92:                              ; @.str.92
	.asciz	"I require independently exact operands or a checked optional FLOAT comparison."

l_.str.93:                              ; @.str.93
	.asciz	"I cannot copy a unique owner or observation."

l_.str.94:                              ; @.str.94
	.asciz	"I cannot discard an unconsumed owner or observation."

l_.str.95:                              ; @.str.95
	.asciz	"I require a live owner before observation."

l_.str.96:                              ; @.str.96
	.asciz	"I require independently initialized ordinary locals."

l_.str.97:                              ; @.str.97
	.asciz	"I cannot overwrite owner authority through an ordinary store."

l_.str.98:                              ; @.str.98
	.asciz	"I require a checked scalar initialization."

l_.str.99:                              ; @.str.99
	.asciz	"I require a checked STRING initialization."

l_.str.100:                             ; @.str.100
	.asciz	"I require a live unobserved owner before consuming it."

l_.str.101:                             ; @.str.101
	.asciz	"I require an empty exact owner destination."

l_.str.102:                             ; @.str.102
	.asciz	"I require exact transferred owner constructor fields."

l_.str.103:                             ; @.str.103
	.asciz	"I require an exact live owner observation path."

l_.str.104:                             ; @.str.104
	.asciz	"I require declared FLOAT array construction."

l_.str.105:                             ; @.str.105
	.asciz	"I require exact FLOAT initializer values."

l_.str.106:                             ; @.str.106
	.asciz	"I require an independently initialized ARRAY receiver."

l_.str.107:                             ; @.str.107
	.asciz	"I require exact INT indices."

l_.str.108:                             ; @.str.108
	.asciz	"I require exact FLOAT writes through aliases."

l_.str.109:                             ; @.str.109
	.asciz	"I require exact independently transferred call arguments."

l_.str.110:                             ; @.str.110
	.asciz	"I require independently exact INT output operands."

l_.str.111:                             ; @.str.111
	.asciz	"I require exact BOOL control operands."

l_.str.112:                             ; @.str.112
	.asciz	"I require an explicit independent lifetime transfer."

.subsections_via_symbols
