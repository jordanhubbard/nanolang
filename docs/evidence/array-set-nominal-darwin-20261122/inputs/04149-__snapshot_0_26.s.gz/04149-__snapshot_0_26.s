	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_layouts_decode          ; -- Begin function nvm_v2_layouts_decode
	.p2align	2
_nvm_v2_layouts_decode:                 ; @nvm_v2_layouts_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	and	w4, w8, #0x1
	and	w5, w8, #0x1
	mov	x6, #0                          ; =0x0
	bl	_layouts_decode_profile
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_decode_profile
_layouts_decode_profile:                ; @layouts_decode_profile
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	sturb	w4, [x29, #-34]
	sturb	w5, [x29, #-35]
	stur	x6, [x29, #-48]
	ldur	x8, [x29, #-32]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #8]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-24]
	add	x0, sp, #72
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	x1, sp, #68
	bl	_nvm_v2_u32
	str	w0, [sp, #64]
	ldr	w8, [sp, #64]
	cbz	w8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	w8, [sp, #64]
	stur	w8, [x29, #-4]
	b	LBB1_68
LBB1_2:
	ldr	w8, [sp, #68]
	cbnz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	stur	wzr, [x29, #-4]
	b	LBB1_68
LBB1_4:
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #88]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_6
	b	LBB1_5
LBB1_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_68
LBB1_6:
	ldr	w8, [sp, #68]
	mov	x0, x8
	mov	x1, #16                         ; =0x10
	bl	_calloc
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbnz	x8, LBB1_10
	b	LBB1_7
LBB1_7:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB1_9
	b	LBB1_8
LBB1_8:
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB1_9
LBB1_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB1_68
LBB1_10:
	str	wzr, [sp, #52]
	strb	wzr, [sp, #51]
	str	wzr, [sp, #44]
	b	LBB1_11
LBB1_11:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_33 Depth 2
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB1_63
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_11 Depth=1
	add	x0, sp, #72
	add	x1, sp, #43
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_14
	b	LBB1_13
LBB1_13:
	b	LBB1_67
LBB1_14:                                ;   in Loop: Header=BB1_11 Depth=1
	add	x0, sp, #72
	add	x1, sp, #42
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_16
	b	LBB1_15
LBB1_15:
	b	LBB1_67
LBB1_16:                                ;   in Loop: Header=BB1_11 Depth=1
	ldrb	w8, [sp, #42]
	cbz	w8, LBB1_18
	b	LBB1_17
LBB1_17:
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_18:                                ;   in Loop: Header=BB1_11 Depth=1
	ldrb	w8, [sp, #43]
	subs	w8, w8, #3
	b.le	LBB1_20
	b	LBB1_19
LBB1_19:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_20:                                ;   in Loop: Header=BB1_11 Depth=1
	add	x0, sp, #72
	add	x1, sp, #40
	bl	_nvm_v2_u16
	str	w0, [sp, #64]
	cbz	w0, LBB1_22
	b	LBB1_21
LBB1_21:
	b	LBB1_67
LBB1_22:                                ;   in Loop: Header=BB1_11 Depth=1
	add	x0, sp, #72
	add	x1, sp, #36
	bl	_nvm_v2_u32
	str	w0, [sp, #64]
	cbz	w0, LBB1_24
	b	LBB1_23
LBB1_23:
	b	LBB1_67
LBB1_24:                                ;   in Loop: Header=BB1_11 Depth=1
	ldrb	w8, [sp, #43]
	ldr	x9, [sp, #56]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	strb	w8, [x9]
	ldrh	w8, [sp, #40]
	ldr	x9, [sp, #56]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	strh	w8, [x9, #2]
	ldr	w8, [sp, #36]
	ldr	x9, [sp, #56]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	w8, [x9, #4]
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #8]
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #52]
	ldrh	w8, [sp, #40]
	cbnz	w8, LBB1_26
	b	LBB1_25
LBB1_25:                                ;   in Loop: Header=BB1_11 Depth=1
	b	LBB1_62
LBB1_26:                                ;   in Loop: Header=BB1_11 Depth=1
	ldrh	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #88]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_28
	b	LBB1_27
LBB1_27:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_28:                                ;   in Loop: Header=BB1_11 Depth=1
	ldrh	w8, [sp, #40]
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	bl	_calloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB1_32
	b	LBB1_29
LBB1_29:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB1_31
	b	LBB1_30
LBB1_30:
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB1_31
LBB1_31:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_32:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #56]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x8, [x9, #8]
	strh	wzr, [sp, #22]
	b	LBB1_33
LBB1_33:                                ;   Parent Loop BB1_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #40]
	subs	w8, w8, w9
	b.ge	LBB1_61
	b	LBB1_34
LBB1_34:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #21
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_36
	b	LBB1_35
LBB1_35:
	b	LBB1_67
LBB1_36:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #20
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_38
	b	LBB1_37
LBB1_37:
	b	LBB1_67
LBB1_38:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #19
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_40
	b	LBB1_39
LBB1_39:
	b	LBB1_67
LBB1_40:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #18
	bl	_nvm_v2_u8
	str	w0, [sp, #64]
	cbz	w0, LBB1_42
	b	LBB1_41
LBB1_41:
	b	LBB1_67
LBB1_42:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrb	w8, [sp, #20]
	cbnz	w8, LBB1_45
	b	LBB1_43
LBB1_43:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrb	w8, [sp, #19]
	cbnz	w8, LBB1_45
	b	LBB1_44
LBB1_44:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrb	w8, [sp, #18]
	cbz	w8, LBB1_46
	b	LBB1_45
LBB1_45:
	mov	w8, #7                          ; =0x7
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_46:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrb	w8, [sp, #21]
	subs	w8, w8, #16
	b.lt	LBB1_48
	b	LBB1_47
LBB1_47:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_48:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #12
	bl	_nvm_v2_u32
	str	w0, [sp, #64]
	cbz	w0, LBB1_50
	b	LBB1_49
LBB1_49:
	b	LBB1_67
LBB1_50:                                ;   in Loop: Header=BB1_33 Depth=2
	add	x0, sp, #72
	add	x1, sp, #8
	bl	_nvm_v2_u32
	str	w0, [sp, #64]
	cbz	w0, LBB1_52
	b	LBB1_51
LBB1_51:
	b	LBB1_67
LBB1_52:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	w8, [sp, #12]
	adds	w8, w8, #1
	b.eq	LBB1_59
	b	LBB1_53
LBB1_53:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB1_55
	b	LBB1_54
LBB1_54:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.ne	LBB1_56
	b	LBB1_55
LBB1_55:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #64]
	b	LBB1_67
LBB1_56:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.ls	LBB1_58
	b	LBB1_57
LBB1_57:                                ;   in Loop: Header=BB1_33 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #51]
	b	LBB1_58
LBB1_58:                                ;   in Loop: Header=BB1_33 Depth=2
	b	LBB1_59
LBB1_59:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrb	w8, [sp, #21]
	ldr	x12, [sp, #24]
	ldrh	w9, [sp, #22]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	strb	w8, [x9]
	ldr	w8, [sp, #12]
	ldr	x12, [sp, #24]
	ldrh	w9, [sp, #22]
                                        ; kill: def $x9 killed $w9
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	str	w8, [x9, #4]
	ldr	w8, [sp, #8]
	ldr	x11, [sp, #24]
	ldrh	w9, [sp, #22]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #8]
	b	LBB1_60
LBB1_60:                                ;   in Loop: Header=BB1_33 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB1_33
LBB1_61:                                ;   in Loop: Header=BB1_11 Depth=1
	b	LBB1_62
LBB1_62:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB1_11
LBB1_63:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB1_66
	b	LBB1_64
LBB1_64:
	ldr	x0, [sp, #56]
	ldr	w1, [sp, #68]
	ldurb	w10, [x29, #-33]
	ldurb	w9, [x29, #-34]
	ldurb	w8, [x29, #-35]
	ldur	x5, [x29, #-48]
	and	w2, w10, #0x1
	and	w3, w9, #0x1
	and	w4, w8, #0x1
	bl	_forward_record_graph
	str	w0, [sp, #64]
	cbz	w0, LBB1_66
	b	LBB1_65
LBB1_65:
	b	LBB1_67
LBB1_66:
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldr	w8, [sp, #68]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #8]
	stur	wzr, [x29, #-4]
	b	LBB1_68
LBB1_67:
	ldr	x0, [sp, #56]
	ldr	w1, [sp, #52]
	bl	_free_fields
	ldr	x0, [sp, #56]
	bl	_free
	ldr	w8, [sp, #64]
	stur	w8, [x29, #-4]
	b	LBB1_68
LBB1_68:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_layouts_private_decode ; -- Begin function nvm_ownership_layouts_private_decode
	.p2align	2
_nvm_ownership_layouts_private_decode:  ; @nvm_ownership_layouts_private_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	and	w4, w8, #0x1
	mov	x5, #0                          ; =0x0
	bl	_ownership_layouts_private_decode
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_layouts_private_decode
_ownership_layouts_private_decode:      ; @ownership_layouts_private_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	sturb	w4, [x29, #-34]
	stur	x5, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-48]
	strb	wzr, [x8]
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_5
	b	LBB3_3
LBB3_3:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB3_5
	b	LBB3_4
LBB3_4:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB3_6
	b	LBB3_5
LBB3_5:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_6:
	ldur	x8, [x29, #-24]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB3_8
	b	LBB3_7
LBB3_7:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_8:
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-24]
	add	x0, sp, #72
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	wzr, [sp, #64]
	add	x1, sp, #68
	bl	_nvm_v2_u32
	str	w0, [sp, #60]
	ldr	w8, [sp, #60]
	cbz	w8, LBB3_10
	b	LBB3_9
LBB3_9:
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_10:
	ldr	w8, [sp, #68]
	subs	w8, w8, #256
	b.ls	LBB3_12
	b	LBB3_11
LBB3_11:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_12:
	str	wzr, [sp, #56]
	b	LBB3_13
LBB3_13:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB3_22
	b	LBB3_14
LBB3_14:                                ;   in Loop: Header=BB3_13 Depth=1
	add	x0, sp, #72
	mov	x1, #8                          ; =0x8
	add	x2, sp, #48
	bl	_nvm_v2_take
	str	w0, [sp, #60]
	cbz	w0, LBB3_16
	b	LBB3_15
LBB3_15:
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_16:                                ;   in Loop: Header=BB3_13 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #2]
	ldr	x9, [sp, #48]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #8
	strh	w8, [sp, #38]
	ldrh	w8, [sp, #38]
	ldr	w10, [sp, #64]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB3_18
	b	LBB3_17
LBB3_17:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_18:                                ;   in Loop: Header=BB3_13 Depth=1
	ldrh	w9, [sp, #38]
	ldr	w8, [sp, #64]
	add	w8, w8, w9
	str	w8, [sp, #64]
	ldrh	w8, [sp, #38]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	add	x0, sp, #72
	add	x2, sp, #40
	bl	_nvm_v2_take
	str	w0, [sp, #60]
	cbz	w0, LBB3_20
	b	LBB3_19
LBB3_19:
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_20:                                ;   in Loop: Header=BB3_13 Depth=1
	b	LBB3_21
LBB3_21:                                ;   in Loop: Header=BB3_13 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB3_13
LBB3_22:
	ldr	x8, [sp, #88]
	ldr	x9, [sp, #80]
	subs	x8, x8, x9
	b.eq	LBB3_24
	b	LBB3_23
LBB3_23:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_24:
	add	x2, sp, #16
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldurb	w9, [x29, #-33]
	ldurb	w8, [x29, #-34]
	ldur	x6, [x29, #-48]
	mov	w10, #1                         ; =0x1
	and	w3, w10, #0x1
	and	w4, w9, #0x1
	and	w5, w8, #0x1
	bl	_layouts_decode_profile
	str	w0, [sp, #60]
	ldr	w8, [sp, #60]
	cbz	w8, LBB3_26
	b	LBB3_25
LBB3_25:
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB3_27
LBB3_26:
	ldur	x8, [x29, #-32]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	stur	wzr, [x29, #-4]
	b	LBB3_27
LBB3_27:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_mixed_layouts_private_decode ; -- Begin function nvm_ownership_mixed_layouts_private_decode
	.p2align	2
_nvm_ownership_mixed_layouts_private_decode: ; @nvm_ownership_mixed_layouts_private_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	mov	x5, #0                          ; =0x0
	bl	_ownership_layouts_private_decode
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_mixed_layouts_private_decode_detailed ; -- Begin function nvm_ownership_mixed_layouts_private_decode_detailed
	.p2align	2
_nvm_ownership_mixed_layouts_private_decode_detailed: ; @nvm_ownership_mixed_layouts_private_decode_detailed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	ldr	x5, [sp]
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_ownership_layouts_private_decode
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_map_layouts_private_decode_detailed ; -- Begin function nvm_ownership_map_layouts_private_decode_detailed
	.p2align	2
_nvm_ownership_map_layouts_private_decode_detailed: ; @nvm_ownership_map_layouts_private_decode_detailed
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	ldr	x5, [sp]
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	and	w4, w8, #0x1
	bl	_ownership_layouts_private_decode
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_layouts_free            ; -- Begin function nvm_v2_layouts_free
	.p2align	2
_nvm_v2_layouts_free:                   ; @nvm_v2_layouts_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB7_5
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_4
	b	LBB7_3
LBB7_3:
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #8]
	b	LBB7_4
LBB7_4:
	b	LBB7_6
LBB7_5:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	ldr	x8, [sp, #8]
	ldr	w1, [x8, #8]
	bl	_free_fields
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #8]
	b	LBB7_6
LBB7_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function free_fields
_free_fields:                           ; @free_fields
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	str	wzr, [sp]
	b	LBB8_1
LBB8_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	w9, [sp, #4]
	subs	w8, w8, w9
	b.hs	LBB8_4
	b	LBB8_2
LBB8_2:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	x8, [sp, #8]
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	bl	_free
	b	LBB8_3
LBB8_3:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB8_1
LBB8_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_layouts_encoded_size    ; -- Begin function nvm_v2_layouts_encoded_size
	.p2align	2
_nvm_v2_layouts_encoded_size:           ; @nvm_v2_layouts_encoded_size
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	mov	x8, #4                          ; =0x4
	str	x8, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB9_1
LBB9_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB9_4
	b	LBB9_2
LBB9_2:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	add	x9, x8, #8
	ldr	x8, [sp, #16]
	add	x8, x8, x9
	str	x8, [sp, #16]
	b	LBB9_3
LBB9_3:                                 ;   in Loop: Header=BB9_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB9_1
LBB9_4:
	ldr	x0, [sp, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_layouts_encode          ; -- Begin function nvm_v2_layouts_encode
	.p2align	2
_nvm_v2_layouts_encode:                 ; @nvm_v2_layouts_encode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_layouts_encoded_size
	str	x0, [sp, #40]
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.hs	LBB10_2
	b	LBB10_1
LBB10_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB10_11
LBB10_2:
	ldur	x0, [x29, #-24]
	ldr	x2, [sp, #40]
	mov	w1, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	str	xzr, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #32]
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	w1, [x8, #8]
	bl	_wr32
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	str	x8, [sp, #32]
	str	wzr, [sp, #28]
	b	LBB10_3
LBB10_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_5 Depth 2
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB10_10
	b	LBB10_4
LBB10_4:                                ;   in Loop: Header=BB10_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #32]
	add	x9, x9, x10
	strb	w8, [x9]
	ldr	x8, [sp, #32]
	add	x8, x8, #2
	str	x8, [sp, #32]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #32]
	add	x11, x10, #1
	str	x11, [sp, #32]
	add	x9, x9, x10
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	asr	w8, w8, #8
	ldur	x9, [x29, #-24]
	ldr	x10, [sp, #32]
	add	x11, x10, #1
	str	x11, [sp, #32]
	strb	w8, [x9, x10]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #32]
	add	x0, x8, x9
	ldr	x8, [sp, #16]
	ldr	w1, [x8, #4]
	bl	_wr32
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	str	x8, [sp, #32]
	strh	wzr, [sp, #14]
	b	LBB10_5
LBB10_5:                                ;   Parent Loop BB10_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB10_8
	b	LBB10_6
LBB10_6:                                ;   in Loop: Header=BB10_5 Depth=2
	ldr	x8, [sp, #16]
	ldr	x11, [x8, #8]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrb	w8, [x8]
	ldur	x10, [x29, #-24]
	ldr	x11, [sp, #32]
	add	x10, x10, x11
	strb	w8, [x10]
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x10, [sp, #32]
	add	x0, x8, x10
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w1, [x8, #4]
	bl	_wr32
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x10, [sp, #32]
	add	x0, x8, x10
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w1, [x8, #8]
	bl	_wr32
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	str	x8, [sp, #32]
	b	LBB10_7
LBB10_7:                                ;   in Loop: Header=BB10_5 Depth=2
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB10_5
LBB10_8:                                ;   in Loop: Header=BB10_3 Depth=1
	b	LBB10_9
LBB10_9:                                ;   in Loop: Header=BB10_3 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB10_3
LBB10_10:
	stur	wzr, [x29, #-4]
	b	LBB10_11
LBB10_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wr32
_wr32:                                  ; @wr32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	strb	w8, [x9]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #8
	ldr	x9, [sp, #8]
	strb	w8, [x9, #1]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #16
	ldr	x9, [sp, #8]
	strb	w8, [x9, #2]
	ldr	w8, [sp, #4]
	lsr	w8, w8, #24
	ldr	x9, [sp, #8]
	strb	w8, [x9, #3]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function forward_record_graph
_forward_record_graph:                  ; @forward_record_graph
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturb	w2, [x29, #-21]
	sturb	w3, [x29, #-22]
	sturb	w4, [x29, #-23]
	stur	x5, [x29, #-32]
	stur	wzr, [x29, #-36]
	b	LBB12_1
LBB12_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_7 Depth 2
	ldur	w8, [x29, #-36]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB12_36
	b	LBB12_2
LBB12_2:                                ;   in Loop: Header=BB12_1 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	cbz	w8, LBB12_6
	b	LBB12_3
LBB12_3:                                ;   in Loop: Header=BB12_1 Depth=1
	ldurb	w8, [x29, #-22]
	tbz	w8, #0, LBB12_5
	b	LBB12_4
LBB12_4:                                ;   in Loop: Header=BB12_1 Depth=1
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB12_6
	b	LBB12_5
LBB12_5:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_6:                                ;   in Loop: Header=BB12_1 Depth=1
	sturh	wzr, [x29, #-50]
	b	LBB12_7
LBB12_7:                                ;   Parent Loop BB12_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-50]
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB12_34
	b	LBB12_8
LBB12_8:                                ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB12_15
	b	LBB12_9
LBB12_9:                                ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB12_13
	b	LBB12_10
LBB12_10:                               ;   in Loop: Header=BB12_7 Depth=2
	ldurb	w8, [x29, #-22]
	tbz	w8, #0, LBB12_14
	b	LBB12_11
LBB12_11:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	cbnz	w8, LBB12_13
	b	LBB12_12
LBB12_12:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbz	w8, LBB12_14
	b	LBB12_13
LBB12_13:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_14:                               ;   in Loop: Header=BB12_7 Depth=2
	b	LBB12_32
LBB12_15:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #1
	b.eq	LBB12_27
	b	LBB12_16
LBB12_16:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB12_27
	b	LBB12_17
LBB12_17:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #3
	b.eq	LBB12_27
	b	LBB12_18
LBB12_18:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	b.eq	LBB12_27
	b	LBB12_19
LBB12_19:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.eq	LBB12_27
	b	LBB12_20
LBB12_20:                               ;   in Loop: Header=BB12_7 Depth=2
	ldurb	w8, [x29, #-23]
	tbz	w8, #0, LBB12_23
	b	LBB12_21
LBB12_21:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #13
	b.ne	LBB12_23
	b	LBB12_22
LBB12_22:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	cbz	w8, LBB12_27
	b	LBB12_23
LBB12_23:                               ;   in Loop: Header=BB12_7 Depth=2
	ldurb	w8, [x29, #-21]
	tbz	w8, #0, LBB12_30
	b	LBB12_24
LBB12_24:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.ne	LBB12_30
	b	LBB12_25
LBB12_25:                               ;   in Loop: Header=BB12_7 Depth=2
	ldurb	w8, [x29, #-22]
	tbz	w8, #0, LBB12_27
	b	LBB12_26
LBB12_26:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	cbnz	w8, LBB12_30
	b	LBB12_27
LBB12_27:                               ;   in Loop: Header=BB12_7 Depth=2
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB12_29
	b	LBB12_28
LBB12_28:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_29:                               ;   in Loop: Header=BB12_7 Depth=2
	b	LBB12_31
LBB12_30:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_31:                               ;   in Loop: Header=BB12_7 Depth=2
	b	LBB12_32
LBB12_32:                               ;   in Loop: Header=BB12_7 Depth=2
	b	LBB12_33
LBB12_33:                               ;   in Loop: Header=BB12_7 Depth=2
	ldurh	w8, [x29, #-50]
	add	w8, w8, #1
	sturh	w8, [x29, #-50]
	b	LBB12_7
LBB12_34:                               ;   in Loop: Header=BB12_1 Depth=1
	b	LBB12_35
LBB12_35:                               ;   in Loop: Header=BB12_1 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB12_1
LBB12_36:
	ldur	w8, [x29, #-20]
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #72]
	ldur	w8, [x29, #-20]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	str	x0, [sp, #64]
	ldr	x8, [sp, #72]
	cbz	x8, LBB12_38
	b	LBB12_37
LBB12_37:
	ldr	x8, [sp, #64]
	cbnz	x8, LBB12_41
	b	LBB12_38
LBB12_38:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB12_40
	b	LBB12_39
LBB12_39:
	ldur	x9, [x29, #-32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB12_40
LBB12_40:
	ldr	x0, [sp, #72]
	bl	_free
	ldr	x0, [sp, #64]
	bl	_free
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_41:
	str	wzr, [sp, #60]
	str	wzr, [sp, #56]
	b	LBB12_42
LBB12_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_46 Depth 2
	ldr	w8, [sp, #56]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB12_57
	b	LBB12_43
LBB12_43:                               ;   in Loop: Header=BB12_42 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB12_45
	b	LBB12_44
LBB12_44:                               ;   in Loop: Header=BB12_42 Depth=1
	b	LBB12_56
LBB12_45:                               ;   in Loop: Header=BB12_42 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #52]
	ldr	x9, [sp, #64]
	ldr	w8, [sp, #56]
	str	w8, [sp, #44]
	str	wzr, [sp, #48]
	ldur	x8, [sp, #44]
	str	x8, [x9]
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB12_46
LBB12_46:                               ;   Parent Loop BB12_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #52]
	cbz	w8, LBB12_55
	b	LBB12_47
LBB12_47:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #64]
	ldr	w9, [sp, #52]
	subs	w9, w9, #1
	add	x8, x8, w9, uxtw #3
	str	x8, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB12_49
	b	LBB12_48
LBB12_48:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldr	w8, [sp, #52]
	subs	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB12_46
LBB12_49:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldr	x11, [sp, #32]
	ldr	w8, [x11, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	str	w9, [x11, #4]
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	str	w8, [sp, #20]
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.eq	LBB12_51
	b	LBB12_50
LBB12_50:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB12_52
	b	LBB12_51
LBB12_51:                               ;   in Loop: Header=BB12_46 Depth=2
	b	LBB12_46
LBB12_52:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB12_54
	b	LBB12_53
LBB12_53:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #60]
	b	LBB12_58
LBB12_54:                               ;   in Loop: Header=BB12_46 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	x9, [sp, #64]
	ldr	w8, [sp, #52]
	mov	x10, x8
	mov	x8, x10
	add	w8, w8, #1
	str	w8, [sp, #52]
	ldr	w8, [sp, #20]
	str	w8, [sp, #12]
	str	wzr, [sp, #16]
	ldur	x8, [sp, #12]
	str	x8, [x9, x10, lsl #3]
	b	LBB12_46
LBB12_55:                               ;   in Loop: Header=BB12_42 Depth=1
	b	LBB12_56
LBB12_56:                               ;   in Loop: Header=BB12_42 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB12_42
LBB12_57:
	b	LBB12_58
LBB12_58:
	ldr	x0, [sp, #72]
	bl	_free
	ldr	x0, [sp, #64]
	bl	_free
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB12_59
LBB12_59:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
