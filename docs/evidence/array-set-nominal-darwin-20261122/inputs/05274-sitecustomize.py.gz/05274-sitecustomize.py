from pathlib import Path
import os,sys,json,time,hashlib,tempfile,subprocess,unittest
if os.environ.get('NANO_MUTATION_OBSERVE')=='1' and 'unittest' in getattr(sys,'orig_argv',[]):
 os.environ.pop('NANO_MUTATION_OBSERVE');out=Path(os.environ['NANO_MUTATION_OBSERVER']);out.mkdir(parents=True,exist_ok=False)
 original_temp=tempfile.TemporaryDirectory;original_run=subprocess.run;original_tests=unittest.TextTestRunner.run;commands=[]
 def retained(*args,**kwargs):
  kwargs['delete']=False
  return original_temp(*args,**kwargs)
 def observed(*args,**kwargs):
  index=len(commands);item=dict(index=index,args=list(map(str,args[0])),timeout=kwargs.get('timeout'),inputs=[]);commands.append(item);started=time.monotonic()
  for value in args[0]:
   p=Path(value)
   if p.suffix in ('.nano','.nvm','.c') and p.is_file():
    raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();(out/'inputs').mkdir(exist_ok=True);artifact='inputs/'+digest+p.suffix;(out/artifact).write_bytes(raw);item['inputs'].append(dict(path=str(p),sha256=digest,artifact=artifact))
  try:
   result=original_run(*args,**kwargs);item['returncode']=result.returncode
   for stream in ('stdout','stderr'):
    raw=getattr(result,stream)
    if raw is not None:(out/(str(index)+'.'+stream)).write_bytes(raw.encode() if isinstance(raw,str) else raw)
   return result
  except BaseException as error:
   item['error']=repr(error)
   if isinstance(error,subprocess.TimeoutExpired):
    for stream in ('stdout','stderr'):
     raw=getattr(error,stream)
     if raw is not None:(out/(str(index)+'.partial.'+stream)).write_bytes(raw.encode() if isinstance(raw,str) else raw)
   raise
  finally:
   item['seconds']=time.monotonic()-started;(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 def tests(self,suite):
  count=suite.countTestCases();assert count==int(os.environ['NANO_MUTATION_EXPECTED']),count
  started=time.monotonic();result=original_tests(self,suite)
  record=dict(discovered=count,ran=result.testsRun,successful=result.wasSuccessful(),failures=result.failures,errors=result.errors,skipped=result.skipped,seconds=time.monotonic()-started)
  (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');assert result.testsRun==count and not result.skipped
  return result
 tempfile.TemporaryDirectory=retained;subprocess.run=observed;unittest.TextTestRunner.run=tests
