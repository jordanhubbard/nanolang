	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_mixed_float_proof_free ; -- Begin function nvm_mixed_float_proof_free
	.globl	_nvm_mixed_float_proof_free
	.p2align	2
_nvm_mixed_float_proof_free:            ; @nvm_mixed_float_proof_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_mixed_layout_view_free
	ldr	x0, [x19, #1568]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_analyze_mixed_float_origins
lCPI1_0:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI1_1:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI1_2:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_analyze_mixed_float_origins
	.globl	_nvm_analyze_mixed_float_origins
	.p2align	2
_nvm_analyze_mixed_float_origins:       ; @nvm_analyze_mixed_float_origins
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #12368                      ; =0x3050
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh2:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	cbz	x0, LBB1_19
; %bb.1:
	cbz	x1, LBB1_19
; %bb.2:
	ldr	x10, [x0, #256]
	cbz	x10, LBB1_19
; %bb.3:
	ldr	x9, [x0, #280]
	cbz	x9, LBB1_19
; %bb.4:
	ldr	w9, [x0, #272]
	cbz	w9, LBB1_19
; %bb.5:
	cmp	w9, #8
	b.hi	LBB1_11
; %bb.6:
	ldr	w11, [x0, #12]
	cbnz	w11, LBB1_11
; %bb.7:
	ldr	w11, [x0, #432]
	cbnz	w11, LBB1_11
; %bb.8:
	ldr	w11, [x0, #448]
	cbnz	w11, LBB1_11
; %bb.9:
	ldr	w11, [x0, #424]
	cbnz	w11, LBB1_11
; %bb.10:
	ldr	w11, [x0, #352]
	cbz	w11, LBB1_12
LBB1_11:
Lloh5:
	adrp	x9, lCPI1_2@PAGE
Lloh6:
	ldr	q0, [x9, lCPI1_2@PAGEOFF]
	str	q0, [x8]
Lloh7:
	adrp	x9, l_.str.1@PAGE
Lloh8:
	add	x9, x9, l_.str.1@PAGEOFF
	b	LBB1_20
LBB1_12:
	ldrh	w12, [x10, #16]
	cmp	w12, #256
	b.hi	LBB1_14
; %bb.13:
	ldrh	w11, [x10, #4]
	cmp	w11, #8
	b.ls	LBB1_16
LBB1_14:
	mov	w10, #0                         ; =0x0
LBB1_15:
	mov	w9, #3                          ; =0x3
	stp	w9, w10, [x8]
	str	xzr, [x8, #8]
Lloh9:
	adrp	x9, l_.str.2@PAGE
Lloh10:
	add	x9, x9, l_.str.2@PAGEOFF
	b	LBB1_20
LBB1_16:
	cmp	w11, w12
	b.hi	LBB1_19
; %bb.17:
	ldrb	w12, [x10, #21]
	cmp	w12, #1
	b.hi	LBB1_19
; %bb.18:
	ldrh	w12, [x10, #18]
	orr	w11, w12, w11
	cbz	w11, LBB1_23
LBB1_19:
Lloh11:
	adrp	x9, l___const.nvm_analyze_mixed_float_origins.invalid@PAGE
Lloh12:
	add	x9, x9, l___const.nvm_analyze_mixed_float_origins.invalid@PAGEOFF
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x9, [x9, #16]
LBB1_20:
	str	x9, [x8, #16]
LBB1_21:
	ldur	x8, [x29, #-96]
Lloh13:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh14:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh15:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_59
; %bb.22:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #80
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_23:
	mov	x19, x0
	mov	x23, x1
	mov	x21, x8
	cmp	w9, #1
	b.ne	LBB1_49
LBB1_24:
	str	xzr, [sp, #56]
	add	x8, sp, #32
	add	x1, sp, #56
	mov	x0, x19
	bl	_nvm_describe_mixed_layouts
	ldr	w8, [sp, #32]
	sub	w9, w8, #3
	cmp	w9, #2
	b.lo	LBB1_58
; %bb.25:
	cbnz	w8, LBB1_57
; %bb.26:
	ldr	x22, [sp, #56]
	ldr	w8, [x22, #5152]
	cbz	w8, LBB1_60
; %bb.27:
	mov	w0, #1                          ; =0x1
	mov	w1, #232                        ; =0xe8
	movk	w1, #7, lsl #16
	bl	_calloc
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #1576                       ; =0x628
	movk	w1, #1, lsl #16
	bl	_calloc
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	cbz	x20, LBB1_61
; %bb.28:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x8, LBB1_61
; %bb.29:
	add	x8, x20, #112, lsl #12          ; =458752
	add	x10, x8, #192
	add	x8, x20, #108, lsl #12          ; =442368
	add	x26, x8, #176
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	stp	x19, x9, [x20]
	str	x22, [x9]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
Lloh16:
	adrp	x8, l___const.nvm_analyze_mixed_float_origins.invalid@PAGE
Lloh17:
	add	x8, x8, l___const.nvm_analyze_mixed_float_origins.invalid@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x10, #16]
	ldr	x8, [x8, #16]
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
	str	x8, [x10, #32]
	mov	x0, x20
	bl	_mf_descriptors
	cbz	w0, LBB1_71
; %bb.30:
	mov	x0, x20
	bl	_mf_preflight
	cbz	w0, LBB1_71
; %bb.31:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w0, [x8, #12]
	str	w0, [x26, #4]
	cbz	w0, LBB1_33
; %bb.32:
	mov	w1, #16                         ; =0x10
	bl	_calloc
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x0, [x8, #1568]
	cbz	x0, LBB1_62
LBB1_33:
	ldr	w8, [x19, #272]
	cbz	w8, LBB1_45
; %bb.34:
	mov	x22, #0                         ; =0x0
	add	x9, x20, #16
	add	x28, sp, #64
	orr	x8, x28, #0x2
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
	add	x27, x20, #36
	mov	w24, #65536                     ; =0x10000
	mov	w25, #1                         ; =0x1
LBB1_35:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
	add	x0, sp, #64
	mov	w1, #12288                      ; =0x3000
	bl	_bzero
	ldr	x8, [x19, #256]
	mov	w9, #24                         ; =0x18
	madd	x8, x22, x9, x8
	ldrh	w9, [x8, #16]
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	cbz	x9, LBB1_37
LBB1_36:                                ;   Parent Loop BB1_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sturh	w25, [x10, #-2]
	stp	xzr, xzr, [x10]
	stur	xzr, [x10, #14]
	add	x10, x10, #24
	subs	x9, x9, #1
	b.ne	LBB1_36
LBB1_37:                                ;   in Loop: Header=BB1_35 Depth=1
	ldrh	w9, [x8, #4]
	cbz	x9, LBB1_43
; %bb.38:                               ;   in Loop: Header=BB1_35 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #3
	mov	x10, x27
	b	LBB1_41
LBB1_39:                                ;   in Loop: Header=BB1_41 Depth=2
	add	x12, x28, x8
	stur	xzr, [x12, #10]
	lsl	w11, w25, w11
	stur	xzr, [x12, #2]
	str	xzr, [x12, #16]
LBB1_40:                                ;   in Loop: Header=BB1_41 Depth=2
	strh	w11, [x28, x8]
	add	x10, x10, #8
	add	x8, x8, #24
	cmp	x9, x8
	b.eq	LBB1_43
LBB1_41:                                ;   Parent Loop BB1_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w11, [x10, #-4]
	cmp	w11, #8
	b.ne	LBB1_39
; %bb.42:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	w11, [x10]
	add	x12, x28, x8
	stur	xzr, [x12, #2]
	str	xzr, [x12, #8]
	stp	w11, w24, [x12, #16]
	mov	w11, #256                       ; =0x100
	b	LBB1_40
LBB1_43:                                ;   in Loop: Header=BB1_35 Depth=1
	mov	w8, #2068                       ; =0x814
	mul	x8, x22, x8
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [x9, x8]
	add	x2, sp, #64
	mov	x0, x20
	mov	w3, #0                          ; =0x0
	bl	_mf_join
	tbz	w0, #0, LBB1_71
; %bb.44:                               ;   in Loop: Header=BB1_35 Depth=1
	add	x22, x22, #1
	ldr	w8, [x19, #272]
	add	x27, x27, #2068
	cmp	x22, x8
	b.lo	LBB1_35
LBB1_45:
	mov	w8, #16624                      ; =0x40f0
	add	x22, x20, x8
	add	x8, x20, #108, lsl #12          ; =442368
	add	x19, x8, #192
	mov	w8, #16656                      ; =0x4110
	add	x24, x20, x8
	mov	w25, #104                       ; =0x68
LBB1_46:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	cbz	w8, LBB1_63
; %bb.47:                               ;   in Loop: Header=BB1_46 Depth=1
	ldr	w9, [x26, #8]
	add	w10, w9, #1
	str	w10, [x26, #8]
	cmp	w9, #64, lsl #12                ; =262144
	b.eq	LBB1_69
; %bb.48:                               ;   in Loop: Header=BB1_46 Depth=1
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	w9, [x10]
	ldr	w1, [x19, x9, lsl #2]
	add	w9, w9, #1
	and	w9, w9, #0xfff
	str	w9, [x10]
	sub	w8, w8, #1
	str	w8, [x10, #8]
	umull	x8, w1, w25
	strb	wzr, [x24, x8]
	mov	x0, x20
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_mf_step
	tbnz	w0, #0, LBB1_46
	b	LBB1_71
LBB1_49:
	add	x11, x10, #45
	mov	w10, #1                         ; =0x1
LBB1_50:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x11, #-5]
	cmp	w8, #256
	b.hi	LBB1_56
; %bb.51:                               ;   in Loop: Header=BB1_50 Depth=1
	ldurh	w12, [x11, #-17]
	cmp	w12, #9
	b.hs	LBB1_56
; %bb.52:                               ;   in Loop: Header=BB1_50 Depth=1
	cmp	w12, w8
	mov	x8, x21
	b.hi	LBB1_19
; %bb.53:                               ;   in Loop: Header=BB1_50 Depth=1
	ldrb	w12, [x11]
	cmp	w12, #1
	b.hi	LBB1_19
; %bb.54:                               ;   in Loop: Header=BB1_50 Depth=1
	ldurh	w12, [x11, #-3]
	cbnz	w12, LBB1_19
; %bb.55:                               ;   in Loop: Header=BB1_50 Depth=1
	add	w10, w10, #1
	add	x11, x11, #24
	cmp	w9, w10
	b.ne	LBB1_50
	b	LBB1_24
LBB1_56:
	mov	x8, x21
	b	LBB1_15
LBB1_57:
	cmp	w8, #2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
LBB1_58:
	stp	w8, wzr, [x21]
	ldr	x8, [sp, #48]
	stp	xzr, x8, [x21, #8]
	b	LBB1_21
LBB1_59:
	bl	___stack_chk_fail
LBB1_60:
	mov	x0, x22
	bl	_nvm_mixed_layout_view_free
Lloh18:
	adrp	x8, lCPI1_2@PAGE
Lloh19:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [x21]
Lloh20:
	adrp	x8, l_.str.3@PAGE
Lloh21:
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [x21, #16]
	b	LBB1_21
LBB1_61:
	mov	x0, x20
	bl	_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_free
	mov	x0, x22
	bl	_nvm_mixed_layout_view_free
Lloh22:
	adrp	x8, lCPI1_0@PAGE
Lloh23:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [x21]
Lloh24:
	adrp	x8, l_.str.4@PAGE
Lloh25:
	add	x8, x8, l_.str.4@PAGEOFF
	str	x8, [x21, #16]
	b	LBB1_21
LBB1_62:
Lloh26:
	adrp	x8, lCPI1_0@PAGE
Lloh27:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	q0, [x9, #16]
Lloh28:
	adrp	x8, l_.str.5@PAGE
Lloh29:
	add	x8, x8, l_.str.5@PAGEOFF
	b	LBB1_70
LBB1_63:
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, #12]
	ldr	w8, [x26]
	cbz	w8, LBB1_68
; %bb.64:
	mov	x19, #0                         ; =0x0
LBB1_65:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22, #24]
	cbz	x8, LBB1_77
; %bb.66:                               ;   in Loop: Header=BB1_65 Depth=1
	mov	x0, x20
	mov	x1, x19
	bl	_mf_step
	tbz	w0, #0, LBB1_71
; %bb.67:                               ;   in Loop: Header=BB1_65 Depth=1
	add	x19, x19, #1
	ldr	w8, [x26]
	add	x22, x22, #104
	cmp	x19, x8
	b.lo	LBB1_65
LBB1_68:
	ldp	x9, x10, [sp, #16]              ; 16-byte Folded Reload
	str	w8, [x10, #16]
	stp	xzr, xzr, [x9, #16]
Lloh30:
	adrp	x8, l_.str.8@PAGE
Lloh31:
	add	x8, x8, l_.str.8@PAGEOFF
	b	LBB1_70
LBB1_69:
Lloh32:
	adrp	x8, lCPI1_1@PAGE
Lloh33:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	q0, [x9, #16]
Lloh34:
	adrp	x8, l_.str.6@PAGE
Lloh35:
	add	x8, x8, l_.str.6@PAGEOFF
LBB1_70:
	str	x8, [x9, #32]
LBB1_71:
	ldr	w8, [x26]
	cbz	w8, LBB1_74
LBB1_72:
	mov	x19, #0                         ; =0x0
	mov	w8, #16648                      ; =0x4108
	add	x22, x20, x8
LBB1_73:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x22], #104
	bl	_free
	add	x19, x19, #1
	ldr	w8, [x26]
	cmp	x19, x8
	b.lo	LBB1_73
LBB1_74:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	q0, [x8, #16]
	str	q0, [x21]
	ldur	x8, [x8, #32]
	str	x8, [x21, #16]
	mov	x0, x20
	bl	_free
	ldr	w8, [x21]
	cbz	w8, LBB1_76
; %bb.75:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_nvm_mixed_float_proof_free
	b	LBB1_21
LBB1_76:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [x23]
	b	LBB1_21
LBB1_77:
	ldr	w8, [x22, #12]
	ldr	w9, [x22]
	mov	w10, #1                         ; =0x1
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	stp	w10, w8, [x11, #16]
	stp	w9, wzr, [x11, #24]
Lloh36:
	adrp	x8, l_.str.7@PAGE
Lloh37:
	add	x8, x8, l_.str.7@PAGEOFF
	str	x8, [x11, #32]
	ldr	w8, [x26]
	cbnz	w8, LBB1_72
	b	LBB1_74
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpAdd	Lloh7, Lloh8
	.loh AdrpAdrp	Lloh5, Lloh7
	.loh AdrpLdr	Lloh5, Lloh6
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpAdd	Lloh11, Lloh12
	.loh AdrpLdrGotLdr	Lloh13, Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_descriptors
_mf_descriptors:                        ; @mf_descriptors
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	ldr	x1, [x8, #5144]
	ldr	w2, [x8, #5152]
	add	x0, sp, #56
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_5
; %bb.1:
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_5
; %bb.2:
	ldr	w1, [sp, #52]
	add	x0, sp, #56
	add	x2, sp, #40
	bl	_nvm_v2_take
	cbnz	w0, LBB2_5
; %bb.3:
	add	x0, sp, #56
	bl	_nvm_v2_align4
	cbnz	w0, LBB2_5
; %bb.4:
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB2_7
LBB2_5:
	mov	w0, #0                          ; =0x0
LBB2_6:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB2_7:
	ldr	w8, [sp, #52]
	mov	w22, #1                         ; =0x1
	cbz	w8, LBB2_41
; %bb.8:
	mov	x21, #0                         ; =0x0
	add	x20, x19, #112, lsl #12         ; =458752
	add	x23, sp, #24
	add	x24, x19, #32
	add	x8, x19, #24
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w25, #2068                      ; =0x814
	mov	w28, #22                        ; =0x16
LBB2_9:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_12 Depth 2
                                        ;       Child Loop BB2_26 Depth 3
	add	x0, sp, #56
	add	x1, sp, #38
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_5
; %bb.10:                               ;   in Loop: Header=BB2_9 Depth=1
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_5
; %bb.11:                               ;   in Loop: Header=BB2_9 Depth=1
	mov	x26, #0                         ; =0x0
	mul	x27, x21, x25
	add	x25, x24, x27
LBB2_12:                                ;   Parent Loop BB2_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_26 Depth 3
	add	x0, sp, #56
	add	x1, sp, #24
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_5
; %bb.13:                               ;   in Loop: Header=BB2_12 Depth=2
	add	x0, sp, #56
	add	x1, sp, #23
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_5
; %bb.14:                               ;   in Loop: Header=BB2_12 Depth=2
	add	x0, sp, #56
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_5
; %bb.15:                               ;   in Loop: Header=BB2_12 Depth=2
	add	x0, sp, #56
	orr	x1, x23, #0x4
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_5
; %bb.16:                               ;   in Loop: Header=BB2_12 Depth=2
	ldrb	w8, [sp, #23]
	cbnz	w8, LBB2_44
; %bb.17:                               ;   in Loop: Header=BB2_12 Depth=2
	cbz	x26, LBB2_21
; %bb.18:                               ;   in Loop: Header=BB2_12 Depth=2
	ldrh	w9, [sp, #36]
	ldrb	w8, [sp, #24]
	cmp	x26, x9
	b.hi	LBB2_20
; %bb.19:                               ;   in Loop: Header=BB2_12 Depth=2
	cbz	w8, LBB2_45
LBB2_20:                                ;   in Loop: Header=BB2_12 Depth=2
	cmp	x26, x9
	b.hi	LBB2_33
LBB2_21:                                ;   in Loop: Header=BB2_12 Depth=2
	ldr	x8, [sp, #24]
	lsr	x9, x8, #32
	and	x10, x8, #0xff
	cmp	x10, #8
	b.ne	LBB2_29
; %bb.22:                               ;   in Loop: Header=BB2_12 Depth=2
	ldr	x10, [x19, #8]
	ldr	x10, [x10]
	ldr	w11, [x10, #8]
	cmp	w11, w9
	b.ls	LBB2_42
; %bb.23:                               ;   in Loop: Header=BB2_12 Depth=2
	add	x11, x10, x9, lsl #2
	ldr	w11, [x11, #4120]
	cmp	w11, #1
	b.ne	LBB2_42
; %bb.24:                               ;   in Loop: Header=BB2_12 Depth=2
	ldr	x10, [x10]
	add	x10, x10, x9, lsl #4
	ldrh	w9, [x10, #2]
	cbz	x9, LBB2_33
; %bb.25:                               ;   in Loop: Header=BB2_12 Depth=2
	ldr	x10, [x10, #8]
	add	x10, x10, #4
LBB2_26:                                ;   Parent Loop BB2_9 Depth=1
                                        ;     Parent Loop BB2_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w11, [x10, #-4]
	cmp	w11, #4
	lsl	w11, w22, w11
	and	w11, w11, w28
	ccmp	w11, #0, #4, ls
	b.eq	LBB2_42
; %bb.27:                               ;   in Loop: Header=BB2_26 Depth=3
	ldr	w11, [x10], #12
	cmn	w11, #1
	b.ne	LBB2_42
; %bb.28:                               ;   in Loop: Header=BB2_26 Depth=3
	subs	x9, x9, #1
	b.ne	LBB2_26
	b	LBB2_33
LBB2_29:                                ;   in Loop: Header=BB2_12 Depth=2
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB2_42
; %bb.30:                               ;   in Loop: Header=BB2_12 Depth=2
	and	w9, w8, #0xff
	cmp	w9, #4
	b.hi	LBB2_42
; %bb.31:                               ;   in Loop: Header=BB2_12 Depth=2
	mov	w9, #23                         ; =0x17
	lsr	w10, w9, w8
Lloh38:
	adrp	x9, l_.str.11@PAGE
Lloh39:
	add	x9, x9, l_.str.11@PAGEOFF
	tbz	w10, #0, LBB2_43
; %bb.32:                               ;   in Loop: Header=BB2_12 Depth=2
	ubfiz	x8, x8, #3, #3
	mov	x9, #256                        ; =0x100
	movk	x9, #2, lsl #16
	movk	x9, #4, lsl #32
	lsr	x8, x9, x8
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
LBB2_33:                                ;   in Loop: Header=BB2_12 Depth=2
	orr	w9, w26, w21
	cbnz	w9, LBB2_36
; %bb.34:                               ;   in Loop: Header=BB2_12 Depth=2
	and	w8, w8, #0xff
	cmp	w8, #4
	b.hi	LBB2_46
; %bb.35:                               ;   in Loop: Header=BB2_12 Depth=2
	lsl	w8, w22, w8
Lloh40:
	adrp	x9, l_.str.12@PAGE
Lloh41:
	add	x9, x9, l_.str.12@PAGEOFF
	tst	w8, w28
	b.eq	LBB2_43
LBB2_36:                                ;   in Loop: Header=BB2_12 Depth=2
	cbz	x26, LBB2_38
; %bb.37:                               ;   in Loop: Header=BB2_12 Depth=2
	add	x8, x25, x26, lsl #3
	ldr	x9, [sp, #24]
	stur	x9, [x8, #-8]
	b	LBB2_39
LBB2_38:                                ;   in Loop: Header=BB2_12 Depth=2
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x9, x27]
LBB2_39:                                ;   in Loop: Header=BB2_12 Depth=2
	ldrh	w8, [sp, #38]
	cmp	x26, x8
	add	x26, x26, #1
	b.lo	LBB2_12
; %bb.40:                               ;   in Loop: Header=BB2_9 Depth=1
	add	x21, x21, #1
	ldr	w8, [sp, #52]
	mov	w0, #1                          ; =0x1
	cmp	x21, x8
	mov	w25, #2068                      ; =0x814
	b.lo	LBB2_9
	b	LBB2_6
LBB2_41:
	mov	w0, #1                          ; =0x1
	b	LBB2_6
LBB2_42:
Lloh42:
	adrp	x9, l_.str.11@PAGE
Lloh43:
	add	x9, x9, l_.str.11@PAGEOFF
LBB2_43:
	mov	w8, #1                          ; =0x1
	stp	w8, w21, [x20, #208]
	stp	xzr, x9, [x20, #216]
	b	LBB2_5
LBB2_44:
Lloh44:
	adrp	x9, l_.str.9@PAGE
Lloh45:
	add	x9, x9, l_.str.9@PAGEOFF
	b	LBB2_43
LBB2_45:
Lloh46:
	adrp	x9, l_.str.10@PAGE
Lloh47:
	add	x9, x9, l_.str.10@PAGEOFF
	b	LBB2_43
LBB2_46:
Lloh48:
	adrp	x9, l_.str.12@PAGE
Lloh49:
	add	x9, x9, l_.str.12@PAGEOFF
	b	LBB2_43
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_preflight
_mf_preflight:                          ; @mf_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x28, [x0]
	ldr	w22, [x28, #272]
	mov	w20, #1                         ; =0x1
	cbz	w22, LBB3_92
; %bb.1:
	mov	x19, x0
	mov	x26, #0                         ; =0x0
	add	x8, x0, #112, lsl #12           ; =458752
	add	x11, x8, #208
	mov	w9, #49328                      ; =0xc0b0
	movk	w9, #6, lsl #16
	ldr	x8, [x0, #8]
	ldr	x10, [x8]
	add	x27, x0, #16
	mov	w8, #16560                      ; =0x40b0
	add	x8, x0, x8
	stp	x10, x8, [sp, #40]              ; 16-byte Folded Spill
	mov	w8, #4120                       ; =0x1018
	add	x8, x10, x8
	stp	x8, x11, [sp, #24]              ; 16-byte Folded Spill
	add	x8, x10, #24
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w24, [x0, x9]
	mov	w9, #24                         ; =0x18
LBB3_2:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_10 Depth 2
                                        ;     Child Loop BB3_16 Depth 2
                                        ;       Child Loop BB3_34 Depth 3
	ldr	x23, [x28, #256]
	mov	w8, w26
	umaddl	x21, w8, w9, x23
	mov	w9, #2068                       ; =0x814
	umaddl	x25, w8, w9, x27
	str	w24, [x25]
	ldr	w8, [x21]
	ldr	w9, [x28, #248]
	cmp	w8, w9
	b.hs	LBB3_77
; %bb.3:                                ;   in Loop: Header=BB3_2 Depth=1
	ldr	x9, [x28, #232]
	cbz	x9, LBB3_77
; %bb.4:                                ;   in Loop: Header=BB3_2 Depth=1
	ldr	x0, [x9, x8, lsl #3]
	cbz	x0, LBB3_77
; %bb.5:                                ;   in Loop: Header=BB3_2 Depth=1
Lloh50:
	adrp	x1, l_.str.14@PAGE
Lloh51:
	add	x1, x1, l_.str.14@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB3_82
; %bb.6:                                ;   in Loop: Header=BB3_2 Depth=1
	ldr	w9, [x21, #8]
	ldr	w10, [x28, #288]
	cmp	w10, w9
	b.lo	LBB3_78
; %bb.7:                                ;   in Loop: Header=BB3_2 Depth=1
	ldr	w8, [x21, #12]
	sub	w11, w8, #1
	sub	w10, w10, w9
	cmp	w11, w10
	b.hs	LBB3_78
; %bb.8:                                ;   in Loop: Header=BB3_2 Depth=1
	cbz	w26, LBB3_13
; %bb.9:                                ;   in Loop: Header=BB3_2 Depth=1
	add	x10, x8, x9
	add	x11, x23, #12
	mov	x12, x26
LBB3_10:                                ;   Parent Loop BB3_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	w13, w14, [x11, #-4]
	add	x14, x14, x13
	cmp	x14, x9
	ccmp	x10, x13, #0, hi
	b.hi	LBB3_75
; %bb.11:                               ;   in Loop: Header=BB3_10 Depth=2
	add	x11, x11, #24
	subs	x12, x12, #1
	b.ne	LBB3_10
; %bb.12:                               ;   in Loop: Header=BB3_2 Depth=1
	cbz	w8, LBB3_57
LBB3_13:                                ;   in Loop: Header=BB3_2 Depth=1
	str	x27, [sp]                       ; 8-byte Folded Spill
	mov	w27, #0                         ; =0x0
	add	x9, x25, #20
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_16
LBB3_14:                                ;   in Loop: Header=BB3_16 Depth=2
	ldrb	w8, [x22, #8]
	cmp	w8, #1
	b.hi	LBB3_88
LBB3_15:                                ;   in Loop: Header=BB3_16 Depth=2
	add	x8, x19, #108, lsl #12          ; =442368
	ldr	w24, [x8, #176]
	mov	w8, #-1                         ; =0xffffffff
	stp	w24, w8, [x22, #68]
	ldr	w8, [x21, #12]
	add	w27, w23, w27
	cmp	w27, w8
	b.hs	LBB3_56
LBB3_16:                                ;   Parent Loop BB3_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_34 Depth 3
	cmp	w24, #1, lsl #12                ; =4096
	b.eq	LBB3_79
; %bb.17:                               ;   in Loop: Header=BB3_16 Depth=2
	add	w9, w24, #1
	mov	w10, #49328                     ; =0xc0b0
	movk	w10, #6, lsl #16
	str	w9, [x19, x10]
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w10, #104                       ; =0x68
	umaddl	x22, w24, w10, x9
	str	w27, [x22, #64]
	mov	w9, #-1                         ; =0xffffffff
	stp	w26, w9, [x22, #76]
	ldr	x9, [x28, #280]
	ldr	w10, [x21, #8]
	add	x9, x9, x10
	add	x0, x9, w27, uxtw
	sub	w1, w8, w27
	mov	x2, x22
	bl	_isa_decode
	cbz	w0, LBB3_80
; %bb.18:                               ;   in Loop: Header=BB3_16 Depth=2
	mov	x23, x0
	ldrb	w24, [x22]
	add	x1, sp, #62
	mov	x0, x24
	bl	_mf_scalar_op
	mov	w11, #22                        ; =0x16
	tbz	w0, #31, LBB3_24
; %bb.19:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #79
	b.gt	LBB3_21
; %bb.20:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #61
	lsl	x8, x20, x24
	mov	x9, #32641                      ; =0x7f81
	movk	x9, #3, lsl #16
	movk	x9, #12032, lsl #48
	and	x8, x8, x9
	ccmp	x8, #0, #4, ls
	b.ne	LBB3_24
	b	LBB3_96
LBB3_21:                                ;   in Loop: Header=BB3_16 Depth=2
	sub	w8, w24, #80
	cmp	w8, #8
	lsl	w8, w20, w8
	mov	w9, #315                        ; =0x13b
	and	w8, w8, w9
	ccmp	w8, #0, #4, ls
	b.ne	LBB3_24
; %bb.22:                               ;   in Loop: Header=BB3_16 Depth=2
	sub	w8, w24, #251
	cmp	w8, #2
	b.lo	LBB3_24
; %bb.23:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #161
	b.ne	LBB3_96
LBB3_24:                                ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #59
	b.hi	LBB3_27
; %bb.25:                               ;   in Loop: Header=BB3_16 Depth=2
	lsl	x8, x20, x24
	mov	w9, #22528                      ; =0x5800
	movk	w9, #3, lsl #16
	tst	x8, x9
	b.eq	LBB3_46
; %bb.26:                               ;   in Loop: Header=BB3_16 Depth=2
	ldrh	w8, [x22, #8]
	ldrh	w9, [x21, #16]
	cmp	w8, w9
	b.hs	LBB3_84
LBB3_27:                                ;   in Loop: Header=BB3_16 Depth=2
	sub	w8, w24, #13
	and	w8, w8, #0xff
	cmp	w8, #1
	b.hi	LBB3_37
; %bb.28:                               ;   in Loop: Header=BB3_16 Depth=2
	add	x8, x22, #8
	cmp	w24, #13
	b.eq	LBB3_30
; %bb.29:                               ;   in Loop: Header=BB3_16 Depth=2
	ldrh	w8, [x8]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x9, x8, lsl #3
LBB3_30:                                ;   in Loop: Header=BB3_16 Depth=2
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	w9, [x9, #8]
	cmp	w8, w9
	b.hs	LBB3_76
; %bb.31:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [x9, x8, lsl #2]
	cmp	w9, #1
	b.ne	LBB3_76
; %bb.32:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	add	x9, x9, x8, lsl #4
	ldrh	w8, [x9, #2]
	cbz	x8, LBB3_37
; %bb.33:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	x9, [x9, #8]
	add	x9, x9, #4
LBB3_34:                                ;   Parent Loop BB3_2 Depth=1
                                        ;     Parent Loop BB3_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurb	w10, [x9, #-4]
	cmp	w10, #4
	lsl	w10, w20, w10
	and	w10, w10, w11
	ccmp	w10, #0, #4, ls
	b.eq	LBB3_76
; %bb.35:                               ;   in Loop: Header=BB3_34 Depth=3
	ldr	w10, [x9], #12
	cmn	w10, #1
	b.ne	LBB3_76
; %bb.36:                               ;   in Loop: Header=BB3_34 Depth=3
	subs	x8, x8, #1
	b.ne	LBB3_34
LBB3_37:                                ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #80
	b.eq	LBB3_40
; %bb.38:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #251
	b.eq	LBB3_40
; %bb.39:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #88
	b.ne	LBB3_15
LBB3_40:                                ;   in Loop: Header=BB3_16 Depth=2
	cmp	w24, #251
	b.ne	LBB3_51
; %bb.41:                               ;   in Loop: Header=BB3_16 Depth=2
	ldrb	w8, [x22, #8]
	cbnz	w8, LBB3_83
; %bb.42:                               ;   in Loop: Header=BB3_16 Depth=2
	ldrh	w8, [x22, #24]
	cbnz	w8, LBB3_83
; %bb.43:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	w9, [x22, #16]
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	ldr	w8, [x11, #16]
	cmp	w9, w8
	b.hs	LBB3_83
; %bb.44:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [x8, w9, uxtw #2]
	ldr	x8, [x11]
	add	x8, x8, w10, uxtw #4
	ldrh	w8, [x8, #2]
	ldrh	w11, [x22, #32]
	cmp	w8, w11
	b.ne	LBB3_86
; %bb.45:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	x11, [sp, #24]                  ; 8-byte Folded Reload
	ldr	w11, [x11, w10, uxtw #2]
	and	w11, w11, #0xfffffffe
	cmp	w11, #2
	b.eq	LBB3_53
	b	LBB3_87
LBB3_46:                                ;   in Loop: Header=BB3_16 Depth=2
	cmp	x24, #3
	b.eq	LBB3_14
; %bb.47:                               ;   in Loop: Header=BB3_16 Depth=2
	cmp	x24, #59
	b.ne	LBB3_27
; %bb.48:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	w8, [x22, #8]
	ldr	w9, [x28, #272]
	cmp	w8, w9
	b.hs	LBB3_89
; %bb.49:                               ;   in Loop: Header=BB3_16 Depth=2
	cbz	w8, LBB3_90
; %bb.50:                               ;   in Loop: Header=BB3_16 Depth=2
	lsl	w8, w20, w8
	ldrb	w9, [x25, #2064]
	orr	w8, w9, w8
	strb	w8, [x25, #2064]
	b	LBB3_15
LBB3_51:                                ;   in Loop: Header=BB3_16 Depth=2
	ldrb	w8, [x22, #8]
	cmp	w8, #3
	b.ne	LBB3_85
; %bb.52:                               ;   in Loop: Header=BB3_16 Depth=2
	mov	w8, #0                          ; =0x0
	mov	w9, #-1                         ; =0xffffffff
	mov	w10, #-1                        ; =0xffffffff
LBB3_53:                                ;   in Loop: Header=BB3_16 Depth=2
	ldr	x12, [x19, #8]
	ldr	w13, [x12, #8]
	cmp	w13, #64
	b.eq	LBB3_81
; %bb.54:                               ;   in Loop: Header=BB3_16 Depth=2
	ldr	w11, [x12, #12]
	mov	w14, #65536                     ; =0x10000
	sub	w14, w14, w11
	cmp	w14, w8
	b.lo	LBB3_81
; %bb.55:                               ;   in Loop: Header=BB3_16 Depth=2
	add	w14, w13, #1
	str	w14, [x12, #8]
	strh	w13, [x22, #80]
	sxth	x13, w13
	mov	w14, #24                        ; =0x18
	smaddl	x12, w13, w14, x12
	cmp	w24, #251
	mov	w13, #7                         ; =0x7
	cinc	w13, w13, eq
	stp	w26, w27, [x12, #28]
	stp	w10, w9, [x12, #36]
	str	w11, [x12, #44]
	strh	w8, [x12, #48]
	strb	w13, [x12, #50]
	strb	wzr, [x12, #51]
	ldr	x9, [x19, #8]
	ldr	w10, [x9, #12]
	add	w8, w10, w8
	str	w8, [x9, #12]
	b	LBB3_15
LBB3_56:                                ;   in Loop: Header=BB3_2 Depth=1
	ldr	w22, [x28, #272]
	ldr	x27, [sp]                       ; 8-byte Folded Reload
LBB3_57:                                ;   in Loop: Header=BB3_2 Depth=1
	str	w24, [x25, #4]
	add	x26, x26, #1
	cmp	w26, w22
	mov	w9, #24                         ; =0x18
	b.lo	LBB3_2
; %bb.58:
	cbz	w22, LBB3_93
; %bb.59:
	mov	x26, #0                         ; =0x0
	mov	w8, #16624                      ; =0x40f0
	add	x21, x19, x8
	mov	w22, #2068                      ; =0x814
	mov	w23, #104                       ; =0x68
	mov	w24, #24                        ; =0x18
LBB3_60:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_63 Depth 2
                                        ;       Child Loop BB3_66 Depth 3
	mov	x25, x27
	madd	x9, x26, x22, x27
	ldp	w8, w9, [x9]
	cmp	w8, w9
	b.hs	LBB3_73
; %bb.61:                               ;   in Loop: Header=BB3_60 Depth=1
	umaddl	x10, w8, w23, x21
	mov	x11, x8
	b	LBB3_63
LBB3_62:                                ;   in Loop: Header=BB3_63 Depth=2
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB3_73
LBB3_63:                                ;   Parent Loop BB3_60 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_66 Depth 3
	ldr	x12, [sp, #48]                  ; 8-byte Folded Reload
	madd	x12, x11, x23, x12
	ldrb	w13, [x12]
	sub	w14, w13, #56
	cmp	w14, #2
	b.hi	LBB3_70
; %bb.64:                               ;   in Loop: Header=BB3_63 Depth=2
	ldr	w27, [x12, #64]
	ldrsw	x14, [x12, #8]
	add	x14, x14, x27
	mov	x15, x10
	mov	x16, x8
	b	LBB3_66
LBB3_65:                                ;   in Loop: Header=BB3_66 Depth=3
	add	x16, x16, #1
	cmp	x9, x16
	b.eq	LBB3_68
LBB3_66:                                ;   Parent Loop BB3_60 Depth=1
                                        ;     Parent Loop BB3_63 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w17, [x15], #104
	cmp	x14, x17
	b.ne	LBB3_65
; %bb.67:                               ;   in Loop: Header=BB3_66 Depth=3
	str	w16, [x12, #72]
	b	LBB3_65
LBB3_68:                                ;   in Loop: Header=BB3_63 Depth=2
	ldr	x15, [x28, #256]
	madd	x15, x26, x24, x15
	ldr	w15, [x15, #12]
	cmp	x14, x15
	b.eq	LBB3_94
; %bb.69:                               ;   in Loop: Header=BB3_63 Depth=2
	ldr	w14, [x12, #72]
	cmn	w14, #1
	b.eq	LBB3_95
LBB3_70:                                ;   in Loop: Header=BB3_63 Depth=2
	ldr	w14, [x12, #68]
	cmp	w14, w9
	b.ne	LBB3_62
; %bb.71:                               ;   in Loop: Header=BB3_63 Depth=2
	cmp	w13, #56
	b.eq	LBB3_62
; %bb.72:                               ;   in Loop: Header=BB3_63 Depth=2
	cmp	w13, #61
	b.eq	LBB3_62
	b	LBB3_97
LBB3_73:                                ;   in Loop: Header=BB3_60 Depth=1
	mov	x0, x19
	mov	x1, x26
	bl	_mf_graph
	mov	x20, x0
	cbz	w0, LBB3_92
; %bb.74:                               ;   in Loop: Header=BB3_60 Depth=1
	add	x26, x26, #1
	ldr	w8, [x28, #272]
	cmp	x26, x8
	mov	x27, x25
	b.lo	LBB3_60
	b	LBB3_92
LBB3_75:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
Lloh52:
	adrp	x10, l_.str.17@PAGE
Lloh53:
	add	x10, x10, l_.str.17@PAGEOFF
	b	LBB3_91
LBB3_76:
	mov	w8, #1                          ; =0x1
Lloh54:
	adrp	x10, l_.str.25@PAGE
Lloh55:
	add	x10, x10, l_.str.25@PAGEOFF
	b	LBB3_91
LBB3_77:
	mov	w27, #0                         ; =0x0
	mov	w8, #2                          ; =0x2
Lloh56:
	adrp	x10, l_.str.13@PAGE
Lloh57:
	add	x10, x10, l_.str.13@PAGEOFF
	b	LBB3_91
LBB3_78:
	mov	w27, #0                         ; =0x0
	mov	w8, #2                          ; =0x2
Lloh58:
	adrp	x10, l_.str.16@PAGE
Lloh59:
	add	x10, x10, l_.str.16@PAGEOFF
	b	LBB3_91
LBB3_79:
	mov	w8, #3                          ; =0x3
Lloh60:
	adrp	x10, l_.str.18@PAGE
Lloh61:
	add	x10, x10, l_.str.18@PAGEOFF
	b	LBB3_91
LBB3_80:
	mov	w8, #2                          ; =0x2
Lloh62:
	adrp	x10, l_.str.19@PAGE
Lloh63:
	add	x10, x10, l_.str.19@PAGEOFF
	b	LBB3_91
LBB3_81:
	mov	w8, #3                          ; =0x3
Lloh64:
	adrp	x10, l_.str.30@PAGE
Lloh65:
	add	x10, x10, l_.str.30@PAGEOFF
	b	LBB3_91
LBB3_82:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
Lloh66:
	adrp	x10, l_.str.15@PAGE
Lloh67:
	add	x10, x10, l_.str.15@PAGEOFF
	b	LBB3_91
LBB3_83:
	mov	w8, #1                          ; =0x1
Lloh68:
	adrp	x10, l_.str.26@PAGE
Lloh69:
	add	x10, x10, l_.str.26@PAGEOFF
	b	LBB3_91
LBB3_84:
	mov	w8, #2                          ; =0x2
Lloh70:
	adrp	x10, l_.str.22@PAGE
Lloh71:
	add	x10, x10, l_.str.22@PAGEOFF
	b	LBB3_91
LBB3_85:
	mov	w8, #1                          ; =0x1
Lloh72:
	adrp	x10, l_.str.29@PAGE
Lloh73:
	add	x10, x10, l_.str.29@PAGEOFF
	b	LBB3_91
LBB3_86:
	mov	w8, #2                          ; =0x2
Lloh74:
	adrp	x10, l_.str.27@PAGE
Lloh75:
	add	x10, x10, l_.str.27@PAGEOFF
	b	LBB3_91
LBB3_87:
	mov	w8, #1                          ; =0x1
Lloh76:
	adrp	x10, l_.str.28@PAGE
Lloh77:
	add	x10, x10, l_.str.28@PAGEOFF
	b	LBB3_91
LBB3_88:
	mov	w8, #2                          ; =0x2
Lloh78:
	adrp	x10, l_.str.21@PAGE
Lloh79:
	add	x10, x10, l_.str.21@PAGEOFF
	b	LBB3_91
LBB3_89:
	mov	w8, #2                          ; =0x2
Lloh80:
	adrp	x10, l_.str.23@PAGE
Lloh81:
	add	x10, x10, l_.str.23@PAGEOFF
	b	LBB3_91
LBB3_90:
	mov	w8, #1                          ; =0x1
Lloh82:
	adrp	x10, l_.str.24@PAGE
Lloh83:
	add	x10, x10, l_.str.24@PAGEOFF
LBB3_91:
	mov	w20, #0                         ; =0x0
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	stp	w8, w26, [x9]
	stp	w27, wzr, [x9, #8]
	str	x10, [x9, #16]
LBB3_92:
	mov	x0, x20
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB3_93:
	mov	w20, #1                         ; =0x1
	b	LBB3_92
LBB3_94:
Lloh84:
	adrp	x10, l_.str.31@PAGE
Lloh85:
	add	x10, x10, l_.str.31@PAGEOFF
	b	LBB3_98
LBB3_95:
Lloh86:
	adrp	x10, l_.str.32@PAGE
Lloh87:
	add	x10, x10, l_.str.32@PAGEOFF
	mov	w8, #2                          ; =0x2
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	b	LBB3_91
LBB3_96:
Lloh88:
	adrp	x10, l_.str.20@PAGE
Lloh89:
	add	x10, x10, l_.str.20@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB3_91
LBB3_97:
	ldr	w27, [x12, #64]
Lloh90:
	adrp	x10, l_.str.33@PAGE
Lloh91:
	add	x10, x10, l_.str.33@PAGEOFF
LBB3_98:
	mov	w8, #1                          ; =0x1
                                        ; kill: def $w26 killed $w26 killed $x26 def $x26
	b	LBB3_91
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_join
_mf_join:                               ; @mf_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x8, x0, #112, lsl #12           ; =458752
	add	x21, x8, #196
	mov	w8, #104                        ; =0x68
	umaddl	x8, w1, w8, x0
	mov	w9, #16560                      ; =0x40b0
	add	x22, x8, x9
	ldr	w23, [x22, #76]
	cmp	w3, #257
	b.lo	LBB4_2
; %bb.1:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x22, #64]
	mov	w10, #3                         ; =0x3
	stp	w10, w23, [x21, #12]
	stp	w9, wzr, [x21, #20]
Lloh92:
	adrp	x9, l_.str.35@PAGE
Lloh93:
	add	x9, x9, l_.str.35@PAGEOFF
	stur	x9, [x21, #28]
	b	LBB4_24
LBB4_2:
	ldr	x8, [x0]
	ldr	x8, [x8, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w23, w9, x8
	ldrh	w24, [x8, #16]
	ldrsh	w8, [x22, #82]
	tbnz	w8, #31, LBB4_5
; %bb.3:
	cmp	w8, w3
	b.eq	LBB4_5
; %bb.4:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x22, #64]
	mov	w10, #2                         ; =0x2
	stp	w10, w23, [x21, #12]
	stp	w9, wzr, [x21, #20]
Lloh94:
	adrp	x9, l_.str.36@PAGE
Lloh95:
	add	x9, x9, l_.str.36@PAGEOFF
	stur	x9, [x21, #28]
	b	LBB4_24
LBB4_5:
	ldr	x8, [x22, #88]
	cbz	x8, LBB4_16
; %bb.6:
	adds	w11, w24, w3
	b.eq	LBB4_23
; %bb.7:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w12, #24                        ; =0x18
	umull	x11, w11, w12
	mov	w12, #1                         ; =0x1
	b	LBB4_10
LBB4_8:                                 ;   in Loop: Header=BB4_10 Depth=1
	ldrh	w16, [x8, x10]
LBB4_9:                                 ;   in Loop: Header=BB4_10 Depth=1
	add	x17, x8, x10
	ldr	x3, [x17, #8]
	ldrb	w4, [x17, #23]
	orr	w14, w16, w14
	strh	w14, [x17]
	orr	x13, x3, x13
	str	x13, [x17, #8]
	orr	w15, w4, w15
	strb	w15, [x17, #23]
	cmp	x3, x13
	ccmp	w4, w15, #0, eq
	cset	w13, ne
	cmp	w16, w14
	csel	w13, w12, w13, ne
	orr	w9, w9, w13
	add	x10, x10, #24
	cmp	x11, x10
	b.eq	LBB4_20
LBB4_10:                                ; =>This Inner Loop Header: Depth=1
	add	x16, x2, x10
	ldrh	w14, [x16]
	ldr	x13, [x16, #8]
	ldrb	w15, [x16, #22]
	and	w17, w15, #0xff
	ldrb	w15, [x16, #23]
	add	x3, x8, x10
	ldrb	w3, [x3, #22]
	orr	w4, w3, w17
	cbz	w4, LBB4_8
; %bb.11:                               ;   in Loop: Header=BB4_10 Depth=1
	cmp	w3, w17
	b.ne	LBB4_15
; %bb.12:                               ;   in Loop: Header=BB4_10 Depth=1
	ldr	w3, [x16, #16]
	add	x17, x8, x10
	ldr	w4, [x17, #16]
	cmp	w4, w3
	b.ne	LBB4_15
; %bb.13:                               ;   in Loop: Header=BB4_10 Depth=1
	ldrh	w16, [x16, #20]
	ldrh	w17, [x17, #20]
	cmp	w17, w16
	b.ne	LBB4_15
; %bb.14:                               ;   in Loop: Header=BB4_10 Depth=1
	ldrh	w17, [x8, x10]
	mov	x16, x14
	cmp	w17, w14
	b.eq	LBB4_9
LBB4_15:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x22, #64]
	mov	w10, #1                         ; =0x1
	stp	w10, w23, [x21, #12]
	stp	w9, wzr, [x21, #20]
Lloh96:
	adrp	x9, l_.str.39@PAGE
Lloh97:
	add	x9, x9, l_.str.39@PAGEOFF
	stur	x9, [x21, #28]
	b	LBB4_24
LBB4_16:
	mov	w25, #49332                     ; =0xc0b4
	movk	w25, #6, lsl #16
	add	x19, x24, #256
	ldr	w27, [x0, x25]
	mov	w8, #1048576                    ; =0x100000
	sub	w8, w8, w27
	cmp	w19, w8
	b.ls	LBB4_18
; %bb.17:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x22, #64]
	mov	w10, #3                         ; =0x3
	stp	w10, w23, [x21, #12]
	stp	w9, wzr, [x21, #20]
Lloh98:
	adrp	x9, l_.str.37@PAGE
Lloh99:
	add	x9, x9, l_.str.37@PAGEOFF
	stur	x9, [x21, #28]
	b	LBB4_24
LBB4_18:
	mov	x28, x3
	mov	x20, x2
	mov	x26, x0
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	mov	x0, x19
	mov	w1, #24                         ; =0x18
	bl	_calloc
	str	x0, [x22, #88]
	cbz	x0, LBB4_25
; %bb.19:
	add	w8, w27, w19
	str	w8, [x26, x25]
	add	w8, w24, w28
	add	w8, w8, w8, lsl #1
	lsl	w2, w8, #3
	mov	x1, x20
	bl	_memcpy
	mov	x0, x26
	strh	w28, [x22, #82]
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	b	LBB4_21
LBB4_20:
	tbz	w9, #0, LBB4_23
LBB4_21:
	mov	w8, w1
	mov	w9, #104                        ; =0x68
	umull	x9, w8, w9
	mov	w8, #16656                      ; =0x4110
	add	x10, x0, x8
	ldrb	w11, [x10, x9]
	mov	w8, #1                          ; =0x1
	tbnz	w11, #0, LBB4_24
; %bb.22:
	strb	w8, [x10, x9]
	ldr	w9, [x21]
	add	x9, x0, x9, lsl #2
	mov	w10, #49344                     ; =0xc0c0
	movk	w10, #6, lsl #16
	str	w1, [x9, x10]
	ldp	w9, w10, [x21]
	add	w9, w9, #1
	and	w9, w9, #0xfff
	add	w10, w10, #1
	stp	w9, w10, [x21]
	b	LBB4_24
LBB4_23:
	mov	w8, #1                          ; =0x1
LBB4_24:
	mov	x0, x8
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB4_25:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x22, #64]
	mov	w10, #4                         ; =0x4
	stp	w10, w23, [x21, #12]
	stp	w9, wzr, [x21, #20]
Lloh100:
	adrp	x9, l_.str.38@PAGE
Lloh101:
	add	x9, x9, l_.str.38@PAGEOFF
	stur	x9, [x21, #28]
	b	LBB4_24
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_step
_mf_step:                               ; @mf_step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #12432                      ; =0x3090
Lloh102:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh103:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x1
	mov	x19, x0
Lloh104:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh105:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh106:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	add	x8, x0, #112, lsl #12           ; =458752
	add	x26, x8, #208
	mov	w8, #104                        ; =0x68
	umaddl	x8, w1, w8, x0
	mov	w9, #16560                      ; =0x40b0
	add	x22, x8, x9
	ldr	x9, [x19], #16
	ldr	w10, [x22, #76]
	ldr	x9, [x9, #256]
	mov	w20, #24                        ; =0x18
	umaddl	x24, w10, w20, x9
	mov	w9, #2068                       ; =0x814
	stp	x0, x10, [sp, #64]              ; 16-byte Folded Spill
	umaddl	x28, w10, w9, x19
	ldr	x1, [x8, #16648]
	ldrh	w8, [x24, #16]
	ldrh	w23, [x22, #82]
	add	x8, x23, x8
	add	x8, x8, x8, lsl #1
	lsl	x2, x8, #3
	add	x27, sp, #128
	add	x0, sp, #128
	mov	w3, #12288                      ; =0x3000
	bl	___memcpy_chk
	ldrh	w25, [x24, #16]
	umaddl	x8, w25, w20, x27
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldrb	w20, [x22]
	mov	x0, x20
	bl	_isa_get_info
	ldrsb	w27, [x0, #28]
	ldrsb	w12, [x0, #29]
	cmp	w20, #60
	b.gt	LBB5_5
; %bb.1:
	cmp	w20, #13
	b.eq	LBB5_9
; %bb.2:
	cmp	w20, #14
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	b.eq	LBB5_16
; %bb.3:
	cmp	w20, #59
	b.ne	LBB5_19
; %bb.4:
	ldr	x8, [x8]
	ldr	x8, [x8, #256]
	ldr	w9, [x22, #8]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w27, [x8, #4]
	ldrb	w12, [x8, #21]
	b	LBB5_19
LBB5_5:
	cmp	w20, #61
	b.eq	LBB5_10
; %bb.6:
	cmp	w20, #251
	b.eq	LBB5_17
; %bb.7:
	cmp	w20, #88
	b.ne	LBB5_19
; %bb.8:
	ldrh	w27, [x22, #16]
	b	LBB5_18
LBB5_9:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	w9, [x22, #8]
	add	x8, x8, x9, lsl #4
	ldrh	w27, [x8, #2]
	b	LBB5_19
LBB5_10:
	ldrb	w8, [x24, #21]
	cmp	w23, w8
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	b.ne	LBB5_49
; %bb.11:
	mov	w0, #1                          ; =0x1
	cbz	w23, LBB5_24
; %bb.12:
	add	x9, x8, #108, lsl #12           ; =442368
	ldrb	w8, [x9, #188]
	ldr	x14, [sp, #56]                  ; 8-byte Folded Reload
	tbz	w8, #0, LBB5_24
; %bb.13:
	ldrh	w8, [x14]
	ldr	x9, [x14, #8]
	ldrb	w10, [x14, #22]
	ldrb	w11, [x14, #23]
	ldr	x12, [x28, #8]
	and	w13, w12, #0xff
	cmp	w13, #8
	b.ne	LBB5_67
; %bb.14:
	cmp	w10, #1
	ccmp	w11, #0, #0, eq
	ccmp	x9, #0, #0, eq
	b.ne	LBB5_68
; %bb.15:
	lsr	x9, x12, #32
	ldr	w10, [x14, #16]
	cmp	w8, #256
	ccmp	w10, w9, #0, eq
	b.eq	LBB5_24
	b	LBB5_68
LBB5_16:
	mov	w27, #0                         ; =0x0
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldrh	w9, [x22, #8]
	add	x9, x28, x9, lsl #3
	ldr	w9, [x9, #20]
	add	x8, x8, x9, lsl #4
	ldrh	w12, [x8, #2]
	b	LBB5_19
LBB5_17:
	ldrh	w27, [x22, #32]
LBB5_18:
	mov	w12, #1                         ; =0x1
LBB5_19:
	tbnz	w27, #31, LBB5_22
; %bb.20:
	tbnz	w12, #31, LBB5_22
; %bb.21:
	subs	w14, w23, w27
	b.hs	LBB5_26
LBB5_22:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #2                         ; =0x2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
Lloh107:
	adrp	x8, l_.str.42@PAGE
Lloh108:
	add	x8, x8, l_.str.42@PAGEOFF
LBB5_23:
	str	x8, [x26, #16]
LBB5_24:
	ldur	x8, [x29, #-96]
Lloh109:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh110:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh111:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_208
; %bb.25:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #144
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB5_26:
	add	w13, w14, w12
	cmp	w13, #257
	b.lo	LBB5_28
; %bb.27:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #3                         ; =0x3
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
Lloh112:
	adrp	x8, l_.str.43@PAGE
Lloh113:
	add	x8, x8, l_.str.43@PAGEOFF
	b	LBB5_23
LBB5_28:
	cmp	w20, #14
	b.eq	LBB5_30
; %bb.29:
	cmp	w20, #11
	b.ne	LBB5_36
LBB5_30:
	cbz	w23, LBB5_36
; %bb.31:
	ldrh	w8, [x22, #8]
	mov	w9, #24                         ; =0x18
	add	x10, sp, #128
	umaddl	x9, w25, w9, x10
	add	x9, x9, #22
	mov	x10, x23
	b	LBB5_33
LBB5_32:                                ;   in Loop: Header=BB5_33 Depth=1
	add	x9, x9, #24
	subs	x10, x10, #1
	b.eq	LBB5_36
LBB5_33:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9]
	cmp	w11, #2
	b.ne	LBB5_32
; %bb.34:                               ;   in Loop: Header=BB5_33 Depth=1
	ldurh	w11, [x9, #-2]
	cmp	w11, w8
	b.ne	LBB5_32
; %bb.35:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
Lloh114:
	adrp	x8, l_.str.44@PAGE
Lloh115:
	add	x8, x8, l_.str.44@PAGEOFF
	b	LBB5_23
LBB5_36:
	str	x14, [sp, #48]                  ; 8-byte Folded Spill
	stp	w13, w12, [sp, #40]             ; 8-byte Folded Spill
	mov	w21, w21
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	add	x1, sp, #118
	mov	x0, x20
	bl	_mf_scalar_op
	ldp	x17, x8, [sp, #64]              ; 16-byte Folded Reload
	ldr	x4, [x17, #8]
	add	x21, x4, x21, lsl #4
	str	w8, [x21, #1576]
	ldr	w2, [x22, #64]
	str	w2, [x21, #1580]
	tbnz	w0, #31, LBB5_50
; %bb.37:
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	ldrh	w8, [sp, #118]
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	cmp	w23, w1
	b.ls	LBB5_61
; %bb.38:
	sub	x9, x23, w1, uxtw
	mov	w10, #24                        ; =0x18
	umull	x11, w25, w10
	umaddl	x10, w1, w10, x11
	add	x11, sp, #128
	add	x10, x10, x11
	add	x10, x10, #23
	b	LBB5_40
LBB5_39:                                ;   in Loop: Header=BB5_40 Depth=1
	add	x10, x10, #24
	subs	x9, x9, #1
	b.eq	LBB5_61
LBB5_40:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x10, #-1]
	cbnz	w11, LBB5_66
; %bb.41:                               ;   in Loop: Header=BB5_40 Depth=1
	ldur	x11, [x10, #-15]
	cbnz	x11, LBB5_66
; %bb.42:                               ;   in Loop: Header=BB5_40 Depth=1
	ldrb	w11, [x10]
	cbnz	w11, LBB5_66
; %bb.43:                               ;   in Loop: Header=BB5_40 Depth=1
	ldurh	w11, [x10, #-23]
	cmp	w11, #32
	b.hs	LBB5_66
; %bb.44:                               ;   in Loop: Header=BB5_40 Depth=1
	cbnz	w11, LBB5_46
; %bb.45:                               ;   in Loop: Header=BB5_40 Depth=1
	add	x12, x17, #108, lsl #12         ; =442368
	ldrb	w12, [x12, #188]
	tbnz	w12, #0, LBB5_80
LBB5_46:                                ;   in Loop: Header=BB5_40 Depth=1
	cbz	w8, LBB5_39
; %bb.47:                               ;   in Loop: Header=BB5_40 Depth=1
	cmp	w11, w8
	b.eq	LBB5_39
; %bb.48:                               ;   in Loop: Header=BB5_40 Depth=1
	ldrh	w12, [x21, #1586]
	orr	w12, w12, w8
	strh	w12, [x21, #1586]
	ldrh	w12, [x21, #1588]
	orr	w11, w12, w11
	strh	w11, [x21, #1588]
	b	LBB5_39
LBB5_49:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #2                         ; =0x2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
Lloh116:
	adrp	x8, l_.str.40@PAGE
Lloh117:
	add	x8, x8, l_.str.40@PAGEOFF
	b	LBB5_23
LBB5_50:
	cmp	w20, #161
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	b.hi	LBB5_88
; %bb.51:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w3, #0                          ; =0x0
Lloh118:
	adrp	x8, lJTI5_0@PAGE
Lloh119:
	add	x8, x8, lJTI5_0@PAGEOFF
	adr	x9, LBB5_52
	ldrh	w10, [x8, x20, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB5_52:
	mov	w8, #24                         ; =0x18
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
	umaddl	x19, w1, w8, x25
	ldrh	w3, [x19]
	ldr	x16, [x19, #8]
	ldr	w0, [x19, #16]
	ldrh	w11, [x19, #20]
	ldrb	w12, [x19, #22]
	ldrb	w15, [x19, #23]
	add	x8, x17, #108, lsl #12          ; =442368
	ldrb	w24, [x8, #188]
	cmp	w24, #1
	b.ne	LBB5_59
; %bb.53:
	str	x4, [sp]                        ; 8-byte Folded Spill
	mov	x27, x2
	str	w3, [sp, #36]                   ; 4-byte Folded Spill
	strh	w3, [sp, #80]
	ldur	w8, [x19, #2]
	stur	w8, [sp, #82]
	ldurh	w8, [x19, #6]
	strh	w8, [sp, #86]
	stp	x16, x0, [sp, #16]              ; 16-byte Folded Spill
	str	x16, [sp, #88]
	str	w0, [sp, #96]
	stp	w12, w11, [sp, #8]              ; 8-byte Folded Spill
	strh	w11, [sp, #100]
	strb	w12, [sp, #102]
	mov	x28, x15
	strb	w15, [sp, #103]
	add	x1, sp, #80
	mov	x0, x17
	bl	_mf_array
	cbz	w0, LBB5_116
; %bb.54:
	sub	w8, w20, #83
	and	w8, w8, #0xff
	cmp	w8, #1
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	mov	x2, x27
	mov	x15, x28
	ldp	x16, x0, [sp, #16]              ; 16-byte Folded Reload
	ldr	w3, [sp, #36]                   ; 4-byte Folded Reload
	ldp	w12, w11, [sp, #8]              ; 8-byte Folded Reload
	ldr	x4, [sp]                        ; 8-byte Folded Reload
	b.hi	LBB5_59
; %bb.55:
	ldrb	w9, [x19, #47]
Lloh120:
	adrp	x8, l_.str.66@PAGE
Lloh121:
	add	x8, x8, l_.str.66@PAGEOFF
	cbnz	w9, LBB5_117
; %bb.56:
	ldrb	w9, [x19, #46]
	cbnz	w9, LBB5_117
; %bb.57:
	ldr	x9, [x19, #32]
	cbnz	x9, LBB5_117
; %bb.58:
	ldrh	w8, [x19, #24]
	cmp	w8, #2
	b.ne	LBB5_201
LBB5_59:
	cmp	w20, #83
	b.gt	LBB5_106
; %bb.60:
	cmp	w20, #81
	b.ne	LBB5_113
	b	LBB5_108
LBB5_61:
	mov	x16, #0                         ; =0x0
	mov	w15, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	lsl	w3, w9, w0
	cmp	w27, #1
	b.lt	LBB5_69
; %bb.62:
	cbnz	w8, LBB5_69
; %bb.63:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w1, w8, x9
	ldrh	w9, [x8]
	ldrh	w10, [x21, #1588]
	orr	w9, w10, w9
	strh	w9, [x21, #1588]
	cmp	w27, #2
	b.lo	LBB5_70
; %bb.64:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldrh	w8, [x8, #24]
	orr	w8, w8, w9
LBB5_65:
	strh	w8, [x21, #1588]
	b	LBB5_71
LBB5_66:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh122:
	adrp	x8, l_.str.45@PAGE
Lloh123:
	add	x8, x8, l_.str.45@PAGEOFF
	b	LBB5_23
LBB5_67:
	lsl	w12, w0, w13
	and	w12, w12, #0xffff
	cmp	w11, #0
	ccmp	w10, #0, #0, eq
	ccmp	x9, #0, #0, eq
	ccmp	w8, w12, #0, eq
	b.eq	LBB5_24
LBB5_68:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
Lloh124:
	adrp	x8, l_.str.41@PAGE
Lloh125:
	add	x8, x8, l_.str.41@PAGEOFF
	b	LBB5_23
LBB5_69:
	mov	x12, x15
	mov	x11, x15
	mov	x0, x15
	b	LBB5_71
LBB5_70:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
LBB5_71:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	cbz	w8, LBB5_73
; %bb.72:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w1, w8, x9
	strh	w3, [x8]
	ldr	w9, [sp, #120]
	stur	w9, [x8, #2]
	ldrh	w9, [sp, #124]
	strh	w9, [x8, #6]
	str	x16, [x8, #8]
	str	w0, [x8, #16]
	strh	w11, [x8, #20]
	strb	w12, [x8, #22]
	strb	w15, [x8, #23]
LBB5_73:
	ldr	w23, [sp, #40]                  ; 4-byte Folded Reload
LBB5_74:
	add	x8, x17, #108, lsl #12          ; =442368
	ldrb	w8, [x8, #188]
	tbz	w8, #0, LBB5_76
; %bb.75:
	mov	w0, #1                          ; =0x1
	b	LBB5_24
LBB5_76:
	sub	w8, w20, #56
	cmp	w8, #2
	b.hi	LBB5_79
; %bb.77:
	ldr	w1, [x22, #72]
	add	x2, sp, #128
	and	w3, w23, #0xffff
	mov	x0, x17
	bl	_mf_join
	cmp	w20, #56
	b.eq	LBB5_24
; %bb.78:
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	cbz	w0, LBB5_24
LBB5_79:
	ldr	w1, [x22, #68]
	add	x2, sp, #128
	and	w3, w23, #0xffff
	mov	x0, x17
	bl	_mf_join
	b	LBB5_24
LBB5_80:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh126:
	adrp	x8, l_.str.46@PAGE
Lloh127:
	add	x8, x8, l_.str.46@PAGEOFF
	b	LBB5_23
LBB5_81:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w1, w8, x9
	ldrb	w9, [x8, #22]
	cbnz	w9, LBB5_87
; %bb.82:
	ldr	x9, [x8, #8]
	cbnz	x9, LBB5_87
; %bb.83:
	ldrb	w9, [x8, #23]
	cbnz	w9, LBB5_87
; %bb.84:
	ldrh	w8, [x8]
	cmp	w8, #32
	b.hs	LBB5_87
; %bb.85:
	cmp	w8, #16
	b.eq	LBB5_173
; %bb.86:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w3, #0                          ; =0x0
	ldrh	w9, [x21, #1586]
	orr	w9, w9, #0x10
	strh	w9, [x21, #1586]
	ldrh	w9, [x21, #1588]
	orr	w8, w9, w8
	b	LBB5_65
LBB5_87:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh128:
	adrp	x8, l_.str.69@PAGE
Lloh129:
	add	x8, x8, l_.str.69@PAGEOFF
	b	LBB5_23
LBB5_88:
	cmp	w20, #251
	b.eq	LBB5_159
; %bb.89:
	cmp	w20, #252
	b.ne	LBB5_115
; %bb.90:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x11, w1, w8, x9
	ldrb	w9, [x11, #22]
	ldrh	w8, [x22, #8]
	cbz	w9, LBB5_180
; %bb.91:
	cmp	w9, #2
	b.ne	LBB5_172
; %bb.92:
	ldr	w9, [x11, #16]
	ldr	x10, [x4]
	ldr	w12, [x10, #8]
	cmp	w9, w12
	b.hs	LBB5_172
; %bb.93:
	ldr	x10, [x10]
	add	x10, x10, x9, lsl #4
	ldrh	w12, [x10, #2]
	cmp	w8, w12
	b.hs	LBB5_203
; %bb.94:
	ldrh	w11, [x11, #20]
	ldrh	w12, [x24, #16]
	cmp	w11, w12
	b.hs	LBB5_205
; %bb.95:
	mov	w12, #24                        ; =0x18
	add	x13, sp, #128
	umaddl	x11, w11, w12, x13
	ldrb	w12, [x11, #22]
	cmp	w12, #1
	b.ne	LBB5_205
; %bb.96:
	ldr	w11, [x11, #16]
	cmp	w11, w9
	b.ne	LBB5_205
; %bb.97:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	x9, [x10, #8]
	mov	w10, #12                        ; =0xc
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	str	wzr, [sp, #120]
	strh	wzr, [sp, #124]
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	and	w3, w8, #0xffff
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	b	LBB5_71
LBB5_98:
	cmp	w23, w1
	b.ls	LBB5_105
; %bb.99:
	add	x8, x17, #108, lsl #12          ; =442368
	ldrb	w8, [x8, #188]
	add	x9, x1, #1
	mov	w10, #24                        ; =0x18
	umull	x11, w25, w10
	umaddl	x10, w1, w10, x11
	add	x11, sp, #128
	add	x10, x10, x11
	add	x10, x10, #23
	b	LBB5_101
LBB5_100:                               ;   in Loop: Header=BB5_101 Depth=1
	cmp	w23, w9, uxth
	add	x9, x9, #1
	add	x10, x10, #24
	b.eq	LBB5_105
LBB5_101:                               ; =>This Inner Loop Header: Depth=1
	cbz	w8, LBB5_100
; %bb.102:                              ;   in Loop: Header=BB5_101 Depth=1
	ldur	x11, [x10, #-15]
	ldurb	w12, [x10, #-1]
	ldrb	w13, [x10]
	cmp	w13, #0
	ccmp	w12, #0, #0, eq
	ccmp	x11, #0, #0, eq
	b.ne	LBB5_104
; %bb.103:                              ;   in Loop: Header=BB5_101 Depth=1
	ldurh	w11, [x10, #-23]
	cmp	w11, #8
	b.eq	LBB5_100
LBB5_104:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh130:
	adrp	x8, l_.str.64@PAGE
Lloh131:
	add	x8, x8, l_.str.64@PAGEOFF
	b	LBB5_23
LBB5_105:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	ldrsh	x8, [x22, #80]
	mov	w9, #1                          ; =0x1
	lsl	x16, x9, x8
	mov	w3, #128                        ; =0x80
	b	LBB5_71
LBB5_106:
	cmp	w20, #85
	b.eq	LBB5_169
; %bb.107:
	cmp	w20, #84
	b.ne	LBB5_157
LBB5_108:
	cbz	w24, LBB5_113
; %bb.109:
	mov	w8, #24                         ; =0x18
	umaddl	x9, w23, w8, x25
	ldurb	w10, [x9, #-1]
Lloh132:
	adrp	x8, l_.str.67@PAGE
Lloh133:
	add	x8, x8, l_.str.67@PAGEOFF
	cbnz	w10, LBB5_117
; %bb.110:
	ldurb	w10, [x9, #-2]
	cbnz	w10, LBB5_117
; %bb.111:
	ldur	x10, [x9, #-16]
	cbnz	x10, LBB5_117
; %bb.112:
	ldurh	w8, [x9, #-24]
	cmp	w8, #8
	b.ne	LBB5_200
LBB5_113:
	cmp	w20, #83
	b.ne	LBB5_157
; %bb.114:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	mov	w3, #9                          ; =0x9
	strh	w3, [x21, #1584]
	b	LBB5_71
LBB5_115:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh134:
	adrp	x8, l_.str.70@PAGE
Lloh135:
	add	x8, x8, l_.str.70@PAGEOFF
	b	LBB5_23
LBB5_116:
Lloh136:
	adrp	x8, l_.str.65@PAGE
Lloh137:
	add	x8, x8, l_.str.65@PAGEOFF
	mov	x2, x27
LBB5_117:
	mov	w0, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w2, wzr, [x26, #8]
	b	LBB5_23
LBB5_118:
	mov	x25, x4
	mov	x24, x2
	ldrh	w8, [x22, #8]
	add	x9, x28, x8, lsl #3
	ldp	w10, w21, [x9, #16]
	mov	w9, #24                         ; =0x18
	add	x11, sp, #128
	umaddl	x19, w8, w9, x11
	orr	x1, x10, x21, lsl #32
	mov	x0, x19
	bl	_mf_type_matches
	tbz	w0, #0, LBB5_170
; %bb.119:
	ldr	x8, [x25]
	ldr	x8, [x8]
	add	x8, x8, x21, lsl #4
	mov	w9, #1                          ; =0x1
	strh	w9, [x19]
	stur	xzr, [x19, #10]
	stur	xzr, [x19, #2]
	str	xzr, [x19, #16]
	ldrh	w10, [x8, #2]
	cbz	w10, LBB5_194
; %bb.120:
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	w12, #24                        ; =0x18
	mov	x13, x23
	ldp	x15, x17, [sp, #56]             ; 16-byte Folded Reload
LBB5_121:                               ; =>This Inner Loop Header: Depth=1
	add	w23, w13, #1
	and	x13, x13, #0xffff
	umaddl	x13, w13, w12, x15
	ldr	x14, [x8, #8]
	ldrb	w14, [x14, x10]
	lsl	w14, w9, w14
	strh	w14, [x13]
	stur	xzr, [x13, #10]
	stur	xzr, [x13, #2]
	str	xzr, [x13, #16]
	add	x11, x11, #1
	ldrh	w14, [x8, #2]
	add	x10, x10, #12
	mov	x13, x23
	cmp	x11, x14
	b.lo	LBB5_121
	b	LBB5_74
LBB5_122:
	ldrh	w8, [x22, #8]
	mov	w9, #24                         ; =0x18
	add	x10, sp, #128
	umaddl	x11, w8, w9, x10
	ldrh	w3, [x11]
	ldur	w9, [x11, #2]
	str	w9, [sp, #120]
	ldrh	w9, [x11, #6]
	strh	w9, [sp, #124]
	ldr	x16, [x11, #8]
	ldr	w0, [x11, #16]
	ldrh	w9, [x11, #20]
	ldrb	w10, [x11, #22]
	ldrb	w15, [x11, #23]
	add	x11, x17, #108, lsl #12         ; =442368
	ldrb	w11, [x11, #188]
	cmp	w11, #1
	b.ne	LBB5_124
; %bb.123:
	add	x11, x28, x8, lsl #3
	ldrb	w11, [x11, #16]
	sub	w11, w11, #9
	and	w12, w3, #0x1
	cmn	w11, #2
	ccmp	w12, #0, #4, hs
	b.ne	LBB5_191
LBB5_124:
	mov	w11, #2                         ; =0x2
	cmp	w10, #1
	csel	w12, w11, w10, eq
	csel	w11, w8, w9, eq
	b	LBB5_71
LBB5_125:
	ldr	w0, [x22, #8]
	ldr	x8, [x4]
	ldr	x8, [x8]
	add	x8, x8, x0, lsl #4
	ldrh	w11, [x8, #2]
	cbz	x11, LBB5_168
; %bb.126:
	mov	x9, #0                          ; =0x0
	add	x10, x17, #108, lsl #12         ; =442368
	ldrb	w10, [x10, #188]
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #2
	mov	w12, #24                        ; =0x18
	umull	x13, w25, w12
	umaddl	x12, w1, w12, x13
	add	x13, sp, #128
	add	x12, x12, x13
	add	x12, x12, #23
	mov	w13, #1                         ; =0x1
	b	LBB5_128
LBB5_127:                               ;   in Loop: Header=BB5_128 Depth=1
	add	x9, x9, #12
	add	x12, x12, #24
	cmp	x11, x9
	b.eq	LBB5_168
LBB5_128:                               ; =>This Inner Loop Header: Depth=1
	cbz	w10, LBB5_127
; %bb.129:                              ;   in Loop: Header=BB5_128 Depth=1
	ldur	x14, [x12, #-15]
	ldurb	w15, [x12, #-1]
	ldrb	w16, [x12]
	cmp	w16, #0
	ccmp	w15, #0, #0, eq
	ccmp	x14, #0, #0, eq
	b.ne	LBB5_131
; %bb.130:                              ;   in Loop: Header=BB5_128 Depth=1
	ldurh	w14, [x12, #-23]
	ldr	x15, [x8, #8]
	ldrb	w15, [x15, x9]
	lsl	w15, w13, w15
	cmp	w14, w15, uxth
	b.eq	LBB5_127
LBB5_131:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh138:
	adrp	x8, l_.str.55@PAGE
Lloh139:
	add	x8, x8, l_.str.55@PAGEOFF
	b	LBB5_23
LBB5_132:
	ldr	w8, [x22, #8]
	ldr	x9, [x17]
	ldr	x10, [x9, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x10, w8, w9, x10
	ldrh	w23, [x10, #4]
	cbz	x23, LBB5_175
; %bb.133:
	mov	w10, #2068                      ; =0x814
	umaddl	x11, w8, w10, x17
	add	x12, x17, #108, lsl #12         ; =442368
	ldrb	w25, [x12, #188]
	umull	x24, w8, w10
	add	x27, x11, #32
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x21, w1, w9, x8
	b	LBB5_135
LBB5_134:                               ;   in Loop: Header=BB5_135 Depth=1
	add	x21, x21, #24
	add	x27, x27, #8
	subs	x23, x23, #1
	b.eq	LBB5_176
LBB5_135:                               ; =>This Inner Loop Header: Depth=1
	cbz	w25, LBB5_134
; %bb.136:                              ;   in Loop: Header=BB5_135 Depth=1
	ldr	x1, [x27]
	mov	x0, x21
	mov	x28, x2
	bl	_mf_type_matches
	mov	x2, x28
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	cbnz	w0, LBB5_134
; %bb.137:
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh140:
	adrp	x8, l_.str.68@PAGE
Lloh141:
	add	x8, x8, l_.str.68@PAGEOFF
	b	LBB5_23
LBB5_138:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w23, w8, x9
	ldurh	w9, [x8, #-24]
	ldur	w10, [x8, #-22]
	str	w10, [sp, #120]
	ldurh	w11, [x8, #-18]
	strh	w11, [sp, #124]
	ldur	x12, [x8, #-16]
	ldp	w13, w14, [x8, #-8]
	ldur	q0, [x8, #-48]
	stur	q0, [x8, #-24]
	ldur	x15, [x8, #-32]
	stur	x15, [x8, #-8]
	sturh	w9, [x8, #-48]
	stur	w10, [x8, #-46]
	sturh	w11, [x8, #-42]
	stur	x12, [x8, #-40]
	stp	w13, w14, [x8, #-32]
	b	LBB5_74
LBB5_139:
	mov	x21, x2
	ldrh	w8, [x22, #8]
	mov	w9, #24                         ; =0x18
	add	x10, sp, #128
	umaddl	x19, w8, w9, x10
	ldrh	w13, [x19]
	ldur	w9, [x19, #2]
	str	w9, [sp, #120]
	ldrh	w9, [x19, #6]
	strh	w9, [sp, #124]
	ldr	x12, [x19, #8]
	ldr	w11, [x19, #16]
	ldrh	w14, [x19, #20]
	ldrb	w27, [x19, #22]
	ldrb	w10, [x19, #23]
	add	x8, x28, x8, lsl #3
	str	w13, [sp, #36]                  ; 4-byte Folded Spill
	strh	w13, [sp, #80]
	ldur	w9, [x19, #2]
	stur	w9, [sp, #82]
	ldrh	w9, [x19, #6]
	strh	w9, [sp, #86]
	mov	x25, x12
	str	x12, [sp, #88]
	mov	x24, x11
	str	w11, [sp, #96]
	mov	x28, x14
	strh	w14, [sp, #100]
	strb	w27, [sp, #102]
	mov	x23, x10
	strb	w10, [sp, #103]
	ldr	x1, [x8, #16]
	add	x0, sp, #80
	bl	_mf_type_matches
	tbz	w0, #0, LBB5_171
; %bb.140:
	cbz	w27, LBB5_195
; %bb.141:
	mov	x12, x27
	mov	w8, #1                          ; =0x1
	strh	w8, [x19]
	orr	x8, x19, #0x2
	stp	xzr, xzr, [x8]
	stur	xzr, [x8, #14]
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	mov	x15, x23
	mov	x0, x24
	mov	x16, x25
	ldr	w3, [sp, #36]                   ; 4-byte Folded Reload
	mov	x11, x28
	b	LBB5_71
LBB5_142:
	ldrh	w8, [x22, #8]
	mov	w9, #24                         ; =0x18
	add	x10, sp, #128
	umaddl	x19, w8, w9, x10
	ldrb	w9, [x19, #22]
	cbnz	w9, LBB5_156
; %bb.143:
	ldr	x9, [x19, #8]
	ldrb	w10, [x19, #23]
	cmp	w10, #0
	ccmp	x9, #0, #0, eq
	b.ne	LBB5_156
; %bb.144:
	ldrh	w9, [x19]
	cmp	w9, #1
	b.ne	LBB5_156
; %bb.145:
	mov	w9, #24                         ; =0x18
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	umaddl	x23, w1, w9, x10
	add	x8, x28, x8, lsl #3
	ldr	x1, [x8, #16]
	mov	x0, x23
	mov	x21, x2
	bl	_mf_type_matches
	mov	x2, x21
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	cbz	w0, LBB5_156
; %bb.146:
	ldrb	w8, [x23, #22]
	cmp	w8, #1
	b.ne	LBB5_156
; %bb.147:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w3, #0                          ; =0x0
	ldr	q0, [x23]
	ldr	x8, [x23, #16]
	str	x8, [x19, #16]
	str	q0, [x19]
	b	LBB5_71
LBB5_148:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w23, w8, x9
	ldurh	w9, [x8, #-24]
	ldur	w10, [x8, #-22]
	str	w10, [sp, #120]
	ldurh	w10, [x8, #-18]
	strh	w10, [sp, #124]
	ldur	x10, [x8, #-16]
	ldp	w11, w12, [x8, #-8]
	ldur	q0, [x8, #-48]
	stur	q0, [x8, #-24]
	ldur	x13, [x8, #-32]
	stur	x13, [x8, #-8]
	ldur	x13, [x8, #-56]
	stur	x13, [x8, #-32]
	ldur	q0, [x8, #-72]
	stur	q0, [x8, #-48]
	sturh	w9, [x8, #-72]
	ldr	w9, [sp, #120]
	ldrh	w13, [sp, #124]
	sturh	w13, [x8, #-66]
	stur	w9, [x8, #-70]
	stur	x10, [x8, #-64]
	stp	w11, w12, [x8, #-56]
	b	LBB5_74
LBB5_149:
	ldrh	w11, [x22, #8]
	add	x8, x28, x11, lsl #3
	ldrb	w9, [x8, #16]
	ldr	w8, [x8, #20]
	mov	w10, #24                        ; =0x18
	ldr	x12, [sp, #56]                  ; 8-byte Folded Reload
	umaddl	x10, w1, w10, x12
	ldrh	w3, [x10]
	mov	x19, x10
	ldr	w12, [x19, #2]!
	str	w12, [sp, #120]
	ldrh	w12, [x10, #6]
	strh	w12, [sp, #124]
	ldrb	w12, [x10, #22]
	cbnz	w12, LBB5_151
; %bb.150:
	mov	w12, #24                        ; =0x18
	add	x13, sp, #128
	umaddl	x21, w11, w12, x13
	ldrb	w11, [x21, #22]
	cbz	w11, LBB5_196
LBB5_151:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh142:
	adrp	x8, l_.str.50@PAGE
Lloh143:
	add	x8, x8, l_.str.50@PAGEOFF
	b	LBB5_23
LBB5_152:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w1, w8, x9
	ldrb	w8, [x8, #22]
	cbz	w8, LBB5_173
; %bb.153:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh144:
	adrp	x8, l_.str.48@PAGE
Lloh145:
	add	x8, x8, l_.str.48@PAGEOFF
	b	LBB5_23
LBB5_154:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w23, w8, x9
	ldurb	w9, [x8, #-2]
	cbz	w9, LBB5_179
; %bb.155:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh146:
	adrp	x8, l_.str.47@PAGE
Lloh147:
	add	x8, x8, l_.str.47@PAGEOFF
	b	LBB5_23
LBB5_156:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh148:
	adrp	x8, l_.str.54@PAGE
Lloh149:
	add	x8, x8, l_.str.54@PAGEOFF
	b	LBB5_23
LBB5_157:
	ldur	w8, [x19, #2]
	str	w8, [sp, #120]
	ldurh	w8, [x19, #6]
	strh	w8, [sp, #124]
	cbz	w24, LBB5_71
; %bb.158:
	ldr	w8, [x4, #20]
	add	w8, w8, #1
	str	w8, [x4, #20]
	b	LBB5_71
LBB5_159:
	ldrsh	x8, [x22, #80]
	ldr	x9, [x4]
	ldr	x9, [x9]
	mov	w19, #24                        ; =0x18
	smaddl	x10, w8, w19, x4
	ldr	w10, [x10, #36]
	add	x24, x9, x10, lsl #4
	ldrh	w27, [x24, #2]
	cbz	w27, LBB5_193
; %bb.160:
	mov	x25, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
Lloh150:
	adrp	x23, l_.str.57@PAGE
Lloh151:
	add	x23, x23, l_.str.57@PAGEOFF
	mov	x28, x1
	b	LBB5_163
LBB5_161:                               ;   in Loop: Header=BB5_163 Depth=1
	ldrsh	w1, [x22, #80]
	ldr	q0, [x8]
	str	q0, [sp, #80]
	ldur	x8, [x8, #14]
	stur	x8, [sp, #94]
	strh	wzr, [sp, #102]
	add	x3, sp, #80
	mov	x0, x17
	mov	x2, x21
	bl	_mf_field_union
	ldrh	w27, [x24, #2]
LBB5_162:                               ;   in Loop: Header=BB5_163 Depth=1
	add	x21, x21, #1
	add	w28, w28, #1
	add	x25, x25, #12
	cmp	x21, w27, uxtw
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	b.hs	LBB5_192
LBB5_163:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	umaddl	x8, w28, w19, x8
	ldrb	w9, [x8, #22]
	ldrb	w10, [x8, #23]
	and	w10, w10, #0xff
	orr	w9, w9, w10
	cbnz	w9, LBB5_167
; %bb.164:                              ;   in Loop: Header=BB5_163 Depth=1
	add	x9, x17, #108, lsl #12          ; =442368
	ldrb	w9, [x9, #188]
	cmp	w9, #1
	b.ne	LBB5_161
; %bb.165:                              ;   in Loop: Header=BB5_163 Depth=1
	ldr	x9, [x24, #8]
	ldr	q0, [x8]
	str	q0, [sp, #80]
	ldur	x8, [x8, #14]
	stur	x8, [sp, #94]
	strh	wzr, [sp, #102]
	add	x1, sp, #80
	add	x2, x9, x25
	mov	x0, x17
	bl	_mf_field_matches
	tbnz	w0, #0, LBB5_162
; %bb.166:
Lloh152:
	adrp	x23, l_.str.58@PAGE
Lloh153:
	add	x23, x23, l_.str.58@PAGEOFF
LBB5_167:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	mov	w10, #1                         ; =0x1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	stp	w10, w9, [x26]
	stp	w8, wzr, [x26, #8]
	str	x23, [x26, #16]
	b	LBB5_24
LBB5_168:
	mov	w15, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	mov	w3, #256                        ; =0x100
	mov	w12, #1                         ; =0x1
	b	LBB5_71
LBB5_169:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	mov	w3, #2                          ; =0x2
	b	LBB5_71
LBB5_170:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w24, wzr, [x26, #8]
Lloh154:
	adrp	x8, l_.str.56@PAGE
Lloh155:
	add	x8, x8, l_.str.56@PAGEOFF
	b	LBB5_23
LBB5_171:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w21, wzr, [x26, #8]
Lloh156:
	adrp	x8, l_.str.52@PAGE
Lloh157:
	add	x8, x8, l_.str.52@PAGEOFF
	b	LBB5_23
LBB5_172:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh158:
	adrp	x8, l_.str.59@PAGE
Lloh159:
	add	x8, x8, l_.str.59@PAGEOFF
	b	LBB5_23
LBB5_173:
	mov	w15, #0                         ; =0x0
LBB5_174:
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w3, #0                          ; =0x0
	b	LBB5_71
LBB5_175:
	mov	w9, #2068                       ; =0x814
	umull	x24, w8, w9
LBB5_176:
	add	x9, x19, x24
	ldrb	w8, [x9, #8]
	cmp	w8, #8
	b.ne	LBB5_178
; %bb.177:
	mov	w15, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	w0, [x9, #12]
	str	wzr, [sp, #120]
	mov	w3, #256                        ; =0x100
	mov	w12, #1                         ; =0x1
	strh	wzr, [sp, #124]
	b	LBB5_71
LBB5_178:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	mov	w9, #1                          ; =0x1
	lsl	w8, w9, w8
	and	w3, w8, #0xffff
	b	LBB5_71
LBB5_179:
	ldur	q0, [x8, #-24]
	str	q0, [x8]
	ldur	x9, [x8, #-8]
	str	x9, [x8, #16]
	add	w23, w23, #1
	b	LBB5_74
LBB5_180:
	ldr	x9, [x11, #8]
	ldrb	w15, [x11, #23]
	add	x10, x17, #108, lsl #12         ; =442368
	ldrb	w10, [x10, #188]
	cmp	w10, #1
	b.ne	LBB5_184
; %bb.181:
	cbnz	w15, LBB5_204
; %bb.182:
	ldrh	w10, [x11]
	cmp	w10, #256
	b.ne	LBB5_204
; %bb.183:
	cbz	x9, LBB5_204
LBB5_184:
	ldr	w10, [x4, #8]
	cbz	w10, LBB5_174
; %bb.185:
	mov	x11, #0                         ; =0x0
	mov	w3, #0                          ; =0x0
	mov	x16, #0                         ; =0x0
	add	x12, x4, #50
	b	LBB5_187
LBB5_186:                               ;   in Loop: Header=BB5_187 Depth=1
	add	x11, x11, #1
	add	x12, x12, #24
	cmp	x10, x11
	b.eq	LBB5_206
LBB5_187:                               ; =>This Inner Loop Header: Depth=1
	lsr	x13, x9, x11
	tbz	w13, #0, LBB5_186
; %bb.188:                              ;   in Loop: Header=BB5_187 Depth=1
	ldrb	w13, [x12]
	cmp	w13, #8
	b.ne	LBB5_202
; %bb.189:                              ;   in Loop: Header=BB5_187 Depth=1
	ldurh	w13, [x12, #-2]
	cmp	w8, w13
	b.hs	LBB5_202
; %bb.190:                              ;   in Loop: Header=BB5_187 Depth=1
	ldr	x13, [x4, #1568]
	ldur	w14, [x12, #-6]
	add	w14, w14, w8
	add	x13, x13, w14, uxtw #4
	ldrh	w14, [x13]
	orr	w3, w14, w3
	ldr	x13, [x13, #8]
	orr	x16, x13, x16
	b	LBB5_186
LBB5_191:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh160:
	adrp	x8, l_.str.49@PAGE
Lloh161:
	add	x8, x8, l_.str.49@PAGEOFF
	b	LBB5_23
LBB5_192:
	ldrsh	x8, [x22, #80]
LBB5_193:
	mov	w15, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	strh	wzr, [sp, #124]
	str	wzr, [sp, #120]
	mov	w9, #1                          ; =0x1
	lsl	x16, x9, x8
	mov	w3, #256                        ; =0x100
	b	LBB5_71
LBB5_194:
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	b	LBB5_74
LBB5_195:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w21, wzr, [x26, #8]
Lloh162:
	adrp	x8, l_.str.53@PAGE
Lloh163:
	add	x8, x8, l_.str.53@PAGEOFF
	b	LBB5_23
LBB5_196:
	ldr	x16, [x10, #8]
	ldr	w0, [x10, #16]
	ldrh	w11, [x10, #20]
	ldrb	w15, [x10, #23]
	add	x10, x17, #108, lsl #12         ; =442368
	ldrb	w10, [x10, #188]
	cmp	w10, #1
	b.ne	LBB5_199
; %bb.197:
	mov	x23, x2
	strb	w9, [sp, #104]
	sturh	wzr, [sp, #105]
	strb	wzr, [sp, #107]
	mov	w9, #-1                         ; =0xffffffff
	stp	w8, w9, [sp, #108]
	str	w3, [sp, #36]                   ; 4-byte Folded Spill
	strh	w3, [sp, #80]
	ldr	w8, [x19]
	stur	w8, [sp, #82]
	ldrh	w8, [x19, #4]
	strh	w8, [sp, #86]
	mov	x27, x16
	str	x16, [sp, #88]
	mov	x25, x0
	str	w0, [sp, #96]
	mov	x28, x11
	strh	w11, [sp, #100]
	strb	wzr, [sp, #102]
	mov	x24, x15
	strb	w15, [sp, #103]
	add	x1, sp, #80
	add	x2, sp, #104
	mov	x0, x17
	bl	_mf_field_matches
	tbz	w0, #0, LBB5_207
; %bb.198:
	ldr	x17, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	mov	x15, x24
	mov	x0, x25
	mov	x16, x27
	ldr	w3, [sp, #36]                   ; 4-byte Folded Reload
	mov	x11, x28
LBB5_199:
	mov	w12, #0                         ; =0x0
	strh	w3, [x21]
	ldrh	w8, [x19, #4]
	ldr	w9, [x19]
	stur	w9, [x21, #2]
	strh	w8, [x21, #6]
	str	x16, [x21, #8]
	str	w0, [x21, #16]
	strh	w11, [x21, #20]
	strb	wzr, [x21, #22]
	strb	w15, [x21, #23]
	b	LBB5_71
LBB5_200:
Lloh164:
	adrp	x8, l_.str.67@PAGE
Lloh165:
	add	x8, x8, l_.str.67@PAGEOFF
	b	LBB5_117
LBB5_201:
Lloh166:
	adrp	x8, l_.str.66@PAGE
Lloh167:
	add	x8, x8, l_.str.66@PAGEOFF
	b	LBB5_117
LBB5_202:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh168:
	adrp	x8, l_.str.63@PAGE
Lloh169:
	add	x8, x8, l_.str.63@PAGEOFF
	b	LBB5_23
LBB5_203:
	mov	w0, #0                          ; =0x0
	mov	w9, #2                          ; =0x2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh170:
	adrp	x8, l_.str.60@PAGE
Lloh171:
	add	x8, x8, l_.str.60@PAGEOFF
	b	LBB5_23
LBB5_204:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh172:
	adrp	x8, l_.str.62@PAGE
Lloh173:
	add	x8, x8, l_.str.62@PAGEOFF
	b	LBB5_23
LBB5_205:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w2, wzr, [x26, #8]
Lloh174:
	adrp	x8, l_.str.61@PAGE
Lloh175:
	add	x8, x8, l_.str.61@PAGEOFF
	b	LBB5_23
LBB5_206:
	mov	w12, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	b	LBB5_71
LBB5_207:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stp	w9, w8, [x26]
	stp	w23, wzr, [x26, #8]
Lloh176:
	adrp	x8, l_.str.51@PAGE
Lloh177:
	add	x8, x8, l_.str.51@PAGEOFF
	b	LBB5_23
LBB5_208:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh104, Lloh105, Lloh106
	.loh AdrpAdd	Lloh107, Lloh108
	.loh AdrpLdrGotLdr	Lloh109, Lloh110, Lloh111
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpLdrGot	Lloh102, Lloh103
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI5_0:
	.short	(LBB5_71-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_154-LBB5_52)>>2
	.short	(LBB5_152-LBB5_52)>>2
	.short	(LBB5_138-LBB5_52)>>2
	.short	(LBB5_148-LBB5_52)>>2
	.short	(LBB5_139-LBB5_52)>>2
	.short	(LBB5_142-LBB5_52)>>2
	.short	(LBB5_125-LBB5_52)>>2
	.short	(LBB5_118-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_122-LBB5_52)>>2
	.short	(LBB5_149-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_71-LBB5_52)>>2
	.short	(LBB5_81-LBB5_52)>>2
	.short	(LBB5_81-LBB5_52)>>2
	.short	(LBB5_132-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_98-LBB5_52)>>2
	.short	(LBB5_52-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_52-LBB5_52)>>2
	.short	(LBB5_52-LBB5_52)>>2
	.short	(LBB5_52-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_98-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_115-LBB5_52)>>2
	.short	(LBB5_81-LBB5_52)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function mf_graph
_mf_graph:                              ; @mf_graph
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w8, #2068                       ; =0x814
	umaddl	x21, w1, w8, x0
	ldrb	w8, [x21, #2081]
	cmp	w8, #2
	b.eq	LBB6_10
; %bb.1:
	mov	x19, x0
	cmp	w8, #1
	b.ne	LBB6_3
; %bb.2:
	mov	w0, #0                          ; =0x0
	add	x8, x19, #112, lsl #12          ; =458752
	mov	w9, #1                          ; =0x1
	stp	w9, w1, [x8, #208]
Lloh178:
	adrp	x9, l_.str.34@PAGE
Lloh179:
	add	x9, x9, l_.str.34@PAGEOFF
	stp	xzr, x9, [x8, #216]
	b	LBB6_11
LBB6_3:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2081]
	ldr	x8, [x19]
	ldr	w9, [x8, #272]
	cbz	w9, LBB6_9
; %bb.4:
	mov	w20, #0                         ; =0x0
	b	LBB6_6
LBB6_5:                                 ;   in Loop: Header=BB6_6 Depth=1
	add	w20, w20, #1
	ldr	w9, [x8, #272]
	cmp	w20, w9
	b.hs	LBB6_9
LBB6_6:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x21, #2080]
	lsr	w9, w9, w20
	tbz	w9, #0, LBB6_5
; %bb.7:                                ;   in Loop: Header=BB6_6 Depth=1
	mov	x0, x19
	mov	x1, x20
	bl	_mf_graph
	cbz	w0, LBB6_11
; %bb.8:                                ;   in Loop: Header=BB6_6 Depth=1
	ldr	x8, [x19]
	b	LBB6_5
LBB6_9:
	mov	w8, #2                          ; =0x2
	strb	w8, [x21, #2081]
LBB6_10:
	mov	w0, #1                          ; =0x1
LBB6_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh178, Lloh179
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_scalar_op
_mf_scalar_op:                          ; @mf_scalar_op
	.cfi_startproc
; %bb.0:
	strh	wzr, [x1]
	sub	w8, w0, #1
	cmp	w8, #225
	b.hi	LBB7_12
; %bb.1:
Lloh180:
	adrp	x9, lJTI7_0@PAGE
Lloh181:
	add	x9, x9, lJTI7_0@PAGEOFF
	adr	x10, LBB7_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB7_2:
	mov	w0, #4                          ; =0x4
	ret
LBB7_3:
	mov	w8, #2                          ; =0x2
	b	LBB7_8
LBB7_4:
	mov	w8, #2                          ; =0x2
	strh	w8, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB7_5:
	mov	w8, #8                          ; =0x8
	b	LBB7_8
LBB7_6:
	mov	w8, #8                          ; =0x8
	strh	w8, [x1]
	mov	w0, #3                          ; =0x3
	ret
LBB7_7:
	mov	w8, #16                         ; =0x10
LBB7_8:
	strh	w8, [x1]
	mov	w0, #4                          ; =0x4
	ret
LBB7_9:
	mov	w0, #0                          ; =0x0
	ret
LBB7_10:
	mov	w0, #2                          ; =0x2
	ret
LBB7_11:
	mov	w0, #3                          ; =0x3
	ret
LBB7_12:
	mov	w0, #-1                         ; =0xffffffff
LBB7_13:
	ret
	.loh AdrpAdd	Lloh180, Lloh181
	.cfi_endproc
	.section	__TEXT,__const
lJTI7_0:
	.byte	(LBB7_13-LBB7_2)>>2
	.byte	(LBB7_11-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_9-LBB7_2)>>2
	.byte	(LBB7_10-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_2-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_4-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_6-LBB7_2)>>2
	.byte	(LBB7_6-LBB7_2)>>2
	.byte	(LBB7_6-LBB7_2)>>2
	.byte	(LBB7_6-LBB7_2)>>2
	.byte	(LBB7_6-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_3-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_5-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_12-LBB7_2)>>2
	.byte	(LBB7_7-LBB7_2)>>2
	.byte	(LBB7_7-LBB7_2)>>2
	.byte	(LBB7_7-LBB7_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function mf_type_matches
_mf_type_matches:                       ; @mf_type_matches
	.cfi_startproc
; %bb.0:
	and	w8, w1, #0xff
	cmp	w8, #8
	b.ne	LBB8_6
; %bb.1:
	ldrb	w8, [x0, #22]
	cmp	w8, #1
	b.ne	LBB8_7
; %bb.2:
	ldrb	w8, [x0, #23]
	cbnz	w8, LBB8_7
; %bb.3:
	ldr	x8, [x0, #8]
	cbnz	x8, LBB8_7
; %bb.4:
	ldrh	w8, [x0]
	cmp	w8, #256
	b.ne	LBB8_7
; %bb.5:
	lsr	x8, x1, #32
	ldr	w9, [x0, #16]
	cmp	w9, w8
	cset	w0, eq
	ret
LBB8_6:
	ldr	x9, [x0, #8]
	ldrb	w10, [x0, #22]
	ldrb	w11, [x0, #23]
	cmp	w11, #0
	ccmp	w10, #0, #0, eq
	ccmp	x9, #0, #0, eq
	b.eq	LBB8_8
LBB8_7:
	mov	w0, #0                          ; =0x0
	ret
LBB8_8:
	ldrh	w9, [x0]
	mov	w10, #1                         ; =0x1
	lsl	w8, w10, w8
	cmp	w9, w8, uxth
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_field_matches
_mf_field_matches:                      ; @mf_field_matches
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1, #22]
	cbnz	w8, LBB9_19
; %bb.1:
	ldrb	w8, [x1, #23]
	cbnz	w8, LBB9_19
; %bb.2:
	ldrh	w9, [x1]
	ldrb	w10, [x2]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w10
	cmp	w9, w8, uxth
	b.ne	LBB9_19
; %bb.3:
	ldr	x8, [x1, #8]
	cmp	w10, #8
	b.eq	LBB9_12
; %bb.4:
	cmp	w10, #7
	b.ne	LBB9_20
; %bb.5:
	mov	x10, x0
	mov	w0, #0                          ; =0x0
	cmp	w9, #128
	b.ne	LBB9_21
; %bb.6:
	cbz	x8, LBB9_21
; %bb.7:
	ldr	x11, [x10, #8]
	ldr	w9, [x11, #8]
	cbz	w9, LBB9_22
; %bb.8:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #50
	mov	w0, #1                          ; =0x1
	b	LBB9_10
LBB9_9:                                 ;   in Loop: Header=BB9_10 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB9_21
LBB9_10:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB9_9
; %bb.11:                               ;   in Loop: Header=BB9_10 Depth=1
	ldrb	w12, [x11]
	cmp	w12, #7
	b.eq	LBB9_9
	b	LBB9_19
LBB9_12:
	cbz	x8, LBB9_19
; %bb.13:
	ldr	x11, [x0, #8]
	ldr	w9, [x11, #8]
	cbz	w9, LBB9_22
; %bb.14:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #36
	mov	w0, #1                          ; =0x1
	b	LBB9_16
LBB9_15:                                ;   in Loop: Header=BB9_16 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB9_21
LBB9_16:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB9_15
; %bb.17:                               ;   in Loop: Header=BB9_16 Depth=1
	ldrb	w12, [x11, #14]
	cmp	w12, #8
	b.ne	LBB9_19
; %bb.18:                               ;   in Loop: Header=BB9_16 Depth=1
	ldr	w12, [x11]
	ldr	w13, [x2, #4]
	cmp	w12, w13
	b.eq	LBB9_15
LBB9_19:
	mov	w0, #0                          ; =0x0
	ret
LBB9_20:
	tst	w9, #0x1f
	ccmp	x8, #0, #0, ne
	cset	w0, eq
LBB9_21:
	ret
LBB9_22:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_field_union
_mf_field_union:                        ; @mf_field_union
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #8]
	ldr	x9, [x8, #1568]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w1, w10, x8
	ldr	w8, [x8, #44]
	add	w8, w8, w2
	add	x8, x9, w8, uxtw #4
	ldrh	w9, [x8]
	ldr	x10, [x8, #8]
	ldrh	w11, [x3]
	orr	w11, w11, w9
	strh	w11, [x8]
	ldr	x12, [x3, #8]
	orr	x12, x12, x10
	str	x12, [x8, #8]
	cmp	w9, w11, uxth
	ccmp	x10, x12, #0, eq
	b.eq	LBB10_10
; %bb.1:
	add	x8, x0, #108, lsl #12           ; =442368
	ldr	w13, [x8, #176]
	cbz	w13, LBB10_10
; %bb.2:
	add	x8, x0, #112, lsl #12           ; =458752
	add	x8, x8, #196
	add	x9, x0, #108, lsl #12           ; =442368
	add	x9, x9, #192
	and	x10, x13, #0x7
	cmp	w13, #8
	b.hs	LBB10_11
; %bb.3:
	mov	x11, #0                         ; =0x0
LBB10_4:
	cbz	x10, LBB10_10
; %bb.5:
	mov	w12, #104                       ; =0x68
	madd	x12, x11, x12, x0
	mov	w13, #16656                     ; =0x4110
	add	x12, x12, x13
	mov	w13, #1                         ; =0x1
	b	LBB10_7
LBB10_6:                                ;   in Loop: Header=BB10_7 Depth=1
	add	w11, w11, #1
	add	x12, x12, #104
	subs	x10, x10, #1
	b.eq	LBB10_10
LBB10_7:                                ; =>This Inner Loop Header: Depth=1
	ldur	x14, [x12, #-8]
	cbz	x14, LBB10_6
; %bb.8:                                ;   in Loop: Header=BB10_7 Depth=1
	ldrb	w14, [x12]
	tbnz	w14, #0, LBB10_6
; %bb.9:                                ;   in Loop: Header=BB10_7 Depth=1
	strb	w13, [x12]
	ldr	w14, [x8]
	str	w11, [x9, x14, lsl #2]
	ldp	w14, w15, [x8]
	add	w14, w14, #1
	and	w14, w14, #0xfff
	add	w15, w15, #1
	stp	w14, w15, [x8]
	b	LBB10_6
LBB10_10:
	ret
LBB10_11:
	mov	x11, #0                         ; =0x0
	mov	w12, #16648                     ; =0x4108
	add	x12, x0, x12
	and	x13, x13, #0xfffffff8
	mov	w14, #1                         ; =0x1
	b	LBB10_13
LBB10_12:                               ;   in Loop: Header=BB10_13 Depth=1
	add	x11, x11, #8
	add	x12, x12, #832
	cmp	x13, x11
	b.eq	LBB10_4
LBB10_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	x15, [x12]
	cbz	x15, LBB10_16
; %bb.14:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #8]
	tbnz	w15, #0, LBB10_16
; %bb.15:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #8]
	ldr	w15, [x8]
	str	w11, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_16:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #104]
	cbz	x15, LBB10_19
; %bb.17:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #112]
	tbnz	w15, #0, LBB10_19
; %bb.18:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #112]
	ldr	w15, [x8]
	add	w16, w11, #1
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_19:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #208]
	cbz	x15, LBB10_22
; %bb.20:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #216]
	tbnz	w15, #0, LBB10_22
; %bb.21:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #216]
	ldr	w15, [x8]
	add	w16, w11, #2
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_22:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #312]
	cbz	x15, LBB10_25
; %bb.23:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #320]
	tbnz	w15, #0, LBB10_25
; %bb.24:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #320]
	ldr	w15, [x8]
	add	w16, w11, #3
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_25:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #416]
	cbz	x15, LBB10_28
; %bb.26:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #424]
	tbnz	w15, #0, LBB10_28
; %bb.27:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #424]
	ldr	w15, [x8]
	add	w16, w11, #4
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_28:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #520]
	cbz	x15, LBB10_31
; %bb.29:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #528]
	tbnz	w15, #0, LBB10_31
; %bb.30:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #528]
	ldr	w15, [x8]
	add	w16, w11, #5
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_31:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #624]
	cbz	x15, LBB10_34
; %bb.32:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #632]
	tbnz	w15, #0, LBB10_34
; %bb.33:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #632]
	ldr	w15, [x8]
	add	w16, w11, #6
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
LBB10_34:                               ;   in Loop: Header=BB10_13 Depth=1
	ldr	x15, [x12, #728]
	cbz	x15, LBB10_12
; %bb.35:                               ;   in Loop: Header=BB10_13 Depth=1
	ldrb	w15, [x12, #736]
	tbnz	w15, #0, LBB10_12
; %bb.36:                               ;   in Loop: Header=BB10_13 Depth=1
	strb	w14, [x12, #736]
	ldr	w15, [x8]
	add	w16, w11, #7
	str	w16, [x9, x15, lsl #2]
	ldp	w15, w16, [x8]
	add	w15, w15, #1
	and	w15, w15, #0xfff
	add	w16, w16, #1
	stp	w15, w16, [x8]
	b	LBB10_12
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mf_array
_mf_array:                              ; @mf_array
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1, #22]
	cbnz	w8, LBB11_9
; %bb.1:
	ldrb	w8, [x1, #23]
	cbnz	w8, LBB11_9
; %bb.2:
	ldrh	w8, [x1]
	cmp	w8, #128
	b.ne	LBB11_9
; %bb.3:
	ldr	x8, [x1, #8]
	cbz	x8, LBB11_9
; %bb.4:
	ldr	x11, [x0, #8]
	ldr	w9, [x11, #8]
	cbz	w9, LBB11_11
; %bb.5:
	mov	x10, #0                         ; =0x0
	add	x11, x11, #50
	mov	w0, #1                          ; =0x1
	b	LBB11_7
LBB11_6:                                ;   in Loop: Header=BB11_7 Depth=1
	add	x10, x10, #1
	add	x11, x11, #24
	cmp	x9, x10
	b.eq	LBB11_10
LBB11_7:                                ; =>This Inner Loop Header: Depth=1
	lsr	x12, x8, x10
	tbz	w12, #0, LBB11_6
; %bb.8:                                ;   in Loop: Header=BB11_7 Depth=1
	ldrb	w12, [x11]
	cmp	w12, #7
	b.eq	LBB11_6
LBB11_9:
	mov	w0, #0                          ; =0x0
LBB11_10:
	ret
LBB11_11:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require a complete immutable module and output."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_mixed_float_origins.invalid
l___const.nvm_analyze_mixed_float_origins.invalid:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"I require my standalone eight-function closed value graph."

l_.str.2:                               ; @.str.2
	.asciz	"I reached my function slot or argument budget."

l_.str.3:                               ; @.str.3
	.asciz	"I require explicit mixed declarations."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate my bounded proof."

l_.str.5:                               ; @.str.5
	.asciz	"I could not allocate field summaries."

l_.str.6:                               ; @.str.6
	.asciz	"I reached my shape fixed-point work budget."

l_.str.7:                               ; @.str.7
	.asciz	"I require checked state for every declared instruction."

l_.str.8:                               ; @.str.8
	.asciz	"I proved closed managed shape only; scalar and affine admission remain separate."

l_.str.9:                               ; @.str.9
	.asciz	"I keep reference calls outside my shape proof."

l_.str.10:                              ; @.str.10
	.asciz	"I require concrete parameter tags."

l_.str.11:                              ; @.str.11
	.asciz	"I require existing scalar or scalar-leaf owner signatures."

l_.str.12:                              ; @.str.12
	.asciz	"I retain scalar entry results."

l_.str.13:                              ; @.str.13
	.asciz	"I require exact function name indices."

l_.str.14:                              ; @.str.14
	.asciz	"__init__"

l_.str.15:                              ; @.str.15
	.asciz	"I keep initializer execution outside this proof."

l_.str.16:                              ; @.str.16
	.asciz	"I require complete nonempty code ranges."

l_.str.17:                              ; @.str.17
	.asciz	"I require distinct function code ranges."

l_.str.18:                              ; @.str.18
	.asciz	"I reached my decoded instruction limit."

l_.str.19:                              ; @.str.19
	.asciz	"I require complete decoded instructions."

l_.str.20:                              ; @.str.20
	.asciz	"I have no closed transfer for this opcode."

l_.str.21:                              ; @.str.21
	.asciz	"I require canonical boolean operands."

l_.str.22:                              ; @.str.22
	.asciz	"I require an existing local index."

l_.str.23:                              ; @.str.23
	.asciz	"I require an existing direct callee."

l_.str.24:                              ; @.str.24
	.asciz	"I do not call my entry function."

l_.str.25:                              ; @.str.25
	.asciz	"I require exact scalar-leaf owner effects."

l_.str.26:                              ; @.str.26
	.asciz	"I require an exact ordinary struct constructor."

l_.str.27:                              ; @.str.27
	.asciz	"I require the declared constructor field count."

l_.str.28:                              ; @.str.28
	.asciz	"I require a known nonresource constructor declaration."

l_.str.29:                              ; @.str.29
	.asciz	"I prove only declared packed FLOAT arrays."

l_.str.30:                              ; @.str.30
	.asciz	"I reached my allocation-origin or field-summary budget."

l_.str.31:                              ; @.str.31
	.asciz	"I require explicit terminal instructions, not end-of-code branches."

l_.str.32:                              ; @.str.32
	.asciz	"I require an instruction-boundary branch target."

l_.str.33:                              ; @.str.33
	.asciz	"I require explicit terminal control flow."

l_.str.34:                              ; @.str.34
	.asciz	"I require an acyclic complete call graph."

l_.str.35:                              ; @.str.35
	.asciz	"I reached my shape stack limit."

l_.str.36:                              ; @.str.36
	.asciz	"I require equal stack heights at shape joins."

l_.str.37:                              ; @.str.37
	.asciz	"I reached my shape state budget."

l_.str.38:                              ; @.str.38
	.asciz	"I could not allocate shape state."

l_.str.39:                              ; @.str.39
	.asciz	"I retain exact opaque owner states at joins."

l_.str.40:                              ; @.str.40
	.asciz	"I require the exact declared return count."

l_.str.41:                              ; @.str.41
	.asciz	"I require exact scalar or owned return identity."

l_.str.42:                              ; @.str.42
	.asciz	"I require complete operand stacks."

l_.str.43:                              ; @.str.43
	.asciz	"I reached my operand stack budget."

l_.str.44:                              ; @.str.44
	.asciz	"I cannot consume an observed owner."

l_.str.45:                              ; @.str.45
	.asciz	"I do not feed managed or opaque values to scalar instructions."

l_.str.46:                              ; @.str.46
	.asciz	"I require known scalar input alternatives."

l_.str.47:                              ; @.str.47
	.asciz	"I cannot duplicate an opaque owner or observation."

l_.str.48:                              ; @.str.48
	.asciz	"I require explicit opaque owner consumption."

l_.str.49:                              ; @.str.49
	.asciz	"I require initialized managed or owned local alternatives."

l_.str.50:                              ; @.str.50
	.asciz	"I keep opaque ownership out of ordinary stores."

l_.str.51:                              ; @.str.51
	.asciz	"I require exact initialized local shape."

l_.str.52:                              ; @.str.52
	.asciz	"I require an intact exact owner move."

l_.str.53:                              ; @.str.53
	.asciz	"I require an owner for an owner move."

l_.str.54:                              ; @.str.54
	.asciz	"I require an empty exact owner destination."

l_.str.55:                              ; @.str.55
	.asciz	"I require exact scalar owner fields."

l_.str.56:                              ; @.str.56
	.asciz	"I require an intact exact unpack source."

l_.str.57:                              ; @.str.57
	.asciz	"I refuse owner or unknown ordinary fields."

l_.str.58:                              ; @.str.58
	.asciz	"I require every exact nominal field alternative."

l_.str.59:                              ; @.str.59
	.asciz	"I require an exact owner observation."

l_.str.60:                              ; @.str.60
	.asciz	"I require an existing owner field."

l_.str.61:                              ; @.str.61
	.asciz	"I require the observed owner to remain live."

l_.str.62:                              ; @.str.62
	.asciz	"I require exact ordinary record receiver origins."

l_.str.63:                              ; @.str.63
	.asciz	"I require a field on every receiver alternative."

l_.str.64:                              ; @.str.64
	.asciz	"I require exact FLOAT literal elements."

l_.str.65:                              ; @.str.65
	.asciz	"I require positive closed FLOAT-array origins."

l_.str.66:                              ; @.str.66
	.asciz	"I require exact integer array indices."

l_.str.67:                              ; @.str.67
	.asciz	"I require exact FLOAT writes on every array alias."

l_.str.68:                              ; @.str.68
	.asciz	"I require every positional call identity before transfer."

l_.str.69:                              ; @.str.69
	.asciz	"I require scalar control operands."

l_.str.70:                              ; @.str.70
	.asciz	"I require an explicit shape transfer."

.subsections_via_symbols
