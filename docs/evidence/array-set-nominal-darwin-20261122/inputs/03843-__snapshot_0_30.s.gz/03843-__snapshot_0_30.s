	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_indirect_public_abi ; -- Begin function nvm_services_runtime_indirect_public_abi
	.p2align	2
_nvm_services_runtime_indirect_public_abi: ; @nvm_services_runtime_indirect_public_abi
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	ccmp	x1, #16, #0, eq
	mov	w8, #6728                       ; =0x1a48
	ccmp	x2, x8, #0, eq
	ccmp	x3, #16, #0, eq
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
